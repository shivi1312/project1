package PojoClass;

public class ChgServiceDetailBean {
	
	int serviceId;
	String serviceName;
	String callBackURl;
	int exceptionCount;
	String status;
	boolean isActive=false;
	
	
	
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getCallBackURl() {
		return callBackURl;
	}
	public void setCallBackURl(String callBackURl) {
		this.callBackURl = callBackURl;
	}
	public int getExceptionCount() {
		return exceptionCount;
	}
	public void setExceptionCount(int exceptionCount) {
		this.exceptionCount = exceptionCount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "ChgServiceDetailBean [serviceId=" + serviceId
				+ ", serviceName=" + serviceName + ", callBackURl="
				+ callBackURl + ", exceptionCount=" + exceptionCount
				+ ", status=" + status + "]";
	}
	
	
	

}
