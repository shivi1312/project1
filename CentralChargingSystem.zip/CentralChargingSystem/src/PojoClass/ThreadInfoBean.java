package PojoClass;

import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;

public class ThreadInfoBean {
	
	
	private PriorityBlockingQueue reqQueue;
	private ThreadPoolExecutor thrdExecotr;
	public PriorityBlockingQueue getReqQueue() {
		return reqQueue;
	}
	public void setReqQueue(PriorityBlockingQueue reqQueue) {
		this.reqQueue = reqQueue;
	}
	public ThreadPoolExecutor getThrdExecotr() {
		return thrdExecotr;
	}
	public void setThrdExecotr(ThreadPoolExecutor thrdExecotr) {
		this.thrdExecotr = thrdExecotr;
	}
	
	
	
	
	
	

}
