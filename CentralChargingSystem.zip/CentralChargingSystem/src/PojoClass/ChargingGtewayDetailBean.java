package PojoClass;

import java.util.ArrayList;
import java.util.Arrays;

public class ChargingGtewayDetailBean {
	
	
	int gatewayId;
	String gatewayName;
	String gwType;
	String gwIP;
	int gwPort;
	String gwUserId;
	String gwPass;
	String vasPid1;
	String vasPid2;
	String vasPid3;
	int maxNumThrds;
	int minNumThrds;
	String className;
	String methodName;
	String postUsrSuprtd;
	String reqTypeSuprtd;
	String status;
	String[] reqTypeArra;
	
	
	
	
	
	
	
	boolean isActive=false;
	
	
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public int getGatewayId() {
		return gatewayId;
	}
	public void setGatewayId(int gatewayId) {
		this.gatewayId = gatewayId;
	}
	public String getGatewayName() {
		return gatewayName;
	}
	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}
	public String getGwType() {
		return gwType;
	}
	public void setGwType(String gwType) {
		this.gwType = gwType;
	}
	public String getGwIP() {
		return gwIP;
	}
	public void setGwIP(String gwIP) {
		this.gwIP = gwIP;
	}
	public int getGwPort() {
		return gwPort;
	}
	public void setGwPort(int gwPort) {
		this.gwPort = gwPort;
	}
	public String getGwUserId() {
		return gwUserId;
	}
	public void setGwUserId(String gwUserId) {
		this.gwUserId = gwUserId;
	}
	public String getGwPass() {
		return gwPass;
	}
	public void setGwPass(String gwPass) {
		this.gwPass = gwPass;
	}
	public String getVasPid1() {
		return vasPid1;
	}
	public void setVasPid1(String vasPid1) {
		this.vasPid1 = vasPid1;
	}
	public String getVasPid2() {
		return vasPid2;
	}
	public void setVasPid2(String vasPid2) {
		this.vasPid2 = vasPid2;
	}
	public String getVasPid3() {
		return vasPid3;
	}
	public void setVasPid3(String vasPid3) {
		this.vasPid3 = vasPid3;
	}
	public int getMaxNumThrds() {
		return maxNumThrds;
	}
	public void setMaxNumThrds(int maxNumThrds) {
		this.maxNumThrds = maxNumThrds;
	}
	public int getMinNumThrds() {
		return minNumThrds;
	}
	public void setMinNumThrds(int minNumThrds) {
		this.minNumThrds = minNumThrds;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}

	 public String getMethodName() {
                return methodName; 
        }                       
        public void setMethodName(String methodName) { 
                this.methodName = methodName;
        }


	
	public String getPostUsrSuprtd() {
		return postUsrSuprtd;
	}
	public void setPostUsrSuprtd(String postUsrSuprtd) {
		this.postUsrSuprtd = postUsrSuprtd;
	}
	public String getReqTypeSuprtd() {
		return reqTypeSuprtd;
	}
	public void setReqTypeSuprtd(String reqTypeSuprtd) {
		this.reqTypeSuprtd = reqTypeSuprtd.trim();
		
		try{
		this.reqTypeArra=this.reqTypeSuprtd.split(",");
		}catch(Exception e)
		{
			this.reqTypeArra[0]="-1";
		}
		
		
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public boolean isReqTypeAvail(int reqType)
	{
		String reqtype=Integer.toString(reqType);
		if(this.reqTypeArra==null)
		{
			return false;
		}else
		{
			return Arrays.asList(this.reqTypeArra).contains(reqtype);
		}
	}
	
	
	
	@Override
	public String toString() {
		return "ChargingGtewayDetailBean [gatewayId=" + gatewayId
				+ ", gatewayName=" + gatewayName + ", gwType=" + gwType
				+ ", gwIP=" + gwIP + ", gwPort=" + gwPort + ", gwUserId="
				+ gwUserId + ", gwPass=" + gwPass + ", vasPid1=" + vasPid1
				+ ", vasPid2=" + vasPid2 + ", vasPid3=" + vasPid3
				+ ", maxNumThrds=" + maxNumThrds + ", minNumThrds="
				+ minNumThrds + ", className=" + className + "methodName = "+methodName+", postUsrSuprtd="
				+ postUsrSuprtd + ", reqTypeSuprtd=" + reqTypeSuprtd
				+ ", status=" + status + "]";
	}
	
	
	
	
	

}
