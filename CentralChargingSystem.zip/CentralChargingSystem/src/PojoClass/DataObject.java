package PojoClass;

import java.net.Socket;


public class DataObject {

	 private String tranxId="-1";
	 private int requestType=-1;
	 private int serviceId=-1;
	 private int packId=-1;
	 private String msisdn="";
	 private String itemCode="";
	 private String o_callBack="NA";
	 private String interType="NA";
	 private String balnceDetailData="0";
	 private String amount="0";
	 private String currncyType="NA";
	 private String subType="NA";
	 private int resCode=-1;
	 private String responseDesc="NA";
	 private Socket sock=null;
	 private String subRequestType="1";
	 //private int o_tarrifCode=1;
	 private String o_tarrifCode="NA";
	 private String chgCode="NA";
	 private String o_addDetails="NA";
	 private String action="NA";
	 private int oldPackId=-1;
	 
	 
	 
	 
	 
	 
	
	
	
	
	public String getAction() {
		return action;
	}




	public void setAction(String action) {
		this.action = action;
	}




	public String getO_tarrifCode() {
		return o_tarrifCode;
	}




	public void setO_tarrifCode(String o_tarrifCode) {
		this.o_tarrifCode = o_tarrifCode;
	}



	 public String getChgCode() {
                return chgCode;
        }




        public void setChgCode(String chgCode) {
                this.chgCode = chgCode;
        }




	public String getO_addDetails() {
		return o_addDetails;
	}




	public void setO_addDetails(String o_addDetails) {
		this.o_addDetails = o_addDetails;
	}




	public String getSubRequestType() {
		return subRequestType;
	}




	public void setSubRequestType(String subRequestType) {
		this.subRequestType = subRequestType;
	}




	public Socket getSock() {
		return sock;
	}




	public void setSock(Socket sock) {
		this.sock = sock;
	}









	public String getTranxId() {
		return tranxId;
	}




	public void setTranxId(String tranxId) {
		this.tranxId = tranxId;
	}



        public String getItemCode() {
                return itemCode;
        }




        public void setItemCode(String itemCode) {
                this.itemCode = itemCode;
        }




	public int getRequestType() {
		return requestType;
	}




	public void setRequestType(int requestType) {
		this.requestType = requestType;
	}




	public int getServiceId() {
		return serviceId;
	}




	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	



        public int getPackId() {
                return packId;
        }




        public void setPackId(int packId) {
                this.packId = packId;
        }






	public String getMsisdn() {
		return msisdn;
	}




	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}




	public String getO_callBack() {
		return o_callBack;
	}




	public void setO_callBack(String o_callBack) {
		this.o_callBack = o_callBack;
	}




	public String getInterType() {
		return interType;
	}




	public void setInterType(String interType) {
		this.interType = interType;
	}




	public String getBalnceDetailData() {
		return balnceDetailData;
	}




	public void setBalnceDetailData(String balnceDetailData) {
		this.balnceDetailData = balnceDetailData;
	}




	public String getAmount() {
		return amount;
	}




	public void setAmount(String amount) {
		this.amount = amount;
	}




	public String getCurrncyType() {
		return currncyType;
	}




	public void setCurrncyType(String currncyType) {
		this.currncyType = currncyType;
	}




	public String getSubType() {
		return subType;
	}




	public void setSubType(String subType) {
		this.subType = subType;
	}




	public int getResCode() {
		return resCode;
	}




	public void setResCode(int resCode) {
		this.resCode = resCode;
	}




	public String getResponseDesc() {
		return responseDesc;
	}




	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}


	

	public int getOldPackId() {
		return oldPackId;
	}




	public void setOldPackId(int oldPackId) {
		this.oldPackId = oldPackId;
	}




	@Override
	public String toString() {
		return "DataObject [tranxId=" + tranxId + ", requestType="
				+ requestType + ", serviceId=" + serviceId + ", msisdn="
				+ msisdn + ", o_callBack=" + o_callBack + ", interType="
				+ interType + ", balnceDetailData=" + balnceDetailData
				+ ", amount=" + amount + ", currncyType=" + currncyType
				+ ", subType=" + subType + ", resCode=" + resCode
				+ ", responseDesc=" + responseDesc
				+" , packId= "+packId+ ",Action="+action+" ,oldPackId="+oldPackId+" ] ";
	}
	
	
	
	
	
}
