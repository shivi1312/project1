package PojoClass;

public class ChgServiceGwMapBean {

	int serviceId;
	int gwId;
	String scope;
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public int getGwId() {
		return gwId;
	}
	public void setGwId(int gwId) {
		this.gwId = gwId;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	@Override
	public String toString() {
		return "ChgServiceGwMapBean [serviceId=" + serviceId + ", gwId=" + gwId
				+ ", scope=" + scope + "]";
	}
	
	
	
	
	
	
}
