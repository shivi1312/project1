package util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;

import org.apache.log4j.Logger;

import CntrlChargingSystem.Global;
import PojoClass.ChargingGtewayDetailBean;
import PojoClass.ChgServiceDetailBean;
import PojoClass.ChgServiceGwMapBean;

public class ChargingCache implements Runnable {

	Logger logger = Logger.getLogger("ChargingCache");
	public static Hashtable<Integer, ChgServiceDetailBean> chgSrvcDtlMap = new Hashtable<Integer, ChgServiceDetailBean>();
	public static Hashtable<Integer, ChgServiceGwMapBean> chgServcieGatWayMap = new Hashtable<Integer, ChgServiceGwMapBean>();
	public static Hashtable<Integer, ChargingGtewayDetailBean> chgGatWayDtlMap = new Hashtable<Integer, ChargingGtewayDetailBean>();
	int sleeptime = 0;

	public ChargingCache(int sl) {
		logger.info("Sleep time .........." + sl);
		sleeptime = sl;
	}

	public void loadChargingServiceDetail() {

		logger.info("Inside function loadChargingServiceDetail()......");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		String query = "";
		try {
			con = Global.conPool.getConnection();
			switch(Global.databaseType){
			case 1:
				query = "select SERVICE_ID,SERVICE_NAME,SERVICE_URL,SERVICE_STATUS from service_master";
				break;
			case 2:
				query = "select SERVICE_ID,SERVICE_NAME,SERVICE_URL,SERVICE_STATUS from service_master";
			}
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ChgServiceDetailBean servicedtl = new ChgServiceDetailBean();
				servicedtl.setCallBackURl(rs.getString("SERVICE_URL").trim());
				servicedtl.setExceptionCount(10);
				servicedtl.setServiceId(rs.getInt("SERVICE_ID"));
				servicedtl.setServiceName(rs.getString("SERVICE_NAME").trim());
				servicedtl.setStatus(rs.getString("SERVICE_STATUS").trim());
				if (rs.getString("SERVICE_STATUS").trim().equalsIgnoreCase("I")) {
					servicedtl.setActive(false);
				} else if (rs.getString("SERVICE_STATUS").trim().equalsIgnoreCase("A")) {
					servicedtl.setActive(true);
				} else {
					servicedtl.setActive(false);
				}
				logger.info("Charging service details ............." + servicedtl);
				chgSrvcDtlMap.put(rs.getInt("SERVICE_ID"), servicedtl);
			}

			rs.close();
			pstmt.close();
			con.close();

		} catch (SQLException sqle) {
			sqle.printStackTrace();
			logger.error(ExceptionCode.SQL_EXCEPTION + " Here we have getting error from loadChargingServiceDetail() "
					+ sqle.getMessage());
		} catch (NullPointerException npe) {
			npe.printStackTrace();
			logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
					+ " Here we have getting error from loadChargingServiceDetail() " + npe.getMessage());
		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			logger.error(ExceptionCode.NUMBER_FORMAT_EXCEPTION
					+ " Here we have getting error from loadChargingServiceDetail() " + nfe.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(
					"CSE-BE-00030" + " Here we have getting error from loadChargingServiceDetail() " + e.getMessage());
		} finally {

			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException sqle) {
				sqle.printStackTrace();
				logger.error(ExceptionCode.SQL_EXCEPTION
						+ " Here we have getting error from loadChargingServiceDetail() " + sqle.getMessage());
			}

		}

	}

	/////// ------------------------------------------------------

	public void loadChargingServiceGatewayMap() {

		logger.info("Inside function loadChargingServiceGatewayMap()  CHG_SERVICE_GW_MAP......");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		String query = "";
		try {
			con = Global.conPool.getConnection();
			switch(Global.databaseType){
			case 1:
				query = "select  SERVICE_ID,GW_ID,SCOPE from CHG_SERVICE_GW_MAP";
				break;
			case 2:
				query = "select  SERVICE_ID,GW_ID,SCOPE from CHG_SERVICE_GW_MAP";
			}
			
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ChgServiceGwMapBean chgServiceBean = new ChgServiceGwMapBean();
				chgServiceBean.setGwId(rs.getInt("GW_ID"));
				chgServiceBean.setServiceId(rs.getInt("SERVICE_ID"));
				chgServiceBean.setScope(rs.getString("SCOPE").trim());
				chgServcieGatWayMap.put(rs.getInt("SERVICE_ID"), chgServiceBean);
				logger.info("servie gatewaymap details......" + chgServiceBean);

			}

			rs.close();
			pstmt.close();
			con.close();

		} catch (SQLException sqle) {
			sqle.printStackTrace();
			logger.error(ExceptionCode.SQL_EXCEPTION
					+ " Here we have getting error from loadChargingServiceGatewayMap() " + sqle.getMessage());
		} catch (NullPointerException npe) {
			npe.printStackTrace();
			logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
					+ " Here we have getting error from loadChargingServiceGatewayMap() " + npe.getMessage());
		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			logger.error(ExceptionCode.NUMBER_FORMAT_EXCEPTION
					+ " Here we have getting error from loadChargingServiceGatewayMap() " + nfe.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("CSE-BE-00031" + " Here we have getting error from loadChargingServiceGatewayMap() "
					+ e.getMessage());
		} finally {

			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException sqle) {
				sqle.printStackTrace();
				logger.error(ExceptionCode.SQL_EXCEPTION
						+ " Here we have getting error from loadChargingServiceGatewayMap() " + sqle.getMessage());
			}

		}

	}

	///// ======================================================

	public void loadChargingGatewayDetail() {

		logger.info("Inside function loadChargingGatewayDetail(). CHG_GW_DETAIL.....");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		String query = "";
		try {
			con = Global.conPool.getConnection();
			switch(Global.databaseType){
			case 1:
				query = "select  GW_ID,GW_NAME,GW_TYPE,GW_IP,GW_PORT,GW_USER_ID,GW_PASSWORD,VASPID1,VASPID2,VASPID3,MIN_NO_OF_THREADS,MAX_NO_OF_THREADS,CLASSNAME,METHODNAME,POST_USER_SUPPORTED,REQ_TYPE_SUPPORTED,STATUS,SERVICE_ID,SCOPE from CHG_GATEWAY_DETAIL";
				break;
			case 2:
				query = "select  GW_ID,GW_NAME,GW_TYPE,GW_IP,GW_PORT,GW_USER_ID,GW_PASSWORD,VASPID1,VASPID2,VASPID3,MIN_NO_OF_THREADS,MAX_NO_OF_THREADS,CLASSNAME,METHODNAME,POST_USER_SUPPORTED,REQ_TYPE_SUPPORTED,STATUS,SERVICE_ID,SCOPE from CHG_GATEWAY_DETAIL";
			}
			
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ChargingGtewayDetailBean chgGwBean = new ChargingGtewayDetailBean();
				chgGwBean.setClassName(rs.getString("CLASSNAME").trim());
				chgGwBean.setMethodName(rs.getString("METHODNAME").trim());
				chgGwBean.setGatewayId(rs.getInt("GW_ID"));
				chgGwBean.setGatewayName(rs.getString("GW_NAME").trim());
				chgGwBean.setGwIP(rs.getString("GW_IP").trim());
				chgGwBean.setGwPass(rs.getString("GW_PASSWORD").trim());
				chgGwBean.setGwPort(rs.getInt("GW_PORT"));
				chgGwBean.setGwType(rs.getString("GW_TYPE").trim());
				chgGwBean.setGwUserId(rs.getString("GW_USER_ID").trim());
				chgGwBean.setMaxNumThrds(rs.getInt("MAX_NO_OF_THREADS"));
				chgGwBean.setMinNumThrds(rs.getInt("MIN_NO_OF_THREADS"));
				chgGwBean.setPostUsrSuprtd(rs.getString("POST_USER_SUPPORTED").trim());
				chgGwBean.setReqTypeSuprtd(rs.getString("REQ_TYPE_SUPPORTED").trim());
				chgGwBean.setStatus(rs.getString("STATUS").trim());
				chgGwBean.setVasPid1(rs.getString("VASPID1").trim());
				chgGwBean.setVasPid2(rs.getString("VASPID2").trim());
				chgGwBean.setVasPid3(rs.getString("VASPID3").trim());
				chgGwBean.setStatus(rs.getString("STATUS").trim());
				if (rs.getString("STATUS").trim().equalsIgnoreCase("I")) {
					chgGwBean.setActive(false);
				} else if (rs.getString("STATUS").trim().equalsIgnoreCase("A")) {
					chgGwBean.setActive(true);
				} else {
					chgGwBean.setStatus("NA");
					chgGwBean.setActive(false);
				}
				logger.info("gatewwy details in cache....." + chgGwBean);
				chgGatWayDtlMap.put(rs.getInt("GW_ID"), chgGwBean);
			}

			rs.close();
			pstmt.close();
			con.close();

		} catch (SQLException sqle) {
			sqle.printStackTrace();
			logger.error(ExceptionCode.SQL_EXCEPTION + " Here we have getting error from loadChargingGatewayDetail() "
					+ sqle.getMessage());
		} catch (NullPointerException npe) {
			npe.printStackTrace();
			logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
					+ " Here we have getting error from loadChargingGatewayDetail() " + npe.getMessage());
		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			logger.error(ExceptionCode.NUMBER_FORMAT_EXCEPTION
					+ " Here we have getting error from loadChargingGatewayDetail() " + nfe.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(
					"CSE-BE-00032" + " Here we have getting error from loadChargingGatewayDetail() " + e.getMessage());
		} finally {

			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException sqle) {
				sqle.printStackTrace();
				logger.error(ExceptionCode.SQL_EXCEPTION
						+ " Here we have getting error from loadChargingGatewayDetail() " + sqle.getMessage());
			}

		}

	}

	public void run() {
		while (true) {
			logger.info("Running Cache Loader Thread........");
			try {
				loadChargingGatewayDetail();
				loadChargingServiceDetail();
				loadChargingServiceGatewayMap();

				Thread.sleep(sleeptime * 1000);

			} catch (InterruptedException ie) {
				ie.printStackTrace();
				logger.error(ExceptionCode.INTERRUPTED_EXCEPTION
						+ " Here we have getting error from ChargingCache run() " + ie.getMessage());
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("CSE-BE-00033" + " Here we have getting error from ChargingCache run() " + e.getMessage());
			}

		}
	}

}
