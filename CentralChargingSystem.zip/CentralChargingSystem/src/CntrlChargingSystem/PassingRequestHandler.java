package CntrlChargingSystem;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;

import util.ChargingCache;
import util.ResponseCode;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import PojoClass.ChargingGtewayDetailBean;
import PojoClass.DataObject;

public class PassingRequestHandler implements Runnable{
	
	int gatewayId;
	DataObject dataObj;
	JSONObject jsonobj = null;
	JSONParser parser=null;
	Logger logger= Logger.getLogger("PassingRequestHandler");
	public PassingRequestHandler(int gatewayId,DataObject obj)
	{
		this.gatewayId=gatewayId;
		this.dataObj=obj;
	}

	public void run()
	{
		
		try{
			
		logger.info("Inside function run of PassingRequestHandler where SERVICE ID [  "+dataObj.getServiceId()+"  ] gatwayid [ "+gatewayId+" ] DATAOBJECT [ "+dataObj.toString()+" ]");
		
		ChargingGtewayDetailBean gatwayDetlBean= ChargingCache.chgGatWayDtlMap.get(this.gatewayId);
		parser=new JSONParser();
		logger.info("This is the gateway ["+gatwayDetlBean.toString()+"] ");
		if(Global.testingEnabled==1)
        {

			this.dataObj.setResCode(2);
			this.dataObj.setResponseDesc("Success");
			if(dataObj.getRequestType()==Global.BALANCEREQUEST)
			{
				//for testing
				if(Global.testingEnabled==1)
				{
							this.dataObj.setResCode(0);
	            			this.dataObj.setBalnceDetailData(Global.testingBalance);
	            			this.dataObj.setAmount(Global.testingBalance);
				}
			}
			 Global.responseHandleQue.put(dataObj);
			 return;

        }

		try{
		jsonobj=new JSONObject();
		jsonobj.put("transactionId",dataObj.getTranxId());
		jsonobj.put("msisdn",dataObj.getMsisdn());	
		//jsonobj.put("action","");
		//jsonobj.put("action",dataObj.getAction());	
		jsonobj.put("description","NA");	
		jsonobj.put("balance",dataObj.getBalnceDetailData()+"");	
		jsonobj.put("errorCode","-1");	
		jsonobj.put("subType",dataObj.getSubType());	
		jsonobj.put("avpCode","-1");	
		jsonobj.put("serviceId",dataObj.getServiceId()+"");	
		jsonobj.put("itemCode",dataObj.getItemCode()+"");	
		jsonobj.put("chgCode",dataObj.getChgCode()+"");	
		jsonobj.put("userinterface",dataObj.getInterType()+"");	
		jsonobj.put("chgAmount",dataObj.getAmount()+"");	
		jsonobj.put("packId",dataObj.getPackId()+"");	
		jsonobj.put("chgDays","0");	
		jsonobj.put("requestType",dataObj.getRequestType()+"");	
		//jsonobj.put("oldPackgeId",dataObj.getOldPackId()+"");
		//jsonobj.put("tariffId",dataObj.getO_tarrifCode()+"");
/*		if(dataObj.getRequestType()==Global.BALANCEREQUEST)
		jsonobj.put("operation","getBalance");
		else(dataObj.getRequestType()==Global.DEBITREQUEST)
		jsonobj.put("operation","deduct");
*/	

	    logger.info("Json data send to charging gateway   "+jsonobj);
	    Class clazz=(Class) Class.forName(gatwayDetlBean.getClassName().trim());
        Object obz=clazz.newInstance();
        logger.debug("Charging gateway call");
   //         Method initMethod=(Method) clazz.getMethod("init");
            // here we are calling the init function first......
           // initMethod.invoke(obz);
            
           // initMethod=(Method)clazz.getMethod("initServerDetails",String.class, Integer.class);
        Method   initMethod=(Method)clazz.getMethod(gatwayDetlBean.getMethodName().trim(),String.class,Integer.class,String.class);
       //Method   initMethod=(Method)clazz.getMethod(gatwayDetlBean.getMethodName().trim(),String.class);
//            int retVal=(Integer)initMethod.invoke(obz,gatwayDetlBean.getGwIP().trim(),gatwayDetlBean.getGwPort());
       
        
      String retVal=(String)initMethod.invoke(obz,gatwayDetlBean.getGwIP().trim(),gatwayDetlBean.getGwPort(),jsonobj.toString());
        logger.debug("Charing Method call");
      //  String retVal=(String)initMethod.invoke(obz,jsonobj.toString());
	    jsonobj=null;
        jsonobj=(JSONObject)parser.parse(retVal); 
        logger.info("...... This is the retval for method invoke ["+retVal+"] for gateway id ["+gatwayDetlBean+"]");
            

		//for testing
		  if(Global.testingEnabled==1)
                        {

            this.dataObj.setResCode(1);
            this.dataObj.setResponseDesc("Success");

		}
		else
		{
			
            this.dataObj.setResCode(Integer.parseInt((String)jsonobj.get("errorCode")));
            this.dataObj.setResponseDesc((String)jsonobj.get("description"));


		}
	    if(dataObj.getRequestType()==Global.BALANCEREQUEST)
		{
			//for testing
			if(Global.testingEnabled==1)
			{
            			this.dataObj.setBalnceDetailData(Global.testingBalance);
			}
			else
			{
			dataObj.setBalnceDetailData((String)jsonobj.get("balance"));
			}
		}
            Global.responseHandleQue.put(dataObj);
            
            
		}
		catch(ClassNotFoundException exe)
		{
			logger.error("Class not found exception.for gateway ["+this.gatewayId+"].....",exe);
			this.dataObj.setResCode(ResponseCode.GTW_CLSS_NOT_FOUND);
            this.dataObj.setResponseDesc("This is the class not found for the gatway ");
            Global.responseHandleQue.put(dataObj);
			
		}catch(NoSuchMethodException nometh)
		{
			logger.error("No such method is define in jar",nometh);
				nometh.printStackTrace();
			this.dataObj.setResCode(ResponseCode.GW_NO_SUCH_METHOD);
            this.dataObj.setResponseDesc("This is the exception where no method is define  ");
            Global.responseHandleQue.put(dataObj);
		}
		catch(Exception e)
		{
			logger.error("Exception inside function ",e);
			this.dataObj.setResCode(ResponseCode.SYSTEM_ERROR);
            this.dataObj.setResponseDesc("This is the exception where no method is define  ");
            Global.responseHandleQue.put(dataObj);
			
		}
			
		}catch(Exception exe)
		{
		logger.info("Inside function PassingRequestHandler run method ().....",exe);
		this.dataObj.setResCode(ResponseCode.SYSTEM_ERROR);
        this.dataObj.setResponseDesc("This is the error3............. ");
        try {
			Global.responseHandleQue.put(this.dataObj);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		
		
	}
	
	
	
}
