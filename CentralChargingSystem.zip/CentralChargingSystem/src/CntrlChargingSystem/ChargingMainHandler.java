package CntrlChargingSystem;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import util.ChargingCache;
import util.ConnPool;
import util.ExceptionCode;
import FileBaseLogging.FileLogWriter;
import PojoClass.ChargingGtewayDetailBean;
import PojoClass.ChgServiceGwMapBean;
import PojoClass.DataObject;

public class ChargingMainHandler {

	static Thread thCacheLoader;
	static Thread thAcceptor;
	static Thread thResSender;
	static Thread thServcHandle;

	public static void main(String[] args) {
		Logger logger = Logger.getLogger("ChargingMainHandler..MAIN");

		try {
			PropertyConfigurator.configure("properties/commoncharging_log.properties");
			if (args.length > 0 && args[0].equalsIgnoreCase("-v")) {

				String VERSION = "R1_2_0_0";
				String SITE = "CENTRAL_BILLING_SYSTEM";
				System.out.println("\n******************************************************************************************");
				System.out.println("\n              CENTRAL_BILLING_SYSTEM  Version [  " + VERSION + "  ]");
				System.out.println("\n				Copyright @2004-2015Telemune Software Solutions Private Limited. All rights reserved");
				System.out.println("\n				Name of the Licensee : Telemune");
				System.out.println("\n				Licence ID: 08981Telemune98Client00909");
				System.out.println("\n******************************************************************************************");
				System.out.println("\n");

				System.exit(1);
			} else {
				try {
					if (args.length > 0)
					Global.TEST_RESPONSE_CODE = args[0].trim();
				} catch (Exception e) {
					e.printStackTrace();
					logger.error("CSE-BE-00001" + " Here we have getting error from ChargingMainHandler " + e.getMessage());
				}
			}
		} catch (NullPointerException npe) {
			npe.printStackTrace();
			logger.error(ExceptionCode.NULL_POINTER_EXCEPTION + " Here we have getting error from ChargingMainHandler "
					+ npe.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("CSE-BE-00002" + " Here we have getting error from ChargingMainHandler " + e.getMessage());
		}

		try {
			String VERSION = "R1_2_0_0";
			String SITE = "CENTRAL_BILLING_SYSTEM";
			logger.info("******************************************************************************************");
			logger.info("   CENTRAL_BILLING_SYSTEM  Version [  " + VERSION + "  ] ");
			logger.info("	Copyright @2004-2015Telemune Software Solutions Private Limited. All rights reserved");
			logger.info("	Name of the Licensee : Telemune");
			logger.info("   Licence ID: 08981Telemune98Client00909");
			logger.info("******************************************************************************************");
			logger.info("");

			int numofcon = -1;
			int accomodation = -1;
			int minnumofcon = 1;
			// int numofsmsthreads=-1;
			int cacheloadTime = 30;
			String dbuser = "NA";
			String dbpass = "NA";
			String dburl = "NA";
			String driver = "NA";
			FileLogWriter reqFileWriter = null;
			FileLogWriter resFileWriter = null;
			FileLogWriter errFileWriter = null;
			int port = -1;
			Properties chrPro = new Properties();

			try {
				FileInputStream fins = new FileInputStream("properties/commoncharging.properties");
				chrPro.load(fins);
				fins.close();
			} catch (NullPointerException npe) {
				npe.printStackTrace();
				logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
						+ " Here we have getting error from ChargingMainHandler " + npe.getMessage());
			} catch (IOException ioe) {
				ioe.printStackTrace();
				logger.error(ExceptionCode.IO_EXCEPTION + " Here we have getting error from ChargingMainHandler "
						+ ioe.getMessage());
				System.exit(1);
			}

			try {

				logger.info("Loading Configuration for the Application");
				logger.info("Database Connectivity");
				// LODING MYSQL CONFIGURATION
				// PARAMTERS................................
				Global.databaseType=Integer.parseInt(chrPro.getProperty("DATABASE_TYPE").trim());
				dbuser = chrPro.getProperty("USER").trim();
				dbpass = chrPro.getProperty("PASS").trim();
				dburl = chrPro.getProperty("URL").trim();
				driver = chrPro.getProperty("DRIVER").trim();
				logger.info("Loading Threads Information");
				numofcon = Integer.parseInt(chrPro.getProperty("NUM_OF_CONNECTION").trim());
				minnumofcon = Integer.parseInt(chrPro.getProperty("MIN_NUM_OF_CONNECTION").trim());
				accomodation = Integer.parseInt(chrPro.getProperty("DB_ACCOMODATION").trim());
				cacheloadTime = Integer.parseInt(chrPro.getProperty("RELOAD_TIME").trim());
				port = Integer.parseInt(chrPro.getProperty("PORT").trim());

				// Setting up the filewriter parameters for submit sm file
				// ..................

				reqFileWriter = new FileLogWriter();
				reqFileWriter.setNewFileInterval(Integer.parseInt(chrPro.getProperty("REQ_LOG_FILE_INTERVAL")));
				reqFileWriter.setFilename(chrPro.getProperty("REQ_LOG_FILENAME"));
				reqFileWriter.setFilePath(chrPro.getProperty("REQ_LOG_FILEPATH"));
				reqFileWriter.setArchiveFilePath(chrPro.getProperty("REQ_LOG_FILEPATH_ARCH"));
				reqFileWriter.setArchiveFilename(chrPro.getProperty("REQ_LOG_FILENAME_ARCH"));

				reqFileWriter.setArchiveFileExtension(".d");
				reqFileWriter.initialize();

				resFileWriter = new FileLogWriter();
				resFileWriter.setNewFileInterval(Integer.parseInt(chrPro.getProperty("RES_LOG_FILE_INTERVAL")));
				resFileWriter.setFilename(chrPro.getProperty("RES_LOG_FILENAME"));
				resFileWriter.setFilePath(chrPro.getProperty("RES_LOG_FILEPATH"));
				resFileWriter.setArchiveFilePath(chrPro.getProperty("RES_LOG_FILEPATH_ARCH"));
				resFileWriter.setArchiveFilename(chrPro.getProperty("RES_LOG_FILENAME_ARCH"));

				resFileWriter.setArchiveFileExtension(".d");
				resFileWriter.initialize();

				errFileWriter = new FileLogWriter();
				errFileWriter.setNewFileInterval(Integer.parseInt(chrPro.getProperty("ERR_LOG_FILE_INTERVAL")));
				errFileWriter.setFilename(chrPro.getProperty("ERR_LOG_FILENAME"));
				errFileWriter.setFilePath(chrPro.getProperty("ERR_LOG_FILEPATH"));
				errFileWriter.setArchiveFilePath(chrPro.getProperty("ERR_LOG_FILEPATH_ARCH"));
				errFileWriter.setArchiveFilename(chrPro.getProperty("ERR_LOG_FILENAME_ARCH"));

				Global.testingEnabled = Integer.parseInt(chrPro.getProperty("TESTING_ENABLE").trim());
				Global.testingBalance = chrPro.getProperty("TESTING_BALANCE").trim();
				errFileWriter.setArchiveFileExtension(".d");
				errFileWriter.initialize();

				// ==============================================================================

			} catch (NullPointerException npe) {
				npe.printStackTrace();
				logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
						+ " Here we have getting error from ChargingMainHandler " + npe.getMessage());
				System.exit(1);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("CSE-BE-00003" + " Here we have getting error from ChargingMainHandler " + e.getMessage());
				logger.fatal("ReadExce:" + " Here we have getting error from ChargingMainHandler " + e.toString());
				System.exit(1);
			}
			logger.info("Intializing Database..." + chrPro.toString());

			Global.conPool = new ConnPool(driver, dburl, dbuser, dbpass, minnumofcon, numofcon, accomodation);
			Global.conPool.MakePool();

			ChargingCache chgCache = new ChargingCache(cacheloadTime);
			chgCache.loadChargingGatewayDetail();
			chgCache.loadChargingServiceDetail();
			chgCache.loadChargingServiceGatewayMap();

			thCacheLoader = new Thread(chgCache);
			thCacheLoader.start();

			ResponseSender resSendr = new ResponseSender();
			thResSender = new Thread(resSendr);
			thResSender.start();

			ServerAcceptor srvraccptr = new ServerAcceptor(port);
			thAcceptor = new Thread(srvraccptr);
			thAcceptor.start();

			ThreadExecutorServiceHandler serviceHandle = new ThreadExecutorServiceHandler();
			thServcHandle = new Thread(serviceHandle);
			thServcHandle.start();

			while (true) {

				ArrayList<Integer> keysAl = new ArrayList<Integer>(ChargingCache.chgServcieGatWayMap.keySet());
				for (int i = 0; i < keysAl.size(); i++) {
					ChgServiceGwMapBean chgSerBean = ChargingCache.chgServcieGatWayMap.get((keysAl.get(i)));

					if (ChargingCache.chgGatWayDtlMap.containsKey(chgSerBean.getGwId())) {
						ChargingGtewayDetailBean gatwyDtlBean = ChargingCache.chgGatWayDtlMap.get(chgSerBean.getGwId());
						if (gatwyDtlBean.isActive()) {
							logger.info("Now we are going to start the thread executor for service id [ "
									+ keysAl.get(i) + " ] and gateway id [ " + gatwyDtlBean.getGatewayId() + " ] ");

							if (!Global.queueInfoMap.containsKey(gatwyDtlBean.getGatewayId())) {
								logger.info("we are going to start the Thread pool executer for this gateway id ["
										+ gatwyDtlBean.getGatewayId() + "] name [" + gatwyDtlBean.getGatewayName()
										+ "]");
								PriorityBlockingQueue<DataObject> reqQueue = new PriorityBlockingQueue<DataObject>(
										100000);

								ThreadPoolExecutor thExecute = new ThreadPoolExecutor(gatwyDtlBean.getMinNumThrds(),
										gatwyDtlBean.getMaxNumThrds(), 10, TimeUnit.SECONDS,
										new ArrayBlockingQueue<Runnable>(100), new RejectedWorkHandler());
								Global.queueInfoMap.put(gatwyDtlBean.getGatewayId(), thExecute);

							}

						} else {
							logger.info("This gateway is not going to start because it not active or not define STATUS [  "+ gatwyDtlBean.getStatus() + " ]  ");
						}

					}

				}

				try {
					if (!thCacheLoader.isAlive()) {
						chgCache = new ChargingCache(cacheloadTime);
						thCacheLoader = new Thread(chgCache);
						thCacheLoader.start();
					}
				} catch (NullPointerException npe) {
					npe.printStackTrace();
					logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
							+ " Here we have getting error from ChargingMainHandler " + npe.getMessage());
					System.exit(1);
				} catch (Exception e) {
					e.printStackTrace();
					logger.error(
							"CSE-BE-00004" + " Here we have getting error from ChargingMainHandler " + e.getMessage());
					System.exit(1);
				}

				try {
					if (!thResSender.isAlive()) {
						resSendr = new ResponseSender();
						thResSender = new Thread(resSendr);
						thResSender.start();
					}
				} catch (NullPointerException npe) {
					npe.printStackTrace();
					logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
							+ " Here we have getting error from ChargingMainHandler " + npe.getMessage());
					System.exit(1);
				} catch (Exception e) {
					e.printStackTrace();
					logger.error(
							"CSE-BE-00005" + " Here we have getting error from ChargingMainHandler " + e.getMessage());
					System.exit(1);
				}

				// ------------------------
				try {
					if (!thAcceptor.isAlive()) {
						srvraccptr = new ServerAcceptor(port);
						thAcceptor = new Thread(srvraccptr);
						thAcceptor.start();
					}
				} catch (NullPointerException npe) {
					npe.printStackTrace();
					logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
							+ " Here we have getting error from ChargingMainHandler " + npe.getMessage());
					System.exit(1);
				} catch (Exception e) {
					e.printStackTrace();
					logger.error(
							"CSE-BE-00006" + " Here we have getting error from ChargingMainHandler " + e.getMessage());
					System.exit(1);
				}

				try {
					if (!thServcHandle.isAlive()) {
						serviceHandle = new ThreadExecutorServiceHandler();
						thServcHandle = new Thread(serviceHandle);
						thServcHandle.start();
					}
				} catch (NullPointerException npe) {
					npe.printStackTrace();
					logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
							+ " Here we have getting error from ChargingMainHandler " + npe.getMessage());
					System.exit(1);
				} catch (Exception e) {
					e.printStackTrace();
					logger.error(
							"CSE-BE-00007" + " Here we have getting error from ChargingMainHandler " + e.getMessage());
					System.exit(1);
				}

				Thread.sleep(300000);

			}

		} catch (NullPointerException npe) {
			npe.printStackTrace();
			logger.error(ExceptionCode.NULL_POINTER_EXCEPTION + " Here we have getting error from ChargingMainHandler "
					+ npe.getMessage());
			System.exit(1);
		} catch (InterruptedException ie) {
			ie.printStackTrace();
			logger.error(ExceptionCode.INTERRUPTED_EXCEPTION + " Here we have getting error from ChargingMainHandler "
					+ ie.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("CSE-BE-00008" + " Here we have getting error from ChargingMainHandler "+e);
		
			System.exit(1);
		} finally {
			try {
				System.out.println("All Threads  stoped: ");
				System.exit(1);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("CSE-BE-00009" + " Here we have getting error from ChargingMainHandler " + e.getMessage());
			}
		}

	}

}
