/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CntrlChargingSystem;

import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import PojoClass.DataObject;
import util.ChargingCache;
import util.ExceptionCode;
import util.ResponseCode;

/**
 * @author ekansh THIS CLASS MANAGE THE THREAD POOL OF SMSChecker THREAD
 */

public class ThreadExecutorServiceHandler implements Runnable, ResponseCode {

	Logger logger = Logger.getLogger("ThreadExecutorServiceHandler");
	ThreadPoolExecutor checkerPoolExecutor = null;

	/**
	 *
	 * THIS RUN METHOD READ THE GLOBAL DATA QUEUE AND GET THE DATA FOR
	 * SMSChecker ALSO MANAGE THE MULTIPLE THREADS USING THE THREAD POOL
	 */

	// (here we need to check for the exception handle counter for gsteway and
	// service both ..................................)

	public void run() {

		try {
			while (true) {

				if (Global.requestHandleQue.isEmpty()) {
					Thread.sleep(100);

				} else {
					DataObject dataObj = Global.requestHandleQue.poll();

					try {

						// logger.info("["+dataObj.getServiceId()+"]
						// 111111111111111111111111111111"+ChargingCache.chgSrvcDtlMap.contains(dataObj.getServiceId())+"size
						// of ["+ChargingCache.chgSrvcDtlMap.toString()+"]");
						if (ChargingCache.chgSrvcDtlMap.containsKey(dataObj.getServiceId())) {
							// logger.info("111111111111111111111111111111");

							if (ChargingCache.chgSrvcDtlMap.get(dataObj.getServiceId()).isActive()) {

								if (ChargingCache.chgServcieGatWayMap.containsKey(dataObj.getServiceId())) {
									int gatewayId = ChargingCache.chgServcieGatWayMap.get(dataObj.getServiceId())
											.getGwId();

									if (ChargingCache.chgGatWayDtlMap.containsKey(gatewayId)) {

										if (ChargingCache.chgGatWayDtlMap.get(gatewayId).isActive()) {

											if (ChargingCache.chgGatWayDtlMap.get(gatewayId)
													.isReqTypeAvail(dataObj.getRequestType())) {

												if (Global.queueInfoMap.containsKey(gatewayId)) {

													ThreadPoolExecutor executerService = Global.queueInfoMap
															.get(gatewayId);
													executerService
															.execute(new PassingRequestHandler(gatewayId, dataObj));// here
																													// we
																													// need
													logger.debug("inside ThreadExecutorServiceHandler");																// to
																													// pass
																													// the
																													// reference
																													// of
																													// thread
																													// class......

												} else {
													logger.info("Condition where for service id ["
															+ dataObj.getServiceId() + "] gatwayid [" + gatewayId
															+ "] is not present.....");
													Global.errorFileWrtrOBJ
															.writeLog("Gateway Id not active for request ["
																	+ dataObj.toString() + "]");

													dataObj.setResCode(GTW_INACTIVE);
													dataObj.setResponseDesc(
															"The gateway id [" + gatewayId + "] for service id ["
																	+ dataObj.getServiceId() + "] INACTIVE");
													Global.responseHandleQue.put(dataObj);

												}

											} else {
												logger.info("requested gateway id [" + gatewayId
														+ "] is not supported the Request TYpe ["
														+ dataObj.getRequestType() + "] requested .....");
												dataObj.setResCode(REQ_TYPE_NOT_SUPPORTED);
												dataObj.setResponseDesc("Request Type not supported");
												Global.responseHandleQue.put(dataObj);
											}

										} else {
											logger.info("requested gateway id [" + gatewayId + "]is not Active.....");
											dataObj.setResCode(GTW_INACTIVE);
											dataObj.setResponseDesc("Gateway is not Active in Database");
											Global.responseHandleQue.put(dataObj);

										}

									} else {
										// condition where gateway id is not
										// define .........
										logger.info("requested gateway id [" + gatewayId
												+ "] is not available in database please make entry in it.....");
										dataObj.setResCode(GTW_NOT_AVAIL);
										dataObj.setResponseDesc("Gateway is not available in Database");
										Global.responseHandleQue.put(dataObj);

									}

								} else {//
									logger.info("condition where no gateway is define for service ["
											+ dataObj.getServiceId() + "] service id available ");
									dataObj.setResCode(GTW_UNCONIFG);
									dataObj.setResponseDesc("Gateway is not define for service  .....");
									Global.responseHandleQue.put(dataObj);
								}

							} else {
								// condition where service id is
								// inactive..........
								logger.info("requested service id is not Active please make it active.....["
										+ dataObj.toString() + "]");
								dataObj.setResCode(SERVICE_DEACTIVATE);
								dataObj.setResponseDesc("Service Not Active in Database");
								Global.responseHandleQue.put(dataObj);
							}

						} else {
							// condition where service id is define or not
							// .........
							logger.info("requested service id  [" + dataObj.getServiceId()
									+ "] is not available in database please make entry in it....[" + dataObj.toString()
									+ "].");
							dataObj.setResCode(SERVICE_NOT_AVAIL);
							dataObj.setResponseDesc("Service Not available in Database");
							Global.responseHandleQue.put(dataObj);

						}

					} catch (NullPointerException npe) {
						npe.printStackTrace();
						logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
								+ " Here we have getting error from ThreadExecutorServiceHandler run() "
								+ npe.getMessage());
						dataObj.setResCode(SYSTEM_ERROR);
						dataObj.setResponseDesc("Got systemn error in THESRVCCLSS");
						Global.responseHandleQue.put(dataObj);
					} catch (NumberFormatException nfe) {
						nfe.printStackTrace();
						logger.error(ExceptionCode.NUMBER_FORMAT_EXCEPTION
								+ " Here we have getting error from ThreadExecutorServiceHandler run() "
								+ nfe.getMessage());
						dataObj.setResCode(SYSTEM_ERROR);
						dataObj.setResponseDesc("Got systemn error in THESRVCCLSS");
						Global.responseHandleQue.put(dataObj);
					} catch (ClassCastException cce) {
						cce.printStackTrace();
						logger.error(ExceptionCode.CLASS_CAST_EXCEPTION
								+ " Here we have getting error from ThreadExecutorServiceHandler run() "
								+ cce.getMessage());
						dataObj.setResCode(SYSTEM_ERROR);
						dataObj.setResponseDesc("Got systemn error in THESRVCCLSS");
						Global.responseHandleQue.put(dataObj);
					} catch (Exception e) {
						e.printStackTrace();
						logger.error(
								"CSE-BE-00028" + " Here we have getting error from ThreadExecutorServiceHandler run() "
										+ e.getMessage());
						dataObj.setResCode(SYSTEM_ERROR);
						dataObj.setResponseDesc("Got systemn error in THESRVCCLSS");
						Global.responseHandleQue.put(dataObj);
					}

				}

			} // while(true)

		} catch (NullPointerException npe) {
			npe.printStackTrace();
			logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
					+ " Here we have getting error from ThreadExecutorServiceHandler run() " + npe.getMessage());
		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			logger.error(ExceptionCode.NUMBER_FORMAT_EXCEPTION
					+ " Here we have getting error from ThreadExecutorServiceHandler run() " + nfe.getMessage());
		} catch (InterruptedException ie) {
			ie.printStackTrace();
			logger.error(ExceptionCode.INTERRUPTED_EXCEPTION
					+ " Here we have getting error from ThreadExecutorServiceHandler run() " + ie.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("CSE-BE-00029" + " Here we have getting error from ThreadExecutorServiceHandler run() "
					+ e.getMessage());
		}

	}// run()
}
