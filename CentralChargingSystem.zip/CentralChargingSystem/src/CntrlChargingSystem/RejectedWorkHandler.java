package CntrlChargingSystem;

import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import util.ExceptionCode;

public class RejectedWorkHandler implements RejectedExecutionHandler{

    Logger logger = Logger.getLogger(RejectedWorkHandler.class);

 @Override
   public void rejectedExecution(Runnable r, ThreadPoolExecutor executor)  {
//       logger.warn("TASK IS REJECTED BECOZ ,MAX THREAD IS OPEN  and WORKING QUEUE IS ALREDY FULL , SO WAIT FOR 1 SECOND  and AGAIN TRY TO EXECUTE : (To avoid this problem increase Number of thread(Best Option) or Increase  Working queue size)"+r.toString());

           try {
                   Thread.sleep(1);
                   //logger.info("Lets Try another time : "+Thread.currentThread().getName());
           } catch (InterruptedException ie)
           {
               ie.printStackTrace();
               logger.error(ExceptionCode.INTERRUPTED_EXCEPTION+" Here we have getting error from rejectedExecution() "+ie.getMessage());
       }
          try{
              executor.execute(r);
          }
          catch(RejectedExecutionException re){
      			re.printStackTrace();
      			logger.error(ExceptionCode.Rejected_Execution_Exception + " Here we have getting error from rejectedExecution() Problem In  Submitting task because Its too late processing, Please check your Processing time of Server(Good Option) or increase thread pool queue size(Bad Option " + re.getMessage());
          logger.error(") ",re);
          }
          catch (Exception e) {
  			e.printStackTrace();
  			logger.error("CSE-BE-00013" + " Here we have getting error from rejectedExecution() " + e.getMessage());
  		}
   }
}

