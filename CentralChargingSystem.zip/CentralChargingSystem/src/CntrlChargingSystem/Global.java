package CntrlChargingSystem;

import java.util.Hashtable;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;

import FileBaseLogging.FileLogWriter;
import PojoClass.DataObject;
import util.ConnPool;

public class Global {

	public static ConnPool conPool=null;
	public static  ArrayBlockingQueue<DataObject> requestHandleQue=new ArrayBlockingQueue<DataObject>(100000);
    public static  ArrayBlockingQueue<DataObject> responseHandleQue=new ArrayBlockingQueue<DataObject>(100000);
    
    public static int DEBITREQUEST=1;
    public static int BALANCEREQUEST=3;
    public static int CREDITREQUEST=2;
    public static int BALCHECK_DEBIT=4;
    
    public static Hashtable<Integer, ThreadPoolExecutor> queueInfoMap= new Hashtable<Integer, ThreadPoolExecutor>();
    public static FileLogWriter errorFileWrtrOBJ=null;
    public static FileLogWriter reqFileWrtrOBJ=null;
    public static FileLogWriter respFileWrtrOBJ=null;
    
    public static String TEST_RESPONSE_CODE = null;    
    public static int testingEnabled = 1; 
    public static String testingBalance = "10";  
    public static int databaseType = 1;
}
