
package CntrlChargingSystem;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import PojoClass.DataObject;
import commonutil.TLVAppInterface;
import util.ExceptionCode;
import util.ResponseCode;

/**
 * @author :- Ekansh Goel
 * @version :- TR2_0_0_3 THIS CLASS IS FOR READING THE REQUEST FROM CLIENT ON
 *          PARTICULAR DEFINE PORT AND THEN INSERT THE DATA INTO THE QUEUE
 * 
 */
class RequestReader implements Runnable, TlvParamsInterface, ResponseCode {
	String name;
	Thread thrd;
	Socket socket_me;
	DataInputStream reader = null;
	Logger logger = Logger.getLogger(RequestReader.class);

	/**
	 * THIS IS THE PARAMETERIZED CONSTRUCTOR OF REQUEST READER
	 * 
	 * @param name
	 *            :- REFERS TO THE NAME OF THE THREAD WHICH ARE RUNNING
	 * @param socket
	 *            :- REFERS TO THR SOCKET ON WHCIH SERVER ACCEPTOR IS LISTENING
	 *            THE REQUEST COMMING FROM CLIENT
	 */
	RequestReader(String name, Socket socket) {
		thrd = new Thread(this, name);
		this.name = name;
		socket_me = socket;
		logger.info("\nintializing thread to recv data: #" + name);
	}

	/**
	 * THIS IS THE RUN FUNCTION OF THE THREAD RequestReader WHICH CALL THE
	 * FUNCTION getfromclient().....FOR GETTING THE DATA FROM CLIENT
	 */
	public void run() {
		logger.info("\nstarted thread to recv data: #" + name);
		getfromclient(name, socket_me);
	}

	public void stop() {

	}

	/**
	 *
	 * THIS FUNCTION IS FOR GETTING THE DATA FROM CLIENT BY RECIEVING THE DATA
	 * AT THE DEFINE PORT
	 * 
	 * @param name
	 *            :- REFERS TO THE THREAD NAME
	 * @param socket_me
	 *            :- REFERS TO THE SOCKET ON WHICH APP GET THE DATA FROM CLIENT
	 *            THIS CLASS BASICALLY MAINTAIN THE TCP/IP CONNECTION FROM
	 *            CLIENT AND READ THE REQUEST FROM CLIENT
	 */
	public void getfromclient(String name, Socket socket_me) {
		try {
			reader = new DataInputStream(socket_me.getInputStream());
		} catch (IOException ioe) {
			ioe.printStackTrace();
			logger.error(ExceptionCode.IO_EXCEPTION + " Here we have getting error from getfromclient() "
					+ ioe.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("CSE-BE-00014" + " Here we have getting error from getfromclient() " + e.getMessage());
		}
		logger.info("\nPreparing to recv  data thread# " + name);
		try {
			while (true) {

				if (socket_me.isClosed()) {
					logger.debug("Socket closed");
					thrd.stop();
					return;
				} else {
					ByteArrayInputStream inbuf = null;
					// logger.info("reading Info ........");
					// logger.info("Socket==="+socket_me.toString());
					byte dataBuf1[] = new byte[4];
					int dataLen = 0;
					try {

						logger.debug("reading Info ......starts.");
						if (reader.read(dataBuf1, 0, 4) == -1) {
							logger.warn("reader.read == -1 ...");
							try {
								socket_me.close();
								logger.warn("Destroy");
								logger.warn("socket closed");
								thrd.stop();
								return;
							} catch (SocketException se) {
								se.printStackTrace();
								logger.error(ExceptionCode.SOCKET_EXCEPTION
										+ " Here we have getting error from getfromclient() " + se.getMessage());
							} catch (Exception e) {
								e.printStackTrace();
								logger.error("CSE-BE-00015" + " Here we have getting error from getfromclient() "
										+ e.getMessage());
							}

						}
						logger.debug("reading Info ......end.");
						int test = 0;
						dataLen = dataLen | (dataBuf1[0] << 24);
						dataLen = dataLen | (dataBuf1[1] << 16);
						dataLen = dataLen | (dataBuf1[2] << 8);
						test = (0x000000ff & dataBuf1[3]);
						dataLen = dataLen | test;
						logger.info("reading Info ......data len.." + dataLen);
					} catch (IOException ioe) {
						ioe.printStackTrace();
						logger.error(ExceptionCode.IO_EXCEPTION + " Here we have getting error from getfromclient() "
								+ ioe.getMessage());
						logger.fatal("Getting exception in reading getfromclient" + ioe.toString());
						try {
							thrd.sleep(1);
							socket_me.close();

						} catch (SocketException se) {
							se.printStackTrace();
							logger.error(ExceptionCode.SOCKET_EXCEPTION
									+ " Here we have getting error from getfromclient() " + se.getMessage());
						} catch (InterruptedException ie) {
							ie.printStackTrace();
							logger.error(ExceptionCode.INTERRUPTED_EXCEPTION
									+ " Here we have getting error from getfromclient() " + ie.getMessage());
						}
					} catch (Exception e) {
						e.printStackTrace();
						logger.error(
								"CSE-BE-00016" + " Here we have getting error from getfromclient() " + e.getMessage());
						logger.fatal("Getting exception in reading...." + e.toString());
						try {
							thrd.sleep(1);
							socket_me.close();

						} catch (SocketException se) {
							se.printStackTrace();
							logger.error(ExceptionCode.SOCKET_EXCEPTION
									+ " Here we have getting error from getfromclient() " + se.getMessage());
						} catch (InterruptedException ie) {
							ie.printStackTrace();
							logger.error(ExceptionCode.INTERRUPTED_EXCEPTION
									+ " Here we have getting error from getfromclient() " + ie.getMessage());
						}
					}
					if (dataLen == 0) {
						try {
							logger.info("Sleeping.....n");
							continue;// thrd.sleep(10);
						} catch (Exception e) {
							e.printStackTrace();
							logger.error("CSE-BE-00017" + " Here we have getting error from getfromclient() "
									+ e.getMessage());
						}
					}

					logger.info("recieved tcp_req size=" + dataLen);
					byte dataBuf[] = new byte[dataLen];

					reader.read(dataBuf, 0, dataLen);

					inbuf = new ByteArrayInputStream(dataBuf);

					TLVAppInterface tcp_req = new TLVAppInterface();
					tcp_req.decode(inbuf, dataLen);

					DataObject dataObject = new DataObject();
					dataObject.setSock(socket_me);

					try {
						logger.info("Transaction_req_ID["+tcp_req.getData(TlvParamsInterface.TXN_ID)+"]");
						int retval = checkCommonValidTCPRequestParam(tcp_req, dataObject);
						logger.info("Required parameter["+tcp_req.getData(TlvParamsInterface.TXN_ID)+"] Package_id =["+tcp_req.getData(TlvParamsInterface.PACKAGE_TAG)+"]");
						if (retval == 1) {
							logger.info("This is the condition where commons parameter are OKKKK");

							if (Integer.parseInt(
									tcp_req.getData(TlvParamsInterface.REQTYPE_TAG).trim()) == Global.BALANCEREQUEST) {
								logger.info(
										"condition where we are going to check.......parametres for CHECKBALNACE REQUEST.....");

								Global.requestHandleQue.put(dataObject);

							} else if (Integer.parseInt(tcp_req.getData(TlvParamsInterface.REQTYPE_TAG).trim()) == Global.DEBITREQUEST) {
								
								retval = checkDebitValidTCPRequestParam(tcp_req);
								if (retval > 0) {
									dataObject.setBalnceDetailData(
											tcp_req.getData(TlvParamsInterface.BALANCE_DETAIL_TAG).trim());
									dataObject.setSubRequestType(
											tcp_req.getData(TlvParamsInterface.SUB_REQUEST_TYPE).trim());
									dataObject.setAmount(tcp_req.getData(TlvParamsInterface.AMOUNT_TAG).trim());
									dataObject.setCurrncyType(tcp_req.getData(TlvParamsInterface.CURRENCY_TYPE).trim());
									dataObject.setSubType(tcp_req.getData(TlvParamsInterface.SUB_TYPE).trim());
									

									if (tcp_req.getData(TlvParamsInterface.TARIFFCODE_TAG) != null) {
										dataObject.setO_tarrifCode(
												tcp_req.getData(TlvParamsInterface.TARIFFCODE_TAG).trim());
										dataObject.setChgCode(
												((dataObject.getO_tarrifCode()).split(";")[0]).split(":")[0]);

									}

									if (tcp_req.getData(TlvParamsInterface.ADD_INFO_TAG) != null) {
										dataObject.setO_tarrifCode(
												tcp_req.getData(TlvParamsInterface.TARIFFCODE_TAG).trim());

									}
									Global.requestHandleQue.put(dataObject);

								} else {
									// need to put data in sending
									// queue................ for response
									// .............
									logger.info(
											"debit request parameters are not valid please send valid parameters.......");
								}

							} else if (Integer.parseInt(
									tcp_req.getData(TlvParamsInterface.REQTYPE_TAG).trim()) == Global.CREDITREQUEST) {
								Global.requestHandleQue.put(dataObject);

							} else if (Integer.parseInt(
									tcp_req.getData(TlvParamsInterface.REQTYPE_TAG).trim()) == Global.BALCHECK_DEBIT) {
								Global.requestHandleQue.put(dataObject);
							} else {
								logger.warn("Invalid request type please send a valid request type......");
								// need to send the response tag and write the
								// file log..... in file writer.....
								Global.requestHandleQue.put(dataObject);
							}

						} else {
							logger.info("WE need send the response for validate failure.........");
							dataObject.setResCode(ResponseCode.REQUEST_PARAM_MISSING);
							dataObject.setResponseDesc("Common Request parameter is missing....");
							logger.info("WE need send the response for validate failure.........11111111");
							Global.responseHandleQue.put(dataObject);
						}

					} catch (NullPointerException npe) {
						npe.printStackTrace();
						logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
								+ " Here we have getting error from getfromclient() " + npe.getMessage());
						dataObject.setResCode(ResponseCode.SYSTEM_ERROR);
						dataObject.setResponseDesc("SYSTEM ERROR");
						// logger.info("WE need send the response for validate
						// failure.........11111111");
						Global.responseHandleQue.put(dataObject);
					} catch (NumberFormatException nfe) {
						nfe.printStackTrace();
						logger.error(ExceptionCode.NUMBER_FORMAT_EXCEPTION
								+ " Here we have getting error from getfromclient() " + nfe.getMessage());
						dataObject.setResCode(ResponseCode.SYSTEM_ERROR);
						dataObject.setResponseDesc("SYSTEM ERROR");
						// logger.info("WE need send the response for validate
						// failure.........11111111");
						Global.responseHandleQue.put(dataObject);
					} catch (Exception e) {
						e.printStackTrace();
						logger.error(
								"CSE-BE-00018" + " Here we have getting error from getfromclient() " + e.getMessage());
						dataObject.setResCode(ResponseCode.SYSTEM_ERROR);
						dataObject.setResponseDesc("SYSTEM ERROR");
						// logger.info("WE need send the response for validate
						// failure.........11111111");
						Global.responseHandleQue.put(dataObject);
					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("CSE-BE-00019" + " Here we have getting error from getfromclient() " + e.getMessage());
		}
	}

	public int checkCommonValidTCPRequestParam(TLVAppInterface tcpData, DataObject dataObject) {

		logger.info("Inside function checkValidTCPRequestParam()..........");
		int retval = 1;
		logger.info("Service id [" + TlvParamsInterface.SERVICE_ID + "] Msisdn ["
				+ tcpData.getData(TlvParamsInterface.MSISDN_TAG) + "] "
				+ tcpData.getData(TlvParamsInterface.PACKAGE_TAG) + "  "
				+ tcpData.getData(TlvParamsInterface.INTERFACE_TAG) + "   "
				+ tcpData.getData(TlvParamsInterface.RBTCODE_TAG));
		try {
			// logger.info("1111.............."+tcpData.getData(TlvParamsInterface.SERVICE_ID).trim());

			logger.info("tranx id [" + tcpData.getData(TlvParamsInterface.TXN_ID) + "] request type ["
					+ tcpData.getData(TlvParamsInterface.REQTYPE_TAG) + "]");

			dataObject.setServiceId(Integer.parseInt(tcpData.getData(TlvParamsInterface.SERVICE_ID).trim()));
			dataObject.setPackId(Integer.parseInt(tcpData.getData(TlvParamsInterface.PACKAGE_TAG).trim()));
			dataObject.setTranxId((tcpData.getData(TlvParamsInterface.TXN_ID).trim()));
			dataObject.setRequestType(Integer.parseInt(tcpData.getData(TlvParamsInterface.REQTYPE_TAG).trim()));
			dataObject.setInterType(tcpData.getData(TlvParamsInterface.INTERFACE_TAG).trim());
			dataObject.setItemCode(tcpData.getData(TlvParamsInterface.RBTCODE_TAG));
			dataObject.setAction(tcpData.getData(TlvParamsInterface.ACTION_TAG).trim());
			dataObject.setOldPackId(Integer.parseInt(tcpData.getData(TlvParamsInterface.OLD_PACKAGE_ID_TAG).trim()));
			logger.debug("tcp_req.getData(global.REQID_TAG)" + tcpData.getData(TlvParamsInterface.REQTYPE_TAG));

			dataObject.setMsisdn(tcpData.getData(TlvParamsInterface.MSISDN_TAG).trim());
			//dataObject.setOldPackId(Integer.parseInt(tcpData.getData(TlvParamsInterface.OLD_PACKAGE_ID_TAG).trim()));
			if (StringUtils.isEmpty(dataObject.getMsisdn()) && (StringUtils.isEmpty(dataObject.getTranxId()))
					&& (dataObject.getRequestType() < 0) && (dataObject.getServiceId() < 0)
					&& StringUtils.isEmpty(dataObject.getInterType())) {

				logger.info("Conditions where request parameters validation are failed ");
				retval = -1;
			}

		} catch (NullPointerException npe) {
			npe.printStackTrace();
			logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
					+ " Here we have getting error from checkCommonValidTCPRequestParam() " + npe.getMessage());
			retval = -99;
		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			logger.error(ExceptionCode.NUMBER_FORMAT_EXCEPTION
					+ " Here we have getting error from checkCommonValidTCPRequestParam() " + nfe.getMessage());
			retval = -99;
		} catch (ClassCastException cce) {
			cce.printStackTrace();
			logger.error(ExceptionCode.CLASS_CAST_EXCEPTION
					+ " Here we have getting error from checkCommonValidTCPRequestParam() " + cce.getMessage());
			retval = -99;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("CSE-BE-00020" + " Here we have getting error from checkCommonValidTCPRequestParam() "
					+ e.getMessage());
			retval = -99;
		}

		return retval;
	}

	public int checkDebitValidTCPRequestParam(TLVAppInterface tcpData) {

		logger.info("Inside function checkValidTCPRequestParam()..........");
		int retval = 1;
		try {

			if (StringUtils.isEmpty(tcpData.getData(TlvParamsInterface.BALANCE_DETAIL_TAG))
					&& StringUtils.isEmpty(tcpData.getData(TlvParamsInterface.SUB_REQUEST_TYPE))
					&& StringUtils.isEmpty(tcpData.getData(TlvParamsInterface.AMOUNT_TAG))
					&& StringUtils.isEmpty(tcpData.getData(TlvParamsInterface.CURRENCY_TYPE))
					&& StringUtils.isEmpty(tcpData.getData(TlvParamsInterface.SUB_TYPE))) {
				logger.info("Conditions where request parameters validation are failed ");
				retval = -1;
			}

		} catch (NullPointerException npe) {
			npe.printStackTrace();
			logger.error(ExceptionCode.NULL_POINTER_EXCEPTION
					+ " Here we have getting error from checkCommonValidTCPRequestParam() " + npe.getMessage());
			retval = -99;
		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			logger.error(ExceptionCode.NUMBER_FORMAT_EXCEPTION
					+ " Here we have getting error from checkCommonValidTCPRequestParam() " + nfe.getMessage());
			retval = -99;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("CSE-BE-00021" + " Here we have getting error from checkCommonValidTCPRequestParam() "
					+ e.getMessage());
			retval = -99;
		}

		return retval;
	}

}
