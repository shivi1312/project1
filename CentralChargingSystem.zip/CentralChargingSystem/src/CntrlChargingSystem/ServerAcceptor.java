
package CntrlChargingSystem;

import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

import org.apache.log4j.Logger;

import util.ExceptionCode;

/**
 * @author :-Ekansh Goel
 * @version :-T@_0_0_3 THIS CLASS IS FOR MAKING THE TCP/IP CONNECTION FROM
 *          CLIENT
 */
public class ServerAcceptor implements Runnable {
	Thread temp;
	Thread threq = null;
	ServerSocket server_socket = null;
	Logger logger = Logger.getLogger("ServerAcceptor");
	int port = -1;

	ServerAcceptor(int port) {
		this.port = port;
	}

	public void run() {
		try {
			temp = new Thread();
			try {
				server_socket = new ServerSocket(port);
				logger.info("Server waiting for client on port " + server_socket.getLocalPort());
			} catch (SocketException se) {
				se.printStackTrace();
				logger.error(ExceptionCode.SOCKET_EXCEPTION + " Here we have getting error from ServerAcceptor() "
						+ se.getMessage());
				logger.fatal(ExceptionCode.SOCKET_EXCEPTION + " Here we have getting error from ServerAcceptor() "
						+ se.getMessage());
				return;
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("CSE-BE-00024" + " Here we have getting error from () " + e.getMessage());
				logger.fatal(ExceptionCode.SOCKET_EXCEPTION + " Here we have getting error from ServerAcceptor() "
						+ e.getMessage());
				return;
			}
			while (true) {
				Socket socket = null;
				try {
					socket = server_socket.accept();
					logger.info("Connection accepted response" + socket.getInetAddress() + ":" + socket.getPort());
				} catch (SocketException se) {
					se.printStackTrace();
					logger.error(ExceptionCode.SOCKET_EXCEPTION + " Here we have getting error from ServerAcceptor() "
							+ se.getMessage());
					logger.fatal(ExceptionCode.SOCKET_EXCEPTION + " Here we have getting error from ServerAcceptor() "
							+ se.getMessage());
				}
				try {
					RequestReader obj_get_data = new RequestReader("threadCheckRequest" + socket.toString(), socket);
					threq = new Thread(obj_get_data);
					threq.start();

				} catch (Exception e) {
					e.printStackTrace();
					logger.error("CSE-BE-00025" + " Here we have getting error from () " + e.getMessage());
					logger.fatal(ExceptionCode.SOCKET_EXCEPTION + " Here we have getting error from ServerAcceptor() "
							+ e.getMessage());
					try {
						socket.close();
					} catch (SocketException se) {
						se.printStackTrace();
						logger.error(ExceptionCode.SOCKET_EXCEPTION
								+ " Here we have getting error from ServerAcceptor() " + se.getMessage());
					}
				}
				try {
					temp.sleep(1);
				} catch (InterruptedException ie) {
					ie.printStackTrace();
					logger.error(ExceptionCode.INTERRUPTED_EXCEPTION
							+ " Here we have getting error from ServerAcceptor() " + ie.getMessage());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("CSE-BE-00026" + " Here we have getting error from ServerAcceptor() " + e.getMessage());
		} finally {
			try {
				server_socket.close();
				logger.debug("All Threads  stoped: ");
				System.exit(1);
			} catch (SocketException se) {
				se.printStackTrace();
				logger.error(ExceptionCode.SOCKET_EXCEPTION
						+ " Here we have getting error from ServerAcceptor(),Threads cannot stoped:  "
						+ se.getMessage());
			} catch (Exception e) {
				e.printStackTrace();
				logger.error(
						"CSE-BE-00027" + " Here we have getting error from ServerAcceptor(),Threads cannot stoped:  "
								+ e.getMessage());
			}
		}

	}
}
