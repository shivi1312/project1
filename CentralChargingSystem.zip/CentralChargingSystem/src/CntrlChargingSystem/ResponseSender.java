
package CntrlChargingSystem;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;

import org.apache.log4j.Logger;

import FileBaseLogging.FileLogWriter;
import PojoClass.DataObject;
import commonutil.TLVAppInterface;
import util.ExceptionCode;

/**
 * @author :-Ashu Mittal
 * @version :-T2_0_0_3 THIS CLASS IS FOR SENDING THE RESPONSE TO THE CLIENT BY
 *          READING THE INFORMATION FROM RESPONSE QUEUE
 */
class ResponseSender implements Runnable, TlvParamsInterface {
	String name;
	static Thread thrd;
	Socket socket_me;
	DataOutputStream stream_send_data;
	FileLogWriter error_log = null;
	FileLogWriter total_log = null;
	Logger logger = Logger.getLogger("com.SMSFilter.run.ResponseSender");

	/**
	 * THIS IS THE CONSTRUCTOR OF THE CLASS ResponseSender IN WHCIH WE ARE
	 * INITIALIZING THE PARAMETERS
	 * 
	 * @param name
	 *            :-REFERS TO THE THREAD NAME
	 * @param logfile
	 *            :- REFERS TO THE OBJECT OF FILE LOG WRITER
	 * @param totallog
	 *            :- REFERS TO ANOTHER FILE WRITER OBJECT WHO WRITE THE TOTAL
	 *            LOG
	 */
	ResponseSender() {

	}

	/**
	 * THIS IS THE RUN METHOD OF ResponseSender THREAD WHICH CALLS THE FUNCTION
	 * sendtoclient() FOR SENDING THE RESPONSE TO CLIENT
	 */
	public void run() {
		logger.info("Starting Thread ResponseSender");
		sendtoclient(name);
	}

	public void stop() {

	}

	// public void sendtoclient(String name,Socket socket_me)
	/**
	 * THIS FUNCTION IS FOR SENDING THE RESPONSE TO THE CLIENT BY READING THE
	 * RESPONSE QUEUE
	 * 
	 * @param name
	 *            :- REFERS TO THE THREAD NAME this function basically read the
	 *            response from queue and send to the client on the port where
	 *            client is listening over TCP/IP
	 */
	public void sendtoclient(String name) {
		logger.info("preparing data from queue to send ......");
		try {
			while (true) {

				if (Global.responseHandleQue.isEmpty()) {
					try {
						thrd.sleep(1);
					} catch (InterruptedException ie) {
						ie.printStackTrace();
						logger.error(ExceptionCode.INTERRUPTED_EXCEPTION
								+ " Here we have getting error from sendtoclient() " + ie.getMessage());
					}

				} else {

					DataObject data_element = new DataObject();
					data_element = (DataObject) Global.responseHandleQue.poll();

					Socket sock = null;
					if (Global.testingEnabled == 1) {
						// data_element.setAmount("10");

						data_element.setAmount(Global.testingBalance);
					}
					data_element.setAmount(data_element.getBalnceDetailData());
					logger.info(">>> Got the data which we have to send in reponse [  " + data_element + "  ]");
					logger.info("Got DATA from Queue " + data_element.getMsisdn() + "" + data_element.getResCode() + ""
							+ data_element.getResponseDesc() + "" + data_element.getSock());

					sock = data_element.getSock();

					TLVAppInterface send_request = new TLVAppInterface();
					ByteArrayOutputStream send_buf = new ByteArrayOutputStream();
					send_request.setData(TlvParamsInterface.MSISDN_TAG, data_element.getMsisdn());
					if (Global.TEST_RESPONSE_CODE != null) { // Added for
																// testing
																// purpose only.
																// In case
																// response code
																// passed as
																// argument then
																// that code
																// will be
																// returned.
						send_request.setData(TlvParamsInterface.RESPONSE_TAG, Global.TEST_RESPONSE_CODE);
					} else {
						send_request.setData(TlvParamsInterface.RESPONSE_TAG, data_element.getResCode());
					}
					send_request.setData(TlvParamsInterface.RESPONSE_DESC, data_element.getResponseDesc());
					send_request.setData(TlvParamsInterface.AMOUNT_TAG, data_element.getAmount());
					send_request.setData(TlvParamsInterface.BALANCE_DETAIL_TAG, data_element.getBalnceDetailData());
					send_request.setData(TlvParamsInterface.REQTYPE_TAG, data_element.getRequestType());
					send_request.encode(send_buf);

					int send_requestLen = send_buf.size();
					try {

						if (sock.isClosed()) {
							// write data in file
							logger.info("Socket is closed...............we need to write the log file here");

							continue;
						}

						stream_send_data = new DataOutputStream(sock.getOutputStream());
						logger.debug("writing Info buf size=" + send_requestLen);
						byte[] len = new byte[4];
						len[3] = (byte) (send_requestLen);
						len[2] = (byte) ((send_requestLen >> 8));
						len[1] = (byte) ((send_requestLen >> 16));
						len[0] = (byte) ((send_requestLen >> 24));
						stream_send_data.write(len, 0, 4);
						// stream_send_data.writeInt(send_requestLen);
						// System.out.println("Data length sent of buf
						// size="+send_requestLen);
						stream_send_data.write(send_buf.toByteArray(), 0, send_buf.toByteArray().length);
						logger.info(data_element.getRequestType() + "#Process Complete=" + send_requestLen);

					} catch (SocketException se) {
						se.printStackTrace();
						logger.error(ExceptionCode.SOCKET_EXCEPTION + " Here we have getting error from sendtoclient() "
								+ se.getMessage());
						logger.fatal("Exception Sending Data:: " + se.toString());
						System.exit(1);
					} catch (IOException ioe) {
						ioe.printStackTrace();
						logger.error(ExceptionCode.IO_EXCEPTION + " Here we have getting error from sendtoclient() "
								+ ioe.getMessage());
						logger.fatal("Exception Sending Data:: " + ioe.toString());
						System.exit(1);
					} catch (Exception e) {
						e.printStackTrace();
						logger.error(
								"CSE-BE-00022" + " Here we have getting error from sendtoclient() " + e.getMessage());
						logger.fatal("Exception Sending Data:: " + e.toString());
						System.out.println("Exception Sending Data:: " + e.toString());
					}
					// break; //Uncommented just for compile otherwise no need
					// to be here ....
				}
			}

		} catch (NullPointerException npe) {
			npe.printStackTrace();
			logger.error(ExceptionCode.NULL_POINTER_EXCEPTION + " Here we have getting error from sendtoclient() "
					+ npe.getMessage());
			System.out.println(" sendtoclient exiting ");
			thrd.stop();
			System.out.println(" sendtoclient stopped success ");
			System.exit(1);
		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			logger.error(ExceptionCode.NUMBER_FORMAT_EXCEPTION + " Here we have getting error from sendtoclient() "
					+ nfe.getMessage());
			System.out.println(" sendtoclient exiting ");
			thrd.stop();
			System.out.println(" sendtoclient stopped success ");
			System.exit(1);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("CSE-BE-00023" + " Here we have getting error from sendtoclient() " + e.getMessage());
			System.out.println(" sendtoclient exiting ");
			thrd.stop();
			System.out.println(" sendtoclient stopped success ");
			System.exit(1);
		} finally {
			System.out.println(" sendtoclient stopped success ");

		}

	}
}
