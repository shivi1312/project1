/**
 * ServiceProviderPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.telemune.hlr.server;

public interface ServiceProviderPortType extends java.rmi.Remote {
    public int getSubType(int msisdn) throws java.rmi.RemoteException;
    public int downFlag(int msisdn) throws java.rmi.RemoteException;
    public int upFlag(int msisdn) throws java.rmi.RemoteException;
}
