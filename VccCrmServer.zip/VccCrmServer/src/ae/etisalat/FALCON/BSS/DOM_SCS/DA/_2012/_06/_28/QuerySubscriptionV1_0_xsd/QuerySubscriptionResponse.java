/**
 * QuerySubscriptionResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd;

public class QuerySubscriptionResponse  implements java.io.Serializable {
    private java.lang.String msisdn;

    private java.lang.Integer paymentMehtod;

    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Subscriptions subscriptions;

    private java.lang.String responseCode;

    private java.lang.String description;

    private int status;

    public QuerySubscriptionResponse() {
    }

    public QuerySubscriptionResponse(
           java.lang.String msisdn,
           java.lang.Integer paymentMehtod,
           ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Subscriptions subscriptions,
           java.lang.String responseCode,
           java.lang.String description,
           int status) {
           this.msisdn = msisdn;
           this.paymentMehtod = paymentMehtod;
           this.subscriptions = subscriptions;
           this.responseCode = responseCode;
           this.description = description;
           this.status = status;
    }


    /**
     * Gets the msisdn value for this QuerySubscriptionResponse.
     * 
     * @return msisdn
     */
    public java.lang.String getMsisdn() {
        return msisdn;
    }


    /**
     * Sets the msisdn value for this QuerySubscriptionResponse.
     * 
     * @param msisdn
     */
    public void setMsisdn(java.lang.String msisdn) {
        this.msisdn = msisdn;
    }


    /**
     * Gets the paymentMehtod value for this QuerySubscriptionResponse.
     * 
     * @return paymentMehtod
     */
    public java.lang.Integer getPaymentMehtod() {
        return paymentMehtod;
    }


    /**
     * Sets the paymentMehtod value for this QuerySubscriptionResponse.
     * 
     * @param paymentMehtod
     */
    public void setPaymentMehtod(java.lang.Integer paymentMehtod) {
        this.paymentMehtod = paymentMehtod;
    }


    /**
     * Gets the subscriptions value for this QuerySubscriptionResponse.
     * 
     * @return subscriptions
     */
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Subscriptions getSubscriptions() {
        return subscriptions;
    }


    /**
     * Sets the subscriptions value for this QuerySubscriptionResponse.
     * 
     * @param subscriptions
     */
    public void setSubscriptions(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Subscriptions subscriptions) {
        this.subscriptions = subscriptions;
    }


    /**
     * Gets the responseCode value for this QuerySubscriptionResponse.
     * 
     * @return responseCode
     */
    public java.lang.String getResponseCode() {
        return responseCode;
    }


    /**
     * Sets the responseCode value for this QuerySubscriptionResponse.
     * 
     * @param responseCode
     */
    public void setResponseCode(java.lang.String responseCode) {
        this.responseCode = responseCode;
    }


    /**
     * Gets the description value for this QuerySubscriptionResponse.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this QuerySubscriptionResponse.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the status value for this QuerySubscriptionResponse.
     * 
     * @return status
     */
    public int getStatus() {
        return status;
    }


    /**
     * Sets the status value for this QuerySubscriptionResponse.
     * 
     * @param status
     */
    public void setStatus(int status) {
        this.status = status;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QuerySubscriptionResponse)) return false;
        QuerySubscriptionResponse other = (QuerySubscriptionResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.msisdn==null && other.getMsisdn()==null) || 
             (this.msisdn!=null &&
              this.msisdn.equals(other.getMsisdn()))) &&
            ((this.paymentMehtod==null && other.getPaymentMehtod()==null) || 
             (this.paymentMehtod!=null &&
              this.paymentMehtod.equals(other.getPaymentMehtod()))) &&
            ((this.subscriptions==null && other.getSubscriptions()==null) || 
             (this.subscriptions!=null &&
              this.subscriptions.equals(other.getSubscriptions()))) &&
            ((this.responseCode==null && other.getResponseCode()==null) || 
             (this.responseCode!=null &&
              this.responseCode.equals(other.getResponseCode()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            this.status == other.getStatus();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMsisdn() != null) {
            _hashCode += getMsisdn().hashCode();
        }
        if (getPaymentMehtod() != null) {
            _hashCode += getPaymentMehtod().hashCode();
        }
        if (getSubscriptions() != null) {
            _hashCode += getSubscriptions().hashCode();
        }
        if (getResponseCode() != null) {
            _hashCode += getResponseCode().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        _hashCode += getStatus();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QuerySubscriptionResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "QuerySubscriptionResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msisdn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "msisdn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentMehtod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "paymentMehtod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subscriptions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "subscriptions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">subscriptions"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("responseCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "responseCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
