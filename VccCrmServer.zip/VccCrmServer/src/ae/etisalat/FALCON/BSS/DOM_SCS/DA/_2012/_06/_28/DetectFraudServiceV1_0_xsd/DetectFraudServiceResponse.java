/**
 * DetectFraudServiceResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd;

public class DetectFraudServiceResponse  implements java.io.Serializable {
    private java.lang.String transaction_id;

    private java.lang.String account_number;

    private java.lang.String response_code;

    private java.lang.String response_description;

    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.Additional_info[] additional_information;

    public DetectFraudServiceResponse() {
    }

    public DetectFraudServiceResponse(
           java.lang.String transaction_id,
           java.lang.String account_number,
           java.lang.String response_code,
           java.lang.String response_description,
           ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.Additional_info[] additional_information) {
           this.transaction_id = transaction_id;
           this.account_number = account_number;
           this.response_code = response_code;
           this.response_description = response_description;
           this.additional_information = additional_information;
    }


    /**
     * Gets the transaction_id value for this DetectFraudServiceResponse.
     * 
     * @return transaction_id
     */
    public java.lang.String getTransaction_id() {
        return transaction_id;
    }


    /**
     * Sets the transaction_id value for this DetectFraudServiceResponse.
     * 
     * @param transaction_id
     */
    public void setTransaction_id(java.lang.String transaction_id) {
        this.transaction_id = transaction_id;
    }


    /**
     * Gets the account_number value for this DetectFraudServiceResponse.
     * 
     * @return account_number
     */
    public java.lang.String getAccount_number() {
        return account_number;
    }


    /**
     * Sets the account_number value for this DetectFraudServiceResponse.
     * 
     * @param account_number
     */
    public void setAccount_number(java.lang.String account_number) {
        this.account_number = account_number;
    }


    /**
     * Gets the response_code value for this DetectFraudServiceResponse.
     * 
     * @return response_code
     */
    public java.lang.String getResponse_code() {
        return response_code;
    }


    /**
     * Sets the response_code value for this DetectFraudServiceResponse.
     * 
     * @param response_code
     */
    public void setResponse_code(java.lang.String response_code) {
        this.response_code = response_code;
    }


    /**
     * Gets the response_description value for this DetectFraudServiceResponse.
     * 
     * @return response_description
     */
    public java.lang.String getResponse_description() {
        return response_description;
    }


    /**
     * Sets the response_description value for this DetectFraudServiceResponse.
     * 
     * @param response_description
     */
    public void setResponse_description(java.lang.String response_description) {
        this.response_description = response_description;
    }


    /**
     * Gets the additional_information value for this DetectFraudServiceResponse.
     * 
     * @return additional_information
     */
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.Additional_info[] getAdditional_information() {
        return additional_information;
    }


    /**
     * Sets the additional_information value for this DetectFraudServiceResponse.
     * 
     * @param additional_information
     */
    public void setAdditional_information(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.Additional_info[] additional_information) {
        this.additional_information = additional_information;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DetectFraudServiceResponse)) return false;
        DetectFraudServiceResponse other = (DetectFraudServiceResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transaction_id==null && other.getTransaction_id()==null) || 
             (this.transaction_id!=null &&
              this.transaction_id.equals(other.getTransaction_id()))) &&
            ((this.account_number==null && other.getAccount_number()==null) || 
             (this.account_number!=null &&
              this.account_number.equals(other.getAccount_number()))) &&
            ((this.response_code==null && other.getResponse_code()==null) || 
             (this.response_code!=null &&
              this.response_code.equals(other.getResponse_code()))) &&
            ((this.response_description==null && other.getResponse_description()==null) || 
             (this.response_description!=null &&
              this.response_description.equals(other.getResponse_description()))) &&
            ((this.additional_information==null && other.getAdditional_information()==null) || 
             (this.additional_information!=null &&
              java.util.Arrays.equals(this.additional_information, other.getAdditional_information())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransaction_id() != null) {
            _hashCode += getTransaction_id().hashCode();
        }
        if (getAccount_number() != null) {
            _hashCode += getAccount_number().hashCode();
        }
        if (getResponse_code() != null) {
            _hashCode += getResponse_code().hashCode();
        }
        if (getResponse_description() != null) {
            _hashCode += getResponse_description().hashCode();
        }
        if (getAdditional_information() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAdditional_information());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAdditional_information(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DetectFraudServiceResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "DetectFraudServiceResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transaction_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "transaction_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("account_number");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "account_number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("response_code");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "response_code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("response_description");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "response_description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("additional_information");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "additional_information"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", ">additional_information"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
