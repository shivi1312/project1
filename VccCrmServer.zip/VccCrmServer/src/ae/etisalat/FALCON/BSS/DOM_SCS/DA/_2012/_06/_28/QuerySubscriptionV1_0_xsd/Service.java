/**
 * Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd;

public class Service  implements java.io.Serializable {
    private java.lang.String externalServiceId;

    private java.lang.Integer serviceStatus;

    private java.lang.String serviceDescription;

    private java.lang.Double initialAmount;

    private java.lang.Double remainingAmount;

    private java.lang.String serviceExpiryDate;

    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.ServiceAttribute[] serviceAttributes;

    public Service() {
    }

    public Service(
           java.lang.String externalServiceId,
           java.lang.Integer serviceStatus,
           java.lang.String serviceDescription,
           java.lang.Double initialAmount,
           java.lang.Double remainingAmount,
           java.lang.String serviceExpiryDate,
           ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.ServiceAttribute[] serviceAttributes) {
           this.externalServiceId = externalServiceId;
           this.serviceStatus = serviceStatus;
           this.serviceDescription = serviceDescription;
           this.initialAmount = initialAmount;
           this.remainingAmount = remainingAmount;
           this.serviceExpiryDate = serviceExpiryDate;
           this.serviceAttributes = serviceAttributes;
    }


    /**
     * Gets the externalServiceId value for this Service.
     * 
     * @return externalServiceId
     */
    public java.lang.String getExternalServiceId() {
        return externalServiceId;
    }


    /**
     * Sets the externalServiceId value for this Service.
     * 
     * @param externalServiceId
     */
    public void setExternalServiceId(java.lang.String externalServiceId) {
        this.externalServiceId = externalServiceId;
    }


    /**
     * Gets the serviceStatus value for this Service.
     * 
     * @return serviceStatus
     */
    public java.lang.Integer getServiceStatus() {
        return serviceStatus;
    }


    /**
     * Sets the serviceStatus value for this Service.
     * 
     * @param serviceStatus
     */
    public void setServiceStatus(java.lang.Integer serviceStatus) {
        this.serviceStatus = serviceStatus;
    }


    /**
     * Gets the serviceDescription value for this Service.
     * 
     * @return serviceDescription
     */
    public java.lang.String getServiceDescription() {
        return serviceDescription;
    }


    /**
     * Sets the serviceDescription value for this Service.
     * 
     * @param serviceDescription
     */
    public void setServiceDescription(java.lang.String serviceDescription) {
        this.serviceDescription = serviceDescription;
    }


    /**
     * Gets the initialAmount value for this Service.
     * 
     * @return initialAmount
     */
    public java.lang.Double getInitialAmount() {
        return initialAmount;
    }


    /**
     * Sets the initialAmount value for this Service.
     * 
     * @param initialAmount
     */
    public void setInitialAmount(java.lang.Double initialAmount) {
        this.initialAmount = initialAmount;
    }


    /**
     * Gets the remainingAmount value for this Service.
     * 
     * @return remainingAmount
     */
    public java.lang.Double getRemainingAmount() {
        return remainingAmount;
    }


    /**
     * Sets the remainingAmount value for this Service.
     * 
     * @param remainingAmount
     */
    public void setRemainingAmount(java.lang.Double remainingAmount) {
        this.remainingAmount = remainingAmount;
    }


    /**
     * Gets the serviceExpiryDate value for this Service.
     * 
     * @return serviceExpiryDate
     */
    public java.lang.String getServiceExpiryDate() {
        return serviceExpiryDate;
    }


    /**
     * Sets the serviceExpiryDate value for this Service.
     * 
     * @param serviceExpiryDate
     */
    public void setServiceExpiryDate(java.lang.String serviceExpiryDate) {
        this.serviceExpiryDate = serviceExpiryDate;
    }


    /**
     * Gets the serviceAttributes value for this Service.
     * 
     * @return serviceAttributes
     */
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.ServiceAttribute[] getServiceAttributes() {
        return serviceAttributes;
    }


    /**
     * Sets the serviceAttributes value for this Service.
     * 
     * @param serviceAttributes
     */
    public void setServiceAttributes(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.ServiceAttribute[] serviceAttributes) {
        this.serviceAttributes = serviceAttributes;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Service)) return false;
        Service other = (Service) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.externalServiceId==null && other.getExternalServiceId()==null) || 
             (this.externalServiceId!=null &&
              this.externalServiceId.equals(other.getExternalServiceId()))) &&
            ((this.serviceStatus==null && other.getServiceStatus()==null) || 
             (this.serviceStatus!=null &&
              this.serviceStatus.equals(other.getServiceStatus()))) &&
            ((this.serviceDescription==null && other.getServiceDescription()==null) || 
             (this.serviceDescription!=null &&
              this.serviceDescription.equals(other.getServiceDescription()))) &&
            ((this.initialAmount==null && other.getInitialAmount()==null) || 
             (this.initialAmount!=null &&
              this.initialAmount.equals(other.getInitialAmount()))) &&
            ((this.remainingAmount==null && other.getRemainingAmount()==null) || 
             (this.remainingAmount!=null &&
              this.remainingAmount.equals(other.getRemainingAmount()))) &&
            ((this.serviceExpiryDate==null && other.getServiceExpiryDate()==null) || 
             (this.serviceExpiryDate!=null &&
              this.serviceExpiryDate.equals(other.getServiceExpiryDate()))) &&
            ((this.serviceAttributes==null && other.getServiceAttributes()==null) || 
             (this.serviceAttributes!=null &&
              java.util.Arrays.equals(this.serviceAttributes, other.getServiceAttributes())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getExternalServiceId() != null) {
            _hashCode += getExternalServiceId().hashCode();
        }
        if (getServiceStatus() != null) {
            _hashCode += getServiceStatus().hashCode();
        }
        if (getServiceDescription() != null) {
            _hashCode += getServiceDescription().hashCode();
        }
        if (getInitialAmount() != null) {
            _hashCode += getInitialAmount().hashCode();
        }
        if (getRemainingAmount() != null) {
            _hashCode += getRemainingAmount().hashCode();
        }
        if (getServiceExpiryDate() != null) {
            _hashCode += getServiceExpiryDate().hashCode();
        }
        if (getServiceAttributes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getServiceAttributes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getServiceAttributes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Service.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">service"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("externalServiceId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "externalServiceId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "serviceStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceDescription");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "serviceDescription"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("initialAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "initialAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remainingAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "remainingAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceExpiryDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "serviceExpiryDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceAttributes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "serviceAttributes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">serviceAttributes"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
