/**
 * OtherServicesBillingRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd;

public class OtherServicesBillingRequest  implements java.io.Serializable {
    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.ChannelInformation channelInformation;

    private java.lang.String account_no;

    private java.lang.String ani;

    private java.lang.String transactionID;

    private java.lang.String request_type_flag;

    public OtherServicesBillingRequest() {
    }

    public OtherServicesBillingRequest(
           ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.ChannelInformation channelInformation,
           java.lang.String account_no,
           java.lang.String ani,
           java.lang.String transactionID,
           java.lang.String request_type_flag) {
           this.channelInformation = channelInformation;
           this.account_no = account_no;
           this.ani = ani;
           this.transactionID = transactionID;
           this.request_type_flag = request_type_flag;
    }


    /**
     * Gets the channelInformation value for this OtherServicesBillingRequest.
     * 
     * @return channelInformation
     */
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.ChannelInformation getChannelInformation() {
        return channelInformation;
    }


    /**
     * Sets the channelInformation value for this OtherServicesBillingRequest.
     * 
     * @param channelInformation
     */
    public void setChannelInformation(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.ChannelInformation channelInformation) {
        this.channelInformation = channelInformation;
    }


    /**
     * Gets the account_no value for this OtherServicesBillingRequest.
     * 
     * @return account_no
     */
    public java.lang.String getAccount_no() {
        return account_no;
    }


    /**
     * Sets the account_no value for this OtherServicesBillingRequest.
     * 
     * @param account_no
     */
    public void setAccount_no(java.lang.String account_no) {
        this.account_no = account_no;
    }


    /**
     * Gets the ani value for this OtherServicesBillingRequest.
     * 
     * @return ani
     */
    public java.lang.String getAni() {
        return ani;
    }


    /**
     * Sets the ani value for this OtherServicesBillingRequest.
     * 
     * @param ani
     */
    public void setAni(java.lang.String ani) {
        this.ani = ani;
    }


    /**
     * Gets the transactionID value for this OtherServicesBillingRequest.
     * 
     * @return transactionID
     */
    public java.lang.String getTransactionID() {
        return transactionID;
    }


    /**
     * Sets the transactionID value for this OtherServicesBillingRequest.
     * 
     * @param transactionID
     */
    public void setTransactionID(java.lang.String transactionID) {
        this.transactionID = transactionID;
    }


    /**
     * Gets the request_type_flag value for this OtherServicesBillingRequest.
     * 
     * @return request_type_flag
     */
    public java.lang.String getRequest_type_flag() {
        return request_type_flag;
    }


    /**
     * Sets the request_type_flag value for this OtherServicesBillingRequest.
     * 
     * @param request_type_flag
     */
    public void setRequest_type_flag(java.lang.String request_type_flag) {
        this.request_type_flag = request_type_flag;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OtherServicesBillingRequest)) return false;
        OtherServicesBillingRequest other = (OtherServicesBillingRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.channelInformation==null && other.getChannelInformation()==null) || 
             (this.channelInformation!=null &&
              this.channelInformation.equals(other.getChannelInformation()))) &&
            ((this.account_no==null && other.getAccount_no()==null) || 
             (this.account_no!=null &&
              this.account_no.equals(other.getAccount_no()))) &&
            ((this.ani==null && other.getAni()==null) || 
             (this.ani!=null &&
              this.ani.equals(other.getAni()))) &&
            ((this.transactionID==null && other.getTransactionID()==null) || 
             (this.transactionID!=null &&
              this.transactionID.equals(other.getTransactionID()))) &&
            ((this.request_type_flag==null && other.getRequest_type_flag()==null) || 
             (this.request_type_flag!=null &&
              this.request_type_flag.equals(other.getRequest_type_flag())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getChannelInformation() != null) {
            _hashCode += getChannelInformation().hashCode();
        }
        if (getAccount_no() != null) {
            _hashCode += getAccount_no().hashCode();
        }
        if (getAni() != null) {
            _hashCode += getAni().hashCode();
        }
        if (getTransactionID() != null) {
            _hashCode += getTransactionID().hashCode();
        }
        if (getRequest_type_flag() != null) {
            _hashCode += getRequest_type_flag().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OtherServicesBillingRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "OtherServicesBillingRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("channelInformation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "channelInformation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", ">channelInformation"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("account_no");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "account_no"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ani");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "ani"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "transactionID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("request_type_flag");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "Request_type_flag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
