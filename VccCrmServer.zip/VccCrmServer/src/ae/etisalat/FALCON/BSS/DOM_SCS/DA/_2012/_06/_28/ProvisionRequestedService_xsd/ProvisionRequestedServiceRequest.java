/**
 * ProvisionRequestedServiceRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd;

public class ProvisionRequestedServiceRequest  implements java.io.Serializable {
    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.ChannelInformation channelInformation;

    private java.lang.String transaction_id;

    private java.lang.String method_name;

    private java.lang.String msisdn;

    private java.lang.String part_num;

    private java.lang.String offer_id;

    private java.lang.String campaign_id;

    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.Additional_info[] additional_information;

    private java.lang.String mode_type;

    private java.lang.String preferred_language;

    public ProvisionRequestedServiceRequest() {
    }

    public ProvisionRequestedServiceRequest(
           ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.ChannelInformation channelInformation,
           java.lang.String transaction_id,
           java.lang.String method_name,
           java.lang.String msisdn,
           java.lang.String part_num,
           java.lang.String offer_id,
           java.lang.String campaign_id,
           ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.Additional_info[] additional_information,
           java.lang.String mode_type,
           java.lang.String preferred_language) {
           this.channelInformation = channelInformation;
           this.transaction_id = transaction_id;
           this.method_name = method_name;
           this.msisdn = msisdn;
           this.part_num = part_num;
           this.offer_id = offer_id;
           this.campaign_id = campaign_id;
           this.additional_information = additional_information;
           this.mode_type = mode_type;
           this.preferred_language = preferred_language;
    }


    /**
     * Gets the channelInformation value for this ProvisionRequestedServiceRequest.
     * 
     * @return channelInformation
     */
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.ChannelInformation getChannelInformation() {
        return channelInformation;
    }


    /**
     * Sets the channelInformation value for this ProvisionRequestedServiceRequest.
     * 
     * @param channelInformation
     */
    public void setChannelInformation(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.ChannelInformation channelInformation) {
        this.channelInformation = channelInformation;
    }


    /**
     * Gets the transaction_id value for this ProvisionRequestedServiceRequest.
     * 
     * @return transaction_id
     */
    public java.lang.String getTransaction_id() {
        return transaction_id;
    }


    /**
     * Sets the transaction_id value for this ProvisionRequestedServiceRequest.
     * 
     * @param transaction_id
     */
    public void setTransaction_id(java.lang.String transaction_id) {
        this.transaction_id = transaction_id;
    }


    /**
     * Gets the method_name value for this ProvisionRequestedServiceRequest.
     * 
     * @return method_name
     */
    public java.lang.String getMethod_name() {
        return method_name;
    }


    /**
     * Sets the method_name value for this ProvisionRequestedServiceRequest.
     * 
     * @param method_name
     */
    public void setMethod_name(java.lang.String method_name) {
        this.method_name = method_name;
    }


    /**
     * Gets the msisdn value for this ProvisionRequestedServiceRequest.
     * 
     * @return msisdn
     */
    public java.lang.String getMsisdn() {
        return msisdn;
    }


    /**
     * Sets the msisdn value for this ProvisionRequestedServiceRequest.
     * 
     * @param msisdn
     */
    public void setMsisdn(java.lang.String msisdn) {
        this.msisdn = msisdn;
    }


    /**
     * Gets the part_num value for this ProvisionRequestedServiceRequest.
     * 
     * @return part_num
     */
    public java.lang.String getPart_num() {
        return part_num;
    }


    /**
     * Sets the part_num value for this ProvisionRequestedServiceRequest.
     * 
     * @param part_num
     */
    public void setPart_num(java.lang.String part_num) {
        this.part_num = part_num;
    }


    /**
     * Gets the offer_id value for this ProvisionRequestedServiceRequest.
     * 
     * @return offer_id
     */
    public java.lang.String getOffer_id() {
        return offer_id;
    }


    /**
     * Sets the offer_id value for this ProvisionRequestedServiceRequest.
     * 
     * @param offer_id
     */
    public void setOffer_id(java.lang.String offer_id) {
        this.offer_id = offer_id;
    }


    /**
     * Gets the campaign_id value for this ProvisionRequestedServiceRequest.
     * 
     * @return campaign_id
     */
    public java.lang.String getCampaign_id() {
        return campaign_id;
    }


    /**
     * Sets the campaign_id value for this ProvisionRequestedServiceRequest.
     * 
     * @param campaign_id
     */
    public void setCampaign_id(java.lang.String campaign_id) {
        this.campaign_id = campaign_id;
    }


    /**
     * Gets the additional_information value for this ProvisionRequestedServiceRequest.
     * 
     * @return additional_information
     */
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.Additional_info[] getAdditional_information() {
        return additional_information;
    }


    /**
     * Sets the additional_information value for this ProvisionRequestedServiceRequest.
     * 
     * @param additional_information
     */
    public void setAdditional_information(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.Additional_info[] additional_information) {
        this.additional_information = additional_information;
    }


    /**
     * Gets the mode_type value for this ProvisionRequestedServiceRequest.
     * 
     * @return mode_type
     */
    public java.lang.String getMode_type() {
        return mode_type;
    }


    /**
     * Sets the mode_type value for this ProvisionRequestedServiceRequest.
     * 
     * @param mode_type
     */
    public void setMode_type(java.lang.String mode_type) {
        this.mode_type = mode_type;
    }


    /**
     * Gets the preferred_language value for this ProvisionRequestedServiceRequest.
     * 
     * @return preferred_language
     */
    public java.lang.String getPreferred_language() {
        return preferred_language;
    }


    /**
     * Sets the preferred_language value for this ProvisionRequestedServiceRequest.
     * 
     * @param preferred_language
     */
    public void setPreferred_language(java.lang.String preferred_language) {
        this.preferred_language = preferred_language;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProvisionRequestedServiceRequest)) return false;
        ProvisionRequestedServiceRequest other = (ProvisionRequestedServiceRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.channelInformation==null && other.getChannelInformation()==null) || 
             (this.channelInformation!=null &&
              this.channelInformation.equals(other.getChannelInformation()))) &&
            ((this.transaction_id==null && other.getTransaction_id()==null) || 
             (this.transaction_id!=null &&
              this.transaction_id.equals(other.getTransaction_id()))) &&
            ((this.method_name==null && other.getMethod_name()==null) || 
             (this.method_name!=null &&
              this.method_name.equals(other.getMethod_name()))) &&
            ((this.msisdn==null && other.getMsisdn()==null) || 
             (this.msisdn!=null &&
              this.msisdn.equals(other.getMsisdn()))) &&
            ((this.part_num==null && other.getPart_num()==null) || 
             (this.part_num!=null &&
              this.part_num.equals(other.getPart_num()))) &&
            ((this.offer_id==null && other.getOffer_id()==null) || 
             (this.offer_id!=null &&
              this.offer_id.equals(other.getOffer_id()))) &&
            ((this.campaign_id==null && other.getCampaign_id()==null) || 
             (this.campaign_id!=null &&
              this.campaign_id.equals(other.getCampaign_id()))) &&
            ((this.additional_information==null && other.getAdditional_information()==null) || 
             (this.additional_information!=null &&
              java.util.Arrays.equals(this.additional_information, other.getAdditional_information()))) &&
            ((this.mode_type==null && other.getMode_type()==null) || 
             (this.mode_type!=null &&
              this.mode_type.equals(other.getMode_type()))) &&
            ((this.preferred_language==null && other.getPreferred_language()==null) || 
             (this.preferred_language!=null &&
              this.preferred_language.equals(other.getPreferred_language())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getChannelInformation() != null) {
            _hashCode += getChannelInformation().hashCode();
        }
        if (getTransaction_id() != null) {
            _hashCode += getTransaction_id().hashCode();
        }
        if (getMethod_name() != null) {
            _hashCode += getMethod_name().hashCode();
        }
        if (getMsisdn() != null) {
            _hashCode += getMsisdn().hashCode();
        }
        if (getPart_num() != null) {
            _hashCode += getPart_num().hashCode();
        }
        if (getOffer_id() != null) {
            _hashCode += getOffer_id().hashCode();
        }
        if (getCampaign_id() != null) {
            _hashCode += getCampaign_id().hashCode();
        }
        if (getAdditional_information() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAdditional_information());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAdditional_information(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMode_type() != null) {
            _hashCode += getMode_type().hashCode();
        }
        if (getPreferred_language() != null) {
            _hashCode += getPreferred_language().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProvisionRequestedServiceRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "ProvisionRequestedServiceRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("channelInformation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "channelInformation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", ">channelInformation"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transaction_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "transaction_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("method_name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "method_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msisdn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "msisdn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("part_num");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "part_num"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offer_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "offer_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("campaign_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "campaign_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("additional_information");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "additional_information"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", ">additional_information"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mode_type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "mode_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("preferred_language");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "preferred_language"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
