/**
 * GetFaultDockCrtCCOResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd;

public class GetFaultDockCrtCCOResponse  implements java.io.Serializable {
    private java.lang.String error_Message;

    private java.lang.String error_No;

    private java.lang.String message;

    private java.lang.String total_No_Of_Recs;

    public GetFaultDockCrtCCOResponse() {
    }

    public GetFaultDockCrtCCOResponse(
           java.lang.String error_Message,
           java.lang.String error_No,
           java.lang.String message,
           java.lang.String total_No_Of_Recs) {
           this.error_Message = error_Message;
           this.error_No = error_No;
           this.message = message;
           this.total_No_Of_Recs = total_No_Of_Recs;
    }


    /**
     * Gets the error_Message value for this GetFaultDockCrtCCOResponse.
     * 
     * @return error_Message
     */
    public java.lang.String getError_Message() {
        return error_Message;
    }


    /**
     * Sets the error_Message value for this GetFaultDockCrtCCOResponse.
     * 
     * @param error_Message
     */
    public void setError_Message(java.lang.String error_Message) {
        this.error_Message = error_Message;
    }


    /**
     * Gets the error_No value for this GetFaultDockCrtCCOResponse.
     * 
     * @return error_No
     */
    public java.lang.String getError_No() {
        return error_No;
    }


    /**
     * Sets the error_No value for this GetFaultDockCrtCCOResponse.
     * 
     * @param error_No
     */
    public void setError_No(java.lang.String error_No) {
        this.error_No = error_No;
    }


    /**
     * Gets the message value for this GetFaultDockCrtCCOResponse.
     * 
     * @return message
     */
    public java.lang.String getMessage() {
        return message;
    }


    /**
     * Sets the message value for this GetFaultDockCrtCCOResponse.
     * 
     * @param message
     */
    public void setMessage(java.lang.String message) {
        this.message = message;
    }


    /**
     * Gets the total_No_Of_Recs value for this GetFaultDockCrtCCOResponse.
     * 
     * @return total_No_Of_Recs
     */
    public java.lang.String getTotal_No_Of_Recs() {
        return total_No_Of_Recs;
    }


    /**
     * Sets the total_No_Of_Recs value for this GetFaultDockCrtCCOResponse.
     * 
     * @param total_No_Of_Recs
     */
    public void setTotal_No_Of_Recs(java.lang.String total_No_Of_Recs) {
        this.total_No_Of_Recs = total_No_Of_Recs;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetFaultDockCrtCCOResponse)) return false;
        GetFaultDockCrtCCOResponse other = (GetFaultDockCrtCCOResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.error_Message==null && other.getError_Message()==null) || 
             (this.error_Message!=null &&
              this.error_Message.equals(other.getError_Message()))) &&
            ((this.error_No==null && other.getError_No()==null) || 
             (this.error_No!=null &&
              this.error_No.equals(other.getError_No()))) &&
            ((this.message==null && other.getMessage()==null) || 
             (this.message!=null &&
              this.message.equals(other.getMessage()))) &&
            ((this.total_No_Of_Recs==null && other.getTotal_No_Of_Recs()==null) || 
             (this.total_No_Of_Recs!=null &&
              this.total_No_Of_Recs.equals(other.getTotal_No_Of_Recs())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getError_Message() != null) {
            _hashCode += getError_Message().hashCode();
        }
        if (getError_No() != null) {
            _hashCode += getError_No().hashCode();
        }
        if (getMessage() != null) {
            _hashCode += getMessage().hashCode();
        }
        if (getTotal_No_Of_Recs() != null) {
            _hashCode += getTotal_No_Of_Recs().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetFaultDockCrtCCOResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "GetFaultDockCrtCCOResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("error_Message");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Error_Message"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("error_No");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Error_No"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("message");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Message"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("total_No_Of_Recs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Total_No_Of_Recs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
