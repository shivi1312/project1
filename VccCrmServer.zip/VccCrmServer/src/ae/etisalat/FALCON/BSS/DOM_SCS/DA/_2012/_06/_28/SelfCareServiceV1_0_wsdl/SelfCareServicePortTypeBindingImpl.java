/**
 * SelfCareServicePortTypeBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl;

import com.vcc.telemune.service.CrmService;

public class SelfCareServicePortTypeBindingImpl implements ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServicePortType{
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope opInquiryNotification(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope inquiryNotificationRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope opQueryGFFNumbersList(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope queryGFFNumbersListRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope opVerifyServiceOrderStatus(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope verifyServiceOrderStatusRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope opModifyService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope modifyServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponse opUpdateOrderStatus(com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequest updateOrderStatusRequest) throws java.rmi.RemoteException, ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage {
    	System.out.println("inside............first.......");
    	return new CrmService().updateCallBack(updateOrderStatusRequest);
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope opCheckEnoughBalance(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope checkEnoughBalanceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope opOtherServicesBilling(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope otherServicesBillingRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope opCancelService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope cancelServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope opQueryCustomerServiceDetails(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope queryCustomerServiceDetailsRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope opViewPlan(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope viewPlanRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope opMigrationStatusCheck(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope migrationStatusCheckRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope opDetectFraudService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope detectFraudServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope opGetBlockedStatus(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope getBlockedStatusRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope opBlackberryInquiry(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope blackberryInquiryRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope opEmcaisService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope emcaisServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope opVerifyComplaintStatus(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope verifyComplaintStatusRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope opQuerySubscription(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope querySubscriptionRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope opCheckSubscription(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope checkSubscriptionRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope opGetFaultDockCrtCC(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope getFaultDockCrtCCRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope opQuerySubscribedServicesList(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope querySubscribedServicesListRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope opGetEvisionBilling(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope getEvisionBillingRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponse opCheckEligibility(com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequest checkEligibilityRequest) throws java.rmi.RemoteException, ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage {
        return null;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope opProvisionRequestedService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope provisionRequestedServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        return null;
    }

}
