/**
 * OtherServicesBillingResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd;

public class OtherServicesBillingResponse  implements java.io.Serializable {
    private java.lang.String account_no;

    private java.lang.String action_flag;

    private double current_month_charges;

    private long cycle_no;

    private java.lang.Long error_no;

    private double last_payment_amount;

    private java.lang.String last_payment_date;

    private double payments;

    private double prev_month_balance;

    private java.lang.String product;

    private java.lang.String product_group;

    private long status_code;

    private java.lang.String status_desc;

    private java.lang.Long total_no_of_recs;

    private double tot_amount_due;

    private java.lang.String trans_reference_s;

    private java.lang.String sn_code;

    private java.lang.String sn_description;

    public OtherServicesBillingResponse() {
    }

    public OtherServicesBillingResponse(
           java.lang.String account_no,
           java.lang.String action_flag,
           double current_month_charges,
           long cycle_no,
           java.lang.Long error_no,
           double last_payment_amount,
           java.lang.String last_payment_date,
           double payments,
           double prev_month_balance,
           java.lang.String product,
           java.lang.String product_group,
           long status_code,
           java.lang.String status_desc,
           java.lang.Long total_no_of_recs,
           double tot_amount_due,
           java.lang.String trans_reference_s,
           java.lang.String sn_code,
           java.lang.String sn_description) {
           this.account_no = account_no;
           this.action_flag = action_flag;
           this.current_month_charges = current_month_charges;
           this.cycle_no = cycle_no;
           this.error_no = error_no;
           this.last_payment_amount = last_payment_amount;
           this.last_payment_date = last_payment_date;
           this.payments = payments;
           this.prev_month_balance = prev_month_balance;
           this.product = product;
           this.product_group = product_group;
           this.status_code = status_code;
           this.status_desc = status_desc;
           this.total_no_of_recs = total_no_of_recs;
           this.tot_amount_due = tot_amount_due;
           this.trans_reference_s = trans_reference_s;
           this.sn_code = sn_code;
           this.sn_description = sn_description;
    }


    /**
     * Gets the account_no value for this OtherServicesBillingResponse.
     * 
     * @return account_no
     */
    public java.lang.String getAccount_no() {
        return account_no;
    }


    /**
     * Sets the account_no value for this OtherServicesBillingResponse.
     * 
     * @param account_no
     */
    public void setAccount_no(java.lang.String account_no) {
        this.account_no = account_no;
    }


    /**
     * Gets the action_flag value for this OtherServicesBillingResponse.
     * 
     * @return action_flag
     */
    public java.lang.String getAction_flag() {
        return action_flag;
    }


    /**
     * Sets the action_flag value for this OtherServicesBillingResponse.
     * 
     * @param action_flag
     */
    public void setAction_flag(java.lang.String action_flag) {
        this.action_flag = action_flag;
    }


    /**
     * Gets the current_month_charges value for this OtherServicesBillingResponse.
     * 
     * @return current_month_charges
     */
    public double getCurrent_month_charges() {
        return current_month_charges;
    }


    /**
     * Sets the current_month_charges value for this OtherServicesBillingResponse.
     * 
     * @param current_month_charges
     */
    public void setCurrent_month_charges(double current_month_charges) {
        this.current_month_charges = current_month_charges;
    }


    /**
     * Gets the cycle_no value for this OtherServicesBillingResponse.
     * 
     * @return cycle_no
     */
    public long getCycle_no() {
        return cycle_no;
    }


    /**
     * Sets the cycle_no value for this OtherServicesBillingResponse.
     * 
     * @param cycle_no
     */
    public void setCycle_no(long cycle_no) {
        this.cycle_no = cycle_no;
    }


    /**
     * Gets the error_no value for this OtherServicesBillingResponse.
     * 
     * @return error_no
     */
    public java.lang.Long getError_no() {
        return error_no;
    }


    /**
     * Sets the error_no value for this OtherServicesBillingResponse.
     * 
     * @param error_no
     */
    public void setError_no(java.lang.Long error_no) {
        this.error_no = error_no;
    }


    /**
     * Gets the last_payment_amount value for this OtherServicesBillingResponse.
     * 
     * @return last_payment_amount
     */
    public double getLast_payment_amount() {
        return last_payment_amount;
    }


    /**
     * Sets the last_payment_amount value for this OtherServicesBillingResponse.
     * 
     * @param last_payment_amount
     */
    public void setLast_payment_amount(double last_payment_amount) {
        this.last_payment_amount = last_payment_amount;
    }


    /**
     * Gets the last_payment_date value for this OtherServicesBillingResponse.
     * 
     * @return last_payment_date
     */
    public java.lang.String getLast_payment_date() {
        return last_payment_date;
    }


    /**
     * Sets the last_payment_date value for this OtherServicesBillingResponse.
     * 
     * @param last_payment_date
     */
    public void setLast_payment_date(java.lang.String last_payment_date) {
        this.last_payment_date = last_payment_date;
    }


    /**
     * Gets the payments value for this OtherServicesBillingResponse.
     * 
     * @return payments
     */
    public double getPayments() {
        return payments;
    }


    /**
     * Sets the payments value for this OtherServicesBillingResponse.
     * 
     * @param payments
     */
    public void setPayments(double payments) {
        this.payments = payments;
    }


    /**
     * Gets the prev_month_balance value for this OtherServicesBillingResponse.
     * 
     * @return prev_month_balance
     */
    public double getPrev_month_balance() {
        return prev_month_balance;
    }


    /**
     * Sets the prev_month_balance value for this OtherServicesBillingResponse.
     * 
     * @param prev_month_balance
     */
    public void setPrev_month_balance(double prev_month_balance) {
        this.prev_month_balance = prev_month_balance;
    }


    /**
     * Gets the product value for this OtherServicesBillingResponse.
     * 
     * @return product
     */
    public java.lang.String getProduct() {
        return product;
    }


    /**
     * Sets the product value for this OtherServicesBillingResponse.
     * 
     * @param product
     */
    public void setProduct(java.lang.String product) {
        this.product = product;
    }


    /**
     * Gets the product_group value for this OtherServicesBillingResponse.
     * 
     * @return product_group
     */
    public java.lang.String getProduct_group() {
        return product_group;
    }


    /**
     * Sets the product_group value for this OtherServicesBillingResponse.
     * 
     * @param product_group
     */
    public void setProduct_group(java.lang.String product_group) {
        this.product_group = product_group;
    }


    /**
     * Gets the status_code value for this OtherServicesBillingResponse.
     * 
     * @return status_code
     */
    public long getStatus_code() {
        return status_code;
    }


    /**
     * Sets the status_code value for this OtherServicesBillingResponse.
     * 
     * @param status_code
     */
    public void setStatus_code(long status_code) {
        this.status_code = status_code;
    }


    /**
     * Gets the status_desc value for this OtherServicesBillingResponse.
     * 
     * @return status_desc
     */
    public java.lang.String getStatus_desc() {
        return status_desc;
    }


    /**
     * Sets the status_desc value for this OtherServicesBillingResponse.
     * 
     * @param status_desc
     */
    public void setStatus_desc(java.lang.String status_desc) {
        this.status_desc = status_desc;
    }


    /**
     * Gets the total_no_of_recs value for this OtherServicesBillingResponse.
     * 
     * @return total_no_of_recs
     */
    public java.lang.Long getTotal_no_of_recs() {
        return total_no_of_recs;
    }


    /**
     * Sets the total_no_of_recs value for this OtherServicesBillingResponse.
     * 
     * @param total_no_of_recs
     */
    public void setTotal_no_of_recs(java.lang.Long total_no_of_recs) {
        this.total_no_of_recs = total_no_of_recs;
    }


    /**
     * Gets the tot_amount_due value for this OtherServicesBillingResponse.
     * 
     * @return tot_amount_due
     */
    public double getTot_amount_due() {
        return tot_amount_due;
    }


    /**
     * Sets the tot_amount_due value for this OtherServicesBillingResponse.
     * 
     * @param tot_amount_due
     */
    public void setTot_amount_due(double tot_amount_due) {
        this.tot_amount_due = tot_amount_due;
    }


    /**
     * Gets the trans_reference_s value for this OtherServicesBillingResponse.
     * 
     * @return trans_reference_s
     */
    public java.lang.String getTrans_reference_s() {
        return trans_reference_s;
    }


    /**
     * Sets the trans_reference_s value for this OtherServicesBillingResponse.
     * 
     * @param trans_reference_s
     */
    public void setTrans_reference_s(java.lang.String trans_reference_s) {
        this.trans_reference_s = trans_reference_s;
    }


    /**
     * Gets the sn_code value for this OtherServicesBillingResponse.
     * 
     * @return sn_code
     */
    public java.lang.String getSn_code() {
        return sn_code;
    }


    /**
     * Sets the sn_code value for this OtherServicesBillingResponse.
     * 
     * @param sn_code
     */
    public void setSn_code(java.lang.String sn_code) {
        this.sn_code = sn_code;
    }


    /**
     * Gets the sn_description value for this OtherServicesBillingResponse.
     * 
     * @return sn_description
     */
    public java.lang.String getSn_description() {
        return sn_description;
    }


    /**
     * Sets the sn_description value for this OtherServicesBillingResponse.
     * 
     * @param sn_description
     */
    public void setSn_description(java.lang.String sn_description) {
        this.sn_description = sn_description;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OtherServicesBillingResponse)) return false;
        OtherServicesBillingResponse other = (OtherServicesBillingResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.account_no==null && other.getAccount_no()==null) || 
             (this.account_no!=null &&
              this.account_no.equals(other.getAccount_no()))) &&
            ((this.action_flag==null && other.getAction_flag()==null) || 
             (this.action_flag!=null &&
              this.action_flag.equals(other.getAction_flag()))) &&
            this.current_month_charges == other.getCurrent_month_charges() &&
            this.cycle_no == other.getCycle_no() &&
            ((this.error_no==null && other.getError_no()==null) || 
             (this.error_no!=null &&
              this.error_no.equals(other.getError_no()))) &&
            this.last_payment_amount == other.getLast_payment_amount() &&
            ((this.last_payment_date==null && other.getLast_payment_date()==null) || 
             (this.last_payment_date!=null &&
              this.last_payment_date.equals(other.getLast_payment_date()))) &&
            this.payments == other.getPayments() &&
            this.prev_month_balance == other.getPrev_month_balance() &&
            ((this.product==null && other.getProduct()==null) || 
             (this.product!=null &&
              this.product.equals(other.getProduct()))) &&
            ((this.product_group==null && other.getProduct_group()==null) || 
             (this.product_group!=null &&
              this.product_group.equals(other.getProduct_group()))) &&
            this.status_code == other.getStatus_code() &&
            ((this.status_desc==null && other.getStatus_desc()==null) || 
             (this.status_desc!=null &&
              this.status_desc.equals(other.getStatus_desc()))) &&
            ((this.total_no_of_recs==null && other.getTotal_no_of_recs()==null) || 
             (this.total_no_of_recs!=null &&
              this.total_no_of_recs.equals(other.getTotal_no_of_recs()))) &&
            this.tot_amount_due == other.getTot_amount_due() &&
            ((this.trans_reference_s==null && other.getTrans_reference_s()==null) || 
             (this.trans_reference_s!=null &&
              this.trans_reference_s.equals(other.getTrans_reference_s()))) &&
            ((this.sn_code==null && other.getSn_code()==null) || 
             (this.sn_code!=null &&
              this.sn_code.equals(other.getSn_code()))) &&
            ((this.sn_description==null && other.getSn_description()==null) || 
             (this.sn_description!=null &&
              this.sn_description.equals(other.getSn_description())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAccount_no() != null) {
            _hashCode += getAccount_no().hashCode();
        }
        if (getAction_flag() != null) {
            _hashCode += getAction_flag().hashCode();
        }
        _hashCode += new Double(getCurrent_month_charges()).hashCode();
        _hashCode += new Long(getCycle_no()).hashCode();
        if (getError_no() != null) {
            _hashCode += getError_no().hashCode();
        }
        _hashCode += new Double(getLast_payment_amount()).hashCode();
        if (getLast_payment_date() != null) {
            _hashCode += getLast_payment_date().hashCode();
        }
        _hashCode += new Double(getPayments()).hashCode();
        _hashCode += new Double(getPrev_month_balance()).hashCode();
        if (getProduct() != null) {
            _hashCode += getProduct().hashCode();
        }
        if (getProduct_group() != null) {
            _hashCode += getProduct_group().hashCode();
        }
        _hashCode += new Long(getStatus_code()).hashCode();
        if (getStatus_desc() != null) {
            _hashCode += getStatus_desc().hashCode();
        }
        if (getTotal_no_of_recs() != null) {
            _hashCode += getTotal_no_of_recs().hashCode();
        }
        _hashCode += new Double(getTot_amount_due()).hashCode();
        if (getTrans_reference_s() != null) {
            _hashCode += getTrans_reference_s().hashCode();
        }
        if (getSn_code() != null) {
            _hashCode += getSn_code().hashCode();
        }
        if (getSn_description() != null) {
            _hashCode += getSn_description().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OtherServicesBillingResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "OtherServicesBillingResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("account_no");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "account_no"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("action_flag");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "action_flag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("current_month_charges");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "current_month_charges"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cycle_no");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "cycle_no"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("error_no");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "error_no"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("last_payment_amount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "last_payment_amount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("last_payment_date");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "last_payment_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "payments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prev_month_balance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "prev_month_balance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "product"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_group");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "product_group"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status_code");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "status_code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status_desc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "status_desc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("total_no_of_recs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "total_no_of_recs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tot_amount_due");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "tot_amount_due"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trans_reference_s");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "trans_reference_s"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sn_code");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "sn_code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sn_description");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "sn_description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
