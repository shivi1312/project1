/**
 * Subscription.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd;

public class Subscription  implements java.io.Serializable {
    private java.lang.String externalSubscriptionId;

    private java.lang.String esdpOfferId;

    private java.lang.String externalOfferId;

    private java.lang.String startDate;

    private java.lang.String expiryDate;

    private java.lang.String nextRenewalDate;

    private java.lang.String cancellationChannel;

    private java.lang.Integer subscriptionStatus;

    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.SubscriptionAttributes subscriptionAttributes;

    private java.lang.String currentCampaignId;

    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.SubscriptionIntervals subscriptionIntervals;

    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Services services;

    public Subscription() {
    }

    public Subscription(
           java.lang.String externalSubscriptionId,
           java.lang.String esdpOfferId,
           java.lang.String externalOfferId,
           java.lang.String startDate,
           java.lang.String expiryDate,
           java.lang.String nextRenewalDate,
           java.lang.String cancellationChannel,
           java.lang.Integer subscriptionStatus,
           ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.SubscriptionAttributes subscriptionAttributes,
           java.lang.String currentCampaignId,
           ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.SubscriptionIntervals subscriptionIntervals,
           ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Services services) {
           this.externalSubscriptionId = externalSubscriptionId;
           this.esdpOfferId = esdpOfferId;
           this.externalOfferId = externalOfferId;
           this.startDate = startDate;
           this.expiryDate = expiryDate;
           this.nextRenewalDate = nextRenewalDate;
           this.cancellationChannel = cancellationChannel;
           this.subscriptionStatus = subscriptionStatus;
           this.subscriptionAttributes = subscriptionAttributes;
           this.currentCampaignId = currentCampaignId;
           this.subscriptionIntervals = subscriptionIntervals;
           this.services = services;
    }


    /**
     * Gets the externalSubscriptionId value for this Subscription.
     * 
     * @return externalSubscriptionId
     */
    public java.lang.String getExternalSubscriptionId() {
        return externalSubscriptionId;
    }


    /**
     * Sets the externalSubscriptionId value for this Subscription.
     * 
     * @param externalSubscriptionId
     */
    public void setExternalSubscriptionId(java.lang.String externalSubscriptionId) {
        this.externalSubscriptionId = externalSubscriptionId;
    }


    /**
     * Gets the esdpOfferId value for this Subscription.
     * 
     * @return esdpOfferId
     */
    public java.lang.String getEsdpOfferId() {
        return esdpOfferId;
    }


    /**
     * Sets the esdpOfferId value for this Subscription.
     * 
     * @param esdpOfferId
     */
    public void setEsdpOfferId(java.lang.String esdpOfferId) {
        this.esdpOfferId = esdpOfferId;
    }


    /**
     * Gets the externalOfferId value for this Subscription.
     * 
     * @return externalOfferId
     */
    public java.lang.String getExternalOfferId() {
        return externalOfferId;
    }


    /**
     * Sets the externalOfferId value for this Subscription.
     * 
     * @param externalOfferId
     */
    public void setExternalOfferId(java.lang.String externalOfferId) {
        this.externalOfferId = externalOfferId;
    }


    /**
     * Gets the startDate value for this Subscription.
     * 
     * @return startDate
     */
    public java.lang.String getStartDate() {
        return startDate;
    }


    /**
     * Sets the startDate value for this Subscription.
     * 
     * @param startDate
     */
    public void setStartDate(java.lang.String startDate) {
        this.startDate = startDate;
    }


    /**
     * Gets the expiryDate value for this Subscription.
     * 
     * @return expiryDate
     */
    public java.lang.String getExpiryDate() {
        return expiryDate;
    }


    /**
     * Sets the expiryDate value for this Subscription.
     * 
     * @param expiryDate
     */
    public void setExpiryDate(java.lang.String expiryDate) {
        this.expiryDate = expiryDate;
    }


    /**
     * Gets the nextRenewalDate value for this Subscription.
     * 
     * @return nextRenewalDate
     */
    public java.lang.String getNextRenewalDate() {
        return nextRenewalDate;
    }


    /**
     * Sets the nextRenewalDate value for this Subscription.
     * 
     * @param nextRenewalDate
     */
    public void setNextRenewalDate(java.lang.String nextRenewalDate) {
        this.nextRenewalDate = nextRenewalDate;
    }


    /**
     * Gets the cancellationChannel value for this Subscription.
     * 
     * @return cancellationChannel
     */
    public java.lang.String getCancellationChannel() {
        return cancellationChannel;
    }


    /**
     * Sets the cancellationChannel value for this Subscription.
     * 
     * @param cancellationChannel
     */
    public void setCancellationChannel(java.lang.String cancellationChannel) {
        this.cancellationChannel = cancellationChannel;
    }


    /**
     * Gets the subscriptionStatus value for this Subscription.
     * 
     * @return subscriptionStatus
     */
    public java.lang.Integer getSubscriptionStatus() {
        return subscriptionStatus;
    }


    /**
     * Sets the subscriptionStatus value for this Subscription.
     * 
     * @param subscriptionStatus
     */
    public void setSubscriptionStatus(java.lang.Integer subscriptionStatus) {
        this.subscriptionStatus = subscriptionStatus;
    }


    /**
     * Gets the subscriptionAttributes value for this Subscription.
     * 
     * @return subscriptionAttributes
     */
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.SubscriptionAttributes getSubscriptionAttributes() {
        return subscriptionAttributes;
    }


    /**
     * Sets the subscriptionAttributes value for this Subscription.
     * 
     * @param subscriptionAttributes
     */
    public void setSubscriptionAttributes(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.SubscriptionAttributes subscriptionAttributes) {
        this.subscriptionAttributes = subscriptionAttributes;
    }


    /**
     * Gets the currentCampaignId value for this Subscription.
     * 
     * @return currentCampaignId
     */
    public java.lang.String getCurrentCampaignId() {
        return currentCampaignId;
    }


    /**
     * Sets the currentCampaignId value for this Subscription.
     * 
     * @param currentCampaignId
     */
    public void setCurrentCampaignId(java.lang.String currentCampaignId) {
        this.currentCampaignId = currentCampaignId;
    }


    /**
     * Gets the subscriptionIntervals value for this Subscription.
     * 
     * @return subscriptionIntervals
     */
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.SubscriptionIntervals getSubscriptionIntervals() {
        return subscriptionIntervals;
    }


    /**
     * Sets the subscriptionIntervals value for this Subscription.
     * 
     * @param subscriptionIntervals
     */
    public void setSubscriptionIntervals(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.SubscriptionIntervals subscriptionIntervals) {
        this.subscriptionIntervals = subscriptionIntervals;
    }


    /**
     * Gets the services value for this Subscription.
     * 
     * @return services
     */
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Services getServices() {
        return services;
    }


    /**
     * Sets the services value for this Subscription.
     * 
     * @param services
     */
    public void setServices(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Services services) {
        this.services = services;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Subscription)) return false;
        Subscription other = (Subscription) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.externalSubscriptionId==null && other.getExternalSubscriptionId()==null) || 
             (this.externalSubscriptionId!=null &&
              this.externalSubscriptionId.equals(other.getExternalSubscriptionId()))) &&
            ((this.esdpOfferId==null && other.getEsdpOfferId()==null) || 
             (this.esdpOfferId!=null &&
              this.esdpOfferId.equals(other.getEsdpOfferId()))) &&
            ((this.externalOfferId==null && other.getExternalOfferId()==null) || 
             (this.externalOfferId!=null &&
              this.externalOfferId.equals(other.getExternalOfferId()))) &&
            ((this.startDate==null && other.getStartDate()==null) || 
             (this.startDate!=null &&
              this.startDate.equals(other.getStartDate()))) &&
            ((this.expiryDate==null && other.getExpiryDate()==null) || 
             (this.expiryDate!=null &&
              this.expiryDate.equals(other.getExpiryDate()))) &&
            ((this.nextRenewalDate==null && other.getNextRenewalDate()==null) || 
             (this.nextRenewalDate!=null &&
              this.nextRenewalDate.equals(other.getNextRenewalDate()))) &&
            ((this.cancellationChannel==null && other.getCancellationChannel()==null) || 
             (this.cancellationChannel!=null &&
              this.cancellationChannel.equals(other.getCancellationChannel()))) &&
            ((this.subscriptionStatus==null && other.getSubscriptionStatus()==null) || 
             (this.subscriptionStatus!=null &&
              this.subscriptionStatus.equals(other.getSubscriptionStatus()))) &&
            ((this.subscriptionAttributes==null && other.getSubscriptionAttributes()==null) || 
             (this.subscriptionAttributes!=null &&
              this.subscriptionAttributes.equals(other.getSubscriptionAttributes()))) &&
            ((this.currentCampaignId==null && other.getCurrentCampaignId()==null) || 
             (this.currentCampaignId!=null &&
              this.currentCampaignId.equals(other.getCurrentCampaignId()))) &&
            ((this.subscriptionIntervals==null && other.getSubscriptionIntervals()==null) || 
             (this.subscriptionIntervals!=null &&
              this.subscriptionIntervals.equals(other.getSubscriptionIntervals()))) &&
            ((this.services==null && other.getServices()==null) || 
             (this.services!=null &&
              this.services.equals(other.getServices())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getExternalSubscriptionId() != null) {
            _hashCode += getExternalSubscriptionId().hashCode();
        }
        if (getEsdpOfferId() != null) {
            _hashCode += getEsdpOfferId().hashCode();
        }
        if (getExternalOfferId() != null) {
            _hashCode += getExternalOfferId().hashCode();
        }
        if (getStartDate() != null) {
            _hashCode += getStartDate().hashCode();
        }
        if (getExpiryDate() != null) {
            _hashCode += getExpiryDate().hashCode();
        }
        if (getNextRenewalDate() != null) {
            _hashCode += getNextRenewalDate().hashCode();
        }
        if (getCancellationChannel() != null) {
            _hashCode += getCancellationChannel().hashCode();
        }
        if (getSubscriptionStatus() != null) {
            _hashCode += getSubscriptionStatus().hashCode();
        }
        if (getSubscriptionAttributes() != null) {
            _hashCode += getSubscriptionAttributes().hashCode();
        }
        if (getCurrentCampaignId() != null) {
            _hashCode += getCurrentCampaignId().hashCode();
        }
        if (getSubscriptionIntervals() != null) {
            _hashCode += getSubscriptionIntervals().hashCode();
        }
        if (getServices() != null) {
            _hashCode += getServices().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Subscription.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">subscription"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("externalSubscriptionId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "externalSubscriptionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("esdpOfferId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "esdpOfferId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("externalOfferId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "externalOfferId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "startDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expiryDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "expiryDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nextRenewalDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "nextRenewalDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cancellationChannel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "cancellationChannel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subscriptionStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "subscriptionStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subscriptionAttributes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "subscriptionAttributes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">subscriptionAttributes"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currentCampaignId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "currentCampaignId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subscriptionIntervals");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "subscriptionIntervals"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">subscriptionIntervals"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("services");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "services"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">services"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
