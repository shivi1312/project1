/**
 * SelfCareServicePortTypeBindingSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl;

public class SelfCareServicePortTypeBindingSkeleton implements ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServicePortType, org.apache.axis.wsdl.Skeleton {
    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServicePortType impl;
    private static java.util.Map _myOperations = new java.util.Hashtable();
    private static java.util.Collection _myOperationsList = new java.util.ArrayList();

    /**
    * Returns List of OperationDesc objects with this name
    */
    public static java.util.List getOperationDescByName(java.lang.String methodName) {
        return (java.util.List)_myOperations.get(methodName);
    }

    /**
    * Returns Collection of OperationDescs
    */
    public static java.util.Collection getOperationDescs() {
        return _myOperationsList;
    }

    static {
        org.apache.axis.description.OperationDesc _oper;
        org.apache.axis.description.FaultDesc _fault;
        org.apache.axis.description.ParameterDesc [] _params;
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opInquiryNotification", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpInquiryNotification"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent//OpInquiryNotification");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opInquiryNotification") == null) {
            _myOperations.put("opInquiryNotification", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opInquiryNotification")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opQueryGFFNumbersList", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpQueryGFFNumbersList"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpQueryGFFNumbersList");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opQueryGFFNumbersList") == null) {
            _myOperations.put("opQueryGFFNumbersList", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opQueryGFFNumbersList")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opVerifyServiceOrderStatus", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpVerifyServiceOrderStatus"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpVerifyServiceOrderStatus");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opVerifyServiceOrderStatus") == null) {
            _myOperations.put("opVerifyServiceOrderStatus", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opVerifyServiceOrderStatus")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opModifyService", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpModifyService"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpModifyService");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opModifyService") == null) {
            _myOperations.put("opModifyService", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opModifyService")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", "UpdateOrderStatusRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">UpdateOrderStatusRequest"), com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opUpdateOrderStatus", _params, new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusResponse.xsd", "UpdateOrderStatusResponse"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusResponse.xsd", ">UpdateOrderStatusResponse"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpUpdateOrderStatus"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service-HTTPS.serviceagent//OpUpdateOrderStatus");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opUpdateOrderStatus") == null) {
            _myOperations.put("opUpdateOrderStatus", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opUpdateOrderStatus")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://www.etisalat.ae/Middleware/SharedResources/Common/AckMessage.xsd", "AckMessage"));
        _fault.setClassName("ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage");
        _fault.setXmlType(new javax.xml.namespace.QName("http://www.etisalat.ae/Middleware/SharedResources/Common/AckMessage.xsd", ">AckMessage"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opCheckEnoughBalance", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpCheckEnoughBalance"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpCheckEnoughBalance");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opCheckEnoughBalance") == null) {
            _myOperations.put("opCheckEnoughBalance", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opCheckEnoughBalance")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opOtherServicesBilling", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpOtherServicesBilling"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpOtherServicesBilling");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opOtherServicesBilling") == null) {
            _myOperations.put("opOtherServicesBilling", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opOtherServicesBilling")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opCancelService", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpCancelService"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpCancelService");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opCancelService") == null) {
            _myOperations.put("opCancelService", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opCancelService")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opQueryCustomerServiceDetails", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpQueryCustomerServiceDetails"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpQueryCustomerServiceDetails");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opQueryCustomerServiceDetails") == null) {
            _myOperations.put("opQueryCustomerServiceDetails", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opQueryCustomerServiceDetails")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opViewPlan", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpViewPlan"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent//OpViewPlan");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opViewPlan") == null) {
            _myOperations.put("opViewPlan", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opViewPlan")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opMigrationStatusCheck", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpMigrationStatusCheck"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent//OpMigrationStatusCheck");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opMigrationStatusCheck") == null) {
            _myOperations.put("opMigrationStatusCheck", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opMigrationStatusCheck")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opDetectFraudService", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpDetectFraudService"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpDetectFraudService");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opDetectFraudService") == null) {
            _myOperations.put("opDetectFraudService", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opDetectFraudService")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opGetBlockedStatus", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpGetBlockedStatus"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent//OpGetBlockedStatus");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opGetBlockedStatus") == null) {
            _myOperations.put("opGetBlockedStatus", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opGetBlockedStatus")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opBlackberryInquiry", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpBlackberryInquiry"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpBlackberryInquiry");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opBlackberryInquiry") == null) {
            _myOperations.put("opBlackberryInquiry", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opBlackberryInquiry")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opEmcaisService", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpEmcaisService"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpEmcaisService");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opEmcaisService") == null) {
            _myOperations.put("opEmcaisService", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opEmcaisService")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opVerifyComplaintStatus", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpVerifyComplaintStatus"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent//OpVerifyComplaintStatus");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opVerifyComplaintStatus") == null) {
            _myOperations.put("opVerifyComplaintStatus", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opVerifyComplaintStatus")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opQuerySubscription", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpQuerySubscription"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpQuerySubscription");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opQuerySubscription") == null) {
            _myOperations.put("opQuerySubscription", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opQuerySubscription")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opCheckSubscription", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpCheckSubscription"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpCheckSubscription");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opCheckSubscription") == null) {
            _myOperations.put("opCheckSubscription", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opCheckSubscription")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opGetFaultDockCrtCC", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpGetFaultDockCrtCC"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent//OpGetFaultDockCrtCC");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opGetFaultDockCrtCC") == null) {
            _myOperations.put("opGetFaultDockCrtCC", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opGetFaultDockCrtCC")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opQuerySubscribedServicesList", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpQuerySubscribedServicesList"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpQuerySubscribedServicesList");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opQuerySubscribedServicesList") == null) {
            _myOperations.put("opQuerySubscribedServicesList", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opQuerySubscribedServicesList")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opGetEvisionBilling", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpGetEvisionBilling"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpGetEvisionBilling");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opGetEvisionBilling") == null) {
            _myOperations.put("opGetEvisionBilling", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opGetEvisionBilling")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "CheckEligibilityRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">CheckEligibilityRequest"), com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opCheckEligibility", _params, new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", "CheckEligibilityResponse"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">CheckEligibilityResponse"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpCheckEligibility"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service-HTTPS.serviceagent//OpCheckEligibility");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opCheckEligibility") == null) {
            _myOperations.put("opCheckEligibility", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opCheckEligibility")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://www.etisalat.ae/Middleware/SharedResources/Common/AckMessage.xsd", "AckMessage"));
        _fault.setClassName("ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage");
        _fault.setXmlType(new javax.xml.namespace.QName("http://www.etisalat.ae/Middleware/SharedResources/Common/AckMessage.xsd", ">AckMessage"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("opProvisionRequestedService", _params, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "MessageEnvelope"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "MessageEnvelope"));
        _oper.setElementQName(new javax.xml.namespace.QName("", "OpProvisionRequestedService"));
        _oper.setSoapAction("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpProvisionRequestedService");
        _myOperationsList.add(_oper);
        if (_myOperations.get("opProvisionRequestedService") == null) {
            _myOperations.put("opProvisionRequestedService", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("opProvisionRequestedService")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("fault1");
        _fault.setQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"));
        _fault.setClassName("ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg");
        _fault.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"));
        _oper.addFault(_fault);
    }

    public SelfCareServicePortTypeBindingSkeleton() {
        this.impl = new ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServicePortTypeBindingImpl();
    }

    public SelfCareServicePortTypeBindingSkeleton(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServicePortType impl) {
        this.impl = impl;
    }
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope opInquiryNotification(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope inquiryNotificationRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope ret = impl.opInquiryNotification(inquiryNotificationRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope opQueryGFFNumbersList(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope queryGFFNumbersListRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope ret = impl.opQueryGFFNumbersList(queryGFFNumbersListRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope opVerifyServiceOrderStatus(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope verifyServiceOrderStatusRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope ret = impl.opVerifyServiceOrderStatus(verifyServiceOrderStatusRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope opModifyService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope modifyServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope ret = impl.opModifyService(modifyServiceRequest);
        return ret;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponse opUpdateOrderStatus(com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequest updateOrderStatusRequest) throws java.rmi.RemoteException, ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage
    {
        com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponse ret = impl.opUpdateOrderStatus(updateOrderStatusRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope opCheckEnoughBalance(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope checkEnoughBalanceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope ret = impl.opCheckEnoughBalance(checkEnoughBalanceRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope opOtherServicesBilling(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope otherServicesBillingRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope ret = impl.opOtherServicesBilling(otherServicesBillingRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope opCancelService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope cancelServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope ret = impl.opCancelService(cancelServiceRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope opQueryCustomerServiceDetails(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope queryCustomerServiceDetailsRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope ret = impl.opQueryCustomerServiceDetails(queryCustomerServiceDetailsRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope opViewPlan(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope viewPlanRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope ret = impl.opViewPlan(viewPlanRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope opMigrationStatusCheck(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope migrationStatusCheckRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope ret = impl.opMigrationStatusCheck(migrationStatusCheckRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope opDetectFraudService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope detectFraudServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope ret = impl.opDetectFraudService(detectFraudServiceRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope opGetBlockedStatus(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope getBlockedStatusRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope ret = impl.opGetBlockedStatus(getBlockedStatusRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope opBlackberryInquiry(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope blackberryInquiryRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope ret = impl.opBlackberryInquiry(blackberryInquiryRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope opEmcaisService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope emcaisServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope ret = impl.opEmcaisService(emcaisServiceRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope opVerifyComplaintStatus(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope verifyComplaintStatusRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope ret = impl.opVerifyComplaintStatus(verifyComplaintStatusRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope opQuerySubscription(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope querySubscriptionRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope ret = impl.opQuerySubscription(querySubscriptionRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope opCheckSubscription(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope checkSubscriptionRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope ret = impl.opCheckSubscription(checkSubscriptionRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope opGetFaultDockCrtCC(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope getFaultDockCrtCCRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope ret = impl.opGetFaultDockCrtCC(getFaultDockCrtCCRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope opQuerySubscribedServicesList(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope querySubscribedServicesListRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope ret = impl.opQuerySubscribedServicesList(querySubscribedServicesListRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope opGetEvisionBilling(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope getEvisionBillingRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope ret = impl.opGetEvisionBilling(getEvisionBillingRequest);
        return ret;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponse opCheckEligibility(com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequest checkEligibilityRequest) throws java.rmi.RemoteException, ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage
    {
        com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponse ret = impl.opCheckEligibility(checkEligibilityRequest);
        return ret;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope opProvisionRequestedService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope provisionRequestedServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg
    {
        ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope ret = impl.opProvisionRequestedService(provisionRequestedServiceRequest);
        return ret;
    }

}
