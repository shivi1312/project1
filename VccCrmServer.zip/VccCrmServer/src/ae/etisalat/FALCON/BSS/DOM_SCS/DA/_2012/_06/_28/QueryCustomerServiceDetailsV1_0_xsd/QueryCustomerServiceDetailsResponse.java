/**
 * QueryCustomerServiceDetailsResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd;

public class QueryCustomerServiceDetailsResponse  implements java.io.Serializable {
    private java.lang.String transactionId;

    private java.lang.String msisdn;

    private java.lang.String responseCode;

    private java.lang.String responseDetails;

    private java.lang.String service_status;

    private java.lang.String service_type;

    private java.lang.String customer_type;

    private java.lang.String service_detail;

    private java.lang.String customerHasEnoughBalance;

    private java.lang.Double priceOfTheProduct;

    private java.lang.String mainAccountBalance;

    private java.lang.String account_status;

    public QueryCustomerServiceDetailsResponse() {
    }

    public QueryCustomerServiceDetailsResponse(
           java.lang.String transactionId,
           java.lang.String msisdn,
           java.lang.String responseCode,
           java.lang.String responseDetails,
           java.lang.String service_status,
           java.lang.String service_type,
           java.lang.String customer_type,
           java.lang.String service_detail,
           java.lang.String customerHasEnoughBalance,
           java.lang.Double priceOfTheProduct,
           java.lang.String mainAccountBalance,
           java.lang.String account_status) {
           this.transactionId = transactionId;
           this.msisdn = msisdn;
           this.responseCode = responseCode;
           this.responseDetails = responseDetails;
           this.service_status = service_status;
           this.service_type = service_type;
           this.customer_type = customer_type;
           this.service_detail = service_detail;
           this.customerHasEnoughBalance = customerHasEnoughBalance;
           this.priceOfTheProduct = priceOfTheProduct;
           this.mainAccountBalance = mainAccountBalance;
           this.account_status = account_status;
    }


    /**
     * Gets the transactionId value for this QueryCustomerServiceDetailsResponse.
     * 
     * @return transactionId
     */
    public java.lang.String getTransactionId() {
        return transactionId;
    }


    /**
     * Sets the transactionId value for this QueryCustomerServiceDetailsResponse.
     * 
     * @param transactionId
     */
    public void setTransactionId(java.lang.String transactionId) {
        this.transactionId = transactionId;
    }


    /**
     * Gets the msisdn value for this QueryCustomerServiceDetailsResponse.
     * 
     * @return msisdn
     */
    public java.lang.String getMsisdn() {
        return msisdn;
    }


    /**
     * Sets the msisdn value for this QueryCustomerServiceDetailsResponse.
     * 
     * @param msisdn
     */
    public void setMsisdn(java.lang.String msisdn) {
        this.msisdn = msisdn;
    }


    /**
     * Gets the responseCode value for this QueryCustomerServiceDetailsResponse.
     * 
     * @return responseCode
     */
    public java.lang.String getResponseCode() {
        return responseCode;
    }


    /**
     * Sets the responseCode value for this QueryCustomerServiceDetailsResponse.
     * 
     * @param responseCode
     */
    public void setResponseCode(java.lang.String responseCode) {
        this.responseCode = responseCode;
    }


    /**
     * Gets the responseDetails value for this QueryCustomerServiceDetailsResponse.
     * 
     * @return responseDetails
     */
    public java.lang.String getResponseDetails() {
        return responseDetails;
    }


    /**
     * Sets the responseDetails value for this QueryCustomerServiceDetailsResponse.
     * 
     * @param responseDetails
     */
    public void setResponseDetails(java.lang.String responseDetails) {
        this.responseDetails = responseDetails;
    }


    /**
     * Gets the service_status value for this QueryCustomerServiceDetailsResponse.
     * 
     * @return service_status
     */
    public java.lang.String getService_status() {
        return service_status;
    }


    /**
     * Sets the service_status value for this QueryCustomerServiceDetailsResponse.
     * 
     * @param service_status
     */
    public void setService_status(java.lang.String service_status) {
        this.service_status = service_status;
    }


    /**
     * Gets the service_type value for this QueryCustomerServiceDetailsResponse.
     * 
     * @return service_type
     */
    public java.lang.String getService_type() {
        return service_type;
    }


    /**
     * Sets the service_type value for this QueryCustomerServiceDetailsResponse.
     * 
     * @param service_type
     */
    public void setService_type(java.lang.String service_type) {
        this.service_type = service_type;
    }


    /**
     * Gets the customer_type value for this QueryCustomerServiceDetailsResponse.
     * 
     * @return customer_type
     */
    public java.lang.String getCustomer_type() {
        return customer_type;
    }


    /**
     * Sets the customer_type value for this QueryCustomerServiceDetailsResponse.
     * 
     * @param customer_type
     */
    public void setCustomer_type(java.lang.String customer_type) {
        this.customer_type = customer_type;
    }


    /**
     * Gets the service_detail value for this QueryCustomerServiceDetailsResponse.
     * 
     * @return service_detail
     */
    public java.lang.String getService_detail() {
        return service_detail;
    }


    /**
     * Sets the service_detail value for this QueryCustomerServiceDetailsResponse.
     * 
     * @param service_detail
     */
    public void setService_detail(java.lang.String service_detail) {
        this.service_detail = service_detail;
    }


    /**
     * Gets the customerHasEnoughBalance value for this QueryCustomerServiceDetailsResponse.
     * 
     * @return customerHasEnoughBalance
     */
    public java.lang.String getCustomerHasEnoughBalance() {
        return customerHasEnoughBalance;
    }


    /**
     * Sets the customerHasEnoughBalance value for this QueryCustomerServiceDetailsResponse.
     * 
     * @param customerHasEnoughBalance
     */
    public void setCustomerHasEnoughBalance(java.lang.String customerHasEnoughBalance) {
        this.customerHasEnoughBalance = customerHasEnoughBalance;
    }


    /**
     * Gets the priceOfTheProduct value for this QueryCustomerServiceDetailsResponse.
     * 
     * @return priceOfTheProduct
     */
    public java.lang.Double getPriceOfTheProduct() {
        return priceOfTheProduct;
    }


    /**
     * Sets the priceOfTheProduct value for this QueryCustomerServiceDetailsResponse.
     * 
     * @param priceOfTheProduct
     */
    public void setPriceOfTheProduct(java.lang.Double priceOfTheProduct) {
        this.priceOfTheProduct = priceOfTheProduct;
    }


    /**
     * Gets the mainAccountBalance value for this QueryCustomerServiceDetailsResponse.
     * 
     * @return mainAccountBalance
     */
    public java.lang.String getMainAccountBalance() {
        return mainAccountBalance;
    }


    /**
     * Sets the mainAccountBalance value for this QueryCustomerServiceDetailsResponse.
     * 
     * @param mainAccountBalance
     */
    public void setMainAccountBalance(java.lang.String mainAccountBalance) {
        this.mainAccountBalance = mainAccountBalance;
    }


    /**
     * Gets the account_status value for this QueryCustomerServiceDetailsResponse.
     * 
     * @return account_status
     */
    public java.lang.String getAccount_status() {
        return account_status;
    }


    /**
     * Sets the account_status value for this QueryCustomerServiceDetailsResponse.
     * 
     * @param account_status
     */
    public void setAccount_status(java.lang.String account_status) {
        this.account_status = account_status;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QueryCustomerServiceDetailsResponse)) return false;
        QueryCustomerServiceDetailsResponse other = (QueryCustomerServiceDetailsResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transactionId==null && other.getTransactionId()==null) || 
             (this.transactionId!=null &&
              this.transactionId.equals(other.getTransactionId()))) &&
            ((this.msisdn==null && other.getMsisdn()==null) || 
             (this.msisdn!=null &&
              this.msisdn.equals(other.getMsisdn()))) &&
            ((this.responseCode==null && other.getResponseCode()==null) || 
             (this.responseCode!=null &&
              this.responseCode.equals(other.getResponseCode()))) &&
            ((this.responseDetails==null && other.getResponseDetails()==null) || 
             (this.responseDetails!=null &&
              this.responseDetails.equals(other.getResponseDetails()))) &&
            ((this.service_status==null && other.getService_status()==null) || 
             (this.service_status!=null &&
              this.service_status.equals(other.getService_status()))) &&
            ((this.service_type==null && other.getService_type()==null) || 
             (this.service_type!=null &&
              this.service_type.equals(other.getService_type()))) &&
            ((this.customer_type==null && other.getCustomer_type()==null) || 
             (this.customer_type!=null &&
              this.customer_type.equals(other.getCustomer_type()))) &&
            ((this.service_detail==null && other.getService_detail()==null) || 
             (this.service_detail!=null &&
              this.service_detail.equals(other.getService_detail()))) &&
            ((this.customerHasEnoughBalance==null && other.getCustomerHasEnoughBalance()==null) || 
             (this.customerHasEnoughBalance!=null &&
              this.customerHasEnoughBalance.equals(other.getCustomerHasEnoughBalance()))) &&
            ((this.priceOfTheProduct==null && other.getPriceOfTheProduct()==null) || 
             (this.priceOfTheProduct!=null &&
              this.priceOfTheProduct.equals(other.getPriceOfTheProduct()))) &&
            ((this.mainAccountBalance==null && other.getMainAccountBalance()==null) || 
             (this.mainAccountBalance!=null &&
              this.mainAccountBalance.equals(other.getMainAccountBalance()))) &&
            ((this.account_status==null && other.getAccount_status()==null) || 
             (this.account_status!=null &&
              this.account_status.equals(other.getAccount_status())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransactionId() != null) {
            _hashCode += getTransactionId().hashCode();
        }
        if (getMsisdn() != null) {
            _hashCode += getMsisdn().hashCode();
        }
        if (getResponseCode() != null) {
            _hashCode += getResponseCode().hashCode();
        }
        if (getResponseDetails() != null) {
            _hashCode += getResponseDetails().hashCode();
        }
        if (getService_status() != null) {
            _hashCode += getService_status().hashCode();
        }
        if (getService_type() != null) {
            _hashCode += getService_type().hashCode();
        }
        if (getCustomer_type() != null) {
            _hashCode += getCustomer_type().hashCode();
        }
        if (getService_detail() != null) {
            _hashCode += getService_detail().hashCode();
        }
        if (getCustomerHasEnoughBalance() != null) {
            _hashCode += getCustomerHasEnoughBalance().hashCode();
        }
        if (getPriceOfTheProduct() != null) {
            _hashCode += getPriceOfTheProduct().hashCode();
        }
        if (getMainAccountBalance() != null) {
            _hashCode += getMainAccountBalance().hashCode();
        }
        if (getAccount_status() != null) {
            _hashCode += getAccount_status().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QueryCustomerServiceDetailsResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "QueryCustomerServiceDetailsResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "transactionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msisdn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "msisdn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("responseCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "responseCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("responseDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "responseDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("service_status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "service_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("service_type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "service_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customer_type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "customer_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("service_detail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "service_detail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerHasEnoughBalance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "customerHasEnoughBalance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("priceOfTheProduct");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "priceOfTheProduct"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mainAccountBalance");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "mainAccountBalance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("account_status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "account_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
