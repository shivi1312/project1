/**
 * GetFaultDockCrtCCORequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd;

public class GetFaultDockCrtCCORequest  implements java.io.Serializable {
    private java.lang.String regioncode;

    private java.lang.String username;

    private java.lang.String accesslevel;

    private java.lang.String password;

    private java.lang.String complaintid;

    private java.lang.String accountno;

    private java.lang.String complaintcode;

    private java.lang.String reportingnumber;

    private java.lang.String contactno;

    private java.lang.String requestdate;

    public GetFaultDockCrtCCORequest() {
    }

    public GetFaultDockCrtCCORequest(
           java.lang.String regioncode,
           java.lang.String username,
           java.lang.String accesslevel,
           java.lang.String password,
           java.lang.String complaintid,
           java.lang.String accountno,
           java.lang.String complaintcode,
           java.lang.String reportingnumber,
           java.lang.String contactno,
           java.lang.String requestdate) {
           this.regioncode = regioncode;
           this.username = username;
           this.accesslevel = accesslevel;
           this.password = password;
           this.complaintid = complaintid;
           this.accountno = accountno;
           this.complaintcode = complaintcode;
           this.reportingnumber = reportingnumber;
           this.contactno = contactno;
           this.requestdate = requestdate;
    }


    /**
     * Gets the regioncode value for this GetFaultDockCrtCCORequest.
     * 
     * @return regioncode
     */
    public java.lang.String getRegioncode() {
        return regioncode;
    }


    /**
     * Sets the regioncode value for this GetFaultDockCrtCCORequest.
     * 
     * @param regioncode
     */
    public void setRegioncode(java.lang.String regioncode) {
        this.regioncode = regioncode;
    }


    /**
     * Gets the username value for this GetFaultDockCrtCCORequest.
     * 
     * @return username
     */
    public java.lang.String getUsername() {
        return username;
    }


    /**
     * Sets the username value for this GetFaultDockCrtCCORequest.
     * 
     * @param username
     */
    public void setUsername(java.lang.String username) {
        this.username = username;
    }


    /**
     * Gets the accesslevel value for this GetFaultDockCrtCCORequest.
     * 
     * @return accesslevel
     */
    public java.lang.String getAccesslevel() {
        return accesslevel;
    }


    /**
     * Sets the accesslevel value for this GetFaultDockCrtCCORequest.
     * 
     * @param accesslevel
     */
    public void setAccesslevel(java.lang.String accesslevel) {
        this.accesslevel = accesslevel;
    }


    /**
     * Gets the password value for this GetFaultDockCrtCCORequest.
     * 
     * @return password
     */
    public java.lang.String getPassword() {
        return password;
    }


    /**
     * Sets the password value for this GetFaultDockCrtCCORequest.
     * 
     * @param password
     */
    public void setPassword(java.lang.String password) {
        this.password = password;
    }


    /**
     * Gets the complaintid value for this GetFaultDockCrtCCORequest.
     * 
     * @return complaintid
     */
    public java.lang.String getComplaintid() {
        return complaintid;
    }


    /**
     * Sets the complaintid value for this GetFaultDockCrtCCORequest.
     * 
     * @param complaintid
     */
    public void setComplaintid(java.lang.String complaintid) {
        this.complaintid = complaintid;
    }


    /**
     * Gets the accountno value for this GetFaultDockCrtCCORequest.
     * 
     * @return accountno
     */
    public java.lang.String getAccountno() {
        return accountno;
    }


    /**
     * Sets the accountno value for this GetFaultDockCrtCCORequest.
     * 
     * @param accountno
     */
    public void setAccountno(java.lang.String accountno) {
        this.accountno = accountno;
    }


    /**
     * Gets the complaintcode value for this GetFaultDockCrtCCORequest.
     * 
     * @return complaintcode
     */
    public java.lang.String getComplaintcode() {
        return complaintcode;
    }


    /**
     * Sets the complaintcode value for this GetFaultDockCrtCCORequest.
     * 
     * @param complaintcode
     */
    public void setComplaintcode(java.lang.String complaintcode) {
        this.complaintcode = complaintcode;
    }


    /**
     * Gets the reportingnumber value for this GetFaultDockCrtCCORequest.
     * 
     * @return reportingnumber
     */
    public java.lang.String getReportingnumber() {
        return reportingnumber;
    }


    /**
     * Sets the reportingnumber value for this GetFaultDockCrtCCORequest.
     * 
     * @param reportingnumber
     */
    public void setReportingnumber(java.lang.String reportingnumber) {
        this.reportingnumber = reportingnumber;
    }


    /**
     * Gets the contactno value for this GetFaultDockCrtCCORequest.
     * 
     * @return contactno
     */
    public java.lang.String getContactno() {
        return contactno;
    }


    /**
     * Sets the contactno value for this GetFaultDockCrtCCORequest.
     * 
     * @param contactno
     */
    public void setContactno(java.lang.String contactno) {
        this.contactno = contactno;
    }


    /**
     * Gets the requestdate value for this GetFaultDockCrtCCORequest.
     * 
     * @return requestdate
     */
    public java.lang.String getRequestdate() {
        return requestdate;
    }


    /**
     * Sets the requestdate value for this GetFaultDockCrtCCORequest.
     * 
     * @param requestdate
     */
    public void setRequestdate(java.lang.String requestdate) {
        this.requestdate = requestdate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetFaultDockCrtCCORequest)) return false;
        GetFaultDockCrtCCORequest other = (GetFaultDockCrtCCORequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.regioncode==null && other.getRegioncode()==null) || 
             (this.regioncode!=null &&
              this.regioncode.equals(other.getRegioncode()))) &&
            ((this.username==null && other.getUsername()==null) || 
             (this.username!=null &&
              this.username.equals(other.getUsername()))) &&
            ((this.accesslevel==null && other.getAccesslevel()==null) || 
             (this.accesslevel!=null &&
              this.accesslevel.equals(other.getAccesslevel()))) &&
            ((this.password==null && other.getPassword()==null) || 
             (this.password!=null &&
              this.password.equals(other.getPassword()))) &&
            ((this.complaintid==null && other.getComplaintid()==null) || 
             (this.complaintid!=null &&
              this.complaintid.equals(other.getComplaintid()))) &&
            ((this.accountno==null && other.getAccountno()==null) || 
             (this.accountno!=null &&
              this.accountno.equals(other.getAccountno()))) &&
            ((this.complaintcode==null && other.getComplaintcode()==null) || 
             (this.complaintcode!=null &&
              this.complaintcode.equals(other.getComplaintcode()))) &&
            ((this.reportingnumber==null && other.getReportingnumber()==null) || 
             (this.reportingnumber!=null &&
              this.reportingnumber.equals(other.getReportingnumber()))) &&
            ((this.contactno==null && other.getContactno()==null) || 
             (this.contactno!=null &&
              this.contactno.equals(other.getContactno()))) &&
            ((this.requestdate==null && other.getRequestdate()==null) || 
             (this.requestdate!=null &&
              this.requestdate.equals(other.getRequestdate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getRegioncode() != null) {
            _hashCode += getRegioncode().hashCode();
        }
        if (getUsername() != null) {
            _hashCode += getUsername().hashCode();
        }
        if (getAccesslevel() != null) {
            _hashCode += getAccesslevel().hashCode();
        }
        if (getPassword() != null) {
            _hashCode += getPassword().hashCode();
        }
        if (getComplaintid() != null) {
            _hashCode += getComplaintid().hashCode();
        }
        if (getAccountno() != null) {
            _hashCode += getAccountno().hashCode();
        }
        if (getComplaintcode() != null) {
            _hashCode += getComplaintcode().hashCode();
        }
        if (getReportingnumber() != null) {
            _hashCode += getReportingnumber().hashCode();
        }
        if (getContactno() != null) {
            _hashCode += getContactno().hashCode();
        }
        if (getRequestdate() != null) {
            _hashCode += getRequestdate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetFaultDockCrtCCORequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "GetFaultDockCrtCCORequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("regioncode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Regioncode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("username");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Username"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accesslevel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Accesslevel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("password");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Password"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("complaintid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Complaintid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Accountno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("complaintcode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Complaintcode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportingnumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Reportingnumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contactno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Contactno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requestdate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Requestdate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
