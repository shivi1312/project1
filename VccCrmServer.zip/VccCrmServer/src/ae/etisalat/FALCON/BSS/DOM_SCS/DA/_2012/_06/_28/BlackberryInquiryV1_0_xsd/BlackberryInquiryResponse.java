/**
 * BlackberryInquiryResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd;

public class BlackberryInquiryResponse  implements java.io.Serializable {
    private java.lang.String transaction_id;

    private java.lang.String response_code;

    private java.lang.String response_description;

    private java.lang.String activation_date;

    private java.lang.String part_num;

    private java.lang.String status;

    private java.util.Date renewal_date;

    private java.lang.String rate_plan_code;

    public BlackberryInquiryResponse() {
    }

    public BlackberryInquiryResponse(
           java.lang.String transaction_id,
           java.lang.String response_code,
           java.lang.String response_description,
           java.lang.String activation_date,
           java.lang.String part_num,
           java.lang.String status,
           java.util.Date renewal_date,
           java.lang.String rate_plan_code) {
           this.transaction_id = transaction_id;
           this.response_code = response_code;
           this.response_description = response_description;
           this.activation_date = activation_date;
           this.part_num = part_num;
           this.status = status;
           this.renewal_date = renewal_date;
           this.rate_plan_code = rate_plan_code;
    }


    /**
     * Gets the transaction_id value for this BlackberryInquiryResponse.
     * 
     * @return transaction_id
     */
    public java.lang.String getTransaction_id() {
        return transaction_id;
    }


    /**
     * Sets the transaction_id value for this BlackberryInquiryResponse.
     * 
     * @param transaction_id
     */
    public void setTransaction_id(java.lang.String transaction_id) {
        this.transaction_id = transaction_id;
    }


    /**
     * Gets the response_code value for this BlackberryInquiryResponse.
     * 
     * @return response_code
     */
    public java.lang.String getResponse_code() {
        return response_code;
    }


    /**
     * Sets the response_code value for this BlackberryInquiryResponse.
     * 
     * @param response_code
     */
    public void setResponse_code(java.lang.String response_code) {
        this.response_code = response_code;
    }


    /**
     * Gets the response_description value for this BlackberryInquiryResponse.
     * 
     * @return response_description
     */
    public java.lang.String getResponse_description() {
        return response_description;
    }


    /**
     * Sets the response_description value for this BlackberryInquiryResponse.
     * 
     * @param response_description
     */
    public void setResponse_description(java.lang.String response_description) {
        this.response_description = response_description;
    }


    /**
     * Gets the activation_date value for this BlackberryInquiryResponse.
     * 
     * @return activation_date
     */
    public java.lang.String getActivation_date() {
        return activation_date;
    }


    /**
     * Sets the activation_date value for this BlackberryInquiryResponse.
     * 
     * @param activation_date
     */
    public void setActivation_date(java.lang.String activation_date) {
        this.activation_date = activation_date;
    }


    /**
     * Gets the part_num value for this BlackberryInquiryResponse.
     * 
     * @return part_num
     */
    public java.lang.String getPart_num() {
        return part_num;
    }


    /**
     * Sets the part_num value for this BlackberryInquiryResponse.
     * 
     * @param part_num
     */
    public void setPart_num(java.lang.String part_num) {
        this.part_num = part_num;
    }


    /**
     * Gets the status value for this BlackberryInquiryResponse.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this BlackberryInquiryResponse.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the renewal_date value for this BlackberryInquiryResponse.
     * 
     * @return renewal_date
     */
    public java.util.Date getRenewal_date() {
        return renewal_date;
    }


    /**
     * Sets the renewal_date value for this BlackberryInquiryResponse.
     * 
     * @param renewal_date
     */
    public void setRenewal_date(java.util.Date renewal_date) {
        this.renewal_date = renewal_date;
    }


    /**
     * Gets the rate_plan_code value for this BlackberryInquiryResponse.
     * 
     * @return rate_plan_code
     */
    public java.lang.String getRate_plan_code() {
        return rate_plan_code;
    }


    /**
     * Sets the rate_plan_code value for this BlackberryInquiryResponse.
     * 
     * @param rate_plan_code
     */
    public void setRate_plan_code(java.lang.String rate_plan_code) {
        this.rate_plan_code = rate_plan_code;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BlackberryInquiryResponse)) return false;
        BlackberryInquiryResponse other = (BlackberryInquiryResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transaction_id==null && other.getTransaction_id()==null) || 
             (this.transaction_id!=null &&
              this.transaction_id.equals(other.getTransaction_id()))) &&
            ((this.response_code==null && other.getResponse_code()==null) || 
             (this.response_code!=null &&
              this.response_code.equals(other.getResponse_code()))) &&
            ((this.response_description==null && other.getResponse_description()==null) || 
             (this.response_description!=null &&
              this.response_description.equals(other.getResponse_description()))) &&
            ((this.activation_date==null && other.getActivation_date()==null) || 
             (this.activation_date!=null &&
              this.activation_date.equals(other.getActivation_date()))) &&
            ((this.part_num==null && other.getPart_num()==null) || 
             (this.part_num!=null &&
              this.part_num.equals(other.getPart_num()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.renewal_date==null && other.getRenewal_date()==null) || 
             (this.renewal_date!=null &&
              this.renewal_date.equals(other.getRenewal_date()))) &&
            ((this.rate_plan_code==null && other.getRate_plan_code()==null) || 
             (this.rate_plan_code!=null &&
              this.rate_plan_code.equals(other.getRate_plan_code())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransaction_id() != null) {
            _hashCode += getTransaction_id().hashCode();
        }
        if (getResponse_code() != null) {
            _hashCode += getResponse_code().hashCode();
        }
        if (getResponse_description() != null) {
            _hashCode += getResponse_description().hashCode();
        }
        if (getActivation_date() != null) {
            _hashCode += getActivation_date().hashCode();
        }
        if (getPart_num() != null) {
            _hashCode += getPart_num().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getRenewal_date() != null) {
            _hashCode += getRenewal_date().hashCode();
        }
        if (getRate_plan_code() != null) {
            _hashCode += getRate_plan_code().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BlackberryInquiryResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "BlackberryInquiryResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transaction_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "transaction_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("response_code");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "Response_code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("response_description");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "Response_description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activation_date");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "Activation_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("part_num");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "part_num"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewal_date");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "Renewal_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rate_plan_code");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "Rate_plan_code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
