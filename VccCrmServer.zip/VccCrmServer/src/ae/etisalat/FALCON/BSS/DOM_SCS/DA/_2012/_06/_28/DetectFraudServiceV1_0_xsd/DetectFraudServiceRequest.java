/**
 * DetectFraudServiceRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd;

public class DetectFraudServiceRequest  implements java.io.Serializable {
    private java.lang.String channelInformation;

    private java.lang.String transaction_id;

    private java.lang.String account_number;

    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.Additional_info[] additional_information;

    private java.lang.String mode_type;

    public DetectFraudServiceRequest() {
    }

    public DetectFraudServiceRequest(
           java.lang.String channelInformation,
           java.lang.String transaction_id,
           java.lang.String account_number,
           ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.Additional_info[] additional_information,
           java.lang.String mode_type) {
           this.channelInformation = channelInformation;
           this.transaction_id = transaction_id;
           this.account_number = account_number;
           this.additional_information = additional_information;
           this.mode_type = mode_type;
    }


    /**
     * Gets the channelInformation value for this DetectFraudServiceRequest.
     * 
     * @return channelInformation
     */
    public java.lang.String getChannelInformation() {
        return channelInformation;
    }


    /**
     * Sets the channelInformation value for this DetectFraudServiceRequest.
     * 
     * @param channelInformation
     */
    public void setChannelInformation(java.lang.String channelInformation) {
        this.channelInformation = channelInformation;
    }


    /**
     * Gets the transaction_id value for this DetectFraudServiceRequest.
     * 
     * @return transaction_id
     */
    public java.lang.String getTransaction_id() {
        return transaction_id;
    }


    /**
     * Sets the transaction_id value for this DetectFraudServiceRequest.
     * 
     * @param transaction_id
     */
    public void setTransaction_id(java.lang.String transaction_id) {
        this.transaction_id = transaction_id;
    }


    /**
     * Gets the account_number value for this DetectFraudServiceRequest.
     * 
     * @return account_number
     */
    public java.lang.String getAccount_number() {
        return account_number;
    }


    /**
     * Sets the account_number value for this DetectFraudServiceRequest.
     * 
     * @param account_number
     */
    public void setAccount_number(java.lang.String account_number) {
        this.account_number = account_number;
    }


    /**
     * Gets the additional_information value for this DetectFraudServiceRequest.
     * 
     * @return additional_information
     */
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.Additional_info[] getAdditional_information() {
        return additional_information;
    }


    /**
     * Sets the additional_information value for this DetectFraudServiceRequest.
     * 
     * @param additional_information
     */
    public void setAdditional_information(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.Additional_info[] additional_information) {
        this.additional_information = additional_information;
    }


    /**
     * Gets the mode_type value for this DetectFraudServiceRequest.
     * 
     * @return mode_type
     */
    public java.lang.String getMode_type() {
        return mode_type;
    }


    /**
     * Sets the mode_type value for this DetectFraudServiceRequest.
     * 
     * @param mode_type
     */
    public void setMode_type(java.lang.String mode_type) {
        this.mode_type = mode_type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DetectFraudServiceRequest)) return false;
        DetectFraudServiceRequest other = (DetectFraudServiceRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.channelInformation==null && other.getChannelInformation()==null) || 
             (this.channelInformation!=null &&
              this.channelInformation.equals(other.getChannelInformation()))) &&
            ((this.transaction_id==null && other.getTransaction_id()==null) || 
             (this.transaction_id!=null &&
              this.transaction_id.equals(other.getTransaction_id()))) &&
            ((this.account_number==null && other.getAccount_number()==null) || 
             (this.account_number!=null &&
              this.account_number.equals(other.getAccount_number()))) &&
            ((this.additional_information==null && other.getAdditional_information()==null) || 
             (this.additional_information!=null &&
              java.util.Arrays.equals(this.additional_information, other.getAdditional_information()))) &&
            ((this.mode_type==null && other.getMode_type()==null) || 
             (this.mode_type!=null &&
              this.mode_type.equals(other.getMode_type())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getChannelInformation() != null) {
            _hashCode += getChannelInformation().hashCode();
        }
        if (getTransaction_id() != null) {
            _hashCode += getTransaction_id().hashCode();
        }
        if (getAccount_number() != null) {
            _hashCode += getAccount_number().hashCode();
        }
        if (getAdditional_information() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAdditional_information());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAdditional_information(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMode_type() != null) {
            _hashCode += getMode_type().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DetectFraudServiceRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "DetectFraudServiceRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("channelInformation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "channelInformation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transaction_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "transaction_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("account_number");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "account_number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("additional_information");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "additional_information"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", ">additional_information"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mode_type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "mode_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
