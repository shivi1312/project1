/**
 * GetEvisionBillingResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd;

public class GetEvisionBillingResponse  implements java.io.Serializable {
    private java.lang.String transaction_id;

    private java.lang.String response_code;

    private java.lang.String response_description;

    private java.lang.String sa_acct_num;

    private java.lang.String sa_cont_status;

    private java.lang.String sa_cust_id;

    private java.lang.String sa_due_amount;

    private java.lang.String sa_last_pay_date;

    private java.lang.String sa_mobile_phone;

    private java.lang.String sa_telephone;

    public GetEvisionBillingResponse() {
    }

    public GetEvisionBillingResponse(
           java.lang.String transaction_id,
           java.lang.String response_code,
           java.lang.String response_description,
           java.lang.String sa_acct_num,
           java.lang.String sa_cont_status,
           java.lang.String sa_cust_id,
           java.lang.String sa_due_amount,
           java.lang.String sa_last_pay_date,
           java.lang.String sa_mobile_phone,
           java.lang.String sa_telephone) {
           this.transaction_id = transaction_id;
           this.response_code = response_code;
           this.response_description = response_description;
           this.sa_acct_num = sa_acct_num;
           this.sa_cont_status = sa_cont_status;
           this.sa_cust_id = sa_cust_id;
           this.sa_due_amount = sa_due_amount;
           this.sa_last_pay_date = sa_last_pay_date;
           this.sa_mobile_phone = sa_mobile_phone;
           this.sa_telephone = sa_telephone;
    }


    /**
     * Gets the transaction_id value for this GetEvisionBillingResponse.
     * 
     * @return transaction_id
     */
    public java.lang.String getTransaction_id() {
        return transaction_id;
    }


    /**
     * Sets the transaction_id value for this GetEvisionBillingResponse.
     * 
     * @param transaction_id
     */
    public void setTransaction_id(java.lang.String transaction_id) {
        this.transaction_id = transaction_id;
    }


    /**
     * Gets the response_code value for this GetEvisionBillingResponse.
     * 
     * @return response_code
     */
    public java.lang.String getResponse_code() {
        return response_code;
    }


    /**
     * Sets the response_code value for this GetEvisionBillingResponse.
     * 
     * @param response_code
     */
    public void setResponse_code(java.lang.String response_code) {
        this.response_code = response_code;
    }


    /**
     * Gets the response_description value for this GetEvisionBillingResponse.
     * 
     * @return response_description
     */
    public java.lang.String getResponse_description() {
        return response_description;
    }


    /**
     * Sets the response_description value for this GetEvisionBillingResponse.
     * 
     * @param response_description
     */
    public void setResponse_description(java.lang.String response_description) {
        this.response_description = response_description;
    }


    /**
     * Gets the sa_acct_num value for this GetEvisionBillingResponse.
     * 
     * @return sa_acct_num
     */
    public java.lang.String getSa_acct_num() {
        return sa_acct_num;
    }


    /**
     * Sets the sa_acct_num value for this GetEvisionBillingResponse.
     * 
     * @param sa_acct_num
     */
    public void setSa_acct_num(java.lang.String sa_acct_num) {
        this.sa_acct_num = sa_acct_num;
    }


    /**
     * Gets the sa_cont_status value for this GetEvisionBillingResponse.
     * 
     * @return sa_cont_status
     */
    public java.lang.String getSa_cont_status() {
        return sa_cont_status;
    }


    /**
     * Sets the sa_cont_status value for this GetEvisionBillingResponse.
     * 
     * @param sa_cont_status
     */
    public void setSa_cont_status(java.lang.String sa_cont_status) {
        this.sa_cont_status = sa_cont_status;
    }


    /**
     * Gets the sa_cust_id value for this GetEvisionBillingResponse.
     * 
     * @return sa_cust_id
     */
    public java.lang.String getSa_cust_id() {
        return sa_cust_id;
    }


    /**
     * Sets the sa_cust_id value for this GetEvisionBillingResponse.
     * 
     * @param sa_cust_id
     */
    public void setSa_cust_id(java.lang.String sa_cust_id) {
        this.sa_cust_id = sa_cust_id;
    }


    /**
     * Gets the sa_due_amount value for this GetEvisionBillingResponse.
     * 
     * @return sa_due_amount
     */
    public java.lang.String getSa_due_amount() {
        return sa_due_amount;
    }


    /**
     * Sets the sa_due_amount value for this GetEvisionBillingResponse.
     * 
     * @param sa_due_amount
     */
    public void setSa_due_amount(java.lang.String sa_due_amount) {
        this.sa_due_amount = sa_due_amount;
    }


    /**
     * Gets the sa_last_pay_date value for this GetEvisionBillingResponse.
     * 
     * @return sa_last_pay_date
     */
    public java.lang.String getSa_last_pay_date() {
        return sa_last_pay_date;
    }


    /**
     * Sets the sa_last_pay_date value for this GetEvisionBillingResponse.
     * 
     * @param sa_last_pay_date
     */
    public void setSa_last_pay_date(java.lang.String sa_last_pay_date) {
        this.sa_last_pay_date = sa_last_pay_date;
    }


    /**
     * Gets the sa_mobile_phone value for this GetEvisionBillingResponse.
     * 
     * @return sa_mobile_phone
     */
    public java.lang.String getSa_mobile_phone() {
        return sa_mobile_phone;
    }


    /**
     * Sets the sa_mobile_phone value for this GetEvisionBillingResponse.
     * 
     * @param sa_mobile_phone
     */
    public void setSa_mobile_phone(java.lang.String sa_mobile_phone) {
        this.sa_mobile_phone = sa_mobile_phone;
    }


    /**
     * Gets the sa_telephone value for this GetEvisionBillingResponse.
     * 
     * @return sa_telephone
     */
    public java.lang.String getSa_telephone() {
        return sa_telephone;
    }


    /**
     * Sets the sa_telephone value for this GetEvisionBillingResponse.
     * 
     * @param sa_telephone
     */
    public void setSa_telephone(java.lang.String sa_telephone) {
        this.sa_telephone = sa_telephone;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetEvisionBillingResponse)) return false;
        GetEvisionBillingResponse other = (GetEvisionBillingResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transaction_id==null && other.getTransaction_id()==null) || 
             (this.transaction_id!=null &&
              this.transaction_id.equals(other.getTransaction_id()))) &&
            ((this.response_code==null && other.getResponse_code()==null) || 
             (this.response_code!=null &&
              this.response_code.equals(other.getResponse_code()))) &&
            ((this.response_description==null && other.getResponse_description()==null) || 
             (this.response_description!=null &&
              this.response_description.equals(other.getResponse_description()))) &&
            ((this.sa_acct_num==null && other.getSa_acct_num()==null) || 
             (this.sa_acct_num!=null &&
              this.sa_acct_num.equals(other.getSa_acct_num()))) &&
            ((this.sa_cont_status==null && other.getSa_cont_status()==null) || 
             (this.sa_cont_status!=null &&
              this.sa_cont_status.equals(other.getSa_cont_status()))) &&
            ((this.sa_cust_id==null && other.getSa_cust_id()==null) || 
             (this.sa_cust_id!=null &&
              this.sa_cust_id.equals(other.getSa_cust_id()))) &&
            ((this.sa_due_amount==null && other.getSa_due_amount()==null) || 
             (this.sa_due_amount!=null &&
              this.sa_due_amount.equals(other.getSa_due_amount()))) &&
            ((this.sa_last_pay_date==null && other.getSa_last_pay_date()==null) || 
             (this.sa_last_pay_date!=null &&
              this.sa_last_pay_date.equals(other.getSa_last_pay_date()))) &&
            ((this.sa_mobile_phone==null && other.getSa_mobile_phone()==null) || 
             (this.sa_mobile_phone!=null &&
              this.sa_mobile_phone.equals(other.getSa_mobile_phone()))) &&
            ((this.sa_telephone==null && other.getSa_telephone()==null) || 
             (this.sa_telephone!=null &&
              this.sa_telephone.equals(other.getSa_telephone())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransaction_id() != null) {
            _hashCode += getTransaction_id().hashCode();
        }
        if (getResponse_code() != null) {
            _hashCode += getResponse_code().hashCode();
        }
        if (getResponse_description() != null) {
            _hashCode += getResponse_description().hashCode();
        }
        if (getSa_acct_num() != null) {
            _hashCode += getSa_acct_num().hashCode();
        }
        if (getSa_cont_status() != null) {
            _hashCode += getSa_cont_status().hashCode();
        }
        if (getSa_cust_id() != null) {
            _hashCode += getSa_cust_id().hashCode();
        }
        if (getSa_due_amount() != null) {
            _hashCode += getSa_due_amount().hashCode();
        }
        if (getSa_last_pay_date() != null) {
            _hashCode += getSa_last_pay_date().hashCode();
        }
        if (getSa_mobile_phone() != null) {
            _hashCode += getSa_mobile_phone().hashCode();
        }
        if (getSa_telephone() != null) {
            _hashCode += getSa_telephone().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetEvisionBillingResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "GetEvisionBillingResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transaction_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "transaction_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("response_code");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "response_code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("response_description");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "response_description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sa_acct_num");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "sa_acct_num"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sa_cont_status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "sa_cont_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sa_cust_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "sa_cust_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sa_due_amount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "sa_due_amount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sa_last_pay_date");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "sa_last_pay_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sa_mobile_phone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "sa_mobile_phone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sa_telephone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "sa_telephone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
