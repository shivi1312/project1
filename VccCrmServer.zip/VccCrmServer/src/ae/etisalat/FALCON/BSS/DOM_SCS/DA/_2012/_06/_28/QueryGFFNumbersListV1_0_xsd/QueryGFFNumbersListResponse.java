/**
 * QueryGFFNumbersListResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd;

public class QueryGFFNumbersListResponse  implements java.io.Serializable {
    private java.lang.String transactionId;

    private java.lang.String msisdn;

    private java.lang.String responseCode;

    private java.lang.String responseDetails;

    private java.lang.String status;

    private java.lang.String[][] numberList;

    private java.lang.String part_num;

    public QueryGFFNumbersListResponse() {
    }

    public QueryGFFNumbersListResponse(
           java.lang.String transactionId,
           java.lang.String msisdn,
           java.lang.String responseCode,
           java.lang.String responseDetails,
           java.lang.String status,
           java.lang.String[][] numberList,
           java.lang.String part_num) {
           this.transactionId = transactionId;
           this.msisdn = msisdn;
           this.responseCode = responseCode;
           this.responseDetails = responseDetails;
           this.status = status;
           this.numberList = numberList;
           this.part_num = part_num;
    }


    /**
     * Gets the transactionId value for this QueryGFFNumbersListResponse.
     * 
     * @return transactionId
     */
    public java.lang.String getTransactionId() {
        return transactionId;
    }


    /**
     * Sets the transactionId value for this QueryGFFNumbersListResponse.
     * 
     * @param transactionId
     */
    public void setTransactionId(java.lang.String transactionId) {
        this.transactionId = transactionId;
    }


    /**
     * Gets the msisdn value for this QueryGFFNumbersListResponse.
     * 
     * @return msisdn
     */
    public java.lang.String getMsisdn() {
        return msisdn;
    }


    /**
     * Sets the msisdn value for this QueryGFFNumbersListResponse.
     * 
     * @param msisdn
     */
    public void setMsisdn(java.lang.String msisdn) {
        this.msisdn = msisdn;
    }


    /**
     * Gets the responseCode value for this QueryGFFNumbersListResponse.
     * 
     * @return responseCode
     */
    public java.lang.String getResponseCode() {
        return responseCode;
    }


    /**
     * Sets the responseCode value for this QueryGFFNumbersListResponse.
     * 
     * @param responseCode
     */
    public void setResponseCode(java.lang.String responseCode) {
        this.responseCode = responseCode;
    }


    /**
     * Gets the responseDetails value for this QueryGFFNumbersListResponse.
     * 
     * @return responseDetails
     */
    public java.lang.String getResponseDetails() {
        return responseDetails;
    }


    /**
     * Sets the responseDetails value for this QueryGFFNumbersListResponse.
     * 
     * @param responseDetails
     */
    public void setResponseDetails(java.lang.String responseDetails) {
        this.responseDetails = responseDetails;
    }


    /**
     * Gets the status value for this QueryGFFNumbersListResponse.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this QueryGFFNumbersListResponse.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the numberList value for this QueryGFFNumbersListResponse.
     * 
     * @return numberList
     */
    public java.lang.String[][] getNumberList() {
        return numberList;
    }


    /**
     * Sets the numberList value for this QueryGFFNumbersListResponse.
     * 
     * @param numberList
     */
    public void setNumberList(java.lang.String[][] numberList) {
        this.numberList = numberList;
    }

    public java.lang.String[] getNumberList(int i) {
        return this.numberList[i];
    }

    public void setNumberList(int i, java.lang.String[] _value) {
        this.numberList[i] = _value;
    }


    /**
     * Gets the part_num value for this QueryGFFNumbersListResponse.
     * 
     * @return part_num
     */
    public java.lang.String getPart_num() {
        return part_num;
    }


    /**
     * Sets the part_num value for this QueryGFFNumbersListResponse.
     * 
     * @param part_num
     */
    public void setPart_num(java.lang.String part_num) {
        this.part_num = part_num;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QueryGFFNumbersListResponse)) return false;
        QueryGFFNumbersListResponse other = (QueryGFFNumbersListResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transactionId==null && other.getTransactionId()==null) || 
             (this.transactionId!=null &&
              this.transactionId.equals(other.getTransactionId()))) &&
            ((this.msisdn==null && other.getMsisdn()==null) || 
             (this.msisdn!=null &&
              this.msisdn.equals(other.getMsisdn()))) &&
            ((this.responseCode==null && other.getResponseCode()==null) || 
             (this.responseCode!=null &&
              this.responseCode.equals(other.getResponseCode()))) &&
            ((this.responseDetails==null && other.getResponseDetails()==null) || 
             (this.responseDetails!=null &&
              this.responseDetails.equals(other.getResponseDetails()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.numberList==null && other.getNumberList()==null) || 
             (this.numberList!=null &&
              java.util.Arrays.equals(this.numberList, other.getNumberList()))) &&
            ((this.part_num==null && other.getPart_num()==null) || 
             (this.part_num!=null &&
              this.part_num.equals(other.getPart_num())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransactionId() != null) {
            _hashCode += getTransactionId().hashCode();
        }
        if (getMsisdn() != null) {
            _hashCode += getMsisdn().hashCode();
        }
        if (getResponseCode() != null) {
            _hashCode += getResponseCode().hashCode();
        }
        if (getResponseDetails() != null) {
            _hashCode += getResponseDetails().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getNumberList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getNumberList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getNumberList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPart_num() != null) {
            _hashCode += getPart_num().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QueryGFFNumbersListResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "QueryGFFNumbersListResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "transactionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msisdn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "msisdn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("responseCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "responseCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("responseDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "responseDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numberList");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "NumberList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "NumberList"));
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("part_num");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "Part_num"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
