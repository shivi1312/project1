/**
 * CheckEnoughBalanceRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd;

public class CheckEnoughBalanceRequest  implements java.io.Serializable {
    private java.lang.String msisdn;

    private java.lang.String part_num;

    private java.lang.String offer_id;

    private java.lang.String campaign_id;

    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.ChannelInformation channelInformation;

    private java.lang.String transaction_id;

    public CheckEnoughBalanceRequest() {
    }

    public CheckEnoughBalanceRequest(
           java.lang.String msisdn,
           java.lang.String part_num,
           java.lang.String offer_id,
           java.lang.String campaign_id,
           ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.ChannelInformation channelInformation,
           java.lang.String transaction_id) {
           this.msisdn = msisdn;
           this.part_num = part_num;
           this.offer_id = offer_id;
           this.campaign_id = campaign_id;
           this.channelInformation = channelInformation;
           this.transaction_id = transaction_id;
    }


    /**
     * Gets the msisdn value for this CheckEnoughBalanceRequest.
     * 
     * @return msisdn
     */
    public java.lang.String getMsisdn() {
        return msisdn;
    }


    /**
     * Sets the msisdn value for this CheckEnoughBalanceRequest.
     * 
     * @param msisdn
     */
    public void setMsisdn(java.lang.String msisdn) {
        this.msisdn = msisdn;
    }


    /**
     * Gets the part_num value for this CheckEnoughBalanceRequest.
     * 
     * @return part_num
     */
    public java.lang.String getPart_num() {
        return part_num;
    }


    /**
     * Sets the part_num value for this CheckEnoughBalanceRequest.
     * 
     * @param part_num
     */
    public void setPart_num(java.lang.String part_num) {
        this.part_num = part_num;
    }


    /**
     * Gets the offer_id value for this CheckEnoughBalanceRequest.
     * 
     * @return offer_id
     */
    public java.lang.String getOffer_id() {
        return offer_id;
    }


    /**
     * Sets the offer_id value for this CheckEnoughBalanceRequest.
     * 
     * @param offer_id
     */
    public void setOffer_id(java.lang.String offer_id) {
        this.offer_id = offer_id;
    }


    /**
     * Gets the campaign_id value for this CheckEnoughBalanceRequest.
     * 
     * @return campaign_id
     */
    public java.lang.String getCampaign_id() {
        return campaign_id;
    }


    /**
     * Sets the campaign_id value for this CheckEnoughBalanceRequest.
     * 
     * @param campaign_id
     */
    public void setCampaign_id(java.lang.String campaign_id) {
        this.campaign_id = campaign_id;
    }


    /**
     * Gets the channelInformation value for this CheckEnoughBalanceRequest.
     * 
     * @return channelInformation
     */
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.ChannelInformation getChannelInformation() {
        return channelInformation;
    }


    /**
     * Sets the channelInformation value for this CheckEnoughBalanceRequest.
     * 
     * @param channelInformation
     */
    public void setChannelInformation(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.ChannelInformation channelInformation) {
        this.channelInformation = channelInformation;
    }


    /**
     * Gets the transaction_id value for this CheckEnoughBalanceRequest.
     * 
     * @return transaction_id
     */
    public java.lang.String getTransaction_id() {
        return transaction_id;
    }


    /**
     * Sets the transaction_id value for this CheckEnoughBalanceRequest.
     * 
     * @param transaction_id
     */
    public void setTransaction_id(java.lang.String transaction_id) {
        this.transaction_id = transaction_id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CheckEnoughBalanceRequest)) return false;
        CheckEnoughBalanceRequest other = (CheckEnoughBalanceRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.msisdn==null && other.getMsisdn()==null) || 
             (this.msisdn!=null &&
              this.msisdn.equals(other.getMsisdn()))) &&
            ((this.part_num==null && other.getPart_num()==null) || 
             (this.part_num!=null &&
              this.part_num.equals(other.getPart_num()))) &&
            ((this.offer_id==null && other.getOffer_id()==null) || 
             (this.offer_id!=null &&
              this.offer_id.equals(other.getOffer_id()))) &&
            ((this.campaign_id==null && other.getCampaign_id()==null) || 
             (this.campaign_id!=null &&
              this.campaign_id.equals(other.getCampaign_id()))) &&
            ((this.channelInformation==null && other.getChannelInformation()==null) || 
             (this.channelInformation!=null &&
              this.channelInformation.equals(other.getChannelInformation()))) &&
            ((this.transaction_id==null && other.getTransaction_id()==null) || 
             (this.transaction_id!=null &&
              this.transaction_id.equals(other.getTransaction_id())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMsisdn() != null) {
            _hashCode += getMsisdn().hashCode();
        }
        if (getPart_num() != null) {
            _hashCode += getPart_num().hashCode();
        }
        if (getOffer_id() != null) {
            _hashCode += getOffer_id().hashCode();
        }
        if (getCampaign_id() != null) {
            _hashCode += getCampaign_id().hashCode();
        }
        if (getChannelInformation() != null) {
            _hashCode += getChannelInformation().hashCode();
        }
        if (getTransaction_id() != null) {
            _hashCode += getTransaction_id().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CheckEnoughBalanceRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "CheckEnoughBalanceRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msisdn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "msisdn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("part_num");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "part_num"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offer_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "offer_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("campaign_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "campaign_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("channelInformation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "channelInformation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", ">channelInformation"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transaction_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "transaction_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
