/**
 * VerifyServiceOrderStatusResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd;

public class VerifyServiceOrderStatusResponse  implements java.io.Serializable {
    private java.lang.String transaction_id;

    private java.lang.String account_no;

    private java.lang.String response_code;

    private java.lang.String response_description;

    private java.lang.String creation_date;

    private java.lang.String closure_date;

    private java.lang.String status;

    public VerifyServiceOrderStatusResponse() {
    }

    public VerifyServiceOrderStatusResponse(
           java.lang.String transaction_id,
           java.lang.String account_no,
           java.lang.String response_code,
           java.lang.String response_description,
           java.lang.String creation_date,
           java.lang.String closure_date,
           java.lang.String status) {
           this.transaction_id = transaction_id;
           this.account_no = account_no;
           this.response_code = response_code;
           this.response_description = response_description;
           this.creation_date = creation_date;
           this.closure_date = closure_date;
           this.status = status;
    }


    /**
     * Gets the transaction_id value for this VerifyServiceOrderStatusResponse.
     * 
     * @return transaction_id
     */
    public java.lang.String getTransaction_id() {
        return transaction_id;
    }


    /**
     * Sets the transaction_id value for this VerifyServiceOrderStatusResponse.
     * 
     * @param transaction_id
     */
    public void setTransaction_id(java.lang.String transaction_id) {
        this.transaction_id = transaction_id;
    }


    /**
     * Gets the account_no value for this VerifyServiceOrderStatusResponse.
     * 
     * @return account_no
     */
    public java.lang.String getAccount_no() {
        return account_no;
    }


    /**
     * Sets the account_no value for this VerifyServiceOrderStatusResponse.
     * 
     * @param account_no
     */
    public void setAccount_no(java.lang.String account_no) {
        this.account_no = account_no;
    }


    /**
     * Gets the response_code value for this VerifyServiceOrderStatusResponse.
     * 
     * @return response_code
     */
    public java.lang.String getResponse_code() {
        return response_code;
    }


    /**
     * Sets the response_code value for this VerifyServiceOrderStatusResponse.
     * 
     * @param response_code
     */
    public void setResponse_code(java.lang.String response_code) {
        this.response_code = response_code;
    }


    /**
     * Gets the response_description value for this VerifyServiceOrderStatusResponse.
     * 
     * @return response_description
     */
    public java.lang.String getResponse_description() {
        return response_description;
    }


    /**
     * Sets the response_description value for this VerifyServiceOrderStatusResponse.
     * 
     * @param response_description
     */
    public void setResponse_description(java.lang.String response_description) {
        this.response_description = response_description;
    }


    /**
     * Gets the creation_date value for this VerifyServiceOrderStatusResponse.
     * 
     * @return creation_date
     */
    public java.lang.String getCreation_date() {
        return creation_date;
    }


    /**
     * Sets the creation_date value for this VerifyServiceOrderStatusResponse.
     * 
     * @param creation_date
     */
    public void setCreation_date(java.lang.String creation_date) {
        this.creation_date = creation_date;
    }


    /**
     * Gets the closure_date value for this VerifyServiceOrderStatusResponse.
     * 
     * @return closure_date
     */
    public java.lang.String getClosure_date() {
        return closure_date;
    }


    /**
     * Sets the closure_date value for this VerifyServiceOrderStatusResponse.
     * 
     * @param closure_date
     */
    public void setClosure_date(java.lang.String closure_date) {
        this.closure_date = closure_date;
    }


    /**
     * Gets the status value for this VerifyServiceOrderStatusResponse.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this VerifyServiceOrderStatusResponse.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof VerifyServiceOrderStatusResponse)) return false;
        VerifyServiceOrderStatusResponse other = (VerifyServiceOrderStatusResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transaction_id==null && other.getTransaction_id()==null) || 
             (this.transaction_id!=null &&
              this.transaction_id.equals(other.getTransaction_id()))) &&
            ((this.account_no==null && other.getAccount_no()==null) || 
             (this.account_no!=null &&
              this.account_no.equals(other.getAccount_no()))) &&
            ((this.response_code==null && other.getResponse_code()==null) || 
             (this.response_code!=null &&
              this.response_code.equals(other.getResponse_code()))) &&
            ((this.response_description==null && other.getResponse_description()==null) || 
             (this.response_description!=null &&
              this.response_description.equals(other.getResponse_description()))) &&
            ((this.creation_date==null && other.getCreation_date()==null) || 
             (this.creation_date!=null &&
              this.creation_date.equals(other.getCreation_date()))) &&
            ((this.closure_date==null && other.getClosure_date()==null) || 
             (this.closure_date!=null &&
              this.closure_date.equals(other.getClosure_date()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransaction_id() != null) {
            _hashCode += getTransaction_id().hashCode();
        }
        if (getAccount_no() != null) {
            _hashCode += getAccount_no().hashCode();
        }
        if (getResponse_code() != null) {
            _hashCode += getResponse_code().hashCode();
        }
        if (getResponse_description() != null) {
            _hashCode += getResponse_description().hashCode();
        }
        if (getCreation_date() != null) {
            _hashCode += getCreation_date().hashCode();
        }
        if (getClosure_date() != null) {
            _hashCode += getClosure_date().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(VerifyServiceOrderStatusResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "VerifyServiceOrderStatusResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transaction_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "transaction_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("account_no");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "account_no"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("response_code");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "response_code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("response_description");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "response_description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creation_date");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "creation_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("closure_date");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "closure_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
