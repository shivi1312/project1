/**
 * SelfCareServiceServiceHTTPSLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl;

public class SelfCareServiceServiceHTTPSLocator extends org.apache.axis.client.Service implements ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServiceServiceHTTPS {

    public SelfCareServiceServiceHTTPSLocator() {
    }


    public SelfCareServiceServiceHTTPSLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public SelfCareServiceServiceHTTPSLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for SelfCareServicePortType
    private java.lang.String SelfCareServicePortType_address = "https://localhost:9157/Etisalat/Falcon/Tibco/IIT/DOM_CC/CustomerManagement/BS_SelfCareService";

    public java.lang.String getSelfCareServicePortTypeAddress() {
        return SelfCareServicePortType_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String SelfCareServicePortTypeWSDDServiceName = "SelfCareService-PortType";

    public java.lang.String getSelfCareServicePortTypeWSDDServiceName() {
        return SelfCareServicePortTypeWSDDServiceName;
    }

    public void setSelfCareServicePortTypeWSDDServiceName(java.lang.String name) {
        SelfCareServicePortTypeWSDDServiceName = name;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServicePortType getSelfCareServicePortType() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(SelfCareServicePortType_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getSelfCareServicePortType(endpoint);
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServicePortType getSelfCareServicePortType(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServicePortTypeBindingStub _stub = new ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServicePortTypeBindingStub(portAddress, this);
            _stub.setPortName(getSelfCareServicePortTypeWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setSelfCareServicePortTypeEndpointAddress(java.lang.String address) {
        SelfCareServicePortType_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServicePortType.class.isAssignableFrom(serviceEndpointInterface)) {
                ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServicePortTypeBindingStub _stub = new ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServicePortTypeBindingStub(new java.net.URL(SelfCareServicePortType_address), this);
                _stub.setPortName(getSelfCareServicePortTypeWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("SelfCareService-PortType".equals(inputPortName)) {
            return getSelfCareServicePortType();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/SelfCareServiceV1.0.wsdl", "SelfCareService-service-HTTPS");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/SelfCareServiceV1.0.wsdl", "SelfCareService-PortType"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("SelfCareServicePortType".equals(portName)) {
            setSelfCareServicePortTypeEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
