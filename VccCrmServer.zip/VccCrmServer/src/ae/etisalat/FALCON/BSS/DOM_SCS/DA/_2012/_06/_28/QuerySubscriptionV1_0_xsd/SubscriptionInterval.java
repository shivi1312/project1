/**
 * SubscriptionInterval.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd;

public class SubscriptionInterval  implements java.io.Serializable {
    private java.lang.String intervalId;

    private java.lang.String campaignId;

    private java.lang.String subscribingChannel;

    private java.lang.String startDate;

    private java.lang.String expiryDate;

    private java.lang.Integer intervalStatus;

    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.IntervalAttributes[] intervalAttributes;

    public SubscriptionInterval() {
    }

    public SubscriptionInterval(
           java.lang.String intervalId,
           java.lang.String campaignId,
           java.lang.String subscribingChannel,
           java.lang.String startDate,
           java.lang.String expiryDate,
           java.lang.Integer intervalStatus,
           ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.IntervalAttributes[] intervalAttributes) {
           this.intervalId = intervalId;
           this.campaignId = campaignId;
           this.subscribingChannel = subscribingChannel;
           this.startDate = startDate;
           this.expiryDate = expiryDate;
           this.intervalStatus = intervalStatus;
           this.intervalAttributes = intervalAttributes;
    }


    /**
     * Gets the intervalId value for this SubscriptionInterval.
     * 
     * @return intervalId
     */
    public java.lang.String getIntervalId() {
        return intervalId;
    }


    /**
     * Sets the intervalId value for this SubscriptionInterval.
     * 
     * @param intervalId
     */
    public void setIntervalId(java.lang.String intervalId) {
        this.intervalId = intervalId;
    }


    /**
     * Gets the campaignId value for this SubscriptionInterval.
     * 
     * @return campaignId
     */
    public java.lang.String getCampaignId() {
        return campaignId;
    }


    /**
     * Sets the campaignId value for this SubscriptionInterval.
     * 
     * @param campaignId
     */
    public void setCampaignId(java.lang.String campaignId) {
        this.campaignId = campaignId;
    }


    /**
     * Gets the subscribingChannel value for this SubscriptionInterval.
     * 
     * @return subscribingChannel
     */
    public java.lang.String getSubscribingChannel() {
        return subscribingChannel;
    }


    /**
     * Sets the subscribingChannel value for this SubscriptionInterval.
     * 
     * @param subscribingChannel
     */
    public void setSubscribingChannel(java.lang.String subscribingChannel) {
        this.subscribingChannel = subscribingChannel;
    }


    /**
     * Gets the startDate value for this SubscriptionInterval.
     * 
     * @return startDate
     */
    public java.lang.String getStartDate() {
        return startDate;
    }


    /**
     * Sets the startDate value for this SubscriptionInterval.
     * 
     * @param startDate
     */
    public void setStartDate(java.lang.String startDate) {
        this.startDate = startDate;
    }


    /**
     * Gets the expiryDate value for this SubscriptionInterval.
     * 
     * @return expiryDate
     */
    public java.lang.String getExpiryDate() {
        return expiryDate;
    }


    /**
     * Sets the expiryDate value for this SubscriptionInterval.
     * 
     * @param expiryDate
     */
    public void setExpiryDate(java.lang.String expiryDate) {
        this.expiryDate = expiryDate;
    }


    /**
     * Gets the intervalStatus value for this SubscriptionInterval.
     * 
     * @return intervalStatus
     */
    public java.lang.Integer getIntervalStatus() {
        return intervalStatus;
    }


    /**
     * Sets the intervalStatus value for this SubscriptionInterval.
     * 
     * @param intervalStatus
     */
    public void setIntervalStatus(java.lang.Integer intervalStatus) {
        this.intervalStatus = intervalStatus;
    }


    /**
     * Gets the intervalAttributes value for this SubscriptionInterval.
     * 
     * @return intervalAttributes
     */
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.IntervalAttributes[] getIntervalAttributes() {
        return intervalAttributes;
    }


    /**
     * Sets the intervalAttributes value for this SubscriptionInterval.
     * 
     * @param intervalAttributes
     */
    public void setIntervalAttributes(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.IntervalAttributes[] intervalAttributes) {
        this.intervalAttributes = intervalAttributes;
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.IntervalAttributes getIntervalAttributes(int i) {
        return this.intervalAttributes[i];
    }

    public void setIntervalAttributes(int i, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.IntervalAttributes _value) {
        this.intervalAttributes[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SubscriptionInterval)) return false;
        SubscriptionInterval other = (SubscriptionInterval) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.intervalId==null && other.getIntervalId()==null) || 
             (this.intervalId!=null &&
              this.intervalId.equals(other.getIntervalId()))) &&
            ((this.campaignId==null && other.getCampaignId()==null) || 
             (this.campaignId!=null &&
              this.campaignId.equals(other.getCampaignId()))) &&
            ((this.subscribingChannel==null && other.getSubscribingChannel()==null) || 
             (this.subscribingChannel!=null &&
              this.subscribingChannel.equals(other.getSubscribingChannel()))) &&
            ((this.startDate==null && other.getStartDate()==null) || 
             (this.startDate!=null &&
              this.startDate.equals(other.getStartDate()))) &&
            ((this.expiryDate==null && other.getExpiryDate()==null) || 
             (this.expiryDate!=null &&
              this.expiryDate.equals(other.getExpiryDate()))) &&
            ((this.intervalStatus==null && other.getIntervalStatus()==null) || 
             (this.intervalStatus!=null &&
              this.intervalStatus.equals(other.getIntervalStatus()))) &&
            ((this.intervalAttributes==null && other.getIntervalAttributes()==null) || 
             (this.intervalAttributes!=null &&
              java.util.Arrays.equals(this.intervalAttributes, other.getIntervalAttributes())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIntervalId() != null) {
            _hashCode += getIntervalId().hashCode();
        }
        if (getCampaignId() != null) {
            _hashCode += getCampaignId().hashCode();
        }
        if (getSubscribingChannel() != null) {
            _hashCode += getSubscribingChannel().hashCode();
        }
        if (getStartDate() != null) {
            _hashCode += getStartDate().hashCode();
        }
        if (getExpiryDate() != null) {
            _hashCode += getExpiryDate().hashCode();
        }
        if (getIntervalStatus() != null) {
            _hashCode += getIntervalStatus().hashCode();
        }
        if (getIntervalAttributes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIntervalAttributes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIntervalAttributes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SubscriptionInterval.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">subscriptionInterval"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("intervalId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "intervalId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("campaignId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "campaignId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subscribingChannel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "subscribingChannel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "startDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expiryDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "expiryDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("intervalStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "intervalStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("intervalAttributes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "intervalAttributes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "intervalAttributes"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
