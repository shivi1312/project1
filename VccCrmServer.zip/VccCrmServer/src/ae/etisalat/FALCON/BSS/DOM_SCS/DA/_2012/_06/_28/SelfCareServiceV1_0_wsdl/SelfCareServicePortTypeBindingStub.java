/**
 * SelfCareServicePortTypeBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl;

public class SelfCareServicePortTypeBindingStub extends org.apache.axis.client.Stub implements ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.SelfCareServiceV1_0_wsdl.SelfCareServicePortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[23];
        _initOperationDesc1();
        _initOperationDesc2();
        _initOperationDesc3();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpInquiryNotification");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpQueryGFFNumbersList");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpVerifyServiceOrderStatus");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpModifyService");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpUpdateOrderStatus");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", "UpdateOrderStatusRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">UpdateOrderStatusRequest"), com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusResponse.xsd", ">UpdateOrderStatusResponse"));
        oper.setReturnClass(com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusResponse.xsd", "UpdateOrderStatusResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://www.etisalat.ae/Middleware/SharedResources/Common/AckMessage.xsd", "AckMessage"),
                      "ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage",
                      new javax.xml.namespace.QName("http://www.etisalat.ae/Middleware/SharedResources/Common/AckMessage.xsd", ">AckMessage"), 
                      true
                     ));
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpCheckEnoughBalance");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpOtherServicesBilling");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpCancelService");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpQueryCustomerServiceDetails");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpViewPlan");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpMigrationStatusCheck");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpDetectFraudService");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpGetBlockedStatus");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpBlackberryInquiry");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpEmcaisService");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpVerifyComplaintStatus");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpQuerySubscription");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[16] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpCheckSubscription");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[17] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpGetFaultDockCrtCC");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[18] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpQuerySubscribedServicesList");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[19] = oper;

    }

    private static void _initOperationDesc3(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpGetEvisionBilling");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[20] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpCheckEligibility");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "CheckEligibilityRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">CheckEligibilityRequest"), com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">CheckEligibilityResponse"));
        oper.setReturnClass(com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", "CheckEligibilityResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://www.etisalat.ae/Middleware/SharedResources/Common/AckMessage.xsd", "AckMessage"),
                      "ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage",
                      new javax.xml.namespace.QName("http://www.etisalat.ae/Middleware/SharedResources/Common/AckMessage.xsd", ">AckMessage"), 
                      true
                     ));
        _operations[21] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OpProvisionRequestedService");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "MessageEnvelope"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "MessageEnvelope"), ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "MessageEnvelope"));
        oper.setReturnClass(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "MessageEnvelope"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "MessageError"),
                      "ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg",
                      new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg"), 
                      true
                     ));
        _operations[22] = oper;

    }

    public SelfCareServicePortTypeBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public SelfCareServicePortTypeBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public SelfCareServicePortTypeBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
        addBindings0();
        addBindings1();
        addBindings2();
    }

    private void addBindings0() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "BlackberryInquiryRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.BlackberryInquiryRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "BlackberryInquiryResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.BlackberryInquiryResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/BlackberryInquiryV1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", ">additional_info");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.Additional_info.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", ">Additional_information");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.Additional_info[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "additional_info");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "CancelServiceRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.CancelServiceRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "CancelServiceResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.CancelServiceResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CancelService.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "CheckEnoughBalanceRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.CheckEnoughBalanceRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "CheckEnoughBalanceResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.CheckEnoughBalanceResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckEnoughBalanceV1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "CheckSubscriptionRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.CheckSubscriptionRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "CheckSubscriptionResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.CheckSubscriptionResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/CheckSubscriptionV1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", ">additional_info");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.Additional_info.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", ">additional_information");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.Additional_info[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "additional_info");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "DetectFraudServiceRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.DetectFraudServiceRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "DetectFraudServiceResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.DetectFraudServiceResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/DetectFraudServiceV1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", ">additional_info");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.Additional_info.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", ">additional_information");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.Additional_info[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "additional_info");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "EmcaisServiceRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.EmcaisServiceRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "EmcaisServiceResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.EmcaisServiceResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/EmcaisServiceV1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "GetEvisionBillingRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.GetEvisionBillingRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "GetEvisionBillingResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.GetEvisionBillingResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/GetEvisionBillingV1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", ">additional_info");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.Additional_info.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", ">additional_information");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.Additional_info[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "additional_info");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "ModifyServiceRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.ModifyServiceRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "ModifyServiceResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.ModifyServiceResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ModifyServiceV1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "OtherServicesBillingRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.OtherServicesBillingRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "OtherServicesBillingResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.OtherServicesBillingResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/OtherServicesBilling.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", ">additional_info");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.Additional_info.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", ">additional_information");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.Additional_info[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "additional_info");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "ProvisionRequestedServiceRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.ProvisionRequestedServiceRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "ProvisionRequestedServiceResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.ProvisionRequestedServiceResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/ProvisionRequestedService.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "QueryCustomerServiceDetailsRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.QueryCustomerServiceDetailsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "QueryCustomerServiceDetailsResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.QueryCustomerServiceDetailsResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryCustomerServiceDetailsV1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", ">NumberList");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "Number");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "QueryGFFNumbersListRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.QueryGFFNumbersListRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "QueryGFFNumbersListResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.QueryGFFNumbersListResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QueryGFFNumbersListV1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", ">part_num_list");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "part_num");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "QuerySubscribedServicesListRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.QuerySubscribedServicesListRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "QuerySubscribedServicesListResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.QuerySubscribedServicesListResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings1() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">intervalAttribute");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.IntervalAttribute.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">intervalAttributes");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.IntervalAttributes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">service");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Service.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">serviceAttribute");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.ServiceAttribute.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">serviceAttributes");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.ServiceAttribute[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "serviceAttribute");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">services");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Services.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">subscription");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Subscription.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">subscriptionAttribute");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.SubscriptionAttribute.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">subscriptionAttributes");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.SubscriptionAttributes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">subscriptionInterval");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.SubscriptionInterval.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">subscriptionIntervals");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.SubscriptionIntervals.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", ">subscriptions");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Subscriptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "QuerySubscriptionRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.QuerySubscriptionRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "QuerySubscriptionResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.QuerySubscriptionResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "VerifyComplaintStatusRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.VerifyComplaintStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyComplaintStatusV1.0.xsd", "VerifyComplaintStatusResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.VerifyComplaintStatusResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "VerifyServiceOrderStatusRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.VerifyServiceOrderStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/VerifyServiceOrderStatusV1.0.xsd", "VerifyServiceOrderStatusResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.VerifyServiceOrderStatusResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "GetBlockedStatusRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.GetBlockedStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "GetBlockedStatusResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.GetBlockedStatusResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/GetBlockedStatusBOv1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", ">IDDPlanList");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "IDDPlanLists");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "ViewPlanRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.ViewPlanRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/10/ViewPlanBOv1.0.xsd", "ViewPlanResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.ViewPlanResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "GetFaultDockCrtCCORequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.GetFaultDockCrtCCORequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "GetFaultDockCrtCCOResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.GetFaultDockCrtCCOResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/GetFaultDockCrtCCBOv1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", ">Name");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.Name.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "MigrationStatusCheckRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MigrationStatusCheckRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "MigrationStatusCheckResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MigrationStatusCheckResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/11/MigrationStatusCheckBOv1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", ">channelInformation");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.ChannelInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "InquiryNotificationRequest");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.InquiryNotificationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "InquiryNotificationResponse");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.InquiryNotificationResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "MessageBody");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "MessageEnvelope");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "Request");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/07/23/InquiryNotificationBOv1.0.xsd", "Response");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorDetail");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorMsg");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageErrorV1.1.xsd", "ErrorType");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", ">Action");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.Action.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", ">ActionType");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.ActionType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", ">BusinessAction");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.BusinessAction.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", ">BusinessEvent");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.BusinessEvent.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", ">complex");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.Complex.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", ">simple");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.Simple.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", ">SystemAction");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.SystemAction.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", ">Version");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", ">VStatus");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.VStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tAction");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TAction.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tContext");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TContext.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tDynamicParameterList");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TParameter[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "Parameter");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tEvent");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TEvent.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tEventSource");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TEventSource.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tHeader");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.THeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tParameter");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TParameter.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tSimpleAction");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TSimpleAction.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tUserInfo");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TUserInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tVersionInfo");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TVersionInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2012/03/18/MessageRetryV1.0.xsd", ">RetryDetail>RetryParameters");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.RetryDetailRetryParameters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2012/03/18/MessageRetryV1.0.xsd", "RetryDetail");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.RetryDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2012/03/18/MessageRetryV1.0.xsd", "RetryMsg");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.RetryMsg.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2012/03/18/MessageRetryV1.0.xsd", "TargetSystems");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.TargetSystems.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.etisalat.ae/Middleware/SharedResources/Common/AckMessage.xsd", ">>AckMessage>Status");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessageStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.etisalat.ae/Middleware/SharedResources/Common/AckMessage.xsd", ">AckMessage");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.etisalat.ae/Middleware/SharedResources/Common/ApplicationHeader.xsd", ">ApplicationHeader");
            cachedSerQNames.add(qName);
            cls = ae.etisalat.www.Middleware.SharedResources.Common.ApplicationHeader_xsd.ApplicationHeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">>>>CheckEligibilityRequest>DataHeader>OrderItem>OfferID");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOfferID.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">>>>CheckEligibilityRequest>DataHeader>OrderItem>OrderInformation");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOrderInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">>>CheckEligibilityRequest>DataHeader>AdditionalInfo");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderAdditionalInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings2() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">>>CheckEligibilityRequest>DataHeader>OrderItem");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItem.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">>CheckEligibilityRequest>DataHeader");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">CheckEligibilityRequest");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">>>>CheckEligibilityResponse>ResponseData>ErrorList>AdditionalParameters");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataErrorListAdditionalParameters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">>>CheckEligibilityResponse>ResponseData>AdditionalInfo");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataAdditionalInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">>>CheckEligibilityResponse>ResponseData>ErrorList");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataErrorList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">>>CheckEligibilityResponse>ResponseData>OrderItemResponse");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataOrderItemResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">>CheckEligibilityResponse>ResponseData");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">>ErrorList>AdditionalParameters");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.ErrorListAdditionalParameters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">CheckEligibilityResponse");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">ErrorList");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.ErrorList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">>>>UpdateOrderStatusRequest>DataHeader>OrderItem>OfferID");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOfferID.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">>>>UpdateOrderStatusRequest>DataHeader>OrderItem>OrderInformation");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOrderInformation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">>>UpdateOrderStatusRequest>DataHeader>AdditionalInfo");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderAdditionalInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">>>UpdateOrderStatusRequest>DataHeader>OrderItem");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItem.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">>UpdateOrderStatusRequest>DataHeader");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">UpdateOrderStatusRequest");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusResponse.xsd", ">>UpdateOrderStatusResponse>ResponseData");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponseResponseData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusResponse.xsd", ">UpdateOrderStatusResponse");
            cachedSerQNames.add(qName);
            cls = com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope opInquiryNotification(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope inquiryNotificationRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent//OpInquiryNotification");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpInquiryNotification"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {inquiryNotificationRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._23.InquiryNotificationBOv1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope opQueryGFFNumbersList(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope queryGFFNumbersListRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpQueryGFFNumbersList");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpQueryGFFNumbersList"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {queryGFFNumbersListRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryGFFNumbersListV1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope opVerifyServiceOrderStatus(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope verifyServiceOrderStatusRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpVerifyServiceOrderStatus");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpVerifyServiceOrderStatus"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {verifyServiceOrderStatusRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyServiceOrderStatusV1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope opModifyService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope modifyServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpModifyService");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpModifyService"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {modifyServiceRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ModifyServiceV1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponse opUpdateOrderStatus(com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequest updateOrderStatusRequest) throws java.rmi.RemoteException, ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service-HTTPS.serviceagent//OpUpdateOrderStatus");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpUpdateOrderStatus"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {updateOrderStatusRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage) {
              throw (ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope opCheckEnoughBalance(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope checkEnoughBalanceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpCheckEnoughBalance");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpCheckEnoughBalance"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {checkEnoughBalanceRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckEnoughBalanceV1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope opOtherServicesBilling(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope otherServicesBillingRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpOtherServicesBilling");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpOtherServicesBilling"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {otherServicesBillingRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.OtherServicesBilling_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope opCancelService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope cancelServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpCancelService");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpCancelService"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cancelServiceRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CancelService_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope opQueryCustomerServiceDetails(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope queryCustomerServiceDetailsRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpQueryCustomerServiceDetails");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpQueryCustomerServiceDetails"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {queryCustomerServiceDetailsRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QueryCustomerServiceDetailsV1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope opViewPlan(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope viewPlanRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent//OpViewPlan");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpViewPlan"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {viewPlanRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.ViewPlanBOv1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope opMigrationStatusCheck(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope migrationStatusCheckRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent//OpMigrationStatusCheck");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpMigrationStatusCheck"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {migrationStatusCheckRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.MigrationStatusCheckBOv1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope opDetectFraudService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope detectFraudServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpDetectFraudService");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpDetectFraudService"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {detectFraudServiceRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.DetectFraudServiceV1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope opGetBlockedStatus(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope getBlockedStatusRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent//OpGetBlockedStatus");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpGetBlockedStatus"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {getBlockedStatusRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._10.GetBlockedStatusBOv1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope opBlackberryInquiry(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope blackberryInquiryRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpBlackberryInquiry");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpBlackberryInquiry"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {blackberryInquiryRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.BlackberryInquiryV1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope opEmcaisService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope emcaisServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpEmcaisService");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpEmcaisService"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {emcaisServiceRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.EmcaisServiceV1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope opVerifyComplaintStatus(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope verifyComplaintStatusRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent//OpVerifyComplaintStatus");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpVerifyComplaintStatus"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {verifyComplaintStatusRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.VerifyComplaintStatusV1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope opQuerySubscription(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope querySubscriptionRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpQuerySubscription");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpQuerySubscription"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {querySubscriptionRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope opCheckSubscription(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope checkSubscriptionRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[17]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpCheckSubscription");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpCheckSubscription"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {checkSubscriptionRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.CheckSubscriptionV1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope opGetFaultDockCrtCC(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope getFaultDockCrtCCRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[18]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent//OpGetFaultDockCrtCC");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpGetFaultDockCrtCC"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {getFaultDockCrtCCRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._07._11.GetFaultDockCrtCCBOv1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope opQuerySubscribedServicesList(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope querySubscribedServicesListRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[19]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpQuerySubscribedServicesList");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpQuerySubscribedServicesList"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {querySubscribedServicesListRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope opGetEvisionBilling(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope getEvisionBillingRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[20]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpGetEvisionBilling");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpGetEvisionBilling"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {getEvisionBillingRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.GetEvisionBillingV1_0_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponse opCheckEligibility(com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequest checkEligibilityRequest) throws java.rmi.RemoteException, ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[21]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service-HTTPS.serviceagent//OpCheckEligibility");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpCheckEligibility"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {checkEligibilityRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage) {
              throw (ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope opProvisionRequestedService(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope provisionRequestedServiceRequest) throws java.rmi.RemoteException, ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[22]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("/CustomerCare/Processes/BusinessAdapter/SelfCareService-service.serviceagent/SelfCareService-PortType/OpProvisionRequestedService");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "OpProvisionRequestedService"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {provisionRequestedServiceRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope) _resp;
            } catch (java.lang.Exception _exception) {
                return (ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope) org.apache.axis.utils.JavaUtils.convert(_resp, ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.ProvisionRequestedService_xsd.MessageEnvelope.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) {
              throw (ae.etisalat.FALCON.common.EMF._2011._12._05.MessageErrorV1_1_xsd.ErrorMsg) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

}
