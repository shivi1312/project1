/**
 * QuerySubscribedServicesListRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd;

public class QuerySubscribedServicesListRequest  implements java.io.Serializable {
    private java.lang.String msisdn;

    private ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.ChannelInformation channelInformation;

    private java.lang.String transaction_id;

    public QuerySubscribedServicesListRequest() {
    }

    public QuerySubscribedServicesListRequest(
           java.lang.String msisdn,
           ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.ChannelInformation channelInformation,
           java.lang.String transaction_id) {
           this.msisdn = msisdn;
           this.channelInformation = channelInformation;
           this.transaction_id = transaction_id;
    }


    /**
     * Gets the msisdn value for this QuerySubscribedServicesListRequest.
     * 
     * @return msisdn
     */
    public java.lang.String getMsisdn() {
        return msisdn;
    }


    /**
     * Sets the msisdn value for this QuerySubscribedServicesListRequest.
     * 
     * @param msisdn
     */
    public void setMsisdn(java.lang.String msisdn) {
        this.msisdn = msisdn;
    }


    /**
     * Gets the channelInformation value for this QuerySubscribedServicesListRequest.
     * 
     * @return channelInformation
     */
    public ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.ChannelInformation getChannelInformation() {
        return channelInformation;
    }


    /**
     * Sets the channelInformation value for this QuerySubscribedServicesListRequest.
     * 
     * @param channelInformation
     */
    public void setChannelInformation(ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscribedServicesListV1_0_xsd.ChannelInformation channelInformation) {
        this.channelInformation = channelInformation;
    }


    /**
     * Gets the transaction_id value for this QuerySubscribedServicesListRequest.
     * 
     * @return transaction_id
     */
    public java.lang.String getTransaction_id() {
        return transaction_id;
    }


    /**
     * Sets the transaction_id value for this QuerySubscribedServicesListRequest.
     * 
     * @param transaction_id
     */
    public void setTransaction_id(java.lang.String transaction_id) {
        this.transaction_id = transaction_id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QuerySubscribedServicesListRequest)) return false;
        QuerySubscribedServicesListRequest other = (QuerySubscribedServicesListRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.msisdn==null && other.getMsisdn()==null) || 
             (this.msisdn!=null &&
              this.msisdn.equals(other.getMsisdn()))) &&
            ((this.channelInformation==null && other.getChannelInformation()==null) || 
             (this.channelInformation!=null &&
              this.channelInformation.equals(other.getChannelInformation()))) &&
            ((this.transaction_id==null && other.getTransaction_id()==null) || 
             (this.transaction_id!=null &&
              this.transaction_id.equals(other.getTransaction_id())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMsisdn() != null) {
            _hashCode += getMsisdn().hashCode();
        }
        if (getChannelInformation() != null) {
            _hashCode += getChannelInformation().hashCode();
        }
        if (getTransaction_id() != null) {
            _hashCode += getTransaction_id().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QuerySubscribedServicesListRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "QuerySubscribedServicesListRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msisdn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "msisdn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("channelInformation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "channelInformation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", ">channelInformation"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transaction_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscribedServicesListV1.0.xsd", "transaction_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
