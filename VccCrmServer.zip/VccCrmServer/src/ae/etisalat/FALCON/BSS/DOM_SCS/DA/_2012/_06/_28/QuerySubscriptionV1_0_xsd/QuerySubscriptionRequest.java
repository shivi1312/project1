/**
 * QuerySubscriptionRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.BSS.DOM_SCS.DA._2012._06._28.QuerySubscriptionV1_0_xsd;

public class QuerySubscriptionRequest  implements java.io.Serializable {
    private java.lang.String transaction_id;

    private java.lang.String msisdn;

    private java.lang.String campaign_id;

    private java.lang.String esdpOfferId;

    private java.lang.String externalOfferId;

    private java.lang.String externalSubscriptionId;

    private java.lang.Integer retrieveOption;

    public QuerySubscriptionRequest() {
    }

    public QuerySubscriptionRequest(
           java.lang.String transaction_id,
           java.lang.String msisdn,
           java.lang.String campaign_id,
           java.lang.String esdpOfferId,
           java.lang.String externalOfferId,
           java.lang.String externalSubscriptionId,
           java.lang.Integer retrieveOption) {
           this.transaction_id = transaction_id;
           this.msisdn = msisdn;
           this.campaign_id = campaign_id;
           this.esdpOfferId = esdpOfferId;
           this.externalOfferId = externalOfferId;
           this.externalSubscriptionId = externalSubscriptionId;
           this.retrieveOption = retrieveOption;
    }


    /**
     * Gets the transaction_id value for this QuerySubscriptionRequest.
     * 
     * @return transaction_id
     */
    public java.lang.String getTransaction_id() {
        return transaction_id;
    }


    /**
     * Sets the transaction_id value for this QuerySubscriptionRequest.
     * 
     * @param transaction_id
     */
    public void setTransaction_id(java.lang.String transaction_id) {
        this.transaction_id = transaction_id;
    }


    /**
     * Gets the msisdn value for this QuerySubscriptionRequest.
     * 
     * @return msisdn
     */
    public java.lang.String getMsisdn() {
        return msisdn;
    }


    /**
     * Sets the msisdn value for this QuerySubscriptionRequest.
     * 
     * @param msisdn
     */
    public void setMsisdn(java.lang.String msisdn) {
        this.msisdn = msisdn;
    }


    /**
     * Gets the campaign_id value for this QuerySubscriptionRequest.
     * 
     * @return campaign_id
     */
    public java.lang.String getCampaign_id() {
        return campaign_id;
    }


    /**
     * Sets the campaign_id value for this QuerySubscriptionRequest.
     * 
     * @param campaign_id
     */
    public void setCampaign_id(java.lang.String campaign_id) {
        this.campaign_id = campaign_id;
    }


    /**
     * Gets the esdpOfferId value for this QuerySubscriptionRequest.
     * 
     * @return esdpOfferId
     */
    public java.lang.String getEsdpOfferId() {
        return esdpOfferId;
    }


    /**
     * Sets the esdpOfferId value for this QuerySubscriptionRequest.
     * 
     * @param esdpOfferId
     */
    public void setEsdpOfferId(java.lang.String esdpOfferId) {
        this.esdpOfferId = esdpOfferId;
    }


    /**
     * Gets the externalOfferId value for this QuerySubscriptionRequest.
     * 
     * @return externalOfferId
     */
    public java.lang.String getExternalOfferId() {
        return externalOfferId;
    }


    /**
     * Sets the externalOfferId value for this QuerySubscriptionRequest.
     * 
     * @param externalOfferId
     */
    public void setExternalOfferId(java.lang.String externalOfferId) {
        this.externalOfferId = externalOfferId;
    }


    /**
     * Gets the externalSubscriptionId value for this QuerySubscriptionRequest.
     * 
     * @return externalSubscriptionId
     */
    public java.lang.String getExternalSubscriptionId() {
        return externalSubscriptionId;
    }


    /**
     * Sets the externalSubscriptionId value for this QuerySubscriptionRequest.
     * 
     * @param externalSubscriptionId
     */
    public void setExternalSubscriptionId(java.lang.String externalSubscriptionId) {
        this.externalSubscriptionId = externalSubscriptionId;
    }


    /**
     * Gets the retrieveOption value for this QuerySubscriptionRequest.
     * 
     * @return retrieveOption
     */
    public java.lang.Integer getRetrieveOption() {
        return retrieveOption;
    }


    /**
     * Sets the retrieveOption value for this QuerySubscriptionRequest.
     * 
     * @param retrieveOption
     */
    public void setRetrieveOption(java.lang.Integer retrieveOption) {
        this.retrieveOption = retrieveOption;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QuerySubscriptionRequest)) return false;
        QuerySubscriptionRequest other = (QuerySubscriptionRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transaction_id==null && other.getTransaction_id()==null) || 
             (this.transaction_id!=null &&
              this.transaction_id.equals(other.getTransaction_id()))) &&
            ((this.msisdn==null && other.getMsisdn()==null) || 
             (this.msisdn!=null &&
              this.msisdn.equals(other.getMsisdn()))) &&
            ((this.campaign_id==null && other.getCampaign_id()==null) || 
             (this.campaign_id!=null &&
              this.campaign_id.equals(other.getCampaign_id()))) &&
            ((this.esdpOfferId==null && other.getEsdpOfferId()==null) || 
             (this.esdpOfferId!=null &&
              this.esdpOfferId.equals(other.getEsdpOfferId()))) &&
            ((this.externalOfferId==null && other.getExternalOfferId()==null) || 
             (this.externalOfferId!=null &&
              this.externalOfferId.equals(other.getExternalOfferId()))) &&
            ((this.externalSubscriptionId==null && other.getExternalSubscriptionId()==null) || 
             (this.externalSubscriptionId!=null &&
              this.externalSubscriptionId.equals(other.getExternalSubscriptionId()))) &&
            ((this.retrieveOption==null && other.getRetrieveOption()==null) || 
             (this.retrieveOption!=null &&
              this.retrieveOption.equals(other.getRetrieveOption())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransaction_id() != null) {
            _hashCode += getTransaction_id().hashCode();
        }
        if (getMsisdn() != null) {
            _hashCode += getMsisdn().hashCode();
        }
        if (getCampaign_id() != null) {
            _hashCode += getCampaign_id().hashCode();
        }
        if (getEsdpOfferId() != null) {
            _hashCode += getEsdpOfferId().hashCode();
        }
        if (getExternalOfferId() != null) {
            _hashCode += getExternalOfferId().hashCode();
        }
        if (getExternalSubscriptionId() != null) {
            _hashCode += getExternalSubscriptionId().hashCode();
        }
        if (getRetrieveOption() != null) {
            _hashCode += getRetrieveOption().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QuerySubscriptionRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "QuerySubscriptionRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transaction_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "transaction_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msisdn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "msisdn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("campaign_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "campaign_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("esdpOfferId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "esdpOfferId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("externalOfferId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "externalOfferId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("externalSubscriptionId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "externalSubscriptionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("retrieveOption");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/BSS/DOM_SCS/DA/2012/06/28/QuerySubscriptionV1.0.xsd", "retrieveOption"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
