/**
 * RetryDetail.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd;

public class RetryDetail  implements java.io.Serializable {
    /* Overall Timeout time. */
    private java.math.BigInteger overallTimeout;

    private ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.RetryDetailRetryParameters retryParameters;

    /* Retry Error Log 0 or 1 */
    private java.lang.Boolean retryErrorLog;

    /* Retry Error Log 0 or 1 */
    private ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.TargetSystems retryTargetSystem;

    public RetryDetail() {
    }

    public RetryDetail(
           java.math.BigInteger overallTimeout,
           ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.RetryDetailRetryParameters retryParameters,
           java.lang.Boolean retryErrorLog,
           ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.TargetSystems retryTargetSystem) {
           this.overallTimeout = overallTimeout;
           this.retryParameters = retryParameters;
           this.retryErrorLog = retryErrorLog;
           this.retryTargetSystem = retryTargetSystem;
    }


    /**
     * Gets the overallTimeout value for this RetryDetail.
     * 
     * @return overallTimeout   * Overall Timeout time.
     */
    public java.math.BigInteger getOverallTimeout() {
        return overallTimeout;
    }


    /**
     * Sets the overallTimeout value for this RetryDetail.
     * 
     * @param overallTimeout   * Overall Timeout time.
     */
    public void setOverallTimeout(java.math.BigInteger overallTimeout) {
        this.overallTimeout = overallTimeout;
    }


    /**
     * Gets the retryParameters value for this RetryDetail.
     * 
     * @return retryParameters
     */
    public ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.RetryDetailRetryParameters getRetryParameters() {
        return retryParameters;
    }


    /**
     * Sets the retryParameters value for this RetryDetail.
     * 
     * @param retryParameters
     */
    public void setRetryParameters(ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.RetryDetailRetryParameters retryParameters) {
        this.retryParameters = retryParameters;
    }


    /**
     * Gets the retryErrorLog value for this RetryDetail.
     * 
     * @return retryErrorLog   * Retry Error Log 0 or 1
     */
    public java.lang.Boolean getRetryErrorLog() {
        return retryErrorLog;
    }


    /**
     * Sets the retryErrorLog value for this RetryDetail.
     * 
     * @param retryErrorLog   * Retry Error Log 0 or 1
     */
    public void setRetryErrorLog(java.lang.Boolean retryErrorLog) {
        this.retryErrorLog = retryErrorLog;
    }


    /**
     * Gets the retryTargetSystem value for this RetryDetail.
     * 
     * @return retryTargetSystem   * Retry Error Log 0 or 1
     */
    public ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.TargetSystems getRetryTargetSystem() {
        return retryTargetSystem;
    }


    /**
     * Sets the retryTargetSystem value for this RetryDetail.
     * 
     * @param retryTargetSystem   * Retry Error Log 0 or 1
     */
    public void setRetryTargetSystem(ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.TargetSystems retryTargetSystem) {
        this.retryTargetSystem = retryTargetSystem;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RetryDetail)) return false;
        RetryDetail other = (RetryDetail) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.overallTimeout==null && other.getOverallTimeout()==null) || 
             (this.overallTimeout!=null &&
              this.overallTimeout.equals(other.getOverallTimeout()))) &&
            ((this.retryParameters==null && other.getRetryParameters()==null) || 
             (this.retryParameters!=null &&
              this.retryParameters.equals(other.getRetryParameters()))) &&
            ((this.retryErrorLog==null && other.getRetryErrorLog()==null) || 
             (this.retryErrorLog!=null &&
              this.retryErrorLog.equals(other.getRetryErrorLog()))) &&
            ((this.retryTargetSystem==null && other.getRetryTargetSystem()==null) || 
             (this.retryTargetSystem!=null &&
              this.retryTargetSystem.equals(other.getRetryTargetSystem())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOverallTimeout() != null) {
            _hashCode += getOverallTimeout().hashCode();
        }
        if (getRetryParameters() != null) {
            _hashCode += getRetryParameters().hashCode();
        }
        if (getRetryErrorLog() != null) {
            _hashCode += getRetryErrorLog().hashCode();
        }
        if (getRetryTargetSystem() != null) {
            _hashCode += getRetryTargetSystem().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RetryDetail.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2012/03/18/MessageRetryV1.0.xsd", "RetryDetail"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overallTimeout");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2012/03/18/MessageRetryV1.0.xsd", "OverallTimeout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("retryParameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2012/03/18/MessageRetryV1.0.xsd", "RetryParameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2012/03/18/MessageRetryV1.0.xsd", ">RetryDetail>RetryParameters"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("retryErrorLog");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2012/03/18/MessageRetryV1.0.xsd", "RetryErrorLog"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("retryTargetSystem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2012/03/18/MessageRetryV1.0.xsd", "RetryTargetSystem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2012/03/18/MessageRetryV1.0.xsd", "TargetSystems"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
