/**
 * TVersionInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd;

public class TVersionInfo  implements java.io.Serializable {
    private java.lang.String VName;

    private java.lang.String version;

    private java.lang.String VDate;

    private ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.VStatus VStatus;

    private java.lang.String VComment;

    private java.lang.String VOwner;

    public TVersionInfo() {
    }

    public TVersionInfo(
           java.lang.String VName,
           java.lang.String version,
           java.lang.String VDate,
           ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.VStatus VStatus,
           java.lang.String VComment,
           java.lang.String VOwner) {
           this.VName = VName;
           this.version = version;
           this.VDate = VDate;
           this.VStatus = VStatus;
           this.VComment = VComment;
           this.VOwner = VOwner;
    }


    /**
     * Gets the VName value for this TVersionInfo.
     * 
     * @return VName
     */
    public java.lang.String getVName() {
        return VName;
    }


    /**
     * Sets the VName value for this TVersionInfo.
     * 
     * @param VName
     */
    public void setVName(java.lang.String VName) {
        this.VName = VName;
    }


    /**
     * Gets the version value for this TVersionInfo.
     * 
     * @return version
     */
    public java.lang.String getVersion() {
        return version;
    }


    /**
     * Sets the version value for this TVersionInfo.
     * 
     * @param version
     */
    public void setVersion(java.lang.String version) {
        this.version = version;
    }


    /**
     * Gets the VDate value for this TVersionInfo.
     * 
     * @return VDate
     */
    public java.lang.String getVDate() {
        return VDate;
    }


    /**
     * Sets the VDate value for this TVersionInfo.
     * 
     * @param VDate
     */
    public void setVDate(java.lang.String VDate) {
        this.VDate = VDate;
    }


    /**
     * Gets the VStatus value for this TVersionInfo.
     * 
     * @return VStatus
     */
    public ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.VStatus getVStatus() {
        return VStatus;
    }


    /**
     * Sets the VStatus value for this TVersionInfo.
     * 
     * @param VStatus
     */
    public void setVStatus(ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.VStatus VStatus) {
        this.VStatus = VStatus;
    }


    /**
     * Gets the VComment value for this TVersionInfo.
     * 
     * @return VComment
     */
    public java.lang.String getVComment() {
        return VComment;
    }


    /**
     * Sets the VComment value for this TVersionInfo.
     * 
     * @param VComment
     */
    public void setVComment(java.lang.String VComment) {
        this.VComment = VComment;
    }


    /**
     * Gets the VOwner value for this TVersionInfo.
     * 
     * @return VOwner
     */
    public java.lang.String getVOwner() {
        return VOwner;
    }


    /**
     * Sets the VOwner value for this TVersionInfo.
     * 
     * @param VOwner
     */
    public void setVOwner(java.lang.String VOwner) {
        this.VOwner = VOwner;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TVersionInfo)) return false;
        TVersionInfo other = (TVersionInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.VName==null && other.getVName()==null) || 
             (this.VName!=null &&
              this.VName.equals(other.getVName()))) &&
            ((this.version==null && other.getVersion()==null) || 
             (this.version!=null &&
              this.version.equals(other.getVersion()))) &&
            ((this.VDate==null && other.getVDate()==null) || 
             (this.VDate!=null &&
              this.VDate.equals(other.getVDate()))) &&
            ((this.VStatus==null && other.getVStatus()==null) || 
             (this.VStatus!=null &&
              this.VStatus.equals(other.getVStatus()))) &&
            ((this.VComment==null && other.getVComment()==null) || 
             (this.VComment!=null &&
              this.VComment.equals(other.getVComment()))) &&
            ((this.VOwner==null && other.getVOwner()==null) || 
             (this.VOwner!=null &&
              this.VOwner.equals(other.getVOwner())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getVName() != null) {
            _hashCode += getVName().hashCode();
        }
        if (getVersion() != null) {
            _hashCode += getVersion().hashCode();
        }
        if (getVDate() != null) {
            _hashCode += getVDate().hashCode();
        }
        if (getVStatus() != null) {
            _hashCode += getVStatus().hashCode();
        }
        if (getVComment() != null) {
            _hashCode += getVComment().hashCode();
        }
        if (getVOwner() != null) {
            _hashCode += getVOwner().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TVersionInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tVersionInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "VName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("version");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "Version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", ">Version"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "VDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "VStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", ">VStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VComment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "VComment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VOwner");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "VOwner"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
