/**
 * TAction.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd;

public class TAction  implements java.io.Serializable {
    private ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.ActionType actionType;

    private java.lang.String sourceSystem;

    private java.lang.String sourceSystemTransactionId;

    private java.util.Calendar submitDateTime;

    private java.lang.String transactionId;

    public TAction() {
    }

    public TAction(
           ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.ActionType actionType,
           java.lang.String sourceSystem,
           java.lang.String sourceSystemTransactionId,
           java.util.Calendar submitDateTime,
           java.lang.String transactionId) {
           this.actionType = actionType;
           this.sourceSystem = sourceSystem;
           this.sourceSystemTransactionId = sourceSystemTransactionId;
           this.submitDateTime = submitDateTime;
           this.transactionId = transactionId;
    }


    /**
     * Gets the actionType value for this TAction.
     * 
     * @return actionType
     */
    public ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.ActionType getActionType() {
        return actionType;
    }


    /**
     * Sets the actionType value for this TAction.
     * 
     * @param actionType
     */
    public void setActionType(ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.ActionType actionType) {
        this.actionType = actionType;
    }


    /**
     * Gets the sourceSystem value for this TAction.
     * 
     * @return sourceSystem
     */
    public java.lang.String getSourceSystem() {
        return sourceSystem;
    }


    /**
     * Sets the sourceSystem value for this TAction.
     * 
     * @param sourceSystem
     */
    public void setSourceSystem(java.lang.String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }


    /**
     * Gets the sourceSystemTransactionId value for this TAction.
     * 
     * @return sourceSystemTransactionId
     */
    public java.lang.String getSourceSystemTransactionId() {
        return sourceSystemTransactionId;
    }


    /**
     * Sets the sourceSystemTransactionId value for this TAction.
     * 
     * @param sourceSystemTransactionId
     */
    public void setSourceSystemTransactionId(java.lang.String sourceSystemTransactionId) {
        this.sourceSystemTransactionId = sourceSystemTransactionId;
    }


    /**
     * Gets the submitDateTime value for this TAction.
     * 
     * @return submitDateTime
     */
    public java.util.Calendar getSubmitDateTime() {
        return submitDateTime;
    }


    /**
     * Sets the submitDateTime value for this TAction.
     * 
     * @param submitDateTime
     */
    public void setSubmitDateTime(java.util.Calendar submitDateTime) {
        this.submitDateTime = submitDateTime;
    }


    /**
     * Gets the transactionId value for this TAction.
     * 
     * @return transactionId
     */
    public java.lang.String getTransactionId() {
        return transactionId;
    }


    /**
     * Sets the transactionId value for this TAction.
     * 
     * @param transactionId
     */
    public void setTransactionId(java.lang.String transactionId) {
        this.transactionId = transactionId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TAction)) return false;
        TAction other = (TAction) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.actionType==null && other.getActionType()==null) || 
             (this.actionType!=null &&
              this.actionType.equals(other.getActionType()))) &&
            ((this.sourceSystem==null && other.getSourceSystem()==null) || 
             (this.sourceSystem!=null &&
              this.sourceSystem.equals(other.getSourceSystem()))) &&
            ((this.sourceSystemTransactionId==null && other.getSourceSystemTransactionId()==null) || 
             (this.sourceSystemTransactionId!=null &&
              this.sourceSystemTransactionId.equals(other.getSourceSystemTransactionId()))) &&
            ((this.submitDateTime==null && other.getSubmitDateTime()==null) || 
             (this.submitDateTime!=null &&
              this.submitDateTime.equals(other.getSubmitDateTime()))) &&
            ((this.transactionId==null && other.getTransactionId()==null) || 
             (this.transactionId!=null &&
              this.transactionId.equals(other.getTransactionId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getActionType() != null) {
            _hashCode += getActionType().hashCode();
        }
        if (getSourceSystem() != null) {
            _hashCode += getSourceSystem().hashCode();
        }
        if (getSourceSystemTransactionId() != null) {
            _hashCode += getSourceSystemTransactionId().hashCode();
        }
        if (getSubmitDateTime() != null) {
            _hashCode += getSubmitDateTime().hashCode();
        }
        if (getTransactionId() != null) {
            _hashCode += getTransactionId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TAction.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tAction"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("actionType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "ActionType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", ">ActionType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sourceSystem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "SourceSystem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sourceSystemTransactionId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "SourceSystemTransactionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("submitDateTime");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "SubmitDateTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "TransactionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
