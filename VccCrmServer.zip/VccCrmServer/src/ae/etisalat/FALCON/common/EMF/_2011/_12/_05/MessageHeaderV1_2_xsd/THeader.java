/**
 * THeader.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd;

public class THeader  implements java.io.Serializable {
    private ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TVersionInfo versionInfo;

    private ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TContext context;

    private ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TUserInfo userInfo;

    private ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.Action action;

    private ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TParameter[] parameterList;

    /* Parent element for entire schema. */
    private ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.RetryMsg messageRetry;

    public THeader() {
    }

    public THeader(
           ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TVersionInfo versionInfo,
           ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TContext context,
           ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TUserInfo userInfo,
           ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.Action action,
           ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TParameter[] parameterList,
           ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.RetryMsg messageRetry) {
           this.versionInfo = versionInfo;
           this.context = context;
           this.userInfo = userInfo;
           this.action = action;
           this.parameterList = parameterList;
           this.messageRetry = messageRetry;
    }


    /**
     * Gets the versionInfo value for this THeader.
     * 
     * @return versionInfo
     */
    public ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TVersionInfo getVersionInfo() {
        return versionInfo;
    }


    /**
     * Sets the versionInfo value for this THeader.
     * 
     * @param versionInfo
     */
    public void setVersionInfo(ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TVersionInfo versionInfo) {
        this.versionInfo = versionInfo;
    }


    /**
     * Gets the context value for this THeader.
     * 
     * @return context
     */
    public ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TContext getContext() {
        return context;
    }


    /**
     * Sets the context value for this THeader.
     * 
     * @param context
     */
    public void setContext(ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TContext context) {
        this.context = context;
    }


    /**
     * Gets the userInfo value for this THeader.
     * 
     * @return userInfo
     */
    public ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TUserInfo getUserInfo() {
        return userInfo;
    }


    /**
     * Sets the userInfo value for this THeader.
     * 
     * @param userInfo
     */
    public void setUserInfo(ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TUserInfo userInfo) {
        this.userInfo = userInfo;
    }


    /**
     * Gets the action value for this THeader.
     * 
     * @return action
     */
    public ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.Action getAction() {
        return action;
    }


    /**
     * Sets the action value for this THeader.
     * 
     * @param action
     */
    public void setAction(ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.Action action) {
        this.action = action;
    }


    /**
     * Gets the parameterList value for this THeader.
     * 
     * @return parameterList
     */
    public ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TParameter[] getParameterList() {
        return parameterList;
    }


    /**
     * Sets the parameterList value for this THeader.
     * 
     * @param parameterList
     */
    public void setParameterList(ae.etisalat.FALCON.common.EMF._2011._12._05.MessageHeaderV1_2_xsd.TParameter[] parameterList) {
        this.parameterList = parameterList;
    }


    /**
     * Gets the messageRetry value for this THeader.
     * 
     * @return messageRetry   * Parent element for entire schema.
     */
    public ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.RetryMsg getMessageRetry() {
        return messageRetry;
    }


    /**
     * Sets the messageRetry value for this THeader.
     * 
     * @param messageRetry   * Parent element for entire schema.
     */
    public void setMessageRetry(ae.etisalat.FALCON.common.EMF._2012._03._18.MessageRetryV1_0_xsd.RetryMsg messageRetry) {
        this.messageRetry = messageRetry;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof THeader)) return false;
        THeader other = (THeader) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.versionInfo==null && other.getVersionInfo()==null) || 
             (this.versionInfo!=null &&
              this.versionInfo.equals(other.getVersionInfo()))) &&
            ((this.context==null && other.getContext()==null) || 
             (this.context!=null &&
              this.context.equals(other.getContext()))) &&
            ((this.userInfo==null && other.getUserInfo()==null) || 
             (this.userInfo!=null &&
              this.userInfo.equals(other.getUserInfo()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.parameterList==null && other.getParameterList()==null) || 
             (this.parameterList!=null &&
              java.util.Arrays.equals(this.parameterList, other.getParameterList()))) &&
            ((this.messageRetry==null && other.getMessageRetry()==null) || 
             (this.messageRetry!=null &&
              this.messageRetry.equals(other.getMessageRetry())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getVersionInfo() != null) {
            _hashCode += getVersionInfo().hashCode();
        }
        if (getContext() != null) {
            _hashCode += getContext().hashCode();
        }
        if (getUserInfo() != null) {
            _hashCode += getUserInfo().hashCode();
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getParameterList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParameterList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParameterList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMessageRetry() != null) {
            _hashCode += getMessageRetry().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(THeader.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tHeader"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("versionInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "VersionInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tVersionInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("context");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "Context"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tContext"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "UserInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tUserInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("action");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "Action"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", ">Action"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parameterList");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "ParameterList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2011/12/05/MessageHeaderV1.2.xsd", "tDynamicParameterList"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageRetry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2012/03/18/MessageRetryV1.0.xsd", "MessageRetry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://etisalat.ae/FALCON/common/EMF/2012/03/18/MessageRetryV1.0.xsd", "RetryMsg"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
