/**
 * CheckEligibilityResponseResponseData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd;

public class CheckEligibilityResponseResponseData  implements java.io.Serializable {
    private java.lang.String transactionID;

    private java.lang.String responseCode;

    private java.lang.String responseDescription;

    private com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataOrderItemResponse[] orderItemResponse;

    private com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataErrorList[] errorList;

    private com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataAdditionalInfo[] additionalInfo;

    public CheckEligibilityResponseResponseData() {
    }

    public CheckEligibilityResponseResponseData(
           java.lang.String transactionID,
           java.lang.String responseCode,
           java.lang.String responseDescription,
           com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataOrderItemResponse[] orderItemResponse,
           com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataErrorList[] errorList,
           com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataAdditionalInfo[] additionalInfo) {
           this.transactionID = transactionID;
           this.responseCode = responseCode;
           this.responseDescription = responseDescription;
           this.orderItemResponse = orderItemResponse;
           this.errorList = errorList;
           this.additionalInfo = additionalInfo;
    }


    /**
     * Gets the transactionID value for this CheckEligibilityResponseResponseData.
     * 
     * @return transactionID
     */
    public java.lang.String getTransactionID() {
        return transactionID;
    }


    /**
     * Sets the transactionID value for this CheckEligibilityResponseResponseData.
     * 
     * @param transactionID
     */
    public void setTransactionID(java.lang.String transactionID) {
        this.transactionID = transactionID;
    }


    /**
     * Gets the responseCode value for this CheckEligibilityResponseResponseData.
     * 
     * @return responseCode
     */
    public java.lang.String getResponseCode() {
        return responseCode;
    }


    /**
     * Sets the responseCode value for this CheckEligibilityResponseResponseData.
     * 
     * @param responseCode
     */
    public void setResponseCode(java.lang.String responseCode) {
        this.responseCode = responseCode;
    }


    /**
     * Gets the responseDescription value for this CheckEligibilityResponseResponseData.
     * 
     * @return responseDescription
     */
    public java.lang.String getResponseDescription() {
        return responseDescription;
    }


    /**
     * Sets the responseDescription value for this CheckEligibilityResponseResponseData.
     * 
     * @param responseDescription
     */
    public void setResponseDescription(java.lang.String responseDescription) {
        this.responseDescription = responseDescription;
    }


    /**
     * Gets the orderItemResponse value for this CheckEligibilityResponseResponseData.
     * 
     * @return orderItemResponse
     */
    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataOrderItemResponse[] getOrderItemResponse() {
        return orderItemResponse;
    }


    /**
     * Sets the orderItemResponse value for this CheckEligibilityResponseResponseData.
     * 
     * @param orderItemResponse
     */
    public void setOrderItemResponse(com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataOrderItemResponse[] orderItemResponse) {
        this.orderItemResponse = orderItemResponse;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataOrderItemResponse getOrderItemResponse(int i) {
        return this.orderItemResponse[i];
    }

    public void setOrderItemResponse(int i, com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataOrderItemResponse _value) {
        this.orderItemResponse[i] = _value;
    }


    /**
     * Gets the errorList value for this CheckEligibilityResponseResponseData.
     * 
     * @return errorList
     */
    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataErrorList[] getErrorList() {
        return errorList;
    }


    /**
     * Sets the errorList value for this CheckEligibilityResponseResponseData.
     * 
     * @param errorList
     */
    public void setErrorList(com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataErrorList[] errorList) {
        this.errorList = errorList;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataErrorList getErrorList(int i) {
        return this.errorList[i];
    }

    public void setErrorList(int i, com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataErrorList _value) {
        this.errorList[i] = _value;
    }


    /**
     * Gets the additionalInfo value for this CheckEligibilityResponseResponseData.
     * 
     * @return additionalInfo
     */
    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataAdditionalInfo[] getAdditionalInfo() {
        return additionalInfo;
    }


    /**
     * Sets the additionalInfo value for this CheckEligibilityResponseResponseData.
     * 
     * @param additionalInfo
     */
    public void setAdditionalInfo(com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataAdditionalInfo[] additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataAdditionalInfo getAdditionalInfo(int i) {
        return this.additionalInfo[i];
    }

    public void setAdditionalInfo(int i, com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.CheckEligibilityResponseResponseDataAdditionalInfo _value) {
        this.additionalInfo[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CheckEligibilityResponseResponseData)) return false;
        CheckEligibilityResponseResponseData other = (CheckEligibilityResponseResponseData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transactionID==null && other.getTransactionID()==null) || 
             (this.transactionID!=null &&
              this.transactionID.equals(other.getTransactionID()))) &&
            ((this.responseCode==null && other.getResponseCode()==null) || 
             (this.responseCode!=null &&
              this.responseCode.equals(other.getResponseCode()))) &&
            ((this.responseDescription==null && other.getResponseDescription()==null) || 
             (this.responseDescription!=null &&
              this.responseDescription.equals(other.getResponseDescription()))) &&
            ((this.orderItemResponse==null && other.getOrderItemResponse()==null) || 
             (this.orderItemResponse!=null &&
              java.util.Arrays.equals(this.orderItemResponse, other.getOrderItemResponse()))) &&
            ((this.errorList==null && other.getErrorList()==null) || 
             (this.errorList!=null &&
              java.util.Arrays.equals(this.errorList, other.getErrorList()))) &&
            ((this.additionalInfo==null && other.getAdditionalInfo()==null) || 
             (this.additionalInfo!=null &&
              java.util.Arrays.equals(this.additionalInfo, other.getAdditionalInfo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransactionID() != null) {
            _hashCode += getTransactionID().hashCode();
        }
        if (getResponseCode() != null) {
            _hashCode += getResponseCode().hashCode();
        }
        if (getResponseDescription() != null) {
            _hashCode += getResponseDescription().hashCode();
        }
        if (getOrderItemResponse() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderItemResponse());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderItemResponse(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getErrorList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getErrorList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getErrorList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAdditionalInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAdditionalInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAdditionalInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CheckEligibilityResponseResponseData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">>CheckEligibilityResponse>ResponseData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", "TransactionID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("responseCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", "ResponseCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("responseDescription");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", "ResponseDescription"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderItemResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", "OrderItemResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">>>CheckEligibilityResponse>ResponseData>OrderItemResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errorList");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", "ErrorList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">>>CheckEligibilityResponse>ResponseData>ErrorList"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("additionalInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", "AdditionalInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">>>CheckEligibilityResponse>ResponseData>AdditionalInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
