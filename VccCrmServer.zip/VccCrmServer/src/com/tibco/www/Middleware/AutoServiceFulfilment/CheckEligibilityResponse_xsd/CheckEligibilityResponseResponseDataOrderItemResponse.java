/**
 * CheckEligibilityResponseResponseDataOrderItemResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd;

public class CheckEligibilityResponseResponseDataOrderItemResponse  implements java.io.Serializable {
    private java.lang.String accountNumber;

    private long orderItemNumber;

    private long demandID;

    private com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.ErrorList[] errorList;

    public CheckEligibilityResponseResponseDataOrderItemResponse() {
    }

    public CheckEligibilityResponseResponseDataOrderItemResponse(
           java.lang.String accountNumber,
           long orderItemNumber,
           long demandID,
           com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.ErrorList[] errorList) {
           this.accountNumber = accountNumber;
           this.orderItemNumber = orderItemNumber;
           this.demandID = demandID;
           this.errorList = errorList;
    }


    /**
     * Gets the accountNumber value for this CheckEligibilityResponseResponseDataOrderItemResponse.
     * 
     * @return accountNumber
     */
    public java.lang.String getAccountNumber() {
        return accountNumber;
    }


    /**
     * Sets the accountNumber value for this CheckEligibilityResponseResponseDataOrderItemResponse.
     * 
     * @param accountNumber
     */
    public void setAccountNumber(java.lang.String accountNumber) {
        this.accountNumber = accountNumber;
    }


    /**
     * Gets the orderItemNumber value for this CheckEligibilityResponseResponseDataOrderItemResponse.
     * 
     * @return orderItemNumber
     */
    public long getOrderItemNumber() {
        return orderItemNumber;
    }


    /**
     * Sets the orderItemNumber value for this CheckEligibilityResponseResponseDataOrderItemResponse.
     * 
     * @param orderItemNumber
     */
    public void setOrderItemNumber(long orderItemNumber) {
        this.orderItemNumber = orderItemNumber;
    }


    /**
     * Gets the demandID value for this CheckEligibilityResponseResponseDataOrderItemResponse.
     * 
     * @return demandID
     */
    public long getDemandID() {
        return demandID;
    }


    /**
     * Sets the demandID value for this CheckEligibilityResponseResponseDataOrderItemResponse.
     * 
     * @param demandID
     */
    public void setDemandID(long demandID) {
        this.demandID = demandID;
    }


    /**
     * Gets the errorList value for this CheckEligibilityResponseResponseDataOrderItemResponse.
     * 
     * @return errorList
     */
    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.ErrorList[] getErrorList() {
        return errorList;
    }


    /**
     * Sets the errorList value for this CheckEligibilityResponseResponseDataOrderItemResponse.
     * 
     * @param errorList
     */
    public void setErrorList(com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.ErrorList[] errorList) {
        this.errorList = errorList;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.ErrorList getErrorList(int i) {
        return this.errorList[i];
    }

    public void setErrorList(int i, com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityResponse_xsd.ErrorList _value) {
        this.errorList[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CheckEligibilityResponseResponseDataOrderItemResponse)) return false;
        CheckEligibilityResponseResponseDataOrderItemResponse other = (CheckEligibilityResponseResponseDataOrderItemResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.accountNumber==null && other.getAccountNumber()==null) || 
             (this.accountNumber!=null &&
              this.accountNumber.equals(other.getAccountNumber()))) &&
            this.orderItemNumber == other.getOrderItemNumber() &&
            this.demandID == other.getDemandID() &&
            ((this.errorList==null && other.getErrorList()==null) || 
             (this.errorList!=null &&
              java.util.Arrays.equals(this.errorList, other.getErrorList())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAccountNumber() != null) {
            _hashCode += getAccountNumber().hashCode();
        }
        _hashCode += new Long(getOrderItemNumber()).hashCode();
        _hashCode += new Long(getDemandID()).hashCode();
        if (getErrorList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getErrorList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getErrorList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CheckEligibilityResponseResponseDataOrderItemResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", ">>>CheckEligibilityResponse>ResponseData>OrderItemResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", "AccountNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderItemNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", "OrderItemNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("demandID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", "DemandID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errorList");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", "ErrorList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityResponse.xsd", "ErrorList"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
