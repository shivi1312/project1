/**
 * CheckEligibilityRequestDataHeaderOrderItem.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd;

public class CheckEligibilityRequestDataHeaderOrderItem  implements java.io.Serializable {
    private java.lang.String actionType;

    private java.lang.String accountNumber;

    private int parentOrderNumber;

    private int orderItemNumber;

    private com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOfferID[] offerID;

    private com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOrderInformation[] orderInformation;

    public CheckEligibilityRequestDataHeaderOrderItem() {
    }

    public CheckEligibilityRequestDataHeaderOrderItem(
           java.lang.String actionType,
           java.lang.String accountNumber,
           int parentOrderNumber,
           int orderItemNumber,
           com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOfferID[] offerID,
           com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOrderInformation[] orderInformation) {
           this.actionType = actionType;
           this.accountNumber = accountNumber;
           this.parentOrderNumber = parentOrderNumber;
           this.orderItemNumber = orderItemNumber;
           this.offerID = offerID;
           this.orderInformation = orderInformation;
    }


    /**
     * Gets the actionType value for this CheckEligibilityRequestDataHeaderOrderItem.
     * 
     * @return actionType
     */
    public java.lang.String getActionType() {
        return actionType;
    }


    /**
     * Sets the actionType value for this CheckEligibilityRequestDataHeaderOrderItem.
     * 
     * @param actionType
     */
    public void setActionType(java.lang.String actionType) {
        this.actionType = actionType;
    }


    /**
     * Gets the accountNumber value for this CheckEligibilityRequestDataHeaderOrderItem.
     * 
     * @return accountNumber
     */
    public java.lang.String getAccountNumber() {
        return accountNumber;
    }


    /**
     * Sets the accountNumber value for this CheckEligibilityRequestDataHeaderOrderItem.
     * 
     * @param accountNumber
     */
    public void setAccountNumber(java.lang.String accountNumber) {
        this.accountNumber = accountNumber;
    }


    /**
     * Gets the parentOrderNumber value for this CheckEligibilityRequestDataHeaderOrderItem.
     * 
     * @return parentOrderNumber
     */
    public int getParentOrderNumber() {
        return parentOrderNumber;
    }


    /**
     * Sets the parentOrderNumber value for this CheckEligibilityRequestDataHeaderOrderItem.
     * 
     * @param parentOrderNumber
     */
    public void setParentOrderNumber(int parentOrderNumber) {
        this.parentOrderNumber = parentOrderNumber;
    }


    /**
     * Gets the orderItemNumber value for this CheckEligibilityRequestDataHeaderOrderItem.
     * 
     * @return orderItemNumber
     */
    public int getOrderItemNumber() {
        return orderItemNumber;
    }


    /**
     * Sets the orderItemNumber value for this CheckEligibilityRequestDataHeaderOrderItem.
     * 
     * @param orderItemNumber
     */
    public void setOrderItemNumber(int orderItemNumber) {
        this.orderItemNumber = orderItemNumber;
    }


    /**
     * Gets the offerID value for this CheckEligibilityRequestDataHeaderOrderItem.
     * 
     * @return offerID
     */
    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOfferID[] getOfferID() {
        return offerID;
    }


    /**
     * Sets the offerID value for this CheckEligibilityRequestDataHeaderOrderItem.
     * 
     * @param offerID
     */
    public void setOfferID(com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOfferID[] offerID) {
        this.offerID = offerID;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOfferID getOfferID(int i) {
        return this.offerID[i];
    }

    public void setOfferID(int i, com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOfferID _value) {
        this.offerID[i] = _value;
    }


    /**
     * Gets the orderInformation value for this CheckEligibilityRequestDataHeaderOrderItem.
     * 
     * @return orderInformation
     */
    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOrderInformation[] getOrderInformation() {
        return orderInformation;
    }


    /**
     * Sets the orderInformation value for this CheckEligibilityRequestDataHeaderOrderItem.
     * 
     * @param orderInformation
     */
    public void setOrderInformation(com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOrderInformation[] orderInformation) {
        this.orderInformation = orderInformation;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOrderInformation getOrderInformation(int i) {
        return this.orderInformation[i];
    }

    public void setOrderInformation(int i, com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItemOrderInformation _value) {
        this.orderInformation[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CheckEligibilityRequestDataHeaderOrderItem)) return false;
        CheckEligibilityRequestDataHeaderOrderItem other = (CheckEligibilityRequestDataHeaderOrderItem) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.actionType==null && other.getActionType()==null) || 
             (this.actionType!=null &&
              this.actionType.equals(other.getActionType()))) &&
            ((this.accountNumber==null && other.getAccountNumber()==null) || 
             (this.accountNumber!=null &&
              this.accountNumber.equals(other.getAccountNumber()))) &&
            this.parentOrderNumber == other.getParentOrderNumber() &&
            this.orderItemNumber == other.getOrderItemNumber() &&
            ((this.offerID==null && other.getOfferID()==null) || 
             (this.offerID!=null &&
              java.util.Arrays.equals(this.offerID, other.getOfferID()))) &&
            ((this.orderInformation==null && other.getOrderInformation()==null) || 
             (this.orderInformation!=null &&
              java.util.Arrays.equals(this.orderInformation, other.getOrderInformation())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getActionType() != null) {
            _hashCode += getActionType().hashCode();
        }
        if (getAccountNumber() != null) {
            _hashCode += getAccountNumber().hashCode();
        }
        _hashCode += getParentOrderNumber();
        _hashCode += getOrderItemNumber();
        if (getOfferID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOfferID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOfferID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOrderInformation() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderInformation());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderInformation(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CheckEligibilityRequestDataHeaderOrderItem.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">>>CheckEligibilityRequest>DataHeader>OrderItem"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("actionType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "ActionType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "AccountNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parentOrderNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "ParentOrderNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderItemNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "OrderItemNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offerID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "OfferID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">>>>CheckEligibilityRequest>DataHeader>OrderItem>OfferID"));
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderInformation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "OrderInformation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">>>>CheckEligibilityRequest>DataHeader>OrderItem>OrderInformation"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
