/**
 * UpdateOrderStatusRequestDataHeader.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd;

public class UpdateOrderStatusRequestDataHeader  implements java.io.Serializable {
    private com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItem[] orderItem;

    private com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderAdditionalInfo[] additionalInfo;

    public UpdateOrderStatusRequestDataHeader() {
    }

    public UpdateOrderStatusRequestDataHeader(
           com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItem[] orderItem,
           com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderAdditionalInfo[] additionalInfo) {
           this.orderItem = orderItem;
           this.additionalInfo = additionalInfo;
    }


    /**
     * Gets the orderItem value for this UpdateOrderStatusRequestDataHeader.
     * 
     * @return orderItem
     */
    public com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItem[] getOrderItem() {
        return orderItem;
    }


    /**
     * Sets the orderItem value for this UpdateOrderStatusRequestDataHeader.
     * 
     * @param orderItem
     */
    public void setOrderItem(com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItem[] orderItem) {
        this.orderItem = orderItem;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItem getOrderItem(int i) {
        return this.orderItem[i];
    }

    public void setOrderItem(int i, com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItem _value) {
        this.orderItem[i] = _value;
    }


    /**
     * Gets the additionalInfo value for this UpdateOrderStatusRequestDataHeader.
     * 
     * @return additionalInfo
     */
    public com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderAdditionalInfo[] getAdditionalInfo() {
        return additionalInfo;
    }


    /**
     * Sets the additionalInfo value for this UpdateOrderStatusRequestDataHeader.
     * 
     * @param additionalInfo
     */
    public void setAdditionalInfo(com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderAdditionalInfo[] additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderAdditionalInfo getAdditionalInfo(int i) {
        return this.additionalInfo[i];
    }

    public void setAdditionalInfo(int i, com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderAdditionalInfo _value) {
        this.additionalInfo[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof UpdateOrderStatusRequestDataHeader)) return false;
        UpdateOrderStatusRequestDataHeader other = (UpdateOrderStatusRequestDataHeader) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderItem==null && other.getOrderItem()==null) || 
             (this.orderItem!=null &&
              java.util.Arrays.equals(this.orderItem, other.getOrderItem()))) &&
            ((this.additionalInfo==null && other.getAdditionalInfo()==null) || 
             (this.additionalInfo!=null &&
              java.util.Arrays.equals(this.additionalInfo, other.getAdditionalInfo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderItem() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderItem());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderItem(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAdditionalInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAdditionalInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAdditionalInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(UpdateOrderStatusRequestDataHeader.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">>UpdateOrderStatusRequest>DataHeader"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderItem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", "OrderItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">>>UpdateOrderStatusRequest>DataHeader>OrderItem"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("additionalInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", "AdditionalInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">>>UpdateOrderStatusRequest>DataHeader>AdditionalInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
