/**
 * CheckEligibilityRequestDataHeader.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd;

public class CheckEligibilityRequestDataHeader  implements java.io.Serializable {
    private java.lang.String channel;

    private java.lang.String subChannel;

    private java.lang.String receivedTime;

    private java.lang.String language;

    private com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItem[] orderItem;

    private com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderAdditionalInfo[] additionalInfo;

    public CheckEligibilityRequestDataHeader() {
    }

    public CheckEligibilityRequestDataHeader(
           java.lang.String channel,
           java.lang.String subChannel,
           java.lang.String receivedTime,
           java.lang.String language,
           com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItem[] orderItem,
           com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderAdditionalInfo[] additionalInfo) {
           this.channel = channel;
           this.subChannel = subChannel;
           this.receivedTime = receivedTime;
           this.language = language;
           this.orderItem = orderItem;
           this.additionalInfo = additionalInfo;
    }


    /**
     * Gets the channel value for this CheckEligibilityRequestDataHeader.
     * 
     * @return channel
     */
    public java.lang.String getChannel() {
        return channel;
    }


    /**
     * Sets the channel value for this CheckEligibilityRequestDataHeader.
     * 
     * @param channel
     */
    public void setChannel(java.lang.String channel) {
        this.channel = channel;
    }


    /**
     * Gets the subChannel value for this CheckEligibilityRequestDataHeader.
     * 
     * @return subChannel
     */
    public java.lang.String getSubChannel() {
        return subChannel;
    }


    /**
     * Sets the subChannel value for this CheckEligibilityRequestDataHeader.
     * 
     * @param subChannel
     */
    public void setSubChannel(java.lang.String subChannel) {
        this.subChannel = subChannel;
    }


    /**
     * Gets the receivedTime value for this CheckEligibilityRequestDataHeader.
     * 
     * @return receivedTime
     */
    public java.lang.String getReceivedTime() {
        return receivedTime;
    }


    /**
     * Sets the receivedTime value for this CheckEligibilityRequestDataHeader.
     * 
     * @param receivedTime
     */
    public void setReceivedTime(java.lang.String receivedTime) {
        this.receivedTime = receivedTime;
    }


    /**
     * Gets the language value for this CheckEligibilityRequestDataHeader.
     * 
     * @return language
     */
    public java.lang.String getLanguage() {
        return language;
    }


    /**
     * Sets the language value for this CheckEligibilityRequestDataHeader.
     * 
     * @param language
     */
    public void setLanguage(java.lang.String language) {
        this.language = language;
    }


    /**
     * Gets the orderItem value for this CheckEligibilityRequestDataHeader.
     * 
     * @return orderItem
     */
    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItem[] getOrderItem() {
        return orderItem;
    }


    /**
     * Sets the orderItem value for this CheckEligibilityRequestDataHeader.
     * 
     * @param orderItem
     */
    public void setOrderItem(com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItem[] orderItem) {
        this.orderItem = orderItem;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItem getOrderItem(int i) {
        return this.orderItem[i];
    }

    public void setOrderItem(int i, com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderOrderItem _value) {
        this.orderItem[i] = _value;
    }


    /**
     * Gets the additionalInfo value for this CheckEligibilityRequestDataHeader.
     * 
     * @return additionalInfo
     */
    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderAdditionalInfo[] getAdditionalInfo() {
        return additionalInfo;
    }


    /**
     * Sets the additionalInfo value for this CheckEligibilityRequestDataHeader.
     * 
     * @param additionalInfo
     */
    public void setAdditionalInfo(com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderAdditionalInfo[] additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderAdditionalInfo getAdditionalInfo(int i) {
        return this.additionalInfo[i];
    }

    public void setAdditionalInfo(int i, com.tibco.www.Middleware.AutoServiceFulfilment.CheckEligibilityRequest_xsd.CheckEligibilityRequestDataHeaderAdditionalInfo _value) {
        this.additionalInfo[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CheckEligibilityRequestDataHeader)) return false;
        CheckEligibilityRequestDataHeader other = (CheckEligibilityRequestDataHeader) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.channel==null && other.getChannel()==null) || 
             (this.channel!=null &&
              this.channel.equals(other.getChannel()))) &&
            ((this.subChannel==null && other.getSubChannel()==null) || 
             (this.subChannel!=null &&
              this.subChannel.equals(other.getSubChannel()))) &&
            ((this.receivedTime==null && other.getReceivedTime()==null) || 
             (this.receivedTime!=null &&
              this.receivedTime.equals(other.getReceivedTime()))) &&
            ((this.language==null && other.getLanguage()==null) || 
             (this.language!=null &&
              this.language.equals(other.getLanguage()))) &&
            ((this.orderItem==null && other.getOrderItem()==null) || 
             (this.orderItem!=null &&
              java.util.Arrays.equals(this.orderItem, other.getOrderItem()))) &&
            ((this.additionalInfo==null && other.getAdditionalInfo()==null) || 
             (this.additionalInfo!=null &&
              java.util.Arrays.equals(this.additionalInfo, other.getAdditionalInfo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getChannel() != null) {
            _hashCode += getChannel().hashCode();
        }
        if (getSubChannel() != null) {
            _hashCode += getSubChannel().hashCode();
        }
        if (getReceivedTime() != null) {
            _hashCode += getReceivedTime().hashCode();
        }
        if (getLanguage() != null) {
            _hashCode += getLanguage().hashCode();
        }
        if (getOrderItem() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderItem());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderItem(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAdditionalInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAdditionalInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAdditionalInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CheckEligibilityRequestDataHeader.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">>CheckEligibilityRequest>DataHeader"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("channel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "Channel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subChannel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "SubChannel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("receivedTime");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "ReceivedTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("language");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "Language"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderItem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "OrderItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">>>CheckEligibilityRequest>DataHeader>OrderItem"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("additionalInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", "AdditionalInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/CheckEligibilityRequest.xsd", ">>>CheckEligibilityRequest>DataHeader>AdditionalInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
