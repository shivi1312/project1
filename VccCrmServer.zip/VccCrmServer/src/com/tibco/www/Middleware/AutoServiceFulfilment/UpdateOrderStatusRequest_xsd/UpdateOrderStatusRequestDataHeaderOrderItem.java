/**
 * UpdateOrderStatusRequestDataHeaderOrderItem.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd;

public class UpdateOrderStatusRequestDataHeaderOrderItem  implements java.io.Serializable {
    private java.lang.String accountNumber;

    private java.lang.String status;

    private java.lang.String subRequestId;

    private com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOfferID[] offerID;

    private com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOrderInformation[] orderInformation;

    public UpdateOrderStatusRequestDataHeaderOrderItem() {
    }

    public UpdateOrderStatusRequestDataHeaderOrderItem(
           java.lang.String accountNumber,
           java.lang.String status,
           java.lang.String subRequestId,
           com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOfferID[] offerID,
           com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOrderInformation[] orderInformation) {
           this.accountNumber = accountNumber;
           this.status = status;
           this.subRequestId = subRequestId;
           this.offerID = offerID;
           this.orderInformation = orderInformation;
    }


    /**
     * Gets the accountNumber value for this UpdateOrderStatusRequestDataHeaderOrderItem.
     * 
     * @return accountNumber
     */
    public java.lang.String getAccountNumber() {
        return accountNumber;
    }


    /**
     * Sets the accountNumber value for this UpdateOrderStatusRequestDataHeaderOrderItem.
     * 
     * @param accountNumber
     */
    public void setAccountNumber(java.lang.String accountNumber) {
        this.accountNumber = accountNumber;
    }


    /**
     * Gets the status value for this UpdateOrderStatusRequestDataHeaderOrderItem.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this UpdateOrderStatusRequestDataHeaderOrderItem.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the subRequestId value for this UpdateOrderStatusRequestDataHeaderOrderItem.
     * 
     * @return subRequestId
     */
    public java.lang.String getSubRequestId() {
        return subRequestId;
    }


    /**
     * Sets the subRequestId value for this UpdateOrderStatusRequestDataHeaderOrderItem.
     * 
     * @param subRequestId
     */
    public void setSubRequestId(java.lang.String subRequestId) {
        this.subRequestId = subRequestId;
    }


    /**
     * Gets the offerID value for this UpdateOrderStatusRequestDataHeaderOrderItem.
     * 
     * @return offerID
     */
    public com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOfferID[] getOfferID() {
        return offerID;
    }


    /**
     * Sets the offerID value for this UpdateOrderStatusRequestDataHeaderOrderItem.
     * 
     * @param offerID
     */
    public void setOfferID(com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOfferID[] offerID) {
        this.offerID = offerID;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOfferID getOfferID(int i) {
        return this.offerID[i];
    }

    public void setOfferID(int i, com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOfferID _value) {
        this.offerID[i] = _value;
    }


    /**
     * Gets the orderInformation value for this UpdateOrderStatusRequestDataHeaderOrderItem.
     * 
     * @return orderInformation
     */
    public com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOrderInformation[] getOrderInformation() {
        return orderInformation;
    }


    /**
     * Sets the orderInformation value for this UpdateOrderStatusRequestDataHeaderOrderItem.
     * 
     * @param orderInformation
     */
    public void setOrderInformation(com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOrderInformation[] orderInformation) {
        this.orderInformation = orderInformation;
    }

    public com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOrderInformation getOrderInformation(int i) {
        return this.orderInformation[i];
    }

    public void setOrderInformation(int i, com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOrderInformation _value) {
        this.orderInformation[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof UpdateOrderStatusRequestDataHeaderOrderItem)) return false;
        UpdateOrderStatusRequestDataHeaderOrderItem other = (UpdateOrderStatusRequestDataHeaderOrderItem) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.accountNumber==null && other.getAccountNumber()==null) || 
             (this.accountNumber!=null &&
              this.accountNumber.equals(other.getAccountNumber()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.subRequestId==null && other.getSubRequestId()==null) || 
             (this.subRequestId!=null &&
              this.subRequestId.equals(other.getSubRequestId()))) &&
            ((this.offerID==null && other.getOfferID()==null) || 
             (this.offerID!=null &&
              java.util.Arrays.equals(this.offerID, other.getOfferID()))) &&
            ((this.orderInformation==null && other.getOrderInformation()==null) || 
             (this.orderInformation!=null &&
              java.util.Arrays.equals(this.orderInformation, other.getOrderInformation())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAccountNumber() != null) {
            _hashCode += getAccountNumber().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getSubRequestId() != null) {
            _hashCode += getSubRequestId().hashCode();
        }
        if (getOfferID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOfferID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOfferID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOrderInformation() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderInformation());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderInformation(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(UpdateOrderStatusRequestDataHeaderOrderItem.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">>>UpdateOrderStatusRequest>DataHeader>OrderItem"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", "AccountNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subRequestId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", "SubRequestId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offerID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", "OfferID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">>>>UpdateOrderStatusRequest>DataHeader>OrderItem>OfferID"));
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderInformation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", "OrderInformation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.tibco.com/Middleware/AutoServiceFulfilment/UpdateOrderStatusRequest.xsd", ">>>>UpdateOrderStatusRequest>DataHeader>OrderItem>OrderInformation"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
