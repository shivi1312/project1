package com.vcc.telemune.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

public class CallbackPickerWorker implements Runnable {
	private volatile boolean callbackPickerRunning = true;
	final static Logger logger = Logger.getLogger(CallbackPickerWorker.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private MsgConfig config;
	private CallbackService callback = new CallbackService();

	public CallbackPickerWorker(MsgConfig config) {
		this.config = config;
	}

	@Override
	public void run() {
		while (callbackPickerRunning) {
			try {
				logger.info("Check if msg pick: "
						+ config.getPick()
						+ " select query run interval: "
						+ AppConfig.config
								.getInt("SELECT_QUERY_INTERVAL", 5000));
				if (config.getPick()) {
					config.setPick(false);
					this.callbackProcessing();
				}
				Thread.sleep(AppConfig.config.getInt("SELECT_QUERY_INTERVAL",
						5000));
			} catch (Exception e) {
				errorLogger.error("ErrorCode ["
						+ AppConfig.config.getString("errorcode_pattern",
								"VCC-CRMS-")
						+ "00003] [Exception while Picking CallBack] Error[ "
						+ e.getMessage() + "]");
				e.printStackTrace();
			}
		}
	}

	public void callbackProcessing() {
		List<CallbackModel> list = null;
		List<CallbackModel> updateList = new ArrayList<CallbackModel>();
		try {
			list = callback.getCallback(config);
			logger.info("Picked callback size: " + list.size());
			if (list != null) {
				for (CallbackModel msgStore : list) {
					long timeDiff = this.getTimeDifference(msgStore);
					if (timeDiff >= AppConfig.config.getInt("callback_wait", 2) && msgStore.getCallbackStatus().equalsIgnoreCase("I")) {
						logger.info("MSISDN[" + msgStore.getMsisdn() + "] Tid["
								+ msgStore.getTid() + "] Time difference ["
								+ timeDiff+ "] Greater than callback_wait["
								+ AppConfig.config.getInt("callback_wait")
								+ "] time,So marking request as FAIL.");
						msgStore.setStatus("FAIL");
						AppConfig.requestQueue.put(msgStore);
						updateList.add(msgStore);
						config.setPickCount(config.getPickCount() - 1);
					}
					else if(msgStore.getCallbackStatus().equalsIgnoreCase("R")){
						AppConfig.requestQueue.put(msgStore);
						updateList.add(msgStore);
						config.setPickCount(config.getPickCount() - 1);
					}
				}
				callback.deleteCallback(updateList);
			}
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-CRMS-")
					+ "00004] [Exception while Processing CallBack] Error[ "
					+ e.getMessage() + "]");
			e.printStackTrace();
		}
		config.setPick(true);
	}

	public long getTimeDifference(CallbackModel msgStore) {
		long diffMinutes = 0;
		try{
			if (msgStore.getCallbackStatus().equalsIgnoreCase("I")) {
				Date date = new Date();
				SimpleDateFormat dateFormat = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss");
				String formattedDate = dateFormat.format(date);
				Date curDate = dateFormat.parse(formattedDate);
				Date reqDate = dateFormat.parse(msgStore.getReq_time());

				long diff = curDate.getTime() - reqDate.getTime();
				diffMinutes= diff / 1000 % 60;
				logger.debug("MSISDN["+msgStore.getMsisdn()+"] Tid["+msgStore.getTid()+"] Time difference ["+diffMinutes+"] Minutes");
			}
		}catch (Exception e) {
			logger.error("MSISDN["+msgStore.getMsisdn()+"] Tid["+msgStore.getTid()+"] Exception while getting time difference. "+e.getMessage());
		}
		return diffMinutes;
	}
	public void terminate() {
		callbackPickerRunning = false;
	}
}
