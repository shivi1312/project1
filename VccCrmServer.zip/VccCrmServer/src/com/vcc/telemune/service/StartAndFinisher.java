package com.vcc.telemune.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class StartAndFinisher
 */
@WebServlet(
		urlPatterns = "/StartAndFinisher",
		loadOnStartup = 1,
        asyncSupported = true
)
public class StartAndFinisher extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(StartAndFinisher.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private Thread callbackThread = null;
	private Worker worker = null;
	private CallbackPickerWorker callbackPickerWorker = null;
	private Thread workerThread = null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StartAndFinisher() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	public void init() throws ServletException {
		try{
			logger.info("Start threads.........");
			MsgConfig msgConfig = new MsgConfig();
			msgConfig.setCount(AppConfig.config.getInt("ROW_PICK", 1));
			callbackPickerWorker = new CallbackPickerWorker(msgConfig);
			callbackThread = new Thread(callbackPickerWorker);
			callbackThread.start();
			worker = new Worker(msgConfig);
			workerThread = new Thread(worker);
			workerThread.start();
		}catch(Exception e){
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-CRMS-")
					+ "00010] [Exception while Starting CallPicker and Worker Threads] Error[ "
					+ e.getMessage() + "]");
			e.printStackTrace();
		}
	}
	public void destroy() {
		logger.info("Shut down threads.........");
		try{
			this.destroyWorker();
			this.destroyCallbackPicker();
			Worker.shutdownWorker();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void destroyWorker(){
		try{
			worker.terminate();
			//workerThread.join();
		}catch(Exception e){
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-CRMS-")
					+ "00011] [Exception while Stoping Worker Threads] Error[ "
					+ e.getMessage() + "]");
			//logger.info("Error while stoping worker thread: "+e.getMessage());
		}
	}
	public void destroyCallbackPicker(){
		try{
			callbackPickerWorker.terminate();
			//callbackThread.join();
		}catch(Exception e){
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-CRMS-")
					+ "00012] [Exception while Stoping callback picker worker thread] Error[ "
					+ e.getMessage() + "]");
			//logger.info("Error while stoping callback picker worker thread: "+e.getMessage());
		}
	}
}
