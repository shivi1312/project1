package com.vcc.telemune.service;

public class MsgConfig implements java.io.Serializable{
	private static final long serialVersionUID = 1L;
	private int count = 0;
	private int pickCount = 0;
	private int mscUrl = AppConfig.config.getInt("default_msc_url",1);
	private boolean pick = true;

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Integer getPickCount() {
		return pickCount;
	}

	public void setPickCount(Integer pickCount) {
		this.pickCount = pickCount;
	}

	public Integer getMscUrl() {
		return mscUrl;
	}

	public void setMscUrl(Integer mscUrl) {
		this.mscUrl = mscUrl;
	}

	public boolean getPick() {
		return pick;
	}

	public void setPick(boolean pick) {
		this.pick = pick;
	}	
	
}
