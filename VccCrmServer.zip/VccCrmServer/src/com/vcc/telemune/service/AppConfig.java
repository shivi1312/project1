package com.vcc.telemune.service;

import java.io.File;
import java.util.concurrent.ArrayBlockingQueue;

import org.apache.commons.configuration.CombinedConfiguration;
import org.apache.commons.configuration.DefaultConfigurationBuilder;
import org.apache.log4j.Logger;
public class AppConfig {

	private final static Logger logger = Logger.getLogger(AppConfig.class);
	private final static Logger errorLogger = Logger.getLogger("errorLogger");
	public static ArrayBlockingQueue<CallbackModel> requestQueue = null;
	public static CombinedConfiguration config;

	static {
		try {
			DefaultConfigurationBuilder builder = new DefaultConfigurationBuilder();
			builder.setFile(new File("config.xml"));
			config = builder.getConfiguration(true);
			initializeQueue();
		}catch(NullPointerException npe){
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-CRMS-") + "90003] [Null Pointer Exception in reading config File] Error[ "+npe.getMessage()+"]");
	}
	catch (Exception e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-CRMS-")
					+ "00001] [Exception in reading config File] Error[ "
					+ e.getMessage() + "]");
		e.printStackTrace();
	} 
	}

	public static void initializeQueue() {
		try {
			requestQueue = new ArrayBlockingQueue<CallbackModel>(
					AppConfig.config.getInt("BLOCKING_QUEUE_SIZE", 10000));
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-CRMS-") + "00002] [Exception while Initializing ArrayBlocking Queue] Error[ "+e.getMessage()+"]");
		}
	}
}
