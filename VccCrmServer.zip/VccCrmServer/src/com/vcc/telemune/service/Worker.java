package com.vcc.telemune.service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;

public class Worker implements Runnable {

	private volatile boolean workerRunning = true;
	final static Logger logger = Logger.getLogger(Worker.class);
	private MsgConfig msgConfig;
	private static ExecutorService executor = Executors
			.newFixedThreadPool(AppConfig.config.getInt("WORKER_THREAD", 5));

	public Worker(MsgConfig msgConfig) {
		this.msgConfig = msgConfig;
		logger.info("WORKER THREAD: "
				+ AppConfig.config.getInt("WORKER_THREAD", 5));
	}

	
	public void run() {
		while (workerRunning) {
			try {
				CallbackModel callbackStore = AppConfig.requestQueue.poll();
				if (callbackStore != null) {
					executor.execute(new CallbackWorker(callbackStore,
							msgConfig));
				}
				Thread.sleep(1000 / AppConfig.config.getInt("TPS", 600));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	public static void shutdownWorker(){
		try{
			executor.shutdown();
		}catch(Exception e){
			
		}
	}
	public void terminate(){
		workerRunning = false;
	}
}
