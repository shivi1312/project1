package com.vcc.telemune.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.google.gson.Gson;

public class CallbackService {
	final static Logger logger = Logger.getLogger(CallbackService.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private DataSource dataSource;

	public static void main(String[] args) {
		List<CallbackModel> list = new ArrayList<CallbackModel>();
		MsgConfig config = new MsgConfig();
		config.setCount(5);
		list = new CallbackService().getCallback(config);
		try {
			for (CallbackModel msgStore : list) {
				if (msgStore.getCallbackStatus().equalsIgnoreCase("I")) {
					Date date = new Date();
					SimpleDateFormat dateFormat = new SimpleDateFormat(
							"yyyy-MM-dd HH:mm:ss");
					String newDate = dateFormat.format(date);
					Date d = dateFormat.parse(newDate);
					Date dd = dateFormat.parse(msgStore.getReq_time());

					long diff = d.getTime() - dd.getTime();
					long diffMinutes = diff / (60 * 1000) % 60;
					long diffSeconds = diff / 1000 % 60;
					long diffHours = diff / (60 * 60 * 1000) % 24;
					System.out.println("MSISDN [" + msgStore.getMsisdn()
							+ "] ReqTime [" + msgStore.getReq_time()
							+ "] Current [" + newDate + "] diff [" + diffHours
							+ "] Hour Minute[" + diffMinutes + "] seconds["
							+ diffSeconds + "]");
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public CallbackService() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public int existCallback(CallbackModel callback) {
		String query = "SELECT COUNT(*) AS CNT FROM VCC_CALLBACK "
				+ "WHERE MSISDN = ? AND SERVICE_TYPE = ?";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		int result = 0;
		try {
			logger.info("Query is: "
					+ String.format(query.replaceAll("\\?", "%s"),
							callback.getMsisdn(), callback.getServiceType()));
			result = jdbcTemplate.queryForObject(
					query,
					new Object[] { callback.getMsisdn(),
							callback.getServiceType() }, Integer.class);
			logger.info("Query is: "
					+ String.format(query.replaceAll("\\?", "%s"),
							callback.getMsisdn(), callback.getServiceType())
					+ " exist: " + result);
		} catch (Exception e) {
			logger.error("Error while check callback exist or not: "
					+ e.getMessage());
		}
		return result;
	}

	public void storeCallback(CallbackModel callback) {

		String query = "";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		int result = 0;
		try {
			logger.info("callback: " + new Gson().toJson(callback));
			if (this.existCallback(callback) > 0) {
				query = "UPDATE VCC_CALLBACK SET CALLBACK_STATUS='R',STATUS=?,CALLBACK_TIME = now() "
						+ "WHERE MSISDN = ? AND SERVICE_TYPE = ?";
				result = jdbcTemplate
						.update(query,
								new Object[] { callback.getStatus(),
										callback.getMsisdn(),
										callback.getServiceType() });
				/*logger.info("Query is: "
						+ String.format(query.replaceAll("\\?", "%s"), 'R',
								callback.getStatus(), callback.getMsisdn(),
								callback.getServiceType(),callback.getTid()));*/
				logger.info("Query is: UPDATE VCC_CALLBACK SET CALLBACK_STATUS='R',STATUS="+callback.getStatus()+"," +
						"CALLBACK_TIME = now() WHERE MSISDN ="+callback.getMsisdn()+" AND " +
								"SERVICE_TYPE ="+callback.getServiceType()+"");
			} else {
				query = "INSERT INTO VCC_CALLBACK(TID,MSISDN,STATUS,SERVICE_TYPE,"
						+ "CALLBACK_COUNTER,REQ_TIME,CALLBACK_TIME,CALLBACK_STATUS,"
						+ "INTERFACE,LANG,MAILBOX_TYPE,TYPE,DESCRIPTION,ACTION,ACT_TRG)VALUES(?,?,?,"
						+ "?,?,now(),now(),'R',?,?,?,?,?,?,?)";
				logger.info("Query is: "
						+ String.format(query.replaceAll("\\?", "%s"),
								callback.getTid(), callback.getMsisdn(),
								callback.getStatus(),
								callback.getServiceType(),
								callback.getCallbackCounter() + 1,
								callback.getReq_time(), 'R',
								callback.getReqInterface(), callback.getLang(),
								callback.getPlanName(), callback.getType(),
								callback.getDescription(),
								callback.getAction(), callback.getActTrg()));
				result = jdbcTemplate.update(
						query,
						new Object[] { callback.getTid(), callback.getMsisdn(),
								callback.getStatus(),
								callback.getServiceType(),
								callback.getCallbackCounter() + 1,
								callback.getReqInterface(), callback.getLang(),
								callback.getPlanName(), callback.getType(),
								callback.getDescription(),
								callback.getAction(), callback.getActTrg() });
			}
			logger.info("Restore callback [" + callback.getMsisdn() + "] ["
					+ callback.getTid() + "] insert status [" + result + "]");
		} catch (Exception e) {
			e.printStackTrace();
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-CRMS-")
							+ "00005] TransactionId["
							+ callback.getTid()
							+ "] MSISDN["
							+ callback.getMsisdn()
							+ "] [Exception while Inserting callback data in VCC_CALLBACK table] Error[ "
							+ e.getMessage() + "]");
			e.printStackTrace();
		}
	}

	public void deleteCallback(final List<CallbackModel> list) {
		String query = "DELETE FROM VCC_CALLBACK WHERE TID = ?";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		logger.info("batch update list size....." + list.size());
		try {
			jdbcTemplate.batchUpdate(query, new BatchPreparedStatementSetter() {
				public void setValues(PreparedStatement ps, int i)
						throws SQLException {
					CallbackModel callback = list.get(i);
					ps.setString(1, callback.getTid());
				}

				public int getBatchSize() {
					return list.size();
				}
			});
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-CRMS-")
							+ "00006] [Exception while Deleting callback data from VCC_CALLBACK table] Error[ "
							+ e.getMessage() + "]");
			e.printStackTrace();
		}
	}

	public List<CallbackModel> getCallback(MsgConfig config) {
		List<CallbackModel> list = null;
		String query = "SELECT msisdn,tid,status,service_type,callback_counter,req_time," +
				"callback_time,interface,lang,callback_status,DESCRIPTION,TYPE,MAILBOX_TYPE," +
				"ACTION,ACT_TRG FROM VCC_CALLBACK LIMIT 0," + config.getCount();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		logger.info("query to get msg: " + query);
		try {
			list = jdbcTemplate.query(query, new RowMapper<CallbackModel>() {
				public CallbackModel mapRow(ResultSet rs, int rownumber)
						throws SQLException {
					CallbackModel callback = new CallbackModel();
					callback.setMsisdn(rs.getString("msisdn"));
					callback.setTid(rs.getString("tid"));
					callback.setStatus(rs.getString("status"));
					callback.setServiceType(rs.getString("service_type"));
					callback.setCallbackCounter(rs.getInt("callback_counter"));
					callback.setReq_time(rs.getString("req_time"));
					callback.setCallback_time(rs.getString("callback_time"));
					callback.setReqInterface(rs.getString("interface"));
					callback.setLang(rs.getInt("lang"));
					callback.setCallbackStatus(rs.getString("callback_status"));
					callback.setDescription(rs.getString("DESCRIPTION"));
					callback.setType(rs.getString("TYPE"));
					callback.setPlanName(rs.getString("MAILBOX_TYPE"));
					callback.setAction(rs.getString("ACTION"));
					callback.setActTrg(rs.getInt("ACT_TRG"));
					return callback;
				}
			});
			config.setPickCount(list.size());
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-CRMS-")
							+ "00007] [Exception while getting callback data from VCC_CALLBACK table] Error[ "
							+ e.getMessage() + "]");
			e.printStackTrace();
		}
		return list;
	}
}