package com.vcc.telemune.service;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;

import org.apache.log4j.Logger;

import ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage;
import ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessageStatus;

import com.google.gson.Gson;
import com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponse;
import com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponseResponseData;

@SuppressWarnings("unused")
public class CallbackWorker implements Runnable {
	private Gson gson = new Gson();
	private CallbackService callbackService = new CallbackService();
	final static Logger logger = Logger.getLogger(CallbackWorker.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	final static Logger ruleLogger = Logger.getLogger("ruleLogger");

	private CallbackModel callbackStore;
	private MsgConfig msgConfig;
	private static final String serviceType = "0010";

	public CallbackWorker(CallbackModel callbackStore, MsgConfig msgConfig) {
		this.callbackStore = callbackStore;
		this.msgConfig = msgConfig;
	}

	public void run() {
		try {
			logger.info("execute callback worker.......["
					+ callbackStore.getMsisdn() + "] ["
					+ callbackStore.getTid() + "]");
			if (!this.callRuleEngine())
				this.restoreCallback();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void restoreCallback() {
		try {
			callbackService.storeCallback(callbackStore);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean callRuleEngine() {
		DataOutputStream out = null;
		DataInputStream reader = null;
		Socket socket = null;
		CrmRequest crmRequest = new CrmRequest();
		String ruleRequest = "";
		String ruleResponse = "";
		boolean callback = false;
		try {
			crmRequest.setMsisdn(callbackStore.getMsisdn());
			crmRequest.setTid(callbackStore.getTid());
			crmRequest.setStatus(callbackStore.getStatus());

			if(callbackStore.getAction().equalsIgnoreCase("create"))
				crmRequest.setActionId(AppConfig.config.getString("rule.engine.create.action.id", "9"));
			else if(callbackStore.getAction().equalsIgnoreCase("modify"))
				crmRequest.setActionId(AppConfig.config.getString("rule.engine.modify.action.id", "11"));
			
			crmRequest.setActTrg(callbackStore.getActTrg());
			crmRequest.setInterFace(callbackStore.getReqInterface());
			crmRequest.setServiceType(callbackStore.getServiceType());
			crmRequest.setLang(callbackStore.getLang());
			crmRequest.setCallback(true);
			crmRequest.setPlanName(callbackStore.getPlanName());
			crmRequest.setType(callbackStore.getType());
			logger.info("[" + callbackStore.getTid() + "] ["
					+ callbackStore.getMsisdn() + "] request to rule engine: "
					+ gson.toJson(crmRequest));
			socket = new Socket(AppConfig.config.getString("rule.engine.ip",
					"127.0.0.1"), AppConfig.config.getInt("rule.engine.port",
					9099));
			socket.setSoTimeout(AppConfig.config.getInt("rule.engine.timeout"));
			out = new DataOutputStream(socket.getOutputStream());
			out.writeUTF(gson.toJson(crmRequest));
			out.flush();
			reader = new DataInputStream(socket.getInputStream());
			ruleRequest = gson.toJson(crmRequest);
			ruleResponse = reader.readUTF();
			logger.info("[" + callbackStore.getTid() + "] ["
					+ callbackStore.getMsisdn() + "] response: "
					+ ruleResponse);
			
			callback = true;
		} catch (SocketTimeoutException soc) {

			callback = false;
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-CRMS-")
							+ "00005] TransactionId["
							+ callbackStore.getTid()
							+ "] MSISDN["
							+ callbackStore.getMsisdn()
							+ "] [SocketTimeoutException while connecting to RuleEngine] Error[ "
							+ soc.getMessage() + "]");
		} catch (Exception e) {
			callback = false;
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-CRMS-") + "00008] TransactionId["
					+ callbackStore.getTid() + "] MSISDN["
					+ callbackStore.getMsisdn()
					+ "] [Exception while connecting to RuleEngine] Error[ "
					+ e.getMessage() + "]");
			e.printStackTrace();
		} finally {
			try {
				if (reader != null)
					reader.close();
				if (out != null)
					out.close();
				if (socket != null && !socket.isClosed())
					socket.close();
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-CRMS-")
								+ "00009] TransactionId["
								+ callbackStore.getTid()
								+ "] MSISDN["
								+ callbackStore.getMsisdn()
								+ "] [Exception while closing connection with RuleEngine] Error[ "
								+ e.getMessage() + "]");
				e.printStackTrace();
			}
		}
		ruleLogger.info("{req:"+ruleRequest+",resp:"+ruleResponse+"}");
		return callback;
	}
}
