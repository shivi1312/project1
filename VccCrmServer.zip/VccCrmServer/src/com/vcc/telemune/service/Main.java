package com.vcc.telemune.service;


public class Main {
	public static void main(String [] args){
		try{
			MsgConfig msgConfig = new MsgConfig();
			msgConfig.setCount(AppConfig.config.getInt("ROW_PICK", 1));
			new Thread(new CallbackPickerWorker(msgConfig)).start();
			new Thread(new Worker(msgConfig)).start();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}