package com.vcc.telemune.service;

import org.apache.log4j.Logger;

import ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessage;
import ae.etisalat.www.Middleware.SharedResources.Common.AckMessage_xsd.AckMessageStatus;
import ae.etisalat.www.Middleware.SharedResources.Common.ApplicationHeader_xsd.ApplicationHeader;

import com.google.gson.Gson;
import com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequest;
import com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeader;
import com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItem;
import com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusRequest_xsd.UpdateOrderStatusRequestDataHeaderOrderItemOfferID;
import com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponse;
import com.tibco.www.Middleware.AutoServiceFulfilment.UpdateOrderStatusResponse_xsd.UpdateOrderStatusResponseResponseData;

public class CrmService {

	final static Logger logger = Logger.getLogger(CrmService.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	final static Logger crmLogger = Logger.getLogger("crmLogger");
	
	private static Gson gson = new Gson();

	private CallbackService callbackService = new CallbackService();
	private ApplicationHeader applicationHeader;
	private UpdateOrderStatusRequestDataHeader dataHeader;

	public UpdateOrderStatusResponse updateCallBack(
			UpdateOrderStatusRequest updateOrderStatusRequest) {
		UpdateOrderStatusResponse updateOrderStatusReponse = null;
		try {		
			applicationHeader = updateOrderStatusRequest.getApplicationHeader();
			dataHeader = updateOrderStatusRequest.getDataHeader();
			String accountNumber = null;
			String status = null;
			String subRequestId = null;
			String tid = null;
			String serviceType = null;
			String req_time = null;
			logger.info("System: " + applicationHeader.getRequestedSystem()
					+ " time: " + applicationHeader.getRequestedDate()
					+ " tid: " + applicationHeader.getTransactionID());
			tid = applicationHeader.getTransactionID();
			req_time = applicationHeader.getRequestedDate();

			for (UpdateOrderStatusRequestDataHeaderOrderItem orderItem : dataHeader
					.getOrderItem()) {
				accountNumber = orderItem.getAccountNumber();
				status = orderItem.getStatus();
				subRequestId = orderItem.getSubRequestId();

				for (UpdateOrderStatusRequestDataHeaderOrderItemOfferID offerId : orderItem
						.getOfferID()) {
					logger.info("offerId:: key: " + offerId.getName()
							+ " value: " + offerId.getValue());
					if (offerId.getValue().equalsIgnoreCase(AppConfig.config.getString("voice_mail_exec_add","61448")) 
							|| offerId.getValue().equalsIgnoreCase(AppConfig.config.getString("voice_mail_exec_delete", "61449"))
							|| offerId.getValue().equalsIgnoreCase(AppConfig.config.getString("voice_mail_basic_add", "61450"))
							|| offerId.getValue().equalsIgnoreCase(AppConfig.config.getString("voice_mail_basic_delete","61451"))
							|| offerId.getValue().equalsIgnoreCase(AppConfig.config.getString("voice_mail_basic_modify", "61452"))
							|| offerId.getValue().equalsIgnoreCase(AppConfig.config.getString("voice_mail_exec_modify", "100004"))) {

						serviceType = AppConfig.config.getString("VM", "0010");
						
					} else if (offerId.getValue().equalsIgnoreCase(AppConfig.config.getString("voice_note_add","61453")) 
							|| offerId.getValue().equalsIgnoreCase(AppConfig.config.getString("voice_note_delete", "61454"))
							|| offerId.getValue().equalsIgnoreCase(AppConfig.config.getString("voice_note_modify", "61455"))) {

						serviceType = AppConfig.config.getString("VN", "0100");
						
					}
					else if(offerId.getValue().equalsIgnoreCase(AppConfig.config.getString("notifyme_delete","73191"))){
						serviceType = AppConfig.config.getString("NOTIFYME", "0001");
						
					}
				}
				logger.info("accountNumber: " + accountNumber + " status: "
						+ status + " subRequestId: " + subRequestId
						+ " serviceType: " + serviceType + " req_Time: "
						+ req_time);
				
				updateOrderStatusReponse = this.storeCallback(tid,accountNumber, status, subRequestId, serviceType,req_time);
				crmLogger.info("SubRequestId:"+subRequestId+", AccountNumber:"+accountNumber+", Tid:"+updateOrderStatusReponse.getResponseData().getTransactionID()+", AckMessage:"+updateOrderStatusReponse.getAckMessage().getStatus()+"");
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-CRMS-")
							+ "00013] [Exception inside updateCallBack() function of CrmService Class] Error[ "
							+ e.getMessage() + "]");
			e.printStackTrace();
		}
		return updateOrderStatusReponse;
	}

	public UpdateOrderStatusResponse storeCallback(String tid, String msisdn,
			String status, String subRequestId, String serviceType,
			String req_time) {
		logger.info("[" + tid + "] [" + msisdn + "] inside......");
		UpdateOrderStatusResponse updateOrderStatusReponse = new UpdateOrderStatusResponse();
		UpdateOrderStatusResponseResponseData responseData = new UpdateOrderStatusResponseResponseData();
		AckMessage ackMessage = new AckMessage();
		CallbackModel callback = new CallbackModel();
		try {
			callback.setTid(tid);
			callback.setMsisdn(msisdn);
			callback.setStatus(status);
			callback.setServiceType(serviceType);
			callback.setReq_time(req_time);

			callbackService.storeCallback(callback);
			ackMessage.setStatus(AckMessageStatus
					.fromString(AckMessageStatus._SUCCESS));
			responseData.setTransactionID(tid);
			updateOrderStatusReponse.setAckMessage(ackMessage);
			updateOrderStatusReponse.setResponseData(responseData);
		} catch (Exception e) {
			ackMessage.setStatus(AckMessageStatus
					.fromString(AckMessageStatus._FAILURE));
			responseData.setTransactionID(tid);
			updateOrderStatusReponse.setAckMessage(ackMessage);
			updateOrderStatusReponse.setResponseData(responseData);
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-CRMS-")
							+ "00014] MSISDN["
							+ msisdn
							+ "] TransactionId["
							+ tid
							+ "] [Exception inside storeCallBack() function of CrmService Class] Error[ "
							+ e.getMessage() + "]");
			/*
			 * logger.info("[" + tid + "] [" + msisdn + "] getting excpeion " +
			 * e.getMessage());
			 */
			e.printStackTrace();
		}
		return updateOrderStatusReponse;
	}

}
