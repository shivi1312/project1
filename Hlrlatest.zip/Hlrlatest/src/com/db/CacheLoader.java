package com.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import com.telemune.hlr.Global;
import com.telemune.hlr.MsisdnVal;

/**
 * This thread read data from some tables that are used as 
 * cache through out the application
 * @author Harjinder
 * */
public class CacheLoader implements Runnable{
	
	private Logger logger = Logger.getLogger(CacheLoader.class);
	ArrayList<MsisdnVal> alMsisdnRange = new ArrayList<MsisdnVal>();
	
	/**
	 * This is run method provided by Runnable interface
	 * call methods to load cache information
	 * @return void 
	 * */
	public void run() {
		
		try
		{
			loadOperatorRange(); //loading all operator ranges from operator_subscriber
			Thread.sleep(1000*Global.CACHE_LOADER_SLP_TIME);
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		
	}
   	
	/**
	 * This method load all ranges from OPERATOR_SUBSCRIBER
	 * @return void
	 * */
	private void loadOperatorRange()
	{
		Statement stmt = null;
		ResultSet rs = null;
		String query = null;
		Connection con = null;
		try
         {
			     con = Global.conPool.getConnection();
                 stmt = con.createStatement();
                 query = "select STARTS_AT,ENDS_AT,COUNTRY_CODE,HLR_ID from operator_subscriber";
                 logger.info(query);
                 rs = stmt.executeQuery(query);
                 int ccode = -1;
                 alMsisdnRange.clear();
                 while (rs.next())
                 {
                    MsisdnVal msval = new MsisdnVal();
                    msval.st_msisdn = rs.getString("STARTS_AT");
                    msval.ed_msisdn = rs.getString("ENDS_AT");
                    ccode = rs.getInt("COUNTRY_CODE");
                    msval.countrycode = Integer.toString(ccode);
                    msval.setHlrId(rs.getInt("HLR_ID")); 
                    alMsisdnRange.add(msval);
                    logger.info("OperatorSubscriber Bean " +msval );
                 }
                 rs.close();
                 stmt.close();
         }
         catch (SQLException exp)
         {
                 exp.printStackTrace();
         }
		 finally{
			 try
			 {
				 if(con!=null){con.close();}
				 if(stmt!=null){stmt.close();}
				 if(rs!=null){rs.close();}
			 }
			 catch(Exception exp)
			 {
				 exp.printStackTrace();
			 }
		 }

	}
	
	/**
	 * This method check that given number exists in any range or not.
	 * If exists then @return hlrId
	 * If not exists then @return -1
	 * */
	public int checkInRange(String number)
		     {
		          int hlrId = -1;
		          
		          if(number.startsWith("+"))
		            {
		               number = number.substring(1);
		            }
                  
		          logger.info("size is ="+alMsisdnRange.size());
                  for(int k = 0; k < alMsisdnRange.size(); k++)
	                 {
	                   MsisdnVal msvals=(MsisdnVal) alMsisdnRange.get(k);
	                   logger.info("start range="+msvals.getSt_msisdn()+" end range"+msvals.getEd_msisdn()+" msisdn["+number+"] result["+(Double.parseDouble(number)>=Double.parseDouble(msvals.getSt_msisdn()) && Double.parseDouble(number)<=Double.parseDouble(msvals.getEd_msisdn()))+"]");
                       if(Double.parseDouble(number)>=Double.parseDouble(msvals.getSt_msisdn()) && Double.parseDouble(number)<=Double.parseDouble(msvals.getEd_msisdn()))
	                    {
	                       logger.debug("Got Number["+number+"]");
	                       if(number.startsWith(msvals.getCountrycode()))
	                         {
	                             logger.info("start with Number["+msvals.getCountrycode()+"]");
	                             hlrId = msvals.getHlrId();
	                         }
	                        else
	                         {
	                             logger.info("start does not with Number["+msvals.getCountrycode()+"]");
	                             hlrId = msvals.getHlrId();
	                         }
	                         break;
	                     }
	                 }
               
                 logger.info("##>>msisdn["+number+"] returning hlrId ["+hlrId+"] from checkInRange");
		         return hlrId;
		     }
}
