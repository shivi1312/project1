package com.telemune.hlr;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.log4j.Logger;

import FileBaseLogging.FileLogWriter;

import com.db.CacheLoader;
import com.db.Dboperation;
import com.telemune.hlr.backend.DataObject;
import com.telemune.hlr.backend.HlrInterface;
import com.telemune.hlr.backend.HttpRequestHandler;
import com.telemune.hlr.backend.SoapRequestHandler;
import com.telemune.hlr.backend.TelnetRequestHandler;

/**
 * This is the main working thread that define all logic regarding different hlr's.
 * @author Harjinder
 * */

public class HlrExecutor implements Runnable{
	final private Logger logger = Logger.getLogger(HlrExecutor.class);
	DataObject dataObject = null;
	HlrInterface<TelnetRequestHandler> sentToTelentHlr = null;
	HlrInterface<HttpRequestHandler> sentToHttpHlr = null;
	HlrInterface<SoapRequestHandler> sentToSoapHlr = null;
	int responseCode = -1;
	Dboperation dbops = null;
	CacheLoader cacheLoader = null;
	private AtomicLong processNo= new AtomicLong(0);
	private AtomicInteger port = new AtomicInteger(0);
	String ip;
	String loginName;
	String password;
	int noOfConnection = 0;
	long objectNo = 1;
	HlrExecutor executor = null;
	
	public HlrExecutor() {
	
	}
	/**
	 * It is a parametrized constructor 
	 * @param dataObject
	 * @param cacheLoader
	 * 
	 * */
	public HlrExecutor(DataObject dataObject , CacheLoader cacheLoader) {
		this.dataObject = dataObject;
	    this.cacheLoader = cacheLoader;
	    this.executor = new HlrExecutor();
	}
	
	
	/**
	 * It id a run method provided by Runnable interface , It define all logic related to different HLR types.
	 * @return void
	 * */
	public void run() {
		try
		{
		if(Global.IsPriorityWiseEnable == 1)
	       {
			   int i =1;
	    	   int resp = -1;
	    	   while(i <= Global.priority_map.size())
	    	   {
	    		       resp = -1;
	    		       int hlrId = Global.priority_map.get(i);
	    		       HlrBean hlrbean = Global.map.get(hlrId);
	    		       logger.debug("##>>msisdn["+dataObject.getMsisdn()+"] Pool Size is["+hlrbean.getTelnet_pool().size()+"] hlrId["+hlrId+"] data["+hlrbean.getHlrType()+"]");
	    		       logger.info("##>>msisdn["+dataObject.getMsisdn()+"] with HlrId["+hlrId+"] ");
	    		       if(hlrbean!=null)
	    		       {
	    		    	   
	    		       if(hlrbean.getHlrType().equalsIgnoreCase("TELNET"))
	    		       {
	    		    	    synchronized (hlrbean) {
						    sentToTelentHlr =(TelnetRequestHandler) hlrbean.getTelnet_pool().borrowObject();
						    }
	    		    	    
                            if(sentToTelentHlr != null)
                            {
                            
                            objectNo = sentToTelentHlr.getObjectNo();
                            if(sentToTelentHlr.isConnected())
                            {
                            responseCode = sentToTelentHlr.doProcessing(dataObject);
                            if(responseCode == 1 && dataObject.getResponse().equals("0"))
                            {
                            	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] Success Response ["+dataObject.getResponse()+"]");
                                resp = 1;
                            }
                            else if(responseCode == -2) //connection lost
                            {
                            	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] Success Response ["+dataObject.getResponse()+"] Connection lost so try agian");
                            	ip = hlrbean.getTelnetConfiguredIp();
    							loginName = hlrbean.getRemoteUser();
    							password = hlrbean.getRemotePassword();
    							port = hlrbean.getPort();
    							logger.info("msisdn["+dataObject.getMsisdn()+"] Going to create new Telnet Connection..");
    							sentToTelentHlr = new TelnetRequestHandler(objectNo ,
																			ip , 
																			port.get() , 
																			loginName , 
																			password);
    							
    							resp = executor.processAfterReconnect(dataObject, sentToTelentHlr);
    							responseCode = resp;
    							logger.info("##getMsisdn()["+dataObject.getMsisdn()+"] Response from processAfterReconnect resp ["+resp+"] responseCode["+responseCode+"]");		
    							if(resp == -2)
    							{
    								logger.debug("##msisdn["+dataObject.getMsisdn()+"] Connection lost so ...break");
    								break;
    							}
    							else if(resp != 1)
    							{
    	                            	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] response["+dataObject.getResponse()+"] Sending to second Hlr enable["+Global.SendToSecondHlrEnable+"]");
    	                            	
    	                            	if(Global.SendToSecondHlrEnable == 1)
    	                            	{
    	                            		i++;
    	                            		hlrbean.getTelnet_pool().returnObject((TelnetRequestHandler) sentToTelentHlr);
    	                                    continue;
    	                            	}
    	                            	else
    	                            	{
    	                            		hlrbean.getTelnet_pool().returnObject((TelnetRequestHandler) sentToTelentHlr);
    	                                 	break;
    	                            	}	
    	                         }
    						}
                            else
                            {
                            	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] response["+dataObject.getResponse()+"] Sending to second Hlr enable["+Global.SendToSecondHlrEnable+"]");
                            	if(Global.SendToSecondHlrEnable == 1)
                            	{
                            		i++;
                            		hlrbean.getTelnet_pool().returnObject((TelnetRequestHandler) sentToTelentHlr);
                                    continue;
                            	}
                            	else
                            	{
                            		hlrbean.getTelnet_pool().returnObject((TelnetRequestHandler) sentToTelentHlr);
                                 	break;
                            	}	
                            }
                            if(resp == 1)
                            {
                            	hlrbean.getTelnet_pool().returnObject((TelnetRequestHandler) sentToTelentHlr);
                                break;
                            }
                            }
                            else
                            {
                            	logger.info("##>msisdn["+dataObject.getMsisdn()+"] FAIL because Hlr Not Connected.");
                            	dataObject.setResponse("-1");
                            	
                            	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] Success Response ["+dataObject.getResponse()+"] Connection lost so try agian");
                            	ip = hlrbean.getTelnetConfiguredIp();
    							loginName = hlrbean.getRemoteUser();
    							password = hlrbean.getRemotePassword();
    							port = hlrbean.getPort();
    							logger.info("msisdn["+dataObject.getMsisdn()+"] Going to create new Telnet Connection..");
    							sentToTelentHlr = new TelnetRequestHandler(objectNo ,
																			ip , 
																			port.get() , 
																			loginName , 
																			password);
    							
    							resp = executor.processAfterReconnect(dataObject, sentToTelentHlr);
    							logger.info("##getMsisdn()["+dataObject.getMsisdn()+"] Response from processAfterReconnect resp ["+resp+"]");
    							responseCode = resp;	
    							if(resp == -2)
    							{
    								logger.debug("##msisdn["+dataObject.getMsisdn()+"] Connection lost so ...break");
    								break;
    							}
    							else if(resp != 1)
    							{
    	                            	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] response["+dataObject.getResponse()+"] Sending to second Hlr enable["+Global.SendToSecondHlrEnable+"]");
    	                            	if(Global.SendToSecondHlrEnable == 1)
    	                            	{
    	                            		i++;
    	                            		hlrbean.getTelnet_pool().returnObject((TelnetRequestHandler) sentToTelentHlr);
    	                                    continue;
    	                            	}
    	                            	else
    	                            	{
    	                            		hlrbean.getTelnet_pool().returnObject((TelnetRequestHandler) sentToTelentHlr);
    	                                 	break;
    	                            	}	
    	                         }
                            	
    							if(resp == 1)
                                {
                                	hlrbean.getTelnet_pool().returnObject((TelnetRequestHandler) sentToTelentHlr);
                                    break;
                                }
                           }
                            }
                            else
                            {
                            	logger.info("##>>msisdn["+dataObject.getMsisdn()+"] sentToTelentHlr bean null so not processing further bean is["+sentToTelentHlr+"]");
                            	Thread.sleep(Global.OBJECT_NOT_FOUND_THEN_SLEEP*1000); //should be configurable
                            	Global.req_queue.put(dataObject); //try agin for that msisdn
                            	responseCode = -3;
                            	break;
                            }	
                            
	    		                 
	    		       }
	    		       else if(hlrbean.getHlrType().equalsIgnoreCase("HTTP"))
	    		       {
	    		    	   synchronized(hlrbean) {
						    sentToHttpHlr = hlrbean.getHttp_pool ().borrowObject();
	    		    	    }
	    		    	   
	    		    	    if(sentToHttpHlr != null)
	    		    	    {
                            responseCode = sentToHttpHlr.doProcessing(dataObject);
                            responseCode = -1;
                            if(responseCode == 1)
                            {
                            	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] Success Response ["+dataObject.getResponse()+"]");
                            	resp = 1;
                            }
                            else
                            {
                            	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] response["+dataObject.getResponse()+"] Sending to second Hlr enable["+Global.SendToSecondHlrEnable+"]");
                            	if(Global.SendToSecondHlrEnable == 1)
                            	{
                            		i++;
                            		hlrbean.getHttp_pool().returnObject((HttpRequestHandler) sentToHttpHlr);
                                    continue;
                            	}
                            	else
                            	{
                            		hlrbean.getHttp_pool().returnObject((HttpRequestHandler) sentToHttpHlr);
                                    break;
                            	}	
                            }
	    		    	    }
	    		    	    else
	                        {
	                            	logger.info("##>>msisdn["+dataObject.getMsisdn()+"] sendToHttpHlr bean null so not processing further bean is["+sentToHttpHlr+"]");
	                            	Global.req_queue.put(dataObject); //try agin for that msisdn
	                            	responseCode = -3;
	                            	break;
	                        }
							if(resp == 1)
                            {
                            	hlrbean.getHttp_pool().returnObject((HttpRequestHandler) sentToHttpHlr);
            	    		    break;
                            }
                       }
	    		       else if(hlrbean.getHlrType().equalsIgnoreCase("SOAP"))
	    		       {
	    		    	    synchronized (hlrbean) {
							sentToSoapHlr = hlrbean.getSoap_pool().borrowObject();
	    		    	    }
                            if(sentToSoapHlr != null)
                            {
                            responseCode = sentToSoapHlr.doProcessing(dataObject);
                            System.out.println("RESPONSE is["+dataObject.getResponse()+"]");
                            if(responseCode == 1 && dataObject.getResponse().equals("0"))
                            {
                            	logger.info("##> msisdn["+dataObject.getMsisdn()+"] Success Response ["+dataObject.getResponse()+"]");
                            	resp = 1;
                            }
                            else
                            {
                            	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] response["+dataObject.getResponse()+"] Sending to second Hlr enable["+Global.SendToSecondHlrEnable+"]");
                            	if(Global.SendToSecondHlrEnable == 1)
                            	{
                            		i++;
                            		hlrbean.getSoap_pool().returnObject((SoapRequestHandler) sentToSoapHlr);
                                    continue;
                            	}
                            	else
                            	{
                            		hlrbean.getSoap_pool().returnObject((SoapRequestHandler) sentToSoapHlr);
                                    break;
                            	}	
                            }
                            }
                            else
	                        {
	                            	logger.info("##>>msisdn["+dataObject.getMsisdn()+"] sendToSoapHlr bean null so not processing further bean is["+sentToSoapHlr+"]");
	                            	Global.req_queue.put(dataObject); //try agin for that msisdn
	                            	responseCode = -3;
	                            	break;
	                        }
                                 
                            if(resp == 1)
                            {
                            	hlrbean.getSoap_pool().returnObject((SoapRequestHandler) sentToSoapHlr);
                                break;
                            }
                            
	    		       }
	    	   }
	    	   else
	    	   {
	    		    dataObject.setResponse("-1");
	    	      	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] HlrId not found so FAIL..");
	           } 
	    	   }
	       }
	       else if(Global.IsRangeWiseEnable == 1)
	       {
	    	   int hlrId = cacheLoader.checkInRange(dataObject.getMsisdn());
	    	   HlrBean hlrbean =(HlrBean) Global.map.get(hlrId);
	    	   if(hlrbean!=null)
	    	   {
		       if(hlrbean.getHlrType().equalsIgnoreCase("TELNET"))
		       {
		    	   synchronized (hlrbean) {
				    sentToTelentHlr = hlrbean.getTelnet_pool().borrowObject();
		    	   }
		    	    if(sentToTelentHlr != null)
		    	    {
		    	    	
		    	    	
		    	    objectNo = sentToTelentHlr.getObjectNo();
		    	    if(sentToTelentHlr.isConnected())
                    {
                    responseCode = sentToTelentHlr.doProcessing(dataObject);
                    if(responseCode == 1 && dataObject.getResponse().equals("0"))
                    {
                    	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] Success Response ["+dataObject.getResponse()+"]");
                    }
                    else if(responseCode == -2)
                    {
                                       
                    	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] Success Response ["+dataObject.getResponse()+"] Connection lost so try agian");
                    	ip = hlrbean.getTelnetConfiguredIp();
						loginName = hlrbean.getRemoteUser();
						password = hlrbean.getRemotePassword();
						port = hlrbean.getPort();
						logger.info("msisdn["+dataObject.getMsisdn()+"] Going to create new Telnet Connection..");
						sentToTelentHlr = new TelnetRequestHandler(objectNo ,
																	ip , 
																	port.get() , 
																	loginName , 
																	password);
						
						responseCode = executor.processAfterReconnect(dataObject, sentToTelentHlr);
						logger.info("##msisdn["+dataObject.getMsisdn()+"] Response from processAfterReconnect resp ["+responseCode+"]");
						
					}
                    else
                    {
                    	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] response["+dataObject.getResponse()+"] FAIL");
                    }
                    }
                    else
                    {
                    	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] response["+dataObject.getResponse()+"] FAIL because HLR not connected..");
                    	dataObject.setResponse("-1");
                    }
		    	    if(responseCode != -2)
		    	    {
		    	    		hlrbean.getTelnet_pool().returnObject((TelnetRequestHandler) sentToTelentHlr);
		    	    }
		    	
		    	    }
		    	    else
                    {
                        	logger.info("##>>msisdn["+dataObject.getMsisdn()+"] sendToTelnetHlr bean null so not processing further bean is["+sentToTelentHlr+"]");
                        	Thread.sleep(Global.OBJECT_NOT_FOUND_THEN_SLEEP*1000); //should be configurable
                        	Global.req_queue.put(dataObject); //try agin for that msisdn
                        	responseCode = -3;
                    }
		    	    
                         
		       }
		       else if(hlrbean.getHlrType().equalsIgnoreCase("HTTP"))
		       {
		    	   synchronized (hlrbean) {
				    sentToHttpHlr = hlrbean.getHttp_pool().borrowObject();
		    	   }
                    if(sentToHttpHlr != null)
                    {
                    responseCode = sentToHttpHlr.doProcessing(dataObject);
                    if(responseCode == 1)
                    {
                    	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] Success Response ["+dataObject.getResponse()+"]");
                    }
                    else
                    {
                    	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] response["+dataObject.getResponse()+"] FAIL");
                    }
                    hlrbean.getHttp_pool().returnObject((HttpRequestHandler) sentToHttpHlr);
                    }
                    else
                    {
                        	logger.info("##>>msisdn["+dataObject.getMsisdn()+"] sendToHttpHlr bean null so not processing further bean is["+sentToHttpHlr+"]");
                        	Global.req_queue.put(dataObject); //try again for that msisdn
                        	responseCode = -3;
                    }
		       }
		       else if(hlrbean.getHlrType().equalsIgnoreCase("SOAP"))
		       {
		    	   synchronized (hlrbean) {
			        sentToSoapHlr = hlrbean.getSoap_pool().borrowObject();
		    	   }
                    if(sentToSoapHlr != null)
                    {
                    responseCode = sentToSoapHlr.doProcessing(dataObject);
                    if(responseCode == 1)
                    {
                    	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] Success Response ["+dataObject.getResponse()+"]");
                    }
                    else
                    {
                    	logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] response["+dataObject.getResponse()+"] FAIL");
                    }
                    hlrbean.getSoap_pool().returnObject((SoapRequestHandler) sentToSoapHlr);
                    }  else
                    {
                    	logger.info("##>>msisdn["+dataObject.getMsisdn()+"] sendToSoapHlr bean null so not processing further bean is["+sentToSoapHlr+"]");
                    	Global.req_queue.put(dataObject); //try agin for that msisdn
                    	responseCode = -3;
                    }
		       }   
	    	   
	       }
	       else
	       {
	    	   dataObject.setResponse("-1");
	           logger.info("##>>getMsisdn()["+dataObject.getMsisdn()+"] HlrId not found so FAIL");
	       }
	    		   
	    }
	       
	  if(dataObject.getHlrReqId()!=-1 && dataObject.getHlrReqId()!=-22)
	  {
		  logger.info("##>>msisdn["+dataObject.getMsisdn()+"] CRBT_HLR_INACTIVE case done successfully with resp["+dataObject.getResponse()+"]");
	  }
	  else if (dataObject.getHlrReqId() == -22) //setSubTypeCase
	  {
		    //case not required
		  if(dataObject.getResponse().equals("0")) //got success from Hlr
		  {
			  dbops = new Dboperation();
			  dbops.updateSubType(dataObject);
			  logger.info("##>>msisdn["+dataObject.getMsisdn()+"] CRBT_SUBSCRIBER_MASTER case done successfully with resp["+dataObject.getResponse()+"]");
		  }
		  else
		  {
			  dbops = new Dboperation();
			  dbops.decrementCounter();
			  logger.info("##>>msisdn["+dataObject.getMsisdn()+"] response not success from Hlr G/w response["+dataObject.getResponse()+"] setSubTypeCounter decrement successfully...");
		  }  
		    
	   }
	   else if(responseCode !=-2 && responseCode!=-3) 
	   {	
	      Global.resp_queue.add(dataObject); 
	   }
	  
	  
	  
	  
	 }
	 catch(NullPointerException nullexp)
	 {
		 nullexp.printStackTrace();
	 }
	 catch (Exception exp) {
		 exp.printStackTrace();
	 }
		
	
		
	}
	
	private int processAfterReconnect(DataObject dataObject , HlrInterface<TelnetRequestHandler> sentToTelentHlr)	
	{
		int retcode = -1;
		try
		{
			responseCode = sentToTelentHlr.doProcessing(dataObject);
			logger.info("##>>isnied processAfterReconnect getMsisdn()["+dataObject.getMsisdn()+"] Success Response ["+dataObject.getResponse()+"]");
            if(responseCode == 1 && dataObject.getResponse().equals("0"))
            {
            	retcode = 1;            
            }
            else if(responseCode == -2) {

            	Global.req_queue.put(dataObject);
            	retcode = -2;
			}
            else {
				retcode = -4;
			}
            return retcode;
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		return -1;
	}

}
