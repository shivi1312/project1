package com.telemune.hlr;

import java.util.concurrent.atomic.AtomicInteger;

import com.telemune.hlr.backend.HttpRequestHandler;
import com.telemune.hlr.backend.SoapRequestHandler;
import com.telemune.hlr.backend.TelnetRequestHandler;

/**
 * This class define all the fields of CEBT_HLR_CONFIG table.
 * @author Harjinder
 * */
public class HlrBean {

	private String hlrType = "NA";
	private ObjectPool<TelnetRequestHandler> telnet_pool = null;
	private ObjectPool<HttpRequestHandler> http_pool = null;
	private ObjectPool<SoapRequestHandler> soap_pool = null;
	
	/**New Parameters**/
	private String remoteUser;
	private String remotePassword;
	private String remoteTermonator;
	private String telnetConfiguredIp;
	private AtomicInteger port;
	private String loginFrmt;
	private String passwordFrmt;
	private String loginValidator;
	private String connectionCheckingCmd;
	private int connectionTimeOut;
	private String telnetRequestForCS;
	private String telnetRequestForCU;
	private String telnetRequestForCD;
	private String httpUrl;
	private int priority;
	private int noOfConnection;
	
	public String getHlrType() {
		return hlrType;
	}
	public void setHlrType(String hlrType) {
		this.hlrType = hlrType;
	}
	public ObjectPool<TelnetRequestHandler> getTelnet_pool() {
		return telnet_pool;
	}
	public void setTelnet_pool(ObjectPool<TelnetRequestHandler> telnet_pool) {
		this.telnet_pool = telnet_pool;
	}
	public ObjectPool<HttpRequestHandler> getHttp_pool() {
		return http_pool;
	}
	public void setHttp_pool(ObjectPool<HttpRequestHandler> http_pool) {
		this.http_pool = http_pool;
	}
	public ObjectPool<SoapRequestHandler> getSoap_pool() {
		return soap_pool;
	}
	public void setSoap_pool(ObjectPool<SoapRequestHandler> soap_pool) {
		this.soap_pool = soap_pool;
	}
	public String getRemoteUser() {
		return remoteUser;
	}
	public void setRemoteUser(String remoteUser) {
		this.remoteUser = remoteUser;
	}
	public String getRemotePassword() {
		return remotePassword;
	}
	public void setRemotePassword(String remotePassword) {
		this.remotePassword = remotePassword;
	}
	public String getRemoteTermonator() {
		return remoteTermonator;
	}
	public void setRemoteTermonator(String remoteTermonator) {
		this.remoteTermonator = remoteTermonator;
	}
	public String getTelnetConfiguredIp() {
		return telnetConfiguredIp;
	}
	public void setTelnetConfiguredIp(String telnetConfiguredIp) {
		this.telnetConfiguredIp = telnetConfiguredIp;
	}
	public AtomicInteger getPort() {
		return port;
	}
	public void setPort(AtomicInteger port2) {
		this.port = port2;
	}
	public String getLoginFrmt() {
		return loginFrmt;
	}
	public void setLoginFrmt(String loginFrmt) {
		this.loginFrmt = loginFrmt;
	}
	public String getPasswordFrmt() {
		return passwordFrmt;
	}
	public void setPasswordFrmt(String passwordFrmt) {
		this.passwordFrmt = passwordFrmt;
	}
	public String getLoginValidator() {
		return loginValidator;
	}
	public void setLoginValidator(String loginValidator) {
		this.loginValidator = loginValidator;
	}
	public String getConnectionCheckingCmd() {
		return connectionCheckingCmd;
	}
	public void setConnectionCheckingCmd(String connectionCheckingCmd) {
		this.connectionCheckingCmd = connectionCheckingCmd;
	}
	public int getConnectionTimeOut() {
		return connectionTimeOut;
	}
	public void setConnectionTimeOut(int connectionTimeOut) {
		this.connectionTimeOut = connectionTimeOut;
	}
	public String getTelnetRequestForCS() {
		return telnetRequestForCS;
	}
	public void setTelnetRequestForCS(String telnetRequestForCS) {
		this.telnetRequestForCS = telnetRequestForCS;
	}
	public String getTelnetRequestForCU() {
		return telnetRequestForCU;
	}
	public void setTelnetRequestForCU(String telnetRequestForCU) {
		this.telnetRequestForCU = telnetRequestForCU;
	}
	public String getTelnetRequestForCD() {
		return telnetRequestForCD;
	}
	public void setTelnetRequestForCD(String telnetRequestForCD) {
		this.telnetRequestForCD = telnetRequestForCD;
	}
	public String getHttpUrl() {
		return httpUrl;
	}
	public void setHttpUrl(String httpUrl) {
		this.httpUrl = httpUrl;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public int getNoOfConnection() {
		return noOfConnection;
	}
	public void setNoOfConnection(int noOfConnection) {
		this.noOfConnection = noOfConnection;
	}
	@Override
	public String toString() {
		return "HlrBean [hlrType=" + hlrType + ", telnet_pool=" + telnet_pool
				+ ", http_pool=" + http_pool + ", soap_pool=" + soap_pool
				+ ", remoteUser=" + remoteUser + ", remotePassword="
				+ remotePassword + ", remoteTermonator=" + remoteTermonator
				+ ", telnetConfiguredIp=" + telnetConfiguredIp + ", port="
				+ port + ", loginFrmt=" + loginFrmt + ", passwordFrmt="
				+ passwordFrmt + ", loginValidator=" + loginValidator
				+ ", connectionCheckingCmd=" + connectionCheckingCmd
				+ ", connectionTimeOut=" + connectionTimeOut
				+ ", telnetRequestForCS=" + telnetRequestForCS
				+ ", telnetRequestForCU=" + telnetRequestForCU
				+ ", telnetRequestForCD=" + telnetRequestForCD + ", httpUrl="
				+ httpUrl + ", priority=" + priority + ", noOfConnection="
				+ noOfConnection + "]";
	}
	
	
}
