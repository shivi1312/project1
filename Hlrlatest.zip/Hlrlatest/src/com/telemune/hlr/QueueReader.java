package com.telemune.hlr;

import java.util.concurrent.ThreadPoolExecutor;

import FileBaseLogging.FileLogWriter;

import com.db.CacheLoader;
import com.telemune.hlr.backend.DataObject;

/**
 * This thread read data from req queue and creates new thread inside Thread Pool.
 * @author Harjinder
 * */

public class QueueReader implements Runnable{
	
	ThreadPoolExecutor hlrexecutor = null;
	int maxPollSize;
	CacheLoader cacheLoader = null;
	Thread monitorTh = null;
	
	
	/**
	 * It is a parameterized constructor 
	 * @param hlrexecutor
	 * @param maxPollSize
	 * @param cacheLoader
	 * */
	public QueueReader(ThreadPoolExecutor hlrexecutor , int maxPollSize , CacheLoader cacheLoader , Thread monitorTh ) {
	this.hlrexecutor = hlrexecutor;
	this.maxPollSize = maxPollSize;
	this.cacheLoader = cacheLoader;
	this.monitorTh   = monitorTh;
	}
	
	/**
	 * It is a run method provided by Runnable interface.It define the logic to get data from queue and creates new thread.  
	 * */
	public void run() {
	
		while(true)
		{
		try
		{
			if(Global.req_queue.size()<=0)
			{
				    Thread.sleep(Global.REQ_QUEUE_READER_THRD_SLP_TIME);
			}
			else
			{
				
				if(monitorTh != null)
				{
					if(monitorTh.isAlive())
					{
						Thread.sleep(Global.REQ_QUEUE_READER_THRD_SLP_TIME);
					}
				}
				
				DataObject dataObject = Global.req_queue.poll();
				hlrexecutor.execute(new HlrExecutor(dataObject , cacheLoader));
				
			}	
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		}
		
	}

}
