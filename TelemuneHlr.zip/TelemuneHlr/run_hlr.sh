#!/bin/bash
#cd /data/sdpuser/development/TelemuneHlrJavaDualDb_V4_2_2_1/
cd /data/sdpuser/development/TelemuneHlrJava

java -Xms256m -Xmx1050m -Djava.ext.dirs=lib/. -jar TelemuneHlr.jar >>OUT >>OUT

