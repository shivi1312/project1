package com.redhat.springDemo;

import org.springframework.stereotype.Component;

@Component
public class Laptop {

	public void compile() {
		System.out.println("lets compile the code");
		
	}

}
