package com.telemune.smsgateway;

public class ProcessThread {
	 public static int minThreadSize = 2;
	 /*public static int maxThreadSize = 4;
	 public static int waitQueueSize = 100;*/
	 public static int maxThreadSize = 40;
	 public static int waitQueueSize = 40;
	 public static int arrayBlockingSize= 2;

}
