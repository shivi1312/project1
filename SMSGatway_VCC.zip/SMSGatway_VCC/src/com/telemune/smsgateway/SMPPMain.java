package com.telemune.smsgateway;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.telemune.smsgateway.bean.HandleDelvryRespBean;
import com.telemune.smsgateway.handler.SubmitMsgProducer;

import FileBaseLogging.FileLogWriter;

/**
 * THIS CLASS IS MAIN CLASS WHICH ACTIVATES THE ALL THEADS AND START THE BINARY
 * 
 * @author ekansh
 * @version :- R1_0_0_0
 */
public class SMPPMain {

	static Logger logger = Logger.getLogger("mainClient");
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	final static String SITE = "SMSGATEWAY_JAVA";//3.2.8.0
	final static String VERSION = "R3_3_0_4";
	final static String LICENSEE = "Telemune";
	final static String LICENSEE_ID = "08981Telemune98Client00909";

	static Thread thCacheLoader;
	static Thread thMemoryCleanUp;
	static Thread gmatReader;
	static Thread smppSubmit;
	static Thread conBindThrd;
	static Thread smsSendThrd;
	static Thread rvcThrd;
	static Thread flwThrd;
	static Thread proHitThrd;
	static Connection con = null;
	static Thread hertBeatSrvr;
	static Thread hertBeatCli;
	static ThreadPoolExecutor thExecute;
	static ThreadPoolExtrProcessHandler processHitHandle;
	static Thread failedMessageReaderThread;
	static Thread retryProcessorThread;

	static boolean startProcess = false;

	public static void main(String[] args) {
		try {
			if (args[0].equalsIgnoreCase("-v")) {
				printInfo();
				System.exit(1);
			}
		} catch (Exception Arrayoutex) {
			// System.out.println("Starts...."+Arrayoutex.toString());
		}

		try {
			printInfo();

			// going to load properties
			loadProperties();

			int waiting = 2100; // default port
			boolean isServerUp = false;

			if (Global.enableHeartBeat == 1) {
				if (Global.isActive == 1) // active
				{
					// start listener
					// startProcess=truenone
					HeartBeatClientClass hertBtCli = new HeartBeatClientClass();
					hertBeatCli = new Thread(hertBtCli);
					hertBeatCli.start();
					Global.isActivateServer = false;
					while (true) {
						if (Global.isActivateServer) {
							logger.info("Inside Active server.............isSerfverUp............." + isServerUp);
							handleProcessStartStop(Global.cacheloadTime, true);
							isServerUp = true;

						} else {
							logger.info("....................isServerUp........" + isServerUp);
							if (isServerUp) {
								handleProcessStartStop(Global.cacheloadTime, false);
								isServerUp = false;
							} else {
								Thread.sleep(100);
							}

						}

						if (!hertBeatCli.isAlive()) {
							hertBtCli = new HeartBeatClientClass();
							hertBeatCli = new Thread(hertBtCli);
							hertBeatCli.start();
						}

					}

				} else {
					HeartBeatServerClass hertBtSrv = new HeartBeatServerClass();
					hertBeatSrvr = new Thread(hertBtSrv);
					hertBeatSrvr.start();
					handleProcessStartStop(Global.cacheloadTime, true);

					while (true) {
						if (!hertBeatSrvr.isAlive()) {
							hertBtSrv = new HeartBeatServerClass();
							hertBeatSrvr = new Thread(hertBtSrv);
							hertBeatSrvr.start();

						}
					}

				}

			} else {
				handleProcessStartStop(Global.cacheloadTime, true);
			}

		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + Global.errCode
					+ "-00009] [Exception when make connection from data base and start Heart beat system] ERROR ["
					+ e.getMessage() + "]");
			e.printStackTrace();
		} finally {
			try {
				System.out.println("All Threads  stoped: ");
				System.exit(1);
			} catch (Exception e) {
				errorLogger.error("ErrorCode [" + Global.errCode
						+ "-00010] [Exception in finally block when start all running threads] ERROR [" + e.getMessage()
						+ "]");
				e.printStackTrace();
				System.out.println("Threads cannot stoped: " + e.toString());
			}
		}

	}

	// added by avinash 16/03/2018
	private static void loadProperties() {

		Properties chrPro = new Properties();
		int numofcon = -1;
		int accomodation = -1;
		int minnumofcon = 1;
		String dbuser = "NA";
		String dbpass = "NA";
		String dburl = "NA";
		String driver = "NA";
		FileLogWriter submitSmfileWriter = null;
		FileLogWriter submitResfileWriter = null;
		FileLogWriter delRecieptfileWriter = null;
		FileLogWriter errfileWriter = null;

		try {
			FileInputStream fins = new FileInputStream("properties/smsgateway.properties");
			chrPro.load(fins);
			fins.close();
		} catch (IOException ioe) {
			errorLogger.error("ErrorCode [" + Global.errCode + "-90002] [IOException when read property file] ERROR ["
					+ ioe.getMessage() + "]");
			ioe.printStackTrace();
			// System.out.println(ioe.getMessage());
			System.exit(1);
		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + Global.errCode + "-00007] [Exception when read Property file] ERROR ["
					+ e.getMessage() + "]");
			e.printStackTrace();
		}

		try {
			logger.info("Loading Configuration for the Application and Data Base Connectivity");
			
			
			PropertyConfigurator.configureAndWatch("properties/smsgateway_log.properties",Long.parseLong(chrPro.getProperty("LOGGER_FILE_REFRESH_INTERVAL").trim()));
			
			logger.debug("Database Connectivity");
			
			
			
			
			Global.dbConfigParamEnable = Integer.parseInt(chrPro.getProperty("DB_CON_PARAM"));
			// LODING MYSQL CONFIGURATION
			// PARAMTERS................................
			
			
			
			dbuser = chrPro.getProperty("DBUSER").trim();
			dbpass = chrPro.getProperty("DBPASSWORD").trim();
			dburl = chrPro.getProperty("DBURL").trim();
			driver = chrPro.getProperty("DRIVER").trim();
			logger.info("Loading Threads Information");
			numofcon = Integer.parseInt(chrPro.getProperty("NUM_OF_CONNECTION").trim());
			minnumofcon = Integer.parseInt(chrPro.getProperty("MIN_NUM_OF_CONNECTION").trim());
			accomodation = Integer.parseInt(chrPro.getProperty("DB_ACCOMODATION").trim());
			Global.cacheloadTime = Integer.parseInt(chrPro.getProperty("RELOAD_TIME").trim());
			Global.memoryCleanTime = Integer.parseInt(chrPro.getProperty("MEMORY_CLEAN_TIME").trim()); // added by Avishkar
			// windowSize=Integer.parseInt(chrPro.getProperty("WINDOW_SIZE").trim());

			// Global.messageWindowSize=windowSize;

			// added on 04/10/2017 - by avinash
			// Global.messageLength=Integer.parseInt(chrPro.getProperty("MESSAGE_LENGTH").trim());
			Global.defaultMsgMaxLength = Integer.parseInt(chrPro.getProperty("DEFAULT_MESSAGE_LENGTH").trim());
			Global.ucs2MsgMaxLength = Integer.parseInt(chrPro.getProperty("UCS2_MESSAGE_LENGTH").trim());
			Global.utf8MsgMaxLength = Integer.parseInt(chrPro.getProperty("UTF8_MESSAGE_LENGTH").trim());

			Global.urlHitTimeout = Integer.parseInt(chrPro.getProperty("HITURL_TIMEOUT").trim());
			Global.readurlHitTimeout = Integer.parseInt(chrPro.getProperty("READHITURL_TIMEOUT").trim());

			Global.appUrl = chrPro.getProperty("APP_URL").trim();
			Global.deliverSmEncoding = chrPro.getProperty("DELIVER_SM_ENCODING").trim();

			// THIS IS FOR HANDLE THE DEL REcipt HIT URL
			Global.enableDelRecptUrlHit = Integer.parseInt(chrPro.getProperty("ENBL_DEL_RECPT_HIT").trim());
			Global.delRcptUrl = chrPro.getProperty("DEL_RECPT_URL").trim();

			Global.submitSmCharEncoding = chrPro.getProperty("SUBMIT_SM_ENCODING").trim();
			Global.submitSmUDH = Integer.parseInt(chrPro.getProperty("ENABLE_UDH"));

			Global.WriteLgsInDB_Enable = Integer.parseInt(chrPro.getProperty("WRITE_DB_LOGS").trim());

			Global.isDeliveryReportEnable = Integer.parseInt(chrPro.getProperty("DELIVERY_RECIEPT_ENABLE"));
			Global.rbtList=chrPro.getProperty("RBT","0").split(";");
			Global.urlAppender=chrPro.getProperty("URL_PARAM_APPENDER","");
			Global.relaseServiceType=chrPro.getProperty("RELEASE_SERVICE_TYPE","RELC");
			
			// Setting up the filewriter parameters for submit sm file
			// ..................
			submitSmfileWriter = new FileLogWriter();
			submitSmfileWriter.setNewFileInterval(Integer.parseInt(chrPro.getProperty("SUB_SM_LOG_FILE_INTERVAL")));
			submitSmfileWriter.setFilename(chrPro.getProperty("SUB_SM_LOG_FILENAME"));
			submitSmfileWriter.setFilePath(chrPro.getProperty("SUB_SM_LOG_FILEPATH"));
			submitSmfileWriter.setArchiveFilePath(chrPro.getProperty("SUB_SM_LOG_FILEPATH_ARCH"));
			submitSmfileWriter.setArchiveFilename(chrPro.getProperty("SUB_SM_LOG_FILENAME_ARCH"));

			submitSmfileWriter.setArchiveFileExtension(".d");
			submitSmfileWriter.initialize();
			// ==============================================================================

			// Setting up the filewriter parameters for submit sm response
			// file ..................
			submitResfileWriter = new FileLogWriter();
			submitResfileWriter.setNewFileInterval(Integer.parseInt(chrPro.getProperty("SUB_RES_LOG_FILE_INTERVAL")));
			submitResfileWriter.setFilename(chrPro.getProperty("SUB_RES_LOG_FILENAME"));
			submitResfileWriter.setFilePath(chrPro.getProperty("SUB_RES_LOG_FILEPATH"));
			submitResfileWriter.setArchiveFilePath(chrPro.getProperty("SUB_RES_LOG_FILEPATH_ARCH"));
			submitResfileWriter.setArchiveFilename(chrPro.getProperty("SUB_RES_LOG_FILENAME_ARCH"));
			submitResfileWriter.setArchiveFileExtension(".d");
			submitResfileWriter.initialize();

			// ==============================================================================

			// Setting up the filewriter parameters for delivery reciept
			// response file ..................
			delRecieptfileWriter = new FileLogWriter();
			delRecieptfileWriter.setNewFileInterval(Integer.parseInt(chrPro.getProperty("DEL_RECP_LOG_FILE_INTERVAL")));
			delRecieptfileWriter.setFilename(chrPro.getProperty("DEL_RECP_LOG_FILENAME"));
			delRecieptfileWriter.setFilePath(chrPro.getProperty("DEL_RECP_LOG_FILEPATH"));
			delRecieptfileWriter.setArchiveFilePath(chrPro.getProperty("DEL_RECP_LOG_FILEPATH_ARCH"));
			delRecieptfileWriter.setArchiveFilename(chrPro.getProperty("DEL_RECP_LOG_FILENAME_ARCH"));
			delRecieptfileWriter.setArchiveFileExtension(".d");
			delRecieptfileWriter.initialize();

			// ==================================================================================

			// Setting up the filewriter parameters for error file
			// ..................
			errfileWriter = new FileLogWriter();
			errfileWriter.setNewFileInterval(Integer.parseInt(chrPro.getProperty("ERROR_LOG_FILE_INTERVAL")));
			errfileWriter.setFilename(chrPro.getProperty("ERROR_LOG_FILENAME"));
			errfileWriter.setFilePath(chrPro.getProperty("ERROR_LOG_FILEPATH"));
			errfileWriter.setArchiveFilePath(chrPro.getProperty("ERROR_LOG_FILEPATH_ARCH"));
			errfileWriter.setArchiveFilename(chrPro.getProperty("ERROR_LOG_FILENAME_ARCH"));

			errfileWriter.setArchiveFileExtension(".d");
			errfileWriter.initialize();

			// ==========================LOADING THE HEART BEAT
			// PARAMETER=======================
			Global.enableHeartBeat = Integer.parseInt(chrPro.getProperty("ENABLE_HEART_BEAT").trim());
			Global.heartBeatPort = Integer.parseInt(chrPro.getProperty("HEART_BEAT_PORT").trim());
			Global.heartBeatIp = chrPro.getProperty("HEART_BEAT_IP").trim();
			Global.isActive = Integer.parseInt(chrPro.getProperty("HEART_BEAT_IS_ACTIVE").trim());

			// ==================================================================================

			// ==========================LOADING CAMPAIGN
			// PARAMETER=======================
			Global.enableCampaignId = Integer.parseInt(chrPro.getProperty("ENABLE_CAMPAIGN_ID").trim());

			// ==========================LOADING PROTOCOL ID
			// PARAMETER=======================
			Global.enableProtocolId = Integer.parseInt(chrPro.getProperty("ENABLE_PROTOCOL_ID").trim());

			// ==========================LOADING CAMPAIGN
			// PARAMETER=======================
			Global.enableValidityPeriod = Integer.parseInt(chrPro.getProperty("ENABLE_VALIDITYPERIOD").trim());

			// ==========================LOAD BALANCING
			// PARAMETER=======================
			Global.loadBalance = Integer.parseInt(chrPro.getProperty("ENABLE_LOAD_BALANCE").trim());
			// ============================SUBMIT DESTINATION
			// NPI==========================
			Global.SubmitDestinationNPI = Integer.parseInt(chrPro.getProperty("DESTINATIONNPI"));
			// ============================SUBMIT DESTINATION
			// NPI==========================
			Global.SubmitOriginationNPI = Integer.parseInt(chrPro.getProperty("ORIGINATIONNPI"));

			// ============================SUBMIT DESTINATION
			// NPI==========================
			Global.SubmitOriginationTON = Integer.parseInt(chrPro.getProperty("ORIGINATIONTON"));

			// ============================Virtual
			// IP==========================
			Global.localHost = chrPro.getProperty("LOCALHOST");

			// ============================Virtual Port====================
			Global.localPort = Integer.parseInt(chrPro.getProperty("LOCALPORT"));

			// ============================Origination number
			// length====================
			Global.orgNumLength = Integer.parseInt(chrPro.getProperty("ORGNUMLENGTH"));

			// ============================Enable opcode====================
			Global.opCode = Integer.parseInt(chrPro.getProperty("OPCODE"));

			// ============================MIN Thread====================
			ProcessThread.minThreadSize = Integer.parseInt(chrPro.getProperty("MINTHREAD"));

			// ============================MAX Thread====================
			ProcessThread.maxThreadSize = Integer.parseInt(chrPro.getProperty("MAXTHREAD"));
			// ============================Wait queue
			// size====================
			ProcessThread.waitQueueSize = Integer.parseInt(chrPro.getProperty("WAITQUEUESIZE"));
			// ============================Size of Array Blocking
			// ====================
			ProcessThread.arrayBlockingSize = Integer.parseInt(chrPro.getProperty("ArrayQUEUESIZE"));
			Global.threadMonitorDelayTime = Integer.parseInt(chrPro.getProperty("ThreadMoniterdelayTime"));

			Global.addressrange = Integer.parseInt(chrPro.getProperty("ENABLEADDRESSRANGE"));
			Global.gmatSmscConfigTable = chrPro.getProperty("GMAT_SMSC_CONFIG");
			Global.gmatMessageStoreTable = chrPro.getProperty("GMAT_MESSAGE_STORE");
			// ===========================================================================

			Global.countryCodeEnable = Integer.parseInt(chrPro.getProperty("CountryCodeEnable"));
			Global.countryCode = chrPro.getProperty("CountryCode");

			System.out.println(Global.SUBMIT_SM_REQUEST);
			Global.flwGateway[Global.SUBMIT_SM_REQUEST] = submitSmfileWriter;

			Global.flwGateway[Global.SUBMIT_SM_RESPONSE] = submitResfileWriter;

			Global.flwGateway[Global.DELIVERY_RECIEPT] = delRecieptfileWriter;
			Global.flwGateway[Global.ERROR_FILE] = errfileWriter;

			// ===============================================================================
			Global.errCode = chrPro.getProperty("errCode");

			Global.optEnable = Integer.parseInt(chrPro.getProperty("optEnable"));
			Global.enableSmsgInsertion = Integer.parseInt(chrPro.getProperty("ENABLE_SMSG_INSERTION"));
			Global.gmatReaderCounter = Integer.parseInt(chrPro.getProperty("GMAT_READER_COUNTER"));

			// =================== added by avinash on 16 Aug 2017 to set
			// custom dcs enocding
			Global.dcsEnable = Integer.parseInt(chrPro.getProperty("DCS_ENABLE").trim());
			Global.dcsEncoding = chrPro.getProperty("DCS_ENCODING").trim();

			// =================== added by avinash on 13/02/2018 to
			// generate sequence number uding database
			Global.generateSeqNumberFromDB = Integer.parseInt(chrPro.getProperty("GENERATE_SEQ_NUM_FROM_DB").trim());

			// =================== added by avinash on 16/03/2018
			// configurations for retry feature
			Global.isRetryEnable = Integer.parseInt(chrPro.getProperty("IS_RETRY_ENABLE").trim());
			Global.numberOfRetry = Integer.parseInt(chrPro.getProperty("NUMBER_OF_RETRY").trim());
			Global.retryAfterMinutes = Integer.parseInt(chrPro.getProperty("RETRY_AFTER_MINUTES").trim());
			Global.priority=Byte.parseByte(chrPro.getProperty("DEFAULT_PRIORITY", "0").trim());
			if(Global.priority>9) {
				Global.priority=0;
			}
			
			
			
			Global.serviceType=chrPro.getProperty("SERVICE_TYPE", "").trim();
			Global.serviceTypeDeliver=chrPro.getProperty("SERVICE_TYPE_DELIVER", "USSRC").trim();
			Global.responseMessage=chrPro.getProperty("SERVICE_TYPE_DELIVER_MSG", "Test").trim();
			
			Global.enableServiceType=chrPro.getProperty("ENABLE_SERVICE_TYPE", "-1").trim();
			Global.dbFetchSize=chrPro.getProperty("DB_FETCH_SIZE","100").trim();
			
			
			String retryForStatusCode = chrPro.getProperty("RETRY_FOR_STATUS_CODE").trim();
			String[] retryForStatusCodeArr = retryForStatusCode.split(",");
			StringBuffer retryForStatusCodeBuffer = new StringBuffer();
			for (String string : retryForStatusCodeArr) {
				retryForStatusCodeBuffer.append("\'");
				retryForStatusCodeBuffer.append(string);
				retryForStatusCodeBuffer.append("\',");
			}
			Global.retryForStatusCode = retryForStatusCodeBuffer.toString().substring(0,
					retryForStatusCodeBuffer.toString().length() - 1);
			logger.info("retry for status code[" + Global.retryForStatusCode + "]");
			retryForStatusCodeBuffer = null;

			String excludeOriginNumber = chrPro.getProperty("EXCLUDE_ORIGIN_NUMBER").trim();
			String[] excludeOriginNumberArr = excludeOriginNumber.split(",");
			StringBuffer excludeOriginNumberBuffer = new StringBuffer();
			for (String string : excludeOriginNumberArr) {
				excludeOriginNumberBuffer.append("\'");
				excludeOriginNumberBuffer.append(string);
				excludeOriginNumberBuffer.append("\',");
			}
			
			Global.excludeOriginNumber = excludeOriginNumberBuffer.toString().substring(0,
					excludeOriginNumberBuffer.toString().length() - 1);
			logger.info("exclude orgination number from retry[" + Global.excludeOriginNumber + "]");
			excludeOriginNumberBuffer = null;

		} catch (NullPointerException expset) {
			errorLogger.error("ErrorCode [" + Global.errCode
					+ "-90003] [Exception when read path of Property file] ERROR [" + expset.getMessage() + "]");
			expset.printStackTrace();
			System.exit(1);
		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + Global.errCode
					+ "-00008] [Exception when read Property file There is any missing parameter in property file] ERROR ["
					+ e.getMessage() + "]");
			e.printStackTrace();
			System.exit(1);
		}
		logger.info("Intializing Database..." + chrPro.toString());

		Global.conPool = new ConnPool(driver, dburl, dbuser, dbpass, minnumofcon, numofcon, accomodation);
		Global.conPool.MakePool();

	}

	/**
	 * THIS FUNCTION IS FOR HANDLE ALL THE PROCESSING THREADS
	 */
	public static void handleProcessStartStop(int cacheloadTime, boolean start) {
		if (start)

		{
			logger.info(
					"Starting Telemune SMSGATEWAY JAVA  Application .............." + Global.conPool.getConnection());

			logger.debug("After Sleep ...................");

			CacheLoader cl = new CacheLoader(cacheloadTime);
			// cl.loadAppConfigParams();
			
			cl.LoadSMSCConfigParams();

			GmatReaderClass gmatRead = new GmatReaderClass();

			logger.info("The size of smsc parameters hashtable........" + Global.smscParamDetail.size());
			// starting the cache loader thread...............
			thCacheLoader = new Thread(cl);
			thCacheLoader.start();
			
			// Added by Avishkar start
			MemoryCleanUp memoryCleanUp = new MemoryCleanUp(Global.memoryCleanTime);
			thMemoryCleanUp = new Thread(memoryCleanUp);
			thMemoryCleanUp.start();
			// Added by Avishkar ends
			
			SMSRecieverTask reciverTask = new SMSRecieverTask();
			rvcThrd = new Thread(reciverTask);
			rvcThrd.start();

			// starting connect and bind thread...........SMPPConnectAndBind
			SMPPConnectAndBind connectBind = new SMPPConnectAndBind();
			conBindThrd = new Thread(connectBind);
			conBindThrd.start();
			// starting the Reciver thread here
			// .......................SMSReciverTask....
			// starting URL hit thread here .........................
			// ProcessHitUrl
			thExecute = new ThreadPoolExecutor(ProcessThread.minThreadSize, ProcessThread.maxThreadSize,
					ProcessThread.waitQueueSize, TimeUnit.SECONDS,
					new ArrayBlockingQueue<Runnable>(ProcessThread.arrayBlockingSize), new RejectedWorkHandler());
			processHitHandle = new ThreadPoolExtrProcessHandler(thExecute);
			proHitThrd = new Thread(processHitHandle);
			proHitThrd.start();

			logger.info("Intializing ThreadMonitor Thread...");
			ThreadMonitor thMonitor = new ThreadMonitor(thExecute, Global.threadMonitorDelayTime);
			Thread monitorThread = new Thread(thMonitor);
			monitorThread.start();

			/*
			 * ` urlHit= new ProcessHitUrl(); proHitThrd= new
			 * Thread(urlHit); proHitThrd.start();
			 */
			// starting gmatReader Thread
			// SMSMonitor..............GmatReaderClass
			gmatRead = new GmatReaderClass();
			gmatReader = new Thread(gmatRead);
			gmatReader.start();

			// starting SMPPSubmit THread
			// here......................SMSSenderTask.....

			SMPPSubmitMessage sendTask = new SMPPSubmitMessage();
			smsSendThrd = new Thread(sendTask);
			smsSendThrd.start();

			// Starting file WRITING
			// THREAD.............................WriteFileLogs.
			WriteFileLogs flwLogs = new WriteFileLogs();
			flwThrd = new Thread(flwLogs);
			flwThrd.start();

			// added by avinash on 16/03/2017
			// starting threads for retry feature
			FailedMessageReader failedMessageReader = null;
			RetryProcessor retryProcessor = null;
			if (Global.isRetryEnable == 1) {
				failedMessageReader = new FailedMessageReader();
				failedMessageReaderThread = new Thread(failedMessageReader);
				failedMessageReaderThread.start();

				retryProcessor = new RetryProcessor();
				retryProcessorThread = new Thread(retryProcessor);
				retryProcessorThread.start();

			}

			// logger.info("Intializing Threads...");
			// int waitCount=0;
			logger.info("Application Started Successfully...");

			while (true) {
				try {
					if (!thCacheLoader.isAlive()) {
						cl = new CacheLoader(cacheloadTime);
						thCacheLoader = new Thread(cl);
						thCacheLoader.start();
					}
				} catch (Exception e) {
					errorLogger.error("ErrorCode [" + Global.errCode
							+ "-00011] [Exception when cacheloader thread is not alive] ERROR [" + e.getMessage()
							+ "]");

					e.printStackTrace();
					System.out.println("got exception in  thread" + e);
					System.exit(1);
				}

				try {
					if (!gmatReader.isAlive()) {
						gmatRead = new GmatReaderClass();
						gmatReader = new Thread(gmatRead);
						gmatReader.start();
					}
				} catch (Exception e) {
					errorLogger.error("ErrorCode [" + Global.errCode
							+ "-00012] [Exception when GmatReader thread is not alive] ERROR [" + e.getMessage() + "]");
					e.printStackTrace();
					System.out.println("got exception in  thread" + e);
					System.exit(1);
				}

				// ------------------------
				try {
					if (!conBindThrd.isAlive()) {
						connectBind = new SMPPConnectAndBind();
						conBindThrd = new Thread(connectBind);
						conBindThrd.start();
					}
				} catch (Exception e) {
					errorLogger.error("ErrorCode [" + Global.errCode
							+ "-00013] [Exception when Connect and bind thread is not alive] ERROR [" + e.getMessage()
							+ "]");
					e.printStackTrace();
					System.out.println("got exception in  thread" + e);
					System.exit(1);
				}

				try {
					if (!smsSendThrd.isAlive()) {
						sendTask = new SMPPSubmitMessage();
						smsSendThrd = new Thread(sendTask);
						smsSendThrd.start();
					}
				} catch (Exception e) {
					errorLogger.error("ErrorCode [" + Global.errCode
							+ "-00014] [Exception when Submit Sm Thread is not alive] ERROR [" + e.getMessage() + "]");
					e.printStackTrace();
					System.out.println("got exception in  thread" + e);
					System.exit(1);
				}
				try {
					if (!rvcThrd.isAlive()) {
						reciverTask = new SMSRecieverTask();
						rvcThrd = new Thread(reciverTask);
						rvcThrd.start();
					}
				} catch (Exception e) {
					errorLogger.error("ErrorCode [" + Global.errCode
							+ "-00015] [Exception when SMS Receiver thread is not alive] ERROR [" + e.getMessage()
							+ "]");
					e.printStackTrace();
					System.out.println("got exception in  thread" + e);
					System.exit(1);
				}
				try {
					if (!flwThrd.isAlive()) {
						flwLogs = new WriteFileLogs();
						flwThrd = new Thread(flwLogs);
						flwThrd.start();
					}
				} catch (Exception e) {
					errorLogger.error("ErrorCode [" + Global.errCode
							+ "-00016] [Exception when File Writer thread is not alive] ERROR [" + e.getMessage()
							+ "]");
					e.printStackTrace();
					System.out.println("got exception in  thread" + e);
					System.exit(1);
				}

				try {
					if (!proHitThrd.isAlive()) {
						processHitHandle = new ThreadPoolExtrProcessHandler(thExecute);
						proHitThrd = new Thread(processHitHandle);
						proHitThrd.start();

					}

				} catch (Exception e) {
					errorLogger.error("ErrorCode [" + Global.errCode
							+ "-00017] [Exception when Process Hit Handler thread is not alive] ERROR ["
							+ e.getMessage() + "]");
					e.printStackTrace();
					System.out.println("got exception in  thread" + e);
					System.exit(1);
				}

				// Added by Avishkar start
				try {
					if (!thMemoryCleanUp.isAlive()) {
						memoryCleanUp = new MemoryCleanUp(Global.memoryCleanTime);
						thMemoryCleanUp = new Thread(memoryCleanUp);
						thMemoryCleanUp.start();
						
					}

				} catch (Exception e) {
					errorLogger.error("ErrorCode [" + Global.errCode
							+ "-00026] [Exception when MemoryCleanUp thread is not alive] ERROR ["
							+ e.getMessage() + "]");
					e.printStackTrace();
					System.out.println("got exception in  thread" + e);
					System.exit(1);
				}
				// Added by Avishkar end
				
				// to check if retry processing threads are alive
				if (Global.isRetryEnable == 1) {
					try {
						if (!failedMessageReaderThread.isAlive()) {
							failedMessageReader = new FailedMessageReader();
							failedMessageReaderThread = new Thread(failedMessageReader);
							failedMessageReaderThread.start();
						}

					} catch (Exception e) {
						errorLogger.error("ErrorCode [" + Global.errCode
								+ "-00017] [Exception when failedMessageReader thread is not alive] ERROR ["
								+ e.getMessage() + "]");
						e.printStackTrace();
						System.out.println("got exception in  thread" + e);
						System.exit(1);
					}

					try {
						if (!retryProcessorThread.isAlive()) {
							retryProcessor = new RetryProcessor();
							retryProcessorThread = new Thread(retryProcessor);
							retryProcessorThread.start();
						}

					} catch (Exception e) {
						errorLogger.error("ErrorCode [" + Global.errCode
								+ "-00017] [Exception when retryProcessor thread is not alive] ERROR [" + e.getMessage()
								+ "]");
						e.printStackTrace();
						System.out.println("got exception in  thread" + e);
						System.exit(1);
					}
				}

				try {
					
/*		// commented by Avishkar start
					long heapSize = Runtime.getRuntime().totalMemory();

					Runtime runtime = Runtime.getRuntime();
					int mb = 1024 * 1024;
*/		// commented by Avishkar ends
					
					/*
					 * System.out.println("Memmory is ["+(runtime.totalMemory()
					 * - runtime.freeMemory()) / mb+"]"); System.out.println(
					 * "Max memory "+runtime.maxMemory()/mb);
					 * System.out.println("heap size is"+heapSize/mb);
					 */
					logger.debug("All Threads Running Successfully...");
					// temp.sleep(30*60*1000);
					// This is for test only........for detecting the issue of
					// deliver sm
					int waitCount = 0;
					while (waitCount <= 1800) {
						logger.info("size of deliverSm is  " + Global.delverSmRespHndleMap.size());

						if (Global.delverSmRespHndleMap.size() != 0) {

							ArrayList dataAl = new ArrayList(Global.delverSmRespHndleMap.keySet());
							logger.info("Size of Data Al is [ " + dataAl.size() + "] hash table is "
									+ Global.delverSmRespHndleMap);
							for (int i = 0; i < dataAl.size(); i++) {
								HandleDelvryRespBean bean = Global.delverSmRespHndleMap.get((Integer) dataAl.get(i));
								// logger.info("Handle DeliverSm bean is
								// "+bean.toString());
								logger.info("inside main class where map contain some key [" + bean.getSequenceNo()
										+ "] old time [" + bean.getTimeStamp() + "]");
								long timediff = System.currentTimeMillis() - bean.getTimeStamp();
								logger.info("This is the timediffrence [ " + timediff + " ]");
								if (timediff > 5000) {
									logger.info(" WE ARE EXITING FROM GATEWAY BY FORCE ");
									System.exit(1);
								} else {
									Thread.sleep(10000);
								}

							}

						} else {
							logger.info("Insmpp main class where size of delresrecmap ["
									+ Global.delverSmRespHndleMap.size() + "] ");

							Thread.sleep(10000);

						}
						if (!Global.isActivateServer) {
							break;
						}

						waitCount++;
					}

				} catch (Exception e) {
					errorLogger.error("ErrorCode [" + Global.errCode
							+ "-00018] [Exception when handling delivery receipt getting from SMSC] ERROR ["
							+ e.getMessage() + "]");
					// logger.fatal("Sleep Exception in main",eee);
					System.out.println("Sleep Exception in main");
				}
				if (!Global.isActivateServer) {
					break;
				}
			}

		} else {

			// =====================================================
			logger.info("###>>> Going to stop All threads Telemune SMSGATEWAY JAVA  Application .............."); // added by Avishkar

			try {
				if (thCacheLoader.isAlive()) {
					logger.info("###>>> CacheLoader thread going to stop...");
					thCacheLoader.stop();
				}
			} catch (Exception e) {
				errorLogger.error("ErrorCode [" + Global.errCode
						+ "-00019] [Getting Exception when stop Cache Loader Thread] ERROR [" + e.getMessage() + "]");
				e.printStackTrace();
				// logger.info("Exception in stoping thread",e);
			}

			try {
				if (gmatReader.isAlive()) {
					logger.info("###>>> gmatReader thread going to stop...");
					gmatReader.stop();
				}
			} catch (Exception e) {
				errorLogger.error("ErrorCode [" + Global.errCode
						+ "-00025] [Getting Exception when stop Gmat Reader Thread] ERROR [" + e.getMessage() + "]");

				e.printStackTrace();
				// logger.info("Exception in stoping thread",e);
			}

			// ------------------------
			try {
				if (conBindThrd.isAlive()) {
					logger.info("###>>> Going to UnbinedRequest...");
					SMPPConnectAndBind unbineRequest = new SMPPConnectAndBind();
					unbineRequest.sendUnbindRequest();
					logger.info("###>>> conBindThrd thread going to stop...");
					conBindThrd.stop();
				}
			} catch (Exception e) {
				errorLogger.error("ErrorCode [" + Global.errCode
						+ "-00024] [Getting Exception when stop Connect and Bind Thread] ERROR [" + e.getMessage()
						+ "]");
				e.printStackTrace();
				// logger.info("Exception in stoping thread",e);
			}

			try {
				if (smsSendThrd.isAlive()) {
					logger.info("###>>> smsSendThrd thread going to stop...");
					smsSendThrd.stop();
				}
			} catch (Exception e) {
				errorLogger.error("ErrorCode [" + Global.errCode
						+ "-00023] [Getting Exception when stop Submit Message Thread] ERROR [" + e.getMessage() + "]");
				e.printStackTrace();
				// logger.info("Exception in stoping thread",e);
			}
			try {
				if (rvcThrd.isAlive()) {
					logger.info("###>>> rvcThrd thread going to stop...");
					rvcThrd.stop();
				}
			} catch (Exception e) {
				errorLogger.error("ErrorCode [" + Global.errCode
						+ "-00022] [Getting Exception when stop Receiver Task Thread] ERROR [" + e.getMessage() + "]");
				e.printStackTrace();
				// logger.info("Exception in stoping thread",e);
			}
			try {
				if (flwThrd.isAlive()) {
					logger.info("###>>> flwThrd thread going to stop...");
					flwThrd.stop();
				}
			} catch (Exception e) {
				errorLogger.error("ErrorCode [" + Global.errCode
						+ "-00021] [Getting Exception when stop File Writer Thread] ERROR [" + e.getMessage() + "]");
				e.printStackTrace();
				// logger.info("Exception in stoping thread",e);
			}

			try {
				if (proHitThrd.isAlive()) {
					logger.info("###>>> proHitThrd thread going to stop...");
					proHitThrd.stop();
				}
			} catch (Exception e) {
				errorLogger.error("ErrorCode [" + Global.errCode
						+ "-00020] [Getting Exception when stop ProcessHit Thread ] ERROR [" + e.getMessage()
						+ "]");
				e.printStackTrace();
				// logger.info("Exception in stoping thread",e);
			}

			// added by Avishkar start
			if (Global.isRetryEnable == 1) {
				
				try {
					if (failedMessageReaderThread.isAlive()) {
						logger.info("###>>> failedMessageReader thread going to stop...");
						failedMessageReaderThread.stop();
					}

				} catch (Exception e) {
					errorLogger.error("ErrorCode [" + Global.errCode
							+ "-00027] [Getting Exception when stop failedMessageReader thread ] ERROR ["
							+ e.getMessage() + "]");
					e.printStackTrace();
//					logger.info("got exception in  thread" + e);
				}

				try {
					if (retryProcessorThread.isAlive()) {
						logger.info("###>>> retryProcessor thread going to stop...");
						retryProcessorThread.stop();
					}

				} catch (Exception e) {
					errorLogger.error("ErrorCode [" + Global.errCode
							+ "-00028] [Getting Exception when stop retryProcessor thread ] ERROR [" + e.getMessage()
							+ "]");
					e.printStackTrace();
//					logger.info("got exception in  thread" + e);
				}
				
			}
			// added by Avishkar end
			
			// 11111111111111111111111111111111

		}
		/////////////////////////

	}

	private static void printInfo() {
		System.out.println(
				"\n******************************************************************************************");
		System.out.println("\n                          	SMSGATEWAY  Version [  " + VERSION + "  ]");
		System.out.println(
				"\n				Copyright @2004-2015Telemune Software Solutions Private Limited. All rights reserved");
		System.out.println("\n				Name of the Licensee : " + LICENSEE);
		System.out.println("\n				Licence ID: " + LICENSEE_ID);
		System.out.println(
				"\n******************************************************************************************");
		System.out.println("\n");
	}
}
