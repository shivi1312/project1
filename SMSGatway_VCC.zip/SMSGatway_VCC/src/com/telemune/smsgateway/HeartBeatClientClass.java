package com.telemune.smsgateway;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import org.apache.log4j.Logger;
public class HeartBeatClientClass implements Runnable {
Logger logger= Logger.getLogger("HeartBeatClientClass");
final static Logger errorLogger = Logger.getLogger("errorLogger");
	public void run()
	{
		while(true)
		{
		Socket socket=null;
		try{   

		socket=new Socket(Global.heartBeatIp.trim(),Global.heartBeatPort);
		socket.setSoTimeout(4000);
		DataOutputStream dout=new DataOutputStream(socket.getOutputStream());  
		dout.writeUTF("Hello Server");  
		dout.flush();  
         DataInputStream in =
                        new DataInputStream(socket.getInputStream());
		String serverStr=in.readUTF();
		logger.info("This is the response which server sends......."+serverStr);
		in.close();
		dout.close();  
		socket.close();
		
		if(serverStr.trim().equalsIgnoreCase("alive"))
		{
			Global.isActivateServer=false;
			Thread.sleep(3000);
			
		}else
		{
			Global.isActivateServer=true;
		}
		
		
		}
	/*	catch(SocketException socExe)
		{
			 errorLogger.error("ErrorCode ["+Global.errCode+"-90011] IP ["+Global.heartBeatIp+"] Port["+Global.heartBeatPort+"] [SocketTimeOut Exception while Connecting to Server SMSGateway] Error[" + socExe.getMessage()+"]");
			 socExe.printStackTrace();
		}
		catch (IOException e) {
			errorLogger.error("ErrorCode ["+Global.errCode+"-90002] IP ["+Global.heartBeatIp+"] Port["+Global.heartBeatPort+"] [IOException Exception while transfer data to Server SMSGateway] Error[" + e.getMessage()+"]");
			 e.printStackTrace();
		}*/
		catch(Exception exe){
			errorLogger.error("ErrorCode ["+Global.errCode+"-00039] IP ["+Global.heartBeatIp+"] Port["+Global.heartBeatPort+"] [Exception when connecting to server SMSGateway] ERROR ["+exe.getMessage()+"]");
			exe.printStackTrace();
			//	logger.info(exe);
			Global.isActivateServer=true;
			try
			{
				Thread.sleep(3000);
			}
			catch(InterruptedException ie)
			{
				 errorLogger.error("ErrorCode ["+Global.errCode+"-90013] IP ["+Global.heartBeatIp+"] Port["+Global.heartBeatPort+"] [InterruptedException when HearBeat Client thread going to sleep] Error[" + ie.getMessage()+"]");
				 ie.printStackTrace();
			}

		}  
		 
		}
		
	}
}
