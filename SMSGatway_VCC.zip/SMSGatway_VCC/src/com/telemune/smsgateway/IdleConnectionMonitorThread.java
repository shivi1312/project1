package com.telemune.smsgateway;

import java.util.concurrent.TimeUnit;

import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.log4j.Logger;

public class IdleConnectionMonitorThread extends Thread {
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	final static Logger logger = Logger
			.getLogger(IdleConnectionMonitorThread.class);
	private final HttpClientConnectionManager connMgr;
	private volatile boolean shutdown;

	public IdleConnectionMonitorThread(
			PoolingHttpClientConnectionManager connMgr) {
		super();
		this.connMgr = connMgr;
	}

	@Override
	public void run() {
		try {
			while (!shutdown) {
				synchronized (this) {
					wait(1000);
					connMgr.closeExpiredConnections();
				//	connMgr.closeIdleConnections(HttpConfig.config.getInt(
				//			"ideal.connection.timeout", 30), TimeUnit.SECONDS);
					connMgr.closeIdleConnections(HttpConfig.config.getInt(
							"ideal.connection.timeout", 2), TimeUnit.SECONDS); // modified by Avishkar
					
				}
			}
		} catch (InterruptedException e) {
			errorLogger.error("ErrorCode ["+Global.errCode+"-90013] [InterruptedException while Close expired http connection ] Error[" + e.getMessage()+"]");
			 e.printStackTrace();
			shutdown();
		}
		catch(Exception exe)
		{
			errorLogger.error("ErrorCode ["+Global.errCode+"-00045] [Exception while Close expired http connection] ERROR ["+exe.getMessage()+"]");
			exe.printStackTrace();
			
		}
	}

	public void shutdown() {
		shutdown = true;
		synchronized (this) {
			notifyAll();
		}
	}
}
