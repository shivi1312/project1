package com.telemune.smsgateway;
/**
 * THIS IS THE POJO CLASS IS FOR HANDLING THE INFORMATION OF LONG MESSAGE
 * @author ekansh
 *@version :-R1_0_0_0
 */

public class LongMessageInfoBean {
	
	
	private String[] messageText;
	private int totalPart;
	private long timeStamp;
	private int partNum;
	private int msgRefNUm;
	private boolean isDestPort=false;
	private int destPort=-1;
	private int msgCount;
	private boolean isAllMsgRecv=false;
	
	
	
	
	/**
	 * THIS IS THE PARAMTERIZED CONSTRUCTOR OF LongMessageInfoBean().....
	 * @param totalPart :-REFRES TO THE TOTAL PATR OF THE MESSGAE CONTAIN
	 */
	
	
	public LongMessageInfoBean( int totalPart) {
		super();
		this.messageText = new String[totalPart];
		this.totalPart = totalPart;
		this.msgCount=1;
	}
	public int getTotalPart() {
		return totalPart;
	}
	public void setTotalPart(int totalPart) {
		this.totalPart = totalPart;
	}
	public long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}
	public int getPartNum() {
		return partNum;
	}
	public void setPartNum(int partNum) {
		this.partNum = partNum;
	}
	public int getMsgRefNUm() {
		return msgRefNUm;
	}
	public void setMsgRefNUm(int msgRefNUm) {
		this.msgRefNUm = msgRefNUm;
	}
	public boolean isDestPort() {
		return isDestPort;
	}
	public void setDestPort(boolean isDestPort) {
		this.isDestPort = isDestPort;
	}
	public int getDestPort() {
		return destPort;
	}
	public void setDestPort(int destPort) {
		this.destPort = destPort;
	}
	
	
	public void setMessageText(int partNUm,String text)
	{
		this.messageText[partNUm-1]=text;
		this.msgCount++;
		if(this.totalPart==this.msgCount)
		{
			this.isAllMsgRecv=true;
		}
		
		
	}
	
	

	public boolean isAllMsgRecv() {
		return isAllMsgRecv;
	}

	public String[] getMessageText()
	{
		return messageText;
	}
	

}

