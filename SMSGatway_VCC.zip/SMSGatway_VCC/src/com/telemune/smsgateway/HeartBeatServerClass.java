package com.telemune.smsgateway;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

import org.apache.log4j.Logger;

public class HeartBeatServerClass implements Runnable {

	Logger logger= Logger.getLogger("HeartBeatServerClass");
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		ServerSocket socketServer=null;
		Socket socket=null;
		try {
			socketServer = new ServerSocket(Global.heartBeatPort);
			
		}
		catch(SocketException socExe)
		{
			 errorLogger.error("ErrorCode ["+Global.errCode+"-90011] Client Port["+Global.heartBeatPort+"] [SocketTimeOut Exception while Connecting to Client SMSGateway] Error[" + socExe.getMessage()+"]");
			 socExe.printStackTrace();
		}
		catch (IOException e) {
			errorLogger.error("ErrorCode ["+Global.errCode+"-90002] Client IP ["+Global.heartBeatIp+"] Port["+Global.heartBeatPort+"] [IOException Exception while transfer data to client SMSGateway] Error[" + e.getMessage()+"]");
			 e.printStackTrace();
		}
		catch(Exception exe){
			errorLogger.error("ErrorCode ["+Global.errCode+"-00040] Client Port["+Global.heartBeatPort+"] [Exception when connecting to client SMSGateway] ERROR ["+exe.getMessage()+"]");
			exe.printStackTrace();
			
			}
		
		while(true)
		{
			DataInputStream dis=null;
			DataOutputStream out=null;
		try{
			logger.info("Waiting for the request........");
			socket=socketServer.accept();//establishes connection
			logger.info("Request accepted.................."+socket.toString());
			
			dis=new DataInputStream(socket.getInputStream());  
				String  str=(String)dis.readUTF();  
				logger.info("Got packet from server....... "+str);
		
		 out= new DataOutputStream(socket.getOutputStream());
		 
           out.writeUTF("Alive");
           out.flush();
           out.close();
           
           
		//ss.close();  
		}
		/*catch(SocketException socExe)
		{
			 errorLogger.error("ErrorCode ["+Global.errCode+"-90011] Client Port["+Global.heartBeatPort+"] [SocketTimeOut Exception while Establish Connection to client SMSGateway] Error[" + socExe.getMessage()+"]");
			 socExe.printStackTrace();
		}
		catch (IOException e) {
			errorLogger.error("ErrorCode ["+Global.errCode+"-90002] Client Port["+Global.heartBeatPort+"] [IOException Exception while send Data to Client SMSGateway] Error[" + e.getMessage()+"]");
			 e.printStackTrace();
		}*/
		catch(Exception exe){
			errorLogger.error("ErrorCode ["+Global.errCode+"-00041] Client Port["+Global.heartBeatPort+"] [Exception when establish connection from client SMSGateway] ERROR ["+exe.getMessage()+"]");
			exe.printStackTrace();
			}finally
			{
				try{
					if(dis!=null)dis.close();
					if(out!=null)out.close();
				}catch(Exception exe)
				{
					errorLogger.error("ErrorCode ["+Global.errCode+"-00042] Client Port["+Global.heartBeatPort+"] [Exception when Closing IO Stream into Finally block] ERROR ["+exe.getMessage()+"]");
					exe.printStackTrace();
					
				}
			}
		}
		
	}

}
