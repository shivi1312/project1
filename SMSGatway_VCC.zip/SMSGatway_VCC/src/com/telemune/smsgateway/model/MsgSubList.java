package com.telemune.smsgateway.model;

import java.util.List;

import com.telemune.smsgateway.bean.GmatMessageBean;

@SuppressWarnings("serial")
public class MsgSubList implements java.io.Serializable {
	List<GmatMessageBean> subList;
	GmatMessageBean gmatBean;
	int msgCount;

	public MsgSubList(List<GmatMessageBean> subList, int msgCount,
			GmatMessageBean gmatBean) {
		this.subList = subList;
		this.msgCount = msgCount;
		this.gmatBean = gmatBean;
	}

	public List<GmatMessageBean> getSubList() {
		return subList;
	}

	public void setSubList(List<GmatMessageBean> subList) {
		this.subList = subList;
	}

	public int getMsgCount() {
		return msgCount;
	}

	public void setMsgCount(int msgCount) {
		this.msgCount = msgCount;
	}

	public GmatMessageBean getGmatBean() {
		return gmatBean;
	}

	public void setGmatBean(GmatMessageBean gmatBean) {
		this.gmatBean = gmatBean;
	}

}
