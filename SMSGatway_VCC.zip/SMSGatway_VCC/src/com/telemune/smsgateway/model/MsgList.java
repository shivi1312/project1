package com.telemune.smsgateway.model;

import java.util.List;

import com.telemune.smsgateway.bean.GmatMessageBean;

@SuppressWarnings("serial")
public class MsgList implements java.io.Serializable {
	private List<MsgSubList> msgSubList;
	List<GmatMessageBean> mainList;

	public List<MsgSubList> getMsgSubList() {
		return msgSubList;
	}

	public void setMsgSubList(List<MsgSubList> msgSubList) {
		this.msgSubList = msgSubList;
	}

	public List<GmatMessageBean> getMainList() {
		return mainList;
	}

	public void setMainList(List<GmatMessageBean> mainList) {
		this.mainList = mainList;
	}

}
