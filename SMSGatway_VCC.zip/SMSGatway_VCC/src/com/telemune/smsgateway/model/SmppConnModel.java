package com.telemune.smsgateway.model;

import com.telemune.smsgateway.bean.ConnectionDetailBean;

@SuppressWarnings("serial")
public class SmppConnModel implements java.io.Serializable {
	private ConnectionDetailBean connBean;
	private int counter;
	private boolean connOpen;

	public SmppConnModel(ConnectionDetailBean connBean, int counter){
		this.connBean = connBean;
		this.counter = counter;
	}
	public ConnectionDetailBean getConnBean() {
		return connBean;
	}

	public void setConnBean(ConnectionDetailBean connBean) {
		this.connBean = connBean;
	}

	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}
	public boolean getConnOpen() {
		return connOpen;
	}
	public void setConnOpen(boolean connOpen) {
		this.connOpen = connOpen;
	}
	
}
