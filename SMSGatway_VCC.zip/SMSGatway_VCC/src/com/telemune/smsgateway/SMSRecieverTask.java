package com.telemune.smsgateway;

import java.util.ArrayList;
import java.util.Enumeration;

import org.apache.log4j.Logger;

import com.telemune.smsgateway.bean.ConnectionDetailBean;
/**
 * THIS CLASS IS JUST FOR SETTING UP THE DELIVER SM LISTNER WHEN THE SMSPP CONNECTION IS BOUND WITH THE SMSC AND 
 * CHECK WHETHER THE LISTNER IS SET OR NOT IF NOT THEN IT TRY AGAIN
 * @author ekansh
 *@version R1_0_0_0
 */
public class SMSRecieverTask implements Runnable{
	
	Logger logger=Logger.getLogger("SMSRecieverTask.java");
	 final static Logger errorLogger = Logger.getLogger("errorLogger");
	ConnectionDetailBean bean[]=null;
	ArrayList keyAl=null;
	public void run()
	{
		
		while(true)
		{
			try{
			 
			if(Global.smppSessionDetail.size()!=0)
			{
				

				 keyAl= new ArrayList(Global.smppSessionDetail.keySet());
					try{
				 for(int j=0;j<keyAl.size();j++)
				 {
					 bean=(ConnectionDetailBean[])Global.smppSessionDetail.get((Integer)keyAl.get(j));
					 for(int i=0;i<bean.length;i++)
					 {
				 //ConnectionDetailBean bean=connectionCount[i];
					 //ConnectionDetailBean bean= (ConnectionDetailBean)Global.smppSessionDetail.get((Integer)keyAl.get(j));
					 if(!bean[i].getSmscSystemId().equalsIgnoreCase("-1"))
					 {
					 if(bean[i].getSession().getSessionState().isReceivable()&&bean[i].getSession().getSessionState().isBound())
					 {
						
						try{	
						 if(bean[i].getSession().getMessageReceiverListener()==null)
						 {
							 logger.info("starting message lisnter......");
							 bean[i].getSession().setMessageReceiverListener(new SMPPDeliverSm(bean[i].getSmscId()));	
							
						}
						}catch(Exception ee)
						{
						logger.error("Exception inside condtion if SMSRecieverTask.....",ee);
						}
						 
					 }
					 }
					 }
				 }

				}
					catch(NullPointerException e)
					{
						errorLogger.error("ErrorCode ["+Global.errCode+"-90003] [NullPointerException when receive task from SMSC] ERROR ["+e.getMessage()+"]");
						e.printStackTrace();
						//logger.error("Getting null pointer exception in SMSRecieverTask()....",exe);
					
					}
					catch(Exception e)
					{
						errorLogger.error("ErrorCode ["+Global.errCode+"-00063] [Exception when receiver task receive request from SMSC] ERROR ["+e.getMessage()+"]");
						e.printStackTrace();
						//logger.error("Getting exception .......SMSRecieverTask......",e);
					}
					
				 
				Thread.sleep(100);
				
			}else if(Global.smppSessionDetail.size()==0)
			{
				logger.info("--------size of....."+Global.smppSessionDetail.size());
				Thread.sleep(1000);
			}
			 
	}
			catch(InterruptedException ie)
			{
				errorLogger.error("ErrorCode ["+Global.errCode+"-90013] [InterruptedException when SMSReceiver Thread is going to sleep] Error[" + ie.getMessage()+"]");
	        	   ie.printStackTrace(); 
			}
			catch(Exception e)
			{
				errorLogger.error("ErrorCode ["+Global.errCode+"-00064] [Exception When run block of SMS Receiver task is executed] ERROR ["+e.getMessage()+"]");
				e.printStackTrace();
				//logger.error("Exception inisde function SMSRECIEVERTASK",exe);
			}
			finally
			{
				if(keyAl!=null)keyAl=null;
				if(bean!=null)bean=null;
			}
			 
		}
		
		
	}

}
