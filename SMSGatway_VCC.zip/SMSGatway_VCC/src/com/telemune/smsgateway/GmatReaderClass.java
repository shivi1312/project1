package com.telemune.smsgateway;



import org.apache.log4j.Logger;

import org.jsmpp.util.HexUtil;

import com.telemune.smsgateway.bean.ConnectionDetailBean;
import com.telemune.smsgateway.bean.GmatMessageBean;
import com.telemune.smsgateway.handler.SubmitMsgProducer;


/**
 * THIS CLASS IS FOR FORMATTING THE TEXT MESSAGE FOR SUBMIT_SM COMMAND THIS
 * CLASS GET THE TEXT MESSAGE FROM THE DATABASE
 * 
 * @author ekansh
 * @version :- R1_0_0_0
 */

public class GmatReaderClass implements Runnable {

	Logger logger = Logger.getLogger("GmatReaderClass");
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	private SubmitMsgProducer submitProducer = new SubmitMsgProducer();

	static int refCount = 0;
	public static int count = 1;
	public static long firstMessageTime = -1;
	public static long timeDiff = -1;
	public static long waitTime = -1;
	public static long selectCount = 0;
	public static int deleteCount = 0;
	ConnectionDetailBean connectionCount[] = null;
	

	/**
	 * THIS IS THE THREAD'S RUN FUNCTION IN WHICH ITS CALLS
	 * getMessageDetailsFromDb() FUNCTION
	 */
	@Override
	public void run() {
		try {
			Thread.sleep(6000);
		}catch(Exception e){
			
		}
		sendSMSFromGmat();

	}

	private void sendSMSFromGmat() {
		while (true) {
			try {
				submitProducer.run();
				Thread.sleep(1500);
				
			} catch (Exception exe) {
				errorLogger.error("ErrorCode [" + Global.errCode
						+ "-00028] [Exception inside run block when get message from data base] ERROR ["
						+ exe.getMessage() + "]");
				exe.printStackTrace();
							} 
		}
	}


	public void handleWapPushMessage(GmatMessageBean bean) {
		logger.info("Inside function handleWapPushMessage() where destination port is [" + bean.getDestinationPort()
				+ "] ");
		if (bean.getDestinationPort() <= 0) {
			bean.setDestinationPort(2948);
		}

		int hrefTagToken = 0;
		String url = bean.getMessageText();
		if (url.startsWith("http://")) {
			if (url.startsWith("www.", 7)) {
				hrefTagToken = 0xD;
				url = url.substring(11);
			} else {
				hrefTagToken = 0xC;
				url = url.substring(7);
			}

		} else if (url.startsWith("https://")) {
			if (url.startsWith("www.", 8)) {
				hrefTagToken = 0xF;
				url = url.substring(12);
			} else {
				hrefTagToken = 0xE;
				url = url.substring(8);
			}
		}

		String newhexString = HexUtil.convertStringToHexString(url);
		bean.setMessageText(hrefTagToken + newhexString);
		bean.setWapPush(true);
	}

}
