package com.telemune.smsgateway;


import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mchange.v2.c3p0.ComboPooledDataSource;
/**
 * THIS CLASS IS FOR HANDLING THE CONNECTION POOLING FOR SMSGATEWAY
 * @author ekansh
 *@version R1_0_0_0
 */

public class ConnPool
{
    Logger logger= Logger.getLogger("ConnPol");
	private ComboPooledDataSource cpds = new ComboPooledDataSource();
	final static Logger errorLogger = Logger.getLogger("errorLogger");	
	
	String driver;
	String url;
	String username;
	String passwd;
	int minpoolsize;
	int maxpoolsize;
	int Accomodation;
	/**
	 * THIS IS THE PARAMETERIZED CONSTRUCTOR FOR CONPOOL CLASS 
	 * @param driver :- REFER TO THE DRIVER OF DB
	 * @param url :- REFER TO THE URL OF CONNECTING DB
	 * @param username :- REFER TO THE DB USERNAME
	 * @param passwd:-REFER TO THE DB PASSWORD
	 * @param minpoolsize:- REFER TO THE MINMUM CONNECTION PRESENT IN THE CONNNECTION POOL
	 * @param maxpoolsize:- REFER TO THE MAXIMUM CONNECTION PRESENT IN THE CONNNECTION POOL
	 * @param Accomodation :-Determines how many connections at a time c3p0 will try to acquire when the pool is exhausted
	 */
	public ConnPool(String driver,String url,String username,String passwd,int minpoolsize,int maxpoolsize,int Accomodation)
	{
		this.driver=driver;
		this.url=url;
		this.username=username;
		this.passwd=passwd;
		this.minpoolsize=minpoolsize;
		this.maxpoolsize=maxpoolsize;
		this.Accomodation=Accomodation;

	}


	/**
	 * THIS FUNCTION IS FOR SETTING UP THE INITAIL CONFIGUARTION OF CONNECTION POOL IN ComboPooledDataSource
	 */
	public void MakePool()
	{
		try 
		{
			//cpds=new ComboPooledDataSource();
			cpds.setDriverClass(driver);
			cpds.setJdbcUrl(url);
			cpds.setUser(username);
			cpds.setPassword(passwd);
			cpds.setMaxPoolSize(maxpoolsize);
			cpds.setMinPoolSize(minpoolsize);
			cpds.setAcquireIncrement(Accomodation);
			cpds.setMaxStatementsPerConnection(25);
		} 
		catch (Exception ex) 
		{
			errorLogger.error("ErrorCode ["+Global.errCode+"-00026] [Exception when set parameter for create conection from data base pool] ERROR ["+ex.getMessage()+"]");
			ex.printStackTrace();
			//handle exception...not important.....
			//logger.error("Exception in MakePool()..........",ex);
		}

	}
	
	/**
	 * THIS FUNCTION IS FOR GETTING THE CONNECTION FROM THE ComboPooledDataSource OBJECT
	 * @return DATABASE CONNECTION OBJECT
	 */
	
	public synchronized Connection getConnection()
	{
		//logger.info("getting the connection con.......");
	
		Connection con=null;
		try{
			con= cpds.getConnection();
			}
		catch(SQLException sqle)
		{
			errorLogger.error("ErrorCode ["+Global.errCode+"-90001] [SQLException getting connection from data base] ERROR ["+sqle.getMessage()+"]");

			sqle.printStackTrace();
		}
		catch(Exception e)
		{
			errorLogger.error("ErrorCode ["+Global.errCode+"-00027] [Exception when get connection from data base] ERROR ["+e.getMessage()+"]");

			//logger.info("Exception in cpds........",e);
			e.printStackTrace();
		}
		return con;
	}
}

