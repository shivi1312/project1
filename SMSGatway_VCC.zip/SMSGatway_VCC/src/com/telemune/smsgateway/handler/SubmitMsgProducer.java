package com.telemune.smsgateway.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.telemune.smsgateway.Global;
import com.telemune.smsgateway.bean.ConnectionDetailBean;
import com.telemune.smsgateway.bean.GmatMessageBean;
import com.telemune.smsgateway.model.MsgList;
import com.telemune.smsgateway.model.MsgSubList;
import com.telemune.smsgateway.model.SmppConnModel;
import com.telemune.smsgateway.service.GmatService;
import com.telemune.smsgateway.util.SmscUtil;

public class SubmitMsgProducer {
	private final static Logger logger = Logger.getLogger("SubmitMsgProducer");
	private GmatService gmatService = new GmatService();
	private SmscUtil smscUtil = new SmscUtil();
	private MsgList msgList = null;
	private static Map<Integer, Integer> map = new HashMap<Integer, Integer>();
	private static Map<Integer, Integer> sinmap = new HashMap<Integer, Integer>();
	private static Map<Integer, Integer> sessDet = new HashMap<Integer, Integer>();

	public SubmitMsgProducer() {

	}

	public void run() {
		try {
			this.msgList = gmatService.getMessages();
			logger.info("Message main list size: " + this.msgList.getMainList().size() + " sub list size: "
					+ this.msgList.getMsgSubList().size());
			if (this.msgList.getMainList().size() > 0 || this.msgList.getMsgSubList().size() > 0) {
				map.clear();
				sinmap.clear();
				sessDet.clear();
				this.process();
				this.printMessageInfo();
			} else
				Thread.sleep(1000);
		} catch (Exception e) {

		}
	}

	private void printMessageInfo() {
		int subList = 0;
		String msg = "";
		try {
			for (MsgSubList list : this.msgList.getMsgSubList()) {
				subList = subList + list.getSubList().size();
			}
			for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
				msg = "msg send: %s out of: %s from smscid: %s, smpp session open: %s for smscid: %s";
				msg = String.format(msg, entry.getValue(), sinmap.get(entry.getKey()), entry.getKey(),
						sessDet.get(entry.getKey()), entry.getKey());
				logger.debug(String.format("total msg selected: %s, single: %s, chunked: %s, " + "%s",
						(this.msgList.getMainList().size() + this.msgList.getMsgSubList().size()),
						this.msgList.getMainList().size(), subList, msg));
			}
		} catch (Exception e) {
			logger.error("Error while print messages info: " + e.getMessage());
		}
	}

	public void putSessionDetail(int smscid, int count) {
		int sesscount = 0;
		try {
			try {
				sesscount = sessDet.get(smscid);
			} catch (Exception e) {
				sesscount = 0;
			}
			sessDet.put(smscid, sesscount + 1);
		} catch (Exception e) {
		}
	}

	public void putDetail(int smscid, int count) {
		int tempcount = 0;
		int singlecount = 0;
		try {
			try {
				tempcount = map.get(smscid);
			} catch (Exception e) {
				tempcount = 0;
			}
			try {
				singlecount = sinmap.get(smscid);
			} catch (Exception e) {
				singlecount = 0;
			}
			map.put(smscid, tempcount + count);
			sinmap.put(smscid, singlecount + 1);
		} catch (Exception e) {
		}
	}

	private void process() {
		List<GmatMessageBean> delList = new ArrayList<GmatMessageBean>();
		try {
			try {
				int smscid = 0;
				SmppConnModel smppModel = new SmppConnModel(null, 1);
				for (MsgSubList msgSubList : this.msgList.getMsgSubList()) {
					smppModel = this.getConn(smppModel);
					try {
						smscid = smppModel.getConnBean().getSmscId();
					} catch (Exception e) {
					}
					if (smppModel.getConnBean() != null
							&& smppModel.getConnBean().getSession().getSessionState().isTransmittable()
							&& smppModel.getConnBean().getSession().getSessionState().isBound()) {
						this.proccessSubList(msgSubList.getGmatBean(), msgSubList.getSubList(),
								smppModel.getConnBean());
						logger.info(String.format("smscid: %s, dest: %s, msg to send ",
								smppModel.getConnBean().getSmscId(), msgSubList.getGmatBean().getDestinationNumber()));
						this.doPause(msgSubList);
						delList.add(msgSubList.getGmatBean());
						if (SmscUtil.getTotalTps() == delList.size()) {
							gmatService.deleteGmatStore(delList, msgList);
							delList.clear();
						}
						if (smppModel.getConnOpen()) {
							this.putSessionDetail(smscid, msgSubList.getSubList().size());
							this.putDetail(smscid, msgSubList.getSubList().size());
						} else {
							this.putDetail(smscid, msgSubList.getSubList().size());
						}
					} else {
						logger.warn(String.format("smsc: %s, dest: %s, org: %s smsc conn is breaked ", smscid,
								msgSubList.getGmatBean().getDestinationNumber(),
								msgSubList.getGmatBean().getOriginationNumber()));
					}
					smppModel.setCounter(smppModel.getCounter() + 1);
				}
				gmatService.deleteGmatStore(delList, msgList);
			} catch (Exception ee) {
				logger.error("Error while processing request: " + ee.getMessage());
			}
			this.processMainList(delList);
		} catch (Exception e) {
			logger.error("Error while processing main and sublist: " + e.getMessage());
		}
	}

	private void doPause(MsgSubList msgSubList) {
		try {
			if (SmscUtil.getTotalTps() >= msgSubList.getSubList().size())
				Thread.sleep(1000 / (SmscUtil.getTotalTps() / msgSubList.getSubList().size()));
			else
				Thread.sleep(1000 / (SmscUtil.getTotalTps() % msgSubList.getSubList().size()));
		} catch (Exception e) {
			logger.info("Error while pause request processing: " + e.getMessage());
		}
	}

	private void processMainList(List<GmatMessageBean> delList) {
		try {
			delList = new ArrayList<GmatMessageBean>();
			int smscid = 0;
			SmppConnModel smppModel = new SmppConnModel(null, 1);
			for (GmatMessageBean messageBean : this.msgList.getMainList()) {
				smppModel = this.getConn(smppModel);
				try {
					smscid = smppModel.getConnBean().getSmscId();
				} catch (Exception e) {
				}
				if (smppModel.getConnBean() != null
						&& smppModel.getConnBean().getSession().getSessionState().isTransmittable()
						&& smppModel.getConnBean().getSession().getSessionState().isBound()) {
					messageBean.setConDetailBean(smppModel.getConnBean());
					Global.gmatMessageQue.put(messageBean);
					delList.add(messageBean);
					if (SmscUtil.getTotalTps() == delList.size()) {
						gmatService.deleteGmatStore(delList, msgList);
						delList.clear();
					}
					if (smppModel.getConnOpen()) {
						this.putSessionDetail(smscid, 1);
						this.putDetail(smscid, 1);
					} else {
						this.putDetail(smscid, 1);
					}
					Thread.sleep(1000 / SmscUtil.getTotalTps());
				} else {
					logger.warn(String.format("smscid: %s, dest: %s, org: %s smsc conn is breaked ", smscid,
							messageBean.getDestinationNumber(), messageBean.getOriginationNumber()));
				}
				smppModel.setCounter(smppModel.getCounter() + 1);
			}
			gmatService.deleteGmatStore(delList, msgList);
		} catch (Exception e) {
			logger.error("Error while processing main list: " + e.getMessage());
		}
	}

	private SmppConnModel getConn(SmppConnModel smppModel) {
		try {
			int smscid = 0;
			try {
				smscid = smppModel.getConnBean().getSmscId();
			} catch (Exception e) {
				smscid = 0;
			}
			smppModel.setConnOpen(false);
			if (smppModel.getConnBean() == null
					|| smppModel.getCounter() > SmscUtil.getTps(smppModel.getConnBean().getSmscId())) {
				smppModel.setConnBean(smscUtil.getConnection(smscid, false));
				logger.info(String.format("smscid: %s, allocted tps: %s, total " + "tps: %s", smscid,
						SmscUtil.getTps(smscid), SmscUtil.getTotalTps()));
				smppModel.setCounter(1);
				smppModel.setConnOpen(true);
			} else {
				if (smppModel.getCounter() > smppModel.getConnBean().getWindowSize()) {
					logger.info(String.format(
							"smscid: %s, total tps: %s, tps: %s, message sent "
									+ "from this conn: %s, cross window size: %s then use " + "next conn",
							smppModel.getConnBean().getSmscId(), SmscUtil.getTotalTps(),
							SmscUtil.getTps(smppModel.getConnBean().getSmscId()), smppModel.getCounter() - 1,
							smppModel.getConnBean().getWindowSize()));
					smppModel.setConnBean(smscUtil.getConnection(smppModel.getConnBean().getSmscId(), true));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while getting conn " + e.getMessage());
		}
		return smppModel;
	}

	private void proccessSubList(GmatMessageBean msgBean, List<GmatMessageBean> subList,
			ConnectionDetailBean connBean) {
		try {
			try {
				for (GmatMessageBean messageBean : subList) {
					logger.debug("message bean: " + messageBean.toString());
					messageBean.setConDetailBean(connBean);
					Global.gmatMessageQue.put(messageBean);
				}
				logger.info(String.format("dest: %s, org: %s, smscid: %s, tps: %s, chunk list: %s",
						msgBean.getDestinationNumber(), msgBean.getOriginationNumber(), connBean.getSmscSystemId(),
						SmscUtil.getTps(connBean.getSmscId()), subList.size()) + " conn valid: "
						+ connBean.getSession().getSessionState().isTransmittable());
			} catch (Exception e) {
				logger.error(String.format("dest: %s, org: %s: getting error to check conn: %s",
						msgBean.getDestinationNumber(), msgBean.getOriginationNumber(), e.getMessage()));
			}
		} catch (Exception e) {
			logger.error(String.format("dest: %s, org: %s: chunk list: %s getting error: %s",
					msgBean.getDestinationNumber(), msgBean.getOriginationNumber(), subList.size(), e.getMessage()));
		}
	}

	public void deliverData(MsgList msgList) {
		try {
			this.msgList = msgList;
			logger.info("Deliver Message main list size: " + this.msgList.getMainList().size() + " sub list size: "
					+ this.msgList.getMsgSubList().size());
			if (this.msgList.getMainList().size() > 0 || this.msgList.getMsgSubList().size() > 0) {
				map.clear();
				sinmap.clear();
				sessDet.clear();
				this.process();
				this.printMessageInfo();
			}
		} catch (Exception e) {

		}
	}
}