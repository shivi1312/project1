package com.telemune.smsgateway;

import org.apache.log4j.Logger;

import org.codehaus.jettison.json.JSONObject;

import com.telemune.smsgateway.bean.FileWriterBean;

import org.apache.commons.lang.StringUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
/**
 * THIS CLASS IS FOR HANDLE THE FILE WRITT FOR MAINTIANG THE LOGS  
 * @author ekansh
 *@version R1_0_0_0
 */

public class WriteFileLogs implements Runnable {
	
	Logger logger=Logger.getLogger("WriteFileLogs.");
	 final static Logger errorLogger = Logger.getLogger("errorLogger");
	 
	public void run()
	{
		
		while(true)
		{
			try{
			if(Global.fileWriteQueue.isEmpty())
			{
				Thread.sleep(1000);
			}else
			{
				FileWriterBean bean =Global.fileWriteQueue.poll();
				
				// added on 15/02/2017 to convert integer smscid to hex
				 try{
					 if(bean.getSmscId()!=null)
					 {
						 int smscid = Integer.parseInt(bean.getSmscId());
						 bean.setSmscId(Integer.toHexString(smscid).toUpperCase());
					 }
				 }
				 catch(NumberFormatException nfx)
				 {
					 bean.setSmscId(bean.getSmscId().toUpperCase());
				 }
				 catch(Exception e)
				 {
					 bean.setSmscId(bean.getSmscId().toUpperCase());
				 }
				
				
				
				if(Global.WriteLgsInDB_Enable==0||Global.WriteLgsInDB_Enable==2)// here we are going to write the logs in perspective file... 
				{
				logger.info("condition where we are going to write the logs in FILE......");	
					
					if(bean.getRequestType()==Global.SUBMIT_SM_REQUEST)
					{
						
						JSONObject submitSmObj= new JSONObject();
						//submitSmObj.put("requestId",bean.getRequestId());
						//submitSmObj.put("responseId",bean.getResponseId());
						submitSmObj.put("sequenceNUm",bean.getSequenceNUm());
						submitSmObj.put("originNum", bean.getOriginNum());
						submitSmObj.put("destNum",bean.getDestNum());
						submitSmObj.put("msgTxt", bean.getMsgTxt());
						submitSmObj.put("timeStamp",bean.getTimeStamp());
						submitSmObj.put("status", bean.getStatus());
						submitSmObj.put("campId", bean.getCampId());
						//submitSmObj.put("retryCount",bean.getRetryCount());
						Global.flwGateway[Global.SUBMIT_SM_REQUEST].writeLog(submitSmObj.toString());
						submitSmObj=null;
						
					}else if(bean.getRequestType()==Global.SUBMIT_SM_RESPONSE)
					{
					
						JSONObject submitSmResObj= new JSONObject();
						submitSmResObj.put("sequenceNUm",bean.getSequenceNUm());
						submitSmResObj.put("originNum", bean.getOriginNum());
						submitSmResObj.put("destNum",bean.getDestNum());
						submitSmResObj.put("smscId", bean.getSmscId());
						if(bean.getStatus()==""||bean.getStatus()==null)
						{
							submitSmResObj.put("status","NA");	
						}else
						{
							submitSmResObj.put("status", bean.getStatus());
						}
						
						Global.flwGateway[Global.SUBMIT_SM_RESPONSE].writeLog(submitSmResObj.toString());
						submitSmResObj=null;
						
					}
		     		else if(bean.getRequestType()==Global.ERROR_FILE)
		     		{
	
						JSONObject errResObj= new JSONObject();
						errResObj.put("timeStamp",bean.getTimeStamp());
						errResObj.put("originNum", bean.getOriginNum());
						errResObj.put("destNum",bean.getDestNum());
						errResObj.put("smscId", bean.getSmscId());
						errResObj.put("status", bean.getStatus());
						
						Global.flwGateway[Global.ERROR_FILE].writeLog(errResObj.toString());
						errResObj=null;
		     		}
					else
					{
						JSONObject delRecptResObj= new JSONObject();
						delRecptResObj.put("timeStamp",bean.getTimeStamp());
						delRecptResObj.put("originNum", bean.getOriginNum());
						delRecptResObj.put("destNum",bean.getDestNum());
						delRecptResObj.put("smscId", bean.getSmscId());
						delRecptResObj.put("status", bean.getStatus());
						
						Global.flwGateway[Global.DELIVERY_RECIEPT].writeLog(delRecptResObj.toString());
						delRecptResObj=null;
		
						
					}
					
				}
				//else
				// modified on 10/11/2017 - avinash
				if(Global.WriteLgsInDB_Enable==1||Global.WriteLgsInDB_Enable==2)
				{
					logger.info("condition where we are going to write the logs in DATA BASE......");
					if(bean.getRequestType()==Global.SUBMIT_SM_REQUEST)
	                {			
						insertDB(bean);		
					}
					else if(bean.getRequestType()==Global.SUBMIT_SM_RESPONSE)
					{
						logger.info("inside submit_sm_response sequence id="+bean.getSequenceNUm()+" origination number="+bean.getOriginNum()+" destination number="+bean.getDestNum()+" smscid ="+bean.getSmscId());	
						//if(bean.getSequenceNUm()!=0 && !StringUtils.isBlank(bean.getOriginNum()) && !StringUtils.isBlank(bean.getDestNum()))
						//{
						//logger.info("calling ubdateDb()");
						if(bean.getSequenceNUm()!=0 && bean.getSmscId()!=null)
						{
							updateDB(bean);
						}
						
						
						//}		
					}
					else if(bean.getRequestType()==Global.DELIVERY_RECIEPT)
					{
						//if(bean.getSequenceNUm()!=0 && !StringUtils.isBlank(bean.getOriginNum()) && !StringUtils.isBlank(bean.getDestNum()) && !StringUtils.isBlank(bean.getSmscId()))
						//{
						if(bean.getSmscId()!=null && bean.getStatus()!=null)
						{
							updateDBRecp(bean);
						}
						
						
						//}
					}
			}
		}
		}
			catch(InterruptedException ie)
			{
				errorLogger.error("ErrorCode ["+Global.errCode+"-90013] [InterruptedException when File Writer thread is going to sleep] Error[" + ie.getMessage()+"]");
	        	   ie.printStackTrace(); 
			}
			catch(Exception e)
			{
				errorLogger.error("Error ["+Global.errCode+"-00053] [Exception in Writer Thread when write logs into Log File] ERROR ["+e.getMessage()+"]");
				e.printStackTrace();
				
			}
	
	}
	}
	
	public void insertDB(FileWriterBean bean)
	{
		logger.info("Inside insertDb() SMSC_ID="+bean.getSmscId());
		Connection con=null;
		PreparedStatement pstmt=null;
		String query="";
		try{
			con=Global.conPool.getConnection();
			if(Global.dbConfigParamEnable==1) //mysql
			{
				query = "insert into SMS_GTW_LOG(REQUEST_ID,RESPONSE_ID,SEQ_NUM,ORG_NUM,DEST_NUM,MSG_TXT,TIME_STAMP,STATUS,SMSC_ID,CAMP_ID,CDR_STATUS,RETRY_COUNT) values(?,?,?,?,?,?,STR_TO_DATE(?,'%d-%m-%Y %H:%i:%s'),?,?,?,?,?);";
			}
			else //oracle
			{
				query="insert into SMS_GTW_LOG(REQUEST_ID,RESPONSE_ID,SEQ_NUM,ORG_NUM,DEST_NUM,MSG_TXT,TIME_STAMP,STATUS,SMSC_ID,CAMP_ID,CDR_STATUS,RETRY_COUNT) values(?,?,?,?,?,?,to_date(?,'dd-mm-yyyy HH24:MI:SS'),?,?,?,?,?)";
			}
			
			pstmt=con.prepareStatement(query);
			pstmt.setInt(1,bean.getRequestId());
			pstmt.setInt(2,bean.getResponseId());
			pstmt.setInt(3,bean.getSequenceNUm());
			pstmt.setString(4,bean.getOriginNum());
			pstmt.setString(5,bean.getDestNum());
			pstmt.setString(6,bean.getMsgTxt());
			pstmt.setString(7,convertIntoDDMMYYYY(bean.getTimeStamp()));
			pstmt.setString(8,bean.getStatus());
			pstmt.setString(9,bean.getSmscId());
			pstmt.setInt(10,bean.getCampId());
			pstmt.setString(11,"N");
			pstmt.setInt(12, bean.getRetryCount());
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
		   }
		catch(SQLException sql)
		{
			errorLogger.error("ErrorCode ["+Global.errCode+"-90001] MSISDN ["+bean.getDestNum()+"] Sequemce Num ["+bean.getSequenceNUm()+"][SQLException when insert submit message detail into SMS_GTW_LOG] ERROR ["+sql.getMessage()+"]");
			sql.printStackTrace();
		}
		catch(Exception ex)
		{
			errorLogger.error("ErrorCode ["+Global.errCode+"-00054]  MSISDN ["+bean.getDestNum()+"] Sequemce Num ["+bean.getSequenceNUm()+"] [Exception when insert submit message detail into SMS_GTW_LOG] ERROR ["+ex.getMessage()+"]");
			ex.printStackTrace();
			
		}finally
		{

			try{
				if(pstmt!=null)pstmt.close();
				if(con!=null)con.close();
				
			}catch(Exception ex)
			{
				errorLogger.error("ErrorCode ["+Global.errCode+"-00055]  MSISDN ["+bean.getDestNum()+"] Sequemce Num ["+bean.getSequenceNUm()+"] [Exception inside finally block when All Database Connections are closed in insertDB] ERROR ["+ex.getMessage()+"]");
				ex.printStackTrace();
			}
		}
	}
	
	public void updateDB(FileWriterBean bean)
	{
		logger.info("Inside updateDb() SMSC_ID="+bean.getSmscId()+" ["+bean.toString()+"]");
		Connection con=null;
                PreparedStatement pstmt=null;
                String query="";
                try{
                		
                        con=Global.conPool.getConnection();
                        if(Global.dbConfigParamEnable==1) //mysql
            			{
            				query = "update SMS_GTW_LOG set SMSC_ID=?,STATUS=?  where SEQ_NUM=?";
            			}
            			else //oracle
            			{
            				query="update SMS_GTW_LOG set SMSC_ID=?,STATUS=?  where SEQ_NUM=?";
            			}
                        
            			pstmt=con.prepareStatement(query);
                       
                        pstmt.setString(1,bean.getSmscId());
                        if(bean.getStatus()==""||bean.getStatus()==null)
                                                {
                                                       pstmt.setString(2,"NA");
                                                }else
                                                {
                                                        pstmt.setString(2,bean.getStatus());
                                                }

						pstmt.setInt(3,bean.getSequenceNUm());
					
                        pstmt.executeUpdate();
						pstmt.close();
						con.close();
						
		   }
                catch(SQLException sql)
        		{
        			errorLogger.error("ErrorCode ["+Global.errCode+"-90001] MSISDN ["+bean.getDestNum()+"] Sequemce Num ["+bean.getSequenceNUm()+"][SQLException when update submit message detail into SMS_GTW_LOG] ERROR ["+sql.getMessage()+"]");
        			sql.printStackTrace();
        		}
        		catch(Exception ex)
        		{
        			errorLogger.error("ErrorCode ["+Global.errCode+"-00056]  MSISDN ["+bean.getDestNum()+"] Sequemce Num ["+bean.getSequenceNUm()+"] [Exception when update submit message detail into SMS_GTW_LOG] ERROR ["+ex.getMessage()+"]");
        			ex.printStackTrace();
        			
        		}
		finally
                {

                        try{
                                if(pstmt!=null)pstmt.close();
                                if(con!=null)con.close();

                        }catch(Exception ex)
                        {
                        	errorLogger.error("ErrorCode ["+Global.errCode+"-00057]  MSISDN ["+bean.getDestNum()+"] Sequemce Num ["+bean.getSequenceNUm()+"] [Exception inside finally block when All Database Connections are closed in updateDB] ERROR ["+ex.getMessage()+"]");
        				ex.printStackTrace();
                        }
                }
	}

	public void updateDBRecp(FileWriterBean bean)
        {
		logger.info("Inside updateDBRec() SMSC_ID="+bean.getSmscId()+"["+bean.toString()+"]");
                Connection con=null;
                PreparedStatement pstmt=null;
                String query="";
                try{
                        con=Global.conPool.getConnection();
                       /*query="update SMS_GTW_LOG set STATUS=?  where SEQ_NUM=? and SMSC_ID=?";
                        pstmt=con.prepareStatement(query);
                        pstmt.setString(1,bean.getStatus());
                        pstmt.setInt(2,bean.getSequenceNUm());
                        pstmt.setString(3,bean.getSmscId());*/
                        
                        if(Global.dbConfigParamEnable==1) //mysql
            			{
            				query = "update SMS_GTW_LOG set RESPONSE_TIME=STR_TO_DATE(?,'%d-%m-%Y %H:%i:%s'),CDR_STATUS=?,STATUS=? where SMSC_ID=? and ORG_NUM=? and DEST_NUM=?";
            			}
            			else //oracle
            			{
            				query="update SMS_GTW_LOG set RESPONSE_TIME=to_date(?,'dd-mm-yyyy HH24:MI:SS'),CDR_STATUS=?,STATUS=? where SMSC_ID=? and ORG_NUM=? and DEST_NUM=?";
            			}
            			pstmt=con.prepareStatement(query);
                        
                        pstmt.setString(1,convertIntoDDMMYYYY(bean.getTimeStamp()));
                        pstmt.setString(2,"Y");
                        pstmt.setString(3,bean.getStatus());
                        pstmt.setString(4,bean.getSmscId());
                        pstmt.setString(5,bean.getOriginNum());
                        pstmt.setString(6,bean.getDestNum());
                       
                        pstmt.executeUpdate();
                        
                          pstmt.close();
                          con.close();
                   }
                catch(SQLException sql)
        		{
        			errorLogger.error("ErrorCode ["+Global.errCode+"-90001] SMSC ID ["+bean.getSmscId()+"] Sequemce Num ["+bean.getSequenceNUm()+"][SQLException when update smscId into SMS_GTW_LOG] ERROR ["+sql.getMessage()+"]");
        			sql.printStackTrace();
        		}
        		catch(Exception ex)
        		{
        			errorLogger.error("ErrorCode ["+Global.errCode+"-00058]  MSISDN ["+bean.getDestNum()+"] Sequemce Num ["+bean.getSequenceNUm()+"] [Exception when update smscId into SMS_GTW_LOG] ERROR ["+ex.getMessage()+"]");
        			ex.printStackTrace();
        			
        		}finally
                {

                        try{
                                if(pstmt!=null)pstmt.close();
                                if(con!=null)con.close();

                        }catch(Exception exe)
                        {
                                exe.printStackTrace();
                        }
                }
        }

	public String convertIntoDDMMYYYY(long timeStamp) {
		logger.debug("inside convertIntoDDMMYYYY() time [" + timeStamp + "] ");
		try {
			Date date = null;
			String newTimeStamp = null;
			//DateFormat srcDf = new SimpleDateFormat("yyyyMMddHHmmSS");
			//String newTimeStamp = String.valueOf(timeStamp);
			//date = srcDf.parse(newTimeStamp);
			date=new Date(timeStamp);
			DateFormat destDf = new SimpleDateFormat("dd-MM-yyyy HH:mm:s");
			newTimeStamp = destDf.format(date);
			logger.debug("inside convertIntoDDMMYYYY() time [" + timeStamp + "] datetime is ["+newTimeStamp+"]");
			return newTimeStamp;
		} catch (Exception e) {
			logger.error("Exception inside convertIntoDDMMYYYY() " + e.getMessage());
			e.printStackTrace();
			return "-1";
		}
	}
}

