package com.telemune.smsgateway;
/**
 * THIS CLASS IS POJO CLASS FOR GETTING AND SETTING THE DATA FOR FILE WRITTING 
 * @author ekansh
 *@version:- R1_0_0_0
 */

public class FileWriterBean {

	private int requestType;
	private int sequenceNUm;
	private String originNum;
	private String destNum;
	private String msgTxt;
	private long timeStamp;
	private String status;
	private int campId;
	private String smscId;
	
	
	
	
	public String getSmscId() {
		return smscId;
	}
	public void setSmscId(String smscId) {
		this.smscId = smscId;
	}
	public int getRequestType() {
		return requestType;
	}
	public void setRequestType(int requestType) {
		this.requestType = requestType;
	}
	public int getSequenceNUm() {
		return sequenceNUm;
	}
	public void setSequenceNUm(int sequenceNUm) {
		this.sequenceNUm = sequenceNUm;
	}
	public String getOriginNum() {
		return originNum;
	}
	public void setOriginNum(String originNum) {
		this.originNum = originNum;
	}
	public String getDestNum() {
		return destNum;
	}
	public void setDestNum(String destNum) {
		this.destNum = destNum;
	}
	public String getMsgTxt() {
		return msgTxt;
	}
	public void setMsgTxt(String msgTxt) {
		this.msgTxt = msgTxt;
	}
	public long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getCampId() {
		return campId;
	}
	public void setCampId(int campId) {
		this.campId = campId;
	}
	@Override
	public String toString() {
		return "FileWriterBean [requestType=" + requestType + ", sequenceNUm=" + sequenceNUm + ", originNum="
				+ originNum + ", destNum=" + destNum + ", msgTxt=" + msgTxt + ", timeStamp=" + timeStamp + ", status="
				+ status + ", campId=" + campId + ", smscId=" + smscId + "]";
	}
	
	
	
	
		
	
}
