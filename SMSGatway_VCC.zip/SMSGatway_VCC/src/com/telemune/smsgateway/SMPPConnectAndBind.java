package com.telemune.smsgateway;

import java.net.ConnectException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import org.apache.log4j.Logger;
import org.jsmpp.session.SMPPSession;

import com.telemune.smsgateway.bean.ConnectionDetailBean;
import com.telemune.smsgateway.bean.SmscConfigBean;
import com.telemune.smsgateway.util.SmscUtil;

/**
 * THIS CLASS IS RESPONSIBLE FOR THE HANDLING THE CONNECTION FROM SMSC AND ALSO
 * CHECKS WHETHER THE CONNECTION IS BIULD OR NOT IF THE CONNECTION IS BUILD THEN
 * OK AND IF THE CONNECTION IS BREAK THEN ITS RETRY THE CONNECTION FOR THAT
 * PARTICULAR SMSC
 * 
 * @author ekansh
 * @version :- R1_0_0_0
 */

public class SMPPConnectAndBind implements Runnable {
	Logger logger = Logger.getLogger("SMPPConnectAndBind");
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	@Override
	public void run() {
		this.process();
	}

	private void process() {
		while(true){
			if(this.checkDetailExist())
				this.getAndConnectionSmppSession();
			try {
				Thread.sleep(4000);
			}catch(Exception e){
				
			}
		}
	}
	
	private boolean checkDetailExist() {
		try {
			if (Global.smscParamDetail == null || Global.smscParamDetail.isEmpty()) {
				logger.warn("Smsc:: config has no detail in db: now sleep for 5000 millseconds");
			} else {
				return true;
			}
		}catch(Exception e){
			logger.error("Smsc:: config has no detail in db:: "+e.getMessage());
		}
		return false;
	}
	
	@SuppressWarnings({ "rawtypes"})
	private void getAndConnectionSmppSession(){
		Enumeration cnfKey = null;
		SmscConfigBean smscBean = null;
		try {
			cnfKey = Global.smscParamDetail.keys();
			while (cnfKey.hasMoreElements()) {
				smscBean = (SmscConfigBean)Global.smscParamDetail.get((Integer)cnfKey.nextElement());
				if(!this.alreadyConnected(smscBean)){
					this.connectSmsc(smscBean);
				}
			}
		}catch(Exception e){
			logger.error("Smsc:: Error while create conn: "+e.getMessage());
		}
	}
	
	
	private boolean alreadyConnected(SmscConfigBean smscBean){
		ConnectionDetailBean connCount[] = null;
		boolean connected = false;
		try {
			connCount = Global.smppSessionDetail.get(smscBean.getSmscId());
			connCount = this.getOnlyActiveConn(connCount, smscBean);
			if(connCount != null){
				Global.smppSessionDetail.put(smscBean.getSmscId(), connCount);
				if(smscBean.getNoOfConnections()==connCount.length) {
					logger.debug("Smsc: "+smscBean.getSmscId()+" ip: "+
							smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
							" address range: "+smscBean.getAddressRange()+
							" window size: "+smscBean.getWindowSize()+" all conn active");
					return true;
				} else {
					logger.warn("Smsc: "+smscBean.getSmscId()+" ip: "+
							smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
							" address range: "+smscBean.getAddressRange()+
							" window size: "+smscBean.getWindowSize()+
							" only "+connCount.length+" is active");
				}
			}
			return connected;
		}catch(Exception e){
			logger.error("Smsc:: Error while check connection existence: "+e.getMessage());
		}
		return connected;
	}
	private void connectSmsc(SmscConfigBean smscBean){
		logger.info("inside connectSmsc() ["+smscBean.toString()+"]");
		ConnectionDetailBean connCount[] = null;
		ConnectionDetailBean tempCount[] = null;
		int index = 0;
		try {
			this.printSmscInfo(smscBean);
			tempCount = Global.smppSessionDetail.get(smscBean.getSmscId());
			tempCount = this.getOnlyActiveConn(tempCount, smscBean);
			connCount = new ConnectionDetailBean[smscBean.getNoOfConnections()];
			if(tempCount != null){
				index = tempCount.length;
				logger.info("Smsc: "+smscBean.getSmscId()+" ip: "+
						smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
						" address range: "+smscBean.getAddressRange()+
						" window size: "+smscBean.getWindowSize()+" inactive conn: "
						+(smscBean.getNoOfConnections()-tempCount.length));
				for(int i = 0; i < tempCount.length; i++)
					connCount[i] = tempCount[i];
			}
			for(int i = index; i < smscBean.getNoOfConnections(); i++){
				this.connect(smscBean, connCount, i);
			}
			connCount = this.getOnlyActiveConn(connCount, smscBean);
			if(connCount != null){
				Global.smppSessionDetail.put(smscBean.getSmscId(), connCount);
				SmscUtil.putSmppSessionInQueue();
			}
		}catch(Exception e){
			logger.error("Smsc: "+smscBean.getSmscId()+" ip: "+
					smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
					" address range: "+smscBean.getAddressRange()+
					" window size: "+smscBean.getWindowSize()+" Error: "+e.getMessage());
		}
	}
	private ConnectionDetailBean [] getOnlyActiveConn(ConnectionDetailBean [] connCount, SmscConfigBean smscBean){
		List<ConnectionDetailBean> list = new ArrayList<ConnectionDetailBean>();
		try {
			if(connCount != null){
				for(int i = 0; i < connCount.length; i++){
					if(connCount[i] != null && connCount[i].getSession() != null
							&& connCount[i].getSession().getSessionState().isTransmittable()
							&& connCount[i].getSession().getSessionState().isBound()){
						list.add(connCount[i]);
						logger.info("Smsc: "+smscBean.getSmscId()+" ip: "+
								smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
								" address range: "+smscBean.getAddressRange()+
								" window size: "+smscBean.getWindowSize()+" (conn is valid)");
					}
				}
			} else {
				logger.warn("Smsc: "+smscBean.getSmscId()+" ip: "+
						smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
						" address range: "+smscBean.getAddressRange()+
						" window size: "+smscBean.getWindowSize()+" no active conn yet");
			}
			if(list.size()>0){
				connCount = new ConnectionDetailBean [list.size()];
				for(int i = 0; i < list.size(); i++){
					connCount[i] = list.get(i);
				}
				logger.info("Smsc: "+smscBean.getSmscId()+" ip: "+
						smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
						" address range: "+smscBean.getAddressRange()+
						" window size: "+smscBean.getWindowSize()+" active conn: "+connCount.length);
			} else {
				logger.info("Smsc: "+smscBean.getSmscId()+" ip: "+
						smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
						" address range: "+smscBean.getAddressRange()+
						" window size: "+smscBean.getWindowSize()+" active conn: "+ 0);
				connCount = null;
			}
		}catch(Exception e){
			logger.info("Smsc: "+smscBean.getSmscId()+" ip: "+
					smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
					" address range: "+smscBean.getAddressRange()+
					" window size: "+smscBean.getWindowSize()+" Error:: "+e.getMessage());
		}
		return connCount;
	}
	private void connect(SmscConfigBean smscBean, 
			ConnectionDetailBean conBean[], int index) {
		SMPPSession smppSession = null;
		String smscSystemId = "-1";
		try {
			smppSession = new SMPPSession();
			if (Global.addressrange == 0)
				smscBean.setAddressRange(null);
			
			smscSystemId = smppSession.connectAndBindWithSMSCid(
					smscBean.getSmscIp(), smscBean.getSmscPort(),
					smscBean.getBindType(), smscBean.getSmscUserId(),
					smscBean.getSmscPassword(), smscBean.getSystemType(),
					smscBean.getTon(), smscBean.getNpi(),
					smscBean.getAddressRange(), 20000, Global.localHost,
					Global.localPort);
			
			if (smppSession != null
					&& smppSession.getSessionState().isTransmittable()
					&& smppSession.getSessionState().isBound()) {
				conBean[index] = new ConnectionDetailBean(smppSession,
						smscSystemId.trim(), smscBean.getWindowSize(),
						smscBean.getSmscId());
				logger.info("Smsc: "+smscBean.getSmscId()+" ip: "+
						smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
						" address range: "+smscBean.getAddressRange()+
						" window size: "+smscBean.getWindowSize()+" smscSystemId: ["+smscSystemId+"] connected successfully...");
			} else {
				logger.warn("Smsc: "+smscBean.getSmscId()+" ip: "+
						smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
						" address range: "+smscBean.getAddressRange()+
						" window size: "+smscBean.getWindowSize()+" smscSystemId ["+smscSystemId+"]  failed to connect");
			}
		} catch(ConnectException ex){
			logger.warn("Smsc: "+smscBean.getSmscId()+" ip: "+
					smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
					" address range: "+smscBean.getAddressRange()+
					" window size: "+smscBean.getWindowSize()+" smscSystemId ["+smscSystemId+"] failed to connect: "+ex.getMessage());
		}catch (Exception e) {
			logger.warn("Smsc: "+smscBean.getSmscId()+" ip: "+
					smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
					" address range: "+smscBean.getAddressRange()+
					" window size: "+smscBean.getWindowSize()+"smscSystemId["+smscSystemId+"] failed to connect : "+e.getMessage());
		}
	}
	
	private void printSmscInfo(SmscConfigBean smscBean){
		logger.info("Smsc: "+smscBean.getSmscId()+" ip: "+
				smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
				" address range: "+smscBean.getAddressRange()+
				" window size: "+smscBean.getWindowSize());
		logger.info("Smsc: "+smscBean.getSmscId()+" userid: "+
				smscBean.getSmscUserId()+" password: "+smscBean.getSmscPassword()+
				" status: "+smscBean.getStatus()+" conn: "+smscBean.getNoOfConnections()+" bindType: "+smscBean.getBindType());
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void sendUnbindRequest() {
		logger.info("###>>> Inside sendUnbinedRequest Method..."); // added by Avishkar
		ArrayList keyAl = null;
		ConnectionDetailBean bean[] = null;
		try {

			keyAl = new ArrayList(Global.smppSessionDetail.keySet());
			for (int j = 0; j < keyAl.size(); j++) {
				bean = (ConnectionDetailBean[]) Global.smppSessionDetail
						.get((Integer) keyAl.get(j));
				for (int i = 0; i < bean.length; i++) {
					if (!bean[i].getSmscSystemId().equalsIgnoreCase("-1")) {
						if (bean[i].getSession().getSessionState()
								.isReceivable()
								&& bean[i].getSession().getSessionState()
										.isBound()) {

							try {
								bean[i].getSession().unbindAndClose(); // added by Avishkar
								/*if (bean[i].getSession()
										.getMessageReceiverListener() == null) {
									logger.info("starting message lisnter......");
									bean[i].getSession()
											.setMessageReceiverListener(
													new SMPPDeliverSm(bean[i]
															.getSmscId()));
								}*/ // commented by Avishkar
							} catch (Exception e) {
								errorLogger
										.error("Error ["
												+ Global.errCode
												+ "-00052] [Exception when send unbind request to SMSC] ERROR ["
												+ e.getMessage() + "]");
								e.printStackTrace();
							}

						}
					}

				}
			}

			Thread.sleep(10);// Sleep for handle the window
								// size..................

		} catch (InterruptedException ie) {
			errorLogger
					.error("ErrorCode ["
							+ Global.errCode
							+ "-90013] [InterruptedException when bind thread is going to sleep] Error["
							+ ie.getMessage() + "]");
			ie.printStackTrace();
		} catch (Exception exe) {
			errorLogger
					.error("Error ["
							+ Global.errCode
							+ "-00093] [Exception when unbind request is going to execute] ERROR ["
							+ exe.getMessage() + "]");
			exe.printStackTrace();
			// logger.error("Exception in ............message reading.....",exe);
		} finally {
			if (keyAl != null)
				keyAl = null;
			if (bean != null)
				bean = null;
		}

	}

}
