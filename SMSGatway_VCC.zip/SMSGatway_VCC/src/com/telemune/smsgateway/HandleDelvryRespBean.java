package com.telemune.smsgateway;
/**
 * THIS IS THE POJO CLASS FOR SETTING AND GETTING THE DATA FOR HANDLE THE DELIVERY RESPONSE INFORMATION
 * @author ekansh
 *@version :-R1_0_0_0
 */
public class HandleDelvryRespBean {
	
	
	private int sequenceNo;
	private long timeStamp;
	public int getSequenceNo() {
		return sequenceNo;
	}
	public void setSequenceNo(int sequenceNo) {
		this.sequenceNo = sequenceNo;
	}
	public long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}
	public HandleDelvryRespBean(int sequenceNo, long timeStamp) {
		super();
		this.sequenceNo = sequenceNo;
		this.timeStamp = timeStamp;
	}
	@Override
	public String toString() {
		return "HandleDelvryRespBean [sequenceNo=" + sequenceNo
				+ ", timeStamp=" + timeStamp + "]";
	}	

}

