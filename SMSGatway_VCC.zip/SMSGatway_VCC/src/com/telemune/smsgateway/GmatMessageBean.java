package com.telemune.smsgateway;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.jsmpp.bean.Alphabet;

/**
 * THIS IS THE POJO CLASS FOR SETTING UP AND GETTING THE DATA FROM
 * GMAT_MESSAGE_STORE
 * 
 * @author ekansh
 * @version :- R1_0_0_0
 */

public class GmatMessageBean {

	private int requestId;
	private int smscId;
	private int responseId;
	private String originationNumber;
	private String destinationNumber;
	private String messageText;
	private int messageType;
	private int language;
	private String status;
	private int validityType;
	private int destinationPort;
	private int campaignId = -1;
	private int priority = 2;
	private boolean isLongMessage = false;
	private int messagePartNo = -1;
	private int messageTotalSegment = -1;

	private String systemId = "0";
	private boolean isMessagePayLoad = false;
	private boolean isSubmitNormal = false;
	private boolean isSubmitOptParam = false;
	private int protocolId = 0;
	private boolean isWapPush = false;
	private ConnectionDetailBean conDetailBean = null;
	private short messageRef = 0;
	private int moreMessage = 0;
	private int opcode = 0;
	private short sessionInfo=0;
	private OptionalParamBean optBean;
	
	
	
	

	


	public OptionalParamBean getOptBean() {
		return optBean;
	}

	public void setOptBean(OptionalParamBean optBean) {
		this.optBean = optBean;
	}

	public short getSessionInfo() {
		return sessionInfo;
	}

	public void setSessionInfo(short sessionInfo) {
		this.sessionInfo = sessionInfo;
	}

	public int getOpcode() {
		return opcode;
	}

	public void setOpcode(int opcode) {
		this.opcode = opcode;
	}

	public int getMoreMessage() {
		return moreMessage;
	}

	public void setMoreMessage(int moreMessage) {
		this.moreMessage = moreMessage;
	}

	public short getMessageRef() {
		return messageRef;
	}

	public void setMessageRef(short messageRef) {
		this.messageRef = messageRef;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public boolean isWapPush() {
		return isWapPush;
	}

	public void setWapPush(boolean isWapPush) {
		this.isWapPush = isWapPush;
	}

	public int getProtocolId() {
		return protocolId;
	}

	public void setProtocolId(int protocolId) {
		this.protocolId = protocolId;
	}

	public ConnectionDetailBean getConDetailBean() {
		return conDetailBean;
	}

	public void setConDetailBean(ConnectionDetailBean conDetailBean) {
		this.conDetailBean = conDetailBean;
	}

	// THIS IS FOR HAMLDING THE
	private Alphabet encodinngScheme = Alphabet.ALPHA_8_BIT;

	public Alphabet getEncodinngScheme() {
		return encodinngScheme;
	}

	public void setEncodinngScheme(Alphabet encodinngScheme) {
		this.encodinngScheme = encodinngScheme;
	}

	private byte[] msgByteAray;

	public byte[] getMsgByteAray() {
		return msgByteAray;
	}

	public void setMsgByteAray(byte[] msgByteAray) {
		this.msgByteAray = msgByteAray;
	}

	public boolean isSubmitNormal() {
		return isSubmitNormal;
	}

	public void setSubmitNormal(boolean isSubmitNormal) {
		this.isSubmitNormal = isSubmitNormal;
	}

	public boolean isSubmitOptParam() {
		return isSubmitOptParam;
	}

	public void setSubmitOptParam(boolean isSubmitOptParam) {
		this.isSubmitOptParam = isSubmitOptParam;
	}

	public boolean isMessagePayLoad() {
		return isMessagePayLoad;
	}

	public void setMessagePayLoad(boolean isMessagePayLoad) {
		this.isMessagePayLoad = isMessagePayLoad;
	}

	/**
	 * THIS IS THE PARAMETRIZED CONSTRUCTOR GMATMESSAGE BEAN CLASS
	 * 
	 * @param responseId
	 *            :- REFERS TO THE RESPONSE ID
	 * @param originationNumber
	 *            :-REFERS TO THE ORIGINATION NUMBER
	 * @param destinationNumber
	 *            :- REFERS TO THE DESTINATION NUMBER
	 * @param messageText
	 *            :- REFERS TO THE MESSAGE TEXT
	 * @param messageType
	 *            :- REFERS TO THE MESSAGE TEXT
	 * @param language
	 *            :- REFERS TO THE LANGUAGE ID
	 * @param status
	 *            :- REFERS TO THE MESSAGE STATUS
	 * @param validityType
	 *            :- REFERS TO THE VALIDITY TYPE
	 * @param destinationPort
	 *            :- REFERS TO THE DESTINATION PORT
	 * @param encodingScheme
	 *            :- REFERS TO THE ENCODING SCHEME
	 * @param campaignId
	 *            :- REFERS TO THE CAMPAIGN ID
	 */
	public GmatMessageBean(int responseId, int requestId,
			String originationNumber, String destinationNumber,
			String messageText, int messageType, String status,
			int validityType, int destinationPort, Alphabet encodingScheme,
			int protclId, int campaignId, int smscId, int opcode,OptionalParamBean optBean,
			ConnectionDetailBean conDetailBean) {
		super();
		this.responseId = responseId;
		this.requestId = requestId;
		this.originationNumber = originationNumber;
		this.destinationNumber = destinationNumber;
		this.messageText = messageText;
		this.messageType = messageType;
		this.status = status;
		this.validityType = validityType;
		this.destinationPort = destinationPort;
		this.encodinngScheme = encodingScheme;
		this.protocolId = protclId;
		this.campaignId = campaignId;
		this.smscId = smscId;
		this.opcode = opcode;
		this.optBean=optBean;
		this.conDetailBean = conDetailBean;
	}

	public int getSmscId() {
		return smscId;
	}

	public void setSmscId(int smscId) {
		this.smscId = smscId;
	}

	public int getResponseId() {
		return responseId;
	}

	public void setResponseId(int responseId) {
		this.responseId = responseId;
	}

	public String getOriginationNumber() {
		return originationNumber;
	}

	public void setOriginationNumber(String originationNumber) {
		this.originationNumber = originationNumber;
	}

	public String getDestinationNumber() {
		return destinationNumber;
	}

	public void setDestinationNumber(String destinationNumber) {
		this.destinationNumber = destinationNumber;
	}

	public String getMessageText() {
		return messageText;
	}

	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}

	public int getMessageType() {
		return messageType;
	}

	public void setMessageType(int messageType) {
		this.messageType = messageType;
	}

	public int getLanguage() {
		return language;
	}

	public void setLanguage(int language) {
		this.language = language;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getValidityType() {
		return validityType;
	}

	public void setValidityType(int validityType) {
		this.validityType = validityType;
	}

	public int getDestinationPort() {
		return destinationPort;
	}

	public void setDestinationPort(int destinationPort) {
		this.destinationPort = destinationPort;
	}

	public boolean isLongMessage() {
		return isLongMessage;
	}

	public void setLongMessage(boolean isLongMessage) {
		this.isLongMessage = isLongMessage;
	}

	public int getMessagePartNo() {
		return messagePartNo;
	}

	public void setMessagePartNo(int messagePartNo) {
		this.messagePartNo = messagePartNo;
	}

	public int getMessageTotalSegment() {
		return messageTotalSegment;
	}

	public void setMessageTotalSegment(int messageTotalSegment) {
		this.messageTotalSegment = messageTotalSegment;
	}

	public int getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(int campaignId) {
		this.campaignId = campaignId;
	}

	@Override
	public String toString() {
		return "GmatMessageBean [requestId=" + requestId + ", smscId=" + smscId
				+ ", responseId=" + responseId + ", originationNumber="
				+ originationNumber + ", destinationNumber="
				+ destinationNumber + ", messageText=" + messageText
				+ ", messageType=" + messageType + ", language=" + language
				+ ", status=" + status + ", validityType=" + validityType
				+ ", destinationPort=" + destinationPort + ", campaignId="
				+ campaignId + ", priority=" + priority + ", isLongMessage="
				+ isLongMessage + ", messagePartNo=" + messagePartNo
				+ ", messageTotalSegment=" + messageTotalSegment
				+ ", systemId=" + systemId + ", isMessagePayLoad="
				+ isMessagePayLoad + ", isSubmitNormal=" + isSubmitNormal
				+ ", isSubmitOptParam=" + isSubmitOptParam + ", protocolId="
				+ protocolId + ", isWapPush=" + isWapPush + ", conDetailBean="
				+ conDetailBean + ", messageRef=" + messageRef
				+ ", moreMessage=" + moreMessage + ", opcode=" + opcode
				+ ", encodinngScheme=" + encodinngScheme + ", msgByteAray="
				+ Arrays.toString(msgByteAray) + "]";
	

	
	}

}
