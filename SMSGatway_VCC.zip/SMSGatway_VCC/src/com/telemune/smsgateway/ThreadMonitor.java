package com.telemune.smsgateway;


import java.util.concurrent.ThreadPoolExecutor;

import FileBaseLogging.*;
import java.io.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import org.apache.log4j.*;

/**
 *@author PANKAJ GUPTA
 *@version R1_0_0_0
 *THIS CLASS IS FOR MONITORING THE THREADS THAT WHICH THREAD IS OPEN AND PERFORMED THE TASK 
 */
public class ThreadMonitor implements Runnable
{
	private ThreadPoolExecutor executorPool;
	private int seconds;
	private boolean run=true;

	static Logger logger=Logger.getLogger("ThreadMonitor");
	 final static Logger errorLogger = Logger.getLogger("errorLogger");

/**
 *THIS IS THE CONSTRUCTOR OF THREAD MONITOR WHICH INITIALIZE THE ESSENTIAL PARAMETER
 *@param executor :-REFERS TO A THREAD POOL EXECUTOR OBJECT GOING TO BE MONITOR 
 *@param delay :- REFERS TO AN INTEGER VALUE WHICH IS FOR DEFINE THE DELAY TIME OF MONITOR THREAD IN SECONDS
 */
	public ThreadMonitor(ThreadPoolExecutor executor, int delay)
	{
		this.executorPool = executor;
		
		this.seconds=delay;
	}
/**
 *THIS METHOD IS FOR SHUTDOWN THE MONITOR THREAD 
 */
	public void shutdown(){
		this.run=false;
	}

/**
 *
 *THIS IS THE RUN METHOD WHICH LOOK UP THE MONITORING OF THE THREADS 
 *THAT HOW MANY THREADS ARE ACTIVE 
 *HOW MANY TASK ARE COMPLETED
 *TOTAL TASK COUNT
 *IS THREAD SHUTDOWN
 *IS THREAD TERMINATED
 *
 *ALL THESE WORK ARE PERFORMED BY THIS RUN METHOD
 */
	@Override
		public void run()
		{
			while(run){
				try
				{
					logger.debug(
							String.format("[monitor] [%d/%d] Active: %d, Completed: %d, Task: %d, isShutdown: %s, isTerminated: %s, Pending Queuesize %d",
								this.executorPool.getPoolSize(),
								this.executorPool.getCorePoolSize(),
								this.executorPool.getActiveCount(),
								this.executorPool.getCompletedTaskCount(),
								this.executorPool.getTaskCount(),
								this.executorPool.isShutdown(),
								this.executorPool.isTerminated(),
								this.executorPool.getQueue().size()));
					logger.debug("Size of the Que"+Global.rcvSMSQueue.size());
					//System.out.println("Size of the Que"+GlobalRE.que_send.size());
				}
				catch(Exception ex)
				{
					errorLogger.error("ErrorCode ["+Global.errCode+"-00062] [Exception when set all monitoring parameter for display] ERROR ["+ex.getMessage()+"]");
					ex.printStackTrace();
				}


				try {
					Thread.sleep(seconds*1000);
					//read.sleep(1);
				} catch(InterruptedException ie)
				{
					  errorLogger.error("ErrorCode ["+Global.errCode+"-90013] [InterruptedException when Monitor thread is going to sleep] Error[" + ie.getMessage()+"]");
		        	  ie.printStackTrace(); 
				}
			}

		}
}
