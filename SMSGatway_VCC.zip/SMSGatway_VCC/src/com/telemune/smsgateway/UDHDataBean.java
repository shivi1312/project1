package com.telemune.smsgateway;

/**
 * THIS IS THE POJO CLASS WHICH HANDLE THE INFORMATION OF UDH HEADER
 * @author ekansh
 *
 */
public class UDHDataBean {
	private int udhMessageLength;
	private int totalmessageParts;
	private int udhHeaderLength;
	private boolean isApplyUDH=false;
	private boolean isConcatBitAdded=false;
	private int udhMessageHeaderLength;
	
	public boolean isConcatBitAdded() {
		return isConcatBitAdded;
	}
	public void setConcatBitAdded(boolean isConcatBitAdded) {
		this.isConcatBitAdded = isConcatBitAdded;
	}
	public int getUdhMessageLength() {
		return udhMessageLength;
	}
	public void setUdhMessageLength(int udhMessageLength) {
		this.udhMessageLength = udhMessageLength;
	}
	public int getTotalmessageParts() {
		return totalmessageParts;
	}
	public void setTotalmessageParts(int totalmessageParts) {
		this.totalmessageParts = totalmessageParts;
	}
	public int getUdhHeaderLength() {
		return udhHeaderLength;
	}
	public void setUdhHeaderLength(int udhHeaderLength) {
		this.udhHeaderLength = udhHeaderLength;
	}
	public boolean isApplyUDH() {
		return isApplyUDH;
	}
	public void setApplyUDH(boolean isApplyUDH) {
		this.isApplyUDH = isApplyUDH;
	}
	public int getUdhMessageHeaderLength() {
                return udhMessageHeaderLength;
        }
        public void setUdhMessageHeaderLength(int udhMessageHeaderLength) {
                this.udhMessageHeaderLength = udhMessageHeaderLength;
        }

	
	
	
	
	

}
