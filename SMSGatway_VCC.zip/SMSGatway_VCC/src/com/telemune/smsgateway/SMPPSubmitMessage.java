package com.telemune.smsgateway;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.jsmpp.InvalidResponseException;
import org.jsmpp.PDUException;
import org.jsmpp.bean.Alphabet;
import org.jsmpp.bean.ESMClass;
import org.jsmpp.bean.GeneralDataCoding;
import org.jsmpp.bean.MessageClass;
import org.jsmpp.bean.NumberingPlanIndicator;
import org.jsmpp.bean.OptionalParameter;
import org.jsmpp.bean.OptionalParameter.Byte;
import org.jsmpp.bean.OptionalParameter.Tag;
import org.jsmpp.bean.OptionalParameters;
import org.jsmpp.bean.RegisteredDelivery;
import org.jsmpp.bean.SMSCDeliveryReceipt;
import org.jsmpp.bean.TypeOfNumber;
import org.jsmpp.extra.NegativeResponseException;
import org.jsmpp.extra.ResponseTimeoutException;
import org.jsmpp.session.SMPPSession;
import org.jsmpp.util.AbsoluteTimeFormatter;
import org.jsmpp.util.TimeFormatter;

import com.telemune.smsgateway.bean.FileWriterBean;
import com.telemune.smsgateway.bean.GmatMessageBean;

/**
 * THIS CLASS IS FOR HANDLE THE SUBMIT MESSAGE ACCORDING TO THE SMSC
 * @author ekansh
 *@version :- R1_0_0_0
 */
public class SMPPSubmitMessage implements Runnable {
	 private static TimeFormatter timeFormatter = new AbsoluteTimeFormatter();;
	Logger logger=Logger.getLogger("SMPPSubmitMessage");
	 final static Logger errorLogger = Logger.getLogger("errorLogger");
	String validity="";	
	
	
	/**
	 * THIS IS THE RUN METHOD OF THIS THREAD
	 */
	public void run()
	{
		GmatMessageBean messageBean=null;
		FileWriterBean fileBean=null;

		while(true)
		{
			try{
				if(Global.gmatMessageQue.isEmpty())
				{
					try{
						Thread.sleep(10);
					}
					catch(InterruptedException ie)
					{
						errorLogger.error("ErrorCode ["+Global.errCode+"-90013] [InterruptedException when Submit Sm thread is going to sleep] Error[" + ie.getMessage()+"]");
			        	ie.printStackTrace(); 
					}catch(Exception exe)
					{
						logger.error("Exception in side thread......",exe);
					}
				}else
				{
					String messageId="";
					
					logger.info("Found some message in db for SUBMIT_SM........."+Global.gmatMessageQue.size());
					 SMSCDeliveryReceipt isDeliveryReportEnable=SMSCDeliveryReceipt.DEFAULT;
					  messageBean= Global.gmatMessageQue.poll();
					  logger.info("message Bean "+messageBean.toString());
					  //System.out.println("############"+messageBean.toString());
					  logger.info("transmitble "+messageBean.getConDetailBean().getSession().getSessionState().isTransmittable()+" is bound "+messageBean.getConDetailBean().getSession().getSessionState().isBound());
					 if(messageBean.getConDetailBean().getSession().getSessionState().isTransmittable()&&messageBean.getConDetailBean().getSession().getSessionState().isBound())
						 { 
						 
						 if(Global.countryCodeEnable==0)
						 {
							 if(messageBean.getOriginationNumber().startsWith(Global.countryCode))
							 {
								 messageBean.setOriginationNumber("0"+messageBean.getOriginationNumber().substring(Global.countryCode.length()));
								 logger.info("origination number "+messageBean.getOriginationNumber());
							 }
						 }
							 logger.info("Found some message in db for SUBMIT_SM and Gmat message bean is"+messageBean.toString());
								if(Global.isDeliveryReportEnable==1)// checking delivery report flag.........................
									{
										isDeliveryReportEnable=SMSCDeliveryReceipt.SUCCESS_FAILURE;
									}
				
							if(messageBean.getValidityType()==0)
								{
								validity=null;
								logger.debug("Inside condition when validity period is 0 then set Validity Period is "+validity);
								}
								else if(messageBean.getValidityType()>0 && messageBean.getValidityType()<=604800)
								{
								validity=getValidityPeriod(messageBean.getValidityType());
								validity=validity+"000R";
								logger.info("Inside condition when validity period is Relative then Validity Period is "+validity);
								}
								else if(messageBean.getValidityType()>604800)
								{
									validity=getValidityPeriod(messageBean.getValidityType());
									validity=validity+"000+";
									logger.info("Inside condition when validity period is Absolute then Validity Period is "+validity);	
								}
							
								// MessageType 40 means "TEST msg/class 0" for MCA.. so setting delivery receipt
								// @Rajesh Bansal
								if (messageBean.getMessageType() == 40) {
									isDeliveryReportEnable = SMSCDeliveryReceipt.SUCCESS_FAILURE;
								}
							
							if(messageBean.isSubmitOptParam())
							 	{
								 ArrayList<OptionalParameter> opt=new ArrayList<OptionalParameter>();

								 Random random= new Random() ;
								 
								 if(messageBean.isLongMessage())
								 {
									 logger.info("Message reference number is"+messageBean.getMessageRef()+"More messages ["+messageBean.getMoreMessage()+"]");
									 
									 opt.add(OptionalParameters.newSarMsgRefNum(messageBean.getMessageRef()));
									 opt.add(OptionalParameters.newSarSegmentSeqnum(messageBean.getMessagePartNo()));
									 opt.add(OptionalParameters.newSarTotalSegments(messageBean.getMessageTotalSegment()));
									 opt.add(OptionalParameters.newMoreMsg(messageBean.getMoreMessage()));
									 
									/* OptionalParameter sarMsgRefNum = OptionalParameters.newSarMsgRefNum(messageBean.getMessageRef()); 
									// OptionalParameter sarMsgRefNum = OptionalParameters.newSarMsgRefNum((short)random.nextInt());
									 OptionalParameter sarSegmentSeqnum = OptionalParameters.newSarSegmentSeqnum(messageBean.getMessagePartNo());
									 OptionalParameter sarTotalSegments = OptionalParameters.newSarTotalSegments(messageBean.getMessageTotalSegment());
									 OptionalParameter sarMoremsgs = OptionalParameters.newMoreMsg(messageBean.getMoreMessage());*/

									 OptionalParameter optionalParam[]=opt.toArray(new OptionalParameter[opt.size()]);
									
									 
									 messageId=submitLongMessageWithOptionalParam(messageBean.getConDetailBean().getSession(),messageBean,isDeliveryReportEnable,optionalParam);
									 /*messageId=submitNormalMessage(messageBean.getConDetailBean().getSession(), messageBean,isDeliveryReportEnable,false,optionalParam);*/

									//  messageId=submitLongMessageWithOptionalParam(messageBean.getConDetailBean().getSession(),messageBean, sarMsgRefNum, sarSegmentSeqnum, sarTotalSegments,sarMoremsgs,isDeliveryReportEnable);

							
								 
								 }else
								 { 
									 messageBean.setSessionInfo((short)0);
									// logger.info("session info value is "+messageBean.getSessionInfo());
									 if(messageBean.getDestinationPort()>0)
									 {
										 byte[] b=new byte[2];
										 b[0]=(byte)(messageBean.getDestinationPort()>>8);
										 b[1]=(byte)(messageBean.getDestinationPort());
										 opt.add(OptionalParameters.destPort(b));
									 }
									 if(Global.opCode==1)
									 {
										 opt.add(OptionalParameters.opcode(messageBean.getOpcode()));
										
									 }
									 
									 if(messageBean.getOptBean()!=null)
									 {
										 logger.info("optional param bean is "+messageBean.getOptBean().toString());
										 if(messageBean.getOptBean().getC() !=null) {
											 if(messageBean.getOptBean().getC().equalsIgnoreCase("Byte"))
											 {
												 logger.info("inside byte block tag ["+messageBean.getOptBean().getT()+"] value ["+messageBean.getOptBean().getV()+"]");
												 opt.add(new OptionalParameter.Byte((short)messageBean.getOptBean().getT(),(byte)(Integer.parseInt(messageBean.getOptBean().getV()))));
											 }
												
											 else if(messageBean.getOptBean().getC().equalsIgnoreCase("Int"))
											 {
												 logger.info("inside byte block tag ["+messageBean.getOptBean().getT()+"] value ["+messageBean.getOptBean().getV()+"]");
												 opt.add(new OptionalParameter.Int((short)messageBean.getOptBean().getT(),Integer.parseInt(messageBean.getOptBean().getV())));
												 
											 }
											 else if(messageBean.getOptBean().getC().equalsIgnoreCase("COctetString"))
											 {
												 logger.info("inside byte block tag ["+messageBean.getOptBean().getT()+"] value ["+messageBean.getOptBean().getV()+"]");
	
												 opt.add(new OptionalParameter.COctetString((short)messageBean.getOptBean().getT(),messageBean.getOptBean().getV()));
												 
											 }
											 else if(messageBean.getOptBean().getC().equalsIgnoreCase("OctetString"))
											 {
												 logger.info("inside byte block tag ["+messageBean.getOptBean().getT()+"] value ["+messageBean.getOptBean().getV()+"]");
	
												 opt.add(new OptionalParameter.OctetString((short)messageBean.getOptBean().getT(),messageBean.getOptBean().getV()));
												 
											 }
											 else if(messageBean.getOptBean().getC().equalsIgnoreCase("Short"))
											 {
												 logger.info("inside byte block tag ["+messageBean.getOptBean().getT()+"] value ["+messageBean.getOptBean().getV()+"]");
	
												 opt.add(new OptionalParameter.Short((short)messageBean.getOptBean().getT(),(short)(Integer.parseInt(messageBean.getOptBean().getV()))));
												 
											 }
											 else
											 {
												 logger.info("inside byte block tag ["+messageBean.getOptBean().getT()+"] value ["+messageBean.getOptBean().getV()+"]");
	
												 opt.add(new OptionalParameter.COctetString((short)messageBean.getOptBean().getT(),messageBean.getOptBean().getV()));
											 }
										 }
										 
									 }
//									opt.add(OptionalParameters.sessionInfo(messageBean.getSessionInfo()));
									
									
									
								
									 logger.debug("optoanal array is"+opt.toString()+"size of array ["+opt.size());
									 OptionalParameter optionalParam[]=opt.toArray(new OptionalParameter[opt.size()]);
									 	
									if(optionalParam.length>=1)
									{
									 logger.info("size of optional parameter is"+optionalParam.length);
									 //messageId=submitUssdWithOptionalParam(messageBean.getConDetailBean().getSession(),messageBean,isDeliveryReportEnable,optionalParam);
									 /**
									  * 	Merge the submitUssdWithOptionalParam() method into submitNormalMessage
									  */
									 messageId=submitNormalMessage(messageBean.getConDetailBean().getSession(), messageBean,isDeliveryReportEnable,false,optionalParam);
									}
									else
									{
										messageId= submitNormalMessage(messageBean.getConDetailBean().getSession(), messageBean,isDeliveryReportEnable,false,null);
									}
									 
								 }
								 opt.clear();
								
							 }else
							 {
								 
								 if(messageBean.isSubmitNormal())
								 {
									// OptionalParameter sarMoremsgs = OptionalParameters.newMoreMsg(messageBean.getMoreMessage());

									messageId= submitNormalMessage(messageBean.getConDetailBean().getSession(), messageBean,isDeliveryReportEnable,false,null);
									 
								 }else
								 {
									 messageId= submitNormalMessage(messageBean.getConDetailBean().getSession(), messageBean,isDeliveryReportEnable,true,null);
								 }
								 
							 }
							 // here we are generating the logs for 
							fileBean= new FileWriterBean();
							fileBean.setRequestType(Global.SUBMIT_SM_REQUEST);
							fileBean.setSequenceNUm(Integer.parseInt(messageId));
							fileBean.setOriginNum(messageBean.getOriginationNumber());
							fileBean.setDestNum(messageBean.getDestinationNumber());
							fileBean.setMsgTxt(messageBean.getMessageText());
							fileBean.setTimeStamp(System.currentTimeMillis());
							fileBean.setStatus("SENT");
							fileBean.setCampId(messageBean.getCampaignId());
							fileBean.setRequestId(messageBean.getRequestId());
							fileBean.setResponseId(messageBean.getResponseId());
							fileBean.setRetryCount(messageBean.getRetryCount());
							Global.fileWriteQueue.put(fileBean); 
							
						 }
						 
				
					
				logger.info("Getting the message id ..............."+messageId);	
					
				}
				
			}catch(Exception exe)
			{
				errorLogger.error("ErrorCode ["+Global.errCode+"-00065] [Exception when Submit Message to SMSC] Error[" + exe.getMessage()+"]");
	        	   exe.printStackTrace(); 
				logger.error("Error in Submit message thread..........",exe);
			}
			finally
			{
				if(fileBean!=null)fileBean=null;
			}	
			
		}
		
	}
	
	
	 //This function is for submit the long message..............
	/**
	 * THIS FUNCTION IS FOR HANDLING THE LONG MESSAGE SUBMIT WITH OPTIONAL PARAMETER
	 * @param session :- SMSC SESSION CONNECTION OBJECT
	 * @param bean :- GMATMESSAGEBEAN OBJECT WHICH HOLDS THE MESSAGE AND ITS INFORMATION
	 * @param sarMsgRefNum :- MESSAGE REFRENCE NUMBER
	 * @param sarSegmentSeqnum :- SEQUENCE NUMBER
	 * @param sarTotalSegments :- TOTAL SEGMENTS 
	 * @param dlvryRecptFlag :- DELIEVRY RECIEPT FLAG
	 * @return :- MESSAGE ID 
	 */
	
	   public String submitLongMessageWithOptionalParam(SMPPSession session,GmatMessageBean bean,SMSCDeliveryReceipt dlvryRecptFlag,OptionalParameter... optionalParam) {
	
    	int messageId = -1;
        try {
  	 		//messageId  = session.submitShortMessageTest("",getOriginationTon(Global.SubmitOriginationTON,bean.getOriginationNumber()),getoriginationNPI(Global.SubmitOriginationNPI,bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL,getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), new ESMClass(), (byte)0, (byte)3,null,validity, new RegisteredDelivery(dlvryRecptFlag), (byte)0, new GeneralDataCoding(false, false, MessageClass.CLASS0,bean.getEncodinngScheme()), (byte)0, bean.getMessageText().getBytes(),optionalParam);;
        	GeneralDataCoding generalDataCoding=null;
        	if(Global.dcsEnable==1)
    		{
    			generalDataCoding=new GeneralDataCoding(Integer.parseInt(Global.dcsEncoding));
    		}
    		else
    		{
    			generalDataCoding = new GeneralDataCoding(false, false, MessageClass.CLASS0, bean.getEncodinngScheme());
    		}
        	messageId  = session.submitShortMessageTest(bean.getServiceType(),getOriginationTon(Global.SubmitOriginationTON,bean.getOriginationNumber()),getoriginationNPI(Global.SubmitOriginationNPI,bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL,getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), new ESMClass(), (byte)0, Global.priority,null,validity, new RegisteredDelivery(dlvryRecptFlag), (byte)0, generalDataCoding, (byte)0, bean.getMessageText().getBytes(),bean.getRequestId(),bean.getMessagePartNo(),optionalParam);;
        	
            
        } catch (PDUException e) {
            // Invalid PDU parameter
        	
        	errorLogger.error("ErrorCode ["+Global.errCode+"-00066] [PDUException when Invalid PDU parameter in submitLongMessage Time] Error[" + e.getMessage()+"]");
     	   	e.printStackTrace(); 
         
            messageId=-99;
           
        } catch (ResponseTimeoutException e) {
            // Response timeout
        	errorLogger.error("ErrorCode ["+Global.errCode+"-00067] [ResponseTimeoutException when Response timeout in submitLongMessage Time] Error[" + e.getMessage()+"]");
     	   	e.printStackTrace(); 
        	messageId=-98;
            }
        catch (InvalidResponseException e) {
            // Invalid response
        	errorLogger.error("ErrorCode ["+Global.errCode+"-00068] [InvalidResponseException when Receive invalid respose in submitLongMessage Time] Error[" + e.getMessage()+"]");
     	   	e.printStackTrace(); 
        	messageId=-97;
           
        } catch (NegativeResponseException e) {
            // Receiving negative response (non-zero command_status)
        	errorLogger.error("ErrorCode ["+Global.errCode+"-00069] [NegativeResponseException when Receive negative response in submitLongMessage Time] Error[" + e.getMessage()+"]");
     	   	e.printStackTrace(); 
        	messageId=-96;
           
        } catch (IOException e) {
        	errorLogger.error("ErrorCode ["+Global.errCode+"-90002] [IOException when Submit Long Message to SMSC] Error[" + e.getMessage()+"]");
     	     e.printStackTrace();
            messageId=-95;
        }catch(Exception exe)
        {
        	errorLogger.error("ErrorCode ["+Global.errCode+"-00070] [Exception when Submit sm thread submit long message] Error[" + exe.getMessage()+"]");
     	   	exe.printStackTrace(); 
        	
        }
        
        return Integer.toString(messageId);
    }
	
	   
	   //Handle ussd optional parameter like opcode and destination port
	   
	   
	   public String submitUssdWithOptionalParam(SMPPSession session,GmatMessageBean bean,SMSCDeliveryReceipt dlvryRecptFlag, OptionalParameter... optionalParam) {
			
	    	int messageId = -1;
	        try {
	        	GeneralDataCoding generalDataCoding=null;
	        	if(Global.dcsEnable==1)
        		{
        			generalDataCoding=new GeneralDataCoding(Integer.parseInt(Global.dcsEncoding));
        		}
        		else
        		{
        			generalDataCoding = new GeneralDataCoding(false, false, MessageClass.CLASS0, bean.getEncodinngScheme());
        		}
	        	
				messageId= session.submitShortMessageTest(bean.getServiceType(),getOriginationTon(Global.SubmitOriginationTON,bean.getOriginationNumber()), getoriginationNPI(Global.SubmitOriginationNPI,bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL,getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), new ESMClass(), (byte)bean.getProtocolId(), Global.priority,null, validity, new RegisteredDelivery(dlvryRecptFlag), (byte)0, generalDataCoding, (byte)0, bean.getMsgByteAray(),bean.getRequestId(),bean.getMessagePartNo(),optionalParam);

	        	
	            
	        } catch (PDUException e) {
	            // Invalid PDU parameter
	        	errorLogger.error("ErrorCode ["+Global.errCode+"-00071] [PDUException when Invalid PDU parameter in submitUSSDMessage Time] Error[" + e.getMessage()+"]");
	     	   	e.printStackTrace(); 
	     	   	messageId=-99;
	        }
	        catch (ResponseTimeoutException e) {
	            // Response timeout
	        	errorLogger.error("ErrorCode ["+Global.errCode+"-00072] [ResponseTimeoutException when Response timeout in submitUSSDMessage Time] Error[" + e.getMessage()+"]");
	     	   	e.printStackTrace(); 
	        	messageId=-98;
	          
	        } catch (InvalidResponseException e) {
	            // Invalid response
	        	errorLogger.error("ErrorCode ["+Global.errCode+"-00075] [InvalidResponseException when Receive invalid respose in submitUSSDMessage Time] Error[" + e.getMessage()+"]");
	     	   	e.printStackTrace(); 
	        	messageId=-97;
	            e.printStackTrace();
	        } catch (NegativeResponseException e) {
	            // Receiving negative response (non-zero command_status)
	        	errorLogger.error("ErrorCode ["+Global.errCode+"-00073] [NegativeResponseException when Receive negative response in submitUSSDMessage Time] Error[" + e.getMessage()+"]");

	        	messageId=-96;
	            e.printStackTrace();
	        } catch (IOException e) {
	        	errorLogger.error("ErrorCode ["+Global.errCode+"-90002] [IOException when Submit USSD Message to SMSC] Error[" + e.getMessage()+"]");

	        	e.printStackTrace();
	            messageId=-95;
	        }catch(Exception exe)
	        {
	        	errorLogger.error("ErrorCode ["+Global.errCode+"-00074] [Exception when Submit sm thread submit USSD message] Error[" + exe.getMessage()+"]");
	        }
	        
	        return Integer.toString(messageId);
	    }
	
    // this function is for submit short message.............
    /**
     * THIS FUNCTION HANDES THE THREE THINGS 
     * 1= SUBMIT LONG MESSAGE WITH MESSAGE PAYLOAD PARAMETER
     * 2= SUBMIT SHORT MESSAGE
     * 3= SUBMIT MESSAGE WITH THE UDH HEADER WHERE WE NEED TO SET THE UDHI IN ESME CLASS OBJECT
     * @param session :- REFERS TO THE SMSC CONNECTION SESSION OBJECT
     * @param bean :- GMATMESSAGEBEAN OBJECT
     * @param dlvryRecptFlag :- DELIVERY RECIEPT FLAG
     * @param HandleUDH :- BOOLEAB FLAG WHETHER THE MESSAGE IS UDH OR NOT 
     * @return
     */
    
public String submitNormalMessage(SMPPSession session, GmatMessageBean bean,SMSCDeliveryReceipt dlvryRecptFlag,boolean HandleUDH,OptionalParameter[] optionalParam) {
    	
        int messageId = -1;
        GeneralDataCoding generalDataCoding=null;
        try {
        	
        	if(bean.isMessagePayLoad())
        	{
        		// added by avinash on 16 Aug 2017
        		if(Global.dcsEnable==1)
        		{
        			generalDataCoding=new GeneralDataCoding(Integer.parseInt(Global.dcsEncoding));
        			
        			
        		}
        		else
        		{
        			generalDataCoding = new GeneralDataCoding(false, false, MessageClass.CLASS0, bean.getEncodinngScheme());
        		}
        		//
        		
        		byte[] msg= new byte[3];
        		
        		if(bean.isLongMessage())
        		{// in this we are setting the message payload tag and sending passing an empty array for shortMessage 
        			//argument and messagePayloadParameter 
        						OptionalParameter messagePayloadParameter = new OptionalParameter.OctetString(Tag.MESSAGE_PAYLOAD,bean.getMessageText());
        		        		//messageId= session.submitShortMessageTest("",getOriginationTon(Global.SubmitOriginationTON,bean.getOriginationNumber()),getoriginationNPI(Global.SubmitOriginationNPI,bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL, getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), new ESMClass(), (byte)bean.getProtocolId(), (byte)3,null, validity, new RegisteredDelivery(dlvryRecptFlag), (byte)0, new GeneralDataCoding(false, false, MessageClass.CLASS0, bean.getEncodinngScheme()), (byte)0, msg,messagePayloadParameter);
        						if(optionalParam==null) {
        						messageId= session.submitShortMessageTest(bean.getServiceType(),getOriginationTon(Global.SubmitOriginationTON,bean.getOriginationNumber()),getoriginationNPI(Global.SubmitOriginationNPI,bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL, getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), new ESMClass(), (byte)bean.getProtocolId(), Global.priority,null, validity, new RegisteredDelivery(dlvryRecptFlag), (byte)0, generalDataCoding, (byte)0, msg,bean.getRequestId(),bean.getMessagePartNo(),messagePayloadParameter);
        						}else {
        							OptionalParameter[] op= new OptionalParameter[optionalParam.length+1];
        							op[0]=messagePayloadParameter;
        							for (int i = 0; i < optionalParam.length; i++) {
        								op[i+1]=optionalParam[i];
									}
        						  /*messageId= session.submitShortMessageTest("",getOriginationTon(Global.SubmitOriginationTON,bean.getOriginationNumber()),getoriginationNPI(Global.SubmitOriginationNPI,bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL,getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), new ESMClass(), (byte)bean.getProtocolId(), (byte)3,null, validity, new RegisteredDelivery(dlvryRecptFlag), (byte)0, new GeneralDataCoding(false, false, MessageClass.CLASS0, bean.getEncodinngScheme()), (byte)0, bean.getMsgByteAray(),bean.getRequestId(),bean.getMessagePartNo(),optionalParam);*/
        							messageId= session.submitShortMessageTest(bean.getServiceType(),getOriginationTon(Global.SubmitOriginationTON,bean.getOriginationNumber()),getoriginationNPI(Global.SubmitOriginationNPI,bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL, getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), new ESMClass(), (byte)bean.getProtocolId(), Global.priority,null, validity, new RegisteredDelivery(dlvryRecptFlag), (byte)0, generalDataCoding, (byte)0, msg,bean.getRequestId(),bean.getMessagePartNo(),op);
        							/*messageId  = session.submitShortMessageTest("",getOriginationTon(Global.SubmitOriginationTON,bean.getOriginationNumber()),getoriginationNPI(Global.SubmitOriginationNPI,bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL,getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), new ESMClass(), (byte)0, (byte)3,null,validity, new RegisteredDelivery(dlvryRecptFlag), (byte)0, new GeneralDataCoding(false, false, MessageClass.CLASS0,bean.getEncodinngScheme()), (byte)0, bean.getMessageText().getBytes(),bean.getRequestId(),bean.getMessagePartNo(),optionalParam);;*/
        						}
        		}
        		else
        		{
        		        		//messageId= session.submitShortMessageTest("",getOriginationTon(Global.SubmitOriginationTON,bean.getOriginationNumber()),getoriginationNPI(Global.SubmitOriginationNPI,bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL,getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), new ESMClass(), (byte)bean.getProtocolId(), (byte)3,null, validity, new RegisteredDelivery(dlvryRecptFlag), (byte)0, new GeneralDataCoding(false, false, MessageClass.CLASS0, bean.getEncodinngScheme()), (byte)0, bean.getMsgByteAray());
        						if(optionalParam==null) {
								messageId= session.submitShortMessageTest(bean.getServiceType(),getOriginationTon(Global.SubmitOriginationTON,bean.getOriginationNumber()),getoriginationNPI(Global.SubmitOriginationNPI,bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL,getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), new ESMClass(), (byte)bean.getProtocolId(), Global.priority,null, validity, new RegisteredDelivery(dlvryRecptFlag), (byte)0, generalDataCoding, (byte)0, bean.getMsgByteAray(),bean.getRequestId(),bean.getMessagePartNo());
        						}else {
        							messageId= session.submitShortMessageTest(bean.getServiceType(),getOriginationTon(Global.SubmitOriginationTON,bean.getOriginationNumber()),getoriginationNPI(Global.SubmitOriginationNPI,bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL,getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), new ESMClass(), (byte)bean.getProtocolId(), Global.priority,null, validity, new RegisteredDelivery(dlvryRecptFlag), (byte)0, generalDataCoding, (byte)0, bean.getMsgByteAray(),bean.getRequestId(),bean.getMessagePartNo(),optionalParam);
        						}
        		}
        		
        	}
        
        	
        	else
        	{	
        		int flashDataCoding=0;
				int esmeClass=0;

			        logger.info("This i sthe character encoding ["+bean.getEncodinngScheme()+"]");	
					if(HandleUDH)
					{			// here we are setting the array which made by using udh........
						 esmeClass=64;
						 		
						 	if(!bean.isWapPush())
						 		{
						 			if(bean.getMessageType()==12)
						 				{
						 					flashDataCoding=240;
						 						if(bean.getEncodinngScheme()==Alphabet.ALPHA_UCS2)
						 							{
						 								flashDataCoding=24;
						 							}
						 				}
						 			else
						 				{
						 					if(bean.getEncodinngScheme()==Alphabet.ALPHA_UCS2)
						 						{
						 							flashDataCoding=8;
						 						}

						 				}
						 		}else
						 				{
						 					flashDataCoding=245;
						 				}
					}	
					else
						{	
							esmeClass=0;
							if(bean.getMessageType()==12)
								{
									flashDataCoding=240;
									if(bean.getEncodinngScheme()==Alphabet.ALPHA_UCS2)
										{
											flashDataCoding=24;
										}
								}
							else
								{
									if(bean.getEncodinngScheme()==Alphabet.ALPHA_UCS2)
										{
											flashDataCoding=8;
										}
								}

						}
					// added by avinash on 16 Aug 2017
	        		if(Global.dcsEnable==1)
	        		{
	        			generalDataCoding=new GeneralDataCoding(Integer.parseInt(Global.dcsEncoding));
	        		}
	        		else
	        		{
	        			generalDataCoding = new GeneralDataCoding(flashDataCoding);
	        		}
	        		//
	        		
					/*messageId= session.submitShortMessageTest("",getOriginationTon(Global.SubmitOriginationTON,
							bean.getOriginationNumber()), getoriginationNPI(Global.SubmitOriginationNPI,
							bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL,
							getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), 
							new ESMClass(esmeClass), (byte)bean.getProtocolId(), (byte)3,null, validity, 
							new RegisteredDelivery(dlvryRecptFlag), (byte)0, new GeneralDataCoding(flashDataCoding), 
							(byte)0, bean.getMsgByteAray());*/
	        		if(optionalParam==null) {
	        			messageId= session.submitShortMessageTest(bean.getServiceType(),getOriginationTon(Global.SubmitOriginationTON,
								bean.getOriginationNumber()), getoriginationNPI(Global.SubmitOriginationNPI,
								bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL,
								getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), 
								new ESMClass(esmeClass), (byte)bean.getProtocolId(), Global.priority,null, validity, 
								new RegisteredDelivery(dlvryRecptFlag), (byte)0, generalDataCoding, 
								(byte)0, bean.getMsgByteAray(),bean.getRequestId(),bean.getMessagePartNo());
	        		}else {
	        			messageId= session.submitShortMessageTest(bean.getServiceType(),getOriginationTon(Global.SubmitOriginationTON,
								bean.getOriginationNumber()), getoriginationNPI(Global.SubmitOriginationNPI,
								bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL,
								getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), 
								new ESMClass(esmeClass), (byte)bean.getProtocolId(), Global.priority,null, validity, 
								new RegisteredDelivery(dlvryRecptFlag), (byte)0, generalDataCoding, 
								(byte)0, bean.getMsgByteAray(),bean.getRequestId(),bean.getMessagePartNo(),optionalParam);
	        		}
	        		/*messageId= session.submitShortMessageTest("",getOriginationTon(Global.SubmitOriginationTON,
							bean.getOriginationNumber()), getoriginationNPI(Global.SubmitOriginationNPI,
							bean.getOriginationNumber()), bean.getOriginationNumber(), TypeOfNumber.INTERNATIONAL,
							getdestinationNPI(Global.SubmitDestinationNPI), bean.getDestinationNumber(), 
							new ESMClass(esmeClass), (byte)bean.getProtocolId(), (byte)3,null, validity, 
							new RegisteredDelivery(dlvryRecptFlag), (byte)0, generalDataCoding, 
							(byte)0, bean.getMsgByteAray(),bean.getRequestId(),bean.getMessagePartNo());*/

		}
        	
          logger.info("Getting the message id sequence number ["+messageId+"]........................");
        	
        } catch (PDUException e) {
            // Invalid PDU parameter	
        	errorLogger.error("ErrorCode ["+Global.errCode+"-00076] [PDUException when Invalid PDU parameter in submitNormalMessage Time] Error[" + e.getMessage()+"]");
     	   	e.printStackTrace(); 
            messageId=-99;
        
        }
        catch (ResponseTimeoutException e) {
            // Response timeout
        	errorLogger.error("ErrorCode ["+Global.errCode+"-00077] [ResponseTimeoutException when Response timeout in submitNormalMessage Time] Error[" + e.getMessage()+"]");
     	   	e.printStackTrace(); 
        	messageId=-98;
          
        } catch (InvalidResponseException e) {
            // Invalid response
        	errorLogger.error("ErrorCode ["+Global.errCode+"-00078] [InvalidResponseException when Receive invalid respose in submitNormalMessage Time] Error[" + e.getMessage()+"]");
     	   	e.printStackTrace(); 
        	messageId=-97;
            e.printStackTrace();
        } catch (NegativeResponseException e) {
            // Receiving negative response (non-zero command_status)
        	errorLogger.error("ErrorCode ["+Global.errCode+"-00079] [NegativeResponseException when Receive negative response in submitNormalMessage Time] Error[" + e.getMessage()+"]");

        	messageId=-96;
            e.printStackTrace();
        } catch (IOException e) {
        	errorLogger.error("ErrorCode ["+Global.errCode+"-90002] [IOException when Submit Normal Message to SMSC] Error[" + e.getMessage()+"]");

        	e.printStackTrace();
            messageId=-95;
        }catch(Exception exe)
        {
        	exe.printStackTrace();
        	errorLogger.error("ErrorCode ["+Global.errCode+"-00080] [Exception when Submit sm thread submit Normal message] Error[" + exe.getMessage()+"]");
        }
        finally {
			generalDataCoding = null;
		}
        
        
        return Integer.toString(messageId);
    }
	
	
// this function is for getting the ton according to the origination number......
/**
 * THIS FUNCTION IS FOR GETTING THE {@link TypeOfNumber} FOR ORIGINATION NUMBER
 * @param oriNum :- REFERS TO THE ORIGINATION NUMBER
 * @return OBJECT OF {@link TypeOfNumber}
 */


public TypeOfNumber getOriginationTon(int orinationTON,String originationNum)
{
	logger.debug("length of origination number is ["+originationNum.length()+"]");
	if(!originationNum.matches("[0-9]+") || (originationNum.length()<=Global.orgNumLength))
	{
		
		return TypeOfNumber.ALPHANUMERIC;
	}
	switch(orinationTON)
	{
	case 0:
		return TypeOfNumber.UNKNOWN;
		
	case 1:
		return TypeOfNumber.INTERNATIONAL;
		
	case 2:
		return TypeOfNumber.NATIONAL;
		
	case 3:
		return TypeOfNumber.NETWORK_SPECIFIC;
		
	case 4:
		return TypeOfNumber.SUBSCRIBER_NUMBER;
		
	case 5:
		return TypeOfNumber.ALPHANUMERIC;
	
	case 6:
		return TypeOfNumber.ABBREVIATED;
		
	
	default:
		return 	TypeOfNumber.UNKNOWN;
	}	
	
}

public NumberingPlanIndicator getoriginationNPI(int submitOriginationNPI,String originationNum)
{
	if(!originationNum.matches("[0-9]+") || (originationNum.length()<=Global.orgNumLength))
	{
		logger.debug("Number is alphanumeric");
		return NumberingPlanIndicator.UNKNOWN;
	}
	
	switch(submitOriginationNPI)
	{
	case 0:
		return NumberingPlanIndicator.UNKNOWN;
		
	case 1:
		return NumberingPlanIndicator.ISDN;
		
	case 2:
		return NumberingPlanIndicator.DATA;
		
	case 3:
		return NumberingPlanIndicator.TELEX;
		
	case 4:
		return NumberingPlanIndicator.LAND_MOBILE;
		
	case 5:
		return NumberingPlanIndicator.NATIONAL;
	
	case 6:
		return NumberingPlanIndicator.PRIVATE;
		
	case 7:
		return NumberingPlanIndicator.ERMES;
		
	case 8:
		return NumberingPlanIndicator.INTERNET;
		
	case 9:
		return NumberingPlanIndicator.WAP;
		
	default:
		return 	NumberingPlanIndicator.UNKNOWN;
	}
}


public NumberingPlanIndicator getdestinationNPI(int submitDestinationNPI)
{
	switch(submitDestinationNPI)
	{
	case 0:
		return NumberingPlanIndicator.UNKNOWN;
		
	case 1:
		return NumberingPlanIndicator.ISDN;
		
	case 2:
		return NumberingPlanIndicator.DATA;
		
	case 3:
		return NumberingPlanIndicator.TELEX;
		
	case 4:
		return NumberingPlanIndicator.LAND_MOBILE;
		
	case 5:
		return NumberingPlanIndicator.NATIONAL;
	
	case 6:
		return NumberingPlanIndicator.PRIVATE;
		
	case 7:
		return NumberingPlanIndicator.ERMES;
		
	case 8:
		return NumberingPlanIndicator.INTERNET;
		
	case 9:
		return NumberingPlanIndicator.WAP;
		
	default:
		return 	NumberingPlanIndicator.UNKNOWN;
	}
}



//This function is for calculate validity Period of Message......
/**
* THIS FUNCTION IS FOR GETTING THE {@link validation Period} FOR MESSAGE
* @param validityPeriod :- REFERS TO THE VALIDATION TIME FOR MESSAGE
* @return STRING OF {@link ValidityTime of Message}
*/
public String getValidityPeriod(long validityPeriod)
{
	int value=0;
	String validityTime="";
	try
	{
	for(int i=1;i<=6;i++)
	{
	switch(i) {
	case 1://value 1 is for calculate year
			value=(int)validityPeriod/(3600*24*365);
			validityPeriod=validityPeriod%(3600*24*365);
	//		logger.info("year are"+value);
			break;
	case 2://value 2 for calculate month
		value=(int)validityPeriod/(3600*24*30);
			validityPeriod=validityPeriod%(3600*24*30);
	//		logger.info("month are"+value);
			break;
	case 3: //value 3 for calculate day
		value=(int)validityPeriod/(3600*24);
			validityPeriod=validityPeriod%(3600*24);
	//		logger.info("days are"+value);
			break;
	case 4: //value 4 for calculate hour
			value=(int)validityPeriod/3600;
			validityPeriod=validityPeriod%3600;
	//		logger.info("hours are"+value);
			break;
	case 5:  //value 5 for calculate minute
			value=(int)validityPeriod/60;
			validityPeriod=validityPeriod%60;
	//		logger.info("minute are"+value);
			break;
	case 6: //value 6 for calculate second
			value=(int)validityPeriod/60;
			validityPeriod=validityPeriod%60;
	
			break;
	default:
		break;
	}
		if(value >=10)
			{
			
			validityTime=validityTime+value;
			}
			else{
				validityTime=validityTime+"0"+value;
				
			}	
	}
	
	}
catch(NumberFormatException e)
	{
	errorLogger.error("ErrorCode ["+Global.errCode+"-90004] [NumberFormatException when GetValidity Period] Error[" + e.getMessage()+"]");
	e.printStackTrace();
	}
	catch (Exception e) {
		errorLogger.error("ErrorCode ["+Global.errCode+"-00081] [Exception when Calculate validity Period] Error[" + e.getMessage()+"]");
		e.printStackTrace();
	}
	return validityTime;
}
}
