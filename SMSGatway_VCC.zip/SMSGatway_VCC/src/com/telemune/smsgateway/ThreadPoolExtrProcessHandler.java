package com.telemune.smsgateway;

import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import com.telemune.smsgateway.bean.SMSProcessBean;

public class ThreadPoolExtrProcessHandler implements Runnable {

	Logger logger = Logger.getLogger("ThreadPoolExtrServiceHandler");
	 final static Logger errorLogger = Logger.getLogger("errorLogger");
	ThreadPoolExecutor contentexecutorPool = null;
	SMSProcessBean bean = null;
	String responseCode = "Na";

	public ThreadPoolExtrProcessHandler(ThreadPoolExecutor contentexecutorPool) {

		this.contentexecutorPool = contentexecutorPool;
	}

	public void run() {

		try {
			while (true) {

				if (Global.rcvSMSQueue.isEmpty()) {
					try {
						Thread.sleep(1);

					} 
					catch(InterruptedException ie)
					{
						errorLogger.error("ErrorCode ["+Global.errCode+"-90013] [InterruptedException when Process Handler Threadpool is going to sleep] Error[" + ie.getMessage()+"]");
			        	  ie.printStackTrace(); 
					}
					catch (Exception ex) {
						errorLogger.error("ErrorCode ["+Global.errCode+"-00059] [Exception when process handler Threadpool is going to sleep] ERROR ["+ex.getMessage()+"]");
						ex.printStackTrace();
						
					}

				} else {
					try {

						logger.debug("THREAD POOL FOUND REQUEST TO PROCESS at the time of process Hit URL size of queue is ["+ Global.rcvSMSQueue.size());
						logger.info("URL queue size is"+Global.rcvSMSQueue.size()+String
								.format("[monitor] [%d/%d] Active: %d, Completed: %d, Task: %d, isShutdown: %s, isTerminated: %s",

								this.contentexecutorPool.getPoolSize(),

								this.contentexecutorPool.getCorePoolSize(),

								this.contentexecutorPool.getActiveCount(),

								this.contentexecutorPool
										.getCompletedTaskCount(),

								this.contentexecutorPool.getTaskCount(),

								this.contentexecutorPool.isShutdown(),

								this.contentexecutorPool.isTerminated()));
						if(this.contentexecutorPool.getActiveCount()==ProcessThread.maxThreadSize)
						{
							logger.info("Thread is going to sleep because maximum threads are active");
							Thread.sleep(1000/100);
						}
						bean = Global.rcvSMSQueue.poll();
						
						contentexecutorPool.execute(new ProcessHitUrl(bean));
				

					}
					catch (Exception ex) {
						
						errorLogger.error("ErrorCode ["+Global.errCode+"-00060] [Exception when queue is full and handle process request thread] ERROR ["+ex.getMessage()+"]");
						ex.printStackTrace();
						System.exit(1);
						break;
					}

				}

			}// while(true)

		} catch (Exception ex) {

			errorLogger.error("ErrorCode ["+Global.errCode+"-00061] [Exception in Process Handler Thread pool executor thread] ERROR ["+ex.getMessage()+"]");
			ex.printStackTrace();
		}

	}// run()

}
