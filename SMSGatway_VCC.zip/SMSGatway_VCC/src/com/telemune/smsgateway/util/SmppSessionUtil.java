package com.telemune.smsgateway.util;

import java.net.ConnectException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import org.apache.log4j.Logger;
import org.jsmpp.session.SMPPSession;

import com.telemune.smsgateway.Global;
import com.telemune.smsgateway.bean.ConnectionDetailBean;
import com.telemune.smsgateway.bean.SmscConfigBean;

public class SmppSessionUtil implements Runnable {
	private static final Logger logger = Logger.getLogger("SmppSessionUtil");
	
	@Override
	public void run() {
		this.process();
	}

	private void process() {
		while(true){
			if(this.checkDetailExist())
				this.getAndConnectionSmppSession();
			try {
				Thread.sleep(5000);
			}catch(Exception e){
				
			}
		}
	}
	
	private boolean checkDetailExist() {
		try {
			if (Global.smscParamDetail == null || Global.smscParamDetail.isEmpty()) {
				logger.warn("Smsc:: config has no detail in db: now sleep for 5000 millseconds");
			} else {
				return true;
			}
		}catch(Exception e){
			logger.error("Smsc:: config has no detail in db:: "+e.getMessage());
		}
		return false;
	}
	
	@SuppressWarnings({ "rawtypes"})
	private void getAndConnectionSmppSession(){
		Enumeration cnfKey = null;
		SmscConfigBean smscBean = null;
		try {
			cnfKey = Global.smscParamDetail.keys();
			while (cnfKey.hasMoreElements()) {
				smscBean = (SmscConfigBean)Global.smscParamDetail.get((Integer)cnfKey.nextElement());
				if(!this.alreadyConnected(smscBean))
					this.connectSmsc(smscBean);
			}
		}catch(Exception e){
			logger.error("Smsc:: Error while create conn: "+e.getMessage());
		}
	}
	private boolean alreadyConnected(SmscConfigBean smscBean){
		ConnectionDetailBean connCount[] = null;
		boolean connected = false;
		try {
			connCount = Global.smppSessionDetail.get(smscBean.getSmscId());
			this.getOnlyActiveConn(connCount, smscBean);
			if(connCount != null){
				Global.smppSessionDetail.put(smscBean.getSmscId(), connCount);
				if(smscBean.getNoOfConnections()==connCount.length) {
					logger.info("Smsc: "+smscBean.getSmscId()+" ip: "+
							smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
							" address range: "+smscBean.getAddressRange()+
							" window size: "+smscBean.getWindowSize()+" all conn active");
					return true;
				} else {
					logger.warn("Smsc: "+smscBean.getSmscId()+" ip: "+
							smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
							" address range: "+smscBean.getAddressRange()+
							" window size: "+smscBean.getWindowSize()+
							" only "+connCount.length+" is active");
				}
			}
			return connected;
		}catch(Exception e){
			logger.error("Smsc:: Error while check connection existence: "+e.getMessage());
		}
		return connected;
	}
	private void connectSmsc(SmscConfigBean smscBean){
		ConnectionDetailBean connCount[] = null;
		ConnectionDetailBean tempCount[] = null;
		int index = 0;
		try {
			this.printSmscInfo(smscBean);
			tempCount = Global.smppSessionDetail.get(smscBean.getSmscId());
			this.getOnlyActiveConn(tempCount, smscBean);
			connCount = new ConnectionDetailBean[smscBean.getNoOfConnections()];
			if(tempCount != null){
				index = tempCount.length;
				logger.info("Smsc: "+smscBean.getSmscId()+" ip: "+
						smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
						" address range: "+smscBean.getAddressRange()+
						" window size: "+smscBean.getWindowSize()+" inactive conn: "
						+(smscBean.getNoOfConnections()-tempCount.length));
				for(int i = 0; i < tempCount.length; i++)
					connCount[i] = tempCount[i];
			}
			for(int i = index; i < smscBean.getNoOfConnections(); i++){
				this.connect(smscBean, connCount, i);
			}
			this.getOnlyActiveConn(connCount, smscBean);
			if(connCount != null)
				Global.smppSessionDetail.put(smscBean.getSmscId(), connCount);
		}catch(Exception e){
			logger.error("Smsc: "+smscBean.getSmscId()+" ip: "+
					smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
					" address range: "+smscBean.getAddressRange()+
					" window size: "+smscBean.getWindowSize()+" Error: "+e.getMessage());
		}
	}
	private void getOnlyActiveConn(ConnectionDetailBean [] connCount, SmscConfigBean smscBean){
		List<ConnectionDetailBean> list = new ArrayList<ConnectionDetailBean>();
		try {
			if(connCount != null){
				for(int i = 0; i < connCount.length; i++){
					if(connCount[i] != null && connCount[i].getSession() != null
							&& connCount[i].getSession().getSessionState().isTransmittable()
							&& connCount[i].getSession().getSessionState().isBound()){
						list.add(connCount[i]);
					}
				}
			} else {
				logger.warn("Smsc: "+smscBean.getSmscId()+" ip: "+
						smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
						" address range: "+smscBean.getAddressRange()+
						" window size: "+smscBean.getWindowSize()+" no active conn yet");
			}
			if(list.size()>0){
				connCount = new ConnectionDetailBean [list.size()];
				for(int i = 0; i < list.size(); i++){
					connCount[i] = list.get(i);
				}
				logger.info("Smsc: "+smscBean.getSmscId()+" ip: "+
						smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
						" address range: "+smscBean.getAddressRange()+
						" window size: "+smscBean.getWindowSize()+" active conn: "+connCount.length);
			}
		}catch(Exception e){
			logger.error("Smsc: "+smscBean.getSmscId()+" ip: "+
					smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
					" address range: "+smscBean.getAddressRange()+
					" window size: "+smscBean.getWindowSize()+" Error:: "+e.getMessage());
		}
	}
	private void connect(SmscConfigBean smscBean, 
			ConnectionDetailBean conBean[], int index) {
		SMPPSession smppSession = null;
		String smscSystemId = "-1";
		try {
			smppSession = new SMPPSession();
			if (Global.addressrange == 0)
				smscBean.setAddressRange(null);
			smscSystemId = smppSession.connectAndBindWithSMSCid(
					smscBean.getSmscIp(), smscBean.getSmscPort(),
					smscBean.getBindType(), smscBean.getSmscUserId(),
					smscBean.getSmscPassword(), smscBean.getSystemType(),
					smscBean.getTon(), smscBean.getNpi(),
					smscBean.getAddressRange(), 20000, Global.localHost,
					Global.localPort);
			if (smppSession != null
					&& smppSession.getSessionState().isTransmittable()
					&& smppSession.getSessionState().isBound()) {
				conBean[index] = new ConnectionDetailBean(smppSession,
						smscSystemId.trim(), smscBean.getWindowSize(),
						smscBean.getSmscId());
			} else {
				logger.warn("Smsc: "+smscBean.getSmscId()+" ip: "+
						smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
						" address range: "+smscBean.getAddressRange()+
						" window size: "+smscBean.getWindowSize()+" connect to failed");
			}
		} catch(ConnectException ex){
			logger.warn("Smsc: "+smscBean.getSmscId()+" ip: "+
					smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
					" address range: "+smscBean.getAddressRange()+
					" window size: "+smscBean.getWindowSize()+" connect to failed: "+ex.getMessage());
		}catch (Exception e) {
			logger.warn("Smsc: "+smscBean.getSmscId()+" ip: "+
					smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
					" address range: "+smscBean.getAddressRange()+
					" window size: "+smscBean.getWindowSize()+" connect to failed: "+e.getMessage());
		}
	}
	
	private void printSmscInfo(SmscConfigBean smscBean){
		logger.info("Smsc: "+smscBean.getSmscId()+" ip: "+
				smscBean.getSmscIp()+" port: "+smscBean.getSmscPort()+
				" address range: "+smscBean.getAddressRange()+
				" window size: "+smscBean.getWindowSize());
		logger.info("Smsc: "+smscBean.getSmscId()+" userid: "+
				smscBean.getSmscUserId()+" password: "+smscBean.getSmscPassword()+
				" status: "+smscBean.getStatus()+" conn: "+smscBean.getNoOfConnections());
	}

}
