package com.telemune.smsgateway.util;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.jsmpp.bean.Alphabet;

import com.telemune.smsgateway.Global;
import com.telemune.smsgateway.bean.GmatMessageBean;
import com.telemune.smsgateway.bean.UDHDataBean;

public class MessageUtil {
	private final static Logger logger = Logger.getLogger("MessageUtil");
	private final static Logger errorLogger = Logger.getLogger("errorLogger");
	private static int refCount = 0;
	
	/*public Alphabet getSubmitSmCharacterEncoding() {
		Alphabet retVal = Alphabet.ALPHA_DEFAULT;
		try {

			if (Global.submitSmCharEncoding.equalsIgnoreCase("utf-8")) {
				retVal = Alphabet.ALPHA_8_BIT;
			} else if (Global.submitSmCharEncoding.equalsIgnoreCase("UCS2")
					|| (Global.submitSmCharEncoding.equalsIgnoreCase("utf-16BE"))) {
				retVal = Alphabet.ALPHA_UCS2;
			} else if (Global.submitSmCharEncoding.equalsIgnoreCase("default")
					|| Global.submitSmCharEncoding.equalsIgnoreCase("7-bit")) {
				retVal = Alphabet.ALPHA_DEFAULT;
			}
			logger.debug("Submit_sm character encoding:: " + Global.submitSmCharEncoding);
		} catch (Exception ex) {
			errorLogger.error("ErrorCode [" + Global.errCode
					+ "-00038] [Exception when setting submit sm character encoding] ERROR [" + ex.getMessage() + "]");
			ex.printStackTrace();
		}
		return retVal;

	}*/
	
	// modified on 04/10/2014 to check submitSmCharacterEncodeing based on the message text
	public Alphabet getSubmitSmCharacterEncoding(String messageText) {
		Alphabet retVal = Alphabet.ALPHA_DEFAULT;
		Matcher matcher = null;
		
		try {
			
			if (Global.submitSmCharEncoding.equalsIgnoreCase("utf-8")) {
				retVal = Alphabet.ALPHA_8_BIT;
			} 
			else if (Global.submitSmCharEncoding.equalsIgnoreCase("UCS2")
					|| (Global.submitSmCharEncoding.equalsIgnoreCase("utf-16BE"))) {
				retVal = Alphabet.ALPHA_UCS2;
			} 
			else if (Global.submitSmCharEncoding.equalsIgnoreCase("default")
					|| Global.submitSmCharEncoding.equalsIgnoreCase("7-bit")) {
				retVal = Alphabet.ALPHA_DEFAULT;
			}
			else{
				
				matcher = Global.defaultSmsEncodingPattern.matcher(messageText);
				
				if(matcher.matches())
				{
					//if message text matches the given pattern for 7bit encoding scheme.
					logger.debug("messageText ["+messageText+"] pattern matcher result ["+matcher.matches()+"] setting encodingtype [ALPHA_DEFAULT] ["+Alphabet.ALPHA_DEFAULT+"]]");
					retVal = Alphabet.ALPHA_DEFAULT;
				}
				else
				{
					//if message text does not match the given pattern for 7bit encoding scheme.
					logger.debug("messageText ["+messageText+"] pattern matcher result ["+matcher.matches()+"] setting encodingtype [ALPHA_UCS2] ["+Alphabet.ALPHA_UCS2+"]]");
					retVal = Alphabet.ALPHA_UCS2;	
				}
				
			}
			
			logger.debug("Submit_sm character encoding:: " + Global.submitSmCharEncoding);
		} catch (Exception ex) {
			errorLogger.error("ErrorCode [" + Global.errCode
					+ "-00038] [Exception when setting submit sm character encoding] ERROR [" + ex.getMessage() + "]");
			ex.printStackTrace();
		}
		return retVal;

	}
	
	
	public void handleVcardStringReplace(GmatMessageBean gmatBean) {
		int destport = 9204;
		try {
			logger.info(String.format("dest: %s, org: %s, handle vcard, destport: "
					+ "%s",gmatBean.getDestinationNumber(), gmatBean.getOriginationNumber(), destport));
			// REPLACING # WITH \r\n FOR MAKING IT VCARD
			gmatBean.setMessageText(gmatBean.getMessageText().replace("#", "\r\n"));
			gmatBean.setDestinationPort(destport);
			gmatBean.setEncodinngScheme(Alphabet.ALPHA_8_BIT);

		} catch (Exception ex) {
			errorLogger.error("ErrorCode [" + Global.errCode + "-00037] ResponseId [" + gmatBean.getResponseId()
					+ "] RequestId [" + gmatBean.getRequestId() + "] MSISDN [" + gmatBean.getDestinationNumber()
					+ " [Exception when handling vcard] ERROR [" + ex.getMessage() + "]");
			ex.printStackTrace();
		}

	}
	public void proccessMessageForSMSC(GmatMessageBean bean, List<GmatMessageBean> dataAl) {
		int strLength = -1;

		int totalMessageSegment = -1;
		GmatMessageBean newMsgBean = null;
		UDHDataBean udhBean = null;
		dataAl.clear();
		
		int messageLength=-1;
		try {

			strLength = bean.getMessageText().length();
			if(bean.getEncodinngScheme()==Alphabet.ALPHA_UCS2)
			{
				messageLength=Global.ucs2MsgMaxLength;
			}
			else if(bean.getEncodinngScheme()==Alphabet.ALPHA_8_BIT)
			{
				messageLength=Global.utf8MsgMaxLength;
			}
			else if(bean.getEncodinngScheme()==Alphabet.ALPHA_DEFAULT)
			{
				messageLength=Global.defaultMsgMaxLength;
			}
			
			logger.debug("sms encoding scheme ["+bean.getEncodinngScheme()+"] original sms length ["+strLength+"] encoding default length ["+messageLength+"] ");
			
			if (Global.submitSmUDH == 2){// REFERS FOR MESSAGE PAYLOAD PARAM
				logger.info(String.format("dest: %s, org: %s, handle payload param"
						+ "%s",bean.getDestinationNumber(), bean.getOriginationNumber()));
				newMsgBean = new GmatMessageBean(bean.getResponseId(), bean.getRequestId(), bean.getOriginationNumber(),
						bean.getDestinationNumber(), bean.getMessageText(), bean.getMessageType(), bean.getStatus(),
						bean.getValidityType(), bean.getDestinationPort(), bean.getEncodinngScheme(),
						bean.getProtocolId(), bean.getCampaignId(), bean.getSmscId(), bean.getOpcode(),bean.getOptBean(),
						bean.getConDetailBean(),bean.getRetryCount());
				newMsgBean.setMessagePayLoad(true);
				newMsgBean.setServiceType(bean.getServiceType());
				if (strLength > messageLength) {
					newMsgBean.setLongMessage(true);
				}
				
				dataAl.add(newMsgBean);

			} else if (Global.submitSmUDH == 3) {
				short msgRefNum = (short) getRefCount();
				logger.info(String.format("dest: %s, org: %s, handle optional parameters"
						,bean.getDestinationNumber(), bean.getOriginationNumber()));
				if (strLength <= messageLength) {
					newMsgBean = new GmatMessageBean(bean.getResponseId(), bean.getRequestId(),
							bean.getOriginationNumber(), bean.getDestinationNumber(), bean.getMessageText(),
							bean.getMessageType(), bean.getStatus(), bean.getValidityType(), bean.getDestinationPort(),
							bean.getEncodinngScheme(), bean.getProtocolId(), bean.getCampaignId(), bean.getSmscId(),
							bean.getOpcode(), bean.getOptBean(),bean.getConDetailBean(),bean.getRetryCount());
					newMsgBean.setSubmitOptParam(true);
					newMsgBean.setMessageRef(msgRefNum);
					newMsgBean.setServiceType(bean.getServiceType());
					logger.info(String.format("dest: %s, org: %s, msg text for short msg: %s"
							,bean.getDestinationNumber(), bean.getOriginationNumber(),newMsgBean.getMessageRef()));
					if (handleSubmitSmCharacterEncoding(bean.getMessageText()) == Global.SUBMIT_SM_UCS_2)
						newMsgBean.setMsgByteAray(bean.getMessageText().getBytes("UTF-16BE"));
					else
						newMsgBean.setMsgByteAray(bean.getMessageText().getBytes());

					dataAl.add(newMsgBean);

				} else {
					logger.debug("setting up the flag where message is long");

					totalMessageSegment = (((strLength % messageLength) == 0)
							|| ((strLength / messageLength) == 0) ? (strLength / messageLength)
									: ((strLength / messageLength) + 1));

					logger.info(String.format("dest: %s, org: %s, total msg segment"
							+ "%s",bean.getDestinationNumber(), bean.getOriginationNumber(),totalMessageSegment));
					String ogMessage = bean.getMessageText();
					int optCount = 0;
					for (int j = 1; j <= totalMessageSegment; j++) {
						newMsgBean = new GmatMessageBean(bean.getResponseId(), bean.getRequestId(),
								bean.getOriginationNumber(), bean.getDestinationNumber(), bean.getMessageText(),
								bean.getMessageType(), bean.getStatus(), bean.getValidityType(),
								bean.getDestinationPort(), bean.getEncodinngScheme(), bean.getProtocolId(),
								bean.getCampaignId(), bean.getSmscId(), bean.getOpcode(),bean.getOptBean(), bean.getConDetailBean(),bean.getRetryCount());
						newMsgBean.setSubmitOptParam(true);
						newMsgBean.setLongMessage(true);
						newMsgBean.setServiceType(bean.getServiceType());
						newMsgBean.setMessageTotalSegment(totalMessageSegment);
						if (j == totalMessageSegment) {
							newMsgBean.setMessageText(ogMessage.substring(optCount, ogMessage.length()));
							newMsgBean.setMoreMessage(0);
						} else {
							newMsgBean.setMessageText(ogMessage.substring(optCount, optCount + messageLength));
							newMsgBean.setMoreMessage(1);
						}
						optCount = optCount + messageLength;
						newMsgBean.setMessagePartNo(j);

						newMsgBean.setMessageRef(msgRefNum);
						logger.debug("message Text is..........." + newMsgBean.getMessageText()
								+ " message reference number is" + newMsgBean.getMessageRef() + " More Message send ["
								+ newMsgBean.getMoreMessage());
						dataAl.add(newMsgBean);
					}
				}

			} else {// here we are going to set the udh........
				
				logger.debug("#######$$$$$$$$$$$$$$$$$$$$$$$$$$ going to set the udh submitSmUDH ["+Global.submitSmUDH+"]");
				//udhBean = new UDHDataBean();
				// this function check the whether the udh is there or not
				udhBean = new UDHDataBean();
				// this function check the whether the udh is there or not
				handleUDHMessage(bean.getMessageText(), bean.getDestinationPort(), udhBean, bean.getMessageType(),bean.getEncodinngScheme());
				int msgPartLength = 0;
				logger.debug("#####UDH "+udhBean.isApplyUDH());
				if (!udhBean.isApplyUDH()) {
					// In this condtion no need to set the udh..............
					newMsgBean = new GmatMessageBean(bean.getResponseId(),
							bean.getRequestId(), bean.getOriginationNumber(),
							bean.getDestinationNumber(), bean.getMessageText(),
							bean.getMessageType(), bean.getStatus(),
							bean.getValidityType(), bean.getDestinationPort(),
							bean.getEncodinngScheme(), bean.getProtocolId(),
							bean.getCampaignId(), bean.getSmscId(),
							bean.getOpcode(), bean.getOptBean(),bean.getConDetailBean(),bean.getRetryCount());
					newMsgBean.setServiceType(bean.getServiceType());
					if (handleSubmitSmCharacterEncoding(bean.getMessageText()) == Global.SUBMIT_SM_UCS_2)
						newMsgBean.setMsgByteAray(bean.getMessageText().getBytes("UTF-16BE"));
					else
						newMsgBean.setMsgByteAray(bean.getMessageText().getBytes());
					newMsgBean.setSubmitNormal(true);
					dataAl.add(newMsgBean);
				} else {
					if (!udhBean.isConcatBitAdded()) {
						// condition where no extra message is their
						if (bean.getDestinationPort() > 0) {
							newMsgBean = new GmatMessageBean(bean.getResponseId(), bean.getRequestId(),
									bean.getOriginationNumber(), bean.getDestinationNumber(), bean.getMessageText(),
									bean.getMessageType(), bean.getStatus(), bean.getValidityType(),
									bean.getDestinationPort(), bean.getEncodinngScheme(), bean.getProtocolId(),
									bean.getCampaignId(), bean.getSmscId(), bean.getOpcode(),bean.getOptBean(), bean.getConDetailBean(),bean.getRetryCount());
							byte[] msgBytes = null;
							if (handleSubmitSmCharacterEncoding(bean.getMessageText()) == Global.SUBMIT_SM_UCS_2)
								msgBytes = bean.getMessageText().getBytes("UTF-16BE");
							else
								msgBytes = bean.getMessageText().getBytes();
							byte[] udh = new byte[udhBean.getUdhHeaderLength()];
							udh[0] = (byte) udhBean.getUdhMessageHeaderLength(); // same
																					// for
																					// any
																					// msg
							udh[1] = 5; // same for any msg
							udh[2] = 4; // same for any msg
							udh[3] = (byte) (bean.getDestinationPort() >> 8);
							udh[4] = (byte) (bean.getDestinationPort());
							udh[5] = 0;
							udh[6] = 0;

							msgPartLength = udhBean.getUdhHeaderLength() + msgBytes.length;

							byte[] msgPart = new byte[msgPartLength];

							System.arraycopy(udh, 0, msgPart, 0, udh.length);
							System.arraycopy(msgBytes, 0, msgPart, udh.length, msgBytes.length);
							String msgtxt = new String(msgPart);
							logger.info(String.format("dest: %s, org: %s, udh header: %s"
									,bean.getDestinationNumber(), bean.getOriginationNumber(),Arrays.toString(msgPart)));
							newMsgBean.setMsgByteAray(msgPart);

							newMsgBean.setServiceType(bean.getServiceType());
							dataAl.add(newMsgBean);

						} else {
							logger.error(" #" + bean.getDestinationNumber()
									+ "# condition inside where concatination bit is not their and also no destination bit is present ");

						}

					} else {
						if (udhBean.isConcatBitAdded()) {

							// inside condition where udh is present message is
							// long message and destination port is also their
							// here we have to set the destination port
							// here we also set the concatination bit
							totalMessageSegment = udhBean.getTotalmessageParts();
							logger.info(String.format("dest: %s, org: %s, total msg segment"
									+ "%s",bean.getDestinationNumber(), bean.getOriginationNumber(),totalMessageSegment));
							String ogMessage = bean.getMessageText();
							int optCount = 0;
							int msgPartNum = 1;
							int msgRefNum = getRefCount();
							int msgLength=messageLength;
							for (int j = 1; j <= totalMessageSegment; j++ ){
								newMsgBean = new GmatMessageBean(bean.getResponseId(), bean.getRequestId(),
										bean.getOriginationNumber(), bean.getDestinationNumber(), bean.getMessageText(),
										bean.getMessageType(), bean.getStatus(), bean.getValidityType(),
										bean.getDestinationPort(), bean.getEncodinngScheme(), bean.getProtocolId(),
										bean.getCampaignId(), bean.getSmscId(), bean.getOpcode(),bean.getOptBean(),
										bean.getConDetailBean(),bean.getRetryCount());
								newMsgBean.setMessagePartNo(j);
								newMsgBean.setServiceType(bean.getServiceType());
								byte[] msgBytes = null;

								if (j == totalMessageSegment) {

									if (handleSubmitSmCharacterEncoding(bean.getMessageText()) == Global.SUBMIT_SM_UCS_2)
										msgBytes = ogMessage.substring(optCount, ogMessage.length())
												.getBytes("UTF-16BE");
									else
										msgBytes = ogMessage.substring(optCount, ogMessage.length()).getBytes();

									newMsgBean.setMessageText(ogMessage.substring(optCount, ogMessage.length()));
									logger.info("#####Message test is " + newMsgBean.getMessageText()+" optCOunt "+optCount);
								} else {

									if (handleSubmitSmCharacterEncoding(bean.getMessageText()) == Global.SUBMIT_SM_UCS_2)
									{
										msgBytes = ogMessage
												.substring(optCount, optCount + udhBean.getUdhMessageLength())
												.getBytes("UTF-16BE");
										
										logger.debug("start optCount["+optCount+"] UdhMessageLength["+udhBean.getUdhMessageLength()+"] index [" + optCount + "] endIndex["
												+ (optCount + udhBean.getUdhMessageLength()) + "] message["
												+ new String(msgBytes) + "]");
										
										// if(messageLength%2!=0)
										// msgLength=messageLength+1;
										
										int udhDefaultHeaderLength = (((udhBean.getUdhHeaderLength() % 2) == 0) && ((udhBean.getUdhHeaderLength() / 2) == 0)
												? (udhBean.getUdhHeaderLength() / 2) : (((udhBean.getUdhHeaderLength() + 1) / 2)));
										
										newMsgBean.setMessageText(ogMessage.substring(optCount, optCount + 
												messageLength-udhDefaultHeaderLength));	
										
										logger.debug("optCount["+optCount+"] messageLength["+messageLength+"] UdhHeaderLength["+udhDefaultHeaderLength+"] startindex [" + optCount + "] endIndex["
												+ (optCount + messageLength - udhDefaultHeaderLength)
												+ "] message[" + newMsgBean.getMessageText() + "]");
										
									}else
									{
										msgBytes = ogMessage
												.substring(optCount, optCount + udhBean.getUdhMessageLength())
												.getBytes();
										
										logger.debug("start optCount["+optCount+"] UdhMessageLength["+udhBean.getUdhMessageLength()+"] index [" + optCount + "] endIndex["
												+ (optCount + udhBean.getUdhMessageLength()) + "] message["
												+ new String(msgBytes) + "]");
										
										newMsgBean.setMessageText(ogMessage.substring(optCount, optCount + 
											messageLength-udhBean.getUdhHeaderLength()));		
									
										logger.debug("optCount["+optCount+"] messageLength["+messageLength+"] UdhHeaderLength["+udhBean.getUdhHeaderLength()+"] startindex [" + optCount + "] endIndex["
												+ (optCount + messageLength - udhBean.getUdhHeaderLength())
												+ "] message[" + newMsgBean.getMessageText() + "]");
										}
									}

								byte[] udh = new byte[udhBean.getUdhHeaderLength()];
								if (bean.getDestinationPort() > 0) {

									// udh[0]=(byte)udhBean.getUdhHeaderLength();
									// //same for any msg
									udh[0] = (byte) udhBean.getUdhMessageHeaderLength();
									udh[1] = 0; // same for any msg concat bit
												// tag
									udh[2] = 3; // same for any msg concat bit
												// tag value
									udh[3] = Byte.valueOf(Integer.toString(msgRefNum));
									udh[4] = (byte) udhBean.getTotalmessageParts(); // total
																					// number
																					// of
																					// parts
									udh[5] = (byte) msgPartNum;
									udh[6] = 5;// same for any msg dest port tag
									udh[7] = 4;// same for any msg dest port tag
												// value
									udh[8] = (byte) (bean.getDestinationPort() >> 8);
									udh[9] = (byte) (bean.getDestinationPort());
									udh[10] = 0;
									udh[11] = 0;
								} else {
									
									/************ UDH Header description in case of  Long SMS
									 * 0500030A0201
									   0500030A0202

									   	05 is the length of data field in the UDH
										00 is the IE identifier for concatenated messages
										03 is the length of data in IE
										0A is the reference number for series of message fragments, it is a random number uniquely identifying the set of fragments for the given long message.
										02 is the number of fragments in the given message
										01 for first and 02 for second fragment (last byte) is the sequence number of current fragment amongst all fragments for a given long message.
										Thus 6 characters of the short_message field can be used for UDH when sending a long message and remaining bytes can be used for data.
									 * 
									 */
									
									udh[0] = (byte) udhBean.getUdhMessageHeaderLength(); // same for any message
									udh[1] = 0; // same for any msg
									udh[2] = 3; // same for any msg
									udh[3] = Byte.valueOf(Integer.toString(msgRefNum));
									udh[4] = (byte) udhBean.getTotalmessageParts(); // total number of parts
									udh[5] = (byte) msgPartNum;
								}
								msgPartLength = udhBean.getUdhHeaderLength() + msgBytes.length;
								logger.debug("msgPartLength["+msgPartLength+"] udhBean.getUdhHeaderLength()["+udhBean.getUdhHeaderLength()+"] msgBytes.length["+msgBytes.length+"] udh.length["+udh.length+"]  msgBytes.length["+ msgBytes.length+"]");
								byte[] msgPart = new byte[msgPartLength];
								System.arraycopy(udh, 0, msgPart, 0, udh.length);
								System.arraycopy(msgBytes, 0, msgPart, udh.length, msgBytes.length);
								newMsgBean.setMsgByteAray(msgPart);
								String messageText = new String(msgPart);
								optCount = optCount + udhBean.getUdhMessageLength();
								logger.info(String.format("dest: %s, org: %s, msg text"
										+ "%s, length: %s",bean.getDestinationNumber(), 
										bean.getOriginationNumber(),messageText, optCount));
								msgPartNum++;
								newMsgBean.setServiceType(bean.getServiceType());
								dataAl.add(newMsgBean);
							}

						} else {
							logger.error("  #" + bean.getDestinationNumber()
									+ "#   This is just for handling the case if comming in this condition then its an issue ");
						}

					}

				}

			}

		}

		catch (Exception ex) {
			errorLogger.error("ErrorCode [" + Global.errCode + "-00033] ResponseId [" + bean.getResponseId()
					+ "] RequestId [" + bean.getRequestId() + "] MSISDN [" + bean.getDestinationNumber()
					+ "[Exception when process on message for sending to Submit Sm] ERROR [" + ex.getMessage() + "]");
			ex.printStackTrace();
		} finally {
			if (newMsgBean != null)
				newMsgBean = null;
		}

	}
	


	public int getRefCount() {
		if (refCount == 126) {
			refCount = 1;
		} else {
			refCount++;
		}

		return refCount;

	}
	public int handleSubmitSmCharacterEncoding(String messageText) {
		int retVal = Global.SUBMIT_SM_UTF_8;
		Matcher matcher = null;
		try {

			if (Global.submitSmCharEncoding.equalsIgnoreCase("utf-8")) {
				retVal = Global.SUBMIT_SM_UTF_8;
			} else if (Global.submitSmCharEncoding.equalsIgnoreCase("UCS2")
					|| (Global.submitSmCharEncoding.equalsIgnoreCase("utf-16BE"))) {
				retVal = Global.SUBMIT_SM_UCS_2;
			} else if (Global.submitSmCharEncoding.equalsIgnoreCase("default")
					|| Global.submitSmCharEncoding.equalsIgnoreCase("7-bit")) {
				retVal = Global.SUBMIT_SM_DEFAULT;
			}
			else{
				
				matcher = Global.defaultSmsEncodingPattern.matcher(messageText);
				
				if(matcher.matches())
				{
					//if message text matches the given pattern for 7bit encoding scheme.
					logger.debug("messageText ["+messageText+"] pattern matcher result ["+matcher.matches()+"] setting encodingtype [ALPHA_DEFAULT] ["+Global.SUBMIT_SM_DEFAULT+"]]");
					retVal = Global.SUBMIT_SM_DEFAULT;
				}
				else
				{
					//if message text does not match the given pattern for 7bit encoding scheme.
					logger.debug("messageText ["+messageText+"] pattern matcher result ["+matcher.matches()+"] setting encodingtype [ALPHA_UCS2] ["+Global.SUBMIT_SM_UCS_2+"]]");
					retVal = Global.SUBMIT_SM_UCS_2;
				}
				
			}

		} catch (Exception ex) {
			errorLogger.error("ErrorCode [" + Global.errCode
					+ "-00035] [Exception when checking for submit sm character encoding] ERROR [" + ex.getMessage()
					+ "]");
			ex.printStackTrace();
		}
		return retVal;

	}
	
	
	public void handleUDHMessage(String message, int destPort, UDHDataBean udhBean, int msgType,Alphabet encodinngScheme) {
		int udhMessageHeaderLength = 0;
		int udhHeaderLength = 0;
		//int udhMessageLength = Global.messageLength;
		int udhMessageLength = -1;
		boolean applyUDH = false;
		boolean isConcatBitAdded = false;
		int totalMessageParts = 0;
		boolean isdestPort = false;

		try {

			int ogMsgLength = message.length();// refers to the original message
												// length .......
			
			if(encodinngScheme==Alphabet.ALPHA_UCS2)
			{
				udhMessageLength = Global.ucs2MsgMaxLength;
			}
			else if(encodinngScheme==Alphabet.ALPHA_8_BIT)
			{
				udhMessageLength = Global.utf8MsgMaxLength;
			}
			else if(encodinngScheme==Alphabet.ALPHA_DEFAULT)
			{
				udhMessageLength = Global.defaultMsgMaxLength;
			}
			
			logger.debug("insede handleUDHMessage() message["+message+"] destPort["+destPort+"] udhBean["+
			udhBean+"], msgType ["+msgType+"],encodinngScheme["+encodinngScheme+"] udhMessageLength["+udhMessageLength+"]");

			if (destPort > 0) {
				udhMessageHeaderLength = 6;// adding 6 for destination port bit
											// in udh header.......
				udhHeaderLength = udhMessageHeaderLength + 1;// adding message
																// length
																// parameter in
																// udh
																// header.......
				applyUDH = true;
				isdestPort = true;
			}

			int encodngSchmVal = Global.SUBMIT_SM_UTF_8;
			if (msgType != 5) {
				encodngSchmVal = handleSubmitSmCharacterEncoding(message);
			}
			// if encodngSchmVal is 1 = UTF-8 || 2 = UCS2 || 3 = 7bit or default
			if (encodngSchmVal == Global.SUBMIT_SM_UTF_8) {

				logger.info("inside condition where encoding scheme [UTF-8] "+ogMsgLength);
				if (ogMsgLength > (udhMessageLength - udhHeaderLength)) {
					applyUDH = true;
					// this is the condition where we need to add the
					// concatination bit to the pdu header
					// originalmessage length is greater than the pdu
					logger.info(
							"inside condition when ogmesglnth > udhmsglegth [UTF-8] and concatination bit in udhheader ");
					if (isdestPort) {
						udhMessageHeaderLength = udhMessageHeaderLength + 5;// this
																			// is
																			// udh
																			// header
																			// message
																			// length
						udhHeaderLength = udhMessageHeaderLength + 1;// this is
																		// udh
																		// header
																		// length
					} else {
						udhMessageHeaderLength = 5;// this is udh header
													// standard length value for
													// concatinate bit
						udhHeaderLength = udhMessageHeaderLength + 1;// this is
																		// udh
																		// header
																		// length
					}
					udhMessageLength = udhMessageLength - udhHeaderLength;
					isConcatBitAdded = true;
					logger.debug("############################### udh "+isConcatBitAdded);
				}

			} else if (encodngSchmVal == Global.SUBMIT_SM_UCS_2) {

				
				//if (udhMessageLength % 2 != 0) {
				//	udhMessageLength = udhMessageLength + 1;
				//}
				//udhMessageLength = udhMessageLength / 2;
				// udhMessageLength=70;
				int checkparam = (((udhHeaderLength % 2) == 0) && ((udhHeaderLength / 2) == 0) ? (udhHeaderLength / 2)
						: (((udhHeaderLength + 1) / 2)));

				logger.debug("inside condition where encoding scheme [UCS2 || UTF-16BE] udhMessageLength["+udhMessageLength+
						"] udhHeaderLength["+udhHeaderLength+"] checkparam["+checkparam+"]");

				if (ogMsgLength > (udhMessageLength - checkparam)) {
					applyUDH = true;
					// this is the condition where we need to add the
					// concatination bit to the pdu header
					// originalmessage length is greater than the pdu
					// udhHeaderLength=(((udhHeaderLength%2)==0)&&((udhHeaderLength/2)==0)?(udhHeaderLength/2):(((udhHeaderLength+1)/2)));
					logger.debug(
							"inside condition when ogmesglnth > udhmsglegth [UCS2 || UTF-16BE] and concatination bit in udhheader ");
					// NEED TO MONITOR WHILE TESTING THIS .....ENCODING
					// SCHEME.....................
					// udhMessageLength=udhMessageLength-3;
					if (isdestPort) {

						// udhMessageHeaderLength=5;
						// udhHeaderLength=udhHeaderLengt;
						udhMessageHeaderLength = udhMessageHeaderLength + 5;
						udhHeaderLength = udhMessageHeaderLength + 1;
					} else {
						udhMessageHeaderLength = 5;// this is udh header
													// standard length value for
													// concatinate bit
						udhHeaderLength = udhMessageHeaderLength + 1;// this is
																		// udh
																		// header
																		// length

					}
					int udhDefaultHeaderLength = (((udhHeaderLength % 2) == 0) && ((udhHeaderLength / 2) == 0)
							? (udhHeaderLength / 2) : (((udhHeaderLength + 1) / 2)));
					
					udhMessageLength = udhMessageLength - udhDefaultHeaderLength;
					
					isConcatBitAdded = true;
					logger.debug("inside handleUDHMessage() udhHeaderLength["+udhHeaderLength+"] udhDefaultHeaderLength["+udhDefaultHeaderLength+"] udhMessageLength["+
					udhMessageLength+"]");
				}

			} else {
				//udhMessageLength = Global.messageLength;
				logger.debug("inside condition where encoding scheme [DEFAULT || 7-BIT] ");
				if (ogMsgLength > (udhMessageLength - udhHeaderLength)) {
					applyUDH = true;
					// this is the condition where we need to add the
					// concatination bit to the pdu header
					// originalmessage length is greater than the pdu
					logger.debug(
							"inside condition when ogmesglnth > udhmsglegth [ DEFAULT || 7-BIT ] and concatination bit in udhheader ");
					// udhMessageLength=udhMessageLength-6;
					if (isdestPort) {
						udhMessageHeaderLength = udhMessageHeaderLength + 5;
						udhHeaderLength = udhMessageHeaderLength + 1;
					}

					else {
						udhMessageHeaderLength = 5;
						udhHeaderLength = udhMessageHeaderLength + 1;
					}
					
					
					// changes required for utf7HeaderAdjustment length
					int utf7HeaderAdjustment = (((udhHeaderLength % 7) == 0)
							&& ((udhHeaderLength / 7) == 0) ? (udhHeaderLength / 7)
									: ((udhHeaderLength / 7) + 1));
					if(utf7HeaderAdjustment>=2)
					{
						udhMessageLength = udhMessageLength-1;
					}
					
					udhMessageLength = udhMessageLength - udhHeaderLength;
					
					isConcatBitAdded = true;
				}

			}

			totalMessageParts = (((ogMsgLength % udhMessageLength) == 0) || ((ogMsgLength / udhMessageLength) == 0)
					? (ogMsgLength / udhMessageLength) : ((ogMsgLength / udhMessageLength) + 1));
			
			logger.debug("inside handleUDHMessage() totalMessageParts["+totalMessageParts+" ogMsgLength["+ogMsgLength+"] udhMessageLength["+udhMessageLength+"]]");
			udhBean.setApplyUDH(applyUDH);
			udhBean.setUdhMessageHeaderLength(udhMessageHeaderLength);
			udhBean.setUdhHeaderLength(udhHeaderLength);
			udhBean.setUdhMessageLength(udhMessageLength);
			udhBean.setTotalmessageParts(totalMessageParts);
			udhBean.setConcatBitAdded(isConcatBitAdded);
			// logger.info("Total Message parts peresent is
			// ["+totalMessageParts+"]");

		} catch (Exception ex) {
			errorLogger.error("ErrorCode [" + Global.errCode + "-00034] message [" + message + "] Message Type ["
					+ msgType + "] [Exception when Handle UDH for sending message] ERROR [" + ex.getMessage() + "]");
			ex.printStackTrace();
		}

	}
}
