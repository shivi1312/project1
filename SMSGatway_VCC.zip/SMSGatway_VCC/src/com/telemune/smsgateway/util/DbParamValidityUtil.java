package com.telemune.smsgateway.util;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.telemune.smsgateway.bean.GmatMessageBean;

public class DbParamValidityUtil {
	private final static Logger logger = Logger.getLogger("DbParamValidityUtil");
	@SuppressWarnings("unused")
	private final static Logger errorLogger = Logger.getLogger("errorLogger");
	public boolean validateDbParams(GmatMessageBean gmatBean){
		boolean valid = false;
		try{
			valid = this.validateCommonDbParams(gmatBean);
			if(valid){
				logger.debug(String.format("dest: %s, org: %s validate succssfully"
						+ " all db params ",gmatBean.getDestinationNumber(),
						gmatBean.getOriginationNumber()));
			} else {
				logger.debug(String.format("dest: %s, org: %s validate unsuccessfully"
						+ " db params ",gmatBean.getDestinationNumber(),
						gmatBean.getOriginationNumber()));
			}
		}catch(Exception e){
			valid = false;
			logger.error(String.format("dest: %s, org: %s error while validate "
					+ "db params:: %s",gmatBean.getDestinationNumber(),
					gmatBean.getOriginationNumber(),e.getMessage()));
		}
		return valid;
	}
	public boolean validateCommonDbParams(GmatMessageBean gmatBean){
		boolean valid = false;
		String destBlank = "no";
		String orgBlank = "no";
		String textBlank = "no";
		String msgType = "no";
		String msg = "dest: %s is blank:: %s, org: %s is blank:: %s, "
				+ "text: %s is blank:: %s, message type: %s is more "
				+ "than 0:: %s, request id:: %s, response id:: %s, all params valid: %s";
		try{
			if (!StringUtils.isBlank(gmatBean.getMessageText())
					&& !StringUtils.isBlank(gmatBean.getDestinationNumber())
					&& !StringUtils.isBlank(gmatBean.getOriginationNumber())
					&& gmatBean.getMessageType() > 0) {
				if(gmatBean.getResponseId() > 0 || gmatBean.getRequestId() > 0){
					valid = true;
				} else {
					valid = false;
				}
			} else {
				if(StringUtils.isBlank(gmatBean.getDestinationNumber())){
					destBlank = "yes";
				}
				if(StringUtils.isBlank(gmatBean.getOriginationNumber())){
					orgBlank = "yes";
				}
				if(StringUtils.isBlank(gmatBean.getMessageText())){
					textBlank = "yes";
				}
				if(gmatBean.getMessageType() <= 0){
					msgType = "yes";
				}
			}
			/*msg = String.format(msg, gmatBean.getDestinationNumber(), destBlank, 
					gmatBean.getOriginationNumber(), orgBlank, gmatBean.getMessageText(),
					textBlank, gmatBean.getMessageType(), msgType, gmatBean.getResponseId(), 
					gmatBean.getResponseId(), valid);*/ 
			msg = String.format(msg, gmatBean.getDestinationNumber(), destBlank, 
					gmatBean.getOriginationNumber(), orgBlank, gmatBean.getMessageText(),
					textBlank, gmatBean.getMessageType(), msgType, gmatBean.getRequestId(), // modified by Avishkar
					gmatBean.getResponseId(), valid); 
			if(valid)
				logger.info(msg);
			else
				logger.error(msg);
		}catch(Exception e){
			logger.error(String.format("dest: %s, org: %s error while validate "
					+ "db params:: %s",gmatBean.getDestinationNumber(),
					gmatBean.getOriginationNumber(),e.getMessage()));
		}
		return valid;
	}
}
