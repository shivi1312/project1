package com.telemune.smsgateway.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import org.apache.log4j.Logger;

import com.telemune.smsgateway.Global;
import com.telemune.smsgateway.bean.ConnectionDetailBean;

/**
* The SmscUtil manage smsc connection via load balancing
* Update connection is any connection break
*
* @author  Vivek Kumar
* @version 1.0
* @since   2016-08-03 
*/
public class SmscUtil {
	final static Logger logger = Logger.getLogger("SmscUtil");
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	public static List<Object> keyAl = null;
	private static Queue<ConnectionDetailBean[]> smppSession = new LinkedList<ConnectionDetailBean[]>();
	private static Map<Integer,Queue<ConnectionDetailBean>> connDetail = new HashMap<Integer, Queue<ConnectionDetailBean>>();
	private static Map<Integer,Integer> tpsMap = new HashMap<Integer,Integer>();
	private static int totalTps = 0;
	
	static {
		putSmppSessionInQueue();
	}
	
	public static void putSmppSessionInQueue(){
		try {
			totalTps = 0;
			smppSession.clear();
			connDetail.clear();
			keyAl = new ArrayList<Object>(Global.smppSessionDetail.keySet());
			logger.info("No of smpp session: " + keyAl.size());
			for (int j = 0; j < keyAl.size(); j++) {
				ConnectionDetailBean connCount[] = (ConnectionDetailBean[])Global.smppSessionDetail.get(keyAl.get(j));
				logger.info("Smpp session: " + connCount.hashCode()+" No of conn: "+connCount.length);
				queuedConnection(connCount);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void queuedConnection(ConnectionDetailBean connCount[]){
		Queue<ConnectionDetailBean> queue = new LinkedList<ConnectionDetailBean>();
		int smscid = -100;
		int tps = 0;
		for (int i = 0; i < connCount.length; i++) {
			if (connCount != null && connCount[i].getSession().getSessionState().isTransmittable()
					&& connCount[i].getSession().getSessionState().isBound()){
				tps = tps + connCount[i].getWindowSize();
				totalTps = totalTps + connCount[i].getWindowSize();
				smscid = connCount[i].getSmscId();
				queue.add(connCount[i]);
			}
		}
		logger.info(String.format("Smpp: smscid: %s, no of connection: %s, "
				+ "tps allocated: %s", smscid, connCount.length, tps));
		if(smscid != -100){
			tpsMap.put(smscid, tps);
			smppSession.add(connCount);
			connDetail.put(smscid, queue);
		}
	}
	public ConnectionDetailBean[] getSmppSession(){
		ConnectionDetailBean[] connBean = smppSession.poll();
		if(connBean != null)
			smppSession.add(connBean);
		return connBean;
	}
	public ConnectionDetailBean[] getSmppSessionBySmscId(int smscid){
		ConnectionDetailBean connCount[] = (ConnectionDetailBean[])Global.smppSessionDetail.get(smscid);
		if(connCount == null){
			logger.error("session is missing for smscid: "+smscid);
			return this.getSmppSession();
		}
		logger.debug("session is hitting for smscid: "+smscid+" hascode: "+connCount.hashCode()); // modified by Avishkar from error to debug
		return connCount;
	}
	public Queue<ConnectionDetailBean> getQueue(int smscid){
		return connDetail.get(smscid);
	}
	
	public ConnectionDetailBean getConnectionBean(Queue<ConnectionDetailBean> queue){
		ConnectionDetailBean connBean = null;
		try {
			logger.debug("Queue size: "+queue.size());
			connBean = queue.poll();
			if(connBean != null && connBean.getSession().getSessionState().isTransmittable()
					&& connBean.getSession().getSessionState().isBound())
				queue.add(connBean);
		} catch(Exception e){
			logger.error("Error while getting conn from queue: "+e.getMessage());
		}
		return connBean;
	}
	public ConnectionDetailBean checkAndReturnConnection(ConnectionDetailBean connBean){
		if (connBean != null && connBean.getSession().getSessionState().isTransmittable()
				&& connBean.getSession().getSessionState().isBound()){
			logger.debug("Transmittable:: smscid: " + connBean.getSmscId()+
					" window size: "+connBean.getWindowSize()+" smsc systemid: "+
					connBean.getSmscSystemId()+" conn: "+connBean.hashCode());
			return connBean;
		}
		return null;
	}
	public int getSmscId(ConnectionDetailBean[] smppConnection){
		int smscid = -100;
		try{
			if(smppConnection != null){
				for(ConnectionDetailBean conDet: smppConnection){
					return conDet.getSmscId();
				}
			}
		}catch(Exception e){
			
		}
		return smscid;
	}
	public ConnectionDetailBean getConnection(int smscid, boolean useOtherConn){
		try {
			ConnectionDetailBean[] smppConnection = null;
			if(Global.loadBalance == 0 && smscid != 0){
				smppConnection = this.getSmppSessionBySmscId(smscid);
			}else{
				if(useOtherConn)
					smppConnection = this.getSmppSessionBySmscId(smscid);
				else
					smppConnection = this.getSmppSession();
			}
			Queue<ConnectionDetailBean> queue = this.getQueue(this.getSmscId(smppConnection));
			logger.debug("Smpp queue size: "+ queue.size());
			ConnectionDetailBean connBean = this.getConnectionBean(queue);
			logger.info(String.format("Conn detail:: smscid: %s, window size: %s", 
					connBean.getSmscId(), connBean.getWindowSize()));
			return this.checkAndReturnConnection(connBean);
		}catch(Exception e){
			logger.error("Error: while getting conn: "+e.getMessage());
		}
		return null;
	}
	public static int getTps(int smscid){
		int tps = 1;
		try {
			if(tpsMap.containsKey(smscid))
				tps = tpsMap.get(smscid);
		}catch(Exception e){
			logger.error("Error while getting tps: "+e.getMessage());
			tps = 1;
		}
		return tps;
	}	
	public static int getTotalTps(){
		return totalTps;
	}
	
	
	
	
	
}
