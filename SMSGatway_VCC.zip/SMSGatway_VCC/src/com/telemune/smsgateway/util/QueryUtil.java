package com.telemune.smsgateway.util;

import org.apache.log4j.Logger;

import com.telemune.smsgateway.Global;

/**
 * The SmscUtil manage smsc connection and handle tps as per connection Simply
 * submit message to smsc
 *
 * @author Vivek Kumar
 * @version 1.0
 * @since 2016-08-03
 */
public class QueryUtil {
	private final static Logger logger = Logger.getLogger("QueryUtil");
	@SuppressWarnings("unused")
	private final static Logger errorLogger = Logger.getLogger("errorLogger");
	/**
	 * This method is used to create query
	 * @return String This returns database query.
	 */
	public static String getQuery() {
		String query = "select RESPONSE_ID,REQUEST_ID,ORIGINATING_NUMBER,"
				+ "DESTINATION_NUMBER,MESSAGE_TEXT,MESSAGE_TYPE,STATUS,DESTINATION_PORT";
		if (Global.loadBalance == 0) {
			query = query + ",SMSC_ID ";
			logger.debug("Load balancing enable:: NO");
		}
		if (Global.enableValidityPeriod == 1) {
			query = query + ",VALIDITY_PERIOD";
			logger.debug("Validation period enable:: YES");
		}
		if (Global.enableProtocolId == 1) {
			query = query + ",PROTOCOL_IDENTIFIER";
			logger.debug("Protocol identifier enable:: YES");
		}
		if (Global.enableCampaignId == 1) {
			query = query + ",CAMPAIGN_ID";
			logger.debug("Campaign id enable:: YES");
		}
		if (Global.opCode == 1) {
			query = query + ",USSD_OPCODE";
		}
		if(Global.optEnable==1)
		{
			query=query+ ",OPTIONAL_PARAM";
		}
		if(Global.isRetryEnable==1)
		{
			query=query+ ",RETRY_COUNT";
		}
		if(Global.enableServiceType.equalsIgnoreCase("1")) {
			query=query+ ",SERVICE_TYPE";
		}
		
		
		if (Global.dbConfigParamEnable == 1) {
			//For MySql....................
			query = query + " from " + Global.gmatMessageStoreTable
					+ " where STATUS='R' and SUBMIT_TIME<=now() order by RESPONSE_ID limit "+Global.dbFetchSize;
			logger.debug("Current database type:: MySql");
		} else {
			// FOR ORACLE...................
			query = query + " from " + Global.gmatMessageStoreTable
					+ " where STATUS='R' and SUBMIT_TIME<=sysdate and rownum<="+Global.dbFetchSize+" order by RESPONSE_ID";
			logger.debug("Current database type:: Oracle");
		}
		logger.debug("Query for gmat_message_store: "+query);
		return query;
	}
}
