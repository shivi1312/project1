package com.telemune.smsgateway;

import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.regex.Pattern;

import com.telemune.smsgateway.bean.ConnectionDetailBean;
import com.telemune.smsgateway.bean.FailedMessageBean;
import com.telemune.smsgateway.bean.FileWriterBean;
import com.telemune.smsgateway.bean.GmatMessageBean;
import com.telemune.smsgateway.bean.HandleDelvryRespBean;
import com.telemune.smsgateway.bean.LongMessageInfoBean;
import com.telemune.smsgateway.bean.SMSProcessBean;
import com.telemune.smsgateway.handler.SubmitMsgProducer;
import com.telemune.smsgateway.service.GmatService;

//import org.jsmpp.session.SMPPSession;

import FileBaseLogging.FileLogWriter;

/**
 * THIS CLASS IS FOR DEFINE THE VARIALE STATICALLY AND GLOBALLY
 *
 * @author ekansh
 * @version: R1_0_0_0
 */
public class Global {
	public static Hashtable config_params = null;
	public static Hashtable smscParamDetail = null;
	public static ConnPool conPool = null;
	// public static SMPPSession smpSession=null;
	public static ArrayBlockingQueue<GmatMessageBean> gmatMessageQue = new ArrayBlockingQueue<GmatMessageBean>(
			100000);
	public static ArrayBlockingQueue<SMSProcessBean> rcvSMSQueue = new ArrayBlockingQueue<SMSProcessBean>(
			100000);
	// public static int messageWindowSize=5;
	public static Hashtable<Integer, ConnectionDetailBean[]> smppSessionDetail = new Hashtable<Integer, ConnectionDetailBean[]>(
			10);
	// public static Hashtable<Integer,ConnectionDetailBean> smppSessionDetail=
	// new Hashtable<Integer,ConnectionDetailBean>();

	//public static int messageLength = -1;
	public static int lastSMSCId = 0;
	public static int urlHitTimeout = -1;
	public static int readurlHitTimeout = -1;
	public static String appUrl = "na";
	public static String deliverSmEncoding = "utf-8";
	public static int isDeliverSmEncodingEnable = 0;
	public static FileLogWriter flwGateway[] = new FileLogWriter[4];
	public static ArrayBlockingQueue<FileWriterBean> fileWriteQueue = new ArrayBlockingQueue<FileWriterBean>(
			100000);
	public static int isDeliveryReportEnable = 0;

	// these are new parameter yet to configure in mainclass from
	// peoperty.........

	public static String submitSmCharEncoding = "utf-8";
	public static Hashtable<Integer, HandleDelvryRespBean> delverSmRespHndleMap = new Hashtable<Integer, HandleDelvryRespBean>(
			100);
	public static int dbConfigParamEnable = 0;

	// This is for handle the long Messsage Cach
	public static HashMap<String, LongMessageInfoBean> longMessageCacheMap = new HashMap<String, LongMessageInfoBean>(
			100);

	// static value of submit sm encoding scheme........
	public static final int SUBMIT_SM_UTF_8 = 1;
	public static final int SUBMIT_SM_UCS_2 = 2;
	public static final int SUBMIT_SM_DEFAULT = 3;
	public static int submitSmUDH = 1;
	public static Hashtable<ConnectionDetailBean, Integer> smssendHT = new Hashtable<ConnectionDetailBean, Integer>();

	// / THESE PARAMETERS ARE TO HANDLE THE LOG FILE REQUEST TYPE AND ALSO
	// LOGFILE WRITER OBJECT INDEX

	public static final int SUBMIT_SM_REQUEST = 0;
	public static final int SUBMIT_SM_RESPONSE = 1;
	public static final int DELIVERY_RECIEPT = 2;
	public static final int ERROR_FILE = 3;

	public static int WriteLgsInDB_Enable = 1; // if value is 0 then wrting the
												// files, if value=1 writng the
												// logs in database , if value=2
												// then write logs in both in
												// database and in file.......
	public static int UDH = -1;
	public static int messagepayload = -1;
	public static int optparameter = -1;

	// THESE PARAMETERS ARE NEW FOR HANDLING THE DELIVER RECIEPT URL HIT
	public static int enableDelRecptUrlHit = 0;
	public static String delRcptUrl = "na";

	// These are the parameters for the HEART BEAT CHECK

	public static int heartBeatPort = 6666;
	public static String heartBeatIp = "10.168.1.108";
	public static int enableHeartBeat = 0;
	public static int isActive = 0;
	public static boolean isActivateServer = true;
	// Parameters for Campaign Id CHECK
	public static int enableCampaignId = 0;
	// Parameters for Protocol Id CHECK
	public static int enableProtocolId = 0;
	// Parameters for Validity Period Id CHECK
	public static int enableValidityPeriod = 0;
	// public static int noOfConnection=1;
	public static int totalMsgSend = 0;
	public static String gmatSmscConfigTable = "NA";
	public static String gmatMessageStoreTable = "NA";
	public static int loadBalance = 1;
	public static int SubmitDestinationNPI = 0;
	public static int addressrange = 1;
	public static int SubmitOriginationNPI = 0;// origination NPI
	public static int SubmitOriginationTON = 0;// origination TON
	public static String localHost = "10.168.1.145";
	public static int localPort = 0;
	public static int orgNumLength = 0;
	public static int opCode = 1;
	public static int threadMonitorDelayTime = 300;
	public static int countryCodeEnable = 0;
	public static int lastSMSCId1 = -1;
	public static String countryCode = "257";
	public static String errCode = "SMSGw";
	public static int optEnable=-1;
	public static int enableSmsgInsertion=-1;
	public static int gmatReaderCounter=-1;
	
	//added by avinash on 16 August 2017
	public static int dcsEnable=-1;
	public static String dcsEncoding=null;

	//added on 4/10/2017
	//public static Pattern defaultSmsEncodingPattern = Pattern.compile("[A-Za-z0-9 @$¥èéùìòÇØøÅå_ΦΓΛΩΠΨΣΘΞÆæßÉ!“#¤%&‘'()*+-.,:;<=>?¡ÄÖÑÜ§¿äöñüà1|/]+");
	public static Pattern defaultSmsEncodingPattern = Pattern.compile("[A-Za-z0-9\\s@$¥èéùìòÇØøÅå_ΦΓΛΩΠΨΣΘΞÆæßÉ!“#¤%&‘'\"\'()*+-.,:;<=>?¡ÄÖÑÜ§¿äöñüà1|/]+");
	//public static Pattern defaultSmsEncodingPattern = Pattern.compile("[A-Za-z0-9 @Δ¿£_!$Φ\"¥Γ#èΛ¤éΩ%ùΠ&ìΨ'òΣ(ÇΘ)Ξ*:Ø+;ÄäøÆ,<Ööæ-=ÑñÅß.>ÜüåÉ/?§à|/]+");
	public static int defaultMsgMaxLength = -1;
	public static int ucs2MsgMaxLength = -1;
	public static int utf8MsgMaxLength = -1;
	
	//added on 13/02/2018
	public static int generateSeqNumberFromDB=-1;
	
	
	// added by avinash 16/03/1018
	public static int isRetryEnable=0;
	public static int numberOfRetry=0;
	public static int retryAfterMinutes=-1;
	public static String retryForStatusCode=null;
	public static String excludeOriginNumber=null;
	public static int cacheloadTime = 30;
	public static int memoryCleanTime = 1800; // added by Avishkar
	public static byte priority=0;
	public static String serviceType="";
	
	public static ArrayBlockingQueue<FailedMessageBean> failedMessageQueue = new ArrayBlockingQueue<FailedMessageBean>(1000000);
	public static int responseMessageType=1;
	
	public static GmatService gmatService=new GmatService();
	public static SubmitMsgProducer submitMessageProducer=new SubmitMsgProducer();
	
	public static String serviceTypeDeliver;
	public static String responseMessage="Test";
	public static String[] rbtList=null;
	public static String urlAppender="";
	public static String relaseServiceType="RELC";
	public static String enableServiceType="-1";
	public static String dbFetchSize="100";
	
}
