package com.telemune.smsgateway;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.annotation.XmlElementDecl.GLOBAL;

import org.apache.http.message.BasicNameValuePair;
import org.apache.log4j.Logger;
import org.jsmpp.PDUException;
import org.jsmpp.bean.AlertNotification;
import org.jsmpp.bean.Alphabet;
import org.jsmpp.bean.DataSm;
import org.jsmpp.bean.DeliverSm;
import org.jsmpp.bean.DeliveryReceipt;
import org.jsmpp.bean.MessageType;
import org.jsmpp.bean.OptionalParameter;
import org.jsmpp.bean.OptionalParameter.Byte;
import org.jsmpp.bean.OptionalParameter.COctetString;
import org.jsmpp.bean.OptionalParameter.Int;
import org.jsmpp.bean.OptionalParameter.OctetString;
import org.jsmpp.bean.OptionalParameter.Short;
import org.jsmpp.bean.OptionalParameter.Tag;
import org.jsmpp.extra.ProcessRequestException;
import org.jsmpp.session.DataSmResult;
import org.jsmpp.session.MessageReceiverListener;
import org.jsmpp.session.Session;
import org.jsmpp.util.InvalidDeliveryReceiptException;
import org.jsmpp.util.MessageId;

import com.telemune.smsgateway.bean.FileWriterBean;
import com.telemune.smsgateway.bean.LongMessageInfoBean;
import com.telemune.smsgateway.bean.SMSProcessBean;

/**
 * THIS CLASS IS FOR HANDLE THE SMPPDELIVER_SM MEANS THIS CLASS HANDLE THE ALL
 * THE MESSAGE RECIEVED FROM THE SMSC
 * 
 * @author ekansh
 * @version :- R1_0_0_0
 */

public class SMPPDeliverSm implements MessageReceiverListener {

	Logger logger = Logger.getLogger(SMPPDeliverSm.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	/**
	 * THIS FUNCTION IS FOR HANLDE THE DELIVER SM WHEN ANY DELIVER SM IS
	 * RECIEVED THIS WILL HANDLE ALL THIS FUNCTION IS ALSO AHNDLE THE DELIVERY
	 * RECIEPT THIS FUNCTION ALSO HANDLE THE NORMAL DELIVER SM THIS FUNCTION IS
	 * ALSO HANDLE THE DELIVER SM CONATIN THE UDH IN MESSAGE ARRAY
	 */
	private int smscId;

	public SMPPDeliverSm(int smscId) {
		this.smscId = smscId;
	}

	public void onAcceptDeliverSm(DeliverSm deliverSm) throws ProcessRequestException {
		boolean skipProcessIfDeliverSmNull = false; 
		try{
			logger.info("#### deliverSm  dataCoding["+deliverSm.getDataCoding()+"] message ["+deliverSm.getShortMessage()+
				"] message utf-8 ["+new String(deliverSm.getShortMessage(), "UTF-8")+"] destination address ["+ deliverSm.getDestAddress() +"] source address ["+deliverSm.getSourceAddr()+"]");
		}
		catch(Exception e){
			if(e.toString().contains("NullPointerException")) { // this if block is added by Avishkar
				skipProcessIfDeliverSmNull=true;
				logger.warn("####>>> skipProcessIfDeliverSmNull["+skipProcessIfDeliverSmNull+"] therefore skipping the process <<<###");
			}
			else {
				logger.error("Exception found onAcceptDeliverSm "+e);
			}
//			logger.error("Exception found onAcceptDeliverSm ",e); // modified by Avishkar
//			logger.error("Exception found onAcceptDeliverSm ["+e.getMessage()+"]"); // commented by Avishkar
			//e.printStackTrace();
		}
		
		if (!skipProcessIfDeliverSmNull) { // this condition is added by Avishkar
			
			logger.info("MessageType.SMSC_DEL_RECEIPT --> "+deliverSm.getEsmClass()+ " deliverSm.getCommandIdAsHex() "+deliverSm.getCommandIdAsHex());
			boolean flag_=false;
			
			/*if(!deliverSm.getCommandIdAsHex().equalsIgnoreCase("80000004")) {
				flag_=true;
			}*/
			
			FileWriterBean fileBean = null;
			if (deliverSm.getCommandIdAsHex().equalsIgnoreCase("00000005") && MessageType.SMSC_DEL_RECEIPT.containedIn(deliverSm.getEsmClass())) {
				// this message is delivery receipt
				try {
					DeliveryReceipt delReceipt =null;
					if(MessageType.SMSC_DEL_RECEIPT.containedIn(deliverSm.getEsmClass())) {
						
						delReceipt = deliverSm.getShortMessageAsDeliveryReceipt();
					
					}
					//added by avinash on 21/03/2018 to check f message id is null
					String messageId = null;
					// lets cover the id to hex string format
					try{
						messageId = delReceipt.getId();
					}
					catch(Exception e){
						messageId = "0";
					}
					String messageStatus = delReceipt==null ? "NA" : delReceipt.getFinalStatus().name();
	
					/*logger.info("  Getting the delRecipt.getId when MessageType.SMSC_DEL_RECEIPT.....[" + delReceipt.getId()
							+ "]Getting messageid [" + delReceipt.getId() + "] SMSC_DEL_RECEIPT [ "
							+ deliverSm.getCommandIdAsHex() +" ] status [" + delReceipt.getFinalStatus()
							+ "]  sequence no [" + deliverSm.getSequenceNumber() + "] destination address ["
							+ deliverSm.getDestAddress() + "]");
					 */
					
					
					logger.info("  Getting the delRecipt.getId when MessageType.SMSC_DEL_RECEIPT.....[" + messageId
					+ "]Getting messageid [" + messageId + "] SMSC_DEL_RECEIPT [ "
					+ deliverSm.getCommandIdAsHex() +" ] status [" + messageStatus
					+ "]  sequence no [" + deliverSm.getSequenceNumber() + "] destination address ["
					+ deliverSm.getDestAddress() + "]");
	
					
					
					/*
					 * you can update the status of your submitted message on the
					 * database based on messageId
					 */
	
					//logger.debug("Getting the DEL_RECP_ERR CODE FROM SMSC [  " + delReceipt==null ? "NA" : delReceipt.getError() + "   ]");
	
					
					fileBean = new FileWriterBean();
					OptionalParameter op[] = null;
	
					OctetString oc = null;
					Byte b1 = null;
	
					try {
						if (deliverSm.getOptionalParametes() != null) {
	
							op = deliverSm.getOptionalParametes();
	
							logger.info("This is the size of optional parameter array [" + op.length + "]");
	
							for (int i = 0; i < op.length; i++) {
	
								if (Tag.codeVal(Tag.RECEIPTED_MESSAGE_ID) == op[i].tag) {
									logger.info("Inside getting messege id");
									oc = (OctetString) op[i];
									logger.info("getting the value as octate string " + oc.getValueAsString());
									messageId = oc.getValueAsString();
	
								}
								
							}
						}
	
					} catch (Exception exe) {
						errorLogger.error("ErrorCode ["+Global.errCode+"-00082] [Exception When Getting Optional Parameter from SMSC] ERROR ["+exe.getMessage()+"]");
						exe.printStackTrace();
			
					} finally {
						if (b1 != null)
							b1 = null;
						if (oc != null)
							oc = null;
						if (op != null)
							op = null;
	
					}
	
					if (Global.rcvSMSQueue.size() == 100000) {
						logger.info("Receiving queue is full logs are write into error file" + Global.rcvSMSQueue.size());
						fileBean.setRequestType(Global.ERROR_FILE);
						fileBean.setSmscId(messageId);
						fileBean.setStatus("queuefull");
						fileBean.setOriginNum(deliverSm.getDestAddress());
						fileBean.setDestNum(deliverSm.getSourceAddr());
						fileBean.setTimeStamp(System.currentTimeMillis());
						Global.fileWriteQueue.put(fileBean);
	
					}
					
					fileBean.setRequestType(Global.DELIVERY_RECIEPT);
					fileBean.setSmscId(messageId);
					fileBean.setStatus(messageStatus);
					fileBean.setOriginNum(deliverSm.getDestAddress());
					fileBean.setDestNum(deliverSm.getSourceAddr());
					fileBean.setTimeStamp(System.currentTimeMillis());
					Global.fileWriteQueue.put(fileBean);
	
					if (Global.enableDelRecptUrlHit >= 1) {
						SMSProcessBean rcvBean = new SMSProcessBean();
						rcvBean.setRequestType(Global.DELIVERY_RECIEPT);
						rcvBean.setMsisdn(deliverSm.getSourceAddr());// MSISDN
						rcvBean.setShortCode(deliverSm.getDestAddress());// SHORTCODE
						rcvBean.setStatus(messageStatus);
						rcvBean.setSmscId(messageId);
						rcvBean.setServiceType(deliverSm.getServiceType());
						rcvBean.setDelRecptHitUrl(true);
						//rcvBean.setMessage(new String(deliverSm.getShortMessage(), "UTF-8"));
						rcvBean.setKeyword(new String(deliverSm.getShortMessage(), "UTF-8"));
						/*if(rcvBean.getServiceType().equalsIgnoreCase(Global.serviceTypeDeliver)) {
							rcvBean.setKeyword(new String(deliverSm.getShortMessage(), "UTF-8"));
						}*/
						Global.rcvSMSQueue.put(rcvBean);
					}
	
					logger.info(
							"Receiving delivery receipt for message '" + messageId + " ' from " + deliverSm.getSourceAddr()
									+ " to " + deliverSm.getDestAddress() );
	
				} catch (InvalidDeliveryReceiptException e) {
					errorLogger.error("ErrorCode ["+Global.errCode+"-00083] [InvalidDeliveryReceiptException Failed at the time of getting delivery Receipt from SMSC] ERROR ["+e.getMessage()+"]");
					e.printStackTrace();
					
	
				} catch (Exception exe) {
					errorLogger.error("ErrorCode ["+Global.errCode+"-00084] [Exception When getting delivery receipt and write delivery receipt log into log file] ERROR ["+exe.getMessage()+"]");
					exe.printStackTrace();
				} finally {
					if (fileBean != null)
						fileBean = null;
				}
	
			} else if (MessageType.ESME_DEL_ACK.containedIn(deliverSm.getEsmClass())) {
				System.out.println("Getting Acknowledgeemnt of .....MessageType.ESME_DEL_ACK " + MessageType.ESME_DEL_ACK);
	
			} else if (MessageType.ESME_MAN_ACK.containedIn(deliverSm.getEsmClass())) {
				System.out.println("Getting Acknowledgeemnt of .....MessageType.ESME_MAN_ACK " + MessageType.ESME_MAN_ACK);
			} else if (MessageType.SME_DEL_ACK.containedIn(deliverSm.getEsmClass())) {
				System.out.println("Getting Acknowledgeemnt of .....MessageType.SME_DEL_ACK " + MessageType.SME_DEL_ACK);
			} else if (MessageType.SME_MAN_ACK.containedIn(deliverSm.getEsmClass())) {
				System.out.println("Getting Acknowledgeemnt of .....MessageType.SME_MAN_ACK " + MessageType.SME_MAN_ACK);
			} else if (deliverSm.getCommandIdAsHex().equalsIgnoreCase("80000004")) {
	
				String messageId=null;
				try{
					 messageId=deliverSm.getMessageId();
				}
				catch(Exception e)
				{
					 messageId="0";
				}
				
				logger.debug("****************************************************************************************");
				logger.info("Getting the submit _sm response in deliver sm.......where sequence nuner is  [ "
						+ deliverSm.getSequenceNumber() + " ] and message id [" + messageId + "]");
				logger.debug("------------------------------------------------------------------------------------");
				logger.debug("****************************************************************************************");
				fileBean = new FileWriterBean();
				try {
	
					fileBean.setRequestType(Global.SUBMIT_SM_RESPONSE);
					fileBean.setSmscId(messageId);
					fileBean.setSequenceNUm(deliverSm.getSequenceNumber());
					fileBean.setOriginNum(deliverSm.getSourceAddr());
					fileBean.setDestNum(deliverSm.getDestAddress());
	
					Global.fileWriteQueue.put(fileBean);
				} catch (Exception exe) {
					errorLogger.error("ErrorCode ["+Global.errCode+"-00085] [Exception When write SubmitSm Response log into log file] ERROR ["+exe.getMessage()+"]");
					exe.printStackTrace();
					
				}
	
			} else {
				// this message is regular short message
				/*
				 * you can save the incoming message to database.
				 */
	
				LongMessageInfoBean lngBean = null;
				SMSProcessBean rcvBean = null;
				try {
					ArrayList<BasicNameValuePair> optList = new ArrayList<BasicNameValuePair>();
					if (deliverSm.isUdhi()) {
						byte[] messageArr = deliverSm.getShortMessage();
						logger.debug("This is the original message array length [" + messageArr.length + "]");
						int udhLen = messageArr[0];
						byte[] udh = new byte[udhLen];
						System.arraycopy(messageArr, 1, udh, 0, udhLen);
						byte[] neMsgArry = new byte[messageArr.length - (udhLen + 1)];
						
						logger.info(
								"This is the original message array length [" + messageArr.length + "] and length of udh ["
										+ udh.length + "] and newmessage array [" + neMsgArry.length + "]");
						System.arraycopy(messageArr, udhLen + 1, neMsgArry, 0, neMsgArry.length);
	
						boolean isdestPortEnable = false;
						boolean isLongmsgEnable = false;
						int msgRef = -1;
						int totalPart = 0;
						int partNum = -1;
						int destPort = -1;
						String key = "";
						//String tempMesgText = new String(neMsgArry);
						String mesgText = "";
						
						
						/// added on 12/09/2017 for converting ucs2 to utf8
						//String mesgText = new String(neMsgArry);
						
						if(deliverSm.getDataCoding()==Alphabet.ALPHA_UCS2.value())
						{
							
							String tempMesgText = new String(deliverSm.getShortMessage(),"UTF-16BE");
							logger.debug("#### Converting start UCS2 to utf-8 ucsMessage ["+tempMesgText+"]");
							//byte[] utf16Bytes=tempMesgText.getBytes("UTF-16BE");
							
							//String temp = new String(utf16Bytes,"UTF-16BE");
							
							byte[] utf8Bytes = tempMesgText.getBytes("UTF-8");
							mesgText = new String(utf8Bytes,"UTF-8");
							logger.debug("#### Converting end UCS2 to utf-8 ucsMessage ["+tempMesgText+"] utf-8 message ["+mesgText+
									"] final msg utf-8 Encode ["+URLEncoder.encode(mesgText, "UTF-8")+
									"] final msg decode ["+URLDecoder.decode(URLEncoder.encode(mesgText, "UTF-8"))+
									"] final msg utf-16be Encode ["+URLEncoder.encode(mesgText, "UTF-16BE")+
									"] final msg utf-16be url decode ["+URLDecoder.decode(URLEncoder.encode(mesgText, "UTF-16BE"))+
									"] tempMesgText utf-8 Encode ["+URLEncoder.encode(tempMesgText, "UTF-8")+
									"] tempMesgText decode ["+URLDecoder.decode(URLEncoder.encode(tempMesgText, "UTF-8"))+
									"] tempMesgText utf-16be Encode ["+URLEncoder.encode(tempMesgText, "UTF-16BE")+
									"] tempMesgText utf-16be url decode ["+URLDecoder.decode(URLEncoder.encode(tempMesgText, "UTF-16BE"))+
									
									"]");
						}
						else
						{
							
							mesgText = new String(deliverSm.getShortMessage(),"UTF-8");
							logger.debug("#### utf-8 message ["+mesgText+
									"] utf-8 Encode ["+URLEncoder.encode(mesgText, "UTF-8")+
									"] utf-8 url decode ["+URLDecoder.decode(URLEncoder.encode(mesgText, "UTF-8"))+
									"] utf-16be Encode ["+URLEncoder.encode(mesgText, "UTF-16BE")+
									"] utf-16be url decode ["+URLDecoder.decode(URLEncoder.encode(mesgText, "UTF-16BE"))+
									"]");
						}
						
						//end added on 12/09/2017 for converting ucs2 to utf8
						logger.debug("#### deliverSm message text ["+mesgText+"] deliverSm["+deliverSm+"]");	
	
						// added by Avishkar for temporary purpose start 
						for (int i = 0; i < udh.length; i++) {
							logger.info("udh["+i+"] value["+udh[i]+"]");
							i = i + 1;
						}
						// added by Avishkar end
						
						for (int i = 0; i < udh.length; i++) {
	
							if (udh[i] == 0 || udh[i] == 8) {
								isLongmsgEnable = true;
	
								if (udh[i] == 8) {

									logger.info("Inside udh[8], value of udh[i + 2] [" + udh[i + 2] + "] and value of udh[i + 3] [" + udh[i + 3]+"]"); // added by Avishkar 21-12-2020
									msgRef = Integer.parseInt(udh[i + 2] + "" + udh[i + 3]);
									i = i + 3;
	
								} else { // else part modified by Rajesh Sir
									logger.info("Inside udh[0], value of udh[i + 2] [" + udh[i + 2] + "]");  // added by Avishkar 21-12-2020
									msgRef = udh[i + 2];
									i = i + 2;
								}
								totalPart = udh[i];
								logger.info("Inside udh[0] or udh[8], value of udh[i + 1] [" + udh[i + 1] + "]");  // added by Avishkar 21-12-2020
								partNum = udh[i + 1];
								i = i + 2;
							}	
							/*	} else {
									msgRef = udh[i = i + 2];
								}
								totalPart = udh[i = i + 1];
								partNum = udh[i = i + 1];
							}*/
	
							if (udh[i] == 5) {
								isdestPortEnable = true;
								logger.info("Inside udh[5], value of udh[i + 2] [" + udh[i + 2] + "] and value of udh[i + 3] [" + udh[i + 3]+"]");  // added by Avishkar 21-12-2020
								destPort = Integer.parseInt(udh[i + 2] + "" + udh[i + 3]);
								i = i + 5;
							}
	
						}
	
						logger.info("This is the parameter isdestPortEnable[" + isdestPortEnable + "] isLongmsgEnable ["
								+ isLongmsgEnable + "] msgRef[" + msgRef + "] totalPart [" + totalPart + "] partNum ["
								+ partNum + "] destPort [" + destPort + "]");
	
						if (isLongmsgEnable) {
							key = deliverSm.getSourceAddr() + "_" + msgRef;
							if (Global.longMessageCacheMap.containsKey(key)) {
								lngBean = Global.longMessageCacheMap.get(key);
	
								if (isdestPortEnable) {
									lngBean.setDestPort(destPort);
								}
	
								lngBean.setMessageText(partNum, mesgText);
								lngBean.setTimeStamp(System.currentTimeMillis());
								if (lngBean.isAllMsgRecv()) {
	
									String messageTxt = processLongMessage(lngBean.getMessageText(), key);
									rcvBean = new SMSProcessBean();
									/*
									 * rcvBean=null; logger.info(
									 * "#####################TESTING OF DELVIER SM FOR MEMEORY CONSUMPTION"
									 * );
									 */
									rcvBean.setMessage(messageTxt);// MESSAGE TEXT
									rcvBean.setMsisdn(deliverSm.getSourceAddr());// MSISDN
									rcvBean.setShortCode(deliverSm.getDestAddress());// SHORTCODE
									rcvBean.setKeyword(messageTxt.substring(0, messageTxt.indexOf(" ")));// KEYWORD
									rcvBean.setDestPort(lngBean.getDestPort());
									rcvBean.setOptList(optList);
									Global.rcvSMSQueue.put(rcvBean);
	
								} else {
									Global.longMessageCacheMap.put(key, lngBean);
								}
	
							} else {
	
								lngBean = new LongMessageInfoBean(totalPart);
								if (isdestPortEnable) {
									lngBean.setDestPort(destPort);
								}
								lngBean.setMsgRefNUm(msgRef);
								lngBean.setTimeStamp(System.currentTimeMillis());
								lngBean.setPartNum(partNum);
								lngBean.setMessageText(partNum, mesgText);
	
								if (lngBean.isAllMsgRecv()) {
									String messageTxt = processLongMessage(lngBean.getMessageText(), key);
									rcvBean = new SMSProcessBean();
									/*
									 * rcvBean=null; logger.info(
									 * "#####################TESTING OF DELVIER SM FOR MEMEORY CONSUMPTION"
									 * );
									 */
									rcvBean.setMessage(messageTxt);// MESSAGE TEXT
									rcvBean.setMsisdn(deliverSm.getSourceAddr());// MSISDN
									rcvBean.setShortCode(deliverSm.getDestAddress());// SHORTCODE
									rcvBean.setKeyword(messageTxt.substring(0, messageTxt.indexOf(" ")));// KEYWORD
									rcvBean.setDestPort(lngBean.getDestPort());
									rcvBean.setOptList(optList);
									Global.rcvSMSQueue.put(rcvBean);
	
								} else {
									Global.longMessageCacheMap.put(key, lngBean);
								}
	
							}
	
						} else if (isdestPortEnable) {
							rcvBean = new SMSProcessBean();
	
							rcvBean.setMessage(mesgText);// MESSAGE TEXT
							rcvBean.setMsisdn(deliverSm.getSourceAddr());// MSISDN
							rcvBean.setShortCode(deliverSm.getDestAddress());// SHORTCODE
							rcvBean.setKeyword(mesgText.substring(0, mesgText.indexOf(" ")));// KEYWORD
							rcvBean.setDestPort(destPort);
							rcvBean.setOptList(optList);
							Global.rcvSMSQueue.put(rcvBean);
	
						} else {
							rcvBean = new SMSProcessBean();
	
							rcvBean.setMessage(mesgText);// MESSAGE TEXT
							rcvBean.setMsisdn(deliverSm.getSourceAddr());// MSISDN
							rcvBean.setShortCode(deliverSm.getDestAddress());// SHORTCODE
							rcvBean.setKeyword(mesgText.substring(0, mesgText.indexOf(" ")));// KEYWORD
							rcvBean.setDestPort(destPort);
							rcvBean.setOptList(optList);
							Global.rcvSMSQueue.put(rcvBean);
	
						}
					} else {
						//ArrayList<BasicNameValuePair> optList = new ArrayList<BasicNameValuePair>();
						String tagName = null;
						String tagValue=null;
						if (deliverSm.getOptionalParametes() != null) {
							OptionalParameter op1[] = null;
	
							op1 = deliverSm.getOptionalParametes();
	
							logger.info("This is the size of optional parameter array [" + op1.length + "] ]");
	
							for (int i = 0; i < op1.length; i++) {
								
								List<Tag> tagList = Arrays.asList((Tag.values()));
								List<java.lang.Short> tagShortVal = new ArrayList<java.lang.Short>();
								for (int j = 0; j < tagList.size(); j++) {
	
									tagShortVal.add(Tag.codeVal(tagList.get(j)));
								}
								
								
								
								
								String classType = op1[i].getClass().toString();
								logger.debug("Classtype is [" + classType + "]");
								String classNAME = classType.substring(classType.lastIndexOf("$") + 1);
								logger.info("Class type is" + classNAME);
									tagName = "O_"+classNAME+"_"+op1[i].tag + "";
									logger.info("Tagname is [" + tagName + "]");
									
									if(!tagShortVal.contains(op1[i].tag))
									{
										logger.info("Tagname is [" + tagName + "] Tag value is ["+((COctetString)op1[i]).getValue()+"]");
									if(((COctetString)op1[i]).getValue()==null)
									{
										logger.info("inside condition when optioalparameter ["+tagName+"] value is null");
										tagValue="NA";
									}
									else
									{
									byte[] b=new byte[((COctetString)op1[i]).getValue().length];
									b=((COctetString)op1[i]).getValue();
									//for(int k=0;k<b.length;k++)								
									 tagValue = DatatypeConverter.printHexBinary(b);
									}
									 logger.info("Hex value is ["+tagValue+"]");
									}
								/*
								if (tagShortVal.contains(op1[i].tag)) {
									tagName = Tag.valueOf(op1[i].tag) + "";
									logger.info("Tagname is [" + tagName + "]");
								} else {
									tagName = "O_"+op1[i].tag + "";
									logger.info("Tagname is [" + tagName + "] Tag value is ["+((COctetString)op1[i]).getValue()+"]");
									if(((COctetString)op1[i]).getValue()==null)
									{
										//logger.info("inside condition when optioalparameter ["+tagName+"] value is null");
										tagValue="NA";
									}
									else
									{
									byte[] b=new byte[((COctetString)op1[i]).getValue().length];
									b=((COctetString)op1[i]).getValue();
									//for(int k=0;k<b.length;k++)								
									 tagValue = DatatypeConverter.printHexBinary(b);
									}
									 logger.info("Hex value is ["+tagValue+"]");
									}
								
								String classType = op1[i].getClass().toString();
								logger.debug("Classtype is [" + classType + "]");
								String classNAME = classType.substring(classType.lastIndexOf("$") + 1);
								logger.info("Class type is" + classNAME);
	*/
								if (classNAME.equalsIgnoreCase("Byte")) 
									{
										logger.debug("Inside byte");
										tagValue=((Byte) op1[i]).getValue() + "";
									}
								else if (classNAME.equalsIgnoreCase("Int")) 	
									{
										logger.debug("Inside int ");
										tagValue=((Int) op1[i]).getValue() + "";
									} 
								else if (classNAME.equalsIgnoreCase("COctetString")) 
									{
										logger.debug("Inside COctetString");
										if(!tagName.startsWith("O_"))
										{
											if(((COctetString) op1[i]).getValue()==null)
												tagValue="NA";
											else
												tagValue=((COctetString) op1[i]).getValueAsString();
										}
									}
								else if (classNAME.equalsIgnoreCase("OctetString")) 	
									{
										logger.debug("Inside OctetString");
										if(((OctetString) op1[i]).getValue()==null)
											tagValue="NA";
										else
										tagValue=((OctetString) op1[i]).getValueAsString();
									} 
								else if (classNAME.equalsIgnoreCase("Short")) 
									{
										logger.debug("Inside short");
										tagValue=((Short) op1[i]).getValue() + "";
									}
								
								optList.add(new BasicNameValuePair(tagName,tagValue));
	
							}
							logger.info("optional parameter is" + optList);
						}
	
						String messageTxt = "";
						if (deliverSm.getShortMessage() != null) {
							/// added on 12/09/2017 for converting ucs2 to utf8
							//messageTxt = new String(deliverSm.getShortMessage());
							//String tempMesgText = new String(deliverSm.getShortMessage());
							if(deliverSm.getDataCoding()==Alphabet.ALPHA_UCS2.value())
							{
								//logger.debug("#### Converting start UCS2 to utf-8 ucsMessage ["+tempMesgText+"]");
								//byte[] utf8 = tempMesgText.getBytes("UTF-8");
								//messageTxt = new String(utf8, "UTF-8");
								//logger.debug("#### Converting end UCS2 to utf-8 ucsMessage ["+tempMesgText+"] utf-8 message ["+messageTxt+"]");
								String tempMesgText = new String(deliverSm.getShortMessage(),"UTF-16BE");
								logger.debug("#### Converting start UCS2 to utf-8 ucsMessage ["+tempMesgText+"]");
								//byte[] utf16Bytes=tempMesgText.getBytes("UTF-16BE");
								
								//String temp = new String(utf16Bytes,"UTF-16BE");
								
								byte[] utf8Bytes = tempMesgText.getBytes("UTF-8");
								messageTxt = new String(utf8Bytes,"UTF-8");
								logger.debug("#### Converting end UCS2 to utf-8 ucsMessage ["+tempMesgText+"] utf-8 message ["+messageTxt+
										"] final msg utf-8 Encode ["+URLEncoder.encode(messageTxt, "UTF-8")+
										"] final msg decode ["+URLDecoder.decode(URLEncoder.encode(messageTxt, "UTF-8"))+
										"] final msg utf-16be Encode ["+URLEncoder.encode(messageTxt, "UTF-16BE")+
										"] final msg utf-16be url decode ["+URLDecoder.decode(URLEncoder.encode(messageTxt, "UTF-16BE"))+
										"] tempMesgText utf-8 Encode ["+URLEncoder.encode(tempMesgText, "UTF-8")+
										"] tempMesgText decode ["+URLDecoder.decode(URLEncoder.encode(tempMesgText, "UTF-8"))+
										"] tempMesgText utf-16be Encode ["+URLEncoder.encode(tempMesgText, "UTF-16BE")+
										"] tempMesgText utf-16be url decode ["+URLDecoder.decode(URLEncoder.encode(tempMesgText, "UTF-16BE"))+
										
										"]");
							}
							else
							{
								messageTxt = new String(deliverSm.getShortMessage(),"UTF-8");
								logger.debug("#### utf-8 message ["+messageTxt+
										"] utf-8 Encode ["+URLEncoder.encode(messageTxt, "UTF-8")+
										"] utf-8 url decode ["+URLDecoder.decode(URLEncoder.encode(messageTxt, "UTF-8"))+
										"] utf-16be Encode ["+URLEncoder.encode(messageTxt, "UTF-16BE")+
										"] utf-16be url decode ["+URLDecoder.decode(URLEncoder.encode(messageTxt, "UTF-16BE"))+
										"]");
							}
							
							//end added on 12/09/2017 for converting ucs2 to utf8
						}
						
						logger.debug("#### deliverSm message text ["+messageTxt+"] deliverSm["+deliverSm.toString()+"]");	
						
						rcvBean = new SMSProcessBean();
	
						rcvBean.setMessage(messageTxt);// MESSAGE TEXT
						rcvBean.setMsisdn(deliverSm.getSourceAddr());// MSISDN
						rcvBean.setShortCode(deliverSm.getDestAddress());// SHORTCODE
						if (messageTxt.trim().contains(" "))
							rcvBean.setKeyword(messageTxt.substring(0, messageTxt.indexOf(" ")));// KEYWORD
						else
							rcvBean.setKeyword(messageTxt.trim());// KEYWORD
						rcvBean.setDestPort(-1);
						rcvBean.setSMSCID(smscId);
						rcvBean.setOptList(optList);
						Global.rcvSMSQueue.put(rcvBean);
	
					}
	
				}
				catch (Exception e) {
					errorLogger.error("ErrorCode ["+Global.errCode+"-00086] [Exception When get deliver sm Hit from SMSC] ERROR ["+e.getMessage()+"]");
					e.printStackTrace();
					
				} finally {
					if (lngBean != null)
						lngBean = null;
					if (rcvBean != null)
						rcvBean = null;
				}
	
			}
		}
		else { // added by Avishkar
			logger.warn("####>>> Problem in getting DeliverSm, therefore no more further processing done <<<###");
		}
	}

	public DataSmResult onAcceptDataSm(DataSm dataSm, Session source) throws ProcessRequestException {

		logger.debug(
				"---------------------------------------------------------------------------------------------------------------------------------------------");
		logger.debug(
				"---------------------------------------------------------------------------------------------------------------------------------------------");
		logger.info("Inisde function onAcceptDataSm......................");

		return null;
	};

	public void onAcceptAlertNotification(AlertNotification alertNotification) {
	}

	/**
	 * This is for test onAcceptsubmit sm()........
	 * 
	 * 
	 */

	public void onAcceptsubmitSmResp(MessageId messageId, int sequenceNumber) throws PDUException, IOException {

		try {

			logger.debug(
					"---------------------------------------------------------------------------------------------------------------------------------------------");
			logger.debug(
					"---------------------------------------------------------------------------------------------------------------------------------------------");
			logger.info("Inside function onAcceptsubmitSmResp()..............where MESSAGEID [" + messageId.getValue()
					+ "]  sequence number [" + sequenceNumber + "].........");
			logger.debug(
					"---------------------------------------------------------------------------------------------------------------------------------------------");
			logger.debug(
					"---------------------------------------------------------------------------------------------------------------------------------------------");

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+Global.errCode+"-00087] [Exception When get deliver sm Receipt from SMSC] ERROR ["+e.getMessage()+"]");
			e.printStackTrace();
			logger.error("Exception inside function .............");
		}

	}

	/**
	 * THIS FUNCTION IS FOR GETTING THE MESSAGE STATE FROM OPTIONAL PARAMETER
	 * 
	 * @param param
	 *            :- AN INTEREGER PARAM RECIEVED FROM DEL RECIEPT IN OPTIONAL
	 *            PARAMETER
	 * @return A STRING WHICH REPRESENT THE MESSAGE STATE
	 */
	public String getOPMessageState(int param) {
		String retval = "failure";
		try {

			switch (param) {

			case 1:
				retval = "ENROUTE";
				break;
			case 2:
				retval = "DELIVERED";
				break;
			case 3:
				retval = "EXPIRED";
				break;
			case 4:
				retval = "DELETED";
				break;
			case 5:
				retval = "UNDELIVERABLE";
				break;
			case 6:
				retval = "ACCEPTED";
				break;
			case 7:
				retval = "UNKNOWN";
				break;
			case 8:
				retval = "REJECTED";
				break;
			default:
				retval = "failure";
				break;
			}

		} catch (Exception exe) {
			errorLogger.error("ErrorCode ["+Global.errCode+"-00088] [Exception When getting delivered message state] ERROR ["+exe.getMessage()+"]");
			exe.printStackTrace();
		

		}

		return retval;

	}

	/**
	 * THIS FUNCTIO IS FOR PROCESSING THE LONG MESSAGE INTO THE SINGLE MESSAGE
	 * 
	 * @param txtMsg
	 *            :- REFERS TO MESSAGE TEXT ARRAY
	 * @param key
	 *            :- REFERS TO THE LONG MESSAGE KEY
	 * @return :- A SINGLE MESSAGE STRING
	 */

	public String processLongMessage(String[] txtMsg, String key) {

		logger.info("Inside function processLongMessage() where length of String array is [" + txtMsg.length
				+ "] with key [" + key + "]");

		String str = "";
		try {
			str = Arrays.asList(txtMsg).toString();

			str = str.substring(1, str.length() - 1).replaceAll(",", "");
			logger.debug("this is the message string [" + str + "]");

		} catch (Exception exe) {
			errorLogger.error("ErrorCode ["+Global.errCode+"-00089] [Exception When processing long message received in delivery receipt] ERROR ["+exe.getMessage()+"]");
			exe.printStackTrace();
			
		}

		return str.trim();

	}

}
