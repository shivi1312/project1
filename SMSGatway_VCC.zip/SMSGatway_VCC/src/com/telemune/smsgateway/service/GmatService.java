package com.telemune.smsgateway.service;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.smsgateway.Global;
import com.telemune.smsgateway.bean.ConnectionDetailBean;
import com.telemune.smsgateway.bean.GmatMessageBean;
import com.telemune.smsgateway.bean.OptionalParamBean;
import com.telemune.smsgateway.bean.SMSProcessBean;
import com.telemune.smsgateway.model.MsgList;
import com.telemune.smsgateway.model.MsgSubList;
import com.telemune.smsgateway.util.DbParamValidityUtil;
import com.telemune.smsgateway.util.MessageUtil;
import com.telemune.smsgateway.util.QueryUtil;

/**
 * The SmscUtil manage smsc connection and handle tps as per connection Simply
 * submit message to smsc
 *
 * @author Vivek Kumar
 * @version 1.0
 * @since 2016-08-03
 */
public class GmatService {
	final static Logger logger = Logger.getLogger("GmatService");
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	private DbParamValidityUtil dbUtil = new DbParamValidityUtil();
	private MessageUtil msgUtil = new MessageUtil();
	private Gson gson = new Gson();
	
	
	@SuppressWarnings("unused")
	public MsgList getMessages() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MsgList msgList = null;
		List<GmatMessageBean> list = new ArrayList<GmatMessageBean>();
		int rows = 0;
		try {
			conn = Global.conPool.getConnection();
			logger.info("Query: "+QueryUtil.getQuery());
			pstmt = conn
					.prepareStatement(QueryUtil.getQuery(),
							ResultSet.TYPE_SCROLL_SENSITIVE,
							ResultSet.CONCUR_UPDATABLE);
			rs = pstmt.executeQuery();
			msgList = this.storeDateInList(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (rs != null)
					rs.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {

			}
		}
		return msgList;
	}
	public MsgList storeDateInList(ResultSet rs){
		List<GmatMessageBean> mainList = new ArrayList<GmatMessageBean>();
		List<GmatMessageBean> invalidList = new ArrayList<GmatMessageBean>();
		List<MsgSubList> msgSubList = new ArrayList<MsgSubList>();
		MsgList msgList = new MsgList();
		ConnectionDetailBean conBean = null;
		OptionalParamBean optBean=null;
		String optionalParam;
		int campId = 0, protocolIdentifier = 0,
				validityTime = 0, opCode = 0, smsc_id = -1,count=0,retryCount=0;
		
		try{
			while(rs.next()){
				if (Global.loadBalance == 0)
					smsc_id = Integer.parseInt(rs.getString("SMSC_ID"));
				if (Global.enableCampaignId == 1)
					campId = rs.getInt("CAMPAIGN_ID");
				if (Global.enableProtocolId == 1)
					protocolIdentifier = rs.getInt("PROTOCOL_IDENTIFIER");
				if (Global.enableValidityPeriod == 1)
					validityTime = rs.getInt("VALIDITY_PERIOD");
				if (Global.opCode == 1)
					opCode = rs.getInt("USSD_OPCODE");
				if (Global.isRetryEnable == 1)
					retryCount = rs.getInt("RETRY_COUNT");
				
				
				
				
				
				if(Global.optEnable==1)
				{
					
					optBean=new OptionalParamBean();
					optionalParam = rs.getString("OPTIONAL_PARAM");
					logger.info("inside opt enable option"+optionalParam);
					 optBean= gson.fromJson(optionalParam, OptionalParamBean.class);
					 logger.info("optional param is"+optBean.toString());
				}
				
				//modified on 4/10/2017 to check message text character encoding
				/*GmatMessageBean messageBean = new GmatMessageBean(rs.getInt("RESPONSE_ID"), rs.getInt("REQUEST_ID"),
						rs.getString("ORIGINATING_NUMBER"), rs.getString("DESTINATION_NUMBER"),
						new String(rs.getString("MESSAGE_TEXT").getBytes("UTF-8")), rs.getInt("MESSAGE_TYPE"),
						rs.getString("STATUS"), validityTime, rs.getInt("DESTINATION_PORT"),
						msgUtil.getSubmitSmCharacterEncoding(), protocolIdentifier, campId, smsc_id, opCode,optBean, conBean);
				*/
				
				GmatMessageBean messageBean = new GmatMessageBean(rs.getInt("RESPONSE_ID"), rs.getInt("REQUEST_ID"),
						rs.getString("ORIGINATING_NUMBER"), rs.getString("DESTINATION_NUMBER"),
						new String(rs.getString("MESSAGE_TEXT").getBytes("UTF-8")), rs.getInt("MESSAGE_TYPE"),
						rs.getString("STATUS"), validityTime, rs.getInt("DESTINATION_PORT"),
						msgUtil.getSubmitSmCharacterEncoding(rs.getString("MESSAGE_TEXT")), protocolIdentifier, campId, smsc_id, opCode,optBean, conBean,retryCount);
				
				if(Global.enableServiceType.equalsIgnoreCase("1")) {
					messageBean.setServiceType(rs.getString("SERVICE_TYPE")!=null ? rs.getString("SERVICE_TYPE").trim() :"") ;
				}
				//messageBean.setServiceType(serviceType);
				
				
				this.doMsgFilter(messageBean, mainList, invalidList, msgSubList);
				count++;
				if(count>=Global.gmatReaderCounter)
				{
					break;
				}
				
			}
			msgList.setMainList(mainList);
			msgList.setMsgSubList(msgSubList);
			if(invalidList.size() > 0){
				logger.error("Total invalid entry found in database"
						+ "(gmat_message_store):: "+invalidList.size());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return msgList;
	}
	
	
	public MsgList deliverMsgList(SMSProcessBean bean) throws UnsupportedEncodingException {
		int campId = 0, protocolIdentifier = 0,validityTime = 0, opCode = 0, smsc_id = -1,count=0,retryCount=0;
		OptionalParamBean optBean=new OptionalParamBean();
		if(Global.optEnable==1)
		{
			 optBean= new Gson().fromJson("", OptionalParamBean.class);
			 logger.info("optional param is"+optBean.toString());
		}
		MessageUtil msgUtil = new MessageUtil();
		
		GmatMessageBean messageBean = new GmatMessageBean(1, 1,
				bean.getShortCode(), bean.getMsisdn(),
				new String(Global.responseMessage.getBytes("UTF-8")),Global.responseMessageType,
				"R", validityTime, 0, msgUtil.getSubmitSmCharacterEncoding(Global.responseMessage), protocolIdentifier, campId, smsc_id, opCode,optBean, null,retryCount);
		
		messageBean.setServiceType(bean.getServiceType());
		List<GmatMessageBean> mainList = new ArrayList<GmatMessageBean>();
		List<GmatMessageBean> invalidList = new ArrayList<GmatMessageBean>();
		List<MsgSubList> msgSubList = new ArrayList<MsgSubList>();
		MsgList msgList = new MsgList();
		
		this.doMsgFilter(messageBean, mainList, invalidList, msgSubList);
		msgList.setMainList(mainList);
		msgList.setMsgSubList(msgSubList);
		return msgList;
	}

	public void doMsgFilter(GmatMessageBean messageBean, 
			List<GmatMessageBean> mainList, 
			List<GmatMessageBean> invalidList, 
			List<MsgSubList> msgSubList){
		try {
			if(dbUtil.validateDbParams(messageBean)){
				if (messageBean.getMessageType() == 5) {
					logger.debug(String.format("dest: %s, org: %s send vcard to user",
							messageBean.getDestinationNumber(),messageBean.getOriginationNumber()));
					msgUtil.handleVcardStringReplace(messageBean);
				} else if (messageBean.getMessageType() == 4) {
					logger.debug(String.format("dest: %s, org: %s send wap push message",
							messageBean.getDestinationNumber(),messageBean.getOriginationNumber()));
				}
				List<GmatMessageBean> chunkList = new ArrayList<GmatMessageBean>();
				msgUtil.proccessMessageForSMSC(messageBean, chunkList);
				logger.info("bean size: "+chunkList.size());
				if(chunkList.size() > 1){
					msgSubList.add(new MsgSubList(chunkList,chunkList.size(), messageBean));
				} else if(chunkList.size()==1){
					for(GmatMessageBean bean: chunkList){
						mainList.add(bean);
					}
				}
			} else {
				invalidList.add(messageBean);
			}
		} catch(Exception e){
			logger.error(String.format("dest: %s, org: %s error while msg filer: %s",
					messageBean.getDestinationNumber(),
					messageBean.getOriginationNumber(), e.getMessage()));
		}
	}
	
	public void insertIntoSMSG(List<GmatMessageBean> dataList)
	{
		
		Connection conn = null;
		PreparedStatement pstmtOne = null;	
		String query=null;
		if(Global.dbConfigParamEnable==1)
		{
			query="insert into SMSG_SMS_RESPONSE_MDR(SUBMIT_TIME,RESPONSE_ID,REQUEST_ID,ORG_NUM,DEST_NUM,MSG_TXT,CAMP_ID,RETRY_COUNT,IS_RETRIED) values(now(),?,?,?,?,?,?,?,'N')";
		}
		else
		{
			query="insert into SMSG_SMS_RESPONSE_MDR(SUBMIT_TIME,RESPONSE_ID,REQUEST_ID,ORG_NUM,DEST_NUM,MSG_TXT,CAMP_ID,RETRY_COUNT,IS_RETRIED) values(sysdate,?,?,?,?,?,?,?,'N')";
	
		}
		try {
			logger.info("query: "+query+" size of delete list: "+dataList.size());
			conn = Global.conPool.getConnection();
			pstmtOne = conn.prepareStatement(query);
			
			for(GmatMessageBean bean: dataList){
				logger.info("Response id: "+bean.getResponseId()+"Destination Number:"+bean.getDestinationNumber());
				/*if(bean.getResponseId()>0){
					pstmtOne.setInt(1, bean.getResponseId());
					
				} else if(bean.getRequestId()>0){
					pstmtOne.setInt(2, bean.getRequestId());
				}*/
				pstmtOne.setInt(1, bean.getResponseId());
				pstmtOne.setInt(2, bean.getRequestId());
				pstmtOne.setString(3, bean.getOriginationNumber());
				pstmtOne.setString(4,bean.getDestinationNumber());
				pstmtOne.setString(5,bean.getMessageText());
				pstmtOne.setInt(6,bean.getCampaignId());
				pstmtOne.setInt(7,bean.getRetryCount());
				
				pstmtOne.addBatch();
					
				}
			int[] batchOne = pstmtOne.executeBatch();
			logger.info("Total row inserted based of response id: "+batchOne.length);
			}
		catch(Exception e){
			logger.error("Exception when insert data into SMSG_SMS_RESPONSE_MDR table"+e.getMessage());
		}finally{
			try{
				if(pstmtOne != null)
					pstmtOne.close();
				if(conn != null)
					conn.close();
			}catch(Exception e){
				
			}
		}
			 
      }
	
	
	public void deleteGmatStore(List<GmatMessageBean> delList, MsgList msgList){
		Connection conn = null;
		PreparedStatement pstmtOne = null;
		PreparedStatement pstmtTwo = null;
		String queryOne = "delete from " + Global.gmatMessageStoreTable + " where RESPONSE_ID=? and STATUS=?";
		String queryTwo = "delete from " + Global.gmatMessageStoreTable + " where REQUEST_ID=? and STATUS=?";
		try {
			logger.info("query: "+queryOne);
			conn = Global.conPool.getConnection();
			pstmtOne = conn.prepareStatement(queryOne);
			pstmtTwo = conn.prepareStatement(queryTwo);
			if(Global.enableSmsgInsertion==1)
			{
				insertIntoSMSG(delList);
			}
			
			for(GmatMessageBean bean: delList){
				logger.info("Response id: "+bean.getResponseId());
				if(bean.getResponseId()>0){
					pstmtOne.setInt(1, bean.getResponseId());
					pstmtOne.setString(2, bean.getStatus());
					pstmtOne.addBatch();
				} else if(bean.getRequestId()>0){
					pstmtTwo.setInt(1, bean.getRequestId());
					pstmtTwo.setString(2, bean.getStatus());
					pstmtTwo.addBatch();
				}
			}
			int[] batchOne = pstmtOne.executeBatch();
			int[] batchTwo = pstmtTwo.executeBatch();
			logger.info("Total row delete based of request id: "+batchTwo.length);
			logger.info("Total row delete based of response id: "+batchOne.length);
			logger.info("Total row deleted: "+(batchTwo.length+batchOne.length)+
					" out of: "+(msgList.getMainList().size()+msgList.getMsgSubList().size()));
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(pstmtOne != null)
					pstmtOne.close();
				if(pstmtTwo != null)
					pstmtTwo.close();
				if(conn != null)
					conn.close();
			}catch(Exception e){
				
			}
		}
	}
	
	
	
	// added by avinash - 13/02/2018 to get sequence number from database.
	
	public static int getNextSequenceNumber()
	{
		int sequenceNumber=-99;
		Connection conn = null;
		PreparedStatement pstmt = null;	
		ResultSet rs = null;
		String query=null;
		if(Global.dbConfigParamEnable==1) //mysql
		{
			// to be done
			return sequenceNumber;
		}
		else //oracle
		{
			query="select sms_seqnum.nextval as sequence_number from dual";
	
		}
		try {
			logger.info("query: "+query);
			conn = Global.conPool.getConnection();
			pstmt= conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			while(rs.next())
			{
				sequenceNumber = rs.getInt("sequence_number");
			}
			
			rs.close();
			pstmt.close();
			conn.close();
			
			}
		catch(Exception e){
			logger.error("Exception in getNextSequenceNumber "+e.getMessage());
		}finally{
			try{
				if(rs!=null)
					rs.close();
				if(pstmt != null)
					pstmt.close();
				if(conn != null)
					conn.close();
			}catch(Exception e){
				logger.error("Exception in getNextSequenceNumber "+e.getMessage());
			}
		}
		return sequenceNumber;	 
      }
	
	
	
}
