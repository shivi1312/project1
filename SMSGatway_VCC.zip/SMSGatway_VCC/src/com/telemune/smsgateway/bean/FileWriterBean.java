package com.telemune.smsgateway.bean;
/**
 * THIS CLASS IS POJO CLASS FOR GETTING AND SETTING THE DATA FOR FILE WRITTING 
 * @author ekansh
 *@version:- R1_0_0_0
 */

public class FileWriterBean {

	private int requestType;
	private int sequenceNUm;
	private String originNum;
	private String destNum;
	private String msgTxt;
	private long timeStamp;
	private String status;
	private int campId;
	private String smscId;
	private int requestId;
	private int responseId;
	private int retryCount=0;
	
	
	
	
	public String getSmscId() {
		return smscId;
	}
	public void setSmscId(String smscId) {
		this.smscId = smscId;
	}
	public int getRequestType() {
		return requestType;
	}
	public void setRequestType(int requestType) {
		this.requestType = requestType;
	}
	public int getSequenceNUm() {
		return sequenceNUm;
	}
	public void setSequenceNUm(int sequenceNUm) {
		this.sequenceNUm = sequenceNUm;
	}
	public String getOriginNum() {
		return originNum;
	}
	public void setOriginNum(String originNum) {
		this.originNum = originNum;
	}
	public String getDestNum() {
		return destNum;
	}
	public void setDestNum(String destNum) {
		this.destNum = destNum;
	}
	public String getMsgTxt() {
		return msgTxt;
	}
	public void setMsgTxt(String msgTxt) {
		this.msgTxt = msgTxt;
	}
	public long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getCampId() {
		return campId;
	}
	public void setCampId(int campId) {
		this.campId = campId;
	}
	
	
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public int getResponseId() {
		return responseId;
	}
	public void setResponseId(int responseId) {
		this.responseId = responseId;
	}
	public int getRetryCount() {
		return retryCount;
	}
	public void setRetryCount(int retryCount) {
		this.retryCount = retryCount;
	}
	@Override
	public String toString() {
		return "FileWriterBean [requestType=" + requestType + ", sequenceNUm=" + sequenceNUm + ", originNum="
				+ originNum + ", destNum=" + destNum + ", msgTxt=" + msgTxt + ", timeStamp=" + timeStamp + ", status="
				+ status + ", campId=" + campId + ", smscId=" + smscId + ", requestId=" + requestId + ", responseId="
				+ responseId + ", retryCount=" + retryCount + "]";
	}
	
	
	
	
	
		
	
}
