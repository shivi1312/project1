package com.telemune.smsgateway.bean;

import java.util.ArrayList;

import org.apache.http.message.BasicNameValuePair;

/**
 * THIS CLASS IS FOR POJO CLASS FOR SETTING AND GETTING YUP THE INFORMATION FOR HTTP URL HIT
 * @author ekansh
 *
 */
public class SMSProcessBean {
	private int requestType;
	
	private String msisdn;
	private String message;
	private String shortCode;
	private String keyword;
	private String status;
	private String smscId;
	private boolean isDelRecptHitUrl=false;
	private int SMSCID;
	private ArrayList<BasicNameValuePair> optList;
	private String serviceType;
	
	
	

	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public ArrayList<BasicNameValuePair> getOptList() {
		return optList;
	}
	public void setOptList(ArrayList<BasicNameValuePair> optList) {
		this.optList = optList;
	}
	public int getSMSCID() {
		return SMSCID;
	}
	public void setSMSCID(int sMSCID) {
		SMSCID = sMSCID;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSmscId() {
		return smscId;
	}
	public void setSmscId(String smscId) {
		this.smscId = smscId;
	}
	public boolean isDelRecptHitUrl() {
		return isDelRecptHitUrl;
	}
	public void setDelRecptHitUrl(boolean isDelRecptHitUrl) {
		this.isDelRecptHitUrl = isDelRecptHitUrl;
	}
	private int destPort;




	public int getDestPort() {
		return destPort;
	}
	public void setDestPort(int destPort) {
		this.destPort = destPort;
	}	


	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getShortCode() {
		return shortCode;
	}
	public void setShortCode(String shortCode) {
		this.shortCode = shortCode;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public int getRequestType() {
		return requestType;
	}
	public void setRequestType(int requestType) {
		this.requestType = requestType;
	}
	@Override
	public String toString() {
		return "SMSProcessBean [requestType=" + requestType + ", msisdn=" + msisdn + ", message=" + message
				+ ", shortCode=" + shortCode + ", keyword=" + keyword + ", status=" + status + ", smscId=" + smscId
				+ ", isDelRecptHitUrl=" + isDelRecptHitUrl + ", SMSCID=" + SMSCID + ", optList=" + optList
				+ ", serviceType=" + serviceType + ", destPort=" + destPort + "]";
	}



}
