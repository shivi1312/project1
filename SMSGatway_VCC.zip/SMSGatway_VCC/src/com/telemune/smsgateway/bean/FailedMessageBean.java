package com.telemune.smsgateway.bean;

import java.sql.Date;

public class FailedMessageBean {

        private int requestType;
        private int sequenceNUm;
        private String originNum;
        private String destNum;
        private String msgTxt;
        private String timeStamp;
        private String status;
        private int campId;
        private String smscId;
        private String cdrStatus;
        private int requestId;
        private int responseId;
        private int retryCount;
        




        public String getCdrStatus() {
			return cdrStatus;
		}
		public void setCdrStatus(String cdrStatus) {
			this.cdrStatus = cdrStatus;
		}
		public String getSmscId() {
                return smscId;
        }
        public void setSmscId(String smscId) {
                this.smscId = smscId;
        }
        public int getRequestType() {
                return requestType;
        }
        public void setRequestType(int requestType) {
                this.requestType = requestType;
        }
        public int getSequenceNUm() {
                return sequenceNUm;
        }
        public void setSequenceNUm(int sequenceNUm) {
                this.sequenceNUm = sequenceNUm;
        }
        public String getOriginNum() {
                return originNum;
        }
        public void setOriginNum(String originNum) {
                this.originNum = originNum;
        }
        public String getDestNum() {
                return destNum;
        }
        public void setDestNum(String destNum) {
                this.destNum = destNum;
        }
        public String getMsgTxt() {
                return msgTxt;
        }
        public void setMsgTxt(String msgTxt) {
            this.msgTxt = msgTxt;
    }
    public String getTimeStamp() {
            return timeStamp;
    }
    public void setTimeStamp(String timeStamp) {
            this.timeStamp = timeStamp;
    }
    public String getStatus() {
            return status;
    }
    public void setStatus(String status) {
            this.status = status;
    }
    public int getCampId() {
            return campId;
    }
    public void setCampId(int campId) {
            this.campId = campId;
    }
    
    
	public int getRetryCount() {
		return retryCount;
	}
	public void setRetryCount(int retryCount) {
		this.retryCount = retryCount;
	}
	
	
	
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public int getResponseId() {
		return responseId;
	}
	public void setResponseId(int responseId) {
		this.responseId = responseId;
	}
	@Override
	public String toString() {
		return "FailedMessageBean [requestType=" + requestType + ", sequenceNUm=" + sequenceNUm + ", originNum="
				+ originNum + ", destNum=" + destNum + ", msgTxt=" + msgTxt + ", timeStamp=" + timeStamp + ", status="
				+ status + ", campId=" + campId + ", smscId=" + smscId + ", cdrStatus=" + cdrStatus + ", requestId="
				+ requestId + ", responseId=" + responseId + ", retryCount=" + retryCount + "]";
	}
	
	
	
	





}

