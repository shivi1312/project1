package com.telemune.smsgateway.bean;

import org.jsmpp.bean.BindType;
import org.jsmpp.bean.NumberingPlanIndicator;
import org.jsmpp.bean.TypeOfNumber;

/**
 * THIS CLASS IS POJO CLASS FOR SETTING AND GETTING UP THE DATA FOR SMSC CONFIGURATION BEAN 
 * @author ekansh
 *@version R1_0_0_0
 */

public class SmscConfigBean {
	
	private int smscId;
	private int smscPort;
	private String smscIp;
	private String smscUserId;
	private String smscPassword;
	private int noOfConnections;
	private String systemType;
	
	private BindType bindType;
	
	private TypeOfNumber ton;
	private NumberingPlanIndicator npi;
	
	//private String clientType;// REFERS TO BINDTYPE AS PER LIB 
	private String status;
	private String addressRange;
	private int speed;
	private int windowSize;
	private int loadBalance;
	
	
	public SmscConfigBean(int smscId, int smscPort, String smscIp,
			String smscUserId, String smscPassword, int noOfConnections,
			String systemType, String status, String addressRange, int speed,int windowSize) {
		super();
		this.smscId = smscId;
		this.smscPort = smscPort;
		this.smscIp = smscIp;
		this.smscUserId = smscUserId;
		this.smscPassword = smscPassword;
		this.noOfConnections = noOfConnections;
		this.systemType = systemType;
		this.status = status;
		this.addressRange = addressRange;
		this.speed = speed;
		this.windowSize=windowSize;
		
	}
	
	
	/*public String toString()
	{
		return "smscid "+smscId;
	}*/
	
	public BindType getBindType() {
		return bindType;
	}
	public void setBindType(BindType bindType) {
		this.bindType = bindType;
	}
	
	
	/**
	 * 
	 * This is for setting the client type 
	 * @param bindType refer to client type 
	 * TR refers to Transreciever
	 * T refers to Transmitter
	 * R refers to Reciever
	 * 
	 */
	public void setBindType(String bindType)
	{
		try{
			if(bindType.equalsIgnoreCase("TR"))
			{
				this.bindType=BindType.BIND_TRX;
			}else if(bindType.equalsIgnoreCase("R"))
			{
				this.bindType=BindType.BIND_RX;
				this.windowSize=0;
			}else if(bindType.equalsIgnoreCase("T"))
			{
				this.bindType=BindType.BIND_TX;
			}else
			{
				this.bindType=BindType.BIND_TRX;
			}
			
		}catch(Exception exe)
		{
			this.bindType=BindType.BIND_TRX;
			exe.printStackTrace();
		}
		
	}
	
	
	
	public TypeOfNumber getTon() {
		return ton;
	}
	public void setTon(TypeOfNumber ton) {
		this.ton = ton;
	}
	
	
	public void setTon(int ton)
	{
		try{
			if(ton<7)
			{
				this.ton=TypeOfNumber.valueOf((byte)ton);
				
			}else
			{
				this.ton=TypeOfNumber.valueOf((byte)1);
			}
			
			
		}catch(Exception exe)
		{
			this.ton=TypeOfNumber.valueOf((byte)1);
			exe.printStackTrace();
		}
		
	}
	
	
	public NumberingPlanIndicator getNpi() {
		return npi;
	}
	
	
	public void setNpi(NumberingPlanIndicator npi) {
		this.npi = npi;
	}
	
	public void setNpi(int npi)
	{
		try{
			if(npi<7)
			{
				this.npi=NumberingPlanIndicator.valueOf((byte)npi);
				
			}else
			{
				this.npi=NumberingPlanIndicator.valueOf((byte)1);
			}
			
		}catch(Exception exe)
		{
			this.npi=NumberingPlanIndicator.valueOf((byte)1);
			exe.printStackTrace();
		}
	}
	
	public int getSmscId() {
		return smscId;
	}
	public void setSmscId(int smscId) {
		this.smscId = smscId;
	}
	public int getSmscPort() {
		return smscPort;
	}
	public void setSmscPort(int smscPort) {
		this.smscPort = smscPort;
	}
	public String getSmscIp() {
		return smscIp;
	}
	public void setSmscIp(String smscIp) {
		this.smscIp = smscIp;
	}
	public String getSmscUserId() {
		return smscUserId;
	}
	public void setSmscUserId(String smscUserId) {
		this.smscUserId = smscUserId;
	}
	public String getSmscPassword() {
		return smscPassword;
	}
	public void setSmscPassword(String smscPassword) {
		this.smscPassword = smscPassword;
	}
	public int getNoOfConnections() {
		return noOfConnections;
	}
	public void setNoOfConnections(int noOfConnections) {
		this.noOfConnections = noOfConnections;
	}
	public String getSystemType() {
		return systemType;
	}
	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAddressRange() {
		return addressRange;
	}
	public void setAddressRange(String addressRange) {
		this.addressRange = addressRange;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}


	public int getWindowSize() {
		return windowSize;
	}


	public void setWindowSize(int windowSize) {
		this.windowSize = windowSize;
	}


	public int getLoadBalance() {
		return loadBalance;
	}


	public void setLoadBalance(int loadBalance) {
		this.loadBalance = loadBalance;
	}


	@Override
	public String toString() {
		return "SmscConfigBean [smscId=" + smscId + ", smscPort=" + smscPort + ", smscIp=" + smscIp + ", smscUserId="
				+ smscUserId + ", smscPassword=" + smscPassword + ", noOfConnections=" + noOfConnections
				+ ", systemType=" + systemType + ", bindType=" + bindType + ", ton=" + ton + ", npi=" + npi
				+ ", status=" + status + ", addressRange=" + addressRange + ", speed=" + speed + ", windowSize="
				+ windowSize + ", loadBalance=" + loadBalance + "]";
	}
	
	
	

}
