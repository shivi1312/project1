package com.telemune.smsgateway.bean;

import org.jsmpp.session.SMPPSession;

/**
 * THIS CLASS IS BEAN CLASS FOR HOLDINGTHE DATA OF CONNECTION DETAIL THIS BEAN
 * HOLDING THE SMSC CONNECTION DETAIL AFTER CREATING THE CONNECTION WITH SMSC
 * 
 * @author ekansh
 * @version :-R2_0_0_0
 */

public class ConnectionDetailBean {

	private SMPPSession session = null;

	private String smscSystemId;
	private int windowSize = 0;

	private int smscId = -1;

	public int getSmscId() {
		return smscId;
	}

	public int getWindowSize() {
		return windowSize;
	}

	public void setWindowSize(int windowSize) {
		this.windowSize = windowSize;
	}

	public void setSmscId(int smscId) {
		this.smscId = smscId;
	}

	public SMPPSession getSession() {
		return session;
	}

	public void setSession(SMPPSession session) {
		this.session = session;
	}

	public String getSmscSystemId() {
		return smscSystemId;
	}

	public void setSmscSystemId(String smscSystemId) {
		this.smscSystemId = smscSystemId;
	}

	public ConnectionDetailBean() {

	}

	public ConnectionDetailBean(SMPPSession session, String smscSystemId,
			int windowSize, int smscId) {
		super();
		this.session = session;
		this.smscSystemId = smscSystemId;
		this.windowSize = windowSize;

		this.smscId = smscId;
	}

	@Override
	public String toString() {
		return "ConnectionDetailBean [session=" + session + ", smscSystemId="
				+ smscSystemId + ", windowSize=" + windowSize + ", smscId="
				+ smscId + "]";
	}

}
