package com.telemune.smsgateway;


public class OptionalParamBean {
	
	private String c;
	private int t;
	private String v;
	public String getC() {
		return c;
	}
	public void setC(String c) {
		this.c = c;
	}
	
	public int getT() {
		return t;
	}
	public void setT(int t) {
		this.t = t;
	}
	public String getV() {
		return v;
	}
	public void setV(String v) {
		this.v = v;
	}
	@Override
	public String toString() {
		return "OptionalParamBean [c=" + c + ", t=" + t + ", v=" + v + "]";
	}
	
	

}
