package com.telemune.smsgateway;

import java.net.*;
import org.apache.log4j.*;

import com.telemune.smsgateway.bean.SmscConfigBean;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.security.MessageDigest;


/**
 * THIS CLASS IS FOR LOAD THE CACHE FOR THE WHOLE SYSTEM 
 *@author :- Ekansh Goel
 *@version :-R2_0_0_0
 *
 */

public class CacheLoader implements Runnable
{
	Hashtable config_params=new Hashtable(10);
	Hashtable SMSCConfig=new Hashtable(10);
	Thread thtemp=new Thread();
	Connection con=null;
	Statement stmt=null;
	PreparedStatement pstmt=null;
	ResultSet rs=null;
	String query="";
	int sleeptime=30;
	Logger logger=Logger.getLogger(CacheLoader.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");	
		
/**
 *
 *THIS IS THE paramETERIZED CONSTRUCTOR OF CACHELOADER CLASS IN WHCIH WE ARE INITIALIZE THE SLEEP TIME OF THIS THREAD
 *@param sl :- REPRESENT THE SLEEP TIME
 *
 */
	public CacheLoader(int sl)
	{
		logger.debug("Sleep time .........."+sl);
		sleeptime=sl;
	}
        /**
         * 
         */
        public void stop()
	{
	}


/**
 *THIS FUNCTION LOADS THE paramETERS WHICH ARE DEFINE FOR SYSTEM 
 *THESE paramETERS ARE CONFIGURE IN TABLE APP_CONFIG_paramS
 *
 *
 */
	public void loadAppConfigParams()
	{
		logger.debug ("Loading Configuration Parameters");
		Connection con= null;
		try
		{
			con=Global.conPool.getConnection();
			stmt=con.createStatement();
			query="select param_NAME,param_VALUE from App_config_params";
			logger.info(query);
			
			rs=stmt.executeQuery(query);
			while(rs.next())
			{
				try
				{	
					config_params.put(rs.getString(1),rs.getString(2));
				}
				catch(NullPointerException ex)
				{
				errorLogger.error("ErrorCode [SMSGW-CORE-90003] Param Name ["+rs.getString(1)+"] Param value ["+rs.getString(2)+"] [NullPointerException when putting App Config data into Hashtable ] ERROR ["+ex.getMessage()+"]");
						ex.printStackTrace();
					
				}
				catch (Exception e) {
					errorLogger.error("ErrorCode [SMSGW-CORE-00001] Param Name ["+rs.getString(1)+"] Param value ["+rs.getString(2)+"] [Exception when inserting APP Config Parameter into Hashtable ] ERROR ["+e.getMessage()+"]");
					e.printStackTrace();	
					
				}
			}
			
			Global.config_params=config_params;
			rs.close();
			stmt.close();
			con.close();
		}
		catch(SQLException sqle)
		{
			errorLogger.error("ErrorCode [SMSGW-CORE-90001] [SQLException while Fetch APP Config parameter from data base] ERROR ["+sqle.getMessage()+"]");
			sqle.printStackTrace();
		}
		catch(Exception e)
		{
			errorLogger.error("ErrorCode [SMSGW-CORE-00002] [Exception when create connection from data base for fetching App Config parameter] ERROR ["+e.getMessage()+"]");
			e.printStackTrace();	
		}finally
		{
			try{
				if(stmt!=null)stmt.close();
				if(rs!=null)rs.close();
				if(con!=null)con.close();
				
			}catch(Exception e)
			{
				errorLogger.error("ErrorCode [SMSGW-CORE-00003] [Exception when Closing all Data Base parameter into finally block] ERROR ["+e.getMessage()+"]");
				e.printStackTrace();	
			}
		}
	}

	/**
	 * This Functioj is for handle the Loading SMSc configuration Params from the database
	 * The configuration is present in the database table name GMAT_SMSC_CONFIG 
	 * 
	 */
	
	
public void LoadSMSCConfigParams()
{
	logger.debug ("Loading GMAT_SMSC_PARAMS..............");
	SmscConfigBean bean=null;
	Connection con= null;
	Global.totalMsgSend=0;
	try
	{
		con=Global.conPool.getConnection();
		stmt=con.createStatement();
		query="select SMSC_ID,SMSC_PORT,SMSC_IP,SMSC_USER_ID,SMSC_PASSWORD,NO_OF_CONNECTIONS,SYSTEM_TYPE,CLIENT_TYPE,STATUS,TON,NPI,ADDRESS_RANGE,SPEED,Window_Size from "+Global.gmatSmscConfigTable+" where status ='A' order by SMSC_ID";
		rs=stmt.executeQuery(query);
		logger.info("LoadSMSCConfigParams()............query ["+query+"]");
		
		while(rs.next())
		{
			try
			{	
				bean= new SmscConfigBean(rs.getInt("SMSC_ID"),
						rs.getInt("SMSC_PORT"),
						rs.getString("SMSC_IP"), 
						rs.getString("SMSC_USER_ID"),
						rs.getString("SMSC_PASSWORD"),
						rs.getInt("NO_OF_CONNECTIONS"),
						rs.getString("SYSTEM_TYPE"),
						rs.getString("STATUS"),
						rs.getString("ADDRESS_RANGE"),
						rs.getInt("SPEED"),rs.getInt("Window_Size"));
				bean.setBindType(rs.getString("CLIENT_TYPE"));
				bean.setNpi(rs.getInt("NPI"));
				bean.setTon(rs.getInt("TON"));
				
				SMSCConfig.put(rs.getInt("SMSC_ID"), bean);
				
			}
			catch(NullPointerException ex)
			{
			errorLogger.error("ErrorCode [SMSGW-CORE-90003] SMSCID ["+bean.getSmscId()+"] SMSC_IP ["+bean.getSmscIp()+"] [NullPointerException when put smsc configuration into Hashtable ] ERROR ["+ex.getMessage()+"]");
					ex.printStackTrace();
				
			}
			catch(SQLException sqle)
			{
				errorLogger.error("ErrorCode [SMSGW-CORE-90001] [SQLException while Fetch SMSC Configuration from data base] ERROR ["+sqle.getMessage()+"]");
				sqle.printStackTrace();
			}
			catch(Exception e)
			{
				errorLogger.error("ErrorCode [SMSGW-CORE-00004] [Exception when put SMSC configuration into Hash table ] ERROR ["+e.getMessage()+"]");
				e.printStackTrace();	
			}
		//logger.info("window size  [  "+bean.getWindowSize()+" ] bind type ["+bean.getBindType()+"  ]");			
		Global.smscParamDetail=SMSCConfig;
		Global.totalMsgSend=Global.totalMsgSend+bean.getNoOfConnections()*bean.getWindowSize();
		}
		rs.close();
		stmt.close();
		con.close();
	}
	
	
	catch(SQLException sqle)
	{
		errorLogger.error("ErrorCode [SMSGW-CORE-90001] [SQLException while Fetch SMSC configuration parameter from data base] ERROR ["+sqle.getMessage()+"]");
		sqle.printStackTrace();
	}
	catch(Exception e)
	{
		errorLogger.error("ErrorCode [SMSGW-CORE-00005] [Exception when create connection from data base for fetching SMSC configuration parameter] ERROR ["+e.getMessage()+"]");
		e.printStackTrace();
	}finally
	{
		try{
			if(stmt!=null)stmt.close();
			if(rs!=null)rs.close();
			if(con!=null)con.close();
			
		}catch(Exception exe)
		{
			errorLogger.error("ErrorCode [SMSGW-CORE-00003] [Exception when Closing all Data Base parameter into finally block] ERROR ["+exe.getMessage()+"]");
			exe.printStackTrace();	
		}
	}
}
	
/**
 *THIS IS THE RUN METHOD OF CACHELOADER THREAD WHICH CALLS THE ABOVE DEFINE FUNCTION AND ALSO SET THE paramETERS GLOBALLY IN 
 */

	public void run()
	{
		while(true)
		{
			logger.debug("Running Cache Loader Thread........");
			try
			{
				//loadAppConfigParams();
				LoadSMSCConfigParams();
				
				
				logger.info("Size of the SMSC CONFIG Params Cache"+Global.smscParamDetail.size());
				
				Thread.sleep(sleeptime*1000);
				
			}
			catch(InterruptedException e)
			{
				errorLogger.error("ErrorCode [SMSGW-CORE-90013] [InterruptedException while Sleep() CacheLoader Thread] ERROR ["+e.getMessage()+"]");
				e.printStackTrace();
			}
			catch(Exception e)
			{
				errorLogger.error("ErrorCode [SMSGW-CORE-00006] [Exception while running Cache Loader thread] ERROR ["+e.getMessage()+"]");
				e.printStackTrace();

			}
			
		}
	}
	
	
}
