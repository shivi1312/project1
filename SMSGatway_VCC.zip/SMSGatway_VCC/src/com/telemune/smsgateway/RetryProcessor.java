package com.telemune.smsgateway;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;

import com.telemune.smsgateway.bean.FailedMessageBean;

public class RetryProcessor implements Runnable{

	Logger logger = Logger.getLogger(RetryProcessor.class);
	
	public RetryProcessor() {
		logger.info("Starting RetryProcessor thread");
	}
	
	
	
	@Override
	public void run() {
		try{
			FailedMessageBean bean = null;
			while(true)
			{
				if(!Global.failedMessageQueue.isEmpty())
				{
					bean = Global.failedMessageQueue.poll();
					processFailedMessage(bean);
				}
				else
				{
					Thread.sleep(1500);
				}
			}
		}
		catch(Exception e){
			logger.error("Error in RetryProcessor Thread ["+e.getMessage()+"]");
		}
		
	}



	private void processFailedMessage(FailedMessageBean bean) {
		logger.info("inside processFailedMessage ["+bean+"]");
		int result = -1;
		Connection con = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		int insertResult = 1;
		String query = null;
		FailedMessageBean failedMessageBean = null;
		
		String orgNumber = null;
		String destNumber = null;
		String messageText = null;
		int campId = -1;
		int retryCount = -1;
		
		try{
			con = Global.conPool.getConnection();
			con.setAutoCommit(false);
			query = "select ORG_NUM,DEST_NUM,MSG_TXT,CAMP_ID,RETRY_COUNT,IS_RETRIED from SMSG_SMS_RESPONSE_MDR where REQUEST_ID=? and ORG_NUM=? and DEST_NUM=? and IS_RETRIED='N'";
			 if(Global.dbConfigParamEnable==0) {
			pstmt = con.prepareStatement(query, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			 }else
			 {
				 query = "select ORG_NUM,DEST_NUM,MSG_TXT,CAMP_ID,RETRY_COUNT,IS_RETRIED,REQUEST_ID,RESPONSE_ID,SUBMIT_TIME from SMSG_SMS_RESPONSE_MDR where REQUEST_ID=? and ORG_NUM=? and DEST_NUM=? and IS_RETRIED='N'";
				 pstmt = con.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			 }
			
			pstmt.setInt(1, bean.getRequestId());
			pstmt.setString(2, bean.getOriginNum());
			pstmt.setString(3, bean.getDestNum());
			rs = pstmt.executeQuery();
			
			if(rs.next())
			{
				 orgNumber = rs.getString("ORG_NUM");
				 destNumber = rs.getString("DEST_NUM");
				 messageText = rs.getString("MSG_TXT");
				 campId = rs.getInt("CAMP_ID");
				 retryCount = rs.getInt("RETRY_COUNT");
				 logger.debug("inside processFailedMessage found message from SMSG_SMS_RESPONSE_MDR  orgNumber["+orgNumber+"] destNumber["+destNumber+"] messageText ["+messageText+"] campId ["+campId+"] retryCount["+retryCount+"]");
				 if(retryCount<Global.numberOfRetry)
				 {
					 //query for oracle
					 if(Global.dbConfigParamEnable==0) 
					 {
						  //query = "insert into gmat_message_store (RESPONSE_ID,REQUEST_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT,SUBMIT_TIME,STATUS,MESSAGE_TYPE,CAMPAIGN_ID,RETRY_COUNT) values (GMAT_REQUEST_ID_SEQ.nextval,GMAT_RESPONSE_ID_SEQ.nextval,?,?,?,sysdate,'R',1,?,?)";
						 query="insert /*+ append */ into  gmat_message_store (RESPONSE_ID,REQUEST_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT,SUBMIT_TIME,STATUS,MESSAGE_TYPE,CAMPAIGN_ID,RETRY_COUNT) values (GMAT_REQUEST_ID_SEQ.nextval,GMAT_RESPONSE_ID_SEQ.nextval,?,?,?,sysdate,'R',1,?,?)";
					 }
					 else //query for mysql
					 {
						 query = "insert into gmat_message_store (ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT,SUBMIT_TIME,STATUS,MESSAGE_TYPE,CAMPAIGN_ID,RETRY_COUNT) values (?,?,?,now(),'R',1,?,?)";
					 }
					 logger.debug("inside processFailedMessage insert query is ["+query+"]");
					 pstmt1 = con.prepareStatement(query);
					 pstmt1.setString(1, orgNumber);
					 pstmt1.setString(2, destNumber);
					 pstmt1.setString(3, messageText);
					 pstmt1.setInt(4, campId);
					 pstmt1.setInt(5, retryCount+1);
					 insertResult = pstmt1.executeUpdate();
					 pstmt1.close();
					 if(insertResult == 1)
					 {
						 rs.updateString("IS_RETRIED", "Y");
						 rs.updateRow();
						 query = "update SMS_GTW_LOG set CDR_STATUS='Y' where REQUEST_ID=? and ORG_NUM=? and DEST_NUM=?";
						 pstmt1 = con.prepareStatement(query);
						 pstmt1.setInt(1, bean.getRequestId());
						 pstmt1.setString(2, bean.getOriginNum());
						 pstmt1.setString(3, bean.getDestNum());
						 
						 if(pstmt1.executeUpdate()>0)
						 {
							 result = 1;
						 }
						 pstmt1.close();
					 }
				 }
				
			}
			else
			{
				// message not found in SMSG_SMS_RESPONSE_MDR with REQUEST_ID=? and IS_RETRIED='N'
				result = 2;
			}
			con.commit();
		}
		catch(Exception e){
			logger.info("Exception inside processFailedMessage ["+e.getMessage()+"]");
		}
		finally{
			try{
				if(rs!=null){ rs.close(); }
				if(pstmt1!=null){ pstmt1.close();}
				if(pstmt!=null){ pstmt.close();}
				if(con!=null){ con.close();}
			}
			catch(Exception e){
				logger.error("Exception inside processFailedMessage finally ["+e.getMessage()+"]");
			}
		}
		
		
		logger.info("exit processFailedMessage ["+bean+"] result ["+result+"]");
	}

}
