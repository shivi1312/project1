package com.telemune.smsgateway.loadbalance;

import java.util.ArrayList;

@SuppressWarnings("rawtypes")
public class Main {
	@SuppressWarnings("unchecked")
	public static void main(String [] args){
		JobFinishEvent callback = new JobFinishEvent() {
            @Override
            public void onFinish(Job j) {
            	System.out.println("Finish..");
            }
        };
		ArrayList jobs = new ArrayList();
        jobs.add(new Job(1, 0, 2, callback));
        jobs.add(new Job(2, 1, 3, callback));
        RoundRobin rr = new RoundRobin();
        rr.run(jobs,10);
	}
}
