package com.telemune.smsgateway.loadbalance;

public interface JobFinishEvent {
	public void onFinish(Job j);
}
