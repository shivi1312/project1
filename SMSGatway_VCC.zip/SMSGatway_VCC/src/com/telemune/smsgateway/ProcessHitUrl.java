
package com.telemune.smsgateway;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import com.telemune.endec.MSISDNEnDec;
import com.telemune.smsgateway.bean.FileWriterBean;
import com.telemune.smsgateway.bean.SMSProcessBean;
import com.telemune.smsgateway.model.MsgList;
/**
 * THIS IS CLASS IS FOR PROCESSING THE HTTP HIT TO THE PARTICULAR APPLICATION
 * WHEN ANY DELIVER SM IS RECIEVED
 * 
 * @author swati
 * @version R1_0_0_0
 *
 */

public class ProcessHitUrl implements Runnable {
	
	
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	Logger logger = Logger.getLogger("ProcessHitUrl");
	static int count = 1;
	FileWriterBean fileBean = null;
	/**
	 * THS RUN METHOD CHECK THE Global.rcvSMSQueue FOR DATA IF THIS QUEUE
	 * CONTAIN SOME DATA THEN IT PROCESS AND DO A HTTP HIT ACCORDING TO THAT
	 */
	SMSProcessBean bean = null;

	public ProcessHitUrl(SMSProcessBean bean) {
		this.bean = bean;
	}
	@Override
	public void run() {
		String responseCode = "Na";

		try {
			
			responseCode = sendGet(bean);
			logger.debug("Getting the response code after hit url...... " + responseCode);

		}
		catch (Exception e) {
			errorLogger.error("ErrorCode ["+Global.errCode+"-00046] MSISDN ["+bean.getMsisdn()+"] [Exception when send http request] ERROR ["+e.getMessage()+"]");
			e.printStackTrace();		
			}

		finally {
			if (bean != null)
				bean = null;
		}

	}

	/**
	 * THIS FUNCTION IS FOR HITTING THE HTTP REQUEST BY MAKING THE CONNECTION TO
	 * THE PARTICULAR URL
	 * 
	 * @param bean
	 *            :- REFERS TO THE SMSProcessBean WHICH HOLD THE INFORMATION
	 *            WHICH GOING TO PASS IN THE HTTP HIT
	 * @return :- RETURN STRING WHICH SHOWS WHETHER THE HIT IS SUCCESS OR NOT
	 */
	private String sendGet(SMSProcessBean bean) {
		String retVal = "failure";
		HttpGet get = null;
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		String encodingString = "UTF-8";
		StringBuilder requestUrl = null;
		CloseableHttpClient client = null; // added by Avishkar
		CloseableHttpResponse response = null; // added by Avishkar
		try {
			if (Global.isDeliverSmEncodingEnable == 1) {

				if (Global.deliverSmEncoding.equalsIgnoreCase("utf-8")) {
					encodingString = "UTF-8";
				} else if (Global.deliverSmEncoding.equalsIgnoreCase("iso-8859-1")) {
					encodingString = "ISO-8859-1";
				}
			}
			logger.info("SMSProcessBean -> "+bean.toString());
			// bean.setShortCode("*123#");

			/*
			 * if (bean.getMessage().contains("VCARD")) { if
			 * (bean.getMessage().contains("\r\n")) {
			 * bean.setMessage(bean.getMessage().replace("\r\n", "#VC#"));6666665r
			 * bean.setKeyword("VCARD"); } }
			 */

			if (Global.enableDelRecptUrlHit == 1 && bean.getRequestType()==Global.DELIVERY_RECIEPT)  {
				requestUrl = new StringBuilder(Global.delRcptUrl);
				params.add(new BasicNameValuePair("msisdn", bean.getMsisdn()));
				params.add(new BasicNameValuePair("shortcode", bean.getShortCode()));
				params.add(new BasicNameValuePair("status", bean.getStatus()));
				params.add(new BasicNameValuePair("smscid", bean.getSmscId()));
				params.add(new BasicNameValuePair("serviceType", bean.getServiceType()));
				params.add(new BasicNameValuePair("keyword", bean.getKeyword()));
			} else if(Global.enableDelRecptUrlHit == 2 && bean.getRequestType()==Global.DELIVERY_RECIEPT && !bean.getServiceType().equalsIgnoreCase(Global.relaseServiceType)) {
				
				logger.info("Get the deliver message for msisdn ["+bean.getMsisdn()+"] with keyword ["+bean.getKeyword()+"] shortCode ["+bean.getShortCode()+"] ["+bean.getServiceType()+"]");
				
				if(bean.getKeyword()==null) {
					bean.setServiceType(Global.serviceTypeDeliver);
					MsgList msgList =  Global.gmatService.deliverMsgList(bean);
					Global.submitMessageProducer.deliverData(msgList);
					return "success";
					
				}else {
					
					bean.setServiceType(Global.relaseServiceType);
					
					MsgList msgList =  Global.gmatService.deliverMsgList(bean);
					Global.submitMessageProducer.deliverData(msgList);
					
					requestUrl = new StringBuilder(Global.delRcptUrl);
					params.add(new BasicNameValuePair("msisdn", bean.getMsisdn()));
					params.add(new BasicNameValuePair("callingNum", bean.getMsisdn()));
					params.add(new BasicNameValuePair("shortcode", bean.getShortCode()));
					params.add(new BasicNameValuePair("status", bean.getStatus()));
					params.add(new BasicNameValuePair("smscid", bean.getSmscId()));
					try {
						if(bean.getKeyword()!=null && Integer.parseInt(bean.getKeyword())-1<Global.rbtList.length) {
							params.add(new BasicNameValuePair("rbtCode", Global.rbtList[Integer.parseInt(bean.getKeyword())]));	
						}
					}catch(Exception e) {
						logger.error("Exception while change the keyword string to int ["+bean.getKeyword()+"]  "+e);
						params.add(new BasicNameValuePair("rbtCode", "0"));
						e.printStackTrace();
					}
					
				}
				
			} else {
				
				requestUrl = new StringBuilder(Global.appUrl);
				/*
				 * params.add(new BasicNameValuePair("msisdn",
				 * bean.getMsisdn())); params.add(new
				 * BasicNameValuePair("shortcode","2203023604")); params.add(new
				 * BasicNameValuePair("status","DELIVERED"));
				 */
				params.add(new BasicNameValuePair("msisdn", bean.getMsisdn()));
				params.add(new BasicNameValuePair("params", bean.getMessage()));
				params.add(new BasicNameValuePair("keyword", bean.getKeyword()));
				params.add(new BasicNameValuePair("shortcode", bean.getShortCode()));
				params.add(new BasicNameValuePair("destport", bean.getDestPort() + ""));
				params.add(new BasicNameValuePair("smscid", bean.getSMSCID() + ""));
				// avinash - added on 24/04/2017 to send encoded value of MSISDN
				//commented by kuldeep in Oct 2020
				//String encodedMSISDN = new MSISDNEnDec().encodeMSISDN(new StringBuilder(bean.getMsisdn()));
				//params.add(new BasicNameValuePair("encv", encodedMSISDN ));
				params.addAll(bean.getOptList());
			}

			String query = URLEncodedUtils.format(params, encodingString);// iso-8859-1
			requestUrl.append("?");
			requestUrl.append(query);
			logger.info("url: " + requestUrl.toString());
			//RequestConfig config = RequestConfig.custom().
				//	setSocketTimeout(5000).setConnectTimeout(5000).build();
			/**
			if(Global.enableDelRecptUrlHit == 2) {
				requestUrl.append(Global.urlAppender);
			}
			*/
//			CloseableHttpClient client = HttpConnectionPool.getInstance().getHttpConnection();
			client = HttpConnectionPool.getInstance().getHttpConnection(); // modified by Avishkar
			get = new HttpGet(requestUrl.toString());
			
//			HttpResponse response = client.execute(get);
			response = client.execute(get); // modified by Avishkar
			EntityUtils.consume(response.getEntity());
			int responseCode = response.getStatusLine().getStatusCode();

			logger.info("status: " + response.getStatusLine() + "status code is "
					+ response.getStatusLine().getStatusCode());
			if (responseCode == 200) {
				retVal = "success";
				get.releaseConnection();


			} else {
				logger.info("response get failure from http hit binary are write into error file"
						+ Global.rcvSMSQueue.size());
				fileBean = new FileWriterBean();
				fileBean.setRequestType(Global.ERROR_FILE);
				fileBean.setSmscId(bean.getSMSCID() + "");
				fileBean.setStatus("Failure of time out");
				fileBean.setDestNum(bean.getMsisdn());
				fileBean.setTimeStamp(System.currentTimeMillis());
				Global.fileWriteQueue.put(fileBean);
				/*
				 * if(get!=null) { get.releaseConnection(); }
				 */
			}
		}

		catch (SocketTimeoutException socExe) {
			try {
				 errorLogger.error("ErrorCode ["+Global.errCode+"-90011] MSISDN["+bean.getMsisdn()+"] ShortCode ["+bean.getShortCode()+"] Keyword ["+bean.getKeyword()+"] [SocketTimeOut Exception while connect with Other HTTP API] Error[" + socExe.getMessage()+"]");
				
				fileBean = new FileWriterBean();
				fileBean.setRequestType(Global.ERROR_FILE);
				fileBean.setSmscId(bean.getSMSCID() + "");
				fileBean.setStatus("Failure of time out");
				fileBean.setDestNum(bean.getMsisdn());
				fileBean.setTimeStamp(System.currentTimeMillis());
				Global.fileWriteQueue.put(fileBean);
				logger.warn("Socket timeout........" + socExe.getMessage());
			} catch (Exception e) {
				 errorLogger.error("ErrorCode ["+Global.errCode+"-00047] MSISDN["+bean.getMsisdn()+"] ShortCode ["+bean.getShortCode()+"] Keyword ["+bean.getKeyword()+"] [Exception when Socket Time Exception Error logs write into Log file] Error[" + e.getMessage()+"]");
				 e.printStackTrace();
			}
		} catch (ConnectException conExe) {
			try {
				  errorLogger.error("ErrorCode  ["+Global.errCode+"-90016] MSISDN["+bean.getMsisdn()+"] ShortCode ["+bean.getShortCode()+"] Keyword ["+bean.getKeyword()+"] [Http connection is not established with other HTTP Application] Error[" + conExe.getMessage()+"]");
				
				  logger.info("Connection refused then error write into file ");
				fileBean = new FileWriterBean();
				fileBean.setRequestType(Global.ERROR_FILE);
				fileBean.setSmscId(bean.getSMSCID() + "");
				fileBean.setStatus("Connection refused");
				fileBean.setDestNum(bean.getMsisdn());
				fileBean.setTimeStamp(System.currentTimeMillis());
				Global.fileWriteQueue.put(fileBean);
				logger.warn("Connection refused........" + conExe.getMessage());
			} catch (Exception e) {
				 errorLogger.error("ErrorCode ["+Global.errCode+"-00048] MSISDN["+bean.getMsisdn()+"] ShortCode ["+bean.getShortCode()+"] Keyword ["+bean.getKeyword()+"] [Exception when Connection Time out Exception Error logs write into Log file] Error[" + e.getMessage()+"]");


		} 
		}catch (Exception e) {
			
			errorLogger.error("ErrorCode ["+Global.errCode+"-00049] MSISDN ["+bean.getMsisdn()+"] ShortCode ["+bean.getShortCode()+"] Keyword ["+bean.getKeyword()+"] [Exception when Hit to HTTP API] ERROR ["+e.getMessage()+"]");
			e.printStackTrace();	
			
		} finally {
			try {
				// Added by Avishkar start
				if (fileBean != null) {
					fileBean = null;
				}
				if (bean != null) {
					bean = null;
				}
				
				if (get != null) {
					get.releaseConnection();
					get = null;
				}
				
				if (client != null) {
			         try {
			           client.close();
			           client = null;
			         } catch (Exception e3) {
			           e3.printStackTrace();
			         }
				}
				
				if (response != null) {
			         try {
			           response.close();
			           response = null;
			         } catch (Exception e4) {
			           e4.printStackTrace();
			         }
		        }
				// Added by Avishkar ends
				
			} catch (Exception e) {
				errorLogger.error("ErrorCode ["+Global.errCode+"-00050] MSISDN ["+bean.getMsisdn()+"] ShortCode ["+bean.getShortCode()+"] Keyword ["+bean.getKeyword()+"] [Exception when release HTTP Connection] ERROR ["+e.getMessage()+"]");
				e.printStackTrace();
			}
		}

		return retVal;
	}
	
	
	
}
