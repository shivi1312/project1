package com.telemune.smsgateway;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;

import com.telemune.smsgateway.bean.FailedMessageBean;

/*
 * This class is used to read failed messages from SMS_GTW_LOG table. 
 * and adds the message to Global.failedMessageQue for further processing for retry feature.
 * 
 */
public class FailedMessageReader implements Runnable {

	private Logger logger = Logger.getLogger(FailedMessageReader.class);

	public FailedMessageReader() {
		logger.info("Starting FailedMessageReader thread.");
	}

	@Override
	public void run() {
		try {
			while(true)
			{
				getFailedMessages();
				Thread.sleep(1500);
			}
		} catch (Exception e) {
			logger.error("Exception inside FailedMessageReader class [" + e.getMessage() + "]");
		}
	}

	private void getFailedMessages() {
		logger.info("Inside getFailedMessages()....");
		Connection con = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		String query = null;
		FailedMessageBean bean = null;
		StringBuffer queryBuffer = null;
		try {

			con = Global.conPool.getConnection();

			queryBuffer = new StringBuffer();
			
			if(Global.dbConfigParamEnable==0)
			{
				
				queryBuffer.append("select REQUEST_ID,RESPONSE_ID,SEQ_NUM,ORG_NUM,DEST_NUM,MSG_TXT,TIME_STAMP,STATUS,CAMP_ID,SMSC_ID,RETRY_COUNT,CDR_STATUS from  sms_gtw_log where trunc(TIME_STAMP)=trunc(sysdate) and CDR_STATUS='N' and RETRY_COUNT<");
				
				
				queryBuffer.append(Global.numberOfRetry);
				queryBuffer.append(" and TIME_STAMP<=sysdate - interval '");
				queryBuffer.append(Global.retryAfterMinutes);
				queryBuffer.append("' minute and status in (");
				queryBuffer.append(Global.retryForStatusCode);
				queryBuffer.append(")  and ORG_NUM not in(");
				queryBuffer.append(Global.excludeOriginNumber);
				queryBuffer.append(") and rownum<1000");
			}
			else
			{
				//queryBuffer.append("############# SQL Query Not available");
				queryBuffer.append("select REQUEST_ID,RESPONSE_ID,SEQ_NUM,ORG_NUM,DEST_NUM,MSG_TXT,TIME_STAMP,STATUS,CAMP_ID,SMSC_ID,RETRY_COUNT,CDR_STATUS from  sms_gtw_log where date(TIME_STAMP)=date(now()) and CDR_STATUS='N' and RETRY_COUNT<");
				queryBuffer.append(Global.numberOfRetry);
				queryBuffer.append(" and TIME_STAMP<= now() - interval '");
				queryBuffer.append(Global.retryAfterMinutes);
				queryBuffer.append("' minute and status in (");
				queryBuffer.append(Global.retryForStatusCode);
				queryBuffer.append(")  and ORG_NUM not in(");
				queryBuffer.append(Global.excludeOriginNumber);
				queryBuffer.append(")  limit 1000");
				
				//logger.error("error inside getFailedMessages query not available for mysql");
			}
			
			query = queryBuffer.toString();
			logger.debug("query for getFailedMessages is [" + query + "]");
			//pstmt = con.prepareStatement(query, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			pstmt = con.prepareStatement(query);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				bean = new FailedMessageBean();
				bean.setRequestId(rs.getInt("REQUEST_ID"));
				bean.setResponseId(rs.getInt("RESPONSE_ID"));
				bean.setSequenceNUm(rs.getInt("SEQ_NUM"));
				bean.setOriginNum(rs.getString("ORG_NUM"));
				bean.setDestNum(rs.getString("DEST_NUM"));
				bean.setMsgTxt(rs.getString("MSG_TXT"));
				bean.setTimeStamp(rs.getString("TIME_STAMP"));
				bean.setStatus(rs.getString("STATUS"));
				bean.setCampId(rs.getInt("CAMP_ID"));
				bean.setSmscId(rs.getString("SMSC_ID"));
				bean.setCdrStatus("N");
				bean.setRetryCount(rs.getInt("RETRY_COUNT"));
				Global.failedMessageQueue.add(bean);
				
				query="update SMS_GTW_LOG set CDR_STATUS='P' where SEQ_NUM=? and REQUEST_ID=? and ORG_NUM=? and DEST_NUM=?";
				pstmt1 = con.prepareStatement(query);
				pstmt1.setInt(1, rs.getInt("SEQ_NUM"));
				pstmt1.setInt(2, rs.getInt("REQUEST_ID"));
				pstmt1.setString(3,rs.getString("ORG_NUM") );
				pstmt1.setString(4, rs.getString("DEST_NUM"));
				pstmt1.executeUpdate();
				pstmt1.close();
				//rs.updateString("CDR_STATUS", "P");
				//rs.updateRow();
			}

			rs.close();
			pstmt.close();
			con.close();

		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (pstmt1 != null) {
					pstmt1.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		}

	}

}
