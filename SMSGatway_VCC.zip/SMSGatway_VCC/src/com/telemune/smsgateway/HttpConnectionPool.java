package com.telemune.smsgateway;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.log4j.Logger;


public class HttpConnectionPool {
	static Logger logger = Logger.getLogger(HttpConnectionPool.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	
    private static PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
    private static HttpConnectionPool datasource;
	private static int readTimedOut = Global.readurlHitTimeout;
    private static int connTimedOut = Global.urlHitTimeout;
    private RequestConfig config = RequestConfig.custom()
    		 .setConnectTimeout(connTimedOut)
    		 .setConnectionRequestTimeout(readTimedOut)
    		 .setSocketTimeout(connTimedOut).build();
    
	public static HttpConnectionPool getInstance() {
		if (datasource == null) {
			datasource = new HttpConnectionPool();
		}
		return datasource;
	}

    /*
     * Configure common configuration per every root setMaxTotal configure max
     * total connection for connection pool, default is 5 setDefaultMaxPerRoute
     * set max connection per route, default value is 5
     */
    private HttpConnectionPool() {
            try {
                    connManager.setMaxTotal(HttpConfig.config.getInt(
                                    "default.max.http.conn", 5));
                    connManager.setDefaultMaxPerRoute(HttpConfig.config.getInt(
                                    "default.max.http.per.route.conn", 5));
                  
                    logger.info("default max conn ["
                                    + HttpConfig.config.getInt("default.max.http.conn", 5)
                                    + "]");
                    logger.info("default max per route ["
                                    + HttpConfig.config.getInt(
                                                    "default.max.http.per.route.conn", 5) + "]");
                    
                    IdleConnectionMonitorThread staleMonitor = new IdleConnectionMonitorThread(
                                    connManager);
                    staleMonitor.start();
                    staleMonitor.join(1000);
            } 
            catch(NumberFormatException ex)
            {
            	errorLogger.error("ErrorCode ["+Global.errCode+"-90004] [NumberFormatException while Fetching record from http property file] ERROR ["+ex.getMessage()+"]");
    			ex.printStackTrace();	
            }
            catch (NullPointerException ex) {
            	errorLogger.error("ErrorCode ["+Global.errCode+"-90003] [NullPointerException while Fetching record from http property file]] ERROR ["+ex.getMessage()+"]");
    			ex.printStackTrace();
			}
            catch (Exception ex) {
            	errorLogger.error("ErrorCode ["+Global.errCode+"-00044] [Exception while Fetching record from http property file and start monitor thread for idle connection] ERROR ["+ex.getMessage()+"]");
    			ex.printStackTrace();
            }
    }


    public CloseableHttpClient getHttpConnection() {
    	
          /*  return HttpClients.custom().setConnectionManager(connManager).
            		setDefaultRequestConfig(config).build();*/ 
    	  return HttpClients.custom().setConnectionManager(connManager). // modified by avishkar on 03122020
    			  setConnectionManagerShared(true).
          		setDefaultRequestConfig(config).build();
    }
    public PoolingHttpClientConnectionManager getConnectionManager() {
    	return connManager;
    }
}

