package com.telemune.smsgateway;

import org.apache.log4j.Logger;

/**
 * 
 * @author Avishkar Verma
 *	this thread is used to clean up the unreachable objects from the memory
 */

public class MemoryCleanUp implements Runnable{
	Logger logger=Logger.getLogger(MemoryCleanUp.class);
	int sleeptime=1800;
	
	public MemoryCleanUp() {
		// TODO Auto-generated constructor stub
	}
	
	public MemoryCleanUp(int sleep) {
		logger.debug("Sleep time .........."+sleep);
		sleeptime=sleep;
	}

	@Override
	public void run() {
		
		while (true) {
			logger.info("Running MemoryCleanUp Thread........");
			try {
				System.gc(); // added by Avishkar for garbage collector
//				Runtime.getRuntime().gc(); // added by Avishkar for garbage collector
				Thread.sleep(sleeptime*1000);
				
			} catch (Exception e) {
				logger.error("### Exception while clearing the objects...",e);
				e.printStackTrace();
			}
		}
		
	}

	@Override
	protected void finalize() throws Throwable {
		logger.debug(">>>### Garbage collector called...");
//		logger.debug("Object garbage collected :" + this);
		super.finalize();
	}
}
