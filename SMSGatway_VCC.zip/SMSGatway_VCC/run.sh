#!/bin/bash

#set -x
. ~/.bash_profile
cd /home/avinash/eclipse_mars/workspace/USSDGateway/
nice -0 java -jar SMSGateway_Java.jar 1>> SMSGateway_Java.out 2>> SMSGateway_Java.out
