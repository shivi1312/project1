-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: 10.168.2.127    Database: smsg
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gmat_message_store`
--

DROP TABLE IF EXISTS `gmat_message_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gmat_message_store` (
  `RESPONSE_ID` bigint(20) DEFAULT '0',
  `REQUEST_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ORIGINATING_NUMBER` varchar(15) NOT NULL,
  `DESTINATION_NUMBER` varchar(15) NOT NULL,
  `MESSAGE_TEXT` text NOT NULL,
  `SUBMIT_TIME` datetime DEFAULT NULL,
  `MESSAGE_TYPE` int(11) DEFAULT '1',
  `LANGUAGE` tinyint(4) DEFAULT '1',
  `UDH` varchar(50) DEFAULT NULL,
  `STATUS_REPORT` tinyint(4) DEFAULT '0',
  `DATA_CODING_SCHEME` tinyint(4) DEFAULT '0',
  `PROTOCOL_IDENTIFIER` tinyint(4) DEFAULT '0',
  `PRIORITY` tinyint(4) DEFAULT '0',
  `CHARGING_CODE` tinyint(4) DEFAULT '-1',
  `STATUS` varchar(2) NOT NULL DEFAULT 'R',
  `VALIDITY_PERIOD` bigint(20) NOT NULL,
  `MESSAGE_ID` bigint(20) NOT NULL,
  `INTERFACE_ID` varchar(25) NOT NULL,
  `INTERFACE_TYPE` int(11) NOT NULL DEFAULT '1',
  `DESTINATION_PORT` bigint(20) DEFAULT NULL,
  `CAMPAIGN_ID` bigint(20) NOT NULL,
  `SMSC_ID` tinyint(4) NOT NULL DEFAULT '0',
  `FORMAT` tinyint(4) DEFAULT NULL,
  `OPTIONAL_PARAM` varchar(200) DEFAULT NULL,
  `USSD_OPCODE` int(11) DEFAULT NULL,
  PRIMARY KEY (`REQUEST_ID`),
  KEY `NEW_IDX_GMAT` (`RESPONSE_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gmat_message_store`
--

LOCK TABLES `gmat_message_store` WRITE;
/*!40000 ALTER TABLE `gmat_message_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `gmat_message_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gmat_message_store_1`
--

DROP TABLE IF EXISTS `gmat_message_store_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gmat_message_store_1` (
  `RESPONSE_ID` bigint(20) NOT NULL,
  `REQUEST_ID` bigint(20) NOT NULL,
  `ORIGINATING_NUMBER` varchar(15) NOT NULL,
  `DESTINATION_NUMBER` varchar(15) NOT NULL,
  `MESSAGE_TEXT` text NOT NULL,
  `SUBMIT_TIME` datetime DEFAULT NULL,
  `MESSAGE_TYPE` int(11) DEFAULT '1',
  `LANGUAGE` tinyint(4) DEFAULT '1',
  `UDH` varchar(50) DEFAULT NULL,
  `STATUS_REPORT` tinyint(4) DEFAULT '0',
  `DATA_CODING_SCHEME` tinyint(4) DEFAULT '0',
  `PROTOCOL_IDENTIFIER` tinyint(4) DEFAULT '0',
  `PRIORITY` tinyint(4) DEFAULT '0',
  `CHARGING_CODE` tinyint(4) DEFAULT '-1',
  `STATUS` varchar(2) NOT NULL,
  `VALIDITY_PERIOD` int(11) DEFAULT NULL,
  `MESSAGE_ID` bigint(20) DEFAULT NULL,
  `INTERFACE_ID` varchar(25) DEFAULT NULL,
  `INTERFACE_TYPE` int(11) DEFAULT NULL,
  `DESTINATION_PORT` bigint(20) DEFAULT NULL,
  `CAMPAIGN_ID` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gmat_message_store_1`
--

LOCK TABLES `gmat_message_store_1` WRITE;
/*!40000 ALTER TABLE `gmat_message_store_1` DISABLE KEYS */;
/*!40000 ALTER TABLE `gmat_message_store_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gmat_smsc_config`
--

DROP TABLE IF EXISTS `gmat_smsc_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gmat_smsc_config` (
  `SMSC_ID` smallint(6) NOT NULL,
  `SMSC_PORT` int(11) NOT NULL,
  `SMSC_IP` varchar(15) NOT NULL,
  `SMSC_USER_ID` varchar(15) DEFAULT NULL,
  `SMSC_PASSWORD` varchar(15) DEFAULT NULL,
  `NO_OF_CONNECTIONS` smallint(6) NOT NULL,
  `SYSTEM_TYPE` varchar(20) DEFAULT NULL,
  `CLIENT_TYPE` varchar(3) DEFAULT NULL,
  `STATUS` varchar(1) DEFAULT NULL,
  `TON` smallint(6) DEFAULT NULL,
  `NPI` smallint(6) DEFAULT NULL,
  `ADDRESS_RANGE` varchar(20) DEFAULT NULL,
  `SPEED` smallint(6) DEFAULT NULL,
  `WINDOW_SIZE` smallint(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gmat_smsc_config`
--

LOCK TABLES `gmat_smsc_config` WRITE;
/*!40000 ALTER TABLE `gmat_smsc_config` DISABLE KEYS */;
INSERT INTO `gmat_smsc_config` VALUES (1,8056,'10.168.3.52','avinash','avinash',1,'SMPP3.4','TR','A',1,1,'255',1,500);
/*!40000 ALTER TABLE `gmat_smsc_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keyword_code_report`
--

DROP TABLE IF EXISTS `keyword_code_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keyword_code_report` (
  `REQUEST_DATE` datetime DEFAULT NULL,
  `KEYWORD_NAME` varchar(30) DEFAULT NULL,
  `SHORT_CODE` varchar(15) DEFAULT NULL,
  `MSISDN` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keyword_code_report`
--

LOCK TABLES `keyword_code_report` WRITE;
/*!40000 ALTER TABLE `keyword_code_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `keyword_code_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lbs_templates`
--

DROP TABLE IF EXISTS `lbs_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lbs_templates` (
  `TEMPLATE_ID` smallint(6) NOT NULL DEFAULT '0',
  `TEMPLATE_TYPE` smallint(6) DEFAULT NULL,
  `TEMPLATE_MESSAGE` text,
  `TOKENS_ALLOWED` varchar(200) DEFAULT NULL,
  `TEMPLATE_DESCRIPTION` varchar(200) DEFAULT NULL,
  `LANGUAGE_ID` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`TEMPLATE_ID`,`LANGUAGE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lbs_templates`
--

LOCK TABLES `lbs_templates` WRITE;
/*!40000 ALTER TABLE `lbs_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `lbs_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_gtw_log`
--

DROP TABLE IF EXISTS `sms_gtw_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms_gtw_log` (
  `TIME_STAMP` datetime DEFAULT NULL,
  `SEQ_NUM` bigint(20) DEFAULT NULL,
  `ORG_NUM` varchar(20) DEFAULT NULL,
  `DEST_NUM` varchar(20) DEFAULT NULL,
  `MSG_TXT` varchar(400) DEFAULT NULL,
  `SMSC_ID` varchar(20) DEFAULT NULL,
  `CAMP_ID` varchar(10) DEFAULT NULL,
  `RESPONSE_TIME` datetime DEFAULT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `CDR_STATUS` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_gtw_log`
--

LOCK TABLES `sms_gtw_log` WRITE;
/*!40000 ALTER TABLE `sms_gtw_log` DISABLE KEYS */;
INSERT INTO `sms_gtw_log` VALUES ('2018-02-22 16:34:51',13,'3001','249123035087','This is a test message for testing.Thankumessage for testing.Thankumessage for testing.Thankumessage for testing.Thankumessage for testing.Thankumessage f','48A9F320','0',NULL,'NA','N'),('2018-02-22 16:34:51',23,'3001','249123035087','or testing.Thankumessage for testing.Thankumessage for testing.Thankumessage for testing.Thanku','6B38C550','0',NULL,'NA','N');
/*!40000 ALTER TABLE `sms_gtw_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsg_gw_seq`
--

DROP TABLE IF EXISTS `smsg_gw_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smsg_gw_seq` (
  `seq_number` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`seq_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsg_gw_seq`
--

LOCK TABLES `smsg_gw_seq` WRITE;
/*!40000 ALTER TABLE `smsg_gw_seq` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsg_gw_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsg_keyword_master`
--

DROP TABLE IF EXISTS `smsg_keyword_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smsg_keyword_master` (
  `KEYWORD_ID` int(11) DEFAULT NULL,
  `KEYWORD_NAME` varchar(30) NOT NULL,
  `SHORT_CODE` varchar(15) DEFAULT NULL,
  `URL` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsg_keyword_master`
--

LOCK TABLES `smsg_keyword_master` WRITE;
/*!40000 ALTER TABLE `smsg_keyword_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsg_keyword_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsg_sms_request_mdr`
--

DROP TABLE IF EXISTS `smsg_sms_request_mdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smsg_sms_request_mdr` (
  `REQUEST_ID` bigint(20) NOT NULL,
  `MSISDN` varchar(15) DEFAULT NULL,
  `COMMAND` varchar(30) DEFAULT NULL,
  `MESSAGE_TEXT` text,
  `REQUEST_TIME` datetime DEFAULT NULL,
  `REQUEST_TYPE` varchar(4) DEFAULT NULL,
  `SUBSCRIBER_TYPE` varchar(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsg_sms_request_mdr`
--

LOCK TABLES `smsg_sms_request_mdr` WRITE;
/*!40000 ALTER TABLE `smsg_sms_request_mdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsg_sms_request_mdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsg_sms_response_mdr`
--

DROP TABLE IF EXISTS `smsg_sms_response_mdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smsg_sms_response_mdr` (
  `SUBMIT_TIME` datetime DEFAULT NULL,
  `REQUEST_ID` int(10) DEFAULT NULL,
  `RESPONSE_ID` int(10) DEFAULT NULL,
  `ORG_NUM` varchar(15) NOT NULL,
  `DEST_NUM` varchar(15) NOT NULL,
  `MSG_TXT` varchar(400) NOT NULL,
  `CAMP_ID` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsg_sms_response_mdr`
--

LOCK TABLES `smsg_sms_response_mdr` WRITE;
/*!40000 ALTER TABLE `smsg_sms_response_mdr` DISABLE KEYS */;
INSERT INTO `smsg_sms_response_mdr` VALUES ('2018-02-22 16:35:25',3,0,'3001','249123035087','This is a test message for testing.Thankumessage for testing.Thankumessage for testing.Thankumessage for testing.Thankumessage for testing.Thankumessage for testing.Thankumessage for testing.Thankumessage for testing.Thankumessage for testing.Thanku',0);
/*!40000 ALTER TABLE `smsg_sms_response_mdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsg_sms_response_mdr_old`
--

DROP TABLE IF EXISTS `smsg_sms_response_mdr_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smsg_sms_response_mdr_old` (
  `RESPONSE_ID` bigint(20) NOT NULL,
  `REQUEST_ID` bigint(20) DEFAULT NULL,
  `MSISDN` varchar(15) DEFAULT NULL,
  `MESSAGE_TEXT` text,
  `RESPONSE_TIME` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsg_sms_response_mdr_old`
--

LOCK TABLES `smsg_sms_response_mdr_old` WRITE;
/*!40000 ALTER TABLE `smsg_sms_response_mdr_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsg_sms_response_mdr_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test` (
  `roll` int(10) NOT NULL,
  PRIMARY KEY (`roll`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
INSERT INTO `test` VALUES (1),(2),(3),(4),(5),(6);
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test1`
--

DROP TABLE IF EXISTS `test1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test1` (
  `roll` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test1`
--

LOCK TABLES `test1` WRITE;
/*!40000 ALTER TABLE `test1` DISABLE KEYS */;
INSERT INTO `test1` VALUES (1),(2),(3);
/*!40000 ALTER TABLE `test1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `url_mapping`
--

DROP TABLE IF EXISTS `url_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `url_mapping` (
  `CODE` varchar(15) DEFAULT NULL,
  `URL` text,
  `ID` bigint(20) DEFAULT NULL,
  `COUNTRY_CODE` smallint(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `url_mapping`
--

LOCK TABLES `url_mapping` WRITE;
/*!40000 ALTER TABLE `url_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `url_mapping` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-22 16:44:11
