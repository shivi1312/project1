create sequence GMAT_REQUEST_ID_SEQ start with 1 maxvalue 99999999 minvalue 1 cache 20 increment by 2;                                                                                                                                                                                         
create sequence GMAT_RESPONSE_ID_SEQ start with 2 maxvalue 99999999 minvalue 1 cache 20 increment by 2;                                                                                                                                                                                       
create sequence SMSG_MESSAGE_ID start with 261 maxvalue 99999999 minvalue 1 cache 20 increment by 1;                                                                                                                                                                                                 
create sequence SMS_SEQNUM start with 161 maxvalue 2147483647 minvalue 1 cache 20 increment by 2;                                                                                                                                                                                                    
exit;

