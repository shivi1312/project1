#!/bin/sh
. $HOME/.bash_profile


sqlplus smsg/smsg@mastera  << EOF >>/home/portal/development/SMSGateway_JAVA/procedure/SmsGatewayReportProcedure.out

select sysdate from dual;
set serveroutput on;
exec SmsGatewayReportProcedure;

quit;
EOF
