create or replace Procedure SmsGatewayReportProcedure as
	L_COUNT number(10);
	L_STATUS varchar2(20);
	L_ORG_NUM varchar2(20);		  
	L_CAMP_ID number(10);
	
	cursor entry_check_cursor is select count(*) as entry_count from GMAT_SMS_REPORT where trunc(SM_DATE)=trunc(sysdate-1);	
	cursor report_cursor is select count(*) as COUNT,STATUS,ORG_NUM,CAMP_ID from sms_gtw_log_history where trunc(time_stamp)=trunc(sysdate-1) group by status,ORG_NUM,CAMP_ID order by ORG_NUM;

BEGIN
	
	dbms_output.put_line('procedure  SmsGatewayReportProcedure started ['||sysdate||'] ');
	open entry_check_cursor;
	Loop
		fetch entry_check_cursor into L_COUNT;
		if(L_COUNT>0) then
			dbms_output.put_line('report already exist for ['||trunc(sysdate-1)||']');
                        exit;
		else
			open report_cursor;
			Loop
                	fetch report_cursor into L_COUNT,L_STATUS,L_ORG_NUM,L_CAMP_ID;
                		EXIT WHEN report_cursor%notfound;
                		dbms_output.put_line('timestamp='||trunc(sysdate-1)||' L_COUNT='||L_COUNT||' L_STATUS='||L_STATUS||' L_ORG_NUM='||L_ORG_NUM||' CAMP_ID='||L_CAMP_ID);
                
                		insert into GMAT_SMS_REPORT(CREATE_DATE,SM_DATE,SHORT_CODE,SM_COUNT,SM_STATUS,SM_TYPE,CAMPAIGN_ID) values (sysdate,trunc(sysdate-1),L_ORG_NUM,L_COUNT,L_STATUS,0,L_CAMP_ID);

        		end Loop;
			close report_cursor;
        		commit;

		end if;
	end Loop;
	close entry_check_cursor;

	dbms_output.put_line('procedure  SmsGatewayReportProcedure ends['||sysdate||'] ');
END SmsGatewayReportProcedure;

/
show errors;
quit;

--SQL> SET SERVEROUTPUT ON;
--SQL> exec SmsGatewayReportProcedure;
