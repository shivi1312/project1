package com.telemune.listener;

import org.apache.logging.log4j.LogManager;import org.apache.logging.log4j.Logger;
import org.telemune.plivo.RequestBean;

import com.telemune.vcc.expiringmap.ExpirationListener;


public class ParserListener implements ExpirationListener<String, RequestBean> {
    Logger logger = LogManager.getLogger(ParserListener.class);
	@Override
	public void expired(String key, RequestBean value) {
		//logger.info("Expiring key: "+key+" value "+value);
                value.getActionMap().clear();
                value.getLangMap().clear();
                value.getMap().clear();
                value.varMap.clear();
                value.getLinkMap().clear();
                value = null;
                
	}
}