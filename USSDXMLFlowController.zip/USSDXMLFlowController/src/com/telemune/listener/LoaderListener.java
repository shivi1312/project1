package com.telemune.listener;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.telemune.plivo.VoiceXMLReader;

import com.telemune.vcc.expiringmap.ExpirationListener;
public class LoaderListener implements ExpirationListener<String, VoiceXMLReader> 
{
    Logger logger = LogManager.getLogger(LoaderListener.class);
	
    public void expired(String key, VoiceXMLReader value) 
    {
    	logger.info("Expiring Map for "+key+" value "+value);
    	value = null;
            
    }
}


