package org.telemune.web;



import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.logging.log4j.web.*;
public class Log4JInit  implements ServletContextListener{

	private Log4JInit listener = 
            new Log4JInit();
	String logPath = System.getenv("LOGGER_FILE_PATH");

@Override
public void contextInitialized(ServletContextEvent event) {
	System.out.print("Init logs"+logPath+"/USSDADVLog4j_XMLParser.properties");
String loggerPath = logPath+"/USSDADVLog4j_XMLParser.properties";
event.getServletContext().setInitParameter(
           Log4jWebSupport.LOG4J_CONFIG_LOCATION, 
           loggerPath);
listener.contextInitialized(event);

}

@Override
public void contextDestroyed(ServletContextEvent event) {
listener.contextDestroyed(event);
}
}
