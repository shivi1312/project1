package org.telemune.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LoggerContext;
import org.telemune.plivo.RequestBean;
import org.telemune.plivo.ShortCodeConfig;
import org.telemune.plivo.UssdXmlGenerator;
import org.telemune.plivo.VoiceXMLReader;
import org.w3c.dom.Document;

import FileBaseLogging.FileLogWriter;

import com.telemune.listener.ParserListener;
import com.telemune.vcc.expiringmap.ExpiringMap;

/**
 * Servlet implementation class USSDControlServlet
 */
public class UssdControlServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	//protected ConcurrentHashMap<String, RequestBean> beanMap = null;
	protected static ExpiringMap<String, RequestBean> beanMap = null;
	public ArrayList<String> attributeList = null;
	public static ConcurrentHashMap<String, VoiceXMLReader> VoiceReaderMap = null;
	public ConcurrentHashMap<String, HttpClient> HttpReaderMap = null;
	public String actionType;

	public boolean first = false;
	Properties chrPro = null;
	public String ip;
	public String general_Ip;
	public String port;
	public String general_Port;
	public static String seprator;
	public static Logger logger = LogManager.getLogger(UssdControlServlet.class);
	public String db_url;
	public String db_user;
	public String db_pass;
	Connection con = null;
	public String fileWrite;
	public String callLogPath;
	public String callFileInterval;
	public String callFileName;
	public String callArcName;
	public StringBuffer callDigInfo = null;
	public String soTimeout;
	public String conTimeout;
	public String conManTimeout;
	public static int cacheExpireTime=0;
	
	boolean cCheck = false;

	UssdXmlGenerator ussdGenerator;
	FileLogWriter flw = null;
	
	ShortCodeConfig shortcodeConfig;
	public static ConcurrentHashMap<String, ShortCodeConfig> appShort = null;
	private static LinkedHashMap<String, String> defaultShortCode = null;
	public static ConcurrentHashMap<String, String> ussdMenuMsg = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UssdControlServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void init() {
		try {
			System.out
					.println("--------- INITIAL PROCESS START FOR USSD REQUEST ---------------------");
			chrPro = new Properties();
			try {

				String propPath = System.getenv("PROPERTY_FILE_PATH");
				String logPath = System.getenv("LOGGER_FILE_PATH");
				FileInputStream fins = null;
				System.setProperty("log4j2.configurationFile",logPath+"/USSDADVLog4j_XMLParser.xml");
				//PropertyConfigurator.configure(logPath + File.separatorChar
					//	+ "USSDADVLog4j_XMLParser.properties");
				// context = (org.apache.logging.log4j.core.LoggerContext) LogManager.getContext(false);
				File file = new File(logPath+"/USSDADVLog4j_XMLParser.xml");
				System.out.print(logPath+"/USSDADVLog4j_XMLParser.xml");

				// this will force a reconfiguration
				//context.setConfigLocation(file.toURI());
				LoggerContext context = (LoggerContext)LogManager.getContext(false);
			     context.setConfigLocation(file.toURI());
			     context.reconfigure();
				fins = new FileInputStream(propPath + File.separatorChar
						+ "USSDADVXML_Parser.properties");
				chrPro.load(fins);
				ip = chrPro.getProperty("IP");
				general_Ip = chrPro.getProperty("generalIp");
				port = chrPro.getProperty("Port");
				general_Port = chrPro.getProperty("generalPort");
				seprator = chrPro.getProperty("Seprator");
				db_url = chrPro.getProperty("db_url");
				db_user = chrPro.getProperty("db_user");
				db_pass = chrPro.getProperty("db_pass");
				fileWrite = chrPro.getProperty("fileWrite");
				callLogPath = chrPro.getProperty("callLogPath");
				callFileInterval = chrPro.getProperty("callFileInterval");
				callFileName = chrPro.getProperty("callFileName");
				callArcName = chrPro.getProperty("callArcName");
				soTimeout = chrPro.getProperty("soTimeout");
				conTimeout = chrPro.getProperty("conTimeout");
				conManTimeout = chrPro.getProperty("conManTimeout");
				cacheExpireTime=Integer.parseInt(chrPro.getProperty("CACHE_EXPIRE_TIME", "30"));
				logger.info("got IP: " + ip + " port " + port + " seprator: "
						+ seprator + " db_url " + db_url + " db_user "
						+ db_user + " db_pass " + db_pass + "FileWrite"
						+ fileWrite + "Call Log Path" + callLogPath
						+ "calllog Namefile [" + callFileName
						+ "] callFileInterval [" + callFileInterval
						+ "] callArcName [" + callArcName + "]");

				fins.close();

				if (fileWrite.equals("1")) {
					flw = new FileLogWriter();
					logger.info("### File Log Writer is Now : " + flw);
					flw.setNewFileInterval(Integer.parseInt(callFileInterval));
					flw.setFilename(callFileName);
					flw.setFilePath(callLogPath);
					flw.setArchiveFilePath(callLogPath);
					flw.setArchiveFilename(callArcName);
					flw.initialize();
				}
			} catch (IOException ioe) {
				logger.fatal("unable to load Property file:" + ioe.getMessage());
				ioe.printStackTrace();

			}

			appShort = new ConcurrentHashMap<String, ShortCodeConfig>();
			loadXmlData();
			loadUssdMenuData();

		} catch (Exception e) {
			logger.fatal("Error in Init block =====" + e.toString());
			e.printStackTrace();
			loadXmlData();
			logger.fatal("##### Reload Data Again #####");
		}
		System.out
				.println("----- INTIAL USSD PROCESS SUCCESSFULLY COMPLETED ---");
	}

	public void loadXmlData() {
		logger.info("#### loadXmlData() function Starts ###");
		appShort.clear();
		if (appShort == null) {
			appShort = new ConcurrentHashMap<String, ShortCodeConfig>();
			logger.debug("#### AppShort Map is null so make new in loadxml() ####");
		}
		String scode = "";
		String shortcode = "";
		String mode = "";
		String appName = "";
		String addDigits = "";
		String query = "select App_Id,ShortCode,Mode,App_Name,AdditionalDigits from Application_List where isActive=?";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(db_url, db_user, db_pass);
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, "Active");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {

				shortcodeConfig = new ShortCodeConfig(rs.getString("App_Id"),
						rs.getString("ShortCode"),
						rs.getString("AdditionalDigits"), rs.getString("Mode"));
				if (rs.getString("AdditionalDigits").equals("NA")
						|| rs.getString("AdditionalDigits").equals("DF")) {
					logger.debug("App Id put is [" + rs.getString("App_Id")
							+ "#" + rs.getString("AdditionalDigits")
							+ "] App Name [" + rs.getString("App_Name") + "]");
					appShort.put(
							rs.getString("App_Id") + "#"
									+ rs.getString("AdditionalDigits"),
							shortcodeConfig);
				} else {
					logger.debug("App Id put is [" + rs.getString("App_Id")
							+ "#] App Name [" + rs.getString("App_Name") + "]");
					appShort.put(rs.getString("App_Id") + "#", shortcodeConfig);
				}
				logger.info("App_ID [" + rs.getString("App_Id")
						+ "] ShortCode [" + rs.getString("ShortCode")
						+ "] App Name [" + rs.getString("App_Name")
						+ "] Mode [" + rs.getString("Mode")
						+ "] AdditionalDigits ["
						+ rs.getString("AdditionalDigits") + "]");
			}
			try {
				pstmt.close();
				rs.close();
			} catch (Exception e) {
				logger.fatal("Exception in PreparedStatement Close "
						+ e.toString());
				e.printStackTrace();
			}
		} catch (Exception e) {
			logger.fatal("Exception from MYSQL CONNECTION IN INIT METHOD ##"
					+ e.getMessage());
			e.printStackTrace();
		}
		logger.debug(" number of total active apps [" + appShort.size() + "]");
		try {
			HttpReaderMap = new ConcurrentHashMap<String, HttpClient>();
			VoiceReaderMap = new ConcurrentHashMap<String, VoiceXMLReader>();
			//beanMap = new ConcurrentHashMap<String, RequestBean>();
			 beanMap = ExpiringMap.builder().expirationListener(new ParserListener())
						.variableExpiration().expiration(UssdControlServlet.cacheExpireTime, TimeUnit.MINUTES).build();
		} catch (Exception ioe) {
			logger.error(ioe.getStackTrace().toString());
			ioe.printStackTrace();
			logger.fatal("unable to load property file " + ioe.getMessage());
		}

		try {
			for (Map.Entry<String, ShortCodeConfig> entry : appShort.entrySet()) {
				String Serv_Id = entry.getKey();
				ShortCodeConfig shortConfig = entry.getValue();
				String shortcode1 = shortConfig.getShortCode();
				String mode1 = shortConfig.getDirection();
				String adddigdata = shortConfig.getAddCode();
				String shortcod;
				if (adddigdata.equals("NA") || adddigdata.equals("DF")) {
					shortcod = shortcode1 + mode1;
				} else {
					shortcod = shortcode1 + mode1 + adddigdata.length();
				}
				logger.debug("#### XML pick for VXReader Instance #### ["
						+ shortcod + "]");
				createVxReaderInstance1(Serv_Id, shortcod, con);
			}
		} catch (Exception ex) {
			logger.error(ex.getStackTrace().toString());
			ex.printStackTrace();
			logger.fatal("unable to create instance of VxReader "
					+ ex.getMessage());

		} finally {
			try {
				if (con != null) {
					con.close();
					logger.info("==== Connection Closed ====");
				}

			} catch (Exception e) {
				logger.fatal("Error in connection Close... PlivoServleettt "
						+ e.toString());
				e.printStackTrace();
			}
		}
		logger.info("### loadXmlData() ends here ###");
	}

	public void loadUssdMenuData() {
		logger.info("# Inside loadUssdMenuData method ");
		if (ussdMenuMsg == null) {
			ussdMenuMsg = new ConcurrentHashMap<String, String>();
			logger.info("# ussdMenuMsg Map is null so new One is Created ");
		}
		Connection con1 = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs1 = null;
		String msgQuery = "select menuName,menuText,appName,langId from USSD_MENU_MSG";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con1 = DriverManager.getConnection(db_url, db_user, db_pass);
			pstmt1 = con1.prepareStatement(msgQuery);
			rs1 = pstmt1.executeQuery();
			while (rs1.next()) {
				logger.info("# appName is [" + rs1.getString("appName")
						+ "] menuName [" + rs1.getString("menuName")
						+ "] langId [" + rs1.getString("langId")
						+ "] menuText [" + rs1.getString("menuText") + "]");
				ussdMenuMsg.put(
						rs1.getString("appName") + "-"
								+ rs1.getString("langId") + "-"
								+ rs1.getString("menuName"),
						rs1.getString("menuText"));
			}
			
			logger.info("# Ussd Menu loaded Successfully in Map ");
			
			/*Iterator it = ussdMenuMsg.entrySet().iterator();
		    while (it.hasNext()) {
		        Map.Entry pair = (Map.Entry)it.next();
		        logger.info("Iterater >> "+pair.getKey() + " = " + pair.getValue());
		        it.remove();
		    }*/

		} catch (Exception exep) {
			logger.fatal("# Exception in loadUssdMenudata()", exep);
			exep.printStackTrace();
		} finally {
			try {
				if (rs1 != null) {
					rs1.close();
				}
				if (pstmt1 != null) {
					pstmt1.close();
				}
				if (con1 != null) {
					con1.close();
				}
			} catch (Exception ee) {
				logger.fatal("# Error in loadUssdMenuDetails in closing conncetion[ "
						+ ee.getMessage() + "]");
				ee.printStackTrace();
			}
		}

	}

	public ConcurrentHashMap<String, String> LoadLangParameter(String callUUID,
			ConcurrentHashMap<String, String> langMap, VoiceXMLReader vxReader) {
		logger.info("#### LoadLangParameter() starts here ####");
		try {
			langMap = vxReader.getXmlLangOrVarMap(callUUID,
					vxReader.langXmlQuery, vxReader.langAttrib1,
					vxReader.langAttrib2);

		} catch (Exception ex) {
			logger.fatal("["
					+ callUUID
					+ "] EXCEPTION IN SERVLET CONTROL INTI : while loading langMap"
					+ ex.toString());
			logger.error(ex.getStackTrace().toString());
			ex.printStackTrace();
		} finally {

			logger.info("#### LoadLangParameter() ens here ####");
			return langMap;
		}
	}

	public synchronized void createHttpClientInstance(String callUUID,
			String calledNum, ConcurrentHashMap<String, String> varMap) {
		logger.info("[" + callUUID
				+ "] #createHttpClientInstance() starts here ");
		if (!HttpReaderMap.containsKey(calledNum)) // start of loop 1
		{
			try {

				String http_ip = "";
				int http_port = 0;
				if (varMap.containsKey("hit_ip")) {
					http_ip = varMap.get("hit_ip");
					logger.info("[" + callUUID + "] varMap contain hit_ip: ["
							+ http_ip + "]");
					if (http_ip == null || http_ip.length() <= 0) {
						http_ip = general_Ip;
						logger.debug("["
								+ callUUID
								+ "] due to null or zero length,using general_Ip as hit_ip ["
								+ http_ip + "]");
					}
				} else {
					http_ip = general_Ip;
					logger.info("["
							+ callUUID
							+ "] varMap does not contain hit_ip as key httpIP ["
							+ http_ip + "] generalIP [" + general_Ip + "]");
				}

				if (varMap.containsKey("hit_port")) {
					String http_port_s = varMap.get("hit_port");
					logger.debug("[" + callUUID
							+ "] varMap contain hit_port: [" + http_port_s
							+ "]");

					if (http_port_s == null || http_port_s.length() <= 0) {
						http_port = Integer.parseInt(general_Port);
						logger.debug("["
								+ callUUID
								+ "] due to null or zero length,using general_Port as hit_port ["
								+ http_port + "]");
					} else {
						http_port = Integer.parseInt(http_port_s);
						logger.info("[" + callUUID + "]  hit_port 1 ["
								+ http_port + "]");
					}
				} else {
					http_port = Integer.parseInt(general_Port);
					logger.info("["
							+ callUUID
							+ "] varMap does not contain hit_port as key hit_port ["
							+ http_port + "] generalPort: [" + general_Port
							+ "]");
				}

				SchemeRegistry schemeRegistry = new SchemeRegistry();
				schemeRegistry.register(new Scheme("http", http_port,
						PlainSocketFactory.getSocketFactory()));

				PoolingClientConnectionManager cm = new PoolingClientConnectionManager(
						schemeRegistry);

				cm.setMaxTotal(300);
				cm.setDefaultMaxPerRoute(20);
				HttpHost localhost = new HttpHost(http_ip, http_port);
				cm.setMaxPerRoute(new HttpRoute(localhost), 250);

				HttpClient _httpClient = new DefaultHttpClient(cm);
				HttpParams _httpPramas = _httpClient.getParams();
				_httpPramas.setIntParameter(CoreConnectionPNames.SO_TIMEOUT,
						Integer.parseInt(soTimeout));
				_httpPramas.setIntParameter(
						CoreConnectionPNames.CONNECTION_TIMEOUT,
						Integer.parseInt(conTimeout));
				_httpPramas.setLongParameter(ClientPNames.CONN_MANAGER_TIMEOUT,
						Long.parseLong(conManTimeout));
				// _httpClient.setParams(_httpPramas);

				HttpReaderMap.put(calledNum, _httpClient);
			} catch (Exception e) {
				logger.fatal("[" + callUUID
						+ "] Exception in createHttpClientInstance: "
						+ e.toString());
			}
		} // end of loop 2

		logger.info("[" + callUUID
				+ "] #createHttpClientInstance() ends here ####");
	}

	@SuppressWarnings("finally")
	public HttpClient getHttpClientObject(String callUUID,
			HttpClient httpClient, String calledNum,
			ConcurrentHashMap<String, String> varMap) {

		logger.info("[" + callUUID
				+ "] #getHttpClientObject() starts here #### Called Num is ["
				+ calledNum + "]");
		try {

			if (!HttpReaderMap.containsKey(calledNum)) { // start of outer loop

				logger.info("[" + callUUID + "] #Service Id " + calledNum);
				this.createHttpClientInstance(callUUID, calledNum, varMap);
			} // end of loop 1
			logger.debug("[" + callUUID + "] #Service ID  is :" + calledNum);
			httpClient = HttpReaderMap.get(calledNum);
			logger.debug("[" + callUUID
					+ "] Got httpClent conncetion reference");

		} catch (Exception ex) {
			logger.fatal("["
					+ callUUID
					+ "] EXCEPTION IN SERVLET CONTROL INTI : while creating HttpObject"
					+ ex.toString());
			logger.error(ex.getStackTrace().toString());
			ex.printStackTrace();
		} finally {

			logger.info("["
					+ callUUID
					+ "] #getHttpClientObject() ends here #### hhtpclient object is ["
					+ httpClient + "]");
			return httpClient;
		}

	}

	public boolean createVxReaderInstance1(String ServiceId, String calledNum,
			Connection conn) {
		logger.info(" #createVxReaderInstance1() start here ####");
		String ServiceId1 = ServiceId.split("#")[0];
		logger.info("#### Service Id to create Voice Instance is :["
				+ ServiceId1 + "]");
		if (!VoiceReaderMap.containsKey(ServiceId1)) {
			logger.info("[" + calledNum + "]  THREAD LOADING VOICE READER MAP");

			VoiceXMLReader _vxReader = new VoiceXMLReader(ServiceId1,
					calledNum, conn);
			if (_vxReader.parsingSuccess) // checking if true then xml is loaded
											// properly else not
			{
				VoiceReaderMap.put(ServiceId1, _vxReader);
				logger.info("Service Id[" + ServiceId1 + "] ShortCode ["
						+ calledNum
						+ "]  THREAD SUCCESSFULLY LOADED VOICE READER MAP");
			} else
				return false;
		}
		if (!first) {
			first = true;
			// pxGenerator = new PlivoXMLGenerator(ip,port);
			ussdGenerator = new UssdXmlGenerator();
			logger.info("[" + calledNum
					+ "] THREAD SUCCESSFULLY CREATE UssdXmlGenerator");
		}
		logger.info(" #createVxReaderInstance1() ends here ####");
		return true;

	}

	public String getAppIdForCall(String destSC, String direct) {
		logger.info("#getAppIdForCall() starts here ####"+destSC+"Direct="+direct);
		String initSc = "";
		int initScLen = 0;
		String addDigit = "";
		String defautlAppID = null;
		String finalAppID = null;
		String keyIs = "";
		String bkSc = null;
		String finalCheckSc=null;
		for (Map.Entry<String, ShortCodeConfig> entry : appShort.entrySet()) {
			ShortCodeConfig codeBean = entry.getValue();
			if (destSC.equalsIgnoreCase(codeBean.getShortCode())
					&& direct.equalsIgnoreCase(codeBean.getDirection())
					&& (codeBean.getAddCode().equalsIgnoreCase("DF") || codeBean
							.getAddCode().equalsIgnoreCase("NA"))) {

				logger.debug("Direct Case of Short Code= " + destSC);
				finalAppID = entry.getKey().split("#")[0];
				keyIs = entry.getKey();
			}
			if (finalAppID != null) {
				break;
			}
		}
		ShortCodeConfig testBean1 = null;
		ShortCodeConfig testBean2 = null;
		if (finalAppID == null) {
			
			logger.debug("InDirect Case of Short Code= " + destSC);

			for (Map.Entry<String, ShortCodeConfig> entry : appShort.entrySet()) {

				testBean1 = null;
				testBean2 = null;
				ShortCodeConfig codeBean = entry.getValue();
				logger.debug(" " + codeBean);
				if (destSC.startsWith(codeBean.getShortCode())
						&& direct.equalsIgnoreCase(codeBean.getDirection())
						&& (!codeBean.getAddCode().equalsIgnoreCase("NA"))) {
					bkSc = destSC;
					initScLen = codeBean.getShortCode().length();
					initSc = bkSc.substring(initScLen+1, bkSc.length());
					bkSc = bkSc.substring(0, initScLen);
					finalCheckSc=initSc;
					logger.debug("New Dest ID=" + bkSc
							+ "\n Entering into Default ID section!!");
					for (Map.Entry<String, ShortCodeConfig> entry1 : appShort
							.entrySet()) {
						testBean1 = entry1.getValue();
						if (bkSc.equalsIgnoreCase(testBean1.getShortCode())
								&& direct.equalsIgnoreCase(testBean1
										.getDirection())) {
							testBean2 = appShort.get(codeBean.getAppID()
									+ "#DF");
							if (testBean2 != null) {
								logger.info(" Detected Default App ID "
										+ testBean2.getAppID());
								defautlAppID = testBean2.getAppID().split("#")[0];
								keyIs = entry.getKey();
								logger.info(" Default APP ID ASSIGNED="
										+ defautlAppID);
								break;
							}
						}
					}
					if(initSc.endsWith("#"))
					{
						initSc=initSc.substring(0,initSc.length()-1);
					}
					logger.debug("bkSc"+ bkSc + "initSc"+initSc+ ""+codeBean.toString());
					if (bkSc.equalsIgnoreCase(codeBean.getShortCode())
							&& direct.equalsIgnoreCase(codeBean.getDirection())) {
						if (initSc.length() == codeBean.getAddCode().length()) {
							finalAppID = entry.getKey().split("#")[0];
							keyIs = entry.getKey();
							logger.debug(" Addition Code Matched  APP ID taken="
									+ keyIs);
						}
					}
				}
				if (finalAppID != null) {
					break;
				}
			}
			
			if (finalAppID == null) {
				finalAppID = (defautlAppID != null) ? defautlAppID : null;
			}
			if(finalAppID==null)
			{
				
				logger.debug("Checking again for the final test"+destSC+"   check"+bkSc);
				
				if(destSC.endsWith("#"))
				{
					destSC=destSC.substring(0,destSC.indexOf("*",destSC.indexOf("*")+1))+"#";
				}
				logger.debug("Checking again for the final test"+destSC+"   check"+bkSc);
			for (Map.Entry<String, ShortCodeConfig> entry : appShort.entrySet()) {
				ShortCodeConfig codeBean = entry.getValue();
				if (destSC.equalsIgnoreCase(codeBean.getShortCode())
						&& direct.equalsIgnoreCase(codeBean.getDirection())
						&& (codeBean.getAddCode().equalsIgnoreCase("DF") || codeBean
								.getAddCode().equalsIgnoreCase("NA"))) {

					logger.debug("Direct Case of Short Code= " + destSC);
					finalAppID = entry.getKey().split("#")[0];
					keyIs = entry.getKey();
				}
				if (finalAppID != null) {
					break;
				}
			}
			}
		}

		logger.info(" KEY IS =" + finalAppID);
		logger.info("#getAppIdForCall() ends here ####");
		return finalAppID;
	}

	public ConcurrentHashMap<String, String> LoadParameter(String callUUID,
			String calledNum, ConcurrentHashMap<String, String> varMap,
			VoiceXMLReader vxReader) {
		logger.info("[" + callUUID + "] #LoadParameter starts here ####");

		if (!VoiceReaderMap.containsKey(calledNum)) {

		}
		vxReader = VoiceReaderMap.get(calledNum);
		logger.debug("vxReader is now :" + vxReader);

		try {
			logger.info("[" + callUUID + "] #VXreader VarXmlQuery[" + vxReader.varXmlQuery
					+ "] #Attribute1[" + vxReader.varAttrib1 + "] #Attribute2["
					+ vxReader.varAttrib2 + "]");
			varMap = vxReader.getXmlLangOrVarMap(callUUID,
					vxReader.varXmlQuery, vxReader.varAttrib1,
					vxReader.varAttrib2);

		} catch (Exception ex) {
			logger.fatal("[" + callUUID
					+ "] EXCEPTION IN SERVLET CONTROL INTI :" + ex.toString());
			logger.fatal(ex.getStackTrace().toString());
			ex.printStackTrace();
		}

		finally {
			logger.info("[" + callUUID + "] #LoadParameter ends here ####");
			return varMap;
		}

	}

	public String getDefaultShortCodeId(String destSC, String direct) {

		logger.info(" #getDefaultShortCodeId() starts here ####");
		String shortCodeId = null;
		for (Map.Entry<String, ShortCodeConfig> entry3 : appShort.entrySet()) {
			ShortCodeConfig codeBean1 = entry3.getValue();
			if (destSC.startsWith(codeBean1.getShortCode())
					&& direct.equalsIgnoreCase(codeBean1.getDirection())
					&& codeBean1.getAddCode().equalsIgnoreCase("DF")) {

				logger.debug("Direct Case of Short Code= " + destSC);
				shortCodeId = entry3.getKey().split("#")[0];
			}
			if (shortCodeId != null) {
				break;
			}
		}
		logger.debug("####### Default Shortcode is [" + shortCodeId + "]");
		logger.info("#getDefaultShortCodeId() ends here ####");
		return shortCodeId;
	}

	// ======================================== doMyService method
	// ===============================
	public void doMyService(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
		try {
			ConcurrentHashMap<String, String> actionMap = null;
			ConcurrentHashMap<String, String> langMap = null;
			ConcurrentHashMap<String, String> linkMap = null;
			int actionSequence = 0;
			int uid = 0;
			VoiceXMLReader vxReader = null;
			ConcurrentHashMap<String, String> varMap = null;
			ConcurrentHashMap<String, String> varMap1 = null;

			String itemId = "";
			String callingNum = "";// From -- Call initiated from
			String calledNum = "";// To -- Called No.
			String direction = "";
			String callUUID = "";
			String callStatus = "";
			String callDuration = "";
			String shortCode = "";
			String gc_cicId = "";
			String ringTime = "";
			String hangupCause = "";
			HttpClient httpClient = null;
			StringBuffer callDigInfo = new StringBuffer();
			String gc_songId = "";
			String dataReset = request.getParameter("reloadallxml");
			String xmlDocTest=request.getParameter("xmlDocTest");
			String testingAppId=request.getParameter("testAppId");
			String queryTest=request.getParameter("queryTest");
			String paramMapTest=request.getParameter("paramMapTest");
			Hashtable<Integer, String> startInputWithShortCode=null;
			
			
			
			if (dataReset != null && dataReset.equalsIgnoreCase("reloadData")) {
				loadXmlData();
				loadUssdMenuData();
				out.write("XML Reloaded Successfully !!!");
				logger.info("XML reloaded successfully !!!");
				return;
			}
			if(xmlDocTest!=null && xmlDocTest.equalsIgnoreCase("true"))
			{
				if(testingAppId!=null)
				{
					String xmlContent=convertDocumentToString(VoiceReaderMap.get(testingAppId).doc);
					logger.info("XML Content for AppId["+testingAppId+"] "+xmlContent);
					if(xmlContent!=null)
					{
						out.write("XML CONTENT : "+xmlContent);
					}
					else
					{
						out.write("No Xml String Found for APP_ID["+testingAppId+"]");
					}
				}
				else
				{
					logger.info("Please send a valid AppId in Paramter name testAppId.");
					out.write("Please send a valid AppId in Paramter name testAppId.");
				}
				return;
			}
			if(queryTest!=null && queryTest.equalsIgnoreCase("true"))
			{
				String xmlQuery=request.getParameter("xmlQuery");
				if(xmlQuery!=null)
				{
					String attribute1=request.getParameter("attribute1");
					String attribute2=request.getParameter("attribute2");
					if(testingAppId!=null)
					{
						if(attribute1!=null && attribute2!=null)
						{
							try
							{
								ConcurrentHashMap<String,String> testingMap=VoiceReaderMap.get(testingAppId).getXmlLangOrVarMap("TESTING..",
										xmlQuery, attribute1,
										attribute2);
								if(testingMap!=null)
								{
									logger.info("Map "+testingMap+" XMLQuery["+xmlQuery+"] Attribute1["+attribute1+"] Attribute2["+attribute2+"]");
									out.write("Map "+testingMap+" XMLQuery["+xmlQuery+"] Attribute1["+attribute1+"] Attribute2["+attribute2+"]");
								}
							}
							catch(Exception e)
							{
								logger.error("Exception occurred while testing xml query. Error["+e+"]");
								out.write("Exception occurred while testing xml query. Error["+e+"]");
							}
						}
						else
						{
							logger.info("Please send a valid Attributes for XMLQuery["
									+ xmlQuery
									+ "] AppId["+testingAppId+"] in respective parameters named attribute1 and attribute2.");
							out.write("Please send valid Attributes for XMLQuery["
									+ xmlQuery
									+ "] AppId["+testingAppId+"] in respective parameters named attribute1 and attribute2.");
						}
					}
					else
					{
						logger.info("Please send a valid AppId in Paramter name testAppId.");
						out.write("Please send a valid AppId in Paramter name testAppId.");
					}
				}
				else
				{
					logger.info("Please send a valid XMLQuery in paramter name xmlQuery.");
					out.write("Please send a valid XMLQuery in paramter name xmlQuery.");
				}
				return;
			}
			if(paramMapTest!=null && paramMapTest.equalsIgnoreCase("true"))
			{
				String testAction=request.getParameter("testAction");
				String testActionType=request.getParameter("testActionType");
				String testItemId=request.getParameter("testItemId");
				if(testAction!=null && testActionType!=null && testItemId!=null)
				{
					if (testingAppId != null) {
						String testLangId=request.getParameter("testLangId");
						String testFilePath=request.getParameter("testFilePath");
						ConcurrentHashMap<String, String> testingVarMap = new ConcurrentHashMap<String, String>();
						testingVarMap.put("id", "TESTING...");
						if (testLangId != null && testFilePath != null) {
							testingVarMap.put("lang", testLangId);
							testingVarMap.put("FilePath", testFilePath);
						}
						try {
							ConcurrentHashMap<String, Object> testingMap = VoiceReaderMap
									.get(testingAppId).getParamMap(testAction,
											testActionType, testItemId, null,
											testingVarMap);
							if (testingMap != null) {
								
								logger.info("ParamMap : "+testingMap+" Action["
										+ testAction
										+ "] AppId["+testingAppId+"] ActionType["
										+ testActionType
										+ "] ItemId["
										+ testItemId
										+ "] testLangId["+testLangId+"] testFilePath["+testFilePath+"]");
								out.write("ParamMap : "+testingMap+" Action["
									+ testAction
									+ "] AppId["+testingAppId+"] ActionType["
									+ testActionType
									+ "] ItemId["
									+ testItemId
									+ "] testLangId["+testLangId+"] testFilePath["+testFilePath+"]");	
							}
						} catch (Exception e) {
							logger.error("Exception occurred while testing param map. Action["
									+ testAction
									+ "] AppId["+testingAppId+"] ActionType["
									+ testActionType
									+ "] ItemId["
									+ testItemId
									+ "] testLangId["+testLangId+"] testFilePath["+testFilePath+"] Error[" + e + "]");
							out.write("Exception occurred while testing param map. Action["
									+ testAction
									+ "] AppId["+testingAppId+"] ActionType["
									+ testActionType
									+ "] ItemId["
									+ testItemId
									+ "] testLangId["+testLangId+"] testFilePath["+testFilePath+"] Error[" + e + "]");
						}
					}
					else
					{
						logger.info("Please send a valid AppId in Paramter name testAppId.");
						out.write("Please send a valid AppId in Paramter name testAppId.");
					}
				}
				else
				{
					logger.info("Please send a valid Action, ActionType and ItemId in paramter name testAction,testActionType,testItemId respectively.");
					out.write("Please send a valid Action, ActionType and ItemId in paramter name testAction,testActionType,testItemId respectively.");
				}
				return;
			}
			logger.info("[" + request.getParameter("CallUUID")
					+ "] request body: " + request.getRequestURI().toString()
					+ " queryString[ " + request.getQueryString() + "]");
			logger.info("\n\n\nCallUUID: [" + request.getParameter("CallUUID")
					+ "] callStatus: [" + request.getParameter("CallStatus")
					+ "]  callingNumber: [" + request.getParameter("From")
					+ "]  To: [" + request.getParameter("To")
					+ "] Digits Received: [" + request.getParameter("Digits")
					+ "] callDirection: [" + request.getParameter("Direction")
					+ "] hangup cause: [" + request.getParameter("HangupCause")
					+ "] ringTime: [" + request.getParameter("ringTime")
					+ "] gc_ccid: [" + request.getParameter("gc_cicId") + "]");
			if (request.getParameter("To") != null
					&& request.getParameter("CallUUID") != null
					&& request.getParameter("From") != null
					&& request.getParameter("CallStatus") != null) {
				String calluuid = request.getParameter("CallUUID");
				logger.debug("Call UUID Comes IS : " + calluuid);
				if (calluuid.equalsIgnoreCase("")) {
					callUUID = request.getParameter("To");
					logger.info("Call UUID is Now Set as :" + callUUID);

				} else {
					callUUID = new String(request.getParameter("CallUUID")
							.trim());
				}

				if (request.getParameter("gc_cicId") != null) {
					gc_cicId = request.getParameter("gc_cicId").replaceAll(
							"[?]", "");
					logger.debug("[" + callUUID + " gc_cicId [" + gc_cicId
							+ "]");
					if (request.getParameter("gc_cicId").indexOf("Direction=") != -1) {
						String[] gcid_token = gc_cicId.split("Direction=");
						gc_cicId = gcid_token[0];
						direction = gcid_token[1];
					} else {
						direction = request.getParameter("Direction");
					}
				} else {
					logger.info("gc_cicId value receieved is null");
					direction = request.getParameter("Direction");
				}
				logger.debug("[" + callUUID + " gc_cicId [" + gc_cicId
						+ "] direction [" + direction + "]");
				if (direction.equalsIgnoreCase("outbound")) {
					calledNum = request.getParameter("From");
					callingNum = request.getParameter("To");
					if (callingNum.indexOf("#") != -1) {
						String token[] = callingNum.split("#");

						shortCode = token[0];
						callingNum = token[1];
					} else {
						shortCode = calledNum;
					}

					logger.info("[" + callUUID + "] Shortcode: [" + shortCode
							+ "] callingNum [" + callingNum + "] calledNum ["
							+ calledNum + "]");

				} else {
					callingNum = request.getParameter("From");
					calledNum = request.getParameter("To");
					
					shortCode = calledNum;
					logger.info("[" + callUUID + "] Shortcode: [" + shortCode
							+ "] callingNum [" + callingNum + "] calledNum ["
							+ calledNum + "]");
					

				}

				if (callingNum.indexOf("-g") != -1) {
					int index_len = callingNum.indexOf("-g");
					callingNum = callingNum.substring(0, index_len);

				}

				callStatus = request.getParameter("CallStatus");

			}

			if (callStatus.equals("completed")) {
				actionSequence = 0;
				itemId = "#hangup";
				logger.info("[" + callUUID
						+ "] Call Status Complete Item ID set is [" + itemId);
			} else if (callStatus.equals("ringing")) {
				itemId = "#start";
				actionSequence = 0;
				/**
				 * Changes by Ashu to handle multi inputs in single shortcode
				 */
			
				StringTokenizer shortCodeToken=new StringTokenizer(shortCode,"*/#");
				System.out.println(shortCodeToken.countTokens());
				if(shortCodeToken.countTokens()!=1)
				{
					
				
				/*if(shortCode.endsWith("#"))
					shortCode="*"+shortCodeToken.nextElement()+"#";
				else
					shortCode="*"+shortCodeToken.nextElement();
				*/
					shortCodeToken.nextElement();
				startInputWithShortCode=new Hashtable<>();
				int cntr=1;
				
				
				while (shortCodeToken.hasMoreElements())
				{
					//System.out.println(shortCodeToken.nextElement());
					startInputWithShortCode.put(cntr, shortCodeToken.nextElement()+"");
					cntr++;
				}
				
				logger.info(startInputWithShortCode);
				logger.info(shortCode);
				}
				
				
			}
			if (callStatus.equals("ringing")
					&& (beanMap.containsKey(callUUID) == true)) {
				logger.info("["
						+ callUUID
						+ "] # Call Status is ringing but map already contains values so Id removes from Map ["
						+ beanMap.remove(callUUID) + "]");
			}
			if (beanMap.containsKey(callUUID) == false) {
				logger.info("[" + callUUID + "] bean is not containing "
						+ callUUID + " size: [" + beanMap.size() + "]");
				if (direction.equalsIgnoreCase("outbound")) {
					if (!callStatus.equals("completed")) {
						itemId = "#start";
					}
				}

				String serviceId = getAppIdForCall(shortCode, direction);
				logger.info("[" + callUUID + "]# Application Id is ["
						+ serviceId + "]");
				varMap = LoadParameter(callUUID, serviceId, varMap, vxReader);
				httpClient = getHttpClientObject(callUUID, httpClient,
						serviceId, varMap);
				vxReader = VoiceReaderMap.get(serviceId);
				langMap = LoadLangParameter(callUUID, langMap, vxReader);
				logger.info("[" + callUUID + "] #From ["
						+ request.getParameter("From") + "] shortcode ["
						+ shortCode + "] varMap is [" + varMap
						+ "] vxReader is[" + vxReader + "]");
				varMap.put("Id", callUUID);
				varMap.put("callingNum", callingNum);
				varMap.put("calledNum", calledNum);
				varMap.put("callUUID", callUUID);
				if (gc_cicId.length() > 0) {
					varMap.put("gc_cicId", gc_cicId);
				}
				if (request.getParameter("gc_songId") != null) {
					gc_songId = request.getParameter("gc_songId");
					logger.info("### Song ID is : " + gc_songId);
					varMap.put("gc_songId", gc_songId);
				}

				SimpleDateFormat sdf1 = new SimpleDateFormat(
						"dd-MM-yyyy HH:mm:ss");
				String ringtime = sdf1.format(new java.util.Date());
				logger.info("[" + callUUID + "] now ringing ");
				varMap.put("ringTime", ringtime);
				if (fileWrite.equals("1")) {
					logger.info("##### Code Comes here for File Write Info ####");
					logger.info("FileWriter is :" + fileWrite);
					callDigInfo.append(callingNum);
					callDigInfo.append(",");
					callDigInfo.append(callUUID);
					callDigInfo.append(",");
					callDigInfo.append(ringtime);
					logger.debug("#### CallDigInfo now is : " + callDigInfo);
					varMap.put("callDigInfo", callDigInfo + "");
				}

				logger.info("[" + callUUID + "] #ring Time [" + ringtime
						+ "] #callStatus [" + callStatus + "] #callDigInfo ["
						+ callDigInfo + "]");

				if (callStatus.equals("completed")
						|| direction.equalsIgnoreCase("inbound")
						|| direction.equalsIgnoreCase("outbound")) {
					SimpleDateFormat sdf = new SimpleDateFormat(
							"dd-MM-yyyy HH:mm:ss");
					String mydate = sdf.format(new java.util.Date());
					varMap.put("callTime", mydate);
					logger.debug("[" + callUUID + "] callStatus [" + callStatus
							+ "] direction[" + direction + "] callTime["
							+ mydate + "]");
					if (request.getParameter("HangupCause") != null) {
						logger.info("putting hangupcause in varMap");
						varMap.put("hangupCause",
								request.getParameter("HangupCause"));
					}

				}
				if (request.getParameter("Digits") != null) {
					varMap.put("digits", request.getParameter("Digits"));
				}
				if (request.getParameter("RecordFile") != null) {
					varMap.put("recordFile", request.getParameter("RecordFile"));
				}

				RequestBean reqbean = new RequestBean();
				logger.info("[" + callUUID + "] Basic file path ["
						+ langMap.get("1") + "]");
				reqbean.setLangMap(langMap);
				reqbean.setCallUUID(callUUID);
				reqbean.setCalledNum(calledNum);
				reqbean.setCallingNum(callingNum);
				reqbean.setCallStatus(callStatus);
				reqbean.setItemId(itemId);
				reqbean.setActionMap(actionMap);
				reqbean.setMap(varMap);
				reqbean.setActionSequence(actionSequence);
				reqbean.setCallDigInfo(callDigInfo);
				reqbean.setServiceId(serviceId);
				reqbean.setInvalidRetry("0");
				reqbean.setStartInputWithShortCode(startInputWithShortCode);
				if (direction.equalsIgnoreCase("outbound")
						&& callStatus.equalsIgnoreCase("in-progress")) {
					SimpleDateFormat sdf8 = new SimpleDateFormat(
							"dd-MM-yyyy HH:mm:ss");
					String mydate2 = sdf8.format(new java.util.Date());
					varMap.put("callTime", mydate2);

				}

				if (direction.equalsIgnoreCase("outbound")
						&& callStatus.equalsIgnoreCase("ringing")) {
					logger.info("["
							+ callUUID
							+ "] only loading the xml not initiating the process");
				} else {
					doActionEvent(request, response, callUUID, itemId,
							actionSequence, reqbean, vxReader, httpClient, out);
				}
				logger.info("[" + callUUID + "] "
						+ "putting Request bean in Map ");
				if (!callStatus.equalsIgnoreCase("completed") && !reqbean.getItemId().equals("#redirect")) {
					logger.info("### [" + callUUID
							+ "]CAll STATUS First time is Not Completed . ###");
					beanMap.put(callUUID.trim(), reqbean,
							cacheExpireTime, TimeUnit.MINUTES);
				}else if(reqbean.getItemId().equals("#redirect")){
					logger.info("["+callUUID+"] call has been redirected to other Short code So Removing session" );
					beanMap.remove(callUUID);
				}else {
					logger.info("["
							+ callUUID
							+ "] #User Not Respond to call or User unavailable ###");
				}

			} else {
				logger.info("[" + callUUID + "] " + "get info from bean ["
						+ beanMap.size() + "]");
				if (callStatus.equalsIgnoreCase("ringing")
						&& direction.equalsIgnoreCase("outbound")) {
					logger.info("In Bean CallUUID exists but CALL STATUS comes RINGING So this Call is ignored");
				} else {

					RequestBean reqbean = (RequestBean) beanMap
							.remove(callUUID);
					reqbean.setStartInputWithShortCode(null);
					logger.info("[" + callUUID
							+ "] # Service Id for callUUID is ["
							+ reqbean.getServiceId() + "]");

					vxReader = VoiceReaderMap.get(reqbean.getServiceId());
					callDigInfo = reqbean.getCallDigInfo();
					logger.info("[" + callUUID + " #Call Dig Info is :"
							+ callDigInfo);

					if (callStatus.equalsIgnoreCase("completed")) {
						logger.info("[" + callUUID + "] " + "set item id ");
						itemId = "#hangup";
						linkMap = null;
						actionSequence = 0;
						if (reqbean.getLinkMap() != null) {
							reqbean.getLinkMap().put("actionSequence",
									Integer.toString(actionSequence));
						}
						reqbean.setItemId(itemId);
						reqbean.setLinkMap(linkMap);
						if (request.getParameter("HangupCause") != null) {
							logger.info("putting hangupcause in varMap");
							reqbean.getMap().put("hangupCause",
									request.getParameter("HangupCause"));
						}
						try {
							if (fileWrite.equals("1")) {
								flw.writeLog(callDigInfo + "");
								logger.info("Writing in Logs Now CallDigitsInfo -"
										+ callDigInfo);
							}
						} catch (Exception ex1) {
							ex1.printStackTrace();
						}

					} else {

						itemId = reqbean.getItemId();

						actionSequence = reqbean.getActionSequence();
					}

					logger.info("[" + callUUID + "]  item id got from bean: ["
							+ itemId + "]");

					if (request.getParameter("Digits") == null) {
						reqbean.getMap().put("digits", "-1");
					} else {
						reqbean.getMap().put("digits",
								request.getParameter("Digits"));
						if (fileWrite.equals("1")) {
							logger.info("["
									+ callUUID
									+ " # Now Write Digits in CallDigInfo #####");
							callDigInfo.append(",");
							callDigInfo.append(request.getParameter("Digits"));
							logger.info("### CallDigInfo is : " + callDigInfo);
							reqbean.getMap().put("callDigInfo",
									callDigInfo + "");
						}
					}
					if (!reqbean.getMap().containsKey("ringTime")) {
						logger.info("["
								+ callUUID
								+ "] Ring Time is Not Present So default is made");
						SimpleDateFormat sdf1 = new SimpleDateFormat(
								"dd-MM-yyyy HH:mm:ss");
						String mydate1 = sdf1.format(new java.util.Date());
						reqbean.getMap().put("ringTime", mydate1);

						logger.debug("[" + callUUID + "] #RING TIME IS :"
								+ reqbean.getMap().get("ringTime"));

					}

					if (!reqbean.getMap().containsKey("callTime")) {
						logger.info("[" + callUUID
								+ "] now user has pick the call");
						SimpleDateFormat sdf = new SimpleDateFormat(
								"dd-MM-yyyy HH:mm:ss");
						String mydate = sdf.format(new java.util.Date());
						reqbean.getMap().put("callTime", mydate);

						logger.debug("[" + callUUID + "] #CALL TIME IS :"
								+ reqbean.getMap().get("callTime"));

					}

					httpClient = getHttpClientObject(callUUID, httpClient,
							reqbean.getServiceId(), reqbean.getMap());
					reqbean.setCallStatus(callStatus);
					doActionEvent(request, response, callUUID, itemId,
							actionSequence, reqbean, vxReader, httpClient, out);
					if (!reqbean.getCallStatus().equalsIgnoreCase("completed") && !reqbean.getItemId().equalsIgnoreCase("#redirect")) {
						//beanMap.put(callUUID.trim(), reqbean);
						beanMap.put(callUUID.trim(), reqbean,
								cacheExpireTime, TimeUnit.MINUTES);
						logger.info("[" + callUUID
								+ "] Data put in Map After perfoming Action");

					}else if (reqbean.getItemId().equalsIgnoreCase("#redirect")){
						beanMap.remove(callUUID);
						logger.info("### [" + callUUID + "] "
								+ "Redirecting to another shortCode. So Session is removed from Cache !!!");
						reqbean = null;
						callUUID = null;
						callDigInfo = null;
						logger.debug("#### Sucessfully Call Ends ####");	
					} else {
						if (beanMap.containsKey(callUUID)) {
							logger.info("[" + callUUID
									+ "] #Now removing Bean Info ####");
							beanMap.remove(callUUID);
							logger.info("### [" + callUUID + "] "
									+ "Now Info is removed ");
						}
						reqbean = null;
						logger.info("[" + callUUID + "] "
								+ "HANGUP DETECTED REMOVING SESSION INFO ["
								+ callUUID + "]");
						callUUID = null;
						callDigInfo = null;
						logger.debug("#### Sucessfully Call Ends ####");
					}
				}
			}

		} catch (Exception ex) {
			logger.warn("Servlet Generated Exception in doMyService Function "
					+ ex.getMessage());
			logger.error(ex.getStackTrace().toString());
			ex.printStackTrace();
		}
	}// end of service method

	// ======================================== doActionEvent method
	// ===============================
	public void doActionEvent(HttpServletRequest request,
			HttpServletResponse response, String callUUID, String itemId,
			Integer actionSequence, RequestBean bean,/* HttpSession session, */
			VoiceXMLReader vxReader, HttpClient httpClient, PrintWriter out)
			throws ServletException, IOException {
		try {
			if (bean.getItemId().equals("#hangup")) {
				String reqStatus = sendHangupRequest(callUUID, bean, httpClient);
				logger.info("[" + callUUID + "] #Response on Hangup Is ["
						+ reqStatus + "]");
			}else {
				int actSeq = 0;
				ConcurrentHashMap<String, Object> paramMap = null;
				int checkStringInputCntr=1;
				while (true) {
					try {
						if (bean.getLinkMap() != null) {
							logger.info("[" + callUUID
									+ "] link map is not null "
									+ bean.getLinkMap().get("itemId"));
							if (bean.getLinkMap().get("itemId") != null) {
								bean.setItemId(bean.getLinkMap().get("itemId"));
								logger.debug("["
										+ callUUID
										+ "] link map item id "
										+ itemId
										+ " bean.getItemId()"
										+ bean.getItemId()
										+ "value of action sequece "
										+ bean.getLinkMap()
												.get("actionSequence")
												.toString());
								if (itemId.equalsIgnoreCase(bean.getItemId())) {
								} else {
									actSeq = 0;
									actionSequence = Integer.parseInt(bean
											.getLinkMap().get("actionSequence")
											.toString());
								}
							}
						} else {

							logger.info("[" + callUUID
									+ "] link map not containing info ");
						}
					} catch (Exception e) {

						logger.fatal("[" + callUUID
								+ "]  1 exception in do Action event: "
								+ e.getMessage());
						e.printStackTrace();
						break;
					}

					try {
						logger.info("[" + callUUID
								+ "] #Item id to get action #######["
								+ bean.getItemId() + "]");
						bean.setActionMap(vxReader.getActionDetail(
								bean.getItemId(), actionSequence, bean.getMap()));

//						logger.info("[" + callUUID + "] bean after change: "
	//							+ bean.getLangMap().get("1"));
						if (bean.getActionMap() != null
								&& (!bean.getActionMap().isEmpty())) {

							if (bean.getActionMap().get("actionType")
									.equals("ussd")) {

								logger.info("["
										+ bean.getMap().get("Id")
										+ "] USSD ACTION IS UNDER PROCESS  Action Sequence ["
										+ actionSequence + "]");

								paramMap = vxReader.getParamMap(bean
										.getActionMap().get("action"), bean
										.getActionMap().get("actionType"), bean
										.getItemId(), bean.getLangMap(), bean
										.getMap());

								logger.info("[" + callUUID
										+ "] Param Map send for Ussd is ["
										+ paramMap + "]");
								String responseMsg = ussdGenerator.doMyAction(
										request, response, bean.getActionMap(),
										paramMap, bean.getMap(),
										bean.getLangMap(), seprator);
								actionSequence++;

								if (!(bean.getItemId()
										.equalsIgnoreCase("#hangup"))) {
									bean.getLinkMap().put("actionSequence",
											Integer.toString(actionSequence));
									logger.info("["
											+ callUUID
											+ "] # Now item id set in bean from Link Map is ["
											+ bean.getLinkMap().get("itemId")
											+ "]");
									bean.setItemId(bean.getLinkMap().get(
											"itemId"));
								}
								bean.setActionSequence(actionSequence);
								
								//response.setContentType("text/html; charset=UTF-8");
								/**
								 * changes by ashu to handle multi inputs in start shortcode
								 */
								
								if(bean.getStartInputWithShortCode()!=null)
								{
									logger.info("please check"+bean.getStartInputWithShortCode()+checkStringInputCntr+bean.getStartInputWithShortCode().size());	
									if(checkStringInputCntr<=bean.getStartInputWithShortCode().size())
									{
										String digits=bean.getStartInputWithShortCode().get(checkStringInputCntr);
										bean.getMap().put("digits",digits);
										checkStringInputCntr++;
										continue;
									}
								}
								
								response.setCharacterEncoding("UTF-8");
								
								response.getWriter().write(responseMsg);
								logger.info("[" + callUUID
										+ "] Response Send is [" + responseMsg
										+ "]");
								break;

							} else if(bean.getActionMap().get("actionType")
									.equals("redirect")){

								logger.info("["
										+ callUUID
										+ "] Redirect ACTION IS UNDER PROCESS Action Sequence :["
										+ actionSequence + "]");
								paramMap = vxReader.getParamMap(bean
										.getActionMap().get("action"), bean
										.getActionMap().get("actionType"), bean
										.getItemId(), bean.getLangMap(), bean
										.getMap());

								for (Iterator iter = paramMap.entrySet()
										.iterator(); iter.hasNext();) {
									Map.Entry entry = (Map.Entry) iter.next();

									String key = (String) entry.getKey();
									String keyvalue = (String) entry.getValue();
									logger.info("key [" + key + "] value ["
											+ keyvalue + "]");
									if (bean.getMap().containsKey(key)
											&& bean.getMap().containsKey(
													keyvalue)) {
										logger.debug("set key with value from map");
										String interChangeKey = keyvalue;// paramMap.get(key).toString();
										String newKeyVal = bean.getMap().get(
												interChangeKey);
										bean.getMap().put(key, newKeyVal);
									} else if (bean.getMap().containsKey(key)) {
										logger.debug("set key [" + key
												+ "] value [" + keyvalue + "]");
										bean.getMap().put(key, keyvalue);
									}
									actionSequence=0;
									bean.getLinkMap().put("actionSequence",
											Integer.toString(actionSequence));
									logger.info("["
											+ callUUID
											+ "] No more action left to process");
									//bean.getLinkMap().clear();
									bean.setItemId("#redirect");
									String responseMsg = ussdGenerator.doMyAction(
											request, response, bean.getActionMap(),
											paramMap, bean.getMap(),
											bean.getLangMap(), seprator);
									response.setContentType("text/html; charset=utf-8");
									response.setCharacterEncoding("utf-8");
									out.write(responseMsg);
									logger.info("[" + callUUID
											+ "] Response Send is [" + responseMsg
											+ "]");
									
									break;
								} 
							
								
							}else if (bean.getActionMap().get("actionType")
									.equals("INTERNAL")) {
								logger.info("["
										+ callUUID
										+ "] INTERNAL ACTION IS UNDER PROCESS Action Sequence :["
										+ actionSequence + "]");
								paramMap = vxReader.getParamMap(bean
										.getActionMap().get("action"), bean
										.getActionMap().get("actionType"), bean
										.getItemId(), bean.getLangMap(), bean
										.getMap());

								for (Iterator iter = paramMap.entrySet()
										.iterator(); iter.hasNext();) {
									Map.Entry entry = (Map.Entry) iter.next();

									String key = (String) entry.getKey();
									String keyvalue = (String) entry.getValue();
								//	logger.info("key [" + key + "] value ["
									//		+ keyvalue + "]");
									if (bean.getMap().containsKey(key)
											&& bean.getMap().containsKey(
													keyvalue)) {
										logger.debug("set key with value from map");
										String interChangeKey = keyvalue;// paramMap.get(key).toString();
										String newKeyVal = bean.getMap().get(
												interChangeKey);
										bean.getMap().put(key, newKeyVal);
									} else if (bean.getMap().containsKey(key)) {
										logger.debug("set key [" + key
												+ "] value [" + keyvalue + "]");
										bean.getMap().put(key, keyvalue);
									}
								}
								actionSequence++;
								if (actionSequence < Integer.parseInt(bean
										.getActionMap().get("actionSequence"))) {

									bean.getLinkMap().put("actionSequence",
											Integer.toString(actionSequence));
									logger.info("[" + callUUID
											+ "] more action left to process");
									continue;
								} else {
									actionSequence = 0;
									bean.getLinkMap().put("actionSequence",
											Integer.toString(actionSequence));
									logger.info("["
											+ callUUID
											+ "] No more action left to process");
									bean.setLinkMap(vxReader.getNextActionLink(
											bean.getItemId(), bean.getMap(),
											bean.getInvalidRetry()));
									bean.setInvalidRetry(bean.getLinkMap().get(
											"invalidRetry"));
									logger.info("["
											+ callUUID
											+ "] Now Invalid Retry set in Internal Case is ["
											+ bean.getLinkMap().get(
													"invalidRetry") + "]");
								} // beanMap.put(callUUID,bean);
							}

							else if (bean.getActionMap().get("actionType")
									.equals("HTTP")) {
								logger.info("["
										+ callUUID
										+ "] HTTP ACTION IS UNDER PROCESS Action Sequence :"
										+ actSeq);
								String url = "";
								ArrayList<String> paramList = null;
								ArrayList<String> setList = null;

								paramMap = vxReader.getParamMap(bean
										.getActionMap().get("action"), bean
										.getActionMap().get("actionType"), bean
										.getItemId(), bean.getLangMap(), bean
										.getMap());
								Set<String> paramKey = paramMap.keySet();

								for (Iterator<String> param = paramKey
										.iterator(); param.hasNext();) {
									String key = param.next();
									if (key.equals("URL")) {
										url = paramMap.get(key).toString();
									} else if (key.equals("parameter")) {
										paramList = (ArrayList) paramMap
												.get(key);

									} else if (key.equals("set")) {
										setList = (ArrayList) paramMap.get(key);
									}
								}
								logger.debug("[" + callUUID
										+ "] parameter passed to hit http :["
										+ paramList + "]");

								String responseBody = sendRequestAndGetResponsePersistnace(
										url, paramList, request, callUUID,
										bean, httpClient);
								String xpathQuery = "/response/var";

								ConcurrentHashMap<String, String> responseMap = vxReader
										.getResponseMap(callUUID, xpathQuery,
												responseBody);
								String key = "";
								if (setList != null && (!setList.isEmpty())) {
									for (Iterator<String> setItr = setList
											.iterator(); setItr.hasNext();) {
										key = setItr.next();
										if (bean.getMap().containsKey(key)
												&& responseMap.containsKey(key)) {
											bean.getMap().put(key,
													responseMap.get(key));
										}
									}
								}
								if(bean.getActionMap().get("action").equals("durlget"))
								{
									String responseMsg = ussdGenerator.doMyAction(
											request, response, bean.getActionMap(),
											paramMap, bean.getMap(), bean.getLangMap(),
											seprator);
									bean.getMap().put("FilePath", responseMsg);
								}
								
								actionSequence++;
								logger.info("action seq : [" + actionSequence
										+ "]");
								logger.info("This is to test item Id :["
										+ bean.getItemId() + "]");
								if (!(bean.getItemId()
										.equalsIgnoreCase("#hangup"))) { // changes
																			// done
																			// by
																			// alkesh
									logger.info("action seq : [" + actionSequence + "]");
									bean.getLinkMap().put("actionSequence",
											Integer.toString(actionSequence));
								} else {
									logger.info("[" + callUUID
											+ "] # Now Hangup Call break");
									break;
								}
								bean.setActionSequence(actionSequence);
								if (actionSequence < Integer.parseInt(bean
										.getActionMap().get("actionSequence"))) {
									logger.info("[" + callUUID
											+ "] more action left to process");
									continue;
								} else {
									logger.info("["
											+ callUUID
											+ "] No more action left to process");
									actionSequence = 0;
									bean.getLinkMap().put("actionSequence",
											Integer.toString(actionSequence));
									bean.setLinkMap(vxReader.getNextActionLink(
											bean.getItemId(), bean.getMap(),
											bean.getInvalidRetry()));
									bean.setInvalidRetry(bean.getLinkMap().get(
											"invalidRetry"));
									logger.info("["
											+ callUUID
											+ "] Now Invalid Retry set in Http  Case is ["
											+ bean.getLinkMap().get(
													"invalidRetry") + "]");
									logger.info("[" + callUUID
											+ "] Done Find linking ");
								}
							}// end of http section
						} else {
							logger.warn("[" + callUUID
									+ "] No Action is found Reading Links");

							bean.setLinkMap(vxReader.getNextActionLink(
									bean.getItemId(), bean.getMap(),
									bean.getInvalidRetry()));
							actionSequence = 0;
							bean.getLinkMap().put("actionSequence",
									Integer.toString(actionSequence));
							bean.setInvalidRetry(bean.getLinkMap().get(
									"invalidRetry"));
						}
						if ((bean.getLinkMap().get("itemId") == null || bean
								.getLinkMap().get("itemId").equals(""))
								|| bean.getLinkMap().get("itemId")
										.equals("#hangup") || bean.getItemId().equals("#redirect")) {
							break;
						}
						// end of infinite loop section
						if (bean.getLinkMap().get("itemId")
								.equals("#invalidOption")) {
							logger.info("["
									+ callUUID
									+ "] Invalid limit reach now ussdEnd request process ");
							String responseBody = "";
							String msgData = null;
							if (bean.getMap().get("invalidDigit") != null) {
								String data1 = bean.getMap()
										.get("invalidDigit").replace("$", "");

								data1 = data1.replaceAll("lang", bean.getMap()
										.get("lang"));
								data1 = data1.replace("/", "-");
								logger.info("[" + callUUID
										+ "] Invalid Data Message is [" + data1
										+ "]");
								msgData = ussdMenuMsg.get(data1);
								logger.info("[" + callUUID
										+ "] Invalid Msg data is now ["
										+ msgData + "]");
							}
							responseBody += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
									+ "<UssdEnvelop>"
									+ "<Msisdn>"
									+ bean.getMap().get("callingNum")
									+ "</Msisdn>"
									+ "<Message>"
									+ msgData
									+ "</Message>"
									+ "<TransactionId>"
									+ callUUID
									+ "</TransactionId>"
									+ "<TransStatus>0</TransStatus>"
									+ "</UssdEnvelop>";
							response.setCharacterEncoding("utf-8");		
							out.write(responseBody);
							logger.info("[" + callUUID
									+ "] # Response send to ussd gateway is ["
									+ responseBody + "]");
							break;
						}

					} catch (Exception e) {

						logger.fatal("[" + callUUID
								+ "]   2 exception in do Action event: "
								+ e.getMessage());
						e.printStackTrace();
						break;
					}
				}
			} // end of else
		} catch (Exception e) {
			logger.error("[" + callUUID
					+ "] ExceptionDuring Action Generation " + e.toString());
			logger.error(e.getStackTrace().toString());
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}// end of doActionEvent method

	public String sendRequestAndGetResponsePersistnace(String url,
			ArrayList<String> paramList, HttpServletRequest request,
			String callUUID, RequestBean bean, HttpClient httpClient) {
		try {
			String path = "";
			logger.debug("[" + callUUID + "] PARAMETER LIST: [" + paramList
					+ "] VARIABLE MAP: [" + bean.getMap() + "]");
			url = url + "?";
			String paramKey = "";
			for (Iterator<String> itr = paramList.iterator(); itr.hasNext();) {
				paramKey = itr.next();

				if (bean.getMap().containsKey(paramKey)) {
					logger.debug("[" + callUUID + "] key  [" + paramKey
							+ "] value [" + bean.getMap().get(paramKey) + "]");
					if (bean.getMap().get(paramKey).contains(" "))
						url = url+ paramKey	+ "="+ bean.getMap().get(paramKey).replace(" ", "%20");
					else
						url = url+ paramKey+ "="+ URLEncoder.encode(bean.getMap().get(paramKey));

				}
				if (itr.hasNext()) {
					url = url + "&";
				}
			}

		} catch (Exception e) {
			logger.error("[" + callUUID + "] Exception :  " + e.toString());
			logger.error(e.getStackTrace().toString());
			e.printStackTrace();
		}
		logger.info("[" + callUUID + "] ## URL IS GOING TO HIT IS : [" + url
				+ "]");
		HttpGet httpget = new HttpGet(url);
		HttpContext context = new BasicHttpContext();
		HttpEntity entity = null;
		String responseBody = "";
		try {
			HttpResponse response = httpClient.execute(httpget, context);
			entity = response.getEntity();
			responseBody = EntityUtils.toString(entity,"UTF-8");
			responseBody = responseBody.trim();
			logger.info("[" + callUUID + "] " + responseBody);

		} catch (IOException e) {
			logger.error("[" + callUUID + "] IOException :  " + e.toString());
			logger.error(e.getStackTrace().toString());
			e.printStackTrace();
		} catch (Exception e) {
			logger.error("[" + callUUID + "] Exception :  " + e.toString());
			logger.error(e.getStackTrace().toString());
			e.printStackTrace();
		} finally {
			try {
				httpget.releaseConnection();
				EntityUtils.consume(entity);
			} catch (Exception e) {
				logger.error("Error in Entity consume ", e);
			}

			// method.releaseConnection();
		}
		return responseBody;
	}// ========= end of sendRequestAndGetResponsePersistnace =================

	/*
	 * /**
	 * 
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 * response)
	 */
	public String sendHangupRequest(String callUUID, RequestBean bean,
			HttpClient httpClient) {
		logger.info("[" + callUUID + "] # Inside Send Hangup Request");
		String shortCode = bean.getMap().get("calledNum");
		if (shortCode.contains("#")) {
			logger.info("[" + callUUID + "] Shortode contains #");
			shortCode = shortCode.replace("#", "%23");
			logger.info("[" + callUUID + "] Now Shortcode is [" + shortCode
					+ "]");

		}
		String ringTime = bean.getMap().get("ringTime");
		if (ringTime.contains(" ")) {
			logger.info("[" + callUUID + "] Time  contains space");
			ringTime = ringTime.replace(" ", "%20");
			logger.info("[" + callUUID + "] Now RingTime is [" + ringTime + "]");

		}
		/*String urlToHit = "http://" + bean.getMap().get("hit_ip") + ":"
				+ bean.getMap().get("hit_port") + "/"
				+ bean.getMap().get("applicationName")
				+ "/callLogs?callingNum=" + bean.getMap().get("callingNum")
				+ "&calledNum=" + shortCode+"&callUUID="+callUUID+"";*/
		
		
		//This hangup request is specially created for MarketPlace.
		// This hit will change according to respective binary.
		
		String urlToHit = "http://" + bean.getMap().get("hit_ip") + ":"
				+ bean.getMap().get("hit_port") + "/"
				+ bean.getMap().get("applicationName")
				+ "/callLogs?msisdn=" + bean.getMap().get("callingNum")
				+ "&langId=" + bean.getMap().get("langId")
				+ "&shortCode=" + shortCode + "&interface="
				+  bean.getMap().get("interface")+"&requestId=" + callUUID+ "&packBrowseList=" 
				+ bean.getMap().get("packBrowseList")+ "&subType=" + bean.getMap().get("subType")
				+ "&balance=" + bean.getMap().get("balance")+ "&fmsisdn=" + bean.getMap().get("fmsisdn")
				+ "&packPurchaseDetail=" + bean.getMap().get("packPurchaseDetail");
		
		/*String urlToHit = "http://" + bean.getMap().get("hit_ip") + ":"
				+ bean.getMap().get("hit_port") + "/"
				+ bean.getMap().get("applicationName")
				+ "/callLogs?callingNum=" + bean.getMap().get("callingNum")
				+ "&calledNum=" + shortCode +"&callUUID=" + callUUID;
		*/
		
		/*
		String urlToHit = "http://" + bean.getMap().get("hit_ip") + ":"
				+ bean.getMap().get("hit_port") + "/"
				+ bean.getMap().get("applicationName")
				+ "?callingNum=" + bean.getMap().get("callingNum");*/
		
		logger.info("[" + callUUID + "] #url going to hit is [" + urlToHit
				+ "]");
		HttpGet httpget = new HttpGet(urlToHit);
		HttpContext context = new BasicHttpContext();
		HttpEntity entity = null;
		String responseBody = "";
		try {
			HttpResponse response = httpClient.execute(httpget, context);
			entity = response.getEntity();
			responseBody = EntityUtils.toString(entity);
			responseBody = responseBody.trim();
			logger.info("[" + callUUID + "] " + responseBody);

		} catch (IOException e) {
			logger.error("[" + callUUID + "] IOException :  " + e.toString());
			logger.error(e.getStackTrace().toString());
			e.printStackTrace();
		} catch (Exception e) {
			logger.error("[" + callUUID + "] Exception :  " + e.toString());
			logger.error(e.getStackTrace().toString());
			e.printStackTrace();
		} finally {
			try {
				httpget.releaseConnection();
				EntityUtils.consume(entity);
			} catch (Exception e) {
				logger.error("Error in Entity consume ", e);
			}

		}
		return responseBody;
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// synchronized(this){
		doMyService(request, response);
		// }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// synchronized(this){
		doMyService(request, response);
		// }
	}
	
	private static String convertDocumentToString(Document doc) {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer;
        try {
            transformer = tf.newTransformer();
            // below code to remove XML declaration
            // transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
            String output = writer.getBuffer().toString();
            return output;
        } catch (TransformerException e) {
            e.printStackTrace();
        }
        
        return null;
    }
	private  String captureMultiInputs(String shortCode,RequestBean reqBean)
	{
		StringTokenizer shortCodeToken=new StringTokenizer(shortCode,"*/#");
		System.out.println(shortCodeToken.countTokens());
		if(shortCodeToken.countTokens()==1)
		{
			return shortCode;
		}
		if(shortCode.endsWith("#"))
			shortCode="*"+shortCodeToken.nextElement()+"#";
		else
			shortCode="*"+shortCodeToken.nextElement();
		
		Hashtable <Integer,String>startInputWithShortCode=new Hashtable<>();
		int cntr=1;
		
		
		while (shortCodeToken.hasMoreElements())
		{
			//System.out.println(shortCodeToken.nextElement());
			startInputWithShortCode.put(cntr, shortCodeToken.nextElement()+"");
			cntr++;
		}
		reqBean.setStartInputWithShortCode(startInputWithShortCode);
		logger.info(startInputWithShortCode);
		logger.info(shortCode);
		return shortCode;
	}

}
