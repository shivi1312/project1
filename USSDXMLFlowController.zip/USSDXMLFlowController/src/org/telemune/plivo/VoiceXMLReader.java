package org.telemune.plivo;

import java.io.IOException;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.logging.log4j.LogManager;import org.apache.logging.log4j.Logger;
import org.telemune.web.UssdControlServlet;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class VoiceXMLReader {

	public Document doc = null;
	XPath xpath = null;

	public String langXmlQuery = "/menus/lang";
	public String varXmlQuery = "/menus/var";

	public String langAttrib1 = "id";
	public String langAttrib2 = "filepath";

	PreparedStatement pstmt1 = null;
	ResultSet rs1 = null;

	public String varAttrib1 = "name";
	public String varAttrib2 = "value";
	public boolean parsingSuccess = false;
	public static final Logger logger = LogManager.getLogger("VoiceXMLReader");

	public VoiceXMLReader(String Serv_ID, String calledNum, Connection conn) {
		logger.debug("### Inside VoiceXMlReader() constructor ####");
		String xmlData = "";
		try {
			String query1 = "select XML_Data from IVR_Services_Data where Serv_Id=?";
			pstmt1 = conn.prepareStatement(query1);
			pstmt1.setInt(1, (Integer.parseInt(Serv_ID)));
			rs1 = pstmt1.executeQuery();
			if (rs1.next()) {
				xmlData = rs1.getString(1);
			}
		} catch (SQLException e) {
			logger.error("Error occurred while retrieving xml data from data base. Serv_Id["
					+ Serv_ID + "] Exception[" + e + "]");
		} catch (Exception e) {
			logger.error("Error occurred while retrieving xml data from data base. Serv_Id["
					+ Serv_ID + "] Exception[" + e + "]");
		} finally {
			try {
				pstmt1.close();
				rs1.close();
			} catch (Exception e) {
				logger.fatal("Error from VoiceReder MySql exception :"
						+ e.toString());
				e.printStackTrace();
			}
		}
		if (xmlData != null) {
			InputSource inSrc = new InputSource(new StringReader(xmlData)); // A
																			// single
																			// input
																			// source
																			// for
																			// an
																			// XML
																			// entity.
			DocumentBuilderFactory factory = DocumentBuilderFactory
					.newInstance();
			try {
				DocumentBuilder builder = factory.newDocumentBuilder();
				try {
					this.doc = builder.parse(inSrc);
					XPathFactory xFactory = XPathFactory.newInstance();
					this.xpath = xFactory.newXPath();
					parsingSuccess = true;
				} catch (SAXException ex) {
					logger.fatal("# Unable to Parse the XML of Id [" + Serv_ID
							+ "] with error ", ex);
					parsingSuccess = false;
				} catch (IOException ex) {
					logger.fatal("# Input Source not found for Id [" + Serv_ID
							+ "] with error ", ex);
					parsingSuccess = false;
				}
			} catch (ParserConfigurationException ex) {
				logger.fatal(
						"# Unable to confihure Parser in VoiceXmlReader Constructor ",
						ex);
				parsingSuccess = false;
			}
		} else {
			logger.info("# Xml not loaded for appId [" + Serv_ID + "]");
			parsingSuccess = false;
		}

		logger.debug("# VoiceXmlReader Ends Here");

	}

	public ConcurrentHashMap<String, String> getXmlLangOrVarMap(
			String callUUID, String xmlQuery, String attrib1, String attrib2)
			throws XPathExpressionException {

		ConcurrentHashMap<String, String> langOrVarMap = new ConcurrentHashMap<String, String>();
		Node mainNode = null;
		NamedNodeMap nnMap = null;
		Node node1 = null;
		Node node2 = null;
		XPathExpression expr = null;
		Object result = null;

		try {
			logger.info("[" + callUUID + "] #Inside getXmlLangOrVarMap()  ####");

			expr = this.xpath.compile(xmlQuery);
			synchronized (this) {
				result = expr.evaluate(this.doc, XPathConstants.NODESET);
			}
			NodeList ndList = (NodeList) result;

			for (int i = 0; i < ndList.getLength(); i++) {
				mainNode = ndList.item(i);
				nnMap = mainNode.getAttributes();
				node1 = nnMap.getNamedItem(attrib1);
				node2 = nnMap.getNamedItem(attrib2);

				langOrVarMap.put(node1.getNodeValue(), node2.getNodeValue());
			}
			logger.debug("[" + callUUID
					+ "] Lang or Var Node is Found Length: ["
					+ ndList.getLength() + "] VarMap value: [" + langOrVarMap
					+ "]");

			logger.info("[" + callUUID
					+ "] getXmlLangOrVarMap() process complete ####");
		} catch (Exception e) {
			logger.error("[" + callUUID
					+ "] Error occurred while retrievig lang and var parameters. Returning NULL. Exception["+e+"]");
			return null;
		}
		return langOrVarMap;
	}

	public ConcurrentHashMap<String, Object> getParamMap(String action,
			String actionType, String itemId,
			ConcurrentHashMap<String, String> langMap,
			ConcurrentHashMap<String, String> varMap)
			throws XPathExpressionException {
		logger.info("[" + varMap.get("Id")
				+ "] #getParamMap() starts here ####");
		ConcurrentHashMap<String, Object> paramMap = new ConcurrentHashMap<String, Object>();
		Node mainNode = null;
		NamedNodeMap nnMap = null;
		Node node1 = null;
		Node node2 = null;
		XPathExpression expr = null;
		Object result=null;

		
		try
		{
			String query = "/menus/item[@id='" + itemId
					+ "']/action[@action='" + action + "'][@type='" + actionType
					+ "']/param";
			logger.debug("query: " + query);
			expr = this.xpath.compile(query);
			synchronized (this) {
				result = expr.evaluate(this.doc, XPathConstants.NODESET);
			}
			NodeList ndList = (NodeList) result;

			logger.info("[" + varMap.get("Id") + "] ParameterMap  Node Length: "
					+ ndList.getLength());
			String attribute1 = "";
			String attribute2 = "";
			ArrayList<String> paramList2 = new ArrayList<String>();
			ArrayList<String> paramList3 = new ArrayList<String>();
			ArrayList<String> paramList4 = new ArrayList<String>();
			if (ndList.getLength() >= 1) {
				logger.info("[" + varMap.get("Id")
						+ "] Parameter List fond for item Id [" + itemId + "]");
			}
			for (int i = 0; i < ndList.getLength(); i++) {

				mainNode = ndList.item(i);
				nnMap = mainNode.getAttributes();
				node1 = nnMap.getNamedItem("name");
				node2 = nnMap.getNamedItem("data");
				attribute1 = node1.getNodeValue();
				attribute2 = node2.getNodeValue();
				logger.debug("[" + varMap.get("Id")
						+ "] PARAM 1: Node Name is Found :" + attribute1);
				logger.debug("[" + varMap.get("Id")
						+ "] PARAM 2: Node Value is Found : " + attribute2);

				if (attribute1.equals("parameter")) {
					logger.debug("[" + varMap.get("Id")
							+ "]parameter attribute found  itemId " + itemId);
					logger.debug("[" + varMap.get("Id") + "]ATTRIBUTE: "
							+ attribute1 + "value " + attribute2);
					paramList2.add(attribute2.replaceAll("[$]", ""));

				} else if (attribute1.equals("set")) {
					logger.debug("[" + varMap.get("Id")
							+ "]set attribute found itemId " + itemId);
					logger.debug("[" + varMap.get("Id") + "]ATTRIBUTE: "
							+ attribute1 + "value " + attribute2);
					paramList3.add(attribute2.replaceAll("[$]", ""));

				} else if (attribute1.equals("text")) {

					logger.info("[" + varMap.get("Id")
							+ "]text attribute found itemId " + itemId);
					attribute2 = attribute2.replace("$", "");

					attribute2 = attribute2.replaceAll("lang", varMap.get("lang"));
					if (attribute2.equalsIgnoreCase("FilePath")) {
						attribute2 = varMap.get("FilePath");
						logger.info("[" + varMap.get("Id")
								+ "] Modified FilePath Message is [" + attribute2
								+ "]");

					} else {
						attribute2 = attribute2.replace("/", "-");
						logger.info("["
								+ varMap.get("Id")
								+ " #Inside getParamMap() method VXReader replace with _ ["
								+ attribute2 + "]");
						attribute2 = UssdControlServlet.ussdMenuMsg.get(attribute2);
						logger.info("["
								+ varMap.get("Id")
								+ " #Inside getParamMap() method VXReader now after getting value from map is ["
								+ attribute2 + "]");
						logger.info("[" + varMap.get("Id")
								+ "] Modified HardCode Message is [" + attribute2
								+ "]");
					}
					paramList4.add(attribute2);
				} else {
					
					/*
                     * Added By Richard Bux for handling Dynamic USSD Redirection
                     */
                    if(actionType.equalsIgnoreCase("redirect"))
                    {
                            if (attribute2.equalsIgnoreCase("FilePath")) {
                                    attribute2 = varMap.get("FilePath");
                                    logger.info("[" + varMap.get("Id")
                                                    + "] USSD Redirection FilePath Message is [" + attribute2
                                                    + "]");
                             
                            }
                            else if(varMap.containsKey(attribute2) && varMap.get(attribute2) !=null)
                            {
                                    attribute2 = varMap.get(attribute2);
                                    logger.info("[" + varMap.get("Id")
                                                    + "] USSD Redirection Message is [" + attribute2
                                                    + "]");
                            }
                            else
                            {
                            	logger.debug("[" + varMap.get("Id") + "]ATTRIBUTE: "
                                        + attribute1 + "itemId " + itemId);
                            	paramMap.put(attribute1, attribute2);
                            	paramMap.put(attribute1.replaceAll("[$]", ""),
                                        attribute2.replaceAll("[$]", ""));// name data
                            	logger.info("[" + varMap.get("Id")
                                        + "] USSD Redirection Message is [" + attribute2
                                        + "]");
                            	
                            }
                            paramMap.put(attribute1, attribute2);
                    }
                    else
                    {
                            logger.debug("[" + varMap.get("Id") + "]ATTRIBUTE: "
                                            + attribute1 + "itemId " + itemId);
                            paramMap.put(attribute1, attribute2);
                            paramMap.put(attribute1.replaceAll("[$]", ""),
                                            attribute2.replaceAll("[$]", ""));// name data
                    }
				}

			}// end of nodeList loop section

			if (paramList2.size() > 0) {
				logger.debug("[" + varMap.get("Id") + "] Parameters Added Are ["
						+ paramList2 + "]");
				paramMap.put("parameter", paramList2);
			}
			if (paramList3.size() > 0) {
				logger.debug("[" + varMap.get("Id") + "] Variables Added Are ["
						+ paramList3 + "]");
				paramMap.put("set", paramList3);
			}
			if (paramList4.size() > 0) {
				logger.info("[" + varMap.get("Id") + "] Messages Added Are ["
						+ paramList4 + "]");
				paramMap.put("text", paramList4);
			}
			logger.info("[" + varMap.get("Id") + "] FINAL PARAM MAP " + paramMap);

			logger.info("[" + varMap.get("Id") + "] #getParamMap() ends here ####");
		}
		catch(Exception e)
		{
			logger.error("[" + varMap.get("Id")
					+ "] Error occurred get Param map. Returning NULL. Exception["+e+"]");
			return null;
		}
		
		return paramMap;

	}

	public ConcurrentHashMap<String, String> getActionDetail(String itemId,
			int actionSequence, ConcurrentHashMap<String, String> varMap)
			throws XPathExpressionException {
		logger.info("[" + varMap.get("Id")
				+ "] #getActionDetail() starts here ####");
		logger.info("[" + varMap.get("Id") + "]  GOT ITEM ID [" + itemId
				+ "] ItemName[" + this.getItemName(itemId) + "]");
		ConcurrentHashMap<String, String> actionMap = new ConcurrentHashMap<String, String>();
		Node mainNode = null;
		NamedNodeMap nnMap = null;
		Node node1 = null;
		Node node2 = null;
		XPathExpression expr = null;
		Object result=null;

		try
		{
			expr = this.xpath.compile("/menus/item[@id='" + itemId + "']/action");
			synchronized (this) {
				result = expr.evaluate(this.doc, XPathConstants.NODESET);
			}
			NodeList ndList = (NodeList) result;

			// logger.info("["+varMap.get("Id")+"]  Total Action Found: " +
			// ndList.getLength());
			String attribute1 = "";
			String attribute2 = "";
			logger.info("[" + varMap.get("Id") + "] Total Action Found: ["
					+ ndList.getLength() + "] Action Squence: [" + actionSequence
					+ "]");

			if (ndList.getLength() > actionSequence && ndList.getLength() != 0) {
				mainNode = ndList.item(actionSequence);
				nnMap = mainNode.getAttributes();
				node1 = nnMap.getNamedItem("type");
				actionMap.put("actionType", node1.getNodeValue());

				node2 = nnMap.getNamedItem("action");
				actionMap.put("action", node2.getNodeValue());
				actionMap.put("actionSequence",
						Integer.toString(ndList.getLength()));
				attribute1 = node1.getNodeValue();
				attribute2 = node2.getNodeValue();

				logger.info("[" + varMap.get("Id") + "]  ACTION MAP: " + actionMap);
			}
			else
			{
				logger.info("[" + varMap.get("Id") + "]  ACTION MAP[null]");
				return null;
			}
		}
		catch(Exception e)
		{
			logger.error("[" + varMap.get("Id")
					+ "] Error occurred getting Action Detail. Returning NULL. Exception["+e+"]");
			return null;
		}
		return actionMap;
		
	}

	public ConcurrentHashMap<String, String> getNextActionLink(String itemId,
			ConcurrentHashMap<String, String> varMap, String invalidRetry) {
		logger.info("[" + varMap.get("callUUID")
				+ "] # Inside getNextActionLink() of VoiceXmlReader");
		ConcurrentHashMap<String, String> nextElementMap = new ConcurrentHashMap<String, String>();
		Node mainNode = null;
		NamedNodeMap nnMap = null;
		Node node1 = null;
		Node node2 = null;
		XPathExpression expr = null;
		Object result = null;
		NodeList ndList = null;
		String var = "";
		String val = "";

		String nextItemId = null;
		byte actionSequence = -1;
		Scanner scan = null;
		Pattern pattern = null;
		boolean match = false;
		String reserveId = null;
		String reserveVariable = null;
		String itemName = this.getItemName(itemId);

		try {
			expr = this.xpath
					.compile("/menus/item[@id='" + itemId + "']/links/link");
			synchronized (this) {
				result = expr.evaluate(this.doc, XPathConstants.NODESET);
			}
			ndList = (NodeList) result;
			logger.info("[" + varMap.get("callUUID") + "] digits: ["
					+ varMap.get("digits") + "] Last Executed Item ID: ["
					+ itemId + "]  Last Executed ItemName [" + itemName
					+ "] Total Link Found: [" + ndList.getLength() + "]");

			for (int i = 0; i < ndList.getLength(); i++) {
				nnMap = ndList.item(i).getAttributes();
				var = nnMap.getNamedItem("variable").getNodeValue();
				val = nnMap.getNamedItem("value").getNodeValue();
				var = var.replaceAll("[$]", "");
				reserveVariable = var;
				if (var != "" && varMap.containsKey(var)
						&& varMap.get(var).equalsIgnoreCase(val)) {
					nextItemId = nnMap.getNamedItem("id").getNodeValue();
					logger.debug("[" + varMap.get("callUUID")
							+ "]  new Item id [" + nextItemId + "]");
					actionSequence = 0;
					break;
				} else if (val.equals("") || val.equals("none")) {
					nextItemId = nnMap.getNamedItem("id").getNodeValue();
					logger.debug("[" + varMap.get("callUUID")
							+ "]  new Item id [" + nextItemId + "]");
					actionSequence = 0;
					break;
				} else if (var != "" && val.startsWith("regex:")) {
					String valreg = val.substring(val.indexOf("["),
							val.length());
					logger.info("[" + varMap.get("callUUID")
							+ "] regular expression: " + valreg);

					pattern = Pattern.compile(valreg);
					if (valreg.contains("-")) {
						reserveId = nnMap.getNamedItem("id").getNodeValue();
						logger.info("[" + varMap.get("callUUID")
								+ "] reserve Id is [" + reserveId + "]");
					}
					if (var != null && var != ""
							&& pattern.matcher(varMap.get(var)).matches()) {

						logger.info("[" + varMap.get("callUUID")
								+ "] ### OK ### INPUT STATUS: "
								+ pattern.matcher(varMap.get(var)).matches());
						match = pattern.matcher(varMap.get(var)).matches();

					} else {

						logger.info("[" + varMap.get("callUUID")
								+ "] ### FAILED ### INPUT STATUS: "
								+ pattern.matcher(varMap.get(var)).matches());
						match = pattern.matcher(varMap.get(var)).matches();

					}
					if (match) {
						nextItemId = nnMap.getNamedItem("id").getNodeValue();
						actionSequence = 0;
						break;
					}
				}
			}
			if (nextItemId != null && actionSequence != -1) {
				logger.debug("["
						+ varMap.get("callUUID")
						+ "] # in getNextActionLink() info placed in Map is item id["
						+ nextItemId + "] actionSequence is [" + actionSequence
						+ "]");
				nextElementMap.put("itemId", nextItemId);
				nextElementMap.put("invalidRetry", "0");
				nextElementMap.put("actionSequence",
						new Byte(actionSequence).toString());
			} else {
				logger.warn("[" + varMap.get("callUUID")
						+ "] NO LINK MATCH for Condition " + "[" + var
						+ "] with Value [" + varMap.get(var) + "]");
				if (reserveVariable.equals("digits")) {
					if (varMap.get("digits").length() > 1
							&& varMap.get("digits") != "-1") {
						logger.info("["
								+ varMap.get("callUUID")
								+ "] Match not found but input is greater then 1 digit so reserve Id is set ["
								+ reserveId + "]");
						nextElementMap.put("itemId", reserveId);
						actionSequence = 0;
						nextElementMap.put("actionSequence", new Byte(
								actionSequence).toString());
					}
				}
				if (nextElementMap.get("itemId") != null) {
					logger.info("[" + varMap.get("callUUID")
							+ "] NextLinkMap is not null [ "
							+ nextElementMap.get("itemId") + "]");
				} else {
					logger.info("["
							+ varMap.get("Id")
							+ "] Input does not match for following Request Item Id ["
							+ itemId + " invalidRetry is [" + invalidRetry
							+ "] Map InalidRety is ["
							+ varMap.get("invalidRetry") + "]");
					if (varMap.get("invalidRetry").equals(invalidRetry)) {
						logger.info("["
								+ varMap.get("Id")
								+ "] Invalid Retry Limit reached So hanging up.");
						nextElementMap.put("itemId", "#hangup");
						actionSequence = 0;
						nextElementMap.put("actionSequence", new Integer(
								actionSequence).toString());
						nextElementMap.put("invalidRetry", invalidRetry);
						logger.info("["
								+ varMap.get("Id")
								+ "] Invalid retry now set in input not match case ["
								+ invalidRetry + "]");
					} else {
						logger.info("["
								+ varMap.get("Id")
								+ "] Invalid Retry Limit Not reach So retry again with itemId ["
								+ itemId + "]");

						nextElementMap.put("itemId", itemId);
						actionSequence = 0;
						nextElementMap.put("actionSequence", new Integer(
								actionSequence).toString());
						nextElementMap.put("invalidRetry",
								Integer.parseInt(invalidRetry) + 1 + "");
						logger.info("["
								+ varMap.get("Id")
								+ "] Invalid retry now set in input not match case ["
								+ invalidRetry + "]");

					}
				}
			}
		} catch (XPathExpressionException ex) {
			logger.fatal("[" + varMap.get("callUUID")
					+ "] #Error in XpathExpression inside getNextActionLink()");
		} finally {
			mainNode = null;
			nnMap = null;
			node1 = null;
			node2 = null;
			expr = null;
			result = null;
			ndList = null;
			var = null;
			val = null;
			nextItemId = null;
			scan = null;
			pattern = null;

		}
		logger.info("["
				+ varMap.get("callUUID")
				+ "] # End of getNextActionLink() of VoiceXmlReader nextActionLinkMap is ["
				+ nextElementMap + "]");
		return nextElementMap;
	}

	public static Document loadXmlFromString(String callUUID, String str)
			throws Exception {

		logger.info("[" + callUUID
				+ "] #loadXmlFromString() starts here #### input xml [" + str);
		DocumentBuilderFactory _factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder _builder = _factory.newDocumentBuilder();
		// StringReader sr=new StringReader(str);
		// logger.info("["+callUUID+"]####String comes in loadxmlfromstring method #####"+str);
		InputSource is = new InputSource(new StringReader(str));

		logger.info("[" + callUUID + "] #loadXmlFromString() ends here ####");
		return _builder.parse(is);
		// return doc;
	}

	public ConcurrentHashMap<String, String> getResponseMap(String callUUID,
			String xpathQuery, String responseBody)
			throws XPathExpressionException {

		logger.info("[" + callUUID + "] #getResponseMap() starts here ####");
		ConcurrentHashMap<String, String> actionMap = new ConcurrentHashMap<String, String>();
		Node mainNode = null;
		NamedNodeMap nnMap = null;
		Node node1 = null;
		Node node2 = null;
		Document doc_x = null;
		XPathExpression expr = null;
		XPath _xpath = null;
		try {
			if (responseBody.contains(System.getProperty("line.separator"))) {
				responseBody = responseBody.replaceAll("\n", "#@");
			}
			doc_x = loadXmlFromString(callUUID, responseBody);
			XPathFactory _xFactory = XPathFactory.newInstance();
			_xpath = _xFactory.newXPath();
		} catch (Exception e) {
			logger.fatal("#### Exception comes from here : " + e.toString());
			e.printStackTrace();
		}

		expr = _xpath.compile(xpathQuery);
		Object result = expr.evaluate(doc_x, XPathConstants.NODESET);
		NodeList ndList = (NodeList) result;

		logger.info("[" + callUUID + "] Node of Item is  Found : "
				+ ndList.getLength());

		for (int i = 0; i < ndList.getLength(); i++) {
			mainNode = ndList.item(i);
			nnMap = mainNode.getAttributes();
			node1 = nnMap.getNamedItem("name");
			node2 = nnMap.getNamedItem("value");
			logger.info("###### Node name ["
					+ (node1.getNodeValue() + "] node value["
							+ node2.getNodeValue() + "]"));
			String dataVal = (String) node2.getNodeValue();
			if (dataVal.contains("#@")) {
				dataVal = dataVal.replaceAll("#@", "\n");
			}
			logger.info("Now data to be save in map is [" + dataVal + "]");
			actionMap.put(node1.getNodeValue(), dataVal);

		}
		logger.info("[" + callUUID + "] Final Action Map " + actionMap);
		logger.info("[" + callUUID + "] #getResponseMap() ends here ####");
		return actionMap;

	}// ======end of getResponseMap

	public String getItemName(String itemId) {
		Node mainNode = null;
		NamedNodeMap nnMap = null;

		XPathExpression expr = null;
		Object result = null;
		NodeList ndList = null;
		String itemName = "NA";
		try {
			if (!itemId.equalsIgnoreCase("#start")
					&& !itemId.equalsIgnoreCase("#hangup")) {

				expr = this.xpath.compile("/menus/item[@id='" + itemId + "']");
				synchronized (this) {
					result = expr.evaluate(this.doc, XPathConstants.NODESET);
				}
				ndList = (NodeList) result;
				mainNode = ndList.item(0);
				nnMap = mainNode.getAttributes();
				itemName = nnMap.getNamedItem("name").getNodeValue();
			} else {
				itemName = itemId;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			mainNode = null;
			nnMap = null;
			expr = null;
			result = null;
			ndList = null;
		}
		return itemName;
	}
}
