

package org.telemune.plivo;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.Future;
import org.apache.logging.log4j.LogManager;import org.apache.logging.log4j.Logger;
import net.spy.memcached.*;

public class MemClient {

        private static MemcachedClient client = null;
	public static Logger logger = LogManager.getLogger("MemClient");
        public MemClient(String ip,String value) {
                try {
			logger.info("Memcached Ip: "+ip+" port: "+value);
			int port=Integer.parseInt(value);
                        client = new MemcachedClient(new InetSocketAddress(ip,port));
                        logger.info("CONNECTED TO SERVER");
                } catch (Exception e) {
			logger.fatal("excetion while creating the connection with Memcached "+e.getMessage());
                        e.printStackTrace();
                }
        }

        public Future<Boolean> addToMemCache(String key, int timeOut, Object val) {
                Future<Boolean> future = client.set(key, timeOut, val);
                return future;
        }

        public Object getMemcachedValue(String key) {
                return client.get(key);
        }
	

	public Object remove(String key) {
		try{
		Object obj=client.get(key);
                return obj;
		}finally{
		Future<Boolean> result= client.delete(key);
		
		}
        }
	
	public boolean containsKey(String key) {
                if(client.get(key) == null)
                {
                return false;
                }else
                {
                return true;
                }
        }

}


