package org.telemune.plivo;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class GenerateReferenceId {

	public static Logger logger=LogManager.getLogger("GenerateReferenceId");

	public Integer getNewReferenceId() {

		Integer id = 0;
		FileInputStream read = null;
		FileOutputStream write = null;
		BufferedReader brIn = null;
		BufferedWriter brOut = null;
		try {
			
			read = new FileInputStream("plivo.refid");
			brIn = new BufferedReader(new InputStreamReader(read));
			id = Integer.parseInt(brIn.readLine());
			read.close();
			id++;
			File f=new File("plivo.refid");
			if(f.exists()){
				logger.info("File is found....");
			}
			write = new FileOutputStream("plivo.refid");
			brOut = new BufferedWriter(new OutputStreamWriter(write));
			brOut.write(new Integer(id).toString());
			//brOut.write("Welcome");
			brOut.flush();
			write.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

		}

		return id;
	}
	public static void main(String ...arg){
	logger.info(new GenerateReferenceId().getNewReferenceId());
	}
}
