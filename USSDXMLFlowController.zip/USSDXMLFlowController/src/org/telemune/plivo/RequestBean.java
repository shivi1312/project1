
package org.telemune.plivo;
import java.io.*;
import java.util.Hashtable;
import java.util.concurrent.ConcurrentHashMap;

public class RequestBean implements Serializable{



public String callUUID;
public String calledNum;
public String itemId;
public String callingNum;
public StringBuffer callDigInfo;
public String callSequence;
//public String callDuration;
public String callStatus;
public String invalidRetry;
public String serviceId;
public int actionSequence;
public ConcurrentHashMap<String, String> varMap;
public ConcurrentHashMap<String, String> linkMap;
public ConcurrentHashMap<String, String> langMap;
 public ConcurrentHashMap<String, String> actionMap;
 private Hashtable<Integer,String> startInputWithShortCode=null;
    public ConcurrentHashMap<String, String> getMap(){
	return varMap;

	}
	
	public void setMap(ConcurrentHashMap<String, String> mp){

	this.varMap=mp;
	}
	


	
	 public ConcurrentHashMap<String, String> getActionMap(){
        return actionMap;

        }

        public void setActionMap(ConcurrentHashMap<String, String> actionMap){

        this.actionMap=actionMap;
        }



	public ConcurrentHashMap<String, String> getLinkMap(){
        return linkMap;

        }

        public void setLinkMap(ConcurrentHashMap<String, String> mp){

        this.linkMap=mp;
        }
	
	public ConcurrentHashMap<String, String> getLangMap(){
        return langMap;

        }

        public void setLangMap(ConcurrentHashMap<String, String> mp){

        this.langMap=mp;
        }

    public int getActionSequence() {
        return actionSequence;
    }

    public void setActionSequence(int actionSequence) {
        this.actionSequence = actionSequence;
    }

    public String getCallUUID() {
        return callUUID;
    }

    public void setCallUUID(String callUUID) {
        this.callUUID = new String(callUUID);
    }

	public String getCallStatus() {
        return callStatus;
    }

/*public void setcallDuration(String callDuration) {
        this.callDuration = new String(callDuration);
    }

        public String getcallDuration() {
        return callDuration;
    }*/	

    public String getCalledNum() {
        return calledNum;
    }

     public void setCallStatus(String callStatus) {
        this.callStatus = new String(callStatus);
    }
	public String getCallSequence() {
        return callSequence;
    }

     public void setCallSequence(String callSequence) {
        this.callSequence = callSequence;
    }

    public void setCalledNum(String calledNum) {
        this.calledNum = new String(calledNum);
    }
 
    public String getServiceId(){
      return serviceId;
   }
   public void setServiceId(String servId){
     this.serviceId = servId;
   }
    public String getCallingNum() {
        return callingNum;
    }

    public void setCallingNum(String callingNum) {
        this.callingNum = new String(callingNum);
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = new String(itemId);
    }
 public StringBuffer getCallDigInfo() {
        return callDigInfo;
    }

    public void setCallDigInfo(StringBuffer callDigInfo) {
        this.callDigInfo = callDigInfo;
    }
     public String getInvalidRetry() {
        return invalidRetry;
    }

    public void setInvalidRetry(String invalidRetry) {
        this.invalidRetry = invalidRetry;
    }

    public void clearMap(){
	this.varMap=null;
        this.linkMap=null;
	this.actionMap=null;
        this.langMap=null;
	this.itemId="#start";
	this.actionSequence=0;
   }
  public String toString(){
		return "VarMap ["+this.varMap+"] Link Map ["+this.linkMap+"] Action Map ["+this.actionMap+"]";
	}

public Hashtable<Integer, String> getStartInputWithShortCode() {
	return startInputWithShortCode;
}

public void setStartInputWithShortCode(Hashtable<Integer, String> startInputWithShortCode) {
	this.startInputWithShortCode = startInputWithShortCode;
}
  
}
