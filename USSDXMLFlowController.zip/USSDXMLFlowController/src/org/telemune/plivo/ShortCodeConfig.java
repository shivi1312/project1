package org.telemune.plivo;

public class ShortCodeConfig{
 	String shortCode;
        String appID;
        String addCode;
        String direction;

        public ShortCodeConfig(String appID,String shortCode, String addCode,String direction){
                this.appID=appID;
                this.shortCode=shortCode;
                this.addCode=addCode;
                this.direction=direction;
        }
        public String getShortCode(){
                return shortCode;
        }
        public String getAppID(){
                return appID;
        }
        public String getAddCode(){
                return addCode;
        }
        public String getDirection(){
                return direction;
        }
        public String toString(){
                return " appID="+appID+", shortCode="+shortCode+", addCode="+addCode+", direction="+direction;
        }

}

