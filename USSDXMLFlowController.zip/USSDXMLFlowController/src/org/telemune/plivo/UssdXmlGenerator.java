package org.telemune.plivo;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.logging.log4j.LogManager;import org.apache.logging.log4j.Logger;

public class UssdXmlGenerator {
	public static Logger logger = LogManager.getLogger("UssdXmlGenerator");

	ArrayList<String> attributeList = new ArrayList<String>();


	public String doMyAction(HttpServletRequest request,
			HttpServletResponse response,
			ConcurrentHashMap<String, String> actionMap,
			ConcurrentHashMap<String, Object> paramMap,
			ConcurrentHashMap<String, String> varMap,
			ConcurrentHashMap<String, String> langMap,String seprator) throws ServletException,
	       IOException {
                 String responseBody="";
		       logger.info("["+varMap.get("Id")+"]   Got Request in UssdXmlGenerator" + actionMap.get("action"));
		if(actionMap.get("action").equals("ussdMenu")){
                   logger.info("["+varMap.get("Id")+"] # ussdMenu Request Comes ####");
                   attributeList = (ArrayList) paramMap.get("text");
                   StringBuffer msgData1=new StringBuffer();
                   for (Iterator<String> iterator = attributeList.iterator(); iterator
                                        .hasNext();) {
                                msgData1.append(iterator.next()); 
                                if(iterator.hasNext()){
                                  msgData1.append("\n");
                                }
                            
                        }
                   logger.info("["+varMap.get("Id")+"] Complete Message sending to user is ["+msgData1.toString()+"]");
                   responseBody+="<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
                  "<UssdEnvelop>"+
                 "<Msisdn>"+varMap.get("callingNum")+"</Msisdn>"+
                 "<Message>"+msgData1.toString()+"</Message>"+
                 "<TransactionId>"+varMap.get("Id")+"</TransactionId>"+
                 "<TransStatus>1</TransStatus>"+
                 "</UssdEnvelop>";
                 
                }else if(actionMap.get("action").equals("ussdEnd")){
               
                   logger.info("["+varMap.get("Id")+"] # ussdEnd Request Comes ####");
                    attributeList = (ArrayList) paramMap.get("text");
		   StringBuffer msgData2=new StringBuffer();
                   for (Iterator<String> iterator = attributeList.iterator(); iterator
                                        .hasNext();) {
                                msgData2.append(iterator.next());
                                if(iterator.hasNext()){
                                  msgData2.append("\n");
                                }

                        }

                   responseBody+="<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
                 "<UssdEnvelop>"+
                 "<Msisdn>"+varMap.get("callingNum")+"</Msisdn>"+
                 "<Message>"+msgData2.toString()+"</Message>"+
                 "<TransactionId>"+varMap.get("Id")+"</TransactionId>"+
                 "<TransStatus>0</TransStatus>"+
                 "</UssdEnvelop>";
                    
                }else if(actionMap.get("action").equals("ussdRedirect")){
                	logger.info("["+varMap.get("Id")+"] ussdRedirect Comes.");
                	StringBuffer msgData2=new StringBuffer();
                	for ( Map.Entry<String, Object> entry : paramMap.entrySet()) {
                	    String key = entry.getKey();
                	    String value = (String) entry.getValue();
                	    msgData2.append(value);
                	}  
                	
                	responseBody+="<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
                            "<UssdEnvelop>"+
                            "<Msisdn>"+varMap.get("callingNum")+"</Msisdn>"+
                            "<Message>"+msgData2+"</Message>"+
                            "<TransactionId>"+varMap.get("Id")+"</TransactionId>"+
                            "<TransStatus>2</TransStatus>"+
                            "</UssdEnvelop>";
                }else if (actionMap.get("action").equals("durlget")) {

        			logger.info("[" + varMap.get("Id")
        					+ "] # durlget Request Comes ####");
        			attributeList = (ArrayList) paramMap.get("header");
        			String msgData = "";
        			for (Iterator<String> iterator = attributeList.iterator(); iterator
        					.hasNext();) {
        				msgData = iterator.next();
        				if (iterator.hasNext()) {
        					msgData += "\n"; // "!";
        				}
        			}
        			msgData += "\n" + varMap.get("FilePath") + "\n";
        			attributeList = (ArrayList) paramMap.get("footer");
        			for (Iterator<String> iterator = attributeList.iterator(); iterator
        					.hasNext();) {
        				msgData += iterator.next();
        				if (iterator.hasNext()) {
        					msgData += "\n"; // "!";
        				}
        			}
        			responseBody = msgData;
        			logger.info("Response Body is [" + responseBody + "]");

        		} else {
			logger.warn("["+varMap.get("Id")+"]Ussd Action Generator is Called but No Action Met Condition ");
		}

	
	      return responseBody;	
	}//end of action method
}
