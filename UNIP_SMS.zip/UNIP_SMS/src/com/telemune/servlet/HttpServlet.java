package com.telemune.servlet;


	import java.io.IOException;

	import javax.servlet.ServletException;

	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	public class HttpServlet {
	public static int counter=1;
		public void init()
		{
			System.out.println("Inside init() method");
		}
		public void doPost(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			try
			{
				response.getOutputStream().write(200);
				
			}
			catch(Exception e)
			{
				System.out.println("Inside exception"+e.getMessage());
			}
			
		}
		public void doGet(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			
					System.out.println("in get");
					response.getOutputStream().write(200);
					
					
				}
	

}
