package com.telemune.dbutilities;


import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class AppContext {
	private static final Logger logger = Logger.getLogger(AppContext.class);
	public static ClassPathXmlApplicationContext context;
	public static DataSource dataSource = null;
	public static ComboPooledDataSource cpds = null;
	static {
		context = new ClassPathXmlApplicationContext("applicationContext.xml");
		dataSource = (DataSource) AppContext.context.getBean("dataSource");
		cpds = (ComboPooledDataSource)AppContext.dataSource;
	}
	public static void statics(String key){
		try{
			logger.info("["+key+"] total conn ["+cpds.getNumConnections()+
					"] active conn ["+cpds.getNumBusyConnections()+
					"] ideal conn ["+cpds.getNumIdleConnections()+"]");
		}catch(Exception e){
			logger.info("["+key+"] Error to print conn details: "+e.getMessage());
		}
	}
}
