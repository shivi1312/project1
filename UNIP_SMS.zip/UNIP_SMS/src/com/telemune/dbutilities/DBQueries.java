package com.telemune.dbutilities;

import org.apache.log4j.Logger;

public class DBQueries {
	
	public static String INSERT_INTO_UNIP_SMS_REQUEST_MDR="";
	public static String INSERT_INTO_UNIP_SMS_RESPONSE_MDR="";
	public static String DELETE_MCA_CALL_DETAIL="";
	public static String INSERT_INTO_GMAT_MESSAGE_STORE="";
	public static String LOAD_SMS_KEYWORDS="";
	public static String LOAD_SMS_TEMPLATES="";
	public static String LOAD_SMS_PROCESS_DETAILS="";
	public static String LOAD_APP_CONFIG_PARAMS="";
	//public static String INSERT_INTO_GMAT_MESSAGE_STORE_WITH_FORMAT="";
	public static String GET_MAX_REQUEST_ID_FROM_REQ_MDR="";
	public static String FETCH_PASSWORD="";
	public static String GET_HELP_MESSAGE="";
	public static String GET_HELP_MESSAGE_KEYWORD="";
	public static String CHECK_SUBSCRIPTION="";
	public static String UPDATE_LANGUAGE="";
	public static String GET_MCA_NOTIFICATION_DETAILS="";
	public static String GET_OPERATOR_RANGE="";
	public static String GET_CHARGING_CODE="";
	
	
	
	private Logger logger=Logger.getLogger(DBQueries.class);
	
	public DBQueries(int dbType)
	{
		buildQueries(dbType);
	}
	
	public void buildQueries(int dbType)
	{
		
		logger.info("Queries created for DBType["+dbType+"]");
		
		switch(dbType)
		{
			//1 for Oracle
			case 1:
				INSERT_INTO_UNIP_SMS_REQUEST_MDR="insert into UNIP_SMS_REQUEST_MDR (REQUEST_ID,MSISDN,COMMAND,MESSAGE_TEXT,REQUEST_TIME,SUBSCRIBER_TYPE)values(request_seq.nextval,?,?,?,sysdate,'N')";
				DELETE_MCA_CALL_DETAIL="delete from mca_call_detail where DESTINATION_NUMBER=?";
				INSERT_INTO_GMAT_MESSAGE_STORE="insert into GMAT_MESSAGE_STORE(RESPONSE_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT,"
							+ "SUBMIT_TIME,STATUS,MESSAGE_TYPE,DESTINATION_PORT,LANGUAGE) values (gmat_request_seq.nextval,?,?,?,sysdate,'R',1,0,1)";
				/*INSERT_INTO_GMAT_MESSAGE_STORE_WITH_FORMAT="insert into gmat_message_store(RESPONSE_ID,REQUEST_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT,SUBMIT_TIME,STATUS,LANGUAGE_ID,TEMPLATE_ID,UNIQUE_ID,SMS_TYPE,FORMAT) values (gmat_response_id_seq.nextval,gmat_response_id_seq.nextval,?,?,?,sysdate,?,1,'-1',1,1,3)";*/
				LOAD_SMS_TEMPLATES="select template_id,template_message,language_id from lbs_templates";
				LOAD_APP_CONFIG_PARAMS="select PARAM_NAME,PARAM_VALUE  from app_config_params";
				LOAD_SMS_KEYWORDS="select request_keyword,process_name,language_id from lbs_parser_master where is_working='Y'";
				LOAD_SMS_PROCESS_DETAILS="select process_name,min_arguments,max_arguments,process_id from lbs_process_master";
				GET_MAX_REQUEST_ID_FROM_REQ_MDR="Select max(REQUEST_ID) REQUEST_ID from UNIP_SMS_REQUEST_MDR where MSISDN=?";
				INSERT_INTO_UNIP_SMS_RESPONSE_MDR="insert into UNIP_SMS_RESPONSE_MDR(RESPONSE_ID,REQUEST_ID,MSISDN,MESSAGE_TEXT,RESPONSE_TIME)values(responce_seq.nextval,?,?,?,sysdate)";
//				FETCH_PASSWORD="select PASS from VCC_AUTH_USER where Msisdn=?"; // commented by Avishkar on 16/9/2020
				FETCH_PASSWORD="select PASS from $(VCC_AUTH_USER) where Msisdn=?"; // modified by Avishkar on 16/9/2020
				GET_HELP_MESSAGE="select HELP_MESSAGE from gmat_help_master where PROCESS_NAME=? and LANGUAGE_ID=?";
//				GET_HELP_MESSAGE_KEYWORD="select REQUEST_KEYWORD from lbs_parser_master where rownum<=10";
				GET_HELP_MESSAGE_KEYWORD="select REQUEST_KEYWORD from lbs_parser_master where IS_WORKING='Y' and rownum<=10"; // modified by Avishkar
//				CHECK_SUBSCRIPTION="select s.SERVICE_TYPE,a.LANGUAGE,s.RATE_PLAN from VCC_SUBSCRIPTION_MASTER  s , VCC_AUTH_USER  a where s.msisdn=a.msisdn and s.msisdn=?"; // commented by Avishkar on 17/9/2020
				CHECK_SUBSCRIPTION="select s.SERVICE_TYPE,a.LANGUAGE,s.RATE_PLAN from $(VCC_SUBSCRIPTION_MASTER)  s , $(VCC_AUTH_USER)  a where s.msisdn=a.msisdn and s.msisdn=?";  // modified by Avishkar on 17/9/2020
//				UPDATE_LANGUAGE="update VCC_AUTH_USER set language=? where Msisdn=?"; // commented by Avishkar on 16/9/2020
				UPDATE_LANGUAGE="update $(VCC_AUTH_USER) set language=? where Msisdn=?"; // modified by Avishkar on 16/9/2020
				//GET_MCA_NOTIFICATION_DETAILS="SELECT REQ_ID,ORIGINATION_NUMBER,to_char(CALL_TIME,'DD-MM-YYYY HH24:MI:SS') as CALL_TIME, CALL_COUNTER,SERVICE_TYPE FROM MCA_CALL_DETAIL WHERE DESTINATION_NUMBER = ?";
				GET_MCA_NOTIFICATION_DETAILS="SELECT REQ_ID,ORIGINATION_NUMBER,to_char(CALL_TIME,'DD-MM-YYYY') as DATE_OF_CALL,ORIGINATION_NUMBER,to_char(CALL_TIME,'HH24:MI:SS') as TIME_OF_CALL, CALL_COUNTER,SERVICE_TYPE,LANGUAGE_ID FROM MCA_CALL_DETAIL WHERE DESTINATION_NUMBER = ?";
//				GET_OPERATOR_RANGE="select count(range_id) from OPERATOR_SUBSCRIBER where (to_number(STARTS_AT) <=to_number(?) and to_number(ENDS_AT) >=to_number(?) and ? not in (select EXCLUDE_NUM from OPERATOR_SUBSCRIBER_EXCLUDE)) or ? in ( select INCLUDE_NUM from OPERATOR_SUBSCRIBER_INCLUDE)"; // commented by Avishkar on 19/8/2020
				GET_OPERATOR_RANGE="Select count(range_id) from vcc_series_range a, vcc_series_group b where a.group_id=b.group_id and b.group_name='NotifyMe' AND (to_number(START_RANGE) <=to_number(?) and to_number(END_RANGE) >=to_number(?))"; // modified by Avishkar on 19/8/2020
				GET_CHARGING_CODE="select PULL_SMS_CODE from vcc_rate_plan where plan_id=?";
				break;
				
			//2 for MySql
			case 2:
				//REQUEST_ID --> AutoIncremented
				INSERT_INTO_UNIP_SMS_REQUEST_MDR="insert into UNIP_SMS_REQUEST_MDR (MSISDN,COMMAND,MESSAGE_TEXT,REQUEST_TIME,SUBSCRIBER_TYPE)values(?,?,?,now(),'N')";
				DELETE_MCA_CALL_DETAIL="delete from mca_call_detail where DESTINATION_NUMBER=?";
				//RESPONSE_ID & REQUEST_ID both has to make auto-incremented 
				INSERT_INTO_GMAT_MESSAGE_STORE="insert into GMAT_MESSAGE_STORE(ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT,"
							+ "SUBMIT_TIME,STATUS,MESSAGE_TYPE,DESTINATION_PORT,LANGUAGE) values (?,?,?,now(),'R',1,0,1)";
				/*INSERT_INTO_GMAT_MESSAGE_STORE_WITH_FORMAT="insert into gmat_message_store(ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT,SUBMIT_TIME,STATUS,LANGUAGE_ID,TEMPLATE_ID,UNIQUE_ID,SMS_TYPE,FORMAT) values (?,?,?,now(),?,1,'-1',1,1,3)";*/
				LOAD_SMS_TEMPLATES="select template_id,template_message,language_id from lbs_templates";
				LOAD_APP_CONFIG_PARAMS="select PARAM_NAME,PARAM_VALUE  from app_config_params";
				LOAD_SMS_KEYWORDS="select request_keyword,process_name,language_id from lbs_parser_master where is_working='Y'";
				LOAD_SMS_PROCESS_DETAILS="select process_name,min_arguments,max_arguments,process_id from lbs_process_master";
				GET_MAX_REQUEST_ID_FROM_REQ_MDR="Select max(REQUEST_ID) REQUEST_ID from UNIP_SMS_REQUEST_MDR where MSISDN=?";
				//RESPONSE_ID --> AutoIncremented
				INSERT_INTO_UNIP_SMS_RESPONSE_MDR="insert into UNIP_SMS_RESPONSE_MDR(REQUEST_ID,MSISDN,MESSAGE_TEXT,RESPONSE_TIME)values(?,?,?,now())";
//				FETCH_PASSWORD="select PASS from VCC_AUTH_USER where Msisdn=?"; // commented by Avishkar on 16/9/2020
				FETCH_PASSWORD="select PASS from $(VCC_AUTH_USER) where Msisdn=?"; // modified by Avishkar on 16/9/2020
				GET_HELP_MESSAGE="select HELP_MESSAGE from gmat_help_master where PROCESS_NAME=? and LANGUAGE_ID=?";
//				GET_HELP_MESSAGE_KEYWORD="select REQUEST_KEYWORD from lbs_parser_master limit 10";
				GET_HELP_MESSAGE_KEYWORD="select REQUEST_KEYWORD from lbs_parser_master where IS_WORKING='Y' limit 10"; // modified by Avishkar
//				CHECK_SUBSCRIPTION="select s.SERVICE_TYPE,a.LANGUAGE,s.RATE_PLAN from VCC_SUBSCRIPTION_MASTER as s JOIN VCC_AUTH_USER as a ON s.msisdn=a.msisdn where s.msisdn=?"; // commented by Avishkar on 17/9/2020
				CHECK_SUBSCRIPTION="select s.SERVICE_TYPE,a.LANGUAGE,s.RATE_PLAN from $(VCC_SUBSCRIPTION_MASTER) as s JOIN $(VCC_AUTH_USER) as a ON s.msisdn=a.msisdn where s.msisdn=?";  // modified by Avishkar on 17/9/2020
//				UPDATE_LANGUAGE="update VCC_AUTH_USER set language=? where Msisdn=?"; // commented by Avishkar on 16/9/2020
				UPDATE_LANGUAGE="update $(VCC_AUTH_USER) set language=? where Msisdn=?"; // modified by Avishkar on 16/9/2020
				//GET_MCA_NOTIFICATION_DETAILS="SELECT REQ_ID,ORIGINATION_NUMBER,date_format(CALL_TIME,'%d-%m-%Y %H:%i:%s') as CALL_TIME,CALL_COUNTER,SERVICE_TYPE FROM MCA_CALL_DETAIL WHERE DESTINATION_NUMBER = ?";
				GET_MCA_NOTIFICATION_DETAILS="SELECT REQ_ID,ORIGINATION_NUMBER,date_format(CALL_TIME,'%d-%m-%Y') as DATE_OF_CALL,date_format(CALL_TIME,'%H:%i:%s') as TIME_OF_CALL,CALL_COUNTER,SERVICE_TYPE,LANGUAGE_ID FROM MCA_CALL_DETAIL WHERE DESTINATION_NUMBER = ?";
//				GET_OPERATOR_RANGE="select count(range_id) from OPERATOR_SUBSCRIBER where (cast(STARTS_AT AS SIGNED) <=cast(?  AS SIGNED) and cast(ENDS_AT  AS SIGNED) >=cast(?  AS SIGNED) and ? not in (select EXCLUDE_NUM from OPERATOR_SUBSCRIBER_EXCLUDE)) or ? in ( select INCLUDE_NUM from OPERATOR_SUBSCRIBER_INCLUDE)"; // commented by Avishkar on 19/8/2020
				GET_OPERATOR_RANGE="Select count(range_id) from vcc_series_range a, vcc_series_group b where a.group_id=b.group_id and b.group_name='NotifyMe' AND (cast(START_RANGE AS SIGNED) <=cast(?  AS SIGNED) and cast(END_RANGE  AS SIGNED) >=cast(?  AS SIGNED))"; // modified by Avishkar on 19/8/2020
				GET_CHARGING_CODE="select PULL_SMS_CODE from vcc_rate_plan where plan_id=?";
				break;
		}
	}
}
