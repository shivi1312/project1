/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.telemune.uniptest.webif;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.dbutilities.AppConfig;
import com.telemune.dbutilities.AppContext;
import com.telemune.dbutilities.DBQueries;
import com.telemune.unified.curd.UnipService;
import com.telemune.unified.model.McaNotification;
import com.telemune.unified.model.UnipRequest;

/**
 *
 * @author telemune
 */
public class DBEngine {

	private static final Logger logger = Logger.getLogger(DBEngine.class);
	public String query = null;
	public String Err_Msg = null;
	public String ad_msg = null;
	public int msg_length;
	public int txn_id;
	AdEngineHandler adEngineHandler = null;
	private UnipService unipService = new UnipService();
	public static void main(String [] args){
		new DBEngine().sendMCAMessage("*123#", "8800544347", 1,"NA");
	}
	public DBEngine() {

	}

	/*
	 * public DBEngine (ConnectionPool conpool) { this.conPool = conpool; }
	 */
	public void insertReqMdr(String keyword, String message, String msisdn) {
		String query = "";
		msisdn = UniptestCache.GetInstance().getInternationalNumber(msisdn);
		logger.info("Inside function insertReqMdr keyword [ " + keyword + " ] message [ " + message + "  ] msisdn [ "
				+ msisdn + " ]");
		try {
			query = DBQueries.INSERT_INTO_UNIP_SMS_REQUEST_MDR;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			jdbcTemplate.update(query, new Object[]{msisdn.trim(),keyword.trim(),message.trim()});
		} catch (Exception e) {
			logger.error("Exception inside insertReqMdr()" + e.getMessage());
			e.printStackTrace();
		}
	}

	public int insertResponseMdr(String messageText, String msisdn) {
		String query = "";
		logger.info("Inside function insertResMdr message [ " + messageText + "  ] msisdn [ " + msisdn + " ]");
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			/*query = DBQueries.GET_MAX_REQUEST_ID_FROM_REQ_MDR;
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query, new Object[]{msisdn.trim()});
			query = DBQueries.INSERT_INTO_UNIP_SMS_RESPONSE_MDR;
			if(rows.size() > 0){
				for (Map<String,Object> row : rows) {
					jdbcTemplate.update(query, new Object[]{row.get("REQUEST_KEYWORD"),msisdn.trim(),messageText.trim()});
				}
			}else {
				logger.info("No request exist into DB");
				return -1;
			}*/
			query = DBQueries.GET_MAX_REQUEST_ID_FROM_REQ_MDR;
			int requestId=jdbcTemplate.queryForObject(query, new Object[]{msisdn}, Integer.class);
			query = DBQueries.INSERT_INTO_UNIP_SMS_RESPONSE_MDR;
			jdbcTemplate.update(query, new Object[]{requestId,msisdn.trim(),messageText.trim()});
			
		} catch (Exception e) {
			logger.info("Exception inside send response" + e.getMessage());
			e.printStackTrace();// TODO: handle exception
		}
		return 1;
	}

	public int getChargingCode(int rateplan, int chargingCode) {
		String query = "";
		logger.info("Inside function getCharging Code ratePlan is [ " + rateplan + " ]");
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			query = DBQueries.GET_CHARGING_CODE;
			chargingCode = (Integer)jdbcTemplate.queryForObject(
					query, new Object[] { rateplan }, Integer.class);
			if(chargingCode == 0){
				logger.info("User is not subscribed ");
				return -1;
			} else {
				return chargingCode;
			}
		}catch (Exception e) {
			logger.error("Exception inside getChargingCode()" + e.getMessage());
			e.printStackTrace();
			return -1;
		}

	}

	public int CheckSubscription(int language, String Msisdn, SetVariable setvar) {
		String query = "";
		@SuppressWarnings("unused")
//		int service_type = -1; // commented by Avishkar on 24/8/2020
		String service_type = "NA"; // added by Avishkar on 24/8/2020
		logger.info("Inside function check Subscribtion of MSISDn" + Msisdn);
		try {
		// addition start by Avishkar on 17/9/2020
			if (AppConfig.config.getInt("MULTIPLE_TABLE_SUBSCRIPTION_CHECK",0)==1) {
				String lastDigit=Msisdn.substring(Msisdn.length() - 1);
				String tableNameAuth="VCC_AUTH_USER"+"_"+lastDigit;
				String tableNameSub="VCC_SUBSCRIPTION_MASTER"+"_"+lastDigit;
				query = (DBQueries.CHECK_SUBSCRIPTION.replace("$(VCC_AUTH_USER)", tableNameAuth)).replace("$(VCC_SUBSCRIPTION_MASTER)", tableNameSub);
			} else {
				query = DBQueries.CHECK_SUBSCRIPTION.replace("$(VCC_AUTH_USER)", "VCC_AUTH_USER").replace("$(VCC_SUBSCRIPTION_MASTER)", "VCC_SUBSCRIPTION_MASTER");
			}
//			query = DBQueries.CHECK_SUBSCRIPTION;
			
		// addition end by Avishkar on 17/9/2020
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			/*query = "select pull_sms_code from rate_plan where plan_id=?";*/
			List<Map<String, Object>> rows = jdbcTemplate.queryForList(query,Msisdn);
			if(rows.size() > 0){
				for (Map<String, Object> row : rows) {
					setvar.setLanguage((Integer)row.get("language"));
					setvar.setPlanId((Integer)row.get("rate_plan"));
//					service_type = (Integer)row.get("service_Type"); // commented by Avishkar on 24/8/2020
					service_type = (String) row.get("service_Type"); // added by Avishkar on 24/8/2020
					break;
				}
				return 1;
			} else {
				logger.info("user not subscribe");
				return -3;
			}
		}catch (Exception e) {
			logger.error("Exception inside getChargingCode()" + e.getMessage());
			e.printStackTrace();
			return -1;
		}
	}

	public int updateLanguage(int languageId, String Msisdn) {
		String query = "";
		logger.info("TO check Subscribtion of MSISDn" + Msisdn);
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
		// addition start by Avishkar on 16/9/2020
			if (AppConfig.config.getInt("MULTIPLE_TABLE_SUBSCRIPTION_CHECK",0)==1) {
				String lastDigit=Msisdn.substring(Msisdn.length() - 1);
				String tableName="VCC_AUTH_USER"+"_"+lastDigit;
				query = DBQueries.UPDATE_LANGUAGE.replace("$(VCC_AUTH_USER)", tableName);
			} else {
				query = DBQueries.UPDATE_LANGUAGE.replace("$(VCC_AUTH_USER)", "VCC_AUTH_USER");
			}
//			query = DBQueries.UPDATE_LANGUAGE;
			
		// addition end by Avishkar on 16/9/2020
			jdbcTemplate.update(query, new Object[]{languageId, Msisdn.trim()});
		} catch (Exception e) {
			logger.info(" exception " + e.toString());
			return -1;
		}
		return 1;
	}

	public String fetchPassword(String Msisdn) {
		String pass = null;
		String query = ""; // added by Avishkar
		logger.info("TO check Subscribtion of MSISDn" + Msisdn);
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
		// addition start by Avishkar on 16/9/2020
			if (AppConfig.config.getInt("MULTIPLE_TABLE_SUBSCRIPTION_CHECK",0)==1) {
				String lastDigit=Msisdn.substring(Msisdn.length() - 1);
				String tableName="VCC_AUTH_USER"+"_"+lastDigit;
				query = DBQueries.FETCH_PASSWORD.replace("$(VCC_AUTH_USER)", tableName);
			} else {
				query = DBQueries.FETCH_PASSWORD.replace("$(VCC_AUTH_USER)", "VCC_AUTH_USER");
			}
//			String query = DBQueries.FETCH_PASSWORD; 
			
		// addition end by Avishkar on 16/9/2020
			pass = (String)jdbcTemplate.queryForObject(
					query, new Object[] { Msisdn.trim() }, String.class);
			return pass;
		} catch (Exception e) {
			logger.info("Exception Occoured" + e.getMessage());
			return null;
		}
	}

	public String CreateTemplate(String srcTemplate, Hashtable<String, String> tagMaps) {
		String _Key = "";
		@SuppressWarnings("rawtypes")
		Enumeration keys = tagMaps.keys();
		String _value = "";
		while (keys.hasMoreElements()) {
			_Key = (String) keys.nextElement();
			_value = (String) tagMaps.get(_Key);

			if (UniptestCache.CountryCodeAlertEnable == 0) {
				logger.debug("UniptestCache.CountryCodeAlertEnable : [" + UniptestCache.CountryCodeAlertEnable + "]");
				if (_Key.equalsIgnoreCase("$(calling_number)")) {
					logger.debug("_Key : [" + _Key + "]");
					_value = getCountryCodeFreeMsisdn(_value);
				}
			}
			srcTemplate = srcTemplate.replace(_Key, _value);
		}
		return srcTemplate;
	}

	public String getCountryCodeFreeMsisdn(String msisdn) {
		try {
			logger.debug("inside getOwnCountryNumber getting msisdn as [" + msisdn + "]");
			if (msisdn.length() == UniptestCache.msisdnLength) {
				logger.debug("total msisdn length verified for msisdn [" + msisdn + "]");
				if (msisdn.startsWith(UniptestCache.countryCode)) {
					msisdn = msisdn.substring(UniptestCache.countryCode.length());
					logger.info("msisdn after removing the country code : [" + msisdn + "]");
				}
			}
		} catch (Exception e) {
			logger.error("Error in getting final country number", e);
		}
		return msisdn;
	}

	public int getRatePlan(int service, int validity) {
		int planId = 0;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			query = "select PLAN_ID from rate_plan where SERVICE_TYPE=? and SUB_VALIDITY=?";
			planId = (Integer)jdbcTemplate.queryForObject(
					query, new Object[] { String.valueOf(service), validity }, Integer.class);
			logger.info("My Plan Indicator is " + planId);
			if(planId == 0) {
				planId = Integer.parseInt(UniptestCache.GetInstance().GetAppConfigParam("DEFAULT_RATE_PLAN"));
				logger.debug("plan id is " + planId);
			}
			return planId;
		} catch (Exception e) {
			logger.info("Exception is getting plan id=" + e.getMessage());
			return -1;
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public int InsertIntoGmat(String Msisdn, String key, Hashtable Error_String) {
		logger.info("INSERT INTO GMAT ==Msisdn " + Msisdn + " key  " + key + " string is " + Error_String);
		String TemplateMessage = null;
		int index = key.indexOf("+");
		if (index != -1) {
			logger.info("value of index" + index);
			TemplateMessage = key.substring(key.indexOf("+") + 1, key.length());
		} else {
			TemplateMessage = UniptestCache.GetInstance().getTemplate(key);
			if (TemplateMessage == null) {
				logger.info("Their is no template define");
				return -1;
			}
		}
		if (Error_String.size() != 0) {
			logger.info("Error_String size is greater than 0");
			Err_Msg = CreateTemplate(TemplateMessage, Error_String);
		} else {
			logger.info("Error_String size is equal to 0");
			Err_Msg = TemplateMessage;
		}
		logger.info("Template message is " + Err_Msg);
		try {
			String ORG_NUM = null;
		    ORG_NUM = UniptestCache.GetInstance().GetAppConfigParam("MCA_SMS_NUMBER"); // added by Avishkar on 18/8/2020
//			ORG_NUM = UniptestCache.GetInstance().GetAppConfigParam("SMS_ORIGINATION_NUMBER_MCA"); // commented by Avishkar on 18/8/2020
			if (ORG_NUM == null) {
				logger.info("NO ORIGINATION NUMBER FOUND ");
				return -1;
			}
			logger.info(" values are " + ORG_NUM + Msisdn + Err_Msg);

			query = DBQueries.INSERT_INTO_GMAT_MESSAGE_STORE;
			
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			jdbcTemplate.update(query, new Object[]{ORG_NUM, Msisdn, Err_Msg});	
			int retval = insertResponseMdr(Err_Msg, Msisdn.trim());
			if (retval < 0) {
				logger.info("Not successfully inserted");
			} else {
				logger.info("Successfully inserted");
			}

		}catch (Exception e) {
			logger.info("Exception is getting plan id=" + e.getMessage());
			return -1;
		}
		return 0;
	}

	public String getHelpMess(String ProcessName, String lang_id) {
		
		String HelpMess = "";
		String query = DBQueries.GET_HELP_MESSAGE;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			HelpMess = (String)jdbcTemplate.queryForObject(query,
					new Object[]{ProcessName, Integer.parseInt(lang_id)},String.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return HelpMess;
	}

	public String getHelpMess1() {
		StringBuffer HelpMess = new StringBuffer();
		String query = DBQueries.GET_HELP_MESSAGE_KEYWORD;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for (Map<String,Object> row : rows) {
				HelpMess = HelpMess.append(row.get("REQUEST_KEYWORD") + " ");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return HelpMess.toString();
	}
	
	public int sendMCAMessage(String shortcode, String msisdn, int status, String worker) {
		UnipRequest unipReq = new UnipRequest(shortcode, msisdn, status);
		unipReq.setWorker(worker);
		try {
			String langId = UniptestCache.GetInstance().GetAppConfigParam("DEFAULT_LANGUAGE_ID");
			UniptestCache.GetInstance();
			String template_message = null, construct_message = null, temp_message = null, org_num = null,
					date_of_call = null, time_of_call = null;
			Hashtable<String, String> replace = null;
			int call_counter, service_type;
			boolean recordExist = false;
			logger.info("worker ["+worker+"] msisdn ["+unipReq.getMsisdn()+"] sc ["+unipReq.getShortCode()+"] "
					+ "status ["+unipReq.getStatus()+"]");
			List<McaNotification> list = unipService.getMcaNotificationDetail(unipReq);
			//modification by Kuldeep on 06/06/2021 - get languafe id from mca_call_detail table
			int bPartyLangId = 1;
			try { bPartyLangId = Integer.parseInt(list.get(0).getLanguageId().trim());
			} catch (Exception e) {
				bPartyLangId = Integer.parseInt(langId);
			}
			logger.info("Destination Number (B Party) template message languge id: "+bPartyLangId+", Getting from mca_call_detail");
			logger.info("OrgNumber (A Party) template message languge id: "+langId+", Getting from catche - DEFAULT_LANGUAGE_ID");
			template_message = UniptestCache.GetInstance()
					.getTemplate(UniptestCache.GetInstance().GetAppConfigParam("MCA_SMS_ALERT_ID") + "-" + bPartyLangId);
			StringBuffer message = new StringBuffer();
			logger.info("template_message ["+template_message+"]");
			if (Integer.parseInt(UniptestCache.GetInstance().GetAppConfigParam("COMBINE_SMS_ENABLE")) == 1) {
				temp_message = template_message.substring(0, template_message.indexOf("$", 0));
				template_message = template_message.substring(template_message.indexOf("$", 0),
						template_message.length());
				message = message.append(temp_message);
				logger.info("worker ["+worker+"] msisdn ["+unipReq.getMsisdn()+"] sc ["+unipReq.getShortCode()+"] "
						+ "status ["+unipReq.getStatus()+"] template ["+temp_message+"] message ["+message+"]");
			}

			for(McaNotification mca: list) {
				org_num = mca.getOrgNumber();
				logger.info("worker ["+worker+"] a-party ["+mca.getOrgNumber()+"] b-party ["+unipReq.getMsisdn()+"] "
						+ "sc ["+unipReq.getShortCode()+"] going to send notification");
				date_of_call = mca.getDateOfCall();
				time_of_call = mca.getTimeOfCall();
				call_counter = mca.getCallCounter();
				service_type = mca.getServiceType();
				replace = new Hashtable<String, String>();
				if (service_type >= 1) {
					/*replace.put("$(calling_time)", call_time + ",");*/
					replace.put("$(calling_time)", date_of_call+" "+time_of_call);
					replace.put("$(date_of_call)", date_of_call);
					replace.put("$(time_of_call)", time_of_call);
					replace.put("$(calling_number)", org_num);
					replace.put("$(no_of_calls)", call_counter + "");
					/**** B-Party message start here*/
					if (Integer.parseInt(UniptestCache.GetInstance().GetAppConfigParam("COMBINE_SMS_ENABLE")) == 0) {
						// modification start by Kuldeep on 27/05/2021
						String singleCountMcaAlert = UniptestCache.GetInstance()
								.getTemplate(UniptestCache.GetInstance().GetAppConfigParam("ONE_COUNT_MCA_SMS_ALERT_ID") + "-" + bPartyLangId);
						if(singleCountMcaAlert != null && call_counter == 1) {
							construct_message = CreateTemplate(singleCountMcaAlert, replace);
							message = new StringBuffer(construct_message);
						} else {
							construct_message = CreateTemplate(template_message, replace);
							message = message.append(construct_message);
						}
						
						mca.setMessage(message.toString());
						mca.setBparty(true);
					// modification start by Avishkar on 18/8/2020
						if (Integer.parseInt(UniptestCache.GetInstance().GetAppConfigParam("MCA_SMS_SENDER_CPN"))==0){
							mca.setOrgNumber(UniptestCache.GetInstance().GetAppConfigParam("MCA_SMS_NUMBER"));
						}
						
						/*if (!UniptestCache.GetInstance().GetAppConfigParam("SMS_ORIGINATION_NUMBER_MCA")
								.equalsIgnoreCase("NA")){
							mca.setOrgNumber(UniptestCache.GetInstance().GetAppConfigParam("SMS_ORIGINATION_NUMBER_MCA"));
						}*/
					// modification end by Avishkar on 18/8/2020
						
						
						logger.info("worker ["+worker+"] a-party ["+mca.getOrgNumber()+"] b-party ["+unipReq.getMsisdn()+"] "
								+ "sc ["+unipReq.getShortCode()+"] send b-party notification ["+mca.getMessage()+"]");
						unipService.storeMsgInGmat(unipReq, mca);
						message = new StringBuffer();
						mca.setOrgNumber(org_num);
					} else {
						construct_message = CreateTemplate(template_message, replace);
						if ((message.length() + construct_message.length()) >= UniptestCache.messageLength) {
							mca.setMessage(message.toString());
							mca.setBparty(true);
						// modification start by Avishkar on 18/8/2020
							if (Integer.parseInt(UniptestCache.GetInstance().GetAppConfigParam("MCA_SMS_SENDER_CPN"))==0){
								mca.setOrgNumber(UniptestCache.GetInstance().GetAppConfigParam("MCA_SMS_NUMBER"));
							}
							/*if (!UniptestCache.GetInstance().GetAppConfigParam("SMS_ORIGINATION_NUMBER_MCA")
									.equalsIgnoreCase("NA")){
								mca.setOrgNumber(UniptestCache.GetInstance().GetAppConfigParam("SMS_ORIGINATION_NUMBER_MCA"));
							}*/
						// modification end by Avishkar on 18/8/2020
							logger.info("worker ["+worker+"] a-party ["+mca.getOrgNumber()+"] b-party ["+unipReq.getMsisdn()+"] "
									+ "sc ["+unipReq.getShortCode()+"] send b-party notification ["+mca.getMessage()+"]");
							unipService.storeMsgInGmat(unipReq, mca);
							logger.debug("worker ["+worker+"] a-party ["+mca.getOrgNumber()+"] b-party ["+unipReq.getMsisdn()+"] "
									+ "sc ["+unipReq.getShortCode()+"] total message ["+message.toString()+"]");
							message = new StringBuffer();
							message = message.append(temp_message);
							mca.setOrgNumber(org_num);
						}
						message = message.append(construct_message);
					}
					/**** B-Party message end here*/
					
					/**** A-Party message start here*/
					if (Integer.parseInt(UniptestCache.GetInstance().GetAppConfigParam("MCA_SEND_APARTY_SMS")) == 1) {
						mca.setBparty(false);
						logger.info("worker ["+worker+"] a-party ["+mca.getOrgNumber()+"] b-party ["+unipReq.getMsisdn()+"] "
								+ "sc ["+unipReq.getShortCode()+"] going to send a-party notification");
						if (Integer.parseInt(
								UniptestCache.GetInstance().GetAppConfigParam("SEND_APARTY_SMS_OTHER_OPERATOR")) == 1) {
							recordExist = unipService.getOperatorRange(unipReq, mca);
						}
						if (recordExist) {
							String _msisdn = msisdn;
							logger.info("worker ["+worker+"] a-party ["+mca.getOrgNumber()+"] b-party ["+unipReq.getMsisdn()+"] "
									+ "sc ["+unipReq.getShortCode()+"] a-party record exist into database");
							if (UniptestCache.CountryCodeAlertEnable == 0) {
								_msisdn = getCountryCodeFreeMsisdn(_msisdn);
							}

							String temp_mess = UniptestCache.GetInstance()
									.getTemplate(UniptestCache.GetInstance().GetAppConfigParam("MCA_SMS_APARTY_ALERT_ID") + "-" + langId);
							temp_mess = temp_mess.replace("$(called_number)", _msisdn);
							mca.setMessage(temp_mess);
							
							String destNum = unipReq.getMsisdn();
							if (!UniptestCache.GetInstance().GetAppConfigParam("SMS_ORIGINATION_NUMBER_MCA")
									.equalsIgnoreCase("NA")) {
								//Modified date 29-05-2021
								unipReq.setMsisdn(UniptestCache.GetInstance().GetAppConfigParam("SMS_ORIGINATION_NUMBER_MCA")); // it's origination when sending msg to A party
								unipService.storeMsgInGmat(unipReq, mca);
								unipReq.setMsisdn(destNum);
								destNum = null;
							} else {
								unipService.storeMsgInGmat(unipReq, mca);
							}
							mca.setOrgNumber(org_num);
							logger.info("worker ["+worker+"] a-party ["+mca.getOrgNumber()+"] b-party ["+unipReq.getMsisdn()+"] "
									+ "sc ["+unipReq.getShortCode()+"] temp message ["+temp_mess+"]");
						}
					}
					/*** A-Party message end here ***/
				}
			}

			/*** Default message start here *****/
			
			McaNotification mca = new McaNotification();
			mca.setOrgNumber(org_num);
			if (message.length() < UniptestCache.messageLength && message.length() != 0) {
				mca.setBparty(true);
				logger.info("worker ["+worker+"] a-party ["+mca.getOrgNumber()+"] b-party ["+unipReq.getMsisdn()+"] "
						+ "sc ["+unipReq.getShortCode()+"] send default b-party message");
			// modification start by Avishkar on 18/8/2020
				if (Integer.parseInt(UniptestCache.GetInstance().GetAppConfigParam("MCA_SMS_SENDER_CPN"))==0){
					mca.setOrgNumber(UniptestCache.GetInstance().GetAppConfigParam("MCA_SMS_NUMBER"));
				}
				/*if (!UniptestCache.GetInstance().GetAppConfigParam("SMS_ORIGINATION_NUMBER_MCA")
						.equalsIgnoreCase("NA")){
					mca.setOrgNumber(UniptestCache.GetInstance().GetAppConfigParam("SMS_ORIGINATION_NUMBER_MCA"));
				}*/
			// modification end by Avishkar on 18/8/2020
				
				mca.setMessage(message.toString());
				unipService.storeMsgInGmat(unipReq, mca);
				mca.setOrgNumber(org_num);
			}
			/*** Default message end here *****/
			/**** Added by Vivek Kumar ****/
			if(AppConfig.config.getBoolean("PRODUCTION",true) && list.size()>0){ // modified by Avishkar
				unipService.deleteMcaDetailOfUser(unipReq);
			}
			return 0;
		} catch (Exception e) {
			logger.error("exception in process request" + e.toString());
			e.printStackTrace();
			return -1;
		}

	}
}
