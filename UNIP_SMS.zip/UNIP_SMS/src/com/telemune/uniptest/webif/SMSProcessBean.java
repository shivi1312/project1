package com.telemune.uniptest.webif;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Telemune
 */
public class SMSProcessBean {

	public int   getProcessId() {
		return ProcessId;
	}
	public int   getMinArg() {
                return MinArg;
        }
	public int   getMaxArg() {
                return MaxArg;
        }




	public SMSProcessBean(int MinArg , int MaxArg , int  ProcessId)
	{
		this.MinArg = MinArg;
		this.MaxArg = MaxArg;
		this.ProcessId = ProcessId;
	}

		
	int  MinArg=-1;
	int MaxArg=-1;	
	int ProcessId=-1;	
}

