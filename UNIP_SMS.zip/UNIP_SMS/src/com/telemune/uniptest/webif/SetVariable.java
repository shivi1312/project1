//ripu
package com.telemune.uniptest.webif;

import java.util.*;

public class SetVariable
{
	private String msisdn = "";
	public String fmsisdn = "";
	private String inter_face = "";
	private String sub_type = "";
	private String updated_by = "";
	private int lang;
	private int plan;
	public int rbt_code;
	public String days = "";
	public int start_t;
	public int end_t;
	public int check_rbt;
	public int groupId;
	public String date = "";
	public int albumId;
	public String albumName = "";
	public String groupName = "";
	public String control_name = "";
	public String occ_name = "";
	public int  service;
	private int language;
	private int planId;

	public int getLanguage() {
		return this.language;
	}
	public void setLanguage(int language) {
		this.language = language;
	}
	public int getPlanId() {
		return this.planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public SetVariable()
	{
		msisdn = "-1";
		inter_face = "NA";
		sub_type = "NA";
		updated_by = "NA";
		lang = 0;
		plan = 0;
		service=-99;
	}
	public int  getService()
	{
		return	this.service;
	}
	public  int setService(int  service)
	{
		this.service = service;
		return 0;
	}

	public String getMsisdn()
	{
		return		this.msisdn;
	}
	public int setMsisdn(String ms)
	{
		this.msisdn = ms;
		return 0;
	}

	public String getInterface()
	{
		return		this.inter_face;
	}
	public int setInterface(String inter)
	{
		this.inter_face = inter;
		return 0;
	}
	public String getOcc()
	{
		return		this.occ_name;
	}
	public String getSubType()
	{
		return		this.sub_type;
	}
	public int setSubType(String ms)
	{
		this.sub_type = ms;
		return 0;
	}
	public String getUpdatedBy()
	{
		return		this.updated_by;
	}
	public int setUpdatedBy(String ms)
	{
		this.updated_by = ms;
		return 0;
	}
	public int getPlan()
	{
		return this.plan;
	}
	public int getLang()
	{
		return this.lang;
	}
	public int setLang(int lang)
	{
		this.lang = lang;
		return 0;
	}
	public int setPlan(int plan)
	{
		this.plan = plan;
		return 0;
	}
}

