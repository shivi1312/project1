package com.telemune.uniptest.webif;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.AppConfig;

import commonutil.TLVAppInterface;

public class AdEngineHandler {
        static final Logger logger = Logger.getLogger(AdEngineHandler.class);
        public static final int MSISDN_TAG = 1;
        public static final int MSG_LENGTH = 2;
        public static final int TRXN_ID = 3;
        public static final int RESC_ID = 4;
        public static final int RESC_DESC = 5;
        public static final int AD_MSG = 6;

        public String appendAdMessage(String msisdn, int msg_length, int txn_id) {
                String res_code = null;
                String res_desc = null;
                String ad_msg = null;

                //String serverIp = "10.168.3.63";
                //int serverPort = Integer.parseInt("8119");
                String serverIp = AppConfig.config.getString("AD_ENGINE_IP");
                int serverPort = AppConfig.config.getInt("AD_ENGINE_PORT");

                TLVAppInterface tlvInterface = new TLVAppInterface();
                tlvInterface.setData(MSISDN_TAG, msisdn);
                tlvInterface.setData(MSG_LENGTH, msg_length);
                tlvInterface.setData(TRXN_ID, txn_id);

                tlvInterface.encode();
                tlvInterface.setServerIP(serverIp);
                tlvInterface.setServerPort(serverPort);
                tlvInterface.send();
                int receive = tlvInterface.receive();
                if (receive < 0) {
                        logger.error(" ["+txn_id+"] msisdn ["+msisdn+"]  Error in charging request execution");

                }
                res_code = tlvInterface.getData(RESC_ID);
                res_desc = tlvInterface.getData(RESC_DESC);

                if (Integer.parseInt(res_code) == 1) {
                    ad_msg = tlvInterface.getData(AD_MSG);

                    logger.info("["+txn_id+"] msisdn ["+msisdn+"] Response from adEngine ID [" + res_code + "] DESC ["
                                    + res_desc + "] AD_MSG [" + ad_msg + "]");

            } else {
                    ad_msg = "";
                    logger.error(" ["+txn_id+"] msisdn ["+msisdn+"]  Error in adEngine ID [" + res_code + "] DESC ["
                                    + res_desc + "]");

            }

            return ad_msg;

    }

}
