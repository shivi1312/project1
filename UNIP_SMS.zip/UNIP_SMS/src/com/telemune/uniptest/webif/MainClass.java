package com.telemune.uniptest.webif;

public class MainClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String version = "R1_0_0_0";
		System.out.println("The version of this Project is : ["+version+"]");
	}

}
