package com.telemune.uniptest.webif;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.dbutilities.AppContext;
import com.telemune.dbutilities.DBQueries;

public class UniptestCache {
	static final Logger logger = Logger.getLogger(UniptestCache.class);
	private static UniptestCache instance_ = null;
	public static String countryCode = "91";
	public static int msisdnLength = 10;
	public static int CountryCodeAlertEnable = 0;
	public static int messageLength = 160;
	private static Properties properties = null;
	private static HashMap<String, KeywordBean> SMSKeywords = new HashMap<String, KeywordBean>();
	private static HashMap<String, String> App_config_params = new HashMap<String, String>();
	private static HashMap<String, SMSProcessBean> SMSProcessDetail = new HashMap<String, SMSProcessBean>();
	private static HashMap<String, String> TemplateDetails = new HashMap<String, String>();
	public static ConcurrentHashMap<String, String> cacheMsisdnMap = new ConcurrentHashMap<String, String>(); // added by Avishkar
	
	@SuppressWarnings("unused")
	private static String DefaultLanguageId = "";

	static String chargingServerIp = "";
	static String chargingServerPort = "";

	public static UniptestCache GetInstance() {
		if (instance_ == null) {
			instance_ = new UniptestCache();
		}
		return instance_;
	}

	public static UniptestCache reLoad() {
		instance_ = new UniptestCache();
		return instance_;
	}

	private UniptestCache() {
		properties = new Properties();
		try {
			String catHome = System.getenv("PROPERTY_FILE_PATH");
			logger.info("property file path  || " + catHome + "");
			FileInputStream fis = null;
			if (catHome == null) {
				fis = new FileInputStream("/home/tomcat/.config/property/unipsms.properties");
			} else {
				fis = new FileInputStream(catHome + File.separator +"unipsms.properties");
			}
			properties.load(fis);
			fis.close();
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}
		DefaultLanguageId = properties.getProperty("DefaultlanguageId");
		chargingServerIp = properties.getProperty("CHARGING_SERVER_IP");
		chargingServerPort = properties.getProperty("CHARGING_SERVER_PORT");
		messageLength = Integer.parseInt(properties.getProperty("MSGLENGTH"));
		DBQueries dbOperations=new DBQueries(Integer.parseInt(properties.getProperty("DB_TYPE")));
		try {

			LoadSMSKeywords();
			LoadSMSProcessDetails();
			LoadSMSTemplates();
			LoadAppConfigParams();
		} catch (Exception e) {
			logger.error("Exception inside read property file" + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * /////////////////////// Loaded SMS Keywords //////////////////////
	 **/

	public KeywordBean getKeywordDetail(String keyword) {
		if (SMSKeywords.containsKey(keyword))
			return SMSKeywords.get(keyword);
		else if(SMSKeywords.containsKey(keyword.toUpperCase()))
			return SMSKeywords.get(keyword.toUpperCase());
		else if(SMSKeywords.containsKey(keyword.toLowerCase()))
			return SMSKeywords.get(keyword.toLowerCase());
		else
			return null;

	}

	@SuppressWarnings("unused")
	private int LoadSMSKeywords() {
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			String query = DBQueries.LOAD_SMS_KEYWORDS;
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for (Map<String,Object> row : rows) {
				KeywordBean SMSKey = new KeywordBean((String)row.get("process_name"), (Integer)row.get("language_id"));
				SMSKeywords.put((String)row.get("request_keyword"), SMSKey);
			}
		}catch (Exception e) {
			logger.error("Exception insdie Load SMSKeyword()" + e.getMessage());
			e.printStackTrace();// TODO: handle exception
			return -1;
		}
		return 1;
	}

	/**
	 * //////////////////////// Load Sms Process Details
	 * /////////////////////////
	 **/

	public SMSProcessBean getProcesDetail(String ProcessName) {
		if (SMSProcessDetail.containsKey(ProcessName))
			return SMSProcessDetail.get(ProcessName);
		else
			return null;

	}

	@SuppressWarnings("unused")
	private int LoadSMSProcessDetails() {
		logger.info("in LoadSMSProcessDetails()");
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			String query = DBQueries.LOAD_SMS_PROCESS_DETAILS;
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for (Map<String,Object> row : rows) {
				SMSProcessBean process = new SMSProcessBean((Integer)row.get("min_arguments"), (Integer)row.get("max_arguments"),
						(Integer)row.get("process_id"));
				SMSProcessDetail.put((String)row.get("process_name"), process);
			}
		}catch (Exception e) {
			logger.error("Exception insdie Load SMSKeyword()" + e.getMessage());
			e.printStackTrace();// TODO: handle exception
			return -1;
		}
		return 1;

	}

	/**
	 * //////////////////// Load SMS Templates ////////////////////
	 */

	public String getTemplate(String key) {

		if (TemplateDetails.containsKey(key)) {
			return TemplateDetails.get(key);
		} else
			return null;

	}

	private int LoadSMSTemplates() {
		logger.info("in LoadSMSTemplates()");
		try {
			String key = "";
			String query = DBQueries.LOAD_SMS_TEMPLATES;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for (Map<String,Object> row : rows) {
				try{
					key = row.get("template_id") + "-" + row.get("language_id");
					TemplateDetails.put(key, (String)row.get("template_message"));
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}catch (Exception e) {
			logger.error("Exception insdie Load SMSKeyword()" + e.getMessage());
			e.printStackTrace();// TODO: handle exception
			return -1;
		}
		return 1;

	}

	/**
	 * /////////////////////// //Load Help Master ///////////////////////
	 */

	/**
	 * /////////////////////////////////////// ///// LOAD APP CONFIG PARAMS
	 * //////// ////////////////////////////////////
	 */

	public String GetAppConfigParam(String paramTag) {
		String _pname = paramTag.trim();
		_pname = _pname.toUpperCase();
		if (App_config_params.containsKey(_pname)) {
			return App_config_params.get(_pname);
		} else
			return null;
	}

	private int LoadAppConfigParams() {
		logger.info("in LoadAppConfigParams()");
		try {
			logger.info("*********************create connection******************************");
			String query = DBQueries.LOAD_APP_CONFIG_PARAMS;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			List<Map<String,Object>> rows = jdbcTemplate.queryForList(query);
			for (Map<String,Object> row : rows) {
				App_config_params.put(((String)row.get("PARAM_NAME")).toUpperCase().trim(), (String)row.get("PARAM_VALUE"));
			}
			countryCode = GetAppConfigParam("COUNTRY_CODE").toString();
			msisdnLength = Integer.parseInt(properties.getProperty("MSISDN_LENGTH").toString());
		}catch (Exception e) {
			System.out.println("Exception *********************");
			logger.error("Exception insdie LoadAppConfigParams()" + e.getMessage());
			e.printStackTrace();// TODO: handle exception
			return -1;
		}		
		return 1;

	}

	/**
	 * ///////////////////////////// //GET INTERNATIONAL NMBER////
	 * ////////////////////////////
	 * 
	 */

	public String getInternationalNumber(String number) {
		String retVal = "";
		if (number.startsWith("+")) {
			number = number.substring(1);
		}
		if (number.startsWith(countryCode)) {
			retVal = number;
		} else if (number.startsWith("0") || number.startsWith("00")) {
			if (number.startsWith("0")) {

				retVal = countryCode + number.substring(1, number.length());

			}
			if (number.startsWith("00")) {
				/* Commented By Richard on 26th Aug 2019
				 * retVal = countryCode + number.substring(2, number.length());*/
				retVal = number.substring(2, number.length());
			}
		} else if (number.length() < msisdnLength) {
			retVal = countryCode + number;
		} else if (number.length() == msisdnLength || number.length() > msisdnLength) {
			retVal = number;
		} else {
			retVal = countryCode + number;
		}
		logger.info("Msisdn [ " + number + " ]  International Format [ " + retVal + " ]");

		return retVal;
	}

	/**
	 * ////////////////////////////////// ///// Constructor ////////
	 * //////////////////////////////////
	 */

	public String getSSFServer() {
		try {
			String strSSFServer = properties.getProperty("SSF_SERVER_HOST");
			// System.out.println("SSF_SERVER_HOST="+ strSSFServer );
			return strSSFServer;
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	public short getSSFPort() {
		try {
			short shSSFPort = Short.parseShort(properties.getProperty("SSF_SERVER_PORT"));
			// System.out.println("SSF_SERVER_PORT="+ shSSFPort);
			return shSSFPort;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}

}
