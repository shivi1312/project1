package com.telemune.uniptest.webif;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Telemune
 */
public class KeywordBean {

	public int   getLangId() {
		return LangId;
	}

	public String getProcessName() {
		return ProcessName;
	}


	public KeywordBean(String ProcessName, int  LangId)
	{
		this.ProcessName = ProcessName;
		this.LangId = LangId;
	}

	String  ProcessName="";
	int  LangId=-1;

}

