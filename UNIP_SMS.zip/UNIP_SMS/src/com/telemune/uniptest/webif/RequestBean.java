/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.telemune.uniptest.webif;

/**
 *
 * @author telemune
 */
public class RequestBean
{

	//public String error="";
	public String Keyword="";
	public String Msisdn ="";
	public String Mess="";
	public RequestBean(String Keyword,String Msisdn,String Mess)
	{
		this.Keyword=Keyword;
		this.Msisdn=Msisdn;
		this.Mess=Mess;
		//this.error=error1;

	}


	public String getKeyword()
	{
		return Keyword;
	}

	

	public String getMess()
	{
		return Mess;
	}

	public String getMsisdn()
	{
		return Msisdn;
	}


	@Override
	public String toString() {
		return "RequestBean [Keyword=" + Keyword + ", Msisdn=" + Msisdn
				+ ", Mess=" + Mess + "]";
	}


}
