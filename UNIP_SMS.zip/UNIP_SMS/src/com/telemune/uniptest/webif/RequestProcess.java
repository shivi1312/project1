/*


 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.telemune.uniptest.webif;

import java.util.Hashtable;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.dbutilities.AppConfig;
/**
 *
 * @author telemune
 */
import com.telemune.sms.net.Connectionpool;
import com.telemune.sms.net.TextSocketConnection;
import com.telemune.sms.util.TcpPool;
import com.telemune.sms.util.UnipData;
import com.telemune.unified.model.UnipRequest;

import commonutil.TLVAppInterface;
public class RequestProcess
{
	static final Logger logger=Logger.getLogger(RequestProcess.class);
	 private VccRuleEngineResponse ruleEngineResponse=null;
	static DBEngine dbengine;
//	DBEngine dbenginesms;
	static final String Template_Id=null;
	String Msisdn ="";
	String Keyword="";
	String Error_String=null;
	String Mess = "";
	String error="";
	int value=-1;
	String value1=null;
	String lang_id=null;
	int validity=0;
	int minarg=0;
	int maxarg=0;
	int jsonRuleEable =0;
	Hashtable<String, String> replace=new Hashtable<String, String>();
	
	
	
    public static int REQTYPE_TAG=12;// Value changed from 1 to 12 for QCell Charging
	public static int BMSISDN_TAG=5;
    public static int MSISDN_TAG=2;
    public static int SUB_TYPE=7;
    public static int RBTCODE_TAG=4;
    public static int FMSISDN_TAG=5;
    public static int INTERFACE_TAG=8;
    public static int RESPONSE_TAG=6;
   
   
    public static int ACTION_TAG=3;
    public static int SERVICE_TAG=9;//
   //  public static int CHARGING_CODE_TAG=3;
      public static int TARIFFID_TAG=4;
     
	public RequestProcess(RequestBean req)
	{
		logger.info("calling constructor of RequestProcess");
		if(dbengine==null)
		dbengine = new DBEngine();
		this.Msisdn= req.getMsisdn();
		this.Keyword = req.getKeyword();
		this.Mess= req.getMess();
		//this.error = req.geterror();
//		this.lang_id=UniptestCache.GetInstance().GetAppConfigParam("DEFAULT_LANGUAGE_ID"); // commented by Avishkar on 19/8/2020
		this.lang_id=UniptestCache.GetInstance().GetAppConfigParam("vms_default_language"); // modified by Avishkar on 19/8/2020
		this.jsonRuleEable =  AppConfig.config.getInt("RULE_ENGINE_JSON_ENABLE",0);
	}
	public RequestProcess()
	{
		if(dbengine==null)
		dbengine = new DBEngine();
	//	dbenginesms = new DBEngine();
	}
	public void setRequest(RequestBean req)
	{
		logger.info("setting the parameter of Request");
		if(dbengine==null)
		{
			logger.info("Inside dbengine");
		dbengine = new DBEngine();
		}
		this.Msisdn= req.getMsisdn();
		
		this.Keyword = req.getKeyword();
		
		this.Mess= req.getMess();
	
		//this.error = req.geterror();
//		this.lang_id=UniptestCache.GetInstance().GetAppConfigParam("DEFAULT_LANGUAGE_ID"); // commented by Avishkar on 19/8/2020
		this.lang_id=UniptestCache.GetInstance().GetAppConfigParam("vms_default_language"); // modified by Avishkar on 19/8/2020
		this.jsonRuleEable =  AppConfig.config.getInt("RULE_ENGINE_JSON_ENABLE",0);
		logger.info("language value is "+lang_id+" Json Rule Engine Eable ["+this.jsonRuleEable+"]");
		//logger.info("request bean is"+req.toString());
	}
		
	@SuppressWarnings("unused")
	public int Process() 
	{
		logger.info("in Process Method");
		int result =-1;
		logger.info("Get request of msisdn " + Msisdn + " with keyword "
				+ Keyword.toUpperCase() + " with message[" + Mess
				+ "] with error[" + error + "]");
		String keyword = Keyword.toUpperCase();		
		KeywordBean key = (KeywordBean)UniptestCache.GetInstance().getKeywordDetail(keyword);
		lang_id = key.LangId+""; //added by kuldeep on 05/06/2021
		logger.info("LANGUAGE_ID ["+lang_id+"] getting from lbs_parser_master where REQUEST_KEYWORD ["+keyword+"]");
		String TemplateKey= "";
//		TemplateKey="16"+"-"+lang_id; // commented by Avishkar on 21/8/2020
		TemplateKey="37"+"-"+lang_id; // modified by Avishkar on 21/8/2020
		if(key==null)
		{
			logger.info("Keyword does not exist in database");
			value=dbengine.InsertIntoGmat(Msisdn.trim(),TemplateKey,replace);
			return value;
		}
		else
		{
			SMSProcessBean sms = (SMSProcessBean)UniptestCache.GetInstance().getProcesDetail(key.ProcessName);
			if(sms==null)
			{
				logger.info("Process does not exist in databse ");
				value=dbengine.InsertIntoGmat(Msisdn.trim(),TemplateKey,replace);
				return value;
			}
			else
			{
				int maxarg = sms.MaxArg;
				int minarg = sms.MinArg;
				String Process = key.getProcessName().toUpperCase();
				logger.info("Start with process name =="+Process+" with min args "+minarg+" with max arg "+maxarg+" with msisdn "+Msisdn +"with lang_id"+lang_id);
				if(Process.equalsIgnoreCase("SUBSCRIBE"))
				{
					value=Subscribe(minarg,maxarg,lang_id);
				}
				else if(Process.equalsIgnoreCase("SUBMCA"))
				{
					value= handleMcaSubscription(minarg,maxarg,lang_id);
				}
				else if(Process.equalsIgnoreCase("SUBVMS"))
				{
					value= handleVmsSubscription(minarg,maxarg,lang_id);
				}
				else if(Process.equalsIgnoreCase("SUBVN"))
				{
					value=handleVNSubscription(minarg,maxarg,lang_id);
				}
				else if(Process.equalsIgnoreCase("UNSUBSCRIBE"))
				{
					value=Unsubscribe(minarg,maxarg,lang_id);
				}
				else if(Process.equalsIgnoreCase("UNSUBMCA"))
				{
					value=handleMcaUnsubscription(minarg,maxarg,lang_id);
				}
				else if(Process.equalsIgnoreCase("UNSUBVMS"))
				{
					value=handleVmsUnsubscription(minarg,maxarg,lang_id);
				}
				else if(Process.equalsIgnoreCase("UNSUBVN"))
				{
					value=handleVNUnsubscription(minarg,maxarg,lang_id);
				}
				
				else if(Process.equalsIgnoreCase("GETPASSWORD"))
				{
					value=getPassword(minarg,maxarg,lang_id);
				}
				else if(Process.equalsIgnoreCase("HELP"))
				{
					value=getHelp(minarg,maxarg,lang_id);
				}
				else if(Process.equalsIgnoreCase("CHANGELANGUAGE"))
				{
					value=handleChangeLanguage(minarg,maxarg,lang_id);
				}
				else if(Process.equalsIgnoreCase("PULL"))
				{
					value=handlegetMcaMessages(minarg,maxarg,lang_id);
				}
			}
		}

		return value;  
	}
	///////////////////handle pull messages///////////
	public int handlegetMcaMessages(int MinArg,int MaxArg,String lang_id)
	{
		SetVariable setvar=new SetVariable();
		int chargingCode=-1;
		int language=-1;
		int rateplan=-1;
		Mess=Mess.replaceAll("%20", " ");
		String MessArray[]=Mess.split(" ");
		logger.info("Size of MessArray "+MessArray.length);
		logger.info("value of minarg="+MinArg+" "+"value of maxarg="+" "+MaxArg+"value of lang_id="+lang_id);
		replace.clear();
		if(MessArray.length < MinArg)
		{
			logger.info("User sent less arguments ");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			
			return value;
		}
		else if(MessArray.length > MaxArg)
		{
			logger.info("User sent Maximum Arguments");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}	
		int status=0;
		String shortcode="121";
		
		int retCheckSub=dbengine.CheckSubscription(language,Msisdn.trim(),setvar);
		/* Commented By Richard on 14th June 2019
		 * 
		 * if(retCheckSub==-1)
		{
			rateplan=Integer.parseInt(UniptestCache.GetInstance().GetAppConfigParam("DEFAULT_RATE_PLAN"));
		}
		else
		{
			rateplan=1;
		}*/
		rateplan=setvar.getPlanId();
		int retCharge=dbengine.getChargingCode(rateplan,chargingCode);
		if(retCharge<0)
		{
			logger.info("There is any error in getting charging code");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"17"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020 
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"38"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}

		int charging=doCharging(Msisdn.trim(),retCharge,Integer.parseInt(lang_id),"S","P","MCA");
		if(charging==-1)
		{
			logger.info("error in charging code");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"17"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020 
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"38"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
int retVal=dbengine.sendMCAMessage(shortcode,Msisdn.trim(), status,"NA");
		
		if(retVal<0)
		{
			logger.info("You have not any Missed call alert");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"35"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"48"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		logger.info("Alert inserted successfully");
		return retVal;
		
	}
	//////////Change language ////////////
	public int handleChangeLanguage(int MinArg,int MaxArg,String lang_id)
	{
		SetVariable setvar=new SetVariable();
		int oldLanguage=-1;
		int languageId=-1;
		String language=null;
		
		Mess=Mess.replaceAll("%20", " ");
		String MessArray[]=Mess.split(" ");
		logger.info("Size of MessArray "+MessArray.length);
		logger.info("value of minarg="+MinArg+" "+"value of maxarg="+" "+MaxArg+"value of lang_id="+lang_id);
		replace.clear();
		if(MessArray.length < MinArg)
		{
			logger.info("User sent less arguments ");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		else if(MessArray.length > MaxArg)
		{
			logger.info("User sent Maximum Arguments");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		setvar=new SetVariable();
		int key=dbengine.CheckSubscription(oldLanguage,Msisdn.trim(),setvar);
		logger.info("user subscribe for language "+setvar.getLanguage());
		if(key==-3)
		{
			logger.info("User is not Subscribed Uniptest service");
				
//			value= dbengine.InsertIntoGmat(Msisdn.trim(),"21"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value= dbengine.InsertIntoGmat(Msisdn.trim(),"40"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		else if(key==-1)
		{
			logger.info("There is any error when check subscription");
			
//			value= dbengine.InsertIntoGmat(Msisdn.trim(),"17"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value= dbengine.InsertIntoGmat(Msisdn.trim(),"38"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		language=MessArray[0];
		if(!language.trim().equalsIgnoreCase("ENGLISH")||!language.trim().equalsIgnoreCase("A")||!language.trim().equalsIgnoreCase("E")||!language.trim().equalsIgnoreCase("AN"))
		{
			logger.info("language id is"+MessArray[1]);
			languageId=1;
		}
		else if(!language.trim().equalsIgnoreCase("LUGANDA")||!language.trim().equalsIgnoreCase("F")||!language.trim().equalsIgnoreCase("FR"))
		{
			logger.info("language id is"+MessArray[1]);
			languageId=2;
		}
		if(MessArray.length==2)
		{
			languageId=Integer.parseInt(MessArray[1]);
		}
		if(languageId!=1 && languageId!=2)
		{
			logger.info("user has entered wrong language code other than 1 or 2");
//			value= dbengine.InsertIntoGmat(Msisdn.trim(),"20"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value= dbengine.InsertIntoGmat(Msisdn.trim(),"39"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		if(setvar.getLanguage()==languageId)
		{
			logger.info("old language id [ "+ setvar.getLanguage() +" ] and new language ID [ "+languageId+" ] is same");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"44"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"49"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		int retLanguage=dbengine.updateLanguage(languageId,Msisdn.trim());
		if(retLanguage<0)
		{
			logger.info("Language is not updated succeessfully");
//			value= dbengine.InsertIntoGmat(Msisdn.trim(),"17"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value= dbengine.InsertIntoGmat(Msisdn.trim(),"38"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		else
		{
			logger.info("Language change successfully");
//			value= dbengine.InsertIntoGmat(Msisdn.trim(),"22"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value= dbengine.InsertIntoGmat(Msisdn.trim(),"41"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		
	}
	/**
	 *
	//////////////////////////////
	/////////Subscriber Process////////
	//////////////////////////////
	 */
	public int Subscribe(int MinArg,int MaxArg,String lang_id)
	{
		
		
		logger.info("Subscription Process Function ");
	
		String user_validity=null;
		String service_type=null;
		String  Service="";
		logger.info("before replaceall()");
		Mess=Mess.replaceAll("%20", " ");
		logger.info("afterreplaceall()");
		String MessArray[]=Mess.split(" ");
		logger.info("Size of MessArray "+MessArray.length);
		logger.info("Message is "+Mess);
	//	replace.clear();
		try
		{
			
		if(MessArray.length < MinArg)
		{
			logger.info("User sent less arguments ");
			replace.clear();
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		else if(MessArray.length > MaxArg)
		{
			logger.info("user send maximum argument "+MessArray.length);
			replace.clear();
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		if(MessArray.length==3)
		{
			service_type=MessArray[1];
			user_validity=MessArray[2];
		}
		else if(MessArray.length==2)                /////////if messArray.length==2
		{
			service_type=MessArray[1];
			validity=30;
			user_validity="MONTHLY";
		}
		else
		{
			logger.info("user send maximum argument "+MessArray.length);
			replace.clear();
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		if(MessArray[1].equalsIgnoreCase("MCA"))
		{
			
			if(this.jsonRuleEable==1)
			Service="0001";
			else
			Service="1";	
		}
		else if(MessArray[1].equalsIgnoreCase("VMS"))
		{
			//Service="2";
			if(this.jsonRuleEable==1)
			Service="0010";
			else
			Service="2";
			
		}
		else if(MessArray[1].equalsIgnoreCase("VN"))
		{
			if(this.jsonRuleEable==1)
			Service="0100";
			else
			Service="2";
		}
		else if(MessArray[1].equalsIgnoreCase("VSSMS"))
		{
			if(this.jsonRuleEable==1)
				Service="0100";
			else
				Service="3";
		}
		else if(MessArray[1].equalsIgnoreCase("VM"))
		{
			if(this.jsonRuleEable==1)
				Service="0010";
			else
				Service="2";
			
		}
		else
		{
			logger.info("You have entered wrong choice");
			replace.clear();
			replace.put("$(service)",service_type);
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"25"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"43"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		if(user_validity.equalsIgnoreCase("DAILY") || user_validity.equalsIgnoreCase("D"))
		{
			validity=1;
		}
		else if(user_validity.equalsIgnoreCase("WEEKLY") || user_validity.equalsIgnoreCase("W"))
		{
			validity=7;
		}
		else if(user_validity.equalsIgnoreCase("MONTHLY") || user_validity.equalsIgnoreCase("M"))
		{
			validity=30;
		}
		else if(user_validity.equalsIgnoreCase("YEARLY") || user_validity.equalsIgnoreCase("Y"))
		{
			validity=365;
		}
		else
		{
			logger.info("You have entered wrong choice ");
			replace.clear();
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"25"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"43"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}

			
			logger.info("Calling RuleEngine");
			int SendRule= sendToRuleEngine(Service,1,lang_id);
			if(SendRule<0)
			{
				logger.info("value of send Rule is"+SendRule);
				if(Error_String.toLowerCase().contains("already subscribed"))
				{
					value= dbengine.InsertIntoGmat(Msisdn.trim(),"10"+"-"+lang_id,replace);
				}
				else
				{
					replace.clear();
					replace.put("$(errorstr)",Error_String);
					logger.info("Error String is"+Error_String);
//					value= dbengine.InsertIntoGmat(Msisdn.trim(),"15"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
					value= dbengine.InsertIntoGmat(Msisdn.trim(),"36"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
				}
				
			}
			else
			{
				dbengine.insertResponseMdr("SUBSCRIBED SUCCESSFULLY", Msisdn.trim());
			}
			logger.info("value of sendRule is"+ SendRule);
			return SendRule;
			}
	catch(Exception e)
	{
		logger.error("Exception inside Subscribe()"+e.getMessage());
		e.printStackTrace();
		return -1;
	}
		
	}
	
	
	/**
	 *
	//////////////////////////////////
	///////SUB Voice Note Process////////////
	////////////////////////////
	 */
	public int handleVNSubscription(int minarg,int maxarg,String lang_id)
	{
		String time="M";
		
		logger.info("Handle VNSubscription Process");
		
		Mess=Mess.replaceAll("%20"," ");
		String MessArray[]=Mess.split(" ");
		logger.info("size of Messarray="+MessArray.length);
		if(MessArray.length==2)
		{
			time=MessArray[1];
		}
		String command="SUB";
		String service="VN";
		Mess=command+" "+service+" "+time;
		logger.info("Message is "+Mess);
		int value=Subscribe(minarg,maxarg,lang_id);
		return value;
	}
	
	
	/**
	 *
	//////////////////////////////////
	///////SUBMCA Process////////////
	////////////////////////////
	 */
	public int handleMcaSubscription(int minarg,int maxarg,String lang_id)
	{
		String time="M";
		
		logger.info("Handle McaSubscription Process");
	
		Mess=Mess.replaceAll("%20"," ");
		String MessArray[]=Mess.split(" ");
		logger.info("size of Messarray="+MessArray.length);
		if(MessArray.length==2)
		{
			time=MessArray[1];
		}
		String command="SUB";
		String service="MCA";
		Mess=command+" "+service+" "+time;
		logger.info("Message is "+Mess);
		int value=Subscribe(minarg,maxarg,lang_id);
		return value;
	}
	/**
	 *
	///////////////////////////////
	/////SUBVMS Process////////////
	//////////////////////////////
	/////////////////////////////
	 */
	public int handleVmsSubscription(int minarg,int maxarg,String lang_id)
	{
		String time="M";
	
		logger.info("handle VmsSubscription Process");
	
		Mess=Mess.replaceAll("%20"," ");
		String MessArray[]=Mess.split(" ");
		logger.info("Size of Messarray="+MessArray.length);
		if(MessArray.length==2)
		{
			time=MessArray[1];
		}
		String command="SUB";
		String service="VMS";
		Mess=command+" "+service+" "+time;
		int value=Subscribe(minarg,maxarg,lang_id);
		return value;
	}
	public int sendToRuleEngine(String Service, int request,String lang_id)
	{
		logger.info("Inside Send Tio Rule Engine. ServiceType[" + Service
				+ "] Request[" + request + "] langId[" + lang_id + "]");
		try {
			if (Service.equalsIgnoreCase("0100")
					|| Service.equalsIgnoreCase("0010")
					|| Service.equalsIgnoreCase("0001")) {
				String result = null;
				Gson gson = new Gson();
				SMSRuleEngineRequest smsSubscribeRequest = new SMSRuleEngineRequest();
				smsSubscribeRequest.setMsisdn(Msisdn);
				smsSubscribeRequest.setServiceType(Service);
				smsSubscribeRequest.setInterFace("S");
				smsSubscribeRequest.setChannel("SMS");
				smsSubscribeRequest.setActionId(request);
				smsSubscribeRequest.setSubType("P");
				smsSubscribeRequest.setTid(String.valueOf(System.nanoTime()));
				smsSubscribeRequest.setReqBy(Msisdn);
			// modification start by Avishkar on 18/8/2020	
				if (Service.equalsIgnoreCase("0100"))
//					smsSubscribeRequest.setPlanName("DEFAULT");
//					smsSubscribeRequest.setPlanName(AppConfig.config.getString("VN_DEFAULT_PLAN")); //("VN_DEFAULT_PLAN");
					smsSubscribeRequest.setPlanName(UniptestCache.GetInstance().GetAppConfigParam("VN_DEFAULT_PLAN"));
				else if (Service.equalsIgnoreCase("0001"))
//					smsSubscribeRequest.setPlanName("DEFAULT");
//					smsSubscribeRequest.setPlanName(AppConfig.config.getString("MCA_DEFAULT_PLAN")); //("MCA_DEFAULT_PLAN");
					smsSubscribeRequest.setPlanName(UniptestCache.GetInstance().GetAppConfigParam("MCA_DEFAULT_PLAN"));
				else if (Service.equalsIgnoreCase("0010"))
//					smsSubscribeRequest.setPlanName("EXECUTIVE");
//					smsSubscribeRequest.setPlanName(AppConfig.config.getString("VM_DEFAULT_PLAN")); //("VM_DEFAULT_PLAN");
					smsSubscribeRequest.setPlanName(UniptestCache.GetInstance().GetAppConfigParam("VM_DEFAULT_PLAN"));
			// modification end by Avishkar on 18/8/2020
				smsSubscribeRequest.setLang(Integer.parseInt(lang_id));
				/*
				 * Commented by Richard on 13th June 2019
				 * 
				 * smsSubscribeRequest.setAppId("vcc");
				 */

				String jsonObj = gson.toJson(smsSubscribeRequest);
				result = sendSubUnscribeRequest(jsonObj);
				//Error_String = "UNKNOWN ERROR PLEASE TRY LATER";
				// logger.info("Error_string is"+Error_String);
				logger.info("result from rule engine is" + result);
				if (result != null) {
					logger.info("rule engine respone " + result);
					this.ruleEngineResponse = new Gson().fromJson(result,
							VccRuleEngineResponse.class);
					Error_String = this.ruleEngineResponse.getMsg();
				} else {
					logger.error("error in rule-engine response " + result);
				}

				if (ruleEngineResponse.getResult().equalsIgnoreCase("success"))
					return 1;
				else
					return -1;
			}

			else {
				int planId = 0;
				planId = dbengine.getRatePlan(Integer.parseInt(Service),
						validity);

				SetVariable sv = new SetVariable();
				sv.setMsisdn(Msisdn);
				sv.setPlan(planId);
				sv.setInterface("S");
				sv.setUpdatedBy(Msisdn);
				sv.setLang(Integer.parseInt(lang_id));
				sv.setSubType("N");
				sv.setService(Integer.parseInt(Service));
				logger.info("Service=" + Service);
				VMSRequest vms_req = new VMSRequest();

				vms_req.constructQuery(request, sv);
				int ret_val = vms_req.send();
				replace.clear();
				Error_String = vms_req.err_string;
				logger.info("Error_string is" + Error_String);
				logger.info("return string is " + vms_req.err_string
						+ "values return is " + ret_val);
				return ret_val;
			}
		} catch (Exception ee) {
			logger.info("ee.getMessage()" + ee.getMessage());
			ee.printStackTrace();
			return -1;
		}
	}
	
	
	
	public String sendSubUnscribeRequest(String json) {
        TextSocketConnection socketConnection = null;
        String response = null;
        try {
                Connectionpool connectionPool = TcpPool.getRuleEngineConPool();
                socketConnection = connectionPool.getConnection();
                logger.info("Server has connected!\n");
                logger.info("Sending string: '" + json + "'\n");
                socketConnection.write(json);
                response = socketConnection.readLine();
                /*if(response != null){
                        logger.error("rule engine respone "+response);
                        this.ruleEngineResponse = new Gson().fromJson(response,
                                        VccRuleEngineResponse.class);
                }else{
                        logger.error("error in rule-engine response "+response);
                }*/
        } catch (Exception e) {
                e.printStackTrace();
        } finally {
                try {
                        socketConnection.close();
                } catch (Exception e) {

                }
        }
        return response;
}
	
	
	/**
	 *
	/////////////////////////////////////////////
	//////////////Unsubscribe process/////////////
	/////////////////////////////////////////////
	////////////////////////////////////////////
	 */ 
	public int Unsubscribe(int MinArg,int MaxArg,String lang_id)
	{
		
		logger.info("Unsubscription Process Function ");
		
	
		String service_type=null;
		String Service="";
		Mess=Mess.replaceAll("%20", " ");
		String MessArray[]=Mess.split(" ");
		logger.info("Size of MessArray "+MessArray.length);
		replace.clear();
		if(MessArray.length==2)                
		{
			service_type=MessArray[1];
		}
		else
		{
			logger.info("wrong request");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		if(service_type!=null)
		{
			if(service_type.equalsIgnoreCase("MCA") || service_type.equalsIgnoreCase("CTQUI"))
			{
				//Service="1";
				if(this.jsonRuleEable==1)
					Service="0001";
				else
					Service="1";
				
			}
			else if(service_type.equalsIgnoreCase("VMS") || service_type.equalsIgnoreCase("REP"))
			{
				//Service="2";
				if(this.jsonRuleEable==1)
					Service="0010";
				else
					Service="2";
			}
			else if(service_type.equalsIgnoreCase("VN") || service_type.equalsIgnoreCase("REP"))
			{
				//Service="2";
				if(this.jsonRuleEable==1)
					Service="0100";
				else
					Service="2";
			}
			else if(service_type.equalsIgnoreCase("0100"))
			{
					Service="0100";
			}
			else
			{
				logger.info("You have entered wrong choice");
//				value=dbengine.InsertIntoGmat(Msisdn.trim(),"26"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
				value=dbengine.InsertIntoGmat(Msisdn.trim(),"44"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
				return value;
			}
		}
		else
		{
			logger.info("You have entered wrong choice");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"26"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"44"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		
		logger.info("Calling RuleEngine");
		int SendRule= sendToRuleEngine(Service,2,lang_id);
			if(SendRule<0)
			{
				logger.info("value of send Rule is"+SendRule);
				if(Error_String.toLowerCase().contains("not a subscriber"))
				{
//					value= dbengine.InsertIntoGmat(Msisdn.trim(),"27"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
					value= dbengine.InsertIntoGmat(Msisdn.trim(),"45"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
				}
				else
				{
					replace.clear();
					replace.put("$(errorstr)",Error_String);
					logger.info("Error String is"+Error_String);
//					value= dbengine.InsertIntoGmat(Msisdn.trim(),"15"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
					value= dbengine.InsertIntoGmat(Msisdn.trim(),"36"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
				}
				
			}
			else
			{
				dbengine.insertResponseMdr("UNSUBSCRIBED SUCCESSFULLY", Msisdn.trim());
			}
			
		return SendRule;
	}
	
	
	
	/**
	 *
	//////////////////////////////////
	///////Unsub Voice Note Process////////////
	////////////////////////////

	 */    
	public int handleVNUnsubscription(int minarg,int maxarg,String lang_id)
	{
		logger.info("Handle McaUnsubscription Process");
		
		Mess=Mess.replaceAll("%20"," ");
		String MessArray[]=Mess.split(" ");
		logger.info("size of Messarray="+MessArray.length);

		String command="UNSUB";
		String service="VN";
		Mess=command+" "+service;
		int value=Unsubscribe(minarg,maxarg,lang_id);
		return value;
	}
	/**
	 *
	//////////////////////////////////
	///////UMCA Process////////////
	////////////////////////////

	 */    
	public int handleMcaUnsubscription(int minarg,int maxarg,String lang_id)
	{
		
		logger.info("Handle McaUnsubscription Process");
		
		Mess=Mess.replaceAll("%20"," ");
		String MessArray[]=Mess.split(" ");
		logger.info("size of Messarray="+MessArray.length);

		String command="UNSUB";
		String service="MCA";
		Mess=command+" "+service;
		int value=Unsubscribe(minarg,maxarg,lang_id);
		return value;
	}
	/**
	 *
	///////////////////////////////
	/////UVMS Process////////////
	//////////////////////////////
	/////////////////////////////
	 */
	public int handleVmsUnsubscription(int minarg,int maxarg,String lang_id)
	{
		
		logger.info("handle VmsSubscription Process");
		Mess=Mess.replaceAll("%20"," ");
		String MessArray[]=Mess.split(" ");
		logger.info("Size of Messarray="+MessArray.length);

		String command="UNSUB";
		String service="VMS";
		Mess=command+" "+service;
		int value=Unsubscribe(minarg,maxarg,lang_id);
		return value;
	}
	/**
	 *
	//////////////////////////////////
	///////Get Password Process////////////
	////////////////////////////
	 */

	public int getPassword(int MinArg,int MaxArg,String lang_id)
	{
		
		Mess=Mess.replaceAll("%20", " ");
		String MessArray[]=Mess.split(" ");
		logger.info("Size of MessArray "+MessArray.length);
		logger.info("value of minarg="+MinArg+" "+"value of maxarg="+" "+MaxArg+"value of lang_id="+lang_id);
		replace.clear();
		if(MessArray.length < MinArg)
		{
			logger.info("User sent less arguments ");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		else if(MessArray.length > MaxArg)
		{
			logger.info("User sent Maximum Arguments");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
/*		if(MessArray.length==2)                
		{
			service_type=MessArray[1];
		}
		if(service_type.equalsIgnoreCase("VMS"))
		{
			Service=2;
		}
		else if(service_type.equalsIgnoreCase("MCA"))
		{
			logger.info("Password is not applicable for the MCA service");
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"34"+"-"+lang_id,replace);
			return value;
		}
		else
		{
			logger.info("You have enterd wrong choice"); 
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace);
			return value;
		}*/
		String Pass=dbengine.fetchPassword(Msisdn);
		if(Pass==null) //user is not subscribed
		{
			logger.info(Msisdn.trim() + "#> user is not subscribed ");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"27"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"45"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		else if(Pass.equalsIgnoreCase("NA"))
		{
			logger.info("Their is no password Regarding the Msisdn");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"34"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"47"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		else
		{	
			logger.info("Password is "+Pass);
			replace.put("$(password)",Pass);
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"28"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"46"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
	}
	public int getHelp(int MinArg,int MaxArg,String lang_id)
	{
		logger.info("inside the help block");
		String Message=null;
		String service_type=null;
	
		Mess=Mess.replaceAll("%20", " ");
		String MessArray[]=Mess.split(" ");
		logger.info("Size of MessArray "+MessArray.length);
		logger.info("value of minarg="+MinArg+" "+"value of maxarg="+" "+MaxArg+"value of lang_id="+lang_id);
		replace.clear();
		if(MessArray.length < MinArg)
		{
			logger.info("User sent less arguments ");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		else if(MessArray.length > MaxArg)
		{
			logger.info("User sent Maximum Arguments");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
		if(MessArray.length==2)                
		{       
			logger.info("if length is 2 then inside this block");
			service_type=MessArray[1].toUpperCase();
			logger.info("Command name : "+service_type);
			KeywordBean key = (KeywordBean)UniptestCache.GetInstance().getKeywordDetail(service_type);
			// addition by Avishkar on 14/10/2020 start
			if (key==null) { // this if block is added to avoid error in application when keyword does not exist or if keyword Is_working is 'N' in database
				value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
				return value;
			}
			// addition ends by Avishkar on 14/10/2020
			String Process=key.getProcessName().toUpperCase();
			logger.info("Process Name="+Process);	
			Message=dbengine.getHelpMess(Process,lang_id);
			logger.info("Message is "+Message);
			replace.put("$(command)",service_type);
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"-1+"+Message,replace);
			return value;
		}
		else if(MessArray.length==1)
		{	logger.info("if length is1 then inside the block");
			if(MessArray[0].equalsIgnoreCase("HELP"))
			{
				Message=dbengine.getHelpMess1();
				logger.info("Commands are : "+Message);
				replace.put("$(commands)",Message);
//				value=dbengine.InsertIntoGmat(Msisdn.trim(),"23"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
				value=dbengine.InsertIntoGmat(Msisdn.trim(),"42"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
				return value;
			}
			else
			{
				logger.info("Error in Your Message");
//				value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
				value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
				return value;
			}
		}
		else
		{
			logger.info("Error in message");
//			value=dbengine.InsertIntoGmat(Msisdn.trim(),"16"+"-"+lang_id,replace); // commented by Avishkar on 21/8/2020
			value=dbengine.InsertIntoGmat(Msisdn.trim(),"37"+"-"+lang_id,replace); // modified by Avishkar on 21/8/2020
			return value;
		}
	}
	public int SMSHandle(String shortcode,String msisdn,int status){ // this method is modified by Avishkar
		UnipRequest unipReq = new UnipRequest(shortcode,msisdn,status);
		boolean isExecute=false;
		try{
			boolean check = UniptestCache.cacheMsisdnMap.containsKey(msisdn);
			logger.debug("##>> msisdn["+msisdn+"] check contain["+check+"] cacheMsisdnSize["+UniptestCache.cacheMsisdnMap.size()+"]");
			if (!check) {
				logger.info("##>> msisdn["+msisdn+"] Doesn't exist in cacheMsisdnMap, so going to put in cacheMsisdnMap and process the request ");
				UniptestCache.cacheMsisdnMap.put(msisdn, "");
//				Thread.sleep(10000); // temp testing sleep
				isExecute=true;
				if(status != 0){
					return -1;
				} else if (status == 0){
					if(AppConfig.config.getBoolean("ALLOW_WORKER",false)){
						UnipData.unipReqQue.put(unipReq);
						Thread.sleep(1000);
						return 0;
					} else {
						value=dbengine.sendMCAMessage(shortcode,msisdn,status,"DISABLE");
						return value;
					}
				} else {
					return -1;
				}
			} else {
				logger.info("##>> msisdn["+msisdn+"] exist in cacheMsisdnMap, so not going to process the request ");
				return -1;
			}
		}catch(Exception e){
			logger.info("Exception in sending message"+e.toString());
			return -1;
		} finally {
			try {
				if (isExecute) {
					logger.debug("##>> msisdn["+msisdn+"] Removing from cacheMsisdnMap");
					UniptestCache.cacheMsisdnMap.remove(msisdn);
				}
			} catch (Exception e2) {
				logger.error("##>> msisdn["+msisdn+"] Exception while deleting from cacheMsisdnMap ");
			}
		}
	}
	@SuppressWarnings("unused")
	public int doCharging(String msisdn,int tarrifCode,int lang_id,String intrface,String subType,String service)
	{
		try
		{
		//return 1;
		logger.info("Inside function doCharging() msisdn is ["+msisdn+"] subType ["+subType+"] service ["+service+"]");
		String err=null;
		String orgMsisdn="NA";
		String reqId="NA";
		logger.info(" ip is [ "+UniptestCache.chargingServerIp+" port "+UniptestCache.chargingServerPort.trim());
		String serverIp=UniptestCache.chargingServerIp;
		int serverPort=Integer.parseInt(UniptestCache.chargingServerPort.trim());
		
			TLVAppInterface tlvInterface = new TLVAppInterface();
		   tlvInterface.setData(MSISDN_TAG,msisdn);
		   tlvInterface.setData(ACTION_TAG,lang_id);
		   tlvInterface.setData(TARIFFID_TAG, tarrifCode);
		   tlvInterface.setData(INTERFACE_TAG, intrface);
		   tlvInterface.setData(SUB_TYPE, subType);
		   tlvInterface.setData(SERVICE_TAG, service);
		   tlvInterface.setData(BMSISDN_TAG,orgMsisdn);
		   tlvInterface.setData(REQTYPE_TAG,reqId);
		   tlvInterface.encode();
		   tlvInterface.setServerIP(serverIp);
		   tlvInterface.setServerPort(serverPort);
		   tlvInterface.send();
		   int receive=tlvInterface.receive();
		   if(receive<0)
		   {
			   logger.info("Error in charging request execution");
			   return -1;
		   }
		   err=tlvInterface.getData(RESPONSE_TAG);
		  
		   if(Integer.parseInt("err")==1)
		   {
			   logger.info("Charging done successfully");
			   return 1;
		   }
		   else{
			   logger.info("Error in charging");
			   return -1;
		   }
		   

	}
		catch(Exception e)
		{
		logger.error("Exception inside doCharging()"+e.getMessage());
		e.printStackTrace();
		return -1;
		}
	}
	
}

