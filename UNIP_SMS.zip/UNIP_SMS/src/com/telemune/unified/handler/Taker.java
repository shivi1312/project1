package com.telemune.unified.handler;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.AppConfig;
import com.telemune.sms.util.UnipData;
import com.telemune.unified.model.UnipRequest;

public class Taker implements Runnable {
	private static final Logger logger = Logger.getLogger(Taker.class);
	public boolean worker = true;

	public Taker() {

	}

	@Override
	public void run() {
		while (worker) {
			UnipRequest unipReq = null;
			try {
				if (!UnipData.unipReqQue.isEmpty()) {
					unipReq = UnipData.unipReqQue.poll();
					UnipData.executor.submit(new Worker(unipReq));
					Thread.sleep(1000/AppConfig.config.getInt("TPS",100));
				} else {
					Thread.sleep(1000);
				}
			} catch (Exception e) {
				logger.error("b-party [" + unipReq.getMsisdn() + "] sc ["
						+ unipReq.getShortCode()
						+ "] Error while retrieve data from queue: "
						+ e.getMessage());
			}
		}
	}
}
