package com.telemune.unified.handler;

import org.apache.log4j.Logger;

import com.telemune.sms.util.UnipData;
import com.telemune.unified.curd.UnipService;
import com.telemune.unified.model.UnipRequest;
import com.telemune.uniptest.webif.DBEngine;

@SuppressWarnings("unused")
public class Worker implements Runnable {
	private static final Logger logger = Logger.getLogger(Worker.class);
	private UnipRequest unipReq = null;
	private UnipService unipService = new UnipService();
	private DBEngine dbEngine = new DBEngine();
	private String tempMsg = "";
	public Worker(UnipRequest unipReq) {
		this.unipReq = unipReq;
	}

	@Override
	public void run() {
		try{
			UnipData.busyCount++;
			Thread.currentThread().setName(unipReq.getMsisdn()+"-"+unipReq.getShortCode());
			logger.info("task started by: "+Thread.currentThread().getName()+" queue size ["+UnipData.unipReqQue.size()+"]");
			dbEngine.sendMCAMessage(unipReq.getShortCode(), unipReq.getMsisdn(), 
					unipReq.getStatus(), Thread.currentThread().getName());
		} catch(Exception e){
			logger.error("worker ["+Thread.currentThread().getName()+"] b-party ["+unipReq.getMsisdn()+"] "
					+ "sc ["+unipReq.getShortCode()+"] error while process request");
		} finally{
			logger.info("task finished by: "+Thread.currentThread().getName()+
					" total worker ["+UnipData.threadGroup.activeCount()+"] busy ["+UnipData.busyCount+"] "
							+ "ideal ["+(UnipData.threadGroup.activeCount()-UnipData.busyCount)+"]");
			UnipData.busyCount--;
		}
	}
}
