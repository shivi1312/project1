package com.telemune.unified.curd;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.telemune.dbutilities.AppConfig;
import com.telemune.dbutilities.AppContext;
import com.telemune.dbutilities.DBQueries;
import com.telemune.unified.model.McaNotification;
import com.telemune.unified.model.UnipRequest;
import com.telemune.uniptest.webif.AdEngineHandler;
import com.telemune.uniptest.webif.UniptestCache;

@SuppressWarnings("unused")
public class UnipService {
	private static final Logger logger = Logger.getLogger(UnipService.class);
	private AdEngineHandler adEngineHandler = null;
	private String ad_msg = null;
	private int msg_length;
	private int txn_id;
	
	public UnipService() {

	}

	public List<McaNotification> getMcaNotificationDetail(UnipRequest unipReq) {
		List<McaNotification> list = new ArrayList<McaNotification>();
		String query = DBQueries.GET_MCA_NOTIFICATION_DETAILS;
		try {
			logger.debug("worker ["+unipReq.getWorker()+"] b-party ["+unipReq.getMsisdn()+
					"] ["+unipReq.getShortCode()+"] ["+query+"]");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			AppContext.statics(unipReq.getMsisdn());
			list = jdbcTemplate.query(query,
					new Object[] { unipReq.getMsisdn() },
					new RowMapper<McaNotification>() {
						@Override
						public McaNotification mapRow(ResultSet rs,
								int rownumber) throws SQLException {
							McaNotification mca = new McaNotification();
							mca.setOrgNumber(UniptestCache.GetInstance()
									.getInternationalNumber(
											rs.getString("ORIGINATION_NUMBER")));
							mca.setDateOfCall(rs.getString("DATE_OF_CALL"));
							mca.setTimeOfCall(rs.getString("TIME_OF_CALL"));
							mca.setCallCounter(rs.getInt("CALL_COUNTER"));
							mca.setServiceType(rs.getInt("SERVICE_TYPE"));
							mca.setLanguageId(rs.getString("LANGUAGE_ID"));
							return mca;
						}
					});
			logger.info("worker ["+unipReq.getWorker()+"] b-party ["+unipReq.getMsisdn()+
					"] sc ["+unipReq.getShortCode()+"] total notification ["+list.size()+"]");
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("worker ["+unipReq.getWorker()+"] b-party ["+unipReq.getMsisdn()+"] Error "
					+ "while retrieve data from mca_call_detail: "
					+ e.getMessage());
		}
		return list;
	}

	public int storeMsgInGmat(UnipRequest unipReq, McaNotification mca) {
		String query = DBQueries.INSERT_INTO_GMAT_MESSAGE_STORE;
		String inserted = "NO";
		int insert = 0;
		String senderId=""; // added by Avishkar on 18/8/2020
		try {
	
	        
			this.callAdEngine(unipReq, mca);//get message from AdEngine
			logger.debug("worker ["+unipReq.getWorker()+"] b-party ["+unipReq.getMsisdn()+
					"] ["+unipReq.getShortCode()+"] ["+query+"]");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			AppContext.statics(unipReq.getMsisdn());
			

	
			
			if(mca.getBparty()){
				insert = jdbcTemplate.update(query,new Object[] { mca.getOrgNumber(), unipReq.getMsisdn(),
								mca.getMessage() });
			}else {
				insert = jdbcTemplate.update(query,new Object[] { unipReq.getMsisdn(), mca.getOrgNumber(),
							mca.getMessage() });
			}
			if(insert > 0)
				inserted = "YES";
			logger.info("worker ["+unipReq.getWorker()+"] b-party ["+unipReq.getMsisdn()+
					"] sc ["+unipReq.getShortCode()+"] inserted in gmat_message_store ["+inserted+"]");
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("worker ["+unipReq.getWorker()+"] b-party ["+unipReq.getMsisdn()+"] Error "
					+ "while insert data in gmat_messge_store: "
					+ e.getMessage());
		}
		return insert;
	}
	public void callAdEngine(UnipRequest unipReq, McaNotification mca){
		if (AppConfig.config.getInt("AD_ENGINE_ENABLE", 0) == 1) {
			logger.info("worker ["+unipReq.getWorker()+"] a-party ["+mca.getOrgNumber()+"] b-party ["+unipReq.getMsisdn()+"] "
					+ "sc ["+unipReq.getShortCode()+"] send request to AdEngine for b-party ["+mca.getBparty()+"]");
			String txn = String.valueOf(System.currentTimeMillis());
			this.adEngineHandler = new AdEngineHandler();
			this.msg_length = mca.getMessage().length();
			this.txn_id = Integer.parseInt(txn.substring(0, 6));
			if(mca.getBparty())
				this.ad_msg = this.adEngineHandler.appendAdMessage(unipReq.getMsisdn(), mca.getMessage().length(), this.txn_id);
			else
				this.ad_msg = this.adEngineHandler.appendAdMessage(mca.getOrgNumber(), mca.getMessage().length(), this.txn_id);
			mca.setMessage(mca.getMessage() + " " + this.ad_msg);
			logger.info("worker ["+unipReq.getWorker()+"] a-party ["+mca.getOrgNumber()+"] b-party ["+unipReq.getMsisdn()+"] "
					+ "sc ["+unipReq.getShortCode()+"] retrive AddEngine response ["+mca.getMessage()+"]");
		}
	}
	public static void main(String [] args){
		UnipRequest unipReq = new UnipRequest("2234324","919700149381",1);
		McaNotification mca = new McaNotification();
		new UnipService().getOperatorRange(unipReq, mca);
	}
	public boolean getOperatorRange(UnipRequest unipReq, McaNotification mca) {
		String query = DBQueries.GET_OPERATOR_RANGE;
		boolean exist = false;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			AppContext.statics(unipReq.getMsisdn());
			logger.info("worker ["+unipReq.getWorker()+"] b-party ["+unipReq.getMsisdn()+
					"] ["+unipReq.getShortCode()+"] ["+query+"]");
			/*
			 * Updated By Parminder Singh on 16 Nov 2018
			 * Because query is returning row with count value
			 * and check should be on value of count
			 * not on row size
			 */
			/*List<Map<String,Object>> rows = jdbcTemplate.queryForList(query, new Object[]{mca.getOrgNumber(),
					mca.getOrgNumber(),mca.getOrgNumber(),mca.getOrgNumber()});
			if(rows.size() > 0)
				exist = true;
			logger.info("worker ["+unipReq.getWorker()+"] b-party ["+unipReq.getMsisdn()+
					"] ["+unipReq.getShortCode()+"] exist ["+exist+"] count ["+rows.size()+"]");*/ 
//			Integer rows = jdbcTemplate.queryForObject(query, new Object[]{mca.getOrgNumber(),
//					mca.getOrgNumber(),mca.getOrgNumber(),mca.getOrgNumber()},Integer.class); // commented by Avishkar on 19/8/2020
			Integer rows = jdbcTemplate.queryForObject(query, new Object[]{mca.getOrgNumber(),
					mca.getOrgNumber()},Integer.class); // modified by Aviskhar on 19/8/2020
			if(rows > 0)
				exist = true;
			logger.info("worker ["+unipReq.getWorker()+"] b-party ["+unipReq.getMsisdn()+
					"] ["+unipReq.getShortCode()+"] ["+mca.getOrgNumber()+"] exist ["+exist+"] count ["+rows+"]");
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("worker ["+unipReq.getWorker()+"] b-party ["+unipReq.getMsisdn()+"] Error "
					+ "while checking operator range exist or not: " + e.getMessage());
		}
		return exist;
	}
	public int deleteMcaDetailOfUser(UnipRequest unipReq){
		String query = DBQueries.DELETE_MCA_CALL_DETAIL;
		int delete = 0;
		String deleted = "NO";
		try{
			logger.debug("worker ["+unipReq.getWorker()+"] b-party ["+unipReq.getMsisdn()+
					"] ["+unipReq.getShortCode()+"] ["+query+"]");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(AppContext.dataSource);
			AppContext.statics(unipReq.getMsisdn());
			delete = jdbcTemplate.update(query, new Object []{unipReq.getMsisdn()});
			if(delete > 0)
				deleted = "YES";
			logger.info("worker ["+unipReq.getWorker()+"] b-party ["+unipReq.getMsisdn()+
					"] ["+unipReq.getShortCode()+"] deleted from mca_call_detail ["+deleted+"]");
		}catch(Exception e){
			logger.error("worker ["+unipReq.getWorker()+"] b-party ["+unipReq.getMsisdn()+"] Error "
					+ "while delete mca detail of user: " + e.getMessage());
		}
		return delete;
	}
}
