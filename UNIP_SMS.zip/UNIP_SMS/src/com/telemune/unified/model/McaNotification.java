package com.telemune.unified.model;

public class McaNotification implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	private String reqId;
	private String orgNumber;
	private String dateOfCall;
	private String timeOfCall;
	private int callCounter;
	private int serviceType;
	private String message;
	private boolean bparty;
	private String languageId;

	public String getReqId() {
		return reqId;
	}

	public void setReqId(String reqId) {
		this.reqId = reqId;
	}

	public String getOrgNumber() {
		return orgNumber;
	}

	public void setOrgNumber(String orgNumber) {
		this.orgNumber = orgNumber;
	}

	public String getDateOfCall() {
		return dateOfCall;
	}

	public void setDateOfCall(String dateOfCall) {
		this.dateOfCall = dateOfCall;
	}

	public String getTimeOfCall() {
		return timeOfCall;
	}

	public void setTimeOfCall(String timeOfCall) {
		this.timeOfCall = timeOfCall;
	}

	public int getCallCounter() {
		return callCounter;
	}

	public void setCallCounter(int callCounter) {
		this.callCounter = callCounter;
	}

	public int getServiceType() {
		return serviceType;
	}

	public void setServiceType(int serviceType) {
		this.serviceType = serviceType;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public boolean getBparty() {
		return bparty;
	}

	public void setBparty(boolean bparty) {
		this.bparty = bparty;
	}

	public String getLanguageId() {
		return languageId;
	}

	public void setLanguageId(String languageId) {
		this.languageId = languageId;
	}
	
}
