package com.telemune.unified.model;

@SuppressWarnings("serial")
public class UnipRequest implements java.io.Serializable {
	private String shortCode;
	private String msisdn;
	private int status;
	private String worker;

	public UnipRequest(String shortCode, String msisdn, int status){
		this.shortCode = shortCode;
		this.msisdn = msisdn;
		this.status = status;
	}
	public String getShortCode() {
		return shortCode;
	}

	public void setShortCode(String shortCode) {
		this.shortCode = shortCode;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	public String getWorker() {
		return worker;
	}
	public void setWorker(String worker) {
		this.worker = worker;
	}
	
}
