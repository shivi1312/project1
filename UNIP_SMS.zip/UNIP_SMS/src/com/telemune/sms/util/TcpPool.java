/**
 * The TcpPool is singleton class that provide single object
 * of SocketConnectionPoll
 * @author Swati Goel 
 */

package com.telemune.sms.util;
import com.telemune.uniptest.webif.*;
import com.telemune.sms.net.Connectionpool;

public class TcpPool {
	private TcpPool() {

	}

	private static Connectionpool ruleEngineConPool = new Connectionpool(
			UniptestCache.GetInstance().getSSFServer(),UniptestCache.GetInstance().getSSFPort());

	/**
	 * This method create connection pool for rule-engine
	 * @return ruleEngineConnection
	 */
	public static Connectionpool getRuleEngineConPool() {
		return ruleEngineConPool;
	}

}
