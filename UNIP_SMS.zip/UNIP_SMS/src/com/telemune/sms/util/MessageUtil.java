package com.telemune.sms.util;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.AppConfig;
import com.telemune.unified.curd.UnipService;
import com.telemune.unified.model.McaNotification;
import com.telemune.unified.model.UnipRequest;
import com.telemune.uniptest.webif.UniptestCache;

public class MessageUtil {
	private static final Logger logger = Logger.getLogger(MessageUtil.class);
	private static final Logger app_error = Logger.getLogger("APP_ERROR");
	private UnipService unipService = new UnipService();
	private String templateMsg = "";
	private String tempMsg = "";
	private StringBuffer message = new StringBuffer();
	
	public void getMessageTemplate(UnipRequest unipReq, McaNotification mca){
		try{
			this.templateMsg = AppConfig.config.getString(AppConfig.config.getString("MCA_SMS_ALERT_ID")+"-"+AppConfig.config.getString("DEFAULT_LANGUAGE_ID"));
			if (AppConfig.config.getInt("COMBINE_SMS_ENABLE") == 1) {
				this.tempMsg = this.templateMsg.substring(0, this.templateMsg.indexOf("$", 0));
				this.templateMsg = this.templateMsg.substring(this.templateMsg.indexOf("$", 0),
						this.templateMsg.length());
				this.message = this.message.append(tempMsg);
				logger.info("msisdn ["+unipReq.getMsisdn()+"] sc ["+unipReq.getShortCode()+
						"] template message ["+this.tempMsg+"] actual message["+this.message+"]");
			}
		}catch(Exception e){
			app_error.error("[" + UnipData.product_module + "_00005] ["+unipReq.getMsisdn()+"] Error "
					+ "while getting template message: " + e.getMessage());
		}
	}
	public void formatMsgTemplate(UnipRequest unipReq, McaNotification mca){
		try{
			if (AppConfig.config.getInt("countr.code.alert.enable") == 0) {
				this.getCountryCodeFreeMsisdn(unipReq, mca);
			}
			templateMsg = templateMsg.replace("$(calling_time)", mca.getDateOfCall()+" "+mca.getTimeOfCall());
			templateMsg = templateMsg.replace("$(date_of_call)", mca.getDateOfCall()).replace("$(time_of_call)", mca.getTimeOfCall());
			templateMsg = templateMsg.replace("$(calling_number)", mca.getOrgNumber());
			if(!AppConfig.config.getString("SMS_ORIGINATION_NUMBER_MCA").equals("NA")){
				mca.setOrgNumber(AppConfig.config.getString("SMS_ORIGINATION_NUMBER_MCA"));
				logger.info("msisdn ["+unipReq.getMsisdn()+"] sc ["+unipReq.getShortCode()+
						"] Change B-Party Number: "+mca.getOrgNumber()+" with " 
						+ AppConfig.config.getString("SMS_ORIGINATION_NUMBER_MCA"));
			}
			if(AppConfig.config.getInt("COMBINE_SMS_ENABLE") == 0){
				message = message.append(this.tempMsg);
				mca.setMessage(message.append(templateMsg).toString());
				unipService.storeMsgInGmat(unipReq, mca);
				this.message = new StringBuffer();
			} else {
				if ((message.length() + templateMsg.length()) >= UniptestCache.messageLength) {
					unipService.storeMsgInGmat(unipReq, mca);
					this.message = message.append(this.tempMsg);
					this.message = new StringBuffer();
				}
				this.message = message.append(this.templateMsg);
				mca.setMessage(message.append(templateMsg).toString());
			}
		}catch(Exception e){
			app_error.error("[" + UnipData.product_module + "_00002] ["+unipReq.getMsisdn()+"] Error "
					+ "while format message: "+ e.getMessage());
		}
	}
	public void getCountryCodeFreeMsisdn(UnipRequest unipReq, McaNotification mca) {
		try {
			logger.debug("msisdn ["+unipReq.getMsisdn()+"] sc ["+unipReq.getShortCode()+"] country code handling");
			if (unipReq.getMsisdn().length() == UniptestCache.msisdnLength) {
				if (unipReq.getMsisdn().startsWith(UniptestCache.countryCode)) {
					unipReq.setMsisdn(unipReq.getMsisdn().substring(UniptestCache.countryCode.length()));
					logger.debug("msisdn ["+unipReq.getMsisdn()+"] sc ["+unipReq.getShortCode()+"] remove country code");
				}
			}
		} catch (Exception e) {
			app_error.error("[" + UnipData.product_module + "_00002] ["+unipReq.getMsisdn()+"] Error "
					+ "while country code remove: "+ e.getMessage());
		}
	}
}
