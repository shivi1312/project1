package com.telemune.sms.util;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import com.telemune.dbutilities.AppConfig;
import com.telemune.unified.model.UnipRequest;

public class UnipData {
	public static final ArrayBlockingQueue<UnipRequest> unipReqQue = new ArrayBlockingQueue<UnipRequest>(
			AppConfig.config.getInt("QUEUE_SIZE",200000));
	public final static ThreadGroup threadGroup = new ThreadGroup("worker");
	public static int busyCount = 0;
	public static ExecutorService executor = Executors.newFixedThreadPool(
			AppConfig.config.getInt("WOKER_THREAD",20),new ThreadFactory(){
		public Thread newThread(Runnable r) {
			return new Thread(threadGroup, r);
		}
	});
	public static String product_module = AppConfig.config.getString("PRODUCT_MODULE","UNIFIED_UNIPSMS");
	public boolean worker = true;
}
