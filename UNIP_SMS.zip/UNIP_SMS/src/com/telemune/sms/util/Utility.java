/**
 * The Utility class helps for validation of msisdn and subtype of user
 * @author Mayank Agrawal
 */

package com.telemune.sms.util;

public class Utility {

	/**
	 * This method msisdn length to configured length
	 * @param msisdn contains number of user
	 * @return status
	 */
	public static boolean isValidateMsisdn(String msisdn) {
		if (msisdn.length() >= 10) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * This method validate prepaid/postpaid subtype
	 * @param subType contains prepaid/postpaid string
	 * @return staus
	 */
	public static boolean isValidateSubType(String subType) {
		if (subType.equalsIgnoreCase("prepaid")
				|| subType.equalsIgnoreCase("postpaid")) {
			return true;
		} else {
			return false;
		}
	}

}
