package com.telemune.sms.util;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.AppConfig;
import com.telemune.unified.handler.Taker;
import com.telemune.uniptest.webif.UniptestCache;

@SuppressWarnings("serial")
@WebServlet(
		urlPatterns = "/LoadConfig",
        loadOnStartup = 1,
        asyncSupported = true
)  
public class LoadConfig extends HttpServlet {
	static final Logger logger = Logger.getLogger(LoadConfig.class);
	static Taker taker = null;
	public void init() {
		logger.info("Initialize config first time");
		System.out.println("Initialize config first time");
		this.cacheLoad();
		this.worker();
	}
	public void destroy(){
		logger.info("db-pool: Destroy db pool");
		try{
			if(AppConfig.config.getBoolean("ALLOW_WORKER",false)){
				UnipData.executor.shutdownNow();
				taker.worker = false;
				logger.info("Shutdown thread successfully...");
			}
		}catch(Exception e){
			logger.error("Error while shutdown thread: "+e.getMessage());
		}
	}
	private void cacheLoad(){
		logger.info("Cache load..........");
		try{
			UniptestCache.GetInstance();
		}catch(Exception e){
			logger.error("Error cache load initialize.."+e.getMessage());
		}
	}
	private void worker(){
		try{
			if(AppConfig.config.getBoolean("ALLOW_WORKER",false)){
				taker = new Taker();
				new Thread(taker).start();
				logger.info("Worker is running now");
			} else {
				logger.info("Worker is disable now to enable set (ALLOW_WORKER=true)");
			}
		}catch(Exception e){
			logger.error("Error while running worker thread: "+e.getMessage());
		}
	}

}
