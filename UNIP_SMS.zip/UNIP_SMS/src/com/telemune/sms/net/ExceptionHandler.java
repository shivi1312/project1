package com.telemune.sms.net;

/**
 * Created by tanujkumar on 02/07/15.
 */
public abstract interface ExceptionHandler {
    public abstract void handleException(Throwable paramThrowable);
}
