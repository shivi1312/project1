package com.telemune.sms.net;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;

/**
 * Created by tanujkumar on 02/07/15.
 */
public class TextSocketConnection extends SocketConnection {
	private DataInputStream reader = null;
	private DataOutputStream writer = null;

	protected DataInputStream reader() {
		return this.reader;
	}

	protected void reader(DataInputStream newReader) {
		this.reader = newReader;
	}

	protected DataOutputStream writer() {
		return this.writer;
	}

	protected void writer(DataOutputStream newWriter) {
		this.writer = newWriter;
	}

	public TextSocketConnection(Socket openSocket) {
		super(openSocket);
	}

	public TextSocketConnection(Socket openSocket,
			ExceptionHandler exceptionHandler) {
		super(openSocket, exceptionHandler);
	}

	public void close() {
		super.close();
		closeReader();
		closeWriter();
	}

	public String readLine() {
		String line = null;
		if (canRead()) {
			try {
				line = getReader().readUTF();
			} catch (SocketException se) {
				isOpen(false);
			} catch (IOException ioe) {
				exceptionOccurred(ioe);
			}
		}
		return line;
	}

	public boolean write(String text) {
		boolean success = false;
		try {
			if (canWrite()) {
				getWriter().writeUTF(text);
				getWriter().flush();
				success = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			success = false;
		}
		return success;
	}

	/*
	 * public boolean writeLine(String line) { boolean success = false; if
	 * (canWrite()) { getWriter().write(line); getWriter().write(10);
	 * getWriter().flush(); success = true; } return success; }
	 */

	protected DataInputStream getReader() {
		if (!hasReader()) {
			if (hasSocket()) {
				try {
					DataInputStream reader = new DataInputStream(socket().getInputStream());
					reader(reader);
				} catch (IOException ioe) {
					exceptionOccurred(ioe);
				}
			}
		}
		return reader();
	}

	protected DataOutputStream getWriter() {
		if (!hasWriter()) {
			if (hasSocket()) {
				try {
					DataOutputStream osw = new DataOutputStream(socket()
							.getOutputStream());
					writer(osw);
				} catch (IOException ioe) {
					exceptionOccurred(ioe);
				}
			}
		}
		return writer();
	}

	protected boolean hasReader() {
		return reader() != null;
	}

	protected boolean hasWriter() {
		return writer() != null;
	}

	protected boolean canRead() {
		return (isOpen()) && (getReader() != null);
	}

	protected boolean canWrite() {
		return (isOpen()) && (getWriter() != null);
	}

	protected void closeReader() {
		try {
			if (hasReader()) {
				reader().close();
				reader(null);
			}
		} catch (IOException ioe) {
			exceptionOccurred(ioe);
		}
	}

	protected void closeWriter() {
		try {
			if (hasWriter()) {
				writer().close();
				writer(null);
			}
		} catch (Exception e) {

		}
	}
}
