/**
 * LST_CBARStruct1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  LST_CBARStruct1 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class LST_CBARStruct1 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = LST_CBARStruct1
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for IMSI
     */
    protected com.huawei.www.hss.Str6_15 localIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSITracker = false;

    /**
     * field for ISDN
     */
    protected com.huawei.www.hss.Str1_15 localISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localISDNTracker = false;

    /**
     * field for CBCOU
     */
    protected com.huawei.www.hss._EnumType localCBCOU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCBCOUTracker = false;

    /**
     * field for CBCOUREASON
     */
    protected com.huawei.www.hss._EnumType localCBCOUREASON;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCBCOUREASONTracker = false;

    /**
     * field for BAOC_ALL
     */
    protected com.huawei.www.hss._EnumType localBAOC_ALL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAOC_ALLTracker = false;

    /**
     * field for BAOC_TS1X
     */
    protected com.huawei.www.hss._EnumType localBAOC_TS1X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAOC_TS1XTracker = false;

    /**
     * field for BAOC_TS2X
     */
    protected com.huawei.www.hss._EnumType localBAOC_TS2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAOC_TS2XTracker = false;

    /**
     * field for BAOC_TS6X
     */
    protected com.huawei.www.hss._EnumType localBAOC_TS6X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAOC_TS6XTracker = false;

    /**
     * field for BAOC_BS2X
     */
    protected com.huawei.www.hss._EnumType localBAOC_BS2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAOC_BS2XTracker = false;

    /**
     * field for BAOC_BS3X
     */
    protected com.huawei.www.hss._EnumType localBAOC_BS3X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAOC_BS3XTracker = false;

    /**
     * field for BAOC_TSDX
     */
    protected com.huawei.www.hss._EnumType localBAOC_TSDX;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAOC_TSDXTracker = false;

    /**
     * field for BOIC_ALL
     */
    protected com.huawei.www.hss._EnumType localBOIC_ALL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOIC_ALLTracker = false;

    /**
     * field for BOIC_TS1X
     */
    protected com.huawei.www.hss._EnumType localBOIC_TS1X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOIC_TS1XTracker = false;

    /**
     * field for BOIC_TS2X
     */
    protected com.huawei.www.hss._EnumType localBOIC_TS2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOIC_TS2XTracker = false;

    /**
     * field for BOIC_TS6X
     */
    protected com.huawei.www.hss._EnumType localBOIC_TS6X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOIC_TS6XTracker = false;

    /**
     * field for BOIC_BS2X
     */
    protected com.huawei.www.hss._EnumType localBOIC_BS2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOIC_BS2XTracker = false;

    /**
     * field for BOIC_BS3X
     */
    protected com.huawei.www.hss._EnumType localBOIC_BS3X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOIC_BS3XTracker = false;

    /**
     * field for BOIC_TSDX
     */
    protected com.huawei.www.hss._EnumType localBOIC_TSDX;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOIC_TSDXTracker = false;

    /**
     * field for BOICEXHC_ALL
     */
    protected com.huawei.www.hss._EnumType localBOICEXHC_ALL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOICEXHC_ALLTracker = false;

    /**
     * field for BOICEXHC_TS1X
     */
    protected com.huawei.www.hss._EnumType localBOICEXHC_TS1X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOICEXHC_TS1XTracker = false;

    /**
     * field for BOICEXHC_TS2X
     */
    protected com.huawei.www.hss._EnumType localBOICEXHC_TS2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOICEXHC_TS2XTracker = false;

    /**
     * field for BOICEXHC_TS6X
     */
    protected com.huawei.www.hss._EnumType localBOICEXHC_TS6X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOICEXHC_TS6XTracker = false;

    /**
     * field for BOICEXHC_BS2X
     */
    protected com.huawei.www.hss._EnumType localBOICEXHC_BS2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOICEXHC_BS2XTracker = false;

    /**
     * field for BOICEXHC_BS3X
     */
    protected com.huawei.www.hss._EnumType localBOICEXHC_BS3X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOICEXHC_BS3XTracker = false;

    /**
     * field for BOICEXHC_TSDX
     */
    protected com.huawei.www.hss._EnumType localBOICEXHC_TSDX;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOICEXHC_TSDXTracker = false;

    /**
     * field for BAIC_ALL
     */
    protected com.huawei.www.hss._EnumType localBAIC_ALL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAIC_ALLTracker = false;

    /**
     * field for BAIC_TS1X
     */
    protected com.huawei.www.hss._EnumType localBAIC_TS1X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAIC_TS1XTracker = false;

    /**
     * field for BAIC_TS2X
     */
    protected com.huawei.www.hss._EnumType localBAIC_TS2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAIC_TS2XTracker = false;

    /**
     * field for BAIC_TS6X
     */
    protected com.huawei.www.hss._EnumType localBAIC_TS6X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAIC_TS6XTracker = false;

    /**
     * field for BAIC_BS2X
     */
    protected com.huawei.www.hss._EnumType localBAIC_BS2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAIC_BS2XTracker = false;

    /**
     * field for BAIC_BS3X
     */
    protected com.huawei.www.hss._EnumType localBAIC_BS3X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAIC_BS3XTracker = false;

    /**
     * field for BAIC_TSDX
     */
    protected com.huawei.www.hss._EnumType localBAIC_TSDX;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBAIC_TSDXTracker = false;

    /**
     * field for BICROAM_ALL
     */
    protected com.huawei.www.hss._EnumType localBICROAM_ALL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBICROAM_ALLTracker = false;

    /**
     * field for BICROAM_TS1X
     */
    protected com.huawei.www.hss._EnumType localBICROAM_TS1X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBICROAM_TS1XTracker = false;

    /**
     * field for BICROAM_TS2X
     */
    protected com.huawei.www.hss._EnumType localBICROAM_TS2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBICROAM_TS2XTracker = false;

    /**
     * field for BICROAM_TS6X
     */
    protected com.huawei.www.hss._EnumType localBICROAM_TS6X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBICROAM_TS6XTracker = false;

    /**
     * field for BICROAM_BS2X
     */
    protected com.huawei.www.hss._EnumType localBICROAM_BS2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBICROAM_BS2XTracker = false;

    /**
     * field for BICROAM_BS3X
     */
    protected com.huawei.www.hss._EnumType localBICROAM_BS3X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBICROAM_BS3XTracker = false;

    /**
     * field for BICROAM_TSDX
     */
    protected com.huawei.www.hss._EnumType localBICROAM_TSDX;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBICROAM_TSDXTracker = false;

    /**
     * field for BORO_ALL
     */
    protected com.huawei.www.hss._EnumType localBORO_ALL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBORO_ALLTracker = false;

    /**
     * field for BORO_TS1X
     */
    protected com.huawei.www.hss._EnumType localBORO_TS1X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBORO_TS1XTracker = false;

    /**
     * field for BORO_TS2X
     */
    protected com.huawei.www.hss._EnumType localBORO_TS2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBORO_TS2XTracker = false;

    /**
     * field for BORO_TS6X
     */
    protected com.huawei.www.hss._EnumType localBORO_TS6X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBORO_TS6XTracker = false;

    /**
     * field for BORO_BS2X
     */
    protected com.huawei.www.hss._EnumType localBORO_BS2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBORO_BS2XTracker = false;

    /**
     * field for BORO_BS3X
     */
    protected com.huawei.www.hss._EnumType localBORO_BS3X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBORO_BS3XTracker = false;

    /**
     * field for BORO_TSDX
     */
    protected com.huawei.www.hss._EnumType localBORO_TSDX;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBORO_TSDXTracker = false;

    public boolean isIMSISpecified() {
        return localIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getIMSI() {
        return localIMSI;
    }

    /**
     * Auto generated setter method
     * @param param IMSI
     */
    public void setIMSI(com.huawei.www.hss.Str6_15 param) {
        localIMSITracker = param != null;

        this.localIMSI = param;
    }

    public boolean isISDNSpecified() {
        return localISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getISDN() {
        return localISDN;
    }

    /**
     * Auto generated setter method
     * @param param ISDN
     */
    public void setISDN(com.huawei.www.hss.Str1_15 param) {
        localISDNTracker = param != null;

        this.localISDN = param;
    }

    public boolean isCBCOUSpecified() {
        return localCBCOUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCBCOU() {
        return localCBCOU;
    }

    /**
     * Auto generated setter method
     * @param param CBCOU
     */
    public void setCBCOU(com.huawei.www.hss._EnumType param) {
        localCBCOUTracker = param != null;

        this.localCBCOU = param;
    }

    public boolean isCBCOUREASONSpecified() {
        return localCBCOUREASONTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCBCOUREASON() {
        return localCBCOUREASON;
    }

    /**
     * Auto generated setter method
     * @param param CBCOUREASON
     */
    public void setCBCOUREASON(com.huawei.www.hss._EnumType param) {
        localCBCOUREASONTracker = param != null;

        this.localCBCOUREASON = param;
    }

    public boolean isBAOC_ALLSpecified() {
        return localBAOC_ALLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAOC_ALL() {
        return localBAOC_ALL;
    }

    /**
     * Auto generated setter method
     * @param param BAOC_ALL
     */
    public void setBAOC_ALL(com.huawei.www.hss._EnumType param) {
        localBAOC_ALLTracker = param != null;

        this.localBAOC_ALL = param;
    }

    public boolean isBAOC_TS1XSpecified() {
        return localBAOC_TS1XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAOC_TS1X() {
        return localBAOC_TS1X;
    }

    /**
     * Auto generated setter method
     * @param param BAOC_TS1X
     */
    public void setBAOC_TS1X(com.huawei.www.hss._EnumType param) {
        localBAOC_TS1XTracker = param != null;

        this.localBAOC_TS1X = param;
    }

    public boolean isBAOC_TS2XSpecified() {
        return localBAOC_TS2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAOC_TS2X() {
        return localBAOC_TS2X;
    }

    /**
     * Auto generated setter method
     * @param param BAOC_TS2X
     */
    public void setBAOC_TS2X(com.huawei.www.hss._EnumType param) {
        localBAOC_TS2XTracker = param != null;

        this.localBAOC_TS2X = param;
    }

    public boolean isBAOC_TS6XSpecified() {
        return localBAOC_TS6XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAOC_TS6X() {
        return localBAOC_TS6X;
    }

    /**
     * Auto generated setter method
     * @param param BAOC_TS6X
     */
    public void setBAOC_TS6X(com.huawei.www.hss._EnumType param) {
        localBAOC_TS6XTracker = param != null;

        this.localBAOC_TS6X = param;
    }

    public boolean isBAOC_BS2XSpecified() {
        return localBAOC_BS2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAOC_BS2X() {
        return localBAOC_BS2X;
    }

    /**
     * Auto generated setter method
     * @param param BAOC_BS2X
     */
    public void setBAOC_BS2X(com.huawei.www.hss._EnumType param) {
        localBAOC_BS2XTracker = param != null;

        this.localBAOC_BS2X = param;
    }

    public boolean isBAOC_BS3XSpecified() {
        return localBAOC_BS3XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAOC_BS3X() {
        return localBAOC_BS3X;
    }

    /**
     * Auto generated setter method
     * @param param BAOC_BS3X
     */
    public void setBAOC_BS3X(com.huawei.www.hss._EnumType param) {
        localBAOC_BS3XTracker = param != null;

        this.localBAOC_BS3X = param;
    }

    public boolean isBAOC_TSDXSpecified() {
        return localBAOC_TSDXTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAOC_TSDX() {
        return localBAOC_TSDX;
    }

    /**
     * Auto generated setter method
     * @param param BAOC_TSDX
     */
    public void setBAOC_TSDX(com.huawei.www.hss._EnumType param) {
        localBAOC_TSDXTracker = param != null;

        this.localBAOC_TSDX = param;
    }

    public boolean isBOIC_ALLSpecified() {
        return localBOIC_ALLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOIC_ALL() {
        return localBOIC_ALL;
    }

    /**
     * Auto generated setter method
     * @param param BOIC_ALL
     */
    public void setBOIC_ALL(com.huawei.www.hss._EnumType param) {
        localBOIC_ALLTracker = param != null;

        this.localBOIC_ALL = param;
    }

    public boolean isBOIC_TS1XSpecified() {
        return localBOIC_TS1XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOIC_TS1X() {
        return localBOIC_TS1X;
    }

    /**
     * Auto generated setter method
     * @param param BOIC_TS1X
     */
    public void setBOIC_TS1X(com.huawei.www.hss._EnumType param) {
        localBOIC_TS1XTracker = param != null;

        this.localBOIC_TS1X = param;
    }

    public boolean isBOIC_TS2XSpecified() {
        return localBOIC_TS2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOIC_TS2X() {
        return localBOIC_TS2X;
    }

    /**
     * Auto generated setter method
     * @param param BOIC_TS2X
     */
    public void setBOIC_TS2X(com.huawei.www.hss._EnumType param) {
        localBOIC_TS2XTracker = param != null;

        this.localBOIC_TS2X = param;
    }

    public boolean isBOIC_TS6XSpecified() {
        return localBOIC_TS6XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOIC_TS6X() {
        return localBOIC_TS6X;
    }

    /**
     * Auto generated setter method
     * @param param BOIC_TS6X
     */
    public void setBOIC_TS6X(com.huawei.www.hss._EnumType param) {
        localBOIC_TS6XTracker = param != null;

        this.localBOIC_TS6X = param;
    }

    public boolean isBOIC_BS2XSpecified() {
        return localBOIC_BS2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOIC_BS2X() {
        return localBOIC_BS2X;
    }

    /**
     * Auto generated setter method
     * @param param BOIC_BS2X
     */
    public void setBOIC_BS2X(com.huawei.www.hss._EnumType param) {
        localBOIC_BS2XTracker = param != null;

        this.localBOIC_BS2X = param;
    }

    public boolean isBOIC_BS3XSpecified() {
        return localBOIC_BS3XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOIC_BS3X() {
        return localBOIC_BS3X;
    }

    /**
     * Auto generated setter method
     * @param param BOIC_BS3X
     */
    public void setBOIC_BS3X(com.huawei.www.hss._EnumType param) {
        localBOIC_BS3XTracker = param != null;

        this.localBOIC_BS3X = param;
    }

    public boolean isBOIC_TSDXSpecified() {
        return localBOIC_TSDXTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOIC_TSDX() {
        return localBOIC_TSDX;
    }

    /**
     * Auto generated setter method
     * @param param BOIC_TSDX
     */
    public void setBOIC_TSDX(com.huawei.www.hss._EnumType param) {
        localBOIC_TSDXTracker = param != null;

        this.localBOIC_TSDX = param;
    }

    public boolean isBOICEXHC_ALLSpecified() {
        return localBOICEXHC_ALLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOICEXHC_ALL() {
        return localBOICEXHC_ALL;
    }

    /**
     * Auto generated setter method
     * @param param BOICEXHC_ALL
     */
    public void setBOICEXHC_ALL(com.huawei.www.hss._EnumType param) {
        localBOICEXHC_ALLTracker = param != null;

        this.localBOICEXHC_ALL = param;
    }

    public boolean isBOICEXHC_TS1XSpecified() {
        return localBOICEXHC_TS1XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOICEXHC_TS1X() {
        return localBOICEXHC_TS1X;
    }

    /**
     * Auto generated setter method
     * @param param BOICEXHC_TS1X
     */
    public void setBOICEXHC_TS1X(com.huawei.www.hss._EnumType param) {
        localBOICEXHC_TS1XTracker = param != null;

        this.localBOICEXHC_TS1X = param;
    }

    public boolean isBOICEXHC_TS2XSpecified() {
        return localBOICEXHC_TS2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOICEXHC_TS2X() {
        return localBOICEXHC_TS2X;
    }

    /**
     * Auto generated setter method
     * @param param BOICEXHC_TS2X
     */
    public void setBOICEXHC_TS2X(com.huawei.www.hss._EnumType param) {
        localBOICEXHC_TS2XTracker = param != null;

        this.localBOICEXHC_TS2X = param;
    }

    public boolean isBOICEXHC_TS6XSpecified() {
        return localBOICEXHC_TS6XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOICEXHC_TS6X() {
        return localBOICEXHC_TS6X;
    }

    /**
     * Auto generated setter method
     * @param param BOICEXHC_TS6X
     */
    public void setBOICEXHC_TS6X(com.huawei.www.hss._EnumType param) {
        localBOICEXHC_TS6XTracker = param != null;

        this.localBOICEXHC_TS6X = param;
    }

    public boolean isBOICEXHC_BS2XSpecified() {
        return localBOICEXHC_BS2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOICEXHC_BS2X() {
        return localBOICEXHC_BS2X;
    }

    /**
     * Auto generated setter method
     * @param param BOICEXHC_BS2X
     */
    public void setBOICEXHC_BS2X(com.huawei.www.hss._EnumType param) {
        localBOICEXHC_BS2XTracker = param != null;

        this.localBOICEXHC_BS2X = param;
    }

    public boolean isBOICEXHC_BS3XSpecified() {
        return localBOICEXHC_BS3XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOICEXHC_BS3X() {
        return localBOICEXHC_BS3X;
    }

    /**
     * Auto generated setter method
     * @param param BOICEXHC_BS3X
     */
    public void setBOICEXHC_BS3X(com.huawei.www.hss._EnumType param) {
        localBOICEXHC_BS3XTracker = param != null;

        this.localBOICEXHC_BS3X = param;
    }

    public boolean isBOICEXHC_TSDXSpecified() {
        return localBOICEXHC_TSDXTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBOICEXHC_TSDX() {
        return localBOICEXHC_TSDX;
    }

    /**
     * Auto generated setter method
     * @param param BOICEXHC_TSDX
     */
    public void setBOICEXHC_TSDX(com.huawei.www.hss._EnumType param) {
        localBOICEXHC_TSDXTracker = param != null;

        this.localBOICEXHC_TSDX = param;
    }

    public boolean isBAIC_ALLSpecified() {
        return localBAIC_ALLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAIC_ALL() {
        return localBAIC_ALL;
    }

    /**
     * Auto generated setter method
     * @param param BAIC_ALL
     */
    public void setBAIC_ALL(com.huawei.www.hss._EnumType param) {
        localBAIC_ALLTracker = param != null;

        this.localBAIC_ALL = param;
    }

    public boolean isBAIC_TS1XSpecified() {
        return localBAIC_TS1XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAIC_TS1X() {
        return localBAIC_TS1X;
    }

    /**
     * Auto generated setter method
     * @param param BAIC_TS1X
     */
    public void setBAIC_TS1X(com.huawei.www.hss._EnumType param) {
        localBAIC_TS1XTracker = param != null;

        this.localBAIC_TS1X = param;
    }

    public boolean isBAIC_TS2XSpecified() {
        return localBAIC_TS2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAIC_TS2X() {
        return localBAIC_TS2X;
    }

    /**
     * Auto generated setter method
     * @param param BAIC_TS2X
     */
    public void setBAIC_TS2X(com.huawei.www.hss._EnumType param) {
        localBAIC_TS2XTracker = param != null;

        this.localBAIC_TS2X = param;
    }

    public boolean isBAIC_TS6XSpecified() {
        return localBAIC_TS6XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAIC_TS6X() {
        return localBAIC_TS6X;
    }

    /**
     * Auto generated setter method
     * @param param BAIC_TS6X
     */
    public void setBAIC_TS6X(com.huawei.www.hss._EnumType param) {
        localBAIC_TS6XTracker = param != null;

        this.localBAIC_TS6X = param;
    }

    public boolean isBAIC_BS2XSpecified() {
        return localBAIC_BS2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAIC_BS2X() {
        return localBAIC_BS2X;
    }

    /**
     * Auto generated setter method
     * @param param BAIC_BS2X
     */
    public void setBAIC_BS2X(com.huawei.www.hss._EnumType param) {
        localBAIC_BS2XTracker = param != null;

        this.localBAIC_BS2X = param;
    }

    public boolean isBAIC_BS3XSpecified() {
        return localBAIC_BS3XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAIC_BS3X() {
        return localBAIC_BS3X;
    }

    /**
     * Auto generated setter method
     * @param param BAIC_BS3X
     */
    public void setBAIC_BS3X(com.huawei.www.hss._EnumType param) {
        localBAIC_BS3XTracker = param != null;

        this.localBAIC_BS3X = param;
    }

    public boolean isBAIC_TSDXSpecified() {
        return localBAIC_TSDXTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBAIC_TSDX() {
        return localBAIC_TSDX;
    }

    /**
     * Auto generated setter method
     * @param param BAIC_TSDX
     */
    public void setBAIC_TSDX(com.huawei.www.hss._EnumType param) {
        localBAIC_TSDXTracker = param != null;

        this.localBAIC_TSDX = param;
    }

    public boolean isBICROAM_ALLSpecified() {
        return localBICROAM_ALLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBICROAM_ALL() {
        return localBICROAM_ALL;
    }

    /**
     * Auto generated setter method
     * @param param BICROAM_ALL
     */
    public void setBICROAM_ALL(com.huawei.www.hss._EnumType param) {
        localBICROAM_ALLTracker = param != null;

        this.localBICROAM_ALL = param;
    }

    public boolean isBICROAM_TS1XSpecified() {
        return localBICROAM_TS1XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBICROAM_TS1X() {
        return localBICROAM_TS1X;
    }

    /**
     * Auto generated setter method
     * @param param BICROAM_TS1X
     */
    public void setBICROAM_TS1X(com.huawei.www.hss._EnumType param) {
        localBICROAM_TS1XTracker = param != null;

        this.localBICROAM_TS1X = param;
    }

    public boolean isBICROAM_TS2XSpecified() {
        return localBICROAM_TS2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBICROAM_TS2X() {
        return localBICROAM_TS2X;
    }

    /**
     * Auto generated setter method
     * @param param BICROAM_TS2X
     */
    public void setBICROAM_TS2X(com.huawei.www.hss._EnumType param) {
        localBICROAM_TS2XTracker = param != null;

        this.localBICROAM_TS2X = param;
    }

    public boolean isBICROAM_TS6XSpecified() {
        return localBICROAM_TS6XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBICROAM_TS6X() {
        return localBICROAM_TS6X;
    }

    /**
     * Auto generated setter method
     * @param param BICROAM_TS6X
     */
    public void setBICROAM_TS6X(com.huawei.www.hss._EnumType param) {
        localBICROAM_TS6XTracker = param != null;

        this.localBICROAM_TS6X = param;
    }

    public boolean isBICROAM_BS2XSpecified() {
        return localBICROAM_BS2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBICROAM_BS2X() {
        return localBICROAM_BS2X;
    }

    /**
     * Auto generated setter method
     * @param param BICROAM_BS2X
     */
    public void setBICROAM_BS2X(com.huawei.www.hss._EnumType param) {
        localBICROAM_BS2XTracker = param != null;

        this.localBICROAM_BS2X = param;
    }

    public boolean isBICROAM_BS3XSpecified() {
        return localBICROAM_BS3XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBICROAM_BS3X() {
        return localBICROAM_BS3X;
    }

    /**
     * Auto generated setter method
     * @param param BICROAM_BS3X
     */
    public void setBICROAM_BS3X(com.huawei.www.hss._EnumType param) {
        localBICROAM_BS3XTracker = param != null;

        this.localBICROAM_BS3X = param;
    }

    public boolean isBICROAM_TSDXSpecified() {
        return localBICROAM_TSDXTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBICROAM_TSDX() {
        return localBICROAM_TSDX;
    }

    /**
     * Auto generated setter method
     * @param param BICROAM_TSDX
     */
    public void setBICROAM_TSDX(com.huawei.www.hss._EnumType param) {
        localBICROAM_TSDXTracker = param != null;

        this.localBICROAM_TSDX = param;
    }

    public boolean isBORO_ALLSpecified() {
        return localBORO_ALLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBORO_ALL() {
        return localBORO_ALL;
    }

    /**
     * Auto generated setter method
     * @param param BORO_ALL
     */
    public void setBORO_ALL(com.huawei.www.hss._EnumType param) {
        localBORO_ALLTracker = param != null;

        this.localBORO_ALL = param;
    }

    public boolean isBORO_TS1XSpecified() {
        return localBORO_TS1XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBORO_TS1X() {
        return localBORO_TS1X;
    }

    /**
     * Auto generated setter method
     * @param param BORO_TS1X
     */
    public void setBORO_TS1X(com.huawei.www.hss._EnumType param) {
        localBORO_TS1XTracker = param != null;

        this.localBORO_TS1X = param;
    }

    public boolean isBORO_TS2XSpecified() {
        return localBORO_TS2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBORO_TS2X() {
        return localBORO_TS2X;
    }

    /**
     * Auto generated setter method
     * @param param BORO_TS2X
     */
    public void setBORO_TS2X(com.huawei.www.hss._EnumType param) {
        localBORO_TS2XTracker = param != null;

        this.localBORO_TS2X = param;
    }

    public boolean isBORO_TS6XSpecified() {
        return localBORO_TS6XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBORO_TS6X() {
        return localBORO_TS6X;
    }

    /**
     * Auto generated setter method
     * @param param BORO_TS6X
     */
    public void setBORO_TS6X(com.huawei.www.hss._EnumType param) {
        localBORO_TS6XTracker = param != null;

        this.localBORO_TS6X = param;
    }

    public boolean isBORO_BS2XSpecified() {
        return localBORO_BS2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBORO_BS2X() {
        return localBORO_BS2X;
    }

    /**
     * Auto generated setter method
     * @param param BORO_BS2X
     */
    public void setBORO_BS2X(com.huawei.www.hss._EnumType param) {
        localBORO_BS2XTracker = param != null;

        this.localBORO_BS2X = param;
    }

    public boolean isBORO_BS3XSpecified() {
        return localBORO_BS3XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBORO_BS3X() {
        return localBORO_BS3X;
    }

    /**
     * Auto generated setter method
     * @param param BORO_BS3X
     */
    public void setBORO_BS3X(com.huawei.www.hss._EnumType param) {
        localBORO_BS3XTracker = param != null;

        this.localBORO_BS3X = param;
    }

    public boolean isBORO_TSDXSpecified() {
        return localBORO_TSDXTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBORO_TSDX() {
        return localBORO_TSDX;
    }

    /**
     * Auto generated setter method
     * @param param BORO_TSDX
     */
    public void setBORO_TSDX(com.huawei.www.hss._EnumType param) {
        localBORO_TSDXTracker = param != null;

        this.localBORO_TSDX = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":LST_CBARStruct1", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "LST_CBARStruct1", xmlWriter);
            }
        }

        if (localIMSITracker) {
            if (localIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMSI cannot be null!!");
            }

            localIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMSI"), xmlWriter);
        }

        if (localISDNTracker) {
            if (localISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ISDN cannot be null!!");
            }

            localISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ISDN"), xmlWriter);
        }

        if (localCBCOUTracker) {
            if (localCBCOU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CBCOU cannot be null!!");
            }

            localCBCOU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CBCOU"), xmlWriter);
        }

        if (localCBCOUREASONTracker) {
            if (localCBCOUREASON == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CBCOUREASON cannot be null!!");
            }

            localCBCOUREASON.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CBCOUREASON"), xmlWriter);
        }

        if (localBAOC_ALLTracker) {
            if (localBAOC_ALL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAOC_ALL cannot be null!!");
            }

            localBAOC_ALL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAOC_ALL"), xmlWriter);
        }

        if (localBAOC_TS1XTracker) {
            if (localBAOC_TS1X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAOC_TS1X cannot be null!!");
            }

            localBAOC_TS1X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAOC_TS1X"), xmlWriter);
        }

        if (localBAOC_TS2XTracker) {
            if (localBAOC_TS2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAOC_TS2X cannot be null!!");
            }

            localBAOC_TS2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAOC_TS2X"), xmlWriter);
        }

        if (localBAOC_TS6XTracker) {
            if (localBAOC_TS6X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAOC_TS6X cannot be null!!");
            }

            localBAOC_TS6X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAOC_TS6X"), xmlWriter);
        }

        if (localBAOC_BS2XTracker) {
            if (localBAOC_BS2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAOC_BS2X cannot be null!!");
            }

            localBAOC_BS2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAOC_BS2X"), xmlWriter);
        }

        if (localBAOC_BS3XTracker) {
            if (localBAOC_BS3X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAOC_BS3X cannot be null!!");
            }

            localBAOC_BS3X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAOC_BS3X"), xmlWriter);
        }

        if (localBAOC_TSDXTracker) {
            if (localBAOC_TSDX == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAOC_TSDX cannot be null!!");
            }

            localBAOC_TSDX.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAOC_TSDX"), xmlWriter);
        }

        if (localBOIC_ALLTracker) {
            if (localBOIC_ALL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOIC_ALL cannot be null!!");
            }

            localBOIC_ALL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOIC_ALL"), xmlWriter);
        }

        if (localBOIC_TS1XTracker) {
            if (localBOIC_TS1X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOIC_TS1X cannot be null!!");
            }

            localBOIC_TS1X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOIC_TS1X"), xmlWriter);
        }

        if (localBOIC_TS2XTracker) {
            if (localBOIC_TS2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOIC_TS2X cannot be null!!");
            }

            localBOIC_TS2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOIC_TS2X"), xmlWriter);
        }

        if (localBOIC_TS6XTracker) {
            if (localBOIC_TS6X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOIC_TS6X cannot be null!!");
            }

            localBOIC_TS6X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOIC_TS6X"), xmlWriter);
        }

        if (localBOIC_BS2XTracker) {
            if (localBOIC_BS2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOIC_BS2X cannot be null!!");
            }

            localBOIC_BS2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOIC_BS2X"), xmlWriter);
        }

        if (localBOIC_BS3XTracker) {
            if (localBOIC_BS3X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOIC_BS3X cannot be null!!");
            }

            localBOIC_BS3X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOIC_BS3X"), xmlWriter);
        }

        if (localBOIC_TSDXTracker) {
            if (localBOIC_TSDX == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOIC_TSDX cannot be null!!");
            }

            localBOIC_TSDX.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOIC_TSDX"), xmlWriter);
        }

        if (localBOICEXHC_ALLTracker) {
            if (localBOICEXHC_ALL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOICEXHC_ALL cannot be null!!");
            }

            localBOICEXHC_ALL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOICEXHC_ALL"), xmlWriter);
        }

        if (localBOICEXHC_TS1XTracker) {
            if (localBOICEXHC_TS1X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOICEXHC_TS1X cannot be null!!");
            }

            localBOICEXHC_TS1X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOICEXHC_TS1X"), xmlWriter);
        }

        if (localBOICEXHC_TS2XTracker) {
            if (localBOICEXHC_TS2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOICEXHC_TS2X cannot be null!!");
            }

            localBOICEXHC_TS2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOICEXHC_TS2X"), xmlWriter);
        }

        if (localBOICEXHC_TS6XTracker) {
            if (localBOICEXHC_TS6X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOICEXHC_TS6X cannot be null!!");
            }

            localBOICEXHC_TS6X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOICEXHC_TS6X"), xmlWriter);
        }

        if (localBOICEXHC_BS2XTracker) {
            if (localBOICEXHC_BS2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOICEXHC_BS2X cannot be null!!");
            }

            localBOICEXHC_BS2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOICEXHC_BS2X"), xmlWriter);
        }

        if (localBOICEXHC_BS3XTracker) {
            if (localBOICEXHC_BS3X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOICEXHC_BS3X cannot be null!!");
            }

            localBOICEXHC_BS3X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOICEXHC_BS3X"), xmlWriter);
        }

        if (localBOICEXHC_TSDXTracker) {
            if (localBOICEXHC_TSDX == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOICEXHC_TSDX cannot be null!!");
            }

            localBOICEXHC_TSDX.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOICEXHC_TSDX"), xmlWriter);
        }

        if (localBAIC_ALLTracker) {
            if (localBAIC_ALL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAIC_ALL cannot be null!!");
            }

            localBAIC_ALL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAIC_ALL"), xmlWriter);
        }

        if (localBAIC_TS1XTracker) {
            if (localBAIC_TS1X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAIC_TS1X cannot be null!!");
            }

            localBAIC_TS1X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAIC_TS1X"), xmlWriter);
        }

        if (localBAIC_TS2XTracker) {
            if (localBAIC_TS2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAIC_TS2X cannot be null!!");
            }

            localBAIC_TS2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAIC_TS2X"), xmlWriter);
        }

        if (localBAIC_TS6XTracker) {
            if (localBAIC_TS6X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAIC_TS6X cannot be null!!");
            }

            localBAIC_TS6X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAIC_TS6X"), xmlWriter);
        }

        if (localBAIC_BS2XTracker) {
            if (localBAIC_BS2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAIC_BS2X cannot be null!!");
            }

            localBAIC_BS2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAIC_BS2X"), xmlWriter);
        }

        if (localBAIC_BS3XTracker) {
            if (localBAIC_BS3X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAIC_BS3X cannot be null!!");
            }

            localBAIC_BS3X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAIC_BS3X"), xmlWriter);
        }

        if (localBAIC_TSDXTracker) {
            if (localBAIC_TSDX == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BAIC_TSDX cannot be null!!");
            }

            localBAIC_TSDX.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BAIC_TSDX"), xmlWriter);
        }

        if (localBICROAM_ALLTracker) {
            if (localBICROAM_ALL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BICROAM_ALL cannot be null!!");
            }

            localBICROAM_ALL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BICROAM_ALL"), xmlWriter);
        }

        if (localBICROAM_TS1XTracker) {
            if (localBICROAM_TS1X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BICROAM_TS1X cannot be null!!");
            }

            localBICROAM_TS1X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BICROAM_TS1X"), xmlWriter);
        }

        if (localBICROAM_TS2XTracker) {
            if (localBICROAM_TS2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BICROAM_TS2X cannot be null!!");
            }

            localBICROAM_TS2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BICROAM_TS2X"), xmlWriter);
        }

        if (localBICROAM_TS6XTracker) {
            if (localBICROAM_TS6X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BICROAM_TS6X cannot be null!!");
            }

            localBICROAM_TS6X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BICROAM_TS6X"), xmlWriter);
        }

        if (localBICROAM_BS2XTracker) {
            if (localBICROAM_BS2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BICROAM_BS2X cannot be null!!");
            }

            localBICROAM_BS2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BICROAM_BS2X"), xmlWriter);
        }

        if (localBICROAM_BS3XTracker) {
            if (localBICROAM_BS3X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BICROAM_BS3X cannot be null!!");
            }

            localBICROAM_BS3X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BICROAM_BS3X"), xmlWriter);
        }

        if (localBICROAM_TSDXTracker) {
            if (localBICROAM_TSDX == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BICROAM_TSDX cannot be null!!");
            }

            localBICROAM_TSDX.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BICROAM_TSDX"), xmlWriter);
        }

        if (localBORO_ALLTracker) {
            if (localBORO_ALL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BORO_ALL cannot be null!!");
            }

            localBORO_ALL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BORO_ALL"), xmlWriter);
        }

        if (localBORO_TS1XTracker) {
            if (localBORO_TS1X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BORO_TS1X cannot be null!!");
            }

            localBORO_TS1X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BORO_TS1X"), xmlWriter);
        }

        if (localBORO_TS2XTracker) {
            if (localBORO_TS2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BORO_TS2X cannot be null!!");
            }

            localBORO_TS2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BORO_TS2X"), xmlWriter);
        }

        if (localBORO_TS6XTracker) {
            if (localBORO_TS6X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BORO_TS6X cannot be null!!");
            }

            localBORO_TS6X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BORO_TS6X"), xmlWriter);
        }

        if (localBORO_BS2XTracker) {
            if (localBORO_BS2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BORO_BS2X cannot be null!!");
            }

            localBORO_BS2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BORO_BS2X"), xmlWriter);
        }

        if (localBORO_BS3XTracker) {
            if (localBORO_BS3X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BORO_BS3X cannot be null!!");
            }

            localBORO_BS3X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BORO_BS3X"), xmlWriter);
        }

        if (localBORO_TSDXTracker) {
            if (localBORO_TSDX == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BORO_TSDX cannot be null!!");
            }

            localBORO_TSDX.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BORO_TSDX"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static LST_CBARStruct1 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            LST_CBARStruct1 object = new LST_CBARStruct1();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"LST_CBARStruct1".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (LST_CBARStruct1) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSI").equals(
                            reader.getName())) {
                    object.setIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ISDN").equals(
                            reader.getName())) {
                    object.setISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CBCOU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CBCOU").equals(
                            reader.getName())) {
                    object.setCBCOU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CBCOUREASON").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CBCOUREASON").equals(
                            reader.getName())) {
                    object.setCBCOUREASON(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAOC_ALL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAOC_ALL").equals(
                            reader.getName())) {
                    object.setBAOC_ALL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAOC_TS1X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAOC_TS1X").equals(
                            reader.getName())) {
                    object.setBAOC_TS1X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAOC_TS2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAOC_TS2X").equals(
                            reader.getName())) {
                    object.setBAOC_TS2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAOC_TS6X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAOC_TS6X").equals(
                            reader.getName())) {
                    object.setBAOC_TS6X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAOC_BS2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAOC_BS2X").equals(
                            reader.getName())) {
                    object.setBAOC_BS2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAOC_BS3X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAOC_BS3X").equals(
                            reader.getName())) {
                    object.setBAOC_BS3X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAOC_TSDX").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAOC_TSDX").equals(
                            reader.getName())) {
                    object.setBAOC_TSDX(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOIC_ALL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOIC_ALL").equals(
                            reader.getName())) {
                    object.setBOIC_ALL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOIC_TS1X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOIC_TS1X").equals(
                            reader.getName())) {
                    object.setBOIC_TS1X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOIC_TS2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOIC_TS2X").equals(
                            reader.getName())) {
                    object.setBOIC_TS2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOIC_TS6X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOIC_TS6X").equals(
                            reader.getName())) {
                    object.setBOIC_TS6X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOIC_BS2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOIC_BS2X").equals(
                            reader.getName())) {
                    object.setBOIC_BS2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOIC_BS3X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOIC_BS3X").equals(
                            reader.getName())) {
                    object.setBOIC_BS3X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOIC_TSDX").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOIC_TSDX").equals(
                            reader.getName())) {
                    object.setBOIC_TSDX(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOICEXHC_ALL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOICEXHC_ALL").equals(
                            reader.getName())) {
                    object.setBOICEXHC_ALL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOICEXHC_TS1X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOICEXHC_TS1X").equals(
                            reader.getName())) {
                    object.setBOICEXHC_TS1X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOICEXHC_TS2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOICEXHC_TS2X").equals(
                            reader.getName())) {
                    object.setBOICEXHC_TS2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOICEXHC_TS6X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOICEXHC_TS6X").equals(
                            reader.getName())) {
                    object.setBOICEXHC_TS6X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOICEXHC_BS2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOICEXHC_BS2X").equals(
                            reader.getName())) {
                    object.setBOICEXHC_BS2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOICEXHC_BS3X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOICEXHC_BS3X").equals(
                            reader.getName())) {
                    object.setBOICEXHC_BS3X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOICEXHC_TSDX").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOICEXHC_TSDX").equals(
                            reader.getName())) {
                    object.setBOICEXHC_TSDX(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAIC_ALL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAIC_ALL").equals(
                            reader.getName())) {
                    object.setBAIC_ALL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAIC_TS1X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAIC_TS1X").equals(
                            reader.getName())) {
                    object.setBAIC_TS1X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAIC_TS2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAIC_TS2X").equals(
                            reader.getName())) {
                    object.setBAIC_TS2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAIC_TS6X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAIC_TS6X").equals(
                            reader.getName())) {
                    object.setBAIC_TS6X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAIC_BS2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAIC_BS2X").equals(
                            reader.getName())) {
                    object.setBAIC_BS2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAIC_BS3X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAIC_BS3X").equals(
                            reader.getName())) {
                    object.setBAIC_BS3X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BAIC_TSDX").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BAIC_TSDX").equals(
                            reader.getName())) {
                    object.setBAIC_TSDX(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BICROAM_ALL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BICROAM_ALL").equals(
                            reader.getName())) {
                    object.setBICROAM_ALL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BICROAM_TS1X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BICROAM_TS1X").equals(
                            reader.getName())) {
                    object.setBICROAM_TS1X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BICROAM_TS2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BICROAM_TS2X").equals(
                            reader.getName())) {
                    object.setBICROAM_TS2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BICROAM_TS6X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BICROAM_TS6X").equals(
                            reader.getName())) {
                    object.setBICROAM_TS6X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BICROAM_BS2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BICROAM_BS2X").equals(
                            reader.getName())) {
                    object.setBICROAM_BS2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BICROAM_BS3X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BICROAM_BS3X").equals(
                            reader.getName())) {
                    object.setBICROAM_BS3X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BICROAM_TSDX").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BICROAM_TSDX").equals(
                            reader.getName())) {
                    object.setBICROAM_TSDX(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BORO_ALL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BORO_ALL").equals(
                            reader.getName())) {
                    object.setBORO_ALL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BORO_TS1X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BORO_TS1X").equals(
                            reader.getName())) {
                    object.setBORO_TS1X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BORO_TS2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BORO_TS2X").equals(
                            reader.getName())) {
                    object.setBORO_TS2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BORO_TS6X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BORO_TS6X").equals(
                            reader.getName())) {
                    object.setBORO_TS6X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BORO_BS2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BORO_BS2X").equals(
                            reader.getName())) {
                    object.setBORO_BS2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BORO_BS3X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BORO_BS3X").equals(
                            reader.getName())) {
                    object.setBORO_BS3X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BORO_TSDX").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BORO_TSDX").equals(
                            reader.getName())) {
                    object.setBORO_TSDX(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
