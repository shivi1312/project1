/**
 * DynamicStatusInfoForS4SGSN_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  DynamicStatusInfoForS4SGSN_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class DynamicStatusInfoForS4SGSN_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = DynamicStatusInfoForS4SGSN_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for SGSNHOST
     */
    protected com.huawei.www.hss.Str1_128 localSGSNHOST;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSGSNHOSTTracker = false;

    /**
     * field for SGSNREALM
     */
    protected com.huawei.www.hss.Str1_128 localSGSNREALM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSGSNREALMTracker = false;

    /**
     * field for SGSNNUMBER
     */
    protected com.huawei.www.hss.Str0_127 localSGSNNUMBER;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSGSNNUMBERTracker = false;

    /**
     * field for SRATTYPE
     */
    protected com.huawei.www.hss._EnumType localSRATTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSRATTYPETracker = false;

    /**
     * field for SVPLMN
     */
    protected com.huawei.www.hss.Str1_9 localSVPLMN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSVPLMNTracker = false;

    /**
     * field for PURGEDONSGSN
     */
    protected com.huawei.www.hss._EnumType localPURGEDONSGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPURGEDONSGSNTracker = false;

    /**
     * field for AREARESTRICT
     */
    protected com.huawei.www.hss._EnumType localAREARESTRICT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAREARESTRICTTracker = false;

    /**
     * field for S4SGSNUpdateLocationTime
     */
    protected com.huawei.www.hss.Str1_35 localS4SGSNUpdateLocationTime;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localS4SGSNUpdateLocationTimeTracker = false;

    /**
     * field for S4SGSNFeatureList
     */
    protected com.huawei.www.hss.Str1_9 localS4SGSNFeatureList;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localS4SGSNFeatureListTracker = false;

    /**
     * field for SLastIDRorDSRFailed
     */
    protected com.huawei.www.hss._EnumType localSLastIDRorDSRFailed;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSLastIDRorDSRFailedTracker = false;

    /**
     * field for SSkipSubscriberDataIndicator
     */
    protected com.huawei.www.hss._EnumType localSSkipSubscriberDataIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSSkipSubscriberDataIndicatorTracker = false;

    /**
     * field for SGPRSSubscriptionDataIndicator
     */
    protected com.huawei.www.hss._EnumType localSGPRSSubscriptionDataIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSGPRSSubscriptionDataIndicatorTracker = false;

    /**
     * field for SNodeTypeIndicator
     */
    protected com.huawei.www.hss._EnumType localSNodeTypeIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSNodeTypeIndicatorTracker = false;

    /**
     * field for SInitialAttachIndicator
     */
    protected com.huawei.www.hss._EnumType localSInitialAttachIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSInitialAttachIndicatorTracker = false;

    /**
     * field for SPSLCSNotSupportedByUE
     */
    protected com.huawei.www.hss._EnumType localSPSLCSNotSupportedByUE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSPSLCSNotSupportedByUETracker = false;

    /**
     * field for SIMEI
     */
    protected com.huawei.www.hss.Str1_16 localSIMEI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSIMEITracker = false;

    /**
     * field for SIMEISV
     */
    protected com.huawei.www.hss.Str1_2 localSIMEISV;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSIMEISVTracker = false;

    /**
     * field for S4SGSNFeatureList2
     */
    protected com.huawei.www.hss.Str1_9 localS4SGSNFeatureList2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localS4SGSNFeatureList2Tracker = false;

    /**
     * field for IMSVOPSSessionsSupportedS4SGSN
     */
    protected com.huawei.www.hss._EnumType localIMSVOPSSessionsSupportedS4SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSVOPSSessionsSupportedS4SGSNTracker = false;

    /**
     * field for UESRVCCCapabilityS4SGSN
     */
    protected com.huawei.www.hss._EnumType localUESRVCCCapabilityS4SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUESRVCCCapabilityS4SGSNTracker = false;

    /**
     * field for VGMLCSGSN
     */
    protected com.huawei.www.hss.Str1_60 localVGMLCSGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVGMLCSGSNTracker = false;

    public boolean isSGSNHOSTSpecified() {
        return localSGSNHOSTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getSGSNHOST() {
        return localSGSNHOST;
    }

    /**
     * Auto generated setter method
     * @param param SGSNHOST
     */
    public void setSGSNHOST(com.huawei.www.hss.Str1_128 param) {
        localSGSNHOSTTracker = param != null;

        this.localSGSNHOST = param;
    }

    public boolean isSGSNREALMSpecified() {
        return localSGSNREALMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getSGSNREALM() {
        return localSGSNREALM;
    }

    /**
     * Auto generated setter method
     * @param param SGSNREALM
     */
    public void setSGSNREALM(com.huawei.www.hss.Str1_128 param) {
        localSGSNREALMTracker = param != null;

        this.localSGSNREALM = param;
    }

    public boolean isSGSNNUMBERSpecified() {
        return localSGSNNUMBERTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_127
     */
    public com.huawei.www.hss.Str0_127 getSGSNNUMBER() {
        return localSGSNNUMBER;
    }

    /**
     * Auto generated setter method
     * @param param SGSNNUMBER
     */
    public void setSGSNNUMBER(com.huawei.www.hss.Str0_127 param) {
        localSGSNNUMBERTracker = param != null;

        this.localSGSNNUMBER = param;
    }

    public boolean isSRATTYPESpecified() {
        return localSRATTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSRATTYPE() {
        return localSRATTYPE;
    }

    /**
     * Auto generated setter method
     * @param param SRATTYPE
     */
    public void setSRATTYPE(com.huawei.www.hss._EnumType param) {
        localSRATTYPETracker = param != null;

        this.localSRATTYPE = param;
    }

    public boolean isSVPLMNSpecified() {
        return localSVPLMNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_9
     */
    public com.huawei.www.hss.Str1_9 getSVPLMN() {
        return localSVPLMN;
    }

    /**
     * Auto generated setter method
     * @param param SVPLMN
     */
    public void setSVPLMN(com.huawei.www.hss.Str1_9 param) {
        localSVPLMNTracker = param != null;

        this.localSVPLMN = param;
    }

    public boolean isPURGEDONSGSNSpecified() {
        return localPURGEDONSGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPURGEDONSGSN() {
        return localPURGEDONSGSN;
    }

    /**
     * Auto generated setter method
     * @param param PURGEDONSGSN
     */
    public void setPURGEDONSGSN(com.huawei.www.hss._EnumType param) {
        localPURGEDONSGSNTracker = param != null;

        this.localPURGEDONSGSN = param;
    }

    public boolean isAREARESTRICTSpecified() {
        return localAREARESTRICTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getAREARESTRICT() {
        return localAREARESTRICT;
    }

    /**
     * Auto generated setter method
     * @param param AREARESTRICT
     */
    public void setAREARESTRICT(com.huawei.www.hss._EnumType param) {
        localAREARESTRICTTracker = param != null;

        this.localAREARESTRICT = param;
    }

    public boolean isS4SGSNUpdateLocationTimeSpecified() {
        return localS4SGSNUpdateLocationTimeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_35
     */
    public com.huawei.www.hss.Str1_35 getS4SGSNUpdateLocationTime() {
        return localS4SGSNUpdateLocationTime;
    }

    /**
     * Auto generated setter method
     * @param param S4SGSNUpdateLocationTime
     */
    public void setS4SGSNUpdateLocationTime(com.huawei.www.hss.Str1_35 param) {
        localS4SGSNUpdateLocationTimeTracker = param != null;

        this.localS4SGSNUpdateLocationTime = param;
    }

    public boolean isS4SGSNFeatureListSpecified() {
        return localS4SGSNFeatureListTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_9
     */
    public com.huawei.www.hss.Str1_9 getS4SGSNFeatureList() {
        return localS4SGSNFeatureList;
    }

    /**
     * Auto generated setter method
     * @param param S4SGSNFeatureList
     */
    public void setS4SGSNFeatureList(com.huawei.www.hss.Str1_9 param) {
        localS4SGSNFeatureListTracker = param != null;

        this.localS4SGSNFeatureList = param;
    }

    public boolean isSLastIDRorDSRFailedSpecified() {
        return localSLastIDRorDSRFailedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSLastIDRorDSRFailed() {
        return localSLastIDRorDSRFailed;
    }

    /**
     * Auto generated setter method
     * @param param SLastIDRorDSRFailed
     */
    public void setSLastIDRorDSRFailed(com.huawei.www.hss._EnumType param) {
        localSLastIDRorDSRFailedTracker = param != null;

        this.localSLastIDRorDSRFailed = param;
    }

    public boolean isSSkipSubscriberDataIndicatorSpecified() {
        return localSSkipSubscriberDataIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSSkipSubscriberDataIndicator() {
        return localSSkipSubscriberDataIndicator;
    }

    /**
     * Auto generated setter method
     * @param param SSkipSubscriberDataIndicator
     */
    public void setSSkipSubscriberDataIndicator(
        com.huawei.www.hss._EnumType param) {
        localSSkipSubscriberDataIndicatorTracker = param != null;

        this.localSSkipSubscriberDataIndicator = param;
    }

    public boolean isSGPRSSubscriptionDataIndicatorSpecified() {
        return localSGPRSSubscriptionDataIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSGPRSSubscriptionDataIndicator() {
        return localSGPRSSubscriptionDataIndicator;
    }

    /**
     * Auto generated setter method
     * @param param SGPRSSubscriptionDataIndicator
     */
    public void setSGPRSSubscriptionDataIndicator(
        com.huawei.www.hss._EnumType param) {
        localSGPRSSubscriptionDataIndicatorTracker = param != null;

        this.localSGPRSSubscriptionDataIndicator = param;
    }

    public boolean isSNodeTypeIndicatorSpecified() {
        return localSNodeTypeIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSNodeTypeIndicator() {
        return localSNodeTypeIndicator;
    }

    /**
     * Auto generated setter method
     * @param param SNodeTypeIndicator
     */
    public void setSNodeTypeIndicator(com.huawei.www.hss._EnumType param) {
        localSNodeTypeIndicatorTracker = param != null;

        this.localSNodeTypeIndicator = param;
    }

    public boolean isSInitialAttachIndicatorSpecified() {
        return localSInitialAttachIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSInitialAttachIndicator() {
        return localSInitialAttachIndicator;
    }

    /**
     * Auto generated setter method
     * @param param SInitialAttachIndicator
     */
    public void setSInitialAttachIndicator(com.huawei.www.hss._EnumType param) {
        localSInitialAttachIndicatorTracker = param != null;

        this.localSInitialAttachIndicator = param;
    }

    public boolean isSPSLCSNotSupportedByUESpecified() {
        return localSPSLCSNotSupportedByUETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSPSLCSNotSupportedByUE() {
        return localSPSLCSNotSupportedByUE;
    }

    /**
     * Auto generated setter method
     * @param param SPSLCSNotSupportedByUE
     */
    public void setSPSLCSNotSupportedByUE(com.huawei.www.hss._EnumType param) {
        localSPSLCSNotSupportedByUETracker = param != null;

        this.localSPSLCSNotSupportedByUE = param;
    }

    public boolean isSIMEISpecified() {
        return localSIMEITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getSIMEI() {
        return localSIMEI;
    }

    /**
     * Auto generated setter method
     * @param param SIMEI
     */
    public void setSIMEI(com.huawei.www.hss.Str1_16 param) {
        localSIMEITracker = param != null;

        this.localSIMEI = param;
    }

    public boolean isSIMEISVSpecified() {
        return localSIMEISVTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_2
     */
    public com.huawei.www.hss.Str1_2 getSIMEISV() {
        return localSIMEISV;
    }

    /**
     * Auto generated setter method
     * @param param SIMEISV
     */
    public void setSIMEISV(com.huawei.www.hss.Str1_2 param) {
        localSIMEISVTracker = param != null;

        this.localSIMEISV = param;
    }

    public boolean isS4SGSNFeatureList2Specified() {
        return localS4SGSNFeatureList2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_9
     */
    public com.huawei.www.hss.Str1_9 getS4SGSNFeatureList2() {
        return localS4SGSNFeatureList2;
    }

    /**
     * Auto generated setter method
     * @param param S4SGSNFeatureList2
     */
    public void setS4SGSNFeatureList2(com.huawei.www.hss.Str1_9 param) {
        localS4SGSNFeatureList2Tracker = param != null;

        this.localS4SGSNFeatureList2 = param;
    }

    public boolean isIMSVOPSSessionsSupportedS4SGSNSpecified() {
        return localIMSVOPSSessionsSupportedS4SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getIMSVOPSSessionsSupportedS4SGSN() {
        return localIMSVOPSSessionsSupportedS4SGSN;
    }

    /**
     * Auto generated setter method
     * @param param IMSVOPSSessionsSupportedS4SGSN
     */
    public void setIMSVOPSSessionsSupportedS4SGSN(
        com.huawei.www.hss._EnumType param) {
        localIMSVOPSSessionsSupportedS4SGSNTracker = param != null;

        this.localIMSVOPSSessionsSupportedS4SGSN = param;
    }

    public boolean isUESRVCCCapabilityS4SGSNSpecified() {
        return localUESRVCCCapabilityS4SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUESRVCCCapabilityS4SGSN() {
        return localUESRVCCCapabilityS4SGSN;
    }

    /**
     * Auto generated setter method
     * @param param UESRVCCCapabilityS4SGSN
     */
    public void setUESRVCCCapabilityS4SGSN(com.huawei.www.hss._EnumType param) {
        localUESRVCCCapabilityS4SGSNTracker = param != null;

        this.localUESRVCCCapabilityS4SGSN = param;
    }

    public boolean isVGMLCSGSNSpecified() {
        return localVGMLCSGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_60
     */
    public com.huawei.www.hss.Str1_60 getVGMLCSGSN() {
        return localVGMLCSGSN;
    }

    /**
     * Auto generated setter method
     * @param param VGMLCSGSN
     */
    public void setVGMLCSGSN(com.huawei.www.hss.Str1_60 param) {
        localVGMLCSGSNTracker = param != null;

        this.localVGMLCSGSN = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":DynamicStatusInfoForS4SGSN_type0",
                    xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "DynamicStatusInfoForS4SGSN_type0", xmlWriter);
            }
        }

        if (localSGSNHOSTTracker) {
            if (localSGSNHOST == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SGSNHOST cannot be null!!");
            }

            localSGSNHOST.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SGSNHOST"), xmlWriter);
        }

        if (localSGSNREALMTracker) {
            if (localSGSNREALM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SGSNREALM cannot be null!!");
            }

            localSGSNREALM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SGSNREALM"), xmlWriter);
        }

        if (localSGSNNUMBERTracker) {
            if (localSGSNNUMBER == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SGSNNUMBER cannot be null!!");
            }

            localSGSNNUMBER.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SGSNNUMBER"), xmlWriter);
        }

        if (localSRATTYPETracker) {
            if (localSRATTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-RATTYPE cannot be null!!");
            }

            localSRATTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-RATTYPE"), xmlWriter);
        }

        if (localSVPLMNTracker) {
            if (localSVPLMN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-VPLMN cannot be null!!");
            }

            localSVPLMN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-VPLMN"), xmlWriter);
        }

        if (localPURGEDONSGSNTracker) {
            if (localPURGEDONSGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PURGEDONSGSN cannot be null!!");
            }

            localPURGEDONSGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PURGEDONSGSN"), xmlWriter);
        }

        if (localAREARESTRICTTracker) {
            if (localAREARESTRICT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AREARESTRICT cannot be null!!");
            }

            localAREARESTRICT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AREARESTRICT"), xmlWriter);
        }

        if (localS4SGSNUpdateLocationTimeTracker) {
            if (localS4SGSNUpdateLocationTime == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S4SGSN-UpdateLocation-Time cannot be null!!");
            }

            localS4SGSNUpdateLocationTime.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S4SGSN-UpdateLocation-Time"),
                xmlWriter);
        }

        if (localS4SGSNFeatureListTracker) {
            if (localS4SGSNFeatureList == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S4SGSN-FeatureList cannot be null!!");
            }

            localS4SGSNFeatureList.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S4SGSN-FeatureList"),
                xmlWriter);
        }

        if (localSLastIDRorDSRFailedTracker) {
            if (localSLastIDRorDSRFailed == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-LastIDRorDSRFailed cannot be null!!");
            }

            localSLastIDRorDSRFailed.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-LastIDRorDSRFailed"),
                xmlWriter);
        }

        if (localSSkipSubscriberDataIndicatorTracker) {
            if (localSSkipSubscriberDataIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-Skip-Subscriber-Data-Indicator cannot be null!!");
            }

            localSSkipSubscriberDataIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "S-Skip-Subscriber-Data-Indicator"), xmlWriter);
        }

        if (localSGPRSSubscriptionDataIndicatorTracker) {
            if (localSGPRSSubscriptionDataIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-GPRS-Subscription-Data-Indicator cannot be null!!");
            }

            localSGPRSSubscriptionDataIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "S-GPRS-Subscription-Data-Indicator"), xmlWriter);
        }

        if (localSNodeTypeIndicatorTracker) {
            if (localSNodeTypeIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-Node-Type-Indicator cannot be null!!");
            }

            localSNodeTypeIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-Node-Type-Indicator"),
                xmlWriter);
        }

        if (localSInitialAttachIndicatorTracker) {
            if (localSInitialAttachIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-Initial-Attach-Indicator cannot be null!!");
            }

            localSInitialAttachIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-Initial-Attach-Indicator"),
                xmlWriter);
        }

        if (localSPSLCSNotSupportedByUETracker) {
            if (localSPSLCSNotSupportedByUE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-PS-LCS-Not-Supported-By-UE cannot be null!!");
            }

            localSPSLCSNotSupportedByUE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-PS-LCS-Not-Supported-By-UE"),
                xmlWriter);
        }

        if (localSIMEITracker) {
            if (localSIMEI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-IMEI cannot be null!!");
            }

            localSIMEI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-IMEI"), xmlWriter);
        }

        if (localSIMEISVTracker) {
            if (localSIMEISV == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-IMEISV cannot be null!!");
            }

            localSIMEISV.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-IMEISV"), xmlWriter);
        }

        if (localS4SGSNFeatureList2Tracker) {
            if (localS4SGSNFeatureList2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S4SGSN-FeatureList2 cannot be null!!");
            }

            localS4SGSNFeatureList2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S4SGSN-FeatureList2"),
                xmlWriter);
        }

        if (localIMSVOPSSessionsSupportedS4SGSNTracker) {
            if (localIMSVOPSSessionsSupportedS4SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMS-VO-PS-Sessions-Supported-S4SGSN cannot be null!!");
            }

            localIMSVOPSSessionsSupportedS4SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "IMS-VO-PS-Sessions-Supported-S4SGSN"), xmlWriter);
        }

        if (localUESRVCCCapabilityS4SGSNTracker) {
            if (localUESRVCCCapabilityS4SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UE-SRVCC-Capability-S4SGSN cannot be null!!");
            }

            localUESRVCCCapabilityS4SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UE-SRVCC-Capability-S4SGSN"),
                xmlWriter);
        }

        if (localVGMLCSGSNTracker) {
            if (localVGMLCSGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VGMLC-SGSN cannot be null!!");
            }

            localVGMLCSGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VGMLC-SGSN"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static DynamicStatusInfoForS4SGSN_type0 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            DynamicStatusInfoForS4SGSN_type0 object = new DynamicStatusInfoForS4SGSN_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"DynamicStatusInfoForS4SGSN_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (DynamicStatusInfoForS4SGSN_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SGSNHOST").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SGSNHOST").equals(
                            reader.getName())) {
                    object.setSGSNHOST(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SGSNREALM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SGSNREALM").equals(
                            reader.getName())) {
                    object.setSGSNREALM(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SGSNNUMBER").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SGSNNUMBER").equals(
                            reader.getName())) {
                    object.setSGSNNUMBER(com.huawei.www.hss.Str0_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S-RATTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S-RATTYPE").equals(
                            reader.getName())) {
                    object.setSRATTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S-VPLMN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S-VPLMN").equals(
                            reader.getName())) {
                    object.setSVPLMN(com.huawei.www.hss.Str1_9.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PURGEDONSGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PURGEDONSGSN").equals(
                            reader.getName())) {
                    object.setPURGEDONSGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AREARESTRICT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AREARESTRICT").equals(
                            reader.getName())) {
                    object.setAREARESTRICT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "S4SGSN-UpdateLocation-Time").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "S4SGSN-UpdateLocation-Time").equals(
                            reader.getName())) {
                    object.setS4SGSNUpdateLocationTime(com.huawei.www.hss.Str1_35.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S4SGSN-FeatureList").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S4SGSN-FeatureList").equals(
                            reader.getName())) {
                    object.setS4SGSNFeatureList(com.huawei.www.hss.Str1_9.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S-LastIDRorDSRFailed").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S-LastIDRorDSRFailed").equals(
                            reader.getName())) {
                    object.setSLastIDRorDSRFailed(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "S-Skip-Subscriber-Data-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "S-Skip-Subscriber-Data-Indicator").equals(
                            reader.getName())) {
                    object.setSSkipSubscriberDataIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "S-GPRS-Subscription-Data-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "S-GPRS-Subscription-Data-Indicator").equals(
                            reader.getName())) {
                    object.setSGPRSSubscriptionDataIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S-Node-Type-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "S-Node-Type-Indicator").equals(reader.getName())) {
                    object.setSNodeTypeIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "S-Initial-Attach-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "S-Initial-Attach-Indicator").equals(
                            reader.getName())) {
                    object.setSInitialAttachIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "S-PS-LCS-Not-Supported-By-UE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "S-PS-LCS-Not-Supported-By-UE").equals(
                            reader.getName())) {
                    object.setSPSLCSNotSupportedByUE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S-IMEI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S-IMEI").equals(
                            reader.getName())) {
                    object.setSIMEI(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S-IMEISV").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S-IMEISV").equals(
                            reader.getName())) {
                    object.setSIMEISV(com.huawei.www.hss.Str1_2.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S4SGSN-FeatureList2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S4SGSN-FeatureList2").equals(
                            reader.getName())) {
                    object.setS4SGSNFeatureList2(com.huawei.www.hss.Str1_9.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "IMS-VO-PS-Sessions-Supported-S4SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "IMS-VO-PS-Sessions-Supported-S4SGSN").equals(
                            reader.getName())) {
                    object.setIMSVOPSSessionsSupportedS4SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "UE-SRVCC-Capability-S4SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "UE-SRVCC-Capability-S4SGSN").equals(
                            reader.getName())) {
                    object.setUESRVCCCapabilityS4SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VGMLC-SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VGMLC-SGSN").equals(
                            reader.getName())) {
                    object.setVGMLCSGSN(com.huawei.www.hss.Str1_60.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
