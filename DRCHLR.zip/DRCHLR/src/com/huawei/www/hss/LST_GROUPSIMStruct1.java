/**
 * LST_GROUPSIMStruct1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  LST_GROUPSIMStruct1 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class LST_GROUPSIMStruct1 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = LST_GROUPSIMStruct1
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for GIMSI
     */
    protected com.huawei.www.hss.Str6_15 localGIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGIMSITracker = false;

    /**
     * field for GISDN
     */
    protected com.huawei.www.hss.Str1_15 localGISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGISDNTracker = false;

    /**
     * field for MSIMTYPE
     */
    protected com.huawei.www.hss._EnumType localMSIMTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMSIMTYPETracker = false;

    /**
     * field for USERTYPE
     */
    protected com.huawei.www.hss.Int0_254 localUSERTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUSERTYPETracker = false;

    /**
     * field for TONETYPE
     */
    protected com.huawei.www.hss._EnumType localTONETYPE;

    /**
     * field for CFSUP
     */
    protected com.huawei.www.hss._EnumType localCFSUP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFSUPTracker = false;

    /**
     * field for STIME
     */
    protected com.huawei.www.hss.Int0_255 localSTIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSTIMETracker = false;

    /**
     * field for PTIME
     */
    protected com.huawei.www.hss.Int0_255 localPTIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPTIMETracker = false;

    /**
     * field for SMS
     */
    protected com.huawei.www.hss.Str1_15 localSMS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSMSTracker = false;

    /**
     * field for VOICE
     */
    protected com.huawei.www.hss.Str1_15 localVOICE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVOICETracker = false;

    /**
     * field for MMS
     */
    protected com.huawei.www.hss.Str1_15 localMMS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMMSTracker = false;

    /**
     * field for LCS
     */
    protected com.huawei.www.hss.Str1_15 localLCS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLCSTracker = false;

    /**
     * field for SYNC
     */
    protected com.huawei.www.hss._EnumType localSYNC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSYNCTracker = false;

    /**
     * field for MEMBERISDN
     */
    protected com.huawei.www.hss.Str1_15 localMEMBERISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMEMBERISDNTracker = false;

    /**
     * field for ORDER
     */
    protected com.huawei.www.hss.Int0_8 localORDER;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localORDERTracker = false;

    /**
     * field for MBRDC
     */
    protected com.huawei.www.hss._EnumType localMBRDC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMBRDCTracker = false;

    /**
     * field for MBRSMS
     */
    protected com.huawei.www.hss._EnumType localMBRSMS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMBRSMSTracker = false;

    public boolean isGIMSISpecified() {
        return localGIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getGIMSI() {
        return localGIMSI;
    }

    /**
     * Auto generated setter method
     * @param param GIMSI
     */
    public void setGIMSI(com.huawei.www.hss.Str6_15 param) {
        localGIMSITracker = param != null;

        this.localGIMSI = param;
    }

    public boolean isGISDNSpecified() {
        return localGISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getGISDN() {
        return localGISDN;
    }

    /**
     * Auto generated setter method
     * @param param GISDN
     */
    public void setGISDN(com.huawei.www.hss.Str1_15 param) {
        localGISDNTracker = param != null;

        this.localGISDN = param;
    }

    public boolean isMSIMTYPESpecified() {
        return localMSIMTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMSIMTYPE() {
        return localMSIMTYPE;
    }

    /**
     * Auto generated setter method
     * @param param MSIMTYPE
     */
    public void setMSIMTYPE(com.huawei.www.hss._EnumType param) {
        localMSIMTYPETracker = param != null;

        this.localMSIMTYPE = param;
    }

    public boolean isUSERTYPESpecified() {
        return localUSERTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_254
     */
    public com.huawei.www.hss.Int0_254 getUSERTYPE() {
        return localUSERTYPE;
    }

    /**
     * Auto generated setter method
     * @param param USERTYPE
     */
    public void setUSERTYPE(com.huawei.www.hss.Int0_254 param) {
        localUSERTYPETracker = param != null;

        this.localUSERTYPE = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTONETYPE() {
        return localTONETYPE;
    }

    /**
     * Auto generated setter method
     * @param param TONETYPE
     */
    public void setTONETYPE(com.huawei.www.hss._EnumType param) {
        this.localTONETYPE = param;
    }

    public boolean isCFSUPSpecified() {
        return localCFSUPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFSUP() {
        return localCFSUP;
    }

    /**
     * Auto generated setter method
     * @param param CFSUP
     */
    public void setCFSUP(com.huawei.www.hss._EnumType param) {
        localCFSUPTracker = param != null;

        this.localCFSUP = param;
    }

    public boolean isSTIMESpecified() {
        return localSTIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_255
     */
    public com.huawei.www.hss.Int0_255 getSTIME() {
        return localSTIME;
    }

    /**
     * Auto generated setter method
     * @param param STIME
     */
    public void setSTIME(com.huawei.www.hss.Int0_255 param) {
        localSTIMETracker = param != null;

        this.localSTIME = param;
    }

    public boolean isPTIMESpecified() {
        return localPTIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_255
     */
    public com.huawei.www.hss.Int0_255 getPTIME() {
        return localPTIME;
    }

    /**
     * Auto generated setter method
     * @param param PTIME
     */
    public void setPTIME(com.huawei.www.hss.Int0_255 param) {
        localPTIMETracker = param != null;

        this.localPTIME = param;
    }

    public boolean isSMSSpecified() {
        return localSMSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getSMS() {
        return localSMS;
    }

    /**
     * Auto generated setter method
     * @param param SMS
     */
    public void setSMS(com.huawei.www.hss.Str1_15 param) {
        localSMSTracker = param != null;

        this.localSMS = param;
    }

    public boolean isVOICESpecified() {
        return localVOICETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getVOICE() {
        return localVOICE;
    }

    /**
     * Auto generated setter method
     * @param param VOICE
     */
    public void setVOICE(com.huawei.www.hss.Str1_15 param) {
        localVOICETracker = param != null;

        this.localVOICE = param;
    }

    public boolean isMMSSpecified() {
        return localMMSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getMMS() {
        return localMMS;
    }

    /**
     * Auto generated setter method
     * @param param MMS
     */
    public void setMMS(com.huawei.www.hss.Str1_15 param) {
        localMMSTracker = param != null;

        this.localMMS = param;
    }

    public boolean isLCSSpecified() {
        return localLCSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getLCS() {
        return localLCS;
    }

    /**
     * Auto generated setter method
     * @param param LCS
     */
    public void setLCS(com.huawei.www.hss.Str1_15 param) {
        localLCSTracker = param != null;

        this.localLCS = param;
    }

    public boolean isSYNCSpecified() {
        return localSYNCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSYNC() {
        return localSYNC;
    }

    /**
     * Auto generated setter method
     * @param param SYNC
     */
    public void setSYNC(com.huawei.www.hss._EnumType param) {
        localSYNCTracker = param != null;

        this.localSYNC = param;
    }

    public boolean isMEMBERISDNSpecified() {
        return localMEMBERISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getMEMBERISDN() {
        return localMEMBERISDN;
    }

    /**
     * Auto generated setter method
     * @param param MEMBERISDN
     */
    public void setMEMBERISDN(com.huawei.www.hss.Str1_15 param) {
        localMEMBERISDNTracker = param != null;

        this.localMEMBERISDN = param;
    }

    public boolean isORDERSpecified() {
        return localORDERTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_8
     */
    public com.huawei.www.hss.Int0_8 getORDER() {
        return localORDER;
    }

    /**
     * Auto generated setter method
     * @param param ORDER
     */
    public void setORDER(com.huawei.www.hss.Int0_8 param) {
        localORDERTracker = param != null;

        this.localORDER = param;
    }

    public boolean isMBRDCSpecified() {
        return localMBRDCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMBRDC() {
        return localMBRDC;
    }

    /**
     * Auto generated setter method
     * @param param MBRDC
     */
    public void setMBRDC(com.huawei.www.hss._EnumType param) {
        localMBRDCTracker = param != null;

        this.localMBRDC = param;
    }

    public boolean isMBRSMSSpecified() {
        return localMBRSMSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMBRSMS() {
        return localMBRSMS;
    }

    /**
     * Auto generated setter method
     * @param param MBRSMS
     */
    public void setMBRSMS(com.huawei.www.hss._EnumType param) {
        localMBRSMSTracker = param != null;

        this.localMBRSMS = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":LST_GROUPSIMStruct1", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "LST_GROUPSIMStruct1", xmlWriter);
            }
        }

        if (localGIMSITracker) {
            if (localGIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GIMSI cannot be null!!");
            }

            localGIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GIMSI"), xmlWriter);
        }

        if (localGISDNTracker) {
            if (localGISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GISDN cannot be null!!");
            }

            localGISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GISDN"), xmlWriter);
        }

        if (localMSIMTYPETracker) {
            if (localMSIMTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MSIMTYPE cannot be null!!");
            }

            localMSIMTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MSIMTYPE"), xmlWriter);
        }

        if (localUSERTYPETracker) {
            if (localUSERTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "USERTYPE cannot be null!!");
            }

            localUSERTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "USERTYPE"), xmlWriter);
        }

        if (localTONETYPE == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "TONETYPE cannot be null!!");
        }

        localTONETYPE.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "TONETYPE"), xmlWriter);

        if (localCFSUPTracker) {
            if (localCFSUP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFSUP cannot be null!!");
            }

            localCFSUP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFSUP"), xmlWriter);
        }

        if (localSTIMETracker) {
            if (localSTIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "STIME cannot be null!!");
            }

            localSTIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "STIME"), xmlWriter);
        }

        if (localPTIMETracker) {
            if (localPTIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PTIME cannot be null!!");
            }

            localPTIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PTIME"), xmlWriter);
        }

        if (localSMSTracker) {
            if (localSMS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SMS cannot be null!!");
            }

            localSMS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SMS"), xmlWriter);
        }

        if (localVOICETracker) {
            if (localVOICE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VOICE cannot be null!!");
            }

            localVOICE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VOICE"), xmlWriter);
        }

        if (localMMSTracker) {
            if (localMMS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MMS cannot be null!!");
            }

            localMMS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MMS"), xmlWriter);
        }

        if (localLCSTracker) {
            if (localLCS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LCS cannot be null!!");
            }

            localLCS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LCS"), xmlWriter);
        }

        if (localSYNCTracker) {
            if (localSYNC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SYNC cannot be null!!");
            }

            localSYNC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SYNC"), xmlWriter);
        }

        if (localMEMBERISDNTracker) {
            if (localMEMBERISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MEMBERISDN cannot be null!!");
            }

            localMEMBERISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MEMBERISDN"), xmlWriter);
        }

        if (localORDERTracker) {
            if (localORDER == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ORDER cannot be null!!");
            }

            localORDER.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ORDER"), xmlWriter);
        }

        if (localMBRDCTracker) {
            if (localMBRDC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MBRDC cannot be null!!");
            }

            localMBRDC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MBRDC"), xmlWriter);
        }

        if (localMBRSMSTracker) {
            if (localMBRSMS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MBRSMS cannot be null!!");
            }

            localMBRSMS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MBRSMS"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static LST_GROUPSIMStruct1 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            LST_GROUPSIMStruct1 object = new LST_GROUPSIMStruct1();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"LST_GROUPSIMStruct1".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (LST_GROUPSIMStruct1) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GIMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GIMSI").equals(
                            reader.getName())) {
                    object.setGIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GISDN").equals(
                            reader.getName())) {
                    object.setGISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MSIMTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MSIMTYPE").equals(
                            reader.getName())) {
                    object.setMSIMTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "USERTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "USERTYPE").equals(
                            reader.getName())) {
                    object.setUSERTYPE(com.huawei.www.hss.Int0_254.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TONETYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TONETYPE").equals(
                            reader.getName())) {
                    object.setTONETYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFSUP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFSUP").equals(
                            reader.getName())) {
                    object.setCFSUP(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "STIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "STIME").equals(
                            reader.getName())) {
                    object.setSTIME(com.huawei.www.hss.Int0_255.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PTIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PTIME").equals(
                            reader.getName())) {
                    object.setPTIME(com.huawei.www.hss.Int0_255.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SMS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SMS").equals(
                            reader.getName())) {
                    object.setSMS(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VOICE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VOICE").equals(
                            reader.getName())) {
                    object.setVOICE(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MMS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MMS").equals(
                            reader.getName())) {
                    object.setMMS(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LCS").equals(
                            reader.getName())) {
                    object.setLCS(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SYNC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SYNC").equals(
                            reader.getName())) {
                    object.setSYNC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MEMBERISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MEMBERISDN").equals(
                            reader.getName())) {
                    object.setMEMBERISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ORDER").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ORDER").equals(
                            reader.getName())) {
                    object.setORDER(com.huawei.www.hss.Int0_8.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MBRDC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MBRDC").equals(
                            reader.getName())) {
                    object.setMBRDC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MBRSMS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MBRSMS").equals(
                            reader.getName())) {
                    object.setMBRSMS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
