/**
 * LST_ESUBStruct1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  LST_ESUBStruct1 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class LST_ESUBStruct1 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = LST_ESUBStruct1
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for IMSI
     */
    protected com.huawei.www.hss.Str6_15 localIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSITracker = false;

    /**
     * field for ISDN
     */
    protected com.huawei.www.hss.Str1_15 localISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localISDNTracker = false;

    /**
     * field for STATE
     */
    protected com.huawei.www.hss._EnumType localSTATE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSTATETracker = false;

    /**
     * field for AUTHD
     */
    protected com.huawei.www.hss._EnumType localAUTHD;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAUTHDTracker = false;

    /**
     * field for NAM
     */
    protected com.huawei.www.hss.Int0_65535 localNAM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localNAMTracker = false;

    /**
     * field for SUD
     */
    protected com.huawei.www.hss.Str1_1024 localSUD;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSUDTracker = false;

    /**
     * field for AMSISDN
     */
    protected com.huawei.www.hss.Str1_15 localAMSISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAMSISDNTracker = false;

    /**
     * field for BS
     */
    protected com.huawei.www.hss._EnumType localBS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSTracker = false;

    /**
     * field for BC
     */
    protected com.huawei.www.hss.Str1_15 localBC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBCTracker = false;

    /**
     * field for BSG1
     */
    protected com.huawei.www.hss._EnumType localBSG1;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG1Tracker = false;

    /**
     * field for BSG1SS
     */
    protected com.huawei.www.hss._EnumType localBSG1SS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG1SSTracker = false;

    /**
     * field for BSG1STATU
     */
    protected com.huawei.www.hss._EnumType localBSG1STATU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG1STATUTracker = false;

    /**
     * field for BSG1FNUM
     */
    protected com.huawei.www.hss.Str1_15 localBSG1FNUM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG1FNUMTracker = false;

    /**
     * field for BSG1TIME
     */
    protected com.huawei.www.hss.Int0_65535 localBSG1TIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG1TIMETracker = false;

    /**
     * field for BSG2
     */
    protected com.huawei.www.hss._EnumType localBSG2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG2Tracker = false;

    /**
     * field for BSG2SS
     */
    protected com.huawei.www.hss._EnumType localBSG2SS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG2SSTracker = false;

    /**
     * field for BSG2STATU
     */
    protected com.huawei.www.hss._EnumType localBSG2STATU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG2STATUTracker = false;

    /**
     * field for BSG2FNUM
     */
    protected com.huawei.www.hss.Str1_15 localBSG2FNUM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG2FNUMTracker = false;

    /**
     * field for BSG2TIME
     */
    protected com.huawei.www.hss.Int0_65535 localBSG2TIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG2TIMETracker = false;

    /**
     * field for BSG3
     */
    protected com.huawei.www.hss._EnumType localBSG3;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG3Tracker = false;

    /**
     * field for BSG3SS
     */
    protected com.huawei.www.hss._EnumType localBSG3SS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG3SSTracker = false;

    /**
     * field for BSG3STATU
     */
    protected com.huawei.www.hss._EnumType localBSG3STATU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG3STATUTracker = false;

    /**
     * field for BSG3FNUM
     */
    protected com.huawei.www.hss.Str1_15 localBSG3FNUM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG3FNUMTracker = false;

    /**
     * field for BSG3TIME
     */
    protected com.huawei.www.hss.Int0_65535 localBSG3TIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG3TIMETracker = false;

    /**
     * field for BSG4
     */
    protected com.huawei.www.hss._EnumType localBSG4;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG4Tracker = false;

    /**
     * field for BSG4SS
     */
    protected com.huawei.www.hss._EnumType localBSG4SS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG4SSTracker = false;

    /**
     * field for BSG4STATU
     */
    protected com.huawei.www.hss._EnumType localBSG4STATU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG4STATUTracker = false;

    /**
     * field for BSG4FNUM
     */
    protected com.huawei.www.hss.Str1_15 localBSG4FNUM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG4FNUMTracker = false;

    /**
     * field for BSG4TIME
     */
    protected com.huawei.www.hss.Int0_65535 localBSG4TIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG4TIMETracker = false;

    /**
     * field for BSG5
     */
    protected com.huawei.www.hss._EnumType localBSG5;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG5Tracker = false;

    /**
     * field for BSG5SS
     */
    protected com.huawei.www.hss._EnumType localBSG5SS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG5SSTracker = false;

    /**
     * field for BSG5STATU
     */
    protected com.huawei.www.hss._EnumType localBSG5STATU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG5STATUTracker = false;

    /**
     * field for BSG5FNUM
     */
    protected com.huawei.www.hss.Str1_15 localBSG5FNUM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG5FNUMTracker = false;

    /**
     * field for BSG5TIME
     */
    protected com.huawei.www.hss.Int0_65535 localBSG5TIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG5TIMETracker = false;

    /**
     * field for BSG6
     */
    protected com.huawei.www.hss._EnumType localBSG6;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG6Tracker = false;

    /**
     * field for BSG6SS
     */
    protected com.huawei.www.hss._EnumType localBSG6SS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG6SSTracker = false;

    /**
     * field for BSG6STATU
     */
    protected com.huawei.www.hss._EnumType localBSG6STATU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG6STATUTracker = false;

    /**
     * field for BSG6FNUM
     */
    protected com.huawei.www.hss.Str1_15 localBSG6FNUM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG6FNUMTracker = false;

    /**
     * field for BSG6TIME
     */
    protected com.huawei.www.hss.Int0_65535 localBSG6TIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSG6TIMETracker = false;

    /**
     * field for VLRNUM
     */
    protected com.huawei.www.hss.Str1_20 localVLRNUM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVLRNUMTracker = false;

    /**
     * field for MSRN
     */
    protected com.huawei.www.hss.Str6_15 localMSRN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMSRNTracker = false;

    /**
     * field for MSCNUM
     */
    protected com.huawei.www.hss.Str6_15 localMSCNUM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMSCNUMTracker = false;

    /**
     * field for LMSID
     */
    protected com.huawei.www.hss.Str1_40 localLMSID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLMSIDTracker = false;

    /**
     * field for MSCRESTRICT
     */
    protected com.huawei.www.hss._EnumType localMSCRESTRICT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMSCRESTRICTTracker = false;

    /**
     * field for VLRRSP
     */
    protected com.huawei.www.hss.Int0_65535 localVLRRSP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVLRRSPTracker = false;

    /**
     * field for SGSNNUM
     */
    protected com.huawei.www.hss.Str1_40 localSGSNNUM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSGSNNUMTracker = false;

    /**
     * field for SGSNRSP
     */
    protected com.huawei.www.hss.Int0_65535 localSGSNRSP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSGSNRSPTracker = false;

    /**
     * field for APNID
     */
    protected com.huawei.www.hss.Int0_65534 localAPNID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAPNIDTracker = false;

    /**
     * field for PDPADD
     */
    protected com.huawei.www.hss.Str1_40 localPDPADD;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPDPADDTracker = false;

    /**
     * field for EQOSID
     */
    protected com.huawei.www.hss.Int0_65535 localEQOSID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEQOSIDTracker = false;

    /**
     * field for VPAA
     */
    protected com.huawei.www.hss._EnumType localVPAA;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVPAATracker = false;

    /**
     * field for PDPCH
     */
    protected com.huawei.www.hss.Str1_15 localPDPCH;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPDPCHTracker = false;

    /**
     * field for PDPTY
     */
    protected com.huawei.www.hss._EnumType localPDPTY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPDPTYTracker = false;

    /**
     * field for PDPID
     */
    protected com.huawei.www.hss.Int0_50 localPDPID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPDPIDTracker = false;

    /**
     * field for TITLE
     */
    protected com.huawei.www.hss._EnumType localTITLE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTITLETracker = false;

    /**
     * field for APNIDS
     */
    protected com.huawei.www.hss.Str1_5 localAPNIDS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAPNIDSTracker = false;

    /**
     * field for QOSIDS
     */
    protected com.huawei.www.hss.Str1_4 localQOSIDS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localQOSIDSTracker = false;

    /**
     * field for PDPS
     */
    protected com.huawei.www.hss.Str1_2 localPDPS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPDPSTracker = false;

    public boolean isIMSISpecified() {
        return localIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getIMSI() {
        return localIMSI;
    }

    /**
     * Auto generated setter method
     * @param param IMSI
     */
    public void setIMSI(com.huawei.www.hss.Str6_15 param) {
        localIMSITracker = param != null;

        this.localIMSI = param;
    }

    public boolean isISDNSpecified() {
        return localISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getISDN() {
        return localISDN;
    }

    /**
     * Auto generated setter method
     * @param param ISDN
     */
    public void setISDN(com.huawei.www.hss.Str1_15 param) {
        localISDNTracker = param != null;

        this.localISDN = param;
    }

    public boolean isSTATESpecified() {
        return localSTATETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSTATE() {
        return localSTATE;
    }

    /**
     * Auto generated setter method
     * @param param STATE
     */
    public void setSTATE(com.huawei.www.hss._EnumType param) {
        localSTATETracker = param != null;

        this.localSTATE = param;
    }

    public boolean isAUTHDSpecified() {
        return localAUTHDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getAUTHD() {
        return localAUTHD;
    }

    /**
     * Auto generated setter method
     * @param param AUTHD
     */
    public void setAUTHD(com.huawei.www.hss._EnumType param) {
        localAUTHDTracker = param != null;

        this.localAUTHD = param;
    }

    public boolean isNAMSpecified() {
        return localNAMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65535
     */
    public com.huawei.www.hss.Int0_65535 getNAM() {
        return localNAM;
    }

    /**
     * Auto generated setter method
     * @param param NAM
     */
    public void setNAM(com.huawei.www.hss.Int0_65535 param) {
        localNAMTracker = param != null;

        this.localNAM = param;
    }

    public boolean isSUDSpecified() {
        return localSUDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_1024
     */
    public com.huawei.www.hss.Str1_1024 getSUD() {
        return localSUD;
    }

    /**
     * Auto generated setter method
     * @param param SUD
     */
    public void setSUD(com.huawei.www.hss.Str1_1024 param) {
        localSUDTracker = param != null;

        this.localSUD = param;
    }

    public boolean isAMSISDNSpecified() {
        return localAMSISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getAMSISDN() {
        return localAMSISDN;
    }

    /**
     * Auto generated setter method
     * @param param AMSISDN
     */
    public void setAMSISDN(com.huawei.www.hss.Str1_15 param) {
        localAMSISDNTracker = param != null;

        this.localAMSISDN = param;
    }

    public boolean isBSSpecified() {
        return localBSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS() {
        return localBS;
    }

    /**
     * Auto generated setter method
     * @param param BS
     */
    public void setBS(com.huawei.www.hss._EnumType param) {
        localBSTracker = param != null;

        this.localBS = param;
    }

    public boolean isBCSpecified() {
        return localBCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getBC() {
        return localBC;
    }

    /**
     * Auto generated setter method
     * @param param BC
     */
    public void setBC(com.huawei.www.hss.Str1_15 param) {
        localBCTracker = param != null;

        this.localBC = param;
    }

    public boolean isBSG1Specified() {
        return localBSG1Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG1() {
        return localBSG1;
    }

    /**
     * Auto generated setter method
     * @param param BSG1
     */
    public void setBSG1(com.huawei.www.hss._EnumType param) {
        localBSG1Tracker = param != null;

        this.localBSG1 = param;
    }

    public boolean isBSG1SSSpecified() {
        return localBSG1SSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG1SS() {
        return localBSG1SS;
    }

    /**
     * Auto generated setter method
     * @param param BSG1SS
     */
    public void setBSG1SS(com.huawei.www.hss._EnumType param) {
        localBSG1SSTracker = param != null;

        this.localBSG1SS = param;
    }

    public boolean isBSG1STATUSpecified() {
        return localBSG1STATUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG1STATU() {
        return localBSG1STATU;
    }

    /**
     * Auto generated setter method
     * @param param BSG1STATU
     */
    public void setBSG1STATU(com.huawei.www.hss._EnumType param) {
        localBSG1STATUTracker = param != null;

        this.localBSG1STATU = param;
    }

    public boolean isBSG1FNUMSpecified() {
        return localBSG1FNUMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getBSG1FNUM() {
        return localBSG1FNUM;
    }

    /**
     * Auto generated setter method
     * @param param BSG1FNUM
     */
    public void setBSG1FNUM(com.huawei.www.hss.Str1_15 param) {
        localBSG1FNUMTracker = param != null;

        this.localBSG1FNUM = param;
    }

    public boolean isBSG1TIMESpecified() {
        return localBSG1TIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65535
     */
    public com.huawei.www.hss.Int0_65535 getBSG1TIME() {
        return localBSG1TIME;
    }

    /**
     * Auto generated setter method
     * @param param BSG1TIME
     */
    public void setBSG1TIME(com.huawei.www.hss.Int0_65535 param) {
        localBSG1TIMETracker = param != null;

        this.localBSG1TIME = param;
    }

    public boolean isBSG2Specified() {
        return localBSG2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG2() {
        return localBSG2;
    }

    /**
     * Auto generated setter method
     * @param param BSG2
     */
    public void setBSG2(com.huawei.www.hss._EnumType param) {
        localBSG2Tracker = param != null;

        this.localBSG2 = param;
    }

    public boolean isBSG2SSSpecified() {
        return localBSG2SSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG2SS() {
        return localBSG2SS;
    }

    /**
     * Auto generated setter method
     * @param param BSG2SS
     */
    public void setBSG2SS(com.huawei.www.hss._EnumType param) {
        localBSG2SSTracker = param != null;

        this.localBSG2SS = param;
    }

    public boolean isBSG2STATUSpecified() {
        return localBSG2STATUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG2STATU() {
        return localBSG2STATU;
    }

    /**
     * Auto generated setter method
     * @param param BSG2STATU
     */
    public void setBSG2STATU(com.huawei.www.hss._EnumType param) {
        localBSG2STATUTracker = param != null;

        this.localBSG2STATU = param;
    }

    public boolean isBSG2FNUMSpecified() {
        return localBSG2FNUMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getBSG2FNUM() {
        return localBSG2FNUM;
    }

    /**
     * Auto generated setter method
     * @param param BSG2FNUM
     */
    public void setBSG2FNUM(com.huawei.www.hss.Str1_15 param) {
        localBSG2FNUMTracker = param != null;

        this.localBSG2FNUM = param;
    }

    public boolean isBSG2TIMESpecified() {
        return localBSG2TIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65535
     */
    public com.huawei.www.hss.Int0_65535 getBSG2TIME() {
        return localBSG2TIME;
    }

    /**
     * Auto generated setter method
     * @param param BSG2TIME
     */
    public void setBSG2TIME(com.huawei.www.hss.Int0_65535 param) {
        localBSG2TIMETracker = param != null;

        this.localBSG2TIME = param;
    }

    public boolean isBSG3Specified() {
        return localBSG3Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG3() {
        return localBSG3;
    }

    /**
     * Auto generated setter method
     * @param param BSG3
     */
    public void setBSG3(com.huawei.www.hss._EnumType param) {
        localBSG3Tracker = param != null;

        this.localBSG3 = param;
    }

    public boolean isBSG3SSSpecified() {
        return localBSG3SSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG3SS() {
        return localBSG3SS;
    }

    /**
     * Auto generated setter method
     * @param param BSG3SS
     */
    public void setBSG3SS(com.huawei.www.hss._EnumType param) {
        localBSG3SSTracker = param != null;

        this.localBSG3SS = param;
    }

    public boolean isBSG3STATUSpecified() {
        return localBSG3STATUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG3STATU() {
        return localBSG3STATU;
    }

    /**
     * Auto generated setter method
     * @param param BSG3STATU
     */
    public void setBSG3STATU(com.huawei.www.hss._EnumType param) {
        localBSG3STATUTracker = param != null;

        this.localBSG3STATU = param;
    }

    public boolean isBSG3FNUMSpecified() {
        return localBSG3FNUMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getBSG3FNUM() {
        return localBSG3FNUM;
    }

    /**
     * Auto generated setter method
     * @param param BSG3FNUM
     */
    public void setBSG3FNUM(com.huawei.www.hss.Str1_15 param) {
        localBSG3FNUMTracker = param != null;

        this.localBSG3FNUM = param;
    }

    public boolean isBSG3TIMESpecified() {
        return localBSG3TIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65535
     */
    public com.huawei.www.hss.Int0_65535 getBSG3TIME() {
        return localBSG3TIME;
    }

    /**
     * Auto generated setter method
     * @param param BSG3TIME
     */
    public void setBSG3TIME(com.huawei.www.hss.Int0_65535 param) {
        localBSG3TIMETracker = param != null;

        this.localBSG3TIME = param;
    }

    public boolean isBSG4Specified() {
        return localBSG4Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG4() {
        return localBSG4;
    }

    /**
     * Auto generated setter method
     * @param param BSG4
     */
    public void setBSG4(com.huawei.www.hss._EnumType param) {
        localBSG4Tracker = param != null;

        this.localBSG4 = param;
    }

    public boolean isBSG4SSSpecified() {
        return localBSG4SSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG4SS() {
        return localBSG4SS;
    }

    /**
     * Auto generated setter method
     * @param param BSG4SS
     */
    public void setBSG4SS(com.huawei.www.hss._EnumType param) {
        localBSG4SSTracker = param != null;

        this.localBSG4SS = param;
    }

    public boolean isBSG4STATUSpecified() {
        return localBSG4STATUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG4STATU() {
        return localBSG4STATU;
    }

    /**
     * Auto generated setter method
     * @param param BSG4STATU
     */
    public void setBSG4STATU(com.huawei.www.hss._EnumType param) {
        localBSG4STATUTracker = param != null;

        this.localBSG4STATU = param;
    }

    public boolean isBSG4FNUMSpecified() {
        return localBSG4FNUMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getBSG4FNUM() {
        return localBSG4FNUM;
    }

    /**
     * Auto generated setter method
     * @param param BSG4FNUM
     */
    public void setBSG4FNUM(com.huawei.www.hss.Str1_15 param) {
        localBSG4FNUMTracker = param != null;

        this.localBSG4FNUM = param;
    }

    public boolean isBSG4TIMESpecified() {
        return localBSG4TIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65535
     */
    public com.huawei.www.hss.Int0_65535 getBSG4TIME() {
        return localBSG4TIME;
    }

    /**
     * Auto generated setter method
     * @param param BSG4TIME
     */
    public void setBSG4TIME(com.huawei.www.hss.Int0_65535 param) {
        localBSG4TIMETracker = param != null;

        this.localBSG4TIME = param;
    }

    public boolean isBSG5Specified() {
        return localBSG5Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG5() {
        return localBSG5;
    }

    /**
     * Auto generated setter method
     * @param param BSG5
     */
    public void setBSG5(com.huawei.www.hss._EnumType param) {
        localBSG5Tracker = param != null;

        this.localBSG5 = param;
    }

    public boolean isBSG5SSSpecified() {
        return localBSG5SSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG5SS() {
        return localBSG5SS;
    }

    /**
     * Auto generated setter method
     * @param param BSG5SS
     */
    public void setBSG5SS(com.huawei.www.hss._EnumType param) {
        localBSG5SSTracker = param != null;

        this.localBSG5SS = param;
    }

    public boolean isBSG5STATUSpecified() {
        return localBSG5STATUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG5STATU() {
        return localBSG5STATU;
    }

    /**
     * Auto generated setter method
     * @param param BSG5STATU
     */
    public void setBSG5STATU(com.huawei.www.hss._EnumType param) {
        localBSG5STATUTracker = param != null;

        this.localBSG5STATU = param;
    }

    public boolean isBSG5FNUMSpecified() {
        return localBSG5FNUMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getBSG5FNUM() {
        return localBSG5FNUM;
    }

    /**
     * Auto generated setter method
     * @param param BSG5FNUM
     */
    public void setBSG5FNUM(com.huawei.www.hss.Str1_15 param) {
        localBSG5FNUMTracker = param != null;

        this.localBSG5FNUM = param;
    }

    public boolean isBSG5TIMESpecified() {
        return localBSG5TIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65535
     */
    public com.huawei.www.hss.Int0_65535 getBSG5TIME() {
        return localBSG5TIME;
    }

    /**
     * Auto generated setter method
     * @param param BSG5TIME
     */
    public void setBSG5TIME(com.huawei.www.hss.Int0_65535 param) {
        localBSG5TIMETracker = param != null;

        this.localBSG5TIME = param;
    }

    public boolean isBSG6Specified() {
        return localBSG6Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG6() {
        return localBSG6;
    }

    /**
     * Auto generated setter method
     * @param param BSG6
     */
    public void setBSG6(com.huawei.www.hss._EnumType param) {
        localBSG6Tracker = param != null;

        this.localBSG6 = param;
    }

    public boolean isBSG6SSSpecified() {
        return localBSG6SSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG6SS() {
        return localBSG6SS;
    }

    /**
     * Auto generated setter method
     * @param param BSG6SS
     */
    public void setBSG6SS(com.huawei.www.hss._EnumType param) {
        localBSG6SSTracker = param != null;

        this.localBSG6SS = param;
    }

    public boolean isBSG6STATUSpecified() {
        return localBSG6STATUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBSG6STATU() {
        return localBSG6STATU;
    }

    /**
     * Auto generated setter method
     * @param param BSG6STATU
     */
    public void setBSG6STATU(com.huawei.www.hss._EnumType param) {
        localBSG6STATUTracker = param != null;

        this.localBSG6STATU = param;
    }

    public boolean isBSG6FNUMSpecified() {
        return localBSG6FNUMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getBSG6FNUM() {
        return localBSG6FNUM;
    }

    /**
     * Auto generated setter method
     * @param param BSG6FNUM
     */
    public void setBSG6FNUM(com.huawei.www.hss.Str1_15 param) {
        localBSG6FNUMTracker = param != null;

        this.localBSG6FNUM = param;
    }

    public boolean isBSG6TIMESpecified() {
        return localBSG6TIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65535
     */
    public com.huawei.www.hss.Int0_65535 getBSG6TIME() {
        return localBSG6TIME;
    }

    /**
     * Auto generated setter method
     * @param param BSG6TIME
     */
    public void setBSG6TIME(com.huawei.www.hss.Int0_65535 param) {
        localBSG6TIMETracker = param != null;

        this.localBSG6TIME = param;
    }

    public boolean isVLRNUMSpecified() {
        return localVLRNUMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_20
     */
    public com.huawei.www.hss.Str1_20 getVLRNUM() {
        return localVLRNUM;
    }

    /**
     * Auto generated setter method
     * @param param VLRNUM
     */
    public void setVLRNUM(com.huawei.www.hss.Str1_20 param) {
        localVLRNUMTracker = param != null;

        this.localVLRNUM = param;
    }

    public boolean isMSRNSpecified() {
        return localMSRNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getMSRN() {
        return localMSRN;
    }

    /**
     * Auto generated setter method
     * @param param MSRN
     */
    public void setMSRN(com.huawei.www.hss.Str6_15 param) {
        localMSRNTracker = param != null;

        this.localMSRN = param;
    }

    public boolean isMSCNUMSpecified() {
        return localMSCNUMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getMSCNUM() {
        return localMSCNUM;
    }

    /**
     * Auto generated setter method
     * @param param MSCNUM
     */
    public void setMSCNUM(com.huawei.www.hss.Str6_15 param) {
        localMSCNUMTracker = param != null;

        this.localMSCNUM = param;
    }

    public boolean isLMSIDSpecified() {
        return localLMSIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_40
     */
    public com.huawei.www.hss.Str1_40 getLMSID() {
        return localLMSID;
    }

    /**
     * Auto generated setter method
     * @param param LMSID
     */
    public void setLMSID(com.huawei.www.hss.Str1_40 param) {
        localLMSIDTracker = param != null;

        this.localLMSID = param;
    }

    public boolean isMSCRESTRICTSpecified() {
        return localMSCRESTRICTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMSCRESTRICT() {
        return localMSCRESTRICT;
    }

    /**
     * Auto generated setter method
     * @param param MSCRESTRICT
     */
    public void setMSCRESTRICT(com.huawei.www.hss._EnumType param) {
        localMSCRESTRICTTracker = param != null;

        this.localMSCRESTRICT = param;
    }

    public boolean isVLRRSPSpecified() {
        return localVLRRSPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65535
     */
    public com.huawei.www.hss.Int0_65535 getVLRRSP() {
        return localVLRRSP;
    }

    /**
     * Auto generated setter method
     * @param param VLRRSP
     */
    public void setVLRRSP(com.huawei.www.hss.Int0_65535 param) {
        localVLRRSPTracker = param != null;

        this.localVLRRSP = param;
    }

    public boolean isSGSNNUMSpecified() {
        return localSGSNNUMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_40
     */
    public com.huawei.www.hss.Str1_40 getSGSNNUM() {
        return localSGSNNUM;
    }

    /**
     * Auto generated setter method
     * @param param SGSNNUM
     */
    public void setSGSNNUM(com.huawei.www.hss.Str1_40 param) {
        localSGSNNUMTracker = param != null;

        this.localSGSNNUM = param;
    }

    public boolean isSGSNRSPSpecified() {
        return localSGSNRSPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65535
     */
    public com.huawei.www.hss.Int0_65535 getSGSNRSP() {
        return localSGSNRSP;
    }

    /**
     * Auto generated setter method
     * @param param SGSNRSP
     */
    public void setSGSNRSP(com.huawei.www.hss.Int0_65535 param) {
        localSGSNRSPTracker = param != null;

        this.localSGSNRSP = param;
    }

    public boolean isAPNIDSpecified() {
        return localAPNIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getAPNID() {
        return localAPNID;
    }

    /**
     * Auto generated setter method
     * @param param APNID
     */
    public void setAPNID(com.huawei.www.hss.Int0_65534 param) {
        localAPNIDTracker = param != null;

        this.localAPNID = param;
    }

    public boolean isPDPADDSpecified() {
        return localPDPADDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_40
     */
    public com.huawei.www.hss.Str1_40 getPDPADD() {
        return localPDPADD;
    }

    /**
     * Auto generated setter method
     * @param param PDPADD
     */
    public void setPDPADD(com.huawei.www.hss.Str1_40 param) {
        localPDPADDTracker = param != null;

        this.localPDPADD = param;
    }

    public boolean isEQOSIDSpecified() {
        return localEQOSIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65535
     */
    public com.huawei.www.hss.Int0_65535 getEQOSID() {
        return localEQOSID;
    }

    /**
     * Auto generated setter method
     * @param param EQOSID
     */
    public void setEQOSID(com.huawei.www.hss.Int0_65535 param) {
        localEQOSIDTracker = param != null;

        this.localEQOSID = param;
    }

    public boolean isVPAASpecified() {
        return localVPAATracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVPAA() {
        return localVPAA;
    }

    /**
     * Auto generated setter method
     * @param param VPAA
     */
    public void setVPAA(com.huawei.www.hss._EnumType param) {
        localVPAATracker = param != null;

        this.localVPAA = param;
    }

    public boolean isPDPCHSpecified() {
        return localPDPCHTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getPDPCH() {
        return localPDPCH;
    }

    /**
     * Auto generated setter method
     * @param param PDPCH
     */
    public void setPDPCH(com.huawei.www.hss.Str1_15 param) {
        localPDPCHTracker = param != null;

        this.localPDPCH = param;
    }

    public boolean isPDPTYSpecified() {
        return localPDPTYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPDPTY() {
        return localPDPTY;
    }

    /**
     * Auto generated setter method
     * @param param PDPTY
     */
    public void setPDPTY(com.huawei.www.hss._EnumType param) {
        localPDPTYTracker = param != null;

        this.localPDPTY = param;
    }

    public boolean isPDPIDSpecified() {
        return localPDPIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_50
     */
    public com.huawei.www.hss.Int0_50 getPDPID() {
        return localPDPID;
    }

    /**
     * Auto generated setter method
     * @param param PDPID
     */
    public void setPDPID(com.huawei.www.hss.Int0_50 param) {
        localPDPIDTracker = param != null;

        this.localPDPID = param;
    }

    public boolean isTITLESpecified() {
        return localTITLETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTITLE() {
        return localTITLE;
    }

    /**
     * Auto generated setter method
     * @param param TITLE
     */
    public void setTITLE(com.huawei.www.hss._EnumType param) {
        localTITLETracker = param != null;

        this.localTITLE = param;
    }

    public boolean isAPNIDSSpecified() {
        return localAPNIDSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_5
     */
    public com.huawei.www.hss.Str1_5 getAPNIDS() {
        return localAPNIDS;
    }

    /**
     * Auto generated setter method
     * @param param APNIDS
     */
    public void setAPNIDS(com.huawei.www.hss.Str1_5 param) {
        localAPNIDSTracker = param != null;

        this.localAPNIDS = param;
    }

    public boolean isQOSIDSSpecified() {
        return localQOSIDSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_4
     */
    public com.huawei.www.hss.Str1_4 getQOSIDS() {
        return localQOSIDS;
    }

    /**
     * Auto generated setter method
     * @param param QOSIDS
     */
    public void setQOSIDS(com.huawei.www.hss.Str1_4 param) {
        localQOSIDSTracker = param != null;

        this.localQOSIDS = param;
    }

    public boolean isPDPSSpecified() {
        return localPDPSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_2
     */
    public com.huawei.www.hss.Str1_2 getPDPS() {
        return localPDPS;
    }

    /**
     * Auto generated setter method
     * @param param PDPS
     */
    public void setPDPS(com.huawei.www.hss.Str1_2 param) {
        localPDPSTracker = param != null;

        this.localPDPS = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":LST_ESUBStruct1", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "LST_ESUBStruct1", xmlWriter);
            }
        }

        if (localIMSITracker) {
            if (localIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMSI cannot be null!!");
            }

            localIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMSI"), xmlWriter);
        }

        if (localISDNTracker) {
            if (localISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ISDN cannot be null!!");
            }

            localISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ISDN"), xmlWriter);
        }

        if (localSTATETracker) {
            if (localSTATE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "STATE cannot be null!!");
            }

            localSTATE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "STATE"), xmlWriter);
        }

        if (localAUTHDTracker) {
            if (localAUTHD == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AUTHD cannot be null!!");
            }

            localAUTHD.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AUTHD"), xmlWriter);
        }

        if (localNAMTracker) {
            if (localNAM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "NAM cannot be null!!");
            }

            localNAM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "NAM"), xmlWriter);
        }

        if (localSUDTracker) {
            if (localSUD == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SUD cannot be null!!");
            }

            localSUD.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SUD"), xmlWriter);
        }

        if (localAMSISDNTracker) {
            if (localAMSISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AMSISDN cannot be null!!");
            }

            localAMSISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AMSISDN"), xmlWriter);
        }

        if (localBSTracker) {
            if (localBS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS cannot be null!!");
            }

            localBS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS"), xmlWriter);
        }

        if (localBCTracker) {
            if (localBC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BC cannot be null!!");
            }

            localBC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BC"), xmlWriter);
        }

        if (localBSG1Tracker) {
            if (localBSG1 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG1 cannot be null!!");
            }

            localBSG1.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG1"), xmlWriter);
        }

        if (localBSG1SSTracker) {
            if (localBSG1SS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG1SS cannot be null!!");
            }

            localBSG1SS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG1SS"), xmlWriter);
        }

        if (localBSG1STATUTracker) {
            if (localBSG1STATU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG1STATU cannot be null!!");
            }

            localBSG1STATU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG1STATU"), xmlWriter);
        }

        if (localBSG1FNUMTracker) {
            if (localBSG1FNUM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG1FNUM cannot be null!!");
            }

            localBSG1FNUM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG1FNUM"), xmlWriter);
        }

        if (localBSG1TIMETracker) {
            if (localBSG1TIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG1TIME cannot be null!!");
            }

            localBSG1TIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG1TIME"), xmlWriter);
        }

        if (localBSG2Tracker) {
            if (localBSG2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG2 cannot be null!!");
            }

            localBSG2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG2"), xmlWriter);
        }

        if (localBSG2SSTracker) {
            if (localBSG2SS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG2SS cannot be null!!");
            }

            localBSG2SS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG2SS"), xmlWriter);
        }

        if (localBSG2STATUTracker) {
            if (localBSG2STATU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG2STATU cannot be null!!");
            }

            localBSG2STATU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG2STATU"), xmlWriter);
        }

        if (localBSG2FNUMTracker) {
            if (localBSG2FNUM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG2FNUM cannot be null!!");
            }

            localBSG2FNUM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG2FNUM"), xmlWriter);
        }

        if (localBSG2TIMETracker) {
            if (localBSG2TIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG2TIME cannot be null!!");
            }

            localBSG2TIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG2TIME"), xmlWriter);
        }

        if (localBSG3Tracker) {
            if (localBSG3 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG3 cannot be null!!");
            }

            localBSG3.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG3"), xmlWriter);
        }

        if (localBSG3SSTracker) {
            if (localBSG3SS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG3SS cannot be null!!");
            }

            localBSG3SS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG3SS"), xmlWriter);
        }

        if (localBSG3STATUTracker) {
            if (localBSG3STATU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG3STATU cannot be null!!");
            }

            localBSG3STATU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG3STATU"), xmlWriter);
        }

        if (localBSG3FNUMTracker) {
            if (localBSG3FNUM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG3FNUM cannot be null!!");
            }

            localBSG3FNUM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG3FNUM"), xmlWriter);
        }

        if (localBSG3TIMETracker) {
            if (localBSG3TIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG3TIME cannot be null!!");
            }

            localBSG3TIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG3TIME"), xmlWriter);
        }

        if (localBSG4Tracker) {
            if (localBSG4 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG4 cannot be null!!");
            }

            localBSG4.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG4"), xmlWriter);
        }

        if (localBSG4SSTracker) {
            if (localBSG4SS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG4SS cannot be null!!");
            }

            localBSG4SS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG4SS"), xmlWriter);
        }

        if (localBSG4STATUTracker) {
            if (localBSG4STATU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG4STATU cannot be null!!");
            }

            localBSG4STATU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG4STATU"), xmlWriter);
        }

        if (localBSG4FNUMTracker) {
            if (localBSG4FNUM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG4FNUM cannot be null!!");
            }

            localBSG4FNUM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG4FNUM"), xmlWriter);
        }

        if (localBSG4TIMETracker) {
            if (localBSG4TIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG4TIME cannot be null!!");
            }

            localBSG4TIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG4TIME"), xmlWriter);
        }

        if (localBSG5Tracker) {
            if (localBSG5 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG5 cannot be null!!");
            }

            localBSG5.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG5"), xmlWriter);
        }

        if (localBSG5SSTracker) {
            if (localBSG5SS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG5SS cannot be null!!");
            }

            localBSG5SS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG5SS"), xmlWriter);
        }

        if (localBSG5STATUTracker) {
            if (localBSG5STATU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG5STATU cannot be null!!");
            }

            localBSG5STATU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG5STATU"), xmlWriter);
        }

        if (localBSG5FNUMTracker) {
            if (localBSG5FNUM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG5FNUM cannot be null!!");
            }

            localBSG5FNUM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG5FNUM"), xmlWriter);
        }

        if (localBSG5TIMETracker) {
            if (localBSG5TIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG5TIME cannot be null!!");
            }

            localBSG5TIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG5TIME"), xmlWriter);
        }

        if (localBSG6Tracker) {
            if (localBSG6 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG6 cannot be null!!");
            }

            localBSG6.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG6"), xmlWriter);
        }

        if (localBSG6SSTracker) {
            if (localBSG6SS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG6SS cannot be null!!");
            }

            localBSG6SS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG6SS"), xmlWriter);
        }

        if (localBSG6STATUTracker) {
            if (localBSG6STATU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG6STATU cannot be null!!");
            }

            localBSG6STATU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG6STATU"), xmlWriter);
        }

        if (localBSG6FNUMTracker) {
            if (localBSG6FNUM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG6FNUM cannot be null!!");
            }

            localBSG6FNUM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG6FNUM"), xmlWriter);
        }

        if (localBSG6TIMETracker) {
            if (localBSG6TIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSG6TIME cannot be null!!");
            }

            localBSG6TIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSG6TIME"), xmlWriter);
        }

        if (localVLRNUMTracker) {
            if (localVLRNUM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VLRNUM cannot be null!!");
            }

            localVLRNUM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VLRNUM"), xmlWriter);
        }

        if (localMSRNTracker) {
            if (localMSRN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MSRN cannot be null!!");
            }

            localMSRN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MSRN"), xmlWriter);
        }

        if (localMSCNUMTracker) {
            if (localMSCNUM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MSCNUM cannot be null!!");
            }

            localMSCNUM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MSCNUM"), xmlWriter);
        }

        if (localLMSIDTracker) {
            if (localLMSID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LMSID cannot be null!!");
            }

            localLMSID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LMSID"), xmlWriter);
        }

        if (localMSCRESTRICTTracker) {
            if (localMSCRESTRICT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MSCRESTRICT cannot be null!!");
            }

            localMSCRESTRICT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MSCRESTRICT"), xmlWriter);
        }

        if (localVLRRSPTracker) {
            if (localVLRRSP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VLRRSP cannot be null!!");
            }

            localVLRRSP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VLRRSP"), xmlWriter);
        }

        if (localSGSNNUMTracker) {
            if (localSGSNNUM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SGSNNUM cannot be null!!");
            }

            localSGSNNUM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SGSNNUM"), xmlWriter);
        }

        if (localSGSNRSPTracker) {
            if (localSGSNRSP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SGSNRSP cannot be null!!");
            }

            localSGSNRSP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SGSNRSP"), xmlWriter);
        }

        if (localAPNIDTracker) {
            if (localAPNID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "APNID cannot be null!!");
            }

            localAPNID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "APNID"), xmlWriter);
        }

        if (localPDPADDTracker) {
            if (localPDPADD == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PDPADD cannot be null!!");
            }

            localPDPADD.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PDPADD"), xmlWriter);
        }

        if (localEQOSIDTracker) {
            if (localEQOSID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EQOSID cannot be null!!");
            }

            localEQOSID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EQOSID"), xmlWriter);
        }

        if (localVPAATracker) {
            if (localVPAA == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VPAA cannot be null!!");
            }

            localVPAA.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VPAA"), xmlWriter);
        }

        if (localPDPCHTracker) {
            if (localPDPCH == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PDPCH cannot be null!!");
            }

            localPDPCH.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PDPCH"), xmlWriter);
        }

        if (localPDPTYTracker) {
            if (localPDPTY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PDPTY cannot be null!!");
            }

            localPDPTY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PDPTY"), xmlWriter);
        }

        if (localPDPIDTracker) {
            if (localPDPID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PDPID cannot be null!!");
            }

            localPDPID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PDPID"), xmlWriter);
        }

        if (localTITLETracker) {
            if (localTITLE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TITLE cannot be null!!");
            }

            localTITLE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TITLE"), xmlWriter);
        }

        if (localAPNIDSTracker) {
            if (localAPNIDS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "APNIDS cannot be null!!");
            }

            localAPNIDS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "APNIDS"), xmlWriter);
        }

        if (localQOSIDSTracker) {
            if (localQOSIDS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "QOSIDS cannot be null!!");
            }

            localQOSIDS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "QOSIDS"), xmlWriter);
        }

        if (localPDPSTracker) {
            if (localPDPS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PDPS cannot be null!!");
            }

            localPDPS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PDPS"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static LST_ESUBStruct1 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            LST_ESUBStruct1 object = new LST_ESUBStruct1();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"LST_ESUBStruct1".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (LST_ESUBStruct1) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSI").equals(
                            reader.getName())) {
                    object.setIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ISDN").equals(
                            reader.getName())) {
                    object.setISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "STATE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "STATE").equals(
                            reader.getName())) {
                    object.setSTATE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AUTHD").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AUTHD").equals(
                            reader.getName())) {
                    object.setAUTHD(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "NAM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "NAM").equals(
                            reader.getName())) {
                    object.setNAM(com.huawei.www.hss.Int0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SUD").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SUD").equals(
                            reader.getName())) {
                    object.setSUD(com.huawei.www.hss.Str1_1024.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AMSISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AMSISDN").equals(
                            reader.getName())) {
                    object.setAMSISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS").equals(
                            reader.getName())) {
                    object.setBS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BC").equals(
                            reader.getName())) {
                    object.setBC(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG1").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG1").equals(
                            reader.getName())) {
                    object.setBSG1(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG1SS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG1SS").equals(
                            reader.getName())) {
                    object.setBSG1SS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG1STATU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG1STATU").equals(
                            reader.getName())) {
                    object.setBSG1STATU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG1FNUM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG1FNUM").equals(
                            reader.getName())) {
                    object.setBSG1FNUM(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG1TIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG1TIME").equals(
                            reader.getName())) {
                    object.setBSG1TIME(com.huawei.www.hss.Int0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG2").equals(
                            reader.getName())) {
                    object.setBSG2(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG2SS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG2SS").equals(
                            reader.getName())) {
                    object.setBSG2SS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG2STATU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG2STATU").equals(
                            reader.getName())) {
                    object.setBSG2STATU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG2FNUM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG2FNUM").equals(
                            reader.getName())) {
                    object.setBSG2FNUM(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG2TIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG2TIME").equals(
                            reader.getName())) {
                    object.setBSG2TIME(com.huawei.www.hss.Int0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG3").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG3").equals(
                            reader.getName())) {
                    object.setBSG3(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG3SS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG3SS").equals(
                            reader.getName())) {
                    object.setBSG3SS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG3STATU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG3STATU").equals(
                            reader.getName())) {
                    object.setBSG3STATU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG3FNUM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG3FNUM").equals(
                            reader.getName())) {
                    object.setBSG3FNUM(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG3TIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG3TIME").equals(
                            reader.getName())) {
                    object.setBSG3TIME(com.huawei.www.hss.Int0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG4").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG4").equals(
                            reader.getName())) {
                    object.setBSG4(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG4SS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG4SS").equals(
                            reader.getName())) {
                    object.setBSG4SS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG4STATU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG4STATU").equals(
                            reader.getName())) {
                    object.setBSG4STATU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG4FNUM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG4FNUM").equals(
                            reader.getName())) {
                    object.setBSG4FNUM(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG4TIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG4TIME").equals(
                            reader.getName())) {
                    object.setBSG4TIME(com.huawei.www.hss.Int0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG5").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG5").equals(
                            reader.getName())) {
                    object.setBSG5(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG5SS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG5SS").equals(
                            reader.getName())) {
                    object.setBSG5SS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG5STATU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG5STATU").equals(
                            reader.getName())) {
                    object.setBSG5STATU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG5FNUM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG5FNUM").equals(
                            reader.getName())) {
                    object.setBSG5FNUM(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG5TIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG5TIME").equals(
                            reader.getName())) {
                    object.setBSG5TIME(com.huawei.www.hss.Int0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG6").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG6").equals(
                            reader.getName())) {
                    object.setBSG6(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG6SS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG6SS").equals(
                            reader.getName())) {
                    object.setBSG6SS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG6STATU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG6STATU").equals(
                            reader.getName())) {
                    object.setBSG6STATU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG6FNUM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG6FNUM").equals(
                            reader.getName())) {
                    object.setBSG6FNUM(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSG6TIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSG6TIME").equals(
                            reader.getName())) {
                    object.setBSG6TIME(com.huawei.www.hss.Int0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VLRNUM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VLRNUM").equals(
                            reader.getName())) {
                    object.setVLRNUM(com.huawei.www.hss.Str1_20.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MSRN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MSRN").equals(
                            reader.getName())) {
                    object.setMSRN(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MSCNUM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MSCNUM").equals(
                            reader.getName())) {
                    object.setMSCNUM(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LMSID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LMSID").equals(
                            reader.getName())) {
                    object.setLMSID(com.huawei.www.hss.Str1_40.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MSCRESTRICT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MSCRESTRICT").equals(
                            reader.getName())) {
                    object.setMSCRESTRICT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VLRRSP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VLRRSP").equals(
                            reader.getName())) {
                    object.setVLRRSP(com.huawei.www.hss.Int0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SGSNNUM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SGSNNUM").equals(
                            reader.getName())) {
                    object.setSGSNNUM(com.huawei.www.hss.Str1_40.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SGSNRSP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SGSNRSP").equals(
                            reader.getName())) {
                    object.setSGSNRSP(com.huawei.www.hss.Int0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "APNID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "APNID").equals(
                            reader.getName())) {
                    object.setAPNID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PDPADD").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PDPADD").equals(
                            reader.getName())) {
                    object.setPDPADD(com.huawei.www.hss.Str1_40.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EQOSID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EQOSID").equals(
                            reader.getName())) {
                    object.setEQOSID(com.huawei.www.hss.Int0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VPAA").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VPAA").equals(
                            reader.getName())) {
                    object.setVPAA(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PDPCH").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PDPCH").equals(
                            reader.getName())) {
                    object.setPDPCH(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PDPTY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PDPTY").equals(
                            reader.getName())) {
                    object.setPDPTY(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PDPID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PDPID").equals(
                            reader.getName())) {
                    object.setPDPID(com.huawei.www.hss.Int0_50.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TITLE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TITLE").equals(
                            reader.getName())) {
                    object.setTITLE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "APNIDS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "APNIDS").equals(
                            reader.getName())) {
                    object.setAPNIDS(com.huawei.www.hss.Str1_5.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "QOSIDS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "QOSIDS").equals(
                            reader.getName())) {
                    object.setQOSIDS(com.huawei.www.hss.Str1_4.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PDPS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PDPS").equals(
                            reader.getName())) {
                    object.setPDPS(com.huawei.www.hss.Str1_2.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
