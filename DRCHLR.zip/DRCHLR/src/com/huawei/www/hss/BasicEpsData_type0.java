/**
 * BasicEpsData_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  BasicEpsData_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class BasicEpsData_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = BasicEpsData_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for APNOI
     */
    protected com.huawei.www.hss.Str1_127 localAPNOI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAPNOITracker = false;

    /**
     * field for AMBRMAXUL
     */
    protected com.huawei.www.hss.Int0_4294967295 localAMBRMAXUL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAMBRMAXULTracker = false;

    /**
     * field for AMBRMAXDL
     */
    protected com.huawei.www.hss.Int0_4294967295 localAMBRMAXDL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAMBRMAXDLTracker = false;

    /**
     * field for RATFREQSELPRIID
     */
    protected com.huawei.www.hss.Int0_65534 localRATFREQSELPRIID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRATFREQSELPRIIDTracker = false;

    /**
     * field for PlmnTplId
     */
    protected com.huawei.www.hss.Int0_65534 localPlmnTplId;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPlmnTplIdTracker = false;

    /**
     * field for DiamNodeTplId
     */
    protected com.huawei.www.hss.Int0_65534 localDiamNodeTplId;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDiamNodeTplIdTracker = false;

    /**
     * field for EGR
     */
    protected com.huawei.www.hss._EnumType localEGR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEGRTracker = false;

    /**
     * field for EgrHlrsn
     */
    protected com.huawei.www.hss.Int0_255 localEgrHlrsn;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEgrHlrsnTracker = false;

    /**
     * field for LtvAutoProv
     */
    protected com.huawei.www.hss._EnumType localLtvAutoProv;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLtvAutoProvTracker = false;

    /**
     * field for MPS
     */
    protected com.huawei.www.hss._EnumType localMPS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMPSTracker = false;

    /**
     * field for ICSIND
     */
    protected com.huawei.www.hss._EnumType localICSIND;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localICSINDTracker = false;

    /**
     * field for ANCHOR
     */
    protected com.huawei.www.hss._EnumType localANCHOR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localANCHORTracker = false;

    /**
     * field for VolteTag
     */
    protected com.huawei.www.hss._EnumType localVolteTag;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVolteTagTracker = false;

    /**
     * field for TAUTIMER
     */
    protected com.huawei.www.hss.Int0_65534 localTAUTIMER;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTAUTIMERTracker = false;

    /**
     * field for RelayNode
     */
    protected com.huawei.www.hss._EnumType localRelayNode;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRelayNodeTracker = false;

    /**
     * field for EpsOdbPos
     */
    protected com.huawei.www.hss._EnumType localEpsOdbPos;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsOdbPosTracker = false;

    /**
     * field for STNSR
     */
    protected com.huawei.www.hss.Str1_15 localSTNSR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSTNSRTracker = false;

    /**
     * field for AnchorTcsiTplId
     */
    protected com.huawei.www.hss.Int0_65534 localAnchorTcsiTplId;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAnchorTcsiTplIdTracker = false;

    public boolean isAPNOISpecified() {
        return localAPNOITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_127
     */
    public com.huawei.www.hss.Str1_127 getAPNOI() {
        return localAPNOI;
    }

    /**
     * Auto generated setter method
     * @param param APNOI
     */
    public void setAPNOI(com.huawei.www.hss.Str1_127 param) {
        localAPNOITracker = param != null;

        this.localAPNOI = param;
    }

    public boolean isAMBRMAXULSpecified() {
        return localAMBRMAXULTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_4294967295
     */
    public com.huawei.www.hss.Int0_4294967295 getAMBRMAXUL() {
        return localAMBRMAXUL;
    }

    /**
     * Auto generated setter method
     * @param param AMBRMAXUL
     */
    public void setAMBRMAXUL(com.huawei.www.hss.Int0_4294967295 param) {
        localAMBRMAXULTracker = param != null;

        this.localAMBRMAXUL = param;
    }

    public boolean isAMBRMAXDLSpecified() {
        return localAMBRMAXDLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_4294967295
     */
    public com.huawei.www.hss.Int0_4294967295 getAMBRMAXDL() {
        return localAMBRMAXDL;
    }

    /**
     * Auto generated setter method
     * @param param AMBRMAXDL
     */
    public void setAMBRMAXDL(com.huawei.www.hss.Int0_4294967295 param) {
        localAMBRMAXDLTracker = param != null;

        this.localAMBRMAXDL = param;
    }

    public boolean isRATFREQSELPRIIDSpecified() {
        return localRATFREQSELPRIIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getRATFREQSELPRIID() {
        return localRATFREQSELPRIID;
    }

    /**
     * Auto generated setter method
     * @param param RATFREQSELPRIID
     */
    public void setRATFREQSELPRIID(com.huawei.www.hss.Int0_65534 param) {
        localRATFREQSELPRIIDTracker = param != null;

        this.localRATFREQSELPRIID = param;
    }

    public boolean isPlmnTplIdSpecified() {
        return localPlmnTplIdTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getPlmnTplId() {
        return localPlmnTplId;
    }

    /**
     * Auto generated setter method
     * @param param PlmnTplId
     */
    public void setPlmnTplId(com.huawei.www.hss.Int0_65534 param) {
        localPlmnTplIdTracker = param != null;

        this.localPlmnTplId = param;
    }

    public boolean isDiamNodeTplIdSpecified() {
        return localDiamNodeTplIdTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getDiamNodeTplId() {
        return localDiamNodeTplId;
    }

    /**
     * Auto generated setter method
     * @param param DiamNodeTplId
     */
    public void setDiamNodeTplId(com.huawei.www.hss.Int0_65534 param) {
        localDiamNodeTplIdTracker = param != null;

        this.localDiamNodeTplId = param;
    }

    public boolean isEGRSpecified() {
        return localEGRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEGR() {
        return localEGR;
    }

    /**
     * Auto generated setter method
     * @param param EGR
     */
    public void setEGR(com.huawei.www.hss._EnumType param) {
        localEGRTracker = param != null;

        this.localEGR = param;
    }

    public boolean isEgrHlrsnSpecified() {
        return localEgrHlrsnTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_255
     */
    public com.huawei.www.hss.Int0_255 getEgrHlrsn() {
        return localEgrHlrsn;
    }

    /**
     * Auto generated setter method
     * @param param EgrHlrsn
     */
    public void setEgrHlrsn(com.huawei.www.hss.Int0_255 param) {
        localEgrHlrsnTracker = param != null;

        this.localEgrHlrsn = param;
    }

    public boolean isLtvAutoProvSpecified() {
        return localLtvAutoProvTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getLtvAutoProv() {
        return localLtvAutoProv;
    }

    /**
     * Auto generated setter method
     * @param param LtvAutoProv
     */
    public void setLtvAutoProv(com.huawei.www.hss._EnumType param) {
        localLtvAutoProvTracker = param != null;

        this.localLtvAutoProv = param;
    }

    public boolean isMPSSpecified() {
        return localMPSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMPS() {
        return localMPS;
    }

    /**
     * Auto generated setter method
     * @param param MPS
     */
    public void setMPS(com.huawei.www.hss._EnumType param) {
        localMPSTracker = param != null;

        this.localMPS = param;
    }

    public boolean isICSINDSpecified() {
        return localICSINDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getICSIND() {
        return localICSIND;
    }

    /**
     * Auto generated setter method
     * @param param ICSIND
     */
    public void setICSIND(com.huawei.www.hss._EnumType param) {
        localICSINDTracker = param != null;

        this.localICSIND = param;
    }

    public boolean isANCHORSpecified() {
        return localANCHORTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getANCHOR() {
        return localANCHOR;
    }

    /**
     * Auto generated setter method
     * @param param ANCHOR
     */
    public void setANCHOR(com.huawei.www.hss._EnumType param) {
        localANCHORTracker = param != null;

        this.localANCHOR = param;
    }

    public boolean isVolteTagSpecified() {
        return localVolteTagTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVolteTag() {
        return localVolteTag;
    }

    /**
     * Auto generated setter method
     * @param param VolteTag
     */
    public void setVolteTag(com.huawei.www.hss._EnumType param) {
        localVolteTagTracker = param != null;

        this.localVolteTag = param;
    }

    public boolean isTAUTIMERSpecified() {
        return localTAUTIMERTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getTAUTIMER() {
        return localTAUTIMER;
    }

    /**
     * Auto generated setter method
     * @param param TAUTIMER
     */
    public void setTAUTIMER(com.huawei.www.hss.Int0_65534 param) {
        localTAUTIMERTracker = param != null;

        this.localTAUTIMER = param;
    }

    public boolean isRelayNodeSpecified() {
        return localRelayNodeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRelayNode() {
        return localRelayNode;
    }

    /**
     * Auto generated setter method
     * @param param RelayNode
     */
    public void setRelayNode(com.huawei.www.hss._EnumType param) {
        localRelayNodeTracker = param != null;

        this.localRelayNode = param;
    }

    public boolean isEpsOdbPosSpecified() {
        return localEpsOdbPosTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEpsOdbPos() {
        return localEpsOdbPos;
    }

    /**
     * Auto generated setter method
     * @param param EpsOdbPos
     */
    public void setEpsOdbPos(com.huawei.www.hss._EnumType param) {
        localEpsOdbPosTracker = param != null;

        this.localEpsOdbPos = param;
    }

    public boolean isSTNSRSpecified() {
        return localSTNSRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getSTNSR() {
        return localSTNSR;
    }

    /**
     * Auto generated setter method
     * @param param STNSR
     */
    public void setSTNSR(com.huawei.www.hss.Str1_15 param) {
        localSTNSRTracker = param != null;

        this.localSTNSR = param;
    }

    public boolean isAnchorTcsiTplIdSpecified() {
        return localAnchorTcsiTplIdTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getAnchorTcsiTplId() {
        return localAnchorTcsiTplId;
    }

    /**
     * Auto generated setter method
     * @param param AnchorTcsiTplId
     */
    public void setAnchorTcsiTplId(com.huawei.www.hss.Int0_65534 param) {
        localAnchorTcsiTplIdTracker = param != null;

        this.localAnchorTcsiTplId = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":BasicEpsData_type0", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "BasicEpsData_type0", xmlWriter);
            }
        }

        if (localAPNOITracker) {
            if (localAPNOI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "APNOI cannot be null!!");
            }

            localAPNOI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "APNOI"), xmlWriter);
        }

        if (localAMBRMAXULTracker) {
            if (localAMBRMAXUL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AMBRMAXUL cannot be null!!");
            }

            localAMBRMAXUL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AMBRMAXUL"), xmlWriter);
        }

        if (localAMBRMAXDLTracker) {
            if (localAMBRMAXDL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AMBRMAXDL cannot be null!!");
            }

            localAMBRMAXDL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AMBRMAXDL"), xmlWriter);
        }

        if (localRATFREQSELPRIIDTracker) {
            if (localRATFREQSELPRIID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RATFREQSELPRIID cannot be null!!");
            }

            localRATFREQSELPRIID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RATFREQSELPRIID"), xmlWriter);
        }

        if (localPlmnTplIdTracker) {
            if (localPlmnTplId == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PlmnTplId cannot be null!!");
            }

            localPlmnTplId.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PlmnTplId"), xmlWriter);
        }

        if (localDiamNodeTplIdTracker) {
            if (localDiamNodeTplId == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DiamNodeTplId cannot be null!!");
            }

            localDiamNodeTplId.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DiamNodeTplId"), xmlWriter);
        }

        if (localEGRTracker) {
            if (localEGR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EGR cannot be null!!");
            }

            localEGR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EGR"), xmlWriter);
        }

        if (localEgrHlrsnTracker) {
            if (localEgrHlrsn == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EgrHlrsn cannot be null!!");
            }

            localEgrHlrsn.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EgrHlrsn"), xmlWriter);
        }

        if (localLtvAutoProvTracker) {
            if (localLtvAutoProv == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LtvAutoProv cannot be null!!");
            }

            localLtvAutoProv.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LtvAutoProv"), xmlWriter);
        }

        if (localMPSTracker) {
            if (localMPS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MPS cannot be null!!");
            }

            localMPS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MPS"), xmlWriter);
        }

        if (localICSINDTracker) {
            if (localICSIND == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ICSIND cannot be null!!");
            }

            localICSIND.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ICSIND"), xmlWriter);
        }

        if (localANCHORTracker) {
            if (localANCHOR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ANCHOR cannot be null!!");
            }

            localANCHOR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ANCHOR"), xmlWriter);
        }

        if (localVolteTagTracker) {
            if (localVolteTag == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VolteTag cannot be null!!");
            }

            localVolteTag.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VolteTag"), xmlWriter);
        }

        if (localTAUTIMERTracker) {
            if (localTAUTIMER == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TAUTIMER cannot be null!!");
            }

            localTAUTIMER.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TAUTIMER"), xmlWriter);
        }

        if (localRelayNodeTracker) {
            if (localRelayNode == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RelayNode cannot be null!!");
            }

            localRelayNode.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RelayNode"), xmlWriter);
        }

        if (localEpsOdbPosTracker) {
            if (localEpsOdbPos == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsOdbPos cannot be null!!");
            }

            localEpsOdbPos.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsOdbPos"), xmlWriter);
        }

        if (localSTNSRTracker) {
            if (localSTNSR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "STNSR cannot be null!!");
            }

            localSTNSR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "STNSR"), xmlWriter);
        }

        if (localAnchorTcsiTplIdTracker) {
            if (localAnchorTcsiTplId == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AnchorTcsiTplId cannot be null!!");
            }

            localAnchorTcsiTplId.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AnchorTcsiTplId"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static BasicEpsData_type0 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            BasicEpsData_type0 object = new BasicEpsData_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"BasicEpsData_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (BasicEpsData_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "APNOI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "APNOI").equals(
                            reader.getName())) {
                    object.setAPNOI(com.huawei.www.hss.Str1_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AMBRMAXUL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AMBRMAXUL").equals(
                            reader.getName())) {
                    object.setAMBRMAXUL(com.huawei.www.hss.Int0_4294967295.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AMBRMAXDL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AMBRMAXDL").equals(
                            reader.getName())) {
                    object.setAMBRMAXDL(com.huawei.www.hss.Int0_4294967295.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RATFREQSELPRIID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RATFREQSELPRIID").equals(
                            reader.getName())) {
                    object.setRATFREQSELPRIID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PlmnTplId").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PlmnTplId").equals(
                            reader.getName())) {
                    object.setPlmnTplId(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DiamNodeTplId").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DiamNodeTplId").equals(
                            reader.getName())) {
                    object.setDiamNodeTplId(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EGR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EGR").equals(
                            reader.getName())) {
                    object.setEGR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EgrHlrsn").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EgrHlrsn").equals(
                            reader.getName())) {
                    object.setEgrHlrsn(com.huawei.www.hss.Int0_255.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LtvAutoProv").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LtvAutoProv").equals(
                            reader.getName())) {
                    object.setLtvAutoProv(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MPS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MPS").equals(
                            reader.getName())) {
                    object.setMPS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ICSIND").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ICSIND").equals(
                            reader.getName())) {
                    object.setICSIND(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ANCHOR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ANCHOR").equals(
                            reader.getName())) {
                    object.setANCHOR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VolteTag").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VolteTag").equals(
                            reader.getName())) {
                    object.setVolteTag(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TAUTIMER").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TAUTIMER").equals(
                            reader.getName())) {
                    object.setTAUTIMER(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RelayNode").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RelayNode").equals(
                            reader.getName())) {
                    object.setRelayNode(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsOdbPos").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsOdbPos").equals(
                            reader.getName())) {
                    object.setEpsOdbPos(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "STNSR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "STNSR").equals(
                            reader.getName())) {
                    object.setSTNSR(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AnchorTcsiTplId").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AnchorTcsiTplId").equals(
                            reader.getName())) {
                    object.setAnchorTcsiTplId(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
