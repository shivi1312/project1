/**
 * ADD_SCARD.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  ADD_SCARD bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class ADD_SCARD implements org.apache.axis2.databinding.ADBBean {
    public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName("http://www.huawei.com/HSS",
            "ADD_SCARD", "ns3");

    /**
     * field for IMSI
     */
    protected com.huawei.www.hss.Str6_15 localIMSI;

    /**
     * field for ISDN
     */
    protected com.huawei.www.hss.Str1_15 localISDN;

    /**
     * field for MIMSI
     */
    protected com.huawei.www.hss.Str6_15 localMIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMIMSITracker = false;

    /**
     * field for MISDN
     */
    protected com.huawei.www.hss.Str1_15 localMISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMISDNTracker = false;

    /**
     * field for TPLID
     */
    protected com.huawei.www.hss.Int0_65534 localTPLID;

    /**
     * field for IMPI
     */
    protected com.huawei.www.hss.Str1_127 localIMPI;

    /**
     * field for IMPIAUTHTYPE
     */
    protected com.huawei.www.hss._EnumType localIMPIAUTHTYPE;

    /**
     * field for HUSERNAME
     */
    protected com.huawei.www.hss.Str1_127 localHUSERNAME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localHUSERNAMETracker = false;

    /**
     * field for PWD
     */
    protected com.huawei.www.spgschema._PasswordType localPWD;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPWDTracker = false;

    /**
     * field for REALM
     */
    protected com.huawei.www.hss.Str1_46 localREALM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localREALMTracker = false;

    /**
     * field for HA1
     */
    protected com.huawei.www.spgschema._PasswordType localHA1;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localHA1Tracker = false;

    /**
     * field for IMPI2
     */
    protected com.huawei.www.hss.Str1_127 localIMPI2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMPI2Tracker = false;

    /**
     * field for IMPI2AUTHTYPE
     */
    protected com.huawei.www.hss._EnumType localIMPI2AUTHTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMPI2AUTHTYPETracker = false;

    /**
     * field for HUSERNAME2
     */
    protected com.huawei.www.hss.Str1_127 localHUSERNAME2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localHUSERNAME2Tracker = false;

    /**
     * field for PWD2
     */
    protected com.huawei.www.spgschema._PasswordType localPWD2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPWD2Tracker = false;

    /**
     * field for REALM2
     */
    protected com.huawei.www.hss.Str1_46 localREALM2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localREALM2Tracker = false;

    /**
     * field for HA12
     */
    protected com.huawei.www.spgschema._PasswordType localHA12;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localHA12Tracker = false;

    /**
     * field for IMPULIST
     */
    protected com.huawei.www.hss.Str1_1300 localIMPULIST;

    /**
     * field for IMPUTPLID
     */
    protected com.huawei.www.hss.Int0_254 localIMPUTPLID;

    /**
     * field for ACTMT
     */
    protected com.huawei.www.hss._EnumType localACTMT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localACTMTTracker = false;

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getIMSI() {
        return localIMSI;
    }

    /**
     * Auto generated setter method
     * @param param IMSI
     */
    public void setIMSI(com.huawei.www.hss.Str6_15 param) {
        this.localIMSI = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getISDN() {
        return localISDN;
    }

    /**
     * Auto generated setter method
     * @param param ISDN
     */
    public void setISDN(com.huawei.www.hss.Str1_15 param) {
        this.localISDN = param;
    }

    public boolean isMIMSISpecified() {
        return localMIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getMIMSI() {
        return localMIMSI;
    }

    /**
     * Auto generated setter method
     * @param param MIMSI
     */
    public void setMIMSI(com.huawei.www.hss.Str6_15 param) {
        localMIMSITracker = param != null;

        this.localMIMSI = param;
    }

    public boolean isMISDNSpecified() {
        return localMISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getMISDN() {
        return localMISDN;
    }

    /**
     * Auto generated setter method
     * @param param MISDN
     */
    public void setMISDN(com.huawei.www.hss.Str1_15 param) {
        localMISDNTracker = param != null;

        this.localMISDN = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getTPLID() {
        return localTPLID;
    }

    /**
     * Auto generated setter method
     * @param param TPLID
     */
    public void setTPLID(com.huawei.www.hss.Int0_65534 param) {
        this.localTPLID = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_127
     */
    public com.huawei.www.hss.Str1_127 getIMPI() {
        return localIMPI;
    }

    /**
     * Auto generated setter method
     * @param param IMPI
     */
    public void setIMPI(com.huawei.www.hss.Str1_127 param) {
        this.localIMPI = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getIMPIAUTHTYPE() {
        return localIMPIAUTHTYPE;
    }

    /**
     * Auto generated setter method
     * @param param IMPIAUTHTYPE
     */
    public void setIMPIAUTHTYPE(com.huawei.www.hss._EnumType param) {
        this.localIMPIAUTHTYPE = param;
    }

    public boolean isHUSERNAMESpecified() {
        return localHUSERNAMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_127
     */
    public com.huawei.www.hss.Str1_127 getHUSERNAME() {
        return localHUSERNAME;
    }

    /**
     * Auto generated setter method
     * @param param HUSERNAME
     */
    public void setHUSERNAME(com.huawei.www.hss.Str1_127 param) {
        localHUSERNAMETracker = param != null;

        this.localHUSERNAME = param;
    }

    public boolean isPWDSpecified() {
        return localPWDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.spgschema._PasswordType
     */
    public com.huawei.www.spgschema._PasswordType getPWD() {
        return localPWD;
    }

    /**
     * Auto generated setter method
     * @param param PWD
     */
    public void setPWD(com.huawei.www.spgschema._PasswordType param) {
        localPWDTracker = param != null;

        this.localPWD = param;
    }

    public boolean isREALMSpecified() {
        return localREALMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_46
     */
    public com.huawei.www.hss.Str1_46 getREALM() {
        return localREALM;
    }

    /**
     * Auto generated setter method
     * @param param REALM
     */
    public void setREALM(com.huawei.www.hss.Str1_46 param) {
        localREALMTracker = param != null;

        this.localREALM = param;
    }

    public boolean isHA1Specified() {
        return localHA1Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.spgschema._PasswordType
     */
    public com.huawei.www.spgschema._PasswordType getHA1() {
        return localHA1;
    }

    /**
     * Auto generated setter method
     * @param param HA1
     */
    public void setHA1(com.huawei.www.spgschema._PasswordType param) {
        localHA1Tracker = param != null;

        this.localHA1 = param;
    }

    public boolean isIMPI2Specified() {
        return localIMPI2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_127
     */
    public com.huawei.www.hss.Str1_127 getIMPI2() {
        return localIMPI2;
    }

    /**
     * Auto generated setter method
     * @param param IMPI2
     */
    public void setIMPI2(com.huawei.www.hss.Str1_127 param) {
        localIMPI2Tracker = param != null;

        this.localIMPI2 = param;
    }

    public boolean isIMPI2AUTHTYPESpecified() {
        return localIMPI2AUTHTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getIMPI2AUTHTYPE() {
        return localIMPI2AUTHTYPE;
    }

    /**
     * Auto generated setter method
     * @param param IMPI2AUTHTYPE
     */
    public void setIMPI2AUTHTYPE(com.huawei.www.hss._EnumType param) {
        localIMPI2AUTHTYPETracker = param != null;

        this.localIMPI2AUTHTYPE = param;
    }

    public boolean isHUSERNAME2Specified() {
        return localHUSERNAME2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_127
     */
    public com.huawei.www.hss.Str1_127 getHUSERNAME2() {
        return localHUSERNAME2;
    }

    /**
     * Auto generated setter method
     * @param param HUSERNAME2
     */
    public void setHUSERNAME2(com.huawei.www.hss.Str1_127 param) {
        localHUSERNAME2Tracker = param != null;

        this.localHUSERNAME2 = param;
    }

    public boolean isPWD2Specified() {
        return localPWD2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.spgschema._PasswordType
     */
    public com.huawei.www.spgschema._PasswordType getPWD2() {
        return localPWD2;
    }

    /**
     * Auto generated setter method
     * @param param PWD2
     */
    public void setPWD2(com.huawei.www.spgschema._PasswordType param) {
        localPWD2Tracker = param != null;

        this.localPWD2 = param;
    }

    public boolean isREALM2Specified() {
        return localREALM2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_46
     */
    public com.huawei.www.hss.Str1_46 getREALM2() {
        return localREALM2;
    }

    /**
     * Auto generated setter method
     * @param param REALM2
     */
    public void setREALM2(com.huawei.www.hss.Str1_46 param) {
        localREALM2Tracker = param != null;

        this.localREALM2 = param;
    }

    public boolean isHA12Specified() {
        return localHA12Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.spgschema._PasswordType
     */
    public com.huawei.www.spgschema._PasswordType getHA12() {
        return localHA12;
    }

    /**
     * Auto generated setter method
     * @param param HA12
     */
    public void setHA12(com.huawei.www.spgschema._PasswordType param) {
        localHA12Tracker = param != null;

        this.localHA12 = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_1300
     */
    public com.huawei.www.hss.Str1_1300 getIMPULIST() {
        return localIMPULIST;
    }

    /**
     * Auto generated setter method
     * @param param IMPULIST
     */
    public void setIMPULIST(com.huawei.www.hss.Str1_1300 param) {
        this.localIMPULIST = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_254
     */
    public com.huawei.www.hss.Int0_254 getIMPUTPLID() {
        return localIMPUTPLID;
    }

    /**
     * Auto generated setter method
     * @param param IMPUTPLID
     */
    public void setIMPUTPLID(com.huawei.www.hss.Int0_254 param) {
        this.localIMPUTPLID = param;
    }

    public boolean isACTMTSpecified() {
        return localACTMTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getACTMT() {
        return localACTMT;
    }

    /**
     * Auto generated setter method
     * @param param ACTMT
     */
    public void setACTMT(com.huawei.www.hss._EnumType param) {
        localACTMTTracker = param != null;

        this.localACTMT = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, MY_QNAME));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":ADD_SCARD", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "ADD_SCARD", xmlWriter);
            }
        }

        if (localIMSI == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "IMSI cannot be null!!");
        }

        localIMSI.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "IMSI"), xmlWriter);

        if (localISDN == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "ISDN cannot be null!!");
        }

        localISDN.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "ISDN"), xmlWriter);

        if (localMIMSITracker) {
            if (localMIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MIMSI cannot be null!!");
            }

            localMIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MIMSI"), xmlWriter);
        }

        if (localMISDNTracker) {
            if (localMISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MISDN cannot be null!!");
            }

            localMISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MISDN"), xmlWriter);
        }

        if (localTPLID == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "TPLID cannot be null!!");
        }

        localTPLID.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "TPLID"), xmlWriter);

        if (localIMPI == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "IMPI cannot be null!!");
        }

        localIMPI.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "IMPI"), xmlWriter);

        if (localIMPIAUTHTYPE == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "IMPIAUTHTYPE cannot be null!!");
        }

        localIMPIAUTHTYPE.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "IMPIAUTHTYPE"), xmlWriter);

        if (localHUSERNAMETracker) {
            if (localHUSERNAME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "HUSERNAME cannot be null!!");
            }

            localHUSERNAME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "HUSERNAME"), xmlWriter);
        }

        if (localPWDTracker) {
            if (localPWD == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PWD cannot be null!!");
            }

            localPWD.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PWD"), xmlWriter);
        }

        if (localREALMTracker) {
            if (localREALM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "REALM cannot be null!!");
            }

            localREALM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "REALM"), xmlWriter);
        }

        if (localHA1Tracker) {
            if (localHA1 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "HA1 cannot be null!!");
            }

            localHA1.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "HA1"), xmlWriter);
        }

        if (localIMPI2Tracker) {
            if (localIMPI2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMPI2 cannot be null!!");
            }

            localIMPI2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMPI2"), xmlWriter);
        }

        if (localIMPI2AUTHTYPETracker) {
            if (localIMPI2AUTHTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMPI2AUTHTYPE cannot be null!!");
            }

            localIMPI2AUTHTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMPI2AUTHTYPE"), xmlWriter);
        }

        if (localHUSERNAME2Tracker) {
            if (localHUSERNAME2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "HUSERNAME2 cannot be null!!");
            }

            localHUSERNAME2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "HUSERNAME2"), xmlWriter);
        }

        if (localPWD2Tracker) {
            if (localPWD2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PWD2 cannot be null!!");
            }

            localPWD2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PWD2"), xmlWriter);
        }

        if (localREALM2Tracker) {
            if (localREALM2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "REALM2 cannot be null!!");
            }

            localREALM2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "REALM2"), xmlWriter);
        }

        if (localHA12Tracker) {
            if (localHA12 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "HA12 cannot be null!!");
            }

            localHA12.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "HA12"), xmlWriter);
        }

        if (localIMPULIST == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "IMPULIST cannot be null!!");
        }

        localIMPULIST.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "IMPULIST"), xmlWriter);

        if (localIMPUTPLID == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "IMPUTPLID cannot be null!!");
        }

        localIMPUTPLID.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "IMPUTPLID"), xmlWriter);

        if (localACTMTTracker) {
            if (localACTMT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ACTMT cannot be null!!");
            }

            localACTMT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ACTMT"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static ADD_SCARD parse(javax.xml.stream.XMLStreamReader reader)
            throws java.lang.Exception {
            ADD_SCARD object = new ADD_SCARD();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"ADD_SCARD".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (ADD_SCARD) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSI").equals(
                            reader.getName())) {
                    object.setIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ISDN").equals(
                            reader.getName())) {
                    object.setISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MIMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MIMSI").equals(
                            reader.getName())) {
                    object.setMIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MISDN").equals(
                            reader.getName())) {
                    object.setMISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TPLID").equals(
                            reader.getName())) {
                    object.setTPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMPI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMPI").equals(
                            reader.getName())) {
                    object.setIMPI(com.huawei.www.hss.Str1_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMPIAUTHTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMPIAUTHTYPE").equals(
                            reader.getName())) {
                    object.setIMPIAUTHTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "HUSERNAME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "HUSERNAME").equals(
                            reader.getName())) {
                    object.setHUSERNAME(com.huawei.www.hss.Str1_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PWD").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PWD").equals(
                            reader.getName())) {
                    object.setPWD(com.huawei.www.spgschema._PasswordType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "REALM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "REALM").equals(
                            reader.getName())) {
                    object.setREALM(com.huawei.www.hss.Str1_46.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "HA1").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "HA1").equals(
                            reader.getName())) {
                    object.setHA1(com.huawei.www.spgschema._PasswordType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMPI2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMPI2").equals(
                            reader.getName())) {
                    object.setIMPI2(com.huawei.www.hss.Str1_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMPI2AUTHTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMPI2AUTHTYPE").equals(
                            reader.getName())) {
                    object.setIMPI2AUTHTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "HUSERNAME2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "HUSERNAME2").equals(
                            reader.getName())) {
                    object.setHUSERNAME2(com.huawei.www.hss.Str1_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PWD2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PWD2").equals(
                            reader.getName())) {
                    object.setPWD2(com.huawei.www.spgschema._PasswordType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "REALM2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "REALM2").equals(
                            reader.getName())) {
                    object.setREALM2(com.huawei.www.hss.Str1_46.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "HA12").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "HA12").equals(
                            reader.getName())) {
                    object.setHA12(com.huawei.www.spgschema._PasswordType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMPULIST").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMPULIST").equals(
                            reader.getName())) {
                    object.setIMPULIST(com.huawei.www.hss.Str1_1300.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMPUTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMPUTPLID").equals(
                            reader.getName())) {
                    object.setIMPUTPLID(com.huawei.www.hss.Int0_254.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ACTMT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ACTMT").equals(
                            reader.getName())) {
                    object.setACTMT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
