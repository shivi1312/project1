/**
 * BasicDynamicDataForGPRS_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  BasicDynamicDataForGPRS_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class BasicDynamicDataForGPRS_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = BasicDynamicDataForGPRS_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for SgsnNum
     */
    protected com.huawei.www.hss.Str1_15 localSgsnNum;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnNumTracker = false;

    /**
     * field for SgsnAddressType
     */
    protected com.huawei.www.hss._EnumType localSgsnAddressType;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnAddressTypeTracker = false;

    /**
     * field for SgsnAddress
     */
    protected com.huawei.www.hss.Str0_127 localSgsnAddress;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnAddressTracker = false;

    /**
     * field for SgsnInHplmn
     */
    protected com.huawei.www.hss._EnumType localSgsnInHplmn;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnInHplmnTracker = false;

    /**
     * field for MsPurgedForGprs
     */
    protected com.huawei.www.hss._EnumType localMsPurgedForGprs;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMsPurgedForGprsTracker = false;

    /**
     * field for SgsnInHomeCountry
     */
    protected com.huawei.www.hss._EnumType localSgsnInHomeCountry;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnInHomeCountryTracker = false;

    /**
     * field for SgsnInArea
     */
    protected com.huawei.www.hss._EnumType localSgsnInArea;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnInAreaTracker = false;

    /**
     * field for RoamingRestrictInSgsnDueToUnsupportedFeature
     */
    protected com.huawei.www.hss._EnumType localRoamingRestrictInSgsnDueToUnsupportedFeature;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRoamingRestrictInSgsnDueToUnsupportedFeatureTracker = false;

    /**
     * field for SgsnAreaRoamingRestrict
     */
    protected com.huawei.www.hss._EnumType localSgsnAreaRoamingRestrict;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnAreaRoamingRestrictTracker = false;

    /**
     * field for ODBarredForUnsupportedCamelForGprs
     */
    protected com.huawei.www.hss._EnumType localODBarredForUnsupportedCamelForGprs;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBarredForUnsupportedCamelForGprsTracker = false;

    /**
     * field for PsUplTime
     */
    protected com.huawei.www.hss.Int0_65534 localPsUplTime;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPsUplTimeTracker = false;

    /**
     * field for PsPurgeTime
     */
    protected com.huawei.www.hss.Int0_65534 localPsPurgeTime;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPsPurgeTimeTracker = false;

    /**
     * field for PSMSISDNLESS
     */
    protected com.huawei.www.hss._EnumType localPSMSISDNLESS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPSMSISDNLESSTracker = false;

    /**
     * field for PSRATTYPE
     */
    protected com.huawei.www.hss._EnumType localPSRATTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPSRATTYPETracker = false;

    /**
     * field for PsUplStatus
     */
    protected com.huawei.www.hss._EnumType localPsUplStatus;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPsUplStatusTracker = false;

    /**
     * field for GgsnNumber
     */
    protected com.huawei.www.hss.Str1_15 localGgsnNumber;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGgsnNumberTracker = false;

    /**
     * field for GgsnAddressType
     */
    protected com.huawei.www.hss._EnumType localGgsnAddressType;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGgsnAddressTypeTracker = false;

    /**
     * field for GgsnAddress
     */
    protected com.huawei.www.hss.Str0_127 localGgsnAddress;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGgsnAddressTracker = false;

    /**
     * field for SupportedCamelPhase3ForGprs
     */
    protected com.huawei.www.hss._EnumType localSupportedCamelPhase3ForGprs;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedCamelPhase3ForGprsTracker = false;

    /**
     * field for SupportedCamelPhase4ForGprs
     */
    protected com.huawei.www.hss._EnumType localSupportedCamelPhase4ForGprs;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedCamelPhase4ForGprsTracker = false;

    /**
     * field for SuperChargerSupportedForGprs
     */
    protected com.huawei.www.hss._EnumType localSuperChargerSupportedForGprs;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSuperChargerSupportedForGprsTracker = false;

    /**
     * field for ZoneCodeStatusAtSgsn
     */
    protected com.huawei.www.hss._EnumType localZoneCodeStatusAtSgsn;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localZoneCodeStatusAtSgsnTracker = false;

    public boolean isSgsnNumSpecified() {
        return localSgsnNumTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getSgsnNum() {
        return localSgsnNum;
    }

    /**
     * Auto generated setter method
     * @param param SgsnNum
     */
    public void setSgsnNum(com.huawei.www.hss.Str1_15 param) {
        localSgsnNumTracker = param != null;

        this.localSgsnNum = param;
    }

    public boolean isSgsnAddressTypeSpecified() {
        return localSgsnAddressTypeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSgsnAddressType() {
        return localSgsnAddressType;
    }

    /**
     * Auto generated setter method
     * @param param SgsnAddressType
     */
    public void setSgsnAddressType(com.huawei.www.hss._EnumType param) {
        localSgsnAddressTypeTracker = param != null;

        this.localSgsnAddressType = param;
    }

    public boolean isSgsnAddressSpecified() {
        return localSgsnAddressTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_127
     */
    public com.huawei.www.hss.Str0_127 getSgsnAddress() {
        return localSgsnAddress;
    }

    /**
     * Auto generated setter method
     * @param param SgsnAddress
     */
    public void setSgsnAddress(com.huawei.www.hss.Str0_127 param) {
        localSgsnAddressTracker = param != null;

        this.localSgsnAddress = param;
    }

    public boolean isSgsnInHplmnSpecified() {
        return localSgsnInHplmnTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSgsnInHplmn() {
        return localSgsnInHplmn;
    }

    /**
     * Auto generated setter method
     * @param param SgsnInHplmn
     */
    public void setSgsnInHplmn(com.huawei.www.hss._EnumType param) {
        localSgsnInHplmnTracker = param != null;

        this.localSgsnInHplmn = param;
    }

    public boolean isMsPurgedForGprsSpecified() {
        return localMsPurgedForGprsTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMsPurgedForGprs() {
        return localMsPurgedForGprs;
    }

    /**
     * Auto generated setter method
     * @param param MsPurgedForGprs
     */
    public void setMsPurgedForGprs(com.huawei.www.hss._EnumType param) {
        localMsPurgedForGprsTracker = param != null;

        this.localMsPurgedForGprs = param;
    }

    public boolean isSgsnInHomeCountrySpecified() {
        return localSgsnInHomeCountryTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSgsnInHomeCountry() {
        return localSgsnInHomeCountry;
    }

    /**
     * Auto generated setter method
     * @param param SgsnInHomeCountry
     */
    public void setSgsnInHomeCountry(com.huawei.www.hss._EnumType param) {
        localSgsnInHomeCountryTracker = param != null;

        this.localSgsnInHomeCountry = param;
    }

    public boolean isSgsnInAreaSpecified() {
        return localSgsnInAreaTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSgsnInArea() {
        return localSgsnInArea;
    }

    /**
     * Auto generated setter method
     * @param param SgsnInArea
     */
    public void setSgsnInArea(com.huawei.www.hss._EnumType param) {
        localSgsnInAreaTracker = param != null;

        this.localSgsnInArea = param;
    }

    public boolean isRoamingRestrictInSgsnDueToUnsupportedFeatureSpecified() {
        return localRoamingRestrictInSgsnDueToUnsupportedFeatureTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRoamingRestrictInSgsnDueToUnsupportedFeature() {
        return localRoamingRestrictInSgsnDueToUnsupportedFeature;
    }

    /**
     * Auto generated setter method
     * @param param RoamingRestrictInSgsnDueToUnsupportedFeature
     */
    public void setRoamingRestrictInSgsnDueToUnsupportedFeature(
        com.huawei.www.hss._EnumType param) {
        localRoamingRestrictInSgsnDueToUnsupportedFeatureTracker = param != null;

        this.localRoamingRestrictInSgsnDueToUnsupportedFeature = param;
    }

    public boolean isSgsnAreaRoamingRestrictSpecified() {
        return localSgsnAreaRoamingRestrictTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSgsnAreaRoamingRestrict() {
        return localSgsnAreaRoamingRestrict;
    }

    /**
     * Auto generated setter method
     * @param param SgsnAreaRoamingRestrict
     */
    public void setSgsnAreaRoamingRestrict(com.huawei.www.hss._EnumType param) {
        localSgsnAreaRoamingRestrictTracker = param != null;

        this.localSgsnAreaRoamingRestrict = param;
    }

    public boolean isODBarredForUnsupportedCamelForGprsSpecified() {
        return localODBarredForUnsupportedCamelForGprsTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBarredForUnsupportedCamelForGprs() {
        return localODBarredForUnsupportedCamelForGprs;
    }

    /**
     * Auto generated setter method
     * @param param ODBarredForUnsupportedCamelForGprs
     */
    public void setODBarredForUnsupportedCamelForGprs(
        com.huawei.www.hss._EnumType param) {
        localODBarredForUnsupportedCamelForGprsTracker = param != null;

        this.localODBarredForUnsupportedCamelForGprs = param;
    }

    public boolean isPsUplTimeSpecified() {
        return localPsUplTimeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getPsUplTime() {
        return localPsUplTime;
    }

    /**
     * Auto generated setter method
     * @param param PsUplTime
     */
    public void setPsUplTime(com.huawei.www.hss.Int0_65534 param) {
        localPsUplTimeTracker = param != null;

        this.localPsUplTime = param;
    }

    public boolean isPsPurgeTimeSpecified() {
        return localPsPurgeTimeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getPsPurgeTime() {
        return localPsPurgeTime;
    }

    /**
     * Auto generated setter method
     * @param param PsPurgeTime
     */
    public void setPsPurgeTime(com.huawei.www.hss.Int0_65534 param) {
        localPsPurgeTimeTracker = param != null;

        this.localPsPurgeTime = param;
    }

    public boolean isPSMSISDNLESSSpecified() {
        return localPSMSISDNLESSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPSMSISDNLESS() {
        return localPSMSISDNLESS;
    }

    /**
     * Auto generated setter method
     * @param param PSMSISDNLESS
     */
    public void setPSMSISDNLESS(com.huawei.www.hss._EnumType param) {
        localPSMSISDNLESSTracker = param != null;

        this.localPSMSISDNLESS = param;
    }

    public boolean isPSRATTYPESpecified() {
        return localPSRATTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPSRATTYPE() {
        return localPSRATTYPE;
    }

    /**
     * Auto generated setter method
     * @param param PSRATTYPE
     */
    public void setPSRATTYPE(com.huawei.www.hss._EnumType param) {
        localPSRATTYPETracker = param != null;

        this.localPSRATTYPE = param;
    }

    public boolean isPsUplStatusSpecified() {
        return localPsUplStatusTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPsUplStatus() {
        return localPsUplStatus;
    }

    /**
     * Auto generated setter method
     * @param param PsUplStatus
     */
    public void setPsUplStatus(com.huawei.www.hss._EnumType param) {
        localPsUplStatusTracker = param != null;

        this.localPsUplStatus = param;
    }

    public boolean isGgsnNumberSpecified() {
        return localGgsnNumberTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getGgsnNumber() {
        return localGgsnNumber;
    }

    /**
     * Auto generated setter method
     * @param param GgsnNumber
     */
    public void setGgsnNumber(com.huawei.www.hss.Str1_15 param) {
        localGgsnNumberTracker = param != null;

        this.localGgsnNumber = param;
    }

    public boolean isGgsnAddressTypeSpecified() {
        return localGgsnAddressTypeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getGgsnAddressType() {
        return localGgsnAddressType;
    }

    /**
     * Auto generated setter method
     * @param param GgsnAddressType
     */
    public void setGgsnAddressType(com.huawei.www.hss._EnumType param) {
        localGgsnAddressTypeTracker = param != null;

        this.localGgsnAddressType = param;
    }

    public boolean isGgsnAddressSpecified() {
        return localGgsnAddressTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_127
     */
    public com.huawei.www.hss.Str0_127 getGgsnAddress() {
        return localGgsnAddress;
    }

    /**
     * Auto generated setter method
     * @param param GgsnAddress
     */
    public void setGgsnAddress(com.huawei.www.hss.Str0_127 param) {
        localGgsnAddressTracker = param != null;

        this.localGgsnAddress = param;
    }

    public boolean isSupportedCamelPhase3ForGprsSpecified() {
        return localSupportedCamelPhase3ForGprsTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedCamelPhase3ForGprs() {
        return localSupportedCamelPhase3ForGprs;
    }

    /**
     * Auto generated setter method
     * @param param SupportedCamelPhase3ForGprs
     */
    public void setSupportedCamelPhase3ForGprs(
        com.huawei.www.hss._EnumType param) {
        localSupportedCamelPhase3ForGprsTracker = param != null;

        this.localSupportedCamelPhase3ForGprs = param;
    }

    public boolean isSupportedCamelPhase4ForGprsSpecified() {
        return localSupportedCamelPhase4ForGprsTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedCamelPhase4ForGprs() {
        return localSupportedCamelPhase4ForGprs;
    }

    /**
     * Auto generated setter method
     * @param param SupportedCamelPhase4ForGprs
     */
    public void setSupportedCamelPhase4ForGprs(
        com.huawei.www.hss._EnumType param) {
        localSupportedCamelPhase4ForGprsTracker = param != null;

        this.localSupportedCamelPhase4ForGprs = param;
    }

    public boolean isSuperChargerSupportedForGprsSpecified() {
        return localSuperChargerSupportedForGprsTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSuperChargerSupportedForGprs() {
        return localSuperChargerSupportedForGprs;
    }

    /**
     * Auto generated setter method
     * @param param SuperChargerSupportedForGprs
     */
    public void setSuperChargerSupportedForGprs(
        com.huawei.www.hss._EnumType param) {
        localSuperChargerSupportedForGprsTracker = param != null;

        this.localSuperChargerSupportedForGprs = param;
    }

    public boolean isZoneCodeStatusAtSgsnSpecified() {
        return localZoneCodeStatusAtSgsnTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getZoneCodeStatusAtSgsn() {
        return localZoneCodeStatusAtSgsn;
    }

    /**
     * Auto generated setter method
     * @param param ZoneCodeStatusAtSgsn
     */
    public void setZoneCodeStatusAtSgsn(com.huawei.www.hss._EnumType param) {
        localZoneCodeStatusAtSgsnTracker = param != null;

        this.localZoneCodeStatusAtSgsn = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":BasicDynamicDataForGPRS_type0",
                    xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "BasicDynamicDataForGPRS_type0", xmlWriter);
            }
        }

        if (localSgsnNumTracker) {
            if (localSgsnNum == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnNum cannot be null!!");
            }

            localSgsnNum.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnNum"), xmlWriter);
        }

        if (localSgsnAddressTypeTracker) {
            if (localSgsnAddressType == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnAddressType cannot be null!!");
            }

            localSgsnAddressType.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnAddressType"), xmlWriter);
        }

        if (localSgsnAddressTracker) {
            if (localSgsnAddress == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnAddress cannot be null!!");
            }

            localSgsnAddress.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnAddress"), xmlWriter);
        }

        if (localSgsnInHplmnTracker) {
            if (localSgsnInHplmn == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnInHplmn cannot be null!!");
            }

            localSgsnInHplmn.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnInHplmn"), xmlWriter);
        }

        if (localMsPurgedForGprsTracker) {
            if (localMsPurgedForGprs == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MsPurgedForGprs cannot be null!!");
            }

            localMsPurgedForGprs.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MsPurgedForGprs"), xmlWriter);
        }

        if (localSgsnInHomeCountryTracker) {
            if (localSgsnInHomeCountry == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnInHomeCountry cannot be null!!");
            }

            localSgsnInHomeCountry.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnInHomeCountry"), xmlWriter);
        }

        if (localSgsnInAreaTracker) {
            if (localSgsnInArea == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnInArea cannot be null!!");
            }

            localSgsnInArea.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnInArea"), xmlWriter);
        }

        if (localRoamingRestrictInSgsnDueToUnsupportedFeatureTracker) {
            if (localRoamingRestrictInSgsnDueToUnsupportedFeature == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RoamingRestrictInSgsnDueToUnsupportedFeature cannot be null!!");
            }

            localRoamingRestrictInSgsnDueToUnsupportedFeature.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "RoamingRestrictInSgsnDueToUnsupportedFeature"), xmlWriter);
        }

        if (localSgsnAreaRoamingRestrictTracker) {
            if (localSgsnAreaRoamingRestrict == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnAreaRoamingRestrict cannot be null!!");
            }

            localSgsnAreaRoamingRestrict.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnAreaRoamingRestrict"),
                xmlWriter);
        }

        if (localODBarredForUnsupportedCamelForGprsTracker) {
            if (localODBarredForUnsupportedCamelForGprs == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBarredForUnsupportedCamelForGprs cannot be null!!");
            }

            localODBarredForUnsupportedCamelForGprs.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "ODBarredForUnsupportedCamelForGprs"), xmlWriter);
        }

        if (localPsUplTimeTracker) {
            if (localPsUplTime == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PsUplTime cannot be null!!");
            }

            localPsUplTime.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PsUplTime"), xmlWriter);
        }

        if (localPsPurgeTimeTracker) {
            if (localPsPurgeTime == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PsPurgeTime cannot be null!!");
            }

            localPsPurgeTime.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PsPurgeTime"), xmlWriter);
        }

        if (localPSMSISDNLESSTracker) {
            if (localPSMSISDNLESS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PS-MSISDN-LESS cannot be null!!");
            }

            localPSMSISDNLESS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PS-MSISDN-LESS"), xmlWriter);
        }

        if (localPSRATTYPETracker) {
            if (localPSRATTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PSRATTYPE cannot be null!!");
            }

            localPSRATTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PSRATTYPE"), xmlWriter);
        }

        if (localPsUplStatusTracker) {
            if (localPsUplStatus == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PsUplStatus cannot be null!!");
            }

            localPsUplStatus.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PsUplStatus"), xmlWriter);
        }

        if (localGgsnNumberTracker) {
            if (localGgsnNumber == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GgsnNumber cannot be null!!");
            }

            localGgsnNumber.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GgsnNumber"), xmlWriter);
        }

        if (localGgsnAddressTypeTracker) {
            if (localGgsnAddressType == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GgsnAddressType cannot be null!!");
            }

            localGgsnAddressType.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GgsnAddressType"), xmlWriter);
        }

        if (localGgsnAddressTracker) {
            if (localGgsnAddress == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GgsnAddress cannot be null!!");
            }

            localGgsnAddress.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GgsnAddress"), xmlWriter);
        }

        if (localSupportedCamelPhase3ForGprsTracker) {
            if (localSupportedCamelPhase3ForGprs == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedCamelPhase3ForGprs cannot be null!!");
            }

            localSupportedCamelPhase3ForGprs.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedCamelPhase3ForGprs"),
                xmlWriter);
        }

        if (localSupportedCamelPhase4ForGprsTracker) {
            if (localSupportedCamelPhase4ForGprs == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedCamelPhase4ForGprs cannot be null!!");
            }

            localSupportedCamelPhase4ForGprs.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedCamelPhase4ForGprs"),
                xmlWriter);
        }

        if (localSuperChargerSupportedForGprsTracker) {
            if (localSuperChargerSupportedForGprs == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SuperChargerSupportedForGprs cannot be null!!");
            }

            localSuperChargerSupportedForGprs.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SuperChargerSupportedForGprs"),
                xmlWriter);
        }

        if (localZoneCodeStatusAtSgsnTracker) {
            if (localZoneCodeStatusAtSgsn == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ZoneCodeStatusAtSgsn cannot be null!!");
            }

            localZoneCodeStatusAtSgsn.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ZoneCodeStatusAtSgsn"),
                xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static BasicDynamicDataForGPRS_type0 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            BasicDynamicDataForGPRS_type0 object = new BasicDynamicDataForGPRS_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"BasicDynamicDataForGPRS_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (BasicDynamicDataForGPRS_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SgsnNum").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SgsnNum").equals(
                            reader.getName())) {
                    object.setSgsnNum(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SgsnAddressType").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SgsnAddressType").equals(
                            reader.getName())) {
                    object.setSgsnAddressType(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SgsnAddress").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SgsnAddress").equals(
                            reader.getName())) {
                    object.setSgsnAddress(com.huawei.www.hss.Str0_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SgsnInHplmn").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SgsnInHplmn").equals(
                            reader.getName())) {
                    object.setSgsnInHplmn(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MsPurgedForGprs").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MsPurgedForGprs").equals(
                            reader.getName())) {
                    object.setMsPurgedForGprs(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SgsnInHomeCountry").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SgsnInHomeCountry").equals(
                            reader.getName())) {
                    object.setSgsnInHomeCountry(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SgsnInArea").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SgsnInArea").equals(
                            reader.getName())) {
                    object.setSgsnInArea(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "RoamingRestrictInSgsnDueToUnsupportedFeature").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "RoamingRestrictInSgsnDueToUnsupportedFeature").equals(
                            reader.getName())) {
                    object.setRoamingRestrictInSgsnDueToUnsupportedFeature(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SgsnAreaRoamingRestrict").equals(reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SgsnAreaRoamingRestrict").equals(reader.getName())) {
                    object.setSgsnAreaRoamingRestrict(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "ODBarredForUnsupportedCamelForGprs").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "ODBarredForUnsupportedCamelForGprs").equals(
                            reader.getName())) {
                    object.setODBarredForUnsupportedCamelForGprs(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PsUplTime").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PsUplTime").equals(
                            reader.getName())) {
                    object.setPsUplTime(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PsPurgeTime").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PsPurgeTime").equals(
                            reader.getName())) {
                    object.setPsPurgeTime(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PS-MSISDN-LESS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PS-MSISDN-LESS").equals(
                            reader.getName())) {
                    object.setPSMSISDNLESS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PSRATTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PSRATTYPE").equals(
                            reader.getName())) {
                    object.setPSRATTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PsUplStatus").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PsUplStatus").equals(
                            reader.getName())) {
                    object.setPsUplStatus(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GgsnNumber").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GgsnNumber").equals(
                            reader.getName())) {
                    object.setGgsnNumber(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GgsnAddressType").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GgsnAddressType").equals(
                            reader.getName())) {
                    object.setGgsnAddressType(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GgsnAddress").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GgsnAddress").equals(
                            reader.getName())) {
                    object.setGgsnAddress(com.huawei.www.hss.Str0_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SupportedCamelPhase3ForGprs").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SupportedCamelPhase3ForGprs").equals(
                            reader.getName())) {
                    object.setSupportedCamelPhase3ForGprs(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SupportedCamelPhase4ForGprs").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SupportedCamelPhase4ForGprs").equals(
                            reader.getName())) {
                    object.setSupportedCamelPhase4ForGprs(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SuperChargerSupportedForGprs").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SuperChargerSupportedForGprs").equals(
                            reader.getName())) {
                    object.setSuperChargerSupportedForGprs(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ZoneCodeStatusAtSgsn").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ZoneCodeStatusAtSgsn").equals(
                            reader.getName())) {
                    object.setZoneCodeStatusAtSgsn(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
