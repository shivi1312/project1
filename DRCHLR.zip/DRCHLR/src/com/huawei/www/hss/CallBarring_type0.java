/**
 * CallBarring_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  CallBarring_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class CallBarring_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = CallBarring_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for CbSerCode
     */
    protected com.huawei.www.hss._EnumType localCbSerCode;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCbSerCodeTracker = false;

    /**
     * field for CbProv
     */
    protected com.huawei.www.hss._EnumType localCbProv;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCbProvTracker = false;

    /**
     * field for CbTs1X
     */
    protected com.huawei.www.hss._EnumType localCbTs1X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCbTs1XTracker = false;

    /**
     * field for CbTs2X
     */
    protected com.huawei.www.hss._EnumType localCbTs2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCbTs2XTracker = false;

    /**
     * field for CbTs6X
     */
    protected com.huawei.www.hss._EnumType localCbTs6X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCbTs6XTracker = false;

    /**
     * field for CbBs2X
     */
    protected com.huawei.www.hss._EnumType localCbBs2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCbBs2XTracker = false;

    /**
     * field for CbBs3X
     */
    protected com.huawei.www.hss._EnumType localCbBs3X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCbBs3XTracker = false;

    /**
     * field for CbTsDX
     */
    protected com.huawei.www.hss._EnumType localCbTsDX;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCbTsDXTracker = false;

    public boolean isCbSerCodeSpecified() {
        return localCbSerCodeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCbSerCode() {
        return localCbSerCode;
    }

    /**
     * Auto generated setter method
     * @param param CbSerCode
     */
    public void setCbSerCode(com.huawei.www.hss._EnumType param) {
        localCbSerCodeTracker = param != null;

        this.localCbSerCode = param;
    }

    public boolean isCbProvSpecified() {
        return localCbProvTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCbProv() {
        return localCbProv;
    }

    /**
     * Auto generated setter method
     * @param param CbProv
     */
    public void setCbProv(com.huawei.www.hss._EnumType param) {
        localCbProvTracker = param != null;

        this.localCbProv = param;
    }

    public boolean isCbTs1XSpecified() {
        return localCbTs1XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCbTs1X() {
        return localCbTs1X;
    }

    /**
     * Auto generated setter method
     * @param param CbTs1X
     */
    public void setCbTs1X(com.huawei.www.hss._EnumType param) {
        localCbTs1XTracker = param != null;

        this.localCbTs1X = param;
    }

    public boolean isCbTs2XSpecified() {
        return localCbTs2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCbTs2X() {
        return localCbTs2X;
    }

    /**
     * Auto generated setter method
     * @param param CbTs2X
     */
    public void setCbTs2X(com.huawei.www.hss._EnumType param) {
        localCbTs2XTracker = param != null;

        this.localCbTs2X = param;
    }

    public boolean isCbTs6XSpecified() {
        return localCbTs6XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCbTs6X() {
        return localCbTs6X;
    }

    /**
     * Auto generated setter method
     * @param param CbTs6X
     */
    public void setCbTs6X(com.huawei.www.hss._EnumType param) {
        localCbTs6XTracker = param != null;

        this.localCbTs6X = param;
    }

    public boolean isCbBs2XSpecified() {
        return localCbBs2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCbBs2X() {
        return localCbBs2X;
    }

    /**
     * Auto generated setter method
     * @param param CbBs2X
     */
    public void setCbBs2X(com.huawei.www.hss._EnumType param) {
        localCbBs2XTracker = param != null;

        this.localCbBs2X = param;
    }

    public boolean isCbBs3XSpecified() {
        return localCbBs3XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCbBs3X() {
        return localCbBs3X;
    }

    /**
     * Auto generated setter method
     * @param param CbBs3X
     */
    public void setCbBs3X(com.huawei.www.hss._EnumType param) {
        localCbBs3XTracker = param != null;

        this.localCbBs3X = param;
    }

    public boolean isCbTsDXSpecified() {
        return localCbTsDXTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCbTsDX() {
        return localCbTsDX;
    }

    /**
     * Auto generated setter method
     * @param param CbTsDX
     */
    public void setCbTsDX(com.huawei.www.hss._EnumType param) {
        localCbTsDXTracker = param != null;

        this.localCbTsDX = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":CallBarring_type0", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "CallBarring_type0", xmlWriter);
            }
        }

        if (localCbSerCodeTracker) {
            if (localCbSerCode == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CbSerCode cannot be null!!");
            }

            localCbSerCode.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CbSerCode"), xmlWriter);
        }

        if (localCbProvTracker) {
            if (localCbProv == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CbProv cannot be null!!");
            }

            localCbProv.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CbProv"), xmlWriter);
        }

        if (localCbTs1XTracker) {
            if (localCbTs1X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CbTs1X cannot be null!!");
            }

            localCbTs1X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CbTs1X"), xmlWriter);
        }

        if (localCbTs2XTracker) {
            if (localCbTs2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CbTs2X cannot be null!!");
            }

            localCbTs2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CbTs2X"), xmlWriter);
        }

        if (localCbTs6XTracker) {
            if (localCbTs6X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CbTs6X cannot be null!!");
            }

            localCbTs6X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CbTs6X"), xmlWriter);
        }

        if (localCbBs2XTracker) {
            if (localCbBs2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CbBs2X cannot be null!!");
            }

            localCbBs2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CbBs2X"), xmlWriter);
        }

        if (localCbBs3XTracker) {
            if (localCbBs3X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CbBs3X cannot be null!!");
            }

            localCbBs3X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CbBs3X"), xmlWriter);
        }

        if (localCbTsDXTracker) {
            if (localCbTsDX == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CbTsDX cannot be null!!");
            }

            localCbTsDX.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CbTsDX"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static CallBarring_type0 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            CallBarring_type0 object = new CallBarring_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"CallBarring_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (CallBarring_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CbSerCode").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CbSerCode").equals(
                            reader.getName())) {
                    object.setCbSerCode(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CbProv").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CbProv").equals(
                            reader.getName())) {
                    object.setCbProv(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CbTs1X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CbTs1X").equals(
                            reader.getName())) {
                    object.setCbTs1X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CbTs2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CbTs2X").equals(
                            reader.getName())) {
                    object.setCbTs2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CbTs6X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CbTs6X").equals(
                            reader.getName())) {
                    object.setCbTs6X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CbBs2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CbBs2X").equals(
                            reader.getName())) {
                    object.setCbBs2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CbBs3X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CbBs3X").equals(
                            reader.getName())) {
                    object.setCbBs3X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CbTsDX").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CbTsDX").equals(
                            reader.getName())) {
                    object.setCbTsDX(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
