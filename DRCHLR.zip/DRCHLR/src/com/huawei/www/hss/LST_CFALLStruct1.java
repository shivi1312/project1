/**
 * LST_CFALLStruct1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  LST_CFALLStruct1 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class LST_CFALLStruct1 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = LST_CFALLStruct1
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for IMSI
     */
    protected com.huawei.www.hss.Str6_15 localIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSITracker = false;

    /**
     * field for ISDN
     */
    protected com.huawei.www.hss.Str1_15 localISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localISDNTracker = false;

    /**
     * field for CFU_OFATPLID
     */
    protected com.huawei.www.hss.Int0_65534 localCFU_OFATPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFU_OFATPLIDTracker = false;

    /**
     * field for CFB_OFATPLID
     */
    protected com.huawei.www.hss.Int0_65534 localCFB_OFATPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFB_OFATPLIDTracker = false;

    /**
     * field for CFNRY_OFATPLID
     */
    protected com.huawei.www.hss.Int0_65534 localCFNRY_OFATPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRY_OFATPLIDTracker = false;

    /**
     * field for CFNRC_OFATPLID
     */
    protected com.huawei.www.hss.Int0_65534 localCFNRC_OFATPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRC_OFATPLIDTracker = false;

    /**
     * field for CFD_OFATPLID
     */
    protected com.huawei.www.hss.Int0_65534 localCFD_OFATPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_OFATPLIDTracker = false;

    /**
     * field for CFU_NFS
     */
    protected com.huawei.www.hss._EnumType localCFU_NFS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFU_NFSTracker = false;

    /**
     * field for CFU_NCS
     */
    protected com.huawei.www.hss._EnumType localCFU_NCS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFU_NCSTracker = false;

    /**
     * field for CFU_COU
     */
    protected com.huawei.www.hss._EnumType localCFU_COU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFU_COUTracker = false;

    /**
     * field for CFU_FTN
     */
    protected com.huawei.www.hss.Str1_16 localCFU_FTN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFU_FTNTracker = false;

    /**
     * field for CFU_BSG
     */
    protected com.huawei.www.hss._EnumType localCFU_BSG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFU_BSGTracker = false;

    /**
     * field for CFU_STATUS
     */
    protected com.huawei.www.hss._EnumType localCFU_STATUS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFU_STATUSTracker = false;

    /**
     * field for CFB_NFS
     */
    protected com.huawei.www.hss._EnumType localCFB_NFS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFB_NFSTracker = false;

    /**
     * field for CFB_NCS
     */
    protected com.huawei.www.hss._EnumType localCFB_NCS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFB_NCSTracker = false;

    /**
     * field for CFB_COU
     */
    protected com.huawei.www.hss._EnumType localCFB_COU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFB_COUTracker = false;

    /**
     * field for CFB_FTN
     */
    protected com.huawei.www.hss.Str1_16 localCFB_FTN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFB_FTNTracker = false;

    /**
     * field for CFB_BSG
     */
    protected com.huawei.www.hss._EnumType localCFB_BSG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFB_BSGTracker = false;

    /**
     * field for CFB_STATUS
     */
    protected com.huawei.www.hss._EnumType localCFB_STATUS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFB_STATUSTracker = false;

    /**
     * field for CFNRY_NFS
     */
    protected com.huawei.www.hss._EnumType localCFNRY_NFS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRY_NFSTracker = false;

    /**
     * field for CFNRY_NCS
     */
    protected com.huawei.www.hss._EnumType localCFNRY_NCS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRY_NCSTracker = false;

    /**
     * field for CFNRY_COU
     */
    protected com.huawei.www.hss._EnumType localCFNRY_COU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRY_COUTracker = false;

    /**
     * field for CFNRY_FTN
     */
    protected com.huawei.www.hss.Str1_16 localCFNRY_FTN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRY_FTNTracker = false;

    /**
     * field for CFNRY_BSG
     */
    protected com.huawei.www.hss._EnumType localCFNRY_BSG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRY_BSGTracker = false;

    /**
     * field for CFNRY_STATUS
     */
    protected com.huawei.www.hss._EnumType localCFNRY_STATUS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRY_STATUSTracker = false;

    /**
     * field for CFNRY_NOTREPLYTIME
     */
    protected com.huawei.www.hss.Int0_65534 localCFNRY_NOTREPLYTIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRY_NOTREPLYTIMETracker = false;

    /**
     * field for CFNRC_NCS
     */
    protected com.huawei.www.hss._EnumType localCFNRC_NCS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRC_NCSTracker = false;

    /**
     * field for CFNRC_COU
     */
    protected com.huawei.www.hss._EnumType localCFNRC_COU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRC_COUTracker = false;

    /**
     * field for CFNRC_FTN
     */
    protected com.huawei.www.hss.Str1_16 localCFNRC_FTN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRC_FTNTracker = false;

    /**
     * field for CFNRC_BSG
     */
    protected com.huawei.www.hss._EnumType localCFNRC_BSG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRC_BSGTracker = false;

    /**
     * field for CFNRC_STATUS
     */
    protected com.huawei.www.hss._EnumType localCFNRC_STATUS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRC_STATUSTracker = false;

    /**
     * field for CFD_NFS
     */
    protected com.huawei.www.hss._EnumType localCFD_NFS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_NFSTracker = false;

    /**
     * field for CFD_NCS
     */
    protected com.huawei.www.hss._EnumType localCFD_NCS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_NCSTracker = false;

    /**
     * field for CFD_COU
     */
    protected com.huawei.www.hss._EnumType localCFD_COU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_COUTracker = false;

    /**
     * field for CFD_FTN
     */
    protected com.huawei.www.hss.Str1_16 localCFD_FTN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_FTNTracker = false;

    /**
     * field for CFD_BSG
     */
    protected com.huawei.www.hss._EnumType localCFD_BSG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_BSGTracker = false;

    /**
     * field for CFD_STATUS
     */
    protected com.huawei.www.hss._EnumType localCFD_STATUS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_STATUSTracker = false;

    /**
     * field for CFD_SUPINTERCFD
     */
    protected com.huawei.www.hss._EnumType localCFD_SUPINTERCFD;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_SUPINTERCFDTracker = false;

    /**
     * field for CFD_NOTREPLYTIME
     */
    protected com.huawei.www.hss.Int0_65534 localCFD_NOTREPLYTIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_NOTREPLYTIMETracker = false;

    /**
     * field for CFD_VALIDCCF
     */
    protected com.huawei.www.hss._EnumType localCFD_VALIDCCF;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_VALIDCCFTracker = false;

    /**
     * field for CFD_SHORTNUM
     */
    protected com.huawei.www.hss._EnumType localCFD_SHORTNUM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_SHORTNUMTracker = false;

    /**
     * field for CFD_CFB_FTN
     */
    protected com.huawei.www.hss.Str1_16 localCFD_CFB_FTN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_CFB_FTNTracker = false;

    /**
     * field for CFD_CFB_BSG
     */
    protected com.huawei.www.hss._EnumType localCFD_CFB_BSG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_CFB_BSGTracker = false;

    /**
     * field for CFD_CFB_STATUS
     */
    protected com.huawei.www.hss._EnumType localCFD_CFB_STATUS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_CFB_STATUSTracker = false;

    /**
     * field for CFD_CFB_NotReplyTime
     */
    protected com.huawei.www.hss.Int0_65534 localCFD_CFB_NotReplyTime;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_CFB_NotReplyTimeTracker = false;

    /**
     * field for CFD_CFNRY_FTN
     */
    protected com.huawei.www.hss.Str1_16 localCFD_CFNRY_FTN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_CFNRY_FTNTracker = false;

    /**
     * field for CFD_CFNRY_BSG
     */
    protected com.huawei.www.hss._EnumType localCFD_CFNRY_BSG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_CFNRY_BSGTracker = false;

    /**
     * field for CFD_CFNRY_STATUS
     */
    protected com.huawei.www.hss._EnumType localCFD_CFNRY_STATUS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_CFNRY_STATUSTracker = false;

    /**
     * field for CFD_CFNRY_NotReplyTime
     */
    protected com.huawei.www.hss.Int0_65534 localCFD_CFNRY_NotReplyTime;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_CFNRY_NotReplyTimeTracker = false;

    /**
     * field for CFD_CFNRC_FTN
     */
    protected com.huawei.www.hss.Str1_16 localCFD_CFNRC_FTN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_CFNRC_FTNTracker = false;

    /**
     * field for CFD_CFBNRC_BSG
     */
    protected com.huawei.www.hss._EnumType localCFD_CFBNRC_BSG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_CFBNRC_BSGTracker = false;

    /**
     * field for CFD_CFBNRC_STATUS
     */
    protected com.huawei.www.hss._EnumType localCFD_CFBNRC_STATUS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_CFBNRC_STATUSTracker = false;

    /**
     * field for CFD_CFNRC_NotReplyTime
     */
    protected com.huawei.www.hss.Int0_65534 localCFD_CFNRC_NotReplyTime;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFD_CFNRC_NotReplyTimeTracker = false;

    public boolean isIMSISpecified() {
        return localIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getIMSI() {
        return localIMSI;
    }

    /**
     * Auto generated setter method
     * @param param IMSI
     */
    public void setIMSI(com.huawei.www.hss.Str6_15 param) {
        localIMSITracker = param != null;

        this.localIMSI = param;
    }

    public boolean isISDNSpecified() {
        return localISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getISDN() {
        return localISDN;
    }

    /**
     * Auto generated setter method
     * @param param ISDN
     */
    public void setISDN(com.huawei.www.hss.Str1_15 param) {
        localISDNTracker = param != null;

        this.localISDN = param;
    }

    public boolean isCFU_OFATPLIDSpecified() {
        return localCFU_OFATPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFU_OFATPLID() {
        return localCFU_OFATPLID;
    }

    /**
     * Auto generated setter method
     * @param param CFU_OFATPLID
     */
    public void setCFU_OFATPLID(com.huawei.www.hss.Int0_65534 param) {
        localCFU_OFATPLIDTracker = param != null;

        this.localCFU_OFATPLID = param;
    }

    public boolean isCFB_OFATPLIDSpecified() {
        return localCFB_OFATPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFB_OFATPLID() {
        return localCFB_OFATPLID;
    }

    /**
     * Auto generated setter method
     * @param param CFB_OFATPLID
     */
    public void setCFB_OFATPLID(com.huawei.www.hss.Int0_65534 param) {
        localCFB_OFATPLIDTracker = param != null;

        this.localCFB_OFATPLID = param;
    }

    public boolean isCFNRY_OFATPLIDSpecified() {
        return localCFNRY_OFATPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFNRY_OFATPLID() {
        return localCFNRY_OFATPLID;
    }

    /**
     * Auto generated setter method
     * @param param CFNRY_OFATPLID
     */
    public void setCFNRY_OFATPLID(com.huawei.www.hss.Int0_65534 param) {
        localCFNRY_OFATPLIDTracker = param != null;

        this.localCFNRY_OFATPLID = param;
    }

    public boolean isCFNRC_OFATPLIDSpecified() {
        return localCFNRC_OFATPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFNRC_OFATPLID() {
        return localCFNRC_OFATPLID;
    }

    /**
     * Auto generated setter method
     * @param param CFNRC_OFATPLID
     */
    public void setCFNRC_OFATPLID(com.huawei.www.hss.Int0_65534 param) {
        localCFNRC_OFATPLIDTracker = param != null;

        this.localCFNRC_OFATPLID = param;
    }

    public boolean isCFD_OFATPLIDSpecified() {
        return localCFD_OFATPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFD_OFATPLID() {
        return localCFD_OFATPLID;
    }

    /**
     * Auto generated setter method
     * @param param CFD_OFATPLID
     */
    public void setCFD_OFATPLID(com.huawei.www.hss.Int0_65534 param) {
        localCFD_OFATPLIDTracker = param != null;

        this.localCFD_OFATPLID = param;
    }

    public boolean isCFU_NFSSpecified() {
        return localCFU_NFSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFU_NFS() {
        return localCFU_NFS;
    }

    /**
     * Auto generated setter method
     * @param param CFU_NFS
     */
    public void setCFU_NFS(com.huawei.www.hss._EnumType param) {
        localCFU_NFSTracker = param != null;

        this.localCFU_NFS = param;
    }

    public boolean isCFU_NCSSpecified() {
        return localCFU_NCSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFU_NCS() {
        return localCFU_NCS;
    }

    /**
     * Auto generated setter method
     * @param param CFU_NCS
     */
    public void setCFU_NCS(com.huawei.www.hss._EnumType param) {
        localCFU_NCSTracker = param != null;

        this.localCFU_NCS = param;
    }

    public boolean isCFU_COUSpecified() {
        return localCFU_COUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFU_COU() {
        return localCFU_COU;
    }

    /**
     * Auto generated setter method
     * @param param CFU_COU
     */
    public void setCFU_COU(com.huawei.www.hss._EnumType param) {
        localCFU_COUTracker = param != null;

        this.localCFU_COU = param;
    }

    public boolean isCFU_FTNSpecified() {
        return localCFU_FTNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getCFU_FTN() {
        return localCFU_FTN;
    }

    /**
     * Auto generated setter method
     * @param param CFU_FTN
     */
    public void setCFU_FTN(com.huawei.www.hss.Str1_16 param) {
        localCFU_FTNTracker = param != null;

        this.localCFU_FTN = param;
    }

    public boolean isCFU_BSGSpecified() {
        return localCFU_BSGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFU_BSG() {
        return localCFU_BSG;
    }

    /**
     * Auto generated setter method
     * @param param CFU_BSG
     */
    public void setCFU_BSG(com.huawei.www.hss._EnumType param) {
        localCFU_BSGTracker = param != null;

        this.localCFU_BSG = param;
    }

    public boolean isCFU_STATUSSpecified() {
        return localCFU_STATUSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFU_STATUS() {
        return localCFU_STATUS;
    }

    /**
     * Auto generated setter method
     * @param param CFU_STATUS
     */
    public void setCFU_STATUS(com.huawei.www.hss._EnumType param) {
        localCFU_STATUSTracker = param != null;

        this.localCFU_STATUS = param;
    }

    public boolean isCFB_NFSSpecified() {
        return localCFB_NFSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFB_NFS() {
        return localCFB_NFS;
    }

    /**
     * Auto generated setter method
     * @param param CFB_NFS
     */
    public void setCFB_NFS(com.huawei.www.hss._EnumType param) {
        localCFB_NFSTracker = param != null;

        this.localCFB_NFS = param;
    }

    public boolean isCFB_NCSSpecified() {
        return localCFB_NCSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFB_NCS() {
        return localCFB_NCS;
    }

    /**
     * Auto generated setter method
     * @param param CFB_NCS
     */
    public void setCFB_NCS(com.huawei.www.hss._EnumType param) {
        localCFB_NCSTracker = param != null;

        this.localCFB_NCS = param;
    }

    public boolean isCFB_COUSpecified() {
        return localCFB_COUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFB_COU() {
        return localCFB_COU;
    }

    /**
     * Auto generated setter method
     * @param param CFB_COU
     */
    public void setCFB_COU(com.huawei.www.hss._EnumType param) {
        localCFB_COUTracker = param != null;

        this.localCFB_COU = param;
    }

    public boolean isCFB_FTNSpecified() {
        return localCFB_FTNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getCFB_FTN() {
        return localCFB_FTN;
    }

    /**
     * Auto generated setter method
     * @param param CFB_FTN
     */
    public void setCFB_FTN(com.huawei.www.hss.Str1_16 param) {
        localCFB_FTNTracker = param != null;

        this.localCFB_FTN = param;
    }

    public boolean isCFB_BSGSpecified() {
        return localCFB_BSGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFB_BSG() {
        return localCFB_BSG;
    }

    /**
     * Auto generated setter method
     * @param param CFB_BSG
     */
    public void setCFB_BSG(com.huawei.www.hss._EnumType param) {
        localCFB_BSGTracker = param != null;

        this.localCFB_BSG = param;
    }

    public boolean isCFB_STATUSSpecified() {
        return localCFB_STATUSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFB_STATUS() {
        return localCFB_STATUS;
    }

    /**
     * Auto generated setter method
     * @param param CFB_STATUS
     */
    public void setCFB_STATUS(com.huawei.www.hss._EnumType param) {
        localCFB_STATUSTracker = param != null;

        this.localCFB_STATUS = param;
    }

    public boolean isCFNRY_NFSSpecified() {
        return localCFNRY_NFSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRY_NFS() {
        return localCFNRY_NFS;
    }

    /**
     * Auto generated setter method
     * @param param CFNRY_NFS
     */
    public void setCFNRY_NFS(com.huawei.www.hss._EnumType param) {
        localCFNRY_NFSTracker = param != null;

        this.localCFNRY_NFS = param;
    }

    public boolean isCFNRY_NCSSpecified() {
        return localCFNRY_NCSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRY_NCS() {
        return localCFNRY_NCS;
    }

    /**
     * Auto generated setter method
     * @param param CFNRY_NCS
     */
    public void setCFNRY_NCS(com.huawei.www.hss._EnumType param) {
        localCFNRY_NCSTracker = param != null;

        this.localCFNRY_NCS = param;
    }

    public boolean isCFNRY_COUSpecified() {
        return localCFNRY_COUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRY_COU() {
        return localCFNRY_COU;
    }

    /**
     * Auto generated setter method
     * @param param CFNRY_COU
     */
    public void setCFNRY_COU(com.huawei.www.hss._EnumType param) {
        localCFNRY_COUTracker = param != null;

        this.localCFNRY_COU = param;
    }

    public boolean isCFNRY_FTNSpecified() {
        return localCFNRY_FTNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getCFNRY_FTN() {
        return localCFNRY_FTN;
    }

    /**
     * Auto generated setter method
     * @param param CFNRY_FTN
     */
    public void setCFNRY_FTN(com.huawei.www.hss.Str1_16 param) {
        localCFNRY_FTNTracker = param != null;

        this.localCFNRY_FTN = param;
    }

    public boolean isCFNRY_BSGSpecified() {
        return localCFNRY_BSGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRY_BSG() {
        return localCFNRY_BSG;
    }

    /**
     * Auto generated setter method
     * @param param CFNRY_BSG
     */
    public void setCFNRY_BSG(com.huawei.www.hss._EnumType param) {
        localCFNRY_BSGTracker = param != null;

        this.localCFNRY_BSG = param;
    }

    public boolean isCFNRY_STATUSSpecified() {
        return localCFNRY_STATUSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRY_STATUS() {
        return localCFNRY_STATUS;
    }

    /**
     * Auto generated setter method
     * @param param CFNRY_STATUS
     */
    public void setCFNRY_STATUS(com.huawei.www.hss._EnumType param) {
        localCFNRY_STATUSTracker = param != null;

        this.localCFNRY_STATUS = param;
    }

    public boolean isCFNRY_NOTREPLYTIMESpecified() {
        return localCFNRY_NOTREPLYTIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFNRY_NOTREPLYTIME() {
        return localCFNRY_NOTREPLYTIME;
    }

    /**
     * Auto generated setter method
     * @param param CFNRY_NOTREPLYTIME
     */
    public void setCFNRY_NOTREPLYTIME(com.huawei.www.hss.Int0_65534 param) {
        localCFNRY_NOTREPLYTIMETracker = param != null;

        this.localCFNRY_NOTREPLYTIME = param;
    }

    public boolean isCFNRC_NCSSpecified() {
        return localCFNRC_NCSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRC_NCS() {
        return localCFNRC_NCS;
    }

    /**
     * Auto generated setter method
     * @param param CFNRC_NCS
     */
    public void setCFNRC_NCS(com.huawei.www.hss._EnumType param) {
        localCFNRC_NCSTracker = param != null;

        this.localCFNRC_NCS = param;
    }

    public boolean isCFNRC_COUSpecified() {
        return localCFNRC_COUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRC_COU() {
        return localCFNRC_COU;
    }

    /**
     * Auto generated setter method
     * @param param CFNRC_COU
     */
    public void setCFNRC_COU(com.huawei.www.hss._EnumType param) {
        localCFNRC_COUTracker = param != null;

        this.localCFNRC_COU = param;
    }

    public boolean isCFNRC_FTNSpecified() {
        return localCFNRC_FTNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getCFNRC_FTN() {
        return localCFNRC_FTN;
    }

    /**
     * Auto generated setter method
     * @param param CFNRC_FTN
     */
    public void setCFNRC_FTN(com.huawei.www.hss.Str1_16 param) {
        localCFNRC_FTNTracker = param != null;

        this.localCFNRC_FTN = param;
    }

    public boolean isCFNRC_BSGSpecified() {
        return localCFNRC_BSGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRC_BSG() {
        return localCFNRC_BSG;
    }

    /**
     * Auto generated setter method
     * @param param CFNRC_BSG
     */
    public void setCFNRC_BSG(com.huawei.www.hss._EnumType param) {
        localCFNRC_BSGTracker = param != null;

        this.localCFNRC_BSG = param;
    }

    public boolean isCFNRC_STATUSSpecified() {
        return localCFNRC_STATUSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRC_STATUS() {
        return localCFNRC_STATUS;
    }

    /**
     * Auto generated setter method
     * @param param CFNRC_STATUS
     */
    public void setCFNRC_STATUS(com.huawei.www.hss._EnumType param) {
        localCFNRC_STATUSTracker = param != null;

        this.localCFNRC_STATUS = param;
    }

    public boolean isCFD_NFSSpecified() {
        return localCFD_NFSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_NFS() {
        return localCFD_NFS;
    }

    /**
     * Auto generated setter method
     * @param param CFD_NFS
     */
    public void setCFD_NFS(com.huawei.www.hss._EnumType param) {
        localCFD_NFSTracker = param != null;

        this.localCFD_NFS = param;
    }

    public boolean isCFD_NCSSpecified() {
        return localCFD_NCSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_NCS() {
        return localCFD_NCS;
    }

    /**
     * Auto generated setter method
     * @param param CFD_NCS
     */
    public void setCFD_NCS(com.huawei.www.hss._EnumType param) {
        localCFD_NCSTracker = param != null;

        this.localCFD_NCS = param;
    }

    public boolean isCFD_COUSpecified() {
        return localCFD_COUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_COU() {
        return localCFD_COU;
    }

    /**
     * Auto generated setter method
     * @param param CFD_COU
     */
    public void setCFD_COU(com.huawei.www.hss._EnumType param) {
        localCFD_COUTracker = param != null;

        this.localCFD_COU = param;
    }

    public boolean isCFD_FTNSpecified() {
        return localCFD_FTNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getCFD_FTN() {
        return localCFD_FTN;
    }

    /**
     * Auto generated setter method
     * @param param CFD_FTN
     */
    public void setCFD_FTN(com.huawei.www.hss.Str1_16 param) {
        localCFD_FTNTracker = param != null;

        this.localCFD_FTN = param;
    }

    public boolean isCFD_BSGSpecified() {
        return localCFD_BSGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_BSG() {
        return localCFD_BSG;
    }

    /**
     * Auto generated setter method
     * @param param CFD_BSG
     */
    public void setCFD_BSG(com.huawei.www.hss._EnumType param) {
        localCFD_BSGTracker = param != null;

        this.localCFD_BSG = param;
    }

    public boolean isCFD_STATUSSpecified() {
        return localCFD_STATUSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_STATUS() {
        return localCFD_STATUS;
    }

    /**
     * Auto generated setter method
     * @param param CFD_STATUS
     */
    public void setCFD_STATUS(com.huawei.www.hss._EnumType param) {
        localCFD_STATUSTracker = param != null;

        this.localCFD_STATUS = param;
    }

    public boolean isCFD_SUPINTERCFDSpecified() {
        return localCFD_SUPINTERCFDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_SUPINTERCFD() {
        return localCFD_SUPINTERCFD;
    }

    /**
     * Auto generated setter method
     * @param param CFD_SUPINTERCFD
     */
    public void setCFD_SUPINTERCFD(com.huawei.www.hss._EnumType param) {
        localCFD_SUPINTERCFDTracker = param != null;

        this.localCFD_SUPINTERCFD = param;
    }

    public boolean isCFD_NOTREPLYTIMESpecified() {
        return localCFD_NOTREPLYTIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFD_NOTREPLYTIME() {
        return localCFD_NOTREPLYTIME;
    }

    /**
     * Auto generated setter method
     * @param param CFD_NOTREPLYTIME
     */
    public void setCFD_NOTREPLYTIME(com.huawei.www.hss.Int0_65534 param) {
        localCFD_NOTREPLYTIMETracker = param != null;

        this.localCFD_NOTREPLYTIME = param;
    }

    public boolean isCFD_VALIDCCFSpecified() {
        return localCFD_VALIDCCFTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_VALIDCCF() {
        return localCFD_VALIDCCF;
    }

    /**
     * Auto generated setter method
     * @param param CFD_VALIDCCF
     */
    public void setCFD_VALIDCCF(com.huawei.www.hss._EnumType param) {
        localCFD_VALIDCCFTracker = param != null;

        this.localCFD_VALIDCCF = param;
    }

    public boolean isCFD_SHORTNUMSpecified() {
        return localCFD_SHORTNUMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_SHORTNUM() {
        return localCFD_SHORTNUM;
    }

    /**
     * Auto generated setter method
     * @param param CFD_SHORTNUM
     */
    public void setCFD_SHORTNUM(com.huawei.www.hss._EnumType param) {
        localCFD_SHORTNUMTracker = param != null;

        this.localCFD_SHORTNUM = param;
    }

    public boolean isCFD_CFB_FTNSpecified() {
        return localCFD_CFB_FTNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getCFD_CFB_FTN() {
        return localCFD_CFB_FTN;
    }

    /**
     * Auto generated setter method
     * @param param CFD_CFB_FTN
     */
    public void setCFD_CFB_FTN(com.huawei.www.hss.Str1_16 param) {
        localCFD_CFB_FTNTracker = param != null;

        this.localCFD_CFB_FTN = param;
    }

    public boolean isCFD_CFB_BSGSpecified() {
        return localCFD_CFB_BSGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_CFB_BSG() {
        return localCFD_CFB_BSG;
    }

    /**
     * Auto generated setter method
     * @param param CFD_CFB_BSG
     */
    public void setCFD_CFB_BSG(com.huawei.www.hss._EnumType param) {
        localCFD_CFB_BSGTracker = param != null;

        this.localCFD_CFB_BSG = param;
    }

    public boolean isCFD_CFB_STATUSSpecified() {
        return localCFD_CFB_STATUSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_CFB_STATUS() {
        return localCFD_CFB_STATUS;
    }

    /**
     * Auto generated setter method
     * @param param CFD_CFB_STATUS
     */
    public void setCFD_CFB_STATUS(com.huawei.www.hss._EnumType param) {
        localCFD_CFB_STATUSTracker = param != null;

        this.localCFD_CFB_STATUS = param;
    }

    public boolean isCFD_CFB_NotReplyTimeSpecified() {
        return localCFD_CFB_NotReplyTimeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFD_CFB_NotReplyTime() {
        return localCFD_CFB_NotReplyTime;
    }

    /**
     * Auto generated setter method
     * @param param CFD_CFB_NotReplyTime
     */
    public void setCFD_CFB_NotReplyTime(com.huawei.www.hss.Int0_65534 param) {
        localCFD_CFB_NotReplyTimeTracker = param != null;

        this.localCFD_CFB_NotReplyTime = param;
    }

    public boolean isCFD_CFNRY_FTNSpecified() {
        return localCFD_CFNRY_FTNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getCFD_CFNRY_FTN() {
        return localCFD_CFNRY_FTN;
    }

    /**
     * Auto generated setter method
     * @param param CFD_CFNRY_FTN
     */
    public void setCFD_CFNRY_FTN(com.huawei.www.hss.Str1_16 param) {
        localCFD_CFNRY_FTNTracker = param != null;

        this.localCFD_CFNRY_FTN = param;
    }

    public boolean isCFD_CFNRY_BSGSpecified() {
        return localCFD_CFNRY_BSGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_CFNRY_BSG() {
        return localCFD_CFNRY_BSG;
    }

    /**
     * Auto generated setter method
     * @param param CFD_CFNRY_BSG
     */
    public void setCFD_CFNRY_BSG(com.huawei.www.hss._EnumType param) {
        localCFD_CFNRY_BSGTracker = param != null;

        this.localCFD_CFNRY_BSG = param;
    }

    public boolean isCFD_CFNRY_STATUSSpecified() {
        return localCFD_CFNRY_STATUSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_CFNRY_STATUS() {
        return localCFD_CFNRY_STATUS;
    }

    /**
     * Auto generated setter method
     * @param param CFD_CFNRY_STATUS
     */
    public void setCFD_CFNRY_STATUS(com.huawei.www.hss._EnumType param) {
        localCFD_CFNRY_STATUSTracker = param != null;

        this.localCFD_CFNRY_STATUS = param;
    }

    public boolean isCFD_CFNRY_NotReplyTimeSpecified() {
        return localCFD_CFNRY_NotReplyTimeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFD_CFNRY_NotReplyTime() {
        return localCFD_CFNRY_NotReplyTime;
    }

    /**
     * Auto generated setter method
     * @param param CFD_CFNRY_NotReplyTime
     */
    public void setCFD_CFNRY_NotReplyTime(com.huawei.www.hss.Int0_65534 param) {
        localCFD_CFNRY_NotReplyTimeTracker = param != null;

        this.localCFD_CFNRY_NotReplyTime = param;
    }

    public boolean isCFD_CFNRC_FTNSpecified() {
        return localCFD_CFNRC_FTNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getCFD_CFNRC_FTN() {
        return localCFD_CFNRC_FTN;
    }

    /**
     * Auto generated setter method
     * @param param CFD_CFNRC_FTN
     */
    public void setCFD_CFNRC_FTN(com.huawei.www.hss.Str1_16 param) {
        localCFD_CFNRC_FTNTracker = param != null;

        this.localCFD_CFNRC_FTN = param;
    }

    public boolean isCFD_CFBNRC_BSGSpecified() {
        return localCFD_CFBNRC_BSGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_CFBNRC_BSG() {
        return localCFD_CFBNRC_BSG;
    }

    /**
     * Auto generated setter method
     * @param param CFD_CFBNRC_BSG
     */
    public void setCFD_CFBNRC_BSG(com.huawei.www.hss._EnumType param) {
        localCFD_CFBNRC_BSGTracker = param != null;

        this.localCFD_CFBNRC_BSG = param;
    }

    public boolean isCFD_CFBNRC_STATUSSpecified() {
        return localCFD_CFBNRC_STATUSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD_CFBNRC_STATUS() {
        return localCFD_CFBNRC_STATUS;
    }

    /**
     * Auto generated setter method
     * @param param CFD_CFBNRC_STATUS
     */
    public void setCFD_CFBNRC_STATUS(com.huawei.www.hss._EnumType param) {
        localCFD_CFBNRC_STATUSTracker = param != null;

        this.localCFD_CFBNRC_STATUS = param;
    }

    public boolean isCFD_CFNRC_NotReplyTimeSpecified() {
        return localCFD_CFNRC_NotReplyTimeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFD_CFNRC_NotReplyTime() {
        return localCFD_CFNRC_NotReplyTime;
    }

    /**
     * Auto generated setter method
     * @param param CFD_CFNRC_NotReplyTime
     */
    public void setCFD_CFNRC_NotReplyTime(com.huawei.www.hss.Int0_65534 param) {
        localCFD_CFNRC_NotReplyTimeTracker = param != null;

        this.localCFD_CFNRC_NotReplyTime = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":LST_CFALLStruct1", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "LST_CFALLStruct1", xmlWriter);
            }
        }

        if (localIMSITracker) {
            if (localIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMSI cannot be null!!");
            }

            localIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMSI"), xmlWriter);
        }

        if (localISDNTracker) {
            if (localISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ISDN cannot be null!!");
            }

            localISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ISDN"), xmlWriter);
        }

        if (localCFU_OFATPLIDTracker) {
            if (localCFU_OFATPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFU_OFATPLID cannot be null!!");
            }

            localCFU_OFATPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFU_OFATPLID"), xmlWriter);
        }

        if (localCFB_OFATPLIDTracker) {
            if (localCFB_OFATPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFB_OFATPLID cannot be null!!");
            }

            localCFB_OFATPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFB_OFATPLID"), xmlWriter);
        }

        if (localCFNRY_OFATPLIDTracker) {
            if (localCFNRY_OFATPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRY_OFATPLID cannot be null!!");
            }

            localCFNRY_OFATPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRY_OFATPLID"), xmlWriter);
        }

        if (localCFNRC_OFATPLIDTracker) {
            if (localCFNRC_OFATPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRC_OFATPLID cannot be null!!");
            }

            localCFNRC_OFATPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRC_OFATPLID"), xmlWriter);
        }

        if (localCFD_OFATPLIDTracker) {
            if (localCFD_OFATPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_OFATPLID cannot be null!!");
            }

            localCFD_OFATPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_OFATPLID"), xmlWriter);
        }

        if (localCFU_NFSTracker) {
            if (localCFU_NFS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFU_NFS cannot be null!!");
            }

            localCFU_NFS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFU_NFS"), xmlWriter);
        }

        if (localCFU_NCSTracker) {
            if (localCFU_NCS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFU_NCS cannot be null!!");
            }

            localCFU_NCS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFU_NCS"), xmlWriter);
        }

        if (localCFU_COUTracker) {
            if (localCFU_COU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFU_COU cannot be null!!");
            }

            localCFU_COU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFU_COU"), xmlWriter);
        }

        if (localCFU_FTNTracker) {
            if (localCFU_FTN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFU_FTN cannot be null!!");
            }

            localCFU_FTN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFU_FTN"), xmlWriter);
        }

        if (localCFU_BSGTracker) {
            if (localCFU_BSG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFU_BSG cannot be null!!");
            }

            localCFU_BSG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFU_BSG"), xmlWriter);
        }

        if (localCFU_STATUSTracker) {
            if (localCFU_STATUS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFU_STATUS cannot be null!!");
            }

            localCFU_STATUS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFU_STATUS"), xmlWriter);
        }

        if (localCFB_NFSTracker) {
            if (localCFB_NFS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFB_NFS cannot be null!!");
            }

            localCFB_NFS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFB_NFS"), xmlWriter);
        }

        if (localCFB_NCSTracker) {
            if (localCFB_NCS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFB_NCS cannot be null!!");
            }

            localCFB_NCS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFB_NCS"), xmlWriter);
        }

        if (localCFB_COUTracker) {
            if (localCFB_COU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFB_COU cannot be null!!");
            }

            localCFB_COU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFB_COU"), xmlWriter);
        }

        if (localCFB_FTNTracker) {
            if (localCFB_FTN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFB_FTN cannot be null!!");
            }

            localCFB_FTN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFB_FTN"), xmlWriter);
        }

        if (localCFB_BSGTracker) {
            if (localCFB_BSG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFB_BSG cannot be null!!");
            }

            localCFB_BSG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFB_BSG"), xmlWriter);
        }

        if (localCFB_STATUSTracker) {
            if (localCFB_STATUS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFB_STATUS cannot be null!!");
            }

            localCFB_STATUS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFB_STATUS"), xmlWriter);
        }

        if (localCFNRY_NFSTracker) {
            if (localCFNRY_NFS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRY_NFS cannot be null!!");
            }

            localCFNRY_NFS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRY_NFS"), xmlWriter);
        }

        if (localCFNRY_NCSTracker) {
            if (localCFNRY_NCS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRY_NCS cannot be null!!");
            }

            localCFNRY_NCS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRY_NCS"), xmlWriter);
        }

        if (localCFNRY_COUTracker) {
            if (localCFNRY_COU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRY_COU cannot be null!!");
            }

            localCFNRY_COU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRY_COU"), xmlWriter);
        }

        if (localCFNRY_FTNTracker) {
            if (localCFNRY_FTN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRY_FTN cannot be null!!");
            }

            localCFNRY_FTN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRY_FTN"), xmlWriter);
        }

        if (localCFNRY_BSGTracker) {
            if (localCFNRY_BSG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRY_BSG cannot be null!!");
            }

            localCFNRY_BSG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRY_BSG"), xmlWriter);
        }

        if (localCFNRY_STATUSTracker) {
            if (localCFNRY_STATUS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRY_STATUS cannot be null!!");
            }

            localCFNRY_STATUS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRY_STATUS"), xmlWriter);
        }

        if (localCFNRY_NOTREPLYTIMETracker) {
            if (localCFNRY_NOTREPLYTIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRY_NOTREPLYTIME cannot be null!!");
            }

            localCFNRY_NOTREPLYTIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRY_NOTREPLYTIME"),
                xmlWriter);
        }

        if (localCFNRC_NCSTracker) {
            if (localCFNRC_NCS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRC_NCS cannot be null!!");
            }

            localCFNRC_NCS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRC_NCS"), xmlWriter);
        }

        if (localCFNRC_COUTracker) {
            if (localCFNRC_COU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRC_COU cannot be null!!");
            }

            localCFNRC_COU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRC_COU"), xmlWriter);
        }

        if (localCFNRC_FTNTracker) {
            if (localCFNRC_FTN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRC_FTN cannot be null!!");
            }

            localCFNRC_FTN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRC_FTN"), xmlWriter);
        }

        if (localCFNRC_BSGTracker) {
            if (localCFNRC_BSG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRC_BSG cannot be null!!");
            }

            localCFNRC_BSG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRC_BSG"), xmlWriter);
        }

        if (localCFNRC_STATUSTracker) {
            if (localCFNRC_STATUS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRC_STATUS cannot be null!!");
            }

            localCFNRC_STATUS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRC_STATUS"), xmlWriter);
        }

        if (localCFD_NFSTracker) {
            if (localCFD_NFS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_NFS cannot be null!!");
            }

            localCFD_NFS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_NFS"), xmlWriter);
        }

        if (localCFD_NCSTracker) {
            if (localCFD_NCS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_NCS cannot be null!!");
            }

            localCFD_NCS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_NCS"), xmlWriter);
        }

        if (localCFD_COUTracker) {
            if (localCFD_COU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_COU cannot be null!!");
            }

            localCFD_COU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_COU"), xmlWriter);
        }

        if (localCFD_FTNTracker) {
            if (localCFD_FTN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_FTN cannot be null!!");
            }

            localCFD_FTN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_FTN"), xmlWriter);
        }

        if (localCFD_BSGTracker) {
            if (localCFD_BSG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_BSG cannot be null!!");
            }

            localCFD_BSG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_BSG"), xmlWriter);
        }

        if (localCFD_STATUSTracker) {
            if (localCFD_STATUS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_STATUS cannot be null!!");
            }

            localCFD_STATUS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_STATUS"), xmlWriter);
        }

        if (localCFD_SUPINTERCFDTracker) {
            if (localCFD_SUPINTERCFD == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_SUPINTERCFD cannot be null!!");
            }

            localCFD_SUPINTERCFD.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_SUPINTERCFD"), xmlWriter);
        }

        if (localCFD_NOTREPLYTIMETracker) {
            if (localCFD_NOTREPLYTIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_NOTREPLYTIME cannot be null!!");
            }

            localCFD_NOTREPLYTIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_NOTREPLYTIME"), xmlWriter);
        }

        if (localCFD_VALIDCCFTracker) {
            if (localCFD_VALIDCCF == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_VALIDCCF cannot be null!!");
            }

            localCFD_VALIDCCF.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_VALIDCCF"), xmlWriter);
        }

        if (localCFD_SHORTNUMTracker) {
            if (localCFD_SHORTNUM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_SHORTNUM cannot be null!!");
            }

            localCFD_SHORTNUM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_SHORTNUM"), xmlWriter);
        }

        if (localCFD_CFB_FTNTracker) {
            if (localCFD_CFB_FTN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_CFB_FTN cannot be null!!");
            }

            localCFD_CFB_FTN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_CFB_FTN"), xmlWriter);
        }

        if (localCFD_CFB_BSGTracker) {
            if (localCFD_CFB_BSG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_CFB_BSG cannot be null!!");
            }

            localCFD_CFB_BSG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_CFB_BSG"), xmlWriter);
        }

        if (localCFD_CFB_STATUSTracker) {
            if (localCFD_CFB_STATUS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_CFB_STATUS cannot be null!!");
            }

            localCFD_CFB_STATUS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_CFB_STATUS"), xmlWriter);
        }

        if (localCFD_CFB_NotReplyTimeTracker) {
            if (localCFD_CFB_NotReplyTime == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_CFB_NotReplyTime cannot be null!!");
            }

            localCFD_CFB_NotReplyTime.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_CFB_NotReplyTime"),
                xmlWriter);
        }

        if (localCFD_CFNRY_FTNTracker) {
            if (localCFD_CFNRY_FTN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_CFNRY_FTN cannot be null!!");
            }

            localCFD_CFNRY_FTN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_CFNRY_FTN"), xmlWriter);
        }

        if (localCFD_CFNRY_BSGTracker) {
            if (localCFD_CFNRY_BSG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_CFNRY_BSG cannot be null!!");
            }

            localCFD_CFNRY_BSG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_CFNRY_BSG"), xmlWriter);
        }

        if (localCFD_CFNRY_STATUSTracker) {
            if (localCFD_CFNRY_STATUS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_CFNRY_STATUS cannot be null!!");
            }

            localCFD_CFNRY_STATUS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_CFNRY_STATUS"), xmlWriter);
        }

        if (localCFD_CFNRY_NotReplyTimeTracker) {
            if (localCFD_CFNRY_NotReplyTime == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_CFNRY_NotReplyTime cannot be null!!");
            }

            localCFD_CFNRY_NotReplyTime.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_CFNRY_NotReplyTime"),
                xmlWriter);
        }

        if (localCFD_CFNRC_FTNTracker) {
            if (localCFD_CFNRC_FTN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_CFNRC_FTN cannot be null!!");
            }

            localCFD_CFNRC_FTN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_CFNRC_FTN"), xmlWriter);
        }

        if (localCFD_CFBNRC_BSGTracker) {
            if (localCFD_CFBNRC_BSG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_CFBNRC_BSG cannot be null!!");
            }

            localCFD_CFBNRC_BSG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_CFBNRC_BSG"), xmlWriter);
        }

        if (localCFD_CFBNRC_STATUSTracker) {
            if (localCFD_CFBNRC_STATUS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_CFBNRC_STATUS cannot be null!!");
            }

            localCFD_CFBNRC_STATUS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_CFBNRC_STATUS"), xmlWriter);
        }

        if (localCFD_CFNRC_NotReplyTimeTracker) {
            if (localCFD_CFNRC_NotReplyTime == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD_CFNRC_NotReplyTime cannot be null!!");
            }

            localCFD_CFNRC_NotReplyTime.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD_CFNRC_NotReplyTime"),
                xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static LST_CFALLStruct1 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            LST_CFALLStruct1 object = new LST_CFALLStruct1();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"LST_CFALLStruct1".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (LST_CFALLStruct1) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSI").equals(
                            reader.getName())) {
                    object.setIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ISDN").equals(
                            reader.getName())) {
                    object.setISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFU_OFATPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFU_OFATPLID").equals(
                            reader.getName())) {
                    object.setCFU_OFATPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFB_OFATPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFB_OFATPLID").equals(
                            reader.getName())) {
                    object.setCFB_OFATPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRY_OFATPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRY_OFATPLID").equals(
                            reader.getName())) {
                    object.setCFNRY_OFATPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRC_OFATPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRC_OFATPLID").equals(
                            reader.getName())) {
                    object.setCFNRC_OFATPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_OFATPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_OFATPLID").equals(
                            reader.getName())) {
                    object.setCFD_OFATPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFU_NFS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFU_NFS").equals(
                            reader.getName())) {
                    object.setCFU_NFS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFU_NCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFU_NCS").equals(
                            reader.getName())) {
                    object.setCFU_NCS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFU_COU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFU_COU").equals(
                            reader.getName())) {
                    object.setCFU_COU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFU_FTN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFU_FTN").equals(
                            reader.getName())) {
                    object.setCFU_FTN(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFU_BSG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFU_BSG").equals(
                            reader.getName())) {
                    object.setCFU_BSG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFU_STATUS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFU_STATUS").equals(
                            reader.getName())) {
                    object.setCFU_STATUS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFB_NFS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFB_NFS").equals(
                            reader.getName())) {
                    object.setCFB_NFS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFB_NCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFB_NCS").equals(
                            reader.getName())) {
                    object.setCFB_NCS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFB_COU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFB_COU").equals(
                            reader.getName())) {
                    object.setCFB_COU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFB_FTN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFB_FTN").equals(
                            reader.getName())) {
                    object.setCFB_FTN(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFB_BSG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFB_BSG").equals(
                            reader.getName())) {
                    object.setCFB_BSG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFB_STATUS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFB_STATUS").equals(
                            reader.getName())) {
                    object.setCFB_STATUS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRY_NFS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRY_NFS").equals(
                            reader.getName())) {
                    object.setCFNRY_NFS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRY_NCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRY_NCS").equals(
                            reader.getName())) {
                    object.setCFNRY_NCS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRY_COU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRY_COU").equals(
                            reader.getName())) {
                    object.setCFNRY_COU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRY_FTN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRY_FTN").equals(
                            reader.getName())) {
                    object.setCFNRY_FTN(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRY_BSG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRY_BSG").equals(
                            reader.getName())) {
                    object.setCFNRY_BSG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRY_STATUS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRY_STATUS").equals(
                            reader.getName())) {
                    object.setCFNRY_STATUS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRY_NOTREPLYTIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRY_NOTREPLYTIME").equals(
                            reader.getName())) {
                    object.setCFNRY_NOTREPLYTIME(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRC_NCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRC_NCS").equals(
                            reader.getName())) {
                    object.setCFNRC_NCS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRC_COU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRC_COU").equals(
                            reader.getName())) {
                    object.setCFNRC_COU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRC_FTN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRC_FTN").equals(
                            reader.getName())) {
                    object.setCFNRC_FTN(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRC_BSG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRC_BSG").equals(
                            reader.getName())) {
                    object.setCFNRC_BSG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRC_STATUS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRC_STATUS").equals(
                            reader.getName())) {
                    object.setCFNRC_STATUS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_NFS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_NFS").equals(
                            reader.getName())) {
                    object.setCFD_NFS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_NCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_NCS").equals(
                            reader.getName())) {
                    object.setCFD_NCS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_COU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_COU").equals(
                            reader.getName())) {
                    object.setCFD_COU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_FTN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_FTN").equals(
                            reader.getName())) {
                    object.setCFD_FTN(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_BSG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_BSG").equals(
                            reader.getName())) {
                    object.setCFD_BSG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_STATUS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_STATUS").equals(
                            reader.getName())) {
                    object.setCFD_STATUS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_SUPINTERCFD").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_SUPINTERCFD").equals(
                            reader.getName())) {
                    object.setCFD_SUPINTERCFD(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_NOTREPLYTIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_NOTREPLYTIME").equals(
                            reader.getName())) {
                    object.setCFD_NOTREPLYTIME(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_VALIDCCF").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_VALIDCCF").equals(
                            reader.getName())) {
                    object.setCFD_VALIDCCF(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_SHORTNUM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_SHORTNUM").equals(
                            reader.getName())) {
                    object.setCFD_SHORTNUM(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_CFB_FTN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_CFB_FTN").equals(
                            reader.getName())) {
                    object.setCFD_CFB_FTN(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_CFB_BSG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_CFB_BSG").equals(
                            reader.getName())) {
                    object.setCFD_CFB_BSG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_CFB_STATUS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_CFB_STATUS").equals(
                            reader.getName())) {
                    object.setCFD_CFB_STATUS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_CFB_NotReplyTime").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_CFB_NotReplyTime").equals(
                            reader.getName())) {
                    object.setCFD_CFB_NotReplyTime(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_CFNRY_FTN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_CFNRY_FTN").equals(
                            reader.getName())) {
                    object.setCFD_CFNRY_FTN(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_CFNRY_BSG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_CFNRY_BSG").equals(
                            reader.getName())) {
                    object.setCFD_CFNRY_BSG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_CFNRY_STATUS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_CFNRY_STATUS").equals(
                            reader.getName())) {
                    object.setCFD_CFNRY_STATUS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "CFD_CFNRY_NotReplyTime").equals(reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "CFD_CFNRY_NotReplyTime").equals(reader.getName())) {
                    object.setCFD_CFNRY_NotReplyTime(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_CFNRC_FTN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_CFNRC_FTN").equals(
                            reader.getName())) {
                    object.setCFD_CFNRC_FTN(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_CFBNRC_BSG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_CFBNRC_BSG").equals(
                            reader.getName())) {
                    object.setCFD_CFBNRC_BSG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD_CFBNRC_STATUS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD_CFBNRC_STATUS").equals(
                            reader.getName())) {
                    object.setCFD_CFBNRC_STATUS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "CFD_CFNRC_NotReplyTime").equals(reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "CFD_CFNRC_NotReplyTime").equals(reader.getName())) {
                    object.setCFD_CFNRC_NotReplyTime(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
