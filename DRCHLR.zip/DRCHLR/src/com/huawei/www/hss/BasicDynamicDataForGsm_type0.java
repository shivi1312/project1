/**
 * BasicDynamicDataForGsm_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  BasicDynamicDataForGsm_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class BasicDynamicDataForGsm_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = BasicDynamicDataForGsm_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for IMEI
     * This was an Array!
     */
    protected com.huawei.www.hss.Str1_16[] localIMEI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMEITracker = false;

    /**
     * field for VlrNum
     */
    protected com.huawei.www.hss.Str1_15 localVlrNum;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVlrNumTracker = false;

    /**
     * field for MscNum
     */
    protected com.huawei.www.hss.Str1_15 localMscNum;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMscNumTracker = false;

    /**
     * field for MsPurgedForNonGprs
     */
    protected com.huawei.www.hss._EnumType localMsPurgedForNonGprs;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMsPurgedForNonGprsTracker = false;

    /**
     * field for VLRInHplmn
     */
    protected com.huawei.www.hss._EnumType localVLRInHplmn;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVLRInHplmnTracker = false;

    /**
     * field for VLRInHomeCountry
     */
    protected com.huawei.www.hss._EnumType localVLRInHomeCountry;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVLRInHomeCountryTracker = false;

    /**
     * field for VLRInArea
     */
    protected com.huawei.www.hss._EnumType localVLRInArea;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVLRInAreaTracker = false;

    /**
     * field for RequireCheckSS
     */
    protected com.huawei.www.hss._EnumType localRequireCheckSS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRequireCheckSSTracker = false;

    /**
     * field for RoamingRestrictInMscDueToUnsupportedFeature
     */
    protected com.huawei.www.hss._EnumType localRoamingRestrictInMscDueToUnsupportedFeature;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRoamingRestrictInMscDueToUnsupportedFeatureTracker = false;

    /**
     * field for MscOrVlrAreaRoamingRestrict
     */
    protected com.huawei.www.hss._EnumType localMscOrVlrAreaRoamingRestrict;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMscOrVlrAreaRoamingRestrictTracker = false;

    /**
     * field for ODBarredForUnsupportedCamel
     */
    protected com.huawei.www.hss._EnumType localODBarredForUnsupportedCamel;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBarredForUnsupportedCamelTracker = false;

    /**
     * field for SupportedCamelPhase1
     */
    protected com.huawei.www.hss._EnumType localSupportedCamelPhase1;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedCamelPhase1Tracker = false;

    /**
     * field for SupportedCamelPhase2
     */
    protected com.huawei.www.hss._EnumType localSupportedCamelPhase2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedCamelPhase2Tracker = false;

    /**
     * field for SupportedCamelPhase3
     */
    protected com.huawei.www.hss._EnumType localSupportedCamelPhase3;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedCamelPhase3Tracker = false;

    /**
     * field for SupportedCamelPhase4
     */
    protected com.huawei.www.hss._EnumType localSupportedCamelPhase4;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedCamelPhase4Tracker = false;

    /**
     * field for SRIMsrnCfActive
     */
    protected com.huawei.www.hss._EnumType localSRIMsrnCfActive;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSRIMsrnCfActiveTracker = false;

    /**
     * field for ZoneCodeStatusAtMsc
     */
    protected com.huawei.www.hss._EnumType localZoneCodeStatusAtMsc;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localZoneCodeStatusAtMscTracker = false;

    /**
     * field for LongGroupIDSupported
     */
    protected com.huawei.www.hss._EnumType localLongGroupIDSupported;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLongGroupIDSupportedTracker = false;

    /**
     * field for BasicISTSupported
     */
    protected com.huawei.www.hss._EnumType localBasicISTSupported;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBasicISTSupportedTracker = false;

    /**
     * field for IstCommandSupported
     */
    protected com.huawei.www.hss._EnumType localIstCommandSupported;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIstCommandSupportedTracker = false;

    /**
     * field for SuperChargerSupportedForGsm
     */
    protected com.huawei.www.hss._EnumType localSuperChargerSupportedForGsm;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSuperChargerSupportedForGsmTracker = false;

    /**
     * field for LMSI
     */
    protected com.huawei.www.hss.Str1_15 localLMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLMSITracker = false;

    /**
     * field for ECATEGORYAtMsc
     */
    protected com.huawei.www.hss._EnumType localECATEGORYAtMsc;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localECATEGORYAtMscTracker = false;

    /**
     * field for CsUplTime
     */
    protected com.huawei.www.hss.Int0_65534 localCsUplTime;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCsUplTimeTracker = false;

    /**
     * field for CsPurgeTime
     */
    protected com.huawei.www.hss.Int0_65534 localCsPurgeTime;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCsPurgeTimeTracker = false;

    /**
     * field for CSMSISDNLESS
     */
    protected com.huawei.www.hss._EnumType localCSMSISDNLESS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCSMSISDNLESSTracker = false;

    /**
     * field for CSRATTYPE
     */
    protected com.huawei.www.hss._EnumType localCSRATTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCSRATTYPETracker = false;

    /**
     * field for CsUplStatus
     */
    protected com.huawei.www.hss._EnumType localCsUplStatus;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCsUplStatusTracker = false;

    /**
     * field for BaocForVlrRestrict
     */
    protected com.huawei.www.hss._EnumType localBaocForVlrRestrict;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBaocForVlrRestrictTracker = false;

    public boolean isIMEISpecified() {
        return localIMEITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16[]
     */
    public com.huawei.www.hss.Str1_16[] getIMEI() {
        return localIMEI;
    }

    /**
     * validate the array for IMEI
     */
    protected void validateIMEI(com.huawei.www.hss.Str1_16[] param) {
    }

    /**
     * Auto generated setter method
     * @param param IMEI
     */
    public void setIMEI(com.huawei.www.hss.Str1_16[] param) {
        validateIMEI(param);

        localIMEITracker = param != null;

        this.localIMEI = param;
    }

    /**
     * Auto generated add method for the array for convenience
     * @param param com.huawei.www.hss.Str1_16
     */
    public void addIMEI(com.huawei.www.hss.Str1_16 param) {
        if (localIMEI == null) {
            localIMEI = new com.huawei.www.hss.Str1_16[] {  };
        }

        //update the setting tracker
        localIMEITracker = true;

        java.util.List list = org.apache.axis2.databinding.utils.ConverterUtil.toList(localIMEI);
        list.add(param);
        this.localIMEI = (com.huawei.www.hss.Str1_16[]) list.toArray(new com.huawei.www.hss.Str1_16[list.size()]);
    }

    public boolean isVlrNumSpecified() {
        return localVlrNumTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getVlrNum() {
        return localVlrNum;
    }

    /**
     * Auto generated setter method
     * @param param VlrNum
     */
    public void setVlrNum(com.huawei.www.hss.Str1_15 param) {
        localVlrNumTracker = param != null;

        this.localVlrNum = param;
    }

    public boolean isMscNumSpecified() {
        return localMscNumTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getMscNum() {
        return localMscNum;
    }

    /**
     * Auto generated setter method
     * @param param MscNum
     */
    public void setMscNum(com.huawei.www.hss.Str1_15 param) {
        localMscNumTracker = param != null;

        this.localMscNum = param;
    }

    public boolean isMsPurgedForNonGprsSpecified() {
        return localMsPurgedForNonGprsTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMsPurgedForNonGprs() {
        return localMsPurgedForNonGprs;
    }

    /**
     * Auto generated setter method
     * @param param MsPurgedForNonGprs
     */
    public void setMsPurgedForNonGprs(com.huawei.www.hss._EnumType param) {
        localMsPurgedForNonGprsTracker = param != null;

        this.localMsPurgedForNonGprs = param;
    }

    public boolean isVLRInHplmnSpecified() {
        return localVLRInHplmnTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVLRInHplmn() {
        return localVLRInHplmn;
    }

    /**
     * Auto generated setter method
     * @param param VLRInHplmn
     */
    public void setVLRInHplmn(com.huawei.www.hss._EnumType param) {
        localVLRInHplmnTracker = param != null;

        this.localVLRInHplmn = param;
    }

    public boolean isVLRInHomeCountrySpecified() {
        return localVLRInHomeCountryTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVLRInHomeCountry() {
        return localVLRInHomeCountry;
    }

    /**
     * Auto generated setter method
     * @param param VLRInHomeCountry
     */
    public void setVLRInHomeCountry(com.huawei.www.hss._EnumType param) {
        localVLRInHomeCountryTracker = param != null;

        this.localVLRInHomeCountry = param;
    }

    public boolean isVLRInAreaSpecified() {
        return localVLRInAreaTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVLRInArea() {
        return localVLRInArea;
    }

    /**
     * Auto generated setter method
     * @param param VLRInArea
     */
    public void setVLRInArea(com.huawei.www.hss._EnumType param) {
        localVLRInAreaTracker = param != null;

        this.localVLRInArea = param;
    }

    public boolean isRequireCheckSSSpecified() {
        return localRequireCheckSSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRequireCheckSS() {
        return localRequireCheckSS;
    }

    /**
     * Auto generated setter method
     * @param param RequireCheckSS
     */
    public void setRequireCheckSS(com.huawei.www.hss._EnumType param) {
        localRequireCheckSSTracker = param != null;

        this.localRequireCheckSS = param;
    }

    public boolean isRoamingRestrictInMscDueToUnsupportedFeatureSpecified() {
        return localRoamingRestrictInMscDueToUnsupportedFeatureTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRoamingRestrictInMscDueToUnsupportedFeature() {
        return localRoamingRestrictInMscDueToUnsupportedFeature;
    }

    /**
     * Auto generated setter method
     * @param param RoamingRestrictInMscDueToUnsupportedFeature
     */
    public void setRoamingRestrictInMscDueToUnsupportedFeature(
        com.huawei.www.hss._EnumType param) {
        localRoamingRestrictInMscDueToUnsupportedFeatureTracker = param != null;

        this.localRoamingRestrictInMscDueToUnsupportedFeature = param;
    }

    public boolean isMscOrVlrAreaRoamingRestrictSpecified() {
        return localMscOrVlrAreaRoamingRestrictTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMscOrVlrAreaRoamingRestrict() {
        return localMscOrVlrAreaRoamingRestrict;
    }

    /**
     * Auto generated setter method
     * @param param MscOrVlrAreaRoamingRestrict
     */
    public void setMscOrVlrAreaRoamingRestrict(
        com.huawei.www.hss._EnumType param) {
        localMscOrVlrAreaRoamingRestrictTracker = param != null;

        this.localMscOrVlrAreaRoamingRestrict = param;
    }

    public boolean isODBarredForUnsupportedCamelSpecified() {
        return localODBarredForUnsupportedCamelTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBarredForUnsupportedCamel() {
        return localODBarredForUnsupportedCamel;
    }

    /**
     * Auto generated setter method
     * @param param ODBarredForUnsupportedCamel
     */
    public void setODBarredForUnsupportedCamel(
        com.huawei.www.hss._EnumType param) {
        localODBarredForUnsupportedCamelTracker = param != null;

        this.localODBarredForUnsupportedCamel = param;
    }

    public boolean isSupportedCamelPhase1Specified() {
        return localSupportedCamelPhase1Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedCamelPhase1() {
        return localSupportedCamelPhase1;
    }

    /**
     * Auto generated setter method
     * @param param SupportedCamelPhase1
     */
    public void setSupportedCamelPhase1(com.huawei.www.hss._EnumType param) {
        localSupportedCamelPhase1Tracker = param != null;

        this.localSupportedCamelPhase1 = param;
    }

    public boolean isSupportedCamelPhase2Specified() {
        return localSupportedCamelPhase2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedCamelPhase2() {
        return localSupportedCamelPhase2;
    }

    /**
     * Auto generated setter method
     * @param param SupportedCamelPhase2
     */
    public void setSupportedCamelPhase2(com.huawei.www.hss._EnumType param) {
        localSupportedCamelPhase2Tracker = param != null;

        this.localSupportedCamelPhase2 = param;
    }

    public boolean isSupportedCamelPhase3Specified() {
        return localSupportedCamelPhase3Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedCamelPhase3() {
        return localSupportedCamelPhase3;
    }

    /**
     * Auto generated setter method
     * @param param SupportedCamelPhase3
     */
    public void setSupportedCamelPhase3(com.huawei.www.hss._EnumType param) {
        localSupportedCamelPhase3Tracker = param != null;

        this.localSupportedCamelPhase3 = param;
    }

    public boolean isSupportedCamelPhase4Specified() {
        return localSupportedCamelPhase4Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedCamelPhase4() {
        return localSupportedCamelPhase4;
    }

    /**
     * Auto generated setter method
     * @param param SupportedCamelPhase4
     */
    public void setSupportedCamelPhase4(com.huawei.www.hss._EnumType param) {
        localSupportedCamelPhase4Tracker = param != null;

        this.localSupportedCamelPhase4 = param;
    }

    public boolean isSRIMsrnCfActiveSpecified() {
        return localSRIMsrnCfActiveTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSRIMsrnCfActive() {
        return localSRIMsrnCfActive;
    }

    /**
     * Auto generated setter method
     * @param param SRIMsrnCfActive
     */
    public void setSRIMsrnCfActive(com.huawei.www.hss._EnumType param) {
        localSRIMsrnCfActiveTracker = param != null;

        this.localSRIMsrnCfActive = param;
    }

    public boolean isZoneCodeStatusAtMscSpecified() {
        return localZoneCodeStatusAtMscTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getZoneCodeStatusAtMsc() {
        return localZoneCodeStatusAtMsc;
    }

    /**
     * Auto generated setter method
     * @param param ZoneCodeStatusAtMsc
     */
    public void setZoneCodeStatusAtMsc(com.huawei.www.hss._EnumType param) {
        localZoneCodeStatusAtMscTracker = param != null;

        this.localZoneCodeStatusAtMsc = param;
    }

    public boolean isLongGroupIDSupportedSpecified() {
        return localLongGroupIDSupportedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getLongGroupIDSupported() {
        return localLongGroupIDSupported;
    }

    /**
     * Auto generated setter method
     * @param param LongGroupIDSupported
     */
    public void setLongGroupIDSupported(com.huawei.www.hss._EnumType param) {
        localLongGroupIDSupportedTracker = param != null;

        this.localLongGroupIDSupported = param;
    }

    public boolean isBasicISTSupportedSpecified() {
        return localBasicISTSupportedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBasicISTSupported() {
        return localBasicISTSupported;
    }

    /**
     * Auto generated setter method
     * @param param BasicISTSupported
     */
    public void setBasicISTSupported(com.huawei.www.hss._EnumType param) {
        localBasicISTSupportedTracker = param != null;

        this.localBasicISTSupported = param;
    }

    public boolean isIstCommandSupportedSpecified() {
        return localIstCommandSupportedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getIstCommandSupported() {
        return localIstCommandSupported;
    }

    /**
     * Auto generated setter method
     * @param param IstCommandSupported
     */
    public void setIstCommandSupported(com.huawei.www.hss._EnumType param) {
        localIstCommandSupportedTracker = param != null;

        this.localIstCommandSupported = param;
    }

    public boolean isSuperChargerSupportedForGsmSpecified() {
        return localSuperChargerSupportedForGsmTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSuperChargerSupportedForGsm() {
        return localSuperChargerSupportedForGsm;
    }

    /**
     * Auto generated setter method
     * @param param SuperChargerSupportedForGsm
     */
    public void setSuperChargerSupportedForGsm(
        com.huawei.www.hss._EnumType param) {
        localSuperChargerSupportedForGsmTracker = param != null;

        this.localSuperChargerSupportedForGsm = param;
    }

    public boolean isLMSISpecified() {
        return localLMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getLMSI() {
        return localLMSI;
    }

    /**
     * Auto generated setter method
     * @param param LMSI
     */
    public void setLMSI(com.huawei.www.hss.Str1_15 param) {
        localLMSITracker = param != null;

        this.localLMSI = param;
    }

    public boolean isECATEGORYAtMscSpecified() {
        return localECATEGORYAtMscTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getECATEGORYAtMsc() {
        return localECATEGORYAtMsc;
    }

    /**
     * Auto generated setter method
     * @param param ECATEGORYAtMsc
     */
    public void setECATEGORYAtMsc(com.huawei.www.hss._EnumType param) {
        localECATEGORYAtMscTracker = param != null;

        this.localECATEGORYAtMsc = param;
    }

    public boolean isCsUplTimeSpecified() {
        return localCsUplTimeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCsUplTime() {
        return localCsUplTime;
    }

    /**
     * Auto generated setter method
     * @param param CsUplTime
     */
    public void setCsUplTime(com.huawei.www.hss.Int0_65534 param) {
        localCsUplTimeTracker = param != null;

        this.localCsUplTime = param;
    }

    public boolean isCsPurgeTimeSpecified() {
        return localCsPurgeTimeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCsPurgeTime() {
        return localCsPurgeTime;
    }

    /**
     * Auto generated setter method
     * @param param CsPurgeTime
     */
    public void setCsPurgeTime(com.huawei.www.hss.Int0_65534 param) {
        localCsPurgeTimeTracker = param != null;

        this.localCsPurgeTime = param;
    }

    public boolean isCSMSISDNLESSSpecified() {
        return localCSMSISDNLESSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCSMSISDNLESS() {
        return localCSMSISDNLESS;
    }

    /**
     * Auto generated setter method
     * @param param CSMSISDNLESS
     */
    public void setCSMSISDNLESS(com.huawei.www.hss._EnumType param) {
        localCSMSISDNLESSTracker = param != null;

        this.localCSMSISDNLESS = param;
    }

    public boolean isCSRATTYPESpecified() {
        return localCSRATTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCSRATTYPE() {
        return localCSRATTYPE;
    }

    /**
     * Auto generated setter method
     * @param param CSRATTYPE
     */
    public void setCSRATTYPE(com.huawei.www.hss._EnumType param) {
        localCSRATTYPETracker = param != null;

        this.localCSRATTYPE = param;
    }

    public boolean isCsUplStatusSpecified() {
        return localCsUplStatusTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCsUplStatus() {
        return localCsUplStatus;
    }

    /**
     * Auto generated setter method
     * @param param CsUplStatus
     */
    public void setCsUplStatus(com.huawei.www.hss._EnumType param) {
        localCsUplStatusTracker = param != null;

        this.localCsUplStatus = param;
    }

    public boolean isBaocForVlrRestrictSpecified() {
        return localBaocForVlrRestrictTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBaocForVlrRestrict() {
        return localBaocForVlrRestrict;
    }

    /**
     * Auto generated setter method
     * @param param BaocForVlrRestrict
     */
    public void setBaocForVlrRestrict(com.huawei.www.hss._EnumType param) {
        localBaocForVlrRestrictTracker = param != null;

        this.localBaocForVlrRestrict = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":BasicDynamicDataForGsm_type0", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "BasicDynamicDataForGsm_type0", xmlWriter);
            }
        }

        if (localIMEITracker) {
            if (localIMEI != null) {
                for (int i = 0; i < localIMEI.length; i++) {
                    if (localIMEI[i] != null) {
                        localIMEI[i].serialize(new javax.xml.namespace.QName(
                                "http://www.huawei.com/HSS", "IMEI"), xmlWriter);
                    } else {
                        // we don't have to do any thing since minOccures is zero
                    }
                }
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMEI cannot be null!!");
            }
        }

        if (localVlrNumTracker) {
            if (localVlrNum == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VlrNum cannot be null!!");
            }

            localVlrNum.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VlrNum"), xmlWriter);
        }

        if (localMscNumTracker) {
            if (localMscNum == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MscNum cannot be null!!");
            }

            localMscNum.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MscNum"), xmlWriter);
        }

        if (localMsPurgedForNonGprsTracker) {
            if (localMsPurgedForNonGprs == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MsPurgedForNonGprs cannot be null!!");
            }

            localMsPurgedForNonGprs.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MsPurgedForNonGprs"),
                xmlWriter);
        }

        if (localVLRInHplmnTracker) {
            if (localVLRInHplmn == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VLRInHplmn cannot be null!!");
            }

            localVLRInHplmn.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VLRInHplmn"), xmlWriter);
        }

        if (localVLRInHomeCountryTracker) {
            if (localVLRInHomeCountry == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VLRInHomeCountry cannot be null!!");
            }

            localVLRInHomeCountry.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VLRInHomeCountry"), xmlWriter);
        }

        if (localVLRInAreaTracker) {
            if (localVLRInArea == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VLRInArea cannot be null!!");
            }

            localVLRInArea.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VLRInArea"), xmlWriter);
        }

        if (localRequireCheckSSTracker) {
            if (localRequireCheckSS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RequireCheckSS cannot be null!!");
            }

            localRequireCheckSS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RequireCheckSS"), xmlWriter);
        }

        if (localRoamingRestrictInMscDueToUnsupportedFeatureTracker) {
            if (localRoamingRestrictInMscDueToUnsupportedFeature == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RoamingRestrictInMscDueToUnsupportedFeature cannot be null!!");
            }

            localRoamingRestrictInMscDueToUnsupportedFeature.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "RoamingRestrictInMscDueToUnsupportedFeature"), xmlWriter);
        }

        if (localMscOrVlrAreaRoamingRestrictTracker) {
            if (localMscOrVlrAreaRoamingRestrict == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MscOrVlrAreaRoamingRestrict cannot be null!!");
            }

            localMscOrVlrAreaRoamingRestrict.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MscOrVlrAreaRoamingRestrict"),
                xmlWriter);
        }

        if (localODBarredForUnsupportedCamelTracker) {
            if (localODBarredForUnsupportedCamel == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBarredForUnsupportedCamel cannot be null!!");
            }

            localODBarredForUnsupportedCamel.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBarredForUnsupportedCamel"),
                xmlWriter);
        }

        if (localSupportedCamelPhase1Tracker) {
            if (localSupportedCamelPhase1 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedCamelPhase1 cannot be null!!");
            }

            localSupportedCamelPhase1.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedCamelPhase1"),
                xmlWriter);
        }

        if (localSupportedCamelPhase2Tracker) {
            if (localSupportedCamelPhase2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedCamelPhase2 cannot be null!!");
            }

            localSupportedCamelPhase2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedCamelPhase2"),
                xmlWriter);
        }

        if (localSupportedCamelPhase3Tracker) {
            if (localSupportedCamelPhase3 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedCamelPhase3 cannot be null!!");
            }

            localSupportedCamelPhase3.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedCamelPhase3"),
                xmlWriter);
        }

        if (localSupportedCamelPhase4Tracker) {
            if (localSupportedCamelPhase4 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedCamelPhase4 cannot be null!!");
            }

            localSupportedCamelPhase4.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedCamelPhase4"),
                xmlWriter);
        }

        if (localSRIMsrnCfActiveTracker) {
            if (localSRIMsrnCfActive == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SRIMsrnCfActive cannot be null!!");
            }

            localSRIMsrnCfActive.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SRIMsrnCfActive"), xmlWriter);
        }

        if (localZoneCodeStatusAtMscTracker) {
            if (localZoneCodeStatusAtMsc == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ZoneCodeStatusAtMsc cannot be null!!");
            }

            localZoneCodeStatusAtMsc.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ZoneCodeStatusAtMsc"),
                xmlWriter);
        }

        if (localLongGroupIDSupportedTracker) {
            if (localLongGroupIDSupported == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "longGroupIDSupported cannot be null!!");
            }

            localLongGroupIDSupported.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "longGroupIDSupported"),
                xmlWriter);
        }

        if (localBasicISTSupportedTracker) {
            if (localBasicISTSupported == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "basicISTSupported cannot be null!!");
            }

            localBasicISTSupported.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "basicISTSupported"), xmlWriter);
        }

        if (localIstCommandSupportedTracker) {
            if (localIstCommandSupported == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "istCommandSupported cannot be null!!");
            }

            localIstCommandSupported.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "istCommandSupported"),
                xmlWriter);
        }

        if (localSuperChargerSupportedForGsmTracker) {
            if (localSuperChargerSupportedForGsm == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SuperChargerSupportedForGsm cannot be null!!");
            }

            localSuperChargerSupportedForGsm.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SuperChargerSupportedForGsm"),
                xmlWriter);
        }

        if (localLMSITracker) {
            if (localLMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LMSI cannot be null!!");
            }

            localLMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LMSI"), xmlWriter);
        }

        if (localECATEGORYAtMscTracker) {
            if (localECATEGORYAtMsc == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ECATEGORYAtMsc cannot be null!!");
            }

            localECATEGORYAtMsc.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ECATEGORYAtMsc"), xmlWriter);
        }

        if (localCsUplTimeTracker) {
            if (localCsUplTime == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CsUplTime cannot be null!!");
            }

            localCsUplTime.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CsUplTime"), xmlWriter);
        }

        if (localCsPurgeTimeTracker) {
            if (localCsPurgeTime == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CsPurgeTime cannot be null!!");
            }

            localCsPurgeTime.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CsPurgeTime"), xmlWriter);
        }

        if (localCSMSISDNLESSTracker) {
            if (localCSMSISDNLESS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CS-MSISDN-LESS cannot be null!!");
            }

            localCSMSISDNLESS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CS-MSISDN-LESS"), xmlWriter);
        }

        if (localCSRATTYPETracker) {
            if (localCSRATTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CSRATTYPE cannot be null!!");
            }

            localCSRATTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CSRATTYPE"), xmlWriter);
        }

        if (localCsUplStatusTracker) {
            if (localCsUplStatus == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CsUplStatus cannot be null!!");
            }

            localCsUplStatus.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CsUplStatus"), xmlWriter);
        }

        if (localBaocForVlrRestrictTracker) {
            if (localBaocForVlrRestrict == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BaocForVlrRestrict cannot be null!!");
            }

            localBaocForVlrRestrict.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BaocForVlrRestrict"),
                xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static BasicDynamicDataForGsm_type0 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            BasicDynamicDataForGsm_type0 object = new BasicDynamicDataForGsm_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"BasicDynamicDataForGsm_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (BasicDynamicDataForGsm_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                java.util.ArrayList list1 = new java.util.ArrayList();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMEI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMEI").equals(
                            reader.getName())) {
                    // Process the array and step past its final element's end.
                    list1.add(com.huawei.www.hss.Str1_16.Factory.parse(reader));

                    //loop until we find a start element that is not part of this array
                    boolean loopDone1 = false;

                    while (!loopDone1) {
                        // We should be at the end element, but make sure
                        while (!reader.isEndElement())
                            reader.next();

                        // Step out of this element
                        reader.next();

                        // Step to next element event.
                        while (!reader.isStartElement() &&
                                !reader.isEndElement())
                            reader.next();

                        if (reader.isEndElement()) {
                            //two continuous end elements means we are exiting the xml structure
                            loopDone1 = true;
                        } else {
                            if (new javax.xml.namespace.QName(
                                        "http://www.huawei.com/HSS", "IMEI").equals(
                                        reader.getName())) {
                                list1.add(com.huawei.www.hss.Str1_16.Factory.parse(
                                        reader));
                            } else {
                                loopDone1 = true;
                            }
                        }
                    }

                    // call the converter utility  to convert and set the array
                    object.setIMEI((com.huawei.www.hss.Str1_16[]) org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                            com.huawei.www.hss.Str1_16.class, list1));
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VlrNum").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VlrNum").equals(
                            reader.getName())) {
                    object.setVlrNum(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MscNum").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MscNum").equals(
                            reader.getName())) {
                    object.setMscNum(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MsPurgedForNonGprs").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MsPurgedForNonGprs").equals(
                            reader.getName())) {
                    object.setMsPurgedForNonGprs(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VLRInHplmn").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VLRInHplmn").equals(
                            reader.getName())) {
                    object.setVLRInHplmn(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VLRInHomeCountry").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VLRInHomeCountry").equals(
                            reader.getName())) {
                    object.setVLRInHomeCountry(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VLRInArea").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VLRInArea").equals(
                            reader.getName())) {
                    object.setVLRInArea(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RequireCheckSS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RequireCheckSS").equals(
                            reader.getName())) {
                    object.setRequireCheckSS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "RoamingRestrictInMscDueToUnsupportedFeature").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "RoamingRestrictInMscDueToUnsupportedFeature").equals(
                            reader.getName())) {
                    object.setRoamingRestrictInMscDueToUnsupportedFeature(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "MscOrVlrAreaRoamingRestrict").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "MscOrVlrAreaRoamingRestrict").equals(
                            reader.getName())) {
                    object.setMscOrVlrAreaRoamingRestrict(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "ODBarredForUnsupportedCamel").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "ODBarredForUnsupportedCamel").equals(
                            reader.getName())) {
                    object.setODBarredForUnsupportedCamel(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SupportedCamelPhase1").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SupportedCamelPhase1").equals(
                            reader.getName())) {
                    object.setSupportedCamelPhase1(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SupportedCamelPhase2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SupportedCamelPhase2").equals(
                            reader.getName())) {
                    object.setSupportedCamelPhase2(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SupportedCamelPhase3").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SupportedCamelPhase3").equals(
                            reader.getName())) {
                    object.setSupportedCamelPhase3(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SupportedCamelPhase4").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SupportedCamelPhase4").equals(
                            reader.getName())) {
                    object.setSupportedCamelPhase4(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SRIMsrnCfActive").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SRIMsrnCfActive").equals(
                            reader.getName())) {
                    object.setSRIMsrnCfActive(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ZoneCodeStatusAtMsc").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ZoneCodeStatusAtMsc").equals(
                            reader.getName())) {
                    object.setZoneCodeStatusAtMsc(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "longGroupIDSupported").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "longGroupIDSupported").equals(
                            reader.getName())) {
                    object.setLongGroupIDSupported(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "basicISTSupported").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "basicISTSupported").equals(
                            reader.getName())) {
                    object.setBasicISTSupported(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "istCommandSupported").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "istCommandSupported").equals(
                            reader.getName())) {
                    object.setIstCommandSupported(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SuperChargerSupportedForGsm").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SuperChargerSupportedForGsm").equals(
                            reader.getName())) {
                    object.setSuperChargerSupportedForGsm(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LMSI").equals(
                            reader.getName())) {
                    object.setLMSI(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ECATEGORYAtMsc").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ECATEGORYAtMsc").equals(
                            reader.getName())) {
                    object.setECATEGORYAtMsc(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CsUplTime").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CsUplTime").equals(
                            reader.getName())) {
                    object.setCsUplTime(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CsPurgeTime").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CsPurgeTime").equals(
                            reader.getName())) {
                    object.setCsPurgeTime(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CS-MSISDN-LESS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CS-MSISDN-LESS").equals(
                            reader.getName())) {
                    object.setCSMSISDNLESS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CSRATTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CSRATTYPE").equals(
                            reader.getName())) {
                    object.setCSRATTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CsUplStatus").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CsUplStatus").equals(
                            reader.getName())) {
                    object.setCsUplStatus(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BaocForVlrRestrict").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BaocForVlrRestrict").equals(
                            reader.getName())) {
                    object.setBaocForVlrRestrict(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
