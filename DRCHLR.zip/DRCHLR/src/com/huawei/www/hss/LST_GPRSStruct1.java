/**
 * LST_GPRSStruct1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  LST_GPRSStruct1 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class LST_GPRSStruct1 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = LST_GPRSStruct1
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for IMSI
     */
    protected com.huawei.www.hss.Str6_15 localIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSITracker = false;

    /**
     * field for ISDN
     */
    protected com.huawei.www.hss.Str1_15 localISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localISDNTracker = false;

    /**
     * field for CHARGE_GLOBAL
     */
    protected com.huawei.www.hss._EnumType localCHARGE_GLOBAL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCHARGE_GLOBALTracker = false;

    /**
     * field for CNTXID
     */
    protected com.huawei.www.hss.Int1_50 localCNTXID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCNTXIDTracker = false;

    /**
     * field for PDPTYPE
     */
    protected com.huawei.www.hss._EnumType localPDPTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPDPTYPETracker = false;

    /**
     * field for PDPADD
     */
    protected com.huawei.www.hss.Str1_40 localPDPADD;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPDPADDTracker = false;

    /**
     * field for ADDIND
     */
    protected com.huawei.www.hss._EnumType localADDIND;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localADDINDTracker = false;

    /**
     * field for RELCLS
     */
    protected com.huawei.www.hss._EnumType localRELCLS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRELCLSTracker = false;

    /**
     * field for DELAYCLS
     */
    protected com.huawei.www.hss._EnumType localDELAYCLS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDELAYCLSTracker = false;

    /**
     * field for PRECLS
     */
    protected com.huawei.www.hss._EnumType localPRECLS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPRECLSTracker = false;

    /**
     * field for PEAKTHR
     */
    protected com.huawei.www.hss._EnumType localPEAKTHR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPEAKTHRTracker = false;

    /**
     * field for MEANTHR
     */
    protected com.huawei.www.hss._EnumType localMEANTHR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMEANTHRTracker = false;

    /**
     * field for ARPRIORITY
     */
    protected com.huawei.www.hss._EnumType localARPRIORITY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localARPRIORITYTracker = false;

    /**
     * field for ERRSDU
     */
    protected com.huawei.www.hss._EnumType localERRSDU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localERRSDUTracker = false;

    /**
     * field for DELIVERY
     */
    protected com.huawei.www.hss._EnumType localDELIVERY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDELIVERYTracker = false;

    /**
     * field for TRAFFICCLS
     */
    protected com.huawei.www.hss._EnumType localTRAFFICCLS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTRAFFICCLSTracker = false;

    /**
     * field for MAXSDUSIZE
     */
    protected com.huawei.www.hss._EnumType localMAXSDUSIZE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXSDUSIZETracker = false;

    /**
     * field for MAXBRUPL
     */
    protected com.huawei.www.hss._EnumType localMAXBRUPL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXBRUPLTracker = false;

    /**
     * field for MAXBRDWL
     */
    protected com.huawei.www.hss._EnumType localMAXBRDWL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXBRDWLTracker = false;

    /**
     * field for RESBER
     */
    protected com.huawei.www.hss._EnumType localRESBER;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRESBERTracker = false;

    /**
     * field for SDUERR
     */
    protected com.huawei.www.hss._EnumType localSDUERR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSDUERRTracker = false;

    /**
     * field for TRANSFERDEL
     */
    protected com.huawei.www.hss._EnumType localTRANSFERDEL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTRANSFERDELTracker = false;

    /**
     * field for TRAFFICPRI
     */
    protected com.huawei.www.hss._EnumType localTRAFFICPRI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTRAFFICPRITracker = false;

    /**
     * field for MAXGBRUPL
     */
    protected com.huawei.www.hss._EnumType localMAXGBRUPL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXGBRUPLTracker = false;

    /**
     * field for MAXGBRDWL
     */
    protected com.huawei.www.hss._EnumType localMAXGBRDWL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXGBRDWLTracker = false;

    /**
     * field for APN
     */
    protected com.huawei.www.hss.Str1_63 localAPN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAPNTracker = false;

    /**
     * field for VPLMN
     */
    protected com.huawei.www.hss._EnumType localVPLMN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVPLMNTracker = false;

    /**
     * field for CHARGE
     */
    protected com.huawei.www.hss._EnumType localCHARGE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCHARGETracker = false;

    /**
     * field for MAXEXTBRDWL
     */
    protected com.huawei.www.hss._EnumType localMAXEXTBRDWL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXEXTBRDWLTracker = false;

    /**
     * field for MAXEXTGBRDWL
     */
    protected com.huawei.www.hss._EnumType localMAXEXTGBRDWL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXEXTGBRDWLTracker = false;

    /**
     * field for PDPADDIPV4
     */
    protected com.huawei.www.hss.Str1_40 localPDPADDIPV4;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPDPADDIPV4Tracker = false;

    /**
     * field for ADD2IND
     */
    protected com.huawei.www.hss._EnumType localADD2IND;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localADD2INDTracker = false;

    /**
     * field for STDCHARGE
     */
    protected com.huawei.www.hss.Str4_4 localSTDCHARGE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSTDCHARGETracker = false;

    /**
     * field for SCHARGE_GLOBAL
     */
    protected com.huawei.www.hss.Str4_4 localSCHARGE_GLOBAL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSCHARGE_GLOBALTracker = false;

    /**
     * field for MAXEXTBRUPL
     */
    protected com.huawei.www.hss._EnumType localMAXEXTBRUPL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXEXTBRUPLTracker = false;

    /**
     * field for MAXEXTGBRUPL
     */
    protected com.huawei.www.hss._EnumType localMAXEXTGBRUPL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXEXTGBRUPLTracker = false;

    /**
     * field for APNOITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localAPNOITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAPNOITPLIDTracker = false;

    public boolean isIMSISpecified() {
        return localIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getIMSI() {
        return localIMSI;
    }

    /**
     * Auto generated setter method
     * @param param IMSI
     */
    public void setIMSI(com.huawei.www.hss.Str6_15 param) {
        localIMSITracker = param != null;

        this.localIMSI = param;
    }

    public boolean isISDNSpecified() {
        return localISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getISDN() {
        return localISDN;
    }

    /**
     * Auto generated setter method
     * @param param ISDN
     */
    public void setISDN(com.huawei.www.hss.Str1_15 param) {
        localISDNTracker = param != null;

        this.localISDN = param;
    }

    public boolean isCHARGE_GLOBALSpecified() {
        return localCHARGE_GLOBALTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCHARGE_GLOBAL() {
        return localCHARGE_GLOBAL;
    }

    /**
     * Auto generated setter method
     * @param param CHARGE_GLOBAL
     */
    public void setCHARGE_GLOBAL(com.huawei.www.hss._EnumType param) {
        localCHARGE_GLOBALTracker = param != null;

        this.localCHARGE_GLOBAL = param;
    }

    public boolean isCNTXIDSpecified() {
        return localCNTXIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_50
     */
    public com.huawei.www.hss.Int1_50 getCNTXID() {
        return localCNTXID;
    }

    /**
     * Auto generated setter method
     * @param param CNTXID
     */
    public void setCNTXID(com.huawei.www.hss.Int1_50 param) {
        localCNTXIDTracker = param != null;

        this.localCNTXID = param;
    }

    public boolean isPDPTYPESpecified() {
        return localPDPTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPDPTYPE() {
        return localPDPTYPE;
    }

    /**
     * Auto generated setter method
     * @param param PDPTYPE
     */
    public void setPDPTYPE(com.huawei.www.hss._EnumType param) {
        localPDPTYPETracker = param != null;

        this.localPDPTYPE = param;
    }

    public boolean isPDPADDSpecified() {
        return localPDPADDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_40
     */
    public com.huawei.www.hss.Str1_40 getPDPADD() {
        return localPDPADD;
    }

    /**
     * Auto generated setter method
     * @param param PDPADD
     */
    public void setPDPADD(com.huawei.www.hss.Str1_40 param) {
        localPDPADDTracker = param != null;

        this.localPDPADD = param;
    }

    public boolean isADDINDSpecified() {
        return localADDINDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getADDIND() {
        return localADDIND;
    }

    /**
     * Auto generated setter method
     * @param param ADDIND
     */
    public void setADDIND(com.huawei.www.hss._EnumType param) {
        localADDINDTracker = param != null;

        this.localADDIND = param;
    }

    public boolean isRELCLSSpecified() {
        return localRELCLSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRELCLS() {
        return localRELCLS;
    }

    /**
     * Auto generated setter method
     * @param param RELCLS
     */
    public void setRELCLS(com.huawei.www.hss._EnumType param) {
        localRELCLSTracker = param != null;

        this.localRELCLS = param;
    }

    public boolean isDELAYCLSSpecified() {
        return localDELAYCLSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDELAYCLS() {
        return localDELAYCLS;
    }

    /**
     * Auto generated setter method
     * @param param DELAYCLS
     */
    public void setDELAYCLS(com.huawei.www.hss._EnumType param) {
        localDELAYCLSTracker = param != null;

        this.localDELAYCLS = param;
    }

    public boolean isPRECLSSpecified() {
        return localPRECLSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPRECLS() {
        return localPRECLS;
    }

    /**
     * Auto generated setter method
     * @param param PRECLS
     */
    public void setPRECLS(com.huawei.www.hss._EnumType param) {
        localPRECLSTracker = param != null;

        this.localPRECLS = param;
    }

    public boolean isPEAKTHRSpecified() {
        return localPEAKTHRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPEAKTHR() {
        return localPEAKTHR;
    }

    /**
     * Auto generated setter method
     * @param param PEAKTHR
     */
    public void setPEAKTHR(com.huawei.www.hss._EnumType param) {
        localPEAKTHRTracker = param != null;

        this.localPEAKTHR = param;
    }

    public boolean isMEANTHRSpecified() {
        return localMEANTHRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMEANTHR() {
        return localMEANTHR;
    }

    /**
     * Auto generated setter method
     * @param param MEANTHR
     */
    public void setMEANTHR(com.huawei.www.hss._EnumType param) {
        localMEANTHRTracker = param != null;

        this.localMEANTHR = param;
    }

    public boolean isARPRIORITYSpecified() {
        return localARPRIORITYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getARPRIORITY() {
        return localARPRIORITY;
    }

    /**
     * Auto generated setter method
     * @param param ARPRIORITY
     */
    public void setARPRIORITY(com.huawei.www.hss._EnumType param) {
        localARPRIORITYTracker = param != null;

        this.localARPRIORITY = param;
    }

    public boolean isERRSDUSpecified() {
        return localERRSDUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getERRSDU() {
        return localERRSDU;
    }

    /**
     * Auto generated setter method
     * @param param ERRSDU
     */
    public void setERRSDU(com.huawei.www.hss._EnumType param) {
        localERRSDUTracker = param != null;

        this.localERRSDU = param;
    }

    public boolean isDELIVERYSpecified() {
        return localDELIVERYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDELIVERY() {
        return localDELIVERY;
    }

    /**
     * Auto generated setter method
     * @param param DELIVERY
     */
    public void setDELIVERY(com.huawei.www.hss._EnumType param) {
        localDELIVERYTracker = param != null;

        this.localDELIVERY = param;
    }

    public boolean isTRAFFICCLSSpecified() {
        return localTRAFFICCLSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTRAFFICCLS() {
        return localTRAFFICCLS;
    }

    /**
     * Auto generated setter method
     * @param param TRAFFICCLS
     */
    public void setTRAFFICCLS(com.huawei.www.hss._EnumType param) {
        localTRAFFICCLSTracker = param != null;

        this.localTRAFFICCLS = param;
    }

    public boolean isMAXSDUSIZESpecified() {
        return localMAXSDUSIZETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXSDUSIZE() {
        return localMAXSDUSIZE;
    }

    /**
     * Auto generated setter method
     * @param param MAXSDUSIZE
     */
    public void setMAXSDUSIZE(com.huawei.www.hss._EnumType param) {
        localMAXSDUSIZETracker = param != null;

        this.localMAXSDUSIZE = param;
    }

    public boolean isMAXBRUPLSpecified() {
        return localMAXBRUPLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXBRUPL() {
        return localMAXBRUPL;
    }

    /**
     * Auto generated setter method
     * @param param MAXBRUPL
     */
    public void setMAXBRUPL(com.huawei.www.hss._EnumType param) {
        localMAXBRUPLTracker = param != null;

        this.localMAXBRUPL = param;
    }

    public boolean isMAXBRDWLSpecified() {
        return localMAXBRDWLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXBRDWL() {
        return localMAXBRDWL;
    }

    /**
     * Auto generated setter method
     * @param param MAXBRDWL
     */
    public void setMAXBRDWL(com.huawei.www.hss._EnumType param) {
        localMAXBRDWLTracker = param != null;

        this.localMAXBRDWL = param;
    }

    public boolean isRESBERSpecified() {
        return localRESBERTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRESBER() {
        return localRESBER;
    }

    /**
     * Auto generated setter method
     * @param param RESBER
     */
    public void setRESBER(com.huawei.www.hss._EnumType param) {
        localRESBERTracker = param != null;

        this.localRESBER = param;
    }

    public boolean isSDUERRSpecified() {
        return localSDUERRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSDUERR() {
        return localSDUERR;
    }

    /**
     * Auto generated setter method
     * @param param SDUERR
     */
    public void setSDUERR(com.huawei.www.hss._EnumType param) {
        localSDUERRTracker = param != null;

        this.localSDUERR = param;
    }

    public boolean isTRANSFERDELSpecified() {
        return localTRANSFERDELTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTRANSFERDEL() {
        return localTRANSFERDEL;
    }

    /**
     * Auto generated setter method
     * @param param TRANSFERDEL
     */
    public void setTRANSFERDEL(com.huawei.www.hss._EnumType param) {
        localTRANSFERDELTracker = param != null;

        this.localTRANSFERDEL = param;
    }

    public boolean isTRAFFICPRISpecified() {
        return localTRAFFICPRITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTRAFFICPRI() {
        return localTRAFFICPRI;
    }

    /**
     * Auto generated setter method
     * @param param TRAFFICPRI
     */
    public void setTRAFFICPRI(com.huawei.www.hss._EnumType param) {
        localTRAFFICPRITracker = param != null;

        this.localTRAFFICPRI = param;
    }

    public boolean isMAXGBRUPLSpecified() {
        return localMAXGBRUPLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXGBRUPL() {
        return localMAXGBRUPL;
    }

    /**
     * Auto generated setter method
     * @param param MAXGBRUPL
     */
    public void setMAXGBRUPL(com.huawei.www.hss._EnumType param) {
        localMAXGBRUPLTracker = param != null;

        this.localMAXGBRUPL = param;
    }

    public boolean isMAXGBRDWLSpecified() {
        return localMAXGBRDWLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXGBRDWL() {
        return localMAXGBRDWL;
    }

    /**
     * Auto generated setter method
     * @param param MAXGBRDWL
     */
    public void setMAXGBRDWL(com.huawei.www.hss._EnumType param) {
        localMAXGBRDWLTracker = param != null;

        this.localMAXGBRDWL = param;
    }

    public boolean isAPNSpecified() {
        return localAPNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_63
     */
    public com.huawei.www.hss.Str1_63 getAPN() {
        return localAPN;
    }

    /**
     * Auto generated setter method
     * @param param APN
     */
    public void setAPN(com.huawei.www.hss.Str1_63 param) {
        localAPNTracker = param != null;

        this.localAPN = param;
    }

    public boolean isVPLMNSpecified() {
        return localVPLMNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVPLMN() {
        return localVPLMN;
    }

    /**
     * Auto generated setter method
     * @param param VPLMN
     */
    public void setVPLMN(com.huawei.www.hss._EnumType param) {
        localVPLMNTracker = param != null;

        this.localVPLMN = param;
    }

    public boolean isCHARGESpecified() {
        return localCHARGETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCHARGE() {
        return localCHARGE;
    }

    /**
     * Auto generated setter method
     * @param param CHARGE
     */
    public void setCHARGE(com.huawei.www.hss._EnumType param) {
        localCHARGETracker = param != null;

        this.localCHARGE = param;
    }

    public boolean isMAXEXTBRDWLSpecified() {
        return localMAXEXTBRDWLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXEXTBRDWL() {
        return localMAXEXTBRDWL;
    }

    /**
     * Auto generated setter method
     * @param param MAXEXTBRDWL
     */
    public void setMAXEXTBRDWL(com.huawei.www.hss._EnumType param) {
        localMAXEXTBRDWLTracker = param != null;

        this.localMAXEXTBRDWL = param;
    }

    public boolean isMAXEXTGBRDWLSpecified() {
        return localMAXEXTGBRDWLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXEXTGBRDWL() {
        return localMAXEXTGBRDWL;
    }

    /**
     * Auto generated setter method
     * @param param MAXEXTGBRDWL
     */
    public void setMAXEXTGBRDWL(com.huawei.www.hss._EnumType param) {
        localMAXEXTGBRDWLTracker = param != null;

        this.localMAXEXTGBRDWL = param;
    }

    public boolean isPDPADDIPV4Specified() {
        return localPDPADDIPV4Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_40
     */
    public com.huawei.www.hss.Str1_40 getPDPADDIPV4() {
        return localPDPADDIPV4;
    }

    /**
     * Auto generated setter method
     * @param param PDPADDIPV4
     */
    public void setPDPADDIPV4(com.huawei.www.hss.Str1_40 param) {
        localPDPADDIPV4Tracker = param != null;

        this.localPDPADDIPV4 = param;
    }

    public boolean isADD2INDSpecified() {
        return localADD2INDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getADD2IND() {
        return localADD2IND;
    }

    /**
     * Auto generated setter method
     * @param param ADD2IND
     */
    public void setADD2IND(com.huawei.www.hss._EnumType param) {
        localADD2INDTracker = param != null;

        this.localADD2IND = param;
    }

    public boolean isSTDCHARGESpecified() {
        return localSTDCHARGETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str4_4
     */
    public com.huawei.www.hss.Str4_4 getSTDCHARGE() {
        return localSTDCHARGE;
    }

    /**
     * Auto generated setter method
     * @param param STDCHARGE
     */
    public void setSTDCHARGE(com.huawei.www.hss.Str4_4 param) {
        localSTDCHARGETracker = param != null;

        this.localSTDCHARGE = param;
    }

    public boolean isSCHARGE_GLOBALSpecified() {
        return localSCHARGE_GLOBALTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str4_4
     */
    public com.huawei.www.hss.Str4_4 getSCHARGE_GLOBAL() {
        return localSCHARGE_GLOBAL;
    }

    /**
     * Auto generated setter method
     * @param param SCHARGE_GLOBAL
     */
    public void setSCHARGE_GLOBAL(com.huawei.www.hss.Str4_4 param) {
        localSCHARGE_GLOBALTracker = param != null;

        this.localSCHARGE_GLOBAL = param;
    }

    public boolean isMAXEXTBRUPLSpecified() {
        return localMAXEXTBRUPLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXEXTBRUPL() {
        return localMAXEXTBRUPL;
    }

    /**
     * Auto generated setter method
     * @param param MAXEXTBRUPL
     */
    public void setMAXEXTBRUPL(com.huawei.www.hss._EnumType param) {
        localMAXEXTBRUPLTracker = param != null;

        this.localMAXEXTBRUPL = param;
    }

    public boolean isMAXEXTGBRUPLSpecified() {
        return localMAXEXTGBRUPLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXEXTGBRUPL() {
        return localMAXEXTGBRUPL;
    }

    /**
     * Auto generated setter method
     * @param param MAXEXTGBRUPL
     */
    public void setMAXEXTGBRUPL(com.huawei.www.hss._EnumType param) {
        localMAXEXTGBRUPLTracker = param != null;

        this.localMAXEXTGBRUPL = param;
    }

    public boolean isAPNOITPLIDSpecified() {
        return localAPNOITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getAPNOITPLID() {
        return localAPNOITPLID;
    }

    /**
     * Auto generated setter method
     * @param param APNOITPLID
     */
    public void setAPNOITPLID(com.huawei.www.hss.Int0_65534 param) {
        localAPNOITPLIDTracker = param != null;

        this.localAPNOITPLID = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":LST_GPRSStruct1", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "LST_GPRSStruct1", xmlWriter);
            }
        }

        if (localIMSITracker) {
            if (localIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMSI cannot be null!!");
            }

            localIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMSI"), xmlWriter);
        }

        if (localISDNTracker) {
            if (localISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ISDN cannot be null!!");
            }

            localISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ISDN"), xmlWriter);
        }

        if (localCHARGE_GLOBALTracker) {
            if (localCHARGE_GLOBAL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CHARGE_GLOBAL cannot be null!!");
            }

            localCHARGE_GLOBAL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CHARGE_GLOBAL"), xmlWriter);
        }

        if (localCNTXIDTracker) {
            if (localCNTXID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CNTXID cannot be null!!");
            }

            localCNTXID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CNTXID"), xmlWriter);
        }

        if (localPDPTYPETracker) {
            if (localPDPTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PDPTYPE cannot be null!!");
            }

            localPDPTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PDPTYPE"), xmlWriter);
        }

        if (localPDPADDTracker) {
            if (localPDPADD == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PDPADD cannot be null!!");
            }

            localPDPADD.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PDPADD"), xmlWriter);
        }

        if (localADDINDTracker) {
            if (localADDIND == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ADDIND cannot be null!!");
            }

            localADDIND.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ADDIND"), xmlWriter);
        }

        if (localRELCLSTracker) {
            if (localRELCLS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RELCLS cannot be null!!");
            }

            localRELCLS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RELCLS"), xmlWriter);
        }

        if (localDELAYCLSTracker) {
            if (localDELAYCLS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DELAYCLS cannot be null!!");
            }

            localDELAYCLS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DELAYCLS"), xmlWriter);
        }

        if (localPRECLSTracker) {
            if (localPRECLS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PRECLS cannot be null!!");
            }

            localPRECLS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PRECLS"), xmlWriter);
        }

        if (localPEAKTHRTracker) {
            if (localPEAKTHR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PEAKTHR cannot be null!!");
            }

            localPEAKTHR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PEAKTHR"), xmlWriter);
        }

        if (localMEANTHRTracker) {
            if (localMEANTHR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MEANTHR cannot be null!!");
            }

            localMEANTHR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MEANTHR"), xmlWriter);
        }

        if (localARPRIORITYTracker) {
            if (localARPRIORITY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ARPRIORITY cannot be null!!");
            }

            localARPRIORITY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ARPRIORITY"), xmlWriter);
        }

        if (localERRSDUTracker) {
            if (localERRSDU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ERRSDU cannot be null!!");
            }

            localERRSDU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ERRSDU"), xmlWriter);
        }

        if (localDELIVERYTracker) {
            if (localDELIVERY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DELIVERY cannot be null!!");
            }

            localDELIVERY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DELIVERY"), xmlWriter);
        }

        if (localTRAFFICCLSTracker) {
            if (localTRAFFICCLS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TRAFFICCLS cannot be null!!");
            }

            localTRAFFICCLS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TRAFFICCLS"), xmlWriter);
        }

        if (localMAXSDUSIZETracker) {
            if (localMAXSDUSIZE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXSDUSIZE cannot be null!!");
            }

            localMAXSDUSIZE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXSDUSIZE"), xmlWriter);
        }

        if (localMAXBRUPLTracker) {
            if (localMAXBRUPL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXBRUPL cannot be null!!");
            }

            localMAXBRUPL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXBRUPL"), xmlWriter);
        }

        if (localMAXBRDWLTracker) {
            if (localMAXBRDWL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXBRDWL cannot be null!!");
            }

            localMAXBRDWL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXBRDWL"), xmlWriter);
        }

        if (localRESBERTracker) {
            if (localRESBER == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RESBER cannot be null!!");
            }

            localRESBER.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RESBER"), xmlWriter);
        }

        if (localSDUERRTracker) {
            if (localSDUERR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SDUERR cannot be null!!");
            }

            localSDUERR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SDUERR"), xmlWriter);
        }

        if (localTRANSFERDELTracker) {
            if (localTRANSFERDEL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TRANSFERDEL cannot be null!!");
            }

            localTRANSFERDEL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TRANSFERDEL"), xmlWriter);
        }

        if (localTRAFFICPRITracker) {
            if (localTRAFFICPRI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TRAFFICPRI cannot be null!!");
            }

            localTRAFFICPRI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TRAFFICPRI"), xmlWriter);
        }

        if (localMAXGBRUPLTracker) {
            if (localMAXGBRUPL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXGBRUPL cannot be null!!");
            }

            localMAXGBRUPL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXGBRUPL"), xmlWriter);
        }

        if (localMAXGBRDWLTracker) {
            if (localMAXGBRDWL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXGBRDWL cannot be null!!");
            }

            localMAXGBRDWL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXGBRDWL"), xmlWriter);
        }

        if (localAPNTracker) {
            if (localAPN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "APN cannot be null!!");
            }

            localAPN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "APN"), xmlWriter);
        }

        if (localVPLMNTracker) {
            if (localVPLMN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VPLMN cannot be null!!");
            }

            localVPLMN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VPLMN"), xmlWriter);
        }

        if (localCHARGETracker) {
            if (localCHARGE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CHARGE cannot be null!!");
            }

            localCHARGE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CHARGE"), xmlWriter);
        }

        if (localMAXEXTBRDWLTracker) {
            if (localMAXEXTBRDWL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXEXTBRDWL cannot be null!!");
            }

            localMAXEXTBRDWL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXEXTBRDWL"), xmlWriter);
        }

        if (localMAXEXTGBRDWLTracker) {
            if (localMAXEXTGBRDWL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXEXTGBRDWL cannot be null!!");
            }

            localMAXEXTGBRDWL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXEXTGBRDWL"), xmlWriter);
        }

        if (localPDPADDIPV4Tracker) {
            if (localPDPADDIPV4 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PDPADDIPV4 cannot be null!!");
            }

            localPDPADDIPV4.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PDPADDIPV4"), xmlWriter);
        }

        if (localADD2INDTracker) {
            if (localADD2IND == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ADD2IND cannot be null!!");
            }

            localADD2IND.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ADD2IND"), xmlWriter);
        }

        if (localSTDCHARGETracker) {
            if (localSTDCHARGE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "STDCHARGE cannot be null!!");
            }

            localSTDCHARGE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "STDCHARGE"), xmlWriter);
        }

        if (localSCHARGE_GLOBALTracker) {
            if (localSCHARGE_GLOBAL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SCHARGE_GLOBAL cannot be null!!");
            }

            localSCHARGE_GLOBAL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SCHARGE_GLOBAL"), xmlWriter);
        }

        if (localMAXEXTBRUPLTracker) {
            if (localMAXEXTBRUPL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXEXTBRUPL cannot be null!!");
            }

            localMAXEXTBRUPL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXEXTBRUPL"), xmlWriter);
        }

        if (localMAXEXTGBRUPLTracker) {
            if (localMAXEXTGBRUPL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXEXTGBRUPL cannot be null!!");
            }

            localMAXEXTGBRUPL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXEXTGBRUPL"), xmlWriter);
        }

        if (localAPNOITPLIDTracker) {
            if (localAPNOITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "APNOITPLID cannot be null!!");
            }

            localAPNOITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "APNOITPLID"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static LST_GPRSStruct1 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            LST_GPRSStruct1 object = new LST_GPRSStruct1();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"LST_GPRSStruct1".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (LST_GPRSStruct1) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSI").equals(
                            reader.getName())) {
                    object.setIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ISDN").equals(
                            reader.getName())) {
                    object.setISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CHARGE_GLOBAL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CHARGE_GLOBAL").equals(
                            reader.getName())) {
                    object.setCHARGE_GLOBAL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CNTXID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CNTXID").equals(
                            reader.getName())) {
                    object.setCNTXID(com.huawei.www.hss.Int1_50.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PDPTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PDPTYPE").equals(
                            reader.getName())) {
                    object.setPDPTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PDPADD").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PDPADD").equals(
                            reader.getName())) {
                    object.setPDPADD(com.huawei.www.hss.Str1_40.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ADDIND").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ADDIND").equals(
                            reader.getName())) {
                    object.setADDIND(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RELCLS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RELCLS").equals(
                            reader.getName())) {
                    object.setRELCLS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DELAYCLS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DELAYCLS").equals(
                            reader.getName())) {
                    object.setDELAYCLS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PRECLS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PRECLS").equals(
                            reader.getName())) {
                    object.setPRECLS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PEAKTHR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PEAKTHR").equals(
                            reader.getName())) {
                    object.setPEAKTHR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MEANTHR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MEANTHR").equals(
                            reader.getName())) {
                    object.setMEANTHR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ARPRIORITY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ARPRIORITY").equals(
                            reader.getName())) {
                    object.setARPRIORITY(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ERRSDU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ERRSDU").equals(
                            reader.getName())) {
                    object.setERRSDU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DELIVERY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DELIVERY").equals(
                            reader.getName())) {
                    object.setDELIVERY(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TRAFFICCLS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TRAFFICCLS").equals(
                            reader.getName())) {
                    object.setTRAFFICCLS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXSDUSIZE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXSDUSIZE").equals(
                            reader.getName())) {
                    object.setMAXSDUSIZE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXBRUPL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXBRUPL").equals(
                            reader.getName())) {
                    object.setMAXBRUPL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXBRDWL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXBRDWL").equals(
                            reader.getName())) {
                    object.setMAXBRDWL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RESBER").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RESBER").equals(
                            reader.getName())) {
                    object.setRESBER(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SDUERR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SDUERR").equals(
                            reader.getName())) {
                    object.setSDUERR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TRANSFERDEL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TRANSFERDEL").equals(
                            reader.getName())) {
                    object.setTRANSFERDEL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TRAFFICPRI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TRAFFICPRI").equals(
                            reader.getName())) {
                    object.setTRAFFICPRI(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXGBRUPL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXGBRUPL").equals(
                            reader.getName())) {
                    object.setMAXGBRUPL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXGBRDWL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXGBRDWL").equals(
                            reader.getName())) {
                    object.setMAXGBRDWL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "APN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "APN").equals(
                            reader.getName())) {
                    object.setAPN(com.huawei.www.hss.Str1_63.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VPLMN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VPLMN").equals(
                            reader.getName())) {
                    object.setVPLMN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CHARGE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CHARGE").equals(
                            reader.getName())) {
                    object.setCHARGE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXEXTBRDWL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXEXTBRDWL").equals(
                            reader.getName())) {
                    object.setMAXEXTBRDWL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXEXTGBRDWL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXEXTGBRDWL").equals(
                            reader.getName())) {
                    object.setMAXEXTGBRDWL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PDPADDIPV4").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PDPADDIPV4").equals(
                            reader.getName())) {
                    object.setPDPADDIPV4(com.huawei.www.hss.Str1_40.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ADD2IND").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ADD2IND").equals(
                            reader.getName())) {
                    object.setADD2IND(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "STDCHARGE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "STDCHARGE").equals(
                            reader.getName())) {
                    object.setSTDCHARGE(com.huawei.www.hss.Str4_4.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SCHARGE_GLOBAL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SCHARGE_GLOBAL").equals(
                            reader.getName())) {
                    object.setSCHARGE_GLOBAL(com.huawei.www.hss.Str4_4.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXEXTBRUPL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXEXTBRUPL").equals(
                            reader.getName())) {
                    object.setMAXEXTBRUPL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXEXTGBRUPL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXEXTGBRUPL").equals(
                            reader.getName())) {
                    object.setMAXEXTGBRUPL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "APNOITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "APNOITPLID").equals(
                            reader.getName())) {
                    object.setAPNOITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
