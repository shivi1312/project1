/**
 * EpsPdpData_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  EpsPdpData_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class EpsPdpData_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = EpsPdpData_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for EpsCntxId
     */
    protected com.huawei.www.hss.Int1_50 localEpsCntxId;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsCntxIdTracker = false;

    /**
     * field for EpsApnTplId
     */
    protected com.huawei.www.hss.Int0_65534 localEpsApnTplId;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsApnTplIdTracker = false;

    /**
     * field for EpsDefaultApn
     */
    protected com.huawei.www.hss._EnumType localEpsDefaultApn;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsDefaultApnTracker = false;

    /**
     * field for EpsWildCardApn
     */
    protected com.huawei.www.hss._EnumType localEpsWildCardApn;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsWildCardApnTracker = false;

    /**
     * field for EpsQosTplId
     */
    protected com.huawei.www.hss.Int0_65534 localEpsQosTplId;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsQosTplIdTracker = false;

    /**
     * field for EpsPdpType
     */
    protected com.huawei.www.hss._EnumType localEpsPdpType;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsPdpTypeTracker = false;

    /**
     * field for EpsAddInd
     */
    protected com.huawei.www.hss._EnumType localEpsAddInd;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsAddIndTracker = false;

    /**
     * field for EpsPdpAddIpv6
     */
    protected com.huawei.www.hss.Str1_40 localEpsPdpAddIpv6;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsPdpAddIpv6Tracker = false;

    /**
     * field for EpsAdd2Ind
     */
    protected com.huawei.www.hss._EnumType localEpsAdd2Ind;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsAdd2IndTracker = false;

    /**
     * field for EpsPdpAddIpv4
     */
    protected com.huawei.www.hss.Str7_15 localEpsPdpAddIpv4;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsPdpAddIpv4Tracker = false;

    /**
     * field for EpsVplmnAllowed
     */
    protected com.huawei.www.hss._EnumType localEpsVplmnAllowed;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsVplmnAllowedTracker = false;

    /**
     * field for EpsCharge
     */
    protected com.huawei.www.hss._EnumType localEpsCharge;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsChargeTracker = false;

    /**
     * field for EpsStdCharge
     */
    protected com.huawei.www.hss.Str4_4 localEpsStdCharge;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsStdChargeTracker = false;

    /**
     * field for EpsApnoiTplId
     */
    protected com.huawei.www.hss.Int0_65534 localEpsApnoiTplId;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEpsApnoiTplIdTracker = false;

    public boolean isEpsCntxIdSpecified() {
        return localEpsCntxIdTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_50
     */
    public com.huawei.www.hss.Int1_50 getEpsCntxId() {
        return localEpsCntxId;
    }

    /**
     * Auto generated setter method
     * @param param EpsCntxId
     */
    public void setEpsCntxId(com.huawei.www.hss.Int1_50 param) {
        localEpsCntxIdTracker = param != null;

        this.localEpsCntxId = param;
    }

    public boolean isEpsApnTplIdSpecified() {
        return localEpsApnTplIdTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getEpsApnTplId() {
        return localEpsApnTplId;
    }

    /**
     * Auto generated setter method
     * @param param EpsApnTplId
     */
    public void setEpsApnTplId(com.huawei.www.hss.Int0_65534 param) {
        localEpsApnTplIdTracker = param != null;

        this.localEpsApnTplId = param;
    }

    public boolean isEpsDefaultApnSpecified() {
        return localEpsDefaultApnTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEpsDefaultApn() {
        return localEpsDefaultApn;
    }

    /**
     * Auto generated setter method
     * @param param EpsDefaultApn
     */
    public void setEpsDefaultApn(com.huawei.www.hss._EnumType param) {
        localEpsDefaultApnTracker = param != null;

        this.localEpsDefaultApn = param;
    }

    public boolean isEpsWildCardApnSpecified() {
        return localEpsWildCardApnTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEpsWildCardApn() {
        return localEpsWildCardApn;
    }

    /**
     * Auto generated setter method
     * @param param EpsWildCardApn
     */
    public void setEpsWildCardApn(com.huawei.www.hss._EnumType param) {
        localEpsWildCardApnTracker = param != null;

        this.localEpsWildCardApn = param;
    }

    public boolean isEpsQosTplIdSpecified() {
        return localEpsQosTplIdTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getEpsQosTplId() {
        return localEpsQosTplId;
    }

    /**
     * Auto generated setter method
     * @param param EpsQosTplId
     */
    public void setEpsQosTplId(com.huawei.www.hss.Int0_65534 param) {
        localEpsQosTplIdTracker = param != null;

        this.localEpsQosTplId = param;
    }

    public boolean isEpsPdpTypeSpecified() {
        return localEpsPdpTypeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEpsPdpType() {
        return localEpsPdpType;
    }

    /**
     * Auto generated setter method
     * @param param EpsPdpType
     */
    public void setEpsPdpType(com.huawei.www.hss._EnumType param) {
        localEpsPdpTypeTracker = param != null;

        this.localEpsPdpType = param;
    }

    public boolean isEpsAddIndSpecified() {
        return localEpsAddIndTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEpsAddInd() {
        return localEpsAddInd;
    }

    /**
     * Auto generated setter method
     * @param param EpsAddInd
     */
    public void setEpsAddInd(com.huawei.www.hss._EnumType param) {
        localEpsAddIndTracker = param != null;

        this.localEpsAddInd = param;
    }

    public boolean isEpsPdpAddIpv6Specified() {
        return localEpsPdpAddIpv6Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_40
     */
    public com.huawei.www.hss.Str1_40 getEpsPdpAddIpv6() {
        return localEpsPdpAddIpv6;
    }

    /**
     * Auto generated setter method
     * @param param EpsPdpAddIpv6
     */
    public void setEpsPdpAddIpv6(com.huawei.www.hss.Str1_40 param) {
        localEpsPdpAddIpv6Tracker = param != null;

        this.localEpsPdpAddIpv6 = param;
    }

    public boolean isEpsAdd2IndSpecified() {
        return localEpsAdd2IndTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEpsAdd2Ind() {
        return localEpsAdd2Ind;
    }

    /**
     * Auto generated setter method
     * @param param EpsAdd2Ind
     */
    public void setEpsAdd2Ind(com.huawei.www.hss._EnumType param) {
        localEpsAdd2IndTracker = param != null;

        this.localEpsAdd2Ind = param;
    }

    public boolean isEpsPdpAddIpv4Specified() {
        return localEpsPdpAddIpv4Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str7_15
     */
    public com.huawei.www.hss.Str7_15 getEpsPdpAddIpv4() {
        return localEpsPdpAddIpv4;
    }

    /**
     * Auto generated setter method
     * @param param EpsPdpAddIpv4
     */
    public void setEpsPdpAddIpv4(com.huawei.www.hss.Str7_15 param) {
        localEpsPdpAddIpv4Tracker = param != null;

        this.localEpsPdpAddIpv4 = param;
    }

    public boolean isEpsVplmnAllowedSpecified() {
        return localEpsVplmnAllowedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEpsVplmnAllowed() {
        return localEpsVplmnAllowed;
    }

    /**
     * Auto generated setter method
     * @param param EpsVplmnAllowed
     */
    public void setEpsVplmnAllowed(com.huawei.www.hss._EnumType param) {
        localEpsVplmnAllowedTracker = param != null;

        this.localEpsVplmnAllowed = param;
    }

    public boolean isEpsChargeSpecified() {
        return localEpsChargeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEpsCharge() {
        return localEpsCharge;
    }

    /**
     * Auto generated setter method
     * @param param EpsCharge
     */
    public void setEpsCharge(com.huawei.www.hss._EnumType param) {
        localEpsChargeTracker = param != null;

        this.localEpsCharge = param;
    }

    public boolean isEpsStdChargeSpecified() {
        return localEpsStdChargeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str4_4
     */
    public com.huawei.www.hss.Str4_4 getEpsStdCharge() {
        return localEpsStdCharge;
    }

    /**
     * Auto generated setter method
     * @param param EpsStdCharge
     */
    public void setEpsStdCharge(com.huawei.www.hss.Str4_4 param) {
        localEpsStdChargeTracker = param != null;

        this.localEpsStdCharge = param;
    }

    public boolean isEpsApnoiTplIdSpecified() {
        return localEpsApnoiTplIdTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getEpsApnoiTplId() {
        return localEpsApnoiTplId;
    }

    /**
     * Auto generated setter method
     * @param param EpsApnoiTplId
     */
    public void setEpsApnoiTplId(com.huawei.www.hss.Int0_65534 param) {
        localEpsApnoiTplIdTracker = param != null;

        this.localEpsApnoiTplId = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":EpsPdpData_type0", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "EpsPdpData_type0", xmlWriter);
            }
        }

        if (localEpsCntxIdTracker) {
            if (localEpsCntxId == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsCntxId cannot be null!!");
            }

            localEpsCntxId.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsCntxId"), xmlWriter);
        }

        if (localEpsApnTplIdTracker) {
            if (localEpsApnTplId == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsApnTplId cannot be null!!");
            }

            localEpsApnTplId.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsApnTplId"), xmlWriter);
        }

        if (localEpsDefaultApnTracker) {
            if (localEpsDefaultApn == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsDefaultApn cannot be null!!");
            }

            localEpsDefaultApn.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsDefaultApn"), xmlWriter);
        }

        if (localEpsWildCardApnTracker) {
            if (localEpsWildCardApn == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsWildCardApn cannot be null!!");
            }

            localEpsWildCardApn.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsWildCardApn"), xmlWriter);
        }

        if (localEpsQosTplIdTracker) {
            if (localEpsQosTplId == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsQosTplId cannot be null!!");
            }

            localEpsQosTplId.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsQosTplId"), xmlWriter);
        }

        if (localEpsPdpTypeTracker) {
            if (localEpsPdpType == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsPdpType cannot be null!!");
            }

            localEpsPdpType.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsPdpType"), xmlWriter);
        }

        if (localEpsAddIndTracker) {
            if (localEpsAddInd == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsAddInd cannot be null!!");
            }

            localEpsAddInd.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsAddInd"), xmlWriter);
        }

        if (localEpsPdpAddIpv6Tracker) {
            if (localEpsPdpAddIpv6 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsPdpAddIpv6 cannot be null!!");
            }

            localEpsPdpAddIpv6.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsPdpAddIpv6"), xmlWriter);
        }

        if (localEpsAdd2IndTracker) {
            if (localEpsAdd2Ind == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsAdd2Ind cannot be null!!");
            }

            localEpsAdd2Ind.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsAdd2Ind"), xmlWriter);
        }

        if (localEpsPdpAddIpv4Tracker) {
            if (localEpsPdpAddIpv4 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsPdpAddIpv4 cannot be null!!");
            }

            localEpsPdpAddIpv4.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsPdpAddIpv4"), xmlWriter);
        }

        if (localEpsVplmnAllowedTracker) {
            if (localEpsVplmnAllowed == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsVplmnAllowed cannot be null!!");
            }

            localEpsVplmnAllowed.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsVplmnAllowed"), xmlWriter);
        }

        if (localEpsChargeTracker) {
            if (localEpsCharge == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsCharge cannot be null!!");
            }

            localEpsCharge.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsCharge"), xmlWriter);
        }

        if (localEpsStdChargeTracker) {
            if (localEpsStdCharge == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsStdCharge cannot be null!!");
            }

            localEpsStdCharge.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsStdCharge"), xmlWriter);
        }

        if (localEpsApnoiTplIdTracker) {
            if (localEpsApnoiTplId == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EpsApnoiTplId cannot be null!!");
            }

            localEpsApnoiTplId.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EpsApnoiTplId"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static EpsPdpData_type0 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            EpsPdpData_type0 object = new EpsPdpData_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"EpsPdpData_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (EpsPdpData_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsCntxId").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsCntxId").equals(
                            reader.getName())) {
                    object.setEpsCntxId(com.huawei.www.hss.Int1_50.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsApnTplId").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsApnTplId").equals(
                            reader.getName())) {
                    object.setEpsApnTplId(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsDefaultApn").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsDefaultApn").equals(
                            reader.getName())) {
                    object.setEpsDefaultApn(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsWildCardApn").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsWildCardApn").equals(
                            reader.getName())) {
                    object.setEpsWildCardApn(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsQosTplId").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsQosTplId").equals(
                            reader.getName())) {
                    object.setEpsQosTplId(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsPdpType").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsPdpType").equals(
                            reader.getName())) {
                    object.setEpsPdpType(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsAddInd").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsAddInd").equals(
                            reader.getName())) {
                    object.setEpsAddInd(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsPdpAddIpv6").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsPdpAddIpv6").equals(
                            reader.getName())) {
                    object.setEpsPdpAddIpv6(com.huawei.www.hss.Str1_40.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsAdd2Ind").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsAdd2Ind").equals(
                            reader.getName())) {
                    object.setEpsAdd2Ind(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsPdpAddIpv4").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsPdpAddIpv4").equals(
                            reader.getName())) {
                    object.setEpsPdpAddIpv4(com.huawei.www.hss.Str7_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsVplmnAllowed").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsVplmnAllowed").equals(
                            reader.getName())) {
                    object.setEpsVplmnAllowed(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsCharge").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsCharge").equals(
                            reader.getName())) {
                    object.setEpsCharge(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsStdCharge").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsStdCharge").equals(
                            reader.getName())) {
                    object.setEpsStdCharge(com.huawei.www.hss.Str4_4.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EpsApnoiTplId").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EpsApnoiTplId").equals(
                            reader.getName())) {
                    object.setEpsApnoiTplId(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
