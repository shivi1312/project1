/**
 * LST_EPSStruct1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  LST_EPSStruct1 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class LST_EPSStruct1 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = LST_EPSStruct1
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for IMSI
     */
    protected com.huawei.www.hss.Str6_15 localIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSITracker = false;

    /**
     * field for ISDN
     */
    protected com.huawei.www.hss.Str1_15 localISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localISDNTracker = false;

    /**
     * field for PROV
     */
    protected com.huawei.www.hss._EnumType localPROV;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPROVTracker = false;

    /**
     * field for STNSR
     */
    protected com.huawei.www.hss.Str3_15 localSTNSR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSTNSRTracker = false;

    /**
     * field for APNOIUE
     */
    protected com.huawei.www.hss.Str1_63 localAPNOIUE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAPNOIUETracker = false;

    /**
     * field for AMBRMAXUL
     */
    protected com.huawei.www.hss.Int0_4294967295 localAMBRMAXUL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAMBRMAXULTracker = false;

    /**
     * field for AMBRMAXDL
     */
    protected com.huawei.www.hss.Int0_4294967295 localAMBRMAXDL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAMBRMAXDLTracker = false;

    /**
     * field for RATFREQSELPRIID
     */
    protected com.huawei.www.hss.Int1_256 localRATFREQSELPRIID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRATFREQSELPRIIDTracker = false;

    /**
     * field for PLMNTPLID
     */
    protected com.huawei.www.hss.Int0_65534 localPLMNTPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPLMNTPLIDTracker = false;

    /**
     * field for DIAMNODETPL_ID
     */
    protected com.huawei.www.hss.Int0_65534 localDIAMNODETPL_ID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDIAMNODETPL_IDTracker = false;

    /**
     * field for ANCHOR
     */
    protected com.huawei.www.hss._EnumType localANCHOR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localANCHORTracker = false;

    /**
     * field for ICSIND
     */
    protected com.huawei.www.hss._EnumType localICSIND;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localICSINDTracker = false;

    /**
     * field for MDT
     */
    protected com.huawei.www.hss._EnumType localMDT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMDTTracker = false;

    /**
     * field for LTEAUTOPROV
     */
    protected com.huawei.www.hss._EnumType localLTEAUTOPROV;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLTEAUTOPROVTracker = false;

    /**
     * field for MPS
     */
    protected com.huawei.www.hss._EnumType localMPS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMPSTracker = false;

    /**
     * field for TAUTIMER
     */
    protected com.huawei.www.hss.Int0_43200 localTAUTIMER;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTAUTIMERTracker = false;

    /**
     * field for RELAY_NODE
     */
    protected com.huawei.www.hss._EnumType localRELAY_NODE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRELAY_NODETracker = false;

    /**
     * field for VOLTETAG
     */
    protected com.huawei.www.hss._EnumType localVOLTETAG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVOLTETAGTracker = false;

    /**
     * field for SWXPLMNTPLID
     */
    protected com.huawei.www.hss.Int0_65534 localSWXPLMNTPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSWXPLMNTPLIDTracker = false;

    /**
     * field for EPSODBPOS
     */
    protected com.huawei.www.hss._EnumType localEPSODBPOS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEPSODBPOSTracker = false;

    /**
     * field for LTE_M2M_FLAG
     */
    protected com.huawei.www.hss._EnumType localLTE_M2M_FLAG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLTE_M2M_FLAGTracker = false;

    public boolean isIMSISpecified() {
        return localIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getIMSI() {
        return localIMSI;
    }

    /**
     * Auto generated setter method
     * @param param IMSI
     */
    public void setIMSI(com.huawei.www.hss.Str6_15 param) {
        localIMSITracker = param != null;

        this.localIMSI = param;
    }

    public boolean isISDNSpecified() {
        return localISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getISDN() {
        return localISDN;
    }

    /**
     * Auto generated setter method
     * @param param ISDN
     */
    public void setISDN(com.huawei.www.hss.Str1_15 param) {
        localISDNTracker = param != null;

        this.localISDN = param;
    }

    public boolean isPROVSpecified() {
        return localPROVTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPROV() {
        return localPROV;
    }

    /**
     * Auto generated setter method
     * @param param PROV
     */
    public void setPROV(com.huawei.www.hss._EnumType param) {
        localPROVTracker = param != null;

        this.localPROV = param;
    }

    public boolean isSTNSRSpecified() {
        return localSTNSRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str3_15
     */
    public com.huawei.www.hss.Str3_15 getSTNSR() {
        return localSTNSR;
    }

    /**
     * Auto generated setter method
     * @param param STNSR
     */
    public void setSTNSR(com.huawei.www.hss.Str3_15 param) {
        localSTNSRTracker = param != null;

        this.localSTNSR = param;
    }

    public boolean isAPNOIUESpecified() {
        return localAPNOIUETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_63
     */
    public com.huawei.www.hss.Str1_63 getAPNOIUE() {
        return localAPNOIUE;
    }

    /**
     * Auto generated setter method
     * @param param APNOIUE
     */
    public void setAPNOIUE(com.huawei.www.hss.Str1_63 param) {
        localAPNOIUETracker = param != null;

        this.localAPNOIUE = param;
    }

    public boolean isAMBRMAXULSpecified() {
        return localAMBRMAXULTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_4294967295
     */
    public com.huawei.www.hss.Int0_4294967295 getAMBRMAXUL() {
        return localAMBRMAXUL;
    }

    /**
     * Auto generated setter method
     * @param param AMBRMAXUL
     */
    public void setAMBRMAXUL(com.huawei.www.hss.Int0_4294967295 param) {
        localAMBRMAXULTracker = param != null;

        this.localAMBRMAXUL = param;
    }

    public boolean isAMBRMAXDLSpecified() {
        return localAMBRMAXDLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_4294967295
     */
    public com.huawei.www.hss.Int0_4294967295 getAMBRMAXDL() {
        return localAMBRMAXDL;
    }

    /**
     * Auto generated setter method
     * @param param AMBRMAXDL
     */
    public void setAMBRMAXDL(com.huawei.www.hss.Int0_4294967295 param) {
        localAMBRMAXDLTracker = param != null;

        this.localAMBRMAXDL = param;
    }

    public boolean isRATFREQSELPRIIDSpecified() {
        return localRATFREQSELPRIIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_256
     */
    public com.huawei.www.hss.Int1_256 getRATFREQSELPRIID() {
        return localRATFREQSELPRIID;
    }

    /**
     * Auto generated setter method
     * @param param RATFREQSELPRIID
     */
    public void setRATFREQSELPRIID(com.huawei.www.hss.Int1_256 param) {
        localRATFREQSELPRIIDTracker = param != null;

        this.localRATFREQSELPRIID = param;
    }

    public boolean isPLMNTPLIDSpecified() {
        return localPLMNTPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getPLMNTPLID() {
        return localPLMNTPLID;
    }

    /**
     * Auto generated setter method
     * @param param PLMNTPLID
     */
    public void setPLMNTPLID(com.huawei.www.hss.Int0_65534 param) {
        localPLMNTPLIDTracker = param != null;

        this.localPLMNTPLID = param;
    }

    public boolean isDIAMNODETPL_IDSpecified() {
        return localDIAMNODETPL_IDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getDIAMNODETPL_ID() {
        return localDIAMNODETPL_ID;
    }

    /**
     * Auto generated setter method
     * @param param DIAMNODETPL_ID
     */
    public void setDIAMNODETPL_ID(com.huawei.www.hss.Int0_65534 param) {
        localDIAMNODETPL_IDTracker = param != null;

        this.localDIAMNODETPL_ID = param;
    }

    public boolean isANCHORSpecified() {
        return localANCHORTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getANCHOR() {
        return localANCHOR;
    }

    /**
     * Auto generated setter method
     * @param param ANCHOR
     */
    public void setANCHOR(com.huawei.www.hss._EnumType param) {
        localANCHORTracker = param != null;

        this.localANCHOR = param;
    }

    public boolean isICSINDSpecified() {
        return localICSINDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getICSIND() {
        return localICSIND;
    }

    /**
     * Auto generated setter method
     * @param param ICSIND
     */
    public void setICSIND(com.huawei.www.hss._EnumType param) {
        localICSINDTracker = param != null;

        this.localICSIND = param;
    }

    public boolean isMDTSpecified() {
        return localMDTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMDT() {
        return localMDT;
    }

    /**
     * Auto generated setter method
     * @param param MDT
     */
    public void setMDT(com.huawei.www.hss._EnumType param) {
        localMDTTracker = param != null;

        this.localMDT = param;
    }

    public boolean isLTEAUTOPROVSpecified() {
        return localLTEAUTOPROVTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getLTEAUTOPROV() {
        return localLTEAUTOPROV;
    }

    /**
     * Auto generated setter method
     * @param param LTEAUTOPROV
     */
    public void setLTEAUTOPROV(com.huawei.www.hss._EnumType param) {
        localLTEAUTOPROVTracker = param != null;

        this.localLTEAUTOPROV = param;
    }

    public boolean isMPSSpecified() {
        return localMPSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMPS() {
        return localMPS;
    }

    /**
     * Auto generated setter method
     * @param param MPS
     */
    public void setMPS(com.huawei.www.hss._EnumType param) {
        localMPSTracker = param != null;

        this.localMPS = param;
    }

    public boolean isTAUTIMERSpecified() {
        return localTAUTIMERTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_43200
     */
    public com.huawei.www.hss.Int0_43200 getTAUTIMER() {
        return localTAUTIMER;
    }

    /**
     * Auto generated setter method
     * @param param TAUTIMER
     */
    public void setTAUTIMER(com.huawei.www.hss.Int0_43200 param) {
        localTAUTIMERTracker = param != null;

        this.localTAUTIMER = param;
    }

    public boolean isRELAY_NODESpecified() {
        return localRELAY_NODETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRELAY_NODE() {
        return localRELAY_NODE;
    }

    /**
     * Auto generated setter method
     * @param param RELAY_NODE
     */
    public void setRELAY_NODE(com.huawei.www.hss._EnumType param) {
        localRELAY_NODETracker = param != null;

        this.localRELAY_NODE = param;
    }

    public boolean isVOLTETAGSpecified() {
        return localVOLTETAGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVOLTETAG() {
        return localVOLTETAG;
    }

    /**
     * Auto generated setter method
     * @param param VOLTETAG
     */
    public void setVOLTETAG(com.huawei.www.hss._EnumType param) {
        localVOLTETAGTracker = param != null;

        this.localVOLTETAG = param;
    }

    public boolean isSWXPLMNTPLIDSpecified() {
        return localSWXPLMNTPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getSWXPLMNTPLID() {
        return localSWXPLMNTPLID;
    }

    /**
     * Auto generated setter method
     * @param param SWXPLMNTPLID
     */
    public void setSWXPLMNTPLID(com.huawei.www.hss.Int0_65534 param) {
        localSWXPLMNTPLIDTracker = param != null;

        this.localSWXPLMNTPLID = param;
    }

    public boolean isEPSODBPOSSpecified() {
        return localEPSODBPOSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEPSODBPOS() {
        return localEPSODBPOS;
    }

    /**
     * Auto generated setter method
     * @param param EPSODBPOS
     */
    public void setEPSODBPOS(com.huawei.www.hss._EnumType param) {
        localEPSODBPOSTracker = param != null;

        this.localEPSODBPOS = param;
    }

    public boolean isLTE_M2M_FLAGSpecified() {
        return localLTE_M2M_FLAGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getLTE_M2M_FLAG() {
        return localLTE_M2M_FLAG;
    }

    /**
     * Auto generated setter method
     * @param param LTE_M2M_FLAG
     */
    public void setLTE_M2M_FLAG(com.huawei.www.hss._EnumType param) {
        localLTE_M2M_FLAGTracker = param != null;

        this.localLTE_M2M_FLAG = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":LST_EPSStruct1", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "LST_EPSStruct1", xmlWriter);
            }
        }

        if (localIMSITracker) {
            if (localIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMSI cannot be null!!");
            }

            localIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMSI"), xmlWriter);
        }

        if (localISDNTracker) {
            if (localISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ISDN cannot be null!!");
            }

            localISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ISDN"), xmlWriter);
        }

        if (localPROVTracker) {
            if (localPROV == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PROV cannot be null!!");
            }

            localPROV.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PROV"), xmlWriter);
        }

        if (localSTNSRTracker) {
            if (localSTNSR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "STN-SR cannot be null!!");
            }

            localSTNSR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "STN-SR"), xmlWriter);
        }

        if (localAPNOIUETracker) {
            if (localAPNOIUE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "APNOI-UE cannot be null!!");
            }

            localAPNOIUE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "APNOI-UE"), xmlWriter);
        }

        if (localAMBRMAXULTracker) {
            if (localAMBRMAXUL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AMBRMAXUL cannot be null!!");
            }

            localAMBRMAXUL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AMBRMAXUL"), xmlWriter);
        }

        if (localAMBRMAXDLTracker) {
            if (localAMBRMAXDL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AMBRMAXDL cannot be null!!");
            }

            localAMBRMAXDL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AMBRMAXDL"), xmlWriter);
        }

        if (localRATFREQSELPRIIDTracker) {
            if (localRATFREQSELPRIID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RATFREQSELPRIID cannot be null!!");
            }

            localRATFREQSELPRIID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RATFREQSELPRIID"), xmlWriter);
        }

        if (localPLMNTPLIDTracker) {
            if (localPLMNTPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PLMNTPLID cannot be null!!");
            }

            localPLMNTPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PLMNTPLID"), xmlWriter);
        }

        if (localDIAMNODETPL_IDTracker) {
            if (localDIAMNODETPL_ID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DIAMNODETPL_ID cannot be null!!");
            }

            localDIAMNODETPL_ID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DIAMNODETPL_ID"), xmlWriter);
        }

        if (localANCHORTracker) {
            if (localANCHOR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ANCHOR cannot be null!!");
            }

            localANCHOR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ANCHOR"), xmlWriter);
        }

        if (localICSINDTracker) {
            if (localICSIND == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ICSIND cannot be null!!");
            }

            localICSIND.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ICSIND"), xmlWriter);
        }

        if (localMDTTracker) {
            if (localMDT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MDT cannot be null!!");
            }

            localMDT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MDT"), xmlWriter);
        }

        if (localLTEAUTOPROVTracker) {
            if (localLTEAUTOPROV == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LTEAUTOPROV cannot be null!!");
            }

            localLTEAUTOPROV.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LTEAUTOPROV"), xmlWriter);
        }

        if (localMPSTracker) {
            if (localMPS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MPS cannot be null!!");
            }

            localMPS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MPS"), xmlWriter);
        }

        if (localTAUTIMERTracker) {
            if (localTAUTIMER == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TAUTIMER cannot be null!!");
            }

            localTAUTIMER.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TAUTIMER"), xmlWriter);
        }

        if (localRELAY_NODETracker) {
            if (localRELAY_NODE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RELAY_NODE cannot be null!!");
            }

            localRELAY_NODE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RELAY_NODE"), xmlWriter);
        }

        if (localVOLTETAGTracker) {
            if (localVOLTETAG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VOLTETAG cannot be null!!");
            }

            localVOLTETAG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VOLTETAG"), xmlWriter);
        }

        if (localSWXPLMNTPLIDTracker) {
            if (localSWXPLMNTPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SWXPLMNTPLID cannot be null!!");
            }

            localSWXPLMNTPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SWXPLMNTPLID"), xmlWriter);
        }

        if (localEPSODBPOSTracker) {
            if (localEPSODBPOS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EPSODBPOS cannot be null!!");
            }

            localEPSODBPOS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EPSODBPOS"), xmlWriter);
        }

        if (localLTE_M2M_FLAGTracker) {
            if (localLTE_M2M_FLAG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LTE_M2M_FLAG cannot be null!!");
            }

            localLTE_M2M_FLAG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LTE_M2M_FLAG"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static LST_EPSStruct1 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            LST_EPSStruct1 object = new LST_EPSStruct1();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"LST_EPSStruct1".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (LST_EPSStruct1) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSI").equals(
                            reader.getName())) {
                    object.setIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ISDN").equals(
                            reader.getName())) {
                    object.setISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PROV").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PROV").equals(
                            reader.getName())) {
                    object.setPROV(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "STN-SR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "STN-SR").equals(
                            reader.getName())) {
                    object.setSTNSR(com.huawei.www.hss.Str3_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "APNOI-UE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "APNOI-UE").equals(
                            reader.getName())) {
                    object.setAPNOIUE(com.huawei.www.hss.Str1_63.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AMBRMAXUL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AMBRMAXUL").equals(
                            reader.getName())) {
                    object.setAMBRMAXUL(com.huawei.www.hss.Int0_4294967295.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AMBRMAXDL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AMBRMAXDL").equals(
                            reader.getName())) {
                    object.setAMBRMAXDL(com.huawei.www.hss.Int0_4294967295.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RATFREQSELPRIID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RATFREQSELPRIID").equals(
                            reader.getName())) {
                    object.setRATFREQSELPRIID(com.huawei.www.hss.Int1_256.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PLMNTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PLMNTPLID").equals(
                            reader.getName())) {
                    object.setPLMNTPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DIAMNODETPL_ID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DIAMNODETPL_ID").equals(
                            reader.getName())) {
                    object.setDIAMNODETPL_ID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ANCHOR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ANCHOR").equals(
                            reader.getName())) {
                    object.setANCHOR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ICSIND").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ICSIND").equals(
                            reader.getName())) {
                    object.setICSIND(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MDT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MDT").equals(
                            reader.getName())) {
                    object.setMDT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LTEAUTOPROV").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LTEAUTOPROV").equals(
                            reader.getName())) {
                    object.setLTEAUTOPROV(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MPS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MPS").equals(
                            reader.getName())) {
                    object.setMPS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TAUTIMER").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TAUTIMER").equals(
                            reader.getName())) {
                    object.setTAUTIMER(com.huawei.www.hss.Int0_43200.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RELAY_NODE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RELAY_NODE").equals(
                            reader.getName())) {
                    object.setRELAY_NODE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VOLTETAG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VOLTETAG").equals(
                            reader.getName())) {
                    object.setVOLTETAG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SWXPLMNTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SWXPLMNTPLID").equals(
                            reader.getName())) {
                    object.setSWXPLMNTPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EPSODBPOS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EPSODBPOS").equals(
                            reader.getName())) {
                    object.setEPSODBPOS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LTE_M2M_FLAG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LTE_M2M_FLAG").equals(
                            reader.getName())) {
                    object.setLTE_M2M_FLAG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
