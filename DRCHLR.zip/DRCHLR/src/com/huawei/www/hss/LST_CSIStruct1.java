/**
 * LST_CSIStruct1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  LST_CSIStruct1 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class LST_CSIStruct1 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = LST_CSIStruct1
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for IMSI
     */
    protected com.huawei.www.hss.Str6_15 localIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSITracker = false;

    /**
     * field for ISDN
     */
    protected com.huawei.www.hss.Str1_15 localISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localISDNTracker = false;

    /**
     * field for OCSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localOCSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localOCSITPLIDTracker = false;

    /**
     * field for TCSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localTCSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTCSITPLIDTracker = false;

    /**
     * field for VTCSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localVTCSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVTCSITPLIDTracker = false;

    /**
     * field for UCSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localUCSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUCSITPLIDTracker = false;

    /**
     * field for SSCSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localSSCSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSSCSITPLIDTracker = false;

    /**
     * field for TIFCSIPROV
     */
    protected com.huawei.www.hss._EnumType localTIFCSIPROV;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTIFCSIPROVTracker = false;

    /**
     * field for MCSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localMCSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMCSITPLIDTracker = false;

    /**
     * field for MOSMSCSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localMOSMSCSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMOSMSCSITPLIDTracker = false;

    /**
     * field for MTSMSCSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localMTSMSCSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMTSMSCSITPLIDTracker = false;

    /**
     * field for GPRSCSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localGPRSCSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGPRSCSITPLIDTracker = false;

    /**
     * field for DCSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localDCSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDCSITPLIDTracker = false;

    /**
     * field for OCSISTATE
     */
    protected com.huawei.www.hss._EnumType localOCSISTATE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localOCSISTATETracker = false;

    /**
     * field for TCSISTATE
     */
    protected com.huawei.www.hss._EnumType localTCSISTATE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTCSISTATETracker = false;

    /**
     * field for VTCSISTATE
     */
    protected com.huawei.www.hss._EnumType localVTCSISTATE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVTCSISTATETracker = false;

    /**
     * field for SSCSISTATE
     */
    protected com.huawei.www.hss._EnumType localSSCSISTATE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSSCSISTATETracker = false;

    /**
     * field for TIFCSISTATE
     */
    protected com.huawei.www.hss._EnumType localTIFCSISTATE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTIFCSISTATETracker = false;

    /**
     * field for MCSISTATE
     */
    protected com.huawei.www.hss._EnumType localMCSISTATE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMCSISTATETracker = false;

    /**
     * field for MOSMSCSISTATE
     */
    protected com.huawei.www.hss._EnumType localMOSMSCSISTATE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMOSMSCSISTATETracker = false;

    /**
     * field for MTSMSCSISTATE
     */
    protected com.huawei.www.hss._EnumType localMTSMSCSISTATE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMTSMSCSISTATETracker = false;

    /**
     * field for GPRSCSISTATE
     */
    protected com.huawei.www.hss._EnumType localGPRSCSISTATE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGPRSCSISTATETracker = false;

    /**
     * field for DCSISTATE
     */
    protected com.huawei.www.hss._EnumType localDCSISTATE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDCSISTATETracker = false;

    /**
     * field for IM_OCSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localIM_OCSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIM_OCSITPLIDTracker = false;

    /**
     * field for IM_VTCSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localIM_VTCSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIM_VTCSITPLIDTracker = false;

    public boolean isIMSISpecified() {
        return localIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getIMSI() {
        return localIMSI;
    }

    /**
     * Auto generated setter method
     * @param param IMSI
     */
    public void setIMSI(com.huawei.www.hss.Str6_15 param) {
        localIMSITracker = param != null;

        this.localIMSI = param;
    }

    public boolean isISDNSpecified() {
        return localISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getISDN() {
        return localISDN;
    }

    /**
     * Auto generated setter method
     * @param param ISDN
     */
    public void setISDN(com.huawei.www.hss.Str1_15 param) {
        localISDNTracker = param != null;

        this.localISDN = param;
    }

    public boolean isOCSITPLIDSpecified() {
        return localOCSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getOCSITPLID() {
        return localOCSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param OCSITPLID
     */
    public void setOCSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localOCSITPLIDTracker = param != null;

        this.localOCSITPLID = param;
    }

    public boolean isTCSITPLIDSpecified() {
        return localTCSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getTCSITPLID() {
        return localTCSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param TCSITPLID
     */
    public void setTCSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localTCSITPLIDTracker = param != null;

        this.localTCSITPLID = param;
    }

    public boolean isVTCSITPLIDSpecified() {
        return localVTCSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getVTCSITPLID() {
        return localVTCSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param VTCSITPLID
     */
    public void setVTCSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localVTCSITPLIDTracker = param != null;

        this.localVTCSITPLID = param;
    }

    public boolean isUCSITPLIDSpecified() {
        return localUCSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getUCSITPLID() {
        return localUCSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param UCSITPLID
     */
    public void setUCSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localUCSITPLIDTracker = param != null;

        this.localUCSITPLID = param;
    }

    public boolean isSSCSITPLIDSpecified() {
        return localSSCSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getSSCSITPLID() {
        return localSSCSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param SSCSITPLID
     */
    public void setSSCSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localSSCSITPLIDTracker = param != null;

        this.localSSCSITPLID = param;
    }

    public boolean isTIFCSIPROVSpecified() {
        return localTIFCSIPROVTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTIFCSIPROV() {
        return localTIFCSIPROV;
    }

    /**
     * Auto generated setter method
     * @param param TIFCSIPROV
     */
    public void setTIFCSIPROV(com.huawei.www.hss._EnumType param) {
        localTIFCSIPROVTracker = param != null;

        this.localTIFCSIPROV = param;
    }

    public boolean isMCSITPLIDSpecified() {
        return localMCSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getMCSITPLID() {
        return localMCSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param MCSITPLID
     */
    public void setMCSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localMCSITPLIDTracker = param != null;

        this.localMCSITPLID = param;
    }

    public boolean isMOSMSCSITPLIDSpecified() {
        return localMOSMSCSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getMOSMSCSITPLID() {
        return localMOSMSCSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param MOSMSCSITPLID
     */
    public void setMOSMSCSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localMOSMSCSITPLIDTracker = param != null;

        this.localMOSMSCSITPLID = param;
    }

    public boolean isMTSMSCSITPLIDSpecified() {
        return localMTSMSCSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getMTSMSCSITPLID() {
        return localMTSMSCSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param MTSMSCSITPLID
     */
    public void setMTSMSCSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localMTSMSCSITPLIDTracker = param != null;

        this.localMTSMSCSITPLID = param;
    }

    public boolean isGPRSCSITPLIDSpecified() {
        return localGPRSCSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getGPRSCSITPLID() {
        return localGPRSCSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param GPRSCSITPLID
     */
    public void setGPRSCSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localGPRSCSITPLIDTracker = param != null;

        this.localGPRSCSITPLID = param;
    }

    public boolean isDCSITPLIDSpecified() {
        return localDCSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getDCSITPLID() {
        return localDCSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param DCSITPLID
     */
    public void setDCSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localDCSITPLIDTracker = param != null;

        this.localDCSITPLID = param;
    }

    public boolean isOCSISTATESpecified() {
        return localOCSISTATETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getOCSISTATE() {
        return localOCSISTATE;
    }

    /**
     * Auto generated setter method
     * @param param OCSISTATE
     */
    public void setOCSISTATE(com.huawei.www.hss._EnumType param) {
        localOCSISTATETracker = param != null;

        this.localOCSISTATE = param;
    }

    public boolean isTCSISTATESpecified() {
        return localTCSISTATETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTCSISTATE() {
        return localTCSISTATE;
    }

    /**
     * Auto generated setter method
     * @param param TCSISTATE
     */
    public void setTCSISTATE(com.huawei.www.hss._EnumType param) {
        localTCSISTATETracker = param != null;

        this.localTCSISTATE = param;
    }

    public boolean isVTCSISTATESpecified() {
        return localVTCSISTATETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVTCSISTATE() {
        return localVTCSISTATE;
    }

    /**
     * Auto generated setter method
     * @param param VTCSISTATE
     */
    public void setVTCSISTATE(com.huawei.www.hss._EnumType param) {
        localVTCSISTATETracker = param != null;

        this.localVTCSISTATE = param;
    }

    public boolean isSSCSISTATESpecified() {
        return localSSCSISTATETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSSCSISTATE() {
        return localSSCSISTATE;
    }

    /**
     * Auto generated setter method
     * @param param SSCSISTATE
     */
    public void setSSCSISTATE(com.huawei.www.hss._EnumType param) {
        localSSCSISTATETracker = param != null;

        this.localSSCSISTATE = param;
    }

    public boolean isTIFCSISTATESpecified() {
        return localTIFCSISTATETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTIFCSISTATE() {
        return localTIFCSISTATE;
    }

    /**
     * Auto generated setter method
     * @param param TIFCSISTATE
     */
    public void setTIFCSISTATE(com.huawei.www.hss._EnumType param) {
        localTIFCSISTATETracker = param != null;

        this.localTIFCSISTATE = param;
    }

    public boolean isMCSISTATESpecified() {
        return localMCSISTATETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMCSISTATE() {
        return localMCSISTATE;
    }

    /**
     * Auto generated setter method
     * @param param MCSISTATE
     */
    public void setMCSISTATE(com.huawei.www.hss._EnumType param) {
        localMCSISTATETracker = param != null;

        this.localMCSISTATE = param;
    }

    public boolean isMOSMSCSISTATESpecified() {
        return localMOSMSCSISTATETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMOSMSCSISTATE() {
        return localMOSMSCSISTATE;
    }

    /**
     * Auto generated setter method
     * @param param MOSMSCSISTATE
     */
    public void setMOSMSCSISTATE(com.huawei.www.hss._EnumType param) {
        localMOSMSCSISTATETracker = param != null;

        this.localMOSMSCSISTATE = param;
    }

    public boolean isMTSMSCSISTATESpecified() {
        return localMTSMSCSISTATETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMTSMSCSISTATE() {
        return localMTSMSCSISTATE;
    }

    /**
     * Auto generated setter method
     * @param param MTSMSCSISTATE
     */
    public void setMTSMSCSISTATE(com.huawei.www.hss._EnumType param) {
        localMTSMSCSISTATETracker = param != null;

        this.localMTSMSCSISTATE = param;
    }

    public boolean isGPRSCSISTATESpecified() {
        return localGPRSCSISTATETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getGPRSCSISTATE() {
        return localGPRSCSISTATE;
    }

    /**
     * Auto generated setter method
     * @param param GPRSCSISTATE
     */
    public void setGPRSCSISTATE(com.huawei.www.hss._EnumType param) {
        localGPRSCSISTATETracker = param != null;

        this.localGPRSCSISTATE = param;
    }

    public boolean isDCSISTATESpecified() {
        return localDCSISTATETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDCSISTATE() {
        return localDCSISTATE;
    }

    /**
     * Auto generated setter method
     * @param param DCSISTATE
     */
    public void setDCSISTATE(com.huawei.www.hss._EnumType param) {
        localDCSISTATETracker = param != null;

        this.localDCSISTATE = param;
    }

    public boolean isIM_OCSITPLIDSpecified() {
        return localIM_OCSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getIM_OCSITPLID() {
        return localIM_OCSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param IM_OCSITPLID
     */
    public void setIM_OCSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localIM_OCSITPLIDTracker = param != null;

        this.localIM_OCSITPLID = param;
    }

    public boolean isIM_VTCSITPLIDSpecified() {
        return localIM_VTCSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getIM_VTCSITPLID() {
        return localIM_VTCSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param IM_VTCSITPLID
     */
    public void setIM_VTCSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localIM_VTCSITPLIDTracker = param != null;

        this.localIM_VTCSITPLID = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":LST_CSIStruct1", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "LST_CSIStruct1", xmlWriter);
            }
        }

        if (localIMSITracker) {
            if (localIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMSI cannot be null!!");
            }

            localIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMSI"), xmlWriter);
        }

        if (localISDNTracker) {
            if (localISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ISDN cannot be null!!");
            }

            localISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ISDN"), xmlWriter);
        }

        if (localOCSITPLIDTracker) {
            if (localOCSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "OCSITPLID cannot be null!!");
            }

            localOCSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "OCSITPLID"), xmlWriter);
        }

        if (localTCSITPLIDTracker) {
            if (localTCSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TCSITPLID cannot be null!!");
            }

            localTCSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TCSITPLID"), xmlWriter);
        }

        if (localVTCSITPLIDTracker) {
            if (localVTCSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VTCSITPLID cannot be null!!");
            }

            localVTCSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VTCSITPLID"), xmlWriter);
        }

        if (localUCSITPLIDTracker) {
            if (localUCSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UCSITPLID cannot be null!!");
            }

            localUCSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UCSITPLID"), xmlWriter);
        }

        if (localSSCSITPLIDTracker) {
            if (localSSCSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SSCSITPLID cannot be null!!");
            }

            localSSCSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SSCSITPLID"), xmlWriter);
        }

        if (localTIFCSIPROVTracker) {
            if (localTIFCSIPROV == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TIFCSIPROV cannot be null!!");
            }

            localTIFCSIPROV.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TIFCSIPROV"), xmlWriter);
        }

        if (localMCSITPLIDTracker) {
            if (localMCSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MCSITPLID cannot be null!!");
            }

            localMCSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MCSITPLID"), xmlWriter);
        }

        if (localMOSMSCSITPLIDTracker) {
            if (localMOSMSCSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MOSMSCSITPLID cannot be null!!");
            }

            localMOSMSCSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MOSMSCSITPLID"), xmlWriter);
        }

        if (localMTSMSCSITPLIDTracker) {
            if (localMTSMSCSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MTSMSCSITPLID cannot be null!!");
            }

            localMTSMSCSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MTSMSCSITPLID"), xmlWriter);
        }

        if (localGPRSCSITPLIDTracker) {
            if (localGPRSCSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GPRSCSITPLID cannot be null!!");
            }

            localGPRSCSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GPRSCSITPLID"), xmlWriter);
        }

        if (localDCSITPLIDTracker) {
            if (localDCSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DCSITPLID cannot be null!!");
            }

            localDCSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DCSITPLID"), xmlWriter);
        }

        if (localOCSISTATETracker) {
            if (localOCSISTATE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "OCSISTATE cannot be null!!");
            }

            localOCSISTATE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "OCSISTATE"), xmlWriter);
        }

        if (localTCSISTATETracker) {
            if (localTCSISTATE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TCSISTATE cannot be null!!");
            }

            localTCSISTATE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TCSISTATE"), xmlWriter);
        }

        if (localVTCSISTATETracker) {
            if (localVTCSISTATE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VTCSISTATE cannot be null!!");
            }

            localVTCSISTATE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VTCSISTATE"), xmlWriter);
        }

        if (localSSCSISTATETracker) {
            if (localSSCSISTATE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SSCSISTATE cannot be null!!");
            }

            localSSCSISTATE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SSCSISTATE"), xmlWriter);
        }

        if (localTIFCSISTATETracker) {
            if (localTIFCSISTATE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TIFCSISTATE cannot be null!!");
            }

            localTIFCSISTATE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TIFCSISTATE"), xmlWriter);
        }

        if (localMCSISTATETracker) {
            if (localMCSISTATE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MCSISTATE cannot be null!!");
            }

            localMCSISTATE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MCSISTATE"), xmlWriter);
        }

        if (localMOSMSCSISTATETracker) {
            if (localMOSMSCSISTATE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MOSMSCSISTATE cannot be null!!");
            }

            localMOSMSCSISTATE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MOSMSCSISTATE"), xmlWriter);
        }

        if (localMTSMSCSISTATETracker) {
            if (localMTSMSCSISTATE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MTSMSCSISTATE cannot be null!!");
            }

            localMTSMSCSISTATE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MTSMSCSISTATE"), xmlWriter);
        }

        if (localGPRSCSISTATETracker) {
            if (localGPRSCSISTATE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GPRSCSISTATE cannot be null!!");
            }

            localGPRSCSISTATE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GPRSCSISTATE"), xmlWriter);
        }

        if (localDCSISTATETracker) {
            if (localDCSISTATE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DCSISTATE cannot be null!!");
            }

            localDCSISTATE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DCSISTATE"), xmlWriter);
        }

        if (localIM_OCSITPLIDTracker) {
            if (localIM_OCSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IM_OCSITPLID cannot be null!!");
            }

            localIM_OCSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IM_OCSITPLID"), xmlWriter);
        }

        if (localIM_VTCSITPLIDTracker) {
            if (localIM_VTCSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IM_VTCSITPLID cannot be null!!");
            }

            localIM_VTCSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IM_VTCSITPLID"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static LST_CSIStruct1 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            LST_CSIStruct1 object = new LST_CSIStruct1();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"LST_CSIStruct1".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (LST_CSIStruct1) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSI").equals(
                            reader.getName())) {
                    object.setIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ISDN").equals(
                            reader.getName())) {
                    object.setISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "OCSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "OCSITPLID").equals(
                            reader.getName())) {
                    object.setOCSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TCSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TCSITPLID").equals(
                            reader.getName())) {
                    object.setTCSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VTCSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VTCSITPLID").equals(
                            reader.getName())) {
                    object.setVTCSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UCSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UCSITPLID").equals(
                            reader.getName())) {
                    object.setUCSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SSCSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SSCSITPLID").equals(
                            reader.getName())) {
                    object.setSSCSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TIFCSIPROV").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TIFCSIPROV").equals(
                            reader.getName())) {
                    object.setTIFCSIPROV(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MCSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MCSITPLID").equals(
                            reader.getName())) {
                    object.setMCSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MOSMSCSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MOSMSCSITPLID").equals(
                            reader.getName())) {
                    object.setMOSMSCSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MTSMSCSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MTSMSCSITPLID").equals(
                            reader.getName())) {
                    object.setMTSMSCSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GPRSCSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GPRSCSITPLID").equals(
                            reader.getName())) {
                    object.setGPRSCSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DCSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DCSITPLID").equals(
                            reader.getName())) {
                    object.setDCSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "OCSISTATE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "OCSISTATE").equals(
                            reader.getName())) {
                    object.setOCSISTATE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TCSISTATE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TCSISTATE").equals(
                            reader.getName())) {
                    object.setTCSISTATE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VTCSISTATE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VTCSISTATE").equals(
                            reader.getName())) {
                    object.setVTCSISTATE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SSCSISTATE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SSCSISTATE").equals(
                            reader.getName())) {
                    object.setSSCSISTATE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TIFCSISTATE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TIFCSISTATE").equals(
                            reader.getName())) {
                    object.setTIFCSISTATE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MCSISTATE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MCSISTATE").equals(
                            reader.getName())) {
                    object.setMCSISTATE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MOSMSCSISTATE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MOSMSCSISTATE").equals(
                            reader.getName())) {
                    object.setMOSMSCSISTATE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MTSMSCSISTATE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MTSMSCSISTATE").equals(
                            reader.getName())) {
                    object.setMTSMSCSISTATE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GPRSCSISTATE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GPRSCSISTATE").equals(
                            reader.getName())) {
                    object.setGPRSCSISTATE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DCSISTATE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DCSISTATE").equals(
                            reader.getName())) {
                    object.setDCSISTATE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IM_OCSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IM_OCSITPLID").equals(
                            reader.getName())) {
                    object.setIM_OCSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IM_VTCSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IM_VTCSITPLID").equals(
                            reader.getName())) {
                    object.setIM_VTCSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
