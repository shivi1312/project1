/**
 * ADD_DIAMRRTPL.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  ADD_DIAMRRTPL bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class ADD_DIAMRRTPL implements org.apache.axis2.databinding.ADBBean {
    public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName("http://www.huawei.com/HSS",
            "ADD_DIAMRRTPL", "ns3");

    /**
     * field for HLRSN
     */
    protected com.huawei.www.hss.Int1_255 localHLRSN;

    /**
     * field for TPLID
     */
    protected com.huawei.www.hss.Int0_65534 localTPLID;

    /**
     * field for TPLNAME
     */
    protected com.huawei.www.hss.Str1_60 localTPLNAME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTPLNAMETracker = false;

    /**
     * field for DEFAULTRULE
     */
    protected com.huawei.www.hss._EnumType localDEFAULTRULE;

    /**
     * field for DEFRSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localDEFRSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDEFRSITPLIDTracker = false;

    /**
     * field for DIAMIDENTITYTYPE
     */
    protected com.huawei.www.hss._EnumType localDIAMIDENTITYTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDIAMIDENTITYTYPETracker = false;

    /**
     * field for DIAMIDENTITY
     */
    protected com.huawei.www.hss.Str1_127 localDIAMIDENTITY;

    /**
     * field for REALMNAME
     */
    protected com.huawei.www.hss.Str1_127 localREALMNAME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localREALMNAMETracker = false;

    /**
     * field for RULE
     */
    protected com.huawei.www.hss._EnumType localRULE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRULETracker = false;

    /**
     * field for RSITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localRSITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRSITPLIDTracker = false;

    /**
     * field for ERRCODE
     */
    protected com.huawei.www.hss._EnumType localERRCODE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localERRCODETracker = false;

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_255
     */
    public com.huawei.www.hss.Int1_255 getHLRSN() {
        return localHLRSN;
    }

    /**
     * Auto generated setter method
     * @param param HLRSN
     */
    public void setHLRSN(com.huawei.www.hss.Int1_255 param) {
        this.localHLRSN = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getTPLID() {
        return localTPLID;
    }

    /**
     * Auto generated setter method
     * @param param TPLID
     */
    public void setTPLID(com.huawei.www.hss.Int0_65534 param) {
        this.localTPLID = param;
    }

    public boolean isTPLNAMESpecified() {
        return localTPLNAMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_60
     */
    public com.huawei.www.hss.Str1_60 getTPLNAME() {
        return localTPLNAME;
    }

    /**
     * Auto generated setter method
     * @param param TPLNAME
     */
    public void setTPLNAME(com.huawei.www.hss.Str1_60 param) {
        localTPLNAMETracker = param != null;

        this.localTPLNAME = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDEFAULTRULE() {
        return localDEFAULTRULE;
    }

    /**
     * Auto generated setter method
     * @param param DEFAULTRULE
     */
    public void setDEFAULTRULE(com.huawei.www.hss._EnumType param) {
        this.localDEFAULTRULE = param;
    }

    public boolean isDEFRSITPLIDSpecified() {
        return localDEFRSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getDEFRSITPLID() {
        return localDEFRSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param DEFRSITPLID
     */
    public void setDEFRSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localDEFRSITPLIDTracker = param != null;

        this.localDEFRSITPLID = param;
    }

    public boolean isDIAMIDENTITYTYPESpecified() {
        return localDIAMIDENTITYTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDIAMIDENTITYTYPE() {
        return localDIAMIDENTITYTYPE;
    }

    /**
     * Auto generated setter method
     * @param param DIAMIDENTITYTYPE
     */
    public void setDIAMIDENTITYTYPE(com.huawei.www.hss._EnumType param) {
        localDIAMIDENTITYTYPETracker = param != null;

        this.localDIAMIDENTITYTYPE = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_127
     */
    public com.huawei.www.hss.Str1_127 getDIAMIDENTITY() {
        return localDIAMIDENTITY;
    }

    /**
     * Auto generated setter method
     * @param param DIAMIDENTITY
     */
    public void setDIAMIDENTITY(com.huawei.www.hss.Str1_127 param) {
        this.localDIAMIDENTITY = param;
    }

    public boolean isREALMNAMESpecified() {
        return localREALMNAMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_127
     */
    public com.huawei.www.hss.Str1_127 getREALMNAME() {
        return localREALMNAME;
    }

    /**
     * Auto generated setter method
     * @param param REALMNAME
     */
    public void setREALMNAME(com.huawei.www.hss.Str1_127 param) {
        localREALMNAMETracker = param != null;

        this.localREALMNAME = param;
    }

    public boolean isRULESpecified() {
        return localRULETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRULE() {
        return localRULE;
    }

    /**
     * Auto generated setter method
     * @param param RULE
     */
    public void setRULE(com.huawei.www.hss._EnumType param) {
        localRULETracker = param != null;

        this.localRULE = param;
    }

    public boolean isRSITPLIDSpecified() {
        return localRSITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getRSITPLID() {
        return localRSITPLID;
    }

    /**
     * Auto generated setter method
     * @param param RSITPLID
     */
    public void setRSITPLID(com.huawei.www.hss.Int0_65534 param) {
        localRSITPLIDTracker = param != null;

        this.localRSITPLID = param;
    }

    public boolean isERRCODESpecified() {
        return localERRCODETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getERRCODE() {
        return localERRCODE;
    }

    /**
     * Auto generated setter method
     * @param param ERRCODE
     */
    public void setERRCODE(com.huawei.www.hss._EnumType param) {
        localERRCODETracker = param != null;

        this.localERRCODE = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, MY_QNAME));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":ADD_DIAMRRTPL", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "ADD_DIAMRRTPL", xmlWriter);
            }
        }

        if (localHLRSN == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "HLRSN cannot be null!!");
        }

        localHLRSN.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "HLRSN"), xmlWriter);

        if (localTPLID == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "TPLID cannot be null!!");
        }

        localTPLID.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "TPLID"), xmlWriter);

        if (localTPLNAMETracker) {
            if (localTPLNAME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TPLNAME cannot be null!!");
            }

            localTPLNAME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TPLNAME"), xmlWriter);
        }

        if (localDEFAULTRULE == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "DEFAULTRULE cannot be null!!");
        }

        localDEFAULTRULE.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "DEFAULTRULE"), xmlWriter);

        if (localDEFRSITPLIDTracker) {
            if (localDEFRSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DEFRSITPLID cannot be null!!");
            }

            localDEFRSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DEFRSITPLID"), xmlWriter);
        }

        if (localDIAMIDENTITYTYPETracker) {
            if (localDIAMIDENTITYTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DIAMIDENTITYTYPE cannot be null!!");
            }

            localDIAMIDENTITYTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DIAMIDENTITYTYPE"), xmlWriter);
        }

        if (localDIAMIDENTITY == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "DIAMIDENTITY cannot be null!!");
        }

        localDIAMIDENTITY.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "DIAMIDENTITY"), xmlWriter);

        if (localREALMNAMETracker) {
            if (localREALMNAME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "REALMNAME cannot be null!!");
            }

            localREALMNAME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "REALMNAME"), xmlWriter);
        }

        if (localRULETracker) {
            if (localRULE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RULE cannot be null!!");
            }

            localRULE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RULE"), xmlWriter);
        }

        if (localRSITPLIDTracker) {
            if (localRSITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RSITPLID cannot be null!!");
            }

            localRSITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RSITPLID"), xmlWriter);
        }

        if (localERRCODETracker) {
            if (localERRCODE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ERRCODE cannot be null!!");
            }

            localERRCODE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ERRCODE"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static ADD_DIAMRRTPL parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            ADD_DIAMRRTPL object = new ADD_DIAMRRTPL();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"ADD_DIAMRRTPL".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (ADD_DIAMRRTPL) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "HLRSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "HLRSN").equals(
                            reader.getName())) {
                    object.setHLRSN(com.huawei.www.hss.Int1_255.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TPLID").equals(
                            reader.getName())) {
                    object.setTPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TPLNAME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TPLNAME").equals(
                            reader.getName())) {
                    object.setTPLNAME(com.huawei.www.hss.Str1_60.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DEFAULTRULE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DEFAULTRULE").equals(
                            reader.getName())) {
                    object.setDEFAULTRULE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DEFRSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DEFRSITPLID").equals(
                            reader.getName())) {
                    object.setDEFRSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DIAMIDENTITYTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DIAMIDENTITYTYPE").equals(
                            reader.getName())) {
                    object.setDIAMIDENTITYTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DIAMIDENTITY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DIAMIDENTITY").equals(
                            reader.getName())) {
                    object.setDIAMIDENTITY(com.huawei.www.hss.Str1_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "REALMNAME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "REALMNAME").equals(
                            reader.getName())) {
                    object.setREALMNAME(com.huawei.www.hss.Str1_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RULE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RULE").equals(
                            reader.getName())) {
                    object.setRULE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RSITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RSITPLID").equals(
                            reader.getName())) {
                    object.setRSITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ERRCODE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ERRCODE").equals(
                            reader.getName())) {
                    object.setERRCODE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
