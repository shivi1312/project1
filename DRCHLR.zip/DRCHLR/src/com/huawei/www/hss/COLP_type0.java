/**
 * COLP_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  COLP_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class COLP_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = COLP_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for ColpProv
     */
    protected com.huawei.www.hss._EnumType localColpProv;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localColpProvTracker = false;

    /**
     * field for ColpOverRide
     */
    protected com.huawei.www.hss._EnumType localColpOverRide;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localColpOverRideTracker = false;

    /**
     * field for ColpTs1X
     */
    protected com.huawei.www.hss._EnumType localColpTs1X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localColpTs1XTracker = false;

    /**
     * field for ColpTs2X
     */
    protected com.huawei.www.hss._EnumType localColpTs2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localColpTs2XTracker = false;

    /**
     * field for ColpTs6X
     */
    protected com.huawei.www.hss._EnumType localColpTs6X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localColpTs6XTracker = false;

    /**
     * field for ColpBs2X
     */
    protected com.huawei.www.hss._EnumType localColpBs2X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localColpBs2XTracker = false;

    /**
     * field for ColpBs3X
     */
    protected com.huawei.www.hss._EnumType localColpBs3X;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localColpBs3XTracker = false;

    public boolean isColpProvSpecified() {
        return localColpProvTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getColpProv() {
        return localColpProv;
    }

    /**
     * Auto generated setter method
     * @param param ColpProv
     */
    public void setColpProv(com.huawei.www.hss._EnumType param) {
        localColpProvTracker = param != null;

        this.localColpProv = param;
    }

    public boolean isColpOverRideSpecified() {
        return localColpOverRideTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getColpOverRide() {
        return localColpOverRide;
    }

    /**
     * Auto generated setter method
     * @param param ColpOverRide
     */
    public void setColpOverRide(com.huawei.www.hss._EnumType param) {
        localColpOverRideTracker = param != null;

        this.localColpOverRide = param;
    }

    public boolean isColpTs1XSpecified() {
        return localColpTs1XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getColpTs1X() {
        return localColpTs1X;
    }

    /**
     * Auto generated setter method
     * @param param ColpTs1X
     */
    public void setColpTs1X(com.huawei.www.hss._EnumType param) {
        localColpTs1XTracker = param != null;

        this.localColpTs1X = param;
    }

    public boolean isColpTs2XSpecified() {
        return localColpTs2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getColpTs2X() {
        return localColpTs2X;
    }

    /**
     * Auto generated setter method
     * @param param ColpTs2X
     */
    public void setColpTs2X(com.huawei.www.hss._EnumType param) {
        localColpTs2XTracker = param != null;

        this.localColpTs2X = param;
    }

    public boolean isColpTs6XSpecified() {
        return localColpTs6XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getColpTs6X() {
        return localColpTs6X;
    }

    /**
     * Auto generated setter method
     * @param param ColpTs6X
     */
    public void setColpTs6X(com.huawei.www.hss._EnumType param) {
        localColpTs6XTracker = param != null;

        this.localColpTs6X = param;
    }

    public boolean isColpBs2XSpecified() {
        return localColpBs2XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getColpBs2X() {
        return localColpBs2X;
    }

    /**
     * Auto generated setter method
     * @param param ColpBs2X
     */
    public void setColpBs2X(com.huawei.www.hss._EnumType param) {
        localColpBs2XTracker = param != null;

        this.localColpBs2X = param;
    }

    public boolean isColpBs3XSpecified() {
        return localColpBs3XTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getColpBs3X() {
        return localColpBs3X;
    }

    /**
     * Auto generated setter method
     * @param param ColpBs3X
     */
    public void setColpBs3X(com.huawei.www.hss._EnumType param) {
        localColpBs3XTracker = param != null;

        this.localColpBs3X = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":COLP_type0", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "COLP_type0", xmlWriter);
            }
        }

        if (localColpProvTracker) {
            if (localColpProv == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ColpProv cannot be null!!");
            }

            localColpProv.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ColpProv"), xmlWriter);
        }

        if (localColpOverRideTracker) {
            if (localColpOverRide == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ColpOverRide cannot be null!!");
            }

            localColpOverRide.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ColpOverRide"), xmlWriter);
        }

        if (localColpTs1XTracker) {
            if (localColpTs1X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ColpTs1X cannot be null!!");
            }

            localColpTs1X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ColpTs1X"), xmlWriter);
        }

        if (localColpTs2XTracker) {
            if (localColpTs2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ColpTs2X cannot be null!!");
            }

            localColpTs2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ColpTs2X"), xmlWriter);
        }

        if (localColpTs6XTracker) {
            if (localColpTs6X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ColpTs6X cannot be null!!");
            }

            localColpTs6X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ColpTs6X"), xmlWriter);
        }

        if (localColpBs2XTracker) {
            if (localColpBs2X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ColpBs2X cannot be null!!");
            }

            localColpBs2X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ColpBs2X"), xmlWriter);
        }

        if (localColpBs3XTracker) {
            if (localColpBs3X == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ColpBs3X cannot be null!!");
            }

            localColpBs3X.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ColpBs3X"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static COLP_type0 parse(javax.xml.stream.XMLStreamReader reader)
            throws java.lang.Exception {
            COLP_type0 object = new COLP_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"COLP_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (COLP_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ColpProv").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ColpProv").equals(
                            reader.getName())) {
                    object.setColpProv(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ColpOverRide").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ColpOverRide").equals(
                            reader.getName())) {
                    object.setColpOverRide(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ColpTs1X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ColpTs1X").equals(
                            reader.getName())) {
                    object.setColpTs1X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ColpTs2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ColpTs2X").equals(
                            reader.getName())) {
                    object.setColpTs2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ColpTs6X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ColpTs6X").equals(
                            reader.getName())) {
                    object.setColpTs6X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ColpBs2X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ColpBs2X").equals(
                            reader.getName())) {
                    object.setColpBs2X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ColpBs3X").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ColpBs3X").equals(
                            reader.getName())) {
                    object.setColpBs3X(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
