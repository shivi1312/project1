/**
 * LST_BSStruct1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  LST_BSStruct1 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class LST_BSStruct1 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = LST_BSStruct1
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for IMSI
     */
    protected com.huawei.www.hss.Str6_15 localIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSITracker = false;

    /**
     * field for MAINIMSI
     */
    protected com.huawei.www.hss.Str6_15 localMAINIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAINIMSITracker = false;

    /**
     * field for ISDN
     */
    protected com.huawei.www.hss.Str1_15 localISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localISDNTracker = false;

    /**
     * field for MAINISDN
     */
    protected com.huawei.www.hss.Str1_15 localMAINISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAINISDNTracker = false;

    /**
     * field for BS20
     */
    protected com.huawei.www.hss._EnumType localBS20;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS20Tracker = false;

    /**
     * field for BS21
     */
    protected com.huawei.www.hss._EnumType localBS21;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS21Tracker = false;

    /**
     * field for BS22
     */
    protected com.huawei.www.hss._EnumType localBS22;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS22Tracker = false;

    /**
     * field for BS23
     */
    protected com.huawei.www.hss._EnumType localBS23;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS23Tracker = false;

    /**
     * field for BS24
     */
    protected com.huawei.www.hss._EnumType localBS24;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS24Tracker = false;

    /**
     * field for BS25
     */
    protected com.huawei.www.hss._EnumType localBS25;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS25Tracker = false;

    /**
     * field for BS26
     */
    protected com.huawei.www.hss._EnumType localBS26;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS26Tracker = false;

    /**
     * field for BS30
     */
    protected com.huawei.www.hss._EnumType localBS30;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS30Tracker = false;

    /**
     * field for BS31
     */
    protected com.huawei.www.hss._EnumType localBS31;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS31Tracker = false;

    /**
     * field for BS32
     */
    protected com.huawei.www.hss._EnumType localBS32;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS32Tracker = false;

    /**
     * field for BS33
     */
    protected com.huawei.www.hss._EnumType localBS33;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS33Tracker = false;

    /**
     * field for BS34
     */
    protected com.huawei.www.hss._EnumType localBS34;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS34Tracker = false;

    /**
     * field for BS41
     */
    protected com.huawei.www.hss._EnumType localBS41;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS41Tracker = false;

    /**
     * field for BS42
     */
    protected com.huawei.www.hss._EnumType localBS42;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS42Tracker = false;

    /**
     * field for BS43
     */
    protected com.huawei.www.hss._EnumType localBS43;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS43Tracker = false;

    /**
     * field for BS44
     */
    protected com.huawei.www.hss._EnumType localBS44;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS44Tracker = false;

    /**
     * field for BS45
     */
    protected com.huawei.www.hss._EnumType localBS45;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS45Tracker = false;

    /**
     * field for BS46
     */
    protected com.huawei.www.hss._EnumType localBS46;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS46Tracker = false;

    /**
     * field for BS51
     */
    protected com.huawei.www.hss._EnumType localBS51;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS51Tracker = false;

    /**
     * field for BS52
     */
    protected com.huawei.www.hss._EnumType localBS52;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS52Tracker = false;

    /**
     * field for BS53
     */
    protected com.huawei.www.hss._EnumType localBS53;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS53Tracker = false;

    /**
     * field for BS61
     */
    protected com.huawei.www.hss._EnumType localBS61;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS61Tracker = false;

    /**
     * field for BS81
     */
    protected com.huawei.www.hss._EnumType localBS81;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBS81Tracker = false;

    public boolean isIMSISpecified() {
        return localIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getIMSI() {
        return localIMSI;
    }

    /**
     * Auto generated setter method
     * @param param IMSI
     */
    public void setIMSI(com.huawei.www.hss.Str6_15 param) {
        localIMSITracker = param != null;

        this.localIMSI = param;
    }

    public boolean isMAINIMSISpecified() {
        return localMAINIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getMAINIMSI() {
        return localMAINIMSI;
    }

    /**
     * Auto generated setter method
     * @param param MAINIMSI
     */
    public void setMAINIMSI(com.huawei.www.hss.Str6_15 param) {
        localMAINIMSITracker = param != null;

        this.localMAINIMSI = param;
    }

    public boolean isISDNSpecified() {
        return localISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getISDN() {
        return localISDN;
    }

    /**
     * Auto generated setter method
     * @param param ISDN
     */
    public void setISDN(com.huawei.www.hss.Str1_15 param) {
        localISDNTracker = param != null;

        this.localISDN = param;
    }

    public boolean isMAINISDNSpecified() {
        return localMAINISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getMAINISDN() {
        return localMAINISDN;
    }

    /**
     * Auto generated setter method
     * @param param MAINISDN
     */
    public void setMAINISDN(com.huawei.www.hss.Str1_15 param) {
        localMAINISDNTracker = param != null;

        this.localMAINISDN = param;
    }

    public boolean isBS20Specified() {
        return localBS20Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS20() {
        return localBS20;
    }

    /**
     * Auto generated setter method
     * @param param BS20
     */
    public void setBS20(com.huawei.www.hss._EnumType param) {
        localBS20Tracker = param != null;

        this.localBS20 = param;
    }

    public boolean isBS21Specified() {
        return localBS21Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS21() {
        return localBS21;
    }

    /**
     * Auto generated setter method
     * @param param BS21
     */
    public void setBS21(com.huawei.www.hss._EnumType param) {
        localBS21Tracker = param != null;

        this.localBS21 = param;
    }

    public boolean isBS22Specified() {
        return localBS22Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS22() {
        return localBS22;
    }

    /**
     * Auto generated setter method
     * @param param BS22
     */
    public void setBS22(com.huawei.www.hss._EnumType param) {
        localBS22Tracker = param != null;

        this.localBS22 = param;
    }

    public boolean isBS23Specified() {
        return localBS23Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS23() {
        return localBS23;
    }

    /**
     * Auto generated setter method
     * @param param BS23
     */
    public void setBS23(com.huawei.www.hss._EnumType param) {
        localBS23Tracker = param != null;

        this.localBS23 = param;
    }

    public boolean isBS24Specified() {
        return localBS24Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS24() {
        return localBS24;
    }

    /**
     * Auto generated setter method
     * @param param BS24
     */
    public void setBS24(com.huawei.www.hss._EnumType param) {
        localBS24Tracker = param != null;

        this.localBS24 = param;
    }

    public boolean isBS25Specified() {
        return localBS25Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS25() {
        return localBS25;
    }

    /**
     * Auto generated setter method
     * @param param BS25
     */
    public void setBS25(com.huawei.www.hss._EnumType param) {
        localBS25Tracker = param != null;

        this.localBS25 = param;
    }

    public boolean isBS26Specified() {
        return localBS26Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS26() {
        return localBS26;
    }

    /**
     * Auto generated setter method
     * @param param BS26
     */
    public void setBS26(com.huawei.www.hss._EnumType param) {
        localBS26Tracker = param != null;

        this.localBS26 = param;
    }

    public boolean isBS30Specified() {
        return localBS30Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS30() {
        return localBS30;
    }

    /**
     * Auto generated setter method
     * @param param BS30
     */
    public void setBS30(com.huawei.www.hss._EnumType param) {
        localBS30Tracker = param != null;

        this.localBS30 = param;
    }

    public boolean isBS31Specified() {
        return localBS31Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS31() {
        return localBS31;
    }

    /**
     * Auto generated setter method
     * @param param BS31
     */
    public void setBS31(com.huawei.www.hss._EnumType param) {
        localBS31Tracker = param != null;

        this.localBS31 = param;
    }

    public boolean isBS32Specified() {
        return localBS32Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS32() {
        return localBS32;
    }

    /**
     * Auto generated setter method
     * @param param BS32
     */
    public void setBS32(com.huawei.www.hss._EnumType param) {
        localBS32Tracker = param != null;

        this.localBS32 = param;
    }

    public boolean isBS33Specified() {
        return localBS33Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS33() {
        return localBS33;
    }

    /**
     * Auto generated setter method
     * @param param BS33
     */
    public void setBS33(com.huawei.www.hss._EnumType param) {
        localBS33Tracker = param != null;

        this.localBS33 = param;
    }

    public boolean isBS34Specified() {
        return localBS34Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS34() {
        return localBS34;
    }

    /**
     * Auto generated setter method
     * @param param BS34
     */
    public void setBS34(com.huawei.www.hss._EnumType param) {
        localBS34Tracker = param != null;

        this.localBS34 = param;
    }

    public boolean isBS41Specified() {
        return localBS41Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS41() {
        return localBS41;
    }

    /**
     * Auto generated setter method
     * @param param BS41
     */
    public void setBS41(com.huawei.www.hss._EnumType param) {
        localBS41Tracker = param != null;

        this.localBS41 = param;
    }

    public boolean isBS42Specified() {
        return localBS42Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS42() {
        return localBS42;
    }

    /**
     * Auto generated setter method
     * @param param BS42
     */
    public void setBS42(com.huawei.www.hss._EnumType param) {
        localBS42Tracker = param != null;

        this.localBS42 = param;
    }

    public boolean isBS43Specified() {
        return localBS43Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS43() {
        return localBS43;
    }

    /**
     * Auto generated setter method
     * @param param BS43
     */
    public void setBS43(com.huawei.www.hss._EnumType param) {
        localBS43Tracker = param != null;

        this.localBS43 = param;
    }

    public boolean isBS44Specified() {
        return localBS44Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS44() {
        return localBS44;
    }

    /**
     * Auto generated setter method
     * @param param BS44
     */
    public void setBS44(com.huawei.www.hss._EnumType param) {
        localBS44Tracker = param != null;

        this.localBS44 = param;
    }

    public boolean isBS45Specified() {
        return localBS45Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS45() {
        return localBS45;
    }

    /**
     * Auto generated setter method
     * @param param BS45
     */
    public void setBS45(com.huawei.www.hss._EnumType param) {
        localBS45Tracker = param != null;

        this.localBS45 = param;
    }

    public boolean isBS46Specified() {
        return localBS46Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS46() {
        return localBS46;
    }

    /**
     * Auto generated setter method
     * @param param BS46
     */
    public void setBS46(com.huawei.www.hss._EnumType param) {
        localBS46Tracker = param != null;

        this.localBS46 = param;
    }

    public boolean isBS51Specified() {
        return localBS51Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS51() {
        return localBS51;
    }

    /**
     * Auto generated setter method
     * @param param BS51
     */
    public void setBS51(com.huawei.www.hss._EnumType param) {
        localBS51Tracker = param != null;

        this.localBS51 = param;
    }

    public boolean isBS52Specified() {
        return localBS52Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS52() {
        return localBS52;
    }

    /**
     * Auto generated setter method
     * @param param BS52
     */
    public void setBS52(com.huawei.www.hss._EnumType param) {
        localBS52Tracker = param != null;

        this.localBS52 = param;
    }

    public boolean isBS53Specified() {
        return localBS53Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS53() {
        return localBS53;
    }

    /**
     * Auto generated setter method
     * @param param BS53
     */
    public void setBS53(com.huawei.www.hss._EnumType param) {
        localBS53Tracker = param != null;

        this.localBS53 = param;
    }

    public boolean isBS61Specified() {
        return localBS61Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS61() {
        return localBS61;
    }

    /**
     * Auto generated setter method
     * @param param BS61
     */
    public void setBS61(com.huawei.www.hss._EnumType param) {
        localBS61Tracker = param != null;

        this.localBS61 = param;
    }

    public boolean isBS81Specified() {
        return localBS81Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBS81() {
        return localBS81;
    }

    /**
     * Auto generated setter method
     * @param param BS81
     */
    public void setBS81(com.huawei.www.hss._EnumType param) {
        localBS81Tracker = param != null;

        this.localBS81 = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":LST_BSStruct1", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "LST_BSStruct1", xmlWriter);
            }
        }

        if (localIMSITracker) {
            if (localIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMSI cannot be null!!");
            }

            localIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMSI"), xmlWriter);
        }

        if (localMAINIMSITracker) {
            if (localMAINIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAINIMSI cannot be null!!");
            }

            localMAINIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAINIMSI"), xmlWriter);
        }

        if (localISDNTracker) {
            if (localISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ISDN cannot be null!!");
            }

            localISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ISDN"), xmlWriter);
        }

        if (localMAINISDNTracker) {
            if (localMAINISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAINISDN cannot be null!!");
            }

            localMAINISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAINISDN"), xmlWriter);
        }

        if (localBS20Tracker) {
            if (localBS20 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS20 cannot be null!!");
            }

            localBS20.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS20"), xmlWriter);
        }

        if (localBS21Tracker) {
            if (localBS21 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS21 cannot be null!!");
            }

            localBS21.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS21"), xmlWriter);
        }

        if (localBS22Tracker) {
            if (localBS22 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS22 cannot be null!!");
            }

            localBS22.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS22"), xmlWriter);
        }

        if (localBS23Tracker) {
            if (localBS23 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS23 cannot be null!!");
            }

            localBS23.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS23"), xmlWriter);
        }

        if (localBS24Tracker) {
            if (localBS24 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS24 cannot be null!!");
            }

            localBS24.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS24"), xmlWriter);
        }

        if (localBS25Tracker) {
            if (localBS25 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS25 cannot be null!!");
            }

            localBS25.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS25"), xmlWriter);
        }

        if (localBS26Tracker) {
            if (localBS26 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS26 cannot be null!!");
            }

            localBS26.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS26"), xmlWriter);
        }

        if (localBS30Tracker) {
            if (localBS30 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS30 cannot be null!!");
            }

            localBS30.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS30"), xmlWriter);
        }

        if (localBS31Tracker) {
            if (localBS31 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS31 cannot be null!!");
            }

            localBS31.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS31"), xmlWriter);
        }

        if (localBS32Tracker) {
            if (localBS32 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS32 cannot be null!!");
            }

            localBS32.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS32"), xmlWriter);
        }

        if (localBS33Tracker) {
            if (localBS33 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS33 cannot be null!!");
            }

            localBS33.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS33"), xmlWriter);
        }

        if (localBS34Tracker) {
            if (localBS34 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS34 cannot be null!!");
            }

            localBS34.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS34"), xmlWriter);
        }

        if (localBS41Tracker) {
            if (localBS41 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS41 cannot be null!!");
            }

            localBS41.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS41"), xmlWriter);
        }

        if (localBS42Tracker) {
            if (localBS42 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS42 cannot be null!!");
            }

            localBS42.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS42"), xmlWriter);
        }

        if (localBS43Tracker) {
            if (localBS43 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS43 cannot be null!!");
            }

            localBS43.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS43"), xmlWriter);
        }

        if (localBS44Tracker) {
            if (localBS44 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS44 cannot be null!!");
            }

            localBS44.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS44"), xmlWriter);
        }

        if (localBS45Tracker) {
            if (localBS45 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS45 cannot be null!!");
            }

            localBS45.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS45"), xmlWriter);
        }

        if (localBS46Tracker) {
            if (localBS46 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS46 cannot be null!!");
            }

            localBS46.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS46"), xmlWriter);
        }

        if (localBS51Tracker) {
            if (localBS51 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS51 cannot be null!!");
            }

            localBS51.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS51"), xmlWriter);
        }

        if (localBS52Tracker) {
            if (localBS52 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS52 cannot be null!!");
            }

            localBS52.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS52"), xmlWriter);
        }

        if (localBS53Tracker) {
            if (localBS53 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS53 cannot be null!!");
            }

            localBS53.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS53"), xmlWriter);
        }

        if (localBS61Tracker) {
            if (localBS61 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS61 cannot be null!!");
            }

            localBS61.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS61"), xmlWriter);
        }

        if (localBS81Tracker) {
            if (localBS81 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS81 cannot be null!!");
            }

            localBS81.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS81"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static LST_BSStruct1 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            LST_BSStruct1 object = new LST_BSStruct1();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"LST_BSStruct1".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (LST_BSStruct1) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSI").equals(
                            reader.getName())) {
                    object.setIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAINIMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAINIMSI").equals(
                            reader.getName())) {
                    object.setMAINIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ISDN").equals(
                            reader.getName())) {
                    object.setISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAINISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAINISDN").equals(
                            reader.getName())) {
                    object.setMAINISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS20").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS20").equals(
                            reader.getName())) {
                    object.setBS20(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS21").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS21").equals(
                            reader.getName())) {
                    object.setBS21(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS22").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS22").equals(
                            reader.getName())) {
                    object.setBS22(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS23").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS23").equals(
                            reader.getName())) {
                    object.setBS23(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS24").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS24").equals(
                            reader.getName())) {
                    object.setBS24(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS25").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS25").equals(
                            reader.getName())) {
                    object.setBS25(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS26").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS26").equals(
                            reader.getName())) {
                    object.setBS26(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS30").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS30").equals(
                            reader.getName())) {
                    object.setBS30(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS31").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS31").equals(
                            reader.getName())) {
                    object.setBS31(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS32").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS32").equals(
                            reader.getName())) {
                    object.setBS32(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS33").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS33").equals(
                            reader.getName())) {
                    object.setBS33(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS34").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS34").equals(
                            reader.getName())) {
                    object.setBS34(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS41").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS41").equals(
                            reader.getName())) {
                    object.setBS41(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS42").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS42").equals(
                            reader.getName())) {
                    object.setBS42(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS43").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS43").equals(
                            reader.getName())) {
                    object.setBS43(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS44").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS44").equals(
                            reader.getName())) {
                    object.setBS44(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS45").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS45").equals(
                            reader.getName())) {
                    object.setBS45(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS46").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS46").equals(
                            reader.getName())) {
                    object.setBS46(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS51").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS51").equals(
                            reader.getName())) {
                    object.setBS51(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS52").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS52").equals(
                            reader.getName())) {
                    object.setBS52(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS53").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS53").equals(
                            reader.getName())) {
                    object.setBS53(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS61").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS61").equals(
                            reader.getName())) {
                    object.setBS61(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS81").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS81").equals(
                            reader.getName())) {
                    object.setBS81(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
