/**
 * CallForward_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  CallForward_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class CallForward_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = CallForward_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for CfSerCode
     */
    protected com.huawei.www.hss.Str1_15 localCfSerCode;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCfSerCodeTracker = false;

    /**
     * field for CfProv
     */
    protected com.huawei.www.hss._EnumType localCfProv;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCfProvTracker = false;

    /**
     * field for NFS
     */
    protected com.huawei.www.hss._EnumType localNFS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localNFSTracker = false;

    /**
     * field for NCS
     */
    protected com.huawei.www.hss._EnumType localNCS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localNCSTracker = false;

    /**
     * field for OfaTplId
     */
    protected com.huawei.www.hss.Int0_65534 localOfaTplId;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localOfaTplIdTracker = false;

    /**
     * field for COU
     */
    protected com.huawei.www.hss._EnumType localCOU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCOUTracker = false;

    /**
     * field for SupinterCfd
     */
    protected com.huawei.www.hss._EnumType localSupinterCfd;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupinterCfdTracker = false;

    /**
     * field for ValidCCF
     */
    protected com.huawei.www.hss._EnumType localValidCCF;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localValidCCFTracker = false;

    /**
     * field for ShortNum
     */
    protected com.huawei.www.hss._EnumType localShortNum;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localShortNumTracker = false;

    /**
     * field for CfBsgInfo
     * This was an Array!
     */
    protected com.huawei.www.hss.CfBsgInfo_type0[] localCfBsgInfo;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCfBsgInfoTracker = false;

    public boolean isCfSerCodeSpecified() {
        return localCfSerCodeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getCfSerCode() {
        return localCfSerCode;
    }

    /**
     * Auto generated setter method
     * @param param CfSerCode
     */
    public void setCfSerCode(com.huawei.www.hss.Str1_15 param) {
        localCfSerCodeTracker = param != null;

        this.localCfSerCode = param;
    }

    public boolean isCfProvSpecified() {
        return localCfProvTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCfProv() {
        return localCfProv;
    }

    /**
     * Auto generated setter method
     * @param param CfProv
     */
    public void setCfProv(com.huawei.www.hss._EnumType param) {
        localCfProvTracker = param != null;

        this.localCfProv = param;
    }

    public boolean isNFSSpecified() {
        return localNFSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getNFS() {
        return localNFS;
    }

    /**
     * Auto generated setter method
     * @param param NFS
     */
    public void setNFS(com.huawei.www.hss._EnumType param) {
        localNFSTracker = param != null;

        this.localNFS = param;
    }

    public boolean isNCSSpecified() {
        return localNCSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getNCS() {
        return localNCS;
    }

    /**
     * Auto generated setter method
     * @param param NCS
     */
    public void setNCS(com.huawei.www.hss._EnumType param) {
        localNCSTracker = param != null;

        this.localNCS = param;
    }

    public boolean isOfaTplIdSpecified() {
        return localOfaTplIdTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getOfaTplId() {
        return localOfaTplId;
    }

    /**
     * Auto generated setter method
     * @param param OfaTplId
     */
    public void setOfaTplId(com.huawei.www.hss.Int0_65534 param) {
        localOfaTplIdTracker = param != null;

        this.localOfaTplId = param;
    }

    public boolean isCOUSpecified() {
        return localCOUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCOU() {
        return localCOU;
    }

    /**
     * Auto generated setter method
     * @param param COU
     */
    public void setCOU(com.huawei.www.hss._EnumType param) {
        localCOUTracker = param != null;

        this.localCOU = param;
    }

    public boolean isSupinterCfdSpecified() {
        return localSupinterCfdTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupinterCfd() {
        return localSupinterCfd;
    }

    /**
     * Auto generated setter method
     * @param param SupinterCfd
     */
    public void setSupinterCfd(com.huawei.www.hss._EnumType param) {
        localSupinterCfdTracker = param != null;

        this.localSupinterCfd = param;
    }

    public boolean isValidCCFSpecified() {
        return localValidCCFTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getValidCCF() {
        return localValidCCF;
    }

    /**
     * Auto generated setter method
     * @param param ValidCCF
     */
    public void setValidCCF(com.huawei.www.hss._EnumType param) {
        localValidCCFTracker = param != null;

        this.localValidCCF = param;
    }

    public boolean isShortNumSpecified() {
        return localShortNumTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getShortNum() {
        return localShortNum;
    }

    /**
     * Auto generated setter method
     * @param param ShortNum
     */
    public void setShortNum(com.huawei.www.hss._EnumType param) {
        localShortNumTracker = param != null;

        this.localShortNum = param;
    }

    public boolean isCfBsgInfoSpecified() {
        return localCfBsgInfoTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.CfBsgInfo_type0[]
     */
    public com.huawei.www.hss.CfBsgInfo_type0[] getCfBsgInfo() {
        return localCfBsgInfo;
    }

    /**
     * validate the array for CfBsgInfo
     */
    protected void validateCfBsgInfo(com.huawei.www.hss.CfBsgInfo_type0[] param) {
        if ((param != null) && (param.length > 10)) {
            throw new java.lang.RuntimeException(
                "Input values do not follow defined XSD restrictions");
        }
    }

    /**
     * Auto generated setter method
     * @param param CfBsgInfo
     */
    public void setCfBsgInfo(com.huawei.www.hss.CfBsgInfo_type0[] param) {
        validateCfBsgInfo(param);

        localCfBsgInfoTracker = param != null;

        this.localCfBsgInfo = param;
    }

    /**
     * Auto generated add method for the array for convenience
     * @param param com.huawei.www.hss.CfBsgInfo_type0
     */
    public void addCfBsgInfo(com.huawei.www.hss.CfBsgInfo_type0 param) {
        if (localCfBsgInfo == null) {
            localCfBsgInfo = new com.huawei.www.hss.CfBsgInfo_type0[] {  };
        }

        //update the setting tracker
        localCfBsgInfoTracker = true;

        java.util.List list = org.apache.axis2.databinding.utils.ConverterUtil.toList(localCfBsgInfo);
        list.add(param);
        this.localCfBsgInfo = (com.huawei.www.hss.CfBsgInfo_type0[]) list.toArray(new com.huawei.www.hss.CfBsgInfo_type0[list.size()]);
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":CallForward_type0", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "CallForward_type0", xmlWriter);
            }
        }

        if (localCfSerCodeTracker) {
            if (localCfSerCode == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CfSerCode cannot be null!!");
            }

            localCfSerCode.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CfSerCode"), xmlWriter);
        }

        if (localCfProvTracker) {
            if (localCfProv == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CfProv cannot be null!!");
            }

            localCfProv.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CfProv"), xmlWriter);
        }

        if (localNFSTracker) {
            if (localNFS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "NFS cannot be null!!");
            }

            localNFS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "NFS"), xmlWriter);
        }

        if (localNCSTracker) {
            if (localNCS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "NCS cannot be null!!");
            }

            localNCS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "NCS"), xmlWriter);
        }

        if (localOfaTplIdTracker) {
            if (localOfaTplId == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "OfaTplId cannot be null!!");
            }

            localOfaTplId.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "OfaTplId"), xmlWriter);
        }

        if (localCOUTracker) {
            if (localCOU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "COU cannot be null!!");
            }

            localCOU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "COU"), xmlWriter);
        }

        if (localSupinterCfdTracker) {
            if (localSupinterCfd == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupinterCfd cannot be null!!");
            }

            localSupinterCfd.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupinterCfd"), xmlWriter);
        }

        if (localValidCCFTracker) {
            if (localValidCCF == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ValidCCF cannot be null!!");
            }

            localValidCCF.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ValidCCF"), xmlWriter);
        }

        if (localShortNumTracker) {
            if (localShortNum == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ShortNum cannot be null!!");
            }

            localShortNum.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ShortNum"), xmlWriter);
        }

        if (localCfBsgInfoTracker) {
            if (localCfBsgInfo != null) {
                for (int i = 0; i < localCfBsgInfo.length; i++) {
                    if (localCfBsgInfo[i] != null) {
                        localCfBsgInfo[i].serialize(new javax.xml.namespace.QName(
                                "http://www.huawei.com/HSS", "CfBsgInfo"),
                            xmlWriter);
                    } else {
                        // we don't have to do any thing since minOccures is zero
                    }
                }
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "CfBsgInfo cannot be null!!");
            }
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static CallForward_type0 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            CallForward_type0 object = new CallForward_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"CallForward_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (CallForward_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                java.util.ArrayList list10 = new java.util.ArrayList();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CfSerCode").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CfSerCode").equals(
                            reader.getName())) {
                    object.setCfSerCode(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CfProv").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CfProv").equals(
                            reader.getName())) {
                    object.setCfProv(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "NFS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "NFS").equals(
                            reader.getName())) {
                    object.setNFS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "NCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "NCS").equals(
                            reader.getName())) {
                    object.setNCS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "OfaTplId").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "OfaTplId").equals(
                            reader.getName())) {
                    object.setOfaTplId(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "COU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "COU").equals(
                            reader.getName())) {
                    object.setCOU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SupinterCfd").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SupinterCfd").equals(
                            reader.getName())) {
                    object.setSupinterCfd(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ValidCCF").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ValidCCF").equals(
                            reader.getName())) {
                    object.setValidCCF(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ShortNum").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ShortNum").equals(
                            reader.getName())) {
                    object.setShortNum(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CfBsgInfo").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CfBsgInfo").equals(
                            reader.getName())) {
                    // Process the array and step past its final element's end.
                    list10.add(com.huawei.www.hss.CfBsgInfo_type0.Factory.parse(
                            reader));

                    //loop until we find a start element that is not part of this array
                    boolean loopDone10 = false;

                    while (!loopDone10) {
                        // We should be at the end element, but make sure
                        while (!reader.isEndElement())
                            reader.next();

                        // Step out of this element
                        reader.next();

                        // Step to next element event.
                        while (!reader.isStartElement() &&
                                !reader.isEndElement())
                            reader.next();

                        if (reader.isEndElement()) {
                            //two continuous end elements means we are exiting the xml structure
                            loopDone10 = true;
                        } else {
                            if (new javax.xml.namespace.QName(
                                        "http://www.huawei.com/HSS", "CfBsgInfo").equals(
                                        reader.getName())) {
                                list10.add(com.huawei.www.hss.CfBsgInfo_type0.Factory.parse(
                                        reader));
                            } else {
                                loopDone10 = true;
                            }
                        }
                    }

                    // call the converter utility  to convert and set the array
                    object.setCfBsgInfo((com.huawei.www.hss.CfBsgInfo_type0[]) org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                            com.huawei.www.hss.CfBsgInfo_type0.class, list10));
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
