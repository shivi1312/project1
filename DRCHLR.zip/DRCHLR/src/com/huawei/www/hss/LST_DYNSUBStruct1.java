/**
 * LST_DYNSUBStruct1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  LST_DYNSUBStruct1 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class LST_DYNSUBStruct1 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = LST_DYNSUBStruct1
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for IMSI
     */
    protected com.huawei.www.hss.Str6_15 localIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSITracker = false;

    /**
     * field for ISDN
     */
    protected com.huawei.www.hss.Str1_15 localISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localISDNTracker = false;

    /**
     * field for HLRSN
     */
    protected com.huawei.www.hss.Int0_254 localHLRSN;

    /**
     * field for MscNum
     */
    protected com.huawei.www.hss.Str1_8 localMscNum;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMscNumTracker = false;

    /**
     * field for VlrNum
     */
    protected com.huawei.www.hss.Str1_8 localVlrNum;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVlrNumTracker = false;

    /**
     * field for MsPurgedForNonGprs
     */
    protected com.huawei.www.hss._EnumType localMsPurgedForNonGprs;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMsPurgedForNonGprsTracker = false;

    /**
     * field for VLRInHplmn
     */
    protected com.huawei.www.hss._EnumType localVLRInHplmn;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVLRInHplmnTracker = false;

    /**
     * field for VLRInHomeCountry
     */
    protected com.huawei.www.hss._EnumType localVLRInHomeCountry;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVLRInHomeCountryTracker = false;

    /**
     * field for VLRInArea
     */
    protected com.huawei.www.hss._EnumType localVLRInArea;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVLRInAreaTracker = false;

    /**
     * field for RequireCheckSS
     */
    protected com.huawei.www.hss._EnumType localRequireCheckSS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRequireCheckSSTracker = false;

    /**
     * field for RoamingRestrictInMscDueToUnsupportedFeature
     */
    protected com.huawei.www.hss._EnumType localRoamingRestrictInMscDueToUnsupportedFeature;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRoamingRestrictInMscDueToUnsupportedFeatureTracker = false;

    /**
     * field for MscOrVlrAreaRoamingRestrict
     */
    protected com.huawei.www.hss._EnumType localMscOrVlrAreaRoamingRestrict;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMscOrVlrAreaRoamingRestrictTracker = false;

    /**
     * field for ODBarredForUnsupportedCamel
     */
    protected com.huawei.www.hss._EnumType localODBarredForUnsupportedCamel;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBarredForUnsupportedCamelTracker = false;

    /**
     * field for SupportedCamelPhase1
     */
    protected com.huawei.www.hss._EnumType localSupportedCamelPhase1;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedCamelPhase1Tracker = false;

    /**
     * field for SupportedCamelPhase2
     */
    protected com.huawei.www.hss._EnumType localSupportedCamelPhase2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedCamelPhase2Tracker = false;

    /**
     * field for SupportedCamelPhase3
     */
    protected com.huawei.www.hss._EnumType localSupportedCamelPhase3;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedCamelPhase3Tracker = false;

    /**
     * field for SupportedCamelPhase3_SGSN
     */
    protected com.huawei.www.hss._EnumType localSupportedCamelPhase3_SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedCamelPhase3_SGSNTracker = false;

    /**
     * field for SRIMsrnCfActive
     */
    protected com.huawei.www.hss._EnumType localSRIMsrnCfActive;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSRIMsrnCfActiveTracker = false;

    /**
     * field for ZoneCodeStatusAtMsc
     */
    protected com.huawei.www.hss._EnumType localZoneCodeStatusAtMsc;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localZoneCodeStatusAtMscTracker = false;

    /**
     * field for UnsupTS
     */
    protected com.huawei.www.hss._EnumType localUnsupTS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUnsupTSTracker = false;

    /**
     * field for UnsupBSFor2G
     */
    protected com.huawei.www.hss._EnumType localUnsupBSFor2G;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUnsupBSFor2GTracker = false;

    /**
     * field for UnsupBSFor3G
     */
    protected com.huawei.www.hss._EnumType localUnsupBSFor3G;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUnsupBSFor3GTracker = false;

    /**
     * field for UnsupSS
     */
    protected com.huawei.www.hss._EnumType localUnsupSS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUnsupSSTracker = false;

    /**
     * field for ECATEGORYAtMsc
     */
    protected com.huawei.www.hss._EnumType localECATEGORYAtMsc;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localECATEGORYAtMscTracker = false;

    /**
     * field for SupportedCamelPhase4
     */
    protected com.huawei.www.hss._EnumType localSupportedCamelPhase4;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedCamelPhase4Tracker = false;

    /**
     * field for SupportedCamelPhase4_SGSN
     */
    protected com.huawei.www.hss._EnumType localSupportedCamelPhase4_SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedCamelPhase4_SGSNTracker = false;

    /**
     * field for SuperChargerSupportedForGprs
     */
    protected com.huawei.www.hss._EnumType localSuperChargerSupportedForGprs;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSuperChargerSupportedForGprsTracker = false;

    /**
     * field for BaocForVlrRestrict
     */
    protected com.huawei.www.hss._EnumType localBaocForVlrRestrict;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBaocForVlrRestrictTracker = false;

    /**
     * field for OCSI_MSC
     */
    protected com.huawei.www.hss._EnumType localOCSI_MSC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localOCSI_MSCTracker = false;

    /**
     * field for OCSI_SGSN
     */
    protected com.huawei.www.hss._EnumType localOCSI_SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localOCSI_SGSNTracker = false;

    /**
     * field for DCSI_MSC
     */
    protected com.huawei.www.hss._EnumType localDCSI_MSC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDCSI_MSCTracker = false;

    /**
     * field for DCSI_SGSN
     */
    protected com.huawei.www.hss._EnumType localDCSI_SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDCSI_SGSNTracker = false;

    /**
     * field for VTCSI_MSC
     */
    protected com.huawei.www.hss._EnumType localVTCSI_MSC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVTCSI_MSCTracker = false;

    /**
     * field for VTCSI_SGSN
     */
    protected com.huawei.www.hss._EnumType localVTCSI_SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVTCSI_SGSNTracker = false;

    /**
     * field for TCSI_MSC
     */
    protected com.huawei.www.hss._EnumType localTCSI_MSC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTCSI_MSCTracker = false;

    /**
     * field for TCSI_SGSN
     */
    protected com.huawei.www.hss._EnumType localTCSI_SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTCSI_SGSNTracker = false;

    /**
     * field for MTSMSCSI_MSC
     */
    protected com.huawei.www.hss._EnumType localMTSMSCSI_MSC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMTSMSCSI_MSCTracker = false;

    /**
     * field for MTSMSCSI_SGSN
     */
    protected com.huawei.www.hss._EnumType localMTSMSCSI_SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMTSMSCSI_SGSNTracker = false;

    /**
     * field for MGCSI_MSC
     */
    protected com.huawei.www.hss._EnumType localMGCSI_MSC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMGCSI_MSCTracker = false;

    /**
     * field for MGCSI_SGSN
     */
    protected com.huawei.www.hss._EnumType localMGCSI_SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMGCSI_SGSNTracker = false;

    /**
     * field for PSIEnhancements_MSC
     */
    protected com.huawei.www.hss._EnumType localPSIEnhancements_MSC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPSIEnhancements_MSCTracker = false;

    /**
     * field for PSIEnhancements_SGSN
     */
    protected com.huawei.www.hss._EnumType localPSIEnhancements_SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPSIEnhancements_SGSNTracker = false;

    /**
     * field for LMSI
     */
    protected com.huawei.www.hss.Str1_4 localLMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLMSITracker = false;

    /**
     * field for SgsnNum
     */
    protected com.huawei.www.hss.Str1_8 localSgsnNum;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnNumTracker = false;

    /**
     * field for SgsnAddressType
     */
    protected com.huawei.www.hss._EnumType localSgsnAddressType;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnAddressTypeTracker = false;

    /**
     * field for SgsnAddress
     */
    protected com.huawei.www.hss.Str1_16 localSgsnAddress;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnAddressTracker = false;

    /**
     * field for SgsnInHplmn
     */
    protected com.huawei.www.hss._EnumType localSgsnInHplmn;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnInHplmnTracker = false;

    /**
     * field for MsPurgedForGprs
     */
    protected com.huawei.www.hss._EnumType localMsPurgedForGprs;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMsPurgedForGprsTracker = false;

    /**
     * field for SgsnInHomeCountry
     */
    protected com.huawei.www.hss._EnumType localSgsnInHomeCountry;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnInHomeCountryTracker = false;

    /**
     * field for SgsnInArea
     */
    protected com.huawei.www.hss._EnumType localSgsnInArea;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnInAreaTracker = false;

    /**
     * field for RoamingRestrictInSgsnDueToUnsupportedFeature
     */
    protected com.huawei.www.hss._EnumType localRoamingRestrictInSgsnDueToUnsupportedFeature;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRoamingRestrictInSgsnDueToUnsupportedFeatureTracker = false;

    /**
     * field for SgsnAreaRoamingRestrict
     */
    protected com.huawei.www.hss._EnumType localSgsnAreaRoamingRestrict;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSgsnAreaRoamingRestrictTracker = false;

    /**
     * field for ODBarredForUnsupportedCamelForGprs
     */
    protected com.huawei.www.hss._EnumType localODBarredForUnsupportedCamelForGprs;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBarredForUnsupportedCamelForGprsTracker = false;

    /**
     * field for ZoneCodeStatusAtSgsn
     */
    protected com.huawei.www.hss._EnumType localZoneCodeStatusAtSgsn;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localZoneCodeStatusAtSgsnTracker = false;

    /**
     * field for MCEFforGSM
     */
    protected com.huawei.www.hss._EnumType localMCEFforGSM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMCEFforGSMTracker = false;

    /**
     * field for MCEFforGPRS
     */
    protected com.huawei.www.hss._EnumType localMCEFforGPRS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMCEFforGPRSTracker = false;

    /**
     * field for MNRF
     */
    protected com.huawei.www.hss._EnumType localMNRF;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMNRFTracker = false;

    /**
     * field for MNRG
     */
    protected com.huawei.www.hss._EnumType localMNRG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMNRGTracker = false;

    /**
     * field for MNRRforGSM
     */
    protected com.huawei.www.hss._EnumType localMNRRforGSM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMNRRforGSMTracker = false;

    /**
     * field for MNRRforGPRS
     */
    protected com.huawei.www.hss._EnumType localMNRRforGPRS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMNRRforGPRSTracker = false;

    /**
     * field for SupportedShortMessageMTPP
     */
    protected com.huawei.www.hss._EnumType localSupportedShortMessageMTPP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedShortMessageMTPPTracker = false;

    /**
     * field for SupportedShortMessageMOPP
     */
    protected com.huawei.www.hss._EnumType localSupportedShortMessageMOPP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupportedShortMessageMOPPTracker = false;

    /**
     * field for SC
     */
    protected com.huawei.www.hss.Str1_8 localSC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSCTracker = false;

    /**
     * field for SCLINE2
     */
    protected com.huawei.www.hss.Str1_8 localSCLINE2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSCLINE2Tracker = false;

    /**
     * field for BarredSSAccess
     */
    protected com.huawei.www.hss._EnumType localBarredSSAccess;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBarredSSAccessTracker = false;

    /**
     * field for BarredOutgoingEntertainmentCall
     */
    protected com.huawei.www.hss._EnumType localBarredOutgoingEntertainmentCall;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBarredOutgoingEntertainmentCallTracker = false;

    /**
     * field for BarredOutgoingInformationCall
     */
    protected com.huawei.www.hss._EnumType localBarredOutgoingInformationCall;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBarredOutgoingInformationCallTracker = false;

    /**
     * field for SupGSMODBBarredOutgoingInternationalCallExHC
     */
    protected com.huawei.www.hss._EnumType localSupGSMODBBarredOutgoingInternationalCallExHC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupGSMODBBarredOutgoingInternationalCallExHCTracker = false;

    /**
     * field for SupGSMODBBarredOutgoingInternationalCall
     */
    protected com.huawei.www.hss._EnumType localSupGSMODBBarredOutgoingInternationalCall;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupGSMODBBarredOutgoingInternationalCallTracker = false;

    /**
     * field for SupGSMODBBarredAllOutgoingCall
     */
    protected com.huawei.www.hss._EnumType localSupGSMODBBarredAllOutgoingCall;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupGSMODBBarredAllOutgoingCallTracker = false;

    /**
     * field for BarredAllECT
     */
    protected com.huawei.www.hss._EnumType localBarredAllECT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBarredAllECTTracker = false;

    /**
     * field for BarredChargeableECT
     */
    protected com.huawei.www.hss._EnumType localBarredChargeableECT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBarredChargeableECTTracker = false;

    /**
     * field for BarredInternationalECT
     */
    protected com.huawei.www.hss._EnumType localBarredInternationalECT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBarredInternationalECTTracker = false;

    /**
     * field for BarredInterzonalECT
     */
    protected com.huawei.www.hss._EnumType localBarredInterzonalECT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBarredInterzonalECTTracker = false;

    /**
     * field for BarredDECT
     */
    protected com.huawei.www.hss._EnumType localBarredDECT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBarredDECTTracker = false;

    /**
     * field for BarredMECT
     */
    protected com.huawei.www.hss._EnumType localBarredMECT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBarredMECTTracker = false;

    /**
     * field for SupGPRSODBBarredAllOutgoingCall
     */
    protected com.huawei.www.hss._EnumType localSupGPRSODBBarredAllOutgoingCall;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupGPRSODBBarredAllOutgoingCallTracker = false;

    /**
     * field for SupGPRSODBBarredOutgoingInternationalCall
     */
    protected com.huawei.www.hss._EnumType localSupGPRSODBBarredOutgoingInternationalCall;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupGPRSODBBarredOutgoingInternationalCallTracker = false;

    /**
     * field for SupGPRSODBBarredOutgoingInternationalCallExHC
     */
    protected com.huawei.www.hss._EnumType localSupGPRSODBBarredOutgoingInternationalCallExHC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSupGPRSODBBarredOutgoingInternationalCallExHCTracker = false;

    /**
     * field for BarringofPacketOrientedServices
     */
    protected com.huawei.www.hss._EnumType localBarringofPacketOrientedServices;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBarringofPacketOrientedServicesTracker = false;

    /**
     * field for MSCSupportedLCSCapabilitySet1
     */
    protected com.huawei.www.hss._EnumType localMSCSupportedLCSCapabilitySet1;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMSCSupportedLCSCapabilitySet1Tracker = false;

    /**
     * field for MSCSupportedLCSCapabilitySet2
     */
    protected com.huawei.www.hss._EnumType localMSCSupportedLCSCapabilitySet2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMSCSupportedLCSCapabilitySet2Tracker = false;

    /**
     * field for SGSNSupportedLCSCapabilitySet2
     */
    protected com.huawei.www.hss._EnumType localSGSNSupportedLCSCapabilitySet2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSGSNSupportedLCSCapabilitySet2Tracker = false;

    /**
     * field for ALS_DYN
     */
    protected com.huawei.www.hss._EnumType localALS_DYN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localALS_DYNTracker = false;

    /**
     * field for VVDN_DYN
     */
    protected com.huawei.www.hss._EnumType localVVDN_DYN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVVDN_DYNTracker = false;

    /**
     * field for DIMSI
     */
    protected com.huawei.www.hss.Str1_8 localDIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDIMSITracker = false;

    /**
     * field for ACTIMSI
     */
    protected com.huawei.www.hss._EnumType localACTIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localACTIMSITracker = false;

    /**
     * field for GgsnNumber
     */
    protected com.huawei.www.hss.Str0_127 localGgsnNumber;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGgsnNumberTracker = false;

    /**
     * field for GgsnAddressType
     */
    protected com.huawei.www.hss._EnumType localGgsnAddressType;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGgsnAddressTypeTracker = false;

    /**
     * field for GgsnAddress
     */
    protected com.huawei.www.hss.Str0_127 localGgsnAddress;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGgsnAddressTracker = false;

    /**
     * field for LongGroupIDSupported
     */
    protected com.huawei.www.hss._EnumType localLongGroupIDSupported;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLongGroupIDSupportedTracker = false;

    /**
     * field for BasicISTSupported
     */
    protected com.huawei.www.hss._EnumType localBasicISTSupported;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBasicISTSupportedTracker = false;

    /**
     * field for IstCommandSupported
     */
    protected com.huawei.www.hss._EnumType localIstCommandSupported;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIstCommandSupportedTracker = false;

    /**
     * field for SuperChargerSupportedForGsm
     */
    protected com.huawei.www.hss._EnumType localSuperChargerSupportedForGsm;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSuperChargerSupportedForGsmTracker = false;

    /**
     * field for IMEI
     */
    protected com.huawei.www.hss.Str0_127 localIMEI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMEITracker = false;

    /**
     * field for CSUPLTIME
     */
    protected com.huawei.www.hss.Str1_30 localCSUPLTIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCSUPLTIMETracker = false;

    /**
     * field for CSPURGETIME
     */
    protected com.huawei.www.hss.Str1_30 localCSPURGETIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCSPURGETIMETracker = false;

    /**
     * field for PSUPLTIME
     */
    protected com.huawei.www.hss.Str1_30 localPSUPLTIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPSUPLTIMETracker = false;

    /**
     * field for PSPURGETIME
     */
    protected com.huawei.www.hss.Str1_30 localPSPURGETIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPSPURGETIMETracker = false;

    /**
     * field for MAINIMSI
     */
    protected com.huawei.www.hss.Str3_8 localMAINIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAINIMSITracker = false;

    /**
     * field for MIMSI_SMS
     */
    protected com.huawei.www.hss.Int1_9 localMIMSI_SMS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMIMSI_SMSTracker = false;

    /**
     * field for MIMSI_VOBB
     */
    protected com.huawei.www.hss.Int1_9 localMIMSI_VOBB;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMIMSI_VOBBTracker = false;

    /**
     * field for MIMSITYPE
     */
    protected com.huawei.www.hss._EnumType localMIMSITYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMIMSITYPETracker = false;

    /**
     * field for LSFLAG
     */
    protected com.huawei.www.hss._EnumType localLSFLAG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLSFLAGTracker = false;

    /**
     * field for CamelInduceBarringSMS
     */
    protected com.huawei.www.hss._EnumType localCamelInduceBarringSMS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCamelInduceBarringSMSTracker = false;

    /**
     * field for RoamBaocTs11
     */
    protected com.huawei.www.hss._EnumType localRoamBaocTs11;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRoamBaocTs11Tracker = false;

    /**
     * field for MTRF_SUPPORTED
     */
    protected com.huawei.www.hss._EnumType localMTRF_SUPPORTED;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMTRF_SUPPORTEDTracker = false;

    /**
     * field for URRP_MME
     */
    protected com.huawei.www.hss._EnumType localURRP_MME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localURRP_MMETracker = false;

    /**
     * field for URRP_SGSN
     */
    protected com.huawei.www.hss._EnumType localURRP_SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localURRP_SGSNTracker = false;

    /**
     * field for TAI
     */
    protected com.huawei.www.hss.Str9_10 localTAI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTAITracker = false;

    /**
     * field for VLR_NUM_SAI
     */
    protected com.huawei.www.hss.Str0_8 localVLR_NUM_SAI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVLR_NUM_SAITracker = false;

    /**
     * field for TIME_STAMP_SAI
     */
    protected com.huawei.www.hss.Str1_30 localTIME_STAMP_SAI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTIME_STAMP_SAITracker = false;

    /**
     * field for MMEHOST
     */
    protected com.huawei.www.hss.Str1_128 localMMEHOST;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMMEHOSTTracker = false;

    /**
     * field for MMEREALM
     */
    protected com.huawei.www.hss.Str1_128 localMMEREALM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMMEREALMTracker = false;

    /**
     * field for MRATTYPE
     */
    protected com.huawei.www.hss._EnumType localMRATTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMRATTYPETracker = false;

    /**
     * field for MVPLMN
     */
    protected com.huawei.www.hss.Str1_9 localMVPLMN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMVPLMNTracker = false;

    /**
     * field for PURGEDONMME
     */
    protected com.huawei.www.hss._EnumType localPURGEDONMME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPURGEDONMMETracker = false;

    /**
     * field for MMEUpdateLocationTime
     */
    protected com.huawei.www.hss.Str1_35 localMMEUpdateLocationTime;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMMEUpdateLocationTimeTracker = false;

    /**
     * field for MMEFeatureList
     */
    protected com.huawei.www.hss.Str1_9 localMMEFeatureList;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMMEFeatureListTracker = false;

    /**
     * field for MLastIDRorDSRSUCC
     */
    protected com.huawei.www.hss._EnumType localMLastIDRorDSRSUCC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMLastIDRorDSRSUCCTracker = false;

    /**
     * field for MSingleRegistrationIndication
     */
    protected com.huawei.www.hss._EnumType localMSingleRegistrationIndication;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMSingleRegistrationIndicationTracker = false;

    /**
     * field for MSkipSubscriberDataIndicator
     */
    protected com.huawei.www.hss._EnumType localMSkipSubscriberDataIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMSkipSubscriberDataIndicatorTracker = false;

    /**
     * field for MGPRSSubscriptionDataIndicator
     */
    protected com.huawei.www.hss._EnumType localMGPRSSubscriptionDataIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMGPRSSubscriptionDataIndicatorTracker = false;

    /**
     * field for MNodeTypeIndicator
     */
    protected com.huawei.www.hss._EnumType localMNodeTypeIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMNodeTypeIndicatorTracker = false;

    /**
     * field for MInitialAttachIndicator
     */
    protected com.huawei.www.hss._EnumType localMInitialAttachIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMInitialAttachIndicatorTracker = false;

    /**
     * field for MPSLCSNotSupportedByUE
     */
    protected com.huawei.www.hss._EnumType localMPSLCSNotSupportedByUE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMPSLCSNotSupportedByUETracker = false;

    /**
     * field for MIMEI
     */
    protected com.huawei.www.hss.Str1_16 localMIMEI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMIMEITracker = false;

    /**
     * field for MIMEISV
     */
    protected com.huawei.www.hss.Str1_2 localMIMEISV;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMIMEISVTracker = false;

    /**
     * field for SGSNHOST
     */
    protected com.huawei.www.hss.Str1_128 localSGSNHOST;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSGSNHOSTTracker = false;

    /**
     * field for SGSNREALM
     */
    protected com.huawei.www.hss.Str1_128 localSGSNREALM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSGSNREALMTracker = false;

    /**
     * field for SGSNNUMBER
     */
    protected com.huawei.www.hss.Str1_128 localSGSNNUMBER;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSGSNNUMBERTracker = false;

    /**
     * field for SRATTYPE
     */
    protected com.huawei.www.hss._EnumType localSRATTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSRATTYPETracker = false;

    /**
     * field for SVPLMN
     */
    protected com.huawei.www.hss.Str1_9 localSVPLMN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSVPLMNTracker = false;

    /**
     * field for PURGEDONSGSN
     */
    protected com.huawei.www.hss._EnumType localPURGEDONSGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPURGEDONSGSNTracker = false;

    /**
     * field for SAREARESTRICT
     */
    protected com.huawei.www.hss._EnumType localSAREARESTRICT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSAREARESTRICTTracker = false;

    /**
     * field for S4SGSNUpdateLocationTime
     */
    protected com.huawei.www.hss.Str1_35 localS4SGSNUpdateLocationTime;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localS4SGSNUpdateLocationTimeTracker = false;

    /**
     * field for S4SGSNFeatureList
     */
    protected com.huawei.www.hss.Str1_9 localS4SGSNFeatureList;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localS4SGSNFeatureListTracker = false;

    /**
     * field for SLastIDRorDSRSUCC
     */
    protected com.huawei.www.hss._EnumType localSLastIDRorDSRSUCC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSLastIDRorDSRSUCCTracker = false;

    /**
     * field for SSingleRegistrationIndication
     */
    protected com.huawei.www.hss._EnumType localSSingleRegistrationIndication;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSSingleRegistrationIndicationTracker = false;

    /**
     * field for SSkipSubscriberDataIndicator
     */
    protected com.huawei.www.hss._EnumType localSSkipSubscriberDataIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSSkipSubscriberDataIndicatorTracker = false;

    /**
     * field for SGPRSSubscriptionDataIndicator
     */
    protected com.huawei.www.hss._EnumType localSGPRSSubscriptionDataIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSGPRSSubscriptionDataIndicatorTracker = false;

    /**
     * field for SNodeTypeIndicator
     */
    protected com.huawei.www.hss._EnumType localSNodeTypeIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSNodeTypeIndicatorTracker = false;

    /**
     * field for SInitialAttachIndicator
     */
    protected com.huawei.www.hss._EnumType localSInitialAttachIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSInitialAttachIndicatorTracker = false;

    /**
     * field for SPSLCSNotSupportedByUE
     */
    protected com.huawei.www.hss._EnumType localSPSLCSNotSupportedByUE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSPSLCSNotSupportedByUETracker = false;

    /**
     * field for SIMEI
     */
    protected com.huawei.www.hss.Str1_16 localSIMEI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSIMEITracker = false;

    /**
     * field for SIMEISV
     */
    protected com.huawei.www.hss.Str1_16 localSIMEISV;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSIMEISVTracker = false;

    /**
     * field for EPSDYNCNTXID
     */
    protected com.huawei.www.hss.Int1_50 localEPSDYNCNTXID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEPSDYNCNTXIDTracker = false;

    /**
     * field for EPSDYNAPN
     */
    protected com.huawei.www.hss.Str1_63 localEPSDYNAPN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEPSDYNAPNTracker = false;

    /**
     * field for EPSDYNPDNGWHOST
     */
    protected com.huawei.www.hss.Str1_128 localEPSDYNPDNGWHOST;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEPSDYNPDNGWHOSTTracker = false;

    /**
     * field for EPSDYNPDNGWREALM
     */
    protected com.huawei.www.hss.Str1_128 localEPSDYNPDNGWREALM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEPSDYNPDNGWREALMTracker = false;

    /**
     * field for EPSDYNPDNGWIPV4
     */
    protected com.huawei.www.hss.Str7_15 localEPSDYNPDNGWIPV4;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEPSDYNPDNGWIPV4Tracker = false;

    /**
     * field for EPSDYNPDNGWIPV6
     */
    protected com.huawei.www.hss.Str1_40 localEPSDYNPDNGWIPV6;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEPSDYNPDNGWIPV6Tracker = false;

    /**
     * field for EPSDYNWILDCARDFLAG
     */
    protected com.huawei.www.hss._EnumType localEPSDYNWILDCARDFLAG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEPSDYNWILDCARDFLAGTracker = false;

    /**
     * field for EPSDYNVNI
     */
    protected com.huawei.www.hss.Str1_63 localEPSDYNVNI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEPSDYNVNITracker = false;

    /**
     * field for VNI
     */
    protected com.huawei.www.hss.Str1_128 localVNI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVNITracker = false;

    /**
     * field for REGSTATUS
     */
    protected com.huawei.www.hss._EnumType localREGSTATUS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localREGSTATUSTracker = false;

    /**
     * field for ACCESSNETID
     */
    protected com.huawei.www.hss.Str1_16 localACCESSNETID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localACCESSNETIDTracker = false;

    /**
     * field for TGPPAAASERVERNAME
     */
    protected com.huawei.www.hss.Str1_128 localTGPPAAASERVERNAME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTGPPAAASERVERNAMETracker = false;

    /**
     * field for TGPPAAASERVERREALM
     */
    protected com.huawei.www.hss.Str1_128 localTGPPAAASERVERREALM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTGPPAAASERVERREALMTracker = false;

    /**
     * field for TGPP2MEID
     */
    protected com.huawei.www.hss.Str1_16 localTGPP2MEID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTGPP2MEIDTracker = false;

    /**
     * field for AAAIMEI
     */
    protected com.huawei.www.hss.Str1_16 localAAAIMEI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAAAIMEITracker = false;

    /**
     * field for AAAIMEISV
     */
    protected com.huawei.www.hss.Str1_2 localAAAIMEISV;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAAAIMEISVTracker = false;

    /**
     * field for ServerAssignmentTime
     */
    protected com.huawei.www.hss.Str1_35 localServerAssignmentTime;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localServerAssignmentTimeTracker = false;

    /**
     * field for IMSVOPSSessionsSupported
     */
    protected com.huawei.www.hss._EnumType localIMSVOPSSessionsSupported;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSVOPSSessionsSupportedTracker = false;

    /**
     * field for UESRVCCCapability
     */
    protected com.huawei.www.hss._EnumType localUESRVCCCapability;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUESRVCCCapabilityTracker = false;

    /**
     * field for IMSVOPSSessionsSupportedS4SGSN
     */
    protected com.huawei.www.hss._EnumType localIMSVOPSSessionsSupportedS4SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSVOPSSessionsSupportedS4SGSNTracker = false;

    /**
     * field for UESRVCCCapabilityS4SGSN
     */
    protected com.huawei.www.hss._EnumType localUESRVCCCapabilityS4SGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUESRVCCCapabilityS4SGSNTracker = false;

    /**
     * field for UERegisterAtIMS
     */
    protected com.huawei.www.hss._EnumType localUERegisterAtIMS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUERegisterAtIMSTracker = false;

    /**
     * field for IP_SM_GW
     */
    protected com.huawei.www.hss.Str1_15 localIP_SM_GW;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIP_SM_GWTracker = false;

    /**
     * field for MCEFforIP
     */
    protected com.huawei.www.hss._EnumType localMCEFforIP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMCEFforIPTracker = false;

    /**
     * field for UNRI
     */
    protected com.huawei.www.hss._EnumType localUNRI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUNRITracker = false;

    /**
     * field for UNRR
     */
    protected com.huawei.www.hss._EnumType localUNRR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUNRRTracker = false;

    /**
     * field for VGMLCMME
     */
    protected com.huawei.www.hss.Str7_39 localVGMLCMME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVGMLCMMETracker = false;

    /**
     * field for VGMLCSGSN
     */
    protected com.huawei.www.hss.Str7_39 localVGMLCSGSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVGMLCSGSNTracker = false;

    /**
     * field for IMSSF
     */
    protected com.huawei.www.hss.Str1_8 localIMSSF;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSSFTracker = false;

    /**
     * field for CS_V_GMLC_ADDTYPE
     */
    protected com.huawei.www.hss._EnumType localCS_V_GMLC_ADDTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCS_V_GMLC_ADDTYPETracker = false;

    /**
     * field for CS_V_GMLC_ADDRESS
     */
    protected com.huawei.www.hss.Str1_39 localCS_V_GMLC_ADDRESS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCS_V_GMLC_ADDRESSTracker = false;

    /**
     * field for PS_V_GMLC_ADDTYPE
     */
    protected com.huawei.www.hss._EnumType localPS_V_GMLC_ADDTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPS_V_GMLC_ADDTYPETracker = false;

    /**
     * field for PS_V_GMLC_ADDRESS
     */
    protected com.huawei.www.hss.Str1_39 localPS_V_GMLC_ADDRESS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPS_V_GMLC_ADDRESSTracker = false;

    /**
     * field for ACTIVE_IMSI
     */
    protected com.huawei.www.hss.Str6_15 localACTIVE_IMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localACTIVE_IMSITracker = false;

    /**
     * field for DataRef
     */
    protected com.huawei.www.hss._EnumType localDataRef;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDataRefTracker = false;

    /**
     * field for AS_Host_Name
     */
    protected com.huawei.www.hss.Str1_128 localAS_Host_Name;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAS_Host_NameTracker = false;

    /**
     * field for AS_Realm_Name
     */
    protected com.huawei.www.hss.Str1_128 localAS_Realm_Name;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAS_Realm_NameTracker = false;

    /**
     * field for CSMSISDNLESS
     */
    protected com.huawei.www.hss._EnumType localCSMSISDNLESS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCSMSISDNLESSTracker = false;

    /**
     * field for PSMSISDNLESS
     */
    protected com.huawei.www.hss._EnumType localPSMSISDNLESS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPSMSISDNLESSTracker = false;

    /**
     * field for CSRATTYPE
     */
    protected com.huawei.www.hss._EnumType localCSRATTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCSRATTYPETracker = false;

    /**
     * field for PSRATTYPE
     */
    protected com.huawei.www.hss._EnumType localPSRATTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPSRATTYPETracker = false;

    /**
     * field for CsUplStatus
     */
    protected com.huawei.www.hss._EnumType localCsUplStatus;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCsUplStatusTracker = false;

    /**
     * field for PsUplStatus
     */
    protected com.huawei.www.hss._EnumType localPsUplStatus;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPsUplStatusTracker = false;

    public boolean isIMSISpecified() {
        return localIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getIMSI() {
        return localIMSI;
    }

    /**
     * Auto generated setter method
     * @param param IMSI
     */
    public void setIMSI(com.huawei.www.hss.Str6_15 param) {
        localIMSITracker = param != null;

        this.localIMSI = param;
    }

    public boolean isISDNSpecified() {
        return localISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getISDN() {
        return localISDN;
    }

    /**
     * Auto generated setter method
     * @param param ISDN
     */
    public void setISDN(com.huawei.www.hss.Str1_15 param) {
        localISDNTracker = param != null;

        this.localISDN = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_254
     */
    public com.huawei.www.hss.Int0_254 getHLRSN() {
        return localHLRSN;
    }

    /**
     * Auto generated setter method
     * @param param HLRSN
     */
    public void setHLRSN(com.huawei.www.hss.Int0_254 param) {
        this.localHLRSN = param;
    }

    public boolean isMscNumSpecified() {
        return localMscNumTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_8
     */
    public com.huawei.www.hss.Str1_8 getMscNum() {
        return localMscNum;
    }

    /**
     * Auto generated setter method
     * @param param MscNum
     */
    public void setMscNum(com.huawei.www.hss.Str1_8 param) {
        localMscNumTracker = param != null;

        this.localMscNum = param;
    }

    public boolean isVlrNumSpecified() {
        return localVlrNumTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_8
     */
    public com.huawei.www.hss.Str1_8 getVlrNum() {
        return localVlrNum;
    }

    /**
     * Auto generated setter method
     * @param param VlrNum
     */
    public void setVlrNum(com.huawei.www.hss.Str1_8 param) {
        localVlrNumTracker = param != null;

        this.localVlrNum = param;
    }

    public boolean isMsPurgedForNonGprsSpecified() {
        return localMsPurgedForNonGprsTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMsPurgedForNonGprs() {
        return localMsPurgedForNonGprs;
    }

    /**
     * Auto generated setter method
     * @param param MsPurgedForNonGprs
     */
    public void setMsPurgedForNonGprs(com.huawei.www.hss._EnumType param) {
        localMsPurgedForNonGprsTracker = param != null;

        this.localMsPurgedForNonGprs = param;
    }

    public boolean isVLRInHplmnSpecified() {
        return localVLRInHplmnTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVLRInHplmn() {
        return localVLRInHplmn;
    }

    /**
     * Auto generated setter method
     * @param param VLRInHplmn
     */
    public void setVLRInHplmn(com.huawei.www.hss._EnumType param) {
        localVLRInHplmnTracker = param != null;

        this.localVLRInHplmn = param;
    }

    public boolean isVLRInHomeCountrySpecified() {
        return localVLRInHomeCountryTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVLRInHomeCountry() {
        return localVLRInHomeCountry;
    }

    /**
     * Auto generated setter method
     * @param param VLRInHomeCountry
     */
    public void setVLRInHomeCountry(com.huawei.www.hss._EnumType param) {
        localVLRInHomeCountryTracker = param != null;

        this.localVLRInHomeCountry = param;
    }

    public boolean isVLRInAreaSpecified() {
        return localVLRInAreaTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVLRInArea() {
        return localVLRInArea;
    }

    /**
     * Auto generated setter method
     * @param param VLRInArea
     */
    public void setVLRInArea(com.huawei.www.hss._EnumType param) {
        localVLRInAreaTracker = param != null;

        this.localVLRInArea = param;
    }

    public boolean isRequireCheckSSSpecified() {
        return localRequireCheckSSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRequireCheckSS() {
        return localRequireCheckSS;
    }

    /**
     * Auto generated setter method
     * @param param RequireCheckSS
     */
    public void setRequireCheckSS(com.huawei.www.hss._EnumType param) {
        localRequireCheckSSTracker = param != null;

        this.localRequireCheckSS = param;
    }

    public boolean isRoamingRestrictInMscDueToUnsupportedFeatureSpecified() {
        return localRoamingRestrictInMscDueToUnsupportedFeatureTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRoamingRestrictInMscDueToUnsupportedFeature() {
        return localRoamingRestrictInMscDueToUnsupportedFeature;
    }

    /**
     * Auto generated setter method
     * @param param RoamingRestrictInMscDueToUnsupportedFeature
     */
    public void setRoamingRestrictInMscDueToUnsupportedFeature(
        com.huawei.www.hss._EnumType param) {
        localRoamingRestrictInMscDueToUnsupportedFeatureTracker = param != null;

        this.localRoamingRestrictInMscDueToUnsupportedFeature = param;
    }

    public boolean isMscOrVlrAreaRoamingRestrictSpecified() {
        return localMscOrVlrAreaRoamingRestrictTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMscOrVlrAreaRoamingRestrict() {
        return localMscOrVlrAreaRoamingRestrict;
    }

    /**
     * Auto generated setter method
     * @param param MscOrVlrAreaRoamingRestrict
     */
    public void setMscOrVlrAreaRoamingRestrict(
        com.huawei.www.hss._EnumType param) {
        localMscOrVlrAreaRoamingRestrictTracker = param != null;

        this.localMscOrVlrAreaRoamingRestrict = param;
    }

    public boolean isODBarredForUnsupportedCamelSpecified() {
        return localODBarredForUnsupportedCamelTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBarredForUnsupportedCamel() {
        return localODBarredForUnsupportedCamel;
    }

    /**
     * Auto generated setter method
     * @param param ODBarredForUnsupportedCamel
     */
    public void setODBarredForUnsupportedCamel(
        com.huawei.www.hss._EnumType param) {
        localODBarredForUnsupportedCamelTracker = param != null;

        this.localODBarredForUnsupportedCamel = param;
    }

    public boolean isSupportedCamelPhase1Specified() {
        return localSupportedCamelPhase1Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedCamelPhase1() {
        return localSupportedCamelPhase1;
    }

    /**
     * Auto generated setter method
     * @param param SupportedCamelPhase1
     */
    public void setSupportedCamelPhase1(com.huawei.www.hss._EnumType param) {
        localSupportedCamelPhase1Tracker = param != null;

        this.localSupportedCamelPhase1 = param;
    }

    public boolean isSupportedCamelPhase2Specified() {
        return localSupportedCamelPhase2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedCamelPhase2() {
        return localSupportedCamelPhase2;
    }

    /**
     * Auto generated setter method
     * @param param SupportedCamelPhase2
     */
    public void setSupportedCamelPhase2(com.huawei.www.hss._EnumType param) {
        localSupportedCamelPhase2Tracker = param != null;

        this.localSupportedCamelPhase2 = param;
    }

    public boolean isSupportedCamelPhase3Specified() {
        return localSupportedCamelPhase3Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedCamelPhase3() {
        return localSupportedCamelPhase3;
    }

    /**
     * Auto generated setter method
     * @param param SupportedCamelPhase3
     */
    public void setSupportedCamelPhase3(com.huawei.www.hss._EnumType param) {
        localSupportedCamelPhase3Tracker = param != null;

        this.localSupportedCamelPhase3 = param;
    }

    public boolean isSupportedCamelPhase3_SGSNSpecified() {
        return localSupportedCamelPhase3_SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedCamelPhase3_SGSN() {
        return localSupportedCamelPhase3_SGSN;
    }

    /**
     * Auto generated setter method
     * @param param SupportedCamelPhase3_SGSN
     */
    public void setSupportedCamelPhase3_SGSN(com.huawei.www.hss._EnumType param) {
        localSupportedCamelPhase3_SGSNTracker = param != null;

        this.localSupportedCamelPhase3_SGSN = param;
    }

    public boolean isSRIMsrnCfActiveSpecified() {
        return localSRIMsrnCfActiveTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSRIMsrnCfActive() {
        return localSRIMsrnCfActive;
    }

    /**
     * Auto generated setter method
     * @param param SRIMsrnCfActive
     */
    public void setSRIMsrnCfActive(com.huawei.www.hss._EnumType param) {
        localSRIMsrnCfActiveTracker = param != null;

        this.localSRIMsrnCfActive = param;
    }

    public boolean isZoneCodeStatusAtMscSpecified() {
        return localZoneCodeStatusAtMscTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getZoneCodeStatusAtMsc() {
        return localZoneCodeStatusAtMsc;
    }

    /**
     * Auto generated setter method
     * @param param ZoneCodeStatusAtMsc
     */
    public void setZoneCodeStatusAtMsc(com.huawei.www.hss._EnumType param) {
        localZoneCodeStatusAtMscTracker = param != null;

        this.localZoneCodeStatusAtMsc = param;
    }

    public boolean isUnsupTSSpecified() {
        return localUnsupTSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUnsupTS() {
        return localUnsupTS;
    }

    /**
     * Auto generated setter method
     * @param param UnsupTS
     */
    public void setUnsupTS(com.huawei.www.hss._EnumType param) {
        localUnsupTSTracker = param != null;

        this.localUnsupTS = param;
    }

    public boolean isUnsupBSFor2GSpecified() {
        return localUnsupBSFor2GTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUnsupBSFor2G() {
        return localUnsupBSFor2G;
    }

    /**
     * Auto generated setter method
     * @param param UnsupBSFor2G
     */
    public void setUnsupBSFor2G(com.huawei.www.hss._EnumType param) {
        localUnsupBSFor2GTracker = param != null;

        this.localUnsupBSFor2G = param;
    }

    public boolean isUnsupBSFor3GSpecified() {
        return localUnsupBSFor3GTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUnsupBSFor3G() {
        return localUnsupBSFor3G;
    }

    /**
     * Auto generated setter method
     * @param param UnsupBSFor3G
     */
    public void setUnsupBSFor3G(com.huawei.www.hss._EnumType param) {
        localUnsupBSFor3GTracker = param != null;

        this.localUnsupBSFor3G = param;
    }

    public boolean isUnsupSSSpecified() {
        return localUnsupSSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUnsupSS() {
        return localUnsupSS;
    }

    /**
     * Auto generated setter method
     * @param param UnsupSS
     */
    public void setUnsupSS(com.huawei.www.hss._EnumType param) {
        localUnsupSSTracker = param != null;

        this.localUnsupSS = param;
    }

    public boolean isECATEGORYAtMscSpecified() {
        return localECATEGORYAtMscTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getECATEGORYAtMsc() {
        return localECATEGORYAtMsc;
    }

    /**
     * Auto generated setter method
     * @param param ECATEGORYAtMsc
     */
    public void setECATEGORYAtMsc(com.huawei.www.hss._EnumType param) {
        localECATEGORYAtMscTracker = param != null;

        this.localECATEGORYAtMsc = param;
    }

    public boolean isSupportedCamelPhase4Specified() {
        return localSupportedCamelPhase4Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedCamelPhase4() {
        return localSupportedCamelPhase4;
    }

    /**
     * Auto generated setter method
     * @param param SupportedCamelPhase4
     */
    public void setSupportedCamelPhase4(com.huawei.www.hss._EnumType param) {
        localSupportedCamelPhase4Tracker = param != null;

        this.localSupportedCamelPhase4 = param;
    }

    public boolean isSupportedCamelPhase4_SGSNSpecified() {
        return localSupportedCamelPhase4_SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedCamelPhase4_SGSN() {
        return localSupportedCamelPhase4_SGSN;
    }

    /**
     * Auto generated setter method
     * @param param SupportedCamelPhase4_SGSN
     */
    public void setSupportedCamelPhase4_SGSN(com.huawei.www.hss._EnumType param) {
        localSupportedCamelPhase4_SGSNTracker = param != null;

        this.localSupportedCamelPhase4_SGSN = param;
    }

    public boolean isSuperChargerSupportedForGprsSpecified() {
        return localSuperChargerSupportedForGprsTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSuperChargerSupportedForGprs() {
        return localSuperChargerSupportedForGprs;
    }

    /**
     * Auto generated setter method
     * @param param SuperChargerSupportedForGprs
     */
    public void setSuperChargerSupportedForGprs(
        com.huawei.www.hss._EnumType param) {
        localSuperChargerSupportedForGprsTracker = param != null;

        this.localSuperChargerSupportedForGprs = param;
    }

    public boolean isBaocForVlrRestrictSpecified() {
        return localBaocForVlrRestrictTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBaocForVlrRestrict() {
        return localBaocForVlrRestrict;
    }

    /**
     * Auto generated setter method
     * @param param BaocForVlrRestrict
     */
    public void setBaocForVlrRestrict(com.huawei.www.hss._EnumType param) {
        localBaocForVlrRestrictTracker = param != null;

        this.localBaocForVlrRestrict = param;
    }

    public boolean isOCSI_MSCSpecified() {
        return localOCSI_MSCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getOCSI_MSC() {
        return localOCSI_MSC;
    }

    /**
     * Auto generated setter method
     * @param param OCSI_MSC
     */
    public void setOCSI_MSC(com.huawei.www.hss._EnumType param) {
        localOCSI_MSCTracker = param != null;

        this.localOCSI_MSC = param;
    }

    public boolean isOCSI_SGSNSpecified() {
        return localOCSI_SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getOCSI_SGSN() {
        return localOCSI_SGSN;
    }

    /**
     * Auto generated setter method
     * @param param OCSI_SGSN
     */
    public void setOCSI_SGSN(com.huawei.www.hss._EnumType param) {
        localOCSI_SGSNTracker = param != null;

        this.localOCSI_SGSN = param;
    }

    public boolean isDCSI_MSCSpecified() {
        return localDCSI_MSCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDCSI_MSC() {
        return localDCSI_MSC;
    }

    /**
     * Auto generated setter method
     * @param param DCSI_MSC
     */
    public void setDCSI_MSC(com.huawei.www.hss._EnumType param) {
        localDCSI_MSCTracker = param != null;

        this.localDCSI_MSC = param;
    }

    public boolean isDCSI_SGSNSpecified() {
        return localDCSI_SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDCSI_SGSN() {
        return localDCSI_SGSN;
    }

    /**
     * Auto generated setter method
     * @param param DCSI_SGSN
     */
    public void setDCSI_SGSN(com.huawei.www.hss._EnumType param) {
        localDCSI_SGSNTracker = param != null;

        this.localDCSI_SGSN = param;
    }

    public boolean isVTCSI_MSCSpecified() {
        return localVTCSI_MSCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVTCSI_MSC() {
        return localVTCSI_MSC;
    }

    /**
     * Auto generated setter method
     * @param param VTCSI_MSC
     */
    public void setVTCSI_MSC(com.huawei.www.hss._EnumType param) {
        localVTCSI_MSCTracker = param != null;

        this.localVTCSI_MSC = param;
    }

    public boolean isVTCSI_SGSNSpecified() {
        return localVTCSI_SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVTCSI_SGSN() {
        return localVTCSI_SGSN;
    }

    /**
     * Auto generated setter method
     * @param param VTCSI_SGSN
     */
    public void setVTCSI_SGSN(com.huawei.www.hss._EnumType param) {
        localVTCSI_SGSNTracker = param != null;

        this.localVTCSI_SGSN = param;
    }

    public boolean isTCSI_MSCSpecified() {
        return localTCSI_MSCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTCSI_MSC() {
        return localTCSI_MSC;
    }

    /**
     * Auto generated setter method
     * @param param TCSI_MSC
     */
    public void setTCSI_MSC(com.huawei.www.hss._EnumType param) {
        localTCSI_MSCTracker = param != null;

        this.localTCSI_MSC = param;
    }

    public boolean isTCSI_SGSNSpecified() {
        return localTCSI_SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTCSI_SGSN() {
        return localTCSI_SGSN;
    }

    /**
     * Auto generated setter method
     * @param param TCSI_SGSN
     */
    public void setTCSI_SGSN(com.huawei.www.hss._EnumType param) {
        localTCSI_SGSNTracker = param != null;

        this.localTCSI_SGSN = param;
    }

    public boolean isMTSMSCSI_MSCSpecified() {
        return localMTSMSCSI_MSCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMTSMSCSI_MSC() {
        return localMTSMSCSI_MSC;
    }

    /**
     * Auto generated setter method
     * @param param MTSMSCSI_MSC
     */
    public void setMTSMSCSI_MSC(com.huawei.www.hss._EnumType param) {
        localMTSMSCSI_MSCTracker = param != null;

        this.localMTSMSCSI_MSC = param;
    }

    public boolean isMTSMSCSI_SGSNSpecified() {
        return localMTSMSCSI_SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMTSMSCSI_SGSN() {
        return localMTSMSCSI_SGSN;
    }

    /**
     * Auto generated setter method
     * @param param MTSMSCSI_SGSN
     */
    public void setMTSMSCSI_SGSN(com.huawei.www.hss._EnumType param) {
        localMTSMSCSI_SGSNTracker = param != null;

        this.localMTSMSCSI_SGSN = param;
    }

    public boolean isMGCSI_MSCSpecified() {
        return localMGCSI_MSCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMGCSI_MSC() {
        return localMGCSI_MSC;
    }

    /**
     * Auto generated setter method
     * @param param MGCSI_MSC
     */
    public void setMGCSI_MSC(com.huawei.www.hss._EnumType param) {
        localMGCSI_MSCTracker = param != null;

        this.localMGCSI_MSC = param;
    }

    public boolean isMGCSI_SGSNSpecified() {
        return localMGCSI_SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMGCSI_SGSN() {
        return localMGCSI_SGSN;
    }

    /**
     * Auto generated setter method
     * @param param MGCSI_SGSN
     */
    public void setMGCSI_SGSN(com.huawei.www.hss._EnumType param) {
        localMGCSI_SGSNTracker = param != null;

        this.localMGCSI_SGSN = param;
    }

    public boolean isPSIEnhancements_MSCSpecified() {
        return localPSIEnhancements_MSCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPSIEnhancements_MSC() {
        return localPSIEnhancements_MSC;
    }

    /**
     * Auto generated setter method
     * @param param PSIEnhancements_MSC
     */
    public void setPSIEnhancements_MSC(com.huawei.www.hss._EnumType param) {
        localPSIEnhancements_MSCTracker = param != null;

        this.localPSIEnhancements_MSC = param;
    }

    public boolean isPSIEnhancements_SGSNSpecified() {
        return localPSIEnhancements_SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPSIEnhancements_SGSN() {
        return localPSIEnhancements_SGSN;
    }

    /**
     * Auto generated setter method
     * @param param PSIEnhancements_SGSN
     */
    public void setPSIEnhancements_SGSN(com.huawei.www.hss._EnumType param) {
        localPSIEnhancements_SGSNTracker = param != null;

        this.localPSIEnhancements_SGSN = param;
    }

    public boolean isLMSISpecified() {
        return localLMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_4
     */
    public com.huawei.www.hss.Str1_4 getLMSI() {
        return localLMSI;
    }

    /**
     * Auto generated setter method
     * @param param LMSI
     */
    public void setLMSI(com.huawei.www.hss.Str1_4 param) {
        localLMSITracker = param != null;

        this.localLMSI = param;
    }

    public boolean isSgsnNumSpecified() {
        return localSgsnNumTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_8
     */
    public com.huawei.www.hss.Str1_8 getSgsnNum() {
        return localSgsnNum;
    }

    /**
     * Auto generated setter method
     * @param param SgsnNum
     */
    public void setSgsnNum(com.huawei.www.hss.Str1_8 param) {
        localSgsnNumTracker = param != null;

        this.localSgsnNum = param;
    }

    public boolean isSgsnAddressTypeSpecified() {
        return localSgsnAddressTypeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSgsnAddressType() {
        return localSgsnAddressType;
    }

    /**
     * Auto generated setter method
     * @param param SgsnAddressType
     */
    public void setSgsnAddressType(com.huawei.www.hss._EnumType param) {
        localSgsnAddressTypeTracker = param != null;

        this.localSgsnAddressType = param;
    }

    public boolean isSgsnAddressSpecified() {
        return localSgsnAddressTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getSgsnAddress() {
        return localSgsnAddress;
    }

    /**
     * Auto generated setter method
     * @param param SgsnAddress
     */
    public void setSgsnAddress(com.huawei.www.hss.Str1_16 param) {
        localSgsnAddressTracker = param != null;

        this.localSgsnAddress = param;
    }

    public boolean isSgsnInHplmnSpecified() {
        return localSgsnInHplmnTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSgsnInHplmn() {
        return localSgsnInHplmn;
    }

    /**
     * Auto generated setter method
     * @param param SgsnInHplmn
     */
    public void setSgsnInHplmn(com.huawei.www.hss._EnumType param) {
        localSgsnInHplmnTracker = param != null;

        this.localSgsnInHplmn = param;
    }

    public boolean isMsPurgedForGprsSpecified() {
        return localMsPurgedForGprsTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMsPurgedForGprs() {
        return localMsPurgedForGprs;
    }

    /**
     * Auto generated setter method
     * @param param MsPurgedForGprs
     */
    public void setMsPurgedForGprs(com.huawei.www.hss._EnumType param) {
        localMsPurgedForGprsTracker = param != null;

        this.localMsPurgedForGprs = param;
    }

    public boolean isSgsnInHomeCountrySpecified() {
        return localSgsnInHomeCountryTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSgsnInHomeCountry() {
        return localSgsnInHomeCountry;
    }

    /**
     * Auto generated setter method
     * @param param SgsnInHomeCountry
     */
    public void setSgsnInHomeCountry(com.huawei.www.hss._EnumType param) {
        localSgsnInHomeCountryTracker = param != null;

        this.localSgsnInHomeCountry = param;
    }

    public boolean isSgsnInAreaSpecified() {
        return localSgsnInAreaTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSgsnInArea() {
        return localSgsnInArea;
    }

    /**
     * Auto generated setter method
     * @param param SgsnInArea
     */
    public void setSgsnInArea(com.huawei.www.hss._EnumType param) {
        localSgsnInAreaTracker = param != null;

        this.localSgsnInArea = param;
    }

    public boolean isRoamingRestrictInSgsnDueToUnsupportedFeatureSpecified() {
        return localRoamingRestrictInSgsnDueToUnsupportedFeatureTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRoamingRestrictInSgsnDueToUnsupportedFeature() {
        return localRoamingRestrictInSgsnDueToUnsupportedFeature;
    }

    /**
     * Auto generated setter method
     * @param param RoamingRestrictInSgsnDueToUnsupportedFeature
     */
    public void setRoamingRestrictInSgsnDueToUnsupportedFeature(
        com.huawei.www.hss._EnumType param) {
        localRoamingRestrictInSgsnDueToUnsupportedFeatureTracker = param != null;

        this.localRoamingRestrictInSgsnDueToUnsupportedFeature = param;
    }

    public boolean isSgsnAreaRoamingRestrictSpecified() {
        return localSgsnAreaRoamingRestrictTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSgsnAreaRoamingRestrict() {
        return localSgsnAreaRoamingRestrict;
    }

    /**
     * Auto generated setter method
     * @param param SgsnAreaRoamingRestrict
     */
    public void setSgsnAreaRoamingRestrict(com.huawei.www.hss._EnumType param) {
        localSgsnAreaRoamingRestrictTracker = param != null;

        this.localSgsnAreaRoamingRestrict = param;
    }

    public boolean isODBarredForUnsupportedCamelForGprsSpecified() {
        return localODBarredForUnsupportedCamelForGprsTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBarredForUnsupportedCamelForGprs() {
        return localODBarredForUnsupportedCamelForGprs;
    }

    /**
     * Auto generated setter method
     * @param param ODBarredForUnsupportedCamelForGprs
     */
    public void setODBarredForUnsupportedCamelForGprs(
        com.huawei.www.hss._EnumType param) {
        localODBarredForUnsupportedCamelForGprsTracker = param != null;

        this.localODBarredForUnsupportedCamelForGprs = param;
    }

    public boolean isZoneCodeStatusAtSgsnSpecified() {
        return localZoneCodeStatusAtSgsnTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getZoneCodeStatusAtSgsn() {
        return localZoneCodeStatusAtSgsn;
    }

    /**
     * Auto generated setter method
     * @param param ZoneCodeStatusAtSgsn
     */
    public void setZoneCodeStatusAtSgsn(com.huawei.www.hss._EnumType param) {
        localZoneCodeStatusAtSgsnTracker = param != null;

        this.localZoneCodeStatusAtSgsn = param;
    }

    public boolean isMCEFforGSMSpecified() {
        return localMCEFforGSMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMCEFforGSM() {
        return localMCEFforGSM;
    }

    /**
     * Auto generated setter method
     * @param param MCEFforGSM
     */
    public void setMCEFforGSM(com.huawei.www.hss._EnumType param) {
        localMCEFforGSMTracker = param != null;

        this.localMCEFforGSM = param;
    }

    public boolean isMCEFforGPRSSpecified() {
        return localMCEFforGPRSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMCEFforGPRS() {
        return localMCEFforGPRS;
    }

    /**
     * Auto generated setter method
     * @param param MCEFforGPRS
     */
    public void setMCEFforGPRS(com.huawei.www.hss._EnumType param) {
        localMCEFforGPRSTracker = param != null;

        this.localMCEFforGPRS = param;
    }

    public boolean isMNRFSpecified() {
        return localMNRFTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMNRF() {
        return localMNRF;
    }

    /**
     * Auto generated setter method
     * @param param MNRF
     */
    public void setMNRF(com.huawei.www.hss._EnumType param) {
        localMNRFTracker = param != null;

        this.localMNRF = param;
    }

    public boolean isMNRGSpecified() {
        return localMNRGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMNRG() {
        return localMNRG;
    }

    /**
     * Auto generated setter method
     * @param param MNRG
     */
    public void setMNRG(com.huawei.www.hss._EnumType param) {
        localMNRGTracker = param != null;

        this.localMNRG = param;
    }

    public boolean isMNRRforGSMSpecified() {
        return localMNRRforGSMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMNRRforGSM() {
        return localMNRRforGSM;
    }

    /**
     * Auto generated setter method
     * @param param MNRRforGSM
     */
    public void setMNRRforGSM(com.huawei.www.hss._EnumType param) {
        localMNRRforGSMTracker = param != null;

        this.localMNRRforGSM = param;
    }

    public boolean isMNRRforGPRSSpecified() {
        return localMNRRforGPRSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMNRRforGPRS() {
        return localMNRRforGPRS;
    }

    /**
     * Auto generated setter method
     * @param param MNRRforGPRS
     */
    public void setMNRRforGPRS(com.huawei.www.hss._EnumType param) {
        localMNRRforGPRSTracker = param != null;

        this.localMNRRforGPRS = param;
    }

    public boolean isSupportedShortMessageMTPPSpecified() {
        return localSupportedShortMessageMTPPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedShortMessageMTPP() {
        return localSupportedShortMessageMTPP;
    }

    /**
     * Auto generated setter method
     * @param param SupportedShortMessageMTPP
     */
    public void setSupportedShortMessageMTPP(com.huawei.www.hss._EnumType param) {
        localSupportedShortMessageMTPPTracker = param != null;

        this.localSupportedShortMessageMTPP = param;
    }

    public boolean isSupportedShortMessageMOPPSpecified() {
        return localSupportedShortMessageMOPPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupportedShortMessageMOPP() {
        return localSupportedShortMessageMOPP;
    }

    /**
     * Auto generated setter method
     * @param param SupportedShortMessageMOPP
     */
    public void setSupportedShortMessageMOPP(com.huawei.www.hss._EnumType param) {
        localSupportedShortMessageMOPPTracker = param != null;

        this.localSupportedShortMessageMOPP = param;
    }

    public boolean isSCSpecified() {
        return localSCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_8
     */
    public com.huawei.www.hss.Str1_8 getSC() {
        return localSC;
    }

    /**
     * Auto generated setter method
     * @param param SC
     */
    public void setSC(com.huawei.www.hss.Str1_8 param) {
        localSCTracker = param != null;

        this.localSC = param;
    }

    public boolean isSCLINE2Specified() {
        return localSCLINE2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_8
     */
    public com.huawei.www.hss.Str1_8 getSCLINE2() {
        return localSCLINE2;
    }

    /**
     * Auto generated setter method
     * @param param SCLINE2
     */
    public void setSCLINE2(com.huawei.www.hss.Str1_8 param) {
        localSCLINE2Tracker = param != null;

        this.localSCLINE2 = param;
    }

    public boolean isBarredSSAccessSpecified() {
        return localBarredSSAccessTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBarredSSAccess() {
        return localBarredSSAccess;
    }

    /**
     * Auto generated setter method
     * @param param BarredSSAccess
     */
    public void setBarredSSAccess(com.huawei.www.hss._EnumType param) {
        localBarredSSAccessTracker = param != null;

        this.localBarredSSAccess = param;
    }

    public boolean isBarredOutgoingEntertainmentCallSpecified() {
        return localBarredOutgoingEntertainmentCallTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBarredOutgoingEntertainmentCall() {
        return localBarredOutgoingEntertainmentCall;
    }

    /**
     * Auto generated setter method
     * @param param BarredOutgoingEntertainmentCall
     */
    public void setBarredOutgoingEntertainmentCall(
        com.huawei.www.hss._EnumType param) {
        localBarredOutgoingEntertainmentCallTracker = param != null;

        this.localBarredOutgoingEntertainmentCall = param;
    }

    public boolean isBarredOutgoingInformationCallSpecified() {
        return localBarredOutgoingInformationCallTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBarredOutgoingInformationCall() {
        return localBarredOutgoingInformationCall;
    }

    /**
     * Auto generated setter method
     * @param param BarredOutgoingInformationCall
     */
    public void setBarredOutgoingInformationCall(
        com.huawei.www.hss._EnumType param) {
        localBarredOutgoingInformationCallTracker = param != null;

        this.localBarredOutgoingInformationCall = param;
    }

    public boolean isSupGSMODBBarredOutgoingInternationalCallExHCSpecified() {
        return localSupGSMODBBarredOutgoingInternationalCallExHCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupGSMODBBarredOutgoingInternationalCallExHC() {
        return localSupGSMODBBarredOutgoingInternationalCallExHC;
    }

    /**
     * Auto generated setter method
     * @param param SupGSMODBBarredOutgoingInternationalCallExHC
     */
    public void setSupGSMODBBarredOutgoingInternationalCallExHC(
        com.huawei.www.hss._EnumType param) {
        localSupGSMODBBarredOutgoingInternationalCallExHCTracker = param != null;

        this.localSupGSMODBBarredOutgoingInternationalCallExHC = param;
    }

    public boolean isSupGSMODBBarredOutgoingInternationalCallSpecified() {
        return localSupGSMODBBarredOutgoingInternationalCallTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupGSMODBBarredOutgoingInternationalCall() {
        return localSupGSMODBBarredOutgoingInternationalCall;
    }

    /**
     * Auto generated setter method
     * @param param SupGSMODBBarredOutgoingInternationalCall
     */
    public void setSupGSMODBBarredOutgoingInternationalCall(
        com.huawei.www.hss._EnumType param) {
        localSupGSMODBBarredOutgoingInternationalCallTracker = param != null;

        this.localSupGSMODBBarredOutgoingInternationalCall = param;
    }

    public boolean isSupGSMODBBarredAllOutgoingCallSpecified() {
        return localSupGSMODBBarredAllOutgoingCallTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupGSMODBBarredAllOutgoingCall() {
        return localSupGSMODBBarredAllOutgoingCall;
    }

    /**
     * Auto generated setter method
     * @param param SupGSMODBBarredAllOutgoingCall
     */
    public void setSupGSMODBBarredAllOutgoingCall(
        com.huawei.www.hss._EnumType param) {
        localSupGSMODBBarredAllOutgoingCallTracker = param != null;

        this.localSupGSMODBBarredAllOutgoingCall = param;
    }

    public boolean isBarredAllECTSpecified() {
        return localBarredAllECTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBarredAllECT() {
        return localBarredAllECT;
    }

    /**
     * Auto generated setter method
     * @param param BarredAllECT
     */
    public void setBarredAllECT(com.huawei.www.hss._EnumType param) {
        localBarredAllECTTracker = param != null;

        this.localBarredAllECT = param;
    }

    public boolean isBarredChargeableECTSpecified() {
        return localBarredChargeableECTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBarredChargeableECT() {
        return localBarredChargeableECT;
    }

    /**
     * Auto generated setter method
     * @param param BarredChargeableECT
     */
    public void setBarredChargeableECT(com.huawei.www.hss._EnumType param) {
        localBarredChargeableECTTracker = param != null;

        this.localBarredChargeableECT = param;
    }

    public boolean isBarredInternationalECTSpecified() {
        return localBarredInternationalECTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBarredInternationalECT() {
        return localBarredInternationalECT;
    }

    /**
     * Auto generated setter method
     * @param param BarredInternationalECT
     */
    public void setBarredInternationalECT(com.huawei.www.hss._EnumType param) {
        localBarredInternationalECTTracker = param != null;

        this.localBarredInternationalECT = param;
    }

    public boolean isBarredInterzonalECTSpecified() {
        return localBarredInterzonalECTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBarredInterzonalECT() {
        return localBarredInterzonalECT;
    }

    /**
     * Auto generated setter method
     * @param param BarredInterzonalECT
     */
    public void setBarredInterzonalECT(com.huawei.www.hss._EnumType param) {
        localBarredInterzonalECTTracker = param != null;

        this.localBarredInterzonalECT = param;
    }

    public boolean isBarredDECTSpecified() {
        return localBarredDECTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBarredDECT() {
        return localBarredDECT;
    }

    /**
     * Auto generated setter method
     * @param param BarredDECT
     */
    public void setBarredDECT(com.huawei.www.hss._EnumType param) {
        localBarredDECTTracker = param != null;

        this.localBarredDECT = param;
    }

    public boolean isBarredMECTSpecified() {
        return localBarredMECTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBarredMECT() {
        return localBarredMECT;
    }

    /**
     * Auto generated setter method
     * @param param BarredMECT
     */
    public void setBarredMECT(com.huawei.www.hss._EnumType param) {
        localBarredMECTTracker = param != null;

        this.localBarredMECT = param;
    }

    public boolean isSupGPRSODBBarredAllOutgoingCallSpecified() {
        return localSupGPRSODBBarredAllOutgoingCallTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupGPRSODBBarredAllOutgoingCall() {
        return localSupGPRSODBBarredAllOutgoingCall;
    }

    /**
     * Auto generated setter method
     * @param param SupGPRSODBBarredAllOutgoingCall
     */
    public void setSupGPRSODBBarredAllOutgoingCall(
        com.huawei.www.hss._EnumType param) {
        localSupGPRSODBBarredAllOutgoingCallTracker = param != null;

        this.localSupGPRSODBBarredAllOutgoingCall = param;
    }

    public boolean isSupGPRSODBBarredOutgoingInternationalCallSpecified() {
        return localSupGPRSODBBarredOutgoingInternationalCallTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupGPRSODBBarredOutgoingInternationalCall() {
        return localSupGPRSODBBarredOutgoingInternationalCall;
    }

    /**
     * Auto generated setter method
     * @param param SupGPRSODBBarredOutgoingInternationalCall
     */
    public void setSupGPRSODBBarredOutgoingInternationalCall(
        com.huawei.www.hss._EnumType param) {
        localSupGPRSODBBarredOutgoingInternationalCallTracker = param != null;

        this.localSupGPRSODBBarredOutgoingInternationalCall = param;
    }

    public boolean isSupGPRSODBBarredOutgoingInternationalCallExHCSpecified() {
        return localSupGPRSODBBarredOutgoingInternationalCallExHCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSupGPRSODBBarredOutgoingInternationalCallExHC() {
        return localSupGPRSODBBarredOutgoingInternationalCallExHC;
    }

    /**
     * Auto generated setter method
     * @param param SupGPRSODBBarredOutgoingInternationalCallExHC
     */
    public void setSupGPRSODBBarredOutgoingInternationalCallExHC(
        com.huawei.www.hss._EnumType param) {
        localSupGPRSODBBarredOutgoingInternationalCallExHCTracker = param != null;

        this.localSupGPRSODBBarredOutgoingInternationalCallExHC = param;
    }

    public boolean isBarringofPacketOrientedServicesSpecified() {
        return localBarringofPacketOrientedServicesTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBarringofPacketOrientedServices() {
        return localBarringofPacketOrientedServices;
    }

    /**
     * Auto generated setter method
     * @param param BarringofPacketOrientedServices
     */
    public void setBarringofPacketOrientedServices(
        com.huawei.www.hss._EnumType param) {
        localBarringofPacketOrientedServicesTracker = param != null;

        this.localBarringofPacketOrientedServices = param;
    }

    public boolean isMSCSupportedLCSCapabilitySet1Specified() {
        return localMSCSupportedLCSCapabilitySet1Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMSCSupportedLCSCapabilitySet1() {
        return localMSCSupportedLCSCapabilitySet1;
    }

    /**
     * Auto generated setter method
     * @param param MSCSupportedLCSCapabilitySet1
     */
    public void setMSCSupportedLCSCapabilitySet1(
        com.huawei.www.hss._EnumType param) {
        localMSCSupportedLCSCapabilitySet1Tracker = param != null;

        this.localMSCSupportedLCSCapabilitySet1 = param;
    }

    public boolean isMSCSupportedLCSCapabilitySet2Specified() {
        return localMSCSupportedLCSCapabilitySet2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMSCSupportedLCSCapabilitySet2() {
        return localMSCSupportedLCSCapabilitySet2;
    }

    /**
     * Auto generated setter method
     * @param param MSCSupportedLCSCapabilitySet2
     */
    public void setMSCSupportedLCSCapabilitySet2(
        com.huawei.www.hss._EnumType param) {
        localMSCSupportedLCSCapabilitySet2Tracker = param != null;

        this.localMSCSupportedLCSCapabilitySet2 = param;
    }

    public boolean isSGSNSupportedLCSCapabilitySet2Specified() {
        return localSGSNSupportedLCSCapabilitySet2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSGSNSupportedLCSCapabilitySet2() {
        return localSGSNSupportedLCSCapabilitySet2;
    }

    /**
     * Auto generated setter method
     * @param param SGSNSupportedLCSCapabilitySet2
     */
    public void setSGSNSupportedLCSCapabilitySet2(
        com.huawei.www.hss._EnumType param) {
        localSGSNSupportedLCSCapabilitySet2Tracker = param != null;

        this.localSGSNSupportedLCSCapabilitySet2 = param;
    }

    public boolean isALS_DYNSpecified() {
        return localALS_DYNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getALS_DYN() {
        return localALS_DYN;
    }

    /**
     * Auto generated setter method
     * @param param ALS_DYN
     */
    public void setALS_DYN(com.huawei.www.hss._EnumType param) {
        localALS_DYNTracker = param != null;

        this.localALS_DYN = param;
    }

    public boolean isVVDN_DYNSpecified() {
        return localVVDN_DYNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVVDN_DYN() {
        return localVVDN_DYN;
    }

    /**
     * Auto generated setter method
     * @param param VVDN_DYN
     */
    public void setVVDN_DYN(com.huawei.www.hss._EnumType param) {
        localVVDN_DYNTracker = param != null;

        this.localVVDN_DYN = param;
    }

    public boolean isDIMSISpecified() {
        return localDIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_8
     */
    public com.huawei.www.hss.Str1_8 getDIMSI() {
        return localDIMSI;
    }

    /**
     * Auto generated setter method
     * @param param DIMSI
     */
    public void setDIMSI(com.huawei.www.hss.Str1_8 param) {
        localDIMSITracker = param != null;

        this.localDIMSI = param;
    }

    public boolean isACTIMSISpecified() {
        return localACTIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getACTIMSI() {
        return localACTIMSI;
    }

    /**
     * Auto generated setter method
     * @param param ACTIMSI
     */
    public void setACTIMSI(com.huawei.www.hss._EnumType param) {
        localACTIMSITracker = param != null;

        this.localACTIMSI = param;
    }

    public boolean isGgsnNumberSpecified() {
        return localGgsnNumberTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_127
     */
    public com.huawei.www.hss.Str0_127 getGgsnNumber() {
        return localGgsnNumber;
    }

    /**
     * Auto generated setter method
     * @param param GgsnNumber
     */
    public void setGgsnNumber(com.huawei.www.hss.Str0_127 param) {
        localGgsnNumberTracker = param != null;

        this.localGgsnNumber = param;
    }

    public boolean isGgsnAddressTypeSpecified() {
        return localGgsnAddressTypeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getGgsnAddressType() {
        return localGgsnAddressType;
    }

    /**
     * Auto generated setter method
     * @param param GgsnAddressType
     */
    public void setGgsnAddressType(com.huawei.www.hss._EnumType param) {
        localGgsnAddressTypeTracker = param != null;

        this.localGgsnAddressType = param;
    }

    public boolean isGgsnAddressSpecified() {
        return localGgsnAddressTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_127
     */
    public com.huawei.www.hss.Str0_127 getGgsnAddress() {
        return localGgsnAddress;
    }

    /**
     * Auto generated setter method
     * @param param GgsnAddress
     */
    public void setGgsnAddress(com.huawei.www.hss.Str0_127 param) {
        localGgsnAddressTracker = param != null;

        this.localGgsnAddress = param;
    }

    public boolean isLongGroupIDSupportedSpecified() {
        return localLongGroupIDSupportedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getLongGroupIDSupported() {
        return localLongGroupIDSupported;
    }

    /**
     * Auto generated setter method
     * @param param LongGroupIDSupported
     */
    public void setLongGroupIDSupported(com.huawei.www.hss._EnumType param) {
        localLongGroupIDSupportedTracker = param != null;

        this.localLongGroupIDSupported = param;
    }

    public boolean isBasicISTSupportedSpecified() {
        return localBasicISTSupportedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getBasicISTSupported() {
        return localBasicISTSupported;
    }

    /**
     * Auto generated setter method
     * @param param BasicISTSupported
     */
    public void setBasicISTSupported(com.huawei.www.hss._EnumType param) {
        localBasicISTSupportedTracker = param != null;

        this.localBasicISTSupported = param;
    }

    public boolean isIstCommandSupportedSpecified() {
        return localIstCommandSupportedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getIstCommandSupported() {
        return localIstCommandSupported;
    }

    /**
     * Auto generated setter method
     * @param param IstCommandSupported
     */
    public void setIstCommandSupported(com.huawei.www.hss._EnumType param) {
        localIstCommandSupportedTracker = param != null;

        this.localIstCommandSupported = param;
    }

    public boolean isSuperChargerSupportedForGsmSpecified() {
        return localSuperChargerSupportedForGsmTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSuperChargerSupportedForGsm() {
        return localSuperChargerSupportedForGsm;
    }

    /**
     * Auto generated setter method
     * @param param SuperChargerSupportedForGsm
     */
    public void setSuperChargerSupportedForGsm(
        com.huawei.www.hss._EnumType param) {
        localSuperChargerSupportedForGsmTracker = param != null;

        this.localSuperChargerSupportedForGsm = param;
    }

    public boolean isIMEISpecified() {
        return localIMEITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_127
     */
    public com.huawei.www.hss.Str0_127 getIMEI() {
        return localIMEI;
    }

    /**
     * Auto generated setter method
     * @param param IMEI
     */
    public void setIMEI(com.huawei.www.hss.Str0_127 param) {
        localIMEITracker = param != null;

        this.localIMEI = param;
    }

    public boolean isCSUPLTIMESpecified() {
        return localCSUPLTIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_30
     */
    public com.huawei.www.hss.Str1_30 getCSUPLTIME() {
        return localCSUPLTIME;
    }

    /**
     * Auto generated setter method
     * @param param CSUPLTIME
     */
    public void setCSUPLTIME(com.huawei.www.hss.Str1_30 param) {
        localCSUPLTIMETracker = param != null;

        this.localCSUPLTIME = param;
    }

    public boolean isCSPURGETIMESpecified() {
        return localCSPURGETIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_30
     */
    public com.huawei.www.hss.Str1_30 getCSPURGETIME() {
        return localCSPURGETIME;
    }

    /**
     * Auto generated setter method
     * @param param CSPURGETIME
     */
    public void setCSPURGETIME(com.huawei.www.hss.Str1_30 param) {
        localCSPURGETIMETracker = param != null;

        this.localCSPURGETIME = param;
    }

    public boolean isPSUPLTIMESpecified() {
        return localPSUPLTIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_30
     */
    public com.huawei.www.hss.Str1_30 getPSUPLTIME() {
        return localPSUPLTIME;
    }

    /**
     * Auto generated setter method
     * @param param PSUPLTIME
     */
    public void setPSUPLTIME(com.huawei.www.hss.Str1_30 param) {
        localPSUPLTIMETracker = param != null;

        this.localPSUPLTIME = param;
    }

    public boolean isPSPURGETIMESpecified() {
        return localPSPURGETIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_30
     */
    public com.huawei.www.hss.Str1_30 getPSPURGETIME() {
        return localPSPURGETIME;
    }

    /**
     * Auto generated setter method
     * @param param PSPURGETIME
     */
    public void setPSPURGETIME(com.huawei.www.hss.Str1_30 param) {
        localPSPURGETIMETracker = param != null;

        this.localPSPURGETIME = param;
    }

    public boolean isMAINIMSISpecified() {
        return localMAINIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str3_8
     */
    public com.huawei.www.hss.Str3_8 getMAINIMSI() {
        return localMAINIMSI;
    }

    /**
     * Auto generated setter method
     * @param param MAINIMSI
     */
    public void setMAINIMSI(com.huawei.www.hss.Str3_8 param) {
        localMAINIMSITracker = param != null;

        this.localMAINIMSI = param;
    }

    public boolean isMIMSI_SMSSpecified() {
        return localMIMSI_SMSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_9
     */
    public com.huawei.www.hss.Int1_9 getMIMSI_SMS() {
        return localMIMSI_SMS;
    }

    /**
     * Auto generated setter method
     * @param param MIMSI_SMS
     */
    public void setMIMSI_SMS(com.huawei.www.hss.Int1_9 param) {
        localMIMSI_SMSTracker = param != null;

        this.localMIMSI_SMS = param;
    }

    public boolean isMIMSI_VOBBSpecified() {
        return localMIMSI_VOBBTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_9
     */
    public com.huawei.www.hss.Int1_9 getMIMSI_VOBB() {
        return localMIMSI_VOBB;
    }

    /**
     * Auto generated setter method
     * @param param MIMSI_VOBB
     */
    public void setMIMSI_VOBB(com.huawei.www.hss.Int1_9 param) {
        localMIMSI_VOBBTracker = param != null;

        this.localMIMSI_VOBB = param;
    }

    public boolean isMIMSITYPESpecified() {
        return localMIMSITYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMIMSITYPE() {
        return localMIMSITYPE;
    }

    /**
     * Auto generated setter method
     * @param param MIMSITYPE
     */
    public void setMIMSITYPE(com.huawei.www.hss._EnumType param) {
        localMIMSITYPETracker = param != null;

        this.localMIMSITYPE = param;
    }

    public boolean isLSFLAGSpecified() {
        return localLSFLAGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getLSFLAG() {
        return localLSFLAG;
    }

    /**
     * Auto generated setter method
     * @param param LSFLAG
     */
    public void setLSFLAG(com.huawei.www.hss._EnumType param) {
        localLSFLAGTracker = param != null;

        this.localLSFLAG = param;
    }

    public boolean isCamelInduceBarringSMSSpecified() {
        return localCamelInduceBarringSMSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCamelInduceBarringSMS() {
        return localCamelInduceBarringSMS;
    }

    /**
     * Auto generated setter method
     * @param param CamelInduceBarringSMS
     */
    public void setCamelInduceBarringSMS(com.huawei.www.hss._EnumType param) {
        localCamelInduceBarringSMSTracker = param != null;

        this.localCamelInduceBarringSMS = param;
    }

    public boolean isRoamBaocTs11Specified() {
        return localRoamBaocTs11Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRoamBaocTs11() {
        return localRoamBaocTs11;
    }

    /**
     * Auto generated setter method
     * @param param RoamBaocTs11
     */
    public void setRoamBaocTs11(com.huawei.www.hss._EnumType param) {
        localRoamBaocTs11Tracker = param != null;

        this.localRoamBaocTs11 = param;
    }

    public boolean isMTRF_SUPPORTEDSpecified() {
        return localMTRF_SUPPORTEDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMTRF_SUPPORTED() {
        return localMTRF_SUPPORTED;
    }

    /**
     * Auto generated setter method
     * @param param MTRF_SUPPORTED
     */
    public void setMTRF_SUPPORTED(com.huawei.www.hss._EnumType param) {
        localMTRF_SUPPORTEDTracker = param != null;

        this.localMTRF_SUPPORTED = param;
    }

    public boolean isURRP_MMESpecified() {
        return localURRP_MMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getURRP_MME() {
        return localURRP_MME;
    }

    /**
     * Auto generated setter method
     * @param param URRP_MME
     */
    public void setURRP_MME(com.huawei.www.hss._EnumType param) {
        localURRP_MMETracker = param != null;

        this.localURRP_MME = param;
    }

    public boolean isURRP_SGSNSpecified() {
        return localURRP_SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getURRP_SGSN() {
        return localURRP_SGSN;
    }

    /**
     * Auto generated setter method
     * @param param URRP_SGSN
     */
    public void setURRP_SGSN(com.huawei.www.hss._EnumType param) {
        localURRP_SGSNTracker = param != null;

        this.localURRP_SGSN = param;
    }

    public boolean isTAISpecified() {
        return localTAITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str9_10
     */
    public com.huawei.www.hss.Str9_10 getTAI() {
        return localTAI;
    }

    /**
     * Auto generated setter method
     * @param param TAI
     */
    public void setTAI(com.huawei.www.hss.Str9_10 param) {
        localTAITracker = param != null;

        this.localTAI = param;
    }

    public boolean isVLR_NUM_SAISpecified() {
        return localVLR_NUM_SAITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_8
     */
    public com.huawei.www.hss.Str0_8 getVLR_NUM_SAI() {
        return localVLR_NUM_SAI;
    }

    /**
     * Auto generated setter method
     * @param param VLR_NUM_SAI
     */
    public void setVLR_NUM_SAI(com.huawei.www.hss.Str0_8 param) {
        localVLR_NUM_SAITracker = param != null;

        this.localVLR_NUM_SAI = param;
    }

    public boolean isTIME_STAMP_SAISpecified() {
        return localTIME_STAMP_SAITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_30
     */
    public com.huawei.www.hss.Str1_30 getTIME_STAMP_SAI() {
        return localTIME_STAMP_SAI;
    }

    /**
     * Auto generated setter method
     * @param param TIME_STAMP_SAI
     */
    public void setTIME_STAMP_SAI(com.huawei.www.hss.Str1_30 param) {
        localTIME_STAMP_SAITracker = param != null;

        this.localTIME_STAMP_SAI = param;
    }

    public boolean isMMEHOSTSpecified() {
        return localMMEHOSTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getMMEHOST() {
        return localMMEHOST;
    }

    /**
     * Auto generated setter method
     * @param param MMEHOST
     */
    public void setMMEHOST(com.huawei.www.hss.Str1_128 param) {
        localMMEHOSTTracker = param != null;

        this.localMMEHOST = param;
    }

    public boolean isMMEREALMSpecified() {
        return localMMEREALMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getMMEREALM() {
        return localMMEREALM;
    }

    /**
     * Auto generated setter method
     * @param param MMEREALM
     */
    public void setMMEREALM(com.huawei.www.hss.Str1_128 param) {
        localMMEREALMTracker = param != null;

        this.localMMEREALM = param;
    }

    public boolean isMRATTYPESpecified() {
        return localMRATTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMRATTYPE() {
        return localMRATTYPE;
    }

    /**
     * Auto generated setter method
     * @param param MRATTYPE
     */
    public void setMRATTYPE(com.huawei.www.hss._EnumType param) {
        localMRATTYPETracker = param != null;

        this.localMRATTYPE = param;
    }

    public boolean isMVPLMNSpecified() {
        return localMVPLMNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_9
     */
    public com.huawei.www.hss.Str1_9 getMVPLMN() {
        return localMVPLMN;
    }

    /**
     * Auto generated setter method
     * @param param MVPLMN
     */
    public void setMVPLMN(com.huawei.www.hss.Str1_9 param) {
        localMVPLMNTracker = param != null;

        this.localMVPLMN = param;
    }

    public boolean isPURGEDONMMESpecified() {
        return localPURGEDONMMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPURGEDONMME() {
        return localPURGEDONMME;
    }

    /**
     * Auto generated setter method
     * @param param PURGEDONMME
     */
    public void setPURGEDONMME(com.huawei.www.hss._EnumType param) {
        localPURGEDONMMETracker = param != null;

        this.localPURGEDONMME = param;
    }

    public boolean isMMEUpdateLocationTimeSpecified() {
        return localMMEUpdateLocationTimeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_35
     */
    public com.huawei.www.hss.Str1_35 getMMEUpdateLocationTime() {
        return localMMEUpdateLocationTime;
    }

    /**
     * Auto generated setter method
     * @param param MMEUpdateLocationTime
     */
    public void setMMEUpdateLocationTime(com.huawei.www.hss.Str1_35 param) {
        localMMEUpdateLocationTimeTracker = param != null;

        this.localMMEUpdateLocationTime = param;
    }

    public boolean isMMEFeatureListSpecified() {
        return localMMEFeatureListTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_9
     */
    public com.huawei.www.hss.Str1_9 getMMEFeatureList() {
        return localMMEFeatureList;
    }

    /**
     * Auto generated setter method
     * @param param MMEFeatureList
     */
    public void setMMEFeatureList(com.huawei.www.hss.Str1_9 param) {
        localMMEFeatureListTracker = param != null;

        this.localMMEFeatureList = param;
    }

    public boolean isMLastIDRorDSRSUCCSpecified() {
        return localMLastIDRorDSRSUCCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMLastIDRorDSRSUCC() {
        return localMLastIDRorDSRSUCC;
    }

    /**
     * Auto generated setter method
     * @param param MLastIDRorDSRSUCC
     */
    public void setMLastIDRorDSRSUCC(com.huawei.www.hss._EnumType param) {
        localMLastIDRorDSRSUCCTracker = param != null;

        this.localMLastIDRorDSRSUCC = param;
    }

    public boolean isMSingleRegistrationIndicationSpecified() {
        return localMSingleRegistrationIndicationTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMSingleRegistrationIndication() {
        return localMSingleRegistrationIndication;
    }

    /**
     * Auto generated setter method
     * @param param MSingleRegistrationIndication
     */
    public void setMSingleRegistrationIndication(
        com.huawei.www.hss._EnumType param) {
        localMSingleRegistrationIndicationTracker = param != null;

        this.localMSingleRegistrationIndication = param;
    }

    public boolean isMSkipSubscriberDataIndicatorSpecified() {
        return localMSkipSubscriberDataIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMSkipSubscriberDataIndicator() {
        return localMSkipSubscriberDataIndicator;
    }

    /**
     * Auto generated setter method
     * @param param MSkipSubscriberDataIndicator
     */
    public void setMSkipSubscriberDataIndicator(
        com.huawei.www.hss._EnumType param) {
        localMSkipSubscriberDataIndicatorTracker = param != null;

        this.localMSkipSubscriberDataIndicator = param;
    }

    public boolean isMGPRSSubscriptionDataIndicatorSpecified() {
        return localMGPRSSubscriptionDataIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMGPRSSubscriptionDataIndicator() {
        return localMGPRSSubscriptionDataIndicator;
    }

    /**
     * Auto generated setter method
     * @param param MGPRSSubscriptionDataIndicator
     */
    public void setMGPRSSubscriptionDataIndicator(
        com.huawei.www.hss._EnumType param) {
        localMGPRSSubscriptionDataIndicatorTracker = param != null;

        this.localMGPRSSubscriptionDataIndicator = param;
    }

    public boolean isMNodeTypeIndicatorSpecified() {
        return localMNodeTypeIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMNodeTypeIndicator() {
        return localMNodeTypeIndicator;
    }

    /**
     * Auto generated setter method
     * @param param MNodeTypeIndicator
     */
    public void setMNodeTypeIndicator(com.huawei.www.hss._EnumType param) {
        localMNodeTypeIndicatorTracker = param != null;

        this.localMNodeTypeIndicator = param;
    }

    public boolean isMInitialAttachIndicatorSpecified() {
        return localMInitialAttachIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMInitialAttachIndicator() {
        return localMInitialAttachIndicator;
    }

    /**
     * Auto generated setter method
     * @param param MInitialAttachIndicator
     */
    public void setMInitialAttachIndicator(com.huawei.www.hss._EnumType param) {
        localMInitialAttachIndicatorTracker = param != null;

        this.localMInitialAttachIndicator = param;
    }

    public boolean isMPSLCSNotSupportedByUESpecified() {
        return localMPSLCSNotSupportedByUETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMPSLCSNotSupportedByUE() {
        return localMPSLCSNotSupportedByUE;
    }

    /**
     * Auto generated setter method
     * @param param MPSLCSNotSupportedByUE
     */
    public void setMPSLCSNotSupportedByUE(com.huawei.www.hss._EnumType param) {
        localMPSLCSNotSupportedByUETracker = param != null;

        this.localMPSLCSNotSupportedByUE = param;
    }

    public boolean isMIMEISpecified() {
        return localMIMEITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getMIMEI() {
        return localMIMEI;
    }

    /**
     * Auto generated setter method
     * @param param MIMEI
     */
    public void setMIMEI(com.huawei.www.hss.Str1_16 param) {
        localMIMEITracker = param != null;

        this.localMIMEI = param;
    }

    public boolean isMIMEISVSpecified() {
        return localMIMEISVTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_2
     */
    public com.huawei.www.hss.Str1_2 getMIMEISV() {
        return localMIMEISV;
    }

    /**
     * Auto generated setter method
     * @param param MIMEISV
     */
    public void setMIMEISV(com.huawei.www.hss.Str1_2 param) {
        localMIMEISVTracker = param != null;

        this.localMIMEISV = param;
    }

    public boolean isSGSNHOSTSpecified() {
        return localSGSNHOSTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getSGSNHOST() {
        return localSGSNHOST;
    }

    /**
     * Auto generated setter method
     * @param param SGSNHOST
     */
    public void setSGSNHOST(com.huawei.www.hss.Str1_128 param) {
        localSGSNHOSTTracker = param != null;

        this.localSGSNHOST = param;
    }

    public boolean isSGSNREALMSpecified() {
        return localSGSNREALMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getSGSNREALM() {
        return localSGSNREALM;
    }

    /**
     * Auto generated setter method
     * @param param SGSNREALM
     */
    public void setSGSNREALM(com.huawei.www.hss.Str1_128 param) {
        localSGSNREALMTracker = param != null;

        this.localSGSNREALM = param;
    }

    public boolean isSGSNNUMBERSpecified() {
        return localSGSNNUMBERTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getSGSNNUMBER() {
        return localSGSNNUMBER;
    }

    /**
     * Auto generated setter method
     * @param param SGSNNUMBER
     */
    public void setSGSNNUMBER(com.huawei.www.hss.Str1_128 param) {
        localSGSNNUMBERTracker = param != null;

        this.localSGSNNUMBER = param;
    }

    public boolean isSRATTYPESpecified() {
        return localSRATTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSRATTYPE() {
        return localSRATTYPE;
    }

    /**
     * Auto generated setter method
     * @param param SRATTYPE
     */
    public void setSRATTYPE(com.huawei.www.hss._EnumType param) {
        localSRATTYPETracker = param != null;

        this.localSRATTYPE = param;
    }

    public boolean isSVPLMNSpecified() {
        return localSVPLMNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_9
     */
    public com.huawei.www.hss.Str1_9 getSVPLMN() {
        return localSVPLMN;
    }

    /**
     * Auto generated setter method
     * @param param SVPLMN
     */
    public void setSVPLMN(com.huawei.www.hss.Str1_9 param) {
        localSVPLMNTracker = param != null;

        this.localSVPLMN = param;
    }

    public boolean isPURGEDONSGSNSpecified() {
        return localPURGEDONSGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPURGEDONSGSN() {
        return localPURGEDONSGSN;
    }

    /**
     * Auto generated setter method
     * @param param PURGEDONSGSN
     */
    public void setPURGEDONSGSN(com.huawei.www.hss._EnumType param) {
        localPURGEDONSGSNTracker = param != null;

        this.localPURGEDONSGSN = param;
    }

    public boolean isSAREARESTRICTSpecified() {
        return localSAREARESTRICTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSAREARESTRICT() {
        return localSAREARESTRICT;
    }

    /**
     * Auto generated setter method
     * @param param SAREARESTRICT
     */
    public void setSAREARESTRICT(com.huawei.www.hss._EnumType param) {
        localSAREARESTRICTTracker = param != null;

        this.localSAREARESTRICT = param;
    }

    public boolean isS4SGSNUpdateLocationTimeSpecified() {
        return localS4SGSNUpdateLocationTimeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_35
     */
    public com.huawei.www.hss.Str1_35 getS4SGSNUpdateLocationTime() {
        return localS4SGSNUpdateLocationTime;
    }

    /**
     * Auto generated setter method
     * @param param S4SGSNUpdateLocationTime
     */
    public void setS4SGSNUpdateLocationTime(com.huawei.www.hss.Str1_35 param) {
        localS4SGSNUpdateLocationTimeTracker = param != null;

        this.localS4SGSNUpdateLocationTime = param;
    }

    public boolean isS4SGSNFeatureListSpecified() {
        return localS4SGSNFeatureListTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_9
     */
    public com.huawei.www.hss.Str1_9 getS4SGSNFeatureList() {
        return localS4SGSNFeatureList;
    }

    /**
     * Auto generated setter method
     * @param param S4SGSNFeatureList
     */
    public void setS4SGSNFeatureList(com.huawei.www.hss.Str1_9 param) {
        localS4SGSNFeatureListTracker = param != null;

        this.localS4SGSNFeatureList = param;
    }

    public boolean isSLastIDRorDSRSUCCSpecified() {
        return localSLastIDRorDSRSUCCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSLastIDRorDSRSUCC() {
        return localSLastIDRorDSRSUCC;
    }

    /**
     * Auto generated setter method
     * @param param SLastIDRorDSRSUCC
     */
    public void setSLastIDRorDSRSUCC(com.huawei.www.hss._EnumType param) {
        localSLastIDRorDSRSUCCTracker = param != null;

        this.localSLastIDRorDSRSUCC = param;
    }

    public boolean isSSingleRegistrationIndicationSpecified() {
        return localSSingleRegistrationIndicationTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSSingleRegistrationIndication() {
        return localSSingleRegistrationIndication;
    }

    /**
     * Auto generated setter method
     * @param param SSingleRegistrationIndication
     */
    public void setSSingleRegistrationIndication(
        com.huawei.www.hss._EnumType param) {
        localSSingleRegistrationIndicationTracker = param != null;

        this.localSSingleRegistrationIndication = param;
    }

    public boolean isSSkipSubscriberDataIndicatorSpecified() {
        return localSSkipSubscriberDataIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSSkipSubscriberDataIndicator() {
        return localSSkipSubscriberDataIndicator;
    }

    /**
     * Auto generated setter method
     * @param param SSkipSubscriberDataIndicator
     */
    public void setSSkipSubscriberDataIndicator(
        com.huawei.www.hss._EnumType param) {
        localSSkipSubscriberDataIndicatorTracker = param != null;

        this.localSSkipSubscriberDataIndicator = param;
    }

    public boolean isSGPRSSubscriptionDataIndicatorSpecified() {
        return localSGPRSSubscriptionDataIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSGPRSSubscriptionDataIndicator() {
        return localSGPRSSubscriptionDataIndicator;
    }

    /**
     * Auto generated setter method
     * @param param SGPRSSubscriptionDataIndicator
     */
    public void setSGPRSSubscriptionDataIndicator(
        com.huawei.www.hss._EnumType param) {
        localSGPRSSubscriptionDataIndicatorTracker = param != null;

        this.localSGPRSSubscriptionDataIndicator = param;
    }

    public boolean isSNodeTypeIndicatorSpecified() {
        return localSNodeTypeIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSNodeTypeIndicator() {
        return localSNodeTypeIndicator;
    }

    /**
     * Auto generated setter method
     * @param param SNodeTypeIndicator
     */
    public void setSNodeTypeIndicator(com.huawei.www.hss._EnumType param) {
        localSNodeTypeIndicatorTracker = param != null;

        this.localSNodeTypeIndicator = param;
    }

    public boolean isSInitialAttachIndicatorSpecified() {
        return localSInitialAttachIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSInitialAttachIndicator() {
        return localSInitialAttachIndicator;
    }

    /**
     * Auto generated setter method
     * @param param SInitialAttachIndicator
     */
    public void setSInitialAttachIndicator(com.huawei.www.hss._EnumType param) {
        localSInitialAttachIndicatorTracker = param != null;

        this.localSInitialAttachIndicator = param;
    }

    public boolean isSPSLCSNotSupportedByUESpecified() {
        return localSPSLCSNotSupportedByUETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSPSLCSNotSupportedByUE() {
        return localSPSLCSNotSupportedByUE;
    }

    /**
     * Auto generated setter method
     * @param param SPSLCSNotSupportedByUE
     */
    public void setSPSLCSNotSupportedByUE(com.huawei.www.hss._EnumType param) {
        localSPSLCSNotSupportedByUETracker = param != null;

        this.localSPSLCSNotSupportedByUE = param;
    }

    public boolean isSIMEISpecified() {
        return localSIMEITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getSIMEI() {
        return localSIMEI;
    }

    /**
     * Auto generated setter method
     * @param param SIMEI
     */
    public void setSIMEI(com.huawei.www.hss.Str1_16 param) {
        localSIMEITracker = param != null;

        this.localSIMEI = param;
    }

    public boolean isSIMEISVSpecified() {
        return localSIMEISVTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getSIMEISV() {
        return localSIMEISV;
    }

    /**
     * Auto generated setter method
     * @param param SIMEISV
     */
    public void setSIMEISV(com.huawei.www.hss.Str1_16 param) {
        localSIMEISVTracker = param != null;

        this.localSIMEISV = param;
    }

    public boolean isEPSDYNCNTXIDSpecified() {
        return localEPSDYNCNTXIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_50
     */
    public com.huawei.www.hss.Int1_50 getEPSDYNCNTXID() {
        return localEPSDYNCNTXID;
    }

    /**
     * Auto generated setter method
     * @param param EPSDYNCNTXID
     */
    public void setEPSDYNCNTXID(com.huawei.www.hss.Int1_50 param) {
        localEPSDYNCNTXIDTracker = param != null;

        this.localEPSDYNCNTXID = param;
    }

    public boolean isEPSDYNAPNSpecified() {
        return localEPSDYNAPNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_63
     */
    public com.huawei.www.hss.Str1_63 getEPSDYNAPN() {
        return localEPSDYNAPN;
    }

    /**
     * Auto generated setter method
     * @param param EPSDYNAPN
     */
    public void setEPSDYNAPN(com.huawei.www.hss.Str1_63 param) {
        localEPSDYNAPNTracker = param != null;

        this.localEPSDYNAPN = param;
    }

    public boolean isEPSDYNPDNGWHOSTSpecified() {
        return localEPSDYNPDNGWHOSTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getEPSDYNPDNGWHOST() {
        return localEPSDYNPDNGWHOST;
    }

    /**
     * Auto generated setter method
     * @param param EPSDYNPDNGWHOST
     */
    public void setEPSDYNPDNGWHOST(com.huawei.www.hss.Str1_128 param) {
        localEPSDYNPDNGWHOSTTracker = param != null;

        this.localEPSDYNPDNGWHOST = param;
    }

    public boolean isEPSDYNPDNGWREALMSpecified() {
        return localEPSDYNPDNGWREALMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getEPSDYNPDNGWREALM() {
        return localEPSDYNPDNGWREALM;
    }

    /**
     * Auto generated setter method
     * @param param EPSDYNPDNGWREALM
     */
    public void setEPSDYNPDNGWREALM(com.huawei.www.hss.Str1_128 param) {
        localEPSDYNPDNGWREALMTracker = param != null;

        this.localEPSDYNPDNGWREALM = param;
    }

    public boolean isEPSDYNPDNGWIPV4Specified() {
        return localEPSDYNPDNGWIPV4Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str7_15
     */
    public com.huawei.www.hss.Str7_15 getEPSDYNPDNGWIPV4() {
        return localEPSDYNPDNGWIPV4;
    }

    /**
     * Auto generated setter method
     * @param param EPSDYNPDNGWIPV4
     */
    public void setEPSDYNPDNGWIPV4(com.huawei.www.hss.Str7_15 param) {
        localEPSDYNPDNGWIPV4Tracker = param != null;

        this.localEPSDYNPDNGWIPV4 = param;
    }

    public boolean isEPSDYNPDNGWIPV6Specified() {
        return localEPSDYNPDNGWIPV6Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_40
     */
    public com.huawei.www.hss.Str1_40 getEPSDYNPDNGWIPV6() {
        return localEPSDYNPDNGWIPV6;
    }

    /**
     * Auto generated setter method
     * @param param EPSDYNPDNGWIPV6
     */
    public void setEPSDYNPDNGWIPV6(com.huawei.www.hss.Str1_40 param) {
        localEPSDYNPDNGWIPV6Tracker = param != null;

        this.localEPSDYNPDNGWIPV6 = param;
    }

    public boolean isEPSDYNWILDCARDFLAGSpecified() {
        return localEPSDYNWILDCARDFLAGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEPSDYNWILDCARDFLAG() {
        return localEPSDYNWILDCARDFLAG;
    }

    /**
     * Auto generated setter method
     * @param param EPSDYNWILDCARDFLAG
     */
    public void setEPSDYNWILDCARDFLAG(com.huawei.www.hss._EnumType param) {
        localEPSDYNWILDCARDFLAGTracker = param != null;

        this.localEPSDYNWILDCARDFLAG = param;
    }

    public boolean isEPSDYNVNISpecified() {
        return localEPSDYNVNITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_63
     */
    public com.huawei.www.hss.Str1_63 getEPSDYNVNI() {
        return localEPSDYNVNI;
    }

    /**
     * Auto generated setter method
     * @param param EPSDYNVNI
     */
    public void setEPSDYNVNI(com.huawei.www.hss.Str1_63 param) {
        localEPSDYNVNITracker = param != null;

        this.localEPSDYNVNI = param;
    }

    public boolean isVNISpecified() {
        return localVNITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getVNI() {
        return localVNI;
    }

    /**
     * Auto generated setter method
     * @param param VNI
     */
    public void setVNI(com.huawei.www.hss.Str1_128 param) {
        localVNITracker = param != null;

        this.localVNI = param;
    }

    public boolean isREGSTATUSSpecified() {
        return localREGSTATUSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getREGSTATUS() {
        return localREGSTATUS;
    }

    /**
     * Auto generated setter method
     * @param param REGSTATUS
     */
    public void setREGSTATUS(com.huawei.www.hss._EnumType param) {
        localREGSTATUSTracker = param != null;

        this.localREGSTATUS = param;
    }

    public boolean isACCESSNETIDSpecified() {
        return localACCESSNETIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getACCESSNETID() {
        return localACCESSNETID;
    }

    /**
     * Auto generated setter method
     * @param param ACCESSNETID
     */
    public void setACCESSNETID(com.huawei.www.hss.Str1_16 param) {
        localACCESSNETIDTracker = param != null;

        this.localACCESSNETID = param;
    }

    public boolean isTGPPAAASERVERNAMESpecified() {
        return localTGPPAAASERVERNAMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getTGPPAAASERVERNAME() {
        return localTGPPAAASERVERNAME;
    }

    /**
     * Auto generated setter method
     * @param param TGPPAAASERVERNAME
     */
    public void setTGPPAAASERVERNAME(com.huawei.www.hss.Str1_128 param) {
        localTGPPAAASERVERNAMETracker = param != null;

        this.localTGPPAAASERVERNAME = param;
    }

    public boolean isTGPPAAASERVERREALMSpecified() {
        return localTGPPAAASERVERREALMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getTGPPAAASERVERREALM() {
        return localTGPPAAASERVERREALM;
    }

    /**
     * Auto generated setter method
     * @param param TGPPAAASERVERREALM
     */
    public void setTGPPAAASERVERREALM(com.huawei.www.hss.Str1_128 param) {
        localTGPPAAASERVERREALMTracker = param != null;

        this.localTGPPAAASERVERREALM = param;
    }

    public boolean isTGPP2MEIDSpecified() {
        return localTGPP2MEIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getTGPP2MEID() {
        return localTGPP2MEID;
    }

    /**
     * Auto generated setter method
     * @param param TGPP2MEID
     */
    public void setTGPP2MEID(com.huawei.www.hss.Str1_16 param) {
        localTGPP2MEIDTracker = param != null;

        this.localTGPP2MEID = param;
    }

    public boolean isAAAIMEISpecified() {
        return localAAAIMEITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getAAAIMEI() {
        return localAAAIMEI;
    }

    /**
     * Auto generated setter method
     * @param param AAAIMEI
     */
    public void setAAAIMEI(com.huawei.www.hss.Str1_16 param) {
        localAAAIMEITracker = param != null;

        this.localAAAIMEI = param;
    }

    public boolean isAAAIMEISVSpecified() {
        return localAAAIMEISVTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_2
     */
    public com.huawei.www.hss.Str1_2 getAAAIMEISV() {
        return localAAAIMEISV;
    }

    /**
     * Auto generated setter method
     * @param param AAAIMEISV
     */
    public void setAAAIMEISV(com.huawei.www.hss.Str1_2 param) {
        localAAAIMEISVTracker = param != null;

        this.localAAAIMEISV = param;
    }

    public boolean isServerAssignmentTimeSpecified() {
        return localServerAssignmentTimeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_35
     */
    public com.huawei.www.hss.Str1_35 getServerAssignmentTime() {
        return localServerAssignmentTime;
    }

    /**
     * Auto generated setter method
     * @param param ServerAssignmentTime
     */
    public void setServerAssignmentTime(com.huawei.www.hss.Str1_35 param) {
        localServerAssignmentTimeTracker = param != null;

        this.localServerAssignmentTime = param;
    }

    public boolean isIMSVOPSSessionsSupportedSpecified() {
        return localIMSVOPSSessionsSupportedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getIMSVOPSSessionsSupported() {
        return localIMSVOPSSessionsSupported;
    }

    /**
     * Auto generated setter method
     * @param param IMSVOPSSessionsSupported
     */
    public void setIMSVOPSSessionsSupported(com.huawei.www.hss._EnumType param) {
        localIMSVOPSSessionsSupportedTracker = param != null;

        this.localIMSVOPSSessionsSupported = param;
    }

    public boolean isUESRVCCCapabilitySpecified() {
        return localUESRVCCCapabilityTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUESRVCCCapability() {
        return localUESRVCCCapability;
    }

    /**
     * Auto generated setter method
     * @param param UESRVCCCapability
     */
    public void setUESRVCCCapability(com.huawei.www.hss._EnumType param) {
        localUESRVCCCapabilityTracker = param != null;

        this.localUESRVCCCapability = param;
    }

    public boolean isIMSVOPSSessionsSupportedS4SGSNSpecified() {
        return localIMSVOPSSessionsSupportedS4SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getIMSVOPSSessionsSupportedS4SGSN() {
        return localIMSVOPSSessionsSupportedS4SGSN;
    }

    /**
     * Auto generated setter method
     * @param param IMSVOPSSessionsSupportedS4SGSN
     */
    public void setIMSVOPSSessionsSupportedS4SGSN(
        com.huawei.www.hss._EnumType param) {
        localIMSVOPSSessionsSupportedS4SGSNTracker = param != null;

        this.localIMSVOPSSessionsSupportedS4SGSN = param;
    }

    public boolean isUESRVCCCapabilityS4SGSNSpecified() {
        return localUESRVCCCapabilityS4SGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUESRVCCCapabilityS4SGSN() {
        return localUESRVCCCapabilityS4SGSN;
    }

    /**
     * Auto generated setter method
     * @param param UESRVCCCapabilityS4SGSN
     */
    public void setUESRVCCCapabilityS4SGSN(com.huawei.www.hss._EnumType param) {
        localUESRVCCCapabilityS4SGSNTracker = param != null;

        this.localUESRVCCCapabilityS4SGSN = param;
    }

    public boolean isUERegisterAtIMSSpecified() {
        return localUERegisterAtIMSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUERegisterAtIMS() {
        return localUERegisterAtIMS;
    }

    /**
     * Auto generated setter method
     * @param param UERegisterAtIMS
     */
    public void setUERegisterAtIMS(com.huawei.www.hss._EnumType param) {
        localUERegisterAtIMSTracker = param != null;

        this.localUERegisterAtIMS = param;
    }

    public boolean isIP_SM_GWSpecified() {
        return localIP_SM_GWTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getIP_SM_GW() {
        return localIP_SM_GW;
    }

    /**
     * Auto generated setter method
     * @param param IP_SM_GW
     */
    public void setIP_SM_GW(com.huawei.www.hss.Str1_15 param) {
        localIP_SM_GWTracker = param != null;

        this.localIP_SM_GW = param;
    }

    public boolean isMCEFforIPSpecified() {
        return localMCEFforIPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMCEFforIP() {
        return localMCEFforIP;
    }

    /**
     * Auto generated setter method
     * @param param MCEFforIP
     */
    public void setMCEFforIP(com.huawei.www.hss._EnumType param) {
        localMCEFforIPTracker = param != null;

        this.localMCEFforIP = param;
    }

    public boolean isUNRISpecified() {
        return localUNRITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUNRI() {
        return localUNRI;
    }

    /**
     * Auto generated setter method
     * @param param UNRI
     */
    public void setUNRI(com.huawei.www.hss._EnumType param) {
        localUNRITracker = param != null;

        this.localUNRI = param;
    }

    public boolean isUNRRSpecified() {
        return localUNRRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUNRR() {
        return localUNRR;
    }

    /**
     * Auto generated setter method
     * @param param UNRR
     */
    public void setUNRR(com.huawei.www.hss._EnumType param) {
        localUNRRTracker = param != null;

        this.localUNRR = param;
    }

    public boolean isVGMLCMMESpecified() {
        return localVGMLCMMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str7_39
     */
    public com.huawei.www.hss.Str7_39 getVGMLCMME() {
        return localVGMLCMME;
    }

    /**
     * Auto generated setter method
     * @param param VGMLCMME
     */
    public void setVGMLCMME(com.huawei.www.hss.Str7_39 param) {
        localVGMLCMMETracker = param != null;

        this.localVGMLCMME = param;
    }

    public boolean isVGMLCSGSNSpecified() {
        return localVGMLCSGSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str7_39
     */
    public com.huawei.www.hss.Str7_39 getVGMLCSGSN() {
        return localVGMLCSGSN;
    }

    /**
     * Auto generated setter method
     * @param param VGMLCSGSN
     */
    public void setVGMLCSGSN(com.huawei.www.hss.Str7_39 param) {
        localVGMLCSGSNTracker = param != null;

        this.localVGMLCSGSN = param;
    }

    public boolean isIMSSFSpecified() {
        return localIMSSFTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_8
     */
    public com.huawei.www.hss.Str1_8 getIMSSF() {
        return localIMSSF;
    }

    /**
     * Auto generated setter method
     * @param param IMSSF
     */
    public void setIMSSF(com.huawei.www.hss.Str1_8 param) {
        localIMSSFTracker = param != null;

        this.localIMSSF = param;
    }

    public boolean isCS_V_GMLC_ADDTYPESpecified() {
        return localCS_V_GMLC_ADDTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCS_V_GMLC_ADDTYPE() {
        return localCS_V_GMLC_ADDTYPE;
    }

    /**
     * Auto generated setter method
     * @param param CS_V_GMLC_ADDTYPE
     */
    public void setCS_V_GMLC_ADDTYPE(com.huawei.www.hss._EnumType param) {
        localCS_V_GMLC_ADDTYPETracker = param != null;

        this.localCS_V_GMLC_ADDTYPE = param;
    }

    public boolean isCS_V_GMLC_ADDRESSSpecified() {
        return localCS_V_GMLC_ADDRESSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_39
     */
    public com.huawei.www.hss.Str1_39 getCS_V_GMLC_ADDRESS() {
        return localCS_V_GMLC_ADDRESS;
    }

    /**
     * Auto generated setter method
     * @param param CS_V_GMLC_ADDRESS
     */
    public void setCS_V_GMLC_ADDRESS(com.huawei.www.hss.Str1_39 param) {
        localCS_V_GMLC_ADDRESSTracker = param != null;

        this.localCS_V_GMLC_ADDRESS = param;
    }

    public boolean isPS_V_GMLC_ADDTYPESpecified() {
        return localPS_V_GMLC_ADDTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPS_V_GMLC_ADDTYPE() {
        return localPS_V_GMLC_ADDTYPE;
    }

    /**
     * Auto generated setter method
     * @param param PS_V_GMLC_ADDTYPE
     */
    public void setPS_V_GMLC_ADDTYPE(com.huawei.www.hss._EnumType param) {
        localPS_V_GMLC_ADDTYPETracker = param != null;

        this.localPS_V_GMLC_ADDTYPE = param;
    }

    public boolean isPS_V_GMLC_ADDRESSSpecified() {
        return localPS_V_GMLC_ADDRESSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_39
     */
    public com.huawei.www.hss.Str1_39 getPS_V_GMLC_ADDRESS() {
        return localPS_V_GMLC_ADDRESS;
    }

    /**
     * Auto generated setter method
     * @param param PS_V_GMLC_ADDRESS
     */
    public void setPS_V_GMLC_ADDRESS(com.huawei.www.hss.Str1_39 param) {
        localPS_V_GMLC_ADDRESSTracker = param != null;

        this.localPS_V_GMLC_ADDRESS = param;
    }

    public boolean isACTIVE_IMSISpecified() {
        return localACTIVE_IMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getACTIVE_IMSI() {
        return localACTIVE_IMSI;
    }

    /**
     * Auto generated setter method
     * @param param ACTIVE_IMSI
     */
    public void setACTIVE_IMSI(com.huawei.www.hss.Str6_15 param) {
        localACTIVE_IMSITracker = param != null;

        this.localACTIVE_IMSI = param;
    }

    public boolean isDataRefSpecified() {
        return localDataRefTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDataRef() {
        return localDataRef;
    }

    /**
     * Auto generated setter method
     * @param param DataRef
     */
    public void setDataRef(com.huawei.www.hss._EnumType param) {
        localDataRefTracker = param != null;

        this.localDataRef = param;
    }

    public boolean isAS_Host_NameSpecified() {
        return localAS_Host_NameTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getAS_Host_Name() {
        return localAS_Host_Name;
    }

    /**
     * Auto generated setter method
     * @param param AS_Host_Name
     */
    public void setAS_Host_Name(com.huawei.www.hss.Str1_128 param) {
        localAS_Host_NameTracker = param != null;

        this.localAS_Host_Name = param;
    }

    public boolean isAS_Realm_NameSpecified() {
        return localAS_Realm_NameTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getAS_Realm_Name() {
        return localAS_Realm_Name;
    }

    /**
     * Auto generated setter method
     * @param param AS_Realm_Name
     */
    public void setAS_Realm_Name(com.huawei.www.hss.Str1_128 param) {
        localAS_Realm_NameTracker = param != null;

        this.localAS_Realm_Name = param;
    }

    public boolean isCSMSISDNLESSSpecified() {
        return localCSMSISDNLESSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCSMSISDNLESS() {
        return localCSMSISDNLESS;
    }

    /**
     * Auto generated setter method
     * @param param CSMSISDNLESS
     */
    public void setCSMSISDNLESS(com.huawei.www.hss._EnumType param) {
        localCSMSISDNLESSTracker = param != null;

        this.localCSMSISDNLESS = param;
    }

    public boolean isPSMSISDNLESSSpecified() {
        return localPSMSISDNLESSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPSMSISDNLESS() {
        return localPSMSISDNLESS;
    }

    /**
     * Auto generated setter method
     * @param param PSMSISDNLESS
     */
    public void setPSMSISDNLESS(com.huawei.www.hss._EnumType param) {
        localPSMSISDNLESSTracker = param != null;

        this.localPSMSISDNLESS = param;
    }

    public boolean isCSRATTYPESpecified() {
        return localCSRATTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCSRATTYPE() {
        return localCSRATTYPE;
    }

    /**
     * Auto generated setter method
     * @param param CSRATTYPE
     */
    public void setCSRATTYPE(com.huawei.www.hss._EnumType param) {
        localCSRATTYPETracker = param != null;

        this.localCSRATTYPE = param;
    }

    public boolean isPSRATTYPESpecified() {
        return localPSRATTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPSRATTYPE() {
        return localPSRATTYPE;
    }

    /**
     * Auto generated setter method
     * @param param PSRATTYPE
     */
    public void setPSRATTYPE(com.huawei.www.hss._EnumType param) {
        localPSRATTYPETracker = param != null;

        this.localPSRATTYPE = param;
    }

    public boolean isCsUplStatusSpecified() {
        return localCsUplStatusTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCsUplStatus() {
        return localCsUplStatus;
    }

    /**
     * Auto generated setter method
     * @param param CsUplStatus
     */
    public void setCsUplStatus(com.huawei.www.hss._EnumType param) {
        localCsUplStatusTracker = param != null;

        this.localCsUplStatus = param;
    }

    public boolean isPsUplStatusSpecified() {
        return localPsUplStatusTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPsUplStatus() {
        return localPsUplStatus;
    }

    /**
     * Auto generated setter method
     * @param param PsUplStatus
     */
    public void setPsUplStatus(com.huawei.www.hss._EnumType param) {
        localPsUplStatusTracker = param != null;

        this.localPsUplStatus = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":LST_DYNSUBStruct1", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "LST_DYNSUBStruct1", xmlWriter);
            }
        }

        if (localIMSITracker) {
            if (localIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMSI cannot be null!!");
            }

            localIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMSI"), xmlWriter);
        }

        if (localISDNTracker) {
            if (localISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ISDN cannot be null!!");
            }

            localISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ISDN"), xmlWriter);
        }

        if (localHLRSN == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "HLRSN cannot be null!!");
        }

        localHLRSN.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "HLRSN"), xmlWriter);

        if (localMscNumTracker) {
            if (localMscNum == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MscNum cannot be null!!");
            }

            localMscNum.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MscNum"), xmlWriter);
        }

        if (localVlrNumTracker) {
            if (localVlrNum == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VlrNum cannot be null!!");
            }

            localVlrNum.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VlrNum"), xmlWriter);
        }

        if (localMsPurgedForNonGprsTracker) {
            if (localMsPurgedForNonGprs == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MsPurgedForNonGprs cannot be null!!");
            }

            localMsPurgedForNonGprs.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MsPurgedForNonGprs"),
                xmlWriter);
        }

        if (localVLRInHplmnTracker) {
            if (localVLRInHplmn == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VLRInHplmn cannot be null!!");
            }

            localVLRInHplmn.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VLRInHplmn"), xmlWriter);
        }

        if (localVLRInHomeCountryTracker) {
            if (localVLRInHomeCountry == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VLRInHomeCountry cannot be null!!");
            }

            localVLRInHomeCountry.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VLRInHomeCountry"), xmlWriter);
        }

        if (localVLRInAreaTracker) {
            if (localVLRInArea == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VLRInArea cannot be null!!");
            }

            localVLRInArea.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VLRInArea"), xmlWriter);
        }

        if (localRequireCheckSSTracker) {
            if (localRequireCheckSS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RequireCheckSS cannot be null!!");
            }

            localRequireCheckSS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RequireCheckSS"), xmlWriter);
        }

        if (localRoamingRestrictInMscDueToUnsupportedFeatureTracker) {
            if (localRoamingRestrictInMscDueToUnsupportedFeature == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RoamingRestrictInMscDueToUnsupportedFeature cannot be null!!");
            }

            localRoamingRestrictInMscDueToUnsupportedFeature.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "RoamingRestrictInMscDueToUnsupportedFeature"), xmlWriter);
        }

        if (localMscOrVlrAreaRoamingRestrictTracker) {
            if (localMscOrVlrAreaRoamingRestrict == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MscOrVlrAreaRoamingRestrict cannot be null!!");
            }

            localMscOrVlrAreaRoamingRestrict.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MscOrVlrAreaRoamingRestrict"),
                xmlWriter);
        }

        if (localODBarredForUnsupportedCamelTracker) {
            if (localODBarredForUnsupportedCamel == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBarredForUnsupportedCamel cannot be null!!");
            }

            localODBarredForUnsupportedCamel.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBarredForUnsupportedCamel"),
                xmlWriter);
        }

        if (localSupportedCamelPhase1Tracker) {
            if (localSupportedCamelPhase1 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedCamelPhase1 cannot be null!!");
            }

            localSupportedCamelPhase1.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedCamelPhase1"),
                xmlWriter);
        }

        if (localSupportedCamelPhase2Tracker) {
            if (localSupportedCamelPhase2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedCamelPhase2 cannot be null!!");
            }

            localSupportedCamelPhase2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedCamelPhase2"),
                xmlWriter);
        }

        if (localSupportedCamelPhase3Tracker) {
            if (localSupportedCamelPhase3 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedCamelPhase3 cannot be null!!");
            }

            localSupportedCamelPhase3.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedCamelPhase3"),
                xmlWriter);
        }

        if (localSupportedCamelPhase3_SGSNTracker) {
            if (localSupportedCamelPhase3_SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedCamelPhase3_SGSN cannot be null!!");
            }

            localSupportedCamelPhase3_SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedCamelPhase3_SGSN"),
                xmlWriter);
        }

        if (localSRIMsrnCfActiveTracker) {
            if (localSRIMsrnCfActive == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SRIMsrnCfActive cannot be null!!");
            }

            localSRIMsrnCfActive.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SRIMsrnCfActive"), xmlWriter);
        }

        if (localZoneCodeStatusAtMscTracker) {
            if (localZoneCodeStatusAtMsc == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ZoneCodeStatusAtMsc cannot be null!!");
            }

            localZoneCodeStatusAtMsc.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ZoneCodeStatusAtMsc"),
                xmlWriter);
        }

        if (localUnsupTSTracker) {
            if (localUnsupTS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UnsupTS cannot be null!!");
            }

            localUnsupTS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UnsupTS"), xmlWriter);
        }

        if (localUnsupBSFor2GTracker) {
            if (localUnsupBSFor2G == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UnsupBSFor2G cannot be null!!");
            }

            localUnsupBSFor2G.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UnsupBSFor2G"), xmlWriter);
        }

        if (localUnsupBSFor3GTracker) {
            if (localUnsupBSFor3G == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UnsupBSFor3G cannot be null!!");
            }

            localUnsupBSFor3G.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UnsupBSFor3G"), xmlWriter);
        }

        if (localUnsupSSTracker) {
            if (localUnsupSS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UnsupSS cannot be null!!");
            }

            localUnsupSS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UnsupSS"), xmlWriter);
        }

        if (localECATEGORYAtMscTracker) {
            if (localECATEGORYAtMsc == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ECATEGORYAtMsc cannot be null!!");
            }

            localECATEGORYAtMsc.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ECATEGORYAtMsc"), xmlWriter);
        }

        if (localSupportedCamelPhase4Tracker) {
            if (localSupportedCamelPhase4 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedCamelPhase4 cannot be null!!");
            }

            localSupportedCamelPhase4.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedCamelPhase4"),
                xmlWriter);
        }

        if (localSupportedCamelPhase4_SGSNTracker) {
            if (localSupportedCamelPhase4_SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedCamelPhase4_SGSN cannot be null!!");
            }

            localSupportedCamelPhase4_SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedCamelPhase4_SGSN"),
                xmlWriter);
        }

        if (localSuperChargerSupportedForGprsTracker) {
            if (localSuperChargerSupportedForGprs == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SuperChargerSupportedForGprs cannot be null!!");
            }

            localSuperChargerSupportedForGprs.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SuperChargerSupportedForGprs"),
                xmlWriter);
        }

        if (localBaocForVlrRestrictTracker) {
            if (localBaocForVlrRestrict == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BaocForVlrRestrict cannot be null!!");
            }

            localBaocForVlrRestrict.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BaocForVlrRestrict"),
                xmlWriter);
        }

        if (localOCSI_MSCTracker) {
            if (localOCSI_MSC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "OCSI_MSC cannot be null!!");
            }

            localOCSI_MSC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "OCSI_MSC"), xmlWriter);
        }

        if (localOCSI_SGSNTracker) {
            if (localOCSI_SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "OCSI_SGSN cannot be null!!");
            }

            localOCSI_SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "OCSI_SGSN"), xmlWriter);
        }

        if (localDCSI_MSCTracker) {
            if (localDCSI_MSC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DCSI_MSC cannot be null!!");
            }

            localDCSI_MSC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DCSI_MSC"), xmlWriter);
        }

        if (localDCSI_SGSNTracker) {
            if (localDCSI_SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DCSI_SGSN cannot be null!!");
            }

            localDCSI_SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DCSI_SGSN"), xmlWriter);
        }

        if (localVTCSI_MSCTracker) {
            if (localVTCSI_MSC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VTCSI_MSC cannot be null!!");
            }

            localVTCSI_MSC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VTCSI_MSC"), xmlWriter);
        }

        if (localVTCSI_SGSNTracker) {
            if (localVTCSI_SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VTCSI_SGSN cannot be null!!");
            }

            localVTCSI_SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VTCSI_SGSN"), xmlWriter);
        }

        if (localTCSI_MSCTracker) {
            if (localTCSI_MSC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TCSI_MSC cannot be null!!");
            }

            localTCSI_MSC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TCSI_MSC"), xmlWriter);
        }

        if (localTCSI_SGSNTracker) {
            if (localTCSI_SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TCSI_SGSN cannot be null!!");
            }

            localTCSI_SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TCSI_SGSN"), xmlWriter);
        }

        if (localMTSMSCSI_MSCTracker) {
            if (localMTSMSCSI_MSC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MTSMSCSI_MSC cannot be null!!");
            }

            localMTSMSCSI_MSC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MTSMSCSI_MSC"), xmlWriter);
        }

        if (localMTSMSCSI_SGSNTracker) {
            if (localMTSMSCSI_SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MTSMSCSI_SGSN cannot be null!!");
            }

            localMTSMSCSI_SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MTSMSCSI_SGSN"), xmlWriter);
        }

        if (localMGCSI_MSCTracker) {
            if (localMGCSI_MSC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MGCSI_MSC cannot be null!!");
            }

            localMGCSI_MSC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MGCSI_MSC"), xmlWriter);
        }

        if (localMGCSI_SGSNTracker) {
            if (localMGCSI_SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MGCSI_SGSN cannot be null!!");
            }

            localMGCSI_SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MGCSI_SGSN"), xmlWriter);
        }

        if (localPSIEnhancements_MSCTracker) {
            if (localPSIEnhancements_MSC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PSIEnhancements_MSC cannot be null!!");
            }

            localPSIEnhancements_MSC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PSIEnhancements_MSC"),
                xmlWriter);
        }

        if (localPSIEnhancements_SGSNTracker) {
            if (localPSIEnhancements_SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PSIEnhancements_SGSN cannot be null!!");
            }

            localPSIEnhancements_SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PSIEnhancements_SGSN"),
                xmlWriter);
        }

        if (localLMSITracker) {
            if (localLMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LMSI cannot be null!!");
            }

            localLMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LMSI"), xmlWriter);
        }

        if (localSgsnNumTracker) {
            if (localSgsnNum == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnNum cannot be null!!");
            }

            localSgsnNum.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnNum"), xmlWriter);
        }

        if (localSgsnAddressTypeTracker) {
            if (localSgsnAddressType == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnAddressType cannot be null!!");
            }

            localSgsnAddressType.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnAddressType"), xmlWriter);
        }

        if (localSgsnAddressTracker) {
            if (localSgsnAddress == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnAddress cannot be null!!");
            }

            localSgsnAddress.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnAddress"), xmlWriter);
        }

        if (localSgsnInHplmnTracker) {
            if (localSgsnInHplmn == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnInHplmn cannot be null!!");
            }

            localSgsnInHplmn.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnInHplmn"), xmlWriter);
        }

        if (localMsPurgedForGprsTracker) {
            if (localMsPurgedForGprs == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MsPurgedForGprs cannot be null!!");
            }

            localMsPurgedForGprs.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MsPurgedForGprs"), xmlWriter);
        }

        if (localSgsnInHomeCountryTracker) {
            if (localSgsnInHomeCountry == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnInHomeCountry cannot be null!!");
            }

            localSgsnInHomeCountry.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnInHomeCountry"), xmlWriter);
        }

        if (localSgsnInAreaTracker) {
            if (localSgsnInArea == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnInArea cannot be null!!");
            }

            localSgsnInArea.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnInArea"), xmlWriter);
        }

        if (localRoamingRestrictInSgsnDueToUnsupportedFeatureTracker) {
            if (localRoamingRestrictInSgsnDueToUnsupportedFeature == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RoamingRestrictInSgsnDueToUnsupportedFeature cannot be null!!");
            }

            localRoamingRestrictInSgsnDueToUnsupportedFeature.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "RoamingRestrictInSgsnDueToUnsupportedFeature"), xmlWriter);
        }

        if (localSgsnAreaRoamingRestrictTracker) {
            if (localSgsnAreaRoamingRestrict == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SgsnAreaRoamingRestrict cannot be null!!");
            }

            localSgsnAreaRoamingRestrict.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SgsnAreaRoamingRestrict"),
                xmlWriter);
        }

        if (localODBarredForUnsupportedCamelForGprsTracker) {
            if (localODBarredForUnsupportedCamelForGprs == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBarredForUnsupportedCamelForGprs cannot be null!!");
            }

            localODBarredForUnsupportedCamelForGprs.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "ODBarredForUnsupportedCamelForGprs"), xmlWriter);
        }

        if (localZoneCodeStatusAtSgsnTracker) {
            if (localZoneCodeStatusAtSgsn == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ZoneCodeStatusAtSgsn cannot be null!!");
            }

            localZoneCodeStatusAtSgsn.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ZoneCodeStatusAtSgsn"),
                xmlWriter);
        }

        if (localMCEFforGSMTracker) {
            if (localMCEFforGSM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MCEFforGSM cannot be null!!");
            }

            localMCEFforGSM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MCEFforGSM"), xmlWriter);
        }

        if (localMCEFforGPRSTracker) {
            if (localMCEFforGPRS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MCEFforGPRS cannot be null!!");
            }

            localMCEFforGPRS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MCEFforGPRS"), xmlWriter);
        }

        if (localMNRFTracker) {
            if (localMNRF == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MNRF cannot be null!!");
            }

            localMNRF.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MNRF"), xmlWriter);
        }

        if (localMNRGTracker) {
            if (localMNRG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MNRG cannot be null!!");
            }

            localMNRG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MNRG"), xmlWriter);
        }

        if (localMNRRforGSMTracker) {
            if (localMNRRforGSM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MNRRforGSM cannot be null!!");
            }

            localMNRRforGSM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MNRRforGSM"), xmlWriter);
        }

        if (localMNRRforGPRSTracker) {
            if (localMNRRforGPRS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MNRRforGPRS cannot be null!!");
            }

            localMNRRforGPRS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MNRRforGPRS"), xmlWriter);
        }

        if (localSupportedShortMessageMTPPTracker) {
            if (localSupportedShortMessageMTPP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedShortMessageMTPP cannot be null!!");
            }

            localSupportedShortMessageMTPP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedShortMessageMTPP"),
                xmlWriter);
        }

        if (localSupportedShortMessageMOPPTracker) {
            if (localSupportedShortMessageMOPP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupportedShortMessageMOPP cannot be null!!");
            }

            localSupportedShortMessageMOPP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SupportedShortMessageMOPP"),
                xmlWriter);
        }

        if (localSCTracker) {
            if (localSC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SC cannot be null!!");
            }

            localSC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SC"), xmlWriter);
        }

        if (localSCLINE2Tracker) {
            if (localSCLINE2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SCLINE2 cannot be null!!");
            }

            localSCLINE2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SCLINE2"), xmlWriter);
        }

        if (localBarredSSAccessTracker) {
            if (localBarredSSAccess == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BarredSSAccess cannot be null!!");
            }

            localBarredSSAccess.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BarredSSAccess"), xmlWriter);
        }

        if (localBarredOutgoingEntertainmentCallTracker) {
            if (localBarredOutgoingEntertainmentCall == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BarredOutgoingEntertainmentCall cannot be null!!");
            }

            localBarredOutgoingEntertainmentCall.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "BarredOutgoingEntertainmentCall"), xmlWriter);
        }

        if (localBarredOutgoingInformationCallTracker) {
            if (localBarredOutgoingInformationCall == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BarredOutgoingInformationCall cannot be null!!");
            }

            localBarredOutgoingInformationCall.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BarredOutgoingInformationCall"),
                xmlWriter);
        }

        if (localSupGSMODBBarredOutgoingInternationalCallExHCTracker) {
            if (localSupGSMODBBarredOutgoingInternationalCallExHC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupGSMODB-BarredOutgoingInternationalCallExHC cannot be null!!");
            }

            localSupGSMODBBarredOutgoingInternationalCallExHC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "SupGSMODB-BarredOutgoingInternationalCallExHC"), xmlWriter);
        }

        if (localSupGSMODBBarredOutgoingInternationalCallTracker) {
            if (localSupGSMODBBarredOutgoingInternationalCall == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupGSMODB-BarredOutgoingInternationalCall cannot be null!!");
            }

            localSupGSMODBBarredOutgoingInternationalCall.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "SupGSMODB-BarredOutgoingInternationalCall"), xmlWriter);
        }

        if (localSupGSMODBBarredAllOutgoingCallTracker) {
            if (localSupGSMODBBarredAllOutgoingCall == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupGSMODB-BarredAllOutgoingCall cannot be null!!");
            }

            localSupGSMODBBarredAllOutgoingCall.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "SupGSMODB-BarredAllOutgoingCall"), xmlWriter);
        }

        if (localBarredAllECTTracker) {
            if (localBarredAllECT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BarredAllECT cannot be null!!");
            }

            localBarredAllECT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BarredAllECT"), xmlWriter);
        }

        if (localBarredChargeableECTTracker) {
            if (localBarredChargeableECT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BarredChargeableECT cannot be null!!");
            }

            localBarredChargeableECT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BarredChargeableECT"),
                xmlWriter);
        }

        if (localBarredInternationalECTTracker) {
            if (localBarredInternationalECT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BarredInternationalECT cannot be null!!");
            }

            localBarredInternationalECT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BarredInternationalECT"),
                xmlWriter);
        }

        if (localBarredInterzonalECTTracker) {
            if (localBarredInterzonalECT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BarredInterzonalECT cannot be null!!");
            }

            localBarredInterzonalECT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BarredInterzonalECT"),
                xmlWriter);
        }

        if (localBarredDECTTracker) {
            if (localBarredDECT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BarredDECT cannot be null!!");
            }

            localBarredDECT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BarredDECT"), xmlWriter);
        }

        if (localBarredMECTTracker) {
            if (localBarredMECT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BarredMECT cannot be null!!");
            }

            localBarredMECT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BarredMECT"), xmlWriter);
        }

        if (localSupGPRSODBBarredAllOutgoingCallTracker) {
            if (localSupGPRSODBBarredAllOutgoingCall == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupGPRSODB-BarredAllOutgoingCall cannot be null!!");
            }

            localSupGPRSODBBarredAllOutgoingCall.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "SupGPRSODB-BarredAllOutgoingCall"), xmlWriter);
        }

        if (localSupGPRSODBBarredOutgoingInternationalCallTracker) {
            if (localSupGPRSODBBarredOutgoingInternationalCall == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupGPRSODB-BarredOutgoingInternationalCall cannot be null!!");
            }

            localSupGPRSODBBarredOutgoingInternationalCall.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "SupGPRSODB-BarredOutgoingInternationalCall"), xmlWriter);
        }

        if (localSupGPRSODBBarredOutgoingInternationalCallExHCTracker) {
            if (localSupGPRSODBBarredOutgoingInternationalCallExHC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SupGPRSODB-BarredOutgoingInternationalCallExHC cannot be null!!");
            }

            localSupGPRSODBBarredOutgoingInternationalCallExHC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "SupGPRSODB-BarredOutgoingInternationalCallExHC"), xmlWriter);
        }

        if (localBarringofPacketOrientedServicesTracker) {
            if (localBarringofPacketOrientedServices == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BarringofPacketOrientedServices cannot be null!!");
            }

            localBarringofPacketOrientedServices.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "BarringofPacketOrientedServices"), xmlWriter);
        }

        if (localMSCSupportedLCSCapabilitySet1Tracker) {
            if (localMSCSupportedLCSCapabilitySet1 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MSCSupportedLCSCapabilitySet1 cannot be null!!");
            }

            localMSCSupportedLCSCapabilitySet1.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MSCSupportedLCSCapabilitySet1"),
                xmlWriter);
        }

        if (localMSCSupportedLCSCapabilitySet2Tracker) {
            if (localMSCSupportedLCSCapabilitySet2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MSCSupportedLCSCapabilitySet2 cannot be null!!");
            }

            localMSCSupportedLCSCapabilitySet2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MSCSupportedLCSCapabilitySet2"),
                xmlWriter);
        }

        if (localSGSNSupportedLCSCapabilitySet2Tracker) {
            if (localSGSNSupportedLCSCapabilitySet2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SGSNSupportedLCSCapabilitySet2 cannot be null!!");
            }

            localSGSNSupportedLCSCapabilitySet2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "SGSNSupportedLCSCapabilitySet2"), xmlWriter);
        }

        if (localALS_DYNTracker) {
            if (localALS_DYN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ALS_DYN cannot be null!!");
            }

            localALS_DYN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ALS_DYN"), xmlWriter);
        }

        if (localVVDN_DYNTracker) {
            if (localVVDN_DYN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VVDN_DYN cannot be null!!");
            }

            localVVDN_DYN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VVDN_DYN"), xmlWriter);
        }

        if (localDIMSITracker) {
            if (localDIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DIMSI cannot be null!!");
            }

            localDIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DIMSI"), xmlWriter);
        }

        if (localACTIMSITracker) {
            if (localACTIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ACTIMSI cannot be null!!");
            }

            localACTIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ACTIMSI"), xmlWriter);
        }

        if (localGgsnNumberTracker) {
            if (localGgsnNumber == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GgsnNumber cannot be null!!");
            }

            localGgsnNumber.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GgsnNumber"), xmlWriter);
        }

        if (localGgsnAddressTypeTracker) {
            if (localGgsnAddressType == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GgsnAddressType cannot be null!!");
            }

            localGgsnAddressType.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GgsnAddressType"), xmlWriter);
        }

        if (localGgsnAddressTracker) {
            if (localGgsnAddress == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GgsnAddress cannot be null!!");
            }

            localGgsnAddress.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GgsnAddress"), xmlWriter);
        }

        if (localLongGroupIDSupportedTracker) {
            if (localLongGroupIDSupported == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "longGroupIDSupported cannot be null!!");
            }

            localLongGroupIDSupported.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "longGroupIDSupported"),
                xmlWriter);
        }

        if (localBasicISTSupportedTracker) {
            if (localBasicISTSupported == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "basicISTSupported cannot be null!!");
            }

            localBasicISTSupported.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "basicISTSupported"), xmlWriter);
        }

        if (localIstCommandSupportedTracker) {
            if (localIstCommandSupported == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "istCommandSupported cannot be null!!");
            }

            localIstCommandSupported.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "istCommandSupported"),
                xmlWriter);
        }

        if (localSuperChargerSupportedForGsmTracker) {
            if (localSuperChargerSupportedForGsm == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SuperChargerSupportedForGsm cannot be null!!");
            }

            localSuperChargerSupportedForGsm.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SuperChargerSupportedForGsm"),
                xmlWriter);
        }

        if (localIMEITracker) {
            if (localIMEI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMEI cannot be null!!");
            }

            localIMEI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMEI"), xmlWriter);
        }

        if (localCSUPLTIMETracker) {
            if (localCSUPLTIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CSUPLTIME cannot be null!!");
            }

            localCSUPLTIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CSUPLTIME"), xmlWriter);
        }

        if (localCSPURGETIMETracker) {
            if (localCSPURGETIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CSPURGETIME cannot be null!!");
            }

            localCSPURGETIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CSPURGETIME"), xmlWriter);
        }

        if (localPSUPLTIMETracker) {
            if (localPSUPLTIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PSUPLTIME cannot be null!!");
            }

            localPSUPLTIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PSUPLTIME"), xmlWriter);
        }

        if (localPSPURGETIMETracker) {
            if (localPSPURGETIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PSPURGETIME cannot be null!!");
            }

            localPSPURGETIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PSPURGETIME"), xmlWriter);
        }

        if (localMAINIMSITracker) {
            if (localMAINIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAINIMSI cannot be null!!");
            }

            localMAINIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAINIMSI"), xmlWriter);
        }

        if (localMIMSI_SMSTracker) {
            if (localMIMSI_SMS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MIMSI_SMS cannot be null!!");
            }

            localMIMSI_SMS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MIMSI_SMS"), xmlWriter);
        }

        if (localMIMSI_VOBBTracker) {
            if (localMIMSI_VOBB == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MIMSI_VOBB cannot be null!!");
            }

            localMIMSI_VOBB.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MIMSI_VOBB"), xmlWriter);
        }

        if (localMIMSITYPETracker) {
            if (localMIMSITYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MIMSITYPE cannot be null!!");
            }

            localMIMSITYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MIMSITYPE"), xmlWriter);
        }

        if (localLSFLAGTracker) {
            if (localLSFLAG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LSFLAG cannot be null!!");
            }

            localLSFLAG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LSFLAG"), xmlWriter);
        }

        if (localCamelInduceBarringSMSTracker) {
            if (localCamelInduceBarringSMS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "camelInduceBarringSMS cannot be null!!");
            }

            localCamelInduceBarringSMS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "camelInduceBarringSMS"),
                xmlWriter);
        }

        if (localRoamBaocTs11Tracker) {
            if (localRoamBaocTs11 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RoamBaocTs11 cannot be null!!");
            }

            localRoamBaocTs11.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RoamBaocTs11"), xmlWriter);
        }

        if (localMTRF_SUPPORTEDTracker) {
            if (localMTRF_SUPPORTED == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MTRF_SUPPORTED cannot be null!!");
            }

            localMTRF_SUPPORTED.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MTRF_SUPPORTED"), xmlWriter);
        }

        if (localURRP_MMETracker) {
            if (localURRP_MME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "URRP_MME cannot be null!!");
            }

            localURRP_MME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "URRP_MME"), xmlWriter);
        }

        if (localURRP_SGSNTracker) {
            if (localURRP_SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "URRP_SGSN cannot be null!!");
            }

            localURRP_SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "URRP_SGSN"), xmlWriter);
        }

        if (localTAITracker) {
            if (localTAI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TAI cannot be null!!");
            }

            localTAI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TAI"), xmlWriter);
        }

        if (localVLR_NUM_SAITracker) {
            if (localVLR_NUM_SAI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VLR_NUM_SAI cannot be null!!");
            }

            localVLR_NUM_SAI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VLR_NUM_SAI"), xmlWriter);
        }

        if (localTIME_STAMP_SAITracker) {
            if (localTIME_STAMP_SAI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TIME_STAMP_SAI cannot be null!!");
            }

            localTIME_STAMP_SAI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TIME_STAMP_SAI"), xmlWriter);
        }

        if (localMMEHOSTTracker) {
            if (localMMEHOST == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MMEHOST cannot be null!!");
            }

            localMMEHOST.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MMEHOST"), xmlWriter);
        }

        if (localMMEREALMTracker) {
            if (localMMEREALM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MMEREALM cannot be null!!");
            }

            localMMEREALM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MMEREALM"), xmlWriter);
        }

        if (localMRATTYPETracker) {
            if (localMRATTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-RATTYPE cannot be null!!");
            }

            localMRATTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "M-RATTYPE"), xmlWriter);
        }

        if (localMVPLMNTracker) {
            if (localMVPLMN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-VPLMN cannot be null!!");
            }

            localMVPLMN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "M-VPLMN"), xmlWriter);
        }

        if (localPURGEDONMMETracker) {
            if (localPURGEDONMME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PURGEDONMME cannot be null!!");
            }

            localPURGEDONMME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PURGEDONMME"), xmlWriter);
        }

        if (localMMEUpdateLocationTimeTracker) {
            if (localMMEUpdateLocationTime == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MME-UpdateLocation-Time cannot be null!!");
            }

            localMMEUpdateLocationTime.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MME-UpdateLocation-Time"),
                xmlWriter);
        }

        if (localMMEFeatureListTracker) {
            if (localMMEFeatureList == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MME-FeatureList cannot be null!!");
            }

            localMMEFeatureList.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MME-FeatureList"), xmlWriter);
        }

        if (localMLastIDRorDSRSUCCTracker) {
            if (localMLastIDRorDSRSUCC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-LastIDRorDSRSUCC cannot be null!!");
            }

            localMLastIDRorDSRSUCC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "M-LastIDRorDSRSUCC"),
                xmlWriter);
        }

        if (localMSingleRegistrationIndicationTracker) {
            if (localMSingleRegistrationIndication == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-Single-Registration-Indication cannot be null!!");
            }

            localMSingleRegistrationIndication.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "M-Single-Registration-Indication"), xmlWriter);
        }

        if (localMSkipSubscriberDataIndicatorTracker) {
            if (localMSkipSubscriberDataIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-Skip-Subscriber-Data-Indicator cannot be null!!");
            }

            localMSkipSubscriberDataIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "M-Skip-Subscriber-Data-Indicator"), xmlWriter);
        }

        if (localMGPRSSubscriptionDataIndicatorTracker) {
            if (localMGPRSSubscriptionDataIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-GPRS-Subscription-Data-Indicator cannot be null!!");
            }

            localMGPRSSubscriptionDataIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "M-GPRS-Subscription-Data-Indicator"), xmlWriter);
        }

        if (localMNodeTypeIndicatorTracker) {
            if (localMNodeTypeIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-Node-Type-Indicator cannot be null!!");
            }

            localMNodeTypeIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "M-Node-Type-Indicator"),
                xmlWriter);
        }

        if (localMInitialAttachIndicatorTracker) {
            if (localMInitialAttachIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-Initial-Attach-Indicator cannot be null!!");
            }

            localMInitialAttachIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "M-Initial-Attach-Indicator"),
                xmlWriter);
        }

        if (localMPSLCSNotSupportedByUETracker) {
            if (localMPSLCSNotSupportedByUE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-PS-LCS-Not-Supported-By-UE cannot be null!!");
            }

            localMPSLCSNotSupportedByUE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "M-PS-LCS-Not-Supported-By-UE"),
                xmlWriter);
        }

        if (localMIMEITracker) {
            if (localMIMEI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-IMEI cannot be null!!");
            }

            localMIMEI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "M-IMEI"), xmlWriter);
        }

        if (localMIMEISVTracker) {
            if (localMIMEISV == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-IMEISV cannot be null!!");
            }

            localMIMEISV.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "M-IMEISV"), xmlWriter);
        }

        if (localSGSNHOSTTracker) {
            if (localSGSNHOST == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SGSNHOST cannot be null!!");
            }

            localSGSNHOST.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SGSNHOST"), xmlWriter);
        }

        if (localSGSNREALMTracker) {
            if (localSGSNREALM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SGSNREALM cannot be null!!");
            }

            localSGSNREALM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SGSNREALM"), xmlWriter);
        }

        if (localSGSNNUMBERTracker) {
            if (localSGSNNUMBER == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SGSNNUMBER cannot be null!!");
            }

            localSGSNNUMBER.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SGSNNUMBER"), xmlWriter);
        }

        if (localSRATTYPETracker) {
            if (localSRATTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-RATTYPE cannot be null!!");
            }

            localSRATTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-RATTYPE"), xmlWriter);
        }

        if (localSVPLMNTracker) {
            if (localSVPLMN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-VPLMN cannot be null!!");
            }

            localSVPLMN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-VPLMN"), xmlWriter);
        }

        if (localPURGEDONSGSNTracker) {
            if (localPURGEDONSGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PURGEDONSGSN cannot be null!!");
            }

            localPURGEDONSGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PURGEDONSGSN"), xmlWriter);
        }

        if (localSAREARESTRICTTracker) {
            if (localSAREARESTRICT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-AREARESTRICT cannot be null!!");
            }

            localSAREARESTRICT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-AREARESTRICT"), xmlWriter);
        }

        if (localS4SGSNUpdateLocationTimeTracker) {
            if (localS4SGSNUpdateLocationTime == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S4SGSN-UpdateLocation-Time cannot be null!!");
            }

            localS4SGSNUpdateLocationTime.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S4SGSN-UpdateLocation-Time"),
                xmlWriter);
        }

        if (localS4SGSNFeatureListTracker) {
            if (localS4SGSNFeatureList == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S4SGSN-FeatureList cannot be null!!");
            }

            localS4SGSNFeatureList.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S4SGSN-FeatureList"),
                xmlWriter);
        }

        if (localSLastIDRorDSRSUCCTracker) {
            if (localSLastIDRorDSRSUCC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-LastIDRorDSRSUCC cannot be null!!");
            }

            localSLastIDRorDSRSUCC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-LastIDRorDSRSUCC"),
                xmlWriter);
        }

        if (localSSingleRegistrationIndicationTracker) {
            if (localSSingleRegistrationIndication == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-Single-Registration-Indication cannot be null!!");
            }

            localSSingleRegistrationIndication.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "S-Single-Registration-Indication"), xmlWriter);
        }

        if (localSSkipSubscriberDataIndicatorTracker) {
            if (localSSkipSubscriberDataIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-Skip-Subscriber-Data-Indicator cannot be null!!");
            }

            localSSkipSubscriberDataIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "S-Skip-Subscriber-Data-Indicator"), xmlWriter);
        }

        if (localSGPRSSubscriptionDataIndicatorTracker) {
            if (localSGPRSSubscriptionDataIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-GPRS-Subscription-Data-Indicator cannot be null!!");
            }

            localSGPRSSubscriptionDataIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "S-GPRS-Subscription-Data-Indicator"), xmlWriter);
        }

        if (localSNodeTypeIndicatorTracker) {
            if (localSNodeTypeIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-Node-Type-Indicator cannot be null!!");
            }

            localSNodeTypeIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-Node-Type-Indicator"),
                xmlWriter);
        }

        if (localSInitialAttachIndicatorTracker) {
            if (localSInitialAttachIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-Initial-Attach-Indicator cannot be null!!");
            }

            localSInitialAttachIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-Initial-Attach-Indicator"),
                xmlWriter);
        }

        if (localSPSLCSNotSupportedByUETracker) {
            if (localSPSLCSNotSupportedByUE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-PS-LCS-Not-Supported-By-UE cannot be null!!");
            }

            localSPSLCSNotSupportedByUE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-PS-LCS-Not-Supported-By-UE"),
                xmlWriter);
        }

        if (localSIMEITracker) {
            if (localSIMEI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-IMEI cannot be null!!");
            }

            localSIMEI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-IMEI"), xmlWriter);
        }

        if (localSIMEISVTracker) {
            if (localSIMEISV == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "S-IMEISV cannot be null!!");
            }

            localSIMEISV.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "S-IMEISV"), xmlWriter);
        }

        if (localEPSDYNCNTXIDTracker) {
            if (localEPSDYNCNTXID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EPSDYNCNTXID cannot be null!!");
            }

            localEPSDYNCNTXID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EPSDYNCNTXID"), xmlWriter);
        }

        if (localEPSDYNAPNTracker) {
            if (localEPSDYNAPN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EPSDYNAPN cannot be null!!");
            }

            localEPSDYNAPN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EPSDYNAPN"), xmlWriter);
        }

        if (localEPSDYNPDNGWHOSTTracker) {
            if (localEPSDYNPDNGWHOST == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EPSDYNPDNGWHOST cannot be null!!");
            }

            localEPSDYNPDNGWHOST.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EPSDYNPDNGWHOST"), xmlWriter);
        }

        if (localEPSDYNPDNGWREALMTracker) {
            if (localEPSDYNPDNGWREALM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EPSDYNPDNGWREALM cannot be null!!");
            }

            localEPSDYNPDNGWREALM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EPSDYNPDNGWREALM"), xmlWriter);
        }

        if (localEPSDYNPDNGWIPV4Tracker) {
            if (localEPSDYNPDNGWIPV4 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EPSDYNPDNGWIPV4 cannot be null!!");
            }

            localEPSDYNPDNGWIPV4.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EPSDYNPDNGWIPV4"), xmlWriter);
        }

        if (localEPSDYNPDNGWIPV6Tracker) {
            if (localEPSDYNPDNGWIPV6 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EPSDYNPDNGWIPV6 cannot be null!!");
            }

            localEPSDYNPDNGWIPV6.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EPSDYNPDNGWIPV6"), xmlWriter);
        }

        if (localEPSDYNWILDCARDFLAGTracker) {
            if (localEPSDYNWILDCARDFLAG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EPSDYNWILDCARDFLAG cannot be null!!");
            }

            localEPSDYNWILDCARDFLAG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EPSDYNWILDCARDFLAG"),
                xmlWriter);
        }

        if (localEPSDYNVNITracker) {
            if (localEPSDYNVNI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EPSDYNVNI cannot be null!!");
            }

            localEPSDYNVNI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EPSDYNVNI"), xmlWriter);
        }

        if (localVNITracker) {
            if (localVNI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VNI cannot be null!!");
            }

            localVNI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VNI"), xmlWriter);
        }

        if (localREGSTATUSTracker) {
            if (localREGSTATUS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "REGSTATUS cannot be null!!");
            }

            localREGSTATUS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "REGSTATUS"), xmlWriter);
        }

        if (localACCESSNETIDTracker) {
            if (localACCESSNETID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ACCESSNETID cannot be null!!");
            }

            localACCESSNETID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ACCESSNETID"), xmlWriter);
        }

        if (localTGPPAAASERVERNAMETracker) {
            if (localTGPPAAASERVERNAME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TGPPAAASERVERNAME cannot be null!!");
            }

            localTGPPAAASERVERNAME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TGPPAAASERVERNAME"), xmlWriter);
        }

        if (localTGPPAAASERVERREALMTracker) {
            if (localTGPPAAASERVERREALM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TGPPAAASERVERREALM cannot be null!!");
            }

            localTGPPAAASERVERREALM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TGPPAAASERVERREALM"),
                xmlWriter);
        }

        if (localTGPP2MEIDTracker) {
            if (localTGPP2MEID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TGPP2MEID cannot be null!!");
            }

            localTGPP2MEID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TGPP2MEID"), xmlWriter);
        }

        if (localAAAIMEITracker) {
            if (localAAAIMEI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AAA-IMEI cannot be null!!");
            }

            localAAAIMEI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AAA-IMEI"), xmlWriter);
        }

        if (localAAAIMEISVTracker) {
            if (localAAAIMEISV == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AAA-IMEISV cannot be null!!");
            }

            localAAAIMEISV.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AAA-IMEISV"), xmlWriter);
        }

        if (localServerAssignmentTimeTracker) {
            if (localServerAssignmentTime == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "Server-Assignment-Time cannot be null!!");
            }

            localServerAssignmentTime.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "Server-Assignment-Time"),
                xmlWriter);
        }

        if (localIMSVOPSSessionsSupportedTracker) {
            if (localIMSVOPSSessionsSupported == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMS-VO-PS-Sessions-Supported cannot be null!!");
            }

            localIMSVOPSSessionsSupported.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMS-VO-PS-Sessions-Supported"),
                xmlWriter);
        }

        if (localUESRVCCCapabilityTracker) {
            if (localUESRVCCCapability == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UE-SRVCC-Capability cannot be null!!");
            }

            localUESRVCCCapability.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UE-SRVCC-Capability"),
                xmlWriter);
        }

        if (localIMSVOPSSessionsSupportedS4SGSNTracker) {
            if (localIMSVOPSSessionsSupportedS4SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMS-VO-PS-Sessions-Supported-S4SGSN cannot be null!!");
            }

            localIMSVOPSSessionsSupportedS4SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "IMS-VO-PS-Sessions-Supported-S4SGSN"), xmlWriter);
        }

        if (localUESRVCCCapabilityS4SGSNTracker) {
            if (localUESRVCCCapabilityS4SGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UE-SRVCC-Capability-S4SGSN cannot be null!!");
            }

            localUESRVCCCapabilityS4SGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UE-SRVCC-Capability-S4SGSN"),
                xmlWriter);
        }

        if (localUERegisterAtIMSTracker) {
            if (localUERegisterAtIMS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UE-Register-AtIMS cannot be null!!");
            }

            localUERegisterAtIMS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UE-Register-AtIMS"), xmlWriter);
        }

        if (localIP_SM_GWTracker) {
            if (localIP_SM_GW == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IP_SM_GW cannot be null!!");
            }

            localIP_SM_GW.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IP_SM_GW"), xmlWriter);
        }

        if (localMCEFforIPTracker) {
            if (localMCEFforIP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MCEFforIP cannot be null!!");
            }

            localMCEFforIP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MCEFforIP"), xmlWriter);
        }

        if (localUNRITracker) {
            if (localUNRI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UNRI cannot be null!!");
            }

            localUNRI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UNRI"), xmlWriter);
        }

        if (localUNRRTracker) {
            if (localUNRR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UNRR cannot be null!!");
            }

            localUNRR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UNRR"), xmlWriter);
        }

        if (localVGMLCMMETracker) {
            if (localVGMLCMME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VGMLC-MME cannot be null!!");
            }

            localVGMLCMME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VGMLC-MME"), xmlWriter);
        }

        if (localVGMLCSGSNTracker) {
            if (localVGMLCSGSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VGMLC-SGSN cannot be null!!");
            }

            localVGMLCSGSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VGMLC-SGSN"), xmlWriter);
        }

        if (localIMSSFTracker) {
            if (localIMSSF == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMSSF cannot be null!!");
            }

            localIMSSF.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMSSF"), xmlWriter);
        }

        if (localCS_V_GMLC_ADDTYPETracker) {
            if (localCS_V_GMLC_ADDTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CS_V_GMLC_ADDTYPE cannot be null!!");
            }

            localCS_V_GMLC_ADDTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CS_V_GMLC_ADDTYPE"), xmlWriter);
        }

        if (localCS_V_GMLC_ADDRESSTracker) {
            if (localCS_V_GMLC_ADDRESS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CS_V_GMLC_ADDRESS cannot be null!!");
            }

            localCS_V_GMLC_ADDRESS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CS_V_GMLC_ADDRESS"), xmlWriter);
        }

        if (localPS_V_GMLC_ADDTYPETracker) {
            if (localPS_V_GMLC_ADDTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PS_V_GMLC_ADDTYPE cannot be null!!");
            }

            localPS_V_GMLC_ADDTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PS_V_GMLC_ADDTYPE"), xmlWriter);
        }

        if (localPS_V_GMLC_ADDRESSTracker) {
            if (localPS_V_GMLC_ADDRESS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PS_V_GMLC_ADDRESS cannot be null!!");
            }

            localPS_V_GMLC_ADDRESS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PS_V_GMLC_ADDRESS"), xmlWriter);
        }

        if (localACTIVE_IMSITracker) {
            if (localACTIVE_IMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ACTIVE_IMSI cannot be null!!");
            }

            localACTIVE_IMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ACTIVE_IMSI"), xmlWriter);
        }

        if (localDataRefTracker) {
            if (localDataRef == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DataRef cannot be null!!");
            }

            localDataRef.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DataRef"), xmlWriter);
        }

        if (localAS_Host_NameTracker) {
            if (localAS_Host_Name == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AS_Host_Name cannot be null!!");
            }

            localAS_Host_Name.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AS_Host_Name"), xmlWriter);
        }

        if (localAS_Realm_NameTracker) {
            if (localAS_Realm_Name == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AS_Realm_Name cannot be null!!");
            }

            localAS_Realm_Name.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AS_Realm_Name"), xmlWriter);
        }

        if (localCSMSISDNLESSTracker) {
            if (localCSMSISDNLESS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CS-MSISDN-LESS cannot be null!!");
            }

            localCSMSISDNLESS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CS-MSISDN-LESS"), xmlWriter);
        }

        if (localPSMSISDNLESSTracker) {
            if (localPSMSISDNLESS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PS-MSISDN-LESS cannot be null!!");
            }

            localPSMSISDNLESS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PS-MSISDN-LESS"), xmlWriter);
        }

        if (localCSRATTYPETracker) {
            if (localCSRATTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CSRATTYPE cannot be null!!");
            }

            localCSRATTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CSRATTYPE"), xmlWriter);
        }

        if (localPSRATTYPETracker) {
            if (localPSRATTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PSRATTYPE cannot be null!!");
            }

            localPSRATTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PSRATTYPE"), xmlWriter);
        }

        if (localCsUplStatusTracker) {
            if (localCsUplStatus == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CsUplStatus cannot be null!!");
            }

            localCsUplStatus.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CsUplStatus"), xmlWriter);
        }

        if (localPsUplStatusTracker) {
            if (localPsUplStatus == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PsUplStatus cannot be null!!");
            }

            localPsUplStatus.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PsUplStatus"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static LST_DYNSUBStruct1 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            LST_DYNSUBStruct1 object = new LST_DYNSUBStruct1();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"LST_DYNSUBStruct1".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (LST_DYNSUBStruct1) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSI").equals(
                            reader.getName())) {
                    object.setIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ISDN").equals(
                            reader.getName())) {
                    object.setISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "HLRSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "HLRSN").equals(
                            reader.getName())) {
                    object.setHLRSN(com.huawei.www.hss.Int0_254.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MscNum").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MscNum").equals(
                            reader.getName())) {
                    object.setMscNum(com.huawei.www.hss.Str1_8.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VlrNum").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VlrNum").equals(
                            reader.getName())) {
                    object.setVlrNum(com.huawei.www.hss.Str1_8.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MsPurgedForNonGprs").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MsPurgedForNonGprs").equals(
                            reader.getName())) {
                    object.setMsPurgedForNonGprs(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VLRInHplmn").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VLRInHplmn").equals(
                            reader.getName())) {
                    object.setVLRInHplmn(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VLRInHomeCountry").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VLRInHomeCountry").equals(
                            reader.getName())) {
                    object.setVLRInHomeCountry(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VLRInArea").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VLRInArea").equals(
                            reader.getName())) {
                    object.setVLRInArea(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RequireCheckSS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RequireCheckSS").equals(
                            reader.getName())) {
                    object.setRequireCheckSS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "RoamingRestrictInMscDueToUnsupportedFeature").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "RoamingRestrictInMscDueToUnsupportedFeature").equals(
                            reader.getName())) {
                    object.setRoamingRestrictInMscDueToUnsupportedFeature(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "MscOrVlrAreaRoamingRestrict").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "MscOrVlrAreaRoamingRestrict").equals(
                            reader.getName())) {
                    object.setMscOrVlrAreaRoamingRestrict(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "ODBarredForUnsupportedCamel").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "ODBarredForUnsupportedCamel").equals(
                            reader.getName())) {
                    object.setODBarredForUnsupportedCamel(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SupportedCamelPhase1").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SupportedCamelPhase1").equals(
                            reader.getName())) {
                    object.setSupportedCamelPhase1(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SupportedCamelPhase2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SupportedCamelPhase2").equals(
                            reader.getName())) {
                    object.setSupportedCamelPhase2(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SupportedCamelPhase3").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SupportedCamelPhase3").equals(
                            reader.getName())) {
                    object.setSupportedCamelPhase3(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SupportedCamelPhase3_SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SupportedCamelPhase3_SGSN").equals(
                            reader.getName())) {
                    object.setSupportedCamelPhase3_SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SRIMsrnCfActive").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SRIMsrnCfActive").equals(
                            reader.getName())) {
                    object.setSRIMsrnCfActive(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ZoneCodeStatusAtMsc").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ZoneCodeStatusAtMsc").equals(
                            reader.getName())) {
                    object.setZoneCodeStatusAtMsc(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UnsupTS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UnsupTS").equals(
                            reader.getName())) {
                    object.setUnsupTS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UnsupBSFor2G").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UnsupBSFor2G").equals(
                            reader.getName())) {
                    object.setUnsupBSFor2G(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UnsupBSFor3G").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UnsupBSFor3G").equals(
                            reader.getName())) {
                    object.setUnsupBSFor3G(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UnsupSS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UnsupSS").equals(
                            reader.getName())) {
                    object.setUnsupSS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ECATEGORYAtMsc").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ECATEGORYAtMsc").equals(
                            reader.getName())) {
                    object.setECATEGORYAtMsc(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SupportedCamelPhase4").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SupportedCamelPhase4").equals(
                            reader.getName())) {
                    object.setSupportedCamelPhase4(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SupportedCamelPhase4_SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SupportedCamelPhase4_SGSN").equals(
                            reader.getName())) {
                    object.setSupportedCamelPhase4_SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SuperChargerSupportedForGprs").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SuperChargerSupportedForGprs").equals(
                            reader.getName())) {
                    object.setSuperChargerSupportedForGprs(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BaocForVlrRestrict").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BaocForVlrRestrict").equals(
                            reader.getName())) {
                    object.setBaocForVlrRestrict(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "OCSI_MSC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "OCSI_MSC").equals(
                            reader.getName())) {
                    object.setOCSI_MSC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "OCSI_SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "OCSI_SGSN").equals(
                            reader.getName())) {
                    object.setOCSI_SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DCSI_MSC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DCSI_MSC").equals(
                            reader.getName())) {
                    object.setDCSI_MSC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DCSI_SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DCSI_SGSN").equals(
                            reader.getName())) {
                    object.setDCSI_SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VTCSI_MSC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VTCSI_MSC").equals(
                            reader.getName())) {
                    object.setVTCSI_MSC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VTCSI_SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VTCSI_SGSN").equals(
                            reader.getName())) {
                    object.setVTCSI_SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TCSI_MSC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TCSI_MSC").equals(
                            reader.getName())) {
                    object.setTCSI_MSC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TCSI_SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TCSI_SGSN").equals(
                            reader.getName())) {
                    object.setTCSI_SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MTSMSCSI_MSC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MTSMSCSI_MSC").equals(
                            reader.getName())) {
                    object.setMTSMSCSI_MSC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MTSMSCSI_SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MTSMSCSI_SGSN").equals(
                            reader.getName())) {
                    object.setMTSMSCSI_SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MGCSI_MSC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MGCSI_MSC").equals(
                            reader.getName())) {
                    object.setMGCSI_MSC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MGCSI_SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MGCSI_SGSN").equals(
                            reader.getName())) {
                    object.setMGCSI_SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PSIEnhancements_MSC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PSIEnhancements_MSC").equals(
                            reader.getName())) {
                    object.setPSIEnhancements_MSC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PSIEnhancements_SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PSIEnhancements_SGSN").equals(
                            reader.getName())) {
                    object.setPSIEnhancements_SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LMSI").equals(
                            reader.getName())) {
                    object.setLMSI(com.huawei.www.hss.Str1_4.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SgsnNum").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SgsnNum").equals(
                            reader.getName())) {
                    object.setSgsnNum(com.huawei.www.hss.Str1_8.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SgsnAddressType").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SgsnAddressType").equals(
                            reader.getName())) {
                    object.setSgsnAddressType(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SgsnAddress").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SgsnAddress").equals(
                            reader.getName())) {
                    object.setSgsnAddress(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SgsnInHplmn").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SgsnInHplmn").equals(
                            reader.getName())) {
                    object.setSgsnInHplmn(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MsPurgedForGprs").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MsPurgedForGprs").equals(
                            reader.getName())) {
                    object.setMsPurgedForGprs(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SgsnInHomeCountry").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SgsnInHomeCountry").equals(
                            reader.getName())) {
                    object.setSgsnInHomeCountry(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SgsnInArea").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SgsnInArea").equals(
                            reader.getName())) {
                    object.setSgsnInArea(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "RoamingRestrictInSgsnDueToUnsupportedFeature").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "RoamingRestrictInSgsnDueToUnsupportedFeature").equals(
                            reader.getName())) {
                    object.setRoamingRestrictInSgsnDueToUnsupportedFeature(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SgsnAreaRoamingRestrict").equals(reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SgsnAreaRoamingRestrict").equals(reader.getName())) {
                    object.setSgsnAreaRoamingRestrict(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "ODBarredForUnsupportedCamelForGprs").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "ODBarredForUnsupportedCamelForGprs").equals(
                            reader.getName())) {
                    object.setODBarredForUnsupportedCamelForGprs(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ZoneCodeStatusAtSgsn").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ZoneCodeStatusAtSgsn").equals(
                            reader.getName())) {
                    object.setZoneCodeStatusAtSgsn(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MCEFforGSM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MCEFforGSM").equals(
                            reader.getName())) {
                    object.setMCEFforGSM(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MCEFforGPRS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MCEFforGPRS").equals(
                            reader.getName())) {
                    object.setMCEFforGPRS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MNRF").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MNRF").equals(
                            reader.getName())) {
                    object.setMNRF(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MNRG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MNRG").equals(
                            reader.getName())) {
                    object.setMNRG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MNRRforGSM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MNRRforGSM").equals(
                            reader.getName())) {
                    object.setMNRRforGSM(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MNRRforGPRS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MNRRforGPRS").equals(
                            reader.getName())) {
                    object.setMNRRforGPRS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SupportedShortMessageMTPP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SupportedShortMessageMTPP").equals(
                            reader.getName())) {
                    object.setSupportedShortMessageMTPP(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SupportedShortMessageMOPP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SupportedShortMessageMOPP").equals(
                            reader.getName())) {
                    object.setSupportedShortMessageMOPP(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SC").equals(
                            reader.getName())) {
                    object.setSC(com.huawei.www.hss.Str1_8.Factory.parse(reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SCLINE2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SCLINE2").equals(
                            reader.getName())) {
                    object.setSCLINE2(com.huawei.www.hss.Str1_8.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BarredSSAccess").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BarredSSAccess").equals(
                            reader.getName())) {
                    object.setBarredSSAccess(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "BarredOutgoingEntertainmentCall").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "BarredOutgoingEntertainmentCall").equals(
                            reader.getName())) {
                    object.setBarredOutgoingEntertainmentCall(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "BarredOutgoingInformationCall").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "BarredOutgoingInformationCall").equals(
                            reader.getName())) {
                    object.setBarredOutgoingInformationCall(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SupGSMODB-BarredOutgoingInternationalCallExHC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SupGSMODB-BarredOutgoingInternationalCallExHC").equals(
                            reader.getName())) {
                    object.setSupGSMODBBarredOutgoingInternationalCallExHC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SupGSMODB-BarredOutgoingInternationalCall").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SupGSMODB-BarredOutgoingInternationalCall").equals(
                            reader.getName())) {
                    object.setSupGSMODBBarredOutgoingInternationalCall(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SupGSMODB-BarredAllOutgoingCall").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SupGSMODB-BarredAllOutgoingCall").equals(
                            reader.getName())) {
                    object.setSupGSMODBBarredAllOutgoingCall(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BarredAllECT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BarredAllECT").equals(
                            reader.getName())) {
                    object.setBarredAllECT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BarredChargeableECT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BarredChargeableECT").equals(
                            reader.getName())) {
                    object.setBarredChargeableECT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "BarredInternationalECT").equals(reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "BarredInternationalECT").equals(reader.getName())) {
                    object.setBarredInternationalECT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BarredInterzonalECT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BarredInterzonalECT").equals(
                            reader.getName())) {
                    object.setBarredInterzonalECT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BarredDECT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BarredDECT").equals(
                            reader.getName())) {
                    object.setBarredDECT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BarredMECT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BarredMECT").equals(
                            reader.getName())) {
                    object.setBarredMECT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SupGPRSODB-BarredAllOutgoingCall").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SupGPRSODB-BarredAllOutgoingCall").equals(
                            reader.getName())) {
                    object.setSupGPRSODBBarredAllOutgoingCall(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SupGPRSODB-BarredOutgoingInternationalCall").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SupGPRSODB-BarredOutgoingInternationalCall").equals(
                            reader.getName())) {
                    object.setSupGPRSODBBarredOutgoingInternationalCall(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SupGPRSODB-BarredOutgoingInternationalCallExHC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SupGPRSODB-BarredOutgoingInternationalCallExHC").equals(
                            reader.getName())) {
                    object.setSupGPRSODBBarredOutgoingInternationalCallExHC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "BarringofPacketOrientedServices").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "BarringofPacketOrientedServices").equals(
                            reader.getName())) {
                    object.setBarringofPacketOrientedServices(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "MSCSupportedLCSCapabilitySet1").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "MSCSupportedLCSCapabilitySet1").equals(
                            reader.getName())) {
                    object.setMSCSupportedLCSCapabilitySet1(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "MSCSupportedLCSCapabilitySet2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "MSCSupportedLCSCapabilitySet2").equals(
                            reader.getName())) {
                    object.setMSCSupportedLCSCapabilitySet2(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SGSNSupportedLCSCapabilitySet2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SGSNSupportedLCSCapabilitySet2").equals(
                            reader.getName())) {
                    object.setSGSNSupportedLCSCapabilitySet2(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ALS_DYN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ALS_DYN").equals(
                            reader.getName())) {
                    object.setALS_DYN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VVDN_DYN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VVDN_DYN").equals(
                            reader.getName())) {
                    object.setVVDN_DYN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DIMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DIMSI").equals(
                            reader.getName())) {
                    object.setDIMSI(com.huawei.www.hss.Str1_8.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ACTIMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ACTIMSI").equals(
                            reader.getName())) {
                    object.setACTIMSI(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GgsnNumber").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GgsnNumber").equals(
                            reader.getName())) {
                    object.setGgsnNumber(com.huawei.www.hss.Str0_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GgsnAddressType").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GgsnAddressType").equals(
                            reader.getName())) {
                    object.setGgsnAddressType(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GgsnAddress").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GgsnAddress").equals(
                            reader.getName())) {
                    object.setGgsnAddress(com.huawei.www.hss.Str0_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "longGroupIDSupported").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "longGroupIDSupported").equals(
                            reader.getName())) {
                    object.setLongGroupIDSupported(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "basicISTSupported").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "basicISTSupported").equals(
                            reader.getName())) {
                    object.setBasicISTSupported(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "istCommandSupported").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "istCommandSupported").equals(
                            reader.getName())) {
                    object.setIstCommandSupported(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "SuperChargerSupportedForGsm").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SuperChargerSupportedForGsm").equals(
                            reader.getName())) {
                    object.setSuperChargerSupportedForGsm(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMEI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMEI").equals(
                            reader.getName())) {
                    object.setIMEI(com.huawei.www.hss.Str0_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CSUPLTIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CSUPLTIME").equals(
                            reader.getName())) {
                    object.setCSUPLTIME(com.huawei.www.hss.Str1_30.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CSPURGETIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CSPURGETIME").equals(
                            reader.getName())) {
                    object.setCSPURGETIME(com.huawei.www.hss.Str1_30.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PSUPLTIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PSUPLTIME").equals(
                            reader.getName())) {
                    object.setPSUPLTIME(com.huawei.www.hss.Str1_30.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PSPURGETIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PSPURGETIME").equals(
                            reader.getName())) {
                    object.setPSPURGETIME(com.huawei.www.hss.Str1_30.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAINIMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAINIMSI").equals(
                            reader.getName())) {
                    object.setMAINIMSI(com.huawei.www.hss.Str3_8.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MIMSI_SMS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MIMSI_SMS").equals(
                            reader.getName())) {
                    object.setMIMSI_SMS(com.huawei.www.hss.Int1_9.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MIMSI_VOBB").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MIMSI_VOBB").equals(
                            reader.getName())) {
                    object.setMIMSI_VOBB(com.huawei.www.hss.Int1_9.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MIMSITYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MIMSITYPE").equals(
                            reader.getName())) {
                    object.setMIMSITYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LSFLAG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LSFLAG").equals(
                            reader.getName())) {
                    object.setLSFLAG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "camelInduceBarringSMS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "camelInduceBarringSMS").equals(reader.getName())) {
                    object.setCamelInduceBarringSMS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RoamBaocTs11").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RoamBaocTs11").equals(
                            reader.getName())) {
                    object.setRoamBaocTs11(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MTRF_SUPPORTED").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MTRF_SUPPORTED").equals(
                            reader.getName())) {
                    object.setMTRF_SUPPORTED(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "URRP_MME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "URRP_MME").equals(
                            reader.getName())) {
                    object.setURRP_MME(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "URRP_SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "URRP_SGSN").equals(
                            reader.getName())) {
                    object.setURRP_SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TAI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TAI").equals(
                            reader.getName())) {
                    object.setTAI(com.huawei.www.hss.Str9_10.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VLR_NUM_SAI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VLR_NUM_SAI").equals(
                            reader.getName())) {
                    object.setVLR_NUM_SAI(com.huawei.www.hss.Str0_8.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TIME_STAMP_SAI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TIME_STAMP_SAI").equals(
                            reader.getName())) {
                    object.setTIME_STAMP_SAI(com.huawei.www.hss.Str1_30.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MMEHOST").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MMEHOST").equals(
                            reader.getName())) {
                    object.setMMEHOST(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MMEREALM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MMEREALM").equals(
                            reader.getName())) {
                    object.setMMEREALM(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "M-RATTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "M-RATTYPE").equals(
                            reader.getName())) {
                    object.setMRATTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "M-VPLMN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "M-VPLMN").equals(
                            reader.getName())) {
                    object.setMVPLMN(com.huawei.www.hss.Str1_9.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PURGEDONMME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PURGEDONMME").equals(
                            reader.getName())) {
                    object.setPURGEDONMME(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "MME-UpdateLocation-Time").equals(reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "MME-UpdateLocation-Time").equals(reader.getName())) {
                    object.setMMEUpdateLocationTime(com.huawei.www.hss.Str1_35.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MME-FeatureList").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MME-FeatureList").equals(
                            reader.getName())) {
                    object.setMMEFeatureList(com.huawei.www.hss.Str1_9.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "M-LastIDRorDSRSUCC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "M-LastIDRorDSRSUCC").equals(
                            reader.getName())) {
                    object.setMLastIDRorDSRSUCC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "M-Single-Registration-Indication").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "M-Single-Registration-Indication").equals(
                            reader.getName())) {
                    object.setMSingleRegistrationIndication(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "M-Skip-Subscriber-Data-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "M-Skip-Subscriber-Data-Indicator").equals(
                            reader.getName())) {
                    object.setMSkipSubscriberDataIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "M-GPRS-Subscription-Data-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "M-GPRS-Subscription-Data-Indicator").equals(
                            reader.getName())) {
                    object.setMGPRSSubscriptionDataIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "M-Node-Type-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "M-Node-Type-Indicator").equals(reader.getName())) {
                    object.setMNodeTypeIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "M-Initial-Attach-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "M-Initial-Attach-Indicator").equals(
                            reader.getName())) {
                    object.setMInitialAttachIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "M-PS-LCS-Not-Supported-By-UE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "M-PS-LCS-Not-Supported-By-UE").equals(
                            reader.getName())) {
                    object.setMPSLCSNotSupportedByUE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "M-IMEI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "M-IMEI").equals(
                            reader.getName())) {
                    object.setMIMEI(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "M-IMEISV").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "M-IMEISV").equals(
                            reader.getName())) {
                    object.setMIMEISV(com.huawei.www.hss.Str1_2.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SGSNHOST").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SGSNHOST").equals(
                            reader.getName())) {
                    object.setSGSNHOST(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SGSNREALM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SGSNREALM").equals(
                            reader.getName())) {
                    object.setSGSNREALM(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SGSNNUMBER").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SGSNNUMBER").equals(
                            reader.getName())) {
                    object.setSGSNNUMBER(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S-RATTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S-RATTYPE").equals(
                            reader.getName())) {
                    object.setSRATTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S-VPLMN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S-VPLMN").equals(
                            reader.getName())) {
                    object.setSVPLMN(com.huawei.www.hss.Str1_9.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PURGEDONSGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PURGEDONSGSN").equals(
                            reader.getName())) {
                    object.setPURGEDONSGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S-AREARESTRICT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S-AREARESTRICT").equals(
                            reader.getName())) {
                    object.setSAREARESTRICT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "S4SGSN-UpdateLocation-Time").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "S4SGSN-UpdateLocation-Time").equals(
                            reader.getName())) {
                    object.setS4SGSNUpdateLocationTime(com.huawei.www.hss.Str1_35.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S4SGSN-FeatureList").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S4SGSN-FeatureList").equals(
                            reader.getName())) {
                    object.setS4SGSNFeatureList(com.huawei.www.hss.Str1_9.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S-LastIDRorDSRSUCC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S-LastIDRorDSRSUCC").equals(
                            reader.getName())) {
                    object.setSLastIDRorDSRSUCC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "S-Single-Registration-Indication").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "S-Single-Registration-Indication").equals(
                            reader.getName())) {
                    object.setSSingleRegistrationIndication(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "S-Skip-Subscriber-Data-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "S-Skip-Subscriber-Data-Indicator").equals(
                            reader.getName())) {
                    object.setSSkipSubscriberDataIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "S-GPRS-Subscription-Data-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "S-GPRS-Subscription-Data-Indicator").equals(
                            reader.getName())) {
                    object.setSGPRSSubscriptionDataIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S-Node-Type-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "S-Node-Type-Indicator").equals(reader.getName())) {
                    object.setSNodeTypeIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "S-Initial-Attach-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "S-Initial-Attach-Indicator").equals(
                            reader.getName())) {
                    object.setSInitialAttachIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "S-PS-LCS-Not-Supported-By-UE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "S-PS-LCS-Not-Supported-By-UE").equals(
                            reader.getName())) {
                    object.setSPSLCSNotSupportedByUE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S-IMEI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S-IMEI").equals(
                            reader.getName())) {
                    object.setSIMEI(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "S-IMEISV").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "S-IMEISV").equals(
                            reader.getName())) {
                    object.setSIMEISV(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EPSDYNCNTXID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EPSDYNCNTXID").equals(
                            reader.getName())) {
                    object.setEPSDYNCNTXID(com.huawei.www.hss.Int1_50.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EPSDYNAPN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EPSDYNAPN").equals(
                            reader.getName())) {
                    object.setEPSDYNAPN(com.huawei.www.hss.Str1_63.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EPSDYNPDNGWHOST").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EPSDYNPDNGWHOST").equals(
                            reader.getName())) {
                    object.setEPSDYNPDNGWHOST(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EPSDYNPDNGWREALM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EPSDYNPDNGWREALM").equals(
                            reader.getName())) {
                    object.setEPSDYNPDNGWREALM(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EPSDYNPDNGWIPV4").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EPSDYNPDNGWIPV4").equals(
                            reader.getName())) {
                    object.setEPSDYNPDNGWIPV4(com.huawei.www.hss.Str7_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EPSDYNPDNGWIPV6").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EPSDYNPDNGWIPV6").equals(
                            reader.getName())) {
                    object.setEPSDYNPDNGWIPV6(com.huawei.www.hss.Str1_40.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EPSDYNWILDCARDFLAG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EPSDYNWILDCARDFLAG").equals(
                            reader.getName())) {
                    object.setEPSDYNWILDCARDFLAG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EPSDYNVNI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EPSDYNVNI").equals(
                            reader.getName())) {
                    object.setEPSDYNVNI(com.huawei.www.hss.Str1_63.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VNI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VNI").equals(
                            reader.getName())) {
                    object.setVNI(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "REGSTATUS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "REGSTATUS").equals(
                            reader.getName())) {
                    object.setREGSTATUS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ACCESSNETID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ACCESSNETID").equals(
                            reader.getName())) {
                    object.setACCESSNETID(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TGPPAAASERVERNAME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TGPPAAASERVERNAME").equals(
                            reader.getName())) {
                    object.setTGPPAAASERVERNAME(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TGPPAAASERVERREALM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TGPPAAASERVERREALM").equals(
                            reader.getName())) {
                    object.setTGPPAAASERVERREALM(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TGPP2MEID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TGPP2MEID").equals(
                            reader.getName())) {
                    object.setTGPP2MEID(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AAA-IMEI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AAA-IMEI").equals(
                            reader.getName())) {
                    object.setAAAIMEI(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AAA-IMEISV").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AAA-IMEISV").equals(
                            reader.getName())) {
                    object.setAAAIMEISV(com.huawei.www.hss.Str1_2.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "Server-Assignment-Time").equals(reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "Server-Assignment-Time").equals(reader.getName())) {
                    object.setServerAssignmentTime(com.huawei.www.hss.Str1_35.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "IMS-VO-PS-Sessions-Supported").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "IMS-VO-PS-Sessions-Supported").equals(
                            reader.getName())) {
                    object.setIMSVOPSSessionsSupported(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UE-SRVCC-Capability").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UE-SRVCC-Capability").equals(
                            reader.getName())) {
                    object.setUESRVCCCapability(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "IMS-VO-PS-Sessions-Supported-S4SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "IMS-VO-PS-Sessions-Supported-S4SGSN").equals(
                            reader.getName())) {
                    object.setIMSVOPSSessionsSupportedS4SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "UE-SRVCC-Capability-S4SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "UE-SRVCC-Capability-S4SGSN").equals(
                            reader.getName())) {
                    object.setUESRVCCCapabilityS4SGSN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UE-Register-AtIMS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UE-Register-AtIMS").equals(
                            reader.getName())) {
                    object.setUERegisterAtIMS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IP_SM_GW").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IP_SM_GW").equals(
                            reader.getName())) {
                    object.setIP_SM_GW(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MCEFforIP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MCEFforIP").equals(
                            reader.getName())) {
                    object.setMCEFforIP(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UNRI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UNRI").equals(
                            reader.getName())) {
                    object.setUNRI(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UNRR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UNRR").equals(
                            reader.getName())) {
                    object.setUNRR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VGMLC-MME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VGMLC-MME").equals(
                            reader.getName())) {
                    object.setVGMLCMME(com.huawei.www.hss.Str7_39.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VGMLC-SGSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VGMLC-SGSN").equals(
                            reader.getName())) {
                    object.setVGMLCSGSN(com.huawei.www.hss.Str7_39.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSSF").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSSF").equals(
                            reader.getName())) {
                    object.setIMSSF(com.huawei.www.hss.Str1_8.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CS_V_GMLC_ADDTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CS_V_GMLC_ADDTYPE").equals(
                            reader.getName())) {
                    object.setCS_V_GMLC_ADDTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CS_V_GMLC_ADDRESS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CS_V_GMLC_ADDRESS").equals(
                            reader.getName())) {
                    object.setCS_V_GMLC_ADDRESS(com.huawei.www.hss.Str1_39.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PS_V_GMLC_ADDTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PS_V_GMLC_ADDTYPE").equals(
                            reader.getName())) {
                    object.setPS_V_GMLC_ADDTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PS_V_GMLC_ADDRESS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PS_V_GMLC_ADDRESS").equals(
                            reader.getName())) {
                    object.setPS_V_GMLC_ADDRESS(com.huawei.www.hss.Str1_39.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ACTIVE_IMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ACTIVE_IMSI").equals(
                            reader.getName())) {
                    object.setACTIVE_IMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DataRef").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DataRef").equals(
                            reader.getName())) {
                    object.setDataRef(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AS_Host_Name").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AS_Host_Name").equals(
                            reader.getName())) {
                    object.setAS_Host_Name(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AS_Realm_Name").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AS_Realm_Name").equals(
                            reader.getName())) {
                    object.setAS_Realm_Name(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CS-MSISDN-LESS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CS-MSISDN-LESS").equals(
                            reader.getName())) {
                    object.setCSMSISDNLESS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PS-MSISDN-LESS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PS-MSISDN-LESS").equals(
                            reader.getName())) {
                    object.setPSMSISDNLESS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CSRATTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CSRATTYPE").equals(
                            reader.getName())) {
                    object.setCSRATTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PSRATTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PSRATTYPE").equals(
                            reader.getName())) {
                    object.setPSRATTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CsUplStatus").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CsUplStatus").equals(
                            reader.getName())) {
                    object.setCsUplStatus(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PsUplStatus").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PsUplStatus").equals(
                            reader.getName())) {
                    object.setPsUplStatus(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
