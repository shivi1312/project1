/**
 * BasicInfo_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  BasicInfo_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class BasicInfo_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = BasicInfo_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for HLRSN
     */
    protected com.huawei.www.hss.Int0_254 localHLRSN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localHLRSNTracker = false;

    /**
     * field for IMSI
     */
    protected com.huawei.www.hss.Str6_15 localIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSITracker = false;

    /**
     * field for CardType
     */
    protected com.huawei.www.hss._EnumType localCardType;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCardTypeTracker = false;

    /**
     * field for NAM
     */
    protected com.huawei.www.hss._EnumType localNAM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localNAMTracker = false;

    /**
     * field for CATEGORY
     */
    protected com.huawei.www.hss._EnumType localCATEGORY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCATEGORYTracker = false;

    /**
     * field for SMDP
     */
    protected com.huawei.www.hss._EnumType localSMDP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSMDPTracker = false;

    /**
     * field for IsdnList
     * This was an Array!
     */
    protected com.huawei.www.hss.IsdnList_type0[] localIsdnList;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIsdnListTracker = false;

    /**
     * field for TeleserviceList
     */
    protected com.huawei.www.hss.TeleserviceList_type0 localTeleserviceList;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTeleserviceListTracker = false;

    /**
     * field for BearerServiceList
     */
    protected com.huawei.www.hss.BearerServiceList_type0 localBearerServiceList;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBearerServiceListTracker = false;

    public boolean isHLRSNSpecified() {
        return localHLRSNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_254
     */
    public com.huawei.www.hss.Int0_254 getHLRSN() {
        return localHLRSN;
    }

    /**
     * Auto generated setter method
     * @param param HLRSN
     */
    public void setHLRSN(com.huawei.www.hss.Int0_254 param) {
        localHLRSNTracker = param != null;

        this.localHLRSN = param;
    }

    public boolean isIMSISpecified() {
        return localIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getIMSI() {
        return localIMSI;
    }

    /**
     * Auto generated setter method
     * @param param IMSI
     */
    public void setIMSI(com.huawei.www.hss.Str6_15 param) {
        localIMSITracker = param != null;

        this.localIMSI = param;
    }

    public boolean isCardTypeSpecified() {
        return localCardTypeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCardType() {
        return localCardType;
    }

    /**
     * Auto generated setter method
     * @param param CardType
     */
    public void setCardType(com.huawei.www.hss._EnumType param) {
        localCardTypeTracker = param != null;

        this.localCardType = param;
    }

    public boolean isNAMSpecified() {
        return localNAMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getNAM() {
        return localNAM;
    }

    /**
     * Auto generated setter method
     * @param param NAM
     */
    public void setNAM(com.huawei.www.hss._EnumType param) {
        localNAMTracker = param != null;

        this.localNAM = param;
    }

    public boolean isCATEGORYSpecified() {
        return localCATEGORYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCATEGORY() {
        return localCATEGORY;
    }

    /**
     * Auto generated setter method
     * @param param CATEGORY
     */
    public void setCATEGORY(com.huawei.www.hss._EnumType param) {
        localCATEGORYTracker = param != null;

        this.localCATEGORY = param;
    }

    public boolean isSMDPSpecified() {
        return localSMDPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSMDP() {
        return localSMDP;
    }

    /**
     * Auto generated setter method
     * @param param SMDP
     */
    public void setSMDP(com.huawei.www.hss._EnumType param) {
        localSMDPTracker = param != null;

        this.localSMDP = param;
    }

    public boolean isIsdnListSpecified() {
        return localIsdnListTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.IsdnList_type0[]
     */
    public com.huawei.www.hss.IsdnList_type0[] getIsdnList() {
        return localIsdnList;
    }

    /**
     * validate the array for IsdnList
     */
    protected void validateIsdnList(com.huawei.www.hss.IsdnList_type0[] param) {
    }

    /**
     * Auto generated setter method
     * @param param IsdnList
     */
    public void setIsdnList(com.huawei.www.hss.IsdnList_type0[] param) {
        validateIsdnList(param);

        localIsdnListTracker = param != null;

        this.localIsdnList = param;
    }

    /**
     * Auto generated add method for the array for convenience
     * @param param com.huawei.www.hss.IsdnList_type0
     */
    public void addIsdnList(com.huawei.www.hss.IsdnList_type0 param) {
        if (localIsdnList == null) {
            localIsdnList = new com.huawei.www.hss.IsdnList_type0[] {  };
        }

        //update the setting tracker
        localIsdnListTracker = true;

        java.util.List list = org.apache.axis2.databinding.utils.ConverterUtil.toList(localIsdnList);
        list.add(param);
        this.localIsdnList = (com.huawei.www.hss.IsdnList_type0[]) list.toArray(new com.huawei.www.hss.IsdnList_type0[list.size()]);
    }

    public boolean isTeleserviceListSpecified() {
        return localTeleserviceListTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.TeleserviceList_type0
     */
    public com.huawei.www.hss.TeleserviceList_type0 getTeleserviceList() {
        return localTeleserviceList;
    }

    /**
     * Auto generated setter method
     * @param param TeleserviceList
     */
    public void setTeleserviceList(
        com.huawei.www.hss.TeleserviceList_type0 param) {
        localTeleserviceListTracker = param != null;

        this.localTeleserviceList = param;
    }

    public boolean isBearerServiceListSpecified() {
        return localBearerServiceListTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.BearerServiceList_type0
     */
    public com.huawei.www.hss.BearerServiceList_type0 getBearerServiceList() {
        return localBearerServiceList;
    }

    /**
     * Auto generated setter method
     * @param param BearerServiceList
     */
    public void setBearerServiceList(
        com.huawei.www.hss.BearerServiceList_type0 param) {
        localBearerServiceListTracker = param != null;

        this.localBearerServiceList = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":BasicInfo_type0", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "BasicInfo_type0", xmlWriter);
            }
        }

        if (localHLRSNTracker) {
            if (localHLRSN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "HLRSN cannot be null!!");
            }

            localHLRSN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "HLRSN"), xmlWriter);
        }

        if (localIMSITracker) {
            if (localIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMSI cannot be null!!");
            }

            localIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMSI"), xmlWriter);
        }

        if (localCardTypeTracker) {
            if (localCardType == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CardType cannot be null!!");
            }

            localCardType.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CardType"), xmlWriter);
        }

        if (localNAMTracker) {
            if (localNAM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "NAM cannot be null!!");
            }

            localNAM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "NAM"), xmlWriter);
        }

        if (localCATEGORYTracker) {
            if (localCATEGORY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CATEGORY cannot be null!!");
            }

            localCATEGORY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CATEGORY"), xmlWriter);
        }

        if (localSMDPTracker) {
            if (localSMDP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SMDP cannot be null!!");
            }

            localSMDP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SMDP"), xmlWriter);
        }

        if (localIsdnListTracker) {
            if (localIsdnList != null) {
                for (int i = 0; i < localIsdnList.length; i++) {
                    if (localIsdnList[i] != null) {
                        localIsdnList[i].serialize(new javax.xml.namespace.QName(
                                "http://www.huawei.com/HSS", "IsdnList"),
                            xmlWriter);
                    } else {
                        // we don't have to do any thing since minOccures is zero
                    }
                }
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                    "IsdnList cannot be null!!");
            }
        }

        if (localTeleserviceListTracker) {
            if (localTeleserviceList == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TeleserviceList cannot be null!!");
            }

            localTeleserviceList.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TeleserviceList"), xmlWriter);
        }

        if (localBearerServiceListTracker) {
            if (localBearerServiceList == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BearerServiceList cannot be null!!");
            }

            localBearerServiceList.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BearerServiceList"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static BasicInfo_type0 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            BasicInfo_type0 object = new BasicInfo_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"BasicInfo_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (BasicInfo_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                java.util.ArrayList list7 = new java.util.ArrayList();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "HLRSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "HLRSN").equals(
                            reader.getName())) {
                    object.setHLRSN(com.huawei.www.hss.Int0_254.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSI").equals(
                            reader.getName())) {
                    object.setIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CardType").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CardType").equals(
                            reader.getName())) {
                    object.setCardType(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "NAM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "NAM").equals(
                            reader.getName())) {
                    object.setNAM(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CATEGORY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CATEGORY").equals(
                            reader.getName())) {
                    object.setCATEGORY(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SMDP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SMDP").equals(
                            reader.getName())) {
                    object.setSMDP(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IsdnList").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IsdnList").equals(
                            reader.getName())) {
                    // Process the array and step past its final element's end.
                    list7.add(com.huawei.www.hss.IsdnList_type0.Factory.parse(
                            reader));

                    //loop until we find a start element that is not part of this array
                    boolean loopDone7 = false;

                    while (!loopDone7) {
                        // We should be at the end element, but make sure
                        while (!reader.isEndElement())
                            reader.next();

                        // Step out of this element
                        reader.next();

                        // Step to next element event.
                        while (!reader.isStartElement() &&
                                !reader.isEndElement())
                            reader.next();

                        if (reader.isEndElement()) {
                            //two continuous end elements means we are exiting the xml structure
                            loopDone7 = true;
                        } else {
                            if (new javax.xml.namespace.QName(
                                        "http://www.huawei.com/HSS", "IsdnList").equals(
                                        reader.getName())) {
                                list7.add(com.huawei.www.hss.IsdnList_type0.Factory.parse(
                                        reader));
                            } else {
                                loopDone7 = true;
                            }
                        }
                    }

                    // call the converter utility  to convert and set the array
                    object.setIsdnList((com.huawei.www.hss.IsdnList_type0[]) org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                            com.huawei.www.hss.IsdnList_type0.class, list7));
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TeleserviceList").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TeleserviceList").equals(
                            reader.getName())) {
                    object.setTeleserviceList(com.huawei.www.hss.TeleserviceList_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BearerServiceList").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BearerServiceList").equals(
                            reader.getName())) {
                    object.setBearerServiceList(com.huawei.www.hss.BearerServiceList_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
