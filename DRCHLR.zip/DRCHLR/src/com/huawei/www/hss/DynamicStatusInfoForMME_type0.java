/**
 * DynamicStatusInfoForMME_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  DynamicStatusInfoForMME_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class DynamicStatusInfoForMME_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = DynamicStatusInfoForMME_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for MMEHOST
     */
    protected com.huawei.www.hss.Str1_128 localMMEHOST;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMMEHOSTTracker = false;

    /**
     * field for MMEREALM
     */
    protected com.huawei.www.hss.Str1_128 localMMEREALM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMMEREALMTracker = false;

    /**
     * field for RATTYPE
     */
    protected com.huawei.www.hss._EnumType localRATTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRATTYPETracker = false;

    /**
     * field for MVPLMN
     */
    protected com.huawei.www.hss.Str1_128 localMVPLMN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMVPLMNTracker = false;

    /**
     * field for PURGEDONMME
     */
    protected com.huawei.www.hss._EnumType localPURGEDONMME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPURGEDONMMETracker = false;

    /**
     * field for MMEUpdateLocationTime
     */
    protected com.huawei.www.hss.Str1_60 localMMEUpdateLocationTime;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMMEUpdateLocationTimeTracker = false;

    /**
     * field for MMEFeatureList
     */
    protected com.huawei.www.hss.Str1_128 localMMEFeatureList;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMMEFeatureListTracker = false;

    /**
     * field for LastIDRorDSRFailed
     */
    protected com.huawei.www.hss._EnumType localLastIDRorDSRFailed;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLastIDRorDSRFailedTracker = false;

    /**
     * field for SingleRegistrationIndication
     */
    protected com.huawei.www.hss._EnumType localSingleRegistrationIndication;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSingleRegistrationIndicationTracker = false;

    /**
     * field for SkipSubscriberDataIndicator
     */
    protected com.huawei.www.hss._EnumType localSkipSubscriberDataIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSkipSubscriberDataIndicatorTracker = false;

    /**
     * field for GPRSSubscriptionDataIndicator
     */
    protected com.huawei.www.hss._EnumType localGPRSSubscriptionDataIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGPRSSubscriptionDataIndicatorTracker = false;

    /**
     * field for NodeTypeIndicator
     */
    protected com.huawei.www.hss._EnumType localNodeTypeIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localNodeTypeIndicatorTracker = false;

    /**
     * field for InitialAttachIndicator
     */
    protected com.huawei.www.hss._EnumType localInitialAttachIndicator;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localInitialAttachIndicatorTracker = false;

    /**
     * field for PSLCSNotSupportedByUE
     */
    protected com.huawei.www.hss._EnumType localPSLCSNotSupportedByUE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPSLCSNotSupportedByUETracker = false;

    /**
     * field for MIMEI
     */
    protected com.huawei.www.hss.Str1_60 localMIMEI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMIMEITracker = false;

    /**
     * field for MIMEISV
     */
    protected com.huawei.www.hss.Str1_60 localMIMEISV;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMIMEISVTracker = false;

    /**
     * field for MMEFeatureList2
     */
    protected com.huawei.www.hss.Str1_9 localMMEFeatureList2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMMEFeatureList2Tracker = false;

    /**
     * field for IMSVOPSSessionsSupportedMME
     */
    protected com.huawei.www.hss._EnumType localIMSVOPSSessionsSupportedMME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSVOPSSessionsSupportedMMETracker = false;

    /**
     * field for UESRVCCCapability
     */
    protected com.huawei.www.hss._EnumType localUESRVCCCapability;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUESRVCCCapabilityTracker = false;

    /**
     * field for VGMLCMME
     */
    protected com.huawei.www.hss.Str1_60 localVGMLCMME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVGMLCMMETracker = false;

    public boolean isMMEHOSTSpecified() {
        return localMMEHOSTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getMMEHOST() {
        return localMMEHOST;
    }

    /**
     * Auto generated setter method
     * @param param MMEHOST
     */
    public void setMMEHOST(com.huawei.www.hss.Str1_128 param) {
        localMMEHOSTTracker = param != null;

        this.localMMEHOST = param;
    }

    public boolean isMMEREALMSpecified() {
        return localMMEREALMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getMMEREALM() {
        return localMMEREALM;
    }

    /**
     * Auto generated setter method
     * @param param MMEREALM
     */
    public void setMMEREALM(com.huawei.www.hss.Str1_128 param) {
        localMMEREALMTracker = param != null;

        this.localMMEREALM = param;
    }

    public boolean isRATTYPESpecified() {
        return localRATTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRATTYPE() {
        return localRATTYPE;
    }

    /**
     * Auto generated setter method
     * @param param RATTYPE
     */
    public void setRATTYPE(com.huawei.www.hss._EnumType param) {
        localRATTYPETracker = param != null;

        this.localRATTYPE = param;
    }

    public boolean isMVPLMNSpecified() {
        return localMVPLMNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getMVPLMN() {
        return localMVPLMN;
    }

    /**
     * Auto generated setter method
     * @param param MVPLMN
     */
    public void setMVPLMN(com.huawei.www.hss.Str1_128 param) {
        localMVPLMNTracker = param != null;

        this.localMVPLMN = param;
    }

    public boolean isPURGEDONMMESpecified() {
        return localPURGEDONMMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPURGEDONMME() {
        return localPURGEDONMME;
    }

    /**
     * Auto generated setter method
     * @param param PURGEDONMME
     */
    public void setPURGEDONMME(com.huawei.www.hss._EnumType param) {
        localPURGEDONMMETracker = param != null;

        this.localPURGEDONMME = param;
    }

    public boolean isMMEUpdateLocationTimeSpecified() {
        return localMMEUpdateLocationTimeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_60
     */
    public com.huawei.www.hss.Str1_60 getMMEUpdateLocationTime() {
        return localMMEUpdateLocationTime;
    }

    /**
     * Auto generated setter method
     * @param param MMEUpdateLocationTime
     */
    public void setMMEUpdateLocationTime(com.huawei.www.hss.Str1_60 param) {
        localMMEUpdateLocationTimeTracker = param != null;

        this.localMMEUpdateLocationTime = param;
    }

    public boolean isMMEFeatureListSpecified() {
        return localMMEFeatureListTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getMMEFeatureList() {
        return localMMEFeatureList;
    }

    /**
     * Auto generated setter method
     * @param param MMEFeatureList
     */
    public void setMMEFeatureList(com.huawei.www.hss.Str1_128 param) {
        localMMEFeatureListTracker = param != null;

        this.localMMEFeatureList = param;
    }

    public boolean isLastIDRorDSRFailedSpecified() {
        return localLastIDRorDSRFailedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getLastIDRorDSRFailed() {
        return localLastIDRorDSRFailed;
    }

    /**
     * Auto generated setter method
     * @param param LastIDRorDSRFailed
     */
    public void setLastIDRorDSRFailed(com.huawei.www.hss._EnumType param) {
        localLastIDRorDSRFailedTracker = param != null;

        this.localLastIDRorDSRFailed = param;
    }

    public boolean isSingleRegistrationIndicationSpecified() {
        return localSingleRegistrationIndicationTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSingleRegistrationIndication() {
        return localSingleRegistrationIndication;
    }

    /**
     * Auto generated setter method
     * @param param SingleRegistrationIndication
     */
    public void setSingleRegistrationIndication(
        com.huawei.www.hss._EnumType param) {
        localSingleRegistrationIndicationTracker = param != null;

        this.localSingleRegistrationIndication = param;
    }

    public boolean isSkipSubscriberDataIndicatorSpecified() {
        return localSkipSubscriberDataIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSkipSubscriberDataIndicator() {
        return localSkipSubscriberDataIndicator;
    }

    /**
     * Auto generated setter method
     * @param param SkipSubscriberDataIndicator
     */
    public void setSkipSubscriberDataIndicator(
        com.huawei.www.hss._EnumType param) {
        localSkipSubscriberDataIndicatorTracker = param != null;

        this.localSkipSubscriberDataIndicator = param;
    }

    public boolean isGPRSSubscriptionDataIndicatorSpecified() {
        return localGPRSSubscriptionDataIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getGPRSSubscriptionDataIndicator() {
        return localGPRSSubscriptionDataIndicator;
    }

    /**
     * Auto generated setter method
     * @param param GPRSSubscriptionDataIndicator
     */
    public void setGPRSSubscriptionDataIndicator(
        com.huawei.www.hss._EnumType param) {
        localGPRSSubscriptionDataIndicatorTracker = param != null;

        this.localGPRSSubscriptionDataIndicator = param;
    }

    public boolean isNodeTypeIndicatorSpecified() {
        return localNodeTypeIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getNodeTypeIndicator() {
        return localNodeTypeIndicator;
    }

    /**
     * Auto generated setter method
     * @param param NodeTypeIndicator
     */
    public void setNodeTypeIndicator(com.huawei.www.hss._EnumType param) {
        localNodeTypeIndicatorTracker = param != null;

        this.localNodeTypeIndicator = param;
    }

    public boolean isInitialAttachIndicatorSpecified() {
        return localInitialAttachIndicatorTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getInitialAttachIndicator() {
        return localInitialAttachIndicator;
    }

    /**
     * Auto generated setter method
     * @param param InitialAttachIndicator
     */
    public void setInitialAttachIndicator(com.huawei.www.hss._EnumType param) {
        localInitialAttachIndicatorTracker = param != null;

        this.localInitialAttachIndicator = param;
    }

    public boolean isPSLCSNotSupportedByUESpecified() {
        return localPSLCSNotSupportedByUETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPSLCSNotSupportedByUE() {
        return localPSLCSNotSupportedByUE;
    }

    /**
     * Auto generated setter method
     * @param param PSLCSNotSupportedByUE
     */
    public void setPSLCSNotSupportedByUE(com.huawei.www.hss._EnumType param) {
        localPSLCSNotSupportedByUETracker = param != null;

        this.localPSLCSNotSupportedByUE = param;
    }

    public boolean isMIMEISpecified() {
        return localMIMEITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_60
     */
    public com.huawei.www.hss.Str1_60 getMIMEI() {
        return localMIMEI;
    }

    /**
     * Auto generated setter method
     * @param param MIMEI
     */
    public void setMIMEI(com.huawei.www.hss.Str1_60 param) {
        localMIMEITracker = param != null;

        this.localMIMEI = param;
    }

    public boolean isMIMEISVSpecified() {
        return localMIMEISVTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_60
     */
    public com.huawei.www.hss.Str1_60 getMIMEISV() {
        return localMIMEISV;
    }

    /**
     * Auto generated setter method
     * @param param MIMEISV
     */
    public void setMIMEISV(com.huawei.www.hss.Str1_60 param) {
        localMIMEISVTracker = param != null;

        this.localMIMEISV = param;
    }

    public boolean isMMEFeatureList2Specified() {
        return localMMEFeatureList2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_9
     */
    public com.huawei.www.hss.Str1_9 getMMEFeatureList2() {
        return localMMEFeatureList2;
    }

    /**
     * Auto generated setter method
     * @param param MMEFeatureList2
     */
    public void setMMEFeatureList2(com.huawei.www.hss.Str1_9 param) {
        localMMEFeatureList2Tracker = param != null;

        this.localMMEFeatureList2 = param;
    }

    public boolean isIMSVOPSSessionsSupportedMMESpecified() {
        return localIMSVOPSSessionsSupportedMMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getIMSVOPSSessionsSupportedMME() {
        return localIMSVOPSSessionsSupportedMME;
    }

    /**
     * Auto generated setter method
     * @param param IMSVOPSSessionsSupportedMME
     */
    public void setIMSVOPSSessionsSupportedMME(
        com.huawei.www.hss._EnumType param) {
        localIMSVOPSSessionsSupportedMMETracker = param != null;

        this.localIMSVOPSSessionsSupportedMME = param;
    }

    public boolean isUESRVCCCapabilitySpecified() {
        return localUESRVCCCapabilityTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUESRVCCCapability() {
        return localUESRVCCCapability;
    }

    /**
     * Auto generated setter method
     * @param param UESRVCCCapability
     */
    public void setUESRVCCCapability(com.huawei.www.hss._EnumType param) {
        localUESRVCCCapabilityTracker = param != null;

        this.localUESRVCCCapability = param;
    }

    public boolean isVGMLCMMESpecified() {
        return localVGMLCMMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_60
     */
    public com.huawei.www.hss.Str1_60 getVGMLCMME() {
        return localVGMLCMME;
    }

    /**
     * Auto generated setter method
     * @param param VGMLCMME
     */
    public void setVGMLCMME(com.huawei.www.hss.Str1_60 param) {
        localVGMLCMMETracker = param != null;

        this.localVGMLCMME = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":DynamicStatusInfoForMME_type0",
                    xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "DynamicStatusInfoForMME_type0", xmlWriter);
            }
        }

        if (localMMEHOSTTracker) {
            if (localMMEHOST == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MMEHOST cannot be null!!");
            }

            localMMEHOST.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MMEHOST"), xmlWriter);
        }

        if (localMMEREALMTracker) {
            if (localMMEREALM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MMEREALM cannot be null!!");
            }

            localMMEREALM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MMEREALM"), xmlWriter);
        }

        if (localRATTYPETracker) {
            if (localRATTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RATTYPE cannot be null!!");
            }

            localRATTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RATTYPE"), xmlWriter);
        }

        if (localMVPLMNTracker) {
            if (localMVPLMN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-VPLMN cannot be null!!");
            }

            localMVPLMN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "M-VPLMN"), xmlWriter);
        }

        if (localPURGEDONMMETracker) {
            if (localPURGEDONMME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PURGEDONMME cannot be null!!");
            }

            localPURGEDONMME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PURGEDONMME"), xmlWriter);
        }

        if (localMMEUpdateLocationTimeTracker) {
            if (localMMEUpdateLocationTime == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MME-UpdateLocation-Time cannot be null!!");
            }

            localMMEUpdateLocationTime.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MME-UpdateLocation-Time"),
                xmlWriter);
        }

        if (localMMEFeatureListTracker) {
            if (localMMEFeatureList == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MME-FeatureList cannot be null!!");
            }

            localMMEFeatureList.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MME-FeatureList"), xmlWriter);
        }

        if (localLastIDRorDSRFailedTracker) {
            if (localLastIDRorDSRFailed == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LastIDRorDSRFailed cannot be null!!");
            }

            localLastIDRorDSRFailed.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LastIDRorDSRFailed"),
                xmlWriter);
        }

        if (localSingleRegistrationIndicationTracker) {
            if (localSingleRegistrationIndication == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "Single-Registration-Indication cannot be null!!");
            }

            localSingleRegistrationIndication.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "Single-Registration-Indication"), xmlWriter);
        }

        if (localSkipSubscriberDataIndicatorTracker) {
            if (localSkipSubscriberDataIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "Skip-Subscriber-Data-Indicator cannot be null!!");
            }

            localSkipSubscriberDataIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "Skip-Subscriber-Data-Indicator"), xmlWriter);
        }

        if (localGPRSSubscriptionDataIndicatorTracker) {
            if (localGPRSSubscriptionDataIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GPRS-Subscription-Data-Indicator cannot be null!!");
            }

            localGPRSSubscriptionDataIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "GPRS-Subscription-Data-Indicator"), xmlWriter);
        }

        if (localNodeTypeIndicatorTracker) {
            if (localNodeTypeIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "Node-Type-Indicator cannot be null!!");
            }

            localNodeTypeIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "Node-Type-Indicator"),
                xmlWriter);
        }

        if (localInitialAttachIndicatorTracker) {
            if (localInitialAttachIndicator == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "Initial-Attach-Indicator cannot be null!!");
            }

            localInitialAttachIndicator.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "Initial-Attach-Indicator"),
                xmlWriter);
        }

        if (localPSLCSNotSupportedByUETracker) {
            if (localPSLCSNotSupportedByUE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PS-LCS-Not-Supported-By-UE cannot be null!!");
            }

            localPSLCSNotSupportedByUE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PS-LCS-Not-Supported-By-UE"),
                xmlWriter);
        }

        if (localMIMEITracker) {
            if (localMIMEI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-IMEI cannot be null!!");
            }

            localMIMEI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "M-IMEI"), xmlWriter);
        }

        if (localMIMEISVTracker) {
            if (localMIMEISV == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M-IMEISV cannot be null!!");
            }

            localMIMEISV.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "M-IMEISV"), xmlWriter);
        }

        if (localMMEFeatureList2Tracker) {
            if (localMMEFeatureList2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MME-FeatureList2 cannot be null!!");
            }

            localMMEFeatureList2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MME-FeatureList2"), xmlWriter);
        }

        if (localIMSVOPSSessionsSupportedMMETracker) {
            if (localIMSVOPSSessionsSupportedMME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMS-VO-PS-Sessions-Supported-MME cannot be null!!");
            }

            localIMSVOPSSessionsSupportedMME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS",
                    "IMS-VO-PS-Sessions-Supported-MME"), xmlWriter);
        }

        if (localUESRVCCCapabilityTracker) {
            if (localUESRVCCCapability == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UE-SRVCC-Capability cannot be null!!");
            }

            localUESRVCCCapability.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UE-SRVCC-Capability"),
                xmlWriter);
        }

        if (localVGMLCMMETracker) {
            if (localVGMLCMME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VGMLC-MME cannot be null!!");
            }

            localVGMLCMME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VGMLC-MME"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static DynamicStatusInfoForMME_type0 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            DynamicStatusInfoForMME_type0 object = new DynamicStatusInfoForMME_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"DynamicStatusInfoForMME_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (DynamicStatusInfoForMME_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MMEHOST").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MMEHOST").equals(
                            reader.getName())) {
                    object.setMMEHOST(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MMEREALM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MMEREALM").equals(
                            reader.getName())) {
                    object.setMMEREALM(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RATTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RATTYPE").equals(
                            reader.getName())) {
                    object.setRATTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "M-VPLMN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "M-VPLMN").equals(
                            reader.getName())) {
                    object.setMVPLMN(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PURGEDONMME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PURGEDONMME").equals(
                            reader.getName())) {
                    object.setPURGEDONMME(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "MME-UpdateLocation-Time").equals(reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "MME-UpdateLocation-Time").equals(reader.getName())) {
                    object.setMMEUpdateLocationTime(com.huawei.www.hss.Str1_60.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MME-FeatureList").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MME-FeatureList").equals(
                            reader.getName())) {
                    object.setMMEFeatureList(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LastIDRorDSRFailed").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LastIDRorDSRFailed").equals(
                            reader.getName())) {
                    object.setLastIDRorDSRFailed(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "Single-Registration-Indication").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "Single-Registration-Indication").equals(
                            reader.getName())) {
                    object.setSingleRegistrationIndication(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "Skip-Subscriber-Data-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "Skip-Subscriber-Data-Indicator").equals(
                            reader.getName())) {
                    object.setSkipSubscriberDataIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "GPRS-Subscription-Data-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "GPRS-Subscription-Data-Indicator").equals(
                            reader.getName())) {
                    object.setGPRSSubscriptionDataIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "Node-Type-Indicator").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "Node-Type-Indicator").equals(
                            reader.getName())) {
                    object.setNodeTypeIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "Initial-Attach-Indicator").equals(reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "Initial-Attach-Indicator").equals(reader.getName())) {
                    object.setInitialAttachIndicator(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "PS-LCS-Not-Supported-By-UE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "PS-LCS-Not-Supported-By-UE").equals(
                            reader.getName())) {
                    object.setPSLCSNotSupportedByUE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "M-IMEI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "M-IMEI").equals(
                            reader.getName())) {
                    object.setMIMEI(com.huawei.www.hss.Str1_60.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "M-IMEISV").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "M-IMEISV").equals(
                            reader.getName())) {
                    object.setMIMEISV(com.huawei.www.hss.Str1_60.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MME-FeatureList2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MME-FeatureList2").equals(
                            reader.getName())) {
                    object.setMMEFeatureList2(com.huawei.www.hss.Str1_9.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "IMS-VO-PS-Sessions-Supported-MME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "IMS-VO-PS-Sessions-Supported-MME").equals(
                            reader.getName())) {
                    object.setIMSVOPSSessionsSupportedMME(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UE-SRVCC-Capability").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UE-SRVCC-Capability").equals(
                            reader.getName())) {
                    object.setUESRVCCCapability(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VGMLC-MME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VGMLC-MME").equals(
                            reader.getName())) {
                    object.setVGMLCMME(com.huawei.www.hss.Str1_60.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
