/**
 * HSSV900R010C10Skeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:26 BST)
 */
package com.huawei.www.hss;

/**
 *  HSSV900R010C10Skeleton java skeleton for the axisService
 */
public class HSSV900R010C10Skeleton {
    /**
     * Auto generated method signature
     *
     * @param mOD_ODBPOS
     * @return mOD_ODBPOSResponse
     */
    public com.huawei.www.hss.MOD_ODBPOSResponse mOD_ODBPOS(
        com.huawei.www.hss.MOD_ODBPOS mOD_ODBPOS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODBPOS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_SPN
     * @return mOD_SPNResponse
     */
    public com.huawei.www.hss.MOD_SPNResponse mOD_SPN(
        com.huawei.www.hss.MOD_SPN mOD_SPN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_SPN");
    }

    /**
     * Auto generated method signature
     *
     * @param aCT_SMSCF
     * @return aCT_SMSCFResponse
     */
    public com.huawei.www.hss.ACT_SMSCFResponse aCT_SMSCF(
        com.huawei.www.hss.ACT_SMSCF aCT_SMSCF) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aCT_SMSCF");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ODBPB2
     * @return mOD_ODBPB2Response
     */
    public com.huawei.www.hss.MOD_ODBPB2Response mOD_ODBPB2(
        com.huawei.www.hss.MOD_ODBPB2 mOD_ODBPB2) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODBPB2");
    }

    /**
     * Auto generated method signature
     *
     * @param aCT_CWAIT
     * @return aCT_CWAITResponse
     */
    public com.huawei.www.hss.ACT_CWAITResponse aCT_CWAIT(
        com.huawei.www.hss.ACT_CWAIT aCT_CWAIT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aCT_CWAIT");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_EPSSER
     * @return mOD_EPSSERResponse
     */
    public com.huawei.www.hss.MOD_EPSSERResponse mOD_EPSSER(
        com.huawei.www.hss.MOD_EPSSER mOD_EPSSER) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_EPSSER");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS25
     * @return mOD_BS25Response
     */
    public com.huawei.www.hss.MOD_BS25Response mOD_BS25(
        com.huawei.www.hss.MOD_BS25 mOD_BS25) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS25");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CFB
     * @return mOD_CFBResponse
     */
    public com.huawei.www.hss.MOD_CFBResponse mOD_CFB(
        com.huawei.www.hss.MOD_CFB mOD_CFB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CFB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_APNSTORAGE
     * @return mOD_APNSTORAGEResponse
     */
    public com.huawei.www.hss.MOD_APNSTORAGEResponse mOD_APNSTORAGE(
        com.huawei.www.hss.MOD_APNSTORAGE mOD_APNSTORAGE) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_APNSTORAGE");
    }

    /**
     * Auto generated method signature
     *
     * @param aCT_BAIC
     * @return aCT_BAICResponse
     */
    public com.huawei.www.hss.ACT_BAICResponse aCT_BAIC(
        com.huawei.www.hss.ACT_BAIC aCT_BAIC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aCT_BAIC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_FTN
     * @return mOD_FTNResponse
     */
    public com.huawei.www.hss.MOD_FTNResponse mOD_FTN(
        com.huawei.www.hss.MOD_FTN mOD_FTN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_FTN");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_DND
     * @return lST_DNDResponse
     */
    public com.huawei.www.hss.LST_DNDResponse lST_DND(
        com.huawei.www.hss.LST_DND lST_DND) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_DND");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_SMSCF
     * @return lST_SMSCFResponse
     */
    public com.huawei.www.hss.LST_SMSCFResponse lST_SMSCF(
        com.huawei.www.hss.LST_SMSCF lST_SMSCF) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_SMSCF");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ECATEGORY
     * @return lST_ECATEGORYResponse
     */
    public com.huawei.www.hss.LST_ECATEGORYResponse lST_ECATEGORY(
        com.huawei.www.hss.LST_ECATEGORY lST_ECATEGORY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ECATEGORY");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_AAAINFO
     * @return mOD_AAAINFOResponse
     */
    public com.huawei.www.hss.MOD_AAAINFOResponse mOD_AAAINFO(
        com.huawei.www.hss.MOD_AAAINFO mOD_AAAINFO) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_AAAINFO");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_GPRS
     * @return mOD_GPRSResponse
     */
    public com.huawei.www.hss.MOD_GPRSResponse mOD_GPRS(
        com.huawei.www.hss.MOD_GPRS mOD_GPRS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_GPRS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_COLP
     * @return mOD_COLPResponse
     */
    public com.huawei.www.hss.MOD_COLPResponse mOD_COLP(
        com.huawei.www.hss.MOD_COLP mOD_COLP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_COLP");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_SGSNNUM
     * @return mOD_SGSNNUMResponse
     */
    public com.huawei.www.hss.MOD_SGSNNUMResponse mOD_SGSNNUM(
        com.huawei.www.hss.MOD_SGSNNUM mOD_SGSNNUM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_SGSNNUM");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CR
     * @return mOD_CRResponse
     */
    public com.huawei.www.hss.MOD_CRResponse mOD_CR(
        com.huawei.www.hss.MOD_CR mOD_CR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CR");
    }

    /**
     * Auto generated method signature
     *
     * @param gET_TERMSTATE
     * @return gET_TERMSTATEResponse
     */
    public com.huawei.www.hss.GET_TERMSTATEResponse gET_TERMSTATE(
        com.huawei.www.hss.GET_TERMSTATE gET_TERMSTATE) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#gET_TERMSTATE");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CF
     * @return mOD_CFResponse
     */
    public com.huawei.www.hss.MOD_CFResponse mOD_CF(
        com.huawei.www.hss.MOD_CF mOD_CF) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CF");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_EPSAPNOI
     * @return mOD_EPSAPNOIResponse
     */
    public com.huawei.www.hss.MOD_EPSAPNOIResponse mOD_EPSAPNOI(
        com.huawei.www.hss.MOD_EPSAPNOI mOD_EPSAPNOI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_EPSAPNOI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_SGSNNUM
     * @return lST_SGSNNUMResponse
     */
    public com.huawei.www.hss.LST_SGSNNUMResponse lST_SGSNNUM(
        com.huawei.www.hss.LST_SGSNNUM lST_SGSNNUM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_SGSNNUM");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ALSSUPP
     * @return mOD_ALSSUPPResponse
     */
    public com.huawei.www.hss.MOD_ALSSUPPResponse mOD_ALSSUPP(
        com.huawei.www.hss.MOD_ALSSUPP mOD_ALSSUPP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ALSSUPP");
    }

    /**
     * Auto generated method signature
     *
     * @param dEA_CWAIT
     * @return dEA_CWAITResponse
     */
    public com.huawei.www.hss.DEA_CWAITResponse dEA_CWAIT(
        com.huawei.www.hss.DEA_CWAIT dEA_CWAIT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#dEA_CWAIT");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_NPNS
     * @return lST_NPNSResponse
     */
    public com.huawei.www.hss.LST_NPNSResponse lST_NPNS(
        com.huawei.www.hss.LST_NPNS lST_NPNS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_NPNS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_EPS
     * @return mOD_EPSResponse
     */
    public com.huawei.www.hss.MOD_EPSResponse mOD_EPS(
        com.huawei.www.hss.MOD_EPS mOD_EPS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_EPS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_EGR
     * @return lST_EGRResponse
     */
    public com.huawei.www.hss.LST_EGRResponse lST_EGR(
        com.huawei.www.hss.LST_EGR lST_EGR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_EGR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_DIC
     * @return mOD_DICResponse
     */
    public com.huawei.www.hss.MOD_DICResponse mOD_DIC(
        com.huawei.www.hss.MOD_DIC mOD_DIC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_DIC");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ODBDAT
     * @return lST_ODBDATResponse
     */
    public com.huawei.www.hss.LST_ODBDATResponse lST_ODBDAT(
        com.huawei.www.hss.LST_ODBDAT lST_ODBDAT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ODBDAT");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_IMSIRTSUB
     * @return aDD_IMSIRTSUBResponse
     */
    public com.huawei.www.hss.ADD_IMSIRTSUBResponse aDD_IMSIRTSUB(
        com.huawei.www.hss.ADD_IMSIRTSUB aDD_IMSIRTSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_IMSIRTSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param rEG_CFNRC
     * @return rEG_CFNRCResponse
     */
    public com.huawei.www.hss.REG_CFNRCResponse rEG_CFNRC(
        com.huawei.www.hss.REG_CFNRC rEG_CFNRC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rEG_CFNRC");
    }

    /**
     * Auto generated method signature
     *
     * @param aCT_BICROM
     * @return aCT_BICROMResponse
     */
    public com.huawei.www.hss.ACT_BICROMResponse aCT_BICROM(
        com.huawei.www.hss.ACT_BICROM aCT_BICROM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aCT_BICROM");
    }

    /**
     * Auto generated method signature
     *
     * @param aCT_ACR
     * @return aCT_ACRResponse
     */
    public com.huawei.www.hss.ACT_ACRResponse aCT_ACR(
        com.huawei.www.hss.ACT_ACR aCT_ACR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aCT_ACR");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_SUB
     * @return aDD_SUBResponse
     */
    public com.huawei.www.hss.ADD_SUBResponse aDD_SUB(
        com.huawei.www.hss.ADD_SUB aDD_SUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_SUB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ELCS
     * @return mOD_ELCSResponse
     */
    public com.huawei.www.hss.MOD_ELCSResponse mOD_ELCS(
        com.huawei.www.hss.MOD_ELCS mOD_ELCS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ELCS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TPLEPSSER
     * @return mOD_TPLEPSSERResponse
     */
    public com.huawei.www.hss.MOD_TPLEPSSERResponse mOD_TPLEPSSER(
        com.huawei.www.hss.MOD_TPLEPSSER mOD_TPLEPSSER) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TPLEPSSER");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_STE
     * @return lST_STEResponse
     */
    public com.huawei.www.hss.LST_STEResponse lST_STE(
        com.huawei.www.hss.LST_STE lST_STE) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_STE");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS81
     * @return mOD_BS81Response
     */
    public com.huawei.www.hss.MOD_BS81Response mOD_BS81(
        com.huawei.www.hss.MOD_BS81 mOD_BS81) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS81");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_NSMSIN
     * @return mOD_NSMSINResponse
     */
    public com.huawei.www.hss.MOD_NSMSINResponse mOD_NSMSIN(
        com.huawei.www.hss.MOD_NSMSIN mOD_NSMSIN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_NSMSIN");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_PREMSMS
     * @return mOD_PREMSMSResponse
     */
    public com.huawei.www.hss.MOD_PREMSMSResponse mOD_PREMSMS(
        com.huawei.www.hss.MOD_PREMSMS mOD_PREMSMS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_PREMSMS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_OPTGPRSTPL
     * @return lST_OPTGPRSTPLResponse
     */
    public com.huawei.www.hss.LST_OPTGPRSTPLResponse lST_OPTGPRSTPL(
        com.huawei.www.hss.LST_OPTGPRSTPL lST_OPTGPRSTPL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_OPTGPRSTPL");
    }

    /**
     * Auto generated method signature
     *
     * @param sND_AUDITREPIND
     * @return sND_AUDITREPINDResponse
     */
    public com.huawei.www.hss.SND_AUDITREPINDResponse sND_AUDITREPIND(
        com.huawei.www.hss.SND_AUDITREPIND sND_AUDITREPIND) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#sND_AUDITREPIND");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_RSZI
     * @return mOD_RSZIResponse
     */
    public com.huawei.www.hss.MOD_RSZIResponse mOD_RSZI(
        com.huawei.www.hss.MOD_RSZI mOD_RSZI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_RSZI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_RFPRID
     * @return lST_RFPRIDResponse
     */
    public com.huawei.www.hss.LST_RFPRIDResponse lST_RFPRID(
        com.huawei.www.hss.LST_RFPRID lST_RFPRID) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_RFPRID");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS51
     * @return mOD_BS51Response
     */
    public com.huawei.www.hss.MOD_BS51Response mOD_BS51(
        com.huawei.www.hss.MOD_BS51 mOD_BS51) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS51");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ICSIND
     * @return lST_ICSINDResponse
     */
    public com.huawei.www.hss.LST_ICSINDResponse lST_ICSIND(
        com.huawei.www.hss.LST_ICSIND lST_ICSIND) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ICSIND");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ODBINFO
     * @return mOD_ODBINFOResponse
     */
    public com.huawei.www.hss.MOD_ODBINFOResponse mOD_ODBINFO(
        com.huawei.www.hss.MOD_ODBINFO mOD_ODBINFO) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODBINFO");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_VBS
     * @return lST_VBSResponse
     */
    public com.huawei.www.hss.LST_VBSResponse lST_VBS(
        com.huawei.www.hss.LST_VBS lST_VBS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_VBS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ODBOC
     * @return mOD_ODBOCResponse
     */
    public com.huawei.www.hss.MOD_ODBOCResponse mOD_ODBOC(
        com.huawei.www.hss.MOD_ODBOC mOD_ODBOC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODBOC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_DCSI
     * @return mOD_DCSIResponse
     */
    public com.huawei.www.hss.MOD_DCSIResponse mOD_DCSI(
        com.huawei.www.hss.MOD_DCSI mOD_DCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_DCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_NCAMEL
     * @return mOD_NCAMELResponse
     */
    public com.huawei.www.hss.MOD_NCAMELResponse mOD_NCAMEL(
        com.huawei.www.hss.MOD_NCAMEL mOD_NCAMEL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_NCAMEL");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_VGCS
     * @return lST_VGCSResponse
     */
    public com.huawei.www.hss.LST_VGCSResponse lST_VGCS(
        com.huawei.www.hss.LST_VGCS lST_VGCS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_VGCS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_TPLROAMPER
     * @return lST_TPLROAMPERResponse
     */
    public com.huawei.www.hss.LST_TPLROAMPERResponse lST_TPLROAMPER(
        com.huawei.www.hss.LST_TPLROAMPER lST_TPLROAMPER) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_TPLROAMPER");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_SCPBWADDR
     * @return lST_SCPBWADDRResponse
     */
    public com.huawei.www.hss.LST_SCPBWADDRResponse lST_SCPBWADDR(
        com.huawei.www.hss.LST_SCPBWADDR lST_SCPBWADDR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_SCPBWADDR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_NTUCSI
     * @return mOD_NTUCSIResponse
     */
    public com.huawei.www.hss.MOD_NTUCSIResponse mOD_NTUCSI(
        com.huawei.www.hss.MOD_NTUCSI mOD_NTUCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_NTUCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ANCHORTCSI
     * @return mOD_ANCHORTCSIResponse
     */
    public com.huawei.www.hss.MOD_ANCHORTCSIResponse mOD_ANCHORTCSI(
        com.huawei.www.hss.MOD_ANCHORTCSI mOD_ANCHORTCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ANCHORTCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_LCS
     * @return lST_LCSResponse
     */
    public com.huawei.www.hss.LST_LCSResponse lST_LCS(
        com.huawei.www.hss.LST_LCS lST_LCS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_LCS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_SMDP
     * @return lST_SMDPResponse
     */
    public com.huawei.www.hss.LST_SMDPResponse lST_SMDP(
        com.huawei.www.hss.LST_SMDP lST_SMDP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_SMDP");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_NAEA
     * @return mOD_NAEAResponse
     */
    public com.huawei.www.hss.MOD_NAEAResponse mOD_NAEA(
        com.huawei.www.hss.MOD_NAEA mOD_NAEA) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_NAEA");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_EPSAMBR
     * @return mOD_EPSAMBRResponse
     */
    public com.huawei.www.hss.MOD_EPSAMBRResponse mOD_EPSAMBR(
        com.huawei.www.hss.MOD_EPSAMBR mOD_EPSAMBR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_EPSAMBR");
    }

    /**
     * Auto generated method signature
     *
     * @param dEA_BICROM
     * @return dEA_BICROMResponse
     */
    public com.huawei.www.hss.DEA_BICROMResponse dEA_BICROM(
        com.huawei.www.hss.DEA_BICROM dEA_BICROM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#dEA_BICROM");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_DEFAULTOFA
     * @return mOD_DEFAULTOFAResponse
     */
    public com.huawei.www.hss.MOD_DEFAULTOFAResponse mOD_DEFAULTOFA(
        com.huawei.www.hss.MOD_DEFAULTOFA mOD_DEFAULTOFA) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_DEFAULTOFA");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ODBPB4
     * @return mOD_ODBPB4Response
     */
    public com.huawei.www.hss.MOD_ODBPB4Response mOD_ODBPB4(
        com.huawei.www.hss.MOD_ODBPB4 mOD_ODBPB4) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODBPB4");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ICI
     * @return mOD_ICIResponse
     */
    public com.huawei.www.hss.MOD_ICIResponse mOD_ICI(
        com.huawei.www.hss.MOD_ICI mOD_ICI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ICI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TCSI
     * @return mOD_TCSIResponse
     */
    public com.huawei.www.hss.MOD_TCSIResponse mOD_TCSI(
        com.huawei.www.hss.MOD_TCSI mOD_TCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_VVDN
     * @return lST_VVDNResponse
     */
    public com.huawei.www.hss.LST_VVDNResponse lST_VVDN(
        com.huawei.www.hss.LST_VVDN lST_VVDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_VVDN");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CCGLOBAL
     * @return mOD_CCGLOBALResponse
     */
    public com.huawei.www.hss.MOD_CCGLOBALResponse mOD_CCGLOBAL(
        com.huawei.www.hss.MOD_CCGLOBAL mOD_CCGLOBAL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CCGLOBAL");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_PLMNRSZI
     * @return lST_PLMNRSZIResponse
     */
    public com.huawei.www.hss.LST_PLMNRSZIResponse lST_PLMNRSZI(
        com.huawei.www.hss.LST_PLMNRSZI lST_PLMNRSZI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_PLMNRSZI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_EPSAMBR
     * @return lST_EPSAMBRResponse
     */
    public com.huawei.www.hss.LST_EPSAMBRResponse lST_EPSAMBR(
        com.huawei.www.hss.LST_EPSAMBR lST_EPSAMBR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_EPSAMBR");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_COLP
     * @return lST_COLPResponse
     */
    public com.huawei.www.hss.LST_COLPResponse lST_COLP(
        com.huawei.www.hss.LST_COLP lST_COLP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_COLP");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_KI
     * @return lST_KIResponse
     */
    public com.huawei.www.hss.LST_KIResponse lST_KI(
        com.huawei.www.hss.LST_KI lST_KI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_KI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_OWNISDN
     * @return lST_OWNISDNResponse
     */
    public com.huawei.www.hss.LST_OWNISDNResponse lST_OWNISDN(
        com.huawei.www.hss.LST_OWNISDN lST_OWNISDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_OWNISDN");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_NPOTHERRPT
     * @return mOD_NPOTHERRPTResponse
     */
    public com.huawei.www.hss.MOD_NPOTHERRPTResponse mOD_NPOTHERRPT(
        com.huawei.www.hss.MOD_NPOTHERRPT mOD_NPOTHERRPT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_NPOTHERRPT");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TPLPSSER
     * @return mOD_TPLPSSERResponse
     */
    public com.huawei.www.hss.MOD_TPLPSSERResponse mOD_TPLPSSER(
        com.huawei.www.hss.MOD_TPLPSSER mOD_TPLPSSER) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TPLPSSER");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_HOLD
     * @return mOD_HOLDResponse
     */
    public com.huawei.www.hss.MOD_HOLDResponse mOD_HOLD(
        com.huawei.www.hss.MOD_HOLD mOD_HOLD) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_HOLD");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS26
     * @return mOD_BS26Response
     */
    public com.huawei.www.hss.MOD_BS26Response mOD_BS26(
        com.huawei.www.hss.MOD_BS26 mOD_BS26) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS26");
    }

    /**
     * Auto generated method signature
     *
     * @param dEA_BAOC
     * @return dEA_BAOCResponse
     */
    public com.huawei.www.hss.DEA_BAOCResponse dEA_BAOC(
        com.huawei.www.hss.DEA_BAOC dEA_BAOC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#dEA_BAOC");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_NONSUB
     * @return lST_NONSUBResponse
     */
    public com.huawei.www.hss.LST_NONSUBResponse lST_NONSUB(
        com.huawei.www.hss.LST_NONSUB lST_NONSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_NONSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CWAIT
     * @return mOD_CWAITResponse
     */
    public com.huawei.www.hss.MOD_CWAITResponse mOD_CWAIT(
        com.huawei.www.hss.MOD_CWAIT mOD_CWAIT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CWAIT");
    }

    /**
     * Auto generated method signature
     *
     * @param rMV_OPTGPRSTPL
     * @return rMV_OPTGPRSTPLResponse
     */
    public com.huawei.www.hss.RMV_OPTGPRSTPLResponse rMV_OPTGPRSTPL(
        com.huawei.www.hss.RMV_OPTGPRSTPL rMV_OPTGPRSTPL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rMV_OPTGPRSTPL");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BOIC
     * @return mOD_BOICResponse
     */
    public com.huawei.www.hss.MOD_BOICResponse mOD_BOIC(
        com.huawei.www.hss.MOD_BOIC mOD_BOIC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BOIC");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CAPL
     * @return lST_CAPLResponse
     */
    public com.huawei.www.hss.LST_CAPLResponse lST_CAPL(
        com.huawei.www.hss.LST_CAPL lST_CAPL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CAPL");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ECATEGORY
     * @return mOD_ECATEGORYResponse
     */
    public com.huawei.www.hss.MOD_ECATEGORYResponse mOD_ECATEGORY(
        com.huawei.www.hss.MOD_ECATEGORY mOD_ECATEGORY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ECATEGORY");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_DIAMRRS
     * @return mOD_DIAMRRSResponse
     */
    public com.huawei.www.hss.MOD_DIAMRRSResponse mOD_DIAMRRS(
        com.huawei.www.hss.MOD_DIAMRRS mOD_DIAMRRS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_DIAMRRS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_AUTHUSER
     * @return lST_AUTHUSERResponse
     */
    public com.huawei.www.hss.LST_AUTHUSERResponse lST_AUTHUSER(
        com.huawei.www.hss.LST_AUTHUSER lST_AUTHUSER) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_AUTHUSER");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_S4SGSNINFO
     * @return mOD_S4SGSNINFOResponse
     */
    public com.huawei.www.hss.MOD_S4SGSNINFOResponse mOD_S4SGSNINFO(
        com.huawei.www.hss.MOD_S4SGSNINFO mOD_S4SGSNINFO) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_S4SGSNINFO");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_SMSROUTE
     * @return lST_SMSROUTEResponse
     */
    public com.huawei.www.hss.LST_SMSROUTEResponse lST_SMSROUTE(
        com.huawei.www.hss.LST_SMSROUTE lST_SMSROUTE) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_SMSROUTE");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_AOCI
     * @return mOD_AOCIResponse
     */
    public com.huawei.www.hss.MOD_AOCIResponse mOD_AOCI(
        com.huawei.www.hss.MOD_AOCI mOD_AOCI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_AOCI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_FRAUD
     * @return lST_FRAUDResponse
     */
    public com.huawei.www.hss.LST_FRAUDResponse lST_FRAUD(
        com.huawei.www.hss.LST_FRAUD lST_FRAUD) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_FRAUD");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_SABLCK
     * @return mOD_SABLCKResponse
     */
    public com.huawei.www.hss.MOD_SABLCKResponse mOD_SABLCK(
        com.huawei.www.hss.MOD_SABLCK mOD_SABLCK) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_SABLCK");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_AOCC
     * @return mOD_AOCCResponse
     */
    public com.huawei.www.hss.MOD_AOCCResponse mOD_AOCC(
        com.huawei.www.hss.MOD_AOCC mOD_AOCC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_AOCC");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_EPSAPNOI
     * @return lST_EPSAPNOIResponse
     */
    public com.huawei.www.hss.LST_EPSAPNOIResponse lST_EPSAPNOI(
        com.huawei.www.hss.LST_EPSAPNOI lST_EPSAPNOI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_EPSAPNOI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_EMLPP
     * @return lST_EMLPPResponse
     */
    public com.huawei.www.hss.LST_EMLPPResponse lST_EMLPP(
        com.huawei.www.hss.LST_EMLPP lST_EMLPP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_EMLPP");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_NSMSIN
     * @return lST_NSMSINResponse
     */
    public com.huawei.www.hss.LST_NSMSINResponse lST_NSMSIN(
        com.huawei.www.hss.LST_NSMSIN lST_NSMSIN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_NSMSIN");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_MAPADDRRES
     * @return lST_MAPADDRRESResponse
     */
    public com.huawei.www.hss.LST_MAPADDRRESResponse lST_MAPADDRRES(
        com.huawei.www.hss.LST_MAPADDRRES lST_MAPADDRRES) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_MAPADDRRES");
    }

    /**
     * Auto generated method signature
     *
     * @param aCT_CFD
     * @return aCT_CFDResponse
     */
    public com.huawei.www.hss.ACT_CFDResponse aCT_CFD(
        com.huawei.www.hss.ACT_CFD aCT_CFD) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aCT_CFD");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS52
     * @return mOD_BS52Response
     */
    public com.huawei.www.hss.MOD_BS52Response mOD_BS52(
        com.huawei.www.hss.MOD_BS52 mOD_BS52) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS52");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_PRERES
     * @return mOD_PRERESResponse
     */
    public com.huawei.www.hss.MOD_PRERESResponse mOD_PRERES(
        com.huawei.www.hss.MOD_PRERES mOD_PRERES) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_PRERES");
    }

    /**
     * Auto generated method signature
     *
     * @param sET_MULTISDN
     * @return sET_MULTISDNResponse
     */
    public com.huawei.www.hss.SET_MULTISDNResponse sET_MULTISDN(
        com.huawei.www.hss.SET_MULTISDN sET_MULTISDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#sET_MULTISDN");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_VMCC
     * @return mOD_VMCCResponse
     */
    public com.huawei.www.hss.MOD_VMCCResponse mOD_VMCC(
        com.huawei.www.hss.MOD_VMCC mOD_VMCC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_VMCC");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_SABLCK
     * @return lST_SABLCKResponse
     */
    public com.huawei.www.hss.LST_SABLCKResponse lST_SABLCK(
        com.huawei.www.hss.LST_SABLCK lST_SABLCK) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_SABLCK");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_STE
     * @return mOD_STEResponse
     */
    public com.huawei.www.hss.MOD_STEResponse mOD_STE(
        com.huawei.www.hss.MOD_STE mOD_STE) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_STE");
    }

    /**
     * Auto generated method signature
     *
     * @param cLR_VOLTEIMSSTATE
     * @return cLR_VOLTEIMSSTATEResponse
     */
    public com.huawei.www.hss.CLR_VOLTEIMSSTATEResponse cLR_VOLTEIMSSTATE(
        com.huawei.www.hss.CLR_VOLTEIMSSTATE cLR_VOLTEIMSSTATE) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#cLR_VOLTEIMSSTATE");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_OSS
     * @return lST_OSSResponse
     */
    public com.huawei.www.hss.LST_OSSResponse lST_OSS(
        com.huawei.www.hss.LST_OSS lST_OSS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_OSS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BOICEXHC
     * @return mOD_BOICEXHCResponse
     */
    public com.huawei.www.hss.MOD_BOICEXHCResponse mOD_BOICEXHC(
        com.huawei.www.hss.MOD_BOICEXHC mOD_BOICEXHC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BOICEXHC");
    }

    /**
     * Auto generated method signature
     *
     * @param dEA_ACR
     * @return dEA_ACRResponse
     */
    public com.huawei.www.hss.DEA_ACRResponse dEA_ACR(
        com.huawei.www.hss.DEA_ACR dEA_ACR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#dEA_ACR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_VBS
     * @return mOD_VBSResponse
     */
    public com.huawei.www.hss.MOD_VBSResponse mOD_VBS(
        com.huawei.www.hss.MOD_VBS mOD_VBS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_VBS");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_OPTGPRSTPL
     * @return aDD_OPTGPRSTPLResponse
     */
    public com.huawei.www.hss.ADD_OPTGPRSTPLResponse aDD_OPTGPRSTPL(
        com.huawei.www.hss.ADD_OPTGPRSTPL aDD_OPTGPRSTPL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_OPTGPRSTPL");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_IMSIISDN
     * @return lST_IMSIISDNResponse
     */
    public com.huawei.www.hss.LST_IMSIISDNResponse lST_IMSIISDN(
        com.huawei.www.hss.LST_IMSIISDN lST_IMSIISDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_IMSIISDN");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_DIAMRRTPL
     * @return aDD_DIAMRRTPLResponse
     */
    public com.huawei.www.hss.ADD_DIAMRRTPLResponse aDD_DIAMRRTPL(
        com.huawei.www.hss.ADD_DIAMRRTPL aDD_DIAMRRTPL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_DIAMRRTPL");
    }

    /**
     * Auto generated method signature
     *
     * @param aCT_BOIC
     * @return aCT_BOICResponse
     */
    public com.huawei.www.hss.ACT_BOICResponse aCT_BOIC(
        com.huawei.www.hss.ACT_BOIC aCT_BOIC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aCT_BOIC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_OSS
     * @return mOD_OSSResponse
     */
    public com.huawei.www.hss.MOD_OSSResponse mOD_OSS(
        com.huawei.www.hss.MOD_OSS mOD_OSS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_OSS");
    }

    /**
     * Auto generated method signature
     *
     * @param dEA_BRDCASTIND
     * @return dEA_BRDCASTINDResponse
     */
    public com.huawei.www.hss.DEA_BRDCASTINDResponse dEA_BRDCASTIND(
        com.huawei.www.hss.DEA_BRDCASTIND dEA_BRDCASTIND) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#dEA_BRDCASTIND");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_USERCATEGORY
     * @return mOD_USERCATEGORYResponse
     */
    public com.huawei.www.hss.MOD_USERCATEGORYResponse mOD_USERCATEGORY(
        com.huawei.www.hss.MOD_USERCATEGORY mOD_USERCATEGORY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_USERCATEGORY");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ICI
     * @return lST_ICIResponse
     */
    public com.huawei.www.hss.LST_ICIResponse lST_ICI(
        com.huawei.www.hss.LST_ICI lST_ICI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ICI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_VOLTETAG
     * @return mOD_VOLTETAGResponse
     */
    public com.huawei.www.hss.MOD_VOLTETAGResponse mOD_VOLTETAG(
        com.huawei.www.hss.MOD_VOLTETAG mOD_VOLTETAG) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_VOLTETAG");
    }

    /**
     * Auto generated method signature
     *
     * @param rMV_KI
     * @return rMV_KIResponse
     */
    public com.huawei.www.hss.RMV_KIResponse rMV_KI(
        com.huawei.www.hss.RMV_KI rMV_KI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rMV_KI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_NTUCSI
     * @return lST_NTUCSIResponse
     */
    public com.huawei.www.hss.LST_NTUCSIResponse lST_NTUCSI(
        com.huawei.www.hss.LST_NTUCSI lST_NTUCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_NTUCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CA
     * @return lST_CAResponse
     */
    public com.huawei.www.hss.LST_CAResponse lST_CA(
        com.huawei.www.hss.LST_CA lST_CA) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CA");
    }

    /**
     * Auto generated method signature
     *
     * @param sND_ISTCMD
     * @return sND_ISTCMDResponse
     */
    public com.huawei.www.hss.SND_ISTCMDResponse sND_ISTCMD(
        com.huawei.www.hss.SND_ISTCMD sND_ISTCMD) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#sND_ISTCMD");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CPP
     * @return mOD_CPPResponse
     */
    public com.huawei.www.hss.MOD_CPPResponse mOD_CPP(
        com.huawei.www.hss.MOD_CPP mOD_CPP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CPP");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BICROM
     * @return mOD_BICROMResponse
     */
    public com.huawei.www.hss.MOD_BICROMResponse mOD_BICROM(
        com.huawei.www.hss.MOD_BICROM mOD_BICROM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BICROM");
    }

    /**
     * Auto generated method signature
     *
     * @param aCT_BORO
     * @return aCT_BOROResponse
     */
    public com.huawei.www.hss.ACT_BOROResponse aCT_BORO(
        com.huawei.www.hss.ACT_BORO aCT_BORO) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aCT_BORO");
    }

    /**
     * Auto generated method signature
     *
     * @param rMV_SUB
     * @return rMV_SUBResponse
     */
    public com.huawei.www.hss.RMV_SUBResponse rMV_SUB(
        com.huawei.www.hss.RMV_SUB rMV_SUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rMV_SUB");
    }

    /**
     * Auto generated method signature
     *
     * @param dEA_BORO
     * @return dEA_BOROResponse
     */
    public com.huawei.www.hss.DEA_BOROResponse dEA_BORO(
        com.huawei.www.hss.DEA_BORO dEA_BORO) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#dEA_BORO");
    }

    /**
     * Auto generated method signature
     *
     * @param rESET_BINDEDTAI
     * @return rESET_BINDEDTAIResponse
     */
    public com.huawei.www.hss.RESET_BINDEDTAIResponse rESET_BINDEDTAI(
        com.huawei.www.hss.RESET_BINDEDTAI rESET_BINDEDTAI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rESET_BINDEDTAI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_MC
     * @return mOD_MCResponse
     */
    public com.huawei.www.hss.MOD_MCResponse mOD_MC(
        com.huawei.www.hss.MOD_MC mOD_MC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_MC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ROUTECATEGORY
     * @return mOD_ROUTECATEGORYResponse
     */
    public com.huawei.www.hss.MOD_ROUTECATEGORYResponse mOD_ROUTECATEGORY(
        com.huawei.www.hss.MOD_ROUTECATEGORY mOD_ROUTECATEGORY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ROUTECATEGORY");
    }

    /**
     * Auto generated method signature
     *
     * @param eRA_CFNRC
     * @return eRA_CFNRCResponse
     */
    public com.huawei.www.hss.ERA_CFNRCResponse eRA_CFNRC(
        com.huawei.www.hss.ERA_CFNRC eRA_CFNRC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#eRA_CFNRC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_SSCSI
     * @return mOD_SSCSIResponse
     */
    public com.huawei.www.hss.MOD_SSCSIResponse mOD_SSCSI(
        com.huawei.www.hss.MOD_SSCSI mOD_SSCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_SSCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_NRBT
     * @return lST_NRBTResponse
     */
    public com.huawei.www.hss.LST_NRBTResponse lST_NRBT(
        com.huawei.www.hss.LST_NRBT lST_NRBT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_NRBT");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ANUMBLST
     * @return lST_ANUMBLSTResponse
     */
    public com.huawei.www.hss.LST_ANUMBLSTResponse lST_ANUMBLST(
        com.huawei.www.hss.LST_ANUMBLST lST_ANUMBLST) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ANUMBLST");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_SMSROUTE
     * @return mOD_SMSROUTEResponse
     */
    public com.huawei.www.hss.MOD_SMSROUTEResponse mOD_SMSROUTE(
        com.huawei.www.hss.MOD_SMSROUTE mOD_SMSROUTE) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_SMSROUTE");
    }

    /**
     * Auto generated method signature
     *
     * @param eRA_CFNRY
     * @return eRA_CFNRYResponse
     */
    public com.huawei.www.hss.ERA_CFNRYResponse eRA_CFNRY(
        com.huawei.www.hss.ERA_CFNRY eRA_CFNRY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#eRA_CFNRY");
    }

    /**
     * Auto generated method signature
     *
     * @param cLR_GPRSDATA
     * @return cLR_GPRSDATAResponse
     */
    public com.huawei.www.hss.CLR_GPRSDATAResponse cLR_GPRSDATA(
        com.huawei.www.hss.CLR_GPRSDATA cLR_GPRSDATA) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#cLR_GPRSDATA");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CWAIT
     * @return lST_CWAITResponse
     */
    public com.huawei.www.hss.LST_CWAITResponse lST_CWAIT(
        com.huawei.www.hss.LST_CWAIT lST_CWAIT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CWAIT");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ZCLOCK
     * @return lST_ZCLOCKResponse
     */
    public com.huawei.www.hss.LST_ZCLOCKResponse lST_ZCLOCK(
        com.huawei.www.hss.LST_ZCLOCK lST_ZCLOCK) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ZCLOCK");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CCBS
     * @return lST_CCBSResponse
     */
    public com.huawei.www.hss.LST_CCBSResponse lST_CCBS(
        com.huawei.www.hss.LST_CCBS lST_CCBS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CCBS");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_TPLUSCSUB
     * @return aDD_TPLUSCSUBResponse
     */
    public com.huawei.www.hss.ADD_TPLUSCSUBResponse aDD_TPLUSCSUB(
        com.huawei.www.hss.ADD_TPLUSCSUB aDD_TPLUSCSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_TPLUSCSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS20
     * @return mOD_BS20Response
     */
    public com.huawei.www.hss.MOD_BS20Response mOD_BS20(
        com.huawei.www.hss.MOD_BS20 mOD_BS20) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS20");
    }

    /**
     * Auto generated method signature
     *
     * @param dEA_BOICEXHC
     * @return dEA_BOICEXHCResponse
     */
    public com.huawei.www.hss.DEA_BOICEXHCResponse dEA_BOICEXHC(
        com.huawei.www.hss.DEA_BOICEXHC dEA_BOICEXHC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#dEA_BOICEXHC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_IMSIISDN
     * @return mOD_IMSIISDNResponse
     */
    public com.huawei.www.hss.MOD_IMSIISDNResponse mOD_IMSIISDN(
        com.huawei.www.hss.MOD_IMSIISDN mOD_IMSIISDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_IMSIISDN");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_IMSI
     * @return mOD_IMSIResponse
     */
    public com.huawei.www.hss.MOD_IMSIResponse mOD_IMSI(
        com.huawei.www.hss.MOD_IMSI mOD_IMSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_IMSI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_SMSCSI
     * @return mOD_SMSCSIResponse
     */
    public com.huawei.www.hss.MOD_SMSCSIResponse mOD_SMSCSI(
        com.huawei.www.hss.MOD_SMSCSI mOD_SMSCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_SMSCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_EMMIN
     * @return mOD_EMMINResponse
     */
    public com.huawei.www.hss.MOD_EMMINResponse mOD_EMMIN(
        com.huawei.www.hss.MOD_EMMIN mOD_EMMIN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_EMMIN");
    }

    /**
     * Auto generated method signature
     *
     * @param sND_RESET
     * @return sND_RESETResponse
     */
    public com.huawei.www.hss.SND_RESETResponse sND_RESET(
        com.huawei.www.hss.SND_RESET sND_RESET) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#sND_RESET");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_SCISDN
     * @return mOD_SCISDNResponse
     */
    public com.huawei.www.hss.MOD_SCISDNResponse mOD_SCISDN(
        com.huawei.www.hss.MOD_SCISDN mOD_SCISDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_SCISDN");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_EPSODB
     * @return lST_EPSODBResponse
     */
    public com.huawei.www.hss.LST_EPSODBResponse lST_EPSODB(
        com.huawei.www.hss.LST_EPSODB lST_EPSODB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_EPSODB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TPLVGCS
     * @return mOD_TPLVGCSResponse
     */
    public com.huawei.www.hss.MOD_TPLVGCSResponse mOD_TPLVGCS(
        com.huawei.www.hss.MOD_TPLVGCS mOD_TPLVGCS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TPLVGCS");
    }

    /**
     * Auto generated method signature
     *
     * @param cHK_KI
     * @return cHK_KIResponse
     */
    public com.huawei.www.hss.CHK_KIResponse cHK_KI(
        com.huawei.www.hss.CHK_KI cHK_KI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#cHK_KI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_FM
     * @return lST_FMResponse
     */
    public com.huawei.www.hss.LST_FMResponse lST_FM(
        com.huawei.www.hss.LST_FM lST_FM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_FM");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CBAR
     * @return lST_CBARResponse
     */
    public com.huawei.www.hss.LST_CBARResponse lST_CBAR(
        com.huawei.www.hss.LST_CBAR lST_CBAR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CBAR");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_DYNSUB
     * @return lST_DYNSUBResponse
     */
    public com.huawei.www.hss.LST_DYNSUBResponse lST_DYNSUB(
        com.huawei.www.hss.LST_DYNSUB lST_DYNSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_DYNSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS
     * @return mOD_BSResponse
     */
    public com.huawei.www.hss.MOD_BSResponse mOD_BS(
        com.huawei.www.hss.MOD_BS mOD_BS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ZCLOCK
     * @return mOD_ZCLOCKResponse
     */
    public com.huawei.www.hss.MOD_ZCLOCKResponse mOD_ZCLOCK(
        com.huawei.www.hss.MOD_ZCLOCK mOD_ZCLOCK) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ZCLOCK");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TIFCSI
     * @return mOD_TIFCSIResponse
     */
    public com.huawei.www.hss.MOD_TIFCSIResponse mOD_TIFCSI(
        com.huawei.www.hss.MOD_TIFCSI mOD_TIFCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TIFCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_LUCSI
     * @return mOD_LUCSIResponse
     */
    public com.huawei.www.hss.MOD_LUCSIResponse mOD_LUCSI(
        com.huawei.www.hss.MOD_LUCSI mOD_LUCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_LUCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_VMCC
     * @return lST_VMCCResponse
     */
    public com.huawei.www.hss.LST_VMCCResponse lST_VMCC(
        com.huawei.www.hss.LST_VMCC lST_VMCC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_VMCC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_M2MNOTIFY
     * @return mOD_M2MNOTIFYResponse
     */
    public com.huawei.www.hss.MOD_M2MNOTIFYResponse mOD_M2MNOTIFY(
        com.huawei.www.hss.MOD_M2MNOTIFY mOD_M2MNOTIFY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_M2MNOTIFY");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS43
     * @return mOD_BS43Response
     */
    public com.huawei.www.hss.MOD_BS43Response mOD_BS43(
        com.huawei.www.hss.MOD_BS43 mOD_BS43) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS43");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_RZONE
     * @return mOD_RZONEResponse
     */
    public com.huawei.www.hss.MOD_RZONEResponse mOD_RZONE(
        com.huawei.www.hss.MOD_RZONE mOD_RZONE) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_RZONE");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_MIMSI
     * @return lST_MIMSIResponse
     */
    public com.huawei.www.hss.LST_MIMSIResponse lST_MIMSI(
        com.huawei.www.hss.LST_MIMSI lST_MIMSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_MIMSI");
    }

    /**
     * Auto generated method signature
     *
     * @param cLR_SUBDATA
     * @return cLR_SUBDATAResponse
     */
    public com.huawei.www.hss.CLR_SUBDATAResponse cLR_SUBDATA(
        com.huawei.www.hss.CLR_SUBDATA cLR_SUBDATA) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#cLR_SUBDATA");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_LCS
     * @return mOD_LCSResponse
     */
    public com.huawei.www.hss.MOD_LCSResponse mOD_LCS(
        com.huawei.www.hss.MOD_LCS mOD_LCS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_LCS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_GPRS
     * @return lST_GPRSResponse
     */
    public com.huawei.www.hss.LST_GPRSResponse lST_GPRS(
        com.huawei.www.hss.LST_GPRS lST_GPRS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_GPRS");
    }

    /**
     * Auto generated method signature
     *
     * @param sND_CANCELC
     * @return sND_CANCELCResponse
     */
    public com.huawei.www.hss.SND_CANCELCResponse sND_CANCELC(
        com.huawei.www.hss.SND_CANCELC sND_CANCELC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#sND_CANCELC");
    }

    /**
     * Auto generated method signature
     *
     * @param cHK_CONSY
     * @return cHK_CONSYResponse
     */
    public com.huawei.www.hss.CHK_CONSYResponse cHK_CONSY(
        com.huawei.www.hss.CHK_CONSY cHK_CONSY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#cHK_CONSY");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ROUTECATEGORY
     * @return lST_ROUTECATEGORYResponse
     */
    public com.huawei.www.hss.LST_ROUTECATEGORYResponse lST_ROUTECATEGORY(
        com.huawei.www.hss.LST_ROUTECATEGORY lST_ROUTECATEGORY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ROUTECATEGORY");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_SMSMT
     * @return mOD_SMSMTResponse
     */
    public com.huawei.www.hss.MOD_SMSMTResponse mOD_SMSMT(
        com.huawei.www.hss.MOD_SMSMT mOD_SMSMT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_SMSMT");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS34
     * @return mOD_BS34Response
     */
    public com.huawei.www.hss.MOD_BS34Response mOD_BS34(
        com.huawei.www.hss.MOD_BS34 mOD_BS34) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS34");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_UUS
     * @return lST_UUSResponse
     */
    public com.huawei.www.hss.LST_UUSResponse lST_UUS(
        com.huawei.www.hss.LST_UUS lST_UUS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_UUS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS30
     * @return mOD_BS30Response
     */
    public com.huawei.www.hss.MOD_BS30Response mOD_BS30(
        com.huawei.www.hss.MOD_BS30 mOD_BS30) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS30");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_VLRNUM
     * @return mOD_VLRNUMResponse
     */
    public com.huawei.www.hss.MOD_VLRNUMResponse mOD_VLRNUM(
        com.huawei.www.hss.MOD_VLRNUM mOD_VLRNUM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_VLRNUM");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_VTCSITPL
     * @return mOD_VTCSITPLResponse
     */
    public com.huawei.www.hss.MOD_VTCSITPLResponse mOD_VTCSITPL(
        com.huawei.www.hss.MOD_VTCSITPL mOD_VTCSITPL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_VTCSITPL");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_EMLPP
     * @return mOD_EMLPPResponse
     */
    public com.huawei.www.hss.MOD_EMLPPResponse mOD_EMLPP(
        com.huawei.www.hss.MOD_EMLPP mOD_EMLPP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_EMLPP");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_RMPY
     * @return lST_RMPYResponse
     */
    public com.huawei.www.hss.LST_RMPYResponse lST_RMPY(
        com.huawei.www.hss.LST_RMPY lST_RMPY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_RMPY");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS21
     * @return mOD_BS21Response
     */
    public com.huawei.www.hss.MOD_BS21Response mOD_BS21(
        com.huawei.www.hss.MOD_BS21 mOD_BS21) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS21");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_VOLTETAG
     * @return lST_VOLTETAGResponse
     */
    public com.huawei.www.hss.LST_VOLTETAGResponse lST_VOLTETAG(
        com.huawei.www.hss.LST_VOLTETAG lST_VOLTETAG) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_VOLTETAG");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ODBIC
     * @return mOD_ODBICResponse
     */
    public com.huawei.www.hss.MOD_ODBICResponse mOD_ODBIC(
        com.huawei.www.hss.MOD_ODBIC mOD_ODBIC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODBIC");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ESUB
     * @return lST_ESUBResponse
     */
    public com.huawei.www.hss.LST_ESUBResponse lST_ESUB(
        com.huawei.www.hss.LST_ESUB lST_ESUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ESUB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_COMISDN
     * @return mOD_COMISDNResponse
     */
    public com.huawei.www.hss.MOD_COMISDNResponse mOD_COMISDN(
        com.huawei.www.hss.MOD_COMISDN mOD_COMISDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_COMISDN");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_NPDONORSUB
     * @return lST_NPDONORSUBResponse
     */
    public com.huawei.www.hss.LST_NPDONORSUBResponse lST_NPDONORSUB(
        com.huawei.www.hss.LST_NPDONORSUB lST_NPDONORSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_NPDONORSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_SPN
     * @return lST_SPNResponse
     */
    public com.huawei.www.hss.LST_SPNResponse lST_SPN(
        com.huawei.www.hss.LST_SPN lST_SPN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_SPN");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_DIC
     * @return lST_DICResponse
     */
    public com.huawei.www.hss.LST_DICResponse lST_DIC(
        com.huawei.www.hss.LST_DIC lST_DIC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_DIC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_RMPY
     * @return mOD_RMPYResponse
     */
    public com.huawei.www.hss.MOD_RMPYResponse mOD_RMPY(
        com.huawei.www.hss.MOD_RMPY mOD_RMPY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_RMPY");
    }

    /**
     * Auto generated method signature
     *
     * @param rMV_IMSIRTSUB
     * @return rMV_IMSIRTSUBResponse
     */
    public com.huawei.www.hss.RMV_IMSIRTSUBResponse rMV_IMSIRTSUB(
        com.huawei.www.hss.RMV_IMSIRTSUB rMV_IMSIRTSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rMV_IMSIRTSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param sND_UPL
     * @return sND_UPLResponse
     */
    public com.huawei.www.hss.SND_UPLResponse sND_UPL(
        com.huawei.www.hss.SND_UPL sND_UPL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#sND_UPL");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_M2MNOTIFY
     * @return lST_M2MNOTIFYResponse
     */
    public com.huawei.www.hss.LST_M2MNOTIFYResponse lST_M2MNOTIFY(
        com.huawei.www.hss.LST_M2MNOTIFY lST_M2MNOTIFY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_M2MNOTIFY");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TPLEPS
     * @return mOD_TPLEPSResponse
     */
    public com.huawei.www.hss.MOD_TPLEPSResponse mOD_TPLEPS(
        com.huawei.www.hss.MOD_TPLEPS mOD_TPLEPS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TPLEPS");
    }

    /**
     * Auto generated method signature
     *
     * @param rMV_ANUMBLST
     * @return rMV_ANUMBLSTResponse
     */
    public com.huawei.www.hss.RMV_ANUMBLSTResponse rMV_ANUMBLST(
        com.huawei.www.hss.RMV_ANUMBLST rMV_ANUMBLST) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rMV_ANUMBLST");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS33
     * @return mOD_BS33Response
     */
    public com.huawei.www.hss.MOD_BS33Response mOD_BS33(
        com.huawei.www.hss.MOD_BS33 mOD_BS33) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS33");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_FMREG
     * @return mOD_FMREGResponse
     */
    public com.huawei.www.hss.MOD_FMREGResponse mOD_FMREG(
        com.huawei.www.hss.MOD_FMREG mOD_FMREG) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_FMREG");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ARD
     * @return lST_ARDResponse
     */
    public com.huawei.www.hss.LST_ARDResponse lST_ARD(
        com.huawei.www.hss.LST_ARD lST_ARD) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ARD");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_NONSUB
     * @return mOD_NONSUBResponse
     */
    public com.huawei.www.hss.MOD_NONSUBResponse mOD_NONSUB(
        com.huawei.www.hss.MOD_NONSUB mOD_NONSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_NONSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_EXEXROUTECATEGORY
     * @return mOD_EXEXROUTECATEGORYResponse
     */
    public com.huawei.www.hss.MOD_EXEXROUTECATEGORYResponse mOD_EXEXROUTECATEGORY(
        com.huawei.www.hss.MOD_EXEXROUTECATEGORY mOD_EXEXROUTECATEGORY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_EXEXROUTECATEGORY");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ELCS
     * @return lST_ELCSResponse
     */
    public com.huawei.www.hss.LST_ELCSResponse lST_ELCS(
        com.huawei.www.hss.LST_ELCS lST_ELCS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ELCS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_NAEA
     * @return lST_NAEAResponse
     */
    public com.huawei.www.hss.LST_NAEAResponse lST_NAEA(
        com.huawei.www.hss.LST_NAEA lST_NAEA) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_NAEA");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_M2MCISDN
     * @return mOD_M2MCISDNResponse
     */
    public com.huawei.www.hss.MOD_M2MCISDNResponse mOD_M2MCISDN(
        com.huawei.www.hss.MOD_M2MCISDN mOD_M2MCISDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_M2MCISDN");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_NTCSI
     * @return lST_NTCSIResponse
     */
    public com.huawei.www.hss.LST_NTCSIResponse lST_NTCSI(
        com.huawei.www.hss.LST_NTCSI lST_NTCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_NTCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_MPTY
     * @return lST_MPTYResponse
     */
    public com.huawei.www.hss.LST_MPTYResponse lST_MPTY(
        com.huawei.www.hss.LST_MPTY lST_MPTY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_MPTY");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS42
     * @return mOD_BS42Response
     */
    public com.huawei.www.hss.MOD_BS42Response mOD_BS42(
        com.huawei.www.hss.MOD_BS42 mOD_BS42) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS42");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_GROUPUSER
     * @return mOD_GROUPUSERResponse
     */
    public com.huawei.www.hss.MOD_GROUPUSERResponse mOD_GROUPUSER(
        com.huawei.www.hss.MOD_GROUPUSER mOD_GROUPUSER) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_GROUPUSER");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_IMOCSI
     * @return mOD_IMOCSIResponse
     */
    public com.huawei.www.hss.MOD_IMOCSIResponse mOD_IMOCSI(
        com.huawei.www.hss.MOD_IMOCSI mOD_IMOCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_IMOCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TPLROAMPER
     * @return mOD_TPLROAMPERResponse
     */
    public com.huawei.www.hss.MOD_TPLROAMPERResponse mOD_TPLROAMPER(
        com.huawei.www.hss.MOD_TPLROAMPER mOD_TPLROAMPER) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TPLROAMPER");
    }

    /**
     * Auto generated method signature
     *
     * @param dEA_CFD
     * @return dEA_CFDResponse
     */
    public com.huawei.www.hss.DEA_CFDResponse dEA_CFD(
        com.huawei.www.hss.DEA_CFD dEA_CFD) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#dEA_CFD");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CLIP
     * @return mOD_CLIPResponse
     */
    public com.huawei.www.hss.MOD_CLIPResponse mOD_CLIP(
        com.huawei.www.hss.MOD_CLIP mOD_CLIP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CLIP");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_MIMSIVM
     * @return mOD_MIMSIVMResponse
     */
    public com.huawei.www.hss.MOD_MIMSIVMResponse mOD_MIMSIVM(
        com.huawei.www.hss.MOD_MIMSIVM mOD_MIMSIVM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_MIMSIVM");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BAOC
     * @return mOD_BAOCResponse
     */
    public com.huawei.www.hss.MOD_BAOCResponse mOD_BAOC(
        com.huawei.www.hss.MOD_BAOC mOD_BAOC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BAOC");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CNAP
     * @return lST_CNAPResponse
     */
    public com.huawei.www.hss.LST_CNAPResponse lST_CNAP(
        com.huawei.www.hss.LST_CNAP lST_CNAP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CNAP");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CFU
     * @return mOD_CFUResponse
     */
    public com.huawei.www.hss.MOD_CFUResponse mOD_CFU(
        com.huawei.www.hss.MOD_CFU mOD_CFU) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CFU");
    }

    /**
     * Auto generated method signature
     *
     * @param rEG_CFB
     * @return rEG_CFBResponse
     */
    public com.huawei.www.hss.REG_CFBResponse rEG_CFB(
        com.huawei.www.hss.REG_CFB rEG_CFB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rEG_CFB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_COLR
     * @return mOD_COLRResponse
     */
    public com.huawei.www.hss.MOD_COLRResponse mOD_COLR(
        com.huawei.www.hss.MOD_COLR mOD_COLR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_COLR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_MAPADDRRES
     * @return mOD_MAPADDRRESResponse
     */
    public com.huawei.www.hss.MOD_MAPADDRRESResponse mOD_MAPADDRRES(
        com.huawei.www.hss.MOD_MAPADDRRES mOD_MAPADDRRES) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_MAPADDRRES");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_VTCSI
     * @return mOD_VTCSIResponse
     */
    public com.huawei.www.hss.MOD_VTCSIResponse mOD_VTCSI(
        com.huawei.www.hss.MOD_VTCSI mOD_VTCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_VTCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param cLR_APNDYNDATA
     * @return cLR_APNDYNDATAResponse
     */
    public com.huawei.www.hss.CLR_APNDYNDATAResponse cLR_APNDYNDATA(
        com.huawei.www.hss.CLR_APNDYNDATA cLR_APNDYNDATA) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#cLR_APNDYNDATA");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_NPDONORSUB
     * @return aDD_NPDONORSUBResponse
     */
    public com.huawei.www.hss.ADD_NPDONORSUBResponse aDD_NPDONORSUB(
        com.huawei.www.hss.ADD_NPDONORSUB aDD_NPDONORSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_NPDONORSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ECT
     * @return lST_ECTResponse
     */
    public com.huawei.www.hss.LST_ECTResponse lST_ECT(
        com.huawei.www.hss.LST_ECT lST_ECT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ECT");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_OKSC
     * @return lST_OKSCResponse
     */
    public com.huawei.www.hss.LST_OKSCResponse lST_OKSC(
        com.huawei.www.hss.LST_OKSC lST_OKSC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_OKSC");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_MERBT
     * @return lST_MERBTResponse
     */
    public com.huawei.www.hss.LST_MERBTResponse lST_MERBT(
        com.huawei.www.hss.LST_MERBT lST_MERBT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_MERBT");
    }

    /**
     * Auto generated method signature
     *
     * @param cLR_SUBMWD
     * @return cLR_SUBMWDResponse
     */
    public com.huawei.www.hss.CLR_SUBMWDResponse cLR_SUBMWD(
        com.huawei.www.hss.CLR_SUBMWD cLR_SUBMWD) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#cLR_SUBMWD");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_DEFAULTOFA
     * @return lST_DEFAULTOFAResponse
     */
    public com.huawei.www.hss.LST_DEFAULTOFAResponse lST_DEFAULTOFA(
        com.huawei.www.hss.LST_DEFAULTOFA lST_DEFAULTOFA) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_DEFAULTOFA");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_EIN
     * @return mOD_EINResponse
     */
    public com.huawei.www.hss.MOD_EINResponse mOD_EIN(
        com.huawei.www.hss.MOD_EIN mOD_EIN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_EIN");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ODBECT
     * @return mOD_ODBECTResponse
     */
    public com.huawei.www.hss.MOD_ODBECTResponse mOD_ODBECT(
        com.huawei.www.hss.MOD_ODBECT mOD_ODBECT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODBECT");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ODBROAM
     * @return mOD_ODBROAMResponse
     */
    public com.huawei.www.hss.MOD_ODBROAMResponse mOD_ODBROAM(
        com.huawei.www.hss.MOD_ODBROAM mOD_ODBROAM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODBROAM");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TPLVBS
     * @return mOD_TPLVBSResponse
     */
    public com.huawei.www.hss.MOD_TPLVBSResponse mOD_TPLVBS(
        com.huawei.www.hss.MOD_TPLVBS mOD_TPLVBS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TPLVBS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS61
     * @return mOD_BS61Response
     */
    public com.huawei.www.hss.MOD_BS61Response mOD_BS61(
        com.huawei.www.hss.MOD_BS61 mOD_BS61) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS61");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_BS
     * @return lST_BSResponse
     */
    public com.huawei.www.hss.LST_BSResponse lST_BS(
        com.huawei.www.hss.LST_BS lST_BS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_BS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_RBT
     * @return lST_RBTResponse
     */
    public com.huawei.www.hss.LST_RBTResponse lST_RBT(
        com.huawei.www.hss.LST_RBT lST_RBT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_RBT");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_MNUG
     * @return lST_MNUGResponse
     */
    public com.huawei.www.hss.LST_MNUGResponse lST_MNUG(
        com.huawei.www.hss.LST_MNUG lST_MNUG) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_MNUG");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CUG
     * @return lST_CUGResponse
     */
    public com.huawei.www.hss.LST_CUGResponse lST_CUG(
        com.huawei.www.hss.LST_CUG lST_CUG) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CUG");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CAMEL
     * @return mOD_CAMELResponse
     */
    public com.huawei.www.hss.MOD_CAMELResponse mOD_CAMEL(
        com.huawei.www.hss.MOD_CAMEL mOD_CAMEL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CAMEL");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_EMMIN
     * @return lST_EMMINResponse
     */
    public com.huawei.www.hss.LST_EMMINResponse lST_EMMIN(
        com.huawei.www.hss.LST_EMMIN lST_EMMIN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_EMMIN");
    }

    /**
     * Auto generated method signature
     *
     * @param aCT_ISDN
     * @return aCT_ISDNResponse
     */
    public com.huawei.www.hss.ACT_ISDNResponse aCT_ISDN(
        com.huawei.www.hss.ACT_ISDN aCT_ISDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aCT_ISDN");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_FRAUD
     * @return mOD_FRAUDResponse
     */
    public com.huawei.www.hss.MOD_FRAUDResponse mOD_FRAUD(
        com.huawei.www.hss.MOD_FRAUD mOD_FRAUD) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_FRAUD");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TELE
     * @return mOD_TELEResponse
     */
    public com.huawei.www.hss.MOD_TELEResponse mOD_TELE(
        com.huawei.www.hss.MOD_TELE mOD_TELE) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TELE");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ISDN
     * @return mOD_ISDNResponse
     */
    public com.huawei.www.hss.MOD_ISDNResponse mOD_ISDN(
        com.huawei.www.hss.MOD_ISDN mOD_ISDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ISDN");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS45
     * @return mOD_BS45Response
     */
    public com.huawei.www.hss.MOD_BS45Response mOD_BS45(
        com.huawei.www.hss.MOD_BS45 mOD_BS45) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS45");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CFD
     * @return mOD_CFDResponse
     */
    public com.huawei.www.hss.MOD_CFDResponse mOD_CFD(
        com.huawei.www.hss.MOD_CFD mOD_CFD) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CFD");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CARP
     * @return lST_CARPResponse
     */
    public com.huawei.www.hss.LST_CARPResponse lST_CARP(
        com.huawei.www.hss.LST_CARP lST_CARP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CARP");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_RZONE
     * @return lST_RZONEResponse
     */
    public com.huawei.www.hss.LST_RZONEResponse lST_RZONE(
        com.huawei.www.hss.LST_RZONE lST_RZONE) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_RZONE");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_GROUPSIM
     * @return lST_GROUPSIMResponse
     */
    public com.huawei.www.hss.LST_GROUPSIMResponse lST_GROUPSIM(
        com.huawei.www.hss.LST_GROUPSIM lST_GROUPSIM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_GROUPSIM");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CATEGORY
     * @return mOD_CATEGORYResponse
     */
    public com.huawei.www.hss.MOD_CATEGORYResponse mOD_CATEGORY(
        com.huawei.www.hss.MOD_CATEGORY mOD_CATEGORY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CATEGORY");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_DIAMRRS
     * @return lST_DIAMRRSResponse
     */
    public com.huawei.www.hss.LST_DIAMRRSResponse lST_DIAMRRS(
        com.huawei.www.hss.LST_DIAMRRS lST_DIAMRRS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_DIAMRRS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_GPRSLCK
     * @return mOD_GPRSLCKResponse
     */
    public com.huawei.www.hss.MOD_GPRSLCKResponse mOD_GPRSLCK(
        com.huawei.www.hss.MOD_GPRSLCK mOD_GPRSLCK) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_GPRSLCK");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_OPTGPRS
     * @return mOD_OPTGPRSResponse
     */
    public com.huawei.www.hss.MOD_OPTGPRSResponse mOD_OPTGPRS(
        com.huawei.www.hss.MOD_OPTGPRS mOD_OPTGPRS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_OPTGPRS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_DYNZC
     * @return lST_DYNZCResponse
     */
    public com.huawei.www.hss.LST_DYNZCResponse lST_DYNZC(
        com.huawei.www.hss.LST_DYNZC lST_DYNZC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_DYNZC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_GPRSCSI
     * @return mOD_GPRSCSIResponse
     */
    public com.huawei.www.hss.MOD_GPRSCSIResponse mOD_GPRSCSI(
        com.huawei.www.hss.MOD_GPRSCSI mOD_GPRSCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_GPRSCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param rMV_NPDONORSUB
     * @return rMV_NPDONORSUBResponse
     */
    public com.huawei.www.hss.RMV_NPDONORSUBResponse rMV_NPDONORSUB(
        com.huawei.www.hss.RMV_NPDONORSUB rMV_NPDONORSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rMV_NPDONORSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ODBSS
     * @return mOD_ODBSSResponse
     */
    public com.huawei.www.hss.MOD_ODBSSResponse mOD_ODBSS(
        com.huawei.www.hss.MOD_ODBSS mOD_ODBSS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODBSS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CLIR
     * @return lST_CLIRResponse
     */
    public com.huawei.www.hss.LST_CLIRResponse lST_CLIR(
        com.huawei.www.hss.LST_CLIR lST_CLIR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CLIR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_SMDP
     * @return mOD_SMDPResponse
     */
    public com.huawei.www.hss.MOD_SMDPResponse mOD_SMDP(
        com.huawei.www.hss.MOD_SMDP mOD_SMDP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_SMDP");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TPLOPTGPRS
     * @return mOD_TPLOPTGPRSResponse
     */
    public com.huawei.www.hss.MOD_TPLOPTGPRSResponse mOD_TPLOPTGPRS(
        com.huawei.www.hss.MOD_TPLOPTGPRS mOD_TPLOPTGPRS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TPLOPTGPRS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_USERCATEGORY
     * @return lST_USERCATEGORYResponse
     */
    public com.huawei.www.hss.LST_USERCATEGORYResponse lST_USERCATEGORY(
        com.huawei.www.hss.LST_USERCATEGORY lST_USERCATEGORY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_USERCATEGORY");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_IMEIBIND
     * @return lST_IMEIBINDResponse
     */
    public com.huawei.www.hss.LST_IMEIBINDResponse lST_IMEIBIND(
        com.huawei.www.hss.LST_IMEIBIND lST_IMEIBIND) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_IMEIBIND");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS22
     * @return mOD_BS22Response
     */
    public com.huawei.www.hss.MOD_BS22Response mOD_BS22(
        com.huawei.www.hss.MOD_BS22 mOD_BS22) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS22");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_FM
     * @return mOD_FMResponse
     */
    public com.huawei.www.hss.MOD_FMResponse mOD_FM(
        com.huawei.www.hss.MOD_FM mOD_FM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_FM");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_RBT
     * @return mOD_RBTResponse
     */
    public com.huawei.www.hss.MOD_RBTResponse mOD_RBT(
        com.huawei.www.hss.MOD_RBT mOD_RBT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_RBT");
    }

    /**
     * Auto generated method signature
     *
     * @param rMV_USCSUB
     * @return rMV_USCSUBResponse
     */
    public com.huawei.www.hss.RMV_USCSUBResponse rMV_USCSUB(
        com.huawei.www.hss.RMV_USCSUB rMV_USCSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rMV_USCSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_VSRR
     * @return mOD_VSRRResponse
     */
    public com.huawei.www.hss.MOD_VSRRResponse mOD_VSRR(
        com.huawei.www.hss.MOD_VSRR mOD_VSRR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_VSRR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TPLGPRS
     * @return mOD_TPLGPRSResponse
     */
    public com.huawei.www.hss.MOD_TPLGPRSResponse mOD_TPLGPRS(
        com.huawei.www.hss.MOD_TPLGPRS mOD_TPLGPRS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TPLGPRS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_MSCNUM
     * @return mOD_MSCNUMResponse
     */
    public com.huawei.www.hss.MOD_MSCNUMResponse mOD_MSCNUM(
        com.huawei.www.hss.MOD_MSCNUM mOD_MSCNUM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_MSCNUM");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_PRERES
     * @return lST_PRERESResponse
     */
    public com.huawei.www.hss.LST_PRERESResponse lST_PRERES(
        com.huawei.www.hss.LST_PRERES lST_PRERES) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_PRERES");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CFNRY
     * @return mOD_CFNRYResponse
     */
    public com.huawei.www.hss.MOD_CFNRYResponse mOD_CFNRY(
        com.huawei.www.hss.MOD_CFNRY mOD_CFNRY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CFNRY");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_SUB
     * @return lST_SUBResponse
     */
    public com.huawei.www.hss.LST_SUBResponse lST_SUB(
        com.huawei.www.hss.LST_SUB lST_SUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_SUB");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CSI
     * @return lST_CSIResponse
     */
    public com.huawei.www.hss.LST_CSIResponse lST_CSI(
        com.huawei.www.hss.LST_CSI lST_CSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CSI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS32
     * @return mOD_BS32Response
     */
    public com.huawei.www.hss.MOD_BS32Response mOD_BS32(
        com.huawei.www.hss.MOD_BS32 mOD_BS32) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS32");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_PSSER
     * @return mOD_PSSERResponse
     */
    public com.huawei.www.hss.MOD_PSSERResponse mOD_PSSER(
        com.huawei.www.hss.MOD_PSSER mOD_PSSER) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_PSSER");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS41
     * @return mOD_BS41Response
     */
    public com.huawei.www.hss.MOD_BS41Response mOD_BS41(
        com.huawei.www.hss.MOD_BS41 mOD_BS41) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS41");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_VVDN
     * @return mOD_VVDNResponse
     */
    public com.huawei.www.hss.MOD_VVDNResponse mOD_VVDN(
        com.huawei.www.hss.MOD_VVDN mOD_VVDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_VVDN");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_NPDONORSUB
     * @return mOD_NPDONORSUBResponse
     */
    public com.huawei.www.hss.MOD_NPDONORSUBResponse mOD_NPDONORSUB(
        com.huawei.www.hss.MOD_NPDONORSUB mOD_NPDONORSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_NPDONORSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_VSRR
     * @return lST_VSRRResponse
     */
    public com.huawei.www.hss.LST_VSRRResponse lST_VSRR(
        com.huawei.www.hss.LST_VSRR lST_VSRR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_VSRR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CLIR
     * @return mOD_CLIRResponse
     */
    public com.huawei.www.hss.MOD_CLIRResponse mOD_CLIR(
        com.huawei.www.hss.MOD_CLIR mOD_CLIR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CLIR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_NPNS
     * @return mOD_NPNSResponse
     */
    public com.huawei.www.hss.MOD_NPNSResponse mOD_NPNS(
        com.huawei.www.hss.MOD_NPNS mOD_NPNS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_NPNS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_NIR
     * @return lST_NIRResponse
     */
    public com.huawei.www.hss.LST_NIRResponse lST_NIR(
        com.huawei.www.hss.LST_NIR lST_NIR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_NIR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_PLMNRSZI
     * @return mOD_PLMNRSZIResponse
     */
    public com.huawei.www.hss.MOD_PLMNRSZIResponse mOD_PLMNRSZI(
        com.huawei.www.hss.MOD_PLMNRSZI mOD_PLMNRSZI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_PLMNRSZI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CNAP
     * @return mOD_CNAPResponse
     */
    public com.huawei.www.hss.MOD_CNAPResponse mOD_CNAP(
        com.huawei.www.hss.MOD_CNAP mOD_CNAP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CNAP");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TS
     * @return mOD_TSResponse
     */
    public com.huawei.www.hss.MOD_TSResponse mOD_TS(
        com.huawei.www.hss.MOD_TS mOD_TS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ANCHOR
     * @return lST_ANCHORResponse
     */
    public com.huawei.www.hss.LST_ANCHORResponse lST_ANCHOR(
        com.huawei.www.hss.LST_ANCHOR lST_ANCHOR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ANCHOR");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_PREMSMS
     * @return lST_PREMSMSResponse
     */
    public com.huawei.www.hss.LST_PREMSMSResponse lST_PREMSMS(
        com.huawei.www.hss.LST_PREMSMS lST_PREMSMS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_PREMSMS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_RSZI
     * @return lST_RSZIResponse
     */
    public com.huawei.www.hss.LST_RSZIResponse lST_RSZI(
        com.huawei.www.hss.LST_RSZI lST_RSZI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_RSZI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_EPS
     * @return lST_EPSResponse
     */
    public com.huawei.www.hss.LST_EPSResponse lST_EPS(
        com.huawei.www.hss.LST_EPS lST_EPS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_EPS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CARDPARA
     * @return mOD_CARDPARAResponse
     */
    public com.huawei.www.hss.MOD_CARDPARAResponse mOD_CARDPARA(
        com.huawei.www.hss.MOD_CARDPARA mOD_CARDPARA) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CARDPARA");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ODBPB1
     * @return mOD_ODBPB1Response
     */
    public com.huawei.www.hss.MOD_ODBPB1Response mOD_ODBPB1(
        com.huawei.www.hss.MOD_ODBPB1 mOD_ODBPB1) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODBPB1");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_SCPBWADDR
     * @return mOD_SCPBWADDRResponse
     */
    public com.huawei.www.hss.MOD_SCPBWADDRResponse mOD_SCPBWADDR(
        com.huawei.www.hss.MOD_SCPBWADDR mOD_SCPBWADDR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_SCPBWADDR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_UUS
     * @return mOD_UUSResponse
     */
    public com.huawei.www.hss.MOD_UUSResponse mOD_UUS(
        com.huawei.www.hss.MOD_UUS mOD_UUS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_UUS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CFALL
     * @return lST_CFALLResponse
     */
    public com.huawei.www.hss.LST_CFALLResponse lST_CFALL(
        com.huawei.www.hss.LST_CFALL lST_CFALL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CFALL");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_KI
     * @return aDD_KIResponse
     */
    public com.huawei.www.hss.ADD_KIResponse aDD_KI(
        com.huawei.www.hss.ADD_KI aDD_KI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_KI");
    }

    /**
     * Auto generated method signature
     *
     * @param sND_FMNOTIFY
     * @return sND_FMNOTIFYResponse
     */
    public com.huawei.www.hss.SND_FMNOTIFYResponse sND_FMNOTIFY(
        com.huawei.www.hss.SND_FMNOTIFY sND_FMNOTIFY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#sND_FMNOTIFY");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CATEGORY
     * @return lST_CATEGORYResponse
     */
    public com.huawei.www.hss.LST_CATEGORYResponse lST_CATEGORY(
        com.huawei.www.hss.LST_CATEGORY lST_CATEGORY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CATEGORY");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CSISTATE
     * @return mOD_CSISTATEResponse
     */
    public com.huawei.www.hss.MOD_CSISTATEResponse mOD_CSISTATE(
        com.huawei.www.hss.MOD_CSISTATE mOD_CSISTATE) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CSISTATE");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_OKSC
     * @return mOD_OKSCResponse
     */
    public com.huawei.www.hss.MOD_OKSCResponse mOD_OKSC(
        com.huawei.www.hss.MOD_OKSC mOD_OKSC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_OKSC");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ACR
     * @return lST_ACRResponse
     */
    public com.huawei.www.hss.LST_ACRResponse lST_ACR(
        com.huawei.www.hss.LST_ACR lST_ACR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ACR");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CCGLOBAL
     * @return lST_CCGLOBALResponse
     */
    public com.huawei.www.hss.LST_CCGLOBALResponse lST_CCGLOBAL(
        com.huawei.www.hss.LST_CCGLOBAL lST_CCGLOBAL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CCGLOBAL");
    }

    /**
     * Auto generated method signature
     *
     * @param sET_NEWSID
     * @return sET_NEWSIDResponse
     */
    public com.huawei.www.hss.SET_NEWSIDResponse sET_NEWSID(
        com.huawei.www.hss.SET_NEWSID sET_NEWSID) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#sET_NEWSID");
    }

    /**
     * Auto generated method signature
     *
     * @param aCT_BAOC
     * @return aCT_BAOCResponse
     */
    public com.huawei.www.hss.ACT_BAOCResponse aCT_BAOC(
        com.huawei.www.hss.ACT_BAOC aCT_BAOC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aCT_BAOC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ARD
     * @return mOD_ARDResponse
     */
    public com.huawei.www.hss.MOD_ARDResponse mOD_ARD(
        com.huawei.www.hss.MOD_ARD mOD_ARD) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ARD");
    }

    /**
     * Auto generated method signature
     *
     * @param rMV_CSPSSUB
     * @return rMV_CSPSSUBResponse
     */
    public com.huawei.www.hss.RMV_CSPSSUBResponse rMV_CSPSSUB(
        com.huawei.www.hss.RMV_CSPSSUB rMV_CSPSSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rMV_CSPSSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BARPWD
     * @return mOD_BARPWDResponse
     */
    public com.huawei.www.hss.MOD_BARPWDResponse mOD_BARPWD(
        com.huawei.www.hss.MOD_BARPWD mOD_BARPWD) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BARPWD");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_PLMN
     * @return mOD_PLMNResponse
     */
    public com.huawei.www.hss.MOD_PLMNResponse mOD_PLMN(
        com.huawei.www.hss.MOD_PLMN mOD_PLMN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_PLMN");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_IST
     * @return lST_ISTResponse
     */
    public com.huawei.www.hss.LST_ISTResponse lST_IST(
        com.huawei.www.hss.LST_IST lST_IST) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_IST");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_DND
     * @return mOD_DNDResponse
     */
    public com.huawei.www.hss.MOD_DNDResponse mOD_DND(
        com.huawei.www.hss.MOD_DND mOD_DND) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_DND");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ECT
     * @return mOD_ECTResponse
     */
    public com.huawei.www.hss.MOD_ECTResponse mOD_ECT(
        com.huawei.www.hss.MOD_ECT mOD_ECT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ECT");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ODB
     * @return mOD_ODBResponse
     */
    public com.huawei.www.hss.MOD_ODBResponse mOD_ODB(
        com.huawei.www.hss.MOD_ODB mOD_ODB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS31
     * @return mOD_BS31Response
     */
    public com.huawei.www.hss.MOD_BS31Response mOD_BS31(
        com.huawei.www.hss.MOD_BS31 mOD_BS31) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS31");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_ANUMBLST
     * @return aDD_ANUMBLSTResponse
     */
    public com.huawei.www.hss.ADD_ANUMBLSTResponse aDD_ANUMBLST(
        com.huawei.www.hss.ADD_ANUMBLST aDD_ANUMBLST) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_ANUMBLST");
    }

    /**
     * Auto generated method signature
     *
     * @param rEG_CFNRY
     * @return rEG_CFNRYResponse
     */
    public com.huawei.www.hss.REG_CFNRYResponse rEG_CFNRY(
        com.huawei.www.hss.REG_CFNRY rEG_CFNRY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rEG_CFNRY");
    }

    /**
     * Auto generated method signature
     *
     * @param eRA_CFU
     * @return eRA_CFUResponse
     */
    public com.huawei.www.hss.ERA_CFUResponse eRA_CFU(
        com.huawei.www.hss.ERA_CFU eRA_CFU) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#eRA_CFU");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS44
     * @return mOD_BS44Response
     */
    public com.huawei.www.hss.MOD_BS44Response mOD_BS44(
        com.huawei.www.hss.MOD_BS44 mOD_BS44) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS44");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TS62
     * @return mOD_TS62Response
     */
    public com.huawei.www.hss.MOD_TS62Response mOD_TS62(
        com.huawei.www.hss.MOD_TS62 mOD_TS62) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TS62");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS23
     * @return mOD_BS23Response
     */
    public com.huawei.www.hss.MOD_BS23Response mOD_BS23(
        com.huawei.www.hss.MOD_BS23 mOD_BS23) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS23");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ACR
     * @return mOD_ACRResponse
     */
    public com.huawei.www.hss.MOD_ACRResponse mOD_ACR(
        com.huawei.www.hss.MOD_ACR mOD_ACR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ACR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_GROUPSIM
     * @return mOD_GROUPSIMResponse
     */
    public com.huawei.www.hss.MOD_GROUPSIMResponse mOD_GROUPSIM(
        com.huawei.www.hss.MOD_GROUPSIM mOD_GROUPSIM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_GROUPSIM");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_GPRSLCK
     * @return lST_GPRSLCKResponse
     */
    public com.huawei.www.hss.LST_GPRSLCKResponse lST_GPRSLCK(
        com.huawei.www.hss.LST_GPRSLCK lST_GPRSLCK) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_GPRSLCK");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_TPLSUB
     * @return aDD_TPLSUBResponse
     */
    public com.huawei.www.hss.ADD_TPLSUBResponse aDD_TPLSUB(
        com.huawei.www.hss.ADD_TPLSUB aDD_TPLSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_TPLSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_SMSMO
     * @return mOD_SMSMOResponse
     */
    public com.huawei.www.hss.MOD_SMSMOResponse mOD_SMSMO(
        com.huawei.www.hss.MOD_SMSMO mOD_SMSMO) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_SMSMO");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_EPSODB
     * @return mOD_EPSODBResponse
     */
    public com.huawei.www.hss.MOD_EPSODBResponse mOD_EPSODB(
        com.huawei.www.hss.MOD_EPSODB mOD_EPSODB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_EPSODB");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_MC
     * @return lST_MCResponse
     */
    public com.huawei.www.hss.LST_MCResponse lST_MC(
        com.huawei.www.hss.LST_MC lST_MC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_MC");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_LCK
     * @return lST_LCKResponse
     */
    public com.huawei.www.hss.LST_LCKResponse lST_LCK(
        com.huawei.www.hss.LST_LCK lST_LCK) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_LCK");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_VGCS
     * @return mOD_VGCSResponse
     */
    public com.huawei.www.hss.MOD_VGCSResponse mOD_VGCS(
        com.huawei.www.hss.MOD_VGCS mOD_VGCS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_VGCS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_RFPRID
     * @return mOD_RFPRIDResponse
     */
    public com.huawei.www.hss.MOD_RFPRIDResponse mOD_RFPRID(
        com.huawei.www.hss.MOD_RFPRID mOD_RFPRID) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_RFPRID");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ANCHOR
     * @return mOD_ANCHORResponse
     */
    public com.huawei.www.hss.MOD_ANCHORResponse mOD_ANCHOR(
        com.huawei.www.hss.MOD_ANCHOR mOD_ANCHOR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ANCHOR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_AUTHUSER
     * @return mOD_AUTHUSERResponse
     */
    public com.huawei.www.hss.MOD_AUTHUSERResponse mOD_AUTHUSER(
        com.huawei.www.hss.MOD_AUTHUSER mOD_AUTHUSER) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_AUTHUSER");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_SS
     * @return lST_SSResponse
     */
    public com.huawei.www.hss.LST_SSResponse lST_SS(
        com.huawei.www.hss.LST_SS lST_SS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_SS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_STNSR
     * @return lST_STNSRResponse
     */
    public com.huawei.www.hss.LST_STNSRResponse lST_STNSR(
        com.huawei.www.hss.LST_STNSR lST_STNSR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_STNSR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_MERBT
     * @return mOD_MERBTResponse
     */
    public com.huawei.www.hss.MOD_MERBTResponse mOD_MERBT(
        com.huawei.www.hss.MOD_MERBT mOD_MERBT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_MERBT");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BAIC
     * @return mOD_BAICResponse
     */
    public com.huawei.www.hss.MOD_BAICResponse mOD_BAIC(
        com.huawei.www.hss.MOD_BAIC mOD_BAIC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BAIC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_GRPUSERATTR
     * @return mOD_GRPUSERATTRResponse
     */
    public com.huawei.www.hss.MOD_GRPUSERATTRResponse mOD_GRPUSERATTR(
        com.huawei.www.hss.MOD_GRPUSERATTR mOD_GRPUSERATTR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_GRPUSERATTR");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_MIMSIVM
     * @return lST_MIMSIVMResponse
     */
    public com.huawei.www.hss.LST_MIMSIVMResponse lST_MIMSIVM(
        com.huawei.www.hss.LST_MIMSIVM lST_MIMSIVM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_MIMSIVM");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ICSIND
     * @return mOD_ICSINDResponse
     */
    public com.huawei.www.hss.MOD_ICSINDResponse mOD_ICSIND(
        com.huawei.www.hss.MOD_ICSIND mOD_ICSIND) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ICSIND");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ALS
     * @return lST_ALSResponse
     */
    public com.huawei.www.hss.LST_ALSResponse lST_ALS(
        com.huawei.www.hss.LST_ALS lST_ALS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ALS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_NIR
     * @return mOD_NIRResponse
     */
    public com.huawei.www.hss.MOD_NIRResponse mOD_NIR(
        com.huawei.www.hss.MOD_NIR mOD_NIR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_NIR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_MCSI
     * @return mOD_MCSIResponse
     */
    public com.huawei.www.hss.MOD_MCSIResponse mOD_MCSI(
        com.huawei.www.hss.MOD_MCSI mOD_MCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_MCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param aCT_BOICEXHC
     * @return aCT_BOICEXHCResponse
     */
    public com.huawei.www.hss.ACT_BOICEXHCResponse aCT_BOICEXHC(
        com.huawei.www.hss.ACT_BOICEXHC aCT_BOICEXHC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aCT_BOICEXHC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CCBS
     * @return mOD_CCBSResponse
     */
    public com.huawei.www.hss.MOD_CCBSResponse mOD_CCBS(
        com.huawei.www.hss.MOD_CCBS mOD_CCBS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CCBS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CBCOU
     * @return mOD_CBCOUResponse
     */
    public com.huawei.www.hss.MOD_CBCOUResponse mOD_CBCOU(
        com.huawei.www.hss.MOD_CBCOU mOD_CBCOU) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CBCOU");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_IMVTCSI
     * @return mOD_IMVTCSIResponse
     */
    public com.huawei.www.hss.MOD_IMVTCSIResponse mOD_IMVTCSI(
        com.huawei.www.hss.MOD_IMVTCSI mOD_IMVTCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_IMVTCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_OPTGPRS
     * @return lST_OPTGPRSResponse
     */
    public com.huawei.www.hss.LST_OPTGPRSResponse lST_OPTGPRS(
        com.huawei.www.hss.LST_OPTGPRS lST_OPTGPRS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_OPTGPRS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_NPOTHERRPT
     * @return lST_NPOTHERRPTResponse
     */
    public com.huawei.www.hss.LST_NPOTHERRPTResponse lST_NPOTHERRPT(
        com.huawei.www.hss.LST_NPOTHERRPT lST_NPOTHERRPT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_NPOTHERRPT");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_OPTGPRSTPL
     * @return mOD_OPTGPRSTPLResponse
     */
    public com.huawei.www.hss.MOD_OPTGPRSTPLResponse mOD_OPTGPRSTPL(
        com.huawei.www.hss.MOD_OPTGPRSTPL mOD_OPTGPRSTPL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_OPTGPRSTPL");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ODBENTE
     * @return mOD_ODBENTEResponse
     */
    public com.huawei.www.hss.MOD_ODBENTEResponse mOD_ODBENTE(
        com.huawei.www.hss.MOD_ODBENTE mOD_ODBENTE) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODBENTE");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ODBPB3
     * @return mOD_ODBPB3Response
     */
    public com.huawei.www.hss.MOD_ODBPB3Response mOD_ODBPB3(
        com.huawei.www.hss.MOD_ODBPB3 mOD_ODBPB3) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODBPB3");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_CKI
     * @return aDD_CKIResponse
     */
    public com.huawei.www.hss.ADD_CKIResponse aDD_CKI(
        com.huawei.www.hss.ADD_CKI aDD_CKI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_CKI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_COMISDN
     * @return lST_COMISDNResponse
     */
    public com.huawei.www.hss.LST_COMISDNResponse lST_COMISDN(
        com.huawei.www.hss.LST_COMISDN lST_COMISDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_COMISDN");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CUGFTR
     * @return mOD_CUGFTRResponse
     */
    public com.huawei.www.hss.MOD_CUGFTRResponse mOD_CUGFTR(
        com.huawei.www.hss.MOD_CUGFTR mOD_CUGFTR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CUGFTR");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_CSPSSUB
     * @return aDD_CSPSSUBResponse
     */
    public com.huawei.www.hss.ADD_CSPSSUBResponse aDD_CSPSSUB(
        com.huawei.www.hss.ADD_CSPSSUB aDD_CSPSSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_CSPSSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_NRBT
     * @return mOD_NRBTResponse
     */
    public com.huawei.www.hss.MOD_NRBTResponse mOD_NRBT(
        com.huawei.www.hss.MOD_NRBT mOD_NRBT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_NRBT");
    }

    /**
     * Auto generated method signature
     *
     * @param rMV_CHANGEDISDN
     * @return rMV_CHANGEDISDNResponse
     */
    public com.huawei.www.hss.RMV_CHANGEDISDNResponse rMV_CHANGEDISDN(
        com.huawei.www.hss.RMV_CHANGEDISDN rMV_CHANGEDISDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rMV_CHANGEDISDN");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_NAM
     * @return mOD_NAMResponse
     */
    public com.huawei.www.hss.MOD_NAMResponse mOD_NAM(
        com.huawei.www.hss.MOD_NAM mOD_NAM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_NAM");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_IMSIRTSUB
     * @return mOD_IMSIRTSUBResponse
     */
    public com.huawei.www.hss.MOD_IMSIRTSUBResponse mOD_IMSIRTSUB(
        com.huawei.www.hss.MOD_IMSIRTSUB mOD_IMSIRTSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_IMSIRTSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_LCK
     * @return mOD_LCKResponse
     */
    public com.huawei.www.hss.MOD_LCKResponse mOD_LCK(
        com.huawei.www.hss.MOD_LCK mOD_LCK) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_LCK");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS24
     * @return mOD_BS24Response
     */
    public com.huawei.www.hss.MOD_BS24Response mOD_BS24(
        com.huawei.www.hss.MOD_BS24 mOD_BS24) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS24");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_MSIM
     * @return mOD_MSIMResponse
     */
    public com.huawei.www.hss.MOD_MSIMResponse mOD_MSIM(
        com.huawei.www.hss.MOD_MSIM mOD_MSIM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_MSIM");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_M2MCISDN
     * @return lST_M2MCISDNResponse
     */
    public com.huawei.www.hss.LST_M2MCISDNResponse lST_M2MCISDN(
        com.huawei.www.hss.LST_M2MCISDN lST_M2MCISDN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_M2MCISDN");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_MSIM
     * @return lST_MSIMResponse
     */
    public com.huawei.www.hss.LST_MSIMResponse lST_MSIM(
        com.huawei.www.hss.LST_MSIM lST_MSIM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_MSIM");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ODBRCF
     * @return mOD_ODBRCFResponse
     */
    public com.huawei.www.hss.MOD_ODBRCFResponse mOD_ODBRCF(
        com.huawei.www.hss.MOD_ODBRCF mOD_ODBRCF) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ODBRCF");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_HZ
     * @return lST_HZResponse
     */
    public com.huawei.www.hss.LST_HZResponse lST_HZ(
        com.huawei.www.hss.LST_HZ lST_HZ) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_HZ");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_NPOTHERRPT
     * @return aDD_NPOTHERRPTResponse
     */
    public com.huawei.www.hss.ADD_NPOTHERRPTResponse aDD_NPOTHERRPT(
        com.huawei.www.hss.ADD_NPOTHERRPT aDD_NPOTHERRPT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_NPOTHERRPT");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_HOLD
     * @return lST_HOLDResponse
     */
    public com.huawei.www.hss.LST_HOLDResponse lST_HOLD(
        com.huawei.www.hss.LST_HOLD lST_HOLD) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_HOLD");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BORO
     * @return mOD_BOROResponse
     */
    public com.huawei.www.hss.MOD_BOROResponse mOD_BORO(
        com.huawei.www.hss.MOD_BORO mOD_BORO) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BORO");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CARP
     * @return mOD_CARPResponse
     */
    public com.huawei.www.hss.MOD_CARPResponse mOD_CARP(
        com.huawei.www.hss.MOD_CARP mOD_CARP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CARP");
    }

    /**
     * Auto generated method signature
     *
     * @param rMV_NPOTHERRPT
     * @return rMV_NPOTHERRPTResponse
     */
    public com.huawei.www.hss.RMV_NPOTHERRPTResponse rMV_NPOTHERRPT(
        com.huawei.www.hss.RMV_NPOTHERRPT rMV_NPOTHERRPT) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rMV_NPOTHERRPT");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_SMSCF
     * @return mOD_SMSCFResponse
     */
    public com.huawei.www.hss.MOD_SMSCFResponse mOD_SMSCF(
        com.huawei.www.hss.MOD_SMSCF mOD_SMSCF) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_SMSCF");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_ANCHORTCSI
     * @return lST_ANCHORTCSIResponse
     */
    public com.huawei.www.hss.LST_ANCHORTCSIResponse lST_ANCHORTCSI(
        com.huawei.www.hss.LST_ANCHORTCSI lST_ANCHORTCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_ANCHORTCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_IMEIBIND
     * @return mOD_IMEIBINDResponse
     */
    public com.huawei.www.hss.MOD_IMEIBINDResponse mOD_IMEIBIND(
        com.huawei.www.hss.MOD_IMEIBIND mOD_IMEIBIND) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_IMEIBIND");
    }

    /**
     * Auto generated method signature
     *
     * @param rMV_DIAMRRTPL
     * @return rMV_DIAMRRTPLResponse
     */
    public com.huawei.www.hss.RMV_DIAMRRTPLResponse rMV_DIAMRRTPL(
        com.huawei.www.hss.RMV_DIAMRRTPL rMV_DIAMRRTPL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rMV_DIAMRRTPL");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_PSAPNOI
     * @return lST_PSAPNOIResponse
     */
    public com.huawei.www.hss.LST_PSAPNOIResponse lST_PSAPNOI(
        com.huawei.www.hss.LST_PSAPNOI lST_PSAPNOI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_PSAPNOI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CPP
     * @return lST_CPPResponse
     */
    public com.huawei.www.hss.LST_CPPResponse lST_CPP(
        com.huawei.www.hss.LST_CPP lST_CPP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CPP");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CUGSUB
     * @return mOD_CUGSUBResponse
     */
    public com.huawei.www.hss.MOD_CUGSUBResponse mOD_CUGSUB(
        com.huawei.www.hss.MOD_CUGSUB mOD_CUGSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CUGSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_IST
     * @return mOD_ISTResponse
     */
    public com.huawei.www.hss.MOD_ISTResponse mOD_IST(
        com.huawei.www.hss.MOD_IST mOD_IST) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_IST");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CFNRC
     * @return mOD_CFNRCResponse
     */
    public com.huawei.www.hss.MOD_CFNRCResponse mOD_CFNRC(
        com.huawei.www.hss.MOD_CFNRC mOD_CFNRC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CFNRC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CB
     * @return mOD_CBResponse
     */
    public com.huawei.www.hss.MOD_CBResponse mOD_CB(
        com.huawei.www.hss.MOD_CB mOD_CB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_UCSI
     * @return mOD_UCSIResponse
     */
    public com.huawei.www.hss.MOD_UCSIResponse mOD_UCSI(
        com.huawei.www.hss.MOD_UCSI mOD_UCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_UCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_MNUG
     * @return mOD_MNUGResponse
     */
    public com.huawei.www.hss.MOD_MNUGResponse mOD_MNUG(
        com.huawei.www.hss.MOD_MNUG mOD_MNUG) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_MNUG");
    }

    /**
     * Auto generated method signature
     *
     * @param dEA_BAIC
     * @return dEA_BAICResponse
     */
    public com.huawei.www.hss.DEA_BAICResponse dEA_BAIC(
        com.huawei.www.hss.DEA_BAIC dEA_BAIC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#dEA_BAIC");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ALS
     * @return mOD_ALSResponse
     */
    public com.huawei.www.hss.MOD_ALSResponse mOD_ALS(
        com.huawei.www.hss.MOD_ALS mOD_ALS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ALS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_EGR
     * @return mOD_EGRResponse
     */
    public com.huawei.www.hss.MOD_EGRResponse mOD_EGR(
        com.huawei.www.hss.MOD_EGR mOD_EGR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_EGR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_NTCSI
     * @return mOD_NTCSIResponse
     */
    public com.huawei.www.hss.MOD_NTCSIResponse mOD_NTCSI(
        com.huawei.www.hss.MOD_NTCSI mOD_NTCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_NTCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_XSUB
     * @return lST_XSUBResponse
     */
    public com.huawei.www.hss.LST_XSUBResponse lST_XSUB(
        com.huawei.www.hss.LST_XSUB lST_XSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_XSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_TPLCSPSSUB
     * @return aDD_TPLCSPSSUBResponse
     */
    public com.huawei.www.hss.ADD_TPLCSPSSUBResponse aDD_TPLCSPSSUB(
        com.huawei.www.hss.ADD_TPLCSPSSUB aDD_TPLCSPSSUB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_TPLCSPSSUB");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_LUCSI
     * @return lST_LUCSIResponse
     */
    public com.huawei.www.hss.LST_LUCSIResponse lST_LUCSI(
        com.huawei.www.hss.LST_LUCSI lST_LUCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_LUCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param dEA_BOIC
     * @return dEA_BOICResponse
     */
    public com.huawei.www.hss.DEA_BOICResponse dEA_BOIC(
        com.huawei.www.hss.DEA_BOIC dEA_BOIC) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#dEA_BOIC");
    }

    /**
     * Auto generated method signature
     *
     * @param rEG_CFU
     * @return rEG_CFUResponse
     */
    public com.huawei.www.hss.REG_CFUResponse rEG_CFU(
        com.huawei.www.hss.REG_CFU rEG_CFU) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rEG_CFU");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS46
     * @return mOD_BS46Response
     */
    public com.huawei.www.hss.MOD_BS46Response mOD_BS46(
        com.huawei.www.hss.MOD_BS46 mOD_BS46) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS46");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CA
     * @return mOD_CAResponse
     */
    public com.huawei.www.hss.MOD_CAResponse mOD_CA(
        com.huawei.www.hss.MOD_CA mOD_CA) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CA");
    }

    /**
     * Auto generated method signature
     *
     * @param aCT_BRDCASTIND
     * @return aCT_BRDCASTINDResponse
     */
    public com.huawei.www.hss.ACT_BRDCASTINDResponse aCT_BRDCASTIND(
        com.huawei.www.hss.ACT_BRDCASTIND aCT_BRDCASTIND) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aCT_BRDCASTIND");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CLIP
     * @return lST_CLIPResponse
     */
    public com.huawei.www.hss.LST_CLIPResponse lST_CLIP(
        com.huawei.www.hss.LST_CLIP lST_CLIP) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CLIP");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_TS
     * @return lST_TSResponse
     */
    public com.huawei.www.hss.LST_TSResponse lST_TS(
        com.huawei.www.hss.LST_TS lST_TS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_TS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_MPTY
     * @return mOD_MPTYResponse
     */
    public com.huawei.www.hss.MOD_MPTYResponse mOD_MPTY(
        com.huawei.www.hss.MOD_MPTY mOD_MPTY) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_MPTY");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_PSAPNOI
     * @return mOD_PSAPNOIResponse
     */
    public com.huawei.www.hss.MOD_PSAPNOIResponse mOD_PSAPNOI(
        com.huawei.www.hss.MOD_PSAPNOI mOD_PSAPNOI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_PSAPNOI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_OCSI
     * @return mOD_OCSIResponse
     */
    public com.huawei.www.hss.MOD_OCSIResponse mOD_OCSI(
        com.huawei.www.hss.MOD_OCSI mOD_OCSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_OCSI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_STNSR
     * @return mOD_STNSRResponse
     */
    public com.huawei.www.hss.MOD_STNSRResponse mOD_STNSR(
        com.huawei.www.hss.MOD_STNSR mOD_STNSR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_STNSR");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_CAPL
     * @return mOD_CAPLResponse
     */
    public com.huawei.www.hss.MOD_CAPLResponse mOD_CAPL(
        com.huawei.www.hss.MOD_CAPL mOD_CAPL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_CAPL");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_PLMNSS
     * @return mOD_PLMNSSResponse
     */
    public com.huawei.www.hss.MOD_PLMNSSResponse mOD_PLMNSS(
        com.huawei.www.hss.MOD_PLMNSS mOD_PLMNSS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_PLMNSS");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_ALSODB
     * @return mOD_ALSODBResponse
     */
    public com.huawei.www.hss.MOD_ALSODBResponse mOD_ALSODB(
        com.huawei.www.hss.MOD_ALSODB mOD_ALSODB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_ALSODB");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_MIMSI
     * @return mOD_MIMSIResponse
     */
    public com.huawei.www.hss.MOD_MIMSIResponse mOD_MIMSI(
        com.huawei.www.hss.MOD_MIMSI mOD_MIMSI) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_MIMSI");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_MMEINFO
     * @return mOD_MMEINFOResponse
     */
    public com.huawei.www.hss.MOD_MMEINFOResponse mOD_MMEINFO(
        com.huawei.www.hss.MOD_MMEINFO mOD_MMEINFO) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_MMEINFO");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_TS61
     * @return mOD_TS61Response
     */
    public com.huawei.www.hss.MOD_TS61Response mOD_TS61(
        com.huawei.www.hss.MOD_TS61 mOD_TS61) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_TS61");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_HZ
     * @return mOD_HZResponse
     */
    public com.huawei.www.hss.MOD_HZResponse mOD_HZ(
        com.huawei.www.hss.MOD_HZ mOD_HZ) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_HZ");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_DIAMRRTPL
     * @return mOD_DIAMRRTPLResponse
     */
    public com.huawei.www.hss.MOD_DIAMRRTPLResponse mOD_DIAMRRTPL(
        com.huawei.www.hss.MOD_DIAMRRTPL mOD_DIAMRRTPL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_DIAMRRTPL");
    }

    /**
     * Auto generated method signature
     *
     * @param mOD_BS53
     * @return mOD_BS53Response
     */
    public com.huawei.www.hss.MOD_BS53Response mOD_BS53(
        com.huawei.www.hss.MOD_BS53 mOD_BS53) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#mOD_BS53");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_EIN
     * @return lST_EINResponse
     */
    public com.huawei.www.hss.LST_EINResponse lST_EIN(
        com.huawei.www.hss.LST_EIN lST_EIN) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_EIN");
    }

    /**
     * Auto generated method signature
     *
     * @param rMV_GPRS
     * @return rMV_GPRSResponse
     */
    public com.huawei.www.hss.RMV_GPRSResponse rMV_GPRS(
        com.huawei.www.hss.RMV_GPRS rMV_GPRS) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#rMV_GPRS");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_DIAMRRTPL
     * @return lST_DIAMRRTPLResponse
     */
    public com.huawei.www.hss.LST_DIAMRRTPLResponse lST_DIAMRRTPL(
        com.huawei.www.hss.LST_DIAMRRTPL lST_DIAMRRTPL) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_DIAMRRTPL");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_CR
     * @return lST_CRResponse
     */
    public com.huawei.www.hss.LST_CRResponse lST_CR(
        com.huawei.www.hss.LST_CR lST_CR) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_CR");
    }

    /**
     * Auto generated method signature
     *
     * @param aDD_SCARD
     * @return aDD_SCARDResponse
     */
    public com.huawei.www.hss.ADD_SCARDResponse aDD_SCARD(
        com.huawei.www.hss.ADD_SCARD aDD_SCARD) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#aDD_SCARD");
    }

    /**
     * Auto generated method signature
     *
     * @param lST_NAM
     * @return lST_NAMResponse
     */
    public com.huawei.www.hss.LST_NAMResponse lST_NAM(
        com.huawei.www.hss.LST_NAM lST_NAM) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#lST_NAM");
    }

    /**
     * Auto generated method signature
     *
     * @param eRA_CFB
     * @return eRA_CFBResponse
     */
    public com.huawei.www.hss.ERA_CFBResponse eRA_CFB(
        com.huawei.www.hss.ERA_CFB eRA_CFB) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#eRA_CFB");
    }
}
