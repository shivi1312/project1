/**
 * GprsPdpData_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  GprsPdpData_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class GprsPdpData_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = GprsPdpData_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for GprsCntxId
     */
    protected com.huawei.www.hss.Int1_50 localGprsCntxId;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGprsCntxIdTracker = false;

    /**
     * field for GprsPdpType
     */
    protected com.huawei.www.hss._EnumType localGprsPdpType;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGprsPdpTypeTracker = false;

    /**
     * field for GprsPdpAdd
     */
    protected com.huawei.www.hss.Str1_39 localGprsPdpAdd;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGprsPdpAddTracker = false;

    /**
     * field for GprsAddInd
     */
    protected com.huawei.www.hss._EnumType localGprsAddInd;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGprsAddIndTracker = false;

    /**
     * field for GprsPdpAddIpv4
     */
    protected com.huawei.www.hss.Str7_15 localGprsPdpAddIpv4;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGprsPdpAddIpv4Tracker = false;

    /**
     * field for GprsAdd2Ind
     */
    protected com.huawei.www.hss._EnumType localGprsAdd2Ind;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGprsAdd2IndTracker = false;

    /**
     * field for RelCls
     */
    protected com.huawei.www.hss._EnumType localRelCls;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRelClsTracker = false;

    /**
     * field for DelayCls
     */
    protected com.huawei.www.hss._EnumType localDelayCls;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDelayClsTracker = false;

    /**
     * field for PreCls
     */
    protected com.huawei.www.hss._EnumType localPreCls;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPreClsTracker = false;

    /**
     * field for PEAKTHR
     */
    protected com.huawei.www.hss._EnumType localPEAKTHR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPEAKTHRTracker = false;

    /**
     * field for MEANTHR
     */
    protected com.huawei.www.hss._EnumType localMEANTHR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMEANTHRTracker = false;

    /**
     * field for ARPRIORITY
     */
    protected com.huawei.www.hss._EnumType localARPRIORITY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localARPRIORITYTracker = false;

    /**
     * field for ERRSDU
     */
    protected com.huawei.www.hss._EnumType localERRSDU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localERRSDUTracker = false;

    /**
     * field for DELIVERY
     */
    protected com.huawei.www.hss._EnumType localDELIVERY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDELIVERYTracker = false;

    /**
     * field for TRAFFICCLS
     */
    protected com.huawei.www.hss._EnumType localTRAFFICCLS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTRAFFICCLSTracker = false;

    /**
     * field for MAXSDUSIZE
     */
    protected com.huawei.www.hss._EnumType localMAXSDUSIZE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXSDUSIZETracker = false;

    /**
     * field for MAXBRUPL
     */
    protected com.huawei.www.hss._EnumType localMAXBRUPL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXBRUPLTracker = false;

    /**
     * field for MAXBRDWL
     */
    protected com.huawei.www.hss._EnumType localMAXBRDWL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXBRDWLTracker = false;

    /**
     * field for RESBER
     */
    protected com.huawei.www.hss._EnumType localRESBER;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRESBERTracker = false;

    /**
     * field for SDUERR
     */
    protected com.huawei.www.hss._EnumType localSDUERR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSDUERRTracker = false;

    /**
     * field for TRANSFERDEL
     */
    protected com.huawei.www.hss._EnumType localTRANSFERDEL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTRANSFERDELTracker = false;

    /**
     * field for TRAFFICPRI
     */
    protected com.huawei.www.hss._EnumType localTRAFFICPRI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTRAFFICPRITracker = false;

    /**
     * field for MAXGBRUPL
     */
    protected com.huawei.www.hss._EnumType localMAXGBRUPL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXGBRUPLTracker = false;

    /**
     * field for MAXGBRDWL
     */
    protected com.huawei.www.hss._EnumType localMAXGBRDWL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXGBRDWLTracker = false;

    /**
     * field for MAXEXTBRDWL
     */
    protected com.huawei.www.hss._EnumType localMAXEXTBRDWL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXEXTBRDWLTracker = false;

    /**
     * field for MAXEXTGBRDWL
     */
    protected com.huawei.www.hss._EnumType localMAXEXTGBRDWL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXEXTGBRDWLTracker = false;

    /**
     * field for MAXEXTBRUPL
     */
    protected com.huawei.www.hss._EnumType localMAXEXTBRUPL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXEXTBRUPLTracker = false;

    /**
     * field for MAXEXTGBRUPL
     */
    protected com.huawei.www.hss._EnumType localMAXEXTGBRUPL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAXEXTGBRUPLTracker = false;

    /**
     * field for APN
     */
    protected com.huawei.www.hss.Str1_63 localAPN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAPNTracker = false;

    /**
     * field for GprsVplmn
     */
    protected com.huawei.www.hss._EnumType localGprsVplmn;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGprsVplmnTracker = false;

    /**
     * field for GprsCharge
     */
    protected com.huawei.www.hss._EnumType localGprsCharge;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGprsChargeTracker = false;

    /**
     * field for GprsStdCharge
     */
    protected com.huawei.www.hss.Str4_4 localGprsStdCharge;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGprsStdChargeTracker = false;

    /**
     * field for GprsApnoiTplId
     */
    protected com.huawei.www.hss.Int0_65534 localGprsApnoiTplId;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGprsApnoiTplIdTracker = false;

    /**
     * field for VBS
     */
    protected com.huawei.www.hss.VBS_type0 localVBS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVBSTracker = false;

    public boolean isGprsCntxIdSpecified() {
        return localGprsCntxIdTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_50
     */
    public com.huawei.www.hss.Int1_50 getGprsCntxId() {
        return localGprsCntxId;
    }

    /**
     * Auto generated setter method
     * @param param GprsCntxId
     */
    public void setGprsCntxId(com.huawei.www.hss.Int1_50 param) {
        localGprsCntxIdTracker = param != null;

        this.localGprsCntxId = param;
    }

    public boolean isGprsPdpTypeSpecified() {
        return localGprsPdpTypeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getGprsPdpType() {
        return localGprsPdpType;
    }

    /**
     * Auto generated setter method
     * @param param GprsPdpType
     */
    public void setGprsPdpType(com.huawei.www.hss._EnumType param) {
        localGprsPdpTypeTracker = param != null;

        this.localGprsPdpType = param;
    }

    public boolean isGprsPdpAddSpecified() {
        return localGprsPdpAddTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_39
     */
    public com.huawei.www.hss.Str1_39 getGprsPdpAdd() {
        return localGprsPdpAdd;
    }

    /**
     * Auto generated setter method
     * @param param GprsPdpAdd
     */
    public void setGprsPdpAdd(com.huawei.www.hss.Str1_39 param) {
        localGprsPdpAddTracker = param != null;

        this.localGprsPdpAdd = param;
    }

    public boolean isGprsAddIndSpecified() {
        return localGprsAddIndTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getGprsAddInd() {
        return localGprsAddInd;
    }

    /**
     * Auto generated setter method
     * @param param GprsAddInd
     */
    public void setGprsAddInd(com.huawei.www.hss._EnumType param) {
        localGprsAddIndTracker = param != null;

        this.localGprsAddInd = param;
    }

    public boolean isGprsPdpAddIpv4Specified() {
        return localGprsPdpAddIpv4Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str7_15
     */
    public com.huawei.www.hss.Str7_15 getGprsPdpAddIpv4() {
        return localGprsPdpAddIpv4;
    }

    /**
     * Auto generated setter method
     * @param param GprsPdpAddIpv4
     */
    public void setGprsPdpAddIpv4(com.huawei.www.hss.Str7_15 param) {
        localGprsPdpAddIpv4Tracker = param != null;

        this.localGprsPdpAddIpv4 = param;
    }

    public boolean isGprsAdd2IndSpecified() {
        return localGprsAdd2IndTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getGprsAdd2Ind() {
        return localGprsAdd2Ind;
    }

    /**
     * Auto generated setter method
     * @param param GprsAdd2Ind
     */
    public void setGprsAdd2Ind(com.huawei.www.hss._EnumType param) {
        localGprsAdd2IndTracker = param != null;

        this.localGprsAdd2Ind = param;
    }

    public boolean isRelClsSpecified() {
        return localRelClsTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRelCls() {
        return localRelCls;
    }

    /**
     * Auto generated setter method
     * @param param RelCls
     */
    public void setRelCls(com.huawei.www.hss._EnumType param) {
        localRelClsTracker = param != null;

        this.localRelCls = param;
    }

    public boolean isDelayClsSpecified() {
        return localDelayClsTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDelayCls() {
        return localDelayCls;
    }

    /**
     * Auto generated setter method
     * @param param DelayCls
     */
    public void setDelayCls(com.huawei.www.hss._EnumType param) {
        localDelayClsTracker = param != null;

        this.localDelayCls = param;
    }

    public boolean isPreClsSpecified() {
        return localPreClsTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPreCls() {
        return localPreCls;
    }

    /**
     * Auto generated setter method
     * @param param PreCls
     */
    public void setPreCls(com.huawei.www.hss._EnumType param) {
        localPreClsTracker = param != null;

        this.localPreCls = param;
    }

    public boolean isPEAKTHRSpecified() {
        return localPEAKTHRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPEAKTHR() {
        return localPEAKTHR;
    }

    /**
     * Auto generated setter method
     * @param param PEAKTHR
     */
    public void setPEAKTHR(com.huawei.www.hss._EnumType param) {
        localPEAKTHRTracker = param != null;

        this.localPEAKTHR = param;
    }

    public boolean isMEANTHRSpecified() {
        return localMEANTHRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMEANTHR() {
        return localMEANTHR;
    }

    /**
     * Auto generated setter method
     * @param param MEANTHR
     */
    public void setMEANTHR(com.huawei.www.hss._EnumType param) {
        localMEANTHRTracker = param != null;

        this.localMEANTHR = param;
    }

    public boolean isARPRIORITYSpecified() {
        return localARPRIORITYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getARPRIORITY() {
        return localARPRIORITY;
    }

    /**
     * Auto generated setter method
     * @param param ARPRIORITY
     */
    public void setARPRIORITY(com.huawei.www.hss._EnumType param) {
        localARPRIORITYTracker = param != null;

        this.localARPRIORITY = param;
    }

    public boolean isERRSDUSpecified() {
        return localERRSDUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getERRSDU() {
        return localERRSDU;
    }

    /**
     * Auto generated setter method
     * @param param ERRSDU
     */
    public void setERRSDU(com.huawei.www.hss._EnumType param) {
        localERRSDUTracker = param != null;

        this.localERRSDU = param;
    }

    public boolean isDELIVERYSpecified() {
        return localDELIVERYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDELIVERY() {
        return localDELIVERY;
    }

    /**
     * Auto generated setter method
     * @param param DELIVERY
     */
    public void setDELIVERY(com.huawei.www.hss._EnumType param) {
        localDELIVERYTracker = param != null;

        this.localDELIVERY = param;
    }

    public boolean isTRAFFICCLSSpecified() {
        return localTRAFFICCLSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTRAFFICCLS() {
        return localTRAFFICCLS;
    }

    /**
     * Auto generated setter method
     * @param param TRAFFICCLS
     */
    public void setTRAFFICCLS(com.huawei.www.hss._EnumType param) {
        localTRAFFICCLSTracker = param != null;

        this.localTRAFFICCLS = param;
    }

    public boolean isMAXSDUSIZESpecified() {
        return localMAXSDUSIZETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXSDUSIZE() {
        return localMAXSDUSIZE;
    }

    /**
     * Auto generated setter method
     * @param param MAXSDUSIZE
     */
    public void setMAXSDUSIZE(com.huawei.www.hss._EnumType param) {
        localMAXSDUSIZETracker = param != null;

        this.localMAXSDUSIZE = param;
    }

    public boolean isMAXBRUPLSpecified() {
        return localMAXBRUPLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXBRUPL() {
        return localMAXBRUPL;
    }

    /**
     * Auto generated setter method
     * @param param MAXBRUPL
     */
    public void setMAXBRUPL(com.huawei.www.hss._EnumType param) {
        localMAXBRUPLTracker = param != null;

        this.localMAXBRUPL = param;
    }

    public boolean isMAXBRDWLSpecified() {
        return localMAXBRDWLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXBRDWL() {
        return localMAXBRDWL;
    }

    /**
     * Auto generated setter method
     * @param param MAXBRDWL
     */
    public void setMAXBRDWL(com.huawei.www.hss._EnumType param) {
        localMAXBRDWLTracker = param != null;

        this.localMAXBRDWL = param;
    }

    public boolean isRESBERSpecified() {
        return localRESBERTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRESBER() {
        return localRESBER;
    }

    /**
     * Auto generated setter method
     * @param param RESBER
     */
    public void setRESBER(com.huawei.www.hss._EnumType param) {
        localRESBERTracker = param != null;

        this.localRESBER = param;
    }

    public boolean isSDUERRSpecified() {
        return localSDUERRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSDUERR() {
        return localSDUERR;
    }

    /**
     * Auto generated setter method
     * @param param SDUERR
     */
    public void setSDUERR(com.huawei.www.hss._EnumType param) {
        localSDUERRTracker = param != null;

        this.localSDUERR = param;
    }

    public boolean isTRANSFERDELSpecified() {
        return localTRANSFERDELTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTRANSFERDEL() {
        return localTRANSFERDEL;
    }

    /**
     * Auto generated setter method
     * @param param TRANSFERDEL
     */
    public void setTRANSFERDEL(com.huawei.www.hss._EnumType param) {
        localTRANSFERDELTracker = param != null;

        this.localTRANSFERDEL = param;
    }

    public boolean isTRAFFICPRISpecified() {
        return localTRAFFICPRITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTRAFFICPRI() {
        return localTRAFFICPRI;
    }

    /**
     * Auto generated setter method
     * @param param TRAFFICPRI
     */
    public void setTRAFFICPRI(com.huawei.www.hss._EnumType param) {
        localTRAFFICPRITracker = param != null;

        this.localTRAFFICPRI = param;
    }

    public boolean isMAXGBRUPLSpecified() {
        return localMAXGBRUPLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXGBRUPL() {
        return localMAXGBRUPL;
    }

    /**
     * Auto generated setter method
     * @param param MAXGBRUPL
     */
    public void setMAXGBRUPL(com.huawei.www.hss._EnumType param) {
        localMAXGBRUPLTracker = param != null;

        this.localMAXGBRUPL = param;
    }

    public boolean isMAXGBRDWLSpecified() {
        return localMAXGBRDWLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXGBRDWL() {
        return localMAXGBRDWL;
    }

    /**
     * Auto generated setter method
     * @param param MAXGBRDWL
     */
    public void setMAXGBRDWL(com.huawei.www.hss._EnumType param) {
        localMAXGBRDWLTracker = param != null;

        this.localMAXGBRDWL = param;
    }

    public boolean isMAXEXTBRDWLSpecified() {
        return localMAXEXTBRDWLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXEXTBRDWL() {
        return localMAXEXTBRDWL;
    }

    /**
     * Auto generated setter method
     * @param param MAXEXTBRDWL
     */
    public void setMAXEXTBRDWL(com.huawei.www.hss._EnumType param) {
        localMAXEXTBRDWLTracker = param != null;

        this.localMAXEXTBRDWL = param;
    }

    public boolean isMAXEXTGBRDWLSpecified() {
        return localMAXEXTGBRDWLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXEXTGBRDWL() {
        return localMAXEXTGBRDWL;
    }

    /**
     * Auto generated setter method
     * @param param MAXEXTGBRDWL
     */
    public void setMAXEXTGBRDWL(com.huawei.www.hss._EnumType param) {
        localMAXEXTGBRDWLTracker = param != null;

        this.localMAXEXTGBRDWL = param;
    }

    public boolean isMAXEXTBRUPLSpecified() {
        return localMAXEXTBRUPLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXEXTBRUPL() {
        return localMAXEXTBRUPL;
    }

    /**
     * Auto generated setter method
     * @param param MAXEXTBRUPL
     */
    public void setMAXEXTBRUPL(com.huawei.www.hss._EnumType param) {
        localMAXEXTBRUPLTracker = param != null;

        this.localMAXEXTBRUPL = param;
    }

    public boolean isMAXEXTGBRUPLSpecified() {
        return localMAXEXTGBRUPLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMAXEXTGBRUPL() {
        return localMAXEXTGBRUPL;
    }

    /**
     * Auto generated setter method
     * @param param MAXEXTGBRUPL
     */
    public void setMAXEXTGBRUPL(com.huawei.www.hss._EnumType param) {
        localMAXEXTGBRUPLTracker = param != null;

        this.localMAXEXTGBRUPL = param;
    }

    public boolean isAPNSpecified() {
        return localAPNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_63
     */
    public com.huawei.www.hss.Str1_63 getAPN() {
        return localAPN;
    }

    /**
     * Auto generated setter method
     * @param param APN
     */
    public void setAPN(com.huawei.www.hss.Str1_63 param) {
        localAPNTracker = param != null;

        this.localAPN = param;
    }

    public boolean isGprsVplmnSpecified() {
        return localGprsVplmnTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getGprsVplmn() {
        return localGprsVplmn;
    }

    /**
     * Auto generated setter method
     * @param param GprsVplmn
     */
    public void setGprsVplmn(com.huawei.www.hss._EnumType param) {
        localGprsVplmnTracker = param != null;

        this.localGprsVplmn = param;
    }

    public boolean isGprsChargeSpecified() {
        return localGprsChargeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getGprsCharge() {
        return localGprsCharge;
    }

    /**
     * Auto generated setter method
     * @param param GprsCharge
     */
    public void setGprsCharge(com.huawei.www.hss._EnumType param) {
        localGprsChargeTracker = param != null;

        this.localGprsCharge = param;
    }

    public boolean isGprsStdChargeSpecified() {
        return localGprsStdChargeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str4_4
     */
    public com.huawei.www.hss.Str4_4 getGprsStdCharge() {
        return localGprsStdCharge;
    }

    /**
     * Auto generated setter method
     * @param param GprsStdCharge
     */
    public void setGprsStdCharge(com.huawei.www.hss.Str4_4 param) {
        localGprsStdChargeTracker = param != null;

        this.localGprsStdCharge = param;
    }

    public boolean isGprsApnoiTplIdSpecified() {
        return localGprsApnoiTplIdTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getGprsApnoiTplId() {
        return localGprsApnoiTplId;
    }

    /**
     * Auto generated setter method
     * @param param GprsApnoiTplId
     */
    public void setGprsApnoiTplId(com.huawei.www.hss.Int0_65534 param) {
        localGprsApnoiTplIdTracker = param != null;

        this.localGprsApnoiTplId = param;
    }

    public boolean isVBSSpecified() {
        return localVBSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.VBS_type0
     */
    public com.huawei.www.hss.VBS_type0 getVBS() {
        return localVBS;
    }

    /**
     * Auto generated setter method
     * @param param VBS
     */
    public void setVBS(com.huawei.www.hss.VBS_type0 param) {
        localVBSTracker = param != null;

        this.localVBS = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":GprsPdpData_type0", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "GprsPdpData_type0", xmlWriter);
            }
        }

        if (localGprsCntxIdTracker) {
            if (localGprsCntxId == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GprsCntxId cannot be null!!");
            }

            localGprsCntxId.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GprsCntxId"), xmlWriter);
        }

        if (localGprsPdpTypeTracker) {
            if (localGprsPdpType == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GprsPdpType cannot be null!!");
            }

            localGprsPdpType.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GprsPdpType"), xmlWriter);
        }

        if (localGprsPdpAddTracker) {
            if (localGprsPdpAdd == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GprsPdpAdd cannot be null!!");
            }

            localGprsPdpAdd.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GprsPdpAdd"), xmlWriter);
        }

        if (localGprsAddIndTracker) {
            if (localGprsAddInd == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GprsAddInd cannot be null!!");
            }

            localGprsAddInd.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GprsAddInd"), xmlWriter);
        }

        if (localGprsPdpAddIpv4Tracker) {
            if (localGprsPdpAddIpv4 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GprsPdpAddIpv4 cannot be null!!");
            }

            localGprsPdpAddIpv4.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GprsPdpAddIpv4"), xmlWriter);
        }

        if (localGprsAdd2IndTracker) {
            if (localGprsAdd2Ind == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GprsAdd2ind cannot be null!!");
            }

            localGprsAdd2Ind.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GprsAdd2ind"), xmlWriter);
        }

        if (localRelClsTracker) {
            if (localRelCls == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RelCls cannot be null!!");
            }

            localRelCls.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RelCls"), xmlWriter);
        }

        if (localDelayClsTracker) {
            if (localDelayCls == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DelayCls cannot be null!!");
            }

            localDelayCls.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DelayCls"), xmlWriter);
        }

        if (localPreClsTracker) {
            if (localPreCls == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PreCls cannot be null!!");
            }

            localPreCls.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PreCls"), xmlWriter);
        }

        if (localPEAKTHRTracker) {
            if (localPEAKTHR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PEAKTHR cannot be null!!");
            }

            localPEAKTHR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PEAKTHR"), xmlWriter);
        }

        if (localMEANTHRTracker) {
            if (localMEANTHR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MEANTHR cannot be null!!");
            }

            localMEANTHR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MEANTHR"), xmlWriter);
        }

        if (localARPRIORITYTracker) {
            if (localARPRIORITY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ARPRIORITY cannot be null!!");
            }

            localARPRIORITY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ARPRIORITY"), xmlWriter);
        }

        if (localERRSDUTracker) {
            if (localERRSDU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ERRSDU cannot be null!!");
            }

            localERRSDU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ERRSDU"), xmlWriter);
        }

        if (localDELIVERYTracker) {
            if (localDELIVERY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DELIVERY cannot be null!!");
            }

            localDELIVERY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DELIVERY"), xmlWriter);
        }

        if (localTRAFFICCLSTracker) {
            if (localTRAFFICCLS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TRAFFICCLS cannot be null!!");
            }

            localTRAFFICCLS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TRAFFICCLS"), xmlWriter);
        }

        if (localMAXSDUSIZETracker) {
            if (localMAXSDUSIZE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXSDUSIZE cannot be null!!");
            }

            localMAXSDUSIZE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXSDUSIZE"), xmlWriter);
        }

        if (localMAXBRUPLTracker) {
            if (localMAXBRUPL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXBRUPL cannot be null!!");
            }

            localMAXBRUPL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXBRUPL"), xmlWriter);
        }

        if (localMAXBRDWLTracker) {
            if (localMAXBRDWL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXBRDWL cannot be null!!");
            }

            localMAXBRDWL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXBRDWL"), xmlWriter);
        }

        if (localRESBERTracker) {
            if (localRESBER == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RESBER cannot be null!!");
            }

            localRESBER.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RESBER"), xmlWriter);
        }

        if (localSDUERRTracker) {
            if (localSDUERR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SDUERR cannot be null!!");
            }

            localSDUERR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SDUERR"), xmlWriter);
        }

        if (localTRANSFERDELTracker) {
            if (localTRANSFERDEL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TRANSFERDEL cannot be null!!");
            }

            localTRANSFERDEL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TRANSFERDEL"), xmlWriter);
        }

        if (localTRAFFICPRITracker) {
            if (localTRAFFICPRI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TRAFFICPRI cannot be null!!");
            }

            localTRAFFICPRI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TRAFFICPRI"), xmlWriter);
        }

        if (localMAXGBRUPLTracker) {
            if (localMAXGBRUPL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXGBRUPL cannot be null!!");
            }

            localMAXGBRUPL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXGBRUPL"), xmlWriter);
        }

        if (localMAXGBRDWLTracker) {
            if (localMAXGBRDWL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXGBRDWL cannot be null!!");
            }

            localMAXGBRDWL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXGBRDWL"), xmlWriter);
        }

        if (localMAXEXTBRDWLTracker) {
            if (localMAXEXTBRDWL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXEXTBRDWL cannot be null!!");
            }

            localMAXEXTBRDWL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXEXTBRDWL"), xmlWriter);
        }

        if (localMAXEXTGBRDWLTracker) {
            if (localMAXEXTGBRDWL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXEXTGBRDWL cannot be null!!");
            }

            localMAXEXTGBRDWL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXEXTGBRDWL"), xmlWriter);
        }

        if (localMAXEXTBRUPLTracker) {
            if (localMAXEXTBRUPL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXEXTBRUPL cannot be null!!");
            }

            localMAXEXTBRUPL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXEXTBRUPL"), xmlWriter);
        }

        if (localMAXEXTGBRUPLTracker) {
            if (localMAXEXTGBRUPL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAXEXTGBRUPL cannot be null!!");
            }

            localMAXEXTGBRUPL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAXEXTGBRUPL"), xmlWriter);
        }

        if (localAPNTracker) {
            if (localAPN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "APN cannot be null!!");
            }

            localAPN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "APN"), xmlWriter);
        }

        if (localGprsVplmnTracker) {
            if (localGprsVplmn == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GprsVplmn cannot be null!!");
            }

            localGprsVplmn.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GprsVplmn"), xmlWriter);
        }

        if (localGprsChargeTracker) {
            if (localGprsCharge == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GprsCharge cannot be null!!");
            }

            localGprsCharge.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GprsCharge"), xmlWriter);
        }

        if (localGprsStdChargeTracker) {
            if (localGprsStdCharge == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GprsStdCharge cannot be null!!");
            }

            localGprsStdCharge.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GprsStdCharge"), xmlWriter);
        }

        if (localGprsApnoiTplIdTracker) {
            if (localGprsApnoiTplId == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GprsApnoiTplId cannot be null!!");
            }

            localGprsApnoiTplId.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GprsApnoiTplId"), xmlWriter);
        }

        if (localVBSTracker) {
            if (localVBS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VBS cannot be null!!");
            }

            localVBS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VBS"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static GprsPdpData_type0 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            GprsPdpData_type0 object = new GprsPdpData_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"GprsPdpData_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (GprsPdpData_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GprsCntxId").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GprsCntxId").equals(
                            reader.getName())) {
                    object.setGprsCntxId(com.huawei.www.hss.Int1_50.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GprsPdpType").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GprsPdpType").equals(
                            reader.getName())) {
                    object.setGprsPdpType(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GprsPdpAdd").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GprsPdpAdd").equals(
                            reader.getName())) {
                    object.setGprsPdpAdd(com.huawei.www.hss.Str1_39.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GprsAddInd").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GprsAddInd").equals(
                            reader.getName())) {
                    object.setGprsAddInd(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GprsPdpAddIpv4").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GprsPdpAddIpv4").equals(
                            reader.getName())) {
                    object.setGprsPdpAddIpv4(com.huawei.www.hss.Str7_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GprsAdd2ind").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GprsAdd2ind").equals(
                            reader.getName())) {
                    object.setGprsAdd2Ind(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RelCls").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RelCls").equals(
                            reader.getName())) {
                    object.setRelCls(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DelayCls").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DelayCls").equals(
                            reader.getName())) {
                    object.setDelayCls(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PreCls").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PreCls").equals(
                            reader.getName())) {
                    object.setPreCls(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PEAKTHR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PEAKTHR").equals(
                            reader.getName())) {
                    object.setPEAKTHR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MEANTHR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MEANTHR").equals(
                            reader.getName())) {
                    object.setMEANTHR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ARPRIORITY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ARPRIORITY").equals(
                            reader.getName())) {
                    object.setARPRIORITY(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ERRSDU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ERRSDU").equals(
                            reader.getName())) {
                    object.setERRSDU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DELIVERY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DELIVERY").equals(
                            reader.getName())) {
                    object.setDELIVERY(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TRAFFICCLS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TRAFFICCLS").equals(
                            reader.getName())) {
                    object.setTRAFFICCLS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXSDUSIZE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXSDUSIZE").equals(
                            reader.getName())) {
                    object.setMAXSDUSIZE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXBRUPL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXBRUPL").equals(
                            reader.getName())) {
                    object.setMAXBRUPL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXBRDWL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXBRDWL").equals(
                            reader.getName())) {
                    object.setMAXBRDWL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RESBER").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RESBER").equals(
                            reader.getName())) {
                    object.setRESBER(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SDUERR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SDUERR").equals(
                            reader.getName())) {
                    object.setSDUERR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TRANSFERDEL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TRANSFERDEL").equals(
                            reader.getName())) {
                    object.setTRANSFERDEL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TRAFFICPRI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TRAFFICPRI").equals(
                            reader.getName())) {
                    object.setTRAFFICPRI(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXGBRUPL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXGBRUPL").equals(
                            reader.getName())) {
                    object.setMAXGBRUPL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXGBRDWL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXGBRDWL").equals(
                            reader.getName())) {
                    object.setMAXGBRDWL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXEXTBRDWL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXEXTBRDWL").equals(
                            reader.getName())) {
                    object.setMAXEXTBRDWL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXEXTGBRDWL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXEXTGBRDWL").equals(
                            reader.getName())) {
                    object.setMAXEXTGBRDWL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXEXTBRUPL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXEXTBRUPL").equals(
                            reader.getName())) {
                    object.setMAXEXTBRUPL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAXEXTGBRUPL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAXEXTGBRUPL").equals(
                            reader.getName())) {
                    object.setMAXEXTGBRUPL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "APN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "APN").equals(
                            reader.getName())) {
                    object.setAPN(com.huawei.www.hss.Str1_63.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GprsVplmn").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GprsVplmn").equals(
                            reader.getName())) {
                    object.setGprsVplmn(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GprsCharge").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GprsCharge").equals(
                            reader.getName())) {
                    object.setGprsCharge(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GprsStdCharge").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GprsStdCharge").equals(
                            reader.getName())) {
                    object.setGprsStdCharge(com.huawei.www.hss.Str4_4.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GprsApnoiTplId").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GprsApnoiTplId").equals(
                            reader.getName())) {
                    object.setGprsApnoiTplId(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VBS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VBS").equals(
                            reader.getName())) {
                    object.setVBS(com.huawei.www.hss.VBS_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
