/**
 * CamelSubscriberInfo_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  CamelSubscriberInfo_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class CamelSubscriberInfo_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = CamelSubscriberInfo_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for OCSI
     */
    protected com.huawei.www.hss.OCSI_type0 localOCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localOCSITracker = false;

    /**
     * field for TCSI
     */
    protected com.huawei.www.hss.TCSI_type0 localTCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTCSITracker = false;

    /**
     * field for VtCSI
     */
    protected com.huawei.www.hss.VtCSI_type0 localVtCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVtCSITracker = false;

    /**
     * field for MoSmsCSI
     */
    protected com.huawei.www.hss.MoSmsCSI_type0 localMoSmsCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMoSmsCSITracker = false;

    /**
     * field for MtSmsCSI
     */
    protected com.huawei.www.hss.MtSmsCSI_type0 localMtSmsCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMtSmsCSITracker = false;

    /**
     * field for DCSI
     */
    protected com.huawei.www.hss.DCSI_type0 localDCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDCSITracker = false;

    /**
     * field for SsCSI
     */
    protected com.huawei.www.hss.SsCSI_type0 localSsCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSsCSITracker = false;

    /**
     * field for MCSI
     */
    protected com.huawei.www.hss.MCSI_type0 localMCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMCSITracker = false;

    /**
     * field for GprsCSI
     */
    protected com.huawei.www.hss.GprsCSI_type0 localGprsCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGprsCSITracker = false;

    /**
     * field for UCSI
     */
    protected com.huawei.www.hss.UCSI_type0 localUCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUCSITracker = false;

    /**
     * field for TifCSI
     */
    protected com.huawei.www.hss.TifCSI_type0 localTifCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTifCSITracker = false;

    /**
     * field for ImOCSI
     */
    protected com.huawei.www.hss.ImOCSI_type0 localImOCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localImOCSITracker = false;

    /**
     * field for ImVtCSI
     */
    protected com.huawei.www.hss.ImVtCSI_type0 localImVtCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localImVtCSITracker = false;

    /**
     * field for SmsIntelligentService
     */
    protected com.huawei.www.hss.SmsIntelligentService_type0 localSmsIntelligentService;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSmsIntelligentServiceTracker = false;

    /**
     * field for LuCSI
     */
    protected com.huawei.www.hss.LuCSI_type0 localLuCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLuCSITracker = false;

    public boolean isOCSISpecified() {
        return localOCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.OCSI_type0
     */
    public com.huawei.www.hss.OCSI_type0 getOCSI() {
        return localOCSI;
    }

    /**
     * Auto generated setter method
     * @param param OCSI
     */
    public void setOCSI(com.huawei.www.hss.OCSI_type0 param) {
        localOCSITracker = param != null;

        this.localOCSI = param;
    }

    public boolean isTCSISpecified() {
        return localTCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.TCSI_type0
     */
    public com.huawei.www.hss.TCSI_type0 getTCSI() {
        return localTCSI;
    }

    /**
     * Auto generated setter method
     * @param param TCSI
     */
    public void setTCSI(com.huawei.www.hss.TCSI_type0 param) {
        localTCSITracker = param != null;

        this.localTCSI = param;
    }

    public boolean isVtCSISpecified() {
        return localVtCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.VtCSI_type0
     */
    public com.huawei.www.hss.VtCSI_type0 getVtCSI() {
        return localVtCSI;
    }

    /**
     * Auto generated setter method
     * @param param VtCSI
     */
    public void setVtCSI(com.huawei.www.hss.VtCSI_type0 param) {
        localVtCSITracker = param != null;

        this.localVtCSI = param;
    }

    public boolean isMoSmsCSISpecified() {
        return localMoSmsCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.MoSmsCSI_type0
     */
    public com.huawei.www.hss.MoSmsCSI_type0 getMoSmsCSI() {
        return localMoSmsCSI;
    }

    /**
     * Auto generated setter method
     * @param param MoSmsCSI
     */
    public void setMoSmsCSI(com.huawei.www.hss.MoSmsCSI_type0 param) {
        localMoSmsCSITracker = param != null;

        this.localMoSmsCSI = param;
    }

    public boolean isMtSmsCSISpecified() {
        return localMtSmsCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.MtSmsCSI_type0
     */
    public com.huawei.www.hss.MtSmsCSI_type0 getMtSmsCSI() {
        return localMtSmsCSI;
    }

    /**
     * Auto generated setter method
     * @param param MtSmsCSI
     */
    public void setMtSmsCSI(com.huawei.www.hss.MtSmsCSI_type0 param) {
        localMtSmsCSITracker = param != null;

        this.localMtSmsCSI = param;
    }

    public boolean isDCSISpecified() {
        return localDCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.DCSI_type0
     */
    public com.huawei.www.hss.DCSI_type0 getDCSI() {
        return localDCSI;
    }

    /**
     * Auto generated setter method
     * @param param DCSI
     */
    public void setDCSI(com.huawei.www.hss.DCSI_type0 param) {
        localDCSITracker = param != null;

        this.localDCSI = param;
    }

    public boolean isSsCSISpecified() {
        return localSsCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.SsCSI_type0
     */
    public com.huawei.www.hss.SsCSI_type0 getSsCSI() {
        return localSsCSI;
    }

    /**
     * Auto generated setter method
     * @param param SsCSI
     */
    public void setSsCSI(com.huawei.www.hss.SsCSI_type0 param) {
        localSsCSITracker = param != null;

        this.localSsCSI = param;
    }

    public boolean isMCSISpecified() {
        return localMCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.MCSI_type0
     */
    public com.huawei.www.hss.MCSI_type0 getMCSI() {
        return localMCSI;
    }

    /**
     * Auto generated setter method
     * @param param MCSI
     */
    public void setMCSI(com.huawei.www.hss.MCSI_type0 param) {
        localMCSITracker = param != null;

        this.localMCSI = param;
    }

    public boolean isGprsCSISpecified() {
        return localGprsCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.GprsCSI_type0
     */
    public com.huawei.www.hss.GprsCSI_type0 getGprsCSI() {
        return localGprsCSI;
    }

    /**
     * Auto generated setter method
     * @param param GprsCSI
     */
    public void setGprsCSI(com.huawei.www.hss.GprsCSI_type0 param) {
        localGprsCSITracker = param != null;

        this.localGprsCSI = param;
    }

    public boolean isUCSISpecified() {
        return localUCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.UCSI_type0
     */
    public com.huawei.www.hss.UCSI_type0 getUCSI() {
        return localUCSI;
    }

    /**
     * Auto generated setter method
     * @param param UCSI
     */
    public void setUCSI(com.huawei.www.hss.UCSI_type0 param) {
        localUCSITracker = param != null;

        this.localUCSI = param;
    }

    public boolean isTifCSISpecified() {
        return localTifCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.TifCSI_type0
     */
    public com.huawei.www.hss.TifCSI_type0 getTifCSI() {
        return localTifCSI;
    }

    /**
     * Auto generated setter method
     * @param param TifCSI
     */
    public void setTifCSI(com.huawei.www.hss.TifCSI_type0 param) {
        localTifCSITracker = param != null;

        this.localTifCSI = param;
    }

    public boolean isImOCSISpecified() {
        return localImOCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.ImOCSI_type0
     */
    public com.huawei.www.hss.ImOCSI_type0 getImOCSI() {
        return localImOCSI;
    }

    /**
     * Auto generated setter method
     * @param param ImOCSI
     */
    public void setImOCSI(com.huawei.www.hss.ImOCSI_type0 param) {
        localImOCSITracker = param != null;

        this.localImOCSI = param;
    }

    public boolean isImVtCSISpecified() {
        return localImVtCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.ImVtCSI_type0
     */
    public com.huawei.www.hss.ImVtCSI_type0 getImVtCSI() {
        return localImVtCSI;
    }

    /**
     * Auto generated setter method
     * @param param ImVtCSI
     */
    public void setImVtCSI(com.huawei.www.hss.ImVtCSI_type0 param) {
        localImVtCSITracker = param != null;

        this.localImVtCSI = param;
    }

    public boolean isSmsIntelligentServiceSpecified() {
        return localSmsIntelligentServiceTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.SmsIntelligentService_type0
     */
    public com.huawei.www.hss.SmsIntelligentService_type0 getSmsIntelligentService() {
        return localSmsIntelligentService;
    }

    /**
     * Auto generated setter method
     * @param param SmsIntelligentService
     */
    public void setSmsIntelligentService(
        com.huawei.www.hss.SmsIntelligentService_type0 param) {
        localSmsIntelligentServiceTracker = param != null;

        this.localSmsIntelligentService = param;
    }

    public boolean isLuCSISpecified() {
        return localLuCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.LuCSI_type0
     */
    public com.huawei.www.hss.LuCSI_type0 getLuCSI() {
        return localLuCSI;
    }

    /**
     * Auto generated setter method
     * @param param LuCSI
     */
    public void setLuCSI(com.huawei.www.hss.LuCSI_type0 param) {
        localLuCSITracker = param != null;

        this.localLuCSI = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":CamelSubscriberInfo_type0", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "CamelSubscriberInfo_type0", xmlWriter);
            }
        }

        if (localOCSITracker) {
            if (localOCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "OCSI cannot be null!!");
            }

            localOCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "OCSI"), xmlWriter);
        }

        if (localTCSITracker) {
            if (localTCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TCSI cannot be null!!");
            }

            localTCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TCSI"), xmlWriter);
        }

        if (localVtCSITracker) {
            if (localVtCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VtCSI cannot be null!!");
            }

            localVtCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VtCSI"), xmlWriter);
        }

        if (localMoSmsCSITracker) {
            if (localMoSmsCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MoSmsCSI cannot be null!!");
            }

            localMoSmsCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MoSmsCSI"), xmlWriter);
        }

        if (localMtSmsCSITracker) {
            if (localMtSmsCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MtSmsCSI cannot be null!!");
            }

            localMtSmsCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MtSmsCSI"), xmlWriter);
        }

        if (localDCSITracker) {
            if (localDCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DCSI cannot be null!!");
            }

            localDCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DCSI"), xmlWriter);
        }

        if (localSsCSITracker) {
            if (localSsCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SsCSI cannot be null!!");
            }

            localSsCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SsCSI"), xmlWriter);
        }

        if (localMCSITracker) {
            if (localMCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MCSI cannot be null!!");
            }

            localMCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MCSI"), xmlWriter);
        }

        if (localGprsCSITracker) {
            if (localGprsCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GprsCSI cannot be null!!");
            }

            localGprsCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GprsCSI"), xmlWriter);
        }

        if (localUCSITracker) {
            if (localUCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UCSI cannot be null!!");
            }

            localUCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UCSI"), xmlWriter);
        }

        if (localTifCSITracker) {
            if (localTifCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TifCSI cannot be null!!");
            }

            localTifCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TifCSI"), xmlWriter);
        }

        if (localImOCSITracker) {
            if (localImOCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ImOCSI cannot be null!!");
            }

            localImOCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ImOCSI"), xmlWriter);
        }

        if (localImVtCSITracker) {
            if (localImVtCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ImVtCSI cannot be null!!");
            }

            localImVtCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ImVtCSI"), xmlWriter);
        }

        if (localSmsIntelligentServiceTracker) {
            if (localSmsIntelligentService == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SmsIntelligentService cannot be null!!");
            }

            localSmsIntelligentService.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SmsIntelligentService"),
                xmlWriter);
        }

        if (localLuCSITracker) {
            if (localLuCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LuCSI cannot be null!!");
            }

            localLuCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LuCSI"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static CamelSubscriberInfo_type0 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            CamelSubscriberInfo_type0 object = new CamelSubscriberInfo_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"CamelSubscriberInfo_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (CamelSubscriberInfo_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "OCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "OCSI").equals(
                            reader.getName())) {
                    object.setOCSI(com.huawei.www.hss.OCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TCSI").equals(
                            reader.getName())) {
                    object.setTCSI(com.huawei.www.hss.TCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VtCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VtCSI").equals(
                            reader.getName())) {
                    object.setVtCSI(com.huawei.www.hss.VtCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MoSmsCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MoSmsCSI").equals(
                            reader.getName())) {
                    object.setMoSmsCSI(com.huawei.www.hss.MoSmsCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MtSmsCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MtSmsCSI").equals(
                            reader.getName())) {
                    object.setMtSmsCSI(com.huawei.www.hss.MtSmsCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DCSI").equals(
                            reader.getName())) {
                    object.setDCSI(com.huawei.www.hss.DCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SsCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SsCSI").equals(
                            reader.getName())) {
                    object.setSsCSI(com.huawei.www.hss.SsCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MCSI").equals(
                            reader.getName())) {
                    object.setMCSI(com.huawei.www.hss.MCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GprsCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GprsCSI").equals(
                            reader.getName())) {
                    object.setGprsCSI(com.huawei.www.hss.GprsCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UCSI").equals(
                            reader.getName())) {
                    object.setUCSI(com.huawei.www.hss.UCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TifCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TifCSI").equals(
                            reader.getName())) {
                    object.setTifCSI(com.huawei.www.hss.TifCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ImOCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ImOCSI").equals(
                            reader.getName())) {
                    object.setImOCSI(com.huawei.www.hss.ImOCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ImVtCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ImVtCSI").equals(
                            reader.getName())) {
                    object.setImVtCSI(com.huawei.www.hss.ImVtCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SmsIntelligentService").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "SmsIntelligentService").equals(reader.getName())) {
                    object.setSmsIntelligentService(com.huawei.www.hss.SmsIntelligentService_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LuCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LuCSI").equals(
                            reader.getName())) {
                    object.setLuCSI(com.huawei.www.hss.LuCSI_type0.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
