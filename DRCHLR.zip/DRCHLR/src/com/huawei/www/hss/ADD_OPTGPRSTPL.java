/**
 * ADD_OPTGPRSTPL.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  ADD_OPTGPRSTPL bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class ADD_OPTGPRSTPL implements org.apache.axis2.databinding.ADBBean {
    public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName("http://www.huawei.com/HSS",
            "ADD_OPTGPRSTPL", "ns3");

    /**
     * field for HLRSN
     */
    protected com.huawei.www.hss.Int1_255 localHLRSN;

    /**
     * field for TPLID
     */
    protected com.huawei.www.hss.Int0_65534 localTPLID;

    /**
     * field for TPLNAME
     */
    protected com.huawei.www.hss.Str1_60 localTPLNAME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTPLNAMETracker = false;

    /**
     * field for CNTXID
     */
    protected com.huawei.www.hss.Int1_50 localCNTXID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCNTXIDTracker = false;

    /**
     * field for APN_TYPE
     */
    protected com.huawei.www.hss._EnumType localAPN_TYPE;

    /**
     * field for APNTPLID
     */
    protected com.huawei.www.hss.Int0_65534 localAPNTPLID;

    /**
     * field for DEFAULTCFGFLAG
     */
    protected com.huawei.www.hss._EnumType localDEFAULTCFGFLAG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDEFAULTCFGFLAGTracker = false;

    /**
     * field for QOSTPLID
     */
    protected com.huawei.www.hss.Int0_65534 localQOSTPLID;

    /**
     * field for EPS_QOSTPLID
     */
    protected com.huawei.www.hss.Int0_65534 localEPS_QOSTPLID;

    /**
     * field for PDPTYPE
     */
    protected com.huawei.www.hss._EnumType localPDPTYPE;

    /**
     * field for VPLMN
     */
    protected com.huawei.www.hss._EnumType localVPLMN;

    /**
     * field for CHARGE
     */
    protected com.huawei.www.hss._EnumType localCHARGE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCHARGETracker = false;

    /**
     * field for STDCHARGE
     */
    protected com.huawei.www.hss.Str4_4 localSTDCHARGE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSTDCHARGETracker = false;

    /**
     * field for PROVAPNOI
     */
    protected com.huawei.www.hss._EnumType localPROVAPNOI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPROVAPNOITracker = false;

    /**
     * field for APNOITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localAPNOITPLID;

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_255
     */
    public com.huawei.www.hss.Int1_255 getHLRSN() {
        return localHLRSN;
    }

    /**
     * Auto generated setter method
     * @param param HLRSN
     */
    public void setHLRSN(com.huawei.www.hss.Int1_255 param) {
        this.localHLRSN = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getTPLID() {
        return localTPLID;
    }

    /**
     * Auto generated setter method
     * @param param TPLID
     */
    public void setTPLID(com.huawei.www.hss.Int0_65534 param) {
        this.localTPLID = param;
    }

    public boolean isTPLNAMESpecified() {
        return localTPLNAMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_60
     */
    public com.huawei.www.hss.Str1_60 getTPLNAME() {
        return localTPLNAME;
    }

    /**
     * Auto generated setter method
     * @param param TPLNAME
     */
    public void setTPLNAME(com.huawei.www.hss.Str1_60 param) {
        localTPLNAMETracker = param != null;

        this.localTPLNAME = param;
    }

    public boolean isCNTXIDSpecified() {
        return localCNTXIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_50
     */
    public com.huawei.www.hss.Int1_50 getCNTXID() {
        return localCNTXID;
    }

    /**
     * Auto generated setter method
     * @param param CNTXID
     */
    public void setCNTXID(com.huawei.www.hss.Int1_50 param) {
        localCNTXIDTracker = param != null;

        this.localCNTXID = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getAPN_TYPE() {
        return localAPN_TYPE;
    }

    /**
     * Auto generated setter method
     * @param param APN_TYPE
     */
    public void setAPN_TYPE(com.huawei.www.hss._EnumType param) {
        this.localAPN_TYPE = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getAPNTPLID() {
        return localAPNTPLID;
    }

    /**
     * Auto generated setter method
     * @param param APNTPLID
     */
    public void setAPNTPLID(com.huawei.www.hss.Int0_65534 param) {
        this.localAPNTPLID = param;
    }

    public boolean isDEFAULTCFGFLAGSpecified() {
        return localDEFAULTCFGFLAGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDEFAULTCFGFLAG() {
        return localDEFAULTCFGFLAG;
    }

    /**
     * Auto generated setter method
     * @param param DEFAULTCFGFLAG
     */
    public void setDEFAULTCFGFLAG(com.huawei.www.hss._EnumType param) {
        localDEFAULTCFGFLAGTracker = param != null;

        this.localDEFAULTCFGFLAG = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getQOSTPLID() {
        return localQOSTPLID;
    }

    /**
     * Auto generated setter method
     * @param param QOSTPLID
     */
    public void setQOSTPLID(com.huawei.www.hss.Int0_65534 param) {
        this.localQOSTPLID = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getEPS_QOSTPLID() {
        return localEPS_QOSTPLID;
    }

    /**
     * Auto generated setter method
     * @param param EPS_QOSTPLID
     */
    public void setEPS_QOSTPLID(com.huawei.www.hss.Int0_65534 param) {
        this.localEPS_QOSTPLID = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPDPTYPE() {
        return localPDPTYPE;
    }

    /**
     * Auto generated setter method
     * @param param PDPTYPE
     */
    public void setPDPTYPE(com.huawei.www.hss._EnumType param) {
        this.localPDPTYPE = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVPLMN() {
        return localVPLMN;
    }

    /**
     * Auto generated setter method
     * @param param VPLMN
     */
    public void setVPLMN(com.huawei.www.hss._EnumType param) {
        this.localVPLMN = param;
    }

    public boolean isCHARGESpecified() {
        return localCHARGETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCHARGE() {
        return localCHARGE;
    }

    /**
     * Auto generated setter method
     * @param param CHARGE
     */
    public void setCHARGE(com.huawei.www.hss._EnumType param) {
        localCHARGETracker = param != null;

        this.localCHARGE = param;
    }

    public boolean isSTDCHARGESpecified() {
        return localSTDCHARGETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str4_4
     */
    public com.huawei.www.hss.Str4_4 getSTDCHARGE() {
        return localSTDCHARGE;
    }

    /**
     * Auto generated setter method
     * @param param STDCHARGE
     */
    public void setSTDCHARGE(com.huawei.www.hss.Str4_4 param) {
        localSTDCHARGETracker = param != null;

        this.localSTDCHARGE = param;
    }

    public boolean isPROVAPNOISpecified() {
        return localPROVAPNOITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getPROVAPNOI() {
        return localPROVAPNOI;
    }

    /**
     * Auto generated setter method
     * @param param PROVAPNOI
     */
    public void setPROVAPNOI(com.huawei.www.hss._EnumType param) {
        localPROVAPNOITracker = param != null;

        this.localPROVAPNOI = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getAPNOITPLID() {
        return localAPNOITPLID;
    }

    /**
     * Auto generated setter method
     * @param param APNOITPLID
     */
    public void setAPNOITPLID(com.huawei.www.hss.Int0_65534 param) {
        this.localAPNOITPLID = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, MY_QNAME));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":ADD_OPTGPRSTPL", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "ADD_OPTGPRSTPL", xmlWriter);
            }
        }

        if (localHLRSN == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "HLRSN cannot be null!!");
        }

        localHLRSN.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "HLRSN"), xmlWriter);

        if (localTPLID == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "TPLID cannot be null!!");
        }

        localTPLID.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "TPLID"), xmlWriter);

        if (localTPLNAMETracker) {
            if (localTPLNAME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TPLNAME cannot be null!!");
            }

            localTPLNAME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TPLNAME"), xmlWriter);
        }

        if (localCNTXIDTracker) {
            if (localCNTXID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CNTXID cannot be null!!");
            }

            localCNTXID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CNTXID"), xmlWriter);
        }

        if (localAPN_TYPE == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "APN_TYPE cannot be null!!");
        }

        localAPN_TYPE.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "APN_TYPE"), xmlWriter);

        if (localAPNTPLID == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "APNTPLID cannot be null!!");
        }

        localAPNTPLID.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "APNTPLID"), xmlWriter);

        if (localDEFAULTCFGFLAGTracker) {
            if (localDEFAULTCFGFLAG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DEFAULTCFGFLAG cannot be null!!");
            }

            localDEFAULTCFGFLAG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DEFAULTCFGFLAG"), xmlWriter);
        }

        if (localQOSTPLID == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "QOSTPLID cannot be null!!");
        }

        localQOSTPLID.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "QOSTPLID"), xmlWriter);

        if (localEPS_QOSTPLID == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "EPS_QOSTPLID cannot be null!!");
        }

        localEPS_QOSTPLID.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "EPS_QOSTPLID"), xmlWriter);

        if (localPDPTYPE == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "PDPTYPE cannot be null!!");
        }

        localPDPTYPE.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "PDPTYPE"), xmlWriter);

        if (localVPLMN == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "VPLMN cannot be null!!");
        }

        localVPLMN.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "VPLMN"), xmlWriter);

        if (localCHARGETracker) {
            if (localCHARGE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CHARGE cannot be null!!");
            }

            localCHARGE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CHARGE"), xmlWriter);
        }

        if (localSTDCHARGETracker) {
            if (localSTDCHARGE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "STDCHARGE cannot be null!!");
            }

            localSTDCHARGE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "STDCHARGE"), xmlWriter);
        }

        if (localPROVAPNOITracker) {
            if (localPROVAPNOI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PROVAPNOI cannot be null!!");
            }

            localPROVAPNOI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PROVAPNOI"), xmlWriter);
        }

        if (localAPNOITPLID == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "APNOITPLID cannot be null!!");
        }

        localAPNOITPLID.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "APNOITPLID"), xmlWriter);

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static ADD_OPTGPRSTPL parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            ADD_OPTGPRSTPL object = new ADD_OPTGPRSTPL();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"ADD_OPTGPRSTPL".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (ADD_OPTGPRSTPL) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "HLRSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "HLRSN").equals(
                            reader.getName())) {
                    object.setHLRSN(com.huawei.www.hss.Int1_255.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TPLID").equals(
                            reader.getName())) {
                    object.setTPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TPLNAME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TPLNAME").equals(
                            reader.getName())) {
                    object.setTPLNAME(com.huawei.www.hss.Str1_60.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CNTXID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CNTXID").equals(
                            reader.getName())) {
                    object.setCNTXID(com.huawei.www.hss.Int1_50.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "APN_TYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "APN_TYPE").equals(
                            reader.getName())) {
                    object.setAPN_TYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "APNTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "APNTPLID").equals(
                            reader.getName())) {
                    object.setAPNTPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DEFAULTCFGFLAG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DEFAULTCFGFLAG").equals(
                            reader.getName())) {
                    object.setDEFAULTCFGFLAG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "QOSTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "QOSTPLID").equals(
                            reader.getName())) {
                    object.setQOSTPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EPS_QOSTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EPS_QOSTPLID").equals(
                            reader.getName())) {
                    object.setEPS_QOSTPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PDPTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PDPTYPE").equals(
                            reader.getName())) {
                    object.setPDPTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VPLMN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VPLMN").equals(
                            reader.getName())) {
                    object.setVPLMN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CHARGE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CHARGE").equals(
                            reader.getName())) {
                    object.setCHARGE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "STDCHARGE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "STDCHARGE").equals(
                            reader.getName())) {
                    object.setSTDCHARGE(com.huawei.www.hss.Str4_4.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PROVAPNOI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PROVAPNOI").equals(
                            reader.getName())) {
                    object.setPROVAPNOI(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "APNOITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "APNOITPLID").equals(
                            reader.getName())) {
                    object.setAPNOITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
