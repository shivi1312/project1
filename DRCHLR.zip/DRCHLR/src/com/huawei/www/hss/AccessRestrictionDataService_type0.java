/**
 * AccessRestrictionDataService_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  AccessRestrictionDataService_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class AccessRestrictionDataService_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = AccessRestrictionDataService_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for ARD
     */
    protected com.huawei.www.hss._EnumType localARD;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localARDTracker = false;

    /**
     * field for UtranNotAllowed
     */
    protected com.huawei.www.hss._EnumType localUtranNotAllowed;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUtranNotAllowedTracker = false;

    /**
     * field for GeranNotAllowed
     */
    protected com.huawei.www.hss._EnumType localGeranNotAllowed;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGeranNotAllowedTracker = false;

    /**
     * field for GanNotAllowed
     */
    protected com.huawei.www.hss._EnumType localGanNotAllowed;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGanNotAllowedTracker = false;

    /**
     * field for IhspaeNotAllowed
     */
    protected com.huawei.www.hss._EnumType localIhspaeNotAllowed;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIhspaeNotAllowedTracker = false;

    /**
     * field for EutranNotAllowed
     */
    protected com.huawei.www.hss._EnumType localEutranNotAllowed;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEutranNotAllowedTracker = false;

    /**
     * field for N3GppNotAllowed
     */
    protected com.huawei.www.hss._EnumType localN3GppNotAllowed;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localN3GppNotAllowedTracker = false;

    public boolean isARDSpecified() {
        return localARDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getARD() {
        return localARD;
    }

    /**
     * Auto generated setter method
     * @param param ARD
     */
    public void setARD(com.huawei.www.hss._EnumType param) {
        localARDTracker = param != null;

        this.localARD = param;
    }

    public boolean isUtranNotAllowedSpecified() {
        return localUtranNotAllowedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUtranNotAllowed() {
        return localUtranNotAllowed;
    }

    /**
     * Auto generated setter method
     * @param param UtranNotAllowed
     */
    public void setUtranNotAllowed(com.huawei.www.hss._EnumType param) {
        localUtranNotAllowedTracker = param != null;

        this.localUtranNotAllowed = param;
    }

    public boolean isGeranNotAllowedSpecified() {
        return localGeranNotAllowedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getGeranNotAllowed() {
        return localGeranNotAllowed;
    }

    /**
     * Auto generated setter method
     * @param param GeranNotAllowed
     */
    public void setGeranNotAllowed(com.huawei.www.hss._EnumType param) {
        localGeranNotAllowedTracker = param != null;

        this.localGeranNotAllowed = param;
    }

    public boolean isGanNotAllowedSpecified() {
        return localGanNotAllowedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getGanNotAllowed() {
        return localGanNotAllowed;
    }

    /**
     * Auto generated setter method
     * @param param GanNotAllowed
     */
    public void setGanNotAllowed(com.huawei.www.hss._EnumType param) {
        localGanNotAllowedTracker = param != null;

        this.localGanNotAllowed = param;
    }

    public boolean isIhspaeNotAllowedSpecified() {
        return localIhspaeNotAllowedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getIhspaeNotAllowed() {
        return localIhspaeNotAllowed;
    }

    /**
     * Auto generated setter method
     * @param param IhspaeNotAllowed
     */
    public void setIhspaeNotAllowed(com.huawei.www.hss._EnumType param) {
        localIhspaeNotAllowedTracker = param != null;

        this.localIhspaeNotAllowed = param;
    }

    public boolean isEutranNotAllowedSpecified() {
        return localEutranNotAllowedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEutranNotAllowed() {
        return localEutranNotAllowed;
    }

    /**
     * Auto generated setter method
     * @param param EutranNotAllowed
     */
    public void setEutranNotAllowed(com.huawei.www.hss._EnumType param) {
        localEutranNotAllowedTracker = param != null;

        this.localEutranNotAllowed = param;
    }

    public boolean isN3GppNotAllowedSpecified() {
        return localN3GppNotAllowedTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getN3GppNotAllowed() {
        return localN3GppNotAllowed;
    }

    /**
     * Auto generated setter method
     * @param param N3GppNotAllowed
     */
    public void setN3GppNotAllowed(com.huawei.www.hss._EnumType param) {
        localN3GppNotAllowedTracker = param != null;

        this.localN3GppNotAllowed = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":AccessRestrictionDataService_type0",
                    xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "AccessRestrictionDataService_type0", xmlWriter);
            }
        }

        if (localARDTracker) {
            if (localARD == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ARD cannot be null!!");
            }

            localARD.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ARD"), xmlWriter);
        }

        if (localUtranNotAllowedTracker) {
            if (localUtranNotAllowed == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UtranNotAllowed cannot be null!!");
            }

            localUtranNotAllowed.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UtranNotAllowed"), xmlWriter);
        }

        if (localGeranNotAllowedTracker) {
            if (localGeranNotAllowed == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GeranNotAllowed cannot be null!!");
            }

            localGeranNotAllowed.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GeranNotAllowed"), xmlWriter);
        }

        if (localGanNotAllowedTracker) {
            if (localGanNotAllowed == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GanNotAllowed cannot be null!!");
            }

            localGanNotAllowed.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GanNotAllowed"), xmlWriter);
        }

        if (localIhspaeNotAllowedTracker) {
            if (localIhspaeNotAllowed == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IhspaeNotAllowed cannot be null!!");
            }

            localIhspaeNotAllowed.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IhspaeNotAllowed"), xmlWriter);
        }

        if (localEutranNotAllowedTracker) {
            if (localEutranNotAllowed == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EutranNotAllowed cannot be null!!");
            }

            localEutranNotAllowed.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EutranNotAllowed"), xmlWriter);
        }

        if (localN3GppNotAllowedTracker) {
            if (localN3GppNotAllowed == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "N3gppNotAllowed cannot be null!!");
            }

            localN3GppNotAllowed.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "N3gppNotAllowed"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static AccessRestrictionDataService_type0 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            AccessRestrictionDataService_type0 object = new AccessRestrictionDataService_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"AccessRestrictionDataService_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (AccessRestrictionDataService_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ARD").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ARD").equals(
                            reader.getName())) {
                    object.setARD(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UtranNotAllowed").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UtranNotAllowed").equals(
                            reader.getName())) {
                    object.setUtranNotAllowed(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GeranNotAllowed").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GeranNotAllowed").equals(
                            reader.getName())) {
                    object.setGeranNotAllowed(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GanNotAllowed").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GanNotAllowed").equals(
                            reader.getName())) {
                    object.setGanNotAllowed(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IhspaeNotAllowed").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IhspaeNotAllowed").equals(
                            reader.getName())) {
                    object.setIhspaeNotAllowed(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EutranNotAllowed").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EutranNotAllowed").equals(
                            reader.getName())) {
                    object.setEutranNotAllowed(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "N3gppNotAllowed").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "N3gppNotAllowed").equals(
                            reader.getName())) {
                    object.setN3GppNotAllowed(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
