/**
 * ADD_CSPSSUB.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  ADD_CSPSSUB bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class ADD_CSPSSUB implements org.apache.axis2.databinding.ADBBean {
    public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName("http://www.huawei.com/HSS",
            "ADD_CSPSSUB", "ns3");

    /**
     * field for HLRSN
     */
    protected com.huawei.www.hss.Int1_255 localHLRSN;

    /**
     * field for IMSI
     */
    protected com.huawei.www.hss.Str6_15 localIMSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSITracker = false;

    /**
     * field for ISDN
     */
    protected com.huawei.www.hss.Str1_15 localISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localISDNTracker = false;

    /**
     * field for NAM
     */
    protected com.huawei.www.hss._EnumType localNAM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localNAMTracker = false;

    /**
     * field for CATEGORY
     */
    protected com.huawei.www.hss._EnumType localCATEGORY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCATEGORYTracker = false;

    /**
     * field for DEFAULTCALL
     */
    protected com.huawei.www.hss._EnumType localDEFAULTCALL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDEFAULTCALLTracker = false;

    /**
     * field for TS
     */
    protected com.huawei.www.hss.Str0_65535 localTS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTSTracker = false;

    /**
     * field for BS
     */
    protected com.huawei.www.hss.Str0_65535 localBS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSTracker = false;

    /**
     * field for CFU
     */
    protected com.huawei.www.hss._EnumType localCFU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFUTracker = false;

    /**
     * field for CFUOFAID
     */
    protected com.huawei.www.hss.Int0_65534 localCFUOFAID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFUOFAIDTracker = false;

    /**
     * field for CFUNCS
     */
    protected com.huawei.www.hss._EnumType localCFUNCS;

    /**
     * field for CFUCOU
     */
    protected com.huawei.www.hss._EnumType localCFUCOU;

    /**
     * field for CFB
     */
    protected com.huawei.www.hss._EnumType localCFB;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFBTracker = false;

    /**
     * field for CFBOFAID
     */
    protected com.huawei.www.hss.Int0_65534 localCFBOFAID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFBOFAIDTracker = false;

    /**
     * field for CFBNFS
     */
    protected com.huawei.www.hss._EnumType localCFBNFS;

    /**
     * field for CFBNCS
     */
    protected com.huawei.www.hss._EnumType localCFBNCS;

    /**
     * field for CFBCOU
     */
    protected com.huawei.www.hss._EnumType localCFBCOU;

    /**
     * field for CFNRY
     */
    protected com.huawei.www.hss._EnumType localCFNRY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRYTracker = false;

    /**
     * field for CFNRYOFAID
     */
    protected com.huawei.www.hss.Int0_65534 localCFNRYOFAID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRYOFAIDTracker = false;

    /**
     * field for CFNRYNFS
     */
    protected com.huawei.www.hss._EnumType localCFNRYNFS;

    /**
     * field for CFNRYNCS
     */
    protected com.huawei.www.hss._EnumType localCFNRYNCS;

    /**
     * field for CFNRYCOU
     */
    protected com.huawei.www.hss._EnumType localCFNRYCOU;

    /**
     * field for CFNRC
     */
    protected com.huawei.www.hss._EnumType localCFNRC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRCTracker = false;

    /**
     * field for CFNRCOFAID
     */
    protected com.huawei.www.hss.Int0_65534 localCFNRCOFAID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFNRCOFAIDTracker = false;

    /**
     * field for CFNRCNCS
     */
    protected com.huawei.www.hss._EnumType localCFNRCNCS;

    /**
     * field for CFNRCOU
     */
    protected com.huawei.www.hss._EnumType localCFNRCOU;

    /**
     * field for CFD
     */
    protected com.huawei.www.hss._EnumType localCFD;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFDTracker = false;

    /**
     * field for VALIDCCF
     */
    protected com.huawei.www.hss.Str0_65535 localVALIDCCF;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVALIDCCFTracker = false;

    /**
     * field for SUPINTERCFD
     */
    protected com.huawei.www.hss._EnumType localSUPINTERCFD;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSUPINTERCFDTracker = false;

    /**
     * field for CFDNFS
     */
    protected com.huawei.www.hss._EnumType localCFDNFS;

    /**
     * field for CFDNCS
     */
    protected com.huawei.www.hss._EnumType localCFDNCS;

    /**
     * field for CFDFTN
     */
    protected com.huawei.www.hss.Str1_16 localCFDFTN;

    /**
     * field for CFDBSG
     */
    protected com.huawei.www.hss._EnumType localCFDBSG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFDBSGTracker = false;

    /**
     * field for CFDNRTIME
     */
    protected com.huawei.www.hss._EnumType localCFDNRTIME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCFDNRTIMETracker = false;

    /**
     * field for CB
     */
    protected com.huawei.www.hss.Str0_65535 localCB;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCBTracker = false;

    /**
     * field for CBCOU
     */
    protected com.huawei.www.hss._EnumType localCBCOU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCBCOUTracker = false;

    /**
     * field for CLIP
     */
    protected com.huawei.www.hss._EnumType localCLIP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCLIPTracker = false;

    /**
     * field for CNAP
     */
    protected com.huawei.www.hss._EnumType localCNAP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCNAPTracker = false;

    /**
     * field for CLIPOR
     */
    protected com.huawei.www.hss._EnumType localCLIPOR;

    /**
     * field for BSGCLIP
     */
    protected com.huawei.www.hss.Str0_65535 localBSGCLIP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSGCLIPTracker = false;

    /**
     * field for CLIR
     */
    protected com.huawei.www.hss._EnumType localCLIR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCLIRTracker = false;

    /**
     * field for CLIRMODE
     */
    protected com.huawei.www.hss._EnumType localCLIRMODE;

    /**
     * field for BSGCLIR
     */
    protected com.huawei.www.hss.Str0_65535 localBSGCLIR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSGCLIRTracker = false;

    /**
     * field for COLP
     */
    protected com.huawei.www.hss._EnumType localCOLP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCOLPTracker = false;

    /**
     * field for COLPOR
     */
    protected com.huawei.www.hss._EnumType localCOLPOR;

    /**
     * field for BSGCOLP
     */
    protected com.huawei.www.hss.Str0_65535 localBSGCOLP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSGCOLPTracker = false;

    /**
     * field for COLR
     */
    protected com.huawei.www.hss._EnumType localCOLR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCOLRTracker = false;

    /**
     * field for BSGCOLR
     */
    protected com.huawei.www.hss.Str0_65535 localBSGCOLR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBSGCOLRTracker = false;

    /**
     * field for ECT
     */
    protected com.huawei.www.hss._EnumType localECT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localECTTracker = false;

    /**
     * field for CW
     */
    protected com.huawei.www.hss._EnumType localCW;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCWTracker = false;

    /**
     * field for HOLD
     */
    protected com.huawei.www.hss._EnumType localHOLD;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localHOLDTracker = false;

    /**
     * field for MPTY
     */
    protected com.huawei.www.hss._EnumType localMPTY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMPTYTracker = false;

    /**
     * field for AOC
     */
    protected com.huawei.www.hss._EnumType localAOC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAOCTracker = false;

    /**
     * field for PLMNSPECSS
     */
    protected com.huawei.www.hss.Str0_65535 localPLMNSPECSS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPLMNSPECSSTracker = false;

    /**
     * field for ODBSS
     */
    protected com.huawei.www.hss._EnumType localODBSS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBSSTracker = false;

    /**
     * field for ODBOC
     */
    protected com.huawei.www.hss._EnumType localODBOC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBOCTracker = false;

    /**
     * field for ODBIC
     */
    protected com.huawei.www.hss._EnumType localODBIC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBICTracker = false;

    /**
     * field for ODBROAM
     */
    protected com.huawei.www.hss._EnumType localODBROAM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBROAMTracker = false;

    /**
     * field for ODBENTE
     */
    protected com.huawei.www.hss._EnumType localODBENTE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBENTETracker = false;

    /**
     * field for ODBINFO
     */
    protected com.huawei.www.hss._EnumType localODBINFO;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBINFOTracker = false;

    /**
     * field for ODBRCF
     */
    protected com.huawei.www.hss._EnumType localODBRCF;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBRCFTracker = false;

    /**
     * field for ODBECT
     */
    protected com.huawei.www.hss._EnumType localODBECT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBECTTracker = false;

    /**
     * field for ODBDECT
     */
    protected com.huawei.www.hss._EnumType localODBDECT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBDECTTracker = false;

    /**
     * field for ODBMECT
     */
    protected com.huawei.www.hss._EnumType localODBMECT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBMECTTracker = false;

    /**
     * field for ODBPLMN
     */
    protected com.huawei.www.hss.Str0_65535 localODBPLMN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBPLMNTracker = false;

    /**
     * field for ODBPOS
     */
    protected com.huawei.www.hss._EnumType localODBPOS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBPOSTracker = false;

    /**
     * field for ODBPOSTYPE
     */
    protected com.huawei.www.hss._EnumType localODBPOSTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBPOSTYPETracker = false;

    /**
     * field for OCSI
     */
    protected com.huawei.www.hss.Int0_65534 localOCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localOCSITracker = false;

    /**
     * field for TCSI
     */
    protected com.huawei.www.hss.Int0_65534 localTCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTCSITracker = false;

    /**
     * field for SMSCSI
     */
    protected com.huawei.www.hss.Int0_65534 localSMSCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSMSCSITracker = false;

    /**
     * field for MTSMSCSI
     */
    protected com.huawei.www.hss.Int0_65534 localMTSMSCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMTSMSCSITracker = false;

    /**
     * field for DCSI
     */
    protected com.huawei.www.hss.Int0_65534 localDCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDCSITracker = false;

    /**
     * field for VTCSI
     */
    protected com.huawei.www.hss.Int0_65534 localVTCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVTCSITracker = false;

    /**
     * field for MCSI
     */
    protected com.huawei.www.hss.Int0_65534 localMCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMCSITracker = false;

    /**
     * field for SSCSI
     */
    protected com.huawei.www.hss.Int0_65534 localSSCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSSCSITracker = false;

    /**
     * field for TIFCSI
     */
    protected com.huawei.www.hss._EnumType localTIFCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTIFCSITracker = false;

    /**
     * field for UCSI
     */
    protected com.huawei.www.hss.Int0_65534 localUCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUCSITracker = false;

    /**
     * field for GPRSCSI
     */
    protected com.huawei.www.hss.Int0_65534 localGPRSCSI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGPRSCSITracker = false;

    /**
     * field for LCS
     */
    protected com.huawei.www.hss.Int0_65534 localLCS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLCSTracker = false;

    /**
     * field for GPRSTPL
     */
    protected com.huawei.www.hss.Int0_65534 localGPRSTPL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGPRSTPLTracker = false;

    /**
     * field for VLRLIST
     */
    protected com.huawei.www.hss.Int0_65534 localVLRLIST;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVLRLISTTracker = false;

    /**
     * field for SGSNLIST
     */
    protected com.huawei.www.hss.Int0_65534 localSGSNLIST;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSGSNLISTTracker = false;

    /**
     * field for SMDP
     */
    protected com.huawei.www.hss._EnumType localSMDP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSMDPTracker = false;

    /**
     * field for NAEA_CIC
     */
    protected com.huawei.www.hss.Int0_9999 localNAEA_CIC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localNAEA_CICTracker = false;

    /**
     * field for NLRIND
     */
    protected com.huawei.www.hss._EnumType localNLRIND;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localNLRINDTracker = false;

    /**
     * field for LINE2NUM
     */
    protected com.huawei.www.hss.Str1_15 localLINE2NUM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLINE2NUMTracker = false;

    /**
     * field for VVDN
     */
    protected com.huawei.www.hss._EnumType localVVDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVVDNTracker = false;

    /**
     * field for RBT
     */
    protected com.huawei.www.hss.Int0_254 localRBT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRBTTracker = false;

    /**
     * field for UTRANNOTALLOWED
     */
    protected com.huawei.www.hss._EnumType localUTRANNOTALLOWED;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUTRANNOTALLOWEDTracker = false;

    /**
     * field for GERANNOTALLOWED
     */
    protected com.huawei.www.hss._EnumType localGERANNOTALLOWED;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGERANNOTALLOWEDTracker = false;

    /**
     * field for CARP
     */
    protected com.huawei.www.hss.Int1_255 localCARP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCARPTracker = false;

    /**
     * field for RROPTION
     */
    protected com.huawei.www.hss._EnumType localRROPTION;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRROPTIONTracker = false;

    /**
     * field for RRTPL
     */
    protected com.huawei.www.hss.Int0_65534 localRRTPL;

    /**
     * field for VBS
     */
    protected com.huawei.www.hss.Int0_65534 localVBS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVBSTracker = false;

    /**
     * field for VGCS
     */
    protected com.huawei.www.hss.Int0_65534 localVGCS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVGCSTracker = false;

    /**
     * field for EMLPP_MAX
     */
    protected com.huawei.www.hss._EnumType localEMLPP_MAX;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEMLPP_MAXTracker = false;

    /**
     * field for EMLPP_DEF
     */
    protected com.huawei.www.hss._EnumType localEMLPP_DEF;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEMLPP_DEFTracker = false;

    /**
     * field for EMLPP_COU
     */
    protected com.huawei.www.hss._EnumType localEMLPP_COU;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEMLPP_COUTracker = false;

    /**
     * field for ECATEGORY
     */
    protected com.huawei.www.hss.Int1_254 localECATEGORY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localECATEGORYTracker = false;

    /**
     * field for UUS
     */
    protected com.huawei.www.hss.Str0_65535 localUUS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUUSTracker = false;

    /**
     * field for SMSCF
     */
    protected com.huawei.www.hss._EnumType localSMSCF;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSMSCFTracker = false;

    /**
     * field for SMSCFOFAID
     */
    protected com.huawei.www.hss.Int0_65534 localSMSCFOFAID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSMSCFOFAIDTracker = false;

    /**
     * field for MC
     */
    protected com.huawei.www.hss._EnumType localMC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMCTracker = false;

    /**
     * field for NBRSB
     */
    protected com.huawei.www.hss.Int2_7 localNBRSB;

    /**
     * field for NBRUSER
     */
    protected com.huawei.www.hss.Int1_7 localNBRUSER;

    /**
     * field for IST
     */
    protected com.huawei.www.hss._EnumType localIST;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localISTTracker = false;

    /**
     * field for ISTTIMER
     */
    protected com.huawei.www.hss.Int15_255 localISTTIMER;

    /**
     * field for ISTRSP
     */
    protected com.huawei.www.hss._EnumType localISTRSP;

    /**
     * field for OPTGPRSTPLID
     */
    protected com.huawei.www.hss.Int0_65534 localOPTGPRSTPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localOPTGPRSTPLIDTracker = false;

    /**
     * field for CHARGE_GLOBAL
     */
    protected com.huawei.www.hss._EnumType localCHARGE_GLOBAL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCHARGE_GLOBALTracker = false;

    /**
     * field for DICLENGTH
     */
    protected com.huawei.www.hss._EnumType localDICLENGTH;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDICLENGTHTracker = false;

    /**
     * field for ROUTECATEGORY
     */
    protected com.huawei.www.hss.Int1_255 localROUTECATEGORY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localROUTECATEGORYTracker = false;

    /**
     * field for EXEXROUTECATEGORY
     */
    protected com.huawei.www.hss.Int1_2147483647 localEXEXROUTECATEGORY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEXEXROUTECATEGORYTracker = false;

    /**
     * field for CALLREDIRECT
     */
    protected com.huawei.www.hss.Int0_255 localCALLREDIRECT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCALLREDIRECTTracker = false;

    /**
     * field for NRBT
     */
    protected com.huawei.www.hss.Int1_65535 localNRBT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localNRBTTracker = false;

    /**
     * field for OSK
     */
    protected com.huawei.www.hss.Int1_999 localOSK;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localOSKTracker = false;

    /**
     * field for TSK
     */
    protected com.huawei.www.hss.Int1_999 localTSK;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTSKTracker = false;

    /**
     * field for MERBT
     */
    protected com.huawei.www.hss._EnumType localMERBT;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMERBTTracker = false;

    /**
     * field for NIRPROV
     */
    protected com.huawei.www.hss._EnumType localNIRPROV;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localNIRPROVTracker = false;

    /**
     * field for NIRINDEX
     */
    protected com.huawei.www.hss.Int0_999 localNIRINDEX;

    /**
     * field for RZONE
     */
    protected com.huawei.www.hss.Int0_9 localRZONE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localRZONETracker = false;

    /**
     * field for CCBS
     */
    protected com.huawei.www.hss._EnumType localCCBS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCCBSTracker = false;

    /**
     * field for CCBSTARGET
     */
    protected com.huawei.www.hss._EnumType localCCBSTARGET;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCCBSTARGETTracker = false;

    /**
     * field for ACR_STATUS
     */
    protected com.huawei.www.hss._EnumType localACR_STATUS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localACR_STATUSTracker = false;

    /**
     * field for SMSROUTETPL
     */
    protected com.huawei.www.hss.Int0_65534 localSMSROUTETPL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSMSROUTETPLTracker = false;

    /**
     * field for SUPSHORTNUM
     */
    protected com.huawei.www.hss._EnumType localSUPSHORTNUM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSUPSHORTNUMTracker = false;

    /**
     * field for ACTCFD
     */
    protected com.huawei.www.hss._EnumType localACTCFD;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localACTCFDTracker = false;

    /**
     * field for SMSINPROV
     */
    protected com.huawei.www.hss._EnumType localSMSINPROV;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSMSINPROVTracker = false;

    /**
     * field for SCPADD
     */
    protected com.huawei.www.hss.Str1_15 localSCPADD;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSCPADDTracker = false;

    /**
     * field for SKEY
     */
    protected com.huawei.www.hss.Int0_2147483647 localSKEY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSKEYTracker = false;

    /**
     * field for DP
     */
    protected com.huawei.www.hss.Str0_65535 localDP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDPTracker = false;

    /**
     * field for TAMM
     */
    protected com.huawei.www.hss._EnumType localTAMM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTAMMTracker = false;

    /**
     * field for DEFAULTOFA_ID
     */
    protected com.huawei.www.hss.Int0_65534 localDEFAULTOFA_ID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDEFAULTOFA_IDTracker = false;

    /**
     * field for GANNOTALLOWED
     */
    protected com.huawei.www.hss._EnumType localGANNOTALLOWED;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localGANNOTALLOWEDTracker = false;

    /**
     * field for IHSPAENOTALLOWED
     */
    protected com.huawei.www.hss._EnumType localIHSPAENOTALLOWED;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIHSPAENOTALLOWEDTracker = false;

    /**
     * field for EUTRANNOTALLOWED
     */
    protected com.huawei.www.hss._EnumType localEUTRANNOTALLOWED;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localEUTRANNOTALLOWEDTracker = false;

    /**
     * field for N3GPPNOTALLOWED
     */
    protected com.huawei.www.hss._EnumType localN3GPPNOTALLOWED;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localN3GPPNOTALLOWEDTracker = false;

    /**
     * field for SCHARGE_GLOBAL
     */
    protected com.huawei.www.hss.Str4_4 localSCHARGE_GLOBAL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSCHARGE_GLOBALTracker = false;

    /**
     * field for CPP
     */
    protected com.huawei.www.hss._EnumType localCPP;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCPPTracker = false;

    /**
     * field for ECATOPTION
     */
    protected com.huawei.www.hss.Int0_127 localECATOPTION;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localECATOPTIONTracker = false;

    /**
     * field for ELCS
     */
    protected com.huawei.www.hss._EnumType localELCS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localELCSTracker = false;

    /**
     * field for FRAUDTPLID
     */
    protected com.huawei.www.hss.Int0_65534 localFRAUDTPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localFRAUDTPLIDTracker = false;

    /**
     * field for IMEILCKPROV
     */
    protected com.huawei.www.hss._EnumType localIMEILCKPROV;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMEILCKPROVTracker = false;

    /**
     * field for IMSIIMEIBIND
     */
    protected com.huawei.www.hss.Str14_14 localIMSIIMEIBIND;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMSIIMEIBINDTracker = false;

    /**
     * field for M2MNOTIFY
     */
    protected com.huawei.www.hss._EnumType localM2MNOTIFY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localM2MNOTIFYTracker = false;

    /**
     * field for LUCSI_TPL_ID
     */
    protected com.huawei.www.hss.Int0_65534 localLUCSI_TPL_ID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLUCSI_TPL_IDTracker = false;

    /**
     * field for SHORTNUMTPL
     */
    protected com.huawei.www.hss.Int0_998 localSHORTNUMTPL;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSHORTNUMTPLTracker = false;

    /**
     * field for USERCATEGORY
     */
    protected com.huawei.www.hss._EnumType localUSERCATEGORY;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localUSERCATEGORYTracker = false;

    /**
     * field for ODBPREMSMS
     */
    protected com.huawei.www.hss._EnumType localODBPREMSMS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBPREMSMSTracker = false;

    /**
     * field for ODBADULTSMS
     */
    protected com.huawei.www.hss._EnumType localODBADULTSMS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localODBADULTSMSTracker = false;

    /**
     * field for BOSK
     */
    protected com.huawei.www.hss.Int1_999 localBOSK;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBOSKTracker = false;

    /**
     * field for ZCLOCKPROV
     */
    protected com.huawei.www.hss._EnumType localZCLOCKPROV;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localZCLOCKPROVTracker = false;

    /**
     * field for PSUSERTPLID
     */
    protected com.huawei.www.hss.Int0_65534 localPSUSERTPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPSUSERTPLIDTracker = false;

    /**
     * field for PSAPNOITPLID
     */
    protected com.huawei.www.hss.Int0_65534 localPSAPNOITPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPSAPNOITPLIDTracker = false;

    /**
     * field for M2MCISDN
     */
    protected com.huawei.www.hss.Str1_15 localM2MCISDN;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localM2MCISDNTracker = false;

    /**
     * field for MAPADDRRESTPLID
     */
    protected com.huawei.www.hss.Int0_65534 localMAPADDRRESTPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMAPADDRRESTPLIDTracker = false;

    /**
     * field for ETCSICONVER_TPLID
     */
    protected com.huawei.www.hss.Int0_65534 localETCSICONVER_TPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localETCSICONVER_TPLIDTracker = false;

    /**
     * field for DND
     */
    protected com.huawei.www.hss._EnumType localDND;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localDNDTracker = false;

    /**
     * field for VMCC
     */
    protected com.huawei.www.hss._EnumType localVMCC;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVMCCTracker = false;

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_255
     */
    public com.huawei.www.hss.Int1_255 getHLRSN() {
        return localHLRSN;
    }

    /**
     * Auto generated setter method
     * @param param HLRSN
     */
    public void setHLRSN(com.huawei.www.hss.Int1_255 param) {
        this.localHLRSN = param;
    }

    public boolean isIMSISpecified() {
        return localIMSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getIMSI() {
        return localIMSI;
    }

    /**
     * Auto generated setter method
     * @param param IMSI
     */
    public void setIMSI(com.huawei.www.hss.Str6_15 param) {
        localIMSITracker = param != null;

        this.localIMSI = param;
    }

    public boolean isISDNSpecified() {
        return localISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getISDN() {
        return localISDN;
    }

    /**
     * Auto generated setter method
     * @param param ISDN
     */
    public void setISDN(com.huawei.www.hss.Str1_15 param) {
        localISDNTracker = param != null;

        this.localISDN = param;
    }

    public boolean isNAMSpecified() {
        return localNAMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getNAM() {
        return localNAM;
    }

    /**
     * Auto generated setter method
     * @param param NAM
     */
    public void setNAM(com.huawei.www.hss._EnumType param) {
        localNAMTracker = param != null;

        this.localNAM = param;
    }

    public boolean isCATEGORYSpecified() {
        return localCATEGORYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCATEGORY() {
        return localCATEGORY;
    }

    /**
     * Auto generated setter method
     * @param param CATEGORY
     */
    public void setCATEGORY(com.huawei.www.hss._EnumType param) {
        localCATEGORYTracker = param != null;

        this.localCATEGORY = param;
    }

    public boolean isDEFAULTCALLSpecified() {
        return localDEFAULTCALLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDEFAULTCALL() {
        return localDEFAULTCALL;
    }

    /**
     * Auto generated setter method
     * @param param DEFAULTCALL
     */
    public void setDEFAULTCALL(com.huawei.www.hss._EnumType param) {
        localDEFAULTCALLTracker = param != null;

        this.localDEFAULTCALL = param;
    }

    public boolean isTSSpecified() {
        return localTSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_65535
     */
    public com.huawei.www.hss.Str0_65535 getTS() {
        return localTS;
    }

    /**
     * Auto generated setter method
     * @param param TS
     */
    public void setTS(com.huawei.www.hss.Str0_65535 param) {
        localTSTracker = param != null;

        this.localTS = param;
    }

    public boolean isBSSpecified() {
        return localBSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_65535
     */
    public com.huawei.www.hss.Str0_65535 getBS() {
        return localBS;
    }

    /**
     * Auto generated setter method
     * @param param BS
     */
    public void setBS(com.huawei.www.hss.Str0_65535 param) {
        localBSTracker = param != null;

        this.localBS = param;
    }

    public boolean isCFUSpecified() {
        return localCFUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFU() {
        return localCFU;
    }

    /**
     * Auto generated setter method
     * @param param CFU
     */
    public void setCFU(com.huawei.www.hss._EnumType param) {
        localCFUTracker = param != null;

        this.localCFU = param;
    }

    public boolean isCFUOFAIDSpecified() {
        return localCFUOFAIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFUOFAID() {
        return localCFUOFAID;
    }

    /**
     * Auto generated setter method
     * @param param CFUOFAID
     */
    public void setCFUOFAID(com.huawei.www.hss.Int0_65534 param) {
        localCFUOFAIDTracker = param != null;

        this.localCFUOFAID = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFUNCS() {
        return localCFUNCS;
    }

    /**
     * Auto generated setter method
     * @param param CFUNCS
     */
    public void setCFUNCS(com.huawei.www.hss._EnumType param) {
        this.localCFUNCS = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFUCOU() {
        return localCFUCOU;
    }

    /**
     * Auto generated setter method
     * @param param CFUCOU
     */
    public void setCFUCOU(com.huawei.www.hss._EnumType param) {
        this.localCFUCOU = param;
    }

    public boolean isCFBSpecified() {
        return localCFBTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFB() {
        return localCFB;
    }

    /**
     * Auto generated setter method
     * @param param CFB
     */
    public void setCFB(com.huawei.www.hss._EnumType param) {
        localCFBTracker = param != null;

        this.localCFB = param;
    }

    public boolean isCFBOFAIDSpecified() {
        return localCFBOFAIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFBOFAID() {
        return localCFBOFAID;
    }

    /**
     * Auto generated setter method
     * @param param CFBOFAID
     */
    public void setCFBOFAID(com.huawei.www.hss.Int0_65534 param) {
        localCFBOFAIDTracker = param != null;

        this.localCFBOFAID = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFBNFS() {
        return localCFBNFS;
    }

    /**
     * Auto generated setter method
     * @param param CFBNFS
     */
    public void setCFBNFS(com.huawei.www.hss._EnumType param) {
        this.localCFBNFS = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFBNCS() {
        return localCFBNCS;
    }

    /**
     * Auto generated setter method
     * @param param CFBNCS
     */
    public void setCFBNCS(com.huawei.www.hss._EnumType param) {
        this.localCFBNCS = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFBCOU() {
        return localCFBCOU;
    }

    /**
     * Auto generated setter method
     * @param param CFBCOU
     */
    public void setCFBCOU(com.huawei.www.hss._EnumType param) {
        this.localCFBCOU = param;
    }

    public boolean isCFNRYSpecified() {
        return localCFNRYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRY() {
        return localCFNRY;
    }

    /**
     * Auto generated setter method
     * @param param CFNRY
     */
    public void setCFNRY(com.huawei.www.hss._EnumType param) {
        localCFNRYTracker = param != null;

        this.localCFNRY = param;
    }

    public boolean isCFNRYOFAIDSpecified() {
        return localCFNRYOFAIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFNRYOFAID() {
        return localCFNRYOFAID;
    }

    /**
     * Auto generated setter method
     * @param param CFNRYOFAID
     */
    public void setCFNRYOFAID(com.huawei.www.hss.Int0_65534 param) {
        localCFNRYOFAIDTracker = param != null;

        this.localCFNRYOFAID = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRYNFS() {
        return localCFNRYNFS;
    }

    /**
     * Auto generated setter method
     * @param param CFNRYNFS
     */
    public void setCFNRYNFS(com.huawei.www.hss._EnumType param) {
        this.localCFNRYNFS = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRYNCS() {
        return localCFNRYNCS;
    }

    /**
     * Auto generated setter method
     * @param param CFNRYNCS
     */
    public void setCFNRYNCS(com.huawei.www.hss._EnumType param) {
        this.localCFNRYNCS = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRYCOU() {
        return localCFNRYCOU;
    }

    /**
     * Auto generated setter method
     * @param param CFNRYCOU
     */
    public void setCFNRYCOU(com.huawei.www.hss._EnumType param) {
        this.localCFNRYCOU = param;
    }

    public boolean isCFNRCSpecified() {
        return localCFNRCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRC() {
        return localCFNRC;
    }

    /**
     * Auto generated setter method
     * @param param CFNRC
     */
    public void setCFNRC(com.huawei.www.hss._EnumType param) {
        localCFNRCTracker = param != null;

        this.localCFNRC = param;
    }

    public boolean isCFNRCOFAIDSpecified() {
        return localCFNRCOFAIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getCFNRCOFAID() {
        return localCFNRCOFAID;
    }

    /**
     * Auto generated setter method
     * @param param CFNRCOFAID
     */
    public void setCFNRCOFAID(com.huawei.www.hss.Int0_65534 param) {
        localCFNRCOFAIDTracker = param != null;

        this.localCFNRCOFAID = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRCNCS() {
        return localCFNRCNCS;
    }

    /**
     * Auto generated setter method
     * @param param CFNRCNCS
     */
    public void setCFNRCNCS(com.huawei.www.hss._EnumType param) {
        this.localCFNRCNCS = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFNRCOU() {
        return localCFNRCOU;
    }

    /**
     * Auto generated setter method
     * @param param CFNRCOU
     */
    public void setCFNRCOU(com.huawei.www.hss._EnumType param) {
        this.localCFNRCOU = param;
    }

    public boolean isCFDSpecified() {
        return localCFDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFD() {
        return localCFD;
    }

    /**
     * Auto generated setter method
     * @param param CFD
     */
    public void setCFD(com.huawei.www.hss._EnumType param) {
        localCFDTracker = param != null;

        this.localCFD = param;
    }

    public boolean isVALIDCCFSpecified() {
        return localVALIDCCFTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_65535
     */
    public com.huawei.www.hss.Str0_65535 getVALIDCCF() {
        return localVALIDCCF;
    }

    /**
     * Auto generated setter method
     * @param param VALIDCCF
     */
    public void setVALIDCCF(com.huawei.www.hss.Str0_65535 param) {
        localVALIDCCFTracker = param != null;

        this.localVALIDCCF = param;
    }

    public boolean isSUPINTERCFDSpecified() {
        return localSUPINTERCFDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSUPINTERCFD() {
        return localSUPINTERCFD;
    }

    /**
     * Auto generated setter method
     * @param param SUPINTERCFD
     */
    public void setSUPINTERCFD(com.huawei.www.hss._EnumType param) {
        localSUPINTERCFDTracker = param != null;

        this.localSUPINTERCFD = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFDNFS() {
        return localCFDNFS;
    }

    /**
     * Auto generated setter method
     * @param param CFDNFS
     */
    public void setCFDNFS(com.huawei.www.hss._EnumType param) {
        this.localCFDNFS = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFDNCS() {
        return localCFDNCS;
    }

    /**
     * Auto generated setter method
     * @param param CFDNCS
     */
    public void setCFDNCS(com.huawei.www.hss._EnumType param) {
        this.localCFDNCS = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getCFDFTN() {
        return localCFDFTN;
    }

    /**
     * Auto generated setter method
     * @param param CFDFTN
     */
    public void setCFDFTN(com.huawei.www.hss.Str1_16 param) {
        this.localCFDFTN = param;
    }

    public boolean isCFDBSGSpecified() {
        return localCFDBSGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFDBSG() {
        return localCFDBSG;
    }

    /**
     * Auto generated setter method
     * @param param CFDBSG
     */
    public void setCFDBSG(com.huawei.www.hss._EnumType param) {
        localCFDBSGTracker = param != null;

        this.localCFDBSG = param;
    }

    public boolean isCFDNRTIMESpecified() {
        return localCFDNRTIMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCFDNRTIME() {
        return localCFDNRTIME;
    }

    /**
     * Auto generated setter method
     * @param param CFDNRTIME
     */
    public void setCFDNRTIME(com.huawei.www.hss._EnumType param) {
        localCFDNRTIMETracker = param != null;

        this.localCFDNRTIME = param;
    }

    public boolean isCBSpecified() {
        return localCBTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_65535
     */
    public com.huawei.www.hss.Str0_65535 getCB() {
        return localCB;
    }

    /**
     * Auto generated setter method
     * @param param CB
     */
    public void setCB(com.huawei.www.hss.Str0_65535 param) {
        localCBTracker = param != null;

        this.localCB = param;
    }

    public boolean isCBCOUSpecified() {
        return localCBCOUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCBCOU() {
        return localCBCOU;
    }

    /**
     * Auto generated setter method
     * @param param CBCOU
     */
    public void setCBCOU(com.huawei.www.hss._EnumType param) {
        localCBCOUTracker = param != null;

        this.localCBCOU = param;
    }

    public boolean isCLIPSpecified() {
        return localCLIPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCLIP() {
        return localCLIP;
    }

    /**
     * Auto generated setter method
     * @param param CLIP
     */
    public void setCLIP(com.huawei.www.hss._EnumType param) {
        localCLIPTracker = param != null;

        this.localCLIP = param;
    }

    public boolean isCNAPSpecified() {
        return localCNAPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCNAP() {
        return localCNAP;
    }

    /**
     * Auto generated setter method
     * @param param CNAP
     */
    public void setCNAP(com.huawei.www.hss._EnumType param) {
        localCNAPTracker = param != null;

        this.localCNAP = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCLIPOR() {
        return localCLIPOR;
    }

    /**
     * Auto generated setter method
     * @param param CLIPOR
     */
    public void setCLIPOR(com.huawei.www.hss._EnumType param) {
        this.localCLIPOR = param;
    }

    public boolean isBSGCLIPSpecified() {
        return localBSGCLIPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_65535
     */
    public com.huawei.www.hss.Str0_65535 getBSGCLIP() {
        return localBSGCLIP;
    }

    /**
     * Auto generated setter method
     * @param param BSGCLIP
     */
    public void setBSGCLIP(com.huawei.www.hss.Str0_65535 param) {
        localBSGCLIPTracker = param != null;

        this.localBSGCLIP = param;
    }

    public boolean isCLIRSpecified() {
        return localCLIRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCLIR() {
        return localCLIR;
    }

    /**
     * Auto generated setter method
     * @param param CLIR
     */
    public void setCLIR(com.huawei.www.hss._EnumType param) {
        localCLIRTracker = param != null;

        this.localCLIR = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCLIRMODE() {
        return localCLIRMODE;
    }

    /**
     * Auto generated setter method
     * @param param CLIRMODE
     */
    public void setCLIRMODE(com.huawei.www.hss._EnumType param) {
        this.localCLIRMODE = param;
    }

    public boolean isBSGCLIRSpecified() {
        return localBSGCLIRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_65535
     */
    public com.huawei.www.hss.Str0_65535 getBSGCLIR() {
        return localBSGCLIR;
    }

    /**
     * Auto generated setter method
     * @param param BSGCLIR
     */
    public void setBSGCLIR(com.huawei.www.hss.Str0_65535 param) {
        localBSGCLIRTracker = param != null;

        this.localBSGCLIR = param;
    }

    public boolean isCOLPSpecified() {
        return localCOLPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCOLP() {
        return localCOLP;
    }

    /**
     * Auto generated setter method
     * @param param COLP
     */
    public void setCOLP(com.huawei.www.hss._EnumType param) {
        localCOLPTracker = param != null;

        this.localCOLP = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCOLPOR() {
        return localCOLPOR;
    }

    /**
     * Auto generated setter method
     * @param param COLPOR
     */
    public void setCOLPOR(com.huawei.www.hss._EnumType param) {
        this.localCOLPOR = param;
    }

    public boolean isBSGCOLPSpecified() {
        return localBSGCOLPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_65535
     */
    public com.huawei.www.hss.Str0_65535 getBSGCOLP() {
        return localBSGCOLP;
    }

    /**
     * Auto generated setter method
     * @param param BSGCOLP
     */
    public void setBSGCOLP(com.huawei.www.hss.Str0_65535 param) {
        localBSGCOLPTracker = param != null;

        this.localBSGCOLP = param;
    }

    public boolean isCOLRSpecified() {
        return localCOLRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCOLR() {
        return localCOLR;
    }

    /**
     * Auto generated setter method
     * @param param COLR
     */
    public void setCOLR(com.huawei.www.hss._EnumType param) {
        localCOLRTracker = param != null;

        this.localCOLR = param;
    }

    public boolean isBSGCOLRSpecified() {
        return localBSGCOLRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_65535
     */
    public com.huawei.www.hss.Str0_65535 getBSGCOLR() {
        return localBSGCOLR;
    }

    /**
     * Auto generated setter method
     * @param param BSGCOLR
     */
    public void setBSGCOLR(com.huawei.www.hss.Str0_65535 param) {
        localBSGCOLRTracker = param != null;

        this.localBSGCOLR = param;
    }

    public boolean isECTSpecified() {
        return localECTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getECT() {
        return localECT;
    }

    /**
     * Auto generated setter method
     * @param param ECT
     */
    public void setECT(com.huawei.www.hss._EnumType param) {
        localECTTracker = param != null;

        this.localECT = param;
    }

    public boolean isCWSpecified() {
        return localCWTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCW() {
        return localCW;
    }

    /**
     * Auto generated setter method
     * @param param CW
     */
    public void setCW(com.huawei.www.hss._EnumType param) {
        localCWTracker = param != null;

        this.localCW = param;
    }

    public boolean isHOLDSpecified() {
        return localHOLDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getHOLD() {
        return localHOLD;
    }

    /**
     * Auto generated setter method
     * @param param HOLD
     */
    public void setHOLD(com.huawei.www.hss._EnumType param) {
        localHOLDTracker = param != null;

        this.localHOLD = param;
    }

    public boolean isMPTYSpecified() {
        return localMPTYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMPTY() {
        return localMPTY;
    }

    /**
     * Auto generated setter method
     * @param param MPTY
     */
    public void setMPTY(com.huawei.www.hss._EnumType param) {
        localMPTYTracker = param != null;

        this.localMPTY = param;
    }

    public boolean isAOCSpecified() {
        return localAOCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getAOC() {
        return localAOC;
    }

    /**
     * Auto generated setter method
     * @param param AOC
     */
    public void setAOC(com.huawei.www.hss._EnumType param) {
        localAOCTracker = param != null;

        this.localAOC = param;
    }

    public boolean isPLMNSPECSSSpecified() {
        return localPLMNSPECSSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_65535
     */
    public com.huawei.www.hss.Str0_65535 getPLMNSPECSS() {
        return localPLMNSPECSS;
    }

    /**
     * Auto generated setter method
     * @param param PLMNSPECSS
     */
    public void setPLMNSPECSS(com.huawei.www.hss.Str0_65535 param) {
        localPLMNSPECSSTracker = param != null;

        this.localPLMNSPECSS = param;
    }

    public boolean isODBSSSpecified() {
        return localODBSSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBSS() {
        return localODBSS;
    }

    /**
     * Auto generated setter method
     * @param param ODBSS
     */
    public void setODBSS(com.huawei.www.hss._EnumType param) {
        localODBSSTracker = param != null;

        this.localODBSS = param;
    }

    public boolean isODBOCSpecified() {
        return localODBOCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBOC() {
        return localODBOC;
    }

    /**
     * Auto generated setter method
     * @param param ODBOC
     */
    public void setODBOC(com.huawei.www.hss._EnumType param) {
        localODBOCTracker = param != null;

        this.localODBOC = param;
    }

    public boolean isODBICSpecified() {
        return localODBICTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBIC() {
        return localODBIC;
    }

    /**
     * Auto generated setter method
     * @param param ODBIC
     */
    public void setODBIC(com.huawei.www.hss._EnumType param) {
        localODBICTracker = param != null;

        this.localODBIC = param;
    }

    public boolean isODBROAMSpecified() {
        return localODBROAMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBROAM() {
        return localODBROAM;
    }

    /**
     * Auto generated setter method
     * @param param ODBROAM
     */
    public void setODBROAM(com.huawei.www.hss._EnumType param) {
        localODBROAMTracker = param != null;

        this.localODBROAM = param;
    }

    public boolean isODBENTESpecified() {
        return localODBENTETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBENTE() {
        return localODBENTE;
    }

    /**
     * Auto generated setter method
     * @param param ODBENTE
     */
    public void setODBENTE(com.huawei.www.hss._EnumType param) {
        localODBENTETracker = param != null;

        this.localODBENTE = param;
    }

    public boolean isODBINFOSpecified() {
        return localODBINFOTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBINFO() {
        return localODBINFO;
    }

    /**
     * Auto generated setter method
     * @param param ODBINFO
     */
    public void setODBINFO(com.huawei.www.hss._EnumType param) {
        localODBINFOTracker = param != null;

        this.localODBINFO = param;
    }

    public boolean isODBRCFSpecified() {
        return localODBRCFTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBRCF() {
        return localODBRCF;
    }

    /**
     * Auto generated setter method
     * @param param ODBRCF
     */
    public void setODBRCF(com.huawei.www.hss._EnumType param) {
        localODBRCFTracker = param != null;

        this.localODBRCF = param;
    }

    public boolean isODBECTSpecified() {
        return localODBECTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBECT() {
        return localODBECT;
    }

    /**
     * Auto generated setter method
     * @param param ODBECT
     */
    public void setODBECT(com.huawei.www.hss._EnumType param) {
        localODBECTTracker = param != null;

        this.localODBECT = param;
    }

    public boolean isODBDECTSpecified() {
        return localODBDECTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBDECT() {
        return localODBDECT;
    }

    /**
     * Auto generated setter method
     * @param param ODBDECT
     */
    public void setODBDECT(com.huawei.www.hss._EnumType param) {
        localODBDECTTracker = param != null;

        this.localODBDECT = param;
    }

    public boolean isODBMECTSpecified() {
        return localODBMECTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBMECT() {
        return localODBMECT;
    }

    /**
     * Auto generated setter method
     * @param param ODBMECT
     */
    public void setODBMECT(com.huawei.www.hss._EnumType param) {
        localODBMECTTracker = param != null;

        this.localODBMECT = param;
    }

    public boolean isODBPLMNSpecified() {
        return localODBPLMNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_65535
     */
    public com.huawei.www.hss.Str0_65535 getODBPLMN() {
        return localODBPLMN;
    }

    /**
     * Auto generated setter method
     * @param param ODBPLMN
     */
    public void setODBPLMN(com.huawei.www.hss.Str0_65535 param) {
        localODBPLMNTracker = param != null;

        this.localODBPLMN = param;
    }

    public boolean isODBPOSSpecified() {
        return localODBPOSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBPOS() {
        return localODBPOS;
    }

    /**
     * Auto generated setter method
     * @param param ODBPOS
     */
    public void setODBPOS(com.huawei.www.hss._EnumType param) {
        localODBPOSTracker = param != null;

        this.localODBPOS = param;
    }

    public boolean isODBPOSTYPESpecified() {
        return localODBPOSTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBPOSTYPE() {
        return localODBPOSTYPE;
    }

    /**
     * Auto generated setter method
     * @param param ODBPOSTYPE
     */
    public void setODBPOSTYPE(com.huawei.www.hss._EnumType param) {
        localODBPOSTYPETracker = param != null;

        this.localODBPOSTYPE = param;
    }

    public boolean isOCSISpecified() {
        return localOCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getOCSI() {
        return localOCSI;
    }

    /**
     * Auto generated setter method
     * @param param OCSI
     */
    public void setOCSI(com.huawei.www.hss.Int0_65534 param) {
        localOCSITracker = param != null;

        this.localOCSI = param;
    }

    public boolean isTCSISpecified() {
        return localTCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getTCSI() {
        return localTCSI;
    }

    /**
     * Auto generated setter method
     * @param param TCSI
     */
    public void setTCSI(com.huawei.www.hss.Int0_65534 param) {
        localTCSITracker = param != null;

        this.localTCSI = param;
    }

    public boolean isSMSCSISpecified() {
        return localSMSCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getSMSCSI() {
        return localSMSCSI;
    }

    /**
     * Auto generated setter method
     * @param param SMSCSI
     */
    public void setSMSCSI(com.huawei.www.hss.Int0_65534 param) {
        localSMSCSITracker = param != null;

        this.localSMSCSI = param;
    }

    public boolean isMTSMSCSISpecified() {
        return localMTSMSCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getMTSMSCSI() {
        return localMTSMSCSI;
    }

    /**
     * Auto generated setter method
     * @param param MTSMSCSI
     */
    public void setMTSMSCSI(com.huawei.www.hss.Int0_65534 param) {
        localMTSMSCSITracker = param != null;

        this.localMTSMSCSI = param;
    }

    public boolean isDCSISpecified() {
        return localDCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getDCSI() {
        return localDCSI;
    }

    /**
     * Auto generated setter method
     * @param param DCSI
     */
    public void setDCSI(com.huawei.www.hss.Int0_65534 param) {
        localDCSITracker = param != null;

        this.localDCSI = param;
    }

    public boolean isVTCSISpecified() {
        return localVTCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getVTCSI() {
        return localVTCSI;
    }

    /**
     * Auto generated setter method
     * @param param VTCSI
     */
    public void setVTCSI(com.huawei.www.hss.Int0_65534 param) {
        localVTCSITracker = param != null;

        this.localVTCSI = param;
    }

    public boolean isMCSISpecified() {
        return localMCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getMCSI() {
        return localMCSI;
    }

    /**
     * Auto generated setter method
     * @param param MCSI
     */
    public void setMCSI(com.huawei.www.hss.Int0_65534 param) {
        localMCSITracker = param != null;

        this.localMCSI = param;
    }

    public boolean isSSCSISpecified() {
        return localSSCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getSSCSI() {
        return localSSCSI;
    }

    /**
     * Auto generated setter method
     * @param param SSCSI
     */
    public void setSSCSI(com.huawei.www.hss.Int0_65534 param) {
        localSSCSITracker = param != null;

        this.localSSCSI = param;
    }

    public boolean isTIFCSISpecified() {
        return localTIFCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTIFCSI() {
        return localTIFCSI;
    }

    /**
     * Auto generated setter method
     * @param param TIFCSI
     */
    public void setTIFCSI(com.huawei.www.hss._EnumType param) {
        localTIFCSITracker = param != null;

        this.localTIFCSI = param;
    }

    public boolean isUCSISpecified() {
        return localUCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getUCSI() {
        return localUCSI;
    }

    /**
     * Auto generated setter method
     * @param param UCSI
     */
    public void setUCSI(com.huawei.www.hss.Int0_65534 param) {
        localUCSITracker = param != null;

        this.localUCSI = param;
    }

    public boolean isGPRSCSISpecified() {
        return localGPRSCSITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getGPRSCSI() {
        return localGPRSCSI;
    }

    /**
     * Auto generated setter method
     * @param param GPRSCSI
     */
    public void setGPRSCSI(com.huawei.www.hss.Int0_65534 param) {
        localGPRSCSITracker = param != null;

        this.localGPRSCSI = param;
    }

    public boolean isLCSSpecified() {
        return localLCSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getLCS() {
        return localLCS;
    }

    /**
     * Auto generated setter method
     * @param param LCS
     */
    public void setLCS(com.huawei.www.hss.Int0_65534 param) {
        localLCSTracker = param != null;

        this.localLCS = param;
    }

    public boolean isGPRSTPLSpecified() {
        return localGPRSTPLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getGPRSTPL() {
        return localGPRSTPL;
    }

    /**
     * Auto generated setter method
     * @param param GPRSTPL
     */
    public void setGPRSTPL(com.huawei.www.hss.Int0_65534 param) {
        localGPRSTPLTracker = param != null;

        this.localGPRSTPL = param;
    }

    public boolean isVLRLISTSpecified() {
        return localVLRLISTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getVLRLIST() {
        return localVLRLIST;
    }

    /**
     * Auto generated setter method
     * @param param VLRLIST
     */
    public void setVLRLIST(com.huawei.www.hss.Int0_65534 param) {
        localVLRLISTTracker = param != null;

        this.localVLRLIST = param;
    }

    public boolean isSGSNLISTSpecified() {
        return localSGSNLISTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getSGSNLIST() {
        return localSGSNLIST;
    }

    /**
     * Auto generated setter method
     * @param param SGSNLIST
     */
    public void setSGSNLIST(com.huawei.www.hss.Int0_65534 param) {
        localSGSNLISTTracker = param != null;

        this.localSGSNLIST = param;
    }

    public boolean isSMDPSpecified() {
        return localSMDPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSMDP() {
        return localSMDP;
    }

    /**
     * Auto generated setter method
     * @param param SMDP
     */
    public void setSMDP(com.huawei.www.hss._EnumType param) {
        localSMDPTracker = param != null;

        this.localSMDP = param;
    }

    public boolean isNAEA_CICSpecified() {
        return localNAEA_CICTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_9999
     */
    public com.huawei.www.hss.Int0_9999 getNAEA_CIC() {
        return localNAEA_CIC;
    }

    /**
     * Auto generated setter method
     * @param param NAEA_CIC
     */
    public void setNAEA_CIC(com.huawei.www.hss.Int0_9999 param) {
        localNAEA_CICTracker = param != null;

        this.localNAEA_CIC = param;
    }

    public boolean isNLRINDSpecified() {
        return localNLRINDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getNLRIND() {
        return localNLRIND;
    }

    /**
     * Auto generated setter method
     * @param param NLRIND
     */
    public void setNLRIND(com.huawei.www.hss._EnumType param) {
        localNLRINDTracker = param != null;

        this.localNLRIND = param;
    }

    public boolean isLINE2NUMSpecified() {
        return localLINE2NUMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getLINE2NUM() {
        return localLINE2NUM;
    }

    /**
     * Auto generated setter method
     * @param param LINE2NUM
     */
    public void setLINE2NUM(com.huawei.www.hss.Str1_15 param) {
        localLINE2NUMTracker = param != null;

        this.localLINE2NUM = param;
    }

    public boolean isVVDNSpecified() {
        return localVVDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVVDN() {
        return localVVDN;
    }

    /**
     * Auto generated setter method
     * @param param VVDN
     */
    public void setVVDN(com.huawei.www.hss._EnumType param) {
        localVVDNTracker = param != null;

        this.localVVDN = param;
    }

    public boolean isRBTSpecified() {
        return localRBTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_254
     */
    public com.huawei.www.hss.Int0_254 getRBT() {
        return localRBT;
    }

    /**
     * Auto generated setter method
     * @param param RBT
     */
    public void setRBT(com.huawei.www.hss.Int0_254 param) {
        localRBTTracker = param != null;

        this.localRBT = param;
    }

    public boolean isUTRANNOTALLOWEDSpecified() {
        return localUTRANNOTALLOWEDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUTRANNOTALLOWED() {
        return localUTRANNOTALLOWED;
    }

    /**
     * Auto generated setter method
     * @param param UTRANNOTALLOWED
     */
    public void setUTRANNOTALLOWED(com.huawei.www.hss._EnumType param) {
        localUTRANNOTALLOWEDTracker = param != null;

        this.localUTRANNOTALLOWED = param;
    }

    public boolean isGERANNOTALLOWEDSpecified() {
        return localGERANNOTALLOWEDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getGERANNOTALLOWED() {
        return localGERANNOTALLOWED;
    }

    /**
     * Auto generated setter method
     * @param param GERANNOTALLOWED
     */
    public void setGERANNOTALLOWED(com.huawei.www.hss._EnumType param) {
        localGERANNOTALLOWEDTracker = param != null;

        this.localGERANNOTALLOWED = param;
    }

    public boolean isCARPSpecified() {
        return localCARPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_255
     */
    public com.huawei.www.hss.Int1_255 getCARP() {
        return localCARP;
    }

    /**
     * Auto generated setter method
     * @param param CARP
     */
    public void setCARP(com.huawei.www.hss.Int1_255 param) {
        localCARPTracker = param != null;

        this.localCARP = param;
    }

    public boolean isRROPTIONSpecified() {
        return localRROPTIONTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getRROPTION() {
        return localRROPTION;
    }

    /**
     * Auto generated setter method
     * @param param RROPTION
     */
    public void setRROPTION(com.huawei.www.hss._EnumType param) {
        localRROPTIONTracker = param != null;

        this.localRROPTION = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getRRTPL() {
        return localRRTPL;
    }

    /**
     * Auto generated setter method
     * @param param RRTPL
     */
    public void setRRTPL(com.huawei.www.hss.Int0_65534 param) {
        this.localRRTPL = param;
    }

    public boolean isVBSSpecified() {
        return localVBSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getVBS() {
        return localVBS;
    }

    /**
     * Auto generated setter method
     * @param param VBS
     */
    public void setVBS(com.huawei.www.hss.Int0_65534 param) {
        localVBSTracker = param != null;

        this.localVBS = param;
    }

    public boolean isVGCSSpecified() {
        return localVGCSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getVGCS() {
        return localVGCS;
    }

    /**
     * Auto generated setter method
     * @param param VGCS
     */
    public void setVGCS(com.huawei.www.hss.Int0_65534 param) {
        localVGCSTracker = param != null;

        this.localVGCS = param;
    }

    public boolean isEMLPP_MAXSpecified() {
        return localEMLPP_MAXTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEMLPP_MAX() {
        return localEMLPP_MAX;
    }

    /**
     * Auto generated setter method
     * @param param EMLPP_MAX
     */
    public void setEMLPP_MAX(com.huawei.www.hss._EnumType param) {
        localEMLPP_MAXTracker = param != null;

        this.localEMLPP_MAX = param;
    }

    public boolean isEMLPP_DEFSpecified() {
        return localEMLPP_DEFTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEMLPP_DEF() {
        return localEMLPP_DEF;
    }

    /**
     * Auto generated setter method
     * @param param EMLPP_DEF
     */
    public void setEMLPP_DEF(com.huawei.www.hss._EnumType param) {
        localEMLPP_DEFTracker = param != null;

        this.localEMLPP_DEF = param;
    }

    public boolean isEMLPP_COUSpecified() {
        return localEMLPP_COUTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEMLPP_COU() {
        return localEMLPP_COU;
    }

    /**
     * Auto generated setter method
     * @param param EMLPP_COU
     */
    public void setEMLPP_COU(com.huawei.www.hss._EnumType param) {
        localEMLPP_COUTracker = param != null;

        this.localEMLPP_COU = param;
    }

    public boolean isECATEGORYSpecified() {
        return localECATEGORYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_254
     */
    public com.huawei.www.hss.Int1_254 getECATEGORY() {
        return localECATEGORY;
    }

    /**
     * Auto generated setter method
     * @param param ECATEGORY
     */
    public void setECATEGORY(com.huawei.www.hss.Int1_254 param) {
        localECATEGORYTracker = param != null;

        this.localECATEGORY = param;
    }

    public boolean isUUSSpecified() {
        return localUUSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_65535
     */
    public com.huawei.www.hss.Str0_65535 getUUS() {
        return localUUS;
    }

    /**
     * Auto generated setter method
     * @param param UUS
     */
    public void setUUS(com.huawei.www.hss.Str0_65535 param) {
        localUUSTracker = param != null;

        this.localUUS = param;
    }

    public boolean isSMSCFSpecified() {
        return localSMSCFTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSMSCF() {
        return localSMSCF;
    }

    /**
     * Auto generated setter method
     * @param param SMSCF
     */
    public void setSMSCF(com.huawei.www.hss._EnumType param) {
        localSMSCFTracker = param != null;

        this.localSMSCF = param;
    }

    public boolean isSMSCFOFAIDSpecified() {
        return localSMSCFOFAIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getSMSCFOFAID() {
        return localSMSCFOFAID;
    }

    /**
     * Auto generated setter method
     * @param param SMSCFOFAID
     */
    public void setSMSCFOFAID(com.huawei.www.hss.Int0_65534 param) {
        localSMSCFOFAIDTracker = param != null;

        this.localSMSCFOFAID = param;
    }

    public boolean isMCSpecified() {
        return localMCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMC() {
        return localMC;
    }

    /**
     * Auto generated setter method
     * @param param MC
     */
    public void setMC(com.huawei.www.hss._EnumType param) {
        localMCTracker = param != null;

        this.localMC = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int2_7
     */
    public com.huawei.www.hss.Int2_7 getNBRSB() {
        return localNBRSB;
    }

    /**
     * Auto generated setter method
     * @param param NBRSB
     */
    public void setNBRSB(com.huawei.www.hss.Int2_7 param) {
        this.localNBRSB = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_7
     */
    public com.huawei.www.hss.Int1_7 getNBRUSER() {
        return localNBRUSER;
    }

    /**
     * Auto generated setter method
     * @param param NBRUSER
     */
    public void setNBRUSER(com.huawei.www.hss.Int1_7 param) {
        this.localNBRUSER = param;
    }

    public boolean isISTSpecified() {
        return localISTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getIST() {
        return localIST;
    }

    /**
     * Auto generated setter method
     * @param param IST
     */
    public void setIST(com.huawei.www.hss._EnumType param) {
        localISTTracker = param != null;

        this.localIST = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int15_255
     */
    public com.huawei.www.hss.Int15_255 getISTTIMER() {
        return localISTTIMER;
    }

    /**
     * Auto generated setter method
     * @param param ISTTIMER
     */
    public void setISTTIMER(com.huawei.www.hss.Int15_255 param) {
        this.localISTTIMER = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getISTRSP() {
        return localISTRSP;
    }

    /**
     * Auto generated setter method
     * @param param ISTRSP
     */
    public void setISTRSP(com.huawei.www.hss._EnumType param) {
        this.localISTRSP = param;
    }

    public boolean isOPTGPRSTPLIDSpecified() {
        return localOPTGPRSTPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getOPTGPRSTPLID() {
        return localOPTGPRSTPLID;
    }

    /**
     * Auto generated setter method
     * @param param OPTGPRSTPLID
     */
    public void setOPTGPRSTPLID(com.huawei.www.hss.Int0_65534 param) {
        localOPTGPRSTPLIDTracker = param != null;

        this.localOPTGPRSTPLID = param;
    }

    public boolean isCHARGE_GLOBALSpecified() {
        return localCHARGE_GLOBALTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCHARGE_GLOBAL() {
        return localCHARGE_GLOBAL;
    }

    /**
     * Auto generated setter method
     * @param param CHARGE_GLOBAL
     */
    public void setCHARGE_GLOBAL(com.huawei.www.hss._EnumType param) {
        localCHARGE_GLOBALTracker = param != null;

        this.localCHARGE_GLOBAL = param;
    }

    public boolean isDICLENGTHSpecified() {
        return localDICLENGTHTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDICLENGTH() {
        return localDICLENGTH;
    }

    /**
     * Auto generated setter method
     * @param param DICLENGTH
     */
    public void setDICLENGTH(com.huawei.www.hss._EnumType param) {
        localDICLENGTHTracker = param != null;

        this.localDICLENGTH = param;
    }

    public boolean isROUTECATEGORYSpecified() {
        return localROUTECATEGORYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_255
     */
    public com.huawei.www.hss.Int1_255 getROUTECATEGORY() {
        return localROUTECATEGORY;
    }

    /**
     * Auto generated setter method
     * @param param ROUTECATEGORY
     */
    public void setROUTECATEGORY(com.huawei.www.hss.Int1_255 param) {
        localROUTECATEGORYTracker = param != null;

        this.localROUTECATEGORY = param;
    }

    public boolean isEXEXROUTECATEGORYSpecified() {
        return localEXEXROUTECATEGORYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_2147483647
     */
    public com.huawei.www.hss.Int1_2147483647 getEXEXROUTECATEGORY() {
        return localEXEXROUTECATEGORY;
    }

    /**
     * Auto generated setter method
     * @param param EXEXROUTECATEGORY
     */
    public void setEXEXROUTECATEGORY(com.huawei.www.hss.Int1_2147483647 param) {
        localEXEXROUTECATEGORYTracker = param != null;

        this.localEXEXROUTECATEGORY = param;
    }

    public boolean isCALLREDIRECTSpecified() {
        return localCALLREDIRECTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_255
     */
    public com.huawei.www.hss.Int0_255 getCALLREDIRECT() {
        return localCALLREDIRECT;
    }

    /**
     * Auto generated setter method
     * @param param CALLREDIRECT
     */
    public void setCALLREDIRECT(com.huawei.www.hss.Int0_255 param) {
        localCALLREDIRECTTracker = param != null;

        this.localCALLREDIRECT = param;
    }

    public boolean isNRBTSpecified() {
        return localNRBTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_65535
     */
    public com.huawei.www.hss.Int1_65535 getNRBT() {
        return localNRBT;
    }

    /**
     * Auto generated setter method
     * @param param NRBT
     */
    public void setNRBT(com.huawei.www.hss.Int1_65535 param) {
        localNRBTTracker = param != null;

        this.localNRBT = param;
    }

    public boolean isOSKSpecified() {
        return localOSKTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_999
     */
    public com.huawei.www.hss.Int1_999 getOSK() {
        return localOSK;
    }

    /**
     * Auto generated setter method
     * @param param OSK
     */
    public void setOSK(com.huawei.www.hss.Int1_999 param) {
        localOSKTracker = param != null;

        this.localOSK = param;
    }

    public boolean isTSKSpecified() {
        return localTSKTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_999
     */
    public com.huawei.www.hss.Int1_999 getTSK() {
        return localTSK;
    }

    /**
     * Auto generated setter method
     * @param param TSK
     */
    public void setTSK(com.huawei.www.hss.Int1_999 param) {
        localTSKTracker = param != null;

        this.localTSK = param;
    }

    public boolean isMERBTSpecified() {
        return localMERBTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getMERBT() {
        return localMERBT;
    }

    /**
     * Auto generated setter method
     * @param param MERBT
     */
    public void setMERBT(com.huawei.www.hss._EnumType param) {
        localMERBTTracker = param != null;

        this.localMERBT = param;
    }

    public boolean isNIRPROVSpecified() {
        return localNIRPROVTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getNIRPROV() {
        return localNIRPROV;
    }

    /**
     * Auto generated setter method
     * @param param NIRPROV
     */
    public void setNIRPROV(com.huawei.www.hss._EnumType param) {
        localNIRPROVTracker = param != null;

        this.localNIRPROV = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_999
     */
    public com.huawei.www.hss.Int0_999 getNIRINDEX() {
        return localNIRINDEX;
    }

    /**
     * Auto generated setter method
     * @param param NIRINDEX
     */
    public void setNIRINDEX(com.huawei.www.hss.Int0_999 param) {
        this.localNIRINDEX = param;
    }

    public boolean isRZONESpecified() {
        return localRZONETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_9
     */
    public com.huawei.www.hss.Int0_9 getRZONE() {
        return localRZONE;
    }

    /**
     * Auto generated setter method
     * @param param RZONE
     */
    public void setRZONE(com.huawei.www.hss.Int0_9 param) {
        localRZONETracker = param != null;

        this.localRZONE = param;
    }

    public boolean isCCBSSpecified() {
        return localCCBSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCCBS() {
        return localCCBS;
    }

    /**
     * Auto generated setter method
     * @param param CCBS
     */
    public void setCCBS(com.huawei.www.hss._EnumType param) {
        localCCBSTracker = param != null;

        this.localCCBS = param;
    }

    public boolean isCCBSTARGETSpecified() {
        return localCCBSTARGETTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCCBSTARGET() {
        return localCCBSTARGET;
    }

    /**
     * Auto generated setter method
     * @param param CCBSTARGET
     */
    public void setCCBSTARGET(com.huawei.www.hss._EnumType param) {
        localCCBSTARGETTracker = param != null;

        this.localCCBSTARGET = param;
    }

    public boolean isACR_STATUSSpecified() {
        return localACR_STATUSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getACR_STATUS() {
        return localACR_STATUS;
    }

    /**
     * Auto generated setter method
     * @param param ACR_STATUS
     */
    public void setACR_STATUS(com.huawei.www.hss._EnumType param) {
        localACR_STATUSTracker = param != null;

        this.localACR_STATUS = param;
    }

    public boolean isSMSROUTETPLSpecified() {
        return localSMSROUTETPLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getSMSROUTETPL() {
        return localSMSROUTETPL;
    }

    /**
     * Auto generated setter method
     * @param param SMSROUTETPL
     */
    public void setSMSROUTETPL(com.huawei.www.hss.Int0_65534 param) {
        localSMSROUTETPLTracker = param != null;

        this.localSMSROUTETPL = param;
    }

    public boolean isSUPSHORTNUMSpecified() {
        return localSUPSHORTNUMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSUPSHORTNUM() {
        return localSUPSHORTNUM;
    }

    /**
     * Auto generated setter method
     * @param param SUPSHORTNUM
     */
    public void setSUPSHORTNUM(com.huawei.www.hss._EnumType param) {
        localSUPSHORTNUMTracker = param != null;

        this.localSUPSHORTNUM = param;
    }

    public boolean isACTCFDSpecified() {
        return localACTCFDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getACTCFD() {
        return localACTCFD;
    }

    /**
     * Auto generated setter method
     * @param param ACTCFD
     */
    public void setACTCFD(com.huawei.www.hss._EnumType param) {
        localACTCFDTracker = param != null;

        this.localACTCFD = param;
    }

    public boolean isSMSINPROVSpecified() {
        return localSMSINPROVTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getSMSINPROV() {
        return localSMSINPROV;
    }

    /**
     * Auto generated setter method
     * @param param SMSINPROV
     */
    public void setSMSINPROV(com.huawei.www.hss._EnumType param) {
        localSMSINPROVTracker = param != null;

        this.localSMSINPROV = param;
    }

    public boolean isSCPADDSpecified() {
        return localSCPADDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getSCPADD() {
        return localSCPADD;
    }

    /**
     * Auto generated setter method
     * @param param SCPADD
     */
    public void setSCPADD(com.huawei.www.hss.Str1_15 param) {
        localSCPADDTracker = param != null;

        this.localSCPADD = param;
    }

    public boolean isSKEYSpecified() {
        return localSKEYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_2147483647
     */
    public com.huawei.www.hss.Int0_2147483647 getSKEY() {
        return localSKEY;
    }

    /**
     * Auto generated setter method
     * @param param SKEY
     */
    public void setSKEY(com.huawei.www.hss.Int0_2147483647 param) {
        localSKEYTracker = param != null;

        this.localSKEY = param;
    }

    public boolean isDPSpecified() {
        return localDPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str0_65535
     */
    public com.huawei.www.hss.Str0_65535 getDP() {
        return localDP;
    }

    /**
     * Auto generated setter method
     * @param param DP
     */
    public void setDP(com.huawei.www.hss.Str0_65535 param) {
        localDPTracker = param != null;

        this.localDP = param;
    }

    public boolean isTAMMSpecified() {
        return localTAMMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getTAMM() {
        return localTAMM;
    }

    /**
     * Auto generated setter method
     * @param param TAMM
     */
    public void setTAMM(com.huawei.www.hss._EnumType param) {
        localTAMMTracker = param != null;

        this.localTAMM = param;
    }

    public boolean isDEFAULTOFA_IDSpecified() {
        return localDEFAULTOFA_IDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getDEFAULTOFA_ID() {
        return localDEFAULTOFA_ID;
    }

    /**
     * Auto generated setter method
     * @param param DEFAULTOFA_ID
     */
    public void setDEFAULTOFA_ID(com.huawei.www.hss.Int0_65534 param) {
        localDEFAULTOFA_IDTracker = param != null;

        this.localDEFAULTOFA_ID = param;
    }

    public boolean isGANNOTALLOWEDSpecified() {
        return localGANNOTALLOWEDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getGANNOTALLOWED() {
        return localGANNOTALLOWED;
    }

    /**
     * Auto generated setter method
     * @param param GANNOTALLOWED
     */
    public void setGANNOTALLOWED(com.huawei.www.hss._EnumType param) {
        localGANNOTALLOWEDTracker = param != null;

        this.localGANNOTALLOWED = param;
    }

    public boolean isIHSPAENOTALLOWEDSpecified() {
        return localIHSPAENOTALLOWEDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getIHSPAENOTALLOWED() {
        return localIHSPAENOTALLOWED;
    }

    /**
     * Auto generated setter method
     * @param param IHSPAENOTALLOWED
     */
    public void setIHSPAENOTALLOWED(com.huawei.www.hss._EnumType param) {
        localIHSPAENOTALLOWEDTracker = param != null;

        this.localIHSPAENOTALLOWED = param;
    }

    public boolean isEUTRANNOTALLOWEDSpecified() {
        return localEUTRANNOTALLOWEDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getEUTRANNOTALLOWED() {
        return localEUTRANNOTALLOWED;
    }

    /**
     * Auto generated setter method
     * @param param EUTRANNOTALLOWED
     */
    public void setEUTRANNOTALLOWED(com.huawei.www.hss._EnumType param) {
        localEUTRANNOTALLOWEDTracker = param != null;

        this.localEUTRANNOTALLOWED = param;
    }

    public boolean isN3GPPNOTALLOWEDSpecified() {
        return localN3GPPNOTALLOWEDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getN3GPPNOTALLOWED() {
        return localN3GPPNOTALLOWED;
    }

    /**
     * Auto generated setter method
     * @param param N3GPPNOTALLOWED
     */
    public void setN3GPPNOTALLOWED(com.huawei.www.hss._EnumType param) {
        localN3GPPNOTALLOWEDTracker = param != null;

        this.localN3GPPNOTALLOWED = param;
    }

    public boolean isSCHARGE_GLOBALSpecified() {
        return localSCHARGE_GLOBALTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str4_4
     */
    public com.huawei.www.hss.Str4_4 getSCHARGE_GLOBAL() {
        return localSCHARGE_GLOBAL;
    }

    /**
     * Auto generated setter method
     * @param param SCHARGE_GLOBAL
     */
    public void setSCHARGE_GLOBAL(com.huawei.www.hss.Str4_4 param) {
        localSCHARGE_GLOBALTracker = param != null;

        this.localSCHARGE_GLOBAL = param;
    }

    public boolean isCPPSpecified() {
        return localCPPTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCPP() {
        return localCPP;
    }

    /**
     * Auto generated setter method
     * @param param CPP
     */
    public void setCPP(com.huawei.www.hss._EnumType param) {
        localCPPTracker = param != null;

        this.localCPP = param;
    }

    public boolean isECATOPTIONSpecified() {
        return localECATOPTIONTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_127
     */
    public com.huawei.www.hss.Int0_127 getECATOPTION() {
        return localECATOPTION;
    }

    /**
     * Auto generated setter method
     * @param param ECATOPTION
     */
    public void setECATOPTION(com.huawei.www.hss.Int0_127 param) {
        localECATOPTIONTracker = param != null;

        this.localECATOPTION = param;
    }

    public boolean isELCSSpecified() {
        return localELCSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getELCS() {
        return localELCS;
    }

    /**
     * Auto generated setter method
     * @param param ELCS
     */
    public void setELCS(com.huawei.www.hss._EnumType param) {
        localELCSTracker = param != null;

        this.localELCS = param;
    }

    public boolean isFRAUDTPLIDSpecified() {
        return localFRAUDTPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getFRAUDTPLID() {
        return localFRAUDTPLID;
    }

    /**
     * Auto generated setter method
     * @param param FRAUDTPLID
     */
    public void setFRAUDTPLID(com.huawei.www.hss.Int0_65534 param) {
        localFRAUDTPLIDTracker = param != null;

        this.localFRAUDTPLID = param;
    }

    public boolean isIMEILCKPROVSpecified() {
        return localIMEILCKPROVTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getIMEILCKPROV() {
        return localIMEILCKPROV;
    }

    /**
     * Auto generated setter method
     * @param param IMEILCKPROV
     */
    public void setIMEILCKPROV(com.huawei.www.hss._EnumType param) {
        localIMEILCKPROVTracker = param != null;

        this.localIMEILCKPROV = param;
    }

    public boolean isIMSIIMEIBINDSpecified() {
        return localIMSIIMEIBINDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str14_14
     */
    public com.huawei.www.hss.Str14_14 getIMSIIMEIBIND() {
        return localIMSIIMEIBIND;
    }

    /**
     * Auto generated setter method
     * @param param IMSIIMEIBIND
     */
    public void setIMSIIMEIBIND(com.huawei.www.hss.Str14_14 param) {
        localIMSIIMEIBINDTracker = param != null;

        this.localIMSIIMEIBIND = param;
    }

    public boolean isM2MNOTIFYSpecified() {
        return localM2MNOTIFYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getM2MNOTIFY() {
        return localM2MNOTIFY;
    }

    /**
     * Auto generated setter method
     * @param param M2MNOTIFY
     */
    public void setM2MNOTIFY(com.huawei.www.hss._EnumType param) {
        localM2MNOTIFYTracker = param != null;

        this.localM2MNOTIFY = param;
    }

    public boolean isLUCSI_TPL_IDSpecified() {
        return localLUCSI_TPL_IDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getLUCSI_TPL_ID() {
        return localLUCSI_TPL_ID;
    }

    /**
     * Auto generated setter method
     * @param param LUCSI_TPL_ID
     */
    public void setLUCSI_TPL_ID(com.huawei.www.hss.Int0_65534 param) {
        localLUCSI_TPL_IDTracker = param != null;

        this.localLUCSI_TPL_ID = param;
    }

    public boolean isSHORTNUMTPLSpecified() {
        return localSHORTNUMTPLTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_998
     */
    public com.huawei.www.hss.Int0_998 getSHORTNUMTPL() {
        return localSHORTNUMTPL;
    }

    /**
     * Auto generated setter method
     * @param param SHORTNUMTPL
     */
    public void setSHORTNUMTPL(com.huawei.www.hss.Int0_998 param) {
        localSHORTNUMTPLTracker = param != null;

        this.localSHORTNUMTPL = param;
    }

    public boolean isUSERCATEGORYSpecified() {
        return localUSERCATEGORYTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getUSERCATEGORY() {
        return localUSERCATEGORY;
    }

    /**
     * Auto generated setter method
     * @param param USERCATEGORY
     */
    public void setUSERCATEGORY(com.huawei.www.hss._EnumType param) {
        localUSERCATEGORYTracker = param != null;

        this.localUSERCATEGORY = param;
    }

    public boolean isODBPREMSMSSpecified() {
        return localODBPREMSMSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBPREMSMS() {
        return localODBPREMSMS;
    }

    /**
     * Auto generated setter method
     * @param param ODBPREMSMS
     */
    public void setODBPREMSMS(com.huawei.www.hss._EnumType param) {
        localODBPREMSMSTracker = param != null;

        this.localODBPREMSMS = param;
    }

    public boolean isODBADULTSMSSpecified() {
        return localODBADULTSMSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getODBADULTSMS() {
        return localODBADULTSMS;
    }

    /**
     * Auto generated setter method
     * @param param ODBADULTSMS
     */
    public void setODBADULTSMS(com.huawei.www.hss._EnumType param) {
        localODBADULTSMSTracker = param != null;

        this.localODBADULTSMS = param;
    }

    public boolean isBOSKSpecified() {
        return localBOSKTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_999
     */
    public com.huawei.www.hss.Int1_999 getBOSK() {
        return localBOSK;
    }

    /**
     * Auto generated setter method
     * @param param BOSK
     */
    public void setBOSK(com.huawei.www.hss.Int1_999 param) {
        localBOSKTracker = param != null;

        this.localBOSK = param;
    }

    public boolean isZCLOCKPROVSpecified() {
        return localZCLOCKPROVTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getZCLOCKPROV() {
        return localZCLOCKPROV;
    }

    /**
     * Auto generated setter method
     * @param param ZCLOCKPROV
     */
    public void setZCLOCKPROV(com.huawei.www.hss._EnumType param) {
        localZCLOCKPROVTracker = param != null;

        this.localZCLOCKPROV = param;
    }

    public boolean isPSUSERTPLIDSpecified() {
        return localPSUSERTPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getPSUSERTPLID() {
        return localPSUSERTPLID;
    }

    /**
     * Auto generated setter method
     * @param param PSUSERTPLID
     */
    public void setPSUSERTPLID(com.huawei.www.hss.Int0_65534 param) {
        localPSUSERTPLIDTracker = param != null;

        this.localPSUSERTPLID = param;
    }

    public boolean isPSAPNOITPLIDSpecified() {
        return localPSAPNOITPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getPSAPNOITPLID() {
        return localPSAPNOITPLID;
    }

    /**
     * Auto generated setter method
     * @param param PSAPNOITPLID
     */
    public void setPSAPNOITPLID(com.huawei.www.hss.Int0_65534 param) {
        localPSAPNOITPLIDTracker = param != null;

        this.localPSAPNOITPLID = param;
    }

    public boolean isM2MCISDNSpecified() {
        return localM2MCISDNTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getM2MCISDN() {
        return localM2MCISDN;
    }

    /**
     * Auto generated setter method
     * @param param M2MCISDN
     */
    public void setM2MCISDN(com.huawei.www.hss.Str1_15 param) {
        localM2MCISDNTracker = param != null;

        this.localM2MCISDN = param;
    }

    public boolean isMAPADDRRESTPLIDSpecified() {
        return localMAPADDRRESTPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getMAPADDRRESTPLID() {
        return localMAPADDRRESTPLID;
    }

    /**
     * Auto generated setter method
     * @param param MAPADDRRESTPLID
     */
    public void setMAPADDRRESTPLID(com.huawei.www.hss.Int0_65534 param) {
        localMAPADDRRESTPLIDTracker = param != null;

        this.localMAPADDRRESTPLID = param;
    }

    public boolean isETCSICONVER_TPLIDSpecified() {
        return localETCSICONVER_TPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getETCSICONVER_TPLID() {
        return localETCSICONVER_TPLID;
    }

    /**
     * Auto generated setter method
     * @param param ETCSICONVER_TPLID
     */
    public void setETCSICONVER_TPLID(com.huawei.www.hss.Int0_65534 param) {
        localETCSICONVER_TPLIDTracker = param != null;

        this.localETCSICONVER_TPLID = param;
    }

    public boolean isDNDSpecified() {
        return localDNDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getDND() {
        return localDND;
    }

    /**
     * Auto generated setter method
     * @param param DND
     */
    public void setDND(com.huawei.www.hss._EnumType param) {
        localDNDTracker = param != null;

        this.localDND = param;
    }

    public boolean isVMCCSpecified() {
        return localVMCCTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getVMCC() {
        return localVMCC;
    }

    /**
     * Auto generated setter method
     * @param param VMCC
     */
    public void setVMCC(com.huawei.www.hss._EnumType param) {
        localVMCCTracker = param != null;

        this.localVMCC = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, MY_QNAME));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":ADD_CSPSSUB", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "ADD_CSPSSUB", xmlWriter);
            }
        }

        if (localHLRSN == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "HLRSN cannot be null!!");
        }

        localHLRSN.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "HLRSN"), xmlWriter);

        if (localIMSITracker) {
            if (localIMSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMSI cannot be null!!");
            }

            localIMSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMSI"), xmlWriter);
        }

        if (localISDNTracker) {
            if (localISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ISDN cannot be null!!");
            }

            localISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ISDN"), xmlWriter);
        }

        if (localNAMTracker) {
            if (localNAM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "NAM cannot be null!!");
            }

            localNAM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "NAM"), xmlWriter);
        }

        if (localCATEGORYTracker) {
            if (localCATEGORY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CATEGORY cannot be null!!");
            }

            localCATEGORY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CATEGORY"), xmlWriter);
        }

        if (localDEFAULTCALLTracker) {
            if (localDEFAULTCALL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DEFAULTCALL cannot be null!!");
            }

            localDEFAULTCALL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DEFAULTCALL"), xmlWriter);
        }

        if (localTSTracker) {
            if (localTS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TS cannot be null!!");
            }

            localTS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TS"), xmlWriter);
        }

        if (localBSTracker) {
            if (localBS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BS cannot be null!!");
            }

            localBS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BS"), xmlWriter);
        }

        if (localCFUTracker) {
            if (localCFU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFU cannot be null!!");
            }

            localCFU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFU"), xmlWriter);
        }

        if (localCFUOFAIDTracker) {
            if (localCFUOFAID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFUOFAID cannot be null!!");
            }

            localCFUOFAID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFUOFAID"), xmlWriter);
        }

        if (localCFUNCS == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CFUNCS cannot be null!!");
        }

        localCFUNCS.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CFUNCS"), xmlWriter);

        if (localCFUCOU == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CFUCOU cannot be null!!");
        }

        localCFUCOU.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CFUCOU"), xmlWriter);

        if (localCFBTracker) {
            if (localCFB == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFB cannot be null!!");
            }

            localCFB.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFB"), xmlWriter);
        }

        if (localCFBOFAIDTracker) {
            if (localCFBOFAID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFBOFAID cannot be null!!");
            }

            localCFBOFAID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFBOFAID"), xmlWriter);
        }

        if (localCFBNFS == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CFBNFS cannot be null!!");
        }

        localCFBNFS.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CFBNFS"), xmlWriter);

        if (localCFBNCS == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CFBNCS cannot be null!!");
        }

        localCFBNCS.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CFBNCS"), xmlWriter);

        if (localCFBCOU == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CFBCOU cannot be null!!");
        }

        localCFBCOU.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CFBCOU"), xmlWriter);

        if (localCFNRYTracker) {
            if (localCFNRY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRY cannot be null!!");
            }

            localCFNRY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRY"), xmlWriter);
        }

        if (localCFNRYOFAIDTracker) {
            if (localCFNRYOFAID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRYOFAID cannot be null!!");
            }

            localCFNRYOFAID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRYOFAID"), xmlWriter);
        }

        if (localCFNRYNFS == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CFNRYNFS cannot be null!!");
        }

        localCFNRYNFS.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CFNRYNFS"), xmlWriter);

        if (localCFNRYNCS == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CFNRYNCS cannot be null!!");
        }

        localCFNRYNCS.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CFNRYNCS"), xmlWriter);

        if (localCFNRYCOU == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CFNRYCOU cannot be null!!");
        }

        localCFNRYCOU.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CFNRYCOU"), xmlWriter);

        if (localCFNRCTracker) {
            if (localCFNRC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRC cannot be null!!");
            }

            localCFNRC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRC"), xmlWriter);
        }

        if (localCFNRCOFAIDTracker) {
            if (localCFNRCOFAID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFNRCOFAID cannot be null!!");
            }

            localCFNRCOFAID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFNRCOFAID"), xmlWriter);
        }

        if (localCFNRCNCS == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CFNRCNCS cannot be null!!");
        }

        localCFNRCNCS.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CFNRCNCS"), xmlWriter);

        if (localCFNRCOU == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CFNRCOU cannot be null!!");
        }

        localCFNRCOU.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CFNRCOU"), xmlWriter);

        if (localCFDTracker) {
            if (localCFD == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFD cannot be null!!");
            }

            localCFD.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFD"), xmlWriter);
        }

        if (localVALIDCCFTracker) {
            if (localVALIDCCF == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VALIDCCF cannot be null!!");
            }

            localVALIDCCF.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VALIDCCF"), xmlWriter);
        }

        if (localSUPINTERCFDTracker) {
            if (localSUPINTERCFD == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SUPINTERCFD cannot be null!!");
            }

            localSUPINTERCFD.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SUPINTERCFD"), xmlWriter);
        }

        if (localCFDNFS == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CFDNFS cannot be null!!");
        }

        localCFDNFS.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CFDNFS"), xmlWriter);

        if (localCFDNCS == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CFDNCS cannot be null!!");
        }

        localCFDNCS.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CFDNCS"), xmlWriter);

        if (localCFDFTN == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CFDFTN cannot be null!!");
        }

        localCFDFTN.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CFDFTN"), xmlWriter);

        if (localCFDBSGTracker) {
            if (localCFDBSG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFDBSG cannot be null!!");
            }

            localCFDBSG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFDBSG"), xmlWriter);
        }

        if (localCFDNRTIMETracker) {
            if (localCFDNRTIME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CFDNRTIME cannot be null!!");
            }

            localCFDNRTIME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CFDNRTIME"), xmlWriter);
        }

        if (localCBTracker) {
            if (localCB == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CB cannot be null!!");
            }

            localCB.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CB"), xmlWriter);
        }

        if (localCBCOUTracker) {
            if (localCBCOU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CBCOU cannot be null!!");
            }

            localCBCOU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CBCOU"), xmlWriter);
        }

        if (localCLIPTracker) {
            if (localCLIP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CLIP cannot be null!!");
            }

            localCLIP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CLIP"), xmlWriter);
        }

        if (localCNAPTracker) {
            if (localCNAP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CNAP cannot be null!!");
            }

            localCNAP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CNAP"), xmlWriter);
        }

        if (localCLIPOR == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CLIPOR cannot be null!!");
        }

        localCLIPOR.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CLIPOR"), xmlWriter);

        if (localBSGCLIPTracker) {
            if (localBSGCLIP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSGCLIP cannot be null!!");
            }

            localBSGCLIP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSGCLIP"), xmlWriter);
        }

        if (localCLIRTracker) {
            if (localCLIR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CLIR cannot be null!!");
            }

            localCLIR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CLIR"), xmlWriter);
        }

        if (localCLIRMODE == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "CLIRMODE cannot be null!!");
        }

        localCLIRMODE.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "CLIRMODE"), xmlWriter);

        if (localBSGCLIRTracker) {
            if (localBSGCLIR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSGCLIR cannot be null!!");
            }

            localBSGCLIR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSGCLIR"), xmlWriter);
        }

        if (localCOLPTracker) {
            if (localCOLP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "COLP cannot be null!!");
            }

            localCOLP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "COLP"), xmlWriter);
        }

        if (localCOLPOR == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "COLPOR cannot be null!!");
        }

        localCOLPOR.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "COLPOR"), xmlWriter);

        if (localBSGCOLPTracker) {
            if (localBSGCOLP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSGCOLP cannot be null!!");
            }

            localBSGCOLP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSGCOLP"), xmlWriter);
        }

        if (localCOLRTracker) {
            if (localCOLR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "COLR cannot be null!!");
            }

            localCOLR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "COLR"), xmlWriter);
        }

        if (localBSGCOLRTracker) {
            if (localBSGCOLR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BSGCOLR cannot be null!!");
            }

            localBSGCOLR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BSGCOLR"), xmlWriter);
        }

        if (localECTTracker) {
            if (localECT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ECT cannot be null!!");
            }

            localECT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ECT"), xmlWriter);
        }

        if (localCWTracker) {
            if (localCW == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CW cannot be null!!");
            }

            localCW.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CW"), xmlWriter);
        }

        if (localHOLDTracker) {
            if (localHOLD == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "HOLD cannot be null!!");
            }

            localHOLD.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "HOLD"), xmlWriter);
        }

        if (localMPTYTracker) {
            if (localMPTY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MPTY cannot be null!!");
            }

            localMPTY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MPTY"), xmlWriter);
        }

        if (localAOCTracker) {
            if (localAOC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AOC cannot be null!!");
            }

            localAOC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AOC"), xmlWriter);
        }

        if (localPLMNSPECSSTracker) {
            if (localPLMNSPECSS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PLMNSPECSS cannot be null!!");
            }

            localPLMNSPECSS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PLMNSPECSS"), xmlWriter);
        }

        if (localODBSSTracker) {
            if (localODBSS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBSS cannot be null!!");
            }

            localODBSS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBSS"), xmlWriter);
        }

        if (localODBOCTracker) {
            if (localODBOC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBOC cannot be null!!");
            }

            localODBOC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBOC"), xmlWriter);
        }

        if (localODBICTracker) {
            if (localODBIC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBIC cannot be null!!");
            }

            localODBIC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBIC"), xmlWriter);
        }

        if (localODBROAMTracker) {
            if (localODBROAM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBROAM cannot be null!!");
            }

            localODBROAM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBROAM"), xmlWriter);
        }

        if (localODBENTETracker) {
            if (localODBENTE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBENTE cannot be null!!");
            }

            localODBENTE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBENTE"), xmlWriter);
        }

        if (localODBINFOTracker) {
            if (localODBINFO == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBINFO cannot be null!!");
            }

            localODBINFO.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBINFO"), xmlWriter);
        }

        if (localODBRCFTracker) {
            if (localODBRCF == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBRCF cannot be null!!");
            }

            localODBRCF.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBRCF"), xmlWriter);
        }

        if (localODBECTTracker) {
            if (localODBECT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBECT cannot be null!!");
            }

            localODBECT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBECT"), xmlWriter);
        }

        if (localODBDECTTracker) {
            if (localODBDECT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBDECT cannot be null!!");
            }

            localODBDECT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBDECT"), xmlWriter);
        }

        if (localODBMECTTracker) {
            if (localODBMECT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBMECT cannot be null!!");
            }

            localODBMECT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBMECT"), xmlWriter);
        }

        if (localODBPLMNTracker) {
            if (localODBPLMN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBPLMN cannot be null!!");
            }

            localODBPLMN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBPLMN"), xmlWriter);
        }

        if (localODBPOSTracker) {
            if (localODBPOS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBPOS cannot be null!!");
            }

            localODBPOS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBPOS"), xmlWriter);
        }

        if (localODBPOSTYPETracker) {
            if (localODBPOSTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBPOSTYPE cannot be null!!");
            }

            localODBPOSTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBPOSTYPE"), xmlWriter);
        }

        if (localOCSITracker) {
            if (localOCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "OCSI cannot be null!!");
            }

            localOCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "OCSI"), xmlWriter);
        }

        if (localTCSITracker) {
            if (localTCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TCSI cannot be null!!");
            }

            localTCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TCSI"), xmlWriter);
        }

        if (localSMSCSITracker) {
            if (localSMSCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SMSCSI cannot be null!!");
            }

            localSMSCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SMSCSI"), xmlWriter);
        }

        if (localMTSMSCSITracker) {
            if (localMTSMSCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MTSMSCSI cannot be null!!");
            }

            localMTSMSCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MTSMSCSI"), xmlWriter);
        }

        if (localDCSITracker) {
            if (localDCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DCSI cannot be null!!");
            }

            localDCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DCSI"), xmlWriter);
        }

        if (localVTCSITracker) {
            if (localVTCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VTCSI cannot be null!!");
            }

            localVTCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VTCSI"), xmlWriter);
        }

        if (localMCSITracker) {
            if (localMCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MCSI cannot be null!!");
            }

            localMCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MCSI"), xmlWriter);
        }

        if (localSSCSITracker) {
            if (localSSCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SSCSI cannot be null!!");
            }

            localSSCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SSCSI"), xmlWriter);
        }

        if (localTIFCSITracker) {
            if (localTIFCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TIFCSI cannot be null!!");
            }

            localTIFCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TIFCSI"), xmlWriter);
        }

        if (localUCSITracker) {
            if (localUCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UCSI cannot be null!!");
            }

            localUCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UCSI"), xmlWriter);
        }

        if (localGPRSCSITracker) {
            if (localGPRSCSI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GPRSCSI cannot be null!!");
            }

            localGPRSCSI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GPRSCSI"), xmlWriter);
        }

        if (localLCSTracker) {
            if (localLCS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LCS cannot be null!!");
            }

            localLCS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LCS"), xmlWriter);
        }

        if (localGPRSTPLTracker) {
            if (localGPRSTPL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GPRSTPL cannot be null!!");
            }

            localGPRSTPL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GPRSTPL"), xmlWriter);
        }

        if (localVLRLISTTracker) {
            if (localVLRLIST == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VLRLIST cannot be null!!");
            }

            localVLRLIST.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VLRLIST"), xmlWriter);
        }

        if (localSGSNLISTTracker) {
            if (localSGSNLIST == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SGSNLIST cannot be null!!");
            }

            localSGSNLIST.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SGSNLIST"), xmlWriter);
        }

        if (localSMDPTracker) {
            if (localSMDP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SMDP cannot be null!!");
            }

            localSMDP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SMDP"), xmlWriter);
        }

        if (localNAEA_CICTracker) {
            if (localNAEA_CIC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "NAEA_CIC cannot be null!!");
            }

            localNAEA_CIC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "NAEA_CIC"), xmlWriter);
        }

        if (localNLRINDTracker) {
            if (localNLRIND == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "NLRIND cannot be null!!");
            }

            localNLRIND.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "NLRIND"), xmlWriter);
        }

        if (localLINE2NUMTracker) {
            if (localLINE2NUM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LINE2NUM cannot be null!!");
            }

            localLINE2NUM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LINE2NUM"), xmlWriter);
        }

        if (localVVDNTracker) {
            if (localVVDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VVDN cannot be null!!");
            }

            localVVDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VVDN"), xmlWriter);
        }

        if (localRBTTracker) {
            if (localRBT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RBT cannot be null!!");
            }

            localRBT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RBT"), xmlWriter);
        }

        if (localUTRANNOTALLOWEDTracker) {
            if (localUTRANNOTALLOWED == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UTRANNOTALLOWED cannot be null!!");
            }

            localUTRANNOTALLOWED.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UTRANNOTALLOWED"), xmlWriter);
        }

        if (localGERANNOTALLOWEDTracker) {
            if (localGERANNOTALLOWED == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GERANNOTALLOWED cannot be null!!");
            }

            localGERANNOTALLOWED.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GERANNOTALLOWED"), xmlWriter);
        }

        if (localCARPTracker) {
            if (localCARP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CARP cannot be null!!");
            }

            localCARP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CARP"), xmlWriter);
        }

        if (localRROPTIONTracker) {
            if (localRROPTION == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RROPTION cannot be null!!");
            }

            localRROPTION.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RROPTION"), xmlWriter);
        }

        if (localRRTPL == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "RRTPL cannot be null!!");
        }

        localRRTPL.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "RRTPL"), xmlWriter);

        if (localVBSTracker) {
            if (localVBS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VBS cannot be null!!");
            }

            localVBS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VBS"), xmlWriter);
        }

        if (localVGCSTracker) {
            if (localVGCS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VGCS cannot be null!!");
            }

            localVGCS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VGCS"), xmlWriter);
        }

        if (localEMLPP_MAXTracker) {
            if (localEMLPP_MAX == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EMLPP_MAX cannot be null!!");
            }

            localEMLPP_MAX.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EMLPP_MAX"), xmlWriter);
        }

        if (localEMLPP_DEFTracker) {
            if (localEMLPP_DEF == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EMLPP_DEF cannot be null!!");
            }

            localEMLPP_DEF.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EMLPP_DEF"), xmlWriter);
        }

        if (localEMLPP_COUTracker) {
            if (localEMLPP_COU == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EMLPP_COU cannot be null!!");
            }

            localEMLPP_COU.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EMLPP_COU"), xmlWriter);
        }

        if (localECATEGORYTracker) {
            if (localECATEGORY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ECATEGORY cannot be null!!");
            }

            localECATEGORY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ECATEGORY"), xmlWriter);
        }

        if (localUUSTracker) {
            if (localUUS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "UUS cannot be null!!");
            }

            localUUS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "UUS"), xmlWriter);
        }

        if (localSMSCFTracker) {
            if (localSMSCF == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SMSCF cannot be null!!");
            }

            localSMSCF.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SMSCF"), xmlWriter);
        }

        if (localSMSCFOFAIDTracker) {
            if (localSMSCFOFAID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SMSCFOFAID cannot be null!!");
            }

            localSMSCFOFAID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SMSCFOFAID"), xmlWriter);
        }

        if (localMCTracker) {
            if (localMC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MC cannot be null!!");
            }

            localMC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MC"), xmlWriter);
        }

        if (localNBRSB == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "NBRSB cannot be null!!");
        }

        localNBRSB.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "NBRSB"), xmlWriter);

        if (localNBRUSER == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "NBRUSER cannot be null!!");
        }

        localNBRUSER.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "NBRUSER"), xmlWriter);

        if (localISTTracker) {
            if (localIST == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IST cannot be null!!");
            }

            localIST.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IST"), xmlWriter);
        }

        if (localISTTIMER == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "ISTTIMER cannot be null!!");
        }

        localISTTIMER.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "ISTTIMER"), xmlWriter);

        if (localISTRSP == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "ISTRSP cannot be null!!");
        }

        localISTRSP.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "ISTRSP"), xmlWriter);

        if (localOPTGPRSTPLIDTracker) {
            if (localOPTGPRSTPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "OPTGPRSTPLID cannot be null!!");
            }

            localOPTGPRSTPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "OPTGPRSTPLID"), xmlWriter);
        }

        if (localCHARGE_GLOBALTracker) {
            if (localCHARGE_GLOBAL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CHARGE_GLOBAL cannot be null!!");
            }

            localCHARGE_GLOBAL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CHARGE_GLOBAL"), xmlWriter);
        }

        if (localDICLENGTHTracker) {
            if (localDICLENGTH == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DICLENGTH cannot be null!!");
            }

            localDICLENGTH.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DICLENGTH"), xmlWriter);
        }

        if (localROUTECATEGORYTracker) {
            if (localROUTECATEGORY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ROUTECATEGORY cannot be null!!");
            }

            localROUTECATEGORY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ROUTECATEGORY"), xmlWriter);
        }

        if (localEXEXROUTECATEGORYTracker) {
            if (localEXEXROUTECATEGORY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EXEXROUTECATEGORY cannot be null!!");
            }

            localEXEXROUTECATEGORY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EXEXROUTECATEGORY"), xmlWriter);
        }

        if (localCALLREDIRECTTracker) {
            if (localCALLREDIRECT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CALLREDIRECT cannot be null!!");
            }

            localCALLREDIRECT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CALLREDIRECT"), xmlWriter);
        }

        if (localNRBTTracker) {
            if (localNRBT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "NRBT cannot be null!!");
            }

            localNRBT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "NRBT"), xmlWriter);
        }

        if (localOSKTracker) {
            if (localOSK == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "OSK cannot be null!!");
            }

            localOSK.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "OSK"), xmlWriter);
        }

        if (localTSKTracker) {
            if (localTSK == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TSK cannot be null!!");
            }

            localTSK.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TSK"), xmlWriter);
        }

        if (localMERBTTracker) {
            if (localMERBT == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MERBT cannot be null!!");
            }

            localMERBT.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MERBT"), xmlWriter);
        }

        if (localNIRPROVTracker) {
            if (localNIRPROV == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "NIRPROV cannot be null!!");
            }

            localNIRPROV.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "NIRPROV"), xmlWriter);
        }

        if (localNIRINDEX == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "NIRINDEX cannot be null!!");
        }

        localNIRINDEX.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "NIRINDEX"), xmlWriter);

        if (localRZONETracker) {
            if (localRZONE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "RZONE cannot be null!!");
            }

            localRZONE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "RZONE"), xmlWriter);
        }

        if (localCCBSTracker) {
            if (localCCBS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CCBS cannot be null!!");
            }

            localCCBS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CCBS"), xmlWriter);
        }

        if (localCCBSTARGETTracker) {
            if (localCCBSTARGET == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CCBSTARGET cannot be null!!");
            }

            localCCBSTARGET.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CCBSTARGET"), xmlWriter);
        }

        if (localACR_STATUSTracker) {
            if (localACR_STATUS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ACR_STATUS cannot be null!!");
            }

            localACR_STATUS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ACR_STATUS"), xmlWriter);
        }

        if (localSMSROUTETPLTracker) {
            if (localSMSROUTETPL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SMSROUTETPL cannot be null!!");
            }

            localSMSROUTETPL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SMSROUTETPL"), xmlWriter);
        }

        if (localSUPSHORTNUMTracker) {
            if (localSUPSHORTNUM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SUPSHORTNUM cannot be null!!");
            }

            localSUPSHORTNUM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SUPSHORTNUM"), xmlWriter);
        }

        if (localACTCFDTracker) {
            if (localACTCFD == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ACTCFD cannot be null!!");
            }

            localACTCFD.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ACTCFD"), xmlWriter);
        }

        if (localSMSINPROVTracker) {
            if (localSMSINPROV == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SMSINPROV cannot be null!!");
            }

            localSMSINPROV.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SMSINPROV"), xmlWriter);
        }

        if (localSCPADDTracker) {
            if (localSCPADD == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SCPADD cannot be null!!");
            }

            localSCPADD.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SCPADD"), xmlWriter);
        }

        if (localSKEYTracker) {
            if (localSKEY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SKEY cannot be null!!");
            }

            localSKEY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SKEY"), xmlWriter);
        }

        if (localDPTracker) {
            if (localDP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DP cannot be null!!");
            }

            localDP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DP"), xmlWriter);
        }

        if (localTAMMTracker) {
            if (localTAMM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TAMM cannot be null!!");
            }

            localTAMM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TAMM"), xmlWriter);
        }

        if (localDEFAULTOFA_IDTracker) {
            if (localDEFAULTOFA_ID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DEFAULTOFA_ID cannot be null!!");
            }

            localDEFAULTOFA_ID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DEFAULTOFA_ID"), xmlWriter);
        }

        if (localGANNOTALLOWEDTracker) {
            if (localGANNOTALLOWED == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "GANNOTALLOWED cannot be null!!");
            }

            localGANNOTALLOWED.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "GANNOTALLOWED"), xmlWriter);
        }

        if (localIHSPAENOTALLOWEDTracker) {
            if (localIHSPAENOTALLOWED == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IHSPAENOTALLOWED cannot be null!!");
            }

            localIHSPAENOTALLOWED.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IHSPAENOTALLOWED"), xmlWriter);
        }

        if (localEUTRANNOTALLOWEDTracker) {
            if (localEUTRANNOTALLOWED == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "EUTRANNOTALLOWED cannot be null!!");
            }

            localEUTRANNOTALLOWED.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "EUTRANNOTALLOWED"), xmlWriter);
        }

        if (localN3GPPNOTALLOWEDTracker) {
            if (localN3GPPNOTALLOWED == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "N3GPPNOTALLOWED cannot be null!!");
            }

            localN3GPPNOTALLOWED.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "N3GPPNOTALLOWED"), xmlWriter);
        }

        if (localSCHARGE_GLOBALTracker) {
            if (localSCHARGE_GLOBAL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SCHARGE_GLOBAL cannot be null!!");
            }

            localSCHARGE_GLOBAL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SCHARGE_GLOBAL"), xmlWriter);
        }

        if (localCPPTracker) {
            if (localCPP == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CPP cannot be null!!");
            }

            localCPP.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CPP"), xmlWriter);
        }

        if (localECATOPTIONTracker) {
            if (localECATOPTION == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ECATOPTION cannot be null!!");
            }

            localECATOPTION.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ECATOPTION"), xmlWriter);
        }

        if (localELCSTracker) {
            if (localELCS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ELCS cannot be null!!");
            }

            localELCS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ELCS"), xmlWriter);
        }

        if (localFRAUDTPLIDTracker) {
            if (localFRAUDTPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "FRAUDTPLID cannot be null!!");
            }

            localFRAUDTPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "FRAUDTPLID"), xmlWriter);
        }

        if (localIMEILCKPROVTracker) {
            if (localIMEILCKPROV == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMEILCKPROV cannot be null!!");
            }

            localIMEILCKPROV.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMEILCKPROV"), xmlWriter);
        }

        if (localIMSIIMEIBINDTracker) {
            if (localIMSIIMEIBIND == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMSIIMEIBIND cannot be null!!");
            }

            localIMSIIMEIBIND.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMSIIMEIBIND"), xmlWriter);
        }

        if (localM2MNOTIFYTracker) {
            if (localM2MNOTIFY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M2MNOTIFY cannot be null!!");
            }

            localM2MNOTIFY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "M2MNOTIFY"), xmlWriter);
        }

        if (localLUCSI_TPL_IDTracker) {
            if (localLUCSI_TPL_ID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LUCSI_TPL_ID cannot be null!!");
            }

            localLUCSI_TPL_ID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LUCSI_TPL_ID"), xmlWriter);
        }

        if (localSHORTNUMTPLTracker) {
            if (localSHORTNUMTPL == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SHORTNUMTPL cannot be null!!");
            }

            localSHORTNUMTPL.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SHORTNUMTPL"), xmlWriter);
        }

        if (localUSERCATEGORYTracker) {
            if (localUSERCATEGORY == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "USERCATEGORY cannot be null!!");
            }

            localUSERCATEGORY.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "USERCATEGORY"), xmlWriter);
        }

        if (localODBPREMSMSTracker) {
            if (localODBPREMSMS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBPREMSMS cannot be null!!");
            }

            localODBPREMSMS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBPREMSMS"), xmlWriter);
        }

        if (localODBADULTSMSTracker) {
            if (localODBADULTSMS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ODBADULTSMS cannot be null!!");
            }

            localODBADULTSMS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ODBADULTSMS"), xmlWriter);
        }

        if (localBOSKTracker) {
            if (localBOSK == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BOSK cannot be null!!");
            }

            localBOSK.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BOSK"), xmlWriter);
        }

        if (localZCLOCKPROVTracker) {
            if (localZCLOCKPROV == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ZCLOCKPROV cannot be null!!");
            }

            localZCLOCKPROV.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ZCLOCKPROV"), xmlWriter);
        }

        if (localPSUSERTPLIDTracker) {
            if (localPSUSERTPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PSUSERTPLID cannot be null!!");
            }

            localPSUSERTPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PSUSERTPLID"), xmlWriter);
        }

        if (localPSAPNOITPLIDTracker) {
            if (localPSAPNOITPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PSAPNOITPLID cannot be null!!");
            }

            localPSAPNOITPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PSAPNOITPLID"), xmlWriter);
        }

        if (localM2MCISDNTracker) {
            if (localM2MCISDN == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "M2MCISDN cannot be null!!");
            }

            localM2MCISDN.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "M2MCISDN"), xmlWriter);
        }

        if (localMAPADDRRESTPLIDTracker) {
            if (localMAPADDRRESTPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "MAPADDRRESTPLID cannot be null!!");
            }

            localMAPADDRRESTPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "MAPADDRRESTPLID"), xmlWriter);
        }

        if (localETCSICONVER_TPLIDTracker) {
            if (localETCSICONVER_TPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ETCSICONVER_TPLID cannot be null!!");
            }

            localETCSICONVER_TPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ETCSICONVER_TPLID"), xmlWriter);
        }

        if (localDNDTracker) {
            if (localDND == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "DND cannot be null!!");
            }

            localDND.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "DND"), xmlWriter);
        }

        if (localVMCCTracker) {
            if (localVMCC == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VMCC cannot be null!!");
            }

            localVMCC.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VMCC"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static ADD_CSPSSUB parse(javax.xml.stream.XMLStreamReader reader)
            throws java.lang.Exception {
            ADD_CSPSSUB object = new ADD_CSPSSUB();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"ADD_CSPSSUB".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (ADD_CSPSSUB) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "HLRSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "HLRSN").equals(
                            reader.getName())) {
                    object.setHLRSN(com.huawei.www.hss.Int1_255.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSI").equals(
                            reader.getName())) {
                    object.setIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ISDN").equals(
                            reader.getName())) {
                    object.setISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "NAM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "NAM").equals(
                            reader.getName())) {
                    object.setNAM(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CATEGORY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CATEGORY").equals(
                            reader.getName())) {
                    object.setCATEGORY(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DEFAULTCALL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DEFAULTCALL").equals(
                            reader.getName())) {
                    object.setDEFAULTCALL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TS").equals(
                            reader.getName())) {
                    object.setTS(com.huawei.www.hss.Str0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BS").equals(
                            reader.getName())) {
                    object.setBS(com.huawei.www.hss.Str0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFU").equals(
                            reader.getName())) {
                    object.setCFU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFUOFAID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFUOFAID").equals(
                            reader.getName())) {
                    object.setCFUOFAID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFUNCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFUNCS").equals(
                            reader.getName())) {
                    object.setCFUNCS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFUCOU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFUCOU").equals(
                            reader.getName())) {
                    object.setCFUCOU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFB").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFB").equals(
                            reader.getName())) {
                    object.setCFB(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFBOFAID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFBOFAID").equals(
                            reader.getName())) {
                    object.setCFBOFAID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFBNFS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFBNFS").equals(
                            reader.getName())) {
                    object.setCFBNFS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFBNCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFBNCS").equals(
                            reader.getName())) {
                    object.setCFBNCS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFBCOU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFBCOU").equals(
                            reader.getName())) {
                    object.setCFBCOU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRY").equals(
                            reader.getName())) {
                    object.setCFNRY(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRYOFAID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRYOFAID").equals(
                            reader.getName())) {
                    object.setCFNRYOFAID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRYNFS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRYNFS").equals(
                            reader.getName())) {
                    object.setCFNRYNFS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRYNCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRYNCS").equals(
                            reader.getName())) {
                    object.setCFNRYNCS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRYCOU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRYCOU").equals(
                            reader.getName())) {
                    object.setCFNRYCOU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRC").equals(
                            reader.getName())) {
                    object.setCFNRC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRCOFAID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRCOFAID").equals(
                            reader.getName())) {
                    object.setCFNRCOFAID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRCNCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRCNCS").equals(
                            reader.getName())) {
                    object.setCFNRCNCS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFNRCOU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFNRCOU").equals(
                            reader.getName())) {
                    object.setCFNRCOU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFD").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFD").equals(
                            reader.getName())) {
                    object.setCFD(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VALIDCCF").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VALIDCCF").equals(
                            reader.getName())) {
                    object.setVALIDCCF(com.huawei.www.hss.Str0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SUPINTERCFD").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SUPINTERCFD").equals(
                            reader.getName())) {
                    object.setSUPINTERCFD(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFDNFS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFDNFS").equals(
                            reader.getName())) {
                    object.setCFDNFS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFDNCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFDNCS").equals(
                            reader.getName())) {
                    object.setCFDNCS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFDFTN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFDFTN").equals(
                            reader.getName())) {
                    object.setCFDFTN(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFDBSG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFDBSG").equals(
                            reader.getName())) {
                    object.setCFDBSG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CFDNRTIME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CFDNRTIME").equals(
                            reader.getName())) {
                    object.setCFDNRTIME(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CB").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CB").equals(
                            reader.getName())) {
                    object.setCB(com.huawei.www.hss.Str0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CBCOU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CBCOU").equals(
                            reader.getName())) {
                    object.setCBCOU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CLIP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CLIP").equals(
                            reader.getName())) {
                    object.setCLIP(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CNAP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CNAP").equals(
                            reader.getName())) {
                    object.setCNAP(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CLIPOR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CLIPOR").equals(
                            reader.getName())) {
                    object.setCLIPOR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSGCLIP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSGCLIP").equals(
                            reader.getName())) {
                    object.setBSGCLIP(com.huawei.www.hss.Str0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CLIR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CLIR").equals(
                            reader.getName())) {
                    object.setCLIR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CLIRMODE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CLIRMODE").equals(
                            reader.getName())) {
                    object.setCLIRMODE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSGCLIR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSGCLIR").equals(
                            reader.getName())) {
                    object.setBSGCLIR(com.huawei.www.hss.Str0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "COLP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "COLP").equals(
                            reader.getName())) {
                    object.setCOLP(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "COLPOR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "COLPOR").equals(
                            reader.getName())) {
                    object.setCOLPOR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSGCOLP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSGCOLP").equals(
                            reader.getName())) {
                    object.setBSGCOLP(com.huawei.www.hss.Str0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "COLR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "COLR").equals(
                            reader.getName())) {
                    object.setCOLR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BSGCOLR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BSGCOLR").equals(
                            reader.getName())) {
                    object.setBSGCOLR(com.huawei.www.hss.Str0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ECT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ECT").equals(
                            reader.getName())) {
                    object.setECT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CW").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CW").equals(
                            reader.getName())) {
                    object.setCW(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "HOLD").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "HOLD").equals(
                            reader.getName())) {
                    object.setHOLD(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MPTY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MPTY").equals(
                            reader.getName())) {
                    object.setMPTY(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AOC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AOC").equals(
                            reader.getName())) {
                    object.setAOC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PLMNSPECSS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PLMNSPECSS").equals(
                            reader.getName())) {
                    object.setPLMNSPECSS(com.huawei.www.hss.Str0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBSS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBSS").equals(
                            reader.getName())) {
                    object.setODBSS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBOC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBOC").equals(
                            reader.getName())) {
                    object.setODBOC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBIC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBIC").equals(
                            reader.getName())) {
                    object.setODBIC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBROAM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBROAM").equals(
                            reader.getName())) {
                    object.setODBROAM(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBENTE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBENTE").equals(
                            reader.getName())) {
                    object.setODBENTE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBINFO").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBINFO").equals(
                            reader.getName())) {
                    object.setODBINFO(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBRCF").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBRCF").equals(
                            reader.getName())) {
                    object.setODBRCF(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBECT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBECT").equals(
                            reader.getName())) {
                    object.setODBECT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBDECT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBDECT").equals(
                            reader.getName())) {
                    object.setODBDECT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBMECT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBMECT").equals(
                            reader.getName())) {
                    object.setODBMECT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBPLMN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBPLMN").equals(
                            reader.getName())) {
                    object.setODBPLMN(com.huawei.www.hss.Str0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBPOS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBPOS").equals(
                            reader.getName())) {
                    object.setODBPOS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBPOSTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBPOSTYPE").equals(
                            reader.getName())) {
                    object.setODBPOSTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "OCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "OCSI").equals(
                            reader.getName())) {
                    object.setOCSI(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TCSI").equals(
                            reader.getName())) {
                    object.setTCSI(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SMSCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SMSCSI").equals(
                            reader.getName())) {
                    object.setSMSCSI(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MTSMSCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MTSMSCSI").equals(
                            reader.getName())) {
                    object.setMTSMSCSI(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DCSI").equals(
                            reader.getName())) {
                    object.setDCSI(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VTCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VTCSI").equals(
                            reader.getName())) {
                    object.setVTCSI(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MCSI").equals(
                            reader.getName())) {
                    object.setMCSI(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SSCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SSCSI").equals(
                            reader.getName())) {
                    object.setSSCSI(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TIFCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TIFCSI").equals(
                            reader.getName())) {
                    object.setTIFCSI(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UCSI").equals(
                            reader.getName())) {
                    object.setUCSI(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GPRSCSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GPRSCSI").equals(
                            reader.getName())) {
                    object.setGPRSCSI(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LCS").equals(
                            reader.getName())) {
                    object.setLCS(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GPRSTPL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GPRSTPL").equals(
                            reader.getName())) {
                    object.setGPRSTPL(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VLRLIST").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VLRLIST").equals(
                            reader.getName())) {
                    object.setVLRLIST(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SGSNLIST").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SGSNLIST").equals(
                            reader.getName())) {
                    object.setSGSNLIST(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SMDP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SMDP").equals(
                            reader.getName())) {
                    object.setSMDP(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "NAEA_CIC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "NAEA_CIC").equals(
                            reader.getName())) {
                    object.setNAEA_CIC(com.huawei.www.hss.Int0_9999.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "NLRIND").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "NLRIND").equals(
                            reader.getName())) {
                    object.setNLRIND(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LINE2NUM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LINE2NUM").equals(
                            reader.getName())) {
                    object.setLINE2NUM(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VVDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VVDN").equals(
                            reader.getName())) {
                    object.setVVDN(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RBT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RBT").equals(
                            reader.getName())) {
                    object.setRBT(com.huawei.www.hss.Int0_254.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UTRANNOTALLOWED").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UTRANNOTALLOWED").equals(
                            reader.getName())) {
                    object.setUTRANNOTALLOWED(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GERANNOTALLOWED").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GERANNOTALLOWED").equals(
                            reader.getName())) {
                    object.setGERANNOTALLOWED(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CARP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CARP").equals(
                            reader.getName())) {
                    object.setCARP(com.huawei.www.hss.Int1_255.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RROPTION").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RROPTION").equals(
                            reader.getName())) {
                    object.setRROPTION(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RRTPL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RRTPL").equals(
                            reader.getName())) {
                    object.setRRTPL(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VBS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VBS").equals(
                            reader.getName())) {
                    object.setVBS(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VGCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VGCS").equals(
                            reader.getName())) {
                    object.setVGCS(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EMLPP_MAX").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EMLPP_MAX").equals(
                            reader.getName())) {
                    object.setEMLPP_MAX(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EMLPP_DEF").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EMLPP_DEF").equals(
                            reader.getName())) {
                    object.setEMLPP_DEF(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EMLPP_COU").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EMLPP_COU").equals(
                            reader.getName())) {
                    object.setEMLPP_COU(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ECATEGORY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ECATEGORY").equals(
                            reader.getName())) {
                    object.setECATEGORY(com.huawei.www.hss.Int1_254.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "UUS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "UUS").equals(
                            reader.getName())) {
                    object.setUUS(com.huawei.www.hss.Str0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SMSCF").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SMSCF").equals(
                            reader.getName())) {
                    object.setSMSCF(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SMSCFOFAID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SMSCFOFAID").equals(
                            reader.getName())) {
                    object.setSMSCFOFAID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MC").equals(
                            reader.getName())) {
                    object.setMC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "NBRSB").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "NBRSB").equals(
                            reader.getName())) {
                    object.setNBRSB(com.huawei.www.hss.Int2_7.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "NBRUSER").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "NBRUSER").equals(
                            reader.getName())) {
                    object.setNBRUSER(com.huawei.www.hss.Int1_7.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IST").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IST").equals(
                            reader.getName())) {
                    object.setIST(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ISTTIMER").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ISTTIMER").equals(
                            reader.getName())) {
                    object.setISTTIMER(com.huawei.www.hss.Int15_255.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ISTRSP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ISTRSP").equals(
                            reader.getName())) {
                    object.setISTRSP(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "OPTGPRSTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "OPTGPRSTPLID").equals(
                            reader.getName())) {
                    object.setOPTGPRSTPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CHARGE_GLOBAL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CHARGE_GLOBAL").equals(
                            reader.getName())) {
                    object.setCHARGE_GLOBAL(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DICLENGTH").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DICLENGTH").equals(
                            reader.getName())) {
                    object.setDICLENGTH(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ROUTECATEGORY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ROUTECATEGORY").equals(
                            reader.getName())) {
                    object.setROUTECATEGORY(com.huawei.www.hss.Int1_255.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EXEXROUTECATEGORY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EXEXROUTECATEGORY").equals(
                            reader.getName())) {
                    object.setEXEXROUTECATEGORY(com.huawei.www.hss.Int1_2147483647.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CALLREDIRECT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CALLREDIRECT").equals(
                            reader.getName())) {
                    object.setCALLREDIRECT(com.huawei.www.hss.Int0_255.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "NRBT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "NRBT").equals(
                            reader.getName())) {
                    object.setNRBT(com.huawei.www.hss.Int1_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "OSK").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "OSK").equals(
                            reader.getName())) {
                    object.setOSK(com.huawei.www.hss.Int1_999.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TSK").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TSK").equals(
                            reader.getName())) {
                    object.setTSK(com.huawei.www.hss.Int1_999.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MERBT").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MERBT").equals(
                            reader.getName())) {
                    object.setMERBT(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "NIRPROV").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "NIRPROV").equals(
                            reader.getName())) {
                    object.setNIRPROV(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "NIRINDEX").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "NIRINDEX").equals(
                            reader.getName())) {
                    object.setNIRINDEX(com.huawei.www.hss.Int0_999.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "RZONE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "RZONE").equals(
                            reader.getName())) {
                    object.setRZONE(com.huawei.www.hss.Int0_9.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CCBS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CCBS").equals(
                            reader.getName())) {
                    object.setCCBS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CCBSTARGET").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CCBSTARGET").equals(
                            reader.getName())) {
                    object.setCCBSTARGET(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ACR_STATUS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ACR_STATUS").equals(
                            reader.getName())) {
                    object.setACR_STATUS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SMSROUTETPL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SMSROUTETPL").equals(
                            reader.getName())) {
                    object.setSMSROUTETPL(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SUPSHORTNUM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SUPSHORTNUM").equals(
                            reader.getName())) {
                    object.setSUPSHORTNUM(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ACTCFD").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ACTCFD").equals(
                            reader.getName())) {
                    object.setACTCFD(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SMSINPROV").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SMSINPROV").equals(
                            reader.getName())) {
                    object.setSMSINPROV(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SCPADD").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SCPADD").equals(
                            reader.getName())) {
                    object.setSCPADD(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SKEY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SKEY").equals(
                            reader.getName())) {
                    object.setSKEY(com.huawei.www.hss.Int0_2147483647.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DP").equals(
                            reader.getName())) {
                    object.setDP(com.huawei.www.hss.Str0_65535.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TAMM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TAMM").equals(
                            reader.getName())) {
                    object.setTAMM(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DEFAULTOFA_ID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DEFAULTOFA_ID").equals(
                            reader.getName())) {
                    object.setDEFAULTOFA_ID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "GANNOTALLOWED").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "GANNOTALLOWED").equals(
                            reader.getName())) {
                    object.setGANNOTALLOWED(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IHSPAENOTALLOWED").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IHSPAENOTALLOWED").equals(
                            reader.getName())) {
                    object.setIHSPAENOTALLOWED(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "EUTRANNOTALLOWED").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "EUTRANNOTALLOWED").equals(
                            reader.getName())) {
                    object.setEUTRANNOTALLOWED(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "N3GPPNOTALLOWED").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "N3GPPNOTALLOWED").equals(
                            reader.getName())) {
                    object.setN3GPPNOTALLOWED(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SCHARGE_GLOBAL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SCHARGE_GLOBAL").equals(
                            reader.getName())) {
                    object.setSCHARGE_GLOBAL(com.huawei.www.hss.Str4_4.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CPP").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CPP").equals(
                            reader.getName())) {
                    object.setCPP(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ECATOPTION").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ECATOPTION").equals(
                            reader.getName())) {
                    object.setECATOPTION(com.huawei.www.hss.Int0_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ELCS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ELCS").equals(
                            reader.getName())) {
                    object.setELCS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "FRAUDTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "FRAUDTPLID").equals(
                            reader.getName())) {
                    object.setFRAUDTPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMEILCKPROV").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMEILCKPROV").equals(
                            reader.getName())) {
                    object.setIMEILCKPROV(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSIIMEIBIND").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSIIMEIBIND").equals(
                            reader.getName())) {
                    object.setIMSIIMEIBIND(com.huawei.www.hss.Str14_14.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "M2MNOTIFY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "M2MNOTIFY").equals(
                            reader.getName())) {
                    object.setM2MNOTIFY(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LUCSI_TPL_ID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LUCSI_TPL_ID").equals(
                            reader.getName())) {
                    object.setLUCSI_TPL_ID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SHORTNUMTPL").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SHORTNUMTPL").equals(
                            reader.getName())) {
                    object.setSHORTNUMTPL(com.huawei.www.hss.Int0_998.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "USERCATEGORY").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "USERCATEGORY").equals(
                            reader.getName())) {
                    object.setUSERCATEGORY(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBPREMSMS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBPREMSMS").equals(
                            reader.getName())) {
                    object.setODBPREMSMS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ODBADULTSMS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ODBADULTSMS").equals(
                            reader.getName())) {
                    object.setODBADULTSMS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BOSK").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BOSK").equals(
                            reader.getName())) {
                    object.setBOSK(com.huawei.www.hss.Int1_999.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ZCLOCKPROV").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ZCLOCKPROV").equals(
                            reader.getName())) {
                    object.setZCLOCKPROV(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PSUSERTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PSUSERTPLID").equals(
                            reader.getName())) {
                    object.setPSUSERTPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PSAPNOITPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PSAPNOITPLID").equals(
                            reader.getName())) {
                    object.setPSAPNOITPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "M2MCISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "M2MCISDN").equals(
                            reader.getName())) {
                    object.setM2MCISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "MAPADDRRESTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "MAPADDRRESTPLID").equals(
                            reader.getName())) {
                    object.setMAPADDRRESTPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ETCSICONVER_TPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ETCSICONVER_TPLID").equals(
                            reader.getName())) {
                    object.setETCSICONVER_TPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "DND").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "DND").equals(
                            reader.getName())) {
                    object.setDND(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VMCC").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VMCC").equals(
                            reader.getName())) {
                    object.setVMCC(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
