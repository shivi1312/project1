/**
 * DynamicStatusInfoForNon3GPP_type0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  DynamicStatusInfoForNon3GPP_type0 bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class DynamicStatusInfoForNon3GPP_type0 implements org.apache.axis2.databinding.ADBBean {
    /* This type was generated from the piece of schema that had
       name = DynamicStatusInfoForNon3GPP_type0
       Namespace URI = http://www.huawei.com/HSS
       Namespace Prefix = ns3
     */

    /**
     * field for VNI
     */
    protected com.huawei.www.hss.Str1_128 localVNI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localVNITracker = false;

    /**
     * field for REGSTATUS
     */
    protected com.huawei.www.hss._EnumType localREGSTATUS;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localREGSTATUSTracker = false;

    /**
     * field for ACCESSNETID
     */
    protected com.huawei.www.hss.Str1_16 localACCESSNETID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localACCESSNETIDTracker = false;

    /**
     * field for TGPPAAASERVERNAME
     */
    protected com.huawei.www.hss.Str1_128 localTGPPAAASERVERNAME;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTGPPAAASERVERNAMETracker = false;

    /**
     * field for TGPPAAASERVERREALM
     */
    protected com.huawei.www.hss.Str1_128 localTGPPAAASERVERREALM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTGPPAAASERVERREALMTracker = false;

    /**
     * field for TGPP2MEID
     */
    protected com.huawei.www.hss.Str1_16 localTGPP2MEID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localTGPP2MEIDTracker = false;

    /**
     * field for AAAIMEI
     */
    protected com.huawei.www.hss.Str1_16 localAAAIMEI;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAAAIMEITracker = false;

    /**
     * field for AAAIMEISV
     */
    protected com.huawei.www.hss.Str1_60 localAAAIMEISV;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localAAAIMEISVTracker = false;

    /**
     * field for ServerAssignmentTime
     */
    protected com.huawei.www.hss.Str1_35 localServerAssignmentTime;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localServerAssignmentTimeTracker = false;

    /**
     * field for NON3GPPRATTYPE
     */
    protected com.huawei.www.hss._EnumType localNON3GPPRATTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localNON3GPPRATTYPETracker = false;

    public boolean isVNISpecified() {
        return localVNITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getVNI() {
        return localVNI;
    }

    /**
     * Auto generated setter method
     * @param param VNI
     */
    public void setVNI(com.huawei.www.hss.Str1_128 param) {
        localVNITracker = param != null;

        this.localVNI = param;
    }

    public boolean isREGSTATUSSpecified() {
        return localREGSTATUSTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getREGSTATUS() {
        return localREGSTATUS;
    }

    /**
     * Auto generated setter method
     * @param param REGSTATUS
     */
    public void setREGSTATUS(com.huawei.www.hss._EnumType param) {
        localREGSTATUSTracker = param != null;

        this.localREGSTATUS = param;
    }

    public boolean isACCESSNETIDSpecified() {
        return localACCESSNETIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getACCESSNETID() {
        return localACCESSNETID;
    }

    /**
     * Auto generated setter method
     * @param param ACCESSNETID
     */
    public void setACCESSNETID(com.huawei.www.hss.Str1_16 param) {
        localACCESSNETIDTracker = param != null;

        this.localACCESSNETID = param;
    }

    public boolean isTGPPAAASERVERNAMESpecified() {
        return localTGPPAAASERVERNAMETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getTGPPAAASERVERNAME() {
        return localTGPPAAASERVERNAME;
    }

    /**
     * Auto generated setter method
     * @param param TGPPAAASERVERNAME
     */
    public void setTGPPAAASERVERNAME(com.huawei.www.hss.Str1_128 param) {
        localTGPPAAASERVERNAMETracker = param != null;

        this.localTGPPAAASERVERNAME = param;
    }

    public boolean isTGPPAAASERVERREALMSpecified() {
        return localTGPPAAASERVERREALMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_128
     */
    public com.huawei.www.hss.Str1_128 getTGPPAAASERVERREALM() {
        return localTGPPAAASERVERREALM;
    }

    /**
     * Auto generated setter method
     * @param param TGPPAAASERVERREALM
     */
    public void setTGPPAAASERVERREALM(com.huawei.www.hss.Str1_128 param) {
        localTGPPAAASERVERREALMTracker = param != null;

        this.localTGPPAAASERVERREALM = param;
    }

    public boolean isTGPP2MEIDSpecified() {
        return localTGPP2MEIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getTGPP2MEID() {
        return localTGPP2MEID;
    }

    /**
     * Auto generated setter method
     * @param param TGPP2MEID
     */
    public void setTGPP2MEID(com.huawei.www.hss.Str1_16 param) {
        localTGPP2MEIDTracker = param != null;

        this.localTGPP2MEID = param;
    }

    public boolean isAAAIMEISpecified() {
        return localAAAIMEITracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_16
     */
    public com.huawei.www.hss.Str1_16 getAAAIMEI() {
        return localAAAIMEI;
    }

    /**
     * Auto generated setter method
     * @param param AAAIMEI
     */
    public void setAAAIMEI(com.huawei.www.hss.Str1_16 param) {
        localAAAIMEITracker = param != null;

        this.localAAAIMEI = param;
    }

    public boolean isAAAIMEISVSpecified() {
        return localAAAIMEISVTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_60
     */
    public com.huawei.www.hss.Str1_60 getAAAIMEISV() {
        return localAAAIMEISV;
    }

    /**
     * Auto generated setter method
     * @param param AAAIMEISV
     */
    public void setAAAIMEISV(com.huawei.www.hss.Str1_60 param) {
        localAAAIMEISVTracker = param != null;

        this.localAAAIMEISV = param;
    }

    public boolean isServerAssignmentTimeSpecified() {
        return localServerAssignmentTimeTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_35
     */
    public com.huawei.www.hss.Str1_35 getServerAssignmentTime() {
        return localServerAssignmentTime;
    }

    /**
     * Auto generated setter method
     * @param param ServerAssignmentTime
     */
    public void setServerAssignmentTime(com.huawei.www.hss.Str1_35 param) {
        localServerAssignmentTimeTracker = param != null;

        this.localServerAssignmentTime = param;
    }

    public boolean isNON3GPPRATTYPESpecified() {
        return localNON3GPPRATTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getNON3GPPRATTYPE() {
        return localNON3GPPRATTYPE;
    }

    /**
     * Auto generated setter method
     * @param param NON3GPPRATTYPE
     */
    public void setNON3GPPRATTYPE(com.huawei.www.hss._EnumType param) {
        localNON3GPPRATTYPETracker = param != null;

        this.localNON3GPPRATTYPE = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":DynamicStatusInfoForNon3GPP_type0",
                    xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "DynamicStatusInfoForNon3GPP_type0", xmlWriter);
            }
        }

        if (localVNITracker) {
            if (localVNI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "VNI cannot be null!!");
            }

            localVNI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "VNI"), xmlWriter);
        }

        if (localREGSTATUSTracker) {
            if (localREGSTATUS == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "REGSTATUS cannot be null!!");
            }

            localREGSTATUS.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "REGSTATUS"), xmlWriter);
        }

        if (localACCESSNETIDTracker) {
            if (localACCESSNETID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ACCESSNETID cannot be null!!");
            }

            localACCESSNETID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ACCESSNETID"), xmlWriter);
        }

        if (localTGPPAAASERVERNAMETracker) {
            if (localTGPPAAASERVERNAME == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TGPPAAASERVERNAME cannot be null!!");
            }

            localTGPPAAASERVERNAME.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TGPPAAASERVERNAME"), xmlWriter);
        }

        if (localTGPPAAASERVERREALMTracker) {
            if (localTGPPAAASERVERREALM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TGPPAAASERVERREALM cannot be null!!");
            }

            localTGPPAAASERVERREALM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TGPPAAASERVERREALM"),
                xmlWriter);
        }

        if (localTGPP2MEIDTracker) {
            if (localTGPP2MEID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "TGPP2MEID cannot be null!!");
            }

            localTGPP2MEID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "TGPP2MEID"), xmlWriter);
        }

        if (localAAAIMEITracker) {
            if (localAAAIMEI == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AAA-IMEI cannot be null!!");
            }

            localAAAIMEI.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AAA-IMEI"), xmlWriter);
        }

        if (localAAAIMEISVTracker) {
            if (localAAAIMEISV == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "AAA-IMEISV cannot be null!!");
            }

            localAAAIMEISV.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "AAA-IMEISV"), xmlWriter);
        }

        if (localServerAssignmentTimeTracker) {
            if (localServerAssignmentTime == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "Server-Assignment-Time cannot be null!!");
            }

            localServerAssignmentTime.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "Server-Assignment-Time"),
                xmlWriter);
        }

        if (localNON3GPPRATTYPETracker) {
            if (localNON3GPPRATTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "NON3GPPRATTYPE cannot be null!!");
            }

            localNON3GPPRATTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "NON3GPPRATTYPE"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static DynamicStatusInfoForNon3GPP_type0 parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            DynamicStatusInfoForNon3GPP_type0 object = new DynamicStatusInfoForNon3GPP_type0();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"DynamicStatusInfoForNon3GPP_type0".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (DynamicStatusInfoForNon3GPP_type0) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "VNI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "VNI").equals(
                            reader.getName())) {
                    object.setVNI(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "REGSTATUS").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "REGSTATUS").equals(
                            reader.getName())) {
                    object.setREGSTATUS(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ACCESSNETID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ACCESSNETID").equals(
                            reader.getName())) {
                    object.setACCESSNETID(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TGPPAAASERVERNAME").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TGPPAAASERVERNAME").equals(
                            reader.getName())) {
                    object.setTGPPAAASERVERNAME(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TGPPAAASERVERREALM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TGPPAAASERVERREALM").equals(
                            reader.getName())) {
                    object.setTGPPAAASERVERREALM(com.huawei.www.hss.Str1_128.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TGPP2MEID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TGPP2MEID").equals(
                            reader.getName())) {
                    object.setTGPP2MEID(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AAA-IMEI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AAA-IMEI").equals(
                            reader.getName())) {
                    object.setAAAIMEI(com.huawei.www.hss.Str1_16.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "AAA-IMEISV").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "AAA-IMEISV").equals(
                            reader.getName())) {
                    object.setAAAIMEISV(com.huawei.www.hss.Str1_60.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS",
                            "Server-Assignment-Time").equals(reader.getName())) ||
                        new javax.xml.namespace.QName("",
                            "Server-Assignment-Time").equals(reader.getName())) {
                    object.setServerAssignmentTime(com.huawei.www.hss.Str1_35.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "NON3GPPRATTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "NON3GPPRATTYPE").equals(
                            reader.getName())) {
                    object.setNON3GPPRATTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
