/**
 * ADD_TPLUSCSUB.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.5  Built on : May 06, 2017 (03:45:50 BST)
 */
package com.huawei.www.hss;


/**
 *  ADD_TPLUSCSUB bean class
 */
@SuppressWarnings({"unchecked",
    "unused"
})
public class ADD_TPLUSCSUB implements org.apache.axis2.databinding.ADBBean {
    public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName("http://www.huawei.com/HSS",
            "ADD_TPLUSCSUB", "ns3");

    /**
     * field for HLRSN
     */
    protected com.huawei.www.hss.Int1_255 localHLRSN;

    /**
     * field for IMSI
     */
    protected com.huawei.www.hss.Str6_15 localIMSI;

    /**
     * field for ISDN
     */
    protected com.huawei.www.hss.Str1_15 localISDN;

    /**
     * field for TPLID
     */
    protected com.huawei.www.hss.Int0_65534 localTPLID;

    /**
     * field for LINE2NUM
     */
    protected com.huawei.www.hss.Str1_15 localLINE2NUM;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localLINE2NUMTracker = false;

    /**
     * field for STNSR
     */
    protected com.huawei.www.hss.Str3_15 localSTNSR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSTNSRTracker = false;

    /**
     * field for ANCHOR
     */
    protected com.huawei.www.hss._EnumType localANCHOR;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localANCHORTracker = false;

    /**
     * field for SUBID
     */
    protected com.huawei.www.hss.Str1_127 localSUBID;

    /**
     * field for IMPI
     */
    protected com.huawei.www.hss.Str1_127 localIMPI;

    /**
     * field for IMPI2
     */
    protected com.huawei.www.hss.Str1_127 localIMPI2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMPI2Tracker = false;

    /**
     * field for IMPI2AUTHTYPE
     */
    protected com.huawei.www.hss._EnumType localIMPI2AUTHTYPE;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMPI2AUTHTYPETracker = false;

    /**
     * field for HUSERNAME2
     */
    protected com.huawei.www.hss.Str1_127 localHUSERNAME2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localHUSERNAME2Tracker = false;

    /**
     * field for PWD2
     */
    protected com.huawei.www.spgschema._PasswordType localPWD2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localPWD2Tracker = false;

    /**
     * field for REALM2
     */
    protected com.huawei.www.hss.Str1_46 localREALM2;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localREALM2Tracker = false;

    /**
     * field for HA12
     */
    protected com.huawei.www.spgschema._PasswordType localHA12;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localHA12Tracker = false;

    /**
     * field for IMPULIST
     */
    protected com.huawei.www.hss.Str1_1300 localIMPULIST;

    /**
     * field for BARIMPULIST
     */
    protected com.huawei.www.hss.Str1_1300 localBARIMPULIST;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localBARIMPULISTTracker = false;

    /**
     * field for CONSFLG
     */
    protected com.huawei.www.hss._EnumType localCONSFLG;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCONSFLGTracker = false;

    /**
     * field for CHARGTPLID
     */
    protected com.huawei.www.hss.Int0_254 localCHARGTPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCHARGTPLIDTracker = false;

    /**
     * field for IMPUTPLID
     */
    protected com.huawei.www.hss.Int0_254 localIMPUTPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIMPUTPLIDTracker = false;

    /**
     * field for SPTPLID
     */
    protected com.huawei.www.hss.Int0_254 localSPTPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localSPTPLIDTracker = false;

    /**
     * field for IRSID
     */
    protected com.huawei.www.hss.Int0_255 localIRSID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localIRSIDTracker = false;

    /**
     * field for ALIASID
     */
    protected com.huawei.www.hss.Int0_255 localALIASID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localALIASIDTracker = false;

    /**
     * field for CAPTPLID
     */
    protected com.huawei.www.hss.Int0_254 localCAPTPLID;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localCAPTPLIDTracker = false;

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int1_255
     */
    public com.huawei.www.hss.Int1_255 getHLRSN() {
        return localHLRSN;
    }

    /**
     * Auto generated setter method
     * @param param HLRSN
     */
    public void setHLRSN(com.huawei.www.hss.Int1_255 param) {
        this.localHLRSN = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str6_15
     */
    public com.huawei.www.hss.Str6_15 getIMSI() {
        return localIMSI;
    }

    /**
     * Auto generated setter method
     * @param param IMSI
     */
    public void setIMSI(com.huawei.www.hss.Str6_15 param) {
        this.localIMSI = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getISDN() {
        return localISDN;
    }

    /**
     * Auto generated setter method
     * @param param ISDN
     */
    public void setISDN(com.huawei.www.hss.Str1_15 param) {
        this.localISDN = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_65534
     */
    public com.huawei.www.hss.Int0_65534 getTPLID() {
        return localTPLID;
    }

    /**
     * Auto generated setter method
     * @param param TPLID
     */
    public void setTPLID(com.huawei.www.hss.Int0_65534 param) {
        this.localTPLID = param;
    }

    public boolean isLINE2NUMSpecified() {
        return localLINE2NUMTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_15
     */
    public com.huawei.www.hss.Str1_15 getLINE2NUM() {
        return localLINE2NUM;
    }

    /**
     * Auto generated setter method
     * @param param LINE2NUM
     */
    public void setLINE2NUM(com.huawei.www.hss.Str1_15 param) {
        localLINE2NUMTracker = param != null;

        this.localLINE2NUM = param;
    }

    public boolean isSTNSRSpecified() {
        return localSTNSRTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str3_15
     */
    public com.huawei.www.hss.Str3_15 getSTNSR() {
        return localSTNSR;
    }

    /**
     * Auto generated setter method
     * @param param STNSR
     */
    public void setSTNSR(com.huawei.www.hss.Str3_15 param) {
        localSTNSRTracker = param != null;

        this.localSTNSR = param;
    }

    public boolean isANCHORSpecified() {
        return localANCHORTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getANCHOR() {
        return localANCHOR;
    }

    /**
     * Auto generated setter method
     * @param param ANCHOR
     */
    public void setANCHOR(com.huawei.www.hss._EnumType param) {
        localANCHORTracker = param != null;

        this.localANCHOR = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_127
     */
    public com.huawei.www.hss.Str1_127 getSUBID() {
        return localSUBID;
    }

    /**
     * Auto generated setter method
     * @param param SUBID
     */
    public void setSUBID(com.huawei.www.hss.Str1_127 param) {
        this.localSUBID = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_127
     */
    public com.huawei.www.hss.Str1_127 getIMPI() {
        return localIMPI;
    }

    /**
     * Auto generated setter method
     * @param param IMPI
     */
    public void setIMPI(com.huawei.www.hss.Str1_127 param) {
        this.localIMPI = param;
    }

    public boolean isIMPI2Specified() {
        return localIMPI2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_127
     */
    public com.huawei.www.hss.Str1_127 getIMPI2() {
        return localIMPI2;
    }

    /**
     * Auto generated setter method
     * @param param IMPI2
     */
    public void setIMPI2(com.huawei.www.hss.Str1_127 param) {
        localIMPI2Tracker = param != null;

        this.localIMPI2 = param;
    }

    public boolean isIMPI2AUTHTYPESpecified() {
        return localIMPI2AUTHTYPETracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getIMPI2AUTHTYPE() {
        return localIMPI2AUTHTYPE;
    }

    /**
     * Auto generated setter method
     * @param param IMPI2AUTHTYPE
     */
    public void setIMPI2AUTHTYPE(com.huawei.www.hss._EnumType param) {
        localIMPI2AUTHTYPETracker = param != null;

        this.localIMPI2AUTHTYPE = param;
    }

    public boolean isHUSERNAME2Specified() {
        return localHUSERNAME2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_127
     */
    public com.huawei.www.hss.Str1_127 getHUSERNAME2() {
        return localHUSERNAME2;
    }

    /**
     * Auto generated setter method
     * @param param HUSERNAME2
     */
    public void setHUSERNAME2(com.huawei.www.hss.Str1_127 param) {
        localHUSERNAME2Tracker = param != null;

        this.localHUSERNAME2 = param;
    }

    public boolean isPWD2Specified() {
        return localPWD2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.spgschema._PasswordType
     */
    public com.huawei.www.spgschema._PasswordType getPWD2() {
        return localPWD2;
    }

    /**
     * Auto generated setter method
     * @param param PWD2
     */
    public void setPWD2(com.huawei.www.spgschema._PasswordType param) {
        localPWD2Tracker = param != null;

        this.localPWD2 = param;
    }

    public boolean isREALM2Specified() {
        return localREALM2Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_46
     */
    public com.huawei.www.hss.Str1_46 getREALM2() {
        return localREALM2;
    }

    /**
     * Auto generated setter method
     * @param param REALM2
     */
    public void setREALM2(com.huawei.www.hss.Str1_46 param) {
        localREALM2Tracker = param != null;

        this.localREALM2 = param;
    }

    public boolean isHA12Specified() {
        return localHA12Tracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.spgschema._PasswordType
     */
    public com.huawei.www.spgschema._PasswordType getHA12() {
        return localHA12;
    }

    /**
     * Auto generated setter method
     * @param param HA12
     */
    public void setHA12(com.huawei.www.spgschema._PasswordType param) {
        localHA12Tracker = param != null;

        this.localHA12 = param;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_1300
     */
    public com.huawei.www.hss.Str1_1300 getIMPULIST() {
        return localIMPULIST;
    }

    /**
     * Auto generated setter method
     * @param param IMPULIST
     */
    public void setIMPULIST(com.huawei.www.hss.Str1_1300 param) {
        this.localIMPULIST = param;
    }

    public boolean isBARIMPULISTSpecified() {
        return localBARIMPULISTTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Str1_1300
     */
    public com.huawei.www.hss.Str1_1300 getBARIMPULIST() {
        return localBARIMPULIST;
    }

    /**
     * Auto generated setter method
     * @param param BARIMPULIST
     */
    public void setBARIMPULIST(com.huawei.www.hss.Str1_1300 param) {
        localBARIMPULISTTracker = param != null;

        this.localBARIMPULIST = param;
    }

    public boolean isCONSFLGSpecified() {
        return localCONSFLGTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss._EnumType
     */
    public com.huawei.www.hss._EnumType getCONSFLG() {
        return localCONSFLG;
    }

    /**
     * Auto generated setter method
     * @param param CONSFLG
     */
    public void setCONSFLG(com.huawei.www.hss._EnumType param) {
        localCONSFLGTracker = param != null;

        this.localCONSFLG = param;
    }

    public boolean isCHARGTPLIDSpecified() {
        return localCHARGTPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_254
     */
    public com.huawei.www.hss.Int0_254 getCHARGTPLID() {
        return localCHARGTPLID;
    }

    /**
     * Auto generated setter method
     * @param param CHARGTPLID
     */
    public void setCHARGTPLID(com.huawei.www.hss.Int0_254 param) {
        localCHARGTPLIDTracker = param != null;

        this.localCHARGTPLID = param;
    }

    public boolean isIMPUTPLIDSpecified() {
        return localIMPUTPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_254
     */
    public com.huawei.www.hss.Int0_254 getIMPUTPLID() {
        return localIMPUTPLID;
    }

    /**
     * Auto generated setter method
     * @param param IMPUTPLID
     */
    public void setIMPUTPLID(com.huawei.www.hss.Int0_254 param) {
        localIMPUTPLIDTracker = param != null;

        this.localIMPUTPLID = param;
    }

    public boolean isSPTPLIDSpecified() {
        return localSPTPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_254
     */
    public com.huawei.www.hss.Int0_254 getSPTPLID() {
        return localSPTPLID;
    }

    /**
     * Auto generated setter method
     * @param param SPTPLID
     */
    public void setSPTPLID(com.huawei.www.hss.Int0_254 param) {
        localSPTPLIDTracker = param != null;

        this.localSPTPLID = param;
    }

    public boolean isIRSIDSpecified() {
        return localIRSIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_255
     */
    public com.huawei.www.hss.Int0_255 getIRSID() {
        return localIRSID;
    }

    /**
     * Auto generated setter method
     * @param param IRSID
     */
    public void setIRSID(com.huawei.www.hss.Int0_255 param) {
        localIRSIDTracker = param != null;

        this.localIRSID = param;
    }

    public boolean isALIASIDSpecified() {
        return localALIASIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_255
     */
    public com.huawei.www.hss.Int0_255 getALIASID() {
        return localALIASID;
    }

    /**
     * Auto generated setter method
     * @param param ALIASID
     */
    public void setALIASID(com.huawei.www.hss.Int0_255 param) {
        localALIASIDTracker = param != null;

        this.localALIASID = param;
    }

    public boolean isCAPTPLIDSpecified() {
        return localCAPTPLIDTracker;
    }

    /**
     * Auto generated getter method
     * @return com.huawei.www.hss.Int0_254
     */
    public com.huawei.www.hss.Int0_254 getCAPTPLID() {
        return localCAPTPLID;
    }

    /**
     * Auto generated setter method
     * @param param CAPTPLID
     */
    public void setCAPTPLID(com.huawei.www.hss.Int0_254 param) {
        localCAPTPLIDTracker = param != null;

        this.localCAPTPLID = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
        final javax.xml.namespace.QName parentQName,
        final org.apache.axiom.om.OMFactory factory)
        throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, MY_QNAME));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
        javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
        throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
            xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://www.huawei.com/HSS");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    namespacePrefix + ":ADD_TPLUSCSUB", xmlWriter);
            } else {
                writeAttribute("xsi",
                    "http://www.w3.org/2001/XMLSchema-instance", "type",
                    "ADD_TPLUSCSUB", xmlWriter);
            }
        }

        if (localHLRSN == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "HLRSN cannot be null!!");
        }

        localHLRSN.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "HLRSN"), xmlWriter);

        if (localIMSI == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "IMSI cannot be null!!");
        }

        localIMSI.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "IMSI"), xmlWriter);

        if (localISDN == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "ISDN cannot be null!!");
        }

        localISDN.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "ISDN"), xmlWriter);

        if (localTPLID == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "TPLID cannot be null!!");
        }

        localTPLID.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "TPLID"), xmlWriter);

        if (localLINE2NUMTracker) {
            if (localLINE2NUM == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "LINE2NUM cannot be null!!");
            }

            localLINE2NUM.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "LINE2NUM"), xmlWriter);
        }

        if (localSTNSRTracker) {
            if (localSTNSR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "STNSR cannot be null!!");
            }

            localSTNSR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "STNSR"), xmlWriter);
        }

        if (localANCHORTracker) {
            if (localANCHOR == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ANCHOR cannot be null!!");
            }

            localANCHOR.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ANCHOR"), xmlWriter);
        }

        if (localSUBID == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "SUBID cannot be null!!");
        }

        localSUBID.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "SUBID"), xmlWriter);

        if (localIMPI == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "IMPI cannot be null!!");
        }

        localIMPI.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "IMPI"), xmlWriter);

        if (localIMPI2Tracker) {
            if (localIMPI2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMPI2 cannot be null!!");
            }

            localIMPI2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMPI2"), xmlWriter);
        }

        if (localIMPI2AUTHTYPETracker) {
            if (localIMPI2AUTHTYPE == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMPI2AUTHTYPE cannot be null!!");
            }

            localIMPI2AUTHTYPE.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMPI2AUTHTYPE"), xmlWriter);
        }

        if (localHUSERNAME2Tracker) {
            if (localHUSERNAME2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "HUSERNAME2 cannot be null!!");
            }

            localHUSERNAME2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "HUSERNAME2"), xmlWriter);
        }

        if (localPWD2Tracker) {
            if (localPWD2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "PWD2 cannot be null!!");
            }

            localPWD2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "PWD2"), xmlWriter);
        }

        if (localREALM2Tracker) {
            if (localREALM2 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "REALM2 cannot be null!!");
            }

            localREALM2.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "REALM2"), xmlWriter);
        }

        if (localHA12Tracker) {
            if (localHA12 == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "HA12 cannot be null!!");
            }

            localHA12.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "HA12"), xmlWriter);
        }

        if (localIMPULIST == null) {
            throw new org.apache.axis2.databinding.ADBException(
                "IMPULIST cannot be null!!");
        }

        localIMPULIST.serialize(new javax.xml.namespace.QName(
                "http://www.huawei.com/HSS", "IMPULIST"), xmlWriter);

        if (localBARIMPULISTTracker) {
            if (localBARIMPULIST == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "BARIMPULIST cannot be null!!");
            }

            localBARIMPULIST.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "BARIMPULIST"), xmlWriter);
        }

        if (localCONSFLGTracker) {
            if (localCONSFLG == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CONSFLG cannot be null!!");
            }

            localCONSFLG.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CONSFLG"), xmlWriter);
        }

        if (localCHARGTPLIDTracker) {
            if (localCHARGTPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CHARGTPLID cannot be null!!");
            }

            localCHARGTPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CHARGTPLID"), xmlWriter);
        }

        if (localIMPUTPLIDTracker) {
            if (localIMPUTPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IMPUTPLID cannot be null!!");
            }

            localIMPUTPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IMPUTPLID"), xmlWriter);
        }

        if (localSPTPLIDTracker) {
            if (localSPTPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "SPTPLID cannot be null!!");
            }

            localSPTPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "SPTPLID"), xmlWriter);
        }

        if (localIRSIDTracker) {
            if (localIRSID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "IRSID cannot be null!!");
            }

            localIRSID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "IRSID"), xmlWriter);
        }

        if (localALIASIDTracker) {
            if (localALIASID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "ALIASID cannot be null!!");
            }

            localALIASID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "ALIASID"), xmlWriter);
        }

        if (localCAPTPLIDTracker) {
            if (localCAPTPLID == null) {
                throw new org.apache.axis2.databinding.ADBException(
                    "CAPTPLID cannot be null!!");
            }

            localCAPTPLID.serialize(new javax.xml.namespace.QName(
                    "http://www.huawei.com/HSS", "CAPTPLID"), xmlWriter);
        }

        xmlWriter.writeEndElement();
    }

    private static java.lang.String generatePrefix(java.lang.String namespace) {
        if (namespace.equals("http://www.huawei.com/HSS")) {
            return "ns3";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
        java.lang.String namespace, java.lang.String localPart,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
        java.lang.String namespace, java.lang.String attName,
        java.lang.String attValue, javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName, attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
        java.lang.String attName, java.lang.String attValue,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
        java.lang.String attName, javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
        javax.xml.stream.XMLStreamWriter xmlWriter)
        throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                     .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
        javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace)
        throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static ADD_TPLUSCSUB parse(
            javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception {
            ADD_TPLUSCSUB object = new ADD_TPLUSCSUB();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                            "http://www.w3.org/2001/XMLSchema-instance", "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                    ":") + 1);

                        if (!"ADD_TPLUSCSUB".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                                           .getNamespaceURI(nsPrefix);

                            return (ADD_TPLUSCSUB) com.huawei.www.spgschema.ExtensionMapper.getTypeObject(nsUri,
                                type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                reader.next();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "HLRSN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "HLRSN").equals(
                            reader.getName())) {
                    object.setHLRSN(com.huawei.www.hss.Int1_255.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMSI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMSI").equals(
                            reader.getName())) {
                    object.setIMSI(com.huawei.www.hss.Str6_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ISDN").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ISDN").equals(
                            reader.getName())) {
                    object.setISDN(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "TPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "TPLID").equals(
                            reader.getName())) {
                    object.setTPLID(com.huawei.www.hss.Int0_65534.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "LINE2NUM").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "LINE2NUM").equals(
                            reader.getName())) {
                    object.setLINE2NUM(com.huawei.www.hss.Str1_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "STNSR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "STNSR").equals(
                            reader.getName())) {
                    object.setSTNSR(com.huawei.www.hss.Str3_15.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ANCHOR").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ANCHOR").equals(
                            reader.getName())) {
                    object.setANCHOR(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SUBID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SUBID").equals(
                            reader.getName())) {
                    object.setSUBID(com.huawei.www.hss.Str1_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMPI").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMPI").equals(
                            reader.getName())) {
                    object.setIMPI(com.huawei.www.hss.Str1_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMPI2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMPI2").equals(
                            reader.getName())) {
                    object.setIMPI2(com.huawei.www.hss.Str1_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMPI2AUTHTYPE").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMPI2AUTHTYPE").equals(
                            reader.getName())) {
                    object.setIMPI2AUTHTYPE(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "HUSERNAME2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "HUSERNAME2").equals(
                            reader.getName())) {
                    object.setHUSERNAME2(com.huawei.www.hss.Str1_127.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "PWD2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "PWD2").equals(
                            reader.getName())) {
                    object.setPWD2(com.huawei.www.spgschema._PasswordType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "REALM2").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "REALM2").equals(
                            reader.getName())) {
                    object.setREALM2(com.huawei.www.hss.Str1_46.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "HA12").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "HA12").equals(
                            reader.getName())) {
                    object.setHA12(com.huawei.www.spgschema._PasswordType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMPULIST").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMPULIST").equals(
                            reader.getName())) {
                    object.setIMPULIST(com.huawei.www.hss.Str1_1300.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                    // 1 - A start element we are not expecting indicates an invalid parameter was passed
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "BARIMPULIST").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "BARIMPULIST").equals(
                            reader.getName())) {
                    object.setBARIMPULIST(com.huawei.www.hss.Str1_1300.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CONSFLG").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CONSFLG").equals(
                            reader.getName())) {
                    object.setCONSFLG(com.huawei.www.hss._EnumType.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CHARGTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CHARGTPLID").equals(
                            reader.getName())) {
                    object.setCHARGTPLID(com.huawei.www.hss.Int0_254.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IMPUTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IMPUTPLID").equals(
                            reader.getName())) {
                    object.setIMPUTPLID(com.huawei.www.hss.Int0_254.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "SPTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "SPTPLID").equals(
                            reader.getName())) {
                    object.setSPTPLID(com.huawei.www.hss.Int0_254.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "IRSID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "IRSID").equals(
                            reader.getName())) {
                    object.setIRSID(com.huawei.www.hss.Int0_255.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "ALIASID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "ALIASID").equals(
                            reader.getName())) {
                    object.setALIASID(com.huawei.www.hss.Int0_255.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName(
                            "http://www.huawei.com/HSS", "CAPTPLID").equals(
                            reader.getName())) ||
                        new javax.xml.namespace.QName("", "CAPTPLID").equals(
                            reader.getName())) {
                    object.setCAPTPLID(com.huawei.www.hss.Int0_254.Factory.parse(
                            reader));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                        "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}
