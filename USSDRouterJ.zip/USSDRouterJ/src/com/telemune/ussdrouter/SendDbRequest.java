package com.telemune.ussdrouter;

public class SendDbRequest {
	public SendDbRequest() {
		// TODO Auto-generated constructor stub
	}

}
