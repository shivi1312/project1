package com.telemune.ussdrouter;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

/**
 * This class works as Rejected work handler for those tasks that are 
 * rejected by Thread Pool executor due to unavailability of threads
 * @author Harjinder
 * */
public class HttpRejectedWork implements RejectedExecutionHandler {
 Logger logger = Logger.getLogger(HttpRejectedWork.class);
 
   /**
    * This method is provided by RejectedExecutionHandler
    * @param r
    * @param executor
    * @return void
    * */
   public void rejectedExecution(Runnable r, ThreadPoolExecutor executor)  {
       logger.warn("TASK IS REJECTED BECOZ ,MAX THREAD IS OPEN  and WORKING QUEUE IS ALREDY FULL , SO WAIT FOR 1 SECOND  and AGAIN TRY TO EXECUTE : (To avoid this problem increase  Working queue size)"+ Thread.currentThread().getName());
       try {
           Thread.sleep(1);
       } catch (InterruptedException e) {
           logger.error("Exception while rejectedExecution "+e);
       }
       logger.debug("Lets Try another time : "+Thread.currentThread().getName());
          try{
              executor.execute(r);
          }
          catch(RejectedExecutionException re){
          logger.error("Problem In  Submitting task because Its too late processing, Please check your Processing time of Server(Good Option) or increase thread pool queue size(Bad Option) ",re);
          }
   }
}
