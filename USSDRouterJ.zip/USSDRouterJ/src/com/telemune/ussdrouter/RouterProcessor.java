package com.telemune.ussdrouter;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.beans.DataObject;
import com.telemune.ussdrouter.beans.Global;
import com.telemune.ussdrouter.db.Dboperations;
import com.telemune.ussdrouter.util.RouterCommonConstants;
import com.telemune.ussdrouter.util.UssdUtils;


public class RouterProcessor implements Runnable{
	private Logger logger = Logger.getLogger(RouterProcessor.class);
	private ArrayBlockingQueue httpReqQueue = null;
	private ArrayBlockingQueue smppReqQueue = null;
	private ArrayBlockingQueue dbReqQueue = null;
	private ArrayBlockingQueue routerResQueue = null;
	private ArrayBlockingQueue httpResQueue = null;
	private ArrayBlockingQueue smppResQueue = null;
	private ArrayBlockingQueue dbResQueue = null;

	private DataObject dataObject = null;
	private ConcurrentHashMap requestMap = null;
	private Dboperations dboperations = null;
	private UssdUtils ussdUtils = null;
	String shortCode;
	String firstDigit = "NA";
	int status = 1;
	private ThreadPoolExecutor httpTaskExecutor = null;
	public DataObject getDataObject() {
		return dataObject;
	}

	public void setDataObject(DataObject dataObject) {
		this.dataObject = dataObject;
	}

	public void setHttpTaskExecutor(ThreadPoolExecutor httpTaskExecutor){
		this.httpTaskExecutor = httpTaskExecutor;	
	}


	public RouterProcessor(ArrayBlockingQueue httpReqQueue , ArrayBlockingQueue smppReqQueue , ArrayBlockingQueue dbReqQueue , ConcurrentHashMap requestMap,Dboperations dboperations , UssdUtils ussdUtils , ArrayBlockingQueue routerResQueue , ArrayBlockingQueue httpResQueue , ArrayBlockingQueue smppResQueue , ArrayBlockingQueue dbResQueue) {
		this.httpReqQueue = httpReqQueue;
		this.smppReqQueue = smppReqQueue;
		this.dbReqQueue = dbReqQueue;
		this.requestMap = requestMap;
		this.dboperations = dboperations;
		this.ussdUtils = ussdUtils;
		this.routerResQueue = routerResQueue;
		this.httpResQueue =  httpResQueue;
		this.smppResQueue = smppResQueue;
		this.dbResQueue = dbResQueue;
	}

	public void run() {
		try
		{
			/*added by rahul kumar 03/04/2018
			 * TPS validation code start here
			 */
			Global.currentTPS.incrementAndGet();			
			long requestTime=System.currentTimeMillis();
			if(Global.currentTPS.get()==1)
			{
				Global.firstRequestTime.set(requestTime);
				Global.tpsStartTime.set(Global.firstRequestTime.get());
				long tpsEndTime=Global.firstRequestTime.get()+1000;
				Global.tpsEndTime.set(tpsEndTime);
				logger.info("[START]>> Going to start TPS so current TPS:["+Global.currentTPS+"],Request Time:["+Global.firstRequestTime+"], TPS Start Time:["+Global.tpsStartTime+"], TPS End Time:["+Global.tpsEndTime+"],process Request:["+Global.processRequest+"]");
			}
			else if(requestTime>Global.tpsEndTime.get())
			{
				Global.firstRequestTime.set(requestTime);
				Global.currentTPS.set(1);
				Global.rejectedRequest.set(0);
				Global.processRequest.set(true);
				Global.tpsStartTime.set(Global.firstRequestTime.get());
				long tpsEndTime=Global.firstRequestTime.get()+1000;
				Global.tpsEndTime.set(tpsEndTime);
				logger.info("[TIMEOUT]>>Second is over so current TPS:["+Global.currentTPS+"],Max TPS:["+Global.maxTps+"],Request Time:["+Global.firstRequestTime+"], TPS Start Time:["+Global.tpsStartTime+"], TPS End Time:["+Global.tpsEndTime+"], process Request:["+Global.processRequest+"]");
			
			}
			if(Global.currentTPS.get()>Global.routersMaxTps.get() && Global.processRequest.get())
			{
				Global.processRequest.set(false);
				long delayTime=Global.tpsEndTime.get()-requestTime;
				if(delayTime>0 && delayTime<1000)
				{
					logger.info("Delay Time:["+delayTime+"]");
					TimerTask task=new DelayTimer();
					Timer timer=new Timer();
					timer.schedule(task,delayTime);
				}
			}			
			//  TPS validation code end here
			if(Global.processRequest.get())
			{
				logger.info("[PROCESS PULL REQUEST]>> MSISDN:["+dataObject.getMsisdn()+"]current TPS:["+Global.currentTPS+"],Max TPS for this router:["+Global.routersMaxTps+"],Total TPS:["+Global.maxTps+"],Request Time:["+requestTime+"],TPS End Time:["+Global.tpsEndTime+"], Rejected Request:["+Global.rejectedRequest.get()+"]TPS Limit for Alert:["+Global.tpsAlertLimit+"],TPS percentage for Alert:["+Global.tpsAlertPercentage+"]");
				if(Global.currentTPS.get()>=Global.tpsAlertLimit.get())
				{
					logger.info("[ALERT]@@ current TPS:["+Global.currentTPS+"],Max TPS for this router:["+Global.routersMaxTps+"],Total TPS:["+Global.maxTps+"],TPS Limit for Alert:["+Global.tpsAlertLimit+"],TPS percentage for Alert:["+Global.tpsAlertPercentage+"]");
				}				
				switch(dataObject.getOpCode())
				{
					case UssdRouterConstants.PSSR_REQ :
						{
							this.ussdUtils.increaseDialog();
							this.ussdUtils.increaseCurrentDialogs();
							Date date = (Date) UssdRouterMainClient.context.getBean("reqTime");
							dataObject.setReqDate(date);
							dataObject.setReqTime(System.currentTimeMillis());
							dataObject.setReqCounter(1);
							/*if(dataObject.getUserData().startsWith("#")){
								logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Dialog String Invalid..");
								dataObject.ussdErrorCodeBean = this.ussdUtils.getErrorMessage("1_"+UssdRouterMainClient.config.getInt("router.defaultLanguage_Id"));
								dataObject.setErrorCode(UssdRouterConstants.SERVICE_NOT_FOUND);
								dataObject.setUserData(dataObject.ussdErrorCodeBean.getErrorStr());
								dataObject.setOpCode(UssdRouterConstants.PSSR_RESP);
								status = -1;
								break;
							}*/
							
							shortCode = dataObject.getUserData();
							if(shortCode.startsWith("*") || shortCode.startsWith("#"))
							{
							firstDigit = shortCode.substring(0,1);
							}
							logger.debug("First Digit is["+firstDigit+"]");
							if(shortCode.contains("*"))
							{
								shortCode = this.ussdUtils.getShortCode(shortCode,"*");
							}
							if(shortCode.contains("#"))
							{
								shortCode = this.ussdUtils.getShortCode(shortCode,"#");
							}
							if(firstDigit.startsWith("*") || firstDigit.startsWith("#"))
							{
							shortCode = firstDigit+shortCode;
							}
							logger.info("##>>msisdn["+dataObject.getMsisdn()+"] shortCode["+shortCode+"] UserData["+dataObject.getUserData()+"]");
							dataObject.ussdServiceCodeBean = this.ussdUtils.getUssdServiceCode(shortCode);
							if(dataObject.ussdServiceCodeBean==null)
							{
								//short code not valid...
								logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Dialed String Defination Not Found ShortCode");
								dataObject.ussdErrorCodeBean = this.ussdUtils.getErrorMessage("1_"+UssdRouterMainClient.config.getInt("router.defaultLanguage_Id"));
								dataObject.setErrorCode(UssdRouterConstants.SERVICE_NOT_FOUND);
								dataObject.setUserData(dataObject.ussdErrorCodeBean.getErrorStr());
								dataObject.setOpCode(UssdRouterConstants.PSSR_RESP);
								status = -1;
								break;
								//sendResponse
							}
							dataObject.ussdServiceCodeBean.setServiceType(RouterCommonConstants.PULL_SERVICE);
							//Putting request data into request map, it is remove from it when sending response by router response sender thread.
							this.requestMap.put(dataObject.getDlgId() , dataObject);
							logger.info("##>>msisdn["+dataObject.getMsisdn()+"] ratePlanId["+dataObject.ussdServiceCodeBean.getRatePlanId()+"] ServiceType["+dataObject.ussdServiceCodeBean.getServiceType()+"]");
							if(dataObject.ussdServiceCodeBean.getRatePlanId()>0 && dataObject.ussdServiceCodeBean.getServiceType().equals("EXE"))
							{
								logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Charging Enable for shotCode["+shortCode+"] ratePlanId["+dataObject.ussdServiceCodeBean.getRatePlanId()+"]");
								dataObject.ussdRatePlanBean =  this.ussdUtils.getUssdRatePlan(dataObject.ussdServiceCodeBean.getRatePlanId());
								if(dataObject.ussdRatePlanBean ==  null)
								{
									logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Charging Enabled but rate Plan defination Not Found ShortCode ["+shortCode+"]");
									dataObject.ussdErrorCodeBean = this.ussdUtils.getErrorMessage("2_"+UssdRouterMainClient.config.getInt("router.defaultLanguage_Id"));
									dataObject.setErrorCode(UssdRouterConstants.RATE_PLAN_NOT_DEFINED);
									dataObject.setUserData(dataObject.ussdErrorCodeBean.getErrorStr());
									dataObject.setOpCode(UssdRouterConstants.PSSR_RESP);
									status = -1;
									break;
									//sendResponse
								}
								dataObject.setSubType("N");
								dataObject.setChgReqType(1);
								dataObject.setFirstChgReq(true);
								dataObject.setSendRequestToCharging(true);
								
							}
							else
							{
								logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Charging Disabled for ShortCode["+shortCode+"]");
							}
							break;
						}
					case UssdRouterConstants.USSR_REQ :
						{
							logger.info("##>>msisdn["+dataObject.getMsisdn()+"] USSR REQ received");
							if(!dataObject.getDialogIdAlredayExists())
							{
								logger.info("##>>msisdn["+dataObject.getMsisdn()+"] USSR REQ DialogId not already exists, so cannot continue..");
								dataObject.setUserData("PSSR Response");
								dataObject.setErrorCode(UssdRouterConstants.ROUTER_TERMINATED);
								dataObject.setOpCode(UssdRouterConstants.PSSR_RESP);
								status = -1;
							}
							dataObject.setReqCounter((dataObject.getReqCounter()+1));
							break;
						}
					case UssdRouterConstants.TIME_OUT :
						{
							logger.info("##msisdn["+dataObject.getMsisdn()+"] TIME OUT received");
							dataObject.setUserData("Time Out");
							dataObject.setErrorCode(UssdRouterConstants.TIME_OUT_ERROR);
							dataObject.setOpCode(UssdRouterConstants.TIME_OUT);
							status = -1;
							break;
						}
					case UssdRouterConstants.USSN_ACK :
						{
							logger.info("##>msisdn["+dataObject.getMsisdn()+"] USSN ACK received");
							dataObject.setUserData("USSN ACK");
							dataObject.setErrorCode(UssdRouterConstants.USSN_ACK);
							dataObject.setOpCode(UssdRouterConstants.USSN_ACK);
							//also removing from requestMap
							this.requestMap.remove(dataObject.getDlgId());
							logger.info("##>>msisdn["+dataObject.getMsisdn()+"] USSN_ACK received so removing from requestMap..");
							status = -1;
							break;
						}
					case UssdRouterConstants.PSSR_RESP :
						{
							logger.info("##>msisdn["+dataObject.getMsisdn()+"] PSSR RESP received");
							dataObject.setReqCounter((dataObject.getReqCounter()+1));
							dataObject.setUserData("PSSR Response");
							dataObject.setErrorCode(UssdRouterConstants.PSSR_RESP);
							dataObject.setOpCode(UssdRouterConstants.PSSR_RESP);
							status = -1;
							break;
						}
					default :
						{
							logger.info("##>msisdn["+dataObject.getMsisdn()+"] In Else Case");
							dataObject.setReqCounter((dataObject.getReqCounter()+1));
							dataObject.ussdErrorCodeBean = this.ussdUtils.getErrorMessage("1_"+UssdRouterMainClient.config.getInt("router.defaultLanguage_Id"));
							dataObject.setErrorCode(UssdRouterConstants.SERVICE_NOT_FOUND);
							dataObject.setUserData(dataObject.ussdErrorCodeBean.getErrorStr());
							dataObject.setOpCode(UssdRouterConstants.PSSR_RESP);
							status = -1;
							break;
						}
	
					}

				if(status == -1)
				{
					if(dataObject.ussdServiceCodeBean!=null)
					{
					logger.info("##>>msisdn Requerst cannot process further so adding into Response queue having interface ["+dataObject.ussdServiceCodeBean.getInterFaceType()+"]");
					if(dataObject.ussdServiceCodeBean.getInterFaceType().equalsIgnoreCase(RouterCommonConstants.HTTP_SOCKET))
	                                {
	                                
						if(dataObject.getOpCode() == UssdRouterConstants.PSSR_RESP || dataObject.getOpCode() == UssdRouterConstants.TIME_OUT || dataObject.getOpCode() == UssdRouterConstants.USSN_ACK )
						{
							this.ussdUtils.decreaseDialog();
							this.ussdUtils.decreaseCurrentDialogs();
							new Dboperations().storeUSSDAccessLog(dataObject);
						}
									
									/*this.httpResQueue.put(dataObject);*/
									HttpQueueReader httpQueueReader = (HttpQueueReader) UssdRouterMainClient.context.getBean("httpQueueReader");
									httpQueueReader.setDataObject(dataObject);
									this.httpTaskExecutor.execute(httpQueueReader);
									//this.httpReqQueue.put(dataObject);
	                                }
	                                else if(dataObject.ussdServiceCodeBean.getInterFaceType().equalsIgnoreCase(RouterCommonConstants.SMPP_SOCKET))
	                                {
	                                        this.smppResQueue.put(dataObject);
	                                }
	                                else if(dataObject.ussdServiceCodeBean.getInterFaceType().equalsIgnoreCase(RouterCommonConstants.DB_SOCKET))
	                                {
	                                        this.dbResQueue.put(dataObject);
	                                }
					
					}
					else
					{
					       this.routerResQueue.put(dataObject);
					}
				
				}
				else
				{	
					if(dataObject.ussdServiceCodeBean.getInterFaceType().equalsIgnoreCase(RouterCommonConstants.HTTP_SOCKET))
					{
						//this.httpReqQueue.put(dataObject);
						 HttpQueueReader httpQueueReader = (HttpQueueReader) UssdRouterMainClient.context.getBean("httpQueueReader");
	                                        httpQueueReader.setDataObject(dataObject);
	                                        this.httpTaskExecutor.execute(httpQueueReader);
					}
					else if(dataObject.ussdServiceCodeBean.getInterFaceType().equalsIgnoreCase(RouterCommonConstants.SMPP_SOCKET))
					{
						this.smppReqQueue.put(dataObject);
					}
					else if(dataObject.ussdServiceCodeBean.getInterFaceType().equalsIgnoreCase(RouterCommonConstants.DB_SOCKET))
					{
						this.dbReqQueue.put(dataObject);
					}
				}
			}
			else
			{
				int rejectedRequest=Global.rejectedRequest.incrementAndGet();
				logger.info("[REJECTED]## MSISDN:["+dataObject.getMsisdn()+"] current TPS:["+Global.currentTPS+"],Max TPS for this router:["+Global.routersMaxTps+"],Total TPS:["+Global.maxTps+"],Request Time:["+requestTime+"], TPS End Time:["+Global.tpsEndTime+"], Rejected Request:["+rejectedRequest+"]");
				dataObject.setReqCounter((dataObject.getReqCounter()));
				dataObject.ussdErrorCodeBean = this.ussdUtils.getErrorMessage(UssdRouterConstants.SERVER_IS_BUSY+"_"+UssdRouterMainClient.config.getInt("router.defaultLanguage_Id"));
				dataObject.setErrorCode(UssdRouterConstants.SERVER_IS_BUSY);
				dataObject.setUserData(dataObject.ussdErrorCodeBean.getErrorStr());
				dataObject.setOpCode(UssdRouterConstants.PSSR_RESP);
				routerResQueue.put(dataObject);
			}
		}
		catch(Exception exp)
		{
			logger.error("##>>Error occured inside RouterProcessor"+exp);
			
		}
	}

}
/**
 * Added by rahul kumar on 03/04/2018
 */
class DelayTimer extends TimerTask
{
	Logger logger=Logger.getLogger(DelayTimer.class);
	@Override
	public void run() {
		Global.currentTPS.set(0);
		Global.rejectedRequest.set(0);		
		Global.firstRequestTime.set(0);
		Global.tpsStartTime.set(0);
		Global.tpsEndTime.set(0);
		Global.processRequest.set(true);
		logger.info("TPS limit is over for current second and delay time is over so going to [RESET]");
		logger.info("[RESET]>> current TPS:["+Global.currentTPS+"],Max TPS for this Router:["+Global.routersMaxTps+"],Total TPS:["+Global.maxTps+"],Request Time:["+Global.firstRequestTime+"], TPS Start Time:["+Global.tpsStartTime+"], TPS End Time:["+Global.tpsEndTime+"],process Request:["+Global.processRequest+"]");
	}	
}
class ResetRequestTimer extends TimerTask
{
	Logger logger=Logger.getLogger(ResetRequestTimer.class);
	@Override
	public void run() {
		Global.currentTPS.set(1);
		Global.rejectedRequest.set(0);
		Global.processRequest.set(true);
		Global.tpsStartTime.set(Global.firstRequestTime.get());
		long tpsEndTime=Global.firstRequestTime.get()+1000;
		Global.tpsEndTime.set(tpsEndTime);
		logger.info("Previous request and current request time difference is more than 1 second so going to [TIME OUT] and reset TPS to process current request.");
		logger.info("TIMEOUT>> current TPS:["+Global.currentTPS+"],,Max TPS for this Router:["+Global.routersMaxTps+"],Total TPS:["+Global.maxTps+"],Request Time:["+Global.firstRequestTime+"], TPS Start Time:["+Global.tpsStartTime+"], TPS End Time:["+Global.tpsEndTime+"], process Request:["+Global.processRequest+"]");
	}	
}
