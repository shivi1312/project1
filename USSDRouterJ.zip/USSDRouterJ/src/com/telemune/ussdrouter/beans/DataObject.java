package com.telemune.ussdrouter.beans;

import java.util.Date;

public class DataObject {
	
	int preAmount;
    int postAmount;
    int chargingType;
    int tariffId;
    int maxSessionTimeout;
    int pulseRate;
    int chgReqType;
    int maxPulseAllowed;
    int chargeStatus;
    boolean isFirstChgReq;


    int dlgId;
    int opCode;
    int action = -1;
    int errorCode;
    String userData;
    String msisdn;
    String shortCode;
    String sessionId="0";
    String subType;
    String serviceName;
    
    public UssdErrorCodeBean ussdErrorCodeBean = null;
    public UssdServiceCodeBean ussdServiceCodeBean = null;
    public UssdRatePlanBean ussdRatePlanBean = null;
    private Boolean dialogIdAlredayExists = false;
    private Boolean sendRequestToCharging = false;
    private Boolean isPushBase;
    private int redirectionCounter = 0;
    private long reqTime;
    private int reqCounter;
    private Date reqDate;
    
	public int getPreAmount() {
		return preAmount;
	}
	public void setPreAmount(int preAmount) {
		this.preAmount = preAmount;
	}
	public int getPostAmount() {
		return postAmount;
	}
	public void setPostAmount(int postAmount) {
		this.postAmount = postAmount;
	}
	public int getChargingType() {
		return chargingType;
	}
	public void setChargingType(int chargingType) {
		this.chargingType = chargingType;
	}
	public int getTariffId() {
		return tariffId;
	}
	public void setTariffId(int tariffId) {
		this.tariffId = tariffId;
	}
	public int getMaxSessionTimeout() {
		return maxSessionTimeout;
	}
	public void setMaxSessionTimeout(int maxSessionTimeout) {
		this.maxSessionTimeout = maxSessionTimeout;
	}
	public int getPulseRate() {
		return pulseRate;
	}
	public void setPulseRate(int pulseRate) {
		this.pulseRate = pulseRate;
	}
	public int getChgReqType() {
		return chgReqType;
	}
	public void setChgReqType(int chgReqType) {
		this.chgReqType = chgReqType;
	}
	public int getMaxPulseAllowed() {
		return maxPulseAllowed;
	}
	public void setMaxPulseAllowed(int maxPulseAllowed) {
		this.maxPulseAllowed = maxPulseAllowed;
	}
	public int getChargeStatus() {
		return chargeStatus;
	}
	public void setChargeStatus(int chargeStatus) {
		this.chargeStatus = chargeStatus;
	}
	public boolean isFirstChgReq() {
		return isFirstChgReq;
	}
	public void setFirstChgReq(boolean isFirstChgReq) {
		this.isFirstChgReq = isFirstChgReq;
	}
	public int getDlgId() {
		return dlgId;
	}
	public void setDlgId(int dlgId) {
		this.dlgId = dlgId;
	}
	public int getOpCode() {
		return opCode;
	}
	public void setOpCode(int opCode) {
		this.opCode = opCode;
	}
	public int getAction() {
		return action;
	}
	public void setAction(int action) {
		this.action = action;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public String getUserData() {
		return userData;
	}
	public void setUserData(String userData) {
		this.userData = userData;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getShortCode() {
		return shortCode;
	}
	public void setShortCode(String shortCode) {
		this.shortCode = shortCode;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
	public Boolean getDialogIdAlredayExists() {
		return dialogIdAlredayExists;
	}
	public void setDialogIdAlredayExists(Boolean dialogIdAlredayExists) {
		this.dialogIdAlredayExists = dialogIdAlredayExists;
	}
	
	public Boolean getSendRequestToCharging() {
		return sendRequestToCharging;
	}
	public void setSendRequestToCharging(Boolean sendRequestToCharging) {
		this.sendRequestToCharging = sendRequestToCharging;
	}
	public Boolean getIsPushBase() {
		return isPushBase;
	}
	public void setIsPushBase(Boolean isPushBase) {
		this.isPushBase = isPushBase;
	}
	
	public int getRedirectionCounter() {
		return redirectionCounter;
	}
	public void setRedirectionCounter(int redirectionCounter) {
		this.redirectionCounter = redirectionCounter;
	}
	public long getReqTime() {
		return reqTime;
	}
	public void setReqTime(long reqTime) {
		this.reqTime = reqTime;
	}
	public int getReqCounter() {
		return reqCounter;
	}
	public void setReqCounter(int reqCounter) {
		this.reqCounter = reqCounter;
	}
	public Date getReqDate() {
		return reqDate;
	}
	public void setReqDate(Date reqDate) {
		this.reqDate = reqDate;
	}
	public UssdServiceCodeBean getUssdServiceCodeBean() {
		return ussdServiceCodeBean;
	}
	public void setUssdServiceCodeBean(UssdServiceCodeBean ussdServiceCodeBean) {
		this.ussdServiceCodeBean = ussdServiceCodeBean;
	}
	@Override
	public String toString() {
		return "DataObject [preAmount=" + preAmount + ", postAmount="
				+ postAmount + ", chargingType=" + chargingType + ", tariffId="
				+ tariffId + ", maxSessionTimeout=" + maxSessionTimeout
				+ ", pulseRate=" + pulseRate + ", chgReqType=" + chgReqType
				+ ", maxPulseAllowed=" + maxPulseAllowed + ", chargeStatus="
				+ chargeStatus + ", isFirstChgReq=" + isFirstChgReq
				+ ", dlgId=" + dlgId + ", opCode=" + opCode + ", action="
				+ action + ", errorCode=" + errorCode + ", userData="
				+ userData + ", msisdn=" + msisdn + ", shortCode=" + shortCode
				+ ", sessionId=" + sessionId + ", subType=" + subType
				+ ", serviceName=" + serviceName + ", ussdErrorCodeBean="
				+ ussdErrorCodeBean + ", ussdServiceCodeBean="
				+ ussdServiceCodeBean + ", ussdRatePlanBean="
				+ ussdRatePlanBean + ", dialogIdAlredayExists="
				+ dialogIdAlredayExists + ", sendRequestToCharging="
				+ sendRequestToCharging + ", isPushBase=" + isPushBase
				+ ", redirectionCounter=" + redirectionCounter + ", reqTime="
				+ reqTime + ", reqCounter=" + reqCounter + ", reqDate="
				+ reqDate + "]";
	}
	

	
    
    

}
