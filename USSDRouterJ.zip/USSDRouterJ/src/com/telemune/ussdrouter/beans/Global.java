package com.telemune.ussdrouter.beans;

import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import com.google.common.util.concurrent.AtomicDouble;
import com.telemune.ussdrouter.UssdRouterMainClient;

public class Global {

	public static ConcurrentHashMap<String, UssdMenuBean> ussdMenuMap = new ConcurrentHashMap<String, UssdMenuBean>();
	public static ConcurrentHashMap<String, UssdServiceCodeBean> ussdServiceCodeMap = new ConcurrentHashMap<String, UssdServiceCodeBean>();
	public static ConcurrentHashMap<Integer, UssdRatePlanBean> ussdRatePlanMap = new ConcurrentHashMap<Integer, UssdRatePlanBean>();
	public static ConcurrentHashMap<String, UssdErrorCodeBean> ussdErrorCodeMap = new ConcurrentHashMap<String, UssdErrorCodeBean>();
	public static long increaseDialog = 0;
	/**
	 * 
	 * @Auther rahul
	 * Created On Mar 29, 2018
	 */
	public static AtomicInteger minDialogs=new AtomicInteger(0);
	public static AtomicInteger maxDialogs=new AtomicInteger(0);
	public static AtomicInteger currentDialogs=new AtomicInteger(0);
	
	public static AtomicInteger currentTPS=new AtomicInteger(0);
	public static AtomicInteger maxTps=new AtomicInteger(0);
	public static AtomicBoolean processRequest=new AtomicBoolean(true);
	public static AtomicInteger rejectedRequest=new AtomicInteger(0);
	public static AtomicLong tpsStartTime=new AtomicLong();
	public static AtomicLong tpsEndTime=new AtomicLong();
	public static AtomicLong firstRequestTime=new AtomicLong();
	
	public static AtomicBoolean needToStopHttpThread=new AtomicBoolean(false);
	public static AtomicBoolean needToStopThread=new AtomicBoolean(false);
	public static AtomicBoolean httpSocketFound=new AtomicBoolean(false);
	public static Socket httpSocket = null;
	
	public static AtomicBoolean newHttpSocket=new AtomicBoolean(false);
	public static AtomicBoolean newHttpResponseSocket=new AtomicBoolean(false);
	
	public static AtomicDouble routerServerCount=new AtomicDouble();
	public static AtomicInteger routersMaxTps=new AtomicInteger(0);
	public static AtomicDouble tpsAlertPercentage=new AtomicDouble();
	public static AtomicDouble tpsAlertLimit=new AtomicDouble();
	
	
	
}
