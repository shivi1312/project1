package com.telemune.ussdrouter.beans;

public class UssdRatePlanBean {

	private int id;
	private String chargeType;
	private String tarrifId;
	private int maxSessionTime;
	private int pulseRate;
	private float amountPre;
	private float amountPost;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getChargeType() {
		return chargeType;
	}
	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}
	public String getTarrifId() {
		return tarrifId;
	}
	public void setTarrifId(String tarrifId) {
		this.tarrifId = tarrifId;
	}
	public int getMaxSessionTime() {
		return maxSessionTime;
	}
	public void setMaxSessionTime(int maxSessionTime) {
		this.maxSessionTime = maxSessionTime;
	}
	public int getPulseRate() {
		return pulseRate;
	}
	public void setPulseRate(int pulseRate) {
		this.pulseRate = pulseRate;
	}
	public float getAmountPre() {
		return amountPre;
	}
	public void setAmountPre(float amountPre) {
		this.amountPre = amountPre;
	}
	public float getAmountPost() {
		return amountPost;
	}
	public void setAmountPost(float amountPost) {
		this.amountPost = amountPost;
	}
	public String toString() {
		return "UssdRatePlanBean [id=" + id + ", chargeType=" + chargeType
				+ ", tarrifId=" + tarrifId + ", maxSessionTime="
				+ maxSessionTime + ", pulseRate=" + pulseRate + ", amountPre="
				+ amountPre + ", amountPost=" + amountPost + "]";
	}
	
	
	
	

}
