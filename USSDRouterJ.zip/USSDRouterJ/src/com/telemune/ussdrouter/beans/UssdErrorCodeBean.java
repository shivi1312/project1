package com.telemune.ussdrouter.beans;

public class UssdErrorCodeBean {
	private int langId;
    private int errorCode;
    private String errorStr;

    
    public int getLangId() {
	return langId;
}
public void setLangId(int langId) {
	this.langId = langId;
}
public int getErrorCode() {
	return errorCode;
}
public void setErrorCode(int errorCode) {
	this.errorCode = errorCode;
}
public String getErrorStr() {
	return errorStr;
}
public void setErrorStr(String errorStr) {
	this.errorStr = errorStr;
}
public String toString() {
	return "UssdErrorCodeBean [langId=" + langId + ", errorCode=" + errorCode
			+ ", errorStr=" + errorStr + "]";
}
   
   

}
