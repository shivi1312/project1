package com.telemune.ussdrouter.beans;

public class UssdServiceCodeBean {
	private String code;
	private String serviceName;
	private String userName;
	private String interFaceType;
	private String serviceType;
	private int ratePlanId;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getInterFaceType() {
		return interFaceType;
	}
	public void setInterFaceType(String interFaceType) {
		this.interFaceType = interFaceType;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public int getRatePlanId() {
		return ratePlanId;
	}
	public void setRatePlanId(int ratePlanId) {
		this.ratePlanId = ratePlanId;
	}
	public String toString() {
		return "UssdServiceCodeBean [code=" + code + ", serviceName="
				+ serviceName + ", userName=" + userName + ", interFaceType="
				+ interFaceType + ", serviceType=" + serviceType
				+ ", ratePlanId=" + ratePlanId + "]";
	}
	
	
	
	

}
