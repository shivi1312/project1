package com.telemune.ussdrouter.beans;

public class UssdMenuBean {

	private String code;
	private String menuStr;
	private String activity;
	private int actionId;
	private int numItems;
	private String interFaceType;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMenuStr() {
		return menuStr;
	}
	public void setMenuStr(String menuStr) {
		this.menuStr = menuStr;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public int getActionId() {
		return actionId;
	}
	public void setActionId(int actionId) {
		this.actionId = actionId;
	}
	public int getNumItems() {
		return numItems;
	}
	public void setNumItems(int numItems) {
		this.numItems = numItems;
	}
	public String getInterFaceType() {
		return interFaceType;
	}
	public void setInterFaceType(String interFaceType) {
		this.interFaceType = interFaceType;
	}
	@Override
	public String toString() {
		return "UssdMenuBean [code=" + code + ", menuStr=" + menuStr
				+ ", activity=" + activity + ", actionId=" + actionId
				+ ", numItems=" + numItems + ", interFaceType=" + interFaceType
				+ "]";
	}
	
	
	
}
