package com.telemune.ussdrouter.db;


import java.io.File;
import java.sql.Types;
import java.util.List;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.DefaultConfigurationBuilder;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.ussdrouter.UssdRouterMainClient;
import com.telemune.ussdrouter.beans.Global;
import com.telemune.ussdrouter.beans.UssdErrorCodeBean;
import com.telemune.ussdrouter.beans.UssdMenuBean;
import com.telemune.ussdrouter.beans.UssdRatePlanBean;
import com.telemune.ussdrouter.beans.UssdServiceCodeBean;
import com.telemune.ussdrouter.rowmapper.UssdErrorCodeRowMapper;
import com.telemune.ussdrouter.rowmapper.UssdMenuRowMapper;
import com.telemune.ussdrouter.rowmapper.UssdRatePlanRowMapper;
import com.telemune.ussdrouter.rowmapper.UssdServiceCodeRowMapper;
import com.telemune.ussdrouter.util.CommonQueryConstants;




public class CacheLoader implements Runnable{
	
	private Logger logger = Logger.getLogger(CacheLoader.class);
	
	public CacheLoader() {
		logger.debug("Data Source isnide Cache loader ");
	}
	
		
	public void run() {
		logger.debug("CacheLoader thread start successfully run method working..");
		while(true)
		{
		try
		{
			/**
			 * Validating thread to stop
			 *  Added by Rahul kumar on 19/01/1018
			 */
			if(Global.needToStopThread.get())
			{
				break;
			}
			int databaseType=UssdRouterMainClient.config.getInt("router.database_type");
			CommonQueryConstants.constructQuery(databaseType);
			//loadUssdServiceMenu();
			loadUssdServiceCode();
			loadRatePlan();
			loadErrorCodes();
			insertUsagesLog();
			/* Commented By Richard on 25thMarch 2019
			 * 
			 * loadProperties();*/
			logger.debug("Going to sleep inisde cache thread,needToStopThread["+Global.needToStopThread+"]");
			Thread.sleep(UssdRouterMainClient.config.getInt("router.cacheThread_SleepTime")*1000); 
		}
		catch(Exception exp)
		{
			logger.error("##>>Error occured inside CacheLoader"+exp);
		}
		}
		
	}
	
	private void loadUssdServiceMenu(){
		JdbcTemplate jdbcTemplate = null;
		//String query = "";
		List<UssdMenuBean> ussdMenuList = null;
	
		try
		{
			//query = "select CODE,MENU_STRING,ACTIVITY,ACTION_ID,NUM_ITEMS,INTERFACE_TYPE from USSD_SERVICE_MENU";
			jdbcTemplate = (JdbcTemplate) UssdRouterMainClient.context.getBean("jdbcTemplate");
			ussdMenuList = jdbcTemplate.query(CommonQueryConstants.SELECT_SEVICE_MENU, new Object[]{},(UssdMenuRowMapper) UssdRouterMainClient.context.getBean("ussdMenuRowMapper"));
			logger.info("ussdMenuList got from jdbc template having size["+ussdMenuList.size()+"]");
			for(UssdMenuBean ussdMenuBean : ussdMenuList){
				Global.ussdMenuMap.put(ussdMenuBean.getCode().trim(), ussdMenuBean);
				
			}
			logger.info("Global.ussdMenuMap size is ["+Global.ussdMenuMap.size()+"]");
			
		}
		catch(Exception exp)
		{
			logger.error("##>>Error occured inside loadUssdServiceMenu"+exp);
			
		}
	}
	
	private void loadUssdServiceCode(){
		JdbcTemplate jdbcTemplate = null;
		//String query = "";
		List<UssdServiceCodeBean> ussdServiceCodeList = null;
		try
		{
			//query = "select a.CODE,a.SERVICE_NAME,b.USER_NAME,b.INTERFACE_TYPE,b.SERVICE_TYPE,a.rate_plan_id from USSD_SERVICE_CODE a,USSD_USERS b where a.USER_ID=b.USER_ID";
			jdbcTemplate = (JdbcTemplate) UssdRouterMainClient.context.getBean("jdbcTemplate");
            ussdServiceCodeList = jdbcTemplate.query(CommonQueryConstants.SELECT_SERVICE_CODE , new Object[] {} , (UssdServiceCodeRowMapper) UssdRouterMainClient.context.getBean("ussdServiceCodeRowMapper"));
        	logger.info("ussdServiceCodeList got from jdbc template having size["+ussdServiceCodeList.size()+"]");
    		
            for(UssdServiceCodeBean ussdServiceCodeBean : ussdServiceCodeList){
            	Global.ussdServiceCodeMap.put(ussdServiceCodeBean.getCode().trim(), ussdServiceCodeBean);
            }
            logger.info("Global.ussdServiceCodeMap size is ["+Global.ussdServiceCodeMap.size()+"]");
		}
		catch(Exception exp)
		{
			logger.error("##>>Error occured inside loadUssdServiceCode"+exp);
			
		}
		
		
	}
	
	private void loadRatePlan(){
		JdbcTemplate jdbcTemplate = null;
		//String query = "";
		List<UssdRatePlanBean> ussdRatePlanList = null;
		try
		{
			//query = "select a.id , a.CHARGE_TYPE ,a.TARRIF_ID,  a.MAX_SESSION_TIME, a.PULSE_RATE , b.AMOUNT_PRE , b.AMOUNT_POST from RATE_PLAN a , TARRIF_DETAIL b where a.tarrif_id=b.tarrif_code";
			jdbcTemplate = (JdbcTemplate) UssdRouterMainClient.context.getBean("jdbcTemplate");
			ussdRatePlanList = jdbcTemplate.query(CommonQueryConstants.SELECT_RATE_PLAN , new Object[] {} , (UssdRatePlanRowMapper) UssdRouterMainClient.context.getBean("ussdRatePlanRowMapper"));
			logger.info("ussdRatePlanList got from jdbc template having size["+ussdRatePlanList.size()+"]");
			for(UssdRatePlanBean ussdRatePlanBean : ussdRatePlanList){
				Global.ussdRatePlanMap.put(ussdRatePlanBean.getId(), ussdRatePlanBean);
			}
			logger.info("Global.ussdRatePlanMap size is ["+Global.ussdRatePlanMap.size()+"]");
		}
		catch(Exception exp)
		{
			logger.error("##>>Error occured inside loadRatePlan"+exp);
			
		}
		
		
	}
	
	private void loadErrorCodes(){
		JdbcTemplate jdbcTemplate = null;
		//String query = "";
		List<UssdErrorCodeBean> ussdErrorCodeList = null;
		try
		{
			//query = "select LANG_ID, ERR_CODE, ERR_STR from USSD_ERROR_CODE";
			jdbcTemplate = (JdbcTemplate) UssdRouterMainClient.context.getBean("jdbcTemplate");
			ussdErrorCodeList = jdbcTemplate.query(CommonQueryConstants.SELECT_ERROR_CODE, new Object[] {}, (UssdErrorCodeRowMapper) UssdRouterMainClient.context.getBean("ussdErrorCodeRowMapper"));
			logger.info("ussdErrorCodeList got from jdbc template having size["+ussdErrorCodeList.size()+"]");
			for(UssdErrorCodeBean ussdErrorCodeBean : ussdErrorCodeList){
				Global.ussdErrorCodeMap.put(ussdErrorCodeBean.getErrorCode()+"_"+ussdErrorCodeBean.getLangId(), ussdErrorCodeBean);
			}
			logger.info("Global.ussdErrorCodeMap size is ["+Global.ussdErrorCodeMap.size()+"]");
		}
		catch(Exception exp)
		{
			logger.error("##>>Error occured inside loadErrorCodes"+exp);
			
		}
		
		
	}
	
	/**
	 * Added by Rahul Kumar on 29/03/2018
	 * 
	 */
	public void insertUsagesLog()
	{
		JdbcTemplate jdbcTemplate = null;
		try
		{
			jdbcTemplate = (JdbcTemplate) UssdRouterMainClient.context.getBean("jdbcTemplate");
			int serverInstanceId=UssdRouterMainClient.config.getInt("router.server_instance_id");
			int minDialogs=Global.minDialogs.get();
			int maxDialogs=Global.maxDialogs.get();
			int currentDialogs=Global.currentDialogs.get();
			logger.info("##>>Inside insertUsagesLog() minDialogs:["+minDialogs+"],maxDialogs:["+maxDialogs+"],serverInstanceId["+serverInstanceId+"] and query["+CommonQueryConstants.USSD_USAGE_LOG+"]");
			Object[] usageParams = new Object[]{maxDialogs,minDialogs,serverInstanceId};
			int[] usageParamsType = new int[] {Types.INTEGER,Types.INTEGER,Types.INTEGER};
			int result = jdbcTemplate.update(CommonQueryConstants.USSD_USAGE_LOG, usageParams, usageParamsType);
			logger.info("Query result is["+result+"]");
			Global.minDialogs.set(currentDialogs);
			Global.maxDialogs.set(currentDialogs);
		}
		catch(Exception e)
		{
			logger.error("Exception while insertUsagesLog ["+e+"]");
		}
		
		
	}
	/*
	 * Commented By Richard Bux on 25th March 2019
	 * Its of no use. We are already loading properties 
	 * from static area in MainClient.
	 * 
	public void loadProperties()
	{

		try {
			PropertyConfigurator.configure("properties/UssdRouter_log.properties");
			DefaultConfigurationBuilder builder = new DefaultConfigurationBuilder();
			builder.setFile(new File("config.xml"));
			UssdRouterMainClient.config = builder.getConfiguration(true);
				logger.info("Configuration file loaded successfully..");
		} catch (ConfigurationException ce) {
			logger.error("Error occured while loading configuration file"+ce);
		} catch (Exception e) {
			logger.error("Error occured while loading configuration file"+e);
		}
	
	}*/
	
	
}
