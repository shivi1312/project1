package com.telemune.ussdrouter.db;

import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.ussdrouter.UssdRouterMainClient;
import com.telemune.ussdrouter.beans.DataObject;
import com.telemune.ussdrouter.util.CommonQueryConstants;


public class Dboperations {

	private Logger logger = Logger.getLogger(Dboperations.class);
	
	public int storeUSSDAccessLog(DataObject dataObject)
	{
		logger.debug("##>>msisdn["+dataObject.getMsisdn()+"] inside storeUSSDAccessLog ...");
		JdbcTemplate jdbcTemplate = null;
		//String query = "";
		try
		{
			SimpleDateFormat format = (SimpleDateFormat) UssdRouterMainClient.context.getBean("simpleDateFormat");
			String reqDate = format.format(dataObject.getReqDate());
			long diff = System.currentTimeMillis() - dataObject.getReqTime();
			double sessionDuration=0.0;
			if(diff>0)
			{
				diff=diff/1000;
			}			
			int errorCode = 0;
			if(dataObject.getErrorCode()>0)
			{
				errorCode=dataObject.getErrorCode();
			}
			/*if(dataObject.ussdErrorCodeBean != null)
				{
				 errorCode  = dataObject.ussdErrorCodeBean.getErrorCode();
				}*/
			//query = "insert into USSD_SESSION_LOG (MSISDN,SERVICE_CODE,USER_NAME,INTERFACE_TYPE,DIALOGUE_ID,REQUEST_TIME,NO_OF_COMPONENTS,ERROR_CODE,SERVICE_TYPE,SESSION_DURATION,ACTION_ID) values(?,?,?,?,?,TO_DATE(?,'DD-MM-YYYY HH24:MI:ss'),?,?,?,?,?)";
			jdbcTemplate = (JdbcTemplate) UssdRouterMainClient.context.getBean("jdbcTemplate");
			
			logger.info("jdbcTemplate["+jdbcTemplate+"] msisdn["+dataObject.getMsisdn()+"] code["+dataObject.ussdServiceCodeBean.getCode()+"] UserName["+dataObject.ussdServiceCodeBean.getUserName()+"] InterFaceType["+dataObject.ussdServiceCodeBean.getInterFaceType()+"] DlgId["+dataObject.getDlgId()+"] ReqTime["+ dataObject.getReqTime()+"] ReqCounter["+dataObject.getReqCounter()+"] ErrorCode["+dataObject.getErrorCode()+"] ServiceType["+dataObject.ussdServiceCodeBean.getServiceType()+"] reqDate["+reqDate+"] getAction["+dataObject.getAction()+"] diff["+diff+"]");

			int result = jdbcTemplate.update(
					CommonQueryConstants.USSD_SESSION_LOG,
					new Object[] { dataObject.getMsisdn() , dataObject.ussdServiceCodeBean.getCode(), dataObject.ussdServiceCodeBean.getUserName() ,
								   dataObject.ussdServiceCodeBean.getInterFaceType() , dataObject.getDlgId() , reqDate , dataObject.getReqCounter() ,
								   errorCode , dataObject.ussdServiceCodeBean.getServiceType() , diff , dataObject.getAction() });

			logger.info("##>>msidn["+dataObject.getMsisdn()+"] logs inserted successfully...");
			return result;
		}
		catch(Exception exp)
		{
			logger.error("##>>msisdn["+dataObject.getMsisdn()+"] Error occured inside  storeUSSDAccessLog"+exp);
		}
		return -1;
	}
}
