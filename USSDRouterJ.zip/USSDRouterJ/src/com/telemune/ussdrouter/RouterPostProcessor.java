package com.telemune.ussdrouter;

import java.util.Date;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.beans.DataObject;
import com.telemune.ussdrouter.db.Dboperations;
import com.telemune.ussdrouter.util.RouterCommonConstants;
import com.telemune.ussdrouter.util.UssdUtils;

public class RouterPostProcessor implements Runnable{
	private Logger logger = Logger.getLogger(RouterPostProcessor.class);
	private ArrayBlockingQueue routerResQueue = null;
	private ConcurrentHashMap requestMap = null;
	private ArrayBlockingQueue httpReqQueue = null;
	private ArrayBlockingQueue routerReqQueue = null;
	private UssdUtils ussdUtils = null;
	private DataObject dataObject = null;
	private Dboperations dpOperations = null;

	private ThreadPoolExecutor requestTaskExecutor = null;
	private RequestRejectedWork requestRejectedWork = null;
	private ThreadPoolExecutor httpTaskExecutor = null; 
	private HttpRejectedWork httpRejectedWork = null;
	
	
	public RouterPostProcessor() {
	}
	
	public RouterPostProcessor(ArrayBlockingQueue routerResQueue , ConcurrentHashMap requestMap , UssdUtils ussdUtils , ArrayBlockingQueue httpReqQueue , ArrayBlockingQueue routerReqQueue , Dboperations dpOperations , ThreadPoolExecutor requestTaskExecutor , RequestRejectedWork requestRejectedWork , ThreadPoolExecutor httpTaskExecutor , HttpRejectedWork httpRejectedWork) {
		this.routerResQueue = routerResQueue;
		this.requestMap = requestMap;
		this.ussdUtils = ussdUtils;
		this.httpReqQueue = httpReqQueue;
		this.routerReqQueue = routerReqQueue;
		this.dpOperations = dpOperations;
		
		this.requestTaskExecutor = requestTaskExecutor;
		this.requestRejectedWork = requestRejectedWork;
		this.requestTaskExecutor.setRejectedExecutionHandler(this.requestRejectedWork);
		this.httpTaskExecutor = httpTaskExecutor;
		this.httpRejectedWork = httpRejectedWork;
		this.httpTaskExecutor.setRejectedExecutionHandler(this.httpRejectedWork);


	}
	
	
	public DataObject getDataObject() {
		return dataObject;
	}

	public void setDataObject(DataObject dataObject) {
		this.dataObject = dataObject;
	}

	public void run() {
		try
		{
		int status = -1;
		int sendResponse = 1;
		String firstDigit = "NA";
		if(dataObject.getIsPushBase()==null)
		{
			dataObject.setIsPushBase(false);
		}
		logger.info("##>>msisdn["+dataObject.getMsisdn()+"] RouterPostProcessor Method called DialogIdAlredayExists["+dataObject.getDialogIdAlredayExists()+"] IsPushBase["+dataObject.getIsPushBase()+"]");
		boolean itrFound = false; 
		if(dataObject.getDialogIdAlredayExists())
		{
			if(dataObject.getOpCode() == UssdRouterConstants.PSSR_RESP || dataObject.getOpCode() == UssdRouterConstants.USSN_REQ)
			{
				
				this.requestMap.remove(dataObject.getDlgId());
				status = 1;
			}
			else if(dataObject.getOpCode() == UssdRouterConstants.TIME_OUT || dataObject.getOpCode() == UssdRouterConstants.USSN_ACK)
			{
				itrFound = true;
			}
		}
		
		if(dataObject.getIsPushBase())
		{
			logger.debug("##>>msisdn["+dataObject.getMsisdn()+"] isPushBase enable ...");
			this.ussdUtils.increaseDialog();
			this.ussdUtils.increaseCurrentDialogs();
			dataObject.setReqCounter(1);
			Date date = (Date) UssdRouterMainClient.context.getBean("reqTime");
			dataObject.setReqDate(date);
			dataObject.setReqTime(System.currentTimeMillis());
			if(dataObject.getShortCode().startsWith("*"))
			{
			firstDigit = dataObject.getShortCode().substring(0,1);
			}
			logger.debug("First Digit is["+firstDigit+"]");
			String shortCode = this.ussdUtils.getShortCode(dataObject.getShortCode(), "*");
			if(firstDigit.startsWith("*"))
			{
			shortCode = firstDigit+shortCode;
			}
			logger.info("##>>msisdn["+dataObject.getMsisdn()+"] PUSH case shortCode["+shortCode+"]");
			dataObject.ussdServiceCodeBean = this.ussdUtils.getUssdServiceCode(shortCode);
			dataObject.ussdServiceCodeBean.setServiceType(RouterCommonConstants.PUSH_SERVICE);
			this.requestMap.put(dataObject.getDlgId(), dataObject);// updating ConcurrentHashMap
			status = 1 ;
			
		}
		else if(dataObject.getOpCode() == UssdRouterConstants.PSSR_RESP || dataObject.getOpCode() == UssdRouterConstants.TIME_OUT || dataObject.getOpCode() == UssdRouterConstants.USSN_ACK || dataObject.getOpCode() == UssdRouterConstants.REDIRECT_REQ)
		{
			this.ussdUtils.decreaseDialog();
			this.ussdUtils.decreaseCurrentDialogs();
			this.dpOperations.storeUSSDAccessLog(dataObject);
			if(dataObject.getOpCode() == UssdRouterConstants.TIME_OUT || dataObject.getOpCode() == UssdRouterConstants.USSN_ACK)
			{
				if(itrFound)
				{
					this.requestMap.remove(dataObject.getDlgId());
					//this.httpReqQueue.put(dataObject); //sendResponse to Http
				        HttpQueueReader httpQueueReader = (HttpQueueReader) UssdRouterMainClient.context.getBean("httpQueueReader");
                                        httpQueueReader.setDataObject(dataObject);
                                        this.httpTaskExecutor.execute(httpQueueReader);
					status = -1;
					sendResponse = -1;
				}
				else
				{
					//recycleMessage
				}
				
			}
			else if(dataObject.getOpCode() == UssdRouterConstants.REDIRECT_REQ)
			{
				dataObject.setRedirectionCounter((dataObject.getRedirectionCounter()+1));
				if(dataObject.getRedirectionCounter() < UssdRouterMainClient.config.getInt("router.redirectCounter"))
				{
					logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Request of Redirect Counter");
					dataObject.setOpCode(UssdRouterConstants.PSSR_REQ);
					//this.routerReqQueue.put(dataObject);
					RouterProcessor routerProcessor = (RouterProcessor) UssdRouterMainClient.context.getBean("routerProcessor");
                                	routerProcessor.setDataObject(dataObject);
                                	routerProcessor.setHttpTaskExecutor(this.httpTaskExecutor);
                                	requestTaskExecutor.execute(routerProcessor);
	
					status =  -1;
					sendResponse = -1;
				}
				else
				{
					logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Else condition of redirectCounter");
			    	dataObject.ussdErrorCodeBean = this.ussdUtils.getErrorMessage("6_"+UssdRouterMainClient.config.getInt("router.defaultLanguage_Id"));
					dataObject.setUserData(dataObject.ussdErrorCodeBean.getErrorStr());
					dataObject.setOpCode(UssdRouterConstants.PSSR_RESP);
					status = 1;
				}
				
			}
		}
		if(status == 1 || sendResponse == 1)
		{
		logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Going to insert into routerResQueue...");	
		this.routerResQueue.put(dataObject); //sendResponse
		}
		else
		{
		logger.info("##>>msisdn["+dataObject.getMsisdn()+"] not inserting into routerResQueue...");
		}
		
		}
		catch(Exception exp)
		{
			logger.error("##>>Error occured inside RouterPostProcessor"+exp);
			exp.printStackTrace();
		}
						
	}

}
