package com.telemune.ussdrouter;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.beans.DataObject;


public class RouterQueueReader implements Runnable{

	private Logger logger = Logger.getLogger(RouterQueueReader.class);
	private ThreadPoolExecutor requestTaskExecutor = null;
	private ArrayBlockingQueue routerReqQueue = null;
	private RequestRejectedWork requestRejectedWork = null;
	
	public RouterQueueReader() {
	}
	
	public RouterQueueReader(ThreadPoolExecutor requestTaskExecutor,ArrayBlockingQueue routerReqQueue , RequestRejectedWork requestRejectedWork ) {
		this.requestTaskExecutor = requestTaskExecutor;
		this.routerReqQueue = routerReqQueue;
	    this.requestRejectedWork = requestRejectedWork;
	    this.requestTaskExecutor.setRejectedExecutionHandler(this.requestRejectedWork);
	}
	
	public void run() {
		logger.debug("Run Method of RouterQueueReader called successfully ThreadPoolExecutor["+requestTaskExecutor+"] routerReqQueue["+routerReqQueue+"]");
		while(true)
		{
			try
			{
			/*	if(routerReqQueue.isEmpty())
				{
					Thread.sleep(UssdRouterMainClient.config.getInt("router.queueReaderThread_SleepTime")); //should be configurable
				}
				else
				{*/
					//DataObject dataObject = (DataObject) routerReqQueue.poll();
					logger.info("Inside RouterQueueReader going to take element if available ..");
					DataObject dataObject = (DataObject) routerReqQueue.take();
					RouterProcessor routerProcessor = (RouterProcessor) UssdRouterMainClient.context.getBean("routerProcessor");
					routerProcessor.setDataObject(dataObject);
					requestTaskExecutor.execute(routerProcessor);
				/*}*/	
			}
			catch(Exception exp)
			{
				logger.error("##>>Error occured inside RouterQueueReader"+exp);
				
			}
			
		}
		
	}
	
	
			
	
}

