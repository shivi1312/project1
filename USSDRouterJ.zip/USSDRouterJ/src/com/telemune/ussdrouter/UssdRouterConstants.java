package com.telemune.ussdrouter;

public interface UssdRouterConstants {

	
	int PSSR_REQ = 1;
	int PSSR_RESP = 4;
	int USSR_REQ = 2;
	int USSR_RESP = 2;
	int USSN_REQ = 5;
	int USSN_ACK = 6;
	int PUSH_SESSION  = 7;
	int ACTION_REQ  = 9;
	int TIME_OUT = 10;
	int REDIRECT_REQ = 11;

	int TLV_MSISDN = 1;
	int TLV_DATA = 2;
	int TLV_OPCODE = 3;
	int TLV_DLGID = 4;
	int TLV_LOGINMSG = 5;
	int TLV_ACTION = 6;
	int TLV_CODE = 7;
	int TLV_SHORTCODE = 8;
	int TLV_SESSIONID =  10;
	int TLV_NEW_PUSH_SEESION = 11;
	int TLV_ERRORCODE = 14;

	int SUCCESS = 0;
	int SERVICE_NOT_FOUND = 2;
	int SERVER_ERROR = 3;
    int TIME_OUT_ERROR = 4;
	int RATE_PLAN_NOT_DEFINED = 7;
	int LOW_BALANCE = 8;
	int ROUTER_TERMINATED = 9; 
	
	int CHARGING_MSISDN = 2;
	int CHARGING_SUBTYPE_TAG = 7 ;
	int CHARGING_REQUESTTYPE_TAG = 12;
	int CHARGING_TARIFF_TAG = 4;
	int CHARGING_SESSION_TAG = 13;
	int CHARGING_SRVNAME_TAG = 8;
	int CHARGING_SHORTCODE_TAG = 9;
	int CHARGING_AMOUNT_TAG = 11;
	int CHARGING_RESPONSE_TAG = 6;
	
	
	int SERVICE_NOT_AVAILABLE=4;
	int SERVER_IS_BUSY=7;
	
}
