package com.telemune.ussdrouter;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.beans.Global;
import com.telemune.ussdrouter.factorybean.AcceptorInputStreamFactory;

import TlvLib.TLVAppInterface;

public class RouterServerAcceptor implements Runnable{
	private Logger logger = Logger.getLogger(RouterServerAcceptor.class);
	private ServerSocket serverSocket = null;
	private ConcurrentHashMap serverSocketMap = null;
	
	public RouterServerAcceptor() {
		// TODO Auto-generated constructor stub
	}
	
	public RouterServerAcceptor(ServerSocket serverSocket,ConcurrentHashMap serverSocketMap) {
		this.serverSocket = serverSocket;
		this.serverSocketMap = serverSocketMap;
	}
	
	
	public void run() {
		logger.debug("Inside Run Method of RouterServerAcceptor serverSocket["+serverSocket+"]"
							+ "serverSocketMap["+serverSocketMap+"]");
		
		
		while(true)
		{
			try
			{
				/**
				 * Validating thread to stop
				 *  Added by Rahul kumar on 19/01/1018
				 */
				if(Global.needToStopThread.get())
				{
					break;
				}
				//Socket object from server socket that is created by calling bean serverSocket and provide local_port properties
				Socket socket = this.serverSocket.accept();
				// Getting object of input AcceptorInputStreamFactory class and set socket input stream into it. 
				AcceptorInputStreamFactory acceptorInputStreamFactory = (AcceptorInputStreamFactory) UssdRouterMainClient.context.getBean("acceptorInputStreamBean");
				acceptorInputStreamFactory.setInputStream(socket.getInputStream());
				//Getting object of DataInputStream by calling acceptorDataInputStream bean of application context
				DataInputStream dataInputStream = (DataInputStream) UssdRouterMainClient.context.getBean("acceptorDataInputStream");
				//Call the read data method to read data from socket
				readData(socket , dataInputStream);
				
			}	
			catch(Exception exp)
			{
				logger.error("Exception while listing socket "+exp);
			}
			
		}
	}
		
		private void readData(Socket socket ,DataInputStream reader)
		{
			logger.debug("Inside RouterServerAcceptor reading data from ["+socket+"] reader["+reader+"]");
			try
			{
				int dataLen = 0;
				byte dataBuf[] = null;
				int test = 0;
				
				if (socket.isClosed())
				{
					return;
				}
				
				dataBuf = new byte[4];
				if(reader.read(dataBuf,0,4)==-1)
				{
					try
					{
						Thread.sleep(10); //should be configurable
					}
					catch(Exception e) {logger.error("Exception while reading request data"+e); }
				}

				dataLen = dataLen | (dataBuf[0] << 24);
				dataLen = dataLen  | (dataBuf[1] << 16);
				dataLen = dataLen | (dataBuf[2] << 8);
				test=(0x000000ff & dataBuf[3]);
				dataLen = dataLen | test;
				
				if (dataLen == 0)
				{
					Thread.sleep(10);	
				}
				dataBuf = new byte[dataLen];
				reader.read( dataBuf, 0, dataLen);
				//Getting TLVAppInterface object by calling bean id tlvAppInterface of context
				TLVAppInterface tcpReq = (TLVAppInterface) UssdRouterMainClient.context.getBean("tlvAppInterface"); 
				//Decode the data by calling TLVAppInterface object.decode() method.
				tcpReq.decode( new ByteArrayInputStream( dataBuf) ,dataLen );
				if(tcpReq.getData(UssdRouterConstants.TLV_LOGINMSG)!=null)
				{
					String loginMessage = tcpReq.getData(UssdRouterConstants.TLV_LOGINMSG);
					logger.info("inside RouterServerAcceptor loginMessage["+loginMessage+"]");
					if(loginMessage.equalsIgnoreCase("HTTP"))
					{
						logger.info(">>Received Http socket["+socket+"]");
						this.serverSocketMap.put(loginMessage, socket);
					}
					else if(loginMessage.equalsIgnoreCase("SMPP"))
					{
						this.serverSocketMap.put(loginMessage, socket);
					}
					

				}
				
			}
			catch(Exception exp)
			{
				logger.error("Error occured inside RouterServerAcceptor"+exp);
			}
			
		}
	
}
