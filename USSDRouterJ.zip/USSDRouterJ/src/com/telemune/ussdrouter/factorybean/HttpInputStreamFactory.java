package com.telemune.ussdrouter.factorybean;

import java.io.InputStream;

import org.apache.log4j.Logger;

public class HttpInputStreamFactory {
	private Logger logger = Logger.getLogger(HttpInputStreamFactory.class);
	private InputStream inputStream = null;
	
	public InputStream getInputStream() {
		logger.debug("Inside HttpInputStream get["+inputStream+"]");
		return inputStream;
	}

	public void setInputStream(InputStream inputStream) {
		logger.debug("Inside HttpInputStream set["+inputStream+"]");
		this.inputStream = inputStream;
	}
	
	
	

}
