package com.telemune.ussdrouter.factorybean;

import java.io.InputStream;

import org.apache.log4j.Logger;

public class UssdChargingInputStreamFactory {
	private Logger logger = Logger.getLogger(UssdChargingInputStreamFactory.class);
	private InputStream inputStream = null;

	public InputStream getInputStream() {
		logger.debug("Inside UssdCharging InputStreamFactory get["+inputStream+"]");
		return inputStream;
	}

	public void setInputStream(InputStream inputStream) {
		logger.debug("Inside UssdCharging InputStreamFactory set["+inputStream+"]");
		this.inputStream = inputStream;
	}
	
	
	

}
