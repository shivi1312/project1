package com.telemune.ussdrouter.factorybean;

import java.io.InputStream;

import org.apache.log4j.Logger;

public class AcceptorInputStreamFactory {
	private InputStream inputStream = null;
	private Logger logger = Logger.getLogger(AcceptorInputStreamFactory.class);

	public InputStream getInputStream() {
		logger.debug("Server Socket InputStream get ["+inputStream+"]");
		return inputStream;
		
	}

	public void setInputStream(InputStream inputStream) {
		logger.debug("Server Socket InputStream set ["+inputStream+"]");
		this.inputStream = inputStream;
	}
	
	
	

}
