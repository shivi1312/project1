package com.telemune.ussdrouter.factorybean;

import java.io.OutputStream;

import org.apache.log4j.Logger;

public class HttpOutputStreamFactory {
	private Logger logger = Logger.getLogger(HttpOutputStreamFactory.class);
	private OutputStream outputStream = null;

	public OutputStream getOutputStream() {
		logger.debug("####>>>>HttpOutputStream get["+outputStream+"]");
		return outputStream;
	}

	public void setOutputStream(OutputStream outputStream) {
		logger.debug("##>>>HttpOutputStream set["+outputStream+"]");
		this.outputStream = outputStream;
	}
	
	
	

}
