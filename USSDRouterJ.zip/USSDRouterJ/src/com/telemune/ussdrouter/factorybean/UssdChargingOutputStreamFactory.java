package com.telemune.ussdrouter.factorybean;

import java.io.OutputStream;

import org.apache.log4j.Logger;

public class UssdChargingOutputStreamFactory {
	private Logger logger = Logger.getLogger(UssdChargingOutputStreamFactory.class);
	private OutputStream outputStream = null;

	public OutputStream getOutputStream() {
		logger.debug("####>>>>UssdCharging OutputStreamFactory get["+outputStream+"]");
		return outputStream;
	}

	public void setOutputStream(OutputStream outputStream) {
		logger.debug("##>>>UssdCharging OutputStreamFactory set["+outputStream+"]");
		this.outputStream = outputStream;
	}
	
	
	

}
