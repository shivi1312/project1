package com.telemune.ussdrouter;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.util.UssdUtils;

public class DbQueueReader implements Runnable{
 Logger logger=Logger.getLogger(DbQueueReader.class);

private ArrayBlockingQueue dbReqQueue = null;
private UssdUtils ussdUtils = null;
private ConcurrentHashMap serverSocketMap = null;
	
	public DbQueueReader() {
		// TODO Auto-generated constructor stub
	}

	public DbQueueReader(ArrayBlockingQueue dbReqQueue , UssdUtils ussdUtils ,ConcurrentHashMap serverSocketMap ) {
		this.dbReqQueue = dbReqQueue;
		this.ussdUtils = ussdUtils;
		this.serverSocketMap = serverSocketMap;
	}
	
	public void run() {
		
		logger.debug("Inside Run Method of DbQueueReader dbReqQueue["+dbReqQueue+"]");
	}
	
}
