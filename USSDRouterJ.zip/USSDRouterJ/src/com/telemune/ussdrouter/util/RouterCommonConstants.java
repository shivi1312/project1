/**
 * @Auther rahul
 * Created On Feb 28, 2018
 */
package com.telemune.ussdrouter.util;

public interface RouterCommonConstants {
	public static final String HTTP_SOCKET="HTTP";
	public static final String SMPP_SOCKET="SMPP";
	public static final String DB_SOCKET="DB";
	public static final int ORACLE_DB=1;
	public static final int MYSQL_DB=2;
	public static final String PULL_SERVICE="PULL";
	public static final String PUSH_SERVICE="PUSH";
	
}
