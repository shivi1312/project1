/**
 * @Auther rahul
 * Created On Mar 29, 2018
 */
package com.telemune.ussdrouter.util;

import org.apache.log4j.Logger;

public class CommonQueryConstants {	
	static Logger logger=Logger.getLogger(CommonQueryConstants.class);
	public static String USSD_SESSION_LOG;
	public static String USSD_USAGE_LOG;
	public static String SELECT_ERROR_CODE;
	public static String SELECT_RATE_PLAN;
	public static String SELECT_SERVICE_CODE;
	public static String SELECT_SEVICE_MENU;
	
	public static void constructQuery(int databaseType)
	{
		logger.info("Going to constructQuery for database:["+databaseType+"], 1 for ORACLE,2 for MYSQL");
		switch(databaseType)
		{
			case RouterCommonConstants.ORACLE_DB:
					SELECT_ERROR_CODE="select LANG_ID, ERR_CODE, ERR_STR from USSD_ERROR_CODE";
					USSD_SESSION_LOG="insert into USSD_SESSION_LOG (MSISDN,SERVICE_CODE,USER_NAME,INTERFACE_TYPE,DIALOGUE_ID,REQUEST_TIME,NO_OF_COMPONENTS,ERROR_CODE,SERVICE_TYPE,SESSION_DURATION,ACTION_ID) values(?,?,?,?,?,TO_DATE(?,'DD-MM-YYYY HH24:MI:ss'),?,?,?,?,?)";
					USSD_USAGE_LOG="insert into USSD_USAGE_LOG (EVENT_DATE,MAX_NO_OF_DLGS,MIN_NO_OF_DLGS,INSTANCE_ID) values(sysdate,?,?,?)";
					SELECT_RATE_PLAN="select a.id , a.CHARGE_TYPE ,a.TARRIF_ID,  a.MAX_SESSION_TIME, a.PULSE_RATE , b.AMOUNT_PRE , b.AMOUNT_POST from RATE_PLAN a , TARRIF_DETAIL b where a.tarrif_id=b.tarrif_code";
					SELECT_SERVICE_CODE="select a.CODE,a.SERVICE_NAME,b.USER_NAME,b.INTERFACE_TYPE,b.SERVICE_TYPE,a.rate_plan_id from USSD_SERVICE_CODE a,USSD_USERS b where a.USER_ID=b.USER_ID";
					SELECT_SEVICE_MENU="select CODE,MENU_STRING,ACTIVITY,ACTION_ID,NUM_ITEMS,INTERFACE_TYPE from USSD_SERVICE_MENU";
				break;
			case RouterCommonConstants.MYSQL_DB:
					SELECT_ERROR_CODE="select LANG_ID, ERR_CODE, ERR_STR from USSD_ERROR_CODE";
					USSD_SESSION_LOG="insert into USSD_SESSION_LOG (MSISDN,SERVICE_CODE,USER_NAME,INTERFACE_TYPE,DIALOGUE_ID,REQUEST_TIME,NO_OF_COMPONENTS,ERROR_CODE,SERVICE_TYPE,SESSION_DURATION,ACTION_ID) values(?,?,?,?,?,STR_TO_DATE(?,'%d-%m-%Y %H:%i:%s'),?,?,?,?,?)";
					USSD_USAGE_LOG="insert into USSD_USAGE_LOG (EVENT_DATE,MAX_NO_OF_DLGS,MIN_NO_OF_DLGS,INSTANCE_ID) values(now(),?,?,?)";
					SELECT_RATE_PLAN="select a.id , a.CHARGE_TYPE ,a.TARRIF_ID,  a.MAX_SESSION_TIME, a.PULSE_RATE , b.AMOUNT_PRE , b.AMOUNT_POST from RATE_PLAN a , TARRIF_DETAIL b where a.tarrif_id=b.tarrif_code";
					SELECT_SERVICE_CODE="select a.CODE,a.SERVICE_NAME,b.USER_NAME,b.INTERFACE_TYPE,b.SERVICE_TYPE,a.rate_plan_id from USSD_SERVICE_CODE a,USSD_USERS b where a.USER_ID=b.USER_ID";
					SELECT_SEVICE_MENU="select CODE,MENU_STRING,ACTIVITY,ACTION_ID,NUM_ITEMS,INTERFACE_TYPE from USSD_SERVICE_MENU";
				break;
		}
	}
}
