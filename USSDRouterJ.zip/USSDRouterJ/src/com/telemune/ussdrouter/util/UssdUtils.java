package com.telemune.ussdrouter.util;

import java.util.concurrent.atomic.AtomicInteger;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.UssdRouterMainClient;
import com.telemune.ussdrouter.beans.Global;
import com.telemune.ussdrouter.beans.UssdErrorCodeBean;
import com.telemune.ussdrouter.beans.UssdRatePlanBean;
import com.telemune.ussdrouter.beans.UssdServiceCodeBean;


public class UssdUtils {
	
	private Logger logger = Logger.getLogger(UssdUtils.class);
	private AtomicInteger seq = null;
	public UssdUtils(AtomicInteger seq){
		this.seq = seq;

	}	
	public UssdErrorCodeBean getErrorMessage(String errorCode){
		try
		{
			if(Global.ussdErrorCodeMap.containsKey(errorCode))
			{
				return Global.ussdErrorCodeMap.get(errorCode);
			}
		}
		catch(Exception exp)
		{
			logger.error("Error occured inside getErrorMessage"+exp);
		}
		return null;
	}
	
	
	public UssdServiceCodeBean getUssdServiceCode(String serviceCode){
		try
		{
			if(Global.ussdServiceCodeMap.containsKey(serviceCode))
			{
				return Global.ussdServiceCodeMap.get(serviceCode);
			}
		}
		catch(Exception exp)
		{
			logger.error("Error occured inside getUssdServiceCode"+exp);
		}
		return null;
	}
	
	public UssdRatePlanBean getUssdRatePlan(int ratePlanId){
		try
		{
			if(Global.ussdRatePlanMap.containsKey(ratePlanId))
			{
				return Global.ussdRatePlanMap.get(ratePlanId);
			}
		}
		catch(Exception exp)
		{
			logger.error("Error occured inside getUssdRatePlan"+exp);
		}
		return null;
	}
	
	public void increaseDialog(){
		Global.increaseDialog++;
	}
	public void decreaseDialog(){
		Global.increaseDialog--;
	}
	public String getShortCode(String data,String key)
	{
		logger.info("##>>Data["+data+"] key["+key+"]");
		if(data.startsWith("*") || data.startsWith("#"))
		{
			while(data.startsWith(key))
			{
				data = data.substring(1,data.length());	
			}	
			logger.debug("##>> inside loop is Data["+data+"]");
		}
		else
		{
			logger.info("Data ["+data+"] indexOf key["+data.indexOf(key)+"]");
		}
		if((data.contains("*") && key.equals("*"))|| (data.contains("#") && key.equals("#")))
			data = data.substring(0,data.indexOf(key));	
		logger.debug("Data is ["+data+"]");
		if(!data.contains("#"))
		{
			data+="#";
		}
		return data;
	}

	public int getUniqueDialogId(){
		int uniqueValue =  1;
		try
		{
		  uniqueValue = this.seq.incrementAndGet();
		  if(uniqueValue==UssdRouterMainClient.config.getInt("router.max_dialog_id")){
			  this.seq.set(0);
			  uniqueValue = this.seq.incrementAndGet();
		  	}	
		}
		catch(Exception exp)
		{
			logger.error("Exception while geting unique dialog id"+exp);
		}	
		return uniqueValue;
	}
	/**	 * 
	 * @Auther rahul
	 * Created On Mar 29, 2018
	 */
	public void increaseCurrentDialogs()
	{
		int currentValue=Global.currentDialogs.incrementAndGet();
		int maxValue=Global.maxDialogs.get();
		if(currentValue>maxValue)
		{
			Global.maxDialogs.set(currentValue);
		}
	}
	/**	 * 
	 * @Auther rahul
	 * Created On Mar 29, 2018
	 */
	public void decreaseCurrentDialogs()
	{
		int currentValue=Global.currentDialogs.decrementAndGet();
		int minValue=Global.minDialogs.get();
		if(currentValue<minValue)
		{
			Global.minDialogs.set(currentValue);
		}
	}
	
	public String getSessionId(String msisdn)
	{
		String sessionId=null;
		long currentMilies=System.currentTimeMillis();
		sessionId=""+currentMilies;
		//sessionId=sessionId.substring(sessionId, endIndex)
		return sessionId;
	}
	
}
