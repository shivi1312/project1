package com.telemune.ussdrouter.util;
import org.apache.log4j.Logger;

import Decoder.BASE64Decoder;
import Decoder.BASE64Encoder;


public class EncriptDecript{

	static Logger logger= Logger.getLogger(EncriptDecript.class);

	public static String encript(String data)
	{
		logger.info("In encript with data:["+data+"]");
		byte[] encrypted=null;
		String base64 =null;

		try{    
			byte[] dataArr=data.getBytes();
			String encBytes="";
			encrypted = new byte[dataArr.length];
			for(int i=0;i<dataArr.length;i++)
			{   
				encrypted[i]=(byte) (dataArr[i]+100);
				encBytes+=encrypted[i];
			}	

			BASE64Encoder encoder = new BASE64Encoder();
			base64 = encoder.encode(encrypted);

		}
		catch(Exception e)
		{
			logger.error("Error in EncriptDecript's encript():"+e);
		}		
		return base64;
	}

	public static String decript(String data)
	{
		logger.info("In decript() with data:["+data+"]");

		String decrypted =null;
		byte[] base64=null;
		try{
			BASE64Decoder decoder = new BASE64Decoder();
			base64 = decoder.decodeBuffer(data);
			byte[] decArr = new byte[base64.length];
			String decBytes="";
			for(int i=0;i<base64.length;i++)
			{
				decArr[i]=(byte) (base64[i]-100);
				decBytes+=decArr[i];
			}

			decrypted = new String(decArr);
		}
		catch(Exception e)
		{
			logger.error("Error in EncriptDecript's decript():"+e);
		}

		return decrypted;
	}



}

