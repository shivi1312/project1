package com.telemune.ussdrouter;

import java.util.concurrent.ConcurrentHashMap;

public class SendSmppRequest {
 private ConcurrentHashMap serverSocketMap = null;
 
 public SendSmppRequest() {
	// TODO Auto-generated constructor stub
}
 public SendSmppRequest(ConcurrentHashMap serverSocketMap) {
	this.serverSocketMap = serverSocketMap;
}
 
  
	
}
