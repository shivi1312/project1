package com.telemune.ussdrouter;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

public class SmppResponseQueueReader  implements Runnable{
	Logger logger=Logger.getLogger(SmppResponseQueueReader.class);
	private ArrayBlockingQueue smppRespQueue = null;
	private ThreadPoolExecutor responseTaskExecutor = null;
	public SmppResponseQueueReader() {
		// TODO Auto-generated constructor stub
	}
	
	public SmppResponseQueueReader(ArrayBlockingQueue smppResQueue,ThreadPoolExecutor responseTaskExecutor) {
		this.smppRespQueue = smppResQueue;
		this.responseTaskExecutor = responseTaskExecutor;
	}
	
	public void run() {
	
		logger.debug("Inside Run Method of SmppResponseQueueReader ...smppResQueue["+smppRespQueue+"] responseTaskExecutor["+responseTaskExecutor+"]");
	}
}
