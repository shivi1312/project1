package com.telemune.ussdrouter;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.net.Socket;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.beans.DataObject;
import com.telemune.ussdrouter.beans.Global;
import com.telemune.ussdrouter.util.EncriptDecript;

import TlvLib.TLVAppInterface;

public class RouterRequestReader implements Runnable{
	private Logger logger = Logger.getLogger(RouterRequestReader.class);
	private Socket socket = null; 
	private ArrayBlockingQueue routerReqQueue = null;
	private DataInputStream dataInputStream = null;
	private ConcurrentHashMap requestMap = null;
	//new additions
	private ThreadPoolExecutor requestTaskExecutor = null;
	private RequestRejectedWork requestRejectedWork = null;
	
	private ThreadPoolExecutor httpTaskExecutor = null;
	private HttpRejectedWork httpRejectedWork = null;		
	private EncriptDecript ussdEncriptDecript = null;

	//testing parameters
	static int counter = 0;
	long d1;
	long d2;	

	public RouterRequestReader() {
	}
	
	public RouterRequestReader(Socket socket , ArrayBlockingQueue routerReqQueue , DataInputStream dataInputStream , ConcurrentHashMap requestMap , ThreadPoolExecutor requestTaskExecutor, RequestRejectedWork requestRejectedWork , ThreadPoolExecutor httpTaskExecutor , HttpRejectedWork httpRejectedWork , EncriptDecript ussdEncriptDecript) {
		this.socket = socket;
		this.routerReqQueue = routerReqQueue;
		this.dataInputStream = dataInputStream;
		this.requestMap = requestMap;
		this.requestTaskExecutor = requestTaskExecutor;
		this.requestRejectedWork = requestRejectedWork;
	        this.requestTaskExecutor.setRejectedExecutionHandler(this.requestRejectedWork);
		this.httpTaskExecutor = httpTaskExecutor;
                this.httpRejectedWork = httpRejectedWork;
                this.httpTaskExecutor.setRejectedExecutionHandler(this.httpRejectedWork);
		this.ussdEncriptDecript = ussdEncriptDecript;
		
	}
	
	public void run() {
		
		logger.debug("Run Method of RouterRequestReader called successfully...socket["+socket+"] routerReqQueue["+routerReqQueue+"]");
		//this socket is ussd socket
		readPacket(this.socket);
	}
	
	public void readPacket(Socket socket)
	{
		try
		{
			DataObject dataObject = null;
			DataObject dataObjectContinue = null;
			DataInputStream reader = null;
			boolean alreadyExists = false;

			if (socket.isClosed())
			{
				return;
			}
			
			reader = this.dataInputStream;
			
			while(true)
			{
				logger.info("Reading packet.........");
			 byte dataBuf[] = null;
			 int dataLen = 0;
			 int test = 0;
			try
			{
				dataBuf = new byte[4];

				if(reader.read(dataBuf,0,4)==-1)
				{
					try
					{
						/*
						 * Added By Richard on 28th March 2019
						 */
						Thread.sleep(UssdRouterMainClient.config.getInt("RETRY_INTERVAL_AT_END_OF_STREAM_ROUTER",10)); //should be configurable
						if(UssdRouterMainClient.config.getInt("ROUTER_SEND_URGENT_DATA_FLAG",1)==0)
						{
							logger.info("End of Stream detected from USSD Gateway side  >>>>>>>>> Sending Urgent Data..");
							try
							{
								socket.sendUrgentData(1);
							}
							catch(Exception e)
							{
									logger.error("Exception occured when calling socket.sendUrgentData(1) Error["
											+ e
											+ "] Setting NeedToStopThread flag to true");
								Global.needToStopThread.set(true);
								break;
							}
						}
						continue;
					}
					catch(Exception e) {logger.error("Exception while reading router request "+e); }
				}
			
				dataLen = dataLen | (dataBuf[0] << 24);
				dataLen = dataLen  | (dataBuf[1] << 16);
				dataLen = dataLen | (dataBuf[2] << 8);
				test=(0x000000ff & dataBuf[3]);
				dataLen = dataLen | test;
			}
			catch (Exception e)
			{
				logger.error("Exception while reading router request "+e);
				try
				{
					Thread.sleep(1);
					socket.close();
				}
				catch(Exception ex) {	logger.error("Exception while closing socket "+ex);}
				finally
				{
					/*
					 * Added By Richard on 28th March 2019
					 */
					Global.needToStopThread.set(true);
				}
			}

			if (dataLen == 0)
			{	
				try
				{
					Thread.sleep(10); //should be configurable
					/**
					 * Validating thread to stop
					 * Added by Rahul kumar on 19/01/1018
					 */
					logger.debug("Need to stop thread is["+Global.needToStopThread+"]");
					if(Global.needToStopThread.get())
					{
						break;
					}
					continue;
				}
				catch(Exception eee){logger.error("Exception while going to sleep"+eee);}
				
				
			}
         	logger.debug("data Length is ["+dataLen+"]");

			dataBuf = new byte[dataLen];
			reader.read( dataBuf, 0, dataLen);
			TLVAppInterface tcpReq = (TLVAppInterface) UssdRouterMainClient.context.getBean("tlvAppInterface"); 
			tcpReq.decode( new ByteArrayInputStream( dataBuf ) , dataLen );
			dataObject = (DataObject) UssdRouterMainClient.context.getBean("dataObject");
			if(UssdRouterMainClient.config.getInt("router.EncriptDecript_Enable") == 1) //Enable encryption
			{
				dataObject.setUserData(ussdEncriptDecript.decript(tcpReq.getData(UssdRouterConstants.TLV_DATA)));
			}
			else
			{
				dataObject.setUserData(tcpReq.getData(UssdRouterConstants.TLV_DATA));
			}
			dataObject.setMsisdn(tcpReq.getData(UssdRouterConstants.TLV_MSISDN));
			dataObject.setDlgId(Integer.parseInt(tcpReq.getData(UssdRouterConstants.TLV_DLGID)));
			dataObject.setOpCode(Integer.parseInt(tcpReq.getData(UssdRouterConstants.TLV_OPCODE)));
			logger.info("##>msisdn["+dataObject.getMsisdn()+"] Inside RouterRequestReader request Opcode is ["+Integer.parseInt(tcpReq.getData(UssdRouterConstants.TLV_OPCODE))+"]");
			
			
			Set requestSet = requestMap.entrySet();
			Iterator requestItr =  requestSet.iterator();			
			while(requestItr.hasNext()){
				Map.Entry entry = (Map.Entry) requestItr.next();
				Integer requestDialogId = (Integer) entry.getKey();
				if(requestDialogId == dataObject.getDlgId())
				{
					logger.info("##>>msisdn["+dataObject.getMsisdn()+"] RouterRequestReader Request alreday exists with dialogId["+requestDialogId+"] so it is a continue request...");
					dataObjectContinue = (DataObject) entry.getValue();
					dataObjectContinue.setDialogIdAlredayExists(true);
					dataObjectContinue.setUserData(tcpReq.getData(UssdRouterConstants.TLV_DATA));
					dataObjectContinue.setOpCode(Integer.parseInt(tcpReq.getData(UssdRouterConstants.TLV_OPCODE)));
					alreadyExists = true;
					break;
				}
			}
			if(alreadyExists)
			{
				/*routerReqQueue.put(dataObjectContinue);*/
				RouterProcessor routerProcessor = (RouterProcessor) UssdRouterMainClient.context.getBean("routerProcessor");
				routerProcessor.setDataObject(dataObjectContinue);
				routerProcessor.setHttpTaskExecutor(this.httpTaskExecutor);
				requestTaskExecutor.execute(routerProcessor);
				logger.debug("RouterRequestReader DataObject sucessfully added inside routerReqQueue...["+dataObjectContinue+"] dataObject hashCode["+dataObjectContinue.hashCode()+"]");
				alreadyExists = false;
			}
			else
			{	
			/*routerReqQueue.put(dataObject);*/
				RouterProcessor routerProcessor = (RouterProcessor) UssdRouterMainClient.context.getBean("routerProcessor");
				routerProcessor.setDataObject(dataObject);
				routerProcessor.setHttpTaskExecutor(this.httpTaskExecutor);
				requestTaskExecutor.execute(routerProcessor);	 //start routerProcessor thread
			    logger.debug("RouterRequestReader DataObject sucessfully added inside routerReqQueue...["+dataObject+"] dataObject hashCode["+dataObject.hashCode()+"]");

			}
		
			logger.debug("##>>counter["+counter+"]");	
			if(counter == 0)
			{
			 d1 = System.currentTimeMillis();
			 logger.debug("##>>RouterRequestReader strat Time Difference is["+(d1)+"]");		
			}
			if(counter == 100002)
			{
			 d2 = System.currentTimeMillis();
			 logger.debug("##>>RouterRequestReader strat Time Difference Final counter["+counter+"] d2["+d2+"] is["+(d2-d1)+"]"); 
			 counter = 0;	
			}
			else
			{
			counter++;
			}
			tcpReq = null; //going to free TLvAppInterface refrence
			
		}
		}
		catch(Exception e)
		{
			logger.error("Error occured inside RouterRequestReader"+e);
		}
	   
	}


}
