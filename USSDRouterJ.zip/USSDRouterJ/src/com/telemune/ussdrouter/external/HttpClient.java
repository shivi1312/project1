package com.telemune.ussdrouter.external;

public class HttpClient {

}
