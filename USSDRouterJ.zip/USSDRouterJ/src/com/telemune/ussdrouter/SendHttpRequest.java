package com.telemune.ussdrouter;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.beans.DataObject;
import com.telemune.ussdrouter.beans.Global;
import com.telemune.ussdrouter.factorybean.HttpOutputStreamFactory;
import com.telemune.ussdrouter.util.EncriptDecript;
import com.telemune.ussdrouter.util.RouterCommonConstants;
import com.telemune.ussdrouter.util.UssdUtils;

import TlvLib.TLVAppInterface;

public class SendHttpRequest implements Runnable {
	private Logger logger = Logger.getLogger(SendHttpRequest.class);
	private ConcurrentHashMap serverSocketMap = null;
	private ArrayBlockingQueue httpTlvReqQueue = null;	
	//private boolean httpSocketFound = false;
	private DataOutputStream dataOutputStream = null;
	//private Socket httpSocket = null;
	private EncriptDecript ussdEncriptDecript = null;
	private UssdUtils ussdUtils = null;
	private ArrayBlockingQueue routerResQueue = null;
	private boolean httpSocketKilled=false;
	
	
	
	public SendHttpRequest( ) {

	}

	public SendHttpRequest(ArrayBlockingQueue httpTlvReqQueue , ConcurrentHashMap serverSocketMap , EncriptDecript ussdEncriptDecript,UssdUtils ussdUtils,ArrayBlockingQueue routerResQueue) {
		this.httpTlvReqQueue = httpTlvReqQueue;
		this.serverSocketMap = serverSocketMap;
		this.ussdEncriptDecript = ussdEncriptDecript;
		this.ussdUtils=ussdUtils;
		this.routerResQueue=routerResQueue;
	}

	public void run(){
	
		try
		{
			while(true)
			{
				/**
				 * Validating thread to stop
				 * Added by Rahul kumar on 19/01/2018
				 */
				if(Global.needToStopThread.get())
				{
					break;
				}
				//logger.info("needToStopThread["+Global.needToStopThread+"],needToStopHttpThread["+Global.needToStopHttpThread+"] and httpSocketFound["+Global.httpSocketFound+"]");
				if(!Global.httpSocketFound.get())
				{
					logger.info("needToStopThread["+Global.needToStopThread+"],needToStopHttpThread["+Global.needToStopHttpThread+"] and httpSocketFound["+Global.httpSocketFound+"],newHttpSocket:["+Global.newHttpSocket+"]");
					Global.httpSocket=(Socket) serverSocketMap.get(RouterCommonConstants.HTTP_SOCKET);
					if(Global.httpSocket!=null)
					{
						logger.debug("HttpResponseReader already connected so Http Socket is ["+Global.httpSocket+"]");
						Global.httpSocketFound.set(true);
						Global.needToStopHttpThread.set(false);
						/*Commented By Richard on 28th March 2019
						 * break;*/
					}
					else if(!httpTlvReqQueue.isEmpty())
					{
						DataObject dataObject =  (DataObject) this.httpTlvReqQueue.take();
						if(dataObject!=null && !Global.httpSocketFound.get())
						{
							logger.info("##>msisdn["+dataObject.getMsisdn()+"],httpSocketFound:["+Global.httpSocketFound+"] service not found.");
							dataObject.setReqCounter((dataObject.getReqCounter()));
							dataObject.ussdErrorCodeBean = this.ussdUtils.getErrorMessage("4_"+UssdRouterMainClient.config.getInt("router.defaultLanguage_Id"));
							dataObject.setErrorCode(UssdRouterConstants.SERVER_IS_BUSY);
							dataObject.setUserData(dataObject.ussdErrorCodeBean.getErrorStr());
							dataObject.setOpCode(UssdRouterConstants.PSSR_RESP);
							routerResQueue.put(dataObject);
							/*
							 * Commented By Richard on 28th March 2019
							 *
							 * break;
							 * 
							 * */
						}						
					}
					else
					{
						Thread.sleep(UssdRouterMainClient.config.getInt("HTTP_SOCKET_LOOKUP_TIME", 1000));
					}
				}
				else if(Global.httpSocket!=null)
				{
					HttpOutputStreamFactory outputStreamFactory = (HttpOutputStreamFactory) UssdRouterMainClient.context.getBean("httpOutputStreamBean");
					logger.debug("HttpOutputStreamFactory inside HttpQueueReader["+outputStreamFactory+"] httpSocketOutputStream["+Global.httpSocket+"]");
					outputStreamFactory.setOutputStream(Global.httpSocket.getOutputStream());                       
					dataOutputStream = (DataOutputStream) UssdRouterMainClient.context.getBean("httpDataOutputStream");
					//logger.info("needToStopThread["+Global.needToStopThread+"],needToStopHttpThread["+Global.needToStopHttpThread+"] and httpSocketFound["+Global.httpSocketFound+"],newHttpSocket:["+Global.newHttpSocket+"]");
					break;
				}
				
			}
			logger.debug("Inside Run Method of SendHttpRequest httpSocket is ["+Global.httpSocket+"]");
		}
		catch(Exception exp)
		{
			logger.error("##>>Error occured inside SendHttpRequest Run method"+exp);
			
		}
		while(true)
		{
			try
			{
				/**
				 * Validating thread to stop
				 * Added by Rahul kumar on 19/01/2018
				 */
				if(Global.needToStopThread.get())
				{
					break;
				}
				logger.info("##>>Going to get element from http queue inside SendHttpRequest,needToStopHttpThread ["
						+ Global.needToStopHttpThread
						+ "] and httpSocketFound["
						+ Global.httpSocketFound
						+ "], Http Queue isEmpty:["
						+ httpTlvReqQueue.isEmpty()
						+ "]");
			  DataObject dataObject =  (DataObject) this.httpTlvReqQueue.take();// Get data from queue set by httpQueueReader
			  int socketStatus=1;
			  if(UssdRouterMainClient.config.getInt("HTTP_SEND_URGENT_DATA_FLAG", 1)==1)
			  {
				  socketStatus=handleSocketStatus();
			  }
			  logger.info("http socket status ["+socketStatus+"],newHttpSocket:["+Global.newHttpSocket+"]");
			  if(socketStatus>0 && dataObject!=null)
			  {				  
				  if(Global.httpSocket!=null && Global.newHttpSocket.get())
				  {					  
						HttpOutputStreamFactory outputStreamFactory = (HttpOutputStreamFactory) UssdRouterMainClient.context.getBean("httpOutputStreamBean");
						logger.debug("HttpOutputStreamFactory inside HttpQueueReader["+outputStreamFactory+"] httpSocketOutputStream["+Global.httpSocket+"]");
						outputStreamFactory.setOutputStream(Global.httpSocket.getOutputStream());                       
						dataOutputStream = (DataOutputStream) UssdRouterMainClient.context.getBean("httpDataOutputStream");
						logger.debug("Isnide SendHttpRequest Global.newHttpSocket:["+Global.newHttpSocket+"]");
						Global.newHttpSocket.set(false);
				  }
				  else if(Global.httpSocket==null && Global.newHttpSocket.get()) //Added By Richard on 28th March 2019
				  {
					  logger.info("##>msisdn["+dataObject.getMsisdn()+"] service not found.");
					  dataObject.setReqCounter((dataObject.getReqCounter()));
					  dataObject.ussdErrorCodeBean = this.ussdUtils.getErrorMessage("4_"+UssdRouterMainClient.config.getInt("router.defaultLanguage_Id"));
					  dataObject.setErrorCode(UssdRouterConstants.SERVER_IS_BUSY);
					  dataObject.setUserData(dataObject.ussdErrorCodeBean.getErrorStr());
					  dataObject.setOpCode(UssdRouterConstants.PSSR_RESP);
					  routerResQueue.put(dataObject);
					  break;
				  }
				  sendHttpRequestData(dataObject);
			  }
			  else if(socketStatus==0 && dataObject!=null)
			  {
				    logger.info("##>msisdn["+dataObject.getMsisdn()+"] service not found.");
					dataObject.setReqCounter((dataObject.getReqCounter()));
					dataObject.ussdErrorCodeBean = this.ussdUtils.getErrorMessage("4_"+UssdRouterMainClient.config.getInt("router.defaultLanguage_Id"));
					dataObject.setErrorCode(UssdRouterConstants.SERVER_IS_BUSY);
					dataObject.setUserData(dataObject.ussdErrorCodeBean.getErrorStr());
					dataObject.setOpCode(UssdRouterConstants.PSSR_RESP);
					routerResQueue.put(dataObject);
					break;					
			  }
			  else
			  {
				  logger.info("##>>Going to break second while loop of sendHttpRequest thread and httpSocketFound["+Global.httpSocketFound+"]");
				  break;
			  }
			  
			}
		   catch(Exception exp)
            	{
                    logger.error("##>>Error occured inside SendHttpRequest Run method"+exp);
            	}

		}	

	}

	
	public int sendHttpRequestData(DataObject dataObject){
		try
		{
			int status = -1; 
			logger.info("##>>msisdn["+dataObject.getMsisdn()+"],socket:["+Global.httpSocket+"] send Request to Http module.");
			TLVAppInterface tlvAppInterface = (TLVAppInterface) UssdRouterMainClient.context.getBean("tlvAppInterface"); 
			ByteArrayOutputStream sendBuf = (ByteArrayOutputStream) UssdRouterMainClient.context.getBean("byteArrayOutputStream");
			tlvAppInterface.setData(UssdRouterConstants.TLV_MSISDN, dataObject.getMsisdn());
			if(UssdRouterMainClient.config.getInt("router.EncriptDecript_Enable") == 1)
			{
			tlvAppInterface.setData(UssdRouterConstants.TLV_DATA,ussdEncriptDecript.encript(dataObject.getUserData()));
			}
			else
			{
			tlvAppInterface.setData(UssdRouterConstants.TLV_DATA, dataObject.getUserData());
			}	
			tlvAppInterface.setData(UssdRouterConstants.TLV_OPCODE, dataObject.getOpCode());
			tlvAppInterface.setData(UssdRouterConstants.TLV_DLGID, dataObject.getDlgId());
			tlvAppInterface.setData(UssdRouterConstants.TLV_SESSIONID, dataObject.getSessionId());
			if(dataObject.getOpCode() == 9)
			{
				tlvAppInterface.setData(UssdRouterConstants.TLV_ACTION, dataObject.getAction());
				
			}
			tlvAppInterface.encode(sendBuf);
			int sendRequestLen = sendBuf.size();
			byte[] len=new byte[4];
			len[3]=(byte)(sendRequestLen );
			len[2]=(byte)((sendRequestLen >> 8) );
			len[1]=(byte)((sendRequestLen >> 16));
			len[0]=(byte)((sendRequestLen >> 24));
			dataOutputStream.write(len,0, 4); //length sent 
			dataOutputStream.write(sendBuf.toByteArray(), 0, sendBuf.toByteArray().length); //actual data sent
			logger.debug("##>>msisdn["+dataObject.getMsisdn()+"] Request sent successfully to Http module...");
			status = 1;
			tlvAppInterface = null;
			return status;
		}
		catch(Exception exp)
		{ 
			logger.error("Error occured inside SendHttpRequest"+exp);
			exp.printStackTrace();
			/*try
			{
				logger.info("Going to call sendUrgentData method ");
				httpSocket.sendUrgentData(1);
			}
			catch(Exception e)
			{
				UssdRouterMainClient.needToStopThread=true; // Added by rahul kumar to restart threads
			}*/
		}
		return -1;
	}
	/**
	 * 
	 * @Auther rahul
	 * Created On Mar 1, 2018
	 */
	private int handleSocketStatus()
	{
		int status=0;
		try
		{
			logger.info("Going to get http socket status inside handleSocketStatus method of SendHttpRequest.");
			Global.httpSocket.sendUrgentData(1);
			status=1;
		}
		catch(Exception e)
		{
		  Global.httpSocketFound.set(false);
		  Global.newHttpSocket.set(true);
		  Global.newHttpResponseSocket.set(true);
			logger.error("Exception occurred while sending urgent data to HTTP socket. Error["
					+ e
					+ "] Setting HttpSocketFound["
					+ Global.httpSocketFound.get()
					+ "]  NewHttpSocketFound["
					+ Global.newHttpSocket.get()
					+ "] NewHttpResponseSocket["
					+ Global.newHttpResponseSocket.get() + "]");
		}	
		return status;
	}
	
}
