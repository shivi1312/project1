package com.telemune.ussdrouter;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.beans.DataObject;

public class HttpResponseQueueReader implements Runnable{
	private Logger logger = Logger.getLogger(HttpResponseQueueReader.class);
	private ArrayBlockingQueue httpRespQueue = null;
	private ThreadPoolExecutor responseTaskExecutor = null;
	private ResponseRejectedWork responseRejectedWork = null;
	public HttpResponseQueueReader() {
		// TODO Auto-generated constructor stub
	}
	
	public HttpResponseQueueReader(ArrayBlockingQueue httpResQueue,ThreadPoolExecutor responseTaskExecutor , ResponseRejectedWork responseRejectedWork) {
		this.httpRespQueue = httpResQueue;
		this.responseTaskExecutor = responseTaskExecutor;
		this.responseRejectedWork = responseRejectedWork; 
		this.responseTaskExecutor.setRejectedExecutionHandler(this.responseRejectedWork);
	}
	
	public void run() {
		
			logger.debug("Inside Run Method of HttpResponseQueueReader ...httpResQueue["+httpRespQueue+"] responseTaskExecutor["+responseTaskExecutor+"]");
			while(true)
			{
				try
				{
				/*	if(this.httpRespQueue.isEmpty())
					{
						Thread.sleep(UssdRouterMainClient.config.getInt("router.httpResponseQueueReaderThread_SleepTime")); //should be configurable
					}
					else
					{*/
						//DataObject dataObject = (DataObject) this.httpRespQueue.poll();
						logger.info("Inside HttpResponseQueueReader Goign to take element if available ...");
						DataObject dataObject = (DataObject) this.httpRespQueue.take();
						RouterPostProcessor routerPostProcessor = (RouterPostProcessor) UssdRouterMainClient.context.getBean("routerPostProcessor");
						routerPostProcessor.setDataObject(dataObject);
						this.responseTaskExecutor.execute(routerPostProcessor);
					/*}*/	
				}
				catch(Exception exp)
				{
					logger.error("##>>Error occured inside HttpResponseQueueReader run method"+exp);
					
				}
				
			}
	}

}
