package com.telemune.ussdrouter;

public class DbResponseQueueReader {

}
