package com.telemune.ussdrouter;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.beans.DataObject;
import com.telemune.ussdrouter.factorybean.UssdChargingInputStreamFactory;
import com.telemune.ussdrouter.factorybean.UssdChargingOutputStreamFactory;

import TlvLib.TLVAppInterface;

public class UssdChargingRequest {

	private Logger logger = Logger.getLogger(UssdChargingRequest.class);
	private Socket socket = null;
	private DataInputStream dataInputStream = null;
	private DataOutputStream dataOutputStream = null;
	
	
	
	public UssdChargingRequest() {
	}
	public UssdChargingRequest(Socket socket) {
		this.socket = socket;
		try
		{
			UssdChargingInputStreamFactory ussdChargingInputStreamFactory = (UssdChargingInputStreamFactory) UssdRouterMainClient.context.getBean("ussdChargingInputStreamBean"); 
			ussdChargingInputStreamFactory.setInputStream(this.socket.getInputStream());
			
			UssdChargingOutputStreamFactory ussdChargingOutputStreamFactory = (UssdChargingOutputStreamFactory) UssdRouterMainClient.context.getBean("ussdChargingOutputStreamBean"); 
			ussdChargingOutputStreamFactory.setOutputStream(this.socket.getOutputStream());
			this.dataInputStream = (DataInputStream) UssdRouterMainClient.context.getBean("ussdChargingDataInputStream");
			this.dataOutputStream = (DataOutputStream) UssdRouterMainClient.context.getBean("ussdChargingDataOutputStream");
			
			ussdChargingInputStreamFactory = null;
			ussdChargingOutputStreamFactory = null;
		}
		catch(Exception exp)
		{
			logger.error("Exception while ussd charging request "+exp);
		}
		
	}
	
	public int sendData(DataObject dataObject)
	{
		try
		{
			
			int status = -1;
			int amount = 0;
			String subType = "N";
			boolean sendRequestForDeductionEnable = false;
  				
			logger.info("##>>msisdn["+dataObject.getMsisdn()+"] chargingType["+dataObject.getChgReqType()+"] going to sent request to charging module..");
			TLVAppInterface tlvAppInterface = (TLVAppInterface) UssdRouterMainClient.context.getBean("tlvAppInterface"); 
			ByteArrayOutputStream sendBuf = (ByteArrayOutputStream) UssdRouterMainClient.context.getBean("byteArrayOutputStream");
			tlvAppInterface.setData(UssdRouterConstants.CHARGING_MSISDN, dataObject.getMsisdn());
			tlvAppInterface.setData(UssdRouterConstants.CHARGING_SUBTYPE_TAG, dataObject.getSubType());
			tlvAppInterface.setData(UssdRouterConstants.CHARGING_REQUESTTYPE_TAG, dataObject.getChgReqType());
			if(dataObject.getChgReqType() == 2)
			{
				tlvAppInterface.setData(UssdRouterConstants.CHARGING_TARIFF_TAG, dataObject.ussdRatePlanBean.getTarrifId());
				tlvAppInterface.setData(UssdRouterConstants.CHARGING_SESSION_TAG, dataObject.getSessionId());
				tlvAppInterface.setData(UssdRouterConstants.CHARGING_SRVNAME_TAG, dataObject.ussdServiceCodeBean.getServiceName());
				tlvAppInterface.setData(UssdRouterConstants.CHARGING_SHORTCODE_TAG, dataObject.ussdServiceCodeBean.getCode());
				if(dataObject.getSubType().equalsIgnoreCase("P"))
				{
					tlvAppInterface.setData(UssdRouterConstants.CHARGING_AMOUNT_TAG, dataObject.ussdRatePlanBean.getAmountPre()+"");
					amount =(int) dataObject.ussdRatePlanBean.getAmountPre();
				}
				else
				{
					tlvAppInterface.setData(UssdRouterConstants.CHARGING_AMOUNT_TAG, dataObject.ussdRatePlanBean.getAmountPost()+"");
					amount =(int) dataObject.ussdRatePlanBean.getAmountPost();
				}	
			}
			tlvAppInterface.encode(sendBuf);
			int sendRequestLen = sendBuf.size();
			byte[] len=new byte[4];
			len[3]=(byte)(sendRequestLen );
			len[2]=(byte)((sendRequestLen >> 8) );
			len[1]=(byte)((sendRequestLen >> 16));
			len[0]=(byte)((sendRequestLen >> 24));
			this.dataOutputStream.write(len,0, 4); //length sent 
			this.dataOutputStream.write(sendBuf.toByteArray(), 0, sendBuf.toByteArray().length); //actual data sent
			logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Request sent successfully to charging...");
			
			int dataLen = 0;
			byte dataBuf[] = new byte[4];
			int test = 0;
			DataInputStream reader = null;
			reader = this.dataInputStream;
			if( reader.read(dataBuf,0,4) == -1 )
               		{        
                       try
                       {
                               this.socket.close();
                               logger.info("sendData Destroy");
                               logger.info("sendData socket closed");
                       }
                       catch(Exception e)
                       {
                               logger.error(e);
                       }

               }

               dataLen = dataLen | (dataBuf[0] << 24);
               dataLen = dataLen  | (dataBuf[1] << 16);
               dataLen = dataLen | (dataBuf[2] << 8);
               test=(0x000000ff & dataBuf[3]);
               dataLen = dataLen | test;
            
               dataBuf = new byte[dataLen];
   			   reader.read( dataBuf, 0, dataLen);
   			   TLVAppInterface tcpReq = (TLVAppInterface) UssdRouterMainClient.context.getBean("tlvAppInterface"); 
   			   tcpReq.decode( new ByteArrayInputStream( dataBuf) ,dataLen );
   			   int response = Integer.parseInt(tcpReq.getData(UssdRouterConstants.CHARGING_RESPONSE_TAG));
			   logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Response form charging is ["+response+"]");		 
   			   if(response < 0)
   			   {
   				   logger.info("##>.msisdn["+dataObject.getMsisdn()+"] err in chg request execution response is ["+response+"]");
   				   dataObject.setChargeStatus(response);
   			   }
   			   else
   			   {
   				   amount = (int) Float.parseFloat(tcpReq.getData(UssdRouterConstants.CHARGING_AMOUNT_TAG));
   				   subType = tcpReq.getData(UssdRouterConstants.CHARGING_SUBTYPE_TAG);
				   logger.info("##>>##>>msisdn["+dataObject.getMsisdn()+"] Resposne from charging user have amount["+amount+"] and subType["+subType+"]");
						
   				   if(subType.equalsIgnoreCase("P"))
   				   {
   					   if(amount >= ((int)dataObject.ussdRatePlanBean.getAmountPre()))
   					   {
   						   sendRequestForDeductionEnable = true;
   						   amount = (int)dataObject.ussdRatePlanBean.getAmountPre();
   						   int temp = (amount/((int)dataObject.ussdRatePlanBean.getAmountPre()));
   						   int maxPulseAllowed = (UssdRouterMainClient.config.getInt("router.maxPulseAllowed") < temp) ? UssdRouterMainClient.config.getInt("router.maxPulseAllowed") : temp;
   						   dataObject.setMaxPulseAllowed(maxPulseAllowed);
   						   
   					   }
   				   }
   				   else
   				   {
   					   sendRequestForDeductionEnable = true;
   					   amount = (int)dataObject.ussdRatePlanBean.getAmountPost();
   					   dataObject.setMaxPulseAllowed(UssdRouterMainClient.config.getInt("router.maxPulseAllowed"));
   				   }
   				   dataObject.setSubType(subType);
   			   } 
   			   this.socket.close();
   			   this.dataInputStream.close();
   			   this.dataOutputStream.close();
   			   tlvAppInterface = null; 
   			   this.dataInputStream = null;
   			   this.dataOutputStream = null;
			   logger.info("##>>msisdn["+dataObject.getMsisdn()+"] sendRequestForDeductionEnable["+sendRequestForDeductionEnable+"]");	
   			   if(sendRequestForDeductionEnable)
   			   {
   				  this.socket =  (Socket)UssdRouterMainClient.context.getBean("ussdChargingSocket");
   				  UssdChargingInputStreamFactory ussdChargingInputStreamFactory = (UssdChargingInputStreamFactory) UssdRouterMainClient.context.getBean("ussdChargingInputStreamBean"); 
   				  ussdChargingInputStreamFactory.setInputStream(this.socket.getInputStream());
   				
   				  UssdChargingOutputStreamFactory ussdChargingOutputStreamFactory = (UssdChargingOutputStreamFactory) UssdRouterMainClient.context.getBean("ussdChargingOutputStreamBean"); 
   				  ussdChargingOutputStreamFactory.setOutputStream(this.socket.getOutputStream());
   				  this.dataInputStream = (DataInputStream) UssdRouterMainClient.context.getBean("ussdChargingDataInputStream");
   				  this.dataOutputStream = (DataOutputStream) UssdRouterMainClient.context.getBean("ussdChargingDataOutputStream");
   				  ussdChargingInputStreamFactory = null;
   				  ussdChargingOutputStreamFactory = null;
   			 	  status = sendRequestToDeductAmount(dataObject,amount);
				  logger.info("##>>msisdn["+dataObject.getMsisdn()+"] response from sendRequestToDeductAmount is status["+status+"]");
   			   }
   			   else
   			   {
   				  dataObject.setChargeStatus(-1);
   				  status = 1;
   			   }
   			   return status;
   			   }
		catch(Exception exp)
		{
			logger.error("Error occured inside sendData"+exp);
		}
		return -1;
	}
	
	public int sendRequestToDeductAmount(DataObject dataObject,int amount)
	{
		try
		{
			int status = -1;
			
			logger.info("##>>msisdn["+dataObject.getMsisdn()+"] going to sent request to charging module for deudction amount["+amount+"]..");
			TLVAppInterface tlvAppInterface = (TLVAppInterface) UssdRouterMainClient.context.getBean("tlvAppInterface"); 
			ByteArrayOutputStream sendBuf = (ByteArrayOutputStream) UssdRouterMainClient.context.getBean("byteArrayOutputStream");
			tlvAppInterface.setData(UssdRouterConstants.CHARGING_MSISDN, dataObject.getMsisdn());
			tlvAppInterface.setData(UssdRouterConstants.CHARGING_SUBTYPE_TAG, dataObject.getSubType());
			tlvAppInterface.setData(UssdRouterConstants.CHARGING_REQUESTTYPE_TAG, "2");
		
			tlvAppInterface.setData(UssdRouterConstants.CHARGING_TARIFF_TAG, dataObject.ussdRatePlanBean.getTarrifId());
			tlvAppInterface.setData(UssdRouterConstants.CHARGING_SESSION_TAG, dataObject.getSessionId());
			tlvAppInterface.setData(UssdRouterConstants.CHARGING_AMOUNT_TAG, amount+"");
			tlvAppInterface.setData(UssdRouterConstants.CHARGING_SRVNAME_TAG, dataObject.ussdServiceCodeBean.getServiceName());
			tlvAppInterface.setData(UssdRouterConstants.CHARGING_SHORTCODE_TAG, dataObject.ussdServiceCodeBean.getCode());
			
			
			tlvAppInterface.encode(sendBuf);
			int sendRequestLen = sendBuf.size();
			byte[] len=new byte[4];
			len[3]=(byte)(sendRequestLen );
			len[2]=(byte)((sendRequestLen >> 8) );
			len[1]=(byte)((sendRequestLen >> 16));
			len[0]=(byte)((sendRequestLen >> 24));
			dataOutputStream.write(len,0, 4); //length sent 
			dataOutputStream.write(sendBuf.toByteArray(), 0, sendBuf.toByteArray().length); //actual data sent
			logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Request  sent successfully to charging for deudction...");
			
			int dataLen = 0;
			byte dataBuf[] = new byte[4];
			int test = 0;
			DataInputStream reader = null;
			reader = dataInputStream;
			if( reader.read(dataBuf,0,4) == -1 )
               {
                       try
                       {
                               this.socket.close();
                               logger.info("sendRequestToDeductAmount Destroy");
                               logger.info("sendRequestToDeductAmount socket closed");
                       }
                       catch(Exception e)
                       {
                               logger.error(e);
                       }

               }

               dataLen = dataLen | (dataBuf[0] << 24);
               dataLen = dataLen  | (dataBuf[1] << 16);
               dataLen = dataLen | (dataBuf[2] << 8);
               test=(0x000000ff & dataBuf[3]);
               dataLen = dataLen | test;
            
               dataBuf = new byte[dataLen];
   			   reader.read( dataBuf, 0, dataLen);
   			   TLVAppInterface tcpReq = (TLVAppInterface) UssdRouterMainClient.context.getBean("tlvAppInterface"); 
   			   tcpReq.decode( new ByteArrayInputStream( dataBuf) ,dataLen );
   			   int response = Integer.parseInt(tcpReq.getData(UssdRouterConstants.CHARGING_RESPONSE_TAG)); 
			   logger.info("##>.msisdn["+dataObject.getMsisdn()+"] Resposne from charging in deudction response["+response+"]");	
   			   if(response < 0)
   			   {
   				   logger.info("##>.msisdn["+dataObject.getMsisdn()+"] err in chg request execution response is ["+response+"]");
   				   dataObject.setChargeStatus(response);
   			   }
   			   else
   			   {
   				  dataObject.setChargeStatus(0);
   			   }
   			   
   			   this.socket.close();
   			   this.dataInputStream.close();
   			   this.dataOutputStream.close();
   			   tlvAppInterface = null;
   			   this.dataInputStream = null;
   			   this.dataOutputStream = null;
   			   status = 1;
   			   return status;
   		}
		catch(Exception exp)
		{
			logger.error("Error occured inside sendRequestToDeductAmount"+exp);
		}
		return -1;
	}
	
}
