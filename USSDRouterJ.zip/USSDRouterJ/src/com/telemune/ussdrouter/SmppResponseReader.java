package com.telemune.ussdrouter;

import java.util.concurrent.ArrayBlockingQueue;

import org.apache.log4j.Logger;


public class SmppResponseReader implements Runnable{
	Logger logger=Logger.getLogger(SmppResponseReader.class);
	private ArrayBlockingQueue smppResQueue = null;
	
	
	public SmppResponseReader() {
		// TODO Auto-generated constructor stub
	}
	
	public SmppResponseReader(ArrayBlockingQueue smppResQueue) {
		this.smppResQueue = smppResQueue;
	}
	
	
	
	public void run() {
		logger.debug("Inside Run Method of SmppResponseReader .....smppResQueue["+smppResQueue+"]");	
	}

}
