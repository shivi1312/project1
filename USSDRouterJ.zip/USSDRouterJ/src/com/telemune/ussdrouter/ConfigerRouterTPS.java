/**
 * @Auther rahul
 * Created On Apr 12, 2018
 */
package com.telemune.ussdrouter;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.beans.Global;

import LCheck.LCheck;

public class ConfigerRouterTPS implements Runnable {
	Logger logger=Logger.getLogger(ConfigerRouterTPS.class);
	AtomicBoolean socketFound=new AtomicBoolean(false);
	AtomicBoolean isSocketConnected=new AtomicBoolean(false);
	AtomicBoolean isMaxTpsConfigured=new AtomicBoolean(false);
	SocketAddress socketAddress=null;
	Socket routerSocket=null;
	@Override
	public void run() {
		try
		{
			logger.info("Configure max TPS for router");			
			while(true)
			{
				try
				{
					Global.routerServerCount.set(UssdRouterMainClient.config.getInt("router.server_count"));
					if(Global.routerServerCount.get()>1)
					{
						createSocketForOtherRouter();
						if(socketFound.get())
						{
							connectToCreatedSocket();	
						}
						else if(!isMaxTpsConfigured.get())
						{
							getMaxTps();
							configureMaxTpsForRouter();
							isMaxTpsConfigured.set(true);
							logger.info("Configure max TPS:["+Global.maxTps+"], Router's max TPS:["+Global.routersMaxTps+"], is TPS configured:["+isMaxTpsConfigured+"]");
						}
					}
					else if(!isMaxTpsConfigured.get())
					{						
						getMaxTps();
						configureMaxTpsForRouter();
						isMaxTpsConfigured.set(true);
						logger.info("Configure max TPS:["+Global.maxTps+"], Router's max TPS:["+Global.routersMaxTps+"], is TPS configured:["+isMaxTpsConfigured+"]");
					}		
				}
				catch(Exception e)
				{
					logger.error("Exception while checking socket connection with other router ");
				}
				Thread.sleep(1*1000);
			}
		}
		catch(Exception e)
		{
			logger.error("Exception while configuring TPS for Router "+e);
		}
	}

	private void createSocketForOtherRouter()
	{
		String secondRouterIp=UssdRouterMainClient.config.getString("router.server_ip");
		int secondRouterPort=UssdRouterMainClient.config.getInt("router.server_port");
		while(true)
		{
			try
			{
				if(socketFound.get())
				{
					break;
				}
				else
				{
					socketAddress=new InetSocketAddress(secondRouterIp,secondRouterPort); 
					routerSocket=new Socket();
					routerSocket.connect(socketAddress, 1000);
					routerSocket.close();
					routerSocket=null;
					socketFound.set(true);
					isMaxTpsConfigured.set(false);
				}
			}
			catch(Exception e)
			{
				logger.debug("Exception while connecting to other router's socket");				
				break;
			}
				
		}
	}
	
	private void connectToCreatedSocket()
	{
		while(true)
		{
			try
			{	
				if(socketFound.get())
				{
					routerSocket=new Socket();
					routerSocket.connect(socketAddress, 1000);
					routerSocket.close();
					routerSocket=null;
					isSocketConnected.set(true);
					if(!isMaxTpsConfigured.get())
					{
						getMaxTps();
						configureMaxTpsForRouter();
						isMaxTpsConfigured.set(true);
						logger.info("Configure max TPS:["+Global.maxTps+"], Router's max TPS:["+Global.routersMaxTps+"],isMaxTpsConfigured:["+isMaxTpsConfigured+"]");
					}
				}
				else
				{
					break;
				}				
				Thread.sleep(1*1000);
			}
			catch(Exception e)
			{
				socketFound.set(false);
				isSocketConnected.set(false);
				isMaxTpsConfigured.set(false);
				logger.info("Configure max TPS:["+Global.maxTps+"], Router's max TPS:["+Global.routersMaxTps+"],isMaxTpsConfigured:["+isMaxTpsConfigured+"]");
			}
		}
	}
	
	
	private  void configureMaxTpsForRouter()
	{
		try
		{
			logger.info("Configure TPS maxTps:["+Global.maxTps.get()+"],router server count:["+Global.routerServerCount.get()+"]");
			if(isSocketConnected.get())
			{
				double maxTpsForRouter=Global.maxTps.get()/Global.routerServerCount.get();
				Global.routersMaxTps.set((int) Math.ceil(maxTpsForRouter));				
			}
			else
			{
				Global.routersMaxTps.set(Global.maxTps.get());
			}
			double tpsAlertPercentage=UssdRouterMainClient.config.getDouble("router.tps_alert_percentage");
			 Global.tpsAlertPercentage.set(tpsAlertPercentage);
			double tpsAlterLim=Global.routersMaxTps.get() * Global.tpsAlertPercentage.get()/100;
			Global.tpsAlertLimit.set(tpsAlterLim);
			logger.info("Max TPS["+Global.routersMaxTps+"], tps alert percentage:["+Global.tpsAlertPercentage+"],tps limit for alert:["+Global.tpsAlertLimit+"]for this router");
		}
		catch(Exception e)
		{
			logger.error("Exception while configure max TPS for router.");
		}
		
		
	}
	
	private void  getMaxTps()
	{
		LCheck lck=null;
		Thread thlck=null;
		Thread th=null;
		try
		{
				logger.info("Going to get max tps based on license key");
				lck=new LCheck();
				thlck=new Thread(lck);
		        thlck.start();
		        th=new Thread();
		        th.sleep(1000);
		        Global.maxTps.set(lck.checkLic());		        
		        logger.info("Going to get max tps:["+lck.checkLic()+"]based on license key");
		        thlck.stop();
		        th.stop();
		}
		catch(Exception e)
		{
			logger.error("Exception while getting max tps from license key.");
		}
		finally
		{
			thlck=null;
			th=null;
			lck=null;
		}
	}
}
