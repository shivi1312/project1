package com.telemune.ussdrouter;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.net.Socket;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.beans.DataObject;
import com.telemune.ussdrouter.beans.Global;
import com.telemune.ussdrouter.factorybean.HttpInputStreamFactory;
import com.telemune.ussdrouter.util.EncriptDecript;
import com.telemune.ussdrouter.util.RouterCommonConstants;
import com.telemune.ussdrouter.util.UssdUtils;

import TlvLib.TLVAppInterface;

public class HttpResponseReader implements Runnable{
	private Logger logger = Logger.getLogger(HttpResponseReader.class);
	private ArrayBlockingQueue httpResQueue = null;
	//private Socket httpSocket = null;
	private ConcurrentHashMap serverSocketMap = null;
	private DataInputStream dataInputStream = null;
	private ConcurrentHashMap requestMap = null;
	private ArrayBlockingQueue httpReqQueue = null;
	//private boolean httpSocketFound = false;
	private UssdUtils ussdUtils = null;
	//new additions
	private ThreadPoolExecutor responseTaskExecutor = null;
	private ResponseRejectedWork responseRejectedWork = null;
	private EncriptDecript ussdEncriptDecript = null;
	private ThreadPoolExecutor httpTaskExecutor = null;	
        private HttpRejectedWork httpRejectedWork = null;
    
	
	public HttpResponseReader() {
		// TODO Auto-generated constructor stub
	}
	
	public HttpResponseReader(ArrayBlockingQueue httpResQueue,ConcurrentHashMap serverSocketMap,ConcurrentHashMap requestMap , ArrayBlockingQueue httpReqQueue , UssdUtils ussdUtils,ThreadPoolExecutor responseTaskExecutor,ResponseRejectedWork responseRejectedWork , EncriptDecript ussdEncriptDecript,ThreadPoolExecutor httpTaskExecutor,HttpRejectedWork httpRejectedWork) {
		this.httpResQueue = httpResQueue;
		this.serverSocketMap = serverSocketMap;
		this.requestMap = requestMap;
		this.httpReqQueue = httpReqQueue;
		this.ussdUtils = ussdUtils;
		this.responseTaskExecutor = responseTaskExecutor;
		this.responseRejectedWork = responseRejectedWork;
		this.responseTaskExecutor.setRejectedExecutionHandler(this.responseRejectedWork);
		this.ussdEncriptDecript = ussdEncriptDecript;
		this.httpTaskExecutor = httpTaskExecutor;
		this.httpRejectedWork = httpRejectedWork;	
		this.httpTaskExecutor.setRejectedExecutionHandler(this.httpRejectedWork);
	}
	
	
	public void run() {
		try
		{
			
			while(true)
			{
				if(Global.needToStopHttpThread.get())
				{
					Global.httpSocketFound.set(false);
				}
				if(Global.httpSocketFound.get())
				{
					logger.info("HttpResponseReader socket Found so do futher task");
					HttpInputStreamFactory inputStreamFactory = (HttpInputStreamFactory) UssdRouterMainClient.context.getBean("httpInputStreamBean");
					inputStreamFactory.setInputStream(Global.httpSocket.getInputStream());
					this.dataInputStream = (DataInputStream) UssdRouterMainClient.context.getBean("httpDataInputStream");
					break;
				}
				else
				{
					Global.httpSocket=(Socket) serverSocketMap.get(RouterCommonConstants.HTTP_SOCKET);
					if(Global.httpSocket!=null)
					{
						logger.info("HttpResponseReader already connected so Http Socket is ["+Global.httpSocket+"]");
						Global.httpSocketFound.set(true);
						Global.needToStopHttpThread.set(false);
					}
				}				
				logger.info("Inside Run Method of HttpResponseReader,http Socket is ["+Global.httpSocket+"],httpSocketFound["+Global.httpSocketFound+"] and needToStopThread["+Global.needToStopThread+"]");
				if(!Global.httpSocketFound.get())
				{
					Thread.sleep(UssdRouterMainClient.config.getInt("HTTP_SOCKET_LOOKUP_TIME", 1000));	
				}
			}
		}
		catch(Exception exp)
		{
			logger.error("##>>httpSocketFound["+Global.httpSocketFound+"]Error occured inside HttpResponseReader"+exp);
			exp.printStackTrace();
			
		}
		
		if (Global.httpSocket.isClosed())
		{
			return;
		}		
		
		while(true)
		{
			
			int dataLen = 0;
            byte dataBuf[] = null;
            int test = 0;
    		
			try
			{
				/**
				 * Validating thread to stop
				 * Added by Rahul kumar on 19/01/1018
				 */
				if(Global.needToStopThread.get())
				{
					break;
				}
				if(Global.needToStopHttpThread.get())
				{
					Global.httpSocketFound.set(false);
					break;
				}
				/* Commented By Richard on 28th March 2019
				 * 
				 * if(Global.newHttpResponseSocket.get() && Global.httpSocket!=null)
				{
					HttpInputStreamFactory inputStreamFactory = (HttpInputStreamFactory) UssdRouterMainClient.context.getBean("httpInputStreamBean");
					inputStreamFactory.setInputStream(Global.httpSocket.getInputStream());
					this.dataInputStream = (DataInputStream) UssdRouterMainClient.context.getBean("httpDataInputStream");
					Global.newHttpResponseSocket.set(false);
				}*/
				
				
				if(UssdRouterMainClient.config.getInt("HTTP_SEND_URGENT_DATA_FLAG",1)==1)
				{
					if(handleSocketStatus()==0)
					{
						break;
					}
				}
				dataBuf = new byte[4];
				if(this.dataInputStream.read(dataBuf,0,4)==-1)
				{
					try
					{
						//logger.info("End of Stream detected from HttpInterface side  >>>>>>>>> Freeing Http Socket");
						Thread.sleep(UssdRouterMainClient.config.getInt("RETRY_INTERVAL_AT_END_OF_STREAM_HTTP",1)); //should be configurable
						if(UssdRouterMainClient.config.getInt("HTTP_SEND_URGENT_DATA_FLAG",1)==0)
						{
							logger.info("End of Stream detected from HttpInterface side  >>>>>>>>> So sending urgent Data.");
							try
							{
								Global.httpSocket.sendUrgentData(1);
							}
							catch(Exception e)
							{
								logger.error("Exception occured when calling socket.sendUrgentData(1). Freeing HTTP Socket. "+e);
								freeHttpSocket();
								break;
							}
						}	
						continue;
					}
					catch(Exception e) {logger.error("error while reading request"+e);}
					
				}

				dataLen = dataLen | (dataBuf[0] << 24);
				dataLen = dataLen  | (dataBuf[1] << 16);
				dataLen = dataLen | (dataBuf[2] << 8);
				test=(0x000000ff & dataBuf[3]);
				dataLen = dataLen | test;
			}
			catch (Exception e)
			{
				logger.error("error while reading request"+e);
				try
				{
					Thread.sleep(1);					
					Global.httpSocket.close();
					
				}
				catch(Exception ex) {logger.error("error while closing http socket "+ex);}
				finally
				{
					/*
					 * Added By Richard on 28th March 2019
					 */
					freeHttpSocket();
				}
			}

			if (dataLen == 0)
			{	
				try
				{
					Thread.sleep(1); //should be configurable					
					continue;
				}
				catch(Exception eee){logger.error("error while going to sleep "+eee);}
				
				
			}
			
			try
			{
			int status = -1;	
			DataObject dataObject = null;	
			DataObject sendHttpRespObj = null;
			dataBuf = new byte[dataLen];
			this.dataInputStream.read( dataBuf, 0, dataLen);
			TLVAppInterface tcpReq = (TLVAppInterface) UssdRouterMainClient.context.getBean("tlvAppInterface"); 
			tcpReq.decode( new ByteArrayInputStream( dataBuf) ,dataLen );
			int dialogId =Integer.parseInt(tcpReq.getData(UssdRouterConstants.TLV_DLGID));
			int newPushSession = Integer.parseInt(tcpReq.getData(UssdRouterConstants.TLV_NEW_PUSH_SEESION));
			int opCode = Integer.parseInt(tcpReq.getData(UssdRouterConstants.TLV_OPCODE));;
			String msisdn = tcpReq.getData(UssdRouterConstants.TLV_MSISDN);
			// Added by rahul kumar
			int errorCode =0;
			if(tcpReq.getData(UssdRouterConstants.TLV_ERRORCODE)!=null)
			{
				errorCode=Integer.parseInt(tcpReq.getData(UssdRouterConstants.TLV_ERRORCODE));				
			}
			logger.info("##>>HttpResponseReader msisdn["+msisdn+"] dialogId["+dialogId+"] newPushSession["+newPushSession+"] opCode["+opCode+"] userResp["+tcpReq.getData(UssdRouterConstants.TLV_DATA)+"],errorCode["+errorCode+"] ");
			if(newPushSession == 1 && (opCode == UssdRouterConstants.USSR_REQ || opCode == UssdRouterConstants.USSN_REQ))
			{				
				/*
				 * added by rahul kumar 03/04/2018
				 * TPS Validation code start here
				 */
				Global.currentTPS.incrementAndGet();			
				long requestTime=System.currentTimeMillis();
				if(Global.currentTPS.get()==1)
				{
					Global.firstRequestTime.set(requestTime);
					Global.tpsStartTime.set(Global.firstRequestTime.get());
					long tpsEndTime=Global.firstRequestTime.get()+1000;
					Global.tpsEndTime.set(tpsEndTime);
					logger.info("[START]>> Going to start TPS so current TPS:["+Global.currentTPS+"],Request Time:["+Global.firstRequestTime+"], TPS Start Time:["+Global.tpsStartTime+"], TPS End Time:["+Global.tpsEndTime+"],process Request:["+Global.processRequest+"]");
				}
				else if(requestTime>Global.tpsEndTime.get())
				{
					Global.firstRequestTime.set(requestTime);
					Global.currentTPS.set(1);
					Global.rejectedRequest.set(0);
					Global.processRequest.set(true);
					Global.tpsStartTime.set(Global.firstRequestTime.get());
					long tpsEndTime=Global.firstRequestTime.get()+1000;
					Global.tpsEndTime.set(tpsEndTime);
					logger.info("[TIMEOUT]>>Second is over so current TPS:["+Global.currentTPS+"],Max TPS:["+Global.maxTps+"],Request Time:["+Global.firstRequestTime+"], TPS Start Time:["+Global.tpsStartTime+"], TPS End Time:["+Global.tpsEndTime+"], process Request:["+Global.processRequest+"]");
				
				}
				if(Global.currentTPS.get()>Global.routersMaxTps.get() && Global.processRequest.get())
				{
					Global.processRequest.set(false);
					long delayTime=Global.tpsEndTime.get()-requestTime;
					if(delayTime>0 && delayTime<1000)
					{
						logger.info("Delay Time:["+delayTime+"]");
						TimerTask task=new DelayTimer();
						Timer timer=new Timer();
						timer.schedule(task,delayTime);
					}
				}	
				// TPS Validation code end here
				
				if(Global.processRequest.get())
				{
					logger.info("[PROCESS PUSH REQUEST]>> current TPS:["+Global.currentTPS+"],Max TPS:["+Global.maxTps+"],Request Time:["+requestTime+"],TPS End Time:["+Global.tpsEndTime+"], Rejected Request:["+Global.rejectedRequest.get()+"]");
					if(Global.currentTPS.get()>=Global.tpsAlertLimit.get())
					{
						logger.info("[ALERT]@@ current TPS:["+Global.currentTPS+"],Max TPS:["+Global.maxTps+"],TPS Limit for Alert:["+Global.tpsAlertLimit+"],TPS percentage for Alert:["+Global.tpsAlertPercentage+"]");
					}	
					int uniqueId = this.ussdUtils.getUniqueDialogId();
					sendHttpRespObj = (DataObject) UssdRouterMainClient.context.getBean("dataObject");
					sendHttpRespObj.setShortCode(tcpReq.getData(UssdRouterConstants.TLV_SHORTCODE));
					sendHttpRespObj.setDlgId(uniqueId);
					sendHttpRespObj.setSessionId(tcpReq.getData(UssdRouterConstants.TLV_SESSIONID));
					sendHttpRespObj.setOpCode(UssdRouterConstants.PUSH_SESSION);
					sendHttpRespObj.setMsisdn(msisdn);
					sendHttpRespObj.setUserData("NA");
					sendHttpRespObj.setIsPushBase(true);
					sendHttpRespObj.setErrorCode(errorCode);
					
					dataObject = (DataObject) UssdRouterMainClient.context.getBean("dataObject");					
					dataObject.setShortCode(sendHttpRespObj.getShortCode());
					dataObject.setDlgId(sendHttpRespObj.getDlgId());
					dataObject.setSessionId(sendHttpRespObj.getSessionId());
					dataObject.setOpCode(opCode);
					dataObject.setMsisdn(sendHttpRespObj.getMsisdn());
					dataObject.setIsPushBase(true);
					dataObject.setSendRequestToCharging(false); //not sending request to charging
					dataObject.setUssdServiceCodeBean(this.ussdUtils.getUssdServiceCode(dataObject.getShortCode()));
					dataObject.setErrorCode(errorCode);
					logger.debug("##>>msisdn["+dataObject.getMsisdn()+"] inside HttpResponseReader servcie bean is ["+dataObject.getUssdServiceCodeBean()+"]");
					
					//this.httpReqQueue.put(sendHttpRespObj); //sendResponse Back to Http module
					HttpQueueReader httpQueueReader = (HttpQueueReader) UssdRouterMainClient.context.getBean("httpQueueReader");
	                                httpQueueReader.setDataObject(sendHttpRespObj);
	                                this.httpTaskExecutor.execute(httpQueueReader);
	
					if(UssdRouterMainClient.config.getInt("router.EncriptDecript_Enable") == 1)         
	                                {
					 dataObject.setUserData(ussdEncriptDecript.decript(tcpReq.getData(UssdRouterConstants.TLV_DATA)));
					}
					else
					{
					dataObject.setUserData(tcpReq.getData(UssdRouterConstants.TLV_DATA));
					}
					status = 1;
				}
				else
				{
					int rejectedRequest=Global.rejectedRequest.incrementAndGet();
					logger.info("[REJECTED]## MSISDN:["+msisdn+"] current TPS:["+Global.currentTPS+"],Max TPS:["+Global.maxTps+"],Request Time:["+requestTime+"], TPS End Time:["+Global.tpsEndTime+"], Rejected Request:["+rejectedRequest+"]");
					sendHttpRespObj = (DataObject) UssdRouterMainClient.context.getBean("dataObject");
					sendHttpRespObj.setShortCode(tcpReq.getData(UssdRouterConstants.TLV_SHORTCODE));
					sendHttpRespObj.setDlgId(-1);
					sendHttpRespObj.setSessionId(tcpReq.getData(UssdRouterConstants.TLV_SESSIONID));
					sendHttpRespObj.setOpCode(UssdRouterConstants.PUSH_SESSION);
					sendHttpRespObj.setMsisdn(msisdn);
					sendHttpRespObj.setUserData(""+UssdRouterConstants.SERVER_IS_BUSY);
					sendHttpRespObj.setIsPushBase(true);
					sendHttpRespObj.setErrorCode(errorCode);
					HttpQueueReader httpQueueReader = (HttpQueueReader) UssdRouterMainClient.context.getBean("httpQueueReader");
                    httpQueueReader.setDataObject(sendHttpRespObj);
                    this.httpTaskExecutor.execute(httpQueueReader);
					status = -1;
				}
			}
			else if (newPushSession == 1) {
				logger.info("##>>msisdn["+msisdn+"] Got PUSH request with wrong opcode so donot taking any action..");
				//recycleMessage 
			}
			else
			{	
			Set requestSet = requestMap.entrySet();
			Iterator requestItr =  requestSet.iterator();			
			while(requestItr.hasNext()){
				Map.Entry entry = (Map.Entry) requestItr.next();
				Integer requestDialogId = (Integer) entry.getKey();
				if(requestDialogId == dialogId)
				{
					logger.info("##>>msisdn["+msisdn+"] Request alreday exists with dialogId["+requestDialogId+"] so it is a continue request...");
					dataObject = (DataObject) entry.getValue();
					dataObject.setIsPushBase(false);
					dataObject.setErrorCode(errorCode);
					break;
				}
			}
			if(dataObject!=null)
			{
		
			if(UssdRouterMainClient.config.getInt("router.EncriptDecript_Enable") == 1)		
				{
					dataObject.setUserData(ussdEncriptDecript.decript(tcpReq.getData(UssdRouterConstants.TLV_DATA)));
				}
			else
				{
	            dataObject.setUserData(tcpReq.getData(UssdRouterConstants.TLV_DATA));
				}
	            dataObject.setOpCode(opCode);
	            dataObject.setDialogIdAlredayExists(true);
		        status = 1;
	        }
			}
			
			if(status == 1)
			{
				
				dataObject.setSendRequestToCharging(false); //not sending request to charging again
				RouterPostProcessor routerPostProcessor = (RouterPostProcessor) UssdRouterMainClient.context.getBean("routerPostProcessor");
				routerPostProcessor.setDataObject(dataObject);
				this.responseTaskExecutor.execute(routerPostProcessor);
			}
			else
			{
				//recycleMesage
			}	
			}
			catch(Exception exp)
			{
				logger.error("##>>Error occured inside HttpResponseReader"+exp);
				exp.printStackTrace();
				
			}
		}
	
		
	}
	/**
	 * 
	 * @Auther rahul
	 * Created On Mar 1, 2018
	 */
	/*private int handleSocketStatus()
	{
		int status=0;
		try
		{			
			logger.debug("Going to get http socket status inside handleSocketStatus method of SendHttpRequest.");
			httpSocket.sendUrgentData(1);
			status=1;
		}
		catch(Exception e)
		{
		  httpSocketFound=false;
		}	
		return status;
	}*/
	
	private int handleSocketStatus()
	{
		int status=0;
		try
		{			
			logger.debug("Going to get http socket status inside handleSocketStatus method of HttpResponseReader.");
			Global.httpSocket.sendUrgentData(1);
			status=1;
		}
		catch(Exception e)
		{
		   if(Global.httpSocket!=null)
			{
			   try
			   {
				   logger.info("Going to close http socket and remove from server socket map.");
				   Global.httpSocket.close();
				   serverSocketMap.remove(RouterCommonConstants.HTTP_SOCKET);
				   Global.httpSocket=null;
				   Global.needToStopHttpThread.set(true);
				   Global.newHttpSocket.set(true);
				   Global.newHttpResponseSocket.set(true);
				   //Thread.sleep(1*1000);
			   }
			   catch(Exception e1)
			   {
				   logger.info("Exception while closing http socket and remove from server socket map.");   
			   }
			 
			}
		}	
		return status;
	}
	
	private void freeHttpSocket() {
		if (Global.httpSocket != null) {
			try {
				logger.info("Going to close http socket and remove from server socket map.");
				Global.httpSocket.close();
				// Thread.sleep(1*1000);
			} catch (Exception e) {
				logger.error("Exception while closing http socket and remove from server socket map. Error["+e+"]");
			}
			finally
			{
				serverSocketMap.remove(RouterCommonConstants.HTTP_SOCKET);
				Global.httpSocket = null;
				Global.needToStopHttpThread.set(true);
				Global.newHttpSocket.set(true);
				Global.newHttpResponseSocket.set(true);
			}
		}
	}
}

