package com.telemune.ussdrouter.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.telemune.ussdrouter.UssdRouterMainClient;
import com.telemune.ussdrouter.beans.UssdRatePlanBean;

public class UssdRatePlanRowMapper implements RowMapper<UssdRatePlanBean>{
	
	public UssdRatePlanBean mapRow(ResultSet rset, int arg1) throws SQLException {
		UssdRatePlanBean ussdRatePlanBean = (UssdRatePlanBean) UssdRouterMainClient.context.getBean("ussdRatePlanBean");
		ussdRatePlanBean.setId(rset.getInt("ID"));
		ussdRatePlanBean.setAmountPost(rset.getFloat("AMOUNT_PRE"));
		ussdRatePlanBean.setAmountPre(rset.getFloat("AMOUNT_POST"));
		ussdRatePlanBean.setChargeType(rset.getString("CHARGE_TYPE"));
		ussdRatePlanBean.setMaxSessionTime(rset.getInt("MAX_SESSION_TIME"));
		ussdRatePlanBean.setPulseRate(rset.getInt("PULSE_RATE"));
		ussdRatePlanBean.setTarrifId(rset.getString("TARRIF_ID"));
		return ussdRatePlanBean;
	}

}
