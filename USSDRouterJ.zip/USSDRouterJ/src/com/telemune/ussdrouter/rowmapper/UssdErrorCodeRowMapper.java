package com.telemune.ussdrouter.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.telemune.ussdrouter.UssdRouterMainClient;
import com.telemune.ussdrouter.beans.UssdErrorCodeBean;

public class UssdErrorCodeRowMapper implements RowMapper<UssdErrorCodeBean>{
	
	public UssdErrorCodeBean mapRow(ResultSet rset, int arg1) throws SQLException {
		UssdErrorCodeBean ussdErrorCodeBean = (UssdErrorCodeBean) UssdRouterMainClient.context.getBean("ussdErrorCodeBean");
		ussdErrorCodeBean.setErrorCode(rset.getInt("ERR_CODE"));
		ussdErrorCodeBean.setErrorStr(rset.getString("ERR_STR"));
		ussdErrorCodeBean.setLangId(rset.getInt("LANG_ID"));
		return ussdErrorCodeBean;
	}

}
