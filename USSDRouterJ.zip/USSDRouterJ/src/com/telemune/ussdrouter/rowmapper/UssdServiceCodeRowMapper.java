package com.telemune.ussdrouter.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.telemune.ussdrouter.UssdRouterMainClient;
import com.telemune.ussdrouter.beans.UssdServiceCodeBean;

public class UssdServiceCodeRowMapper implements RowMapper<UssdServiceCodeBean>{
	
	public UssdServiceCodeBean mapRow(ResultSet rset, int arg1) throws SQLException {
		UssdServiceCodeBean ussdServiceCodeBean = (UssdServiceCodeBean) UssdRouterMainClient.context.getBean("ussdServiceCodeBean");
		ussdServiceCodeBean.setCode(rset.getString("CODE"));
		ussdServiceCodeBean.setInterFaceType(rset.getString("INTERFACE_TYPE"));
		ussdServiceCodeBean.setRatePlanId(rset.getInt("RATE_PLAN_ID"));
		ussdServiceCodeBean.setServiceName(rset.getString("SERVICE_NAME"));
		ussdServiceCodeBean.setServiceType(rset.getString("SERVICE_TYPE"));
		ussdServiceCodeBean.setUserName(rset.getString("USER_NAME"));
		return ussdServiceCodeBean;
	}

}
