package com.telemune.ussdrouter.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.telemune.ussdrouter.UssdRouterMainClient;
import com.telemune.ussdrouter.beans.UssdMenuBean;

public class UssdMenuRowMapper implements RowMapper<UssdMenuBean>{
	
	public UssdMenuBean mapRow(ResultSet rset, int arg1) throws SQLException {
		UssdMenuBean ussdMenuBean = (UssdMenuBean) UssdRouterMainClient.context.getBean("ussdMenuBean");
		ussdMenuBean.setCode(rset.getString("CODE"));
		ussdMenuBean.setMenuStr(rset.getString("MENU_STRING"));
		ussdMenuBean.setActivity(rset.getString("ACTIVITY"));
		ussdMenuBean.setActionId(rset.getInt("ACTION_ID"));
		ussdMenuBean.setNumItems(rset.getInt("NUM_ITEMS"));
		ussdMenuBean.setInterFaceType(rset.getString("INTERFACE_TYPE"));
		return ussdMenuBean;
	}

}
