package com.telemune.ussdrouter;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.beans.DataObject;
import com.telemune.ussdrouter.beans.Global;
import com.telemune.ussdrouter.util.EncriptDecript;

import TlvLib.TLVAppInterface;
public class RouterResponseSender implements Runnable{
private Logger logger = Logger.getLogger(RouterResponseSender.class);
private Socket socket = null; 
private ArrayBlockingQueue routerResQueue= null;
private DataOutputStream dataOutputStream = null;
private ConcurrentHashMap requestMap = null;
private EncriptDecript ussdEncriptDecript = null;	

	public RouterResponseSender() {
	}
	
	public RouterResponseSender(Socket socket , ArrayBlockingQueue routerResQueue , DataOutputStream dataOutputStream , ConcurrentHashMap requestMap , EncriptDecript ussdEncriptDecript) {
		this.socket = socket;
		this.routerResQueue = routerResQueue;
		this.dataOutputStream = dataOutputStream;
		this.requestMap = requestMap;
		this.ussdEncriptDecript = ussdEncriptDecript;
	}
	
	public void run() {
		logger.debug("Run Method of RouterResponseSender called successfully...socket["+socket+"] routerResQueue["+routerResQueue.size()+"]");
		sendResponse(this.socket);
	}
	
	private void sendResponse(Socket socket)
	{
		try
		{
			while(true)
			{
				/*if(this.routerResQueue.isEmpty())
				{
					Thread.sleep(UssdRouterMainClient.config.getInt("router.responseSenderThread_SleepTime")); //should be configurable
				}
				else
				{*/
					logger.info("Inside RouterResponseSender Going to take element if available...");
					if(Global.needToStopThread.get())
					{
						break;
					}
					//DataObject dataObject = (DataObject) routerResQueue.poll();
					DataObject dataObject = (DataObject) routerResQueue.take(); // Get data from this queue that is set by router processor
					if(dataObject.getOpCode() == UssdRouterConstants.PSSR_RESP)
					{
						//this.ussdUtils.increaseDialog();
						//this.ussdUtils.increaseCurrentDialogs();
						//remove from requestMap
						requestMap.remove(dataObject.getDlgId());
					    logger.info("##>msisdn["+dataObject.getMsisdn()+"] opcode["+dataObject.getOpCode()+"] thats why removed from requestMap...");
					}
					logger.debug("##>>RouterResponseSender msisdn["+dataObject.getMsisdn()+"] going to sent response.. Resposnedata is ["+dataObject.getUserData().trim()+"]");
					TLVAppInterface tlvAppInterface = (TLVAppInterface) UssdRouterMainClient.context.getBean("tlvAppInterface"); 
					ByteArrayOutputStream sendBuf = (ByteArrayOutputStream) UssdRouterMainClient.context.getBean("byteArrayOutputStream");
					tlvAppInterface.setData(UssdRouterConstants.TLV_MSISDN,dataObject.getMsisdn());
					if(dataObject.getUserData().length()>180)
					{
						dataObject.setUserData(dataObject.getUserData().substring(0, 180).toString());
					}
					
					if(UssdRouterMainClient.config.getInt("router.EncriptDecript_Enable") == 1)
					{
					tlvAppInterface.setData(UssdRouterConstants.TLV_DATA, ussdEncriptDecript.encript(dataObject.getUserData().trim()));
					}
					else
					{					
					tlvAppInterface.setData(UssdRouterConstants.TLV_DATA, dataObject.getUserData().trim());
					}
					tlvAppInterface.setData(UssdRouterConstants.TLV_OPCODE, dataObject.getOpCode());
					tlvAppInterface.setData(UssdRouterConstants.TLV_DLGID, dataObject.getDlgId());
					tlvAppInterface.encode(sendBuf);
					int sendRequestLen = sendBuf.size();
					byte[] len=new byte[4];
					len[3]=(byte)(sendRequestLen );
					len[2]=(byte)((sendRequestLen >> 8) );
					len[1]=(byte)((sendRequestLen >> 16));
					len[0]=(byte)((sendRequestLen >> 24));
					this.dataOutputStream.write(len,0, 4); //length sent 
					this.dataOutputStream.write(sendBuf.toByteArray(), 0, sendBuf.toByteArray().length); //actual data sent
					logger.info("##>>RouterResponseSender msisdn["+dataObject.getMsisdn()+"] userData["+dataObject.getUserData().length()+"] Response sent successfully...");
				/*}*/	
			}
			
		}
		catch(Exception exp)
		{
			logger.error("Error occured inside RouterResponseSender"+exp);
			
		}
	}

}
