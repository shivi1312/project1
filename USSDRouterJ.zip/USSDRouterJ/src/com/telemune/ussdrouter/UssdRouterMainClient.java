package com.telemune.ussdrouter;

import java.io.File;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.commons.configuration.CombinedConfiguration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.DefaultConfigurationBuilder;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.telemune.ussdrouter.beans.Global;
import com.telemune.ussdrouter.util.RouterCommonConstants;
public class UssdRouterMainClient {
   private static  Logger logger = Logger.getLogger(UssdRouterMainClient.class);
   public static CombinedConfiguration config;
   public static ApplicationContext context;
   /**
    * @Auther rahul
    * Created On Jan 19, 2018
    * All threads 
    */
    Thread cacheThread = null;
	Thread routerRequestReaderThread = null;
	/*Thread routerQueueReaderThread = null;*/
	//Thread httpQueueReaderThread = null;
	Thread smppQueueReaderThread = null;
	Thread dbQueueReaderThread = null;
	Thread serverAcceptorThread = null;
	
	Thread httpResponseReaderThread = null;
	Thread smppResponseReaderThread = null;
	Thread smppResponseQueueReaderThread = null;
	/*Thread httpResponseQueueReaderThread = null;*/
	Thread routerResponseSenderThread = null;
	Thread sendHttpRequestThread = null;
	Socket socket = null;
	/**
	 * Added by rahul kumar
	 */
	//public static boolean needToStopThread=false;
	public static int restartCount=0;
	private ConcurrentHashMap serverSocketMap=null;
	//public static boolean needToStopHttpThread=false;
	private Socket httpSocketTemp=null;
	Thread routerTPSThread=null;
	
	
	/**
	 * @Auther rahul
	 * Created On Jan 19, 2018
	 * It is used to start all thread at the starting of application
	 */
   private void startApplicationThread()
   {
		try
		{
			//Start the cache thread
			cacheThread = (Thread)context.getBean("cacheThread");
			cacheThread.start();
			logger.info("CacheLoader Thread Started successfully...");
			
			routerTPSThread = (Thread)context.getBean("routerTPSThread");
			routerTPSThread.start();
			logger.info("Router TPS Thread Started successfully...");
			
			serverAcceptorThread = (Thread)context.getBean("serverAcceptorThread");
			serverAcceptorThread.start();
			logger.info("ServerAcceptorThread Thread Started successfully...");
			
			routerRequestReaderThread = (Thread)context.getBean("routerRequestReaderThread");
			routerRequestReaderThread.start();
			logger.info("routerRequestReaderThread Thread Started successfully...");
			
			routerResponseSenderThread = (Thread)context.getBean("routerResponseSenderThread");
			routerResponseSenderThread.start();
			logger.info("routerResponseSenderThread Thread Started successfully...");			
			
			httpResponseReaderThread = (Thread)context.getBean("httpResponseReaderThread");
			httpResponseReaderThread.start();
			logger.info("httpResponseReaderThread Thread Started successfully...");
			
			sendHttpRequestThread = (Thread)context.getBean("sendHttpRequestThread");
			sendHttpRequestThread.start();
			logger.info("sendHttpRequestThread Thread Started successfully...");
		}
		catch(Exception e)
		{
			logger.info("Exception is occured inside startApplicationThread method. ["+e+"]");
		}
   }
   
   /**
    * 
    * @Auther rahul
    * Created On Jan 19, 2018
    */
   
   private void runningApplicationThread()
   {
	   		
		try
		{						
			socket = (Socket) context.getBean("ussdRouterSocket");
			socket.setKeepAlive(true);
			long startTime=0;
			while(true)
			{
				try
				{
					logger.debug("CacheThread isAlive["+cacheThread.isAlive()+"] serverAcceptorThread isAlive["+serverAcceptorThread.isAlive()+"] routerRequestReaderThread isAlive["+routerRequestReaderThread.isAlive()+"]"
						   +"routerResponseSenderThread isAlive["+routerResponseSenderThread.isAlive()+"] httpResponseReaderThread isAlive["+httpResponseReaderThread.isAlive()+"] sendHttpRequestThread isAlive["+sendHttpRequestThread.isAlive()+"] needToStopThread["+Global.needToStopThread+"], needToStopHttpThread["+Global.needToStopHttpThread+"]");				
					if(config.getInt("ROUTER_SEND_URGENT_DATA_FLAG",1)==1)
					{
						try
						{
							socket.sendUrgentData(1);
						}
						catch(Exception e)
						{
							logger.error("Exception is occured when calling socket.sendUrgentData(1)"+e);
							Global.needToStopThread.set(true);						
						}
					}
				if(Global.needToStopThread.get())
				{
					logger.info("Restart count["+restartCount+"] needToStopThread["+Global.needToStopThread+"]");
					try
					{
						serverSocketMap = (ConcurrentHashMap)context.getBean("serverSocketMap");
						if(serverSocketMap!=null && serverSocketMap.size()>0)
						{
							httpSocketTemp=(Socket) serverSocketMap.get(RouterCommonConstants.HTTP_SOCKET);
						}
						Thread.sleep(1*1000);
						stopAllRunningThread();
						Thread.sleep(1*1000);
						
						ThreadPoolExecutor httpExecutor=(ThreadPoolExecutor) context.getBean("httpTaskExecutor");
						httpExecutor.shutdownNow();
						logger.info("HTTP Thread Pool Executor is terminated:["+httpExecutor.isTerminated()+"]");
						ThreadPoolExecutor reqExecutor=(ThreadPoolExecutor) context.getBean("requestTaskExecutor");
						reqExecutor.shutdownNow();			
						logger.info("Request Thread Pool Executor is terminated:["+reqExecutor.isTerminated()+"]");
						ThreadPoolExecutor respExecutor=(ThreadPoolExecutor) context.getBean("responseTaskExecutor");
						respExecutor.shutdownNow();
						logger.info("Response Thread Pool Executor is terminated:["+respExecutor.isTerminated()+"]");
						
						
						
						
						((ConfigurableApplicationContext)context).registerShutdownHook();
						((ConfigurableApplicationContext)context).close();
						context=null;
						logger.info("Application context is closed successfully.");
						Thread.sleep(1*1000);
						restartApplicationThreads();
						serverSocketMap = (ConcurrentHashMap)context.getBean("serverSocketMap");
						if(serverSocketMap!=null)
						{
							logger.info("Goging to set HTTP Socket["+httpSocketTemp+"] into map");
							serverSocketMap.putIfAbsent(RouterCommonConstants.HTTP_SOCKET, httpSocketTemp);
						}
					}
					catch(Exception exp)
					{
						logger.info("Exception while closing application context"+exp);
					}
					
					
				}
					
				if(!cacheThread.isAlive())
				{
					cacheThread = (Thread)context.getBean("cacheThread");
					cacheThread.start();
				}
				if(!serverAcceptorThread.isAlive())
				{
					serverAcceptorThread = (Thread)context.getBean("serverAcceptorThread");
					serverAcceptorThread.start();
				}
				if(!routerRequestReaderThread.isAlive())
				{
					routerRequestReaderThread = (Thread)context.getBean("routerRequestReaderThread");
					routerRequestReaderThread.start();
				}
				if(!routerResponseSenderThread.isAlive())
				{
					routerResponseSenderThread = (Thread)context.getBean("routerResponseSenderThread");
					routerResponseSenderThread.start();
				}				
				if(!httpResponseReaderThread.isAlive())
				{
					httpResponseReaderThread = (Thread)context.getBean("httpResponseReaderThread");
					httpResponseReaderThread.start();
				}
				if(!sendHttpRequestThread.isAlive())
				{
					sendHttpRequestThread = (Thread)context.getBean("sendHttpRequestThread");
		                        sendHttpRequestThread.start();		        

				}
				/*if(config.getInt("HTTP_SEND_URGENT_DATA_FLAG",1)==1)
				{
					serverSocketMap = (ConcurrentHashMap)context.getBean("serverSocketMap");
					if(serverSocketMap!=null)
					{
						Socket httpSocket=null;
						try
						{
							httpSocket=(Socket) serverSocketMap.get(RouterCommonConstants.HTTP_SOCKET);
							if(httpSocket!=null)
							{
								httpSocket.sendUrgentData(1);
							}
						}
						catch(Exception e)
						{
						   if(httpSocket!=null)
							{
							   logger.info("Going to close http socket and remove from server socket map.");
							   httpSocket.close();
							   serverSocketMap.remove(RouterCommonConstants.HTTP_SOCKET);
							   httpSocket=null;
							   Global.needToStopHttpThread.set(true);
							   Global.httpSocketFound.set(false);
							   Global.newHttpSocket.set(true);
							   Global.newHttpResponseSocket.set(true);
							   Thread.sleep(1*1000);
							}
						}					
					}
				}*/
				
				/*if(needToStopHttpThread)
				{
					restartHttpThreads();
				}*/
				Thread.sleep(config.getInt("GATEWAY_URGENT_DATA_RETRY_INTERVAL",1000));
				}
				catch(Exception e)
				{
					logger.info("Going to stop application because of exception ["+e+"]");
					System.exit(1);
					
				}
			}		 
			
		}
		
		catch(Exception exp)
		{
			logger.error("Error occured isnide runningApplicationThread method"+exp);
		}
		
	
   }
   /**
    * 
    * @Auther rahul
    * Created On Jan 19, 2018
    * To stop all running threads
    */
   private void stopAllRunningThread()
   {
	   logger.info("Start executing stopAllRunningThread method.");
	   try
	   {
		   if(cacheThread !=null)
		   {
			   cacheThread.stop();
		   }
		   if(serverAcceptorThread !=null)
		   {
			   serverAcceptorThread.stop();
		   }
		   if(routerRequestReaderThread !=null)
		   {
			   routerRequestReaderThread.stop();
		   }	
		   if(routerResponseSenderThread !=null)
		   {
			   routerResponseSenderThread.stop();
		   }
		   if(httpResponseReaderThread !=null)
		   {
			   httpResponseReaderThread.stop();
		   }		  
		   if(sendHttpRequestThread !=null)
		   {
			   sendHttpRequestThread.stop();
		   }
		   if(socket!=null)
		   {
			   socket.close();
			   socket=null;
		   }
		   logger.info("All the threads are stoped successfully in stopAllRunningThread method.");
	   }
	   catch(Exception e)
	   {
		   logger.error("Exception while stoping all the threads["+e+"]");
	   }	   
	  
   }
   
   /**
    * @Auther rahul
    * Created On Jan 19, 2018
    * Restart all the theads with new context
    */
   private void restartApplicationThreads()
   {
	    logger.info("Inside restartApplicationThreads() method ...");
	    int retryEnable=0;
	    int retryCount=0;
	    int retryGapeInSeconds=0;
	    int count=0;
	    boolean isTry=true;
	    try
	    {
	    	retryGapeInSeconds=UssdRouterMainClient.config.getInt("router.reconnect_retry_time");
	    	while(isTry)
	    	{ 
	    		try
	    		{
	    			context = new ClassPathXmlApplicationContext("applicationContext.xml");
		    		Global.needToStopThread.set(false);
					startApplicationThread();
					socket = (Socket) context.getBean("ussdRouterSocket");
					socket.setKeepAlive(true);
					logger.info("USSDRouter is successfully connected with USSDGateway and needToStopThread["+Global.needToStopThread+"].");
					isTry=false;
	    		}
	    		catch(Exception e)
	    		{
	    			logger.error("Exception inside while of restartApplicationThreads method");
	    			logger.info("Going to sleep for ["+retryGapeInSeconds+"] seconds");
	    			Thread.sleep(retryGapeInSeconds*1000);
	    		}
	    	}	    	
	    }
	    catch(Exception e)
	    {
	    	logger.error("Exception in restartApplicationThreads method."+e);
	    }
		
		
   }
   /**
    * 
    * @Auther rahul
    * Created On Mar 5, 2018
    */
   public void restartHttpThreads()
   {
	   try
	   {
		   logger.info("needToStopHttpThread["+Global.needToStopHttpThread+"],so going to stop http threads.");
		   if(httpResponseReaderThread !=null)
		   {
			   httpResponseReaderThread.stop();
		   }		  
		   if(sendHttpRequestThread !=null)
		   {
			   sendHttpRequestThread.stop();
		   }
		   logger.info("needToStopHttpThread["+Global.needToStopHttpThread+"],so going to restart http threads.");
		   Global.needToStopHttpThread.set(false);
		   httpResponseReaderThread = (Thread)context.getBean("httpResponseReaderThread");
		   httpResponseReaderThread.start();
		   logger.info("httpResponseReaderThread Thread restarted successfully...");
		   sendHttpRequestThread = (Thread)context.getBean("sendHttpRequestThread");
		   sendHttpRequestThread.start();
		   logger.info("needToStopHttpThread["+Global.needToStopHttpThread+"]sendHttpRequestThread Thread restarted successfully...");			
	   }
	   catch(Exception e)
	   {
		   logger.info("Exception while restartHttpThreads."+e);	
	   }	   
   }
   
   
   // To load all the properties from property file
   static {
		try {
			PropertyConfigurator.configure("properties/UssdRouter_log.properties");
			DefaultConfigurationBuilder builder = new DefaultConfigurationBuilder();
			builder.setFile(new File("config.xml"));
			config = builder.getConfiguration(true);
				logger.info("Configuration file loaded successfully..");
		} catch (ConfigurationException ce) {
			logger.error("Error occured while loading configuration file"+ce);
		} catch (Exception e) {
			logger.error("Error occured while loading configuration file"+e);
		}
	}
      
   
	public static void main(String arg[])
	{
		UssdRouterMainClient routerClient=new UssdRouterMainClient();
		try
		{			
			/**
			 * Initialize and run all the threads
			 */
			logger.info("Inside main() method ...");
		/*	LCheck lck=new LCheck();
            Thread thlck=new Thread(lck);
            thlck.start();
            Thread th=new Thread();
            th.sleep(1000);
            logger.info("LIC :["+lck.checkLic()+"]");
            Global.maxTps.set(lck.checkLic());
            //Global.maxTps.set(2);// Need to remove
            logger.info("Max TPS :["+Global.maxTps+"]");*/
			context = new ClassPathXmlApplicationContext("applicationContext.xml");
			routerClient.startApplicationThread();
			
			/**
			 * Start monitoring all the running thread to read the request 
			 */
			routerClient.runningApplicationThread();
			
						
		}
		catch(Exception e)
		{
			routerClient=null;
			logger.info("Exception inside main ["+e+"]");
		}
		
	}
	
	

	
}
