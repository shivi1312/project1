package com.telemune.ussdrouter;

import java.util.concurrent.ArrayBlockingQueue;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.beans.DataObject;
import com.telemune.ussdrouter.util.UssdUtils;

public class HttpQueueReader implements Runnable{
	private Logger logger = Logger.getLogger(HttpQueueReader.class);
	//private ArrayBlockingQueue httpReqQueue = null;
	private UssdUtils ussdUtils = null;
	//private Socket httpSocket = null;
	//private ConcurrentHashMap serverSocketMap = null;
	private ArrayBlockingQueue routerResQueue = null;
	private ArrayBlockingQueue httpTlvReqQueue = null;
	//private boolean httpSocketFound = false;
	private DataObject dataObject = null;
	
	public DataObject getDataObject() {
		return dataObject;
	}

	public void setDataObject(DataObject dataObject) {
		this.dataObject = dataObject;
	}

	
	public HttpQueueReader() {
		// TODO Auto-generated constructor stub
	}
	//public HttpQueueReader(ArrayBlockingQueue httpReqQueue , UssdUtils ussdUtils , ArrayBlockingQueue routerResQueue , ArrayBlockingQueue httpTlvReqQueue) {
	public HttpQueueReader(UssdUtils ussdUtils , ArrayBlockingQueue routerResQueue , ArrayBlockingQueue httpTlvReqQueue) {
//		this.httpReqQueue = httpReqQueue;
		this.ussdUtils = ussdUtils;
		//this.serverSocketMap = serverSocketMap;
		this.routerResQueue = routerResQueue;
		this.httpTlvReqQueue = httpTlvReqQueue;
	}
	
	
	
	public void run() {
		
		/*try
		{
		while(true)
		{
		 if(httpSocketFound)
		 {
			 break;
		 }
		 else
		 {	 
			 Set serverSocketSet = this.serverSocketMap.entrySet();
			 Iterator serverSocketItr =  serverSocketSet.iterator();			
			 while(serverSocketItr.hasNext()){
				 Map.Entry entry = (Map.Entry) serverSocketItr.next();
				 String connectionType = (String) entry.getKey();
				 if(connectionType.equalsIgnoreCase("HTTP"))
				 {
					 logger.info("Http already connected so Http Socket is ["+entry.getValue()+"]");
					 this.httpSocket = (Socket) entry.getValue();
					 httpSocketFound = true;
				 }
			 }
		 }
		}
		logger.debug("Inside Run Method of HttpQueueReader httpSocket is ["+this.httpSocket+"]");
		}
		catch(Exception exp)
		{
			logger.error("##>>Error occured inside HttpQueueReader Run method"+exp);
			
		}*/
		/*while(true)
		{*/
			try{
				/*if(this.httpReqQueue.isEmpty())
				{
					Thread.sleep(UssdRouterMainClient.config.getInt("router.httpQueueReaderThread_SleepTime")); //should be configurable
				}
				else
				{*/
				 int sendRequestToHttp = -1; 
				 // logger.info("inside HttpQueueReader Going to take element if available ...");
				 //DataObject dataObject = (DataObject) this.httpReqQueue.poll();
				 //DataObject dataObject = (DataObject) this.httpReqQueue.take();
				 logger.info("##>>msisdn["+dataObject.getMsisdn()+"] inside HttpQueueReader sendRequestToCharging["+dataObject.getSendRequestToCharging()+"]");
				 if(dataObject.getSendRequestToCharging())
				 {
			      	  int responseFromCharging = -1; 
				      UssdChargingRequest ussdChargingRequest = (UssdChargingRequest) UssdRouterMainClient.context.getBean("ussdChargingRequest");
				      responseFromCharging = ussdChargingRequest.sendData(dataObject);
				      logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Response from charging is response["+responseFromCharging+"]");
				      if(responseFromCharging == 1)
				      {
				    	  if(dataObject.isFirstChgReq())
				    	  {
				    		  if(dataObject.getChargeStatus() < 0)
				    		  {
				    			  dataObject.ussdErrorCodeBean = this.ussdUtils.getErrorMessage("3_"+UssdRouterMainClient.config.getInt("router.defaultLanguage_Id"));
				    			  dataObject.setErrorCode(UssdRouterConstants.LOW_BALANCE);
				    			  dataObject.setUserData(dataObject.ussdErrorCodeBean.getErrorStr());
				    			  dataObject.setOpCode(UssdRouterConstants.PSSR_RESP);
				    			  dataObject.setSendRequestToCharging(false);
				    			  this.routerResQueue.put(dataObject); // Set the data for gateway response
				    		  }
				    		  else
				    		  {
				    			 //having doubt
				    			 //send Response
				    			sendRequestToHttp = 1;
				    			   
				    		  } 
				    	  }
				    	  
				      }
				      ussdChargingRequest = null; //Charging bean nullify
				 }
				 else
				 {
					 sendRequestToHttp = 1;
				 }
				 
				 if(sendRequestToHttp == 1)
				 {
				  int status = -1;
				  	  logger.info("set the data for send http request");
			          this.httpTlvReqQueue.put(dataObject);	// set the data for send http request
				  
	    			  /*HttpOutputStreamFactory outputStreamFactory = (HttpOutputStreamFactory) UssdRouterMainClient.context.getBean("httpOutputStreamBean");
	    			  logger.debug("HttpOutputStreamFactory inside HttpQueueReader["+outputStreamFactory+"] httpSocketOutputStream["+this.httpSocket+"]");
	    			  outputStreamFactory.setOutputStream(this.httpSocket.getOutputStream());                       
	    			  DataOutputStream dataOutputStream = (DataOutputStream) UssdRouterMainClient.context.getBean("httpDataOutputStream");
	    			  logger.debug("Isnide HttpQueueReader dataOutputStream["+dataOutputStream+"]");
	    			  SendHttpRequest sendHttpClient = (SendHttpRequest) UssdRouterMainClient.context.getBean("sendHttpRequest");
	    			  status = sendHttpClient.sendHttpRequestData(dataObject, this.httpSocket , dataOutputStream);
	    			  if(status == 1)
	    			  {
	    				  logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Request successfully sent to Http module");
	    			  }
	    			  dataOutputStream = null;
	    			  sendHttpClient = null;
	    			  outputStreamFactory = null;*/
				 }
				/*}*/
			}
			catch(Exception exp)
			{
				logger.error("##>>Error occured inside HttpQueueReader at second loop"+exp);
			}
		/*}*/
		
	}
	
}
