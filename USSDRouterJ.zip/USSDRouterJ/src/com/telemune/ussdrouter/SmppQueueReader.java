package com.telemune.ussdrouter;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.telemune.ussdrouter.util.UssdUtils;

public class SmppQueueReader implements Runnable{
Logger logger=Logger.getLogger(SmppQueueReader.class);
private ArrayBlockingQueue smppReqQueue = null;
private UssdUtils ussdUtils = null;
private ConcurrentHashMap serverSocketMap = null;
	
	public SmppQueueReader() {
		// TODO Auto-generated constructor stub
	}
	public SmppQueueReader(ArrayBlockingQueue smppReqQueue , UssdUtils ussdUtils , ConcurrentHashMap serverSocketMap) {
		this.smppReqQueue = smppReqQueue;
		this.ussdUtils = ussdUtils;
		this.serverSocketMap = serverSocketMap;
	}
	
	
	
	public void run() {
		
		logger.debug("Inside Run Method of SmppQueueReader smppReqQueue["+smppReqQueue+"]");
	}
	

}
