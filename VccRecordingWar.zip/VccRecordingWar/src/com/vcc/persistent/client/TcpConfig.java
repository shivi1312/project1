package com.vcc.persistent.client;

@SuppressWarnings("serial")
public class TcpConfig implements java.io.Serializable {

	private String host;
	private int port;
	private int bufferSize;
	private String codec;
	private int maxTotalTcp;
	private int maxIdealTcp;
	private int minIdealTcp;
	private boolean testOnBorrow;
	private boolean testOnReturn;
	private int requestTimedOut = 30;
	private int readTimedOut = 30;
	private int maxWaitMillis;
	private boolean blockWhenExhausted;
	private String product;
	private int connectTimeout = 5000;

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public int getBufferSize() {
		return bufferSize;
	}

	public void setBufferSize(int bufferSize) {
		this.bufferSize = bufferSize;
	}

	public String getCodec() {
		return codec;
	}

	public void setCodec(String codec) {
		this.codec = codec;
	}

	public int getMaxTotalTcp() {
		return maxTotalTcp;
	}

	public void setMaxTotalTcp(int maxTotalTcp) {
		this.maxTotalTcp = maxTotalTcp;
	}

	public int getMaxIdealTcp() {
		return maxIdealTcp;
	}

	public void setMaxIdealTcp(int maxIdealTcp) {
		this.maxIdealTcp = maxIdealTcp;
	}

	public int getMinIdealTcp() {
		return minIdealTcp;
	}

	public void setMinIdealTcp(int minIdealTcp) {
		this.minIdealTcp = minIdealTcp;
	}

	public boolean getTestOnBorrow() {
		return testOnBorrow;
	}

	public void setTestOnBorrow(boolean testOnBorrow) {
		this.testOnBorrow = testOnBorrow;
	}

	public boolean getTestOnReturn() {
		return testOnReturn;
	}

	public void setTestOnReturn(boolean testOnReturn) {
		this.testOnReturn = testOnReturn;
	}

	public int getRequestTimedOut() {
		return requestTimedOut;
	}

	public void setRequestTimedOut(int requestTimedOut) {
		this.requestTimedOut = requestTimedOut;
	}

	public int getReadTimedOut() {
		return readTimedOut;
	}

	public void setReadTimedOut(int readTimedOut) {
		this.readTimedOut = readTimedOut;
	}

	public int getMaxWaitMillis() {
		return maxWaitMillis;
	}

	public void setMaxWaitMillis(int maxWaitMillis) {
		this.maxWaitMillis = maxWaitMillis;
	}

	public boolean geBlockWhenExhausted() {
		return blockWhenExhausted;
	}

	public void setBlockWhenExhausted(boolean blockWhenExhausted) {
		this.blockWhenExhausted = blockWhenExhausted;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public int getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}
	
	
}
