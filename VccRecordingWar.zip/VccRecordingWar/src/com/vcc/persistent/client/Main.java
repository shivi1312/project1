package com.vcc.persistent.client;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;


public class Main {
	@SuppressWarnings("unused")
	private final static Logger logger = Logger.getLogger(Client.class);
	
	public static void main(String[] args) throws Exception {
		try {
			TcpClient tcpClient = TcpConnectionUtil.getInstance("rule").getConnection();
			ExecutorService executorService = Executors.newFixedThreadPool(100);
			for (int i = 0; i < 3; i++) {
				try{
					executorService.execute(new Worker(tcpClient,""+i));
					Thread.sleep(1000/1);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
