package com.vcc.persistent.client;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.log4j.Logger;

import com.tele.config.AppConfig;
import com.vcc.persistent.client.codec.TeleRequest;

@SuppressWarnings("unused")
public class TcpConnectionUtil {
	private final static Logger logger = Logger
			.getLogger(TcpConnectionUtil.class);
	private static Map<String, TcpConnectionUtil> map = new ConcurrentHashMap<String, TcpConnectionUtil>();
	private static Map<String, Boolean> keyValidateMap = new ConcurrentHashMap<String, Boolean>();
	private static ConcurrentMap<Integer, Object> responseMap = new ConcurrentHashMap<Integer, Object>();
	private TcpConfig tcpConfig = null;
	private String product;
	private TcpClient tcpClient = null;

	private TcpConnectionUtil() {

	}

	public static TcpConnectionUtil getInstance(String product)
			throws Exception {
		TcpConnectionUtil _instance = map.get(product);
		if (_instance == null) {
			_instance = new TcpConnectionUtil(product);
			map.put(product, _instance);
		}
		return _instance;
	}

	private TcpConnectionUtil(String product) throws Exception {
		this.product = product;
		tcpConfig = new TcpConfig();
		this.setConfiguration(product);
		this.tcpClient = new TcpClient(this.tcpConfig);
	}
	public TcpClient getConnection(){
		return this.tcpClient;
	}
	private void setConfiguration(String product) {
		tcpConfig.setHost(AppConfig.config.getString(product + ".tcp.host",
				"127.0.0.1"));
		tcpConfig.setPort(AppConfig.config.getInt(product + ".tcp.port", 9123));
		tcpConfig.setBufferSize(AppConfig.config.getInt(product
				+ ".tcp.buffer.size", 1024));
		tcpConfig.setCodec(AppConfig.config.getString(product + ".tcp.codec"));
		tcpConfig.setRequestTimedOut(AppConfig.config.getInt(product
				+ ".tcp.request.timed.out", 30));
		tcpConfig.setReadTimedOut(AppConfig.config.getInt(product
				+ ".tcp.read.timed.out", 30));
		tcpConfig.setProduct(product);
	}

	/***
	 ** @param {TeleRequest}
	 ** @return {void}
	 ** @see {Single concurrent map which is store response in map}
	 ***/
	public static void responseRecieved(TeleRequest tlvRequest) {
		logger.debug(String.format("Recieve Response {%s}",
				tlvRequest.getCorrelationId()));
		if (responseMap.get(tlvRequest.getCorrelationId()) != null) {
			((TeleRequest) responseMap.get(tlvRequest.getCorrelationId()))
					.responseReceived(tlvRequest.getResponse());
		} else {
			logger.error("This response is already timedout: "
					+ tlvRequest.getCorrelationId());
		}

	}

	public static void putRequest(TeleRequest teleRequest) {
		logger.debug(String.format("Put in map for {%s}",
				teleRequest.getCorrelationId()));
		responseMap.put(teleRequest.getCorrelationId(), teleRequest);
	}

	public static void removeRequest(TeleRequest teleRequest) {
		logger.debug(String.format("Remove from map for {%s}",
				teleRequest.getCorrelationId()));
		responseMap.remove(teleRequest.getCorrelationId());
	}
}
