/*package com.vcc.persistent.client;

import org.apache.log4j.Logger;

import com.vcc.config.AppConfig;

public class ReconnectionThread extends Thread {

	private TcpClient tcpClient = null;
	private Logger logger = Logger.getLogger(ReconnectionThread.class);
	private boolean mcaConnected = false;

	public ReconnectionThread(TcpClient tcpClient) {
		this.tcpClient = tcpClient;
	}

	public void run() {
		logger.info("Reconnection Thread Started.....");
		while (true) {

			try {
				mcaConnected = tcpClient.connect();
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Exception occurred while connecting MCAHandler from ReconnectionThread. Error["
						+ e + "]");
			}

			if (mcaConnected) {
				logger.info("Reconnection with MCAHandler done successfully.");
				break;
			} else {
				try {
					Thread.sleep(AppConfig.config.getInt(
							"RECONNECTION_SLEEP_TIME", 2000));
				} catch (InterruptedException e) {
					logger.error("ReconnectionThread Interrupted. Error[" + e
							+ "]");
					e.printStackTrace();
				}
			}
		}
	}
}
*/


