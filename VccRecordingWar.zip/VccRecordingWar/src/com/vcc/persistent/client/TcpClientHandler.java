package com.vcc.persistent.client;

import org.apache.log4j.Logger;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;

import com.vcc.persistent.client.codec.TeleRequest;

public class TcpClientHandler extends IoHandlerAdapter {

	private final static Logger logger = Logger.getLogger(TcpClientHandler.class);

	public TcpClientHandler() {

	}

	@Override
	public void sessionOpened(IoSession session) {

	}

	@Override
	public void messageReceived(IoSession session, Object message) {
		TeleRequest teleRequest = (TeleRequest)message;
		logger.info("Recieve Response: " + teleRequest.getResponse());
		if(teleRequest.getModeType().equals("sync"))
			TcpConnectionUtil.responseRecieved(teleRequest);
	}

	@Override
	public void exceptionCaught(IoSession session, Throwable cause) {
		logger.error("Exception occurred in the normal course of handling remote connections. Error["
				+ cause.getMessage() + "; " + cause.getStackTrace() + "]");
		session.closeNow();
	}
	
	@Override
    public void sessionIdle( IoSession session, IdleStatus status )
    {
        System.out.println( "IDLE " + session.getIdleCount( status ));
    }
}
