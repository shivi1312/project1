package com.vcc.persistent.client.codec;

import java.nio.charset.Charset;

import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;

public class TeleCodecFactory implements ProtocolCodecFactory {
	private ProtocolEncoder encoder;
    private ProtocolDecoder decoder;
    
    public TeleCodecFactory(Charset charset, boolean client) {
    	if (client) {
            encoder = new TeleRequestEncoder(charset);
            decoder = new TeleResponseDecoder(charset);
        } else {
            encoder = new TeleResponseEncoder(charset);
            decoder = new TeleRequestDecoder(charset);
        }
    }
    
    public ProtocolEncoder getEncoder(IoSession ioSession) throws Exception {
        return encoder;
    }

    public ProtocolDecoder getDecoder(IoSession ioSession) throws Exception {
        return decoder;
    }
    
}
