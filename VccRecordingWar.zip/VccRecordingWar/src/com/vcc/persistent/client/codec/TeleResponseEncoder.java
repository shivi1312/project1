package com.vcc.persistent.client.codec;

import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;

import org.apache.log4j.Logger;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.AttributeKey;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolEncoderAdapter;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;

public class TeleResponseEncoder extends ProtocolEncoderAdapter {
	private final static Logger logger = Logger.getLogger(TeleResponseEncoder.class);
	private final AttributeKey ENCODER = new AttributeKey(getClass(), "encoder");
	private Charset charset;

	public TeleResponseEncoder(Charset charset) {
		this.charset = charset;
	}

	@Override
	public void encode(IoSession session, Object message,
			ProtocolEncoderOutput out) throws Exception {
		
		logger.info("Server side encoder...........");
		CharsetEncoder encoder = (CharsetEncoder) session.getAttribute(ENCODER);
		if (encoder == null) {
			encoder = charset.newEncoder();
            session.setAttribute(ENCODER, encoder);
		}
		
		TeleRequest response = (TeleRequest) message;
		logger.info("Server side encoder..........."+response.getRequest());
		IoBuffer buffer = IoBuffer.allocate(8 + response.getRequest().length())
				.setAutoExpand(true);
		buffer.putInt(4 + response.getResponse().getBytes(charset).length);
		buffer.putInt(response.getCorrelationId());
		buffer.putString(response.getResponse(), encoder);
		buffer.flip();
		out.write(buffer);
	}
}
