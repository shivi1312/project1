package com.vcc.persistent.client.codec;

import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;

import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.AttributeKey;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.CumulativeProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolDecoderOutput;

@SuppressWarnings("unused")
public class TeleResponseDecoder extends CumulativeProtocolDecoder {

	private final AttributeKey DECODER = new AttributeKey(getClass(), "decoder");
	private Charset charset;

	public TeleResponseDecoder(Charset charset) {
		this.charset = charset;
	}

	protected boolean doDecode(IoSession session, IoBuffer in,
			ProtocolDecoderOutput out) throws Exception {
		CharsetDecoder decoder = (CharsetDecoder) session.getAttribute(DECODER);
		if (decoder == null) {
			decoder = charset.newDecoder();
			session.setAttribute(DECODER, decoder);
		}
		if (in.prefixedDataAvailable(4)) {
			int length = in.getInt();
			int correlationId = in.getInt();
			length = length - 4;
			byte[] bytes = new byte[length];
			in.get(bytes);
			CharBuffer buffer = decoder.decode(ByteBuffer.wrap(bytes));
			TeleRequest response = new TeleRequest();
			response.setCorrelationId(correlationId);
			response.setResponse(new String(buffer.array()));
			out.write(response);
			return true;
		} else {
			return false;
		}
	}
}
