package com.vcc.persistent.client;

import org.apache.log4j.Logger;

public class Worker implements Runnable{
	private final static Logger logger = Logger.getLogger(Worker.class);
	private Client client = null;
	private String msg = null;
	public Worker(Client client, String msg){
		this.client = client;
		this.msg = msg;
	}
	@Override
	public void run(){
		try{
			String response = client.writeAsSync(msg);
			logger.info("Response: "+response);
		}catch(Exception e){
			
			System.out.println("Error: "+e.getMessage());
		}
	}
}
