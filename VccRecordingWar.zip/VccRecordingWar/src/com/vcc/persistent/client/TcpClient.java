/*package com.vcc.persistent.client;

import java.net.InetSocketAddress;
import java.nio.charset.Charset;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.mina.core.RuntimeIoException;
import org.apache.mina.core.future.CloseFuture;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.future.IoFuture;
import org.apache.mina.core.future.IoFutureListener;
import org.apache.mina.core.future.WriteFuture;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.logging.LoggingFilter;
import org.apache.mina.transport.socket.nio.NioSocketConnector;

import com.vcc.config.AppConfig;
import com.vcc.persistent.client.codec.TeleCodecFactory;
import com.vcc.persistent.client.codec.TeleRequest;

public class TcpClient implements Client {
	private final static Logger logger = Logger.getLogger(TcpClient.class);
	private final static Logger errorLogger = Logger.getLogger("errorLogger");
	private static NioSocketConnector connector = null;
	private TcpConfig tcpConfig = null;
	private IoSession session = null;
	private static CloseFuture closeFuture = null;
	private static boolean isClosingSessionInitiated=true;
	private static boolean mcaConnected=false;
	private static boolean firstTry=false;

	public TcpClient() {

	}

	public TcpClient(TcpConfig tcpConfig) {
		this.tcpConfig = tcpConfig;
		try {
			firstTry=true;
			this.connect();
			
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-IVRWAR-")
					+ "00062] [Exception in Connecting Product["
					+ tcpConfig.getProduct() + "]] Error[" + e.getMessage()
					+ "]");
			e.printStackTrace();
			logger.error(String.format("Product [%s] is not connect: %s",
					tcpConfig.getProduct(), e.getMessage()));
		}
	}

	public boolean connect() throws Exception {
		this.setConfiguration();
		logger.info("Trying to connect to Host: " + this.tcpConfig.getHost() + " and Port: "
				+ this.tcpConfig.getPort());
		try {
			ConnectFuture connectFuture = connector.connect(new InetSocketAddress(
					this.tcpConfig.getHost(), this.tcpConfig.getPort()));
			

			connectFuture.awaitUninterruptibly();
			this.session = connectFuture.getSession();
			
			
			
			logger.info("IsDisposed["
					+ this.connector.isDisposed() + "] IsDisposing["
					+ this.connector.isDisposing()
					+ "] Connector Session Active Status >>>>>>> "
					+ session.isActive());
			
			// Get the close future for this session
			closeFuture = connectFuture.getSession().getCloseFuture();
						
			// Adding a listener to this close event
			closeFuture.addListener((IoFutureListener<?>) new IoFutureListener<IoFuture>() {
			        @Override
			        public void operationComplete(IoFuture future) {
			        	isClosingSessionInitiated=false;
			            logger.info("The session is now successfully closed.");
			            
			        }
			});
			
			mcaConnected=true;
			isClosingSessionInitiated=false;
			
		} catch (RuntimeIoException e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-IVRWAR-")
					+ "90020] [RunTimeIOException While connecting Host["
					+ this.tcpConfig.getHost() + "]] Error[" + e.getMessage()
					+ "]]");
			logger.error(e.getMessage());
			mcaConnected=false;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			mcaConnected=false;
			logger.error("Exception occurred while creating NioProcessor. Error["+e+"]");
		}
		
		if (!connector.isActive()) {
			logger.info("Host: " + this.tcpConfig.getHost() + " and port: "
					+ this.tcpConfig.getPort() + " could not connect");
			connector.dispose();
			closeConnectorSession();
		}
		return mcaConnected;
	}

	private void setConfiguration() {
		connector = new NioSocketConnector();

		logger.info("Connect timeout: " + this.tcpConfig.getConnectTimeout()
				+ " codec: " + this.tcpConfig.getCodec());
		connector.setConnectTimeoutMillis(this.tcpConfig.getConnectTimeout());
		connector.getFilterChain().addLast(
				"codec",
				new ProtocolCodecFilter(new TeleCodecFactory(Charset
						.forName(this.tcpConfig.getCodec()), true)));
		connector.getFilterChain().addLast("logger", new LoggingFilter());
		connector.setHandler(new TcpClientHandler());
	}

	private synchronized void reconnect(TeleRequest teleRequest)
			throws Exception {
		//connector.dispose();
		if (this.session == null || !this.session.isActive())
		{
			this.connect();
		}
		if (this.session != null && this.session.isActive()) {
			logger.info("Reconnection done successfull. Now going to write.");
			this.session.write(teleRequest);
		} else {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-IVRWAR-")
					+ "00063] [Failed to reconnect MCA Handler]");
			logger.info("Failed to reconnect!...Error");
			return;
		}
	}
	
	private synchronized void reSendingRequest(String mcnRequest)
			throws Exception {
		//connector.dispose();
		
		if (this.session == null || !this.session.isActive())
		{
			logger.info("MCA Not Conneted. Discarding MCN trigger Request["+mcnRequest+"]");
		}
		
		if (this.session != null && this.session.isActive()) {
			TeleRequest teleRequest = new TeleRequest(mcnRequest);
			logger.info("Rewritting MCN Trigger Request.");
			this.session.write(teleRequest);
		} else {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-IVRWAR-")
					+ "00063] [Failed to reconnect MCA Handler]");
			//logger.info("Failed to reconnect!...Error");
			return;
		}
	}

	@Override
	public void write(String value) {
		TeleRequest teleRequest = new TeleRequest(value);
		if (this.session != null && this.session.isActive()) {
			this.session.write(teleRequest);
		} else {
			logger.info("Connection is break now reconnect");
			try {
				if (this.session != null) {
					
					synchronized(this)
					{
						if(firstTry)
						{
							startReconnectionThread();
						}
						if(!isClosingSessionInitiated)
						{
							logger.info("Process for closing the session has been initiated.");
							closeConnectorSession();
							isClosingSessionInitiated=true;
						}
					}
					
					
					this.session.getCloseFuture().awaitUninterruptibly();
				}
				//this.reconnect(teleRequest);
				this.reSendingRequest(value);
			} catch (Exception e) {
				errorLogger.error("ErrorCode ["
						+ AppConfig.config.getString("errorcode_pattern",
								"VCC-IVRWAR-")
						+ "00063] [Exception reconnect MCA Handler] Error["
						+ e.getMessage() + "]");
				logger.info("Excepton while reconnect: " + e.getMessage());
			}
		}
	}

	public String writeAsSync(String message) {
		TeleRequest teleRequest = new TeleRequest(message);
		teleRequest.setModeType("sync");
		TcpConnectionUtil.putRequest(teleRequest);
		WriteFuture writeFuture = this.session.write(teleRequest);
		logger.debug("Session id: " + this.session.getId());
		try {
			if (!writeFuture.await(this.tcpConfig.getRequestTimedOut(),
					TimeUnit.SECONDS)) {
				logger.info(String.format(
						"Error for {%s: [%s]} is request timedout",
						teleRequest.getCorrelationId(),
						this.tcpConfig.getProduct()));
				throw new Exception(
						String.format(
								"Could not sent request in {%s seconds} for {%s: [%s]}",
								this.tcpConfig.getRequestTimedOut(),
								teleRequest.getCorrelationId(),
								this.tcpConfig.getProduct()));
			}
			if (writeFuture.getException() != null) {
				throw writeFuture.getException();
			}
			teleRequest.waitResponse(this.tcpConfig.getReadTimedOut(),
					TimeUnit.SECONDS);
			TcpConnectionUtil.removeRequest(teleRequest);
			if (teleRequest.getResponse() == null) {
				logger.info(String.format(
						"Error for {%s: [%s]} is read timedout",
						teleRequest.getCorrelationId(),
						this.tcpConfig.getProduct()));
				throw new Exception(
						String.format(
								"Could not receive the response in {%s seconds} for {%s: [%s]}",
								this.tcpConfig.getReadTimedOut(),
								teleRequest.getCorrelationId(),
								this.tcpConfig.getProduct()));
			}
			logger.info(String.format("Response for {%s: [%s]} is getting",
					teleRequest.getCorrelationId(), this.tcpConfig.getProduct()));
		} catch (InterruptedException e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "90013] [InterruptedException while writing Data to MCA Handler] Error["
							+ e.getMessage() + "]");
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00064] [Exception while writing Data to MCA Handler] Error["
							+ e.getMessage() + "]");
		} catch (Throwable e) {

		}
		return teleRequest.getResponse();
	}

	public void closeConnectorSession() {
		//logger.info("<<<<<< Closing Connection >>>>>>>>>");
		// Do the close requesting without waiting for the pending messages 
		try
		{
			closeFuture.getSession().close(true);
			closeFuture.awaitUninterruptibly();
			logger.info("Session isClosed["+closeFuture.isClosed()+"]");
			if(closeFuture.isClosed())
			{
				connector.dispose();
				logger.info("Connector IsDisposed["
						+ connector.isDisposed() + "] IsDisposing["
						+ connector.isDisposing()
						+ "]");
			}
		}
		catch(Exception e)
		{
			logger.error("Exception occurred during the process of closing the session.CloseFuture["
					+ closeFuture
					+ "] Session ["+closeFuture.getSession()+"] Connector["
					+ connector
					+ "] Error["
					+ e
					+ "]");
		}
		startReconnectionThread();
	}

	public void startReconnectionThread()
	{
		firstTry=false;
		ReconnectionThread reconnectThread=new ReconnectionThread(this);
		reconnectThread.start();
	}
	
	@Override
	public void closeSession() {
		if (this.session != null)
			this.session.closeOnFlush();
	}
	
	public static void close() {
        //logger.info("<<<<<< Closing Connection >>>>>>>>>");
        connector.dispose();
	}
	
}
*/


package com.vcc.persistent.client;

import java.net.InetSocketAddress;
import java.nio.charset.Charset;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.mina.core.RuntimeIoException;
import org.apache.mina.core.future.CloseFuture;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.future.IoFuture;
import org.apache.mina.core.future.IoFutureListener;
import org.apache.mina.core.future.WriteFuture;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.logging.LoggingFilter;
import org.apache.mina.transport.socket.nio.NioSocketConnector;

import com.vcc.config.AppConfig;
import com.vcc.persistent.client.codec.TeleCodecFactory;
import com.vcc.persistent.client.codec.TeleRequest;

public class TcpClient implements Client {
	private final static Logger logger = Logger.getLogger(TcpClient.class);
	private final static Logger errorLogger = Logger.getLogger("errorLogger");
	private static NioSocketConnector connector = null;
	private TcpConfig tcpConfig = null;
	private IoSession session = null;
	private static CloseFuture closeFuture = null;
	private static boolean isClosingSessionInitiated=true;

	public TcpClient() {

	}

	public TcpClient(TcpConfig tcpConfig) {
		this.tcpConfig = tcpConfig;
		try {
			this.connect();
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-IVRWAR-")
					+ "00062] [Exception in Connecting Product["
					+ tcpConfig.getProduct() + "]] Error[" + e.getMessage()
					+ "]");
			e.printStackTrace();
			logger.error(String.format("Product [%s] is not connect: %s",
					tcpConfig.getProduct(), e.getMessage()));
		}
	}

	/*private void connect() throws Exception {
		this.setConfiguration();
		logger.info("Host: " + this.tcpConfig.getHost() + " and Port: "
				+ this.tcpConfig.getPort());
		try {
			ConnectFuture future = connector.connect(new InetSocketAddress(
					this.tcpConfig.getHost(), this.tcpConfig.getPort()));
			future.awaitUninterruptibly();
			this.session = future.getSession();
		} catch (RuntimeIoException e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-IVRWAR-")
					+ "90020] [RunTimeIOException While connecting Host["
					+ this.tcpConfig.getHost() + "]] Error[" + e.getMessage()
					+ "]]");
			logger.error(e.getMessage());
		}

		if (!connector.isActive()) {
			logger.info("Host: " + this.tcpConfig.getHost() + " and port: "
					+ this.tcpConfig.getPort() + " could not connect");
			connector.dispose();
		}
	}*/
	
	public void connect() throws Exception {
		this.setConfiguration();
		logger.info("Trying to connect to Host: " + this.tcpConfig.getHost() + " and Port: "
				+ this.tcpConfig.getPort());
		try {
			ConnectFuture connectFuture = connector.connect(new InetSocketAddress(
					this.tcpConfig.getHost(), this.tcpConfig.getPort()));
			

			connectFuture.awaitUninterruptibly();
			this.session = connectFuture.getSession();
			
			
			
			/*logger.info("IsDisposed["
					+ connector.isDisposed() + "] IsDisposing["
					+ connector.isDisposing()
					+ "] Connector Session Active Status >>>>>>> "
					+ session.isActive());*/
			
			// Get the close future for this session
			closeFuture = connectFuture.getSession().getCloseFuture();
						
			// Adding a listener to this close event
			closeFuture.addListener((IoFutureListener<?>) new IoFutureListener<IoFuture>() {
			        @Override
			        public void operationComplete(IoFuture future) {
			        	isClosingSessionInitiated=false;
			            logger.info("The session is now successfully closed.");
			            
			        }
			});
			
			//mcaConnected=true;
			//isClosingSessionInitiated=false;
			
		} catch (RuntimeIoException e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-IVRWAR-")
					+ "90020] [RunTimeIOException While connecting Host["
					+ this.tcpConfig.getHost() + "]] Error[" + e.getMessage()
					+ "]]");
			logger.error(e.getMessage());
			//mcaConnected=false;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//mcaConnected=false;
			logger.error("Exception occurred while creating NioProcessor. Error["+e+"]");
		}
		
		/*if (!connector.isActive()) {
			logger.info("Host: " + this.tcpConfig.getHost() + " and port: "
					+ this.tcpConfig.getPort() + " could not connect");
			//connector.dispose();
			closeConnectorSession();
		}*/
		//return mcaConnected;
	}

	private void setConfiguration() {
		connector = new NioSocketConnector();

		logger.info("Connect timeout: " + this.tcpConfig.getConnectTimeout()
				+ " codec: " + this.tcpConfig.getCodec());
		connector.setConnectTimeoutMillis(this.tcpConfig.getConnectTimeout());
		connector.getFilterChain().addLast(
				"codec",
				new ProtocolCodecFilter(new TeleCodecFactory(Charset
						.forName(this.tcpConfig.getCodec()), true)));
		connector.getFilterChain().addLast("logger", new LoggingFilter());
		connector.setHandler(new TcpClientHandler());
	}

	private synchronized void reconnect(TeleRequest teleRequest)
			throws Exception {
		//connector.dispose();
		if (this.session == null || !this.session.isActive())
			this.connect();
		if (this.session != null && this.session.isActive()) {
			logger.info("Reconnection is successed. now going to write");
			this.session.write(teleRequest);
		} else {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-IVRWAR-")
					+ "00063] [Failed to reconnect MCA Handler]");
			logger.info("Failed to reconnect!...Error");
			return;
		}
	}

	@Override
	public void write(String value) {
		TeleRequest teleRequest = new TeleRequest(value);
		if (this.session != null && this.session.isActive()) {
			this.session.write(teleRequest);
		} else {
			logger.info("Connection is break now reconnect");
			try {
				if (this.session != null) {
					
					synchronized(this)
					{
						if(!isClosingSessionInitiated)
						{
							isClosingSessionInitiated=true;
							logger.info("Process for closing the session has been initiated.");
							closeConnectorSession();
						}
					}
					
				}
				this.reconnect(teleRequest);
			} catch (Exception e) {
				errorLogger.error("ErrorCode ["
						+ AppConfig.config.getString("errorcode_pattern",
								"VCC-IVRWAR-")
						+ "00063] [Exception reconnect MCA Handler] Error["
						+ e.getMessage() + "]");
				logger.info("Excepton while reconnect: " + e.getMessage());
			}
		}
	}

	public String writeAsSync(String message) {
		TeleRequest teleRequest = new TeleRequest(message);
		teleRequest.setModeType("sync");
		TcpConnectionUtil.putRequest(teleRequest);
		WriteFuture writeFuture = this.session.write(teleRequest);
		logger.debug("Session id: " + this.session.getId());
		try {
			if (!writeFuture.await(this.tcpConfig.getRequestTimedOut(),
					TimeUnit.SECONDS)) {
				logger.info(String.format(
						"Error for {%s: [%s]} is request timedout",
						teleRequest.getCorrelationId(),
						this.tcpConfig.getProduct()));
				throw new Exception(
						String.format(
								"Could not sent request in {%s seconds} for {%s: [%s]}",
								this.tcpConfig.getRequestTimedOut(),
								teleRequest.getCorrelationId(),
								this.tcpConfig.getProduct()));
			}
			if (writeFuture.getException() != null) {
				throw writeFuture.getException();
			}
			teleRequest.waitResponse(this.tcpConfig.getReadTimedOut(),
					TimeUnit.SECONDS);
			TcpConnectionUtil.removeRequest(teleRequest);
			if (teleRequest.getResponse() == null) {
				logger.info(String.format(
						"Error for {%s: [%s]} is read timedout",
						teleRequest.getCorrelationId(),
						this.tcpConfig.getProduct()));
				throw new Exception(
						String.format(
								"Could not receive the response in {%s seconds} for {%s: [%s]}",
								this.tcpConfig.getReadTimedOut(),
								teleRequest.getCorrelationId(),
								this.tcpConfig.getProduct()));
			}
			logger.info(String.format("Response for {%s: [%s]} is getting",
					teleRequest.getCorrelationId(), this.tcpConfig.getProduct()));
		} catch (InterruptedException e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "90013] [InterruptedException while writing Data to MCA Handler] Error["
							+ e.getMessage() + "]");
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00064] [Exception while writing Data to MCA Handler] Error["
							+ e.getMessage() + "]");
		} catch (Throwable e) {

		}
		return teleRequest.getResponse();
	}

	public static void close() {
		//logger.info("<<<<<< Closing Connection >>>>>>>>>");
		connector.dispose();
	}
	
	public static void closeConnectorSession() {
		//logger.info("<<<<<< Closing Connection >>>>>>>>>");
		// Do the close requesting without waiting for the pending messages 
		try
		{
			closeFuture.getSession().close(true);
			closeFuture.awaitUninterruptibly();
			logger.info("Session isClosed["+closeFuture.isClosed()+"]");
			if(closeFuture.isClosed())
			{
				connector.dispose();
				logger.info("Connector IsDisposed["
						+ connector.isDisposed() + "] IsDisposing["
						+ connector.isDisposing()
						+ "]");
			}
		}
		catch(Exception e)
		{
			logger.error("Exception occurred during the process of closing the session.CloseFuture["
					+ closeFuture
					+ "] Session ["+closeFuture.getSession()+"] Connector["
					+ connector
					+ "] Error["
					+ e
					+ "]");
		}
	}

	@Override
	public void closeSession() {
		if (this.session != null)
			this.session.closeOnFlush();
	}
}