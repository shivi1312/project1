package com.vcc.filter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.validation.BindingResult;

import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;

public class ProfileFilterChain {

	private List<Filter> filters = new ArrayList<Filter>();

	public void addFilter(Filter userFilter) {
		filters.add(userFilter);
	}

	public void execute(BindingResult bindingResult, VccServices vccServices,
			ProfileRequest profileRequest, ProfileResponse profileResponse,
			VmError vmError) {
		for (Filter filter : filters) {
			filter.execute(profileRequest, bindingResult, profileResponse, vmError,
					vccServices);
		}
	}

}
