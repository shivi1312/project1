package com.vcc.filter;

import org.springframework.validation.BindingResult;

import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;

public class ProfileClient {

	
	private ProfileFilterManager profileFilterManager;

	public ProfileClient() {

	}

	

	public void setFilterManager(ProfileFilterManager profileFilterManager) {
		this.profileFilterManager = profileFilterManager;
	}

	public void sendRequest(BindingResult bindingResult, VccServices vccServices,
			ProfileRequest profileRequest, ProfileResponse profileResponse, VmError error) {
		profileFilterManager.filterRequest(bindingResult, vccServices, profileRequest,
				profileResponse, error);

	}

}
