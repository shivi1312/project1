package com.vcc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.vcc.config.AppConfig;
import com.vcc.model.VccSubscriptionMaster;

public class VccSubscriptionRowMapper implements RowMapper<VccSubscriptionMaster> {
	@Override
	public VccSubscriptionMaster mapRow(ResultSet rs, int rownumber) throws SQLException {
		VccSubscriptionMaster vcc = new VccSubscriptionMaster();
		vcc.setLanguage(AppConfig.config.getInt("vms_default_language"));
		vcc.setMsisdn(rs.getString("MSISDN"));
		vcc.setServiceType(rs.getString("SERVICE_TYPE"));
		vcc.setExpiryDate(rs.getString("EXPIRY_DATE"));
		vcc.setRatePlan(rs.getInt("RATE_PLAN"));
		vcc.setDateRegistered(rs.getString("DATE_REGISTERED"));
		vcc.setStatus(rs.getString("STATUS"));
		vcc.setServiceFlag(rs.getString("SERVICE_FLAG"));
		return vcc;
	};
}
