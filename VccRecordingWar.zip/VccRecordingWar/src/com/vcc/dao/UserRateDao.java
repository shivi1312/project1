package com.vcc.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.vcc.model.VccRatePlan;
@Transactional(readOnly=false)
public class UserRateDao implements RateDao {

	@Autowired
	DataSource dataSource;

	@Override
	public List<VccRatePlan> getRatePan() {
		String sql = "select * from vcc_rate_pan";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		return jdbcTemplate.query(sql, new VccRatePlanRowMapper());
	}
}
