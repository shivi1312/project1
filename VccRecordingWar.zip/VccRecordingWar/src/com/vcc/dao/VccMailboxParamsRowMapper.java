package com.vcc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.vcc.config.AppConfig;
import com.vcc.model.VccMailboxParams;

public class VccMailboxParamsRowMapper implements RowMapper<VccMailboxParams>{
	@Override
	public VccMailboxParams mapRow(ResultSet rs, int rownumber) throws SQLException {
		
		VccMailboxParams mailboxParams = new VccMailboxParams();
		mailboxParams.setMailboxId(rs.getInt("MAILBOX_ID"));
		mailboxParams.setMailboxType(rs.getString("MAILBOX_TYPE"));
		mailboxParams.setMaxMessage(rs.getInt("MAX_MESSAGES"));
		mailboxParams.setMsgLifeTime(rs.getInt("MSG_LIFETIME"));
		mailboxParams.setMsgLifeTimeAfterRet(rs.getInt("MSG_LIFETIME_AFTER_RET"));
		mailboxParams.setMsgLifeTimeAfterSave(rs.getInt("MSG_LIFETIME_AFTER_SAVE"));
		mailboxParams.setMaxRecordingTime(rs.getInt("MAX_RECORDING_TIME"));
		
		return mailboxParams;
		/*AppConfig.config.setProperty(rs.getString("mailbox_type")+"_mailbox_id", rs.getString("mailbox_id"));
		AppConfig.config.setProperty(rs.getString("mailbox_type"), rs.getString("mailbox_type"));
		AppConfig.config.setProperty(rs.getString("mailbox_type")+"_max_messages", rs.getString("max_messages"));
		AppConfig.config.setProperty(rs.getString("mailbox_type")+"_msg_lifetime", rs.getString("msg_lifetime"));
		AppConfig.config.setProperty(rs.getString("mailbox_type")+"_msg_lifetime_after_ret", rs.getString("msg_lifetime_after_ret"));
		AppConfig.config.setProperty(rs.getString("mailbox_type")+"_msg_lifetime_after_save", rs.getString("msg_lifetime_after_save"));
		AppConfig.config.setProperty(rs.getString("mailbox_type")+"_max_recording_time", rs.getString("max_recording_time"));
		return null;*/
		
	};
}
