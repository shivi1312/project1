package com.vcc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.vcc.common.VccCommonOperation;
import com.vcc.config.AppConfig;
import com.vcc.model.GroupDetail;
import com.vcc.model.VccSeriesRange;
import com.vcc.request.UserConfigRequest;
@Transactional(readOnly=false)
public class VccUserConfigDao implements UserConfigDao {

	final static Logger logger = Logger.getLogger(VccUserConfigDao.class);
	private final static Logger errorLogger = Logger.getLogger("errorLogger");

	@Autowired
	DataSource dataSource;

	@Override
	public Boolean insertFrndGroupList(GroupDetail groupDetail) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			Boolean result = false;
			/*String query = "insert into VCC_GROUP_DETAIL "
					+ "(MSISDN,GROUP_ID,CREATE_DATE,OWNER_MSISDN)"
					+ "values(?,?,now(),?)";
*/
			String query = null;
			if (AppConfig.config.getString("db_type").equalsIgnoreCase("mysql")) {
				query = "insert into VCC_GROUP_DETAIL "
						+ "(MSISDN,GROUP_ID,CREATE_DATE,OWNER_MSISDN)"
						+ "values(?,?,now(),?)";
			} else if (AppConfig.config.getString("db_type").equalsIgnoreCase(
					"oracle")) {
				query = "insert into VCC_GROUP_DETAIL "
						+ "(MSISDN,GROUP_ID,CREATE_DATE,OWNER_MSISDN)"
						+ "values(?,?,sysdate,?)";
			}

			List<Object[]> inputList = new ArrayList<Object[]>();
			for (String msisdn : groupDetail.getFrndList()) {
				Object[] tmp = {
						commonOperation.msisdnWithCountryCode(msisdn),
						groupDetail.getGroupId(),
						commonOperation.msisdnWithCountryCode(groupDetail
								.getCallingNum()) };
				inputList.add(tmp);
			}
			int[] rows = jdbcTemplate.batchUpdate(query, inputList);

			if (rows.length > 0) {
				result = true;
			}
			return result;
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00042] MSISDN["+groupDetail.getCallingNum()+"] ServiceType["+groupDetail.getServiceType()+"] [Exception in inserting data in VCC_GROUP_DETAIL] Error["+ e.getMessage() +"]");
			logger.error("[" + groupDetail.getCallingNum()
					+ "] error is occours in inert into VCC_GROUP_DETAIL [" + e
					+ "]");
			return false;
		} finally {
			commonOperation = null;
		}
	}

	@Override
	public int checkGroupIdExists(UserConfigRequest configRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String quesry = "select count(*) from VCC_GROUP_MASTER where MSISDN=? and GROUP_ID=?";

			return jdbcTemplate.queryForObject(
					quesry,
					new Object[] {
							commonOperation.msisdnWithCountryCode(configRequest
									.getCallingNum()),
							configRequest.getGroupId() }, Integer.class);
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00043] MSISDN["+configRequest.getCallingNum()+"] groupId["+configRequest.getGroupId()+"] [Exception while checking groupId Existance in VCC_GROUP_MASTER] Error["+ e.getMessage() +"]");
			logger.error("Error in createGroup is ["
					+ configRequest.getCallingNum() + "] Exception is [" + e
					+ "]");
			return 0;
		} finally {
			commonOperation = null;
		}
	}

	@Override
	public Boolean createGroup(GroupDetail groupDetail) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(groupDetail
				.getCallingNum());
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			
			/*String query = "insert into VCC_GROUP_MASTER(MSISDN,GROUP_ID,FILENAME,CREATE_DATE) values(?,?,?,now())";*/

			String query = null;
			if (AppConfig.config.getString("db_type").equalsIgnoreCase("mysql")) {
				query = "insert into VCC_GROUP_MASTER(MSISDN,GROUP_ID,FILENAME,CREATE_DATE) values(?,?,?,now())";
			} else if (AppConfig.config.getString("db_type").equalsIgnoreCase(
					"oracle")) {
				query = "insert into VCC_GROUP_MASTER(MSISDN,GROUP_ID,FILENAME,CREATE_DATE) values(?,?,?,sysdate)";
			}
			
			
			int status = jdbcTemplate.update(query, new Object[] { msisdn,
					groupDetail.getGroupId(), groupDetail.getFileName() });
			logger.info("[" + groupDetail.getCallingNum()
					+ "] Group created status is [" + status + "]");
			if (status > 0)
				return true;
			else
				return false;
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00044] MSISDN["+msisdn+"] groupId["+groupDetail.getGroupId()+"] [Exception while inserting data in VCC_GROUP_MASTER for group creation] Error["+ e.getMessage() +"]");

			logger.error("Error in createGroup os ["
					+ groupDetail.getCallingNum() + "] Exception is [" + e
					+ "]");
			return false;

		} finally {
			commonOperation = null;
		}
	}

	@Override
	public List<String> getMsisdnList(GroupDetail groupDetail) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(groupDetail
				.getCallingNum());
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "select MSISDN from VCC_GROUP_DETAIL where GROUP_ID=? and OWNER_MSISDN=?";
			return jdbcTemplate.query(query,
					new Object[] { groupDetail.getGroupId(), msisdn },
					new RowMapper<String>() {
						@Override
						public String mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return rs.getString("MSISDN");
						}
					});
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00045] MSISDN["+msisdn+"] groupId["+groupDetail.getGroupId()+"] [Exception while getting msisdn list from VCC_GROUP_MASTER] Error["+ e.getMessage() +"]");
			logger.error("Error in createGroup os ["
					+ groupDetail.getCallingNum() + "] Exception is [" + e
					+ "]");
			return new ArrayList<String>();

		} finally {
			commonOperation = null;
		}
	}

	@Override
	public String getGroupName(UserConfigRequest userConfigRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(userConfigRequest
				.getCallingNum());
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "select FILENAME from VCC_GROUP_MASTER where MSISDN=? and GROUP_ID =? ";

			return jdbcTemplate.queryForObject(query, new Object[] { msisdn,
					userConfigRequest.getGroupId() }, String.class);

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00046] MSISDN["+msisdn+"] groupId["+userConfigRequest.getGroupId()+"] [Exception while getting group name from VCC_GROUP_MASTER] Error["+ e.getMessage() +"]");
			logger.error("error in getGroupName  calling Num["
					+ userConfigRequest.getCallingNum() + "] and GroupId ["
					+ userConfigRequest.getGroupId() + "] and error is [" + e
					+ "]");
			return null;
		} finally {
			commonOperation = null;
		}

	}

	@Override
	public Boolean deleteGroup(GroupDetail groupDetail) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(groupDetail
				.getCallingNum());
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "delete from VCC_GROUP_MASTER where MSISDN=? and GROUP_ID=?";

			int result = jdbcTemplate.update(query, new Object[] { msisdn,
					groupDetail.getGroupId() });

			if (result > 0)
				return true;
			else
				return false;

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00047] MSISDN["+msisdn+"] groupId["+groupDetail.getGroupId()+"] [Exception while deleting group from VCC_GROUP_MASTER] Error["+ e.getMessage() +"]");
			logger.info("Getting error in delete group of ["
					+ groupDetail.getCallingNum() + "] and Id ["
					+ groupDetail.getGroupId() + "] and Eror is [" + e + "]");
			return false;
		} finally {
			commonOperation = null;
		}

	}

	@Override
	public Boolean deleteGroupDetails(GroupDetail groupDetail) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(groupDetail
				.getCallingNum());
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "delete from VCC_GROUP_DETAIL  where OWNER_MSISDN=? and GROUP_ID=?";

			int result = jdbcTemplate.update(query, new Object[] { msisdn,
					groupDetail.getGroupId() });

			if (result > 0)
				return true;
			else
				return false;

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00048] MSISDN["+msisdn+"] groupId["+groupDetail.getGroupId()+"] [Exception while deleting group detail from VCC_GROUP_DETAIL] Error["+ e.getMessage() +"]");
			logger.info("Getting error in delete group details of ["
					+ groupDetail.getCallingNum() + "] and Id ["
					+ groupDetail.getGroupId() + "] and Eror is [" + e + "]");
			return false;
		} finally {
			commonOperation = null;
		}

	}

	@Override
	public Boolean updateGroupName(GroupDetail groupDetail) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(groupDetail
				.getCallingNum());
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "update  VCC_GROUP_MASTER set FILENAME=? where MSISDN=? and GROUP_ID=?";

			int result = jdbcTemplate.update(query,
					new Object[] { groupDetail.getFileName(), msisdn,
							groupDetail.getGroupId() });

			if (result > 0)
				return true;
			else
				return false;

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00049] MSISDN["+msisdn+"] groupId["+groupDetail.getGroupId()+"] [Exception while updating group name in VCC_GROUP_MASTER] Error["+ e.getMessage() +"]");
			logger.info("Getting error in update group details of ["
					+ groupDetail.getCallingNum() + "] and Id ["
					+ groupDetail.getGroupId() + "] and Eror is [" + e + "]");
			return false;
		} finally {
			commonOperation = null;
		}
	}

	@Override
	public Boolean deleteMsisdnFromGroup(String ownerMsisdn, int groupId,
			String msisdn) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		msisdn = commonOperation.msisdnWithCountryCode(msisdn);
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "delete from VCC_GROUP_DETAIL  where OWNER_MSISDN=? and GROUP_ID=? and MSISDN=?";

			int result = jdbcTemplate.update(query, new Object[] {
					commonOperation.msisdnWithCountryCode(ownerMsisdn),
					groupId, msisdn });

			if (result > 0)
				return true;
			else
				return false;

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00050] MSISDN["+msisdn+"] groupId["+groupId+"] [Exception while deleting group msisdn from VCC_GROUP_DETAIL] Error["+ e.getMessage() +"]");
			logger.info("Getting error in deletemsisdn from group details of ["
					+ msisdn + "] and Id [" + groupId + "] and Eror is [" + e
					+ "]");
			return false;
		} finally {
			commonOperation = null;
		}

	}

	@Override
	public Boolean addAlternativeMsisdn(UserConfigRequest userConfigRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String ownerMsisdn = commonOperation
				.msisdnWithCountryCode(userConfigRequest.getCallingNum());
		String alternativeMsisdn = commonOperation
				.msisdnWithCountryCode(userConfigRequest.getCalledNumB());
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "insert into VCC_ADVANCED_DETAILS(MSISDN,FRIEND_MSISDN,SERVICE_FLAG_INDEX,SERVICE_TYPE) values(?,?,?,?)";

			int result = jdbcTemplate.update(query, new Object[] { ownerMsisdn,
					alternativeMsisdn, userConfigRequest.getServiceFlagIndex(),
					userConfigRequest.getServiceType() });

			if (result > 0)
				return true;
			else
				return false;

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00051] MSISDN["+ownerMsisdn+"] ServiceType["+userConfigRequest.getServiceType()+"] [Exception while adding alternate number in VCC_ADVANCED_DETAILS] Error["+ e.getMessage() +"]");
			logger.info("[" + userConfigRequest.getCallingNum()
					+ "]Getting error in addAlternativeMsisdn alterMsisdn ["
					+ alternativeMsisdn + "] and ServiceType ["
					+ userConfigRequest.getServiceType() + "] and Eror is ["
					+ e + "]");
			return false;
		} finally {
			commonOperation = null;
		}

	}

	@Override
	public String getMsisdnFromAdvancedDetails(
			UserConfigRequest userConfigRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String ownerMsisdn = commonOperation
				.msisdnWithCountryCode(userConfigRequest.getCallingNum());

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "select FRIEND_MSISDN from VCC_ADVANCED_DETAILS where MSISDN=? and SERVICE_FLAG_INDEX=? and SERVICE_TYPE=? ";

			return jdbcTemplate.queryForObject(query, new Object[] {
					ownerMsisdn, userConfigRequest.getServiceFlagIndex(),
					userConfigRequest.getServiceType() }, String.class);

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00052] MSISDN["+ownerMsisdn+"] ServiceType["+userConfigRequest.getServiceType()+"] [Exception while getting friend msisdn from VCC_ADVANCED_DETAILS] Error["+ e.getMessage() +"]");
			logger.error("["
					+ userConfigRequest.getCallingNum()
					+ "]Getting error in get AlternativeMsisdn  and ServiceType ["
					+ userConfigRequest.getServiceType() + "] and Eror is ["
					+ e + "]");
			return null;
		} finally {
			commonOperation = null;
		}
	}

	@Override
	public int activateOrDeactivateNotification(
			UserConfigRequest userConfigRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String ownerMsisdn = commonOperation
				.msisdnWithCountryCode(userConfigRequest.getCallingNum());

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				query = "update VCC_SUBSCRIPTION_MASTER_"+ownerMsisdn.charAt(ownerMsisdn.length()-1)+" set SERVICE_FLAG=? where  MSISDN=? and SERVICE_TYPE=? ";
			} else {
				query = "update VCC_SUBSCRIPTION_MASTER set SERVICE_FLAG=? where  MSISDN=? and SERVICE_TYPE=? ";
			}
			logger.debug("["+ ownerMsisdn+ "] Query is :->>> ["+query+"]");

			return jdbcTemplate.update(query,
					new Object[] { userConfigRequest.getServiceFlag(),
							ownerMsisdn, userConfigRequest.getServiceType() });

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00053] MSISDN["+ownerMsisdn+"] ServiceType["+userConfigRequest.getServiceType()+"] [Exception while activating or deactivating notification in VCC_SUBSCRIPTION_MASTER] Error["+ e.getMessage() +"]");
			logger.info("["
					+ userConfigRequest.getCallingNum()
					+ "]Getting error in ActivateNotification  and ServiceType ["
					+ userConfigRequest.getServiceType() + "] and Eror is ["
					+ e + "]");
			return 0;
		} finally {
			commonOperation = null;
		}

	}

	@Override
	public List<VccSeriesRange> isUserExistWithInRange(String msisdn) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String callingNum = commonOperation.msisdnWithCountryCode(msisdn);

		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String query = "select A.*,B.GROUP_NAME from VCC_SERIES_RANGE A,VCC_SERIES_GROUP B where START_RANGE <=? AND END_RANGE>=? AND A.GROUP_ID=B.GROUP_ID";
		return jdbcTemplate.query(query,
				new Object[] { callingNum, callingNum, },
				new RowMapper<VccSeriesRange>() {
					@Override
					public VccSeriesRange mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						VccSeriesRange vsr = new VccSeriesRange();
						vsr.setRangeId(rs.getInt("RANGE_ID"));
						vsr.setStartRange(rs.getString("START_RANGE"));
						vsr.setEndRange(rs.getString("END_RANGE"));
						vsr.setRangeType(rs.getString("TYPE"));
						vsr.setGroupName(rs.getString("GROUP_NAME"));
						return vsr;
					}

				});

	}

	@Override
	public String getServiceFlag(String msisdn, String serviceType) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String ownerMsisdn = commonOperation.msisdnWithCountryCode(msisdn);

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				query = "select SERVICE_FLAG from VCC_SUBSCRIPTION_MASTER_"+ownerMsisdn.charAt(ownerMsisdn.length()-1)+" where MSISDN=? and SERVICE_TYPE=? ";
			} else {
				query = "select SERVICE_FLAG from VCC_SUBSCRIPTION_MASTER where MSISDN=? and SERVICE_TYPE=? ";
			}
			logger.debug("["+ ownerMsisdn+ "] Query is :->>> ["+query+"]");
			return jdbcTemplate.queryForObject(query, new Object[] {
					ownerMsisdn, serviceType }, String.class);

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00054] MSISDN["+ownerMsisdn+"] ServiceType["+serviceType+"] [Exception while getting service flag from VCC_SUBSCRIPTION_MASTER] Error["+ e.getMessage() +"]");
			logger.info("[" + msisdn
					+ "]Getting error in get getServiceFlag  and ServiceType ["
					+ serviceType + "] and Eror is [" + e + "]");
			return null;
		} finally {
			commonOperation = null;
		}
	}

	@Override
	public Boolean updateAlternativeMsisdn(UserConfigRequest userConfigRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String ownerMsisdn = commonOperation
				.msisdnWithCountryCode(userConfigRequest.getCallingNum());
		String alternativeMsisdn = commonOperation
				.msisdnWithCountryCode(userConfigRequest.getCalledNumB());
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "update VCC_ADVANCED_DETAILS set FRIEND_MSISDN=? where MSISDN=? and SERVICE_FLAG_INDEX=? and SERVICE_TYPE=?";

			int result = jdbcTemplate.update(query,
					new Object[] { alternativeMsisdn, ownerMsisdn,
							userConfigRequest.getServiceFlagIndex(),
							userConfigRequest.getServiceType() });

			if (result > 0)
				return true;
			else
				return false;

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00055] MSISDN["+ownerMsisdn+"] ServiceType["+userConfigRequest.getServiceType()+"] [Exception while updating alternate MSISDN in VCC_ADVANCED_DETAILS] Error["+ e.getMessage() +"]");
			logger.info("[" + userConfigRequest.getCallingNum()
					+ "]Getting error in updateAlternativeMsisdn alterMsisdn ["
					+ alternativeMsisdn + "] and ServiceType ["
					+ userConfigRequest.getServiceType() + "] and Eror is ["
					+ e + "]");
			return false;
		} finally {
			commonOperation = null;
		}
	}

	@Override
	public Boolean deleteAlternativenumber(String msisdn, int serviceFagPos) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		msisdn = commonOperation.msisdnWithCountryCode(msisdn);
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "delete from  VCC_ADVANCED_DETAILS where MSISDN=? and SERVICE_FLAG_INDEX=?";

			int result = jdbcTemplate.update(query, new Object[] { msisdn,
					serviceFagPos, });

			if (result > 0)
				return true;
			else
				return false;

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00056] MSISDN["+msisdn+"] [Exception while deleting alternate MSISDN from VCC_ADVANCED_DETAILS] Error["+ e.getMessage() +"]");
			logger.info("["
					+ msisdn
					+ "]Getting error in delete AlternativeMsisdn  ServiceFalgPos ["
					+ serviceFagPos + "] and Eror is [" + e + "]");
			return false;
		} finally {
			commonOperation = null;
		}
	}

	@Override
	public int groupCount(String msisdn) {
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			VccCommonOperation commonOperation = new VccCommonOperation();

			msisdn = commonOperation.msisdnWithCountryCode(msisdn);

			String sql = "select count(*) from VCC_GROUP_MASTER where MSISDN="
					+ msisdn + "";

			int result = jdbcTemplate.queryForInt(sql);
			logger.info("query [" + sql + "] result [" + result + "]");
			return result;
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00057] MSISDN["+msisdn+"] [Exception while getting group count from VCC_GROUP_MASTER] Error["+ e.getMessage() +"]");
			logger.error("[" + msisdn + "] Error in getting group count [" + e
					+ "]");
			e.printStackTrace();
			return -1;
		}
	}
}
