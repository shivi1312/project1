package com.vcc.dao;

import java.util.List;

import com.vcc.model.GroupDetail;
import com.vcc.model.VccSeriesRange;
import com.vcc.request.UserConfigRequest;

public interface UserConfigDao {

	public Boolean insertFrndGroupList(GroupDetail groupDetail);

	public int checkGroupIdExists(UserConfigRequest configRequest);

	public Boolean createGroup(GroupDetail groupDetail);

	public List<String> getMsisdnList(GroupDetail groupDetail);

	public String getGroupName(UserConfigRequest userConfigRequest);

	public Boolean deleteGroup(GroupDetail groupDetail);

	public Boolean deleteGroupDetails(GroupDetail groupDetail);

	public Boolean updateGroupName(GroupDetail groupDetail);

	public Boolean deleteMsisdnFromGroup(String ownerMsisdn, int groupId,
			String msisdn);

	public Boolean addAlternativeMsisdn(UserConfigRequest userConfigRequest);

	public Boolean updateAlternativeMsisdn(UserConfigRequest userConfigRequest);
	
	public String getMsisdnFromAdvancedDetails(UserConfigRequest userConfigRequest);

	public int activateOrDeactivateNotification(
			UserConfigRequest userConfigRequest);
	
	public int groupCount(String msisdn);

	public List<VccSeriesRange> isUserExistWithInRange(String msisdn);

	public String getServiceFlag(String msisdn, String serviceType);
	
	public Boolean deleteAlternativenumber(String msisdn, int serviceFagPos);

}
