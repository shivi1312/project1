package com.vcc.dao;

import java.util.List;

import com.vcc.model.VccRatePlan;

public interface RateDao {
	public List<VccRatePlan> getRatePan();
}
