package com.vcc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.vcc.common.VccCommonOperation;
import com.vcc.config.AppConfig;
import com.vcc.model.MessageAttribute;
import com.vcc.model.VccFwdCallLogs;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.model.VccVoiceMessage;
import com.vcc.request.VccMessageRequest;
@Transactional(readOnly=false)
public class VccMessageDao implements MessageDao {
	final static Logger logger = Logger.getLogger(VccMessageDao.class);
	private final static Logger errorLogger = Logger.getLogger("errorLogger");
	@Autowired
	DataSource dataSource;

	/*public VccMessageDao() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}*/
	
	@SuppressWarnings("deprecation")
	@Override
	public int getNextIndex() {
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

			String sql = "select max(LOCAL_MESSAGE_INDEX) from VCC_VOICE_MSG";

			logger.info("local msg index is [" + sql + "]");
			int result = jdbcTemplate.queryForInt(sql) + 1;

			return result;
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00014] [Exception in getting local message Index] Error["
							+ e.getMessage() + "]");
			e.printStackTrace();
			return -1;
		}
	}

	@Override
	public int insertVoiceMessage(VccVoiceMessage vmsMessage) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

		try {
			String sql = null;

			/*
			 * sql = "insert into VCC_VOICE_MSG " +
			 * "(ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_TIME,FILENAME,RECORDING_DURATION,ORIGINAL_NUMBER,LOCAL_MESSAGE_INDEX,SENDING_TIME,SERVICE_TYPE) "
			 * + "values(?,?,?,?,?,?,?,now(),?)";
			 */

			if (AppConfig.config.getString("db_type").equalsIgnoreCase("mysql")) {
				sql = "insert into VCC_VOICE_MSG "
						+ "(ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_TIME,FILENAME,RECORDING_DURATION,ORIGINAL_NUMBER,LOCAL_MESSAGE_INDEX,SENDING_TIME,SERVICE_TYPE) "
						+ "values(?,?,?,?,?,?,?,now(),?)";
			} else if (AppConfig.config.getString("db_type").equalsIgnoreCase(
					"oracle")) {
				sql = "insert into VCC_VOICE_MSG "
						+ "(ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_TIME,FILENAME,RECORDING_DURATION,ORIGINAL_NUMBER,LOCAL_MESSAGE_INDEX,SENDING_TIME,SERVICE_TYPE) "
						+ "values(?,?,to_date(?,'DD-MM-YYYY HH24:MI:SS'),?,?,?,?,sysdate,?)";
			}
			logger.info("sql query is " + sql);
			return jdbcTemplate.update(
					sql,
					new Object[] { vmsMessage.getOriginattingNumber(),
							vmsMessage.getDesticationNumber(),
							vmsMessage.getCallTime(), vmsMessage.getFileName(),
							vmsMessage.getRecordingTime(),
							vmsMessage.getOrginalNumber(),
							vmsMessage.getLocalMessageIndex(),
							vmsMessage.getServiceType()

					});
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00015] OriginationNumber["
							+ vmsMessage.getOriginattingNumber()
							+ "] DestinationNumber["
							+ vmsMessage.getDesticationNumber()
							+ "] [Exception while inserting data in VCC_VOICE_MSG] Error["
							+ e.getMessage() + "]");

			logger.error("[" + vmsMessage.getOriginattingNumber()
					+ " ] destination number ["
					+ vmsMessage.getDesticationNumber()
					+ "] error in inserting entry in vcc_voice_msg [" + e
					+ "]_");
			e.printStackTrace();
			return 0;
		}
	}

	@Override
	public int insertFwdCallLogs(VccFwdCallLogs fwdCallLogs) {
		
		/*
		 * String query = "insert into VCC_FWD_CALL_LOGS" +
		 * "(SERVER_ID,CALL_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,CIRCUIT_ID,"
		 * +
		 * "IAM_CAUSE_CODE,REL_CAUSE_CODE,MSG_LENGTH,VOICE_MSG_INDEX,CALL_TIME,"
		 * + "CALL_DURATION,ANSWERED,SERVICE_TYPE,SUB_TYPE,RATE_PLAN)" +
		 * "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		 */
		
		if(AppConfig.config.getInt("FILE_WRITER_FWD_CALL_LOGS_ENABLED",0) == 1) {
			AppConfig.VCC_FWD_CALL_LOGS_WRITER.writeLog(fwdCallLogs.getServerId()+","+fwdCallLogs.getCallId()+","+fwdCallLogs.getOriginatingNumber()+","+fwdCallLogs.getDestinationNumber()+","+fwdCallLogs.getCircuitId()+","+fwdCallLogs.getIamCauseCode()+","+fwdCallLogs.getRelCauseCode()+","+fwdCallLogs.getMsgLength()+",0,"+fwdCallLogs.getCallTime()+","+fwdCallLogs.getCallDuration()+","+fwdCallLogs.getAnswered()+","+fwdCallLogs.getServiceType()+","+fwdCallLogs.getSubType()+","+fwdCallLogs.getRatePlan()+",NULL,N");
			logger.info("VCC_FWD_CALL_LOGS writes into File at path : ["+AppConfig.config.getString("RULEBLOCK_LOG_FILEPATH")+"]");
			return 1;
		} else {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = null;
			if (AppConfig.config.getString("db_type").equalsIgnoreCase("mysql")) {
				query = "insert into VCC_FWD_CALL_LOGS"
						+ "(SERVER_ID,CALL_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,CIRCUIT_ID,"
						+ "IAM_CAUSE_CODE,REL_CAUSE_CODE,MSG_LENGTH,CALL_TIME,"
						+ "CALL_DURATION,ANSWERED,SERVICE_TYPE,SUB_TYPE,RATE_PLAN)"
						+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			} else if (AppConfig.config.getString("db_type").equalsIgnoreCase(
					"oracle")) {
				query = "insert into VCC_FWD_CALL_LOGS"
						+ "(SERVER_ID,CALL_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,CIRCUIT_ID,"
						+ "IAM_CAUSE_CODE,REL_CAUSE_CODE,MSG_LENGTH,CALL_TIME,"
						+ "CALL_DURATION,ANSWERED,SERVICE_TYPE,SUB_TYPE,RATE_PLAN)"
						+ "values(?,?,?,?,?,?,?,?,to_date(?,'DD-MM-YYYY HH24:MI:SS'),?,?,?,?,?)";
			}

			logger.info("sql query is " + query);
			try {
				return jdbcTemplate.update(
						query,
						new Object[] { fwdCallLogs.getServerId(),
								fwdCallLogs.getCallId(),
								fwdCallLogs.getOriginatingNumber(),
								fwdCallLogs.getDestinationNumber(),
								fwdCallLogs.getCircuitId(),
								fwdCallLogs.getIamCauseCode(),
								fwdCallLogs.getRelCauseCode(),
								fwdCallLogs.getMsgLength(),
								fwdCallLogs.getCallTime(),
								fwdCallLogs.getCallDuration(),
								fwdCallLogs.getAnswered(),
								fwdCallLogs.getServiceType(),
								fwdCallLogs.getSubType(), fwdCallLogs.getRatePlan()

						});
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString("errorcode_pattern",
										"VCC-IVRWAR-")
								+ "00019] OriginationNumber["
								+ fwdCallLogs.getOriginatingNumber()
								+ "] DestinationNumber["
								+ fwdCallLogs.getDestinationNumber()
								+ "] ServiceType["
								+ fwdCallLogs.getServiceType()
								+ "] [Exception while inserting data into VCC_FWD_CALL_LOGS] Error["
								+ e.getMessage() + "]");
				return 0;
			}
		}
	}
	
	@SuppressWarnings("deprecation")
	@Override
	public int getMessageCount(VccMessageRequest messageRequest) {

		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(messageRequest
				.getCallingNum());
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = " select count(*) from VCC_VOICE_MSG where ORIGINAL_NUMBER=? and MESSAGE_STATUS=?";
			logger.info("sql query is " + query);
			return jdbcTemplate.queryForInt(query, new Object[] { msisdn,
					messageRequest.getCatName() });

		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00038] MSISDN["
							+ msisdn
							+ "] [Exception while getting message count from VCC_VOICE_MSG] Error["
							+ e.getMessage() + "]");
			logger.error("[" + messageRequest.getCallingNum()
					+ "] db operation not perform in messase count ");
			return 0;
		} finally {
			commonOperation = null;
		}
	}
	
	@Override
	public List<MessageAttribute> getMessageInfo(
			VccMessageRequest messageRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(messageRequest
				.getCallingNum());
		List<MessageAttribute> list = null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = null;
			if (AppConfig.config.getString("db_type").equalsIgnoreCase("mysql")) {
				query = " select MESSAGE_STATUS,ORIGINATING_NUMBER,FILENAME,VOICE_MESSAGE_INDEX,DESTINATION_NUMBER,"
						+ "ORIGINAL_NUMBER,RECORDING_DURATION,SERVICE_TYPE,DATE_FORMAT(SENDING_TIME, '%Y-%m-%d %H:%i:%s') "
						+ "as da from VCC_VOICE_MSG where ORIGINAL_NUMBER=? AND SERVICE_TYPE = ? ORDER BY da DESC";
			} else if (AppConfig.config.getString("db_type").equalsIgnoreCase(
					"oracle")) {
				query = " select MESSAGE_STATUS,ORIGINATING_NUMBER,FILENAME,VOICE_MESSAGE_INDEX,DESTINATION_NUMBER,"
						+ "ORIGINAL_NUMBER,RECORDING_DURATION,SERVICE_TYPE,SENDING_TIME as da from VCC_VOICE_MSG where "
						+ "ORIGINAL_NUMBER=? AND SERVICE_TYPE = ? ORDER BY da DESC";
			}
			logger.debug("sql query is " + query);
			list = jdbcTemplate.query(query, new Object[] { msisdn, messageRequest.getServiceType() },
					new RowMapper<MessageAttribute>() {
						@Override
						public MessageAttribute mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							VccCommonOperation commonOperation = new VccCommonOperation();
							MessageAttribute ma = new MessageAttribute();
							ma.setMsgStatus(rs.getString("MESSAGE_STATUS"));
							ma.setSenderNum(commonOperation.msisdnWithoutCountryCode(rs.getString("ORIGINATING_NUMBER")));
							ma.setFileName(rs.getString("FILENAME"));
							ma.setVoiceMsgIndex(rs.getInt("VOICE_MESSAGE_INDEX"));
							ma.setOriginalNum(commonOperation.msisdnWithoutCountryCode(rs.getString("ORIGINAL_NUMBER")));
							ma.setRecordingDuration(rs.getInt("RECORDING_DURATION"));
							ma.setServiceType(rs.getString("SERVICE_TYPE"));
							ma.setSendingTime(rs.getString("da").toString());
							return ma;
						}
					});
			if(list == null)
				list = new ArrayList<MessageAttribute>();
		} catch (Exception e) {
			e.printStackTrace();
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00039] MSISDN["
							+ msisdn
							+ "] [Exception while getting message info from VCC_VOICE_MSG] Error["
							+ e.getMessage() + "]");
			logger.error("[" + messageRequest.getCallingNum()
					+ "] db operation fail during get message info ");
			list = new ArrayList<MessageAttribute>();
		}
		return list;
	}

	@Override
	public String getGreetingFile(String msisdn) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		msisdn = commonOperation.msisdnWithCountryCode(msisdn);
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String filename = null;

			String query = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				query = "select FILEPATH from VCC_PERSONALIZED_GREETING where GREET_TYPE=(select GREET_TYPE from VCC_AUTH_USER_"+msisdn.charAt(msisdn.length()-1)+" where MSISDN=?) and MSISDN=?";
			} else {
				query = "select FILEPATH from VCC_PERSONALIZED_GREETING where GREET_TYPE=(select GREET_TYPE from VCC_AUTH_USER where MSISDN=?) and MSISDN=?";
			}
			logger.debug("["+ msisdn+ "] Query is :->>> ["+query+"]");
			filename = (String) jdbcTemplate.queryForObject(query,
					new Object[] { msisdn, msisdn }, String.class);

			return filename;
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00040] MSISDN["+msisdn+"] [Exception while getting user's greeting filepath from VCC_PERSONALIZED_GREETING] Error["+ e.getMessage() +"]");
			logger.error("[" + msisdn
					+ "] db operation not perform for getGreetingFile");
			return null;
		} finally {
			commonOperation = null;
		}
	}

	@Override
	public Boolean updateMsgStatus(String msisdn, int voiceMsgIndex) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		msisdn = commonOperation.msisdnWithCountryCode(msisdn);
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

			/*
			 * String query =
			 * " update  VCC_VOICE_MSG  set MESSAGE_STATUS=?,RETRIVAL_TIME=now() where DESTINATION_NUMBER=? and VOICE_MESSAGE_INDEX=? and MESSAGE_STATUS=? "
			 * ;
			 */

			String query = null;
			if (AppConfig.config.getString("db_type").equalsIgnoreCase("mysql")) {
				query = " update  VCC_VOICE_MSG  set MESSAGE_STATUS=?,RETRIVAL_TIME=now() where DESTINATION_NUMBER=? and VOICE_MESSAGE_INDEX=? and MESSAGE_STATUS=? ";
			} else if (AppConfig.config.getString("db_type").equalsIgnoreCase(
					"oracle")) {
				query = " update  VCC_VOICE_MSG  set MESSAGE_STATUS=?,RETRIVAL_TIME=sysdate where DESTINATION_NUMBER=? and VOICE_MESSAGE_INDEX=? and MESSAGE_STATUS=? ";
			}

			int result = jdbcTemplate.update(query, new Object[] { "R", msisdn,
					voiceMsgIndex, "N" });
			if (result > 0)
				return true;
			else
				return false;
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00028] MSISDN["+msisdn+"]  [Exception while updating message status in VCC_VOICE_MSG] Error["+e.getMessage()+"]");
			logger.error("[" + msisdn
					+ "] db operation not perform for updateMsgStatus");
			return null;
		} finally {
			commonOperation = null;
		}
	}

	@Override
	public Boolean insertVoiceMsgWithScheduling(
			VccVoiceMessage vccVoiceMessage,
			VccUserCompleteDetails userCompleteDetails) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		try {
			/*
			 * String sql = "insert into VCC_VOICE_MSG_SCHEDULING " +
			 * "(ORIGINATION_NUMBER,DESTINATION_NUMBER,CALL_TIME,FILENAME," +
			 * "RECORDING_DURATION,MSG_PROTECT,MSG_PRIORITY,PASS_PROTECTED," +
			 * "PASSWORD,ORIGINAL_NUMBER,SENDING_TIME,SERVICE_TYPE,LANGUAGE,RATE_PLAN,SUB_TYPE,CLASS_TYPE,DELIVERY_INTERFACE) "
			 * + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			 */

			String sql = null;
			if (AppConfig.config.getString("db_type").equalsIgnoreCase("mysql")) {
				sql = "insert into VCC_VOICE_MSG_SCHEDULING "
						+ "(ORIGINATION_NUMBER,DESTINATION_NUMBER,CALL_TIME,FILENAME,"
						+ "RECORDING_DURATION,MSG_PROTECT,MSG_PRIORITY,PASS_PROTECTED,"
						+ "PASSWORD,ORIGINAL_NUMBER,SENDING_TIME,SERVICE_TYPE,LANGUAGE,RATE_PLAN,SUB_TYPE,CLASS_TYPE,DELIVERY_INTERFACE) "
						+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			} else if (AppConfig.config.getString("db_type").equalsIgnoreCase(
					"oracle")) {
				sql = "insert into VCC_VOICE_MSG_SCHEDULING "
						+ "(ORIGINATION_NUMBER,DESTINATION_NUMBER,CALL_TIME,FILENAME,"
						+ "RECORDING_DURATION,MSG_PROTECT,MSG_PRIORITY,PASS_PROTECTED,"
						+ "PASSWORD,ORIGINAL_NUMBER,SENDING_TIME,SERVICE_TYPE,LANGUAGE,RATE_PLAN,SUB_TYPE,CLASS_TYPE,DELIVERY_INTERFACE) "
						+ "values(?,?,to_date(?,'DD-MM-YYYY HH24:MI:SS'),?,?,?,?,?,?,?,to_date(?,'DD-MM-YYYY HH24:MI:SS'),?,?,?,?,?,?)";
			}

			logger.info("Query is " + sql);
			int status = jdbcTemplate.update(
					sql,
					new Object[] { vccVoiceMessage.getOriginattingNumber(),
							vccVoiceMessage.getDesticationNumber(),
							vccVoiceMessage.getCallTime(),
							vccVoiceMessage.getFileName(),
							vccVoiceMessage.getRecordingTime(),
							vccVoiceMessage.getMsgProtect(),
							vccVoiceMessage.getMsgPriority(),
							vccVoiceMessage.getPassProtected(),
							vccVoiceMessage.getPassword(),
							vccVoiceMessage.getOrginalNumber(),
							vccVoiceMessage.getSendingTime(),
							vccVoiceMessage.getServiceType(),
							userCompleteDetails.getLanguage(),
							userCompleteDetails.getRatePlan(),
							userCompleteDetails.getSubType(),
							userCompleteDetails.getClassType(),
							userCompleteDetails.getDeliveryInterface() });

			if (status > 0)
				return true;
			else
				return false;
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00041] OriginationNumber["+vccVoiceMessage.getOriginattingNumber()+"] DestinationNumber["+vccVoiceMessage.getDesticationNumber()+"] ServiceType["+vccVoiceMessage.getServiceType()+"] [Exception while inserting data in VCC_VOICE_MSG_SCHEDULING] Error["+e.getMessage()+"]");
			logger.error("["
					+ vccVoiceMessage.getOriginattingNumber()
					+ "] db operation not perform in insertVoiceMsgWithScheduling ["
					+ e + "]");

			return false;
		}
	}

}
