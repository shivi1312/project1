package com.vcc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.vcc.model.VccChargingCode;

public class VccChargingCodeRowMapper implements RowMapper<VccChargingCode> {
	@Override
	public VccChargingCode mapRow(ResultSet rs, int rownumber) throws SQLException {
		VccChargingCode vcc = new VccChargingCode();
		
		vcc.setChargingCode(rs.getInt("CHARGING_CODE"));
		vcc.setAmountPre(rs.getDouble("AMOUNT_PRE"));
		vcc.setAmountPost(rs.getDouble("AMOUNT_POST"));
		vcc.setChargingCodeName(rs.getString("CHARGING_CODE_NAME"));
		vcc.setTariffPre(rs.getLong("TARIFF_PRE"));
		vcc.setTariffPost(rs.getLong("TARIFF_POST"));
		return vcc;
	};

}
