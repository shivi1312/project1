package com.vcc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.vcc.model.VccVoiceMessage;


public class VccVoiceMsgRowMapper implements RowMapper<VccVoiceMessage> {
	@Override
	public VccVoiceMessage mapRow(ResultSet rs, int rownumber) throws SQLException {
		VccVoiceMessage vcc = new VccVoiceMessage();
		vcc.setCallTime(String.valueOf(rs.getDate("CALL_TIME")));
		vcc.setDesticationNumber(rs.getString("DESTINATION_NUMBER"));
		vcc.setFileName(rs.getString("FILENAME"));
		vcc.setLocalMessageIndex(rs.getInt("LOCAL_MESSAGE_INDEX"));
		vcc.setMessageStatus(rs.getString("MESSAGE_STATUS"));
		vcc.setOriginattingNumber(rs.getString("ORIGINATING_NUMBER"));
		vcc.setRecordingTime(rs.getInt("RECORDING_DURATION"));
		vcc.setSendingTime(rs.getString("SENDING_TIME"));
		vcc.setServiceType(rs.getString("SERVICE_TYPE"));
		vcc.setVoiceMessageIndex(rs.getInt("VOICE_MESSAGE_INDEX"));
		
		return vcc;
	};
}
