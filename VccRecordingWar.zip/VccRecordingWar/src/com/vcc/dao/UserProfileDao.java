package com.vcc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.vcc.common.VccCommonOperation;
import com.vcc.config.AppConfig;
import com.vcc.model.VccAuthUser;
import com.vcc.model.VccClassType;
import com.vcc.model.VccFwdCallLogs;
import com.vcc.model.VccPersonalGreeting;
import com.vcc.model.VccSeriesRange;
import com.vcc.model.VccServiceProvider;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.model.VccVoiceMessage;
import com.vcc.request.ProfileRequest;
import com.vcc.request.RetLogRequest;
import com.vcc.request.VccGreetingRequest;
import com.vcc.request.VmRequest;
import com.vcc.request.VnRequest;
import com.vcc.response.ProfileResponse;

@Transactional(readOnly = false)
public class UserProfileDao implements ProfileDao {
	final static Logger logger = Logger.getLogger(UserProfileDao.class);
	private final static Logger errorLogger = Logger.getLogger("errorLogger");
	@Autowired
	DataSource dataSource;

	@SuppressWarnings("deprecation")
	@Override
	public int getNextIndex(String msisdn, String serviceType) {
		String sql = null;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			VccCommonOperation commonOperation = new VccCommonOperation();

			msisdn = commonOperation.msisdnWithCountryCode(msisdn);
			// String sql =
			// "select max(LOCAL_MESSAGE_INDEX) from VCC_VOICE_MSG";
			if (serviceType != null)
				sql = "select max(LOCAL_MESSAGE_INDEX) from VCC_VOICE_MSG where DESTINATION_NUMBER="
						+ msisdn + " and SERVICE_TYPE=" + serviceType + "";
			else
				sql = "select max(LOCAL_MESSAGE_INDEX) from VCC_VOICE_MSG where DESTINATION_NUMBER="
						+ msisdn + "";

			int result = jdbcTemplate.queryForInt(sql) + 1;
			logger.debug("query [" + sql + "] local msg index is [" + result
					+ "]");
			return result;
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00014] [Exception in getting local message Index] Error["
							+ e.getMessage() + "]");
			logger.error("[" + msisdn + "] error in get local msg index [" + e
					+ "]");
			e.printStackTrace();
			return -1;
		}
	}

	@Override
	public int insertVoiceMessage(VccVoiceMessage vmsMessage) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

		try {

			/*
			 * String sql = "insert into VCC_VOICE_MSG " +
			 * "(MESSAGE_STATUS,ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_TIME,FILENAME,RECORDING_DURATION,ORIGINAL_NUMBER,LOCAL_MESSAGE_INDEX,SENDING_TIME,SERVICE_TYPE) "
			 * + "values(?,?,?,?,?,?,?,?,now(),?)";
			 */

			String sql = null;
			if (AppConfig.config.getString("db_type").equalsIgnoreCase("mysql")) {
				sql = "insert into VCC_VOICE_MSG "
						+ "(MESSAGE_STATUS,ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_TIME,FILENAME,RECORDING_DURATION,ORIGINAL_NUMBER,LOCAL_MESSAGE_INDEX,SENDING_TIME,SERVICE_TYPE) "
						+ "values(?,?,?,?,?,?,?,?,now(),?)";

				logger.debug("["
						+ vmsMessage.getOriginattingNumber()
						+ "] MySql query :->>> [insert into VCC_VOICE_MSG "
						+ "(MESSAGE_STATUS,ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_TIME,FILENAME,RECORDING_DURATION,ORIGINAL_NUMBER,LOCAL_MESSAGE_INDEX,SENDING_TIME,SERVICE_TYPE) "
						+ "values(" + vmsMessage.getMessageStatus() + ","
						+ vmsMessage.getOriginattingNumber() + ","
						+ vmsMessage.getDesticationNumber() + ","
						+ vmsMessage.getCallTime() + ","
						+ vmsMessage.getFileName() + ","
						+ vmsMessage.getRecordingTime() + ","
						+ vmsMessage.getOrginalNumber() + ","
						+ vmsMessage.getLocalMessageIndex() + " ,now(), "
						+ vmsMessage.getServiceType() + ")]");
			} else if (AppConfig.config.getString("db_type").equalsIgnoreCase(
					"oracle")) {
				sql = "insert into VCC_VOICE_MSG "
						+ "(MESSAGE_STATUS,ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_TIME,FILENAME,VOICE_MESSAGE_INDEX,RECORDING_DURATION,ORIGINAL_NUMBER,LOCAL_MESSAGE_INDEX,SENDING_TIME,SERVICE_TYPE) "
						+ "values(?,?,?,to_date(?,'DD-MM-YYYY HH24:MI:SS'),?,VOICE_MSG_SEQ.nextval,?,?,?,sysdate,?)";

				logger.debug("["
						+ vmsMessage.getOriginattingNumber()
						+ "] Oracle query :->>> [insert into VCC_VOICE_MSG "
						+ "(MESSAGE_STATUS,ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_TIME,FILENAME,RECORDING_DURATION,ORIGINAL_NUMBER,LOCAL_MESSAGE_INDEX,SENDING_TIME,SERVICE_TYPE) "
						+ "values(" + vmsMessage.getMessageStatus() + ","
						+ vmsMessage.getOriginattingNumber() + ","
						+ vmsMessage.getDesticationNumber() + ","
						+ vmsMessage.getCallTime() + ","
						+ vmsMessage.getFileName() + ","
						+ vmsMessage.getRecordingTime() + ","
						+ vmsMessage.getOrginalNumber() + ","
						+ vmsMessage.getLocalMessageIndex() + ", sysdate ,"
						+ vmsMessage.getServiceType() + ")]");
			}

			return jdbcTemplate.update(
					sql,
					new Object[] { vmsMessage.getMessageStatus(),
							vmsMessage.getOriginattingNumber(),
							vmsMessage.getDesticationNumber(),
							vmsMessage.getCallTime(), vmsMessage.getFileName(),
							vmsMessage.getRecordingTime(),
							vmsMessage.getOrginalNumber(),
							vmsMessage.getLocalMessageIndex(),
							vmsMessage.getServiceType()

					});
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00015] OriginationNumber["
							+ vmsMessage.getOriginattingNumber()
							+ "] DestinationNumber["
							+ vmsMessage.getDesticationNumber()
							+ "] [Exception while inserting data in VCC_VOICE_MSG] Error["
							+ e.getMessage() + "]");
			e.printStackTrace();
			logger.error("[" + vmsMessage.getOriginattingNumber()
					+ "] error in inserting into VCC_VOICE_MSG [" + e + "] ");
			return 0;
		}
	}

	@Override
	public List<VccSubscriptionMaster> getActiveServiceList(
			ProfileRequest profileRequest) {
		if (profileRequest.getServiceType() == null) {
			String sql = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				sql = "select MSISDN,SERVICE_TYPE,EXPIRY_DATE,RATE_PLAN,DATE_REGISTERED,STATUS,"
						+ "SERVICE_FLAG,LAST_VISIT_TIME from VCC_SUBSCRIPTION_MASTER_"+profileRequest.getCalledNum().charAt(profileRequest.getCalledNum().length()-1)+" where MSISDN = ?";
			} else {
				sql = "select MSISDN,SERVICE_TYPE,EXPIRY_DATE,RATE_PLAN,DATE_REGISTERED,STATUS,"
						+ "SERVICE_FLAG,LAST_VISIT_TIME from VCC_SUBSCRIPTION_MASTER where MSISDN = ?";
			}
			logger.debug("["+ profileRequest.getCalledNum()+ "] Query is :->>> ["+sql+"]");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			return jdbcTemplate.query(sql,
					new Object[] { profileRequest.getCalledNum() },
					new VccSubscriptionRowMapper());
		} else {
			String sql = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				sql = "select MSISDN,SERVICE_TYPE,EXPIRY_DATE,RATE_PLAN,DATE_REGISTERED,STATUS,"
						+ "SERVICE_FLAG,LAST_VISIT_TIME from VCC_SUBSCRIPTION_MASTER_"+profileRequest.getCalledNum().charAt(profileRequest.getCalledNum().length()-1)+" where MSISDN = ? and SERVICE_TYPE=?";
			} else {
				sql = "select MSISDN,SERVICE_TYPE,EXPIRY_DATE,RATE_PLAN,DATE_REGISTERED,STATUS,"
						+ "SERVICE_FLAG,LAST_VISIT_TIME from VCC_SUBSCRIPTION_MASTER where MSISDN = ? and SERVICE_TYPE=?";
			}
			logger.debug("["+ profileRequest.getCalledNum()+ "] Query is :->>> ["+sql+"]");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			return jdbcTemplate.query(sql,
					new Object[] { profileRequest.getCalledNum(),
							profileRequest.getServiceType() },
					new VccSubscriptionRowMapper());
		}

	}

	@Override
	public List<VccServiceProvider> getServiceList(ProfileRequest profileRequest) {
		String sql = "select * from SERVICE_PROVIDER order by PRIORITY";
		logger.debug("query is :->>>> [" + sql + "]");
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		return jdbcTemplate.query(sql, new Object[] {},
				new VccServiceProviderRowMapper());
	}

	@Override
	public List<VccSeriesRange> isUserExistWithInRange(String msisdn) {
		/*
		 * Added by vivek kumar at 18/4/2016
		 */
		if (msisdn.startsWith(AppConfig.config.getString("longCode"))) {
			msisdn = msisdn.substring(AppConfig.config.getString("longCode")
					.length(), msisdn.length());
		}
		/**************/
		VccCommonOperation commonOperation = new VccCommonOperation();
		String callingNum = commonOperation.msisdnWithCountryCode(msisdn);
		logger.debug("Query is [select A.*,B.GROUP_NAME from VCC_SERIES_RANGE A,VCC_SERIES_GROUP B where START_RANGE <="
				+ callingNum
				+ " AND END_RANGE>="
				+ callingNum
				+ " AND A.GROUP_ID=B.GROUP_ID GROUP BY GROUP_ID]");
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String query = "select A.*,B.GROUP_NAME from VCC_SERIES_RANGE A,VCC_SERIES_GROUP B where START_RANGE <=? AND END_RANGE>=? AND A.GROUP_ID=B.GROUP_ID GROUP BY GROUP_ID";

		return jdbcTemplate.query(query,
				new Object[] { callingNum, callingNum, },
				new RowMapper<VccSeriesRange>() {
					@Override
					public VccSeriesRange mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						VccSeriesRange vsr = new VccSeriesRange();
						vsr.setRangeId(rs.getInt("RANGE_ID"));
						vsr.setStartRange(rs.getString("START_RANGE"));
						vsr.setEndRange(rs.getString("END_RANGE"));
						vsr.setRangeType(rs.getString("TYPE"));
						vsr.setGroupName(rs.getString("GROUP_NAME"));
						return vsr;
					}

				});

	}

	public VccClassType haveAnyClass(ProfileRequest profileRequest) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String query = "select a.id id,a.msisdn msisdn,b.class_type "
				+ "class_type from vcc_user_class a,vcc_class_type b where a.msisdn = ? and a.class_type=b.id";
		return jdbcTemplate.query(query,
				new Object[] { profileRequest.getCalledNum() },
				new ResultSetExtractor<VccClassType>() {
					@Override
					public VccClassType extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						if (rs.next()) {
							VccClassType vcc = new VccClassType();
							vcc.setId(rs.getInt("id"));
							vcc.setClassType(rs.getString("class_type"));
							vcc.setMsisdn(rs.getString("msisdn"));
						}
						return null;
					}
				});
	}

	public VccAuthUser getProfileDetailByCalledNum(ProfileRequest profileRequest) {

		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(profileRequest
				.getCalledNum());
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				query = "select LOGIN_NAME,MSISDN,LANGUAGE,WPIN,EMAIL_ADDR,DELIVERY_INTERFACE,PASS,SERVICE_TYPE,GREETING_TYPE,SUB_TYPE,IMSI,CLASS_TYPE,ISNEW,ISMIGRATING,STATUS from VCC_AUTH_USER_"+msisdn.charAt(msisdn.length()-1)+" where MSISDN = ?";
			} else {
				query = "select LOGIN_NAME,MSISDN,LANGUAGE,WPIN,EMAIL_ADDR,DELIVERY_INTERFACE,PASS,SERVICE_TYPE,GREETING_TYPE,SUB_TYPE,IMSI,CLASS_TYPE,ISNEW,ISMIGRATING,STATUS from VCC_AUTH_USER where MSISDN = ?";
			}
			logger.debug("["+ msisdn+ "] Query is :->>> ["+query+"]");
			return jdbcTemplate.query(query, new Object[] { msisdn },
					new ResultSetExtractor<VccAuthUser>() {
						@Override
						public VccAuthUser extractData(ResultSet rs)
								throws SQLException, DataAccessException {
							if (rs.next()) {
								VccAuthUser vcc = new VccAuthUser();
								vcc.setLoginName(rs.getString("LOGIN_NAME"));
								vcc.setMsisdn(rs.getString("MSISDN"));
								vcc.setLanguage(rs.getInt("LANGUAGE"));
								vcc.setWpin(rs.getString("WPIN"));
								vcc.setEmail(rs.getString("EMAIL_ADDR"));
								vcc.setDeliveryInterface(rs.getInt("DELIVERY_INTERFACE"));
								vcc.setPassword(rs.getString("PASS"));
								vcc.setServiceType(rs.getString("SERVICE_TYPE"));
								vcc.setGreetingType(rs.getInt("GREETING_TYPE"));
								vcc.setSubType(rs.getString("SUB_TYPE"));
								vcc.setImsi(rs.getString("IMSI"));
								vcc.setClassType(rs.getInt("CLASS_TYPE"));
								vcc.setIsNew(rs.getInt("ISNEW"));
								vcc.setIsMigrating(rs.getInt("ISMIGRATING"));
								vcc.setStatus(rs.getString("STATUS"));
								return vcc;
							}
							return null;
						}
					});
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00016] MSISDN["
							+ msisdn
							+ "][Exception while getting user profile detail from VCC_AUTH_USER] Error["
							+ e.getMessage() + "]");
			logger.info("[" + msisdn
					+ "] db operation not perform for getProfileDetail [" + e
					+ "]");
			return null;
		} finally {
			commonOperation = null;
		}
	}

	public VccAuthUser getProfileDetailByCallingNum(
			ProfileRequest profileRequest) {

		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(profileRequest
				.getCallingNum());
		
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				query = "select LOGIN_NAME,MSISDN,LANGUAGE,WPIN,EMAIL_ADDR,DELIVERY_INTERFACE,PASS,SERVICE_TYPE,GREETING_TYPE,SUB_TYPE,IMSI,CLASS_TYPE,ISNEW,ISMIGRATING,STATUS  from VCC_AUTH_USER_"+msisdn.charAt(msisdn.length()-1)+" where MSISDN = ?";
			} else {
				query = "select LOGIN_NAME,MSISDN,LANGUAGE,WPIN,EMAIL_ADDR,DELIVERY_INTERFACE,PASS,SERVICE_TYPE,GREETING_TYPE,SUB_TYPE,IMSI,CLASS_TYPE,ISNEW,ISMIGRATING,STATUS  from VCC_AUTH_USER where MSISDN = ?";
			}
			logger.debug("["+ msisdn+ "] Query is :->>> ["+query+"]");
			return jdbcTemplate.query(query, new Object[] { msisdn },
					new ResultSetExtractor<VccAuthUser>() {
						@Override
						public VccAuthUser extractData(ResultSet rs)
								throws SQLException, DataAccessException {
							if (rs.next()) {
								VccAuthUser vcc = new VccAuthUser();
								vcc.setLoginName(rs.getString("LOGIN_NAME"));
								vcc.setMsisdn(rs.getString("MSISDN"));
								vcc.setLanguage(rs.getInt("LANGUAGE"));
								vcc.setWpin(rs.getString("WPIN"));
								vcc.setEmail(rs.getString("EMAIL_ADDR"));
								vcc.setDeliveryInterface(rs
										.getInt("DELIVERY_INTERFACE"));
								vcc.setPassword(rs.getString("PASS"));
								vcc.setServiceType(rs.getString("SERVICE_TYPE"));
								vcc.setGreetingType(rs.getInt("GREETING_TYPE"));
								vcc.setSubType(rs.getString("SUB_TYPE"));
								vcc.setImsi(rs.getString("IMSI"));
								vcc.setClassType(rs.getInt("CLASS_TYPE"));
								vcc.setIsNew(rs.getInt("ISNEW"));
								vcc.setIsMigrating(rs.getInt("ISMIGRATING"));
								vcc.setStatus(rs.getString("STATUS"));
								logger.debug("[" + rs.getString("MSISDN")
										+ "] found in VCC_AUTH_USER ");
								return vcc;
							}
							logger.info("No data  found in VCC_AUTH_USER");
							return null;
						}
					});
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00016] MSISDN["
							+ msisdn
							+ "][Exception while getting user profile detail from VCC_AUTH_USER] Error["
							+ e.getMessage() + "]");
			logger.info("[" + msisdn
					+ "] db operation not perform for getProfileDetail [" + e
					+ "]");
			return null;
		} finally {
			commonOperation = null;
		}
	}

	public List<VccVoiceMessage> getMailboxGroupByCount(String msisdn,
			String serviceType) {
		
		List<VccVoiceMessage> vcc = null;
		VccCommonOperation commonOperation = new VccCommonOperation();
		msisdn = commonOperation.msisdnWithCountryCode(msisdn);
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "select MESSAGE_STATUS,ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_TIME,"
					+ "RETRIVAL_TIME,FILENAME,VOICE_MESSAGE_INDEX,RECORDING_DURATION,MSG_PROTECT,"
					+ "MSG_PRIORITY,PASS_PROTECTED,PASSWORD,ORIGINAL_NUMBER,LOCAL_MESSAGE_INDEX,"
					+ "SENDING_TIME,SERVICE_TYPE from VCC_VOICE_MSG where DESTINATION_NUMBER=? and SERVICE_TYPE =? order by CALL_TIME";
			vcc = jdbcTemplate.query(query,
					new Object[] { msisdn, serviceType },
					new VccVoiceMsgRowMapper());
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00020] MSISDN["
							+ msisdn
							+ "] ServiceType["
							+ serviceType
							+ "] [Exception while getting data from VCC_VOICE_MSG] Error["
							+ e.getMessage() + "]");

			logger.info("["
					+ msisdn
					+ "] error in executing query [select * from VCC_VOICE_MSG where  DESTINATION_NUMBER="
					+ msisdn + " and SERVICE_TYPE=" + serviceType
					+ " order by CALL_TIME]");
			return null;
		}
		logger.debug("List from DB" + vcc.toString());
		return vcc;

	}

	@SuppressWarnings("deprecation")
	public boolean isUserIsOptedOut(ProfileRequest profileRequest,
			ProfileResponse profileResponse) {

		Integer status = 0;
		String query = "select count(*) from VCC_SERVICE_UNSUB "
				+ "where MSISDN = " + profileRequest.getCalledNum()
				+ " and SERVICE_TYPE = " + profileRequest.getServiceType() + "";
		logger.debug("[" + profileRequest.getCalledNum() + "] Query is:->>> ["
				+ query + "]");

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			status = jdbcTemplate.queryForInt(query);
			logger.debug("select count(*) from VCC_SERVICE_UNSUB where MSISDN = "
					+ profileRequest.getCalledNum()
					+ " and SERVICE_TYPE = "
					+ profileRequest.getServiceType() + " [" + status + "]");
			if (status != 0)
				return true;
			else
				return false;
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-IVRWAR-") + "00018] MSISDN["
					+ profileRequest.getCalledNum() + "] ServiceType["
					+ profileRequest.getServiceType()
					+ "] [Exception while checking isUserIsOptedOut] Error["
					+ e.getMessage() + "]");
			logger.info("Error in check isUserIsOptedOut" + e);
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public int getVoiceMsgIndex(VmRequest vmRequest) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String query = "select VOICE_MESSAGE_INDEX from VCC_VOICE_MSG "
				+ "where FILENAME=?";

		logger.debug("Quesry is :->>> [select VOICE_MESSAGE_INDEX from VCC_VOICE_MSG "
				+ "where FILENAME=" + vmRequest.getRecordFileName() + "]");

		VccVoiceMessage msg = jdbcTemplate.query(query,
				new Object[] { vmRequest.getRecordFileName() },
				new ResultSetExtractor<VccVoiceMessage>() {
					@Override
					public VccVoiceMessage extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						if (rs.next()) {
							VccVoiceMessage msg = new VccVoiceMessage();
							msg.setVoiceMessageIndex(rs
									.getInt("VOICE_MESSAGE_INDEX"));
							return msg;
						}
						return new VccVoiceMessage();
					}
				});
		if (msg != null)
			return msg.getVoiceMessageIndex();
		else
			return 0;
	}

	@Override
	public int insertFwdCallLogs(VccFwdCallLogs fwdCallLogs) {
		VccCommonOperation vccCommon = new VccCommonOperation();
		String countryCode = vccCommon.getCountryCode(fwdCallLogs
				.getOriginatingNumber());
		
		if(AppConfig.config.getInt("FILE_WRITER_FWD_CALL_LOGS_ENABLED",0) == 1) {
			AppConfig.VCC_FWD_CALL_LOGS_WRITER.writeLog(fwdCallLogs.getServerId()+","+fwdCallLogs.getCallId()+","+fwdCallLogs.getOriginatingNumber()+","+fwdCallLogs.getDestinationNumber()+","+fwdCallLogs.getCircuitId()+","+fwdCallLogs.getIamCauseCode()+","+fwdCallLogs.getRelCauseCode()+","+fwdCallLogs.getMsgLength()+",0,"+fwdCallLogs.getCallTime()+","+fwdCallLogs.getCallDuration()+","+fwdCallLogs.getAnswered()+","+fwdCallLogs.getServiceType()+","+fwdCallLogs.getSubType()+","+fwdCallLogs.getRatePlan()+","+fwdCallLogs.getFileName()+","+countryCode);
			logger.info("VCC_FWD_CALL_LOGS writes into File at path : ["+AppConfig.config.getString("RULEBLOCK_LOG_FILEPATH")+"]");
			return 1;
		} else {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			logger.debug("["
					+ fwdCallLogs.getOriginatingNumber()
					+ "] Query is [insert into VCC_FWD_CALL_LOGS"
					+ "(SERVER_ID,CALL_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,CIRCUIT_ID,"
					+ "IAM_CAUSE_CODE,REL_CAUSE_CODE,MSG_LENGTH,CALL_TIME,"
					+ "CALL_DURATION,ANSWERED,SERVICE_TYPE,SUB_TYPE,RATE_PLAN,FILENAME,ORG_CNT_CODE)"
					+ "values(" + fwdCallLogs.getServerId() + ","
					+ fwdCallLogs.getCallId() + ","
					+ fwdCallLogs.getOriginatingNumber() + ","
					+ fwdCallLogs.getDestinationNumber() + ","
					+ fwdCallLogs.getCircuitId() + ","
					+ fwdCallLogs.getIamCauseCode() + ","
					+ fwdCallLogs.getRelCauseCode() + ","
					+ fwdCallLogs.getMsgLength() + ","
					+ fwdCallLogs.getCallTime() + ","
					+ fwdCallLogs.getCallDuration() + ","
					+ fwdCallLogs.getAnswered() + ","
					+ fwdCallLogs.getServiceType() + "," + fwdCallLogs.getSubType()
					+ "," + fwdCallLogs.getRatePlan() + ","
					+ fwdCallLogs.getFileName() + "," + countryCode + ")]");

			/*
			 * String query = "insert into VCC_FWD_CALL_LOGS" +
			 * "(SERVER_ID,CALL_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,CIRCUIT_ID,"
			 * +
			 * "IAM_CAUSE_CODE,REL_CAUSE_CODE,MSG_LENGTH,VOICE_MSG_INDEX,CALL_TIME,"
			 * + "CALL_DURATION,ANSWERED,SERVICE_TYPE,SUB_TYPE,RATE_PLAN,FILENAME)"
			 * + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			 */

			String query = null;
			if (AppConfig.config.getString("db_type").equalsIgnoreCase("mysql")) {
				query = "insert into VCC_FWD_CALL_LOGS"
						+ "(SERVER_ID,CALL_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,CIRCUIT_ID,"
						+ "IAM_CAUSE_CODE,REL_CAUSE_CODE,MSG_LENGTH,CALL_TIME,"
						+ "CALL_DURATION,ANSWERED,SERVICE_TYPE,SUB_TYPE,RATE_PLAN,FILENAME,ORG_CNT_CODE)"
						+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			} else if (AppConfig.config.getString("db_type").equalsIgnoreCase(
					"oracle")) {
				query = "insert into VCC_FWD_CALL_LOGS"
						+ "(SERVER_ID,CALL_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,CIRCUIT_ID,"
						+ "IAM_CAUSE_CODE,REL_CAUSE_CODE,MSG_LENGTH,CALL_TIME,"
						+ "CALL_DURATION,ANSWERED,SERVICE_TYPE,SUB_TYPE,RATE_PLAN,FILENAME,ORG_CNT_CODE)"
						+ "values(?,?,?,?,?,?,?,?,to_date(?,'DD-MM-YYYY HH24:MI:SS'),?,?,?,?,?,?,?)";
			}
			try {
				return jdbcTemplate.update(
						query,
						new Object[] { fwdCallLogs.getServerId(),
								fwdCallLogs.getCallId(),
								fwdCallLogs.getOriginatingNumber(),
								fwdCallLogs.getDestinationNumber(),
								fwdCallLogs.getCircuitId(),
								fwdCallLogs.getIamCauseCode(),
								fwdCallLogs.getRelCauseCode(),
								fwdCallLogs.getMsgLength(),
								fwdCallLogs.getCallTime(),
								fwdCallLogs.getCallDuration(),
								fwdCallLogs.getAnswered(),
								fwdCallLogs.getServiceType(),
								fwdCallLogs.getSubType(),
								fwdCallLogs.getRatePlan(),
								fwdCallLogs.getFileName(), countryCode

						});
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString("errorcode_pattern",
										"VCC-IVRWAR-")
								+ "00019] OriginationNumber["
								+ fwdCallLogs.getOriginatingNumber()
								+ "] DestinationNumber["
								+ fwdCallLogs.getDestinationNumber()
								+ "] ServiceType["
								+ fwdCallLogs.getServiceType()
								+ "] [Exception while inserting data into VCC_FWD_CALL_LOGS] Error["
								+ e.getMessage() + "]");

				return 0;
			}
		}
	}

	@Override
	public List<VccVoiceMessage> getMailboxOrderByCallTime(String msisdn,
			String serviceType) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		msisdn = commonOperation.msisdnWithCountryCode(msisdn);
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "select MESSAGE_STATUS,ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_TIME,"
					+ "RETRIVAL_TIME,FILENAME,VOICE_MESSAGE_INDEX,RECORDING_DURATION,MSG_PROTECT,"
					+ "MSG_PRIORITY,PASS_PROTECTED,PASSWORD,ORIGINAL_NUMBER,LOCAL_MESSAGE_INDEX,"
					+ "SENDING_TIME,SERVICE_TYPE from VCC_VOICE_MSG where DESTINATION_NUMBER=? and SERVICE_TYPE =? order by CALL_TIME";
			return jdbcTemplate.query(query,
					new Object[] { msisdn, serviceType },
					new VccVoiceMsgRowMapper());
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00020] MSISDN["
							+ msisdn
							+ "] ServiceType["
							+ serviceType
							+ "] [Exception while getting data from VCC_VOICE_MSG] Error["
							+ e.getMessage() + "]");

			logger.info("["
					+ msisdn
					+ "] error in executing query [select * from VCC_VOICE_MSG where  DESTINATION_NUMBER="
					+ msisdn + " and SERVICE_TYPE=" + serviceType
					+ " order by CALL_TIME]");
			return null;

		}
	}

	@Override
	public Boolean deleteVccVoiceMessage(String calledNum, int voiceMsgIndex) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		calledNum = commonOperation.msisdnWithCountryCode(calledNum);
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			logger.debug("["
					+ calledNum
					+ "] query :- >>>[delete from VCC_VOICE_MSG where DESTINATION_NUMBER="
					+ calledNum + " and VOICE_MESSAGE_INDEX=" + voiceMsgIndex
					+ "]");
			String query = "delete from VCC_VOICE_MSG where DESTINATION_NUMBER=? and VOICE_MESSAGE_INDEX=?";
			int result = jdbcTemplate.update(query, new Object[] { calledNum,
					voiceMsgIndex });
			if (result == 1)
				return true;
			else {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-IVRWAR-")
								+ "00021] MSISDN["
								+ calledNum
								+ "] [Unable to delete data from VCC_VOICE_MSG. No data found to delete]");
				return false;
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00022] MSISDN["
							+ calledNum
							+ "] [Exception while deleting data from VCC_VOICE_MSG.] Error["
							+ e.getMessage() + "]");
			logger.error("[" + calledNum
					+ "] db operation not perform for voicemsgindex ["
					+ voiceMsgIndex + "]in   deleteVccVoiceMessage [" + e + "]");
			return false;
		} finally {
			commonOperation = null;
		}
	}

	@Override
	public VccSubscriptionMaster getActiveUserByServiceType(String msisdn,
			String serviceType) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		msisdn = commonOperation.msisdnWithCountryCode(msisdn);

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				query = "select MSISDN,SERVICE_TYPE,EXPIRY_DATE,RATE_PLAN,DATE_REGISTERED,STATUS,SERVICE_FLAG,LAST_VISIT_TIME from VCC_SUBSCRIPTION_MASTER_"+msisdn.charAt(msisdn.length()-1)+" where MSISDN='"+ msisdn + "' and SERVICE_TYPE='" + serviceType + "'";
			} else {
				query = "select MSISDN,SERVICE_TYPE,EXPIRY_DATE,RATE_PLAN,DATE_REGISTERED,STATUS,SERVICE_FLAG,LAST_VISIT_TIME from VCC_SUBSCRIPTION_MASTER where MSISDN='"+ msisdn + "' and SERVICE_TYPE='" + serviceType + "'";
			}
			logger.debug("[" + msisdn + "] sql query :->>> [" + query + "]");
			return jdbcTemplate.query(query, new Object[] {},
					new ResultSetExtractor<VccSubscriptionMaster>() {
						@Override
						public VccSubscriptionMaster extractData(ResultSet rs)
								throws SQLException, DataAccessException {
							if (rs.next()) {
								VccSubscriptionMaster vccSubscriptionMaster = new VccSubscriptionMaster();
								vccSubscriptionMaster.setMsisdn(rs
										.getString("MSISDN"));
								vccSubscriptionMaster.setRatePlan(rs
										.getInt("RATE_PLAN"));
								vccSubscriptionMaster.setServiceType(rs
										.getString("SERVICE_TYPE"));
								vccSubscriptionMaster.setStatus(rs
										.getString("STATUS"));
								vccSubscriptionMaster.setServiceFlag(rs
										.getString("SERVICE_FLAG"));
								logger.debug("["
										+ rs.getString("MSISDN")
										+ "] found in VCC_SUBSCRIPTION_MASTER and service flag are ["
										+ rs.getString("SERVICE_FLAG") + "]");
								return vccSubscriptionMaster;

							}
							logger.warn("NO data found in VCC_SUBSCRIPTION_MASTER");
							return null;
						}

					});
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00023] MSISDN["
							+ msisdn
							+ "] ServiceType["
							+ serviceType
							+ "] [Exception while getting data from VCC_SUBSCRIPTION_MASTER] Error["
							+ e.getMessage() + "]");
			logger.error("["
					+ msisdn
					+ "] db operation not perform in getActiveUserByServiceType error ["
					+ e + "]");
			return null;
		}
	}

	@Override
	public int updateUserLanguage(ProfileRequest profileRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(profileRequest
				.getCallingNum());
		int isNew = 0;
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			if (AppConfig.config.getInt("product_code", 1) == 1) {
				String query = null;
				if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
					query = "update VCC_AUTH_USER_"+msisdn.charAt(msisdn.length()-1)+" SET LANGUAGE=? ,ISNEW=? Where MSISDN=?";
				} else {
					query = "update VCC_AUTH_USER SET LANGUAGE=? ,ISNEW=? Where MSISDN=?";
				}
				logger.debug("["+ msisdn+ "] Query is :->>> ["+query+"]");
				return jdbcTemplate
						.update(query, new Object[] { profileRequest.getLang(),
								isNew, msisdn });
			} else {
				String query = null;
				if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
					query = "update VCC_AUTH_USER_"+msisdn.charAt(msisdn.length()-1)+" SET LANGUAGE=? Where MSISDN=?";
				} else {
					query = "update VCC_AUTH_USER SET LANGUAGE=? Where MSISDN=?";
				}
				logger.debug("["+ msisdn+ "] Query is :->>> ["+query+"]");
				return jdbcTemplate.update(query, new Object[] { profileRequest.getLang(), msisdn });
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00024] MSISDN["
							+ msisdn
							+ "] ServiceType["
							+ profileRequest.getServiceType()
							+ "] [Exception while updating language in VCC_AUTH_USER] Error["
							+ e.getMessage() + "]");
			logger.error("[" + msisdn + "] error in update language [" + e
					+ "]");
			e.printStackTrace();
			return 0;
		} finally {
			commonOperation = null;
		}
	}

	@Override
	public boolean isUserSubscribe(String msisdn, String serviceType) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		msisdn = commonOperation.msisdnWithCountryCode(msisdn);
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				query = "select count(*) from VCC_SUBSCRIPTION_MASTER_"+msisdn.charAt(msisdn.length()-1)+" where MSISDN = ? and SERVICE_TYPE = ? and " + "STATUS = ?";
			} else {
				query = "select count(*) from VCC_SUBSCRIPTION_MASTER where MSISDN = ? and SERVICE_TYPE = ? and " + "STATUS = ?";
			}
			logger.debug("["+ msisdn+ "] Query is :->>> ["+query+"]");
			
			return jdbcTemplate.queryForObject(query, new Object[] { msisdn,
					serviceType, "A" }, Boolean.class);
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-IVRWAR-") + "00025] MSISDN[" + msisdn
					+ "] ServiceType[" + serviceType
					+ "] [Exception while checking isUserSubscriber] Error["
					+ e.getMessage() + "]");
			logger.error("[" + msisdn
					+ "] db operation not perform in isUserSubscribe [" + e
					+ "]");
			return false;
		} finally {
			commonOperation = null;
		}
	}

	@Override
	public int saveRetrievalLog(RetLogRequest retLogRequest) {

		VccCommonOperation commonOperation = new VccCommonOperation();

		String msisdn = commonOperation.msisdnWithCountryCode(retLogRequest
				.getCallingNum());
		String countryCode = commonOperation.getCountryCode(retLogRequest
				.getCallingNum());
		logger.debug("["
				+ msisdn
				+ "]Query is :->>> [insert into VCC_RETRIEVAL_LOG "
				+ "(SERVER_ID,CALL_ID,ORIGINATING_ADDRESS,DESTINATION_ADDRESS,MAILBOX_NO,MSG_LENGTH,CALL_TIME,CALL_DURATION,"
				+ "NO_MSGREAD,NO_MSGDEL,NO_MSGMOVE,NO_MSGCOPY,NO_MSGSAVE,NO_GREETADD,NO_GREETDEL,NO_FRNDADD,"
				+ "NO_FRNDDEL,NO_DIALED,NO_RECORED,ANSWERED,SERVICE_TYPE,SUB_TYPE,RATE_PLAN,ORG_CNT_CODE) "
				+ "values(" + retLogRequest.getServerId() + ","
				+ retLogRequest.getCallUUID() + "," + msisdn + ","
				+ retLogRequest.getCalledNum() + ","
				+ retLogRequest.getMailboxNo() + ","
				+ retLogRequest.getMsgLength() + ","
				+ retLogRequest.getCallTime() + ","
				+ retLogRequest.getCallDuration() + ","
				+ retLogRequest.getmRd() + "," + retLogRequest.getmDel() + ","
				+ retLogRequest.getmMv() + "," + retLogRequest.getmCp() + ","
				+ retLogRequest.getmSv() + "," + retLogRequest.getGrtAd() + ","
				+ retLogRequest.getGrtDel() + "," + retLogRequest.getFrndAd()
				+ "," + retLogRequest.getFrndDel() + ","
				+ retLogRequest.getDialCnt() + "," + retLogRequest.getRecCnt()
				+ "," + retLogRequest.getAnswered() + ","
				+ retLogRequest.getServiceType() + ","
				+ retLogRequest.getSubType() + ","
				+ retLogRequest.getRatePlan() + "," + countryCode + ")]");
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			/*
			 * String query = "insert into VCC_RETRIEVAL_LOG " +
			 * "(SERVER_ID,CALL_ID,ORIGINATING_ADDRESS,DESTINATION_ADDRESS,MAILBOX_NO,MSG_LENGTH,CALL_TIME,CALL_DURATION,"
			 * +
			 * "NO_MSGREAD,NO_MSGDEL,NO_MSGMOVE,NO_MSGCOPY,NO_MSGSAVE,NO_GREETADD,NO_GREETDEL,NO_FRNDADD,"
			 * +
			 * "NO_FRNDDEL,NO_DIALED,NO_RECORED,ANSWERED,SERVICE_TYPE,SUB_TYPE,RATE_PLAN) values(?,?,?,?,?,?,to_date(?,'DD-MM-YYYY HH24:MI:SS'),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
			 * ;
			 */

			String query = null;
			if (AppConfig.config.getString("db_type").equalsIgnoreCase("mysql")) {
				query = "insert into VCC_RETRIEVAL_LOG "
						+ "(SERVER_ID,CALL_ID,ORIGINATING_ADDRESS,DESTINATION_ADDRESS,MAILBOX_NO,MSG_LENGTH,CALL_TIME,CALL_DURATION,"
						+ "NO_MSGREAD,NO_MSGDEL,NO_MSGMOVE,NO_MSGCOPY,NO_MSGSAVE,NO_GREETADD,NO_GREETDEL,NO_FRNDADD,"
						+ "NO_FRNDDEL,NO_DIALED,NO_RECORED,ANSWERED,SERVICE_TYPE,SUB_TYPE,RATE_PLAN,ORG_CNT_CODE) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			} else if (AppConfig.config.getString("db_type").equalsIgnoreCase(
					"oracle")) {
				query = "insert into VCC_RETRIEVAL_LOG "
						+ "(SERVER_ID,CALL_ID,ORIGINATING_ADDRESS,DESTINATION_ADDRESS,MAILBOX_NO,MSG_LENGTH,CALL_TIME,CALL_DURATION,"
						+ "NO_MSGREAD,NO_MSGDEL,NO_MSGMOVE,NO_MSGCOPY,NO_MSGSAVE,NO_GREETADD,NO_GREETDEL,NO_FRNDADD,"
						+ "NO_FRNDDEL,NO_DIALED,NO_RECORED,ANSWERED,SERVICE_TYPE,SUB_TYPE,RATE_PLAN,ORG_CNT_CODE) values(?,?,?,?,?,?,to_date(?,'DD-MM-YYYY HH24:MI:SS'),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			}

			return jdbcTemplate.update(
					query,
					new Object[] { retLogRequest.getServerId(),
							retLogRequest.getCallUUID(), msisdn,
							retLogRequest.getCalledNum(),
							retLogRequest.getMailboxNo(),
							retLogRequest.getMsgLength(),
							retLogRequest.getCallTime(),
							retLogRequest.getCallDuration(),
							retLogRequest.getmRd(), retLogRequest.getmDel(),
							retLogRequest.getmMv(), retLogRequest.getmCp(),
							retLogRequest.getmSv(), retLogRequest.getGrtAd(),
							retLogRequest.getGrtDel(),
							retLogRequest.getFrndAd(),
							retLogRequest.getFrndDel(),
							retLogRequest.getDialCnt(),
							retLogRequest.getRecCnt(),
							retLogRequest.getAnswered(),
							retLogRequest.getServiceType(),
							retLogRequest.getSubType(),
							retLogRequest.getRatePlan(), countryCode });
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00026] MSISDN["
							+ msisdn
							+ "] ServiceType["
							+ retLogRequest.getServiceType()
							+ "] [Exception while saving retrieval log in VCC_RETRIEVAL_LOG] Error["
							+ e.getMessage() + "]");
			logger.error("[" + retLogRequest.getCallingNum()
					+ "] db operation not perform in saveRetrievalLog error ["
					+ e + "]");
			e.printStackTrace();

			return 0;
		}
	}

	@Override
	public List<VccVoiceMessage> getMailboxOrderBySendTime(VmRequest vmRequest) {

		logger.debug("["
				+ vmRequest.getCalledNum()
				+ "] Query is :->>> [select * from VCC_VOICE_MSG where  ORIGINAL_NUMBER="
				+ vmRequest.getCalledNum() + " and MESSAGE_STATUS ="
				+ vmRequest.getCatName() + " order by SENDING_TIME]");
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "select * from VCC_VOICE_MSG where  ORIGINAL_NUMBER=? and MESSAGE_STATUS =? order by SENDING_TIME";
			return jdbcTemplate.query(
					query,
					new Object[] { vmRequest.getCalledNum(),
							vmRequest.getCatName() },
					new VccVoiceMsgRowMapper());
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00027] MSISDN["
							+ vmRequest.getCalledNum()
							+ "] ServiceType["
							+ vmRequest.getServiceType()
							+ "] [Exception while getting mailbox detail order by Sending time from VCC_VOICE_MSG] Error["
							+ e.getMessage() + "]");
			logger.error("[" + vmRequest.getCallingNum()
					+ "] db operation not perform in getMailboxOrderBySendTime");
			return null;
		}
	}

	@Override
	public int updateVoiceMsgStatus(VmRequest vmRequest, String status) {

		VccCommonOperation commonOperation = new VccCommonOperation();

		String msisdn = commonOperation.msisdnWithCountryCode(vmRequest
				.getCallingNum());

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			/*
			 * String query =
			 * "update VCC_VOICE_MSG SET MESSAGE_STATUS=?,RETRIVAL_TIME=now() Where "
			 * + "ORIGINAL_NUMBER=? and VOICE_MESSAGE_INDEX=?";
			 */

			String query = null;
			if (AppConfig.config.getString("db_type").equalsIgnoreCase("mysql")) {

				logger.debug("["
						+ msisdn
						+ "] Query is :->>> [update VCC_VOICE_MSG SET MESSAGE_STATUS="
						+ status + ",RETRIVAL_TIME=now() Where "
						+ "ORIGINAL_NUMBER=" + msisdn
						+ " and VOICE_MESSAGE_INDEX="
						+ vmRequest.getVoiceMsgIndex() + "]");

				query = "update VCC_VOICE_MSG SET MESSAGE_STATUS=?,RETRIVAL_TIME=now() Where "
						+ "ORIGINAL_NUMBER=? and VOICE_MESSAGE_INDEX=?";
			} else if (AppConfig.config.getString("db_type").equalsIgnoreCase(
					"oracle")) {

				logger.debug("["
						+ msisdn
						+ "] Query is :->>> [update VCC_VOICE_MSG SET MESSAGE_STATUS="
						+ status + ",RETRIVAL_TIME=sysdate Where "
						+ "ORIGINAL_NUMBER=" + msisdn
						+ " and VOICE_MESSAGE_INDEX="
						+ vmRequest.getVoiceMsgIndex() + "]");
				query = "update VCC_VOICE_MSG SET MESSAGE_STATUS=?,RETRIVAL_TIME=sysdate Where "
						+ "ORIGINAL_NUMBER=? and VOICE_MESSAGE_INDEX=?";
			}

			return jdbcTemplate.update(query, new Object[] { status, msisdn,
					vmRequest.getVoiceMsgIndex() });
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00028] MSISDN["
							+ msisdn
							+ "] ServiceType["
							+ vmRequest.getServiceType()
							+ "] [Exception while updating message status in VCC_VOICE_MSG] Error["
							+ e.getMessage() + "]");
			logger.error("[" + vmRequest.getCallingNum()
					+ "] db operation not perform in updateVoiceMsgStatus ["
					+ e + "]");

			return 0;
		} finally {
			commonOperation = null;
		}

	}

	@Override
	public List<VccUserCompleteDetails> getUserCompleteDetail(String msisdn) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		msisdn = commonOperation.msisdnWithCountryCode(msisdn);
		List<VccUserCompleteDetails> list = new ArrayList<VccUserCompleteDetails>();
		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String sql = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				char lastDigit = msisdn.charAt(msisdn.length()-1);
				sql = "select a.LOGIN_NAME,a.MSISDN,a.LANGUAGE,a.WPIN,a.EMAIL_ADDR,"
						+ "a.DELIVERY_INTERFACE,a.PASS,a.GREETING_TYPE,a.SUB_TYPE,a.IMSI,"
						+ "a.CLASS_TYPE,a.ISNEW,a.ISMIGRATING,b.STATUS,b.SERVICE_TYPE,"
						+ "b.RATE_PLAN,b.EXPIRY_DATE,b.DATE_REGISTERED,b.service_flag"
						+ " from VCC_AUTH_USER_"+lastDigit+" a join VCC_SUBSCRIPTION_MASTER_"+lastDigit+" b on(a.MSISDN=b.MSISDN and a.MSISDN=?)";
			} else {
				sql = "select a.LOGIN_NAME,a.MSISDN,a.LANGUAGE,a.WPIN,a.EMAIL_ADDR,"
						+ "a.DELIVERY_INTERFACE,a.PASS,a.GREETING_TYPE,a.SUB_TYPE,a.IMSI,"
						+ "a.CLASS_TYPE,a.ISNEW,a.ISMIGRATING,b.STATUS,b.SERVICE_TYPE,"
						+ "b.RATE_PLAN,b.EXPIRY_DATE,b.DATE_REGISTERED,b.service_flag"
						+ " from VCC_AUTH_USER a join VCC_SUBSCRIPTION_MASTER b on(a.MSISDN=b.MSISDN and a.MSISDN=?)";
			}
			logger.info("Getting User Complete Details. Query["+sql+"] Msisdn["+msisdn+"]");
			list = jdbcTemplate.query(sql, new Object[] { msisdn},
					new RowMapper<VccUserCompleteDetails>() {
						@Override
						public VccUserCompleteDetails mapRow(ResultSet rs,
								int rownumber) throws SQLException {
							VccUserCompleteDetails vcc = new VccUserCompleteDetails();
							vcc.setLoginName(rs.getString("LOGIN_NAME"));
							vcc.setMsisdn(rs.getString("MSISDN"));
							vcc.setLanguage(rs.getInt("LANGUAGE"));
							vcc.setWpin(rs.getString("WPIN"));
							vcc.setEmail(rs.getString("EMAIL_ADDR"));
							vcc.setDeliveryInterface(rs
									.getInt("DELIVERY_INTERFACE"));
							vcc.setPassword(rs.getString("PASS"));
							vcc.setServiceType(rs.getString("SERVICE_TYPE"));
							vcc.setGreetingType(rs.getInt("GREETING_TYPE"));
							vcc.setSubType(rs.getString("SUB_TYPE"));
							vcc.setImsi(rs.getString("IMSI"));
							vcc.setClassType(rs.getInt("CLASS_TYPE"));
							vcc.setRatePlan(rs.getInt("RATE_PLAN"));
							vcc.setExpiryDate(rs.getString("EXPIRY_DATE"));
							vcc.setDateRegistered(rs
									.getString("DATE_REGISTERED"));
							vcc.setIsNew(rs.getInt("ISNEW"));
							vcc.setIsMigrating(rs.getInt("ISMIGRATING"));
							vcc.setStatus(rs.getString("STATUS"));
							vcc.setServiceFlag(rs.getString("service_flag"));
							return vcc;
						}
					});
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00029] MSISDN["
							+ msisdn
							+ "] [Exception while getting user complete profile from VCC_SUBSCRIPTION_MASTER and VCC_AUTH_USER] Error["
							+ e.getMessage() + "]");
			logger.error("[" + msisdn
					+ "] db operation not perform in getUserCompleteDetail ["
					+ e + "]");
			return null;
		}
		return list;
	}


	@Override
	public List<VccUserCompleteDetails> getUserCompleteDetail(ProfileRequest profileRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(profileRequest.getCalledNum());
		List<VccUserCompleteDetails> list = new ArrayList<VccUserCompleteDetails>();

		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String sql = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				char lastDigit = msisdn.charAt(msisdn.length()-1);
				sql = "select a.LOGIN_NAME,a.MSISDN,a.LANGUAGE,a.WPIN,a.EMAIL_ADDR,"
						+ "a.DELIVERY_INTERFACE,a.PASS,a.GREETING_TYPE,a.SUB_TYPE,a.IMSI,"
						+ "a.CLASS_TYPE,a.ISNEW,a.ISMIGRATING,b.STATUS,b.SERVICE_TYPE,"
						+ "b.RATE_PLAN,b.EXPIRY_DATE,b.DATE_REGISTERED,b.service_flag"
						+ " from VCC_AUTH_USER_"+lastDigit+" a join VCC_SUBSCRIPTION_MASTER_"+lastDigit+" b on(a.MSISDN=b.MSISDN and a.MSISDN=? and b.service_type=?)";
			} else {
				sql = "select a.LOGIN_NAME,a.MSISDN,a.LANGUAGE,a.WPIN,a.EMAIL_ADDR,"
						+ "a.DELIVERY_INTERFACE,a.PASS,a.GREETING_TYPE,a.SUB_TYPE,a.IMSI,"
						+ "a.CLASS_TYPE,a.ISNEW,a.ISMIGRATING,b.STATUS,b.SERVICE_TYPE,"
						+ "b.RATE_PLAN,b.EXPIRY_DATE,b.DATE_REGISTERED,b.service_flag"
						+ " from VCC_AUTH_USER a join VCC_SUBSCRIPTION_MASTER b on(a.MSISDN=b.MSISDN and a.MSISDN=? and b.service_type=?)";
			}
			logger.info("Query["+sql+"] Msisdn["+msisdn+"]");
			list = jdbcTemplate.query(sql, new Object[] { msisdn, profileRequest.getServiceType() },
					new RowMapper<VccUserCompleteDetails>() {
						@Override
						public VccUserCompleteDetails mapRow(ResultSet rs,
								int rownumber) throws SQLException {
							VccUserCompleteDetails vcc = new VccUserCompleteDetails();
							vcc.setLoginName(rs.getString("LOGIN_NAME"));
							vcc.setMsisdn(rs.getString("MSISDN"));
							vcc.setLanguage(rs.getInt("LANGUAGE"));
							vcc.setWpin(rs.getString("WPIN"));
							vcc.setEmail(rs.getString("EMAIL_ADDR"));
							vcc.setDeliveryInterface(rs
									.getInt("DELIVERY_INTERFACE"));
							vcc.setPassword(rs.getString("PASS"));
							vcc.setServiceType(rs.getString("SERVICE_TYPE"));
							vcc.setGreetingType(rs.getInt("GREETING_TYPE"));
							vcc.setSubType(rs.getString("SUB_TYPE"));
							vcc.setImsi(rs.getString("IMSI"));
							vcc.setClassType(rs.getInt("CLASS_TYPE"));
							vcc.setRatePlan(rs.getInt("RATE_PLAN"));
							vcc.setExpiryDate(rs.getString("EXPIRY_DATE"));
							vcc.setDateRegistered(rs
									.getString("DATE_REGISTERED"));
							vcc.setIsNew(rs.getInt("ISNEW"));
							vcc.setIsMigrating(rs.getInt("ISMIGRATING"));
							vcc.setStatus(rs.getString("STATUS"));
							vcc.setServiceFlag(rs.getString("service_flag"));
							return vcc;
						}
					});
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00029] MSISDN["
							+ msisdn
							+ "] [Exception while getting user complete profile from VCC_SUBSCRIPTION_MASTER and VCC_AUTH_USER] Error["
							+ e.getMessage() + "]");
			logger.error("[" + msisdn
					+ "] db operation not perform in getUserCompleteDetail ["
					+ e + "]");
			return null;
		}
		return list;
	}
	
	@Override
	public List<VccUserCompleteDetails> getUserAuthDetail(ProfileRequest profileRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(profileRequest.getCalledNum());
		List<VccUserCompleteDetails> list = new ArrayList<VccUserCompleteDetails>();

		try {

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String sql = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				sql = "select a.LOGIN_NAME,a.MSISDN,a.LANGUAGE,a.WPIN,a.EMAIL_ADDR,a.DELIVERY_INTERFACE,a.PASS,a.GREETING_TYPE,a.SUB_TYPE,a.IMSI,a.CLASS_TYPE,a.ISNEW,a.ISMIGRATING,a.SERVICE_TYPE from VCC_AUTH_USER_"+msisdn.charAt(msisdn.length()-1)+" a WHERE a.MSISDN=?";
			} else {
				sql = "select a.LOGIN_NAME,a.MSISDN,a.LANGUAGE,a.WPIN,a.EMAIL_ADDR,a.DELIVERY_INTERFACE,a.PASS,a.GREETING_TYPE,a.SUB_TYPE,a.IMSI,a.CLASS_TYPE,a.ISNEW,a.ISMIGRATING,a.SERVICE_TYPE from VCC_AUTH_USER a WHERE a.MSISDN=?";
			}
			logger.debug("["+ msisdn+ "] Query is :->>> ["+sql+"]");
			list = jdbcTemplate.query(sql, new Object[] { msisdn },
					new RowMapper<VccUserCompleteDetails>() {
						@Override
						public VccUserCompleteDetails mapRow(ResultSet rs,
								int rownumber) throws SQLException {
							VccUserCompleteDetails vcc = new VccUserCompleteDetails();
							//b.STATUS,b.RATE_PLAN,b.EXPIRY_DATE,b.DATE_REGISTERED,b.service_flag
							vcc.setLoginName(rs.getString("LOGIN_NAME"));
							vcc.setMsisdn(rs.getString("MSISDN"));
							vcc.setLanguage(rs.getInt("LANGUAGE"));
							vcc.setWpin(rs.getString("WPIN"));
							vcc.setEmail(rs.getString("EMAIL_ADDR"));
							vcc.setDeliveryInterface(rs.getInt("DELIVERY_INTERFACE"));
							vcc.setPassword(rs.getString("PASS"));
							vcc.setServiceType(rs.getString("SERVICE_TYPE"));
							vcc.setGreetingType(rs.getInt("GREETING_TYPE"));
							vcc.setSubType(rs.getString("SUB_TYPE"));
							vcc.setImsi(rs.getString("IMSI"));
							vcc.setClassType(rs.getInt("CLASS_TYPE"));
							vcc.setIsNew(rs.getInt("ISNEW"));
							vcc.setIsMigrating(rs.getInt("ISMIGRATING"));
							//vcc.setRatePlan(rs.getInt("RATE_PLAN"));
							//vcc.setExpiryDate(rs.getString("EXPIRY_DATE"));
							//vcc.setDateRegistered(rs.getString("DATE_REGISTERED"));
							//vcc.setStatus(rs.getString("STATUS"));
							//vcc.setServiceFlag(rs.getString("service_flag"));
							return vcc;
						}
					});
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00029] MSISDN["
							+ msisdn
							+ "] [Exception while getting user profile from VCC_AUTH_USER] Error["
							+ e.getMessage() + "]");
			logger.error("[" + msisdn
					+ "] db operation not perform in getUserAuthDetail ["
					+ e + "]");
			return null;
		}
		return list;
	}
	
	@Override
	public List<VccUserCompleteDetails> getUserSubscriptionDetail(List<VccUserCompleteDetails> vccUserCompleteDetailList) {
		List<VccUserCompleteDetails> list = new ArrayList<VccUserCompleteDetails>();
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String sql = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				char lastDigit = vccUserCompleteDetailList.get(0).getMsisdn().charAt(vccUserCompleteDetailList.get(0).getMsisdn().length()-1);
				sql = "select b.STATUS,b.RATE_PLAN,b.EXPIRY_DATE,b.DATE_REGISTERED,b.service_flag from vcc_subscription_master_"+lastDigit+" b WHERE b.MSISDN=? AND b.SERVICE_TYPE=?";
			} else {
				sql = "select b.STATUS,b.RATE_PLAN,b.EXPIRY_DATE,b.DATE_REGISTERED,b.service_flag from vcc_subscription_master b WHERE b.MSISDN=? AND b.SERVICE_TYPE=?";
			}
			logger.debug("["+ vccUserCompleteDetailList.get(0).getMsisdn()+ "] Query is :->>> ["+sql+"]");
			VccUserCompleteDetails vcc = jdbcTemplate.query(sql, new Object[] { vccUserCompleteDetailList.get(0).getMsisdn(), vccUserCompleteDetailList.get(0).getServiceType() }, new ResultSetExtractor<VccUserCompleteDetails>() {
				@Override
				public VccUserCompleteDetails extractData(ResultSet rs) throws SQLException, DataAccessException {
					if (rs.next()) {
						VccUserCompleteDetails vcc2 =  new VccUserCompleteDetails();
						vcc2.setRatePlan(rs.getInt("RATE_PLAN"));
						vcc2.setExpiryDate(rs.getString("EXPIRY_DATE"));
						vcc2.setDateRegistered(rs.getString("DATE_REGISTERED"));
						vcc2.setStatus(rs.getString("STATUS"));
						vcc2.setServiceFlag(rs.getString("service_flag"));
						return vcc2;
					}
					return null;
				}
			});
			
			if(vcc != null) {
				list = vccUserCompleteDetailList;
				list.get(0).setRatePlan(vcc.getRatePlan());
				list.get(0).setExpiryDate(vcc.getExpiryDate());
				list.get(0).setDateRegistered(vcc.getDateRegistered());
				list.get(0).setStatus(vcc.getStatus());
				list.get(0).setServiceFlag(vcc.getServiceFlag());
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00029] MSISDN["
							+ vccUserCompleteDetailList.get(0).getMsisdn()
							+ "] [Exception while getting user complete profile from VCC_SUBSCRIPTION_MASTER] Error["
							+ e.getMessage() + "]");
			logger.error("[" + vccUserCompleteDetailList.get(0).getMsisdn()
					+ "] db operation not perform in getUserSubscriptionDetail ["
					+ e + "]");
			return null;
		}
		return list;
	}
	
	@Override
	public int saveVccNotification(VccVoiceMessage vccVoiceMessage,
			VccUserCompleteDetails userCompleteDetails) {
		userCompleteDetails.setStatus("N");
		String tableName = "";
		if (vccVoiceMessage.getNotificationSend())
			tableName = "vcc_notification";
		else
			tableName = "vcc_notification_temp";
		logger.debug("["
				+ vccVoiceMessage.getOriginattingNumber()
				+ "] Query is :->>> [insert into "
				+ tableName
				+ " "
				+ "(ORIGINATION_NUMBER,DESTINATION_NUMBER,ORIGINAL_NUMBER,SERVICE_TYPE,LANGUAGE,STATUS,CALL_TIME,"
				+ "RECORD_DURATION,LOCAL_MSG_INDEX,MSG_PRIORITY,PASS_PROTECTED,"
				+ "PASSWORD,DELIVERY_INTERFACE,CLASS_TYPE,SUB_TYPE,RATE_PLAN) "
				+ "values(" + vccVoiceMessage.getOriginattingNumber() + ","
				+ vccVoiceMessage.getDesticationNumber() + ","
				+ vccVoiceMessage.getOrginalNumber() + ","
				+ vccVoiceMessage.getServiceType() + ","
				+ userCompleteDetails.getLanguage() + ","
				+ userCompleteDetails.getStatus() + ","
				+ vccVoiceMessage.getCallTime() + ","
				+ vccVoiceMessage.getRecordingTime() + ","
				+ vccVoiceMessage.getLocalMessageIndex() + ","
				+ vccVoiceMessage.getMsgPriority() + ","
				+ vccVoiceMessage.getPassProtected() + ","
				+ vccVoiceMessage.getPassword() + ","
				+ userCompleteDetails.getDeliveryInterface() + ","
				+ userCompleteDetails.getClassType() + ","
				+ userCompleteDetails.getSubType() + ","
				+ userCompleteDetails.getRatePlan() + ")]");

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

			/*
			 * String sql = "insert into VCC_NOTIFICATION " +
			 * "(ORIGINATION_NUMBER,DESTINATION_NUMBER,ORIGINAL_NUMBER,SERVICE_TYPE,LANGUAGE,STATUS,CALL_TIME,"
			 * +
			 * "RECORD_DURATION,VOICE_MSG_INDEX,LOCAL_MSG_INDEX,MSG_PRIORITY,PASS_PROTECTED,"
			 * + "PASSWORD,DELIVERY_INTERFACE,CLASS_TYPE,SUB_TYPE,RATE_PLAN) " +
			 * "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			 */

			String sql = null;
			if (AppConfig.config.getString("db_type").equalsIgnoreCase("mysql")) {
				sql = "insert into "
						+ tableName
						+ " "
						+ "(ORIGINATION_NUMBER,DESTINATION_NUMBER,ORIGINAL_NUMBER,SERVICE_TYPE,LANGUAGE,STATUS,CALL_TIME,"
						+ "RECORD_DURATION,LOCAL_MSG_INDEX,MSG_PRIORITY,PASS_PROTECTED,"
						+ "PASSWORD,DELIVERY_INTERFACE,CLASS_TYPE,SUB_TYPE,RATE_PLAN) "
						+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			} else if (AppConfig.config.getString("db_type").equalsIgnoreCase(
					"oracle")) {
				sql = "insert into "
						+ tableName
						+ " "
						+ "(ORIGINATION_NUMBER,DESTINATION_NUMBER,ORIGINAL_NUMBER,SERVICE_TYPE,LANGUAGE,STATUS,CALL_TIME,"
						+ "RECORD_DURATION,LOCAL_MSG_INDEX,MSG_PRIORITY,PASS_PROTECTED,"
						+ "PASSWORD,DELIVERY_INTERFACE,CLASS_TYPE,SUB_TYPE,RATE_PLAN) "
						+ "values(?,?,?,?,?,?,to_date(?,'DD-MM-YYYY HH24:MI:SS'),?,?,?,?,?,?,?,?,?)";
			}

			return jdbcTemplate.update(
					sql,
					new Object[] { vccVoiceMessage.getOriginattingNumber(),
							vccVoiceMessage.getDesticationNumber(),
							vccVoiceMessage.getOrginalNumber(),
							vccVoiceMessage.getServiceType(),
							userCompleteDetails.getLanguage(),
							userCompleteDetails.getStatus(),
							vccVoiceMessage.getCallTime(),
							vccVoiceMessage.getRecordingTime(),
							vccVoiceMessage.getLocalMessageIndex(),
							vccVoiceMessage.getMsgPriority(),
							vccVoiceMessage.getPassProtected(),
							vccVoiceMessage.getPassword(),
							userCompleteDetails.getDeliveryInterface(),
							userCompleteDetails.getClassType(),
							userCompleteDetails.getSubType(),
							userCompleteDetails.getRatePlan() });
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00030] OriginationNumber["
							+ vccVoiceMessage.getOriginattingNumber()
							+ "] DestinationNumber["
							+ vccVoiceMessage.getDesticationNumber()
							+ "] ServiceType["
							+ vccVoiceMessage.getServiceType()
							+ "] [Exception while saving notification in VCC_NOTIFICATION] Error["
							+ e.getMessage() + "]");
			e.printStackTrace();
			logger.error("[" + vccVoiceMessage.getOriginattingNumber()
					+ "] db operation not perform in saveVccNotification [" + e
					+ "]");

			return 0;
		}
	}

	@Override
	public boolean updateUserPassword(ProfileRequest profileRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(profileRequest
				.getCallingNum());
		int isNew = 0;

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				query = "update VCC_AUTH_USER_"+msisdn.charAt(msisdn.length()-1)+" SET PASS=?,ISNEW=? Where MSISDN=?";
			} else {
				query = "update VCC_AUTH_USER SET PASS=?,ISNEW=? Where MSISDN=?";
			}
			logger.debug("["+ msisdn+ "] Query is :->>> ["+query+"]");
			int result = jdbcTemplate.update(query, new Object[] {
					profileRequest.getPassword(), isNew, msisdn });
			if (result > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00031] MSISDN["
							+ msisdn
							+ "] ServiceType["
							+ profileRequest.getServiceType()
							+ "] [Exception while updating password in VCC_AUTH_USER] Error["
							+ e.getMessage() + "]");
			logger.error("[" + profileRequest.getCallingNum()
					+ "] db operation not perform in updateUserPassword [" + e
					+ "]");
			return false;
		}
	}

	@Override
	public boolean saveUserGreeting(VccGreetingRequest greetingRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(greetingRequest
				.getCallingNum());
		logger.debug("[" + msisdn
				+ "] Query is :->>> [insert into VCC_PERSONALIZED_GREETING"
				+ "(MSISDN,FILEPATH,GREET_TYPE,RECORDING_TIME)" + "values("
				+ msisdn + "," + greetingRequest.getRecordFileName() + ","
				+ greetingRequest.getGreetingType() + ","
				+ greetingRequest.getRecordingDuration() + ")]");
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "insert into VCC_PERSONALIZED_GREETING"
					+ "(MSISDN,FILEPATH,GREET_TYPE,RECORDING_TIME)"
					+ "values(?,?,?,?)";
			int result = jdbcTemplate.update(
					query,
					new Object[] { msisdn, greetingRequest.getRecordFileName(),
							greetingRequest.getGreetingType(),
							greetingRequest.getRecordingDuration() });
			if (result > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00032] MSISDN["
							+ msisdn
							+ "] [Exception while saving user's greeting in VCC_PERSONALIZED_GREETING] Error["
							+ e.getMessage() + "]");
			logger.error("[" + greetingRequest.getCallingNum()
					+ "] db operation not perform in saveUserGreeting [" + e
					+ "]");
			return false;
		}
	}

	@Override
	public boolean deleteUserGreeting(VccGreetingRequest greetingRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(greetingRequest
				.getCallingNum());
		logger.debug("["
				+ msisdn
				+ "] Query is :->> [delete from VCC_PERSONALIZED_GREETING where MSISDN="
				+ msisdn + "]");
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "delete from VCC_PERSONALIZED_GREETING where MSISDN=?";
			int result = jdbcTemplate.update(query, new Object[] { msisdn });
			if (result > 0)
				return true;
			else
				return false;
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00033] MSISDN["
							+ msisdn
							+ "] [Exception while deleting user's greeting from VCC_PERSONALIZED_GREETING] Error["
							+ e.getMessage() + "]");
			logger.error("[" + greetingRequest.getCallingNum()
					+ "] db operation not perform in delteUserGreeting [" + e
					+ "]");
			return false;
		}

	}

	@Override
	public VccPersonalGreeting getUserGreeting(String msisdn) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		msisdn = commonOperation.msisdnWithCountryCode(msisdn);
		logger.debug("["
				+ msisdn
				+ "] Query is :->>> [select * from VCC_PERSONALIZED_GREETING where MSISDN = "
				+ msisdn + "]");

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "select * from VCC_PERSONALIZED_GREETING where MSISDN = ?";
			return jdbcTemplate.query(query, new Object[] { msisdn },
					new ResultSetExtractor<VccPersonalGreeting>() {
						@Override
						public VccPersonalGreeting extractData(ResultSet rs)
								throws SQLException, DataAccessException {
							if (rs.next()) {
								VccPersonalGreeting vcc = new VccPersonalGreeting();
								vcc.setMsisdn(rs.getString("MSISDN"));
								vcc.setFilePath(rs.getString("FILEPATH"));
								vcc.setGreetType(rs.getInt("GREET_TYPE"));
								vcc.setRecordingTime(rs
										.getInt("RECORDING_TIME"));
								return vcc;
							}
							return null;
						}
					});
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00034] MSISDN["
							+ msisdn
							+ "] [Exception while getting user's greeting from VCC_PERSONALIZED_GREETING] Error["
							+ e.getMessage() + "]");
			logger.error("[" + msisdn
					+ "] db operation not perform in getUserGreeting [" + e
					+ "]");
			return null;
		}
	}

	@Override
	public boolean updatePersonalGreeting(VccGreetingRequest greetingRequest) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		String msisdn = commonOperation.msisdnWithCountryCode(greetingRequest
				.getCallingNum());

		logger.debug("[" + msisdn
				+ "] Query is [update VCC_PERSONALIZED_GREETING SET FILEPATH="
				+ greetingRequest.getRecordFileName() + ",GREET_TYPE="
				+ greetingRequest.getGreetingType() + ",RECORDING_TIME="
				+ greetingRequest.getRecordingDuration() + " Where MSISDN="
				+ msisdn + "]");

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String query = "update VCC_PERSONALIZED_GREETING SET FILEPATH=?,GREET_TYPE=?,RECORDING_TIME=? Where MSISDN=?";
			int result = jdbcTemplate.update(
					query,
					new Object[] { greetingRequest.getRecordFileName(),
							greetingRequest.getGreetingType(),
							greetingRequest.getRecordingDuration(), msisdn });
			if (result > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00035] MSISDN["
							+ msisdn
							+ "] [Exception while updating user's greeting in VCC_PERSONALIZED_GREETING] Error["
							+ e.getMessage() + "]");
			logger.error("[" + msisdn
					+ "] db operation not perform in updatePersonalGreeting ["
					+ e + "]");
			return false;
		}
	}

	@Override
	public boolean updateGreetingType(int greetingType, String msisdn) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		msisdn = commonOperation.msisdnWithCountryCode(msisdn);

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

			String query = null;
			if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
				query = "update VCC_AUTH_USER_"+msisdn.charAt(msisdn.length()-1)+" set GREETING_TYPE=?  where MSISDN=?";
			} else {
				query = "update VCC_AUTH_USER set GREETING_TYPE=?  where MSISDN=?";
			}
			logger.debug("["+ msisdn+ "] Query is :->>> ["+query+"]");
			int result = jdbcTemplate.update(query, new Object[] {
					greetingType, msisdn });
			if (result > 0) {
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00036] MSISDN["
							+ msisdn
							+ "] [Exception while updating user's greeting type in VCC_PERSONALIZED_GREETING] Error["
							+ e.getMessage() + "]");
			logger.error("[" + msisdn
					+ "] db operation not perform in updateGreetingType [" + e
					+ "]");
			return false;
		}

	}

	@Override
	public boolean updateLastVisitTime(String msisdn) {
		VccCommonOperation commonOperation = new VccCommonOperation();
		msisdn = commonOperation.msisdnWithCountryCode(msisdn);

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

			String query = null;
			if (AppConfig.config.getString("db_type").equalsIgnoreCase("mysql")) {
				if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
					query = "update VCC_SUBSCRIPTION_MASTER_"+msisdn.charAt(msisdn.length()-1)+" set LAST_VISIT_TIME=now() where MSISDN=?";
				} else {
					query = "update VCC_SUBSCRIPTION_MASTER set LAST_VISIT_TIME=now() where MSISDN=?";
				}
				logger.debug("["+ msisdn+ "] Query is :->>> ["+query+"]");
			} else if (AppConfig.config.getString("db_type").equalsIgnoreCase("oracle")) {
				if(AppConfig.config.getInt("multi_table_sub_check", 0) == 1)  {
					query = "update VCC_SUBSCRIPTION_MASTER_"+msisdn.charAt(msisdn.length()-1)+" set LAST_VISIT_TIME=sysdate where MSISDN=?";
				} else {
					query = "update VCC_SUBSCRIPTION_MASTER set LAST_VISIT_TIME=sysdate where MSISDN=?";
				}
				logger.debug("["+ msisdn+ "] Query is :->>> ["+query+"]");
			}
			int result = jdbcTemplate.update(query, new Object[] { msisdn });
			if (result > 0) {
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "00037] MSISDN["
							+ msisdn
							+ "] [Exception while updating user's last visiting time in VCC_SUBSCRIPTION_MASTER] Error["
							+ e.getMessage() + "]");
			logger.error("[" + msisdn
					+ "] db operation not perform in updateLastVisitTime [" + e
					+ "]");
			return false;
		}

	}

	@Override
	public Boolean insertIntoVccTempSubscription(VnRequest vnRequest) {
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

			String query = null;
			logger.debug("Calling Num ["
					+ vnRequest.getCallingNum()
					+ "] CalledNum ["
					+ vnRequest.getCalledNum()
					+ "] Query is : - insert into VCC_VN_TEMP_SUBSCRIPTION (CALLING_NUM,CALLED_NUM,CALL_TIME,FILE_NAME,RECORDING_DURATION,SERVICE_TYPE,SENDING_TIME,LANGUAGE,CLASS_TYPE,SERVER_ID,CALL_ID,IAM_CAUSE_CODE,REL_CAUSE_CODE,MSG_LENGTH,ANSWERED,ORG_CNT_CODE,STATUS,RETRY_COUNT,CALL_DURATION,SILENCE_DETECT) "
					+ "values (" + vnRequest.getCallingNum() + ","
					+ vnRequest.getCalledNum() + "," + vnRequest.getCallTime()
					+ "," + vnRequest.getRecordFileName() + ","
					+ vnRequest.getRecordingDuration() + ","
					+ vnRequest.getServiceType() + ",now(),"
					+ vnRequest.getLang() + "," + vnRequest.getClassType()
					+ "," + vnRequest.getServerId() + ","
					+ vnRequest.getCallUUID() + ","
					+ vnRequest.getIamCauseCode() + ","
					+ vnRequest.getRelCauseCode() + ","
					+ vnRequest.getMsgLength() + "," + vnRequest.getAnswerd()
					+ "," + vnRequest.getOrgCntCode() + ","
					+ vnRequest.getStatus() + "," + vnRequest.getRetryCount()
					+ "," + vnRequest.getCallDuration() + ","
					+ vnRequest.getIsSilentDetect() + ")");
			query = "insert into VCC_VN_TEMP_SUBSCRIPTION (CALLING_NUM,CALLED_NUM,CALL_TIME,FILE_NAME,RECORDING_DURATION,SERVICE_TYPE,SENDING_TIME,LANGUAGE,CLASS_TYPE,SERVER_ID,CALL_ID,IAM_CAUSE_CODE,REL_CAUSE_CODE,MSG_LENGTH,ANSWERED,ORG_CNT_CODE,STATUS,RETRY_COUNT,CALL_DURATION,SILENCE_DETECT) "
					+ "values (?,?,?,?,?,?,now(),?,?,?,?,?,?,?,?,?,?,?,?,?)";

			jdbcTemplate.update(
					query,
					new Object[] { vnRequest.getCallingNum(),
							vnRequest.getCalledNum(), vnRequest.getCallTime(),
							vnRequest.getRecordFileName(),
							vnRequest.getRecordingDuration(),
							vnRequest.getServiceType(), vnRequest.getLang(),
							vnRequest.getClassType(), vnRequest.getServerId(),
							vnRequest.getCallUUID(),
							vnRequest.getIamCauseCode(),
							vnRequest.getRelCauseCode(),
							vnRequest.getMsgLength(), vnRequest.getAnswerd(),
							vnRequest.getOrgCntCode(), vnRequest.getStatus(),
							vnRequest.getRetryCount(),
							vnRequest.getCallDuration(),vnRequest.getIsSilentDetect() });
		} catch (Exception e) {
			errorLogger
					.error("callingNum ["+vnRequest.getCallingNum()+"] calledNum["+vnRequest.getCalledNum()+"] Exception while inserting data in VCC_VN_TEMP_SUBSCRIPTION"
							+ e.getMessage());
			e.printStackTrace();

			return false;
		}
		return true;

	}
}
