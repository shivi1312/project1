package com.vcc.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.handler.VccLogHandler;
import com.vcc.request.RetLogRequest;
import com.vcc.response.ProfileResponse;


@RestController
@RequestMapping("/")
public class VccLogsController {
	
	final static Logger logger = Logger.getLogger(VccLogsController.class);
	@Autowired
	VccServices vccServices;
	@RequestMapping(value="save.retlog",method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	ProfileResponse saveRetLog(RetLogRequest retLogRequest,
			BindingResult bindingResult, ProfileResponse profileResponse)
	{
		  VccLogHandler vccLogHandler = new VccLogHandler();
			logger.debug(" request is:  >>>>>>>"+ AppConfig.config.getString("save.retlog", "save.retlog"));
		vccLogHandler.process(retLogRequest, profileResponse, vccServices);
		vccLogHandler = null;
		//	profileResponse.setIsSuccess(1);
		return profileResponse;
	}

}
