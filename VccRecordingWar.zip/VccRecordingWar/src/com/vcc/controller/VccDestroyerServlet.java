package com.vcc.controller;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.vcc.cache.VccExpiryCache;
import com.vcc.domain.VccSendNotification;
import com.vcc.persistent.client.TcpClient;
import com.vcc.persistent.client.TcpConnectionUtil;

/**
 * Servlet implementation class VccDestroyerServlet
 */
public class VccDestroyerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(VccDestroyerServlet.class);

	public VccDestroyerServlet() {
		super();
	}

	public void init(ServletConfig config) throws ServletException {
		logger.info("<############ Init called #############>");
	}

	public void destroy() {
		logger.info("<<<<<<<<< Destroying TcpClient and ExpiryMap >>>>>>>>>");
		try {
			this.closeTcp();
			this.closeCache();
			//logger.info("<<<<<<<<< Destroyed Successfully >>>>>>>>>");
		} catch (Exception e) {
			logger.error("Exception while closing connection");

		}
	}

	protected void closeCache(){
		try{
			VccExpiryCache.sysmap.clear();
			VccExpiryCache.sysmap = null;
			VccExpiryCache.pxmlmap = null;
			VccExpiryCache.dbmap = null;
		}catch(Exception e){
			
		}
	}
	protected void closeTcp(){
		try{
			//TcpClient.close();
			TcpClient.closeConnectorSession();
		}catch(Exception e){
			
		}
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
