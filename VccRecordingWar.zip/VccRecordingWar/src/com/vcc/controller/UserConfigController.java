package com.vcc.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vcc.common.VccServiceFlag;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.handler.VccUserConfigHandler;
import com.vcc.request.UserConfigRequest;
import com.vcc.response.UserConfigResponse;

@RestController
@RequestMapping("/")
public class UserConfigController {

	final static Logger logger = Logger.getLogger(UserConfigController.class);
	@Autowired
	VccServices vccServices;

	@RequestMapping(value = "groupId.validation", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse groupIdValidation(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {

		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.debug(" request is:  >>>>>>> "
				+ AppConfig.config.getString("groupId.validation",
						"groupId.validation"));
		userConfigHandler.groupValidationProcess(userConfigRequest,
				bindingResult, userConfigResponse, vccServices);
		userConfigHandler = null;
		logger.info(String
				.format("A-Party [%s] isSuccess [%s] groupid [%s] recordFilename [%s] recordFilePath [%s] ",
						userConfigRequest.getCallingNum(),
						userConfigResponse.getIsSuccess(),
						userConfigResponse.getGroupId(),
						userConfigResponse.getRecordFileName(),
						userConfigResponse.getRecordFilePath()));
		return userConfigResponse;
	}

	@RequestMapping(value = "group.count", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse groupCount(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {

		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.debug("request is:  >>>>>>> "
				+ AppConfig.config.getString("group.count",
						"group.count"));
		userConfigHandler.groupCountProcess(userConfigRequest,
				bindingResult, userConfigResponse, vccServices);
		userConfigHandler = null;
	
		return userConfigResponse;
	}

	
	@RequestMapping(value = "check.groupId", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse groupIdCheck(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {

		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.debug("\n request is:  >>>>>>> "
				+ AppConfig.config.getString("check.groupId", "check.groupId"));
		userConfigHandler.groupIdCheck(userConfigRequest, bindingResult,
				userConfigResponse, vccServices);
		userConfigHandler = null;
		logger.info(String
				.format("A-Party [%s] isSuccess [%s] groupid [%s] recordFilename [%s] recordFilePath [%s] ",
						userConfigRequest.getCallingNum(),
						userConfigResponse.getIsSuccess(),
						userConfigResponse.getGroupId(),
						userConfigResponse.getRecordFileName(),
						userConfigResponse.getRecordFilePath()));
		return userConfigResponse;
	}

	@RequestMapping(value = "addtolist", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse addToListFrnd(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {
		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.debug(" request is:  >>>>>>> "
				+ AppConfig.config.getString("addtolist", "addtolist"));
		userConfigHandler.addListprocess(userConfigRequest, userConfigResponse,
				vccServices);
		userConfigHandler = null;
		logger.info(String.format(
				"A-Party [%s] isSubscriber [%s] frndCnt [%s]  ",
				userConfigRequest.getCallingNum(),
				userConfigResponse.getIsSubscriber(),
				userConfigResponse.getFrndCnt()));
		return userConfigResponse;
	}

	@RequestMapping(value = "addalltolist", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse addAllToList(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {
		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.debug(" request is:  >>>>>>> "
				+ AppConfig.config.getString("addalltolist",
						"addalltolist"));
		userConfigHandler.addAllprocess(userConfigRequest, userConfigResponse,
				vccServices);
		userConfigHandler = null;
		logger.info(String.format("A-Party [%s] isSuccess [%s]   ",
				userConfigRequest.getCallingNum(),
				userConfigResponse.getIsSuccess()));
		return userConfigResponse;
	}

	@RequestMapping(value = "grouplist.with.validation", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse groupList(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {
		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.debug(" request is:  >>>>>>> "
				+ AppConfig.config.getString("grouplist.with.validation",
						"grouplist.with.validation"));
		if(userConfigRequest.getInputCount()>=3)
		{
		
			userConfigResponse.setInputCount(userConfigRequest.getInputCount());
			userConfigResponse.setIsSuccess(-2);
		}else
		{	
			
		userConfigHandler.groupListProcess(userConfigRequest,
				userConfigResponse, bindingResult, vccServices);
		}
		userConfigHandler = null;
		logger.info(String.format(
				"A-Party [%s] isSuccess [%s] groupPath [%s] groupId [%s] ",
				userConfigRequest.getCallingNum(),
				userConfigResponse.getIsSuccess(),
				userConfigResponse.getgroupPath(),
				userConfigResponse.getGroupId()));
		return userConfigResponse;

	}

	@RequestMapping(value = "grouplist.details", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse groupListDetails(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {
		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.debug("request is:  >>>>>>> "
				+ AppConfig.config.getString("grouplist.details",
						"grouplist.details"));
		userConfigHandler.groupListDetails(userConfigRequest,
				userConfigResponse, bindingResult, vccServices);
		userConfigHandler = null;
		logger.info(String
				.format("A-Party [%s] isSuccess [%s] msisdnFilePath [%s] groupId [%s] ",
						userConfigRequest.getCallingNum(),
						userConfigResponse.getIsSuccess(),
						userConfigResponse.getMsisdnFilePath(),
						userConfigResponse.getGroupId()));
		return userConfigResponse;

	}

	@RequestMapping(value = "group.delete", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse groupDelete(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {
		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.debug(" request is:  >>>>>>> "
				+ AppConfig.config.getString("group.delete", "group.delete"));
		userConfigHandler.groupDeleteProcess(userConfigRequest,
				userConfigResponse, bindingResult, vccServices);
		userConfigHandler = null;
		logger.info(String.format("A-Party [%s] isSuccess [%s]  ",
				userConfigRequest.getCallingNum(),
				userConfigResponse.getIsSuccess()));
		return userConfigResponse;
	}

	@RequestMapping(value = "group.name.modify", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse groupModify(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {
		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.debug(" request is:  >>>>>>> "
				+ AppConfig.config.getString("group.name.modify",
						"group.name.modify"));
		userConfigHandler.groupModifyProcess(userConfigRequest,
				userConfigResponse, bindingResult, vccServices);
		userConfigHandler = null;
		logger.info(String.format("A-Party [%s] isSuccess [%s]  ",
				userConfigRequest.getCallingNum(),
				userConfigResponse.getIsSuccess()));
		return userConfigResponse;
	}

	@RequestMapping(value = "check.group.exists", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse checkGroup(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {
		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.debug(" request is:  >>>>>>> "
				+ AppConfig.config.getString("check.group.exists",
						"check.group.exists"));
		userConfigHandler.groupModifyProcess(userConfigRequest,
				userConfigResponse, bindingResult, vccServices);
		userConfigHandler = null;
		logger.info(String.format("A-Party [%s] isSuccess [%s]  ",
				userConfigRequest.getCallingNum(),
				userConfigResponse.getIsSuccess()));
		return userConfigResponse;
	}

	@RequestMapping(value = "msisdn.delete", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse deleteMsisdn(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {
		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.debug("request is:  >>>>>>> "
				+ AppConfig.config.getString("msisdn.delete",
						"msisdn.delete"));
		userConfigHandler.deleteMsisdnProcess(userConfigRequest,
				userConfigResponse, bindingResult, vccServices);
		userConfigHandler = null;
		logger.info(String.format("A-Party [%s] isSuccess [%s]  ",
				userConfigRequest.getCallingNum(),
				userConfigResponse.getIsSuccess()));
		return userConfigResponse;
	}

	@RequestMapping(value = "get.alternative.number", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse getNumber(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {
		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.debug(" request is:  >>>>>>> "
				+ AppConfig.config.getString("get.alternative.number",
						"get.alternative.number"));
		userConfigHandler.getAlternativeMsisdnProcess(userConfigRequest,
				userConfigResponse, bindingResult, vccServices);
		userConfigHandler = null;
		logger.info(String.format("A-Party [%s] isSuccess [%s]  ",
				userConfigRequest.getCallingNum(),
				userConfigResponse.getIsSuccess()));
		return userConfigResponse;
	}

	@RequestMapping(value = "add.alternative.number", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse addNumber(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {
		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.debug(" request is:  >>>>>>> "
				+ AppConfig.config.getString("add.alternative.number",
						"add.alternative.number"));
		userConfigHandler.addAlternativeMsisdnProcess(userConfigRequest,
				userConfigResponse, bindingResult, vccServices);
		userConfigHandler = null;
		logger.info(String.format("A-Party [%s] isSuccess [%s]  ",
				userConfigRequest.getCallingNum(),
				userConfigResponse.getIsSuccess()));
		return userConfigResponse;
	}

	@RequestMapping(value = "actDeact.notification.number", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse actDeactNotification(
			UserConfigRequest userConfigRequest, BindingResult bindingResult,
			UserConfigResponse userConfigResponse) {
		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.info("request is:  >>>>>>> "
				+ AppConfig.config.getString("actDeact.notification.number",
						"actDeact.notification.number"));
		userConfigHandler.actOrDctServiceFlagProcess(userConfigRequest,
				userConfigResponse, bindingResult, vccServices,
				VccServiceFlag.notification_enable_disable);

		userConfigHandler = null;
		logger.info(String.format("A-Party [%s] isSuccess [%s]  ",
				userConfigRequest.getCallingNum(),
				userConfigResponse.getIsSuccess()));
		return userConfigResponse;
	}

	@RequestMapping(value = "actDeact.alternative.number", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse actDeactAlternative(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {
		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.info(" request is:  >>>>>>> "
				+ AppConfig.config.getString("actDeact.alternative.number",
						"actDeact.alternative.number"));
		userConfigHandler.actOrDctServiceFlagProcess(userConfigRequest,
				userConfigResponse, bindingResult, vccServices,
				VccServiceFlag.alternative_msisdn_enable_disable);


		userConfigHandler = null;
		logger.info(String.format("A-Party [%s] isSuccess [%s]  ",
				userConfigRequest.getCallingNum(),
				userConfigResponse.getIsSuccess()));
		return userConfigResponse;
	}
	
	@RequestMapping(value = "actDeact.message.header", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UserConfigResponse actDeactMessageHeader(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse) {
		VccUserConfigHandler userConfigHandler = new VccUserConfigHandler();
		logger.info("request is:  >>>>>>> "
				+ AppConfig.config.getString("actDeact.message.header",
						"actDeact.message.header"));
		userConfigHandler.actOrDctServiceFlagProcess(userConfigRequest,
				userConfigResponse, bindingResult, vccServices,
				VccServiceFlag.message_header_enable_disable);


		userConfigHandler = null;
		logger.info(String.format("A-Party [%s] isSuccess [%s]  ",
				userConfigRequest.getCallingNum(),
				userConfigResponse.getIsSuccess()));
		return userConfigResponse;
	}

}
