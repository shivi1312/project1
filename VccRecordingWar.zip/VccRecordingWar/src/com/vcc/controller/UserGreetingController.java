package com.vcc.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.handler.VccGreetingHandler;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VccGreetingRequest;
import com.vcc.response.ProfileResponse;

@RestController
@RequestMapping("/")
public class UserGreetingController {
	
	final static Logger logger = Logger.getLogger(UserGreetingController.class);
	@Autowired
	VccServices vccServices;
	
	@RequestMapping(value = "greet.file.path", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	ProfileResponse getGreetingFilePath(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse) {
		VccGreetingHandler greetingHandler = new VccGreetingHandler();
		logger.debug("request is:  >>>>>>>"
				+ AppConfig.config.getString("greet.file.path",
						"greet.file.path"));
		greetingHandler.greetingFilePathProcess(profileRequest, bindingResult,
				profileResponse, vccServices);
		return profileResponse;
	}
	
	@RequestMapping(value = "save.greet", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	ProfileResponse saveGreeting(VccGreetingRequest greetingRequest,
			BindingResult bindingResult, ProfileResponse profileResponse) {
		VccGreetingHandler greetingHandler = new VccGreetingHandler();
		logger.debug(" request is:  >>>>>>>"
				+ AppConfig.config.getString("save.greet",
						"greet.file.path"));
		greetingHandler.saveGreetingProcess(greetingRequest, bindingResult,
				profileResponse, vccServices);
		return profileResponse;
	}
	
	@RequestMapping(value = "delete.greet", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	ProfileResponse deleteGreeting(VccGreetingRequest greetingRequest,
			BindingResult bindingResult, ProfileResponse profileResponse) {
		VccGreetingHandler greetingHandler = new VccGreetingHandler();
		logger.debug(" request is:  >>>>>>>"
				+ AppConfig.config.getString("delete.greet",
						"delete.greet"));
		greetingHandler.deleteGreetingProcess(greetingRequest, bindingResult,
				profileResponse, vccServices);
		return profileResponse;
	}
	
	

}
