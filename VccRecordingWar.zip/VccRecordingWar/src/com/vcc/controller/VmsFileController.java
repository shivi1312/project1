package com.vcc.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.domain.FsSaveHandler;
import com.vcc.handler.VmRecordHandler;
import com.vcc.handler.VmRecordWithHangUpHandler;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.response.VmResponse;

/*
 * Have actions for voice mail related informations
 * Save voice mail and Delete voice mail
 * */
@RestController
@RequestMapping("/")
public class VmsFileController {

	final static Logger logger = Logger.getLogger(VmsFileController.class);
	@Autowired
	private VccServices vccServices;

	@RequestMapping(value = "save.record", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody VmResponse saveRecord(VmRequest vmRequest,
			BindingResult bindingResult, VmResponse vmResponse) {
		VmRecordHandler vmHandler = new VmRecordHandler();
		logger.debug(" request is:  >>>>>>>"
				+ AppConfig.config.getString("save.record", "vm record save"));
		vmHandler.saveRecordProcess(vmRequest, bindingResult, vmResponse,
				vccServices);
		return vmResponse;
	}

	@RequestMapping(value = "cancel.record", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody VmResponse cancelRecord(VmRequest vmRequest,
			BindingResult bindingResult, VmResponse vmResponse) {
		VmRecordHandler vmHandler = new VmRecordHandler();
		vmHandler.cancelRecordProcess(vmRequest, bindingResult, vmResponse,
				vccServices);
		vmHandler = null;
		return vmResponse;
	}

	@RequestMapping(value = "save.hangup", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody VmResponse saveHangup(VmRequest vmRequest,
			BindingResult bindingResult, VmResponse vmResponse) {
		VmRecordWithHangUpHandler vmHandler = new VmRecordWithHangUpHandler();
		logger.debug(" request is:  >>>>>>>"
				+ AppConfig.config.getString("save.hangup",
						"vm save with hangup"));
		vmHandler.process(vmRequest, bindingResult, vmResponse, vccServices);
		return vmResponse;
	}

	@RequestMapping(value = "fs.save.hangup", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody VmResponse fsSaveHangup(VmRequest vmRequest,
			BindingResult bindingResult, VmResponse vmResponse) {
		FsSaveHandler vmHandler = new FsSaveHandler();
		logger.debug(" request is:  >>>>>>>"
				+ AppConfig.config.getString("fs.save.hangup",
						"vm save with hangup"));
		vmHandler.process(vmRequest, vmResponse, vccServices);
		vmHandler = null;
		return vmResponse;
	}

	@RequestMapping(value = "save.msg", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody VmResponse saveMsg(VmRequest vmRequest,
			BindingResult bindingResult, VmResponse vmResponse) {
		VmRecordHandler vmHandler = new VmRecordHandler();
		logger.info(" request is:  >>>>>>>"
				+ AppConfig.config.getString("save.msg", "save.msg"));
		vmHandler.saveMsgProcess(vmRequest, bindingResult, vmResponse,
				vccServices);
		vmHandler = null;
		return vmResponse;
	}

	@RequestMapping(value = "profile.check.reply", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody ProfileResponse checkProfileReply(
			ProfileRequest profileRequest, BindingResult bindingResult,
			ProfileResponse profileResponse) {
		VmRecordHandler vmHandler = new VmRecordHandler();
		logger.info(" request is:  >>>>>>>"
				+ AppConfig.config.getString("profile.check.reply",
						"profile.check.reply"));
		vmHandler.checkProfileRpy(profileRequest, bindingResult,
				profileResponse, vccServices);
		vmHandler = null;
		return profileResponse;
	}

	@RequestMapping(value = "save.record.reply", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody VmResponse scheduleSaveMsg(VmRequest vmRequest,
			BindingResult bindingResult, VmResponse vmResponse) {
		VmRecordHandler vmHandler = new VmRecordHandler();
		logger.info(" request is:  >>>>>>>"
				+ AppConfig.config.getString("save.record.reply",
						"save.record.reply"));
		vmHandler.saveRpyMsg(vmRequest, bindingResult, vmResponse, vccServices);
		vmHandler = null;
		return vmResponse;
	}

	@RequestMapping(value = "save.vm.wih.scheduling", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody VmResponse saveReplyMsg(VmRequest vmRequest,
			BindingResult bindingResult, VmResponse vmResponse) {
		VmRecordHandler vmHandler = new VmRecordHandler();
		logger.info(" request is:  >>>>>>>"
				+ AppConfig.config.getString("save.vm.wih.scheduling",
						"save.vm.wih.scheduling"));
		vmHandler.scheduleVoiceMail(vmRequest, bindingResult, vmResponse,
				vccServices);
		vmHandler = null;
		return vmResponse;
	}

}
