package com.vcc.common;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.PhoneNumberUtil.PhoneNumberFormat;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;
import com.vcc.cache.VccExpiryCache;
import com.vcc.config.AppConfig;
import com.vcc.model.VccFwdCallLogs;
import com.vcc.model.VccSeries;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.VmResponse;

public class VccCommonOperation {
	final static Logger logger = Logger.getLogger(VccCommonOperation.class);
	final static Logger delLogger = Logger.getLogger("deleteLogger");
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	public VccCommonOperation() {

	}

	/**
	 * This method does not return any response. Its only add/remove the country
	 * code in callingNum and calledNum
	 * 
	 * @param vmRequest
	 *            the vmRequest is a bean to contain user info.like callingNum
	 *            ,calledNum,lang,ratePlan etc
	 * @return void return by this method
	 * @see nothing
	 */
	public void addAndRemoveCountryCode(VmRequest vmRequest) {
		String callingNumWithoutCountryCode = vmRequest.getCallingNum();
		String calledNumWithoutCountryCode = vmRequest.getCalledNum();

		String specialCountryCode = AppConfig.config.getString("country_special_code");
		logger.debug(" msisdn convert in international msisdn counrty code is [" + specialCountryCode + "] ");

		vmRequest.setCallingNum(convertToInternationalNumber(callingNumWithoutCountryCode, specialCountryCode));
		vmRequest.setCalledNum(convertToInternationalNumber(calledNumWithoutCountryCode, specialCountryCode));
		vmRequest.setCallingNumWithoutCountryCode(
				convertToNationalNumber(callingNumWithoutCountryCode, specialCountryCode));
		vmRequest.setCalledNumWithoutCountryCode(
				convertToNationalNumber(calledNumWithoutCountryCode, specialCountryCode));

		/*
		 * String countryCode = AppConfig.config.getString("country_code"); if
		 * (vmRequest.getCallingNum().startsWith(countryCode)) {
		 * 
		 * callingNumWithoutCountryCode = callingNumWithoutCountryCode
		 * .substring(countryCode.length(),
		 * callingNumWithoutCountryCode.length()); vmRequest
		 * .setCallingNumWithoutCountryCode(callingNumWithoutCountryCode); }
		 * else { StringBuilder callingNum = new StringBuilder();
		 * callingNum.append(AppConfig.config.getString("country_code"));
		 * if(vmRequest.getCallingNum().startsWith("0")) {
		 * callingNum.append(vmRequest
		 * .getCallingNum().substring(1,vmRequest.getCallingNum().length()));
		 * }else if(vmRequest.getCallingNum().startsWith("00")){
		 * callingNum.append
		 * (vmRequest.getCallingNum().substring(2,vmRequest.getCallingNum
		 * ().length())); }else { callingNum.append(vmRequest.getCallingNum());
		 * } vmRequest
		 * .setCallingNumWithoutCountryCode(vmRequest.getCallingNum());
		 * vmRequest.setCallingNum(callingNum.toString());
		 * 
		 * }
		 * 
		 * if (vmRequest.getCalledNum().startsWith(countryCode)) {
		 * calledNumWithoutCountryCode = calledNumWithoutCountryCode
		 * .substring(countryCode.length(),
		 * calledNumWithoutCountryCode.length()); vmRequest
		 * .setCalledNumWithoutCountryCode(calledNumWithoutCountryCode); } else
		 * {
		 * 
		 * StringBuilder calledNum = new StringBuilder();
		 * calledNum.append(AppConfig.config.getStrin g("country_code"));
		 * if(vmRequest.getCalledNum().startsWith("0")) {
		 * calledNum.append(vmRequest
		 * .getCalledNum().substring(1,vmRequest.getCalledNum().length()));
		 * }else if(vmRequest.getCalledNum().startsWith("00")){
		 * calledNum.append(
		 * vmRequest.getCalledNum().substring(2,vmRequest.getCalledNum
		 * ().length())); }else { calledNum.append(vmRequest.getCalledNum()); }
		 * 
		 * 
		 * vmRequest.setCalledNumWithoutCountryCode(vmRequest.getCalledNum());
		 * vmRequest.setCalledNum(calledNum.toString());
		 * 
		 * 
		 * }
		 */
	}

	/**
	 * return the wav file path for playing prompt voice mail record date
	 * converted into filepath
	 * 
	 * @param date
	 *            the voice mail record date
	 * @param lang
	 *            the lang contain the multiple language option for playing date
	 * @return filepath the location of prompt
	 * @see prompts file location
	 */
	public String convertDateToPath(String date, int lang) {
		StringBuilder filepath = new StringBuilder();
		String commonBashPath = AppConfig.config.getString("ivr_common_path");
		Date date1 = null;
		DateFormat srcDf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String am_pm = "AM";
		try {
			date1 = srcDf.parse(date);

		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00001] [Exception in Parsing Date While converting Date to Path] Error[" + e.getMessage() + "]");
			return null;
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date1);
		if (cal.get(Calendar.AM_PM) == 0) {
			am_pm = "AM";
		} else {
			am_pm = "PM";
		}

		logger.info("Date[" + date + "] convert to file path");

		int year = Integer.parseInt(getDateInFormat("yyyy").format(date1));
		int day = Integer.parseInt(getDateInFormat("dd").format(date1));
		int month = Integer.parseInt(getDateInFormat("MM").format(date1));
		int hh = Integer.parseInt(getDateInFormat("hh").format(date1));
		int HH = Integer.parseInt(getDateInFormat("HH").format(date1));
		int mm = Integer.parseInt(getDateInFormat("mm").format(date1));

		logger.info("Date[" + date + "] convert to file path year [" + year + "] month [" + month + "] day[" + day
				+ "] hour in hh [" + hh + "]  hour in HH [" + HH + "] mm [" + mm + "] AM_PM [" + am_pm + "]");

		filepath.append(commonBashPath + File.separator + lang + File.separator + "ON_DATE.wav");
		filepath.append(",");
		filepath.append(
				commonBashPath + File.separator + "DIGITS" + File.separator + lang + File.separator + day + ".wav");
		filepath.append(",");
		filepath.append(
				commonBashPath + File.separator + "MONTH" + File.separator + lang + File.separator + month + ".wav");
		filepath.append(",");
		filepath.append(
				commonBashPath + File.separator + "YEAR" + File.separator + lang + File.separator + year + ".wav");
		filepath.append(",");
		filepath.append(commonBashPath + File.separator + lang + File.separator + "AT_TIME.wav");
		filepath.append(",");

		if (AppConfig.config.getString("message_header_play_format", "AM_PM").equals("AM_PM")) {
			filepath.append(
					commonBashPath + File.separator + "DIGITS" + File.separator + lang + File.separator + hh + ".wav");
			filepath.append(",");
			filepath.append(commonBashPath + File.separator + lang + File.separator + am_pm + ".wav");
		} else {
			filepath.append(
					commonBashPath + File.separator + "DIGITS" + File.separator + lang + File.separator + HH + ".wav");
			filepath.append(",");
			filepath.append(commonBashPath + File.separator + lang + File.separator + "HOUR.wav");
		}
		filepath.append(",");
		filepath.append(
				commonBashPath + File.separator + "DIGITS" + File.separator + lang + File.separator + mm + ".wav");
		filepath.append(",");
		filepath.append(commonBashPath + File.separator + lang + File.separator + "MINUTE.wav");

		logger.debug("file path [" + filepath.toString() + "]");
		return filepath.toString();

	}

	/**
	 * This method does not return any response. Its only add/remove the country
	 * code in callingNum and calledNum
	 * 
	 * @param profileRequest
	 *            the vmRequest is a bean to contain user info.like callingNum
	 *            ,calledNum,lang,ratePlan etc
	 * @return void return by this method
	 * @see nothing
	 */
	public void addAndRemoveCountryCode(ProfileRequest profileRequest) {

		String callingNumWithoutCountryCode = profileRequest.getCallingNum();
		String calledNumWithoutCountryCode = profileRequest.getCalledNum();

		String specialCountryCode = AppConfig.config.getString("country_special_code");

		profileRequest.setCallingNum(convertToInternationalNumber(callingNumWithoutCountryCode, specialCountryCode));
		profileRequest.setCalledNum(convertToInternationalNumber(calledNumWithoutCountryCode, specialCountryCode));
		profileRequest.setCallingNumWithoutCountryCode(
				convertToNationalNumber(callingNumWithoutCountryCode, specialCountryCode));
		profileRequest.setCalledNumWithoutCountryCode(
				convertToNationalNumber(calledNumWithoutCountryCode, specialCountryCode));

		/*
		 * String countryCode = AppConfig.config.getString("country_code"); if
		 * (profileRequest.getCallingNum().startsWith(countryCode)) {
		 * 
		 * callingNumWithoutCountryCode = callingNumWithoutCountryCode
		 * .substring(countryCode.length(),
		 * callingNumWithoutCountryCode.length()); profileRequest
		 * .setCallingNumWithoutCountryCode(callingNumWithoutCountryCode); }
		 * else { StringBuilder callingNum = new StringBuilder();
		 * callingNum.append(AppConfig.config.getString("country_code"));
		 * callingNum.append(profileRequest.getCallingNum());
		 * profileRequest.setCallingNumWithoutCountryCode(profileRequest
		 * .getCallingNum());
		 * profileRequest.setCallingNum(callingNum.toString());
		 * 
		 * }
		 * 
		 * if (profileRequest.getCalledNum().startsWith(countryCode)) {
		 * calledNumWithoutCountryCode = calledNumWithoutCountryCode
		 * .substring(countryCode.length(),
		 * calledNumWithoutCountryCode.length()); profileRequest
		 * .setCalledNumWithoutCountryCode(calledNumWithoutCountryCode); } else
		 * {
		 * 
		 * StringBuilder calledNum = new StringBuilder();
		 * calledNum.append(AppConfig.config.getString("country_code"));
		 * calledNum.append(profileRequest.getCalledNum());
		 * profileRequest.setCalledNumWithoutCountryCode(profileRequest
		 * .getCalledNum()); profileRequest.setCalledNum(calledNum.toString());
		 * 
		 * }
		 */
	}

	/**
	 * return the msisdn with country code
	 * 
	 * @param msisdn
	 *            the msisdn which does not start with country code
	 * @return msisdnNum the no. with country code
	 * @see country code with msisdn
	 */
	public String msisdnWithCountryCode(String msisdn) {

		String countryCode = AppConfig.config.getString("country_special_code");
		return convertToInternationalNumber(msisdn, countryCode);

	}

	/**
	 * return the msisdn without country code
	 * 
	 * @param msisdn
	 *            the msisdn which start with country code
	 * @return msisdnNum the no. without country code
	 * @see msisdn without country code
	 */
	public String msisdnWithoutCountryCode(String msisdn) {

		String countryCode = AppConfig.config.getString("country_special_code");
		return convertToNationalNumber(msisdn, countryCode);

		/*
		 * String countryCode = AppConfig.config.getString("country_code"); if
		 * (msisdn.startsWith(countryCode)) { return
		 * msisdn.substring(countryCode.length(), msisdn.length());
		 * 
		 * } else { return msisdn; }
		 */
	}

	/**
	 * return the filepath of voice mail (user voice which is send by AParty)
	 * 
	 * @param startSixDigits
	 *            the variable contain starting 6 digits of record file name for
	 *            parsing the file location of voice mail
	 * @param calledNum
	 *            the msisdn of Bparty
	 * @param recordFileName
	 *            file name of voice mail
	 * @param basePath
	 *            the variable contain bash path of recorded mail
	 * @return filepathBuilder the location of voice mail
	 * @see voice mail physical location in filepath
	 */
	public String getCopletePath2(String startEightDigits, String calledNum, String recordFileName, String basePath) {
		calledNum = this.msisdnWithoutCountryCode(calledNum);
		/*
		 * Added by Vivek Kumar at 20/4/2016 To handle fixed line for file path:
		 * add 0 prefix
		 */
		int msisdnLength = AppConfig.config.getInt("msisdn_length");
		logger.debug(String.format("[%s] length with country code [%s]", calledNum, msisdnLength));
		if (calledNum.length() < msisdnLength) {
			logger.info(
					String.format("Handle fixed line: [%s] length with country code [%s]", calledNum, msisdnLength));
			calledNum = "0" + calledNum;
			logger.info(String.format("fixed line msisdn after handling: [%s]", calledNum));
		}

		StringBuilder filepathBuilder = new StringBuilder();
		filepathBuilder.append(startEightDigits.substring(0, startEightDigits.length() - 6));
		filepathBuilder.append("/");
		filepathBuilder
				.append(startEightDigits.substring(startEightDigits.length() - 6, startEightDigits.length() - 4));
		filepathBuilder.append("/");
		filepathBuilder
				.append(startEightDigits.substring(startEightDigits.length() - 4, startEightDigits.length() - 2));
		filepathBuilder.append("/");
		filepathBuilder.append(startEightDigits.substring(startEightDigits.length() - 2, startEightDigits.length()));

		logger.debug("file path [" + filepathBuilder.toString() + "]");

		try {
			DateFormat srcDf = new SimpleDateFormat("yy/MM/dd/HH");
			String myDate = String.valueOf(filepathBuilder);
			Date date = srcDf.parse(myDate);
			DateFormat destDf = new SimpleDateFormat("yyyy/MM/dd/HH");
			myDate = destDf.format(date);
			myDate = myDate.replace("/", File.separator);
			filepathBuilder = new StringBuilder();
			filepathBuilder.append(basePath);
			filepathBuilder.append(File.separator);
			filepathBuilder.append(myDate);
			filepathBuilder.append(File.separator);
			filepathBuilder.append(calledNum.substring(0, 3));
			filepathBuilder.append(File.separator);
			filepathBuilder.append(calledNum.substring(3, 6));
			filepathBuilder.append(File.separator);
			filepathBuilder.append(calledNum.substring(6, 9));
			filepathBuilder.append(File.separator);
			if (recordFileName != null) {
				filepathBuilder.append(recordFileName);
				filepathBuilder.append(".wav");
			}

		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00002] [Exception in getting Record File Path] Error[" + e.getMessage() + "]");

			return null;
		}

		return filepathBuilder.toString();
	}

	/**
	 * return the filepath of voice mail (user voice which is send by AParty)
	 * 
	 * @param startSixDigits
	 *            the variable contain starting 6 digits of record file name for
	 *            parsing the file location of voice mail
	 * @param calledNum
	 *            the msisdn of Bparty
	 * @param recordFileName
	 *            file name of voice mail
	 * @param basePath
	 *            the variable contain bash path of recorded mail
	 * @return filepathBuilder the location of voice mail
	 * @see voice mail physical location in filepath
	 */
	public String getCopletePath(String startEightDigits, String calledNum, String recordFileName, String basePath) {
		calledNum = this.msisdnWithoutCountryCode(calledNum);
		/*
		 * Added by Vivek Kumar at 20/4/2016 To handle fixed line for file path:
		 * add 0 prefix
		 */
		int msisdnLength = AppConfig.config.getInt("msisdn_length", 10);

		logger.debug(String.format("[%s] length with country code [%s]", calledNum, msisdnLength));
		if (calledNum.length() < msisdnLength) {
			logger.info(
					String.format("Handle fixed line: [%s] length with country code [%s]", calledNum, msisdnLength));
			calledNum = "0" + calledNum;
			logger.info(String.format("fixed line msisdn after handling: [%s]", calledNum));
		}

		String dir_format = AppConfig.config.getString("dir_format", "yy/MM/dd/HH/N3/N2/N7");

		String date_dir_format = dir_format.substring(0, dir_format.indexOf("N") - 1);

		String msisdn_dir_format = this.msisdnFormator(dir_format, calledNum);

		logger.debug("Date dir [" + date_dir_format + "] msisdn dir [" + msisdn_dir_format + "]");

		StringBuilder filepathBuilder = new StringBuilder();
		filepathBuilder.append(startEightDigits.substring(0, startEightDigits.length() - 6));
		filepathBuilder.append("/");
		filepathBuilder
				.append(startEightDigits.substring(startEightDigits.length() - 6, startEightDigits.length() - 4));
		filepathBuilder.append("/");
		filepathBuilder
				.append(startEightDigits.substring(startEightDigits.length() - 4, startEightDigits.length() - 2));
		filepathBuilder.append("/");
		filepathBuilder.append(startEightDigits.substring(startEightDigits.length() - 2, startEightDigits.length()));

		logger.debug("file path [" + filepathBuilder.toString() + "]");

		try {

			DateFormat srcDf = new SimpleDateFormat(date_dir_format);
			String myDate = String.valueOf(filepathBuilder);
			Date date = srcDf.parse(myDate);
			DateFormat destDf = new SimpleDateFormat("yy" + date_dir_format);
			myDate = destDf.format(date);
			myDate = myDate.replace("/", File.separator);

			filepathBuilder = new StringBuilder();
			filepathBuilder.append(basePath);

			filepathBuilder.append(File.separator);
			filepathBuilder.append(myDate);

			filepathBuilder.append(File.separator);
			filepathBuilder.append(msisdn_dir_format.replace("/", File.separator));
			filepathBuilder.append(File.separator);

			if (recordFileName != null) {

				filepathBuilder.append(recordFileName);
				filepathBuilder.append(".wav");
			}

		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00002] [Exception in getting Complete RecordFilePath] Error[" + e.getMessage() + "]");
			return null;
		}

		return filepathBuilder.toString();
	}

	public String getCompleteTempPath(String basePath, String recordFileName) {

		StringBuilder tempFileBuilder = new StringBuilder();
		try {
			String temp_dir_format = AppConfig.config.getString("temp_dir_format","");
			Date date = new Date();
			DateFormat dateFormat = new SimpleDateFormat(temp_dir_format);
			String formattedDate = dateFormat.format(date);

			tempFileBuilder.append(basePath);
			tempFileBuilder.append(File.separator);
			tempFileBuilder.append(formattedDate);
			tempFileBuilder.append(File.separator);

			if (recordFileName != null) {
				tempFileBuilder.append(recordFileName);
				tempFileBuilder.append(".wav");
			}
		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00002] [Exception in creating temporary RecordFilePath] Error[" + e.getMessage() + "]");
			return null;
		}
		return tempFileBuilder.toString();
	}

	public String msisdnFormator(String format, String msisdn) {
		String[] dir_format_array = format.substring(format.indexOf("N"), format.length()).split("/");
		String msisdn_dir_format = "";
		int start = 0;
		int d = 0;
		try {
			for (String dg : dir_format_array) {
				d = Integer.parseInt(dg.substring(1, dg.length()));
				if (msisdn.length() >= d + start)
					msisdn_dir_format = msisdn_dir_format + msisdn.substring(start, d + start) + "/";
				else
					msisdn_dir_format = msisdn_dir_format + msisdn.substring(start, msisdn.length()) + "/";
				start += d;
			}
			logger.debug("new: " + format.substring(0, format.indexOf("N")) + msisdn_dir_format);
		} catch (ArrayIndexOutOfBoundsException e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "90007] MSISDN[" + msisdn
					+ "] [Array Index Out of Bound Exception while formatting msisdn in directory Format] Error["
					+ e.getMessage() + "]");
		} catch (NullPointerException npe) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "90003] MSISDN[" + msisdn
					+ "] [Null Pointer Exception Exception while formatting msisdn in directory Format] Error["
					+ npe.getMessage() + "]");
		}
		return msisdn_dir_format;
	}

	/**
	 * return filepath of user input digits the location of digits parse in
	 * filepath for playing prompts
	 * 
	 * @param digits
	 *            the digits are enter by user
	 * @param lang
	 *            the lang variable used to play prompt in multiple language
	 * @return sb the file path prompts
	 * @see filepath
	 */
	public String userInputParse(String digits, int lang) {
		StringBuilder sb = new StringBuilder();
		String ivrBashPath = AppConfig.config.getString("ivr_digits_path");
		for (char digit : digits.toCharArray()) {
			if (sb.length() > 0)
				sb.append(",");
			sb.append(ivrBashPath);
			sb.append(File.separator);
			sb.append(lang);
			sb.append(File.separator);
			sb.append(AppConfig.config.getString("file.path-" + digit));
		}

		return sb.toString();
	}

	/**
	 * return Boolean value for delete Status of filepath delete any file path
	 * which contain some prompts (voice mail)
	 * 
	 * @param recordingFileNameconvertToInternationalNumber
	 *            the voice mail file name
	 * @param msisdn
	 *            the user msisdn (BParty)
	 * @return true/false return status ofconvertToInternationalNumber delete
	 *         file
	 * @see status
	 */
	public Boolean deletePhysicalFile(String recordingFileName, String msisdn, String completePath, String bashPath) {

		msisdn = this.msisdnWithoutCountryCode(msisdn);
		String recordFilePath = null;
		String tempName = null;
		String calledNum = null;
		if (completePath != null && completePath != "") {
			recordFilePath = completePath;
		} else {

			tempName = recordingFileName.substring(0,
					recordingFileName.length() - AppConfig.config.getInt("default_record_digits", 10));
			calledNum = msisdn;

			recordFilePath = this.getCopletePath(tempName, calledNum, recordingFileName, bashPath);
			logger.info("record file path [" + recordFilePath + "]");
		}

		if (AppConfig.config.getBoolean("VM_DELETE_PHYSICALLY", false)) {
			try {

				File file = new File(recordFilePath);
				if (file.exists()) {
					logger.info("delete file is [" + recordFilePath + "]");
					file.delete();
				} else {
					logger.info(" file not exists [" + recordFilePath + "]");
					errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
							+ "00003] [Recorded File not exist So Unable to delete physical recorded file]");
				}
			} catch (Exception e) {
				errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
						+ "00004] [Exception while deleting physical recorded file [" + recordFilePath + "]]");
				e.printStackTrace();
				return false;
			}
		} else {
			delLogger.info(recordFilePath);
			return true;
		}
		return true;

	}

	/**
	 * return Boolean value for copy Status of filepath copy any file path to
	 * another file path which contain some prompts (voice mail)
	 * 
	 * @param sourcefilePath
	 *            the location of prompt (voice mail) to be copy
	 * @param destFilePath
	 *            the location of destination where prompts copy
	 * @return true/false return status of copy file
	 * @see status
	 */

	

	public Boolean copyRecordFile(String sourcefilePath, String destFilePath) {

		try {
			File source = new File(sourcefilePath);
			File dest = new File(destFilePath);
			if(AppConfig.config.getBoolean("copy_temp_file",true)){
				FileUtils.copyFile(source, dest);
				//	dest.setExecutable(true, false);
				//	dest.setReadable(true, false);
				//	dest.setWritable(true, false);
				return true;
			}else{
				logger.info("Copying temp file is disabled So Temp File"+sourcefilePath+" is not copied to actual path "+destFilePath+"");
				return true;
			}
		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00007] [Exception while copying source filepath to another filepath] Error[" + e.getMessage()
					+ "]");
			logger.error("FIle not copy source file [" + sourcefilePath + "] to [" + destFilePath + "]");
			return false;
		}
		/*
		 * File sourceLoc = null;
		 * 
		 * File destLoc = null; try { sourceLoc = new File(sourcefilePath);
		 * destLoc = new File(destFilePath); if (!sourceLoc.exists()) {
		 * errorLogger .error("ErrorCode [" + AppConfig.config.getString(
		 * "errorcode_pattern", "VCC-IVRWAR-") +
		 * "00005] [Source FilePath not Exists while copying to another FilePath]"
		 * ); logger.error("Source [" + sourcefilePath + "] File path not exits"
		 * ); return false;
		 * 
		 * } if (AppConfig.config.getBoolean("file_write_executable", false)) {
		 * sourceLoc.setExecutable(true, false); sourceLoc.setReadable(true,
		 * false); sourceLoc.setWritable(true, false); if
		 * (sourceLoc.canExecute()) { if (!destLoc.exists()) {
		 * destLoc.setExecutable(true, false); destLoc.setReadable(true, false);
		 * destLoc.setWritable(true, false); FileUtils.copyFile(sourceLoc,
		 * destLoc); logger.info("FIle  copy source file [" + sourcefilePath +
		 * "] to [" + destFilePath + "]");
		 * 
		 * return true; } } else { errorLogger .error("ErrorCode [" +
		 * AppConfig.config.getString( "errorcode_pattern", "VCC-IVRWAR-") +
		 * "00006] [File not copy from source file [" + sourcefilePath +
		 * "] to [" + destFilePath +
		 * "] because source location not executable and readable]"); return
		 * false; } } else { if (!destLoc.exists()) {
		 * FileUtils.copyFile(sourceLoc, destLoc); logger.info(
		 * "FIle  copy source file [" + sourcefilePath + "] to [" + destFilePath
		 * + "]");
		 * 
		 * return true; } else { FileUtils.copyFile(sourceLoc, destLoc);
		 * logger.info("FIle  copy source file [" + sourcefilePath + "] to [" +
		 * destFilePath + "] because file already Exists"); return true; } }
		 * 
		 * } catch (Exception e) { errorLogger .error("ErrorCode [" +
		 * AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-") +
		 * "00007] [Exception while copying source filepath to another filepath] Error["
		 * + e.getMessage() + "]"); logger.error("FIle not copy source file [" +
		 * sourcefilePath + "] to [" + destFilePath + "]"); return false;
		 * 
		 * } finally { if (sourceLoc != null || destLoc != null) { try {
		 * sourceLoc = null; destLoc = null; } catch (Exception ex) {
		 * 
		 * } }
		 * 
		 * }
		 */
	}

	/**
	 * return the file path of msisdn(for playing user msisdn) convert msisdn to
	 * file path for playing user msisdn
	 * 
	 * @param msisdn
	 *            the user msisdn
	 * @param lang
	 *            the variable used to play prompts in multiple language
	 * @return filepath the method return filepath (msisdn)
	 * @see filepath
	 */
	public String getMsisdnPath(String msisdn, int lang) {
		msisdn = this.msisdnWithoutCountryCode(msisdn);
		StringBuilder filepath = new StringBuilder();
		String ivrBashPath = AppConfig.config.getString("ivr_digits_path");
		filepath.append(ivrBashPath);
		filepath.append(File.separator);
		filepath.append(lang);
		filepath.append(File.separator);
		filepath.append(AppConfig.config.getString("file.path-" + 0));
		// filepath.append(",");
		for (char digit : msisdn.toCharArray()) {
			if (filepath.length() > 0)
				filepath.append(",");
			filepath.append(ivrBashPath);
			filepath.append(File.separator);
			filepath.append(lang);
			filepath.append(File.separator);
			filepath.append(AppConfig.config.getString("file.path-" + digit));

		}
		return filepath.toString();
	}

	/**
	 * return true if file path location is exists otherwise return false
	 * 
	 * @param recordFilepath
	 *            the physical location of voice mail
	 * @return status the method return true or false
	 * @see status
	 */
	public Boolean checkFileExists(String recordFilepath) {
		File file = new File(recordFilepath);
		try {
			if (file.exists())
				return true;
			else
				return false;

		} catch (SecurityException ex) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "90014] [Security Exception while checking file existance] Error[" + ex.getMessage() + "]");
			return false;
		} catch (Exception e) {
			return false;
		} finally {
			file = null;
		}
	}

	/**
	 * return true if valid date input by user otherwise return false
	 * 
	 * @param date
	 *            this value input by user
	 * @return status the method return true or false
	 * @see status
	 */
	public boolean isValidDate(String date) {
		String datePattern = AppConfig.config.getString("vm_schedule_datetime_format");
		logger.info("date parttern [" + datePattern + "] and  Date is [" + date + "]");
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(datePattern);
		simpleDateFormat.setLenient(false);
		try {
			simpleDateFormat.parse(date.trim());
		} catch (ParseException pe) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00001] [Exception in parsing date while checking valid date] Error[" + pe.getMessage() + "]");
			logger.info("date pattern [" + datePattern + "] and  Date  [" + date + "] are not match");
			return false;
		}
		return true;

	}

	/**
	 * return true if user input date >= current date otherwise return false
	 * 
	 * @param date
	 *            this value input by user
	 * @return status the method return true or false
	 * @see status
	 */
	public boolean isDateAfterCurrentDate(String date) {
		String datePattern = AppConfig.config.getString("vm_schedule_datetime_format");
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(datePattern);
		try {
			Date schlDate = simpleDateFormat.parse(date);
			Calendar calendar = Calendar.getInstance();
			if (schlDate.before(calendar.getTime())) {
				logger.info(" Input  Date  [" + date + "] is less than current date [" + new Date() + "]");
				return false;
			} else {
				logger.info(" Input  Date  [" + date + "] is greater  than current date ");
				return true;
			}
		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00008] [Exception while comparing input date with current date] Error[" + e.getMessage() + "]");
			logger.info(" Input  Date  [" + date + "] is invalid ");
			return false;
		}

	}

	/**
	 * return change date format in yyyy-MM-dd HH:mm:ss change date format
	 * scheduleDate to system specific format
	 * 
	 * @param scheduleDate
	 *            this value input by user
	 * @return destDate the method return converted date
	 * @see date
	 */
	public String parseDate(String scheduleDate) {
		try {
			DateFormat srcDf = new SimpleDateFormat(AppConfig.config.getString("vm_schedule_datetime_format"));

			Date date = srcDf.parse(scheduleDate);

			DateFormat destDf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String destDate = destDf.format(date);

			return destDate;
		} catch (ParseException e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00001] [Exception in parsing scheduledate format to system specific format] Error["
					+ e.getMessage() + "]");
			return null;

		}

	}

	/**
	 * return record file name voice mail record file name set for each
	 * recording
	 * 
	 * @return recordFileName the method return filename of mail
	 * @see file name
	 */
	public String getRecordFileName() {
		String recordFileName = null;
		Date date = new Date();
		try {
			String nanoSec = String.valueOf(System.nanoTime());
			nanoSec = (String) nanoSec.subSequence(nanoSec.length() - 6, nanoSec.length());
			recordFileName = getDateInFormat("yy").format(date) + getDateInFormat("MM").format(date)
					+ getDateInFormat("dd").format(date) + getDateInFormat("HH").format(date)
					+ getDateInFormat("mm").format(date) + getDateInFormat("ss").format(date) + nanoSec;
		} catch (IndexOutOfBoundsException ex) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "90015] [IndexOutOfBoundsException while getting Record filename ] Error[" + ex.getMessage()
					+ "]");
		}
		return recordFileName;
	}

	/**
	 * return complete voice mail record file path
	 * 
	 * @param msisdn
	 *            the user msisdn
	 * @param msisdn
	 *            the user recordFileName
	 * @param bashPath
	 *            the variable contains bash path of record location
	 * @return recordFilePath the method return complete file path of voice mail
	 * @see filepath
	 */
	public String getRecordFilePath(String msisdn, String recordFileName, String bashPath) {
		msisdn = this.msisdnWithoutCountryCode(msisdn);
		String tempName = recordFileName.substring(0,
				recordFileName.length() - AppConfig.config.getInt("default_record_digits", 10));
		String recordFilePath = this.getCopletePath(tempName, msisdn, null, bashPath);
		Boolean status = false;
		if (AppConfig.config.getBoolean("nio_used", false)) {
			status = this.createNioDirectory(recordFilePath);
		} else {
			status = this.createDirectory(recordFilePath);
		}
		if (status)
			return recordFilePath;
		else
			return null;
	}

	/**
	 * return true if service flag on for particular services check particular
	 * flag for service in String
	 * 
	 * @param serviceFlag
	 *            the variable contain info of services which active /inactive
	 *            for particular msisdn
	 * @param position
	 *            the position variable contains index of service
	 * @return status true / false
	 * @see status
	 */
	public Boolean checkServiceFlag(String serviceFlag, int position) {
		if (serviceFlag != null) {
			char[] sflag = serviceFlag.toCharArray();

			int flag = sflag[position - 1];
			if (flag == 48) // 48 == 0 in Service flag
				return true;
			else
				/*
				 * Changed by Vivek Kumar at 18/04/2016
				 */

				return false;
		} else {
			return false;
		}
	}

	/**
	 * return change service flag String at given position
	 * 
	 * @param serviceFlag
	 *            the variable contain info of services which active /inactive
	 *            for particular msisdn
	 * @param position
	 *            the position variable contains index of service
	 * @return sflag the method return change service Flag String
	 * @see sflag
	 */
	public String changeServiceFlag(String serviceFlag, int position) {
		char[] sflag = serviceFlag.toCharArray();

		int flag = sflag[position - 1];
		logger.info("service flag [" + flag + "]");
		if (flag == 48)
			sflag[position - 1] = 49;// 49 == 1 in Service flag
		else
			/*
			 * Changed by Vivek Kumar at 18/04/2016
			 */

			sflag[position - 1] = 48;// 48 == 0 in Service flag
		logger.info("service flag [" + String.valueOf(sflag) + "]");
		return String.valueOf(sflag);
	}

	/**
	 * return service flag value at given position
	 * 
	 * @param serviceFlag
	 *            the variable contain info of services which active /inactive
	 *            for particular msisdn
	 * @param position
	 *            the position variable contains index of service
	 * @return sflag the method return change service Flag String
	 * @see sflag
	 */
	/*
	 * Changed by Vivek Kumar at 18/04/2016
	 */

	public int getServiceFlag(String serviceFlag, int position) {
		char[] sflag = serviceFlag.toCharArray();

		int flag = sflag[position - 1];
		if (flag == 48)
			flag = 0;
		else
			flag = 1;

		return flag;
	}

	/**
	 * return true if directory create successfully other return false
	 * 
	 * @param recordFilePath
	 *            the variable contain location of voice mail
	 * @return status the method return status of creating directory
	 * @see status
	 */
	public Boolean createDirectory(String recordFilePath) {
		Boolean status = false;
		try {
			File recordPath = new File(recordFilePath);
			if (recordPath.mkdirs()) {
				status = true;
			} else {
				status = true;
			}

		} catch (SecurityException se) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "90014] [Security Exception while creating directory] Error[" + se.getMessage() + "]");
			status = false;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00009] [Exception while creating directory] Error[" + e.getMessage() + "]");
			e.printStackTrace();
			logger.error("Error In create directory [" + recordFilePath + "]", e);
			status = false;
		}
		return status;
	}

	public boolean createTempDirectory(String recordTempPath) {
		Boolean status = false;
		try {
			File recordPath = new File(recordTempPath);
			if (recordPath.mkdirs()) {
				status = true;
			} else {
				status = true;
			}

		} catch (SecurityException se) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "90014] [Security Exception while creating directory] Error[" + se.getMessage() + "]");
			status = false;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00009] [Exception while creating directory] Error[" + e.getMessage() + "]");
			e.printStackTrace();
			logger.error("Error In create directory [" + recordTempPath + "]", e);
			status = false;
		}
		return status;
	}

	/**
	 * return true if directory create successfully other return false
	 * 
	 * @param recordFilePath
	 *            the variable contain location of voice mail
	 * @return status the method return status of creating directory
	 * @see status
	 */
	public Boolean createNioDirectory(String recordFilePath) {
		Boolean status = false;

		Path path = Paths.get(recordFilePath);

		if (!Files.exists(path)) {
			try {
				Files.createDirectories(path);
				status = true;
			} catch (IOException e) {

				status = false;
				logger.error("Error In create directory [" + recordFilePath + "]", e);
			}
		} else {
			status = true;
		}

		return status;

	}

	/**
	 * return format of date in dd , yy , mm etc
	 * 
	 * @param pattern
	 *            the variable specify the pattern of date
	 * @return sdf the method return day , month ,year from any date
	 * @see day , month ,year
	 */
	public SimpleDateFormat getDateInFormat(String pattern) {

		SimpleDateFormat sdf = new SimpleDateFormat(pattern);

		return sdf;

	}

	public String convertToInternationalNumber(String msisdn, String code) {
		String retMsisdn = "";
		if (msisdn.startsWith(AppConfig.config.getString("country_code"))) {
			msisdn = msisdn.substring(AppConfig.config.getString("country_code").length(), msisdn.length());
		} else if (!msisdn.startsWith(AppConfig.config.getString("country_code")) && !msisdn.startsWith("0")
				&& msisdn.length() > AppConfig.config.getInt("msisdn_length")) {
			return msisdn.trim();
		} else if (msisdn.startsWith("00")) {
			return msisdn.trim();
		} else if (msisdn.startsWith("0")) {
			msisdn = msisdn.substring(1, msisdn.length());
		}
		

		logger.debug("msisdn: " + msisdn);
		PhoneNumber number = null;
		PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
		try {
			number = phoneUtil.parse(msisdn, code);
		} catch (NumberParseException e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "90016] [NumberParse Exception while converting MSISDN to International Exception] Error["
					+ e.getMessage() + "]");
			/*e.printStackTrace();*/
			return msisdn;
		}
		logger.debug("number [" + msisdn + "] to international number ["
				+ phoneUtil.format(number, PhoneNumberFormat.E164).toString().replace("+", "") + "]");
		retMsisdn = phoneUtil.format(number, PhoneNumberFormat.E164).toString().replace("+", "").trim();
		/*
		 * Added by Vivek Kumar at 20/4/2016 Handle fixed to make 9 digit
		 * number:- Add 0 after country code
		 */
		int msisdnLengthWithCountryCode = AppConfig.config.getInt("msisdn_length")
				+ AppConfig.config.getString("country_code").length();
		logger.debug(String.format("[%s] length with country code [%s]", retMsisdn, msisdnLengthWithCountryCode));
		if (retMsisdn.length() < msisdnLengthWithCountryCode) {
			logger.debug(String.format("Handle fixed line: [%s] length with country code [%s]", retMsisdn,
					msisdnLengthWithCountryCode));
			retMsisdn = retMsisdn.substring(0, AppConfig.config.getString("country_code").length()) + ""
					+ retMsisdn.substring(AppConfig.config.getString("country_code").length(), retMsisdn.length());
			logger.info(String.format("fixed line msisdn after handling: [%s]", retMsisdn));
		}
		return retMsisdn;
	}

	
	
	public String convertToNationalNumber(String msisdn, String code) {

		PhoneNumber number = null;
		PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
		try {
			number = phoneUtil.parse(msisdn, code);
		} catch (NumberParseException e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "90016] [NumberParse Exception while converting MSISDN to National Exception] Error["
					+ e.getMessage() + "]");
			//e.printStackTrace();
			return msisdn;
		}

		String convertMsisdn = phoneUtil.format(number, PhoneNumberFormat.NATIONAL).toString().replace(" ", "")
				.replace("(", "").replace(")", "").replace("-", "");
		String countryCode =  number.getCountryCode()+""; // added by ashu sir
		if(msisdn.startsWith(countryCode) && msisdn.length() > AppConfig.config.getInt("msisdn_length"))
			convertMsisdn= msisdn.substring(countryCode.length(),msisdn.length());
		
		if (convertMsisdn.startsWith("0")) {
			convertMsisdn = convertMsisdn.substring(1, convertMsisdn.length());
		}

		logger.debug("number [" + msisdn + "] to national number [" + convertMsisdn + "]");
		return convertMsisdn;
	}

	public static void main(String[] args) throws Exception {
		try {
			
			VccCommonOperation commonOperation = new VccCommonOperation();
			System.out.println(commonOperation.convertToNationalNumber("", ""));
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public int isInternationalNumber(String msisdn) {
		int status = 0;
		if (!msisdn.startsWith(AppConfig.config.getString("country_code"))) {
			status = 1;

		} else if (msisdn.startsWith("00")) {
			status = 1;

		} else if (msisdn.startsWith("+") && !msisdn.startsWith("+" + AppConfig.config.getString("country_code"))) {
			status = 1;

		} else {
			status = 0;

		}
		return status;
	}

	public String getCountryCode(String msisdn) {
		PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
		String cntCode = "N";
		try {
			PhoneNumber numberProto = phoneUtil.parse("+" + msisdn, "");
			cntCode = phoneUtil.getRegionCodeForNumber(numberProto);
		} catch (Exception e) {
			cntCode = "N";
		}
		return cntCode;
	}

	public boolean isExistWithinGroup(String msisdn1, String groupName) {
		boolean isExist = false;
		int startValue = 0;
		int endValue = 0;
		BigInteger msisdn;
		List<VccSeries> vccSeries = null;
		vccSeries = (List<VccSeries>) VccExpiryCache.getGlobalmap().get("vcc_series_range");
		if (vccSeries != null) {
			try {
				msisdn = new BigInteger(msisdn1);
				for (VccSeries series : vccSeries) {

					startValue = series.getStartRange().compareTo(msisdn);
					endValue = series.getEndRange().compareTo(msisdn);
					logger.debug("msisdn [" + msisdn + "] start [" + series.getStartRange() + "] end " + "["
							+ series.getEndRange() + "] startValue: " + startValue + " endValue: " + endValue
							+ " group: " + series.getGroupName() + " check for: " + groupName);
					if (((startValue == -1 || startValue == 0) && (endValue == 1 || endValue == 0))
							&& series.getGroupName().equals(groupName)) {
						return true;
					}

				}
			} catch (Exception e) {
				errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
						+ "90019]" + "MSISDN[" + msisdn1 + "] Group Name [" + groupName
						+ "]  [Exception in is isExistWithinGroup] Error[" + e.getMessage() + "]");

				isExist = false;
			}
		} else {
			isExist = false;
			errorLogger.error("ErrorCode  [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-") + "90019]"
					+ "MSISDN[" + msisdn1 + "] Group Name [" + groupName
					+ "]  [Exception in is isExistWithinGroup] The series range cache Not Exits");

		}
		return isExist;
	}
	
	/*
	 * Added By Richard on 12th JAN 2018
	 * 
	 */
	public int getIsSilentDetected(VmRequest vmRequest) {
		if (vmRequest.getIsSilentDetect() == 1) {
			if (vmRequest.getRecordingDuration() <= AppConfig.config.getInt(
					"record_timeout_" + vmRequest.getServiceType() + "", 5)) {
				logger.info("called ["
						+ vmRequest.getCalledNum()
						+ "] calling ["
						+ vmRequest.getCallingNum()
						+ "] Getting Silent Detected and Recording Duration["
						+ vmRequest.getRecordingDuration()
						+ "] is less than or equal to timeout value["
						+ AppConfig.config.getInt(
								"record_timeout_" + vmRequest.getServiceType()
										+ "", 5)
						+ " seconds]. Continuing with Silence Detection !!!");
				return 1;
			} else if (vmRequest.getRecordingDuration() <= AppConfig.config
					.getInt("record_timeout_" + vmRequest.getServiceType() + "",
							5)
					+ AppConfig.config.getInt("silence_negotiation", 2)) {
				logger.info("called ["
						+ vmRequest.getCalledNum()
						+ "] calling ["
						+ vmRequest.getCallingNum()
						+ "] Getting Silent Detected and Recording Duration["
						+ vmRequest.getRecordingDuration()
						+ "] is less than or equal to timeout value["
						+ AppConfig.config.getInt(
								"record_timeout_" + vmRequest.getServiceType()
										+ "", 5)
						+ " seconds], even after considering silence_negotiation factor["
						+ AppConfig.config.getInt("silence_negotiation", 2)
						+ " seconds]. Continuing with Silence Detection !!!");
				return 1;
			} else {
				logger.info("called ["
						+ vmRequest.getCalledNum()
						+ "] calling ["
						+ vmRequest.getCallingNum()
						+ "] Getting Silent Detected But Recording Duration["
						+ vmRequest.getRecordingDuration()
						+ "] is greator than timeout["
						+ AppConfig.config.getInt(
								"record_timeout_" + vmRequest.getServiceType()
										+ "", 5)
						+ " seconds], even after considering the silence_negotiation factor["
						+ AppConfig.config.getInt("silence_negotiation", 2)
						+ " seconds]. So Ignoring Silence Detection !!!");
				return 0;
			}
		} else {
			return 0;
		}
	}
	
	public boolean checkForSubscription(VmRequest vmRequest,VccServices vccServices)
	{
		/*VccUserCompleteDetails userCompleteDetail=null;
		try
		{
			userCompleteDetail=this.getCompleteAuthDetail(vccServices.userService.getUserCompleteDetail(vmRequest.getCalledNum()));
			logger.info("UserCompleteDetails["+userCompleteDetail+"]");
		}
		catch(Exception e)
		{
			logger.error("Exception occured while retrieving the user details. Exception["+e+"]");
		}
		if(userCompleteDetail==null)
		{
			return false;
		}*/
		boolean check=false;
		try
		{
			VccSubscriptionMaster master=vccServices.userService.getActiveUserByServiceType(vmRequest.getCalledNum(), vmRequest.getServiceType());
			if(master!=null && master.getStatus()!=null && master.getStatus().equalsIgnoreCase("A"))
				check=true;
			else
				check=false;
		}
		catch(Exception e)
		{
			logger.error("Exception occured while checking for voice mail user profile at the save.hangup. callingNum["
					+ vmRequest.getCallingNum()
					+ "] calledNum["
					+ vmRequest.getCalledNum() + "] Error[" + e + "]");
			check=false;
		}
		return check;
		
	}
	
	public void setFwdCallLogs(VccFwdCallLogs fwdCallLogs, VmRequest vmRequest) {

		fwdCallLogs.setServerId(vmRequest.getServerId());
		fwdCallLogs.setCallId(vmRequest.getCallUUID());
		fwdCallLogs.setOriginatingNumber(vmRequest.getCallingNum());
		fwdCallLogs.setDestinationNumber(vmRequest.getCalledNum());
		fwdCallLogs.setCircuitId(vmRequest.getCircuitId());
		fwdCallLogs.setIamCauseCode(vmRequest.getReleaseCode());
		fwdCallLogs.setRelCauseCode(vmRequest.getHangupCause());
	
		if(vmRequest.getRecordFileName() == null || vmRequest.getRecordFileName().equalsIgnoreCase(""))
		{
			fwdCallLogs.setFileName("NA");
		}else{
			fwdCallLogs.setFileName(vmRequest.getRecordFileName());
		}
		fwdCallLogs.setMsgLength(vmRequest.getRecordingDuration());
		int vccMsgIndex = 0;
		fwdCallLogs.setVoiceMsgIndex(vccMsgIndex);
		fwdCallLogs.setCallTime(vmRequest.getCallTime());
		fwdCallLogs.setCallDuration(vmRequest.getCallDuration());
		fwdCallLogs.setAnswered(vmRequest.getAnswerd());
		fwdCallLogs.setServiceType(vmRequest.getServiceType());
		if(vmRequest.getSubType().equalsIgnoreCase("0"))
		{
			fwdCallLogs.setSubType("N");
		}
		else
		{
			fwdCallLogs.setSubType(vmRequest.getSubType());
		}
		fwdCallLogs.setRatePlan(0);

	}
	
	public VccUserCompleteDetails getCompleteAuthDetail(List<VccUserCompleteDetails> master){
		VccUserCompleteDetails vccSub = null;
		try {
			if(master != null){
				for(VccUserCompleteDetails vccMaster: master){
					return vccMaster;
				}
			}
		}catch(Exception e){
			logger.error("Error while convert master to auth user: "+e.getMessage());
		}
		return vccSub;
	}
}
