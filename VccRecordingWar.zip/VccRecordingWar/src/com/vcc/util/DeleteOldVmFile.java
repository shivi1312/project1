package com.vcc.util;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;

import com.vcc.chain.VmChain;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.domain.FwdCallLogs;
import com.vcc.error.VmError;
import com.vcc.model.VccVoiceMessage;
import com.vcc.request.VmRequest;
import com.vcc.response.VmResponse;

public class DeleteOldVmFile implements VmChain {

	final static Logger logger = Logger.getLogger(DeleteOldVmFile.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private VmChain nextInVmChain;
	private VccServices vccServices;
	private Boolean isOldFileDeleted = false;
	int isVoiceMailDeleted;
	int isMailBoxFull;
	Boolean isDefault = false;
	private List<VccVoiceMessage> vccMsgList = null;
	private VccCommonOperation commonOperation = null;
	private String deleteCat = "R";
	private String catName = "R";

	@Override
	public void setNext(VmChain nextInVmChain, VccServices vccServices) {
		this.nextInVmChain = nextInVmChain;
		this.vccServices = vccServices;
	}

	/**
	 * return void this method is responsible for delete old/new voice mail
	 * file(wav)
	 * 
	 * @param vmRequest
	 *            the variable contain bean of VmRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param vmResponse
	 *            the variable contain bean of VmResponse , which actually
	 *            return in url response like - isSuccess etc
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @return void
	 * @see nothing
	 */
	@Override
	public void process(VmRequest vmRequest, VmResponse vmResponse,
			VmError vmError) {

		this.isVoiceMailDeleted = vmRequest.getIsVoiceMailDeleted();
		this.isMailBoxFull = vmRequest.getIsMailBoxFull();

		if (vmRequest.getIsCallAllowed() == 0
				&& vmRequest.getReasonCode() != null
				&& vmRequest.getReasonCode().equalsIgnoreCase("special")) {
			logger.debug("inside the special");
			this.nextInVmChain = new FwdCallLogs();
			this.nextInVmChain.setNext(nextInVmChain, vccServices);
			isDefault = false;
		} else if (vmRequest.getIsCallAllowed() == 1
				&& vmRequest.getReasonCode() != null
				&& vmRequest.getReasonCode().equalsIgnoreCase("cancel")) {
			logger.debug("inside the cancel");
			deleteNewFile(vmRequest);
			this.nextInVmChain = new FwdCallLogs();
			this.nextInVmChain.setNext(nextInVmChain, vccServices);
			isDefault = false;
		} else if (vmRequest.getIsCallAllowed() == 1
				&& vmRequest.getReasonCode() != null
				&& vmRequest.getReasonCode().equalsIgnoreCase("recorded")) {
			logger.debug("inside the recorded");
			this.nextInVmChain = new FwdCallLogs();
			this.nextInVmChain.setNext(nextInVmChain, vccServices);
			isDefault = false;

		} else if (vmRequest.getIsCallAllowed() == 1
				&& vmRequest.getReasonCode() != null
				&& vmRequest.getReasonCode().equalsIgnoreCase("hangup")) {
			logger.debug("inside the hangup");
			this.nextInVmChain = new FwdCallLogs();
			this.nextInVmChain.setNext(nextInVmChain, vccServices);
			isDefault = false;

		} else if (vmRequest.getIsCallAllowed() == 1
				&& vmRequest.getReasonCode() != null
				&& vmRequest.getReasonCode().equalsIgnoreCase("hangupWithSave")) {
			logger.info("inside the hangupWithSave");
			if(vmRequest.getIsSilentDetect()==1){
				this.nextInVmChain = new FwdCallLogs();
				this.nextInVmChain.setNext(nextInVmChain, vccServices);
			}
			deleteOldFile(vmRequest, vccServices);
			isDefault = false;
		} else if (vmRequest.getReasonCode().equalsIgnoreCase("normal")) {
			logger.debug("inside the default");
			isDefault = true;
			deleteOldFile(vmRequest, vccServices);
		} else {
			logger.debug("inside the no condition match");
			this.nextInVmChain = new FwdCallLogs();
			this.nextInVmChain.setNext(nextInVmChain, vccServices);
			isDefault = false;
		}
		logger.debug(String
				.format("A-Party [%s] B-Party [%s] isOldFileDeleted [%s] any error [%s]",
						vmRequest.getCallingNum(), vmRequest.getCalledNum(),
						this.isOldFileDeleted, vmError.getError()));

		vmRequest.setIsOldFileDeleted(this.isOldFileDeleted);

		if (!vmError.getError()) {
			if (this.isDefault) {

				this.nextInVmChain.process(vmRequest, vmResponse, vmError);
			} else {

				this.nextInVmChain.process(vmRequest, vmResponse, vmError);

			}
		} else {
			vmResponse.setIsSuccess(0);
		}

	}

	/**
	 * return status this method is responsible for delete old voice mail
	 * file(wav)
	 * 
	 * @param vmRequest
	 *            the variable contain bean of VmRequest ,which set by url
	 *            request like - callingNum , calledNum
	 *            ,recordFilePath,recordFileName etc
	 * @return status return true if file delete successfully otherwise false
	 * @see nothing
	 */
	private Boolean deleteNewFile(VmRequest vmRequest) {
		commonOperation = new VccCommonOperation();
		String recordingFileName = vmRequest.getRecordFileName();
		String tempName = recordingFileName.substring(
				0,
				recordingFileName.length()
						- AppConfig.config.getInt("default_record_digits", 10));
		String calledNum = vmRequest.getCalledNumWithoutCountryCode();

		String recordFilePath = commonOperation.getCopletePath(tempName,
				calledNum, recordingFileName,
				AppConfig.config.getString("ivr_record_path"));

		try {

			File file = new File(recordFilePath);
			if (file.exists()) {
				logger.debug("delete file is [" + recordFilePath + "]");
				file.delete();
			}
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-IVRWAR-")
							+ "90003] CalledNum["
							+ calledNum
							+ "] [Null Pointer Exception in deleting old voice mail File] Error["
							+ npe.getMessage() + "]");

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-IVRWAR-") + "00061] CalledNum[" + calledNum
					+ "] [Exception in deleting old voice mail File] Error[ "
					+ e.getMessage() + "]");
			e.printStackTrace();
			return false;
		}

		return true;

	}

	/**
	 * return status this method is responsible for delete new voice mail
	 * file(wav)
	 * 
	 * @param vmRequest
	 *            the variable contain bean of VmRequest ,which set by url
	 *            request like - callingNum , calledNum
	 *            ,recordFilePath,recordFileName etc
	 * @return status return true if file delete successfully otherwise false
	 * @see nothing
	 */
	private Boolean deleteOldFile(VmRequest vmRequest, VccServices vccServices) {
		Boolean status = false;
		logger.info("calling ["+vmRequest.getCallingNum()+"] voice mail deleted ["+
		this.isVoiceMailDeleted+"] mailbox full ["+this.isMailBoxFull+"]");
		if (this.isVoiceMailDeleted == 1 && this.isMailBoxFull == 1){
				this.vccMsgList = vmRequest.getVccList();	
		}
		
		if (this.isMailBoxFull == 1 && this.isVoiceMailDeleted == 1
				&& this.vccMsgList.size() != 0) {
			logger.info("[" + vmRequest.getCallingNum()
					+ "] old mail going to deleted ["
					+ this.vccMsgList.get(0).getVoiceMessageIndex() + "]");
			if (this.deleteCat.equalsIgnoreCase("R")) {
				logger.debug("find read msg in list cat [" + this.deleteCat
						+ "]");
				this.catName = "R";
				status = deleteOldMsgByCategory(this.deleteCat, this.catName,
						vmRequest, vccServices);

			}
			if (this.deleteCat != null && this.deleteCat.equalsIgnoreCase("N")) {
				logger.debug("find new  msg in list cat [" + this.deleteCat
						+ "]");
				this.catName = "N";
				status = deleteOldMsgByCategory(this.deleteCat, this.catName,
						vmRequest, vccServices);

			}
			if (this.deleteCat != null && this.deleteCat.equalsIgnoreCase("S")) {
				logger.debug("find save  msg in list cat [" + this.deleteCat
						+ "]");
				this.catName = "S";
				status = deleteOldMsgByCategory(this.deleteCat, this.catName,
						vmRequest, vccServices);
			}

			this.isOldFileDeleted = true;

		} else {
			this.isOldFileDeleted = false;
		}
		return status;
	}

	private Boolean deleteOldMsgByCategory(String deleteCat, String catName,
			VmRequest vmRequest, VccServices vccServices2) {
		Boolean status = false, status1 = false;

		for (VccVoiceMessage msg : this.vccMsgList) {

			if (msg.getMessageStatus().equalsIgnoreCase(this.catName)) {
				status = vccServices.userService.deleteVccVoiceMessage(
						msg.getDesticationNumber(), msg.getVoiceMessageIndex());
				commonOperation = new VccCommonOperation();
				// write the logic of delete old voice mail physically
				status1 = commonOperation.deletePhysicalFile(msg.getFileName(),
						msg.getDesticationNumber(), null,
						AppConfig.config.getString("ivr_record_path"));
				logger.info("delete mail box of [" + vmRequest.getCalledNum()
						+ "] and voice mail box is ["
						+ msg.getVoiceMessageIndex()
						+ "] and stauts of delete old file[" + status1
						+ "]  delete category is [" + this.catName + "]");
				this.deleteCat = null;
				break;
			} else {

				if (this.catName.equalsIgnoreCase("R"))
					this.deleteCat = "N";
				else if (this.catName.equalsIgnoreCase("N"))
					this.deleteCat = "S";
				continue;
			}

		}
		logger.info("[" + vmRequest.getCallingNum() + "] delete mail box os ["
				+ vmRequest.getCalledNum() + "] and stauts[" + status
				+ "] of delete old file[" + status1 + "]  delete category is ["
				+ this.catName + "] ");
		return status;
	}

}
