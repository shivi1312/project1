package com.vcc.util;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.filter.Filter;
import com.vcc.model.VccClassType;
import com.vcc.model.VccSeriesRange;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.services.UserService;

/*
 * Check configuration for call is allowed or not
 * 1. Check user exist with in the given range
 * 2. Check user have any class type
 * */
public class CallAllowanceFilter implements Filter {

	final static Logger logger = Logger.getLogger(CallAllowanceFilter.class);
	
	private List<VccSeriesRange> seriesRangesList;
	private List<VccSubscriptionMaster> activeServiceList;

	public void setActiveServiceList(List<VccSubscriptionMaster> activeServiceList) {
		this.activeServiceList = activeServiceList;
	}
	public CallAllowanceFilter() {

	}

	/**
	 * return void 
	 * this method is check whether calledNum is white listed or not 
	 * @param profileRequest the variable contain bean of ProfileRequest ,which set by url request like - callingNum , calledNum ,serviceType etc  
	 * @param profileResponse the variable contain bean of  profileResponse , which actually return in url response like - isSuccess , isCallAllowed, isSubscriber 
	 * @param vmError vmError is a bean that is used to define which type of error generate in operation
	 * @param vccServices vccServices is a bean that contain reference of interface(UserService,MessageService,UserConfigService) 
	 * @return void     
	 * @see    nothing
	 */
	@Override
	public void execute(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError,VccServices vccServices) {
		this.isInternationalNumber(profileRequest, bindingResult, profileResponse,
				vmError, vccServices);
		
		this.isUserWhiteList(profileRequest, bindingResult, profileResponse,
				vmError, vccServices);
		logger.debug(String.format(
				"A-Party [%s] B-Party [%s] classType [%s] isCallAllowed [%s]",
				profileRequest.getCallingNum(),profileRequest.getCalledNum(),
				profileResponse.getClassType(),AppConfig.config.getString(
				profileResponse.getIsCallAllowed()+ "_call_allowed","" + profileResponse.getIsCallAllowed())));
	}

	private void isInternationalNumber(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {
		
		VccCommonOperation commonOperation = new VccCommonOperation();
		
		int status =commonOperation.isInternationalNumber(profileRequest.getCallingNum());
		logger.debug("["+profileRequest.getCallingNum()+"] is international number ["+status+"]");
		profileResponse.setIsIntNo(status);
		commonOperation= null;
		
		
		
		
	}

	/*
	 * Check is call allowed Check if user exist with in given range
	 */
	/**
	 * return void 
	 * this method is a sub task of this class for check calledNum within range or not of white list
	 * @param profileRequest the variable contain bean of ProfileRequest ,which set by url request like - callingNum , calledNum ,serviceType etc  
	 * @param profileResponse the variable contain bean of  profileResponse , which actually return in url response like -isCallAllowed 
	 * @param vmError vmError is a bean that is used to define which type of error generate in operation
	 * @param vccServices vccServices is a bean that contain reference of interface(UserService,MessageService,UserConfigService) 
	 * @return void     
	 * @see    nothing
	 */
	private void isUserWhiteList(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {
		boolean isExistWithInSeries = false;
		boolean isBlackList=false;
		String groupName="blacklist";
		VccCommonOperation commonOperation = new VccCommonOperation();
		
		if (AppConfig.config.getBoolean("vsms_whitelist_enable", true)) {
			isBlackList = commonOperation.isExistWithinGroup(profileRequest.getCalledNum(), groupName);
			groupName = "whitelist";
			isExistWithInSeries = commonOperation.isExistWithinGroup(profileRequest.getCalledNum(), groupName);
		} else {
			isExistWithInSeries = true;
		}
		if (isBlackList!=true && isExistWithInSeries)
			profileResponse.setIsCallAllowed(1);
		else
			profileResponse.setIsCallAllowed(0);
		
		logger.info(String
				.format("A-Party [%s] B-Party [%s] Series Whitelist enable [%s] MSISDN isWithInRange [%s]",
				profileRequest.getCallingNum(), profileRequest.getCalledNum(), AppConfig.config.getBoolean(
				"vsms_whitelist_enable", true),isExistWithInSeries));
	}
	/**
	 *this method is responsible for gathering details from list 
	 *@return status if whitelist find in list return true other return false 
	 */
	@SuppressWarnings("unused")
	private boolean checkBlackList() {

		boolean status = false;

		for (VccSeriesRange vccSeriesRange : this.seriesRangesList) {

			if (vccSeriesRange.getGroupName().equalsIgnoreCase("whitelist")) {
				logger.debug(" user in white list ");
				status = true;
			} else if (vccSeriesRange.getGroupName().equalsIgnoreCase(
					"blacklist")) {
				logger.info(" user in blacklist ");
				status = false;
				break;
			}
		}

		return status;
	}

	/*
	 * Check if user is belongs to any class Like vip,dubail...etc
	 */
	@SuppressWarnings("unused")
	private void haveAnyClass(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, UserService service) {
		boolean haveAnyClassType = false;
		VccClassType classType = service.haveAnyClass(profileRequest);
		if (classType != null) {
			haveAnyClassType = true;
			profileResponse.setClassType(classType.getId());
			logger.debug(String
					.format("A-Party [%s] B-Party [%s] class type [%s] have any class [%s]",
							profileRequest.getCallingNum(),
							profileRequest.getCalledNum(),
							classType.getClassType(), haveAnyClassType));
		}
		if (haveAnyClassType)
			profileResponse.setIsCallAllowed(0);
		else
			profileResponse.setIsCallAllowed(1);
	}

}
