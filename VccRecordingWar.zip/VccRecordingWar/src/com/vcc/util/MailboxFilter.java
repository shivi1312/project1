package com.vcc.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.validation.BindingResult;

import com.vcc.cache.VccExpiryCache;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.filter.Filter;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.model.VccVoiceMessage;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.ProfileResponse;

public class MailboxFilter implements Filter {

	final static Logger logger = Logger.getLogger(MailboxFilter.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private List<VccVoiceMessage> vcc;
	private boolean isVmsMailboxFullRejected=false;
	private boolean isVmsMailboxFullNewAutoDelete;
	@SuppressWarnings("unused")
	private String serviceType;
	private int totalCount;
	private int totalNewCount;
	private int maxMessage = 5;
	private int mailBoxId = 0;
	private int ratePlan = 0;
	@SuppressWarnings("unused")
	private List<VccSubscriptionMaster> activeServiceList;

	public void setActiveServiceList(
			List<VccSubscriptionMaster> activeServiceList) {
		this.activeServiceList = activeServiceList;
	}

	public MailboxFilter() {

	}

	/**
	 * return void this method is responsible for filtering mail box whether
	 * mail box full or not if full and not deleted so isCallAllowed set 0
	 * otherwiese set 1
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of ProfileResponse , which actually
	 *            return in url response like - isSuccess , isCallAllowed
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	@Override
	public void execute(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {

		if (profileResponse.getIsCallAllowed() == 1) {
			this.isVmsMailboxFullRejected = AppConfig.config.getBoolean(
					"vms_mailbox_full_reject", false);
			this.isVmsMailboxFullNewAutoDelete = AppConfig.config.getBoolean(
					"vms_mailbox_full_new_auto_delete", false);
			this.serviceType = AppConfig.config.getString("service_type_"
					+ profileResponse.getServiceType());
			logger.info(String.format(
					"A-Party [%s] B-Party [%s] service [%s] isCallAllowed [%s]"
							+ " mailbox full rejected [%s] isNewDeleted [%s]",
					profileRequest.getCallingNum(),
					profileRequest.getCalledNum(),
					AppConfig.config.getString(profileResponse.getServiceType()
							+ "_service_name",
							"" + profileResponse.getServiceType()),
					AppConfig.config.getString(
							profileResponse.getIsCallAllowed()
									+ "_call_allowed",
							"" + profileResponse.getIsCallAllowed()),
					this.isVmsMailboxFullRejected,
					this.isVmsMailboxFullNewAutoDelete));
			if (profileResponse.getRatePlan() != 0) {
				ratePlan = profileResponse.getRatePlan();
				String ratePlanJson = VccExpiryCache.getSysmap().get(
						"vcc_rate_plan");

				logger.debug("rate plan json " + ratePlanJson);

				JSONObject mailBoxJson;
				try {
					mailBoxJson = new JSONObject(ratePlanJson);
					mailBoxId = Integer.parseInt(mailBoxJson
							.getJSONObject("" + ratePlan + "").get("mailBoxId")
							.toString());

				} catch (JSONException e) {
					errorLogger
							.error("ErrorCode ["
									+ AppConfig.config.getString(
											"errorcode_pattern", "VCC-IVRWAR-")
									+ "90018] CallingNum["
									+ profileRequest.getCallingNum()
									+ "] CalledNum["
									+ profileRequest.getCalledNum()
									+ "] [Json Exception while getting MailBox Id from Json] Error["
									+ e.getMessage() + "]");
					logger.error("[" + profileRequest.getCallingNum()
							+ "] rateplan [" + ratePlan
							+ "] mailBoxId not found in json [" + mailBoxId
							+ "] ");
					e.printStackTrace();
					profileResponse.setIsSuccess(-1);
				}

				String mailBoxParam = VccExpiryCache.getSysmap().get(
						"vcc_mailbox_param");

				logger.debug("mailbox  plan json " + mailBoxParam);

				try {
					mailBoxJson = new JSONObject(mailBoxParam);
					maxMessage = Integer.parseInt(mailBoxJson
							.getJSONObject("" + mailBoxId + "")
							.get("maxMessage").toString());

				} catch (JSONException e) {
					errorLogger
							.error("ErrorCode ["
									+ AppConfig.config.getString(
											"errorcode_pattern", "VCC-IVRWAR-")
									+ "90018] CallingNum["
									+ profileRequest.getCallingNum()
									+ "] CalledNum["
									+ profileRequest.getCalledNum()
									+ "] [Json Exception while getting MailBox Id from Json] Error["
									+ e.getMessage() + "]");
					profileResponse.setIsSuccess(-1);
					logger.error("[" + profileRequest.getCallingNum()
							+ "] rateplan [" + ratePlan
							+ "] mailBoxId not found in json [" + mailBoxId
							+ "] ");
					e.printStackTrace();
				}

				logger.debug("[" + profileRequest.getCallingNum()
						+ "] service type [" + profileResponse.getServiceType()
						+ "] ratePlan [" + profileResponse.getRatePlan()
						+ "] mailboxid [" + mailBoxId + "]  maxMessage ["
						+ maxMessage + "]");
			} else {
				logger.warn("[" + profileRequest.getCallingNum()
						+ "] rateplan not found for ["
						+ profileRequest.getCalledNum() + "] rateplan ["
						+ profileResponse.getRatePlan() + "]");
			}
		}
		/*if (profileResponse.getIsCallAllowed() == 1
				&& !profileResponse.getSubType().equalsIgnoreCase("0")) {

			// Changed By AbhiShek Rana
			List<VccVoiceMessage> vccList = vccServices.userService.getMailboxGroupByCount(profileRequest.getCalledNum(),profileResponse.getServiceType());

			profileRequest.setVccList(vccList);
			profileResponse.setVccList(vccList);

			if (vccList != null)
				this.getTotalMessageCount(vccList);
			if (vcc != null) {
				this.getTotalCount(profileRequest, profileResponse, vmError,
						vccServices);
				this.getTotalCountOfNew(profileRequest, profileResponse,
						vmError, vccServices);
				logger.debug("[" + profileRequest.getCallingNum()
						+ "] total message [" + totalCount + "] of ["
						+ profileRequest.getCalledNum() + "] ");
				// delete old message or not check
				if (totalCount >= maxMessage) {
					if (this.isVmsMailboxFullRejected) {
						profileResponse.setIsCallAllowed(0);
					} else {
						// delete
						if (this.totalNewCount >= maxMessage) {
							if (this.isVmsMailboxFullNewAutoDelete) {
								profileResponse.setIsCallAllowed(1);
								profileResponse.setIsVoiceMailDeleted(1);
								profileResponse.setIsMailBoxFull(1);
							} else
								profileResponse.setIsCallAllowed(0);

							profileResponse.setIsMailBoxFull(1);
							profileResponse.setIsVoiceMailDeleted(1);
						} else {
							profileResponse.setIsCallAllowed(1);
							profileResponse.setIsVoiceMailDeleted(0);
							profileResponse.setIsMailBoxFull(1);
						}
						profileResponse.setIsCallAllowed(1);
						profileResponse.setIsMailBoxFull(1);
						profileResponse.setIsVoiceMailDeleted(1);
					}
				} else {
					profileResponse.setIsVoiceMailDeleted(0);
					profileResponse.setIsMailBoxFull(0);
				}
				logger.info("calling [" + profileRequest.getCallingNum()
						+ "] [" + profileRequest.getCalledNum()
						+ "] total msg [" + totalCount + "] message allowed ["
						+ maxMessage + "] mailbox full rejected ["
						+ this.isVmsMailboxFullRejected
						+ "] mailbox new auto deleted ["
						+ this.isVmsMailboxFullNewAutoDelete
						+ "] call allowed ["
						+ profileResponse.getIsCallAllowed()
						+ "] voice mail deleted ["
						+ profileResponse.getIsVoiceMailDeleted()
						+ "] mailbox full ["
						+ profileResponse.getIsMailBoxFull() + "]");

				logger.info(String.format(
						"A-Party [%s] B-Party [%s] totalCount [%s] "
								+ "totalNewCount [%s] isCallAllowed [%s]",
						profileRequest.getCallingNum(),
						profileRequest.getCalledNum(),
						this.totalCount,
						this.totalNewCount,
						AppConfig.config.getString(
								profileResponse.getIsCallAllowed()
										+ "_call_allowed",
								"" + profileResponse.getIsCallAllowed())));
			}
		}*/

	}

	/**
	 * return void this method is responsible for counting total voice mail in
	 * mailbox
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @return void
	 * @see nothing
	 */
	public void getTotalCount() {
		for (VccVoiceMessage msg : this.vcc) {
			totalCount += msg.getCount();
		}
	}

	/**
	 * return void this method is responsible for counting new voice mail in
	 * mailbox
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @return void
	 * @see nothing
	 */
	public void getTotalCountOfNew() {
		for (VccVoiceMessage msg : this.vcc) {
			if (msg.getMessageStatus().equals("N"))
				this.totalNewCount = msg.getCount();
		}
	}

	// Added By AbhiShek Rana
	public void getTotalMessageCount(List<VccVoiceMessage> vcc) {
		logger.debug("List>>>>>>>"+vcc.toString());
		HashMap<String, Integer> listMap = new HashMap<String, Integer>();
		listMap.put("N", 0);
		listMap.put("R", 0);
		listMap.put("S", 0);
		List<VccVoiceMessage> list = new ArrayList<VccVoiceMessage>();
		if (vcc != null) {
			for (VccVoiceMessage msg : vcc) {
				if(listMap.containsKey(msg.getMessageStatus()))
					listMap.put(msg.getMessageStatus(),listMap.get(msg.getMessageStatus()) + 1);
				else
					listMap.put(msg.getMessageStatus(),1);
			}

			for (String key : listMap.keySet()) {
				VccVoiceMessage vccMessage = new VccVoiceMessage();
				vccMessage.setMessageStatus("" + key);
				vccMessage.setCount(Integer.parseInt("" + listMap.get(key)));
				list.add(vccMessage);
			}
			logger.debug("Message Map - "+listMap.toString());
		}
		this.vcc = list;
	}
	
	public VmRequest getMailBoxDetails(VmRequest vmRequest,VccServices vccServices){
		
		logger.info("Inside getmailBoxDetails "+vmRequest.getCallingNum());
		if (vmRequest.getIsCallAllowed() == 1) {
			this.isVmsMailboxFullRejected = AppConfig.config.getBoolean(
					"vms_mailbox_full_reject", false);
			this.isVmsMailboxFullNewAutoDelete = AppConfig.config.getBoolean(
					"vms_mailbox_full_new_auto_delete", false);
			this.serviceType = AppConfig.config.getString("service_type_"
					+ vmRequest.getServiceType());
			logger.info(String.format(
					"A-Party [%s] B-Party [%s] service [%s] isCallAllowed [%s]"
							+ " mailbox full rejected [%s] isNewDeleted [%s]",
							vmRequest.getCallingNum(),
							vmRequest.getCalledNum(),
					AppConfig.config.getString(vmRequest.getServiceType()
							+ "_service_name",
							"" + vmRequest.getServiceType()),
					AppConfig.config.getString(
							vmRequest.getIsCallAllowed()
									+ "_call_allowed",
							"" + vmRequest.getIsCallAllowed()),
					this.isVmsMailboxFullRejected,
					this.isVmsMailboxFullNewAutoDelete));
			if (vmRequest.getRatePlan() != 0) {
				ratePlan = vmRequest.getRatePlan();
				String ratePlanJson = VccExpiryCache.getSysmap().get(
						"vcc_rate_plan");

				logger.debug("rate plan json " + ratePlanJson);

				JSONObject mailBoxJson;
				try {
					mailBoxJson = new JSONObject(ratePlanJson);
					mailBoxId = Integer.parseInt(mailBoxJson
							.getJSONObject("" + ratePlan + "").get("mailBoxId")
							.toString());

				} catch (JSONException e) {
					e.printStackTrace();
					logger.error("Exception while getting mailbox id"+e.getMessage());
				}

				String mailBoxParam = VccExpiryCache.getSysmap().get(
						"vcc_mailbox_param");

				logger.info("mailbox  plan json " + mailBoxParam);

				try {
					mailBoxJson = new JSONObject(mailBoxParam);
					maxMessage = Integer.parseInt(mailBoxJson
							.getJSONObject("" + mailBoxId + "")
							.get("maxMessage").toString());

				} catch (JSONException e) {
					errorLogger
							.error("ErrorCode ["
									+ AppConfig.config.getString(
											"errorcode_pattern", "VCC-IVRWAR-")
									+ "90018] CallingNum["
									+ vmRequest.getCallingNum()
									+ "] CalledNum["
									+ vmRequest.getCalledNum()
									+ "] [Json Exception while getting MailBox Id from Json] Error["
									+ e.getMessage() + "]");
					
					logger.error("[" + vmRequest.getCallingNum()
							+ "] rateplan [" + ratePlan
							+ "] mailBoxId not found in json [" + mailBoxId
							+ "] ");
					e.printStackTrace();
				}

				logger.debug("[" + vmRequest.getCallingNum()
						+ "] service type [" + vmRequest.getServiceType()
						+ "] ratePlan [" + vmRequest.getRatePlan()
						+ "] mailboxid [" + mailBoxId + "]  maxMessage ["
						+ maxMessage + "]");
			} else {
				logger.info("[" + vmRequest.getCallingNum()
						+ "] rateplan not found for ["
						+ vmRequest.getCalledNum() + "] rateplan ["
						+ vmRequest.getRatePlan() + "]");
			}
		}

				
		if (vmRequest.getIsCallAllowed() == 1
				&& !vmRequest.getSubType().equalsIgnoreCase("0")) {
			List<VccVoiceMessage> vccList = vccServices.userService
					.getMailboxGroupByCount(vmRequest.getCalledNum(),
							vmRequest.getServiceType());

			vmRequest.setVccList(vccList);
			if (vccList != null)
				this.getTotalMessageCount(vccList);
			if (vcc != null) {
				this.getTotalCount();
				this.getTotalCountOfNew();
				logger.debug("[" + vmRequest.getCallingNum()
						+ "] total message [" + totalCount + "] of ["
						+ vmRequest.getCalledNum() + "] ");
				// delete old message or not check
				if (totalCount >= maxMessage) {
					if (this.isVmsMailboxFullRejected) {
						vmRequest.setIsCallAllowed(0);
					} else {
						// delete
						if (this.totalNewCount >= maxMessage) {
							if (this.isVmsMailboxFullNewAutoDelete) {
								vmRequest.setIsCallAllowed(1);
								vmRequest.setIsVoiceMailDeleted(1);
								vmRequest.setIsMailBoxFull(1);
							} else
								vmRequest.setIsCallAllowed(0);

							vmRequest.setIsMailBoxFull(1);
							vmRequest.setIsVoiceMailDeleted(1);
						} else {
							vmRequest.setIsCallAllowed(1);
							vmRequest.setIsVoiceMailDeleted(0);
							vmRequest.setIsMailBoxFull(1);
						}
						vmRequest.setIsCallAllowed(1);
						vmRequest.setIsMailBoxFull(1);
						vmRequest.setIsVoiceMailDeleted(1);
					}
				} else {
					vmRequest.setIsVoiceMailDeleted(0);
					vmRequest.setIsMailBoxFull(0);
				}
				logger.info("calling [" + vmRequest.getCallingNum() + "] ["
						+ vmRequest.getCalledNum() + "] total msg ["
						+ totalCount + "] message allowed [" + maxMessage
						+ "] mailbox full rejected ["
						+ this.isVmsMailboxFullRejected
						+ "] mailbox new auto deleted ["
						+ this.isVmsMailboxFullNewAutoDelete
						+ "] call allowed [" + vmRequest.getIsCallAllowed()
						+ "] voice mail deleted ["
						+ vmRequest.getIsVoiceMailDeleted()
						+ "] mailbox full [" + vmRequest.getIsMailBoxFull()
						+ "]");

				logger.info(String.format(
						"A-Party [%s] B-Party [%s] totalCount [%s] "
								+ "totalNewCount [%s] isCallAllowed [%s]",
						vmRequest.getCallingNum(),
						vmRequest.getCalledNum(),
						this.totalCount,
						this.totalNewCount,
						AppConfig.config.getString(vmRequest.getIsCallAllowed()
								+ "_call_allowed",
								"" + vmRequest.getIsCallAllowed())));
			}
		}
		return vmRequest;
	}
	
	
	

}
