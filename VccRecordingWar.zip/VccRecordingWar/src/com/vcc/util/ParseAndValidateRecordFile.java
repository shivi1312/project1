package com.vcc.util;

import java.io.File;

import org.apache.log4j.Logger;

import com.vcc.chain.VmChain;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.domain.FwdCallLogs;
import com.vcc.domain.VccSendNotification;
import com.vcc.error.VmError;
import com.vcc.request.VmRequest;
import com.vcc.response.VmResponse;

public class ParseAndValidateRecordFile implements VmChain {

	final static Logger logger = Logger
			.getLogger(ParseAndValidateRecordFile.class);

	private VmChain nextInVmChain;
	@SuppressWarnings("unused")
	private VccServices vccServices;
	private String recordFileName;
	private String recordTempPath = null;
	private String recordFilePath;
	private Boolean isRecordFileExits = false;
	private VccCommonOperation commonOperation = null;

	@Override
	public void setNext(VmChain nextInVmChain, VccServices vccServices) {
		this.nextInVmChain = nextInVmChain;
		this.vccServices = vccServices;

	}

	/**
	 * return void this method is responsible for checking the record file path
	 * physically exists or not
	 * 
	 * @param vmRequest
	 *            the variable contain bean of VmRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param vmResponse
	 *            the variable contain bean of VmResponse , which actually
	 *            return in url response like - isSuccess
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	@Override
	public void process(VmRequest vmRequest, VmResponse vmResponse,
			VmError vmError) {

		logger.debug("called [" + vmRequest.getCalledNum() + "] calling ["
				+ vmRequest.getCallingNum()
				+ "] validate voice mail record file ["
				+ vmRequest.getRecordFileName() + "]");
		try {
			this.commonOperation = new VccCommonOperation();
			this.commonOperation.addAndRemoveCountryCode(vmRequest);

			/*
			 * Commented For ESL Testing, the very next line should be commented
			 * and this one should make uncommented recordFileName =
			 * vmRequest.getRecordFileName();
			 */
			//recordFileName = "171024193648886268";
			recordFileName = vmRequest.getRecordFileName();

			String tempName = recordFileName.substring(
					0,
					recordFileName.length()
							- AppConfig.config.getInt("default_record_digits",
									10));

			this.recordFilePath = this.commonOperation.getCopletePath(tempName,
					vmRequest.getCalledNumWithoutCountryCode(), recordFileName,
					AppConfig.config.getString("ivr_record_path"));
			this.recordTempPath = vmRequest.getRecordTempPath();
			// int silentDetect = this.getIsSilentDetected(vmRequest);
			int silentDetect = vmRequest.getIsSilentDetect();
			logger.info("called [" + vmRequest.getCalledNum() + "] calling ["
					+ vmRequest.getCallingNum() + "] source ["
					+ this.recordTempPath + "] destination ["
					+ this.recordFilePath + "] IsSilentDetect[" + silentDetect
					+ "]");

			if (vmRequest.getReasonCode() != null
					&& !vmRequest.getReasonCode().equals("cancel")
					&& silentDetect == 0
					&& (vmRequest.getRecordingDuration() > AppConfig.config
							.getInt("IGNORE_RECORDING_LENGTH", 2))) {
				/*
				 * Commented on 15th Jan 2018 for ESL Testing
				 * this.commonOperation.copyRecordFile(this.recordTempPath,
				 * this.recordFilePath);
				 */
				this.commonOperation.copyRecordFile(this.recordTempPath,this.recordFilePath);
			} else {
				logger.info("File not copied from temporary path to actual path.Calling["
						+ vmRequest.getCallingNum()
						+ "] Called["
						+ vmRequest.getCalledNum()
						+ "] ReasonCode["
						+ vmRequest.getReasonCode()
						+ "] RecordingDuration["
						+ vmRequest.getRecordingDuration()
						+ "] IsSilentDetect[" + silentDetect + "].");
			}

			// --------------

			/*
			 * Commented on 15th Jan 2018 for ESL Testing Uncomment these two
			 * lines before making it live this.isRecordFileExits =
			 * validateRecordFile(this.recordFilePath);
			 * vmRequest.setIsRecordFileExits(isRecordFileExits);
			 */
			this.isRecordFileExits = validateRecordFile(this.recordFilePath);
			/*
			 * Commented for ESL Testing uncomment it before making it live and
			 * comment the very next line
			 * 
			 * vmRequest.setIsRecordFileExits(isRecordFileExits);
			 */
			/*vmRequest.setIsRecordFileExits(true);*/
			vmRequest.setIsRecordFileExits(isRecordFileExits);

			logger.debug(String
					.format("A-Party [%s] B-Party [%s] IsRecordFileExits [%s] isOldFileDeleted [%s] any error [%s]",
							vmRequest.getCallingNum(),
							vmRequest.getCalledNum(), this.isRecordFileExits,
							vmRequest.getIsOldFileDeleted(), vmError.getError()));

			if (!vmError.getError()) {
				nextInVmChain.process(vmRequest, vmResponse, vmError);
			} else {
				logger.info(String
						.format("A-Party [%s] B-Party [%s] IsRecordFileExits [%s] isOldFileDeleted [%s] any error [%s]",
								vmRequest.getCallingNum(),
								vmRequest.getCalledNum(),
								this.isRecordFileExits,
								vmRequest.getIsOldFileDeleted(),
								vmError.getError()));

				vmResponse.setIsSuccess(0);
			}
		} catch (Exception e) {
			/*logger.error("Exception occured in parsing and validating record file. inserting data only in vcc_fwd_call_logs "
					+ e);
			this.nextInVmChain = new FwdCallLogs();
			this.nextInVmChain.setNext(nextInVmChain, vccServices);
			this.nextInVmChain.process(vmRequest, vmResponse, vmError);*/
			logger.error("Exception occured in parsing and validating record file. "
					+ e);
			if((vmRequest.getServiceType().equalsIgnoreCase(AppConfig.config.getString("VM","0010")) && vmRequest.getIsSuccess()!=1) ||
					(vmRequest.getServiceType().equalsIgnoreCase(AppConfig.config.getString("VN","0100")) && !vmRequest.isVoiceNoteActive())){
				this.nextInVmChain = new VccSendNotification();
				this.nextInVmChain.setNext(nextInVmChain, vccServices);
				this.nextInVmChain.process(vmRequest, vmResponse, vmError);
			}else{
				this.nextInVmChain = new FwdCallLogs();
				this.nextInVmChain.setNext(nextInVmChain, vccServices);
				this.nextInVmChain.process(vmRequest, vmResponse, vmError);
			}
			
			
		}

	}

	/*
	 * private int getIsSilentDetected(VmRequest profileRequest) { if
	 * (profileRequest.getIsSilentDetect() == 1) { if
	 * (profileRequest.getRecordingDuration() <= AppConfig.config.getInt(
	 * "record_timeout_" + profileRequest.getServiceType() + "", 10)) { return
	 * 1; } else if (profileRequest.getRecordingDuration() <= AppConfig.config
	 * .getInt("record_timeout_" + profileRequest.getServiceType() + "", 10) +
	 * AppConfig.config.getInt("silence_negotiation", 0)) { return 1; } else {
	 * return 0; } } else { return 0; } }
	 */

	/**
	 * return status this method is responsible for checking the record file
	 * path physically exists or not ,return true if exists otherwise false
	 * 
	 * @param recordFilePath2
	 *            if physical path of voice mail
	 * @return status return true if filepath exists otherwise false
	 * @see nothing
	 */
	private Boolean validateRecordFile(String recordFilePath2) {
		Boolean status = false;
		File file = new File(recordFilePath2);
		if (file.exists()) {
			status = true;
			file.setExecutable(true);
			file.setReadable(true);
		} else {
			status = false;
		}
		return status;
	}

}
