package com.vcc.util;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.filter.Filter;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;

public class MsisdnFileFilter implements Filter {

	final static Logger logger = Logger.getLogger(MsisdnFileFilter.class);
	
	private List<VccSubscriptionMaster> activeServiceList;

	public void setActiveServiceList(List<VccSubscriptionMaster> activeServiceList) {
		this.activeServiceList = activeServiceList;
	}
	public MsisdnFileFilter() {

	}

	
	/**
	 * return void 
	 * this method is responsible for filtering msisdn and set file path to play msisdn 
	 * @param profileRequest the variable contain bean of ProfileRequest ,which set by url request like - callingNum , calledNum ,serviceType etc  
	 * @param profileResponse the variable contain bean of  ProfileResponse , which actually return in url response like - msisdnFilePath
	 * @param vmError vmError is a bean that is used to define which type of error generate in operation
	 * @param vccServices vccServices is a bean that contain reference of interface(UserService,MessageService,UserConfigService) 
	 * @return void     
	 * @see    nothing
	 */
	public void execute(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {
		StringBuilder sb = new StringBuilder();
		String ivrBashPath = AppConfig.config.getString("ivr_digits_path");
		for(char digit: profileRequest.getCalledNumWithoutCountryCode().toCharArray()){
			if(sb.length() > 0) sb.append(",");
			sb.append(ivrBashPath);
			sb.append(File.separator);
			sb.append(AppConfig.config.getString("vms_default_language")+File.separator);
			sb.append(AppConfig.config.getString("file.path-"+digit));
		}
		profileResponse.setMsisdnFilePath(sb.toString());
		logger.debug(String.format("A-Party [%s] B-Party [%s] msisdn file list [%s]",
				profileRequest.getCallingNum(), profileRequest.getCalledNum(),sb.toString()));
	}
}
