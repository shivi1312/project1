package com.vcc.util;

import org.apache.log4j.Logger;

import com.vcc.config.AppConfig;

import edu.emory.mathcs.util.net.ConnectionPool;

public class TcpConnectionPool {
	final static Logger logger = Logger.getLogger(TcpConnectionPool.class);

	private TcpConnectionPool() {

	}

	private static ConnectionPool mcaConPool = new ConnectionPool(
			AppConfig.config.getString("mca_server_ip"),
			AppConfig.config.getInt("mca_server_port"),
			AppConfig.config.getInt("mca_socket_timeout", 15000),
			AppConfig.config.getInt("mca_server_pool_limit", 5));

	private static ConnectionPool ruleEngineConPool = new ConnectionPool(
			AppConfig.config.getString("rule_engine_ip"),
			AppConfig.config.getInt("rule_engine_port"),
			AppConfig.config.getInt("rule_engine_socket_timeout",15000),
			AppConfig.config.getInt("rule_engine_pool_limit", 5));

	public static ConnectionPool getRuleEngineConPool() {
		logger.debug("the rule engine ip ["
				+ AppConfig.config.getString("rule_engine_ip") + "] port ["
				+ AppConfig.config.getInt("rule_engine_port") + "] ");
		
		return ruleEngineConPool;
	}

	public static ConnectionPool getMcaConPool() {
		logger.debug("the mca ip ["
				+ AppConfig.config.getString("mca_server_ip") + "] port ["
				+ AppConfig.config.getInt("mca_server_port") + "]");

		return mcaConPool;
	}

}
