package com.vcc.util;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.vcc.chain.VccChain;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.request.VccMessageRequest;
import com.vcc.response.VccMessageResponse;

public class MessageCountFileFilter implements VccChain {

	final static Logger logger = Logger.getLogger(MessageCountFileFilter.class);
	@SuppressWarnings("unused")
	private VccChain nextInVmChain;
	@Autowired
	private VccServices vccServices;
	private String newMsgCountPath;
	private String oldMsgCountPath;
	private String saveMsgCountPath;

	@Override
	public void setNext(VccChain nextInVmChain, VccServices vccServices) {
		this.nextInVmChain = nextInVmChain;
		this.vccServices = vccServices;

	}

	@Override
	public void process(VccMessageRequest messageRequest,
			VccMessageResponse messageResponse, VmError vmError) {

		this.newMsgCountPath = AppConfig.config.getString("ivr_digits_path")+File.separator+messageRequest.getLang()
				+ File.separator + messageRequest.getTotalNewMsg() + ".wav";
		this.oldMsgCountPath = AppConfig.config.getString("ivr_digits_path")+File.separator+messageRequest.getLang()
				+ File.separator + messageRequest.getTotalOldMsg() + ".wav";
		this.saveMsgCountPath = AppConfig.config.getString("ivr_digits_path")+File.separator+messageRequest.getLang()
				+ File.separator + messageRequest.getTotalSaveMsg() + ".wav";

		logger.info(String
				.format("A-Party [%s] B-Party(Shortcode) [%s] SenderNum [%s] new msg [%s] old msg [%s] save msg [%s] new msg path[%s] old msg path[%s] save msg path[%s]",
						messageRequest.getCallingNum(),
						messageRequest.getCalledNum(),
						messageRequest.getSenderNum(),
						messageRequest.getTotalNewMsg(),
						messageRequest.getTotalOldMsg(),
						messageRequest.getTotalSaveMsg(),
						this.newMsgCountPath,
						this.oldMsgCountPath,
						this.saveMsgCountPath
						));
		messageResponse.setIsSuccess(1);
		messageResponse.setNewMsgCountPath(this.newMsgCountPath);
		messageResponse.setTotalNewMsg(messageRequest.getTotalNewMsg());
		messageResponse.setOldMsgCountPath(this.oldMsgCountPath);
		messageResponse.setTotalOldMsg(messageRequest.getTotalOldMsg());
		messageResponse.setSaveMsgCountPath(this.saveMsgCountPath);
		messageResponse.setTotalSaveMsg(messageRequest.getTotalSaveMsg());
		

	}

}