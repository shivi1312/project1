package com.vcc.util;

import java.io.File;
import java.util.Calendar;

import org.apache.log4j.Logger;
import org.springframework.util.FileCopyUtils;

import com.vcc.chain.VmChain;
import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.request.VmRequest;
import com.vcc.response.VmResponse;

public class CopyAndDeleteVmFile implements VmChain {

	final static Logger logger = Logger.getLogger(CopyAndDeleteVmFile.class);
	private VmChain nextInVmChain;
	@SuppressWarnings("unused")
	private VccServices vccServices;
	
	@Override
	public void setNext(VmChain nextInVmChain, VccServices vccServices) {
		this.nextInVmChain = nextInVmChain;
		this.vccServices = vccServices;
	}

	@Override
	public void process(VmRequest vmRequest, VmResponse vmResponse,
			VmError vmError) {
		String base = "C:" + File.separator + "MyData" + File.separator
				+ "content";
		String directories = base + "%s%s%s%s%s%s%s%s";
		try {
			directories = String.format(directories, File.separator, Calendar
					.getInstance().get(Calendar.YEAR), File.separator, Calendar
					.getInstance().get(Calendar.MONTH), File.separator,
					Calendar.getInstance().get(Calendar.DATE), File.separator,
					vmRequest.getCallingNum());
			File file = new File(directories);
			if (!file.exists())
				file.mkdirs();
			String destFile = directories + File.separator + "1.txt";
			File source = new File(vmRequest.getRecordFile());
			File dest = new File(destFile);
			dest.setWritable(true);
			dest.setReadable(true);
			FileCopyUtils.copy(source, dest);
			vmRequest.setRecordFile(destFile);
			logger.info(String.format(
					"A-Party [%s] B-Party [%s] saved file [%s]",
					vmRequest.getCallingNum(), vmRequest.getCalledNum(),
					destFile));
			nextInVmChain.process(vmRequest, vmResponse, vmError);
		} catch (Exception e) {
			vmResponse.setIsSuccess(-1);
			logger.info(String.format(
					"A-Party [%s] B-Party [%s] Exception [%s]",
					vmRequest.getCallingNum(), vmRequest.getCalledNum(),
					e.getMessage()));
		}
	}
}
