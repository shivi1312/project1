package com.vcc.util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.filter.Filter;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.ProfileResponse;

public class CallRecordPathFilter implements Filter {
	final static Logger logger = Logger.getLogger(CallRecordPathFilter.class);
	private String recordFileName = null;
	private String recordFilePath = null;
	private String recordTempPath = null;
	private String calledNum;
	private boolean isRecordFlow = true;
	private VccCommonOperation commonOperation = null;
	private List<VccSubscriptionMaster> activeServiceList;

	public void setActiveServiceList(
			List<VccSubscriptionMaster> activeServiceList) {
		this.activeServiceList = activeServiceList;
	}

	public CallRecordPathFilter() {

	}

	/**
	 * return void this method is responsible for generating voice mail record
	 * file path and record file name
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of profileResponse , which actually
	 *            return in url response like - isSuccess , isCallAllowed,
	 *            recordFileName,recordFilePath
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	@Override
	public void execute(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {

		//if (profileResponse.getIsCallAllowed() == 1) {
			if (profileRequest.getCalledNumWithoutCountryCode() != null
					&& profileRequest.getCalledNumWithoutCountryCode() != "") {
				this.calledNum = profileRequest
						.getCalledNumWithoutCountryCode();
				this.isRecordFlow = true;
			} else {
				this.calledNum = profileRequest.getCalledNumB();
				this.isRecordFlow = false;

			}
			String tempName = null;
			Date date = new Date();
			String nanoSec = String.valueOf(System.nanoTime());
			nanoSec = (String) nanoSec.subSequence(nanoSec.length() - 6,
					nanoSec.length());
			this.recordFileName = getDateInFormat("yy").format(date)
					+ getDateInFormat("MM").format(date)
					+ getDateInFormat("dd").format(date)
					+ getDateInFormat("HH").format(date)
					+ getDateInFormat("mm").format(date)
					+ getDateInFormat("ss").format(date) + nanoSec;
			tempName = recordFileName.substring(0, recordFileName.length()
					- AppConfig.config.getInt("default_record_digits", 10));
			commonOperation = new VccCommonOperation();
			this.recordFilePath = commonOperation.getCopletePath(tempName,
					this.calledNum, null,
					AppConfig.config.getString("ivr_record_path"));
			this.recordTempPath=commonOperation.getCompleteTempPath(AppConfig.config.getString("ivr_temp_path"), null);

			Boolean status = true;
			//status = commonOperation.createDirectory(recordFilePath);

			/*if (AppConfig.config.getBoolean("dir_create_enable", false)
					&& AppConfig.config.getBoolean("nio_used", false)) {
				status = commonOperation.createNioDirectory(recordFilePath);
			} else if (AppConfig.config.getBoolean("dir_create_enable", false)) {
				status = commonOperation.createDirectory(recordFilePath);
			} else if (!isRecordFlow) {
				status = commonOperation.createDirectory(recordFilePath);
			} else if (!AppConfig.config.getBoolean("dir_create_enable", true)) {
				this.recordTempPath = commonOperation.getCompleteTempPath(
						AppConfig.config.getString("ivr_temp_path"), null);
				status = commonOperation.createTempDirectory(recordTempPath);
			}*/
			logger.debug(String.format(
					"A-Party [%s] B-Party [%s] is call Allowed [%s] status [%s]",
					profileRequest.getCallingNum(), profileRequest.getCalledNum(),
					profileResponse.getIsCallAllowed(),status));

			if (status) {
				profileRequest.setRecordFileName(recordFileName);
				if (!AppConfig.config.getBoolean("dir_create_enable", true)
						&& isRecordFlow) {
					profileResponse.setRecordTempPath(recordTempPath);
					profileResponse.setRecordFileName(recordFileName);
					profileResponse.setRecordFilePath(recordFilePath);
					profileResponse.setInvalidDigitsSound(AppConfig.config
							.getString("ivr_common_path")
							+ File.separator
							+ profileResponse.getLang()
							+ File.separator
							+ "INVALID_CHOICE.wav");
				} else {
					profileResponse.setRecordTempPath(recordTempPath);
					profileResponse.setRecordFileName(recordFileName);
					profileResponse.setRecordFilePath(recordFilePath);
					profileResponse.setInvalidDigitsSound(AppConfig.config
							.getString("ivr_common_path")
							+ File.separator
							+ profileResponse.getLang()
							+ File.separator
							+ "INVALID_CHOICE.wav");
				}
			} else {
				logger.error("Error in Creatiing Directory ");
				profileResponse.setIsCallAllowed(0);
			}
			logger.info("[" + profileRequest.getCallingNum()
					+ "] record file name[" + recordFileName + "] file path ["
					+ recordFilePath + "]");

			commonOperation = null;
		//}
	}

	/**
	 * return status this method is responsible for create directory
	 * 
	 * @param recordDirectory
	 *            this variable contain record path of voice mail
	 * @return status return true if directory create successfully otherwise
	 *         retrun false
	 * @see nothing
	 */
	@SuppressWarnings("unused")
	private Boolean createDirectory(String recordDirectory) {
		Boolean status = false;
		try {
			File recordPath = new File(recordDirectory);
			if (recordPath.mkdirs()) {
				status = true;
			} else {
				status = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error In create directory [" + recordDirectory + "]",
					e);
			status = false;
		}
		return status;

	}

	private SimpleDateFormat getDateInFormat(String pattern) {

		SimpleDateFormat sdf = new SimpleDateFormat(pattern);

		return sdf;

	}

}
