package com.vcc.util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.request.UserConfigRequest;
import com.vcc.response.UserConfigResponse;

public class GroupNameRecordPathFilter  {
	final static Logger logger = Logger.getLogger(GroupNameRecordPathFilter.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private String recordFileName = null;
	private String recordFilePath = null;
	private String calledNum;
	private VccCommonOperation commonOperation = null;

	public GroupNameRecordPathFilter() {

	}
	/**
	 * return void 
	 * this method is responsible for generating group name record file path
	 * @param userConfigRequest the variable contain bean of UserConfigRequest ,which set by url request like - callingNum , calledNum ,serviceType etc  
	 * @param userConfigResponse the variable contain bean of  UserConfigResponse , which actually return in url response like - isSuccess , isCallAllowed, recordFileName,recordFilePath 
	 * @param vmError vmError is a bean that is used to define which type of error generate in operation
	 * @param vccServices vccServices is a bean that contain reference of interface(UserService,MessageService,UserConfigService) 
	 * @return void     
	 * @see    nothing
	 */
	public void execute(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse,
			VmError vmError, VccServices vccServices) {
		logger.info(String.format("A-Party [%s] Service Type [%s] is GroupId is[%s]  ",
				userConfigRequest.getCallingNum(), userConfigRequest.getServiceType(),userConfigRequest.getGroupId()));
		Boolean status=false;
		if (userConfigRequest.getCallingNum() != null
				&& userConfigRequest.getCallingNum() != "") {
			this.calledNum = userConfigRequest.getCallingNum();
		} else {
			this.calledNum = userConfigRequest.getCallingNum();
		}
		String tempName = null;
		Date date = new Date();
		String nanoSec = String.valueOf(System.nanoTime());
		nanoSec = (String) nanoSec.subSequence(nanoSec.length() - 6,
				nanoSec.length());
		this.recordFileName = getDateInFormat("yy").format(date)
				+ getDateInFormat("MM").format(date)
				+ getDateInFormat("dd").format(date)
				+ getDateInFormat("HH").format(date)
				+ getDateInFormat("mm").format(date)
				+ getDateInFormat("ss").format(date) + nanoSec;
		tempName = recordFileName.substring(0, recordFileName.length() - AppConfig.config.getInt("default_record_digits", 10));
		commonOperation = new VccCommonOperation();
		this.recordFilePath = commonOperation.getCopletePath(tempName,
				this.calledNum, null,
				AppConfig.config.getString("ivr_group_path"));
		
		 status = this.createDirectory(this.recordFilePath);
		if (status) {
			userConfigResponse.setRecordFileName(recordFileName);
			userConfigResponse.setRecordFilePath(recordFilePath);
			
		} else {
			userConfigResponse.setIsCallAllowed(0);
		}
		logger.info("["+userConfigRequest.getCallingNum()+"] record file name[" + recordFileName + "]file path["
				+ recordFilePath+"] file path create status ["+status+"]");
		
		commonOperation = null;
	}
	/**
	 * return status 
	 * this method is responsible for create directory 
	 * @param recordDirectory this variable contain record path of voice mail  
	 * @return status    return true if directory create successfully otherwise retrun false 
	 * @see    nothing
	 */
	private Boolean createDirectory(String recordDirectory) {
		Boolean status = false;
		try {
			File recordPath = new File(recordDirectory);
			if (!recordPath.exists()) {
				recordPath.mkdirs();
				recordPath.setExecutable(true, false);
				recordPath.setReadable(true, false);
				recordPath.setWritable(true, false);
				
				status = true;
			} else {
				status = true;
			}

		} catch (NullPointerException npe) {
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-IVRWAR-")
					+ "90003] [Null Pointer Exception in Creating Directory] Error["
					+ npe.getMessage() + "]");
			}catch (Exception e) {
				errorLogger
				.error("ErrorCode ["
						+ AppConfig.config.getString("errorcode_pattern",
								"VCC-IVRWAR-")
						+ "00009] [Exception while Creating Directory] Error["
						+ e.getMessage() + "]");
			e.printStackTrace();
			status = false;
		}
		return status;

	}

	private SimpleDateFormat getDateInFormat(String pattern) {

		SimpleDateFormat sdf = new SimpleDateFormat(pattern);

		return sdf;

	}

}
