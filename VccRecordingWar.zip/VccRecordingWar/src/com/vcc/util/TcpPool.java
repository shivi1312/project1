package com.vcc.util;

import org.apache.log4j.Logger;

import sun.util.logging.resources.logging;

import com.vcc.config.AppConfig;
import com.vcc.handler.VccSubUnScribeHandler;
import com.vcc.net.ConnectionPool;

public class TcpPool {
	final static Logger logger = Logger.getLogger(TcpPool.class);

	private TcpPool() {

	}

	private static ConnectionPool mcaConPool = new ConnectionPool(
			AppConfig.config.getString("mca_server_ip"),
			AppConfig.config.getInt("mca_server_port"),AppConfig.config.getInt("mca_server_pool_limit",5));



	private static ConnectionPool ruleEngineConPool = new ConnectionPool(
			AppConfig.config.getString("rule_engine_ip"),
			AppConfig.config.getInt("rule_engine_port"),AppConfig.config.getInt("rule_engine_pool_limit",5));

	public static ConnectionPool getRuleEngineConPool() {
		logger.info("the rule engine ip ["
				+ AppConfig.config.getString("rule_engine_ip") + "] port ["
				+ AppConfig.config.getInt("rule_engine_port") + "]");
		return ruleEngineConPool;
	}

	public static ConnectionPool getMcaConPool() {
		logger.info("the mca ip ["
				+ AppConfig.config.getString("mca_server_ip") + "] port ["
				+ AppConfig.config.getInt("mca_server_port") + "]");
		return mcaConPool;
	}

}
