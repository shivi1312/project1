package com.vcc.util;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.filter.Filter;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;

public class CountryCodeFilter implements Filter {

	final static Logger logger = Logger.getLogger(CountryCodeFilter.class);
	VccCommonOperation commonOperation = null;

	public CountryCodeFilter() {

	}

	/**
	 * return void this method is responsible for add country code if callingNum
	 * and calledNum not contain country code and if callingNum and calledNum
	 * contain country code than remove country code from callingNum and
	 * calledNum and set in profile request bean
	 * 	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum etc
	 * @param profileResponse
	 *            the variable contain bean of profileResponse , which actually
	 *            return in url response like - isSuccess , isCallAllowed,
	 *            isSubscriber
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void execute(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {
		commonOperation = new VccCommonOperation();
		commonOperation.addAndRemoveCountryCode(profileRequest);

		logger.info(String.format(
				"A-Party [%s] B-Party [%s] check country code",
				profileRequest.getCallingNum(), profileRequest.getCalledNum()));
		commonOperation = null;
	}

}
