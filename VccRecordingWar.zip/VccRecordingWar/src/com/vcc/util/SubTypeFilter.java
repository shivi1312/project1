package com.vcc.util;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.filter.Filter;
import com.vcc.model.VccSeriesRange;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;

/*
 * Check configuration for call is allowed or not
 * 1. Check user exist with in the given range
 * 2. Check user have any class type
 * */
public class SubTypeFilter implements Filter {

	final static Logger logger = Logger.getLogger(SubTypeFilter.class);

	private List<VccSeriesRange> seriesRangesList;
	private List<VccSubscriptionMaster> activeServiceList;

	public SubTypeFilter() {

	}

	public void setActiveServiceList(List<VccSubscriptionMaster> activeServiceList) {
		this.activeServiceList = activeServiceList;
	}

	/**
	 * return void this method is check whether calledNum is white listed or not
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of profileResponse , which actually
	 *            return in url response like - isSuccess , isCallAllowed,
	 *            isSubscriber
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)	 * @return void
	 * @see nothing
	 */
	@Override
	public void execute(ProfileRequest profileRequest, BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {

		this.checkSubcriberTypeProcess(profileRequest, profileResponse, vccServices);

		Boolean isSub = false;

		if (profileResponse.getSubType().equalsIgnoreCase("F")) {
			isSub = this.processActiveSubscriberList(this.activeServiceList);
			if (isSub) {
				profileResponse.setIsCallAllowed(1);
				logger.trace("calling ["+profileRequest.getCallingNum()+"] called ["+profileRequest.
						getCalledNum()+"] service ["+profileRequest.getServiceType()+"] isSub["+isSub+"] isCallAllowed["+profileResponse.getIsCallAllowed()+"] user is already a subscriber !!..");
			} else {
				profileResponse.setIsCallAllowed(0);
				logger.warn("calling ["+profileRequest.getCallingNum()+"] called ["+profileRequest.
						getCalledNum()+"] service ["+profileRequest.getServiceType()+"] isSub["+isSub+"] isCallAllowed["+profileResponse.getIsCallAllowed()+"] user is not a subscriber !..");
			}
		}
		logger.info("calling ["+profileRequest.getCallingNum()+"] called ["+profileRequest.
				getCalledNum()+"] service ["+profileRequest.getServiceType()+"] call allowed ["+
				AppConfig.config.getString(profileResponse.getIsCallAllowed() + "_call_allowed","" +
				profileResponse.getIsCallAllowed())+"] active services ["+(this.activeServiceList!=null)+
				"]check call allowed or not");
	}
	private Boolean processActiveSubscriberList(List<VccSubscriptionMaster> activeServiceList2) {
		if (activeServiceList2 != null) {
			return true;
		} else {
			return false;
		}

	}
	public void checkSubcriberTypeProcess(ProfileRequest profileRequest, ProfileResponse profileResponse,
			VccServices vccServices) {

		boolean isExistWithInSeries = false;
		String groupName = "fixedline";
		VccCommonOperation commonOperation = new VccCommonOperation();
		isExistWithInSeries = commonOperation.isExistWithinGroup(profileRequest.getCalledNum(), groupName);
		if (isExistWithInSeries) {
			profileResponse.setSubType("F");
		} else {
			profileResponse.setSubType(AppConfig.config.getString("default_sub_type", "N"));
		}

	}

	@SuppressWarnings("unused")
	private boolean checkFixedList() {

		boolean status = false;

		for (VccSeriesRange vccSeriesRange : this.seriesRangesList) {

			if (vccSeriesRange.getGroupName().equalsIgnoreCase("fixedline")) {
				logger.debug(" user in fixedline list ");
				status = true;
				break;
			} else {
				logger.debug(" user is not in fixedline list ");
				status = false;

			}
		}

		return status;
	}

}
