package com.vcc.factory;

import java.util.List;

import org.apache.log4j.Logger;

import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.model.VccServiceProvider;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.services.McaServicing;
import com.vcc.services.Servicing;
import com.vcc.services.VoiceMailServicing;
import com.vcc.services.VoiceNoteServicing;

public class ServicingFactory {

	final static Logger logger = Logger.getLogger(ServicingFactory.class);
	private List<VccSubscriptionMaster> activeBackerList;
	@SuppressWarnings("unused")
	private List<VccServiceProvider> serviceList;
	private VccServiceProvider serviceProvider;
	private VccSubscriptionMaster backer;
	private ProfileRequest profileRequest;
	@SuppressWarnings("unused")
	private ProfileResponse profileResponse;
	List<VccSubscriptionMaster> activeServiceList;

	public ServicingFactory(ProfileRequest profileRequest,
			ProfileResponse profileResponse, VmError vmError,
			VccServices vccServices, List<VccSubscriptionMaster> activeBackerList,
			List<VccServiceProvider> serviceList,List<VccSubscriptionMaster> activeServiceList) {
		this.activeBackerList = activeBackerList;
		this.serviceList = serviceList;
		this.profileRequest = profileRequest;
		this.profileResponse = profileResponse;
		this.activeServiceList = activeServiceList;
	}
	/**
	 * return Servicing  three type of object according to service type of calledNum
	 * this method is used to check which type of serviceType active for calledNum
	 * @param serviceProvider
	 *         this bean class not using now it use in future 
	 * @return Servicing this return three type of object(VoiceNoteServicing,VoiceMailServicing,McaServicing) according to calledNum profile 
	 * @see nothing
	 */
	public Servicing getBackerType(VccServiceProvider serviceProvider) {
		this.serviceProvider = serviceProvider;
		this.backer = this.getBacker();
		if (this.backer == null) {
			return null;
		}
		if (this.backer.getServiceType().equals(AppConfig.config.getString("VM", "0010"))) {
			logger.debug(String.format(
					"A-Party [%s] B-Party [%s] active service [%s]",
					profileRequest.getCallingNum(),
					profileRequest.getCalledNum(),
					AppConfig.config.getString(backer.getServiceType()
							+ "_service_name", "Voice Mail")));
			return new VoiceMailServicing(serviceProvider, backer,this.activeBackerList);
		} else if (this.backer.getServiceType().equals(AppConfig.config.getString(
				"VN", "0100"))) {
			logger.debug(String.format(
					"A-Party [%s] B-Party [%s] active service [%s]",
					profileRequest.getCallingNum(),
					profileRequest.getCalledNum(),
					AppConfig.config.getString(backer.getServiceType()
							+ "_service_name", "Voice Note")));
					profileRequest.setServiceType("0100");
			return new VoiceNoteServicing(serviceProvider, backer,this.activeBackerList);
		} else if (this.backer.getServiceType().equals(AppConfig.config.getString(
				"MCA", "0001"))) {
			logger.debug(String.format(
					"A-Party [%s] B-Party [%s] active service [%s]",
					profileRequest.getCallingNum(),
					profileRequest.getCalledNum(),
					AppConfig.config.getString(backer.getServiceType()
							+ "_service_name", "Mca")));
			return new McaServicing(serviceProvider, backer,this.activeBackerList);
		}
		return null;

	}
	/**
	 * return service  this method return calledNum  details in VccSubscriptionMaster bean 
	 * @return service this return calledNum details  
	 * @see nothing
	 */
	private VccSubscriptionMaster getBacker() {
		try {
			for (VccSubscriptionMaster service : this.activeBackerList) {
				if (this.serviceProvider.getServiceOffer().equals(
						AppConfig.config.getString(service.getServiceType()))) {
					return service;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

}
