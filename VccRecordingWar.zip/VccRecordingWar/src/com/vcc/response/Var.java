package com.vcc.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement(name = "var")
@XmlAccessorType(XmlAccessType.FIELD)
public class Var implements java.io.Serializable {

	@XmlAttribute(required = true)
	private String name;
	@XmlAttribute(required = true)
	private String value;

	public Var() {

	}

	public Var(String name, String value) {
		super();
		this.name = name;
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
