package com.vcc.response;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlTransient;


@XmlRootElement(name = "response")
@XmlSeeAlso(Var.class)
@XmlAccessorType(XmlAccessType.FIELD)
public class UserConfigResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@XmlTransient
	private int lang;
	@XmlTransient
	private int ratePlan;
	@XmlTransient
	private String subType;
	@XmlTransient
	private int classType;
	@XmlTransient
	private int greetingType;
	@XmlTransient
	private String msisdnFilePath;
	@XmlTransient
	private int isMailBoxFull;
	@XmlTransient
	private int isSuccess;
	@XmlTransient
	private int isCallAllowed;
	@XmlTransient
	private int isVoiceMailDeleted;
	@XmlTransient
	private String serviceType;
	@XmlTransient
	private boolean isActive;
	@XmlTransient
	private String recordFileName;
	@XmlTransient
	private String recordFilePath;
	@XmlTransient
	private String invalidDigitsSound;
	@XmlTransient
	private String groupPath;
	@XmlTransient
	private int groupId;
	@XmlTransient
	private int isSubscriber;
	@XmlTransient
	private int frndCount;
	@XmlTransient
	private int groupCount;
	@XmlTransient
	private String groupCountPath;
	@XmlTransient
	private int isGlimitFull;
	@XmlTransient
	private String available;
	@XmlTransient
	private int nxtIndex;
	@XmlTransient
	private int prvIndex;
	@XmlTransient
	private String frndMsisdn;
	@XmlTransient
	private String pointer;
	@XmlTransient
	private int recordTimeout;
	@XmlTransient
	private int recordLength;
	@XmlTransient
	private int notiFlag;
	@XmlTransient
	private int altFlag;
	@XmlTransient
	private int inputCount;
	@XmlTransient
	private int headerFlag;
	
	@XmlElement(name="var")
	Var varFrndCnt;
	@XmlElement(name = "var")
	Var varLang;
	@XmlElement(name = "var")
	Var varRatePlan;
	@XmlElement(name = "var")
	Var varSubType;
	@XmlElement(name = "var")
	Var varClassType;
	@XmlElement(name = "var")
	Var varGreetingType;
	@XmlElement(name = "var")
	Var varMsisdnFilePath;
	@XmlElement(name = "var")
	Var varIsMailBoxFull;
	@XmlElement(name = "var")
	Var varIsSuccess;
	@XmlElement(name = "var")
	Var varIsCallAllowed;
	@XmlElement(name = "var")
	Var varIsVoiceMailDeleted;
	@XmlElement(name = "var")
	Var varServiceType;
	@XmlElement(name = "var")
	Var varRecordFileName;
	@XmlElement(name = "var")
	Var varRecordFilePath;
	@XmlElement(name = "var")
	Var varInvalidDigitsSound;
	@XmlElement(name = "var")
	Var varGroupPath;
	@XmlElement(name = "var")
	Var varGroupId;
	@XmlElement(name = "var")
	Var varIsSubscriber;
	@XmlElement(name = "var")
	Var varAvaliable;
	@XmlElement(name = "var")
	Var varNxtIndex;
	@XmlElement(name = "var")
	Var varPrvIndex;
	@XmlElement(name = "var")
	Var varFrndMsisdn;
	@XmlElement(name = "var")
	Var varPointer;
	@XmlElement(name = "var")
	Var varRecordTimeout;
	@XmlElement(name = "var")
	Var varRecordLength;
	@XmlElement(name = "var")
	Var varNotiFlag;
	@XmlElement(name = "var")
	Var varAltFlag;
	@XmlElement(name = "var")
	Var varGroupCount;
	@XmlElement(name = "var")
	Var varGroupCountPath;
	@XmlElement(name = "var")
	Var varIsGlimitFull;
	@XmlElement(name = "var")
	Var varInputCount;
	@XmlElement(name = "var")
	Var varHeaderFlag;
	
	
	public int getHeaderFlag() {
		return headerFlag;
	}

	public void setHeaderFlag(int headerFlag) {
		varHeaderFlag = new Var("headerFlag",""+ headerFlag);
		this.headerFlag = headerFlag;
	}
	
	public int getInputCount() {
		return inputCount;
	}

	public void setInputCount(int inputCount) {
		this.inputCount = inputCount;
		varInputCount  = new Var("inputCount", ""+inputCount);
	}

	public int getIsGlimitFull() {
		return isGlimitFull;
	}

	public void setIsGlimitFull(int isGlimitFull) {
		this.isGlimitFull = isGlimitFull;
		varIsGlimitFull = new Var("isGlimitFull", ""+isGlimitFull);
	}

	public int getGroupCount() {
		return groupCount;
	}

	public void setGroupCount(int groupCount) {
		this.groupCount = groupCount;
		varGroupCount = new Var("groupCount", ""+groupCount);
	}

	public String getGroupCountPath() {
		return groupCountPath;
	}

	public void setGroupCountPath(String groupCountPath) {
		this.groupCountPath = groupCountPath;
		varGroupCountPath = new Var("groupCountPath", groupCountPath);
	}

	public String getGroupPath() {
		return groupPath;
	}

	public void setGroupPath(String groupPath) {
		varGroupPath = new Var("groupPath", groupPath);
		this.groupPath = groupPath;
	}

	public int getFrndCount() {
		return frndCount;
	}

	public void setFrndCount(int frndCount) {
		varFrndCnt = new Var("frndCount", ""+frndCount);
		this.frndCount = frndCount;
	}


	public int getNotiFlag() {
		return notiFlag;
	}

	public void setNotiFlag(int notiFlag) {
		varNotiFlag = new Var("notiFlag", ""+notiFlag);
		this.notiFlag = notiFlag;
	}

	public int getAltFlag() {
		return altFlag;
	}

	public void setAltFlag(int altFlag) {
		varAltFlag = new Var("altFlag", ""+altFlag);
		this.altFlag = altFlag;
	}

	public int getRecordTimeout() {
		return recordTimeout;
	}

	public void setRecordTimeout(int recordTimeout) {
		this.recordTimeout = recordTimeout;
		varRecordTimeout = new Var("recordTimeout",""+ recordTimeout);
	}

	public int getRecordLength() {
		return recordLength;
	}

	public void setRecordLength(int recordLength) {
		this.recordLength = recordLength;
		varRecordLength = new Var("recordLength",""+ recordLength);
	}
	
	public int getLang() {
		return lang;
	}

	public void setLang(int lang) {
		this.lang = lang;
		varLang = new Var("lang", "" + lang);
	}

	public int getRatePlan() {
		return ratePlan;
	}

	public void setRatePlan(int ratePlan) {
		this.ratePlan = ratePlan;
		varRatePlan = new Var("ratePlan", "" + ratePlan);
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
		varSubType = new Var("subType", "" + subType);
	}

	public int getClassType() {
		return classType;
	}

	public void setClassType(int classType) {
		this.classType = classType;
		varClassType = new Var("classType", "" + classType);
	}

	public int getGreetingType() {
		return greetingType;
	}

	public void setGreetingType(int greetingType) {
		this.greetingType = greetingType;
		varGreetingType = new Var("greetingType", "" + greetingType);
	}

	public String getMsisdnFilePath() {
		return msisdnFilePath;
	}

	public void setMsisdnFilePath(String msisdnFilePath) {
		this.msisdnFilePath = msisdnFilePath;
		varMsisdnFilePath = new Var("msisdnFilePath", "" + msisdnFilePath);
	}

	public int getIsMailBoxFull() {
		return isMailBoxFull;
	}

	public void setIsMailBoxFull(int isMailBoxFull) {
		this.isMailBoxFull = isMailBoxFull;
		varIsMailBoxFull = new Var("isMailBoxFull", "" + isMailBoxFull);
	}

	public int getIsSuccess() {
		return isSuccess;
	}

	public void setIsSuccess(int isSuccess) {
		this.isSuccess = isSuccess;
		varIsSuccess = new Var("isSuccess", "" + isSuccess);
	}

	public int getIsCallAllowed() {
		return isCallAllowed;
	}

	public void setIsCallAllowed(int isCallAllowed) {
		this.isCallAllowed = isCallAllowed;
		varIsCallAllowed = new Var("isCallAllowed", "" + isCallAllowed);
	}

	public int getIsVoiceMailDeleted() {
		return isVoiceMailDeleted;
	}

	public void setIsVoiceMailDeleted(int isVoiceMailDeleted) {
		this.isVoiceMailDeleted = isVoiceMailDeleted;
		varIsVoiceMailDeleted = new Var("isVoiceMailDeleted", ""
				+ isVoiceMailDeleted);
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
		varServiceType = new Var("serviceType", "" + serviceType);
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getRecordFileName() {
		return recordFileName;
	}

	public void setRecordFileName(String recordFileName) {
		this.recordFileName = recordFileName;
		varRecordFileName = new Var("recordFileName", "" + recordFileName);
	}

	public String getRecordFilePath() {
		return recordFilePath;
	}

	public void setRecordFilePath(String recordFilePath) {
		this.recordFilePath = recordFilePath;
		varRecordFilePath = new Var("recordFilePath", "" + recordFilePath);
	}

	public String getInvalidDigitsSound() {
		return invalidDigitsSound;
	}

	public void setInvalidDigitsSound(String invalidDigitsSound) {
		this.invalidDigitsSound = invalidDigitsSound;
		varInvalidDigitsSound = new Var("invalidDigitsSound", "" + invalidDigitsSound);
	}

	public String getgroupPath() {
		return groupPath;
	}

	public void setgroupPath(String groupPath) {
		this.groupPath = groupPath;
		varGroupPath = new Var("groupPath", ""+groupPath);
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
		varGroupId= new Var("groupId", ""+groupId);
	}
	
	public int getIsSubscriber() {
		return isSubscriber;
	}

	public void setIsSubscriber(int isSubscriber) {
		this.isSubscriber = isSubscriber;
		varIsSubscriber = new Var("isSubscriber", "" + isSubscriber);
	}
		
	
	public int getFrndCnt() {
		return frndCount;
	}
	public void setFrndCnt(int frndCount) {
		this.frndCount = frndCount;
		varFrndCnt = new Var("frndCount", String.valueOf(frndCount));
	}

	public int getNxtIndex() {
		return nxtIndex;
	}

	public void setNxtIndex(int nxtIndex) {
		this.nxtIndex = nxtIndex;
		varNxtIndex = new Var("nxtIndex", ""+nxtIndex);
	}

	public int getPrvIndex() {
		return prvIndex;
	}

	public void setPrvIndex(int prvIndex) {
		this.prvIndex = prvIndex;
		varPrvIndex = new Var("prvIndex", ""+prvIndex);
	}

	

	public String getFrndMsisdn() {
		return frndMsisdn;
	}

	public void setFrndMsisdn(String frndMsisdn) {
		this.frndMsisdn = frndMsisdn;
		varFrndMsisdn = new Var("frndMsisdn", ""+frndMsisdn);
	}

	public String getAvailable() {
		return available;
	}

	public void setAvailable(String available) {
		this.available = available;
		varAvaliable = new Var("available", ""+available);
	}

	

	public String getPointer() {
		return pointer;
	}

	public void setPointer(String pointer) {
		this.pointer = pointer;
		varPointer = new Var("pointer", ""+pointer);
	}
	
}
