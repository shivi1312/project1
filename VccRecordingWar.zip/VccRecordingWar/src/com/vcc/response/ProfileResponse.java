package com.vcc.response;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlTransient;

import com.vcc.model.VccVoiceMessage;

@XmlRootElement(name = "response")
@XmlSeeAlso(Var.class)
@XmlAccessorType(XmlAccessType.FIELD)
public class ProfileResponse implements java.io.Serializable {

	private static final long serialVersionUID = -2805877486785914575L;
	@XmlTransient
	private int lang;
	@XmlTransient
	private int ratePlan;
	@XmlTransient
	private String subType;
	@XmlTransient
	private int classType;
	@XmlTransient
	private int greetingType;
	@XmlTransient
	private String msisdnFilePath;
	@XmlTransient
	private int isMailBoxFull;
	@XmlTransient
	private int isSuccess;
	@XmlTransient
	private int isCallAllowed;
	@XmlTransient
	private int isVoiceMailDeleted;
	@XmlTransient
	private String serviceType;
	@XmlTransient
	private boolean isActive;
	@XmlTransient
	private String recordFileName;
	@XmlTransient
	private String recordFilePath;
	@XmlTransient
	private String recordTempPath;
	@XmlTransient
	private String invalidDigitsSound;
	@XmlTransient
	private int isUserIsOptedOut;
	@XmlTransient
	private int isNotifyMeWithMCM;
	@XmlTransient
	private int isSubscriber;
	@XmlTransient
	private String greetPath;
	@XmlTransient
	private int msisdnLength;
	@XmlTransient
	private int altFlag;
	@XmlTransient
	private int notiFlag;
	@XmlTransient
	private int headerFlag;
	@XmlTransient
	private int recordTimeout;
	@XmlTransient
	private int recordLength;
	@XmlTransient
	private String  callingNum;
	@XmlTransient
	private String calledNum;
	@XmlTransient
	private String  password;
	@XmlTransient
	private int  isNew;
	@XmlTransient
	private int isMigrating;
	@XmlTransient
	private String status="P";
	@XmlTransient
	private String planName="D";
	@XmlTransient
	private int isIntNo=0;
	@XmlTransient
	private int isMultiLang;
	@XmlElement(name = "var")
	Var multiLang;
	@XmlElement(name = "var")
	Var varLang;
	@XmlElement(name = "var")
	Var varRatePlan;
	@XmlElement(name = "var")
	Var varSubType;
	@XmlElement(name = "var")
	Var varClassType;
	@XmlElement(name = "var")
	Var varGreetingType;
	@XmlElement(name = "var")
	Var varMsisdnFilePath;
	@XmlElement(name = "var")
	Var varIsMailBoxFull;
	@XmlElement(name = "var")
	Var varIsSuccess;
	@XmlElement(name = "var")
	Var varIsCallAllowed;
	@XmlElement(name = "var")
	Var varIsVoiceMailDeleted;
	@XmlElement(name = "var")
	Var varServiceType;
	@XmlElement(name = "var")
	Var varRecordFileName;
	@XmlElement(name = "var")
	Var varRecordTempPath;
	@XmlElement(name = "var")
	Var varRecordFilePath;
	@XmlElement(name = "var")
	Var varInvalidDigitsSound;
	@XmlElement(name = "var")
	Var varIsUserIsOptedOut;
	@XmlElement(name = "var")
	Var varIsNotifyMeWithMCM;
	@XmlElement(name = "var")
	Var varIsSubscriber;
	@XmlElement(name = "var")
	Var varGreetParh;
	@XmlElement(name = "var")
	Var varMsisdnLength;
	@XmlElement(name = "var")
	Var varAltFlag;
	@XmlElement(name = "var")
	Var varNotiFlag;
	@XmlElement(name = "var")
	Var varHeaderFlag;
	@XmlElement(name = "var")
	Var varRecordTimeout;
	@XmlElement(name = "var")
	Var varRecordLength;
	@XmlElement(name = "var")
	Var varCallingNum;
	@XmlElement(name = "var")
	Var varCalledNum;
	@XmlElement(name = "var")
	Var varPassword;
	@XmlElement(name = "var")
	Var varIsNew;
	@XmlElement(name = "var")
	Var varIsMigrating;
	@XmlElement(name = "var")
	Var varStatus;
	@XmlElement(name = "var")
	Var varPlanName;
	@XmlElement(name = "var")
	Var varIsIntNo;
	
	
	private boolean voiceNoteActive=true;
	private int isSilentDetect;
	
	
	public int getIsSilentDetect() {
		return isSilentDetect;
	}

	public void setIsSilentDetect(int isSilentDetect) {
		this.isSilentDetect = isSilentDetect;
	}

	public boolean isVoiceNoteActive() {
		return voiceNoteActive;
	}

	public void setVoiceNoteActive(boolean voiceNoteActive) {
		this.voiceNoteActive = voiceNoteActive;
	}

	private List<VccVoiceMessage> vccList;
	
	
	public int getHeaderFlag() {
		return headerFlag;
	}

	public void setHeaderFlag(int headerFlag) {
		varHeaderFlag = new Var("headerFlag",""+ headerFlag);
		this.headerFlag = headerFlag;
	}

	public int getIsIntNo() {
		return isIntNo;
	}

	public void setIsIntNo(int isIntNo) {
		this.isIntNo = isIntNo;
		varIsIntNo = new Var("isIntNo",""+ isIntNo);
	}

	
	
	public int getRecordTimeout() {
		return recordTimeout;
	}

	public void setRecordTimeout(int recordTimeout) {
		this.recordTimeout = recordTimeout;
		varRecordTimeout = new Var("recordTimeout",""+ recordTimeout);
	}

	public int getRecordLength() {
		return recordLength;
	}

	public void setRecordLength(int recordLength) {
		this.recordLength = recordLength;
		varRecordLength = new Var("recordLength",""+ recordLength);
	}

	public int getAltFlag() {
		return altFlag;
	}

	public void setAltFlag(int altFlag) {
		this.altFlag = altFlag;
		varAltFlag = new Var("altFlag", "" + altFlag);
	}

	public int getNotiFlag() {
		return notiFlag;
	}

	public void setNotiFlag(int notiFlag) {
		this.notiFlag = notiFlag;
		varNotiFlag = new Var("notiFlag", "" + notiFlag);
	}

	public int getLang() {
		return lang;
	}

	public void setLang(int lang) {
		this.lang = lang;
		varLang = new Var("lang", "" + lang);
	}

	public int getIsMultiLang() {
		return isMultiLang;
	}

	public void setIsMultiLang(int isMultiLang) {
		this.isMultiLang = isMultiLang;
		multiLang = new Var("multiLang", "" + isMultiLang);
	}

	public int getRatePlan() {
		return ratePlan;
	}

	public void setRatePlan(int ratePlan) {
		this.ratePlan = ratePlan;
		varRatePlan = new Var("ratePlan", "" + ratePlan);
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
		varSubType = new Var("subType", "" + subType);
	}

	public int getClassType() {
		return classType;
	}

	public void setClassType(int classType) {
		this.classType = classType;
		varClassType = new Var("classType", "" + classType);
	}

	public int getGreetingType() {
		return greetingType;
	}

	public void setGreetingType(int greetingType) {
		this.greetingType = greetingType;
		varGreetingType = new Var("greetingType", "" + greetingType);
	}

	public String getMsisdnFilePath() {
		return msisdnFilePath;
	}

	public void setMsisdnFilePath(String msisdnFilePath) {
		this.msisdnFilePath = msisdnFilePath;
		varMsisdnFilePath = new Var("msisdnFilePath", "" + msisdnFilePath);
	}

	public int getIsMailBoxFull() {
		return isMailBoxFull;
	}

	public void setIsMailBoxFull(int isMailBoxFull) {
		this.isMailBoxFull = isMailBoxFull;
		varIsMailBoxFull = new Var("isMailBoxFull", "" + isMailBoxFull);
	}

	public int getIsSuccess() {
		return isSuccess;
	}

	public void setIsSuccess(int isSuccess) {
		this.isSuccess = isSuccess;
		varIsSuccess = new Var("isSuccess", "" + isSuccess);
	}

	public int getIsCallAllowed() {
		return isCallAllowed;
	}

	public void setIsCallAllowed(int isCallAllowed) {
		this.isCallAllowed = isCallAllowed;
		varIsCallAllowed = new Var("isCallAllowed", "" + isCallAllowed);
	}

	public int getIsVoiceMailDeleted() {
		return isVoiceMailDeleted;
	}

	public void setIsVoiceMailDeleted(int isVoiceMailDeleted) {
		this.isVoiceMailDeleted = isVoiceMailDeleted;
		varIsVoiceMailDeleted = new Var("isVoiceMailDeleted", ""
				+ isVoiceMailDeleted);
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
		varServiceType = new Var("serviceType", "" + serviceType);
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getRecordFileName() {
		return recordFileName;
	}

	public void setRecordFileName(String recordFileName) {
		this.recordFileName = recordFileName;
		varRecordFileName = new Var("recordFileName", "" + recordFileName);
	}

	public String getRecordFilePath() {
		return recordFilePath;
	}

	public void setRecordFilePath(String recordFilePath) {
		this.recordFilePath = recordFilePath;
		varRecordFilePath = new Var("recordFilePath", "" + recordFilePath);
	}
	
	public String getRecordTempPath() {
		return recordTempPath;
	}

	public void setRecordTempPath(String recordTempPath) {
		this.recordTempPath = recordTempPath;
		varRecordTempPath = new Var("recordTempPath", "" + recordTempPath);
	}

	public String getInvalidDigitsSound() {
		return invalidDigitsSound;
	}

	public void setInvalidDigitsSound(String invalidDigitsSound) {
		this.invalidDigitsSound = invalidDigitsSound;
		varInvalidDigitsSound = new Var("invalidDigitsSound", "" + invalidDigitsSound);
	}

	public int getIsUserIsOptedOut() {
		return isUserIsOptedOut;
	}

	public void setIsUserIsOptedOut(int isUserIsOptedOut) {
		this.isUserIsOptedOut = isUserIsOptedOut;
		varIsUserIsOptedOut = new Var("isUserIsOptedOut", ""+isUserIsOptedOut);
	}

	public int getIsNotifyMeWithMCM() {
		return isNotifyMeWithMCM;
	}

	public void setIsNotifyMeWithMCM(int isNotifyMeWithMCM) {
		this.isNotifyMeWithMCM = isNotifyMeWithMCM;
		varIsNotifyMeWithMCM= new Var("isNotifyMeWithMCM", ""+isNotifyMeWithMCM);
	}
	
	public int getIsSubscriber() {
		return isSubscriber;
	}

	public void setIsSubscriber(int isSubscriber) {
		this.isSubscriber = isSubscriber;
		varIsSubscriber = new Var("isSubscriber", "" + isSubscriber);
	}

	public String getGreetPath() {
		return greetPath;
	}

	public void setGreetPath(String greetPath) {
		this.greetPath = greetPath;
		varGreetParh = new Var("greetPath", greetPath);
	}

	public int getMsisdnLength() {
		return msisdnLength;
	}

	public void setMsisdnLength(int msisdnLength) {
		this.msisdnLength = msisdnLength;
		varMsisdnLength = new Var("msisdnLength", ""+msisdnLength);
	}

	public String getCallingNum() {
		return callingNum;
	}

	public void setCallingNum(String callingNum) {
		this.callingNum = callingNum;
		varCallingNum = new Var("callingNum", callingNum);
	}

	public String getCalledNum() {
		return calledNum;
	}

	public void setCalledNum(String calledNum) {
		this.calledNum = calledNum;
		varCalledNum = new Var("calledNum", calledNum);
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
		varPassword = new Var("password", password);
	}

	public int getIsNew() {
		return isNew;
	}

	public void setIsNew(int isNew) {
		this.isNew = isNew;
		varIsNew = new Var("isNew", ""+isNew);
	}

	public int getIsMigrating() {
		return isMigrating;
	}

	public void setIsMigrating(int isMigrating) {
		this.isMigrating = isMigrating;
		varIsMigrating = new Var("isMigrating", ""+isMigrating);
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
		varStatus = new Var("status", status);
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
		varPlanName = new Var("planName", planName);
	}

	public List<VccVoiceMessage> getVccList() {
		return vccList;
	}

	public void setVccList(List<VccVoiceMessage> vccList) {
		this.vccList = vccList;
	}
	
	
}
