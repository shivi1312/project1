package com.vcc.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlValue;


@XmlRootElement(name = "response")
@XmlSeeAlso(Var.class)
@XmlAccessorType(XmlAccessType.FIELD)
public class VmResponse implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@XmlTransient
	private int isSuccess;
	@XmlElement(name="var")
	Var varIsSuccess;
	@XmlTransient
	private int isSilentDetect;
	@XmlElement(name="var")
	Var varIsSilentDetect;
	
	
	
	public int getIsSilentDetect() {
		return isSilentDetect;
	}

	public void setIsSilentDetect(int isSilentDetect) {
		this.isSilentDetect = isSilentDetect;
		varIsSilentDetect = new Var("isSilentDetect", ""+isSilentDetect);
	}

	public int getIsSuccess() {
		return isSuccess;
	}
	
	@XmlValue
	public void setIsSuccess(int isSuccess) {
		this.isSuccess = isSuccess;
		varIsSuccess = new Var("isSuccess", ""+isSuccess);
	}
	
}
