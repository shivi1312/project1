package com.vcc.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement(name = "response")
@XmlSeeAlso(Var.class)
@XmlAccessorType(XmlAccessType.FIELD)
public class VccMessageResponse implements java.io.Serializable {

	private static final long serialVersionUID = -2805877486785914575L;
	@XmlTransient
	private int totalNewMsg;
	@XmlTransient
	private int totalOldMsg;
	@XmlTransient
	private int totalSaveMsg;
	@XmlTransient
	private String newMsgCountPath;
	@XmlTransient
	private String oldMsgCountPath;
	@XmlTransient
	private String saveMsgCountPath;
	@XmlTransient
	private String greetingPath;
	@XmlTransient
	private String msgPath;
	@XmlTransient
	private String available;
	@XmlTransient
	private int nxtIndex;
	@XmlTransient
	private int prvIndex;
	@XmlTransient
	private String senderNum;
	@XmlTransient
	private int isSuccess;
	@XmlTransient
	private int msgIndex;
	@XmlTransient
	private String pointer;
	@XmlTransient
	private int msgDuration;
	
	
	@XmlElement(name = "var")
	Var varTotalNewMsg;
	@XmlElement(name = "var")
	Var varTotalOldMsg;
	@XmlElement(name = "var")
	Var varTotalSaveMsg;
	@XmlElement(name = "var")
	Var varNewMsgCountPath;
	@XmlElement(name = "var")
	Var varOldMsgCountPath;
	@XmlElement(name = "var")
	Var varSaveMsgCountPath;
	@XmlElement(name = "var")
	Var varGreetingPath;
	@XmlElement(name = "var")
	Var varMsgPath;
	@XmlElement(name = "var")
	Var varAvailable;
	@XmlElement(name = "var")
	Var varNxtIndex;
	@XmlElement(name = "var")
	Var varIsSuccess;
	@XmlElement(name = "var")
	Var varPrvIndex;
	@XmlElement(name = "var")
	Var varSenderNum;
	@XmlElement(name = "var")
	Var varPointer;
	@XmlElement(name = "var")
	Var varMsgIndex;
	@XmlElement(name = "var")
	Var varMsgDuration;
	
	
	
	public int getMsgDuration() {
		return msgDuration;
	}

	public void setMsgDuration(int msgDuration) {
		this.msgDuration = msgDuration;
		varMsgDuration = new Var("msgDuration", ""+msgDuration);
	}

	public int getIsSuccess() {
		return isSuccess;
	}

	public void setIsSuccess(int isSuccess) {
		this.isSuccess = isSuccess;
		varIsSuccess = new Var("isSuccess", "" + isSuccess);
	}

	public int getTotalNewMsg() {
		return totalNewMsg;
	}

	public void setTotalNewMsg(int totalNewMsg) {
		this.totalNewMsg = totalNewMsg;
		varTotalNewMsg= new Var("totalNewMsg", ""+totalNewMsg);
	}

	public int getTotalOldMsg() {
		return totalOldMsg;
	}

	public void setTotalOldMsg(int totalOldMsg) {
		this.totalOldMsg = totalOldMsg;
		varTotalOldMsg = new Var("totalOldMsg",""+totalOldMsg);
	}

	public String getNewMsgCountPath() {
		return newMsgCountPath;
	}

	public void setNewMsgCountPath(String newMsgCountPath) {
		this.newMsgCountPath = newMsgCountPath;
		varNewMsgCountPath = new Var("newMsgCountPath", ""+newMsgCountPath);
	}

	public String getOldMsgCountPath() {
		return oldMsgCountPath;
	}

	public void setOldMsgCountPath(String oldMsgCountPath) {
		this.oldMsgCountPath = oldMsgCountPath;
		varOldMsgCountPath = new Var("oldMsgCountPath",""+oldMsgCountPath);
	}

	public String getGreetingPath() {
		return greetingPath;
	}

	public void setGreetingPath(String greetingPath) {
		this.greetingPath = greetingPath;
		varGreetingPath = new Var("greetingPath", ""+greetingPath);
	}

	public String getMsgPath() {
		return msgPath;
	}

	public void setMsgPath(String msgPath) {
		this.msgPath = msgPath;
		varMsgPath = new Var("msgPath", ""+msgPath);
	}

	public int getNxtIndex() {
		return nxtIndex;
	}

	public void setNxtIndex(int nxtIndex) {
		this.nxtIndex = nxtIndex;
		varNxtIndex = new Var("nxtIndex", ""+nxtIndex);
	}

	public int getPrvIndex() {
		return prvIndex;
	}

	public void setPrvIndex(int prvIndex) {
		this.prvIndex = prvIndex;
		varPrvIndex = new Var("prvIndex", ""+prvIndex);
	}

	public String getSenderNum() {
		return senderNum;
	}

	public void setSenderNum(String senderNum) {
		this.senderNum = senderNum;
		varSenderNum = new Var("senderNum", ""+senderNum);
	}

	public String getAvailable() {
		return available;
	}

	public void setAvailable(String available) {
		this.available = available;
		varAvailable = new Var("available", ""+available);
	}

	public int getMsgIndex() {
		return msgIndex;
	}

	public void setMsgIndex(int msgIndex) {
		this.msgIndex = msgIndex;
		varMsgIndex = new Var("msgIndex", ""+msgIndex);
	}

	public String getPointer() {
		return pointer;
	}

	public void setPointer(String pointer) {
		this.pointer = pointer;
		varPointer = new Var("pointer", ""+pointer);
	}

	public int getTotalSaveMsg() {
		return totalSaveMsg;
	}

	public void setTotalSaveMsg(int totalSaveMsg) {
		this.totalSaveMsg = totalSaveMsg;
		varTotalSaveMsg = new Var("totalSaveMsg",""+ totalSaveMsg);
	}

	public String getSaveMsgCountPath() {
		return saveMsgCountPath;
	}

	public void setSaveMsgCountPath(String saveMsgCountPath) {
		this.saveMsgCountPath = saveMsgCountPath;
		varSaveMsgCountPath = new Var("saveMsgCountPath", saveMsgCountPath);
	}

		

}
