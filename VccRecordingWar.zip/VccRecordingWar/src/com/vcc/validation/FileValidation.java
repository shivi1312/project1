package com.vcc.validation;

import java.io.File;

import org.apache.log4j.Logger;

import com.vcc.chain.VmChain;
import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.request.VmRequest;
import com.vcc.response.VmResponse;

public class FileValidation implements VmChain {

	final static Logger logger = Logger.getLogger(FileValidation.class);
	private VmChain nextInVmChain;
	@SuppressWarnings("unused")
	private VccServices vccServices;

	@Override
	public void setNext(VmChain nextInVmChain, VccServices vccServices) {
		this.nextInVmChain = nextInVmChain;
		this.vccServices = vccServices;
	}

	@Override
	public void process(VmRequest vmRequest, VmResponse vmResponse,
			VmError vmError) {
		File file = null;
		try {
			file = new File(vmRequest.getRecordFile());
			if (!file.exists()) {
				vmError.setError(true);
				if (!file.canWrite()) {
					vmError.setError(true);
				}
				if (!file.canRead()) {
					vmError.setError(true);
				}
			}
			logger.info(String.format(
					"A-Party [%s] B-Party [%s] Is file exist [%s] "
							+ "Is writable [%s] Is Readable [%s] Any Error [%s]",
					vmRequest.getCallingNum(), vmRequest.getCalledNum(),
					file.exists(),file.canWrite(), file.canRead(),vmError.getError()));
			if (!vmError.getError()) {
				nextInVmChain.process(vmRequest, vmResponse, vmError);
			}else{
				vmResponse.setIsSuccess(0);
			}
		} catch (Exception e) {
			vmResponse.setIsSuccess(-1);
			e.printStackTrace();
			logger.info(String.format(
					"A-Party [%s] B-Party [%s] Exception [%s]",
					vmRequest.getCallingNum(), vmRequest.getCalledNum(),
					e.getMessage()));
		}
	}
}
