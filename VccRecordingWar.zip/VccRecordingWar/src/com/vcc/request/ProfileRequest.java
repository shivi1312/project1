package com.vcc.request;

import java.util.List;

import com.vcc.model.VccSubscriptionMaster;
import com.vcc.model.VccVoiceMessage;

public class ProfileRequest implements java.io.Serializable {

	private static final long serialVersionUID = 555740254018860075L;
	/** callingNum variable contain msisdn of aParty */
	private String callingNum;
	/** calledNum variable contain msisdn of bParty */
	private String calledNum;
	/** calledNumB variable contain msisdn of cParty or temp. variable*/
	private String calledNumB;
	/** callingNumWithoutCountryCode variable contain msisdn of aParty with country code */
	private String callingNumWithoutCountryCode;
	/** calledNumWithoutCountryCode variable contain msisdn of aParty with country code */
	private String calledNumWithoutCountryCode;
	/** releaseCode variable contain reason of call forwarding */
	private String releaseCode;
	/** serviceType variable contain service info. of end user  */
	private String serviceType;
	/** lang variable contain playing prompt language info of end user  */
	private int lang;
	/** catName variable contain category of voice message   */
	private String catName;
	/** catName variable contain index of voice mail in database */
	private int voiceMsgIndex;
	/** callTime variable contain date and time of calling in ivr system */
	private String callTime;
	/** password variable contain end user secure password*/
	private String password;
	/** digits variable contain end user secure password*/
	private String digits;
	
	private int triggerType;
	
	private String flowType;
	
	private String planName;
	
	private int actTrg;
	
	private String subType;
	
	private String recordFilePath;
	
	private String recordTempPath;
	
	/*Added by vivek to reduce the query*/
    private List<VccSubscriptionMaster> activeServiceList;

	public List<VccSubscriptionMaster> getActiveServiceList() {
		return activeServiceList;
	}

	public void setActiveServiceList(List<VccSubscriptionMaster> activeServiceList) {
		this.activeServiceList = activeServiceList;
	}

	// Added By AbhiShek Rana for reduce the queries
	private List<VccVoiceMessage> vccList;
	
	
	public String getRecordFilePath() {
		return recordFilePath;
	}

	public void setRecordFilePath(String recordFilePath) {
		this.recordFilePath = recordFilePath;
	}
	private String recordFileName;
	
	public String getRecordFileName() {
		return recordFileName;
	}

	public void setRecordFileName(String recordFileName) {
		this.recordFileName = recordFileName;
	}

	private int serverId;
	private String callUUID;
	
	private int recordingDuration;
	private String hangupCause;
	private int callDuration;
	private int answerd;
	private int isSilentDetect;
	
	private int recordTimeout;
	
	private int isCheckProfileEnabled=-1;

	public int getIsCheckProfileEnabled() {
		return isCheckProfileEnabled;
	}

	public void setIsCheckProfileEnabled(int isCheckProfileEnabled) {
		this.isCheckProfileEnabled = isCheckProfileEnabled;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getRecordTimeout() {
		return recordTimeout;
	}

	public void setRecordTimeout(int recordTimeout) {
		this.recordTimeout = recordTimeout;
	}

	public int getIsSilentDetect() {
		return isSilentDetect;
	}

	public void setIsSilentDetect(int isSilentDetect) {
		this.isSilentDetect = isSilentDetect;
	}

	public int getCallDuration() {
		return callDuration;
	}

	public void setCallDuration(int callDuration) {
		this.callDuration = callDuration;
	}

	public int getAnswerd() {
		return answerd;
	}

	public void setAnswerd(int answerd) {
		this.answerd = answerd;
	}

	public String getHangupCause() {
		return hangupCause;
	}

	public void setHangupCause(String hangupCause) {
		this.hangupCause = hangupCause;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getCallingNum() {
		return callingNum;
	}

	public void setCallingNum(String callingNum) {
		this.callingNum = callingNum;
	}

	public String getCalledNum() {
		return calledNum;
	}

	public void setCalledNum(String calledNum) {
		this.calledNum = calledNum;
	}

	public String getReleaseCode() {
		return releaseCode;
	}

	public void setReleaseCode(String releaseCode) {
		this.releaseCode = releaseCode;
	}

	public String getCallingNumWithoutCountryCode() {
		return callingNumWithoutCountryCode;
	}

	public void setCallingNumWithoutCountryCode(String callingNumWithoutCountryCode) {
		this.callingNumWithoutCountryCode = callingNumWithoutCountryCode;
	}

	public String getCalledNumWithoutCountryCode() {
		return calledNumWithoutCountryCode;
	}

	public void setCalledNumWithoutCountryCode(String calledNumWithoutCountryCode) {
		this.calledNumWithoutCountryCode = calledNumWithoutCountryCode;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public int getLang() {
		return lang;
	}

	public void setLang(int lang) {
		this.lang = lang;
	}

	public String getCalledNumB() {
		return calledNumB;
	}

	public void setCalledNumB(String calledNumB) {
		this.calledNumB = calledNumB;
	}

	public String getCatName() {
		return catName;
	}

	public void setCatName(String catName) {
		this.catName = catName;
	}



	public int getVoiceMsgIndex() {
		return voiceMsgIndex;
	}

	public void setVoiceMsgIndex(int voiceMsgIndex) {
		this.voiceMsgIndex = voiceMsgIndex;
	}

	public String getCallTime() {
		return callTime;
	}

	public void setCallTime(String callTime) {
		this.callTime = callTime;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDigits() {
		return digits;
	}

	public void setDigits(String digits) {
		this.digits = digits;
	}

	public int getTriggerType() {
		return triggerType;
	}

	public void setTriggerType(int triggerType) {
		this.triggerType = triggerType;
	}

	public String getFlowType() {
		return flowType;
	}

	public void setFlowType(String flowType) {
		this.flowType = flowType;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public int getActTrg() {
		return actTrg;
	}

	public void setActTrg(int actTrg) {
		this.actTrg = actTrg;
	}

	public String getRecordTempPath() {
		return recordTempPath;
	}

	public void setRecordTempPath(String recordTempPath) {
		this.recordTempPath = recordTempPath;
	}

	public List<VccVoiceMessage> getVccList() {
		return vccList;
	}

	public void setVccList(List<VccVoiceMessage> vccList) {
		this.vccList = vccList;
	}

	public int getServerId() {
		return serverId;
	}

	public void setServerId(int serverId) {
		this.serverId = serverId;
	}

	public String getCallUUID() {
		return callUUID;
	}

	public void setCallUUID(String callUUID) {
		this.callUUID = callUUID;
	}

	public int getRecordingDuration() {
		return recordingDuration;
	}

	public void setRecordingDuration(int recordingDuration) {
		this.recordingDuration = recordingDuration;
	}
	
	
	
}
