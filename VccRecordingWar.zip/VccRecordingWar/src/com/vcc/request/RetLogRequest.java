package com.vcc.request;

import java.io.Serializable;

public class RetLogRequest implements Serializable {
	
	private static final long serialVersionUID = 555740254018860075L;

	private int serverId=0;
	private String callUUID;
	private String callingNum;
	private String calledNum;
	private int mailboxNo=0;
	
	private String subType;
	private String serviceType;
	private int ratePlan=0;
	private int answered=1;
	private String callTime;
	private int callDuration;
	private int msgLength=0;
	private int mRd;
	private int mDel;
	private int mMv;
	private int mCp;
	private int mSv;
	private int grtAd;
	private int grtDel;
	private int frndAd;
	private int frndDel;
	private int dialCnt;
	//private int edPassCnt;
	private int recCnt;
	private int cngLngCnt;
	
	public int getMailboxNo() {
		return mailboxNo;
	}
	public void setMailboxNo(int mailboxNo) {
		this.mailboxNo = mailboxNo;
	}
	public int getServerId() {
		return serverId;
	}
	public void setServerId(int serverId) {
		this.serverId = serverId;
	}
	
	public String getCallUUID() {
		return callUUID;
	}
	public void setCallUUID(String callUUID) {
		this.callUUID = callUUID;
	}
	public String getCallingNum() {
		return callingNum;
	}
	public void setCallingNum(String callingNum) {
		this.callingNum = callingNum;
	}
	public String getCalledNum() {
		return calledNum;
	}
	public void setCalledNum(String calledNum) {
		this.calledNum = calledNum;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public int getRatePlan() {
		return ratePlan;
	}
	public void setRatePlan(int ratePlan) {
		this.ratePlan = ratePlan;
	}
	public int getAnswered() {
		return answered;
	}
	public void setAnswered(int answered) {
		this.answered = answered;
	}
	public String getCallTime() {
		return callTime;
	}
	public void setCallTime(String callTime) {
		this.callTime = callTime;
	}
	public int getCallDuration() {
		return callDuration;
	}
	public void setCallDuration(int callDuration) {
		this.callDuration = callDuration;
	}
	public int getMsgLength() {
		return msgLength;
	}
	public void setMsgLength(int msgLength) {
		this.msgLength = msgLength;
	}
	public int getmRd() {
		return mRd;
	}
	public void setmRd(int mRd) {
		this.mRd = mRd;
	}
	public int getmDel() {
		return mDel;
	}
	public void setmDel(int mDel) {
		this.mDel = mDel;
	}
	public int getmMv() {
		return mMv;
	}
	public void setmMv(int mMv) {
		this.mMv = mMv;
	}
	public int getmCp() {
		return mCp;
	}
	public void setmCp(int mCp) {
		this.mCp = mCp;
	}
	public int getmSv() {
		return mSv;
	}
	public void setmSv(int mSv) {
		this.mSv = mSv;
	}
	public int getGrtAd() {
		return grtAd;
	}
	public void setGrtAd(int grtAd) {
		this.grtAd = grtAd;
	}
	public int getGrtDel() {
		return grtDel;
	}
	public void setGrtDel(int grtDel) {
		this.grtDel = grtDel;
	}
	public int getFrndAd() {
		return frndAd;
	}
	public void setFrndAd(int frndAd) {
		this.frndAd = frndAd;
	}
	public int getFrndDel() {
		return frndDel;
	}
	public void setFrndDel(int frndDel) {
		this.frndDel = frndDel;
	}
	public int getDialCnt() {
		return dialCnt;
	}
	public void setDialCnt(int dialCnt) {
		this.dialCnt = dialCnt;
	}
	public int getRecCnt() {
		return recCnt;
	}
	public void setRecCnt(int recCnt) {
		this.recCnt = recCnt;
	}
	public int getCngLngCnt() {
		return cngLngCnt;
	}
	public void setCngLngCnt(int cngLngCnt) {
		this.cngLngCnt = cngLngCnt;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

}
