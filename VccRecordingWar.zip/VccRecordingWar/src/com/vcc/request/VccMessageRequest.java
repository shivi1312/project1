package com.vcc.request;

public class VccMessageRequest implements java.io.Serializable {

	private static final long serialVersionUID = 555740254018860075L;
	private String callingNum;
	private String calledNum;
	private String senderNum="0";
	private String calledNumB;
	private String callingNumWithoutCountryCode;
	private String senderNumWithoutCountryCode;
	private String catName="NA";
    private String serviceType="0000";
    private int nxtIndex=0;
    private int prvIndex=0;
    private String available;
    private String pointer="S";
    private int lang=1;
    private int totalNewMsg=0;
    private int totalOldMsg=0;
    private int totalSaveMsg=0;
    private Boolean readMsg = false;
    private int readMsgIndex =0;
    private String retrievalTime;
    private int voiceMsgIndex;
    private int msgDuration;
    private int headerFlag=0;
    
    
	public int getHeaderFlag() {
		return headerFlag;
	}
	public void setHeaderFlag(int headerFlag) {
		this.headerFlag = headerFlag;
	}
	public int getMsgDuration() {
		return msgDuration;
	}
	public void setMsgDuration(int msgDuration) {
		this.msgDuration = msgDuration;
	}
	public int getVoiceMsgIndex() {
		return voiceMsgIndex;
	}
	public void setVoiceMsgIndex(int voiceMsgIndex) {
		this.voiceMsgIndex = voiceMsgIndex;
	}
	public String getCallingNum() {
		return callingNum;
	}
	public void setCallingNum(String callingNum) {
		this.callingNum = callingNum;
	}
	public String getSenderNum() {
		return senderNum;
	}
	public void setSenderNum(String senderNum) {
		this.senderNum = senderNum;
	}
	public String getCallingNumWithoutCountryCode() {
		return callingNumWithoutCountryCode;
	}
	public void setCallingNumWithoutCountryCode(String callingNumWithoutCountryCode) {
		this.callingNumWithoutCountryCode = callingNumWithoutCountryCode;
	}
	public String getSenderNumWithoutCountryCode() {
		return senderNumWithoutCountryCode;
	}
	public void setSenderNumWithoutCountryCode(String senderNumWithoutCountryCode) {
		this.senderNumWithoutCountryCode = senderNumWithoutCountryCode;
	}
	public String getCatName() {
		return catName;
	}
	public void setCatName(String catName) {
		this.catName = catName;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public int getLang() {
		return lang;
	}
	public void setLang(int lang) {
		this.lang = lang;
	}
	public int getTotalNewMsg() {
		return totalNewMsg;
	}
	public void setTotalNewMsg(int totalNewMsg) {
		this.totalNewMsg = totalNewMsg;
	}
	public int getTotalOldMsg() {
		return totalOldMsg;
	}
	public void setTotalOldMsg(int totalOldMsg) {
		this.totalOldMsg = totalOldMsg;
	}
	public int getTotalSaveMsg() {
		return totalSaveMsg;
	}
	public void setTotalSaveMsg(int totalSaveMsg) {
		this.totalSaveMsg = totalSaveMsg;
	}
	public int getNxtIndex() {
		return nxtIndex;
	}
	public void setNxtIndex(int nxtIndex) {
		this.nxtIndex = nxtIndex;
	}
	public int getPrvIndex() {
		return prvIndex;
	}
	public void setPrvIndex(int prvIndex) {
		this.prvIndex = prvIndex;
	}
	public String getAvailable() {
		return available;
	}
	public void setAvailable(String available) {
		this.available = available;
	}
	public String getPointer() {
		return pointer;
	}
	public void setPointer(String pointer) {
		this.pointer = pointer;
	}
	public String getCalledNum() {
		return calledNum;
	}
	public void setCalledNum(String calledNum) {
		this.calledNum = calledNum;
	}
	public String getCalledNumB() {
		return calledNumB;
	}
	public void setCalledNumB(String calledNumB) {
		this.calledNumB = calledNumB;
	}
	public Boolean getReadMsg() {
		return readMsg;
	}
	public void setReadMsg(Boolean readMsg) {
		this.readMsg = readMsg;
	}
	public int getReadMsgIndex() {
		return readMsgIndex;
	}
	public void setReadMsgIndex(int readMsgIndex) {
		this.readMsgIndex = readMsgIndex;
	}
	public String getRetrievalTime() {
		return retrievalTime;
	}
	public void setRetrievalTime(String retrievalTime) {
		this.retrievalTime = retrievalTime;
	}
    
    

	
}
