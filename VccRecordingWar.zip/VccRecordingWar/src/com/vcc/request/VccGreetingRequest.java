package com.vcc.request;

public class VccGreetingRequest implements java.io.Serializable {
	
	private static final long serialVersionUID = 555740254018860075L;
	
	private String callingNum;
	private String calledNum;
	private String serviceType;
	private int lang;
	private String recordFileName;
	private int recordingDuration;
	private int greetingType;
	
	public String getCallingNum() {
		return callingNum;
	}
	public void setCallingNum(String callingNum) {
		this.callingNum = callingNum;
	}
	public String getCalledNum() {
		return calledNum;
	}
	public void setCalledNum(String calledNum) {
		this.calledNum = calledNum;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public int getLang() {
		return lang;
	}
	public void setLang(int lang) {
		this.lang = lang;
	}
	public String getRecordFileName() {
		return recordFileName;
	}
	public void setRecordFileName(String recordFileName) {
		this.recordFileName = recordFileName;
	}
	
	public int getGreetingType() {
		return greetingType;
	}
	public void setGreetingType(int greetingType) {
		this.greetingType = greetingType;
	}
	public int getRecordingDuration() {
		return recordingDuration;
	}
	public void setRecordingDuration(int recordingDuration) {
		this.recordingDuration = recordingDuration;
	}

	
}
