package com.vcc.request;

import java.io.Serializable;

public class UserConfigRequest implements Serializable {
	
	private static final long serialVersionUID = 555740254018860075L;
	private String callingNum;
	private String calledNumB;
	private int lang=1;
	private String frndMsisdn;
	private int groupId=0;
	private String fileName;
	private String serviceType;
	private int frndCount=0;
	private String type;
	private int nxtIndex=0;
	private int prvIndex=0;
	private String available;
	private String pointer;
	private int pagination=0;
	private String recordFileName;
	private String serviceFlag;
	private int serviceFlagIndex=0;
	private int ratePlan=0;
	private int inputCount=0;
	
	
	
	
	
	public int getRatePlan() {
		return ratePlan;
	}
	public void setRatePlan(int ratePlan) {
		this.ratePlan = ratePlan;
	}
	public int getServiceFlagIndex() {
		return serviceFlagIndex;
	}
	public void setServiceFlagIndex(int serviceFlagIndex) {
		this.serviceFlagIndex = serviceFlagIndex;
	}
	public String getServiceFlag() {
		return serviceFlag;
	}
	public void setServiceFlag(String serviceFlag) {
		this.serviceFlag = serviceFlag;
	}
	public String getCalledNumB() {
		return calledNumB;
	}
	public void setCalledNumB(String calledNumB) {
		this.calledNumB = calledNumB;
	}
	public String getCallingNum() {
		return callingNum;
	}
	public void setCallingNum(String callingNum) {
		this.callingNum = callingNum;
	}
	public String getFrndMsisdn() {
		return frndMsisdn;
	}
	public void setFrndMsisdn(String frndMsisdn) {
		this.frndMsisdn = frndMsisdn;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public int getFrndCount() {
		return frndCount;
	}
	public void setFrndCount(int frndCount) {
		this.frndCount = frndCount;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getNxtIndex() {
		return nxtIndex;
	}
	public void setNxtIndex(int nxtIndex) {
		this.nxtIndex = nxtIndex;
	}
	
	public int getPrvIndex() {
		return prvIndex;
	}
	public void setPrvIndex(int prvIndex) {
		this.prvIndex = prvIndex;
	}
	public String getAvailable() {
		return available;
	}
	public void setAvailable(String available) {
		this.available = available;
	}
	public String getPointer() {
		return pointer;
	}
	public void setPointer(String pointer) {
		this.pointer = pointer;
	}
	public int getPagination() {
		return pagination;
	}
	public void setPagination(int pagination) {
		this.pagination = pagination;
	}
	public int getLang() {
		return lang;
	}
	public void setLang(int lang) {
		this.lang = lang;
	}
	public String getRecordFileName() {
		return recordFileName;
	}
	public void setRecordFileName(String recordFileName) {
		this.recordFileName = recordFileName;
	}
	public int getInputCount() {
		return inputCount;
	}
	public void setInputCount(int inputCount) {
		this.inputCount = inputCount;
	}
	
	

}
