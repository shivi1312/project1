package com.vcc.request;

import java.util.List;

import com.vcc.model.VccSubscriptionMaster;
import com.vcc.model.VccVoiceMessage;


public class VmRequest implements java.io.Serializable {

	@Override
	public String toString() {
		return "VmRequest [serverId=" + serverId + ", circuitId=" + circuitId
				+ ", answerd=" + answerd + ", callingNum=" + callingNum
				+ ", calledNum=" + calledNum + ", calledNumB=" + calledNumB
				+ ", recordFile=" + recordFile + ", callTime=" + callTime
				+ ", ringTime=" + ringTime + ", callDuration=" + callDuration
				+ ", recordingDuration=" + recordingDuration
				+ ", isVoiceMailDeleted=" + isVoiceMailDeleted
				+ ", isMailBoxFull=" + isMailBoxFull + ", serviceType="
				+ serviceType + ", recordFileName=" + recordFileName
				+ ", callingNumWithoutCountryCode="
				+ callingNumWithoutCountryCode
				+ ", calledNumWithoutCountryCode="
				+ calledNumWithoutCountryCode + ", isOldFileDeleted="
				+ isOldFileDeleted + ", isRecordFileExits=" + isRecordFileExits
				+ ", reasonCode=" + reasonCode + ", subType=" + subType
				+ ", HangupCause=" + HangupCause + ", ratePlan=" + ratePlan
				+ ", isCallAllowed=" + isCallAllowed + ", releaseCode="
				+ releaseCode + ", callUUID=" + callUUID
				+ ", isUserIsOptedOut=" + isUserIsOptedOut
				+ ", isNotifyMeWithMCM=" + isNotifyMeWithMCM + ", type=" + type
				+ ", catName=" + catName + ", voiceMsgIndex=" + voiceMsgIndex
				+ ", scheduleDate=" + scheduleDate + ", scheduleTime="
				+ scheduleTime + ", groupId=" + groupId + ", digits=" + digits
				+ ", recordTimeout=" + recordTimeout + ", recordLength="
				+ recordLength + ", isSilentDetect=" + isSilentDetect
				+ ", recordTempPath=" + recordTempPath + ", lang=" + lang
				+ ", notificationSend=" + notificationSend
				+ ", activeServiceList=" + activeServiceList + ", isSuccess="
				+ isSuccess + ", vccList=" + vccList + ", voiceNoteActive="
				+ voiceNoteActive + "]";
	}

	private static final long serialVersionUID = 1L;
	private int serverId;
	private int circuitId;
	private int answerd;
	private String callingNum;
	private String calledNum;
	private String calledNumB;
	private String recordFile;
	private String callTime;
	private String ringTime;
	private int callDuration;
	private int recordingDuration;
	private int isHangupByuser = -1;
	private int isVoiceMailDeleted;
	private int isMailBoxFull;
	private String serviceType;
	private String recordFileName;
	private String callingNumWithoutCountryCode;
	private String calledNumWithoutCountryCode;
	private Boolean isOldFileDeleted;
	private Boolean isRecordFileExits;
	private String reasonCode;
	private String subType;
	private String HangupCause;
	private int ratePlan;
	private int isCallAllowed;
	private String releaseCode;
	private String callUUID;
	private int isUserIsOptedOut;
	private int isNotifyMeWithMCM;
	private String type;
	private String catName;
	private int voiceMsgIndex;
    private String scheduleDate;
    private String scheduleTime;
    private int groupId=0;
    private String digits="0";
    private int recordTimeout;
    private int recordLength;
    private int isSilentDetect=0;
    private String recordTempPath;
    private int lang;
    private boolean notificationSend = true;
    /*Added by vivek to reduce the query*/
    private List<VccSubscriptionMaster> activeServiceList;
    private int isSuccess;
    
    
    
	public List<VccSubscriptionMaster> getActiveServiceList() {
		return activeServiceList;
	}

	public void setActiveServiceList(List<VccSubscriptionMaster> activeServiceList) {
		this.activeServiceList = activeServiceList;
	}

	// Added by AbhiShek Rana
	private List<VccVoiceMessage> vccList;
	private boolean voiceNoteActive;
	
	
	public int getIsSilentDetect() {
		return isSilentDetect;
	}

	public void setIsSilentDetect(int isSilentDetect) {
		this.isSilentDetect = isSilentDetect;
	}

	public int getRecordTimeout() {
		return recordTimeout;
	}

	public void setRecordTimeout(int recordTimeout) {
		this.recordTimeout = recordTimeout;
	}

	public int getRecordLength() {
		return recordLength;
	}

	public void setRecordLength(int recordLength) {
		this.recordLength = recordLength;
	}

	public String getDigits() {
		return digits;
	}

	public void setDigits(String digits) {
		this.digits = digits;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getHangupCause() {
		return HangupCause;
	}

	public void setHangupCause(String hangupCause) {
		HangupCause = hangupCause;
	}

	public int getRatePlan() {
		return ratePlan;
	}

	public void setRatePlan(int ratePlan) {
		this.ratePlan = ratePlan;
	}

	public int getIsCallAllowed() {
		return isCallAllowed;
	}

	public void setIsCallAllowed(int isCallAllowed) {
		this.isCallAllowed = isCallAllowed;
	}

	public String getReleaseCode() {
		return releaseCode;
	}

	public void setReleaseCode(String releaseCode) {
		this.releaseCode = releaseCode;
	}

	public String getCallingNum() {
		return callingNum;
	}

	public void setCallingNum(String callingNum) {
		this.callingNum = callingNum;
	}

	public String getCalledNum() {
		return calledNum;
	}

	public void setCalledNum(String calledNum) {
		this.calledNum = calledNum;
	}

	public String getRecordFile() {
		return recordFile;
	}

	public void setRecordFile(String recordFile) {
		this.recordFile = recordFile;
	}

	public String getCallTime() {
		return callTime;
	}

	public void setCallTime(String callTime) {
		this.callTime = callTime;
	}

	public int getCallDuration() {
		return callDuration;
	}

	public void setCallDuration(int callDuration) {
		this.callDuration = callDuration;
	}

	public int getRecordingDuration() {
		return recordingDuration;
	}

	public void setRecordingDuration(int recordingDuration) {
		this.recordingDuration = recordingDuration;
	}

	public int getIsHangupByuser() {
		return isHangupByuser;
	}

	public void setIsHangupByuser(int isHangupByuser) {
		this.isHangupByuser = isHangupByuser;
	}

	public int getIsVoiceMailDeleted() {
		return isVoiceMailDeleted;
	}

	public void setIsVoiceMailDeleted(int isVoiceMailDeleted) {
		this.isVoiceMailDeleted = isVoiceMailDeleted;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getCallingNumWithoutCountryCode() {
		return callingNumWithoutCountryCode;
	}

	public void setCallingNumWithoutCountryCode(String callingNumWithoutCountryCode) {
		this.callingNumWithoutCountryCode = callingNumWithoutCountryCode;
	}

	public String getCalledNumWithoutCountryCode() {
		return calledNumWithoutCountryCode;
	}

	public void setCalledNumWithoutCountryCode(String calledNumWithoutCountryCode) {
		this.calledNumWithoutCountryCode = calledNumWithoutCountryCode;
	}

	public Boolean getIsOldFileDeleted() {
		return isOldFileDeleted;
	}

	public void setIsOldFileDeleted(Boolean isOldFileDeleted) {
		this.isOldFileDeleted = isOldFileDeleted;
	}

	public Boolean getIsRecordFileExits() {
		return isRecordFileExits;
	}

	public void setIsRecordFileExits(Boolean isRecordFileExits) {
		this.isRecordFileExits = isRecordFileExits;
	}

	public String getRecordFileName() {
		return recordFileName;
	}

	public void setRecordFileName(String recordFileName) {
		this.recordFileName = recordFileName;
	}

	public int getIsMailBoxFull() {
		return isMailBoxFull;
	}

	public void setIsMailBoxFull(int isMailBoxFull) {
		this.isMailBoxFull = isMailBoxFull;
	}

	
	public int getServerId() {
		return serverId;
	}

	public void setServerId(int serverId) {
		this.serverId = serverId;
	}

	public int getCircuitId() {
		return circuitId;
	}

	public void setCircuitId(int circuitId) {
		this.circuitId = circuitId;
	}

	public int getAnswerd() {
		return answerd;
	}

	public void setAnswerd(int answerd) {
		this.answerd = answerd;
	}

	public String getRingTime() {
		return ringTime;
	}

	public void setRingTime(String ringTime) {
		this.ringTime = ringTime;
	}

	public int getIsUserIsOptedOut() {
		return isUserIsOptedOut;
	}

	public void setIsUserIsOptedOut(int isUserIsOptedOut) {
		this.isUserIsOptedOut = isUserIsOptedOut;
	}

	public int getIsNotifyMeWithMCM() {
		return isNotifyMeWithMCM;
	}

	public void setIsNotifyMeWithMCM(int isNotifyMeWithMCM) {
		this.isNotifyMeWithMCM = isNotifyMeWithMCM;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCatName() {
		return catName;
	}

	public void setCatName(String catName) {
		this.catName = catName;
	}
	public int getVoiceMsgIndex() {
		return voiceMsgIndex;
	}

	public void setVoiceMsgIndex(int voiceMsgIndex) {
		this.voiceMsgIndex = voiceMsgIndex;
	}

	public String getCalledNumB() {
		return calledNumB;
	}

	public void setCalledNumB(String calledNumB) {
		this.calledNumB = calledNumB;
	}

	public String getScheduleDate() {
		return scheduleDate;
	}

	public void setScheduleDate(String scheduleDate) {
		this.scheduleDate = scheduleDate;
	}

	public String getScheduleTime() {
		return scheduleTime;
	}

	public void setScheduleTime(String scheduleTime) {
		this.scheduleTime = scheduleTime;
	}

	public String getCallUUID() {
		return callUUID;
	}

	public void setCallUUID(String callUUID) {
		this.callUUID = callUUID;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public String getRecordTempPath() {
		return recordTempPath;
	}

	public void setRecordTempPath(String recordTempPath) {
		this.recordTempPath = recordTempPath;
	}

	public int getLang() {
		return lang;
	}

	public void setLang(int lang) {
		this.lang = lang;
	}

	public boolean getNotificationSend() {
		return notificationSend;
	}

	public void setNotificationSend(boolean notificationSend) {
		this.notificationSend = notificationSend;
	}

	public List<VccVoiceMessage> getVccList() {
		return vccList;
	}

	public void setVccList(List<VccVoiceMessage> vccList) {
		this.vccList = vccList;
	}

	public boolean isVoiceNoteActive() {
		return voiceNoteActive;
	}

	public void setVoiceNoteActive(boolean voiceNoteActive) {
		this.voiceNoteActive = voiceNoteActive;
	}

	public int getIsSuccess() {
		return isSuccess;
	}

	public void setIsSuccess(int isSuccess) {
		this.isSuccess = isSuccess;
	}
	
}
