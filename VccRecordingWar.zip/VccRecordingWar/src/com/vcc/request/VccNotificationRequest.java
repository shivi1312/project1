package com.vcc.request;

public class VccNotificationRequest {
	@SuppressWarnings("unused")
	private static final long serialVersionUID = 1L;
	private String aParty;
	private String bParty;
	private String reasonCode;
	private String serviceType;
	private String callTime;
	private String type;
	private int lang;
	public String getaParty() {
		return aParty;
	}
	public void setaParty(String aParty) {
		this.aParty = aParty;
	}
	public String getbParty() {
		return bParty;
	}
	public void setbParty(String bParty) {
		this.bParty = bParty;
	}
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getCallTime() {
		return callTime;
	}
	public void setCallTime(String callTime) {
		this.callTime = callTime;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getLang() {
		return lang;
	}
	public void setLang(int lang) {
		this.lang = lang;
	}
}
