package com.vcc.config;

import java.io.File;
import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import org.apache.commons.configuration.CombinedConfiguration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.DefaultConfigurationBuilder;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.vcc.cache.VccExpiryCache;
import com.vcc.dao.AppConfigParamRowMapper;
import com.vcc.dao.VccChargingCodeRowMapper;
import com.vcc.dao.VccMailboxParamsRowMapper;
import com.vcc.dao.VccRatePlanRowMapper;
import com.vcc.dao.VccServiceProviderRowMapper;
import com.vcc.model.AppConfigParam;
import com.vcc.model.VccChargingCode;
import com.vcc.model.VccMailboxParams;
import com.vcc.model.VccRatePlan;
import com.vcc.model.VccSeries;
import com.vcc.model.VccServiceProvider;

import FileBaseLogging.FileLogWriter;

@Service
public class AppConfig {
	private final static Logger logger = Logger.getLogger(AppConfig.class);
	private final static Logger errorLogger = Logger.getLogger("errorLogger");

	public static CombinedConfiguration config;
	public static FileLogWriter VCC_FWD_CALL_LOGS_WRITER = new FileLogWriter();

	/*
	 * private static String envVar; private static boolean readEnv;
	 */

	@Autowired
	private AppConfig(DataSource dataSource) {
		config.setProperty("datasource", dataSource);
		readDatabaseConfig();
		readMailBoxParam();
		readRatePlan();
		readSeriesRange();
		loadVccFwdCallFileLogWriter();
	}

	public static void readServiceProvider() {
		JdbcTemplate jdbcTemplate = null;
		DataSource dataSource;
		List<VccServiceProvider> serviceProviders=null;
		try {
			String sql = "select * from SERVICE_PROVIDER order by PRIORITY";
			logger.debug("query is :->>>> [" + sql + "]");
			dataSource = (DataSource) config.getProperty("datasource");
			jdbcTemplate = new JdbcTemplate(dataSource);
			serviceProviders =jdbcTemplate.query(sql, new Object[] {}, new VccServiceProviderRowMapper());
			VccExpiryCache.dbmap.put("vcc_service_provider", serviceProviders, 24, TimeUnit.HOURS);
//			VccExpiryCache.dbmap.put("vcc_service_provider", serviceProviders, 2, TimeUnit.MINUTES);
		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "90019] [Exception while loading SERVICE_PROVIDER] Error[" + e.getMessage() + "]");
			e.printStackTrace();
		}
	}

	public static void readSeriesRange() {

		String query = "";
		List<VccSeries> vccSeries = null;
		JdbcTemplate jdbcTemplate = null;
		query = "SELECT A.GROUP_ID AS GROUP_ID,A.GROUP_NAME AS GROUP_NAME,B.TYPE AS TYPE,B.START_RANGE AS START_RANGE,"
				+ "B.END_RANGE END_RANGE FROM vcc_series_group A,vcc_series_range B WHERE A.GROUP_ID=B.GROUP_ID";
		DataSource dataSource;
		try {
			dataSource = (DataSource) config.getProperty("datasource");
			jdbcTemplate = new JdbcTemplate(dataSource);

			vccSeries = jdbcTemplate.query(query, new RowMapper<VccSeries>() {
				@Override
				public VccSeries mapRow(ResultSet rs, int rownumber) throws SQLException {
					VccSeries series = new VccSeries();
					series.setGroupId(rs.getInt("GROUP_ID"));
					series.setGroupName(rs.getString("GROUP_NAME"));
					series.setStartRange(new BigInteger(rs.getString("START_RANGE")));
					series.setEndRange(new BigInteger(rs.getString("END_RANGE")));
					series.setType(rs.getString("TYPE"));
					return series;
				}
			});
			VccExpiryCache.dbmap.put("vcc_series_range", vccSeries, 24, TimeUnit.HOURS);
			//VccExpiryCache.dbmap.put("vcc_series_range", vccSeries, 2, TimeUnit.MINUTES);

		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "90019] [Exception while loading series range and series group] Error[" + e.getMessage() + "]");
			e.printStackTrace();
		}

	}

	static {
		try {
			DefaultConfigurationBuilder builder = new DefaultConfigurationBuilder();
			/*
			 * readEnv(); if(readEnv){
			 * 
			 * builder.setFile(new
			 * File(envVar+File.separator+"vccwar"+File.separator+"config.xml"))
			 * ; }else{ logger.error(
			 * "Environment variable [PROPERTY_FILE_PATH] is not set"); }
			 */
			builder.setFile(new File("config.xml"));
			config = builder.getConfiguration(true);

			System.out.println("rule_engine_ip " + config.getString("rule_engine_ip"));
		} catch (ConfigurationException ce) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "90019] [Configuration Exception in reading Config.xml File] Error[" + ce.getMessage() + "]");
		} catch (Exception e) {
			logger.error("error in configuration [" + e + "]");
		}
	}

	/*
	 * public static void readEnv(){ try{ envVar =
	 * System.getenv("PROPERTY_FILE_PATH"); readEnv = true; }catch(Exception e){
	 * readEnv = false; } }
	 */
	public static void readDatabaseConfig() {
		DataSource dataSource;
		try {
			dataSource = (DataSource) config.getProperty("datasource");
			String sql = "select * from APP_CONFIG_PARAMS";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			List<AppConfigParam> list = jdbcTemplate.query(sql, new AppConfigParamRowMapper());
			for (AppConfigParam param : list) {
				AppConfig.config.setProperty(param.getParamName(), param.getParamValue());
			}
			logger.info("APP_CONFIG_PARAMS details load in cache ");

		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00010] [Exception in loading APP_CONFIG_PARAMS detail] Error[" + e.getMessage() + "]");
			logger.error("error in db operation for APP_CONFIG_PARAMS details  [" + e + "]");
		}
	}

	public static void readMailBoxParam() {
		DataSource dataSource;
		HashMap<Integer, VccMailboxParams> mailBoxMap = new HashMap<Integer, VccMailboxParams>();
		Gson gson = new Gson();
		try {
			dataSource = (DataSource) config.getProperty("datasource");
			// String sql = "select * from VCC_MAILBOX_PARAMS group by
			// MAILBOX_TYPE";
			String sql = "select * from VCC_MAILBOX_PARAMS";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			List<VccMailboxParams> mailboxParams = jdbcTemplate.query(sql, new VccMailboxParamsRowMapper());

			for (Iterator<VccMailboxParams> iterator = mailboxParams.iterator(); iterator.hasNext();) {

				VccMailboxParams vccMailboxParams = (VccMailboxParams) iterator.next();

				mailBoxMap.put(vccMailboxParams.getMailboxId(), vccMailboxParams);
			}

			String json = gson.toJson(mailBoxMap);
			logger.debug("mail box json [" + json + "] set in sysmap");
			VccExpiryCache.sysmap.put("vcc_mailbox_param", json, 24, TimeUnit.HOURS);
			//VccExpiryCache.sysmap.put("vcc_mailbox_param", json, 2, TimeUnit.MINUTES);

		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00011] [Exception in loading VCC_MAILBOX_PARAMS detail] Error[" + e.getMessage() + "]");
			logger.error("error in db operation for readMailBoxParam details  [" + e + "]");
		}
	}

	public static void readRatePlan() {
		DataSource dataSource;
		HashMap<Integer, VccRatePlan> ratePlanMap = new HashMap<Integer, VccRatePlan>();
		Gson gson = new Gson();
		try {
			dataSource = (DataSource) config.getProperty("datasource");
			String sql = " select * from VCC_RATE_PLAN";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			List<VccRatePlan> ratePlanlist = jdbcTemplate.query(sql, new VccRatePlanRowMapper());

			for (Iterator<VccRatePlan> iterator = ratePlanlist.iterator(); iterator.hasNext();) {
				VccRatePlan vccRatePlan = (VccRatePlan) iterator.next();
				ratePlanMap.put(vccRatePlan.getPlanId(), vccRatePlan);
			}
			String json = gson.toJson(ratePlanMap);
			logger.debug("Rate plan json [" + json + "] set in sysmap");
			
			VccExpiryCache.sysmap.put("vcc_rate_plan", json, 24, TimeUnit.HOURS);
			//VccExpiryCache.sysmap.put("vcc_rate_plan", json, 2, TimeUnit.MINUTES);

		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00012] [Exception in loading VCC_RATE_PLAN detail] Error[" + e.getMessage() + "]");
			logger.error("error in db operation for readRatePlan deatils  [" + e + "]");

		}

	}

	public static void readChargingCode() {
		DataSource dataSource;

		HashMap<Integer, VccChargingCode> charMap = new HashMap<Integer, VccChargingCode>();
		Gson gson = new Gson();
		try {
			dataSource = (DataSource) config.getProperty("datasource");
			String sql = " select * from VCC_CHARGING_CODE";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			List<VccChargingCode> chargingCodeslist = jdbcTemplate.query(sql, new VccChargingCodeRowMapper());

			for (Iterator<VccChargingCode> iterator = chargingCodeslist.iterator(); iterator.hasNext();) {
				VccChargingCode chargingCode = (VccChargingCode) iterator.next();
				charMap.put(chargingCode.getChargingCode(), chargingCode);
			}
			String json = gson.toJson(charMap);
			VccExpiryCache.sysmap.put("vcc_charging_code", json, 24, TimeUnit.HOURS);
			//VccExpiryCache.sysmap.put("vcc_charging_code", json, 2, TimeUnit.MINUTES);

		} catch (Exception e) {
			errorLogger.error("ErrorCode [" + AppConfig.config.getString("errorcode_pattern", "VCC-IVRWAR-")
					+ "00013] [Exception in loading VCC_CHARGING_CODE detail] Error[" + e.getMessage() + "]");
			logger.error("error in db operation for readRatePlan deatils  [" + e + "]");

		}

	}
	
	public void loadVccFwdCallFileLogWriter()
	{
		logger.info("Inside loadFileLogWriter()");
		try {
			if(config.getInt("FILE_WRITER_FWD_CALL_LOGS_ENABLED",0) == 1) {
				VCC_FWD_CALL_LOGS_WRITER.setNewFileInterval(config.getInt("RULEBLOCK_LOG_FILE_INTERVAL"));
				VCC_FWD_CALL_LOGS_WRITER.setFilename(config.getString("RULEBLOCK_LOG_FILENAME").trim());
				VCC_FWD_CALL_LOGS_WRITER.setFilePath(config.getString("RULEBLOCK_LOG_FILEPATH").trim());
				VCC_FWD_CALL_LOGS_WRITER.setArchiveFilePath(config.getString("RULEBLOCK_LOG_FILENAME_ARCH").trim());
				VCC_FWD_CALL_LOGS_WRITER.setArchiveFilename(config.getString("RULEBLOCK_LOG_FILEPATH_ARCH").trim());
				VCC_FWD_CALL_LOGS_WRITER.setArchiveFileExtension("");
				VCC_FWD_CALL_LOGS_WRITER.setIncludeTime(false);
				VCC_FWD_CALL_LOGS_WRITER.initialize();
				//Add Header Here
				VCC_FWD_CALL_LOGS_WRITER.writeLog("SERVER_ID,CALL_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,CIRCUIT_ID,IAM_CAUSE_CODE,REL_CAUSE_CODE,MSG_LENGTH,VOICE_MSG_INDEX,CALL_TIME,CALL_DURATION,ANSWERED,SERVICE_TYPE,SUB_TYPE,RATE_PLAN,FILENAME,ORG_CNT_CODE");
			}
		} catch(Exception e) {
			logger.error("Exception in loadFileLogWriter(): "+e);
			e.printStackTrace();
		}
		logger.info("Exit loadFileLogWriter()");
	}

}
