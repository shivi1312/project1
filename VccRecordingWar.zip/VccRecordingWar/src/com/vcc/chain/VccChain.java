package com.vcc.chain;

import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.request.VccMessageRequest;
import com.vcc.response.VccMessageResponse;

public interface VccChain {

	public abstract void setNext(VccChain nextInVmChain,
		 VccServices vccServices);

	public abstract void process(VccMessageRequest messageRequest, VccMessageResponse messageResponse,
			VmError vmError);
	
	
}
