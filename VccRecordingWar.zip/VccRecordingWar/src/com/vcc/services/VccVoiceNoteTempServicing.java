package com.vcc.services;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VnRequest;

public class VccVoiceNoteTempServicing {
	final static Logger logger = Logger
			.getLogger(VccVoiceNoteTempServicing.class);

	private VccCommonOperation commonOperation = new VccCommonOperation();

	// private VccServices vccServices;
	public VccVoiceNoteTempServicing() {

	}

	public void handleVoiceNote(ProfileRequest profileRequest,
			VccServices vccServices) {
		logger.debug("Inside handle VoiceNote Unsubscription");
		VnRequest vnRequest = new VnRequest();
		this.setTempSubscriptionParameters(vnRequest, profileRequest);

		logger.debug("VnRequest to be inserted >>>> "
				+ new Gson().toJson(vnRequest));
		boolean status = vccServices.userService
				.insertIntoVccTempSubscription(vnRequest);
		logger.info("CallingNum[" + profileRequest.getCallingNum()
				+ "] CalledNum[" + profileRequest.getCalledNum()
				+ "] Inserted into vcc_vn_temp_subscription. Status[" + status
				+ "]");
		if (status) {
			logger.debug("CallingNum ["
					+ profileRequest.getCallingNum()
					+ "] CalledNum["
					+ profileRequest.getCalledNum()
					+ "] Successfully Inserted in VCC_VN_TEMP_SUBSCRIPTION table !");
		} else {
			logger.debug("CallingNum ["
					+ profileRequest.getCallingNum()
					+ "] CalledNum["
					+ profileRequest.getCalledNum()
					+ "] Unsuccessfull Insertion in VCC_VN_TEMP_SUBSCRIPTION table !");
		}

	}

	private void setTempSubscriptionParameters(VnRequest vnRequest,
			ProfileRequest profileRequest) {
		logger.debug("Request Parameters>>>>>>>>>>> "
				+ new Gson().toJson(profileRequest));
		vnRequest.setCallingNum(profileRequest.getCallingNum());
		vnRequest.setCalledNum(profileRequest.getCalledNum());
		vnRequest.setCallTime(profileRequest.getCallTime());
		vnRequest.setCallDuration(profileRequest.getCallDuration());
		if (profileRequest.getRecordFileName() == null
				|| profileRequest.getRecordFileName().equalsIgnoreCase("")
				|| profileRequest.getRecordFileName().equalsIgnoreCase("0"))
		{
			vnRequest.setRecordFileName("NA");
		}else{
			vnRequest.setRecordFileName(profileRequest.getRecordFileName());
		}
		vnRequest.setRecordingDuration(this
				.getRecordingDuration(profileRequest));
		vnRequest.setServiceType(profileRequest.getServiceType());
		if (profileRequest.getLang() != 0)
			vnRequest.setLang(profileRequest.getLang());
		else
			vnRequest.setLang(1);
		vnRequest.setClassType(0);
		vnRequest.setServerId(profileRequest.getServerId());
		vnRequest.setCallUUID(profileRequest.getCallUUID());
		vnRequest.setIamCauseCode(profileRequest.getReleaseCode());
		vnRequest.setRelCauseCode(profileRequest.getHangupCause());
		//vnRequest.setMsgLength(this.getMessageLength(profileRequest));
		vnRequest.setMsgLength(this
				.getRecordingDuration(profileRequest));
		vnRequest.setAnswerd(profileRequest.getAnswerd());
		vnRequest.setOrgCntCode(commonOperation.getCountryCode(profileRequest
				.getCallingNum()));
		vnRequest.setStatus("I");
		vnRequest.setRetryCount(0);
		vnRequest.setIsSilentDetect(profileRequest.getIsSilentDetect());

	}

		private int getRecordingDuration(ProfileRequest profileRequest) {

		int recDuration = 0;
		if (profileRequest.getRecordingDuration() != 0) {
			recDuration = profileRequest.getRecordingDuration();

		}
		logger.debug("recording Duration is " + recDuration);
		return recDuration;
	}

	public int getRetSecond(String dateStart, Date dateStop) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		Date d1 = null;
		Date d2 = null;
		logger.debug("date start [" + dateStart + "] and datestop [" + dateStop
				+ "]");
		try {
			d1 = format.parse(dateStart);
			d2 = format.parse(format.format(dateStop));
			logger.debug("Date parse date start [" + d1 + "] and datestop ["
					+ d2 + "]");
			// in milliseconds
			long diff = d2.getTime() - d1.getTime();

			int diffSeconds = (int) ((diff / 1000));
			logger.debug("total record duration is [" + diffSeconds + "] di["
					+ (diff / 1000 % 60) + "]");
			return diffSeconds;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;

		}

	}

	private String getRecordFileName() {
		Date date = new Date();
		String nanoSec = String.valueOf(System.nanoTime());
		String recordFileName = "";
		nanoSec = (String) nanoSec.subSequence(nanoSec.length() - 6,
				nanoSec.length());
		recordFileName = getDateInFormat("yy").format(date)
				+ getDateInFormat("MM").format(date)
				+ getDateInFormat("dd").format(date)
				+ getDateInFormat("HH").format(date)
				+ getDateInFormat("mm").format(date)
				+ getDateInFormat("ss").format(date) + nanoSec;
		logger.debug("RecordFileName is [" + recordFileName + "]");
		return recordFileName;

	}

	private SimpleDateFormat getDateInFormat(String pattern) {

		SimpleDateFormat sdf = new SimpleDateFormat(pattern);

		return sdf;

	}

	private int getMessageLength(ProfileRequest profileRequest) {
		int msgLength = 0;
		if (profileRequest.getRecordingDuration() < 1 && profileRequest.getAnswerd() == 0) {
			msgLength = 0;

		} else if (profileRequest.getRecordingDuration() < 1 && profileRequest.getAnswerd() == 1 && profileRequest.getCallDuration() > 1) {
			msgLength = profileRequest.getCallDuration() - 7;
		} else {
			msgLength = profileRequest.getRecordingDuration();

		}
		return msgLength;
	}

}
