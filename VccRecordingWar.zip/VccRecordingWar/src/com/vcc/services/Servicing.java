package com.vcc.services;

import java.util.List;

import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;

public interface Servicing {

	public VccSubscriptionMaster getActiveService();

	public boolean canConsent();

	public boolean doConsent(ProfileRequest profileRequest, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices, List<VccSubscriptionMaster> master);

}
