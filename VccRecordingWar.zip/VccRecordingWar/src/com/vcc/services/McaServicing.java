package com.vcc.services;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.List;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.model.VccAuthUser;
import com.vcc.model.VccServiceProvider;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VccSubscriptionRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.response.VccSubscriptionResponse;

public class McaServicing implements Servicing {

	final static Logger logger = Logger.getLogger(McaServicing.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	@SuppressWarnings("unused")
	private VccServiceProvider provider;
	private VccSubscriptionMaster backer;
	private VccAuthUser authUser;
	private boolean isActive;
	private boolean isUserOptout;
	@SuppressWarnings("unused")
	private VccCommonOperation commonOperation = null;
	private VccSubscriptionResponse subscriptionResponse = null;
	private VccSubscriptionRequest subscriptionRequest = null;
	private Gson gson = new Gson();
	private List<VccSubscriptionMaster> activeServiceList;

	public McaServicing(VccServiceProvider provider,
			VccSubscriptionMaster backer,List<VccSubscriptionMaster> activeServiceList) {
		this.provider = provider;
		this.backer = backer;
		this.activeServiceList = activeServiceList;
	}

	@Override
	public VccSubscriptionMaster getActiveService() {
		return this.backer;
	}

	@Override
	public boolean canConsent() {
		return true;
	}

	/**
	 * return status this method is responsible for check whether calledNum is
	 * subscriber or not
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of profileResponse , which actually
	 *            return in url response like - isSuccess , isCallAllowed,
	 *            isSubscriber
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return status return true/false if calledNum is subscribe than return
	 *         true otherwise false
	 * @see nothing
	 */
	private VccSubscriptionMaster getUserActiveService(ProfileRequest profileRequest,
			VccServices vccServices, String serviceType){
		VccSubscriptionMaster vccMaster = null;
		if(this.activeServiceList != null){
			for(VccSubscriptionMaster vccSub: this.activeServiceList){
				if(vccSub.getServiceType().equalsIgnoreCase(serviceType)){
					vccMaster = vccSub;
					logger.debug(String.format("[%s] [%s] Profile matched", 
							profileRequest.getCalledNum(),serviceType));
					break;
				}
			}
		}
		if(vccMaster == null){
			logger.debug(String.format("[%s] [%s] Profile did not match going to execute query", 
					profileRequest.getCalledNum(),serviceType));
			vccMaster = vccServices.userService.getActiveUserByServiceType(
					profileRequest.getCalledNum(),serviceType);
		}
		return vccMaster;
	}
	public VccAuthUser getAuthDetail(List<VccSubscriptionMaster> master){
		VccAuthUser authUser = null;
		try {
			if(master != null){
				for(VccSubscriptionMaster vccSub: master){
					return gson.fromJson(gson.toJson(vccSub), VccAuthUser.class);
				}
			}
		}catch(Exception e){
			logger.error("Error while convert master to auth user: "+e.getMessage());
		}
		return authUser;
	}
	@Override
	public boolean doConsent(ProfileRequest profileRequest,
			ProfileResponse profileResponse, VmError vmError,
			VccServices vccServices, List<VccSubscriptionMaster> master) {

		/*
		 * if (!isActive && profileResponse.getIsCallAllowed() == 1) {
		 * isUserOptout =
		 * vccServices.userService.isUserIsOptedOut(profileRequest,
		 * profileResponse); } if (profileResponse.getIsCallAllowed() == 1)
		 * authUser =
		 * vccServices.userService.getProfileDetailByCalledNum(profileRequest);
		 * this.setOutput(profileRequest, profileResponse, vmError,
		 * vccServices); return true;
		 */

		// Added by AbhiShek Rana on 11/05/2016 for setting MCA as default
		// service.
		/*
		 * Commented by richard
		 * if (profileResponse.getIsCallAllowed() == 0)*/
		if (profileResponse.getIsCallAllowed() == 1) {
			profileRequest.setServiceType(AppConfig.config.getString("MCA",
					"0001"));
			if(this.backer==null)
			this.isUserOptout = vccServices.userService.isUserIsOptedOut(
					profileRequest, profileResponse);
		}
		if (!this.isUserOptout) {

			profileResponse.setIsNotifyMeWithMCM(1);
			/*this.authUser = vccServices.userService
					.getProfileDetailByCalledNum(profileRequest);*/
			this.authUser = this.getAuthDetail(master);
			profileResponse.setIsNew(0);
			if(this.backer==null)
				this.backer = this.getUserActiveService(profileRequest, vccServices, 
						AppConfig.config.getString("MCA", "0001"));
/*				this.backer = vccServices.userService.getActiveUserByServiceType(
					profileRequest.getCalledNum(),
					AppConfig.config.getString("MCA", "0001"));*/

			if (this.authUser != null && this.backer != null) {
				this.isActive = true;
			}

		}

		profileResponse.setIsSubscriber(this.isActive?1:0);
		if (!this.isActive && profileResponse.getIsCallAllowed() == 1
				&& !this.isUserOptout) {
			this.setSubscriptionParams(profileRequest);

			String jsonData = this.gson.toJson(this.subscriptionRequest);

			logger.info(String.format(
					"A-Party [%s] B-Party [%s] active service [%s] MCA "
							+ " allowed ",
					profileRequest.getCallingNum(),
					profileRequest.getCalledNum(),
					AppConfig.config.getString(profileResponse.getServiceType()
							+ "_service_name", "Mca")));

			this.callTcp(jsonData);
			if (this.subscriptionResponse != null) {
				if (this.subscriptionResponse.getResult().equalsIgnoreCase(
						"success")) {
					profileResponse.setIsCallAllowed(0);
					profileResponse.setIsSubscriber(1);
					logger.info(String.format(
							"A-Party [%s] B-Party [%s] active service [%s] MCA "
									+ " allowed rule engine response msg [%s]",
							profileRequest.getCallingNum(),
							profileRequest.getCalledNum(),
							AppConfig.config.getString(
									profileResponse.getServiceType()
											+ "_service_name", "Mca"),
							this.subscriptionResponse.getMsg()));

				} else {
					profileResponse.setIsCallAllowed(0);
					logger.info(String
							.format("A-Party [%s] B-Party [%s] active service [%s] Mca "
									+ "not allowed due system fail rule engine response msg [%s]  ",
									profileRequest.getCallingNum(),
									profileRequest.getCalledNum(),
									AppConfig.config.getString(
											profileResponse.getServiceType()
													+ "_service_name", "Mca"),
									this.subscriptionResponse.getMsg()
							/* ,this.subscriptionResponse.getInfo().isBl() */));

				}

			} else {
				profileResponse.setIsCallAllowed(0);
			}

		}

		if (!this.isActive && profileResponse.getIsCallAllowed() == 0
				&& !this.isUserOptout) {
			if (profileRequest.getServiceType() == null)
				profileRequest.setServiceType(AppConfig.config.getString("MCA",
						"0001"));
			if(this.authUser==null)
			this.authUser = vccServices.userService
					.getProfileDetailByCalledNum(profileRequest);
			if(this.backer==null)
				this.backer = this.getUserActiveService(profileRequest, vccServices, 
						profileRequest.getServiceType());
/*			this.backer = vccServices.userService.getActiveUserByServiceType(
					profileRequest.getCalledNum(),
					profileRequest.getServiceType());*/
		}
		this.setOutput(profileRequest, profileResponse, vmError, vccServices);
		return true;

	}

	/**
	 * return void this method is responsible for set the response on
	 * profileResponse bean
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of profileResponse , which actually
	 *            return in url response like - isSuccess , isCallAllowed,
	 *            isSubscriber
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	private void setOutput(ProfileRequest profileRequest,
			ProfileResponse profileResponse, VmError vmError,
			VccServices vccServices) {
		if (authUser != null) {
			profileResponse.setLang(backer.getLanguage());
			profileResponse.setRatePlan(backer.getRatePlan());
			//profileResponse.setSubType(AppConfig.config.getString("MCA"));
			profileResponse.setSubType(authUser.getSubType());
			profileResponse.setClassType(authUser.getClassType());
			profileResponse.setGreetingType(authUser.getGreetingType());
			profileResponse.setServiceType(backer.getServiceType());
			profileResponse.setIsCallAllowed(0);
			profileResponse.setIsSuccess(AppConfig.config.getInt(
					"default_service_success", 1));
			logger.info(String.format(
					"A-Party [%s] B-Party serviceType [%s] set "
							+ "response for active service [%s] isOptout [%s]",
					profileRequest.getCallingNum(),
					profileRequest.getCalledNum(),
					AppConfig.config.getString(""
							+ profileResponse.getServiceType()), isUserOptout));
		} else {
			profileResponse.setLang(AppConfig.config.getInt(
					"vms_default_language", 0));
			profileResponse.setRatePlan(AppConfig.config.getInt(
					"default_rate_plan", 0));
			profileResponse.setSubType(AppConfig.config.getString(
					"default_sub_type", "0"));
			profileResponse.setClassType(AppConfig.config.getInt(
					"default_class_type", 0));
			profileResponse.setGreetingType(AppConfig.config.getInt(
					"default_greeting_type", 0));
			profileResponse.setServiceType(AppConfig.config.getString(
					"default_service_type", "0000"));
			profileResponse.setIsSuccess(AppConfig.config.getInt(
					"default_service_fail", 0));
			logger.info(String
					.format("A-Party [%s] B-Party serviceType [%s] set "
							+ "response for no active service [%s] isOptout [%s]",
							profileRequest.getCallingNum(),
							profileRequest.getCalledNum(),
							profileResponse.getServiceType(), isUserOptout));
		}
	}

	private void setSubscriptionParams(ProfileRequest profileRequest) {
		this.subscriptionRequest = new VccSubscriptionRequest();
		this.subscriptionRequest.setMsisdn(profileRequest.getCalledNum());
		this.subscriptionRequest.setLang(AppConfig.config.getInt(
				"vms_default_language", 1));
		this.subscriptionRequest.setActionId(AppConfig.config.getString(
				"mcasub_actionId", "1"));
		this.subscriptionRequest.setChannel(AppConfig.config
				.getString("default_channel"));
		this.subscriptionRequest.setInterFace(AppConfig.config
				.getString("default_interface"));
		this.subscriptionRequest.setTid(String.valueOf(System.nanoTime()));
		this.subscriptionRequest.setServiceType(AppConfig.config
				.getString("MCA"));
		this.subscriptionRequest.setPlanName(AppConfig.config.getString(
				"MCA_DEFAULT_PLAN", "basic"));
		this.subscriptionRequest.setAppId(AppConfig.config.getString("app_id"));

	}

	public void callTcp(String json) {
		Socket socket = null;
		DataOutputStream out = null;
		DataInputStream reader = null;
		String response = null;
		try {
			socket = new Socket(AppConfig.config.getString("rule_engine_ip",
					"10.237.236.14"), AppConfig.config.getInt(
					"rule_engine_port", 9097));

			socket.setSoTimeout(AppConfig.config.getInt(
					"rule_engine_socket_timeout", 10000));
			logger.info("Server has connected!\n");
			logger.info("Sending string: '" + json + "'\n");
			out = new DataOutputStream(socket.getOutputStream());
			out.writeUTF(json);
			out.flush();
			reader = new DataInputStream(socket.getInputStream());
			response = reader.readUTF();
			if (response != null) {
				this.subscriptionResponse = this.gson.fromJson(response,
						VccSubscriptionResponse.class);
				logger.info("request: " + json + " response: " + response);
			} else {
				logger.info("request: " + json + " response: " + response);
			}

			try {
				logger.info("post delay after subscription/unsubcription for ["
						+ AppConfig.config.getInt("post_delay_after_sub", 0)
						+ "] sec");
				Thread.sleep(AppConfig.config.getInt("post_delay_after_sub", 0));
			} catch (Exception e) {
				logger.error(String.format(
						"wait for  post_delay_after_sub time [%s]  : ",
						AppConfig.config.getInt("post_delay_after_sub", 0)), e);

			}

		} catch (SocketTimeoutException ex) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"90017] [SocketTimeout Exception while connecting to Rule Engine] Error["+ ex.getMessage() +"]");
			logger.error(
					String.format("[%s] Socket Time out Exception : ", json),
					ex);
			try {
				if (out != null)
					out.close();
				if (reader != null)
					reader.close();
				if (socket != null)
					socket.close();
				return;
			} catch (Exception e) {
				return;
			}

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00058] [Exception while connecting to Rule Engine] Error["+ e.getMessage() +"]");

			logger.error(String.format("[%s] Error: ", json), e);
			e.printStackTrace();
			return;
		} finally {
			try {
				if (out != null)
					out.close();
				if (reader != null)
					reader.close();
				if (socket != null)
					socket.close();
			} catch (Exception e) {
			}
		}
		logger.info("Socket is closed [" + socket.isClosed() + "]");

	}

	public boolean canOptOut() {
		return true;
	}
}
