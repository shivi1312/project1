package com.vcc.services;

import java.util.List;

import com.vcc.model.MessageAttribute;
import com.vcc.model.VccFwdCallLogs;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.model.VccVoiceMessage;
import com.vcc.request.VccMessageRequest;

public interface MessageService {


	public int getNextIndex();

	public int insertVoiceMessage(VccVoiceMessage vmsMessage);

	
	public int insertFwdCallLogs(VccFwdCallLogs fwdCallLogs);
	
	public int getMessageCount(VccMessageRequest messageRequest);
	
	public List<MessageAttribute> getMessageInfo(VccMessageRequest messageRequest);
	
	public String getGreetingFile(String msisdn);
	
	public Boolean updateMsgStatus(String msisdn,int voiceMsgIndex);
	
	public Boolean insertVoiceMsgWithScheduling(
			VccVoiceMessage vccVoiceMessage,
			VccUserCompleteDetails completeDetails);
	
}