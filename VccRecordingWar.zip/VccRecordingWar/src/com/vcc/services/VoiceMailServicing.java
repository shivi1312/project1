package com.vcc.services;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.List;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.model.VccAuthUser;
import com.vcc.model.VccServiceProvider;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VccSubscriptionRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.response.VccSubscriptionResponse;

public class VoiceMailServicing implements Servicing {

	final static Logger logger = Logger.getLogger(VoiceMailServicing.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	@SuppressWarnings("unused")
	private VccServiceProvider provider;
	private VccSubscriptionMaster backer;
	private VccAuthUser authUser;
	private boolean isActive;
	private boolean isUserOptout=false;
	private VccCommonOperation commonOperation = null;
	private VccSubscriptionResponse subscriptionResponse = null;
	private VccSubscriptionRequest subscriptionRequest = null;
	private Gson gson = new Gson();
	
	private List<VccSubscriptionMaster> activeServiceList;

	public VoiceMailServicing(VccServiceProvider provider,
			VccSubscriptionMaster backer,List<VccSubscriptionMaster> activeServiceList) {
		this.provider = provider;
		this.backer = backer;
		this.activeServiceList = activeServiceList;
	}

	@Override
	public VccSubscriptionMaster getActiveService() {
		return this.backer;
	}

	@Override
	public boolean canConsent() {
		return true;
	}
	private VccSubscriptionMaster getUserActiveService(ProfileRequest profileRequest,
			VccServices vccServices, String serviceType){
		VccSubscriptionMaster vccMaster = null;
		if(this.activeServiceList != null){
			for(VccSubscriptionMaster vccSub: this.activeServiceList){
				if(vccSub.getServiceType().equalsIgnoreCase(serviceType)){
					vccMaster = vccSub;
					logger.debug(String.format("[%s] [%s] Profile matched", 
							profileRequest.getCalledNum(),serviceType));
					break;
				}
			}
		}
		if(vccMaster == null){
			logger.debug(String.format("[%s] [%s] Profile did not match going to execute query", 
					profileRequest.getCalledNum(),serviceType));
			vccMaster = vccServices.userService.getActiveUserByServiceType(
					profileRequest.getCalledNum(),serviceType);
		}
		return vccMaster;
	}
	public VccAuthUser getAuthDetail(List<VccSubscriptionMaster> master){
		VccAuthUser authUser = null;
		try {
			if(master != null){
				for(VccSubscriptionMaster vccSub: master){
					return gson.fromJson(gson.toJson(vccSub), VccAuthUser.class);
				}
			}
		}catch(Exception e){
			logger.error("Error while convert master to auth user: "+e.getMessage());
		}
		return authUser;
	}
	@Override
	public boolean doConsent(ProfileRequest profileRequest,
			ProfileResponse profileResponse, VmError vmError,
			VccServices vccServices, List<VccSubscriptionMaster> master) {

		if (profileResponse.getIsCallAllowed() == 1) {
			profileRequest.setServiceType(AppConfig.config.getString("VM",
					"0010"));
			if(this.backer==null)
			this.isUserOptout = vccServices.userService.isUserIsOptedOut(profileRequest, profileResponse);
		}
		if (!this.isUserOptout) {
			profileResponse.setIsCallAllowed(1);
			profileResponse.setIsNotifyMeWithMCM(0);
			//this.authUser = vccServices.userService.getProfileDetailByCalledNum(profileRequest);
			this.authUser = this.getAuthDetail(master);
			if(this.backer==null)
				this.backer = this.getUserActiveService(profileRequest, vccServices,
						AppConfig.config.getString("VM", "0010"));
			if (this.authUser != null && this.backer != null)
				this.isActive = true;
			
		}
		profileResponse.setIsSubscriber(this.isActive?1:0);
		if (!this.isActive && profileResponse.getIsCallAllowed() == 1
				&& !this.isUserOptout) {
			
			profileResponse.setIsCallAllowed(1);
			profileResponse.setIsSubscriber(1);
			/*
			this.setSubscriptionParams(profileRequest);
			String jsonData = this.gson.toJson(this.subscriptionRequest);
			logger.info(String.format(
					"A-Party [%s] B-Party [%s] active service [%s] Voice "
							+ "mail  allowed ",
					profileRequest.getCallingNum(),
					profileRequest.getCalledNum(),
					AppConfig.config.getString(profileResponse.getServiceType()
							+ "_service_name", "Voice Mail")));
			this.callTcp(jsonData);
			if (this.subscriptionResponse != null) {
				if (this.subscriptionResponse.getResult().equalsIgnoreCase(
						"success")) {
					profileResponse.setIsCallAllowed(1);
					logger.info(String.format("A-Party [%s] B-Party [%s] active service [%s] Voice "
							+ "mail  allowed rule engine response msg [%s]",profileRequest.getCallingNum(),
							profileRequest.getCalledNum(),AppConfig.config.getString(
							profileResponse.getServiceType()+ "_service_name","Voice Mail"),
							this.subscriptionResponse.getMsg()));
				} else {
					profileResponse.setIsCallAllowed(0);
					logger.info(String.format("A-Party [%s] B-Party [%s] active service [%s] Voice "
						+ "mail not allowed due system fail rule engine response msg [%s] reason [%s] ",
						profileRequest.getCallingNum(),profileRequest.getCalledNum(),AppConfig.config.getString(
						profileResponse.getServiceType()+ "_service_name","Voice Mail"),
						this.subscriptionResponse.getMsg(),this.subscriptionResponse.getInfo().isBl()));
				}
			} else {
				profileResponse.setIsCallAllowed(0);

			}

		*/
			
		}

		if (!this.isActive && profileResponse.getIsCallAllowed() == 1
				&& !this.isUserOptout) {
			if (profileRequest.getServiceType() == null)
				profileRequest.setServiceType(AppConfig.config.getString("VM",
						"0010"));
			if(this.authUser==null)
			this.authUser = vccServices.userService.getProfileDetailByCalledNum(profileRequest);
			if(this.backer==null)
			this.backer = vccServices.userService.getActiveUserByServiceType(
					profileRequest.getCalledNum(),
					profileRequest.getServiceType());
		}
		this.setOutput(profileRequest, profileResponse, vmError, vccServices);
		return true;
	}

	private void setOutput(ProfileRequest profileRequest,
			ProfileResponse profileResponse, VmError vmError,
			VccServices vccServices) {
		/*
		 * Commented by Richard on 4th April 2018 as when backer object finds
		 * null then we were getting NullPointerException. Because if user is a subscriber of voice note and not of voice mail
		 * then authUser will not be null because query to find authUser doen not include service_type but only msisdn
		 * while backer object we found null as query in this case includes both msisdn and service_type. 
		 * 
		 * 
		 * if (this.authUser != null &&
		 * this.backer.getStatus().equalsIgnoreCase("A"))
		 */
		try {
			if (this.authUser != null && this.backer != null
					&& this.backer.getStatus() != null && this.backer.getStatus().equalsIgnoreCase("A")) {
				profileResponse.setIsUserIsOptedOut(0);
				profileResponse.setLang(this.authUser.getLanguage());
				profileResponse.setRatePlan(this.backer.getRatePlan());
				profileResponse.setSubType(this.authUser.getSubType());
				profileResponse.setClassType(this.authUser.getClassType());
				profileResponse
						.setGreetingType(this.authUser.getGreetingType());
				if (profileRequest.getServiceType() != null)
					profileResponse.setServiceType(profileRequest
							.getServiceType());
				else
					profileResponse
							.setServiceType(this.backer.getServiceType());
				profileResponse.setIsSuccess(AppConfig.config.getInt(
						"default_service_success", 1));
				logger.debug("greet type " + profileResponse.getGreetingType());
				if (profileResponse.getGreetingType() == 1) {
					String greetPath = vccServices.messageService
							.getGreetingFile(profileRequest.getCalledNum());
					if (greetPath != null) {
						commonOperation = new VccCommonOperation();
						greetPath = commonOperation
								.getCopletePath(
										greetPath.substring(
												0,
												greetPath.length()
														- AppConfig.config
																.getInt("default_record_digits",
																		10)),
										profileRequest.getCalledNum(),
										greetPath, AppConfig.config
												.getString("ivr_greeting_path"));
						logger.info("[" + profileRequest.getCallingNum()
								+ "] called num ["
								+ profileRequest.getCalledNum()
								+ "] greeting path is [" + greetPath + "]");
						profileResponse.setGreetPath(greetPath);

					}
				}
				logger.info(String
						.format("A-Party [%s] B-Party [%s] active service [%s] isOptout [%s] greetType [%s]",
								profileRequest.getCallingNum(), profileRequest
										.getCalledNum(), AppConfig.config
										.getString(
												profileResponse
														.getServiceType()
														+ "_service_name",
												"Voice Mail"), isUserOptout,
								profileResponse.getGreetingType()));

			} else {
				profileResponse.setIsCallAllowed(1);
				profileResponse.setIsUserIsOptedOut(0);
				profileResponse.setLang(AppConfig.config.getInt(
						"vms_default_language", 1));
				profileResponse.setRatePlan(AppConfig.config.getInt(
						"default_rate_plan", 20));
				profileResponse.setSubType(AppConfig.config.getString(
						"default_sub_type", "N"));
				profileResponse.setClassType(AppConfig.config.getInt(
						"default_class_type", 0));
				profileResponse.setGreetingType(AppConfig.config.getInt(
						"default_greeting_type", 0));
				if (profileRequest.getServiceType() != null)
					profileResponse.setServiceType(profileRequest
							.getServiceType());
				else
					profileResponse.setServiceType(AppConfig.config.getString(
							"default_service_type", "0010"));
				profileResponse.setIsSuccess(AppConfig.config.getInt(
						"default_service_fail", 0));
				logger.info(String
						.format("A-Party [%s] B-Party [%s] inactive service [%s] isOptout [%s]",
								profileRequest.getCallingNum(), profileRequest
										.getCalledNum(), AppConfig.config
										.getString(
												profileResponse
														.getServiceType()
														+ "_service_name",
												"Voice Mail"), isUserOptout));
			}
		} catch (NullPointerException e) {
			logger.error("callingNum[" + profileRequest.getCallingNum()
					+ "] calledNum[" + profileRequest.getCalledNum()
					+ "] callUUID[" + profileRequest.getCallUUID() + "] Error["
					+ e + "]");
		} catch (Exception e) {
			logger.error("callingNum[" + profileRequest.getCallingNum()
					+ "] calledNum[" + profileRequest.getCalledNum()
					+ "] callUUID[" + profileRequest.getCallUUID() + "] Error["
					+ e + "]");
		}
	}

	private void setSubscriptionParams(ProfileRequest profileRequest) {
		this.subscriptionRequest = new VccSubscriptionRequest();
		this.subscriptionRequest.setMsisdn(profileRequest.getCalledNum());
		this.subscriptionRequest.setLang(AppConfig.config.getInt(
				"vms_default_language", 1));
		this.subscriptionRequest.setActionId(AppConfig.config.getString(
				"vmsub_actionId", "1"));
		this.subscriptionRequest.setChannel(AppConfig.config
				.getString("default_channel"));
		this.subscriptionRequest.setInterFace(AppConfig.config
				.getString("default_rec_interface"));
		this.subscriptionRequest.setTid(String.valueOf(System.nanoTime()));
		this.subscriptionRequest.setServiceType(AppConfig.config
				.getString("VM"));
		this.subscriptionRequest.setPlanName(AppConfig.config.getString(
				"VM_DEFAULT_PLAN", "basic"));
		this.subscriptionRequest.setAppId(AppConfig.config.getString("app_id"));
		this.subscriptionRequest.setReqBy(profileRequest.getCalledNum());
		this.subscriptionRequest.setActTrg(AppConfig.config.getString(
				"reason.code.trigger." + profileRequest.getReleaseCode() + "", "2"));
		if (profileRequest.getSubType() != null)
			this.subscriptionRequest.setSubType(profileRequest.getSubType());
		else
			this.subscriptionRequest.setSubType(AppConfig.config.getString(
					"default_sub_type", "N"));

	}

	public void callTcp(String json) {
		Socket socket = null;
		DataOutputStream out = null;
		DataInputStream reader = null;
		String response = null;
		try {
			socket = new Socket(AppConfig.config.getString("rule_engine_ip",
					"10.237.236.14"), AppConfig.config.getInt(
					"rule_engine_port", 9097));

			socket.setSoTimeout(AppConfig.config.getInt(
					"rule_engine_socket_timeout", 10000));
			logger.info("Server has connected!\n");
			logger.info("Sending string: '" + json + "'\n");
			out = new DataOutputStream(socket.getOutputStream());
			out.writeUTF(json);out.flush();
			reader = new DataInputStream(socket.getInputStream());
			response = reader.readUTF();
			if (response != null) {
				this.subscriptionResponse = this.gson.fromJson(response,VccSubscriptionResponse.class);
				logger.info("request: " + json + " response: " + response);
			} else {
				logger.info("request: " + json + " response: " + response);
			}

			if (this.subscriptionResponse.getResult().equalsIgnoreCase("success")) {
				try {
					logger.info("post delay after subscription for ["+ AppConfig.config.getInt("post_delay_after_sub", 0)+ "] sec");
					Thread.sleep(AppConfig.config.getInt("post_delay_after_sub", 0));
				} catch (Exception e) {
					logger.error(String.format("wait for  post_delay_after_sub time [%s]  : "
							,AppConfig.config.getInt("post_delay_after_sub", 0)), e);
				}
			}
		} catch (SocketTimeoutException ex) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"90017] "
					+ "[SocketTimeout Exception while connecting to Rule Engine] Error["+ ex.getMessage() +"]");
			logger.error(String.format("[%s] Socket Time out Exception : ", json),
					ex);
			try {
				if (out != null)
					out.close();
				if (reader != null)
					reader.close();
				if (socket != null)
					socket.close();
				return;
			} catch (Exception e) {
				return;
			}

		} catch (Exception e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+
					"00058] [Exception while connecting to Rule Engine] Error["+ e.getMessage() +"]");

			logger.error(String.format("[%s] Error: ", json), e);
			e.printStackTrace();
			return;
		} finally {
			try {
				if (out != null)
					out.close();
				if (reader != null)
					reader.close();
				if (socket != null)
					socket.close();
			} catch (Exception e) {
			}
		}
		logger.info("Socket is closed [" + socket.isClosed() + "]");

	}

	public boolean canOptOut() {
		return true;
	}
}
