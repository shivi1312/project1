package com.vcc.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.vcc.dao.ProfileDao;
import com.vcc.dao.RateDao;
import com.vcc.model.VccAuthUser;
import com.vcc.model.VccClassType;
import com.vcc.model.VccFwdCallLogs;
import com.vcc.model.VccPersonalGreeting;
import com.vcc.model.VccRatePlan;
import com.vcc.model.VccSeriesRange;
import com.vcc.model.VccServiceProvider;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.model.VccVoiceMessage;
import com.vcc.request.ProfileRequest;
import com.vcc.request.RetLogRequest;
import com.vcc.request.VccGreetingRequest;
import com.vcc.request.VmRequest;
import com.vcc.request.VnRequest;
import com.vcc.response.ProfileResponse;

public class VccUserService implements UserService {

	@Autowired
	ProfileDao voiceMessageDao;
	@Autowired
	RateDao rateService;

	@Override
	public int getNextIndex(String msisdn,String serviceType) {
		return voiceMessageDao.getNextIndex(msisdn,serviceType);
	}

	@Override
	public int insertVoiceMessage(VccVoiceMessage vmsMessage) {
		return voiceMessageDao.insertVoiceMessage(vmsMessage);
	}

	@Override
	public List<VccSubscriptionMaster> getActiveServiceList(
			ProfileRequest profileRequest) {
		return voiceMessageDao.getActiveServiceList(profileRequest);
	}

	@Override
	public List<VccRatePlan> getRatePlan() {
		return rateService.getRatePan();
	}

	public List<VccServiceProvider> getServiceList(ProfileRequest profileRequest) {
		return voiceMessageDao.getServiceList(profileRequest);
	}

	@Override
	public List<VccSeriesRange> isUserExistWithInRange(
			String msisdn) {
		return voiceMessageDao.isUserExistWithInRange(msisdn);
	}

	@Override
	public VccClassType haveAnyClass(ProfileRequest profileRequest) {
		return voiceMessageDao.haveAnyClass(profileRequest);
	}


	@Override
	public List<VccVoiceMessage> getMailboxGroupByCount(
			String msisdn, String serviceType) {
		return voiceMessageDao.getMailboxGroupByCount(msisdn,
				serviceType);
	}

	@Override
	public boolean isUserIsOptedOut(ProfileRequest profileRequest,
			ProfileResponse profileResponse) {
		return voiceMessageDao
				.isUserIsOptedOut(profileRequest, profileResponse);
	}

	@Override
	public int getVoiceMsgIndex(VmRequest vmRequest) {

		return voiceMessageDao.getVoiceMsgIndex(vmRequest);
	}

	@Override
	public int insertFwdCallLogs(VccFwdCallLogs fwdCallLogs) {

		return voiceMessageDao.insertFwdCallLogs(fwdCallLogs);
	}

	@Override
	public List<VccVoiceMessage> getMailboxOrderByCallTime(String msisdn,String serviceType){

		return voiceMessageDao.getMailboxOrderByCallTime(msisdn,serviceType);
	}

	@Override
	public Boolean deleteVccVoiceMessage(String calledNum, int voiceMsgIndex) {

		return voiceMessageDao.deleteVccVoiceMessage(calledNum, voiceMsgIndex);
	}

	@Override
	public VccSubscriptionMaster getActiveUserByServiceType(
			String msisdn,String serviceType) {

		return voiceMessageDao.getActiveUserByServiceType(msisdn,serviceType);
	}

	@Override
	public int updateUserLanguage(ProfileRequest profileRequest) {
		
		return voiceMessageDao.updateUserLanguage(profileRequest);
	}

	@Override
	public boolean isUserSubscribe(String msisdn,String serviceType) {
		
		return voiceMessageDao.isUserSubscribe(msisdn,serviceType);
	}

	@Override
	public int insertRetLog(RetLogRequest retLogRequest) {
		return voiceMessageDao.saveRetrievalLog(retLogRequest);
	}

	@Override
	public List<VccVoiceMessage> getMailboxOrderBySendTime(VmRequest request) {
	
		return voiceMessageDao.getMailboxOrderBySendTime(request);
	}

	@Override
	public int updateVoiceMsgStatus(VmRequest vmRequest, String status) {
		
		return voiceMessageDao.updateVoiceMsgStatus(vmRequest, status);
	}

	@Override
	public List<VccUserCompleteDetails> getUserCompleteDetail(String msisdn) {
		return voiceMessageDao.getUserCompleteDetail(msisdn);
	}
	
	@Override
	public List<VccUserCompleteDetails> getUserCompleteDetail(ProfileRequest profileRequest) {
		return voiceMessageDao.getUserCompleteDetail(profileRequest);
	}
	
	@Override
	public List<VccUserCompleteDetails> getUserAuthDetail(ProfileRequest profileRequest) {
		return voiceMessageDao.getUserAuthDetail(profileRequest);
	}
	
	@Override
	public List<VccUserCompleteDetails> getUserSubscriptionDetail(List<VccUserCompleteDetails> vccUserCompleteDetailList) {
		return voiceMessageDao.getUserSubscriptionDetail(vccUserCompleteDetailList);
	}

	@Override
	public int saveVccNotification(VccVoiceMessage vccVoiceMessage,
			VccUserCompleteDetails userCompleteDetails) {
		
		return voiceMessageDao.saveVccNotification(vccVoiceMessage, userCompleteDetails);
	}

	@Override
	public boolean updateUserPassword(ProfileRequest profileRequest) {
		return voiceMessageDao.updateUserPassword(profileRequest);
	}

	@Override
	public boolean saveUserGreeting(VccGreetingRequest greetingRequest) {
		return voiceMessageDao.saveUserGreeting(greetingRequest);
	}

	@Override
	public boolean deleteUserGreeting(VccGreetingRequest greetingRequest) {
		return voiceMessageDao.deleteUserGreeting(greetingRequest);
	}

	@Override
	public VccPersonalGreeting getUserGreeting(String msisdn) {
		return voiceMessageDao.getUserGreeting(msisdn);
	}

	@Override
	public boolean updatePersonalGreeting(VccGreetingRequest greetingRequest) {
		return voiceMessageDao.updatePersonalGreeting(greetingRequest);
	}

	@Override
	public VccAuthUser getProfileDetailByCallingNum(
			ProfileRequest profileRequest) {
	
		return voiceMessageDao.getProfileDetailByCallingNum(profileRequest);
	}

	@Override
	public VccAuthUser getProfileDetailByCalledNum(ProfileRequest profileRequest) {
		
		return voiceMessageDao.getProfileDetailByCalledNum(profileRequest);
	}

	@Override
	public boolean updateGreetingType(int greetingType, String msisdn) {
		return voiceMessageDao.updateGreetingType(greetingType, msisdn);
	}

	@Override
	public boolean updateLastVisitTime(String msisdn) {
		
		return voiceMessageDao.updateLastVisitTime(msisdn);
	}
	@Override
	public boolean insertIntoVccTempSubscription(VnRequest vnRequest){
		return voiceMessageDao.insertIntoVccTempSubscription(vnRequest);
	}
}
