package com.vcc.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.vcc.dao.UserConfigDao;
import com.vcc.model.GroupDetail;
import com.vcc.model.VccSeriesRange;
import com.vcc.request.UserConfigRequest;

public class VccUserConfigService implements UserConfigService {

	@Autowired
	UserConfigDao userConfigDao;
	@Override
	public Boolean insertFrndGroupList(GroupDetail groupDetail) {
		return userConfigDao.insertFrndGroupList(groupDetail);
	}
	@Override
	public int checkGroupIdExists(UserConfigRequest configRequest) {
		
		return userConfigDao.checkGroupIdExists(configRequest);
	}
	@Override
	public Boolean createGroup(GroupDetail groupDetail) {
		
		return userConfigDao.createGroup(groupDetail);
	}
	@Override
	public List<String> getMsisdnList(GroupDetail groupDetail) {
		
		return userConfigDao.getMsisdnList(groupDetail);
	}
	@Override
	public String getGroupName(UserConfigRequest userConfigRequest) {
		
		return userConfigDao.getGroupName(userConfigRequest);
	}
	@Override
	public Boolean deleteGroup(GroupDetail groupDetail) {
	
		return userConfigDao.deleteGroup(groupDetail);
	}
	@Override
	public Boolean deleteGroupDetails(GroupDetail groupDetail) {
		
		return userConfigDao.deleteGroupDetails(groupDetail);
	}
	@Override
	public Boolean updateGroupName(GroupDetail groupDetail) {
		
		return userConfigDao.updateGroupName(groupDetail);
	}
	@Override
	public Boolean deleteMsisdnFromGroup(String ownerMsisdn, int groupId,
			String msisdn) {
		
		return userConfigDao.deleteMsisdnFromGroup(ownerMsisdn, groupId, msisdn);
	}
	@Override
	public Boolean addAlternativeMsisdn(UserConfigRequest userConfigRequest) {
		
		return userConfigDao.addAlternativeMsisdn(userConfigRequest);
	}
	@Override
	public String getMsisdnFromAdvancedDetails(UserConfigRequest userConfigRequest) {
		
		return userConfigDao.getMsisdnFromAdvancedDetails(userConfigRequest);
	}
	
	
	@Override
	public List<VccSeriesRange> isUserExistWithInRange(String msisdn) {
	
		return userConfigDao.isUserExistWithInRange(msisdn);
	}
	@Override
	public String getServiceFlag(String msisdn, String serviceType) {
		
		return userConfigDao.getServiceFlag(msisdn, serviceType);
	}
	@Override
	public int activateOrDeactivateNotification(
			UserConfigRequest userConfigRequest) {
		
		return userConfigDao.activateOrDeactivateNotification(userConfigRequest);
	}
	@Override
	public Boolean updateAlternativeMsisdn(UserConfigRequest userConfigRequest) {
		
		return userConfigDao.updateAlternativeMsisdn(userConfigRequest);
	}
	@Override
	public Boolean deleteAlternativenumber(String msisdn, int serviceFagPos) {
		return userConfigDao.deleteAlternativenumber(msisdn, serviceFagPos);
	}
	@Override
	public int groupCount(String msisdn) {
		
		return userConfigDao.groupCount(msisdn);
	}

}
