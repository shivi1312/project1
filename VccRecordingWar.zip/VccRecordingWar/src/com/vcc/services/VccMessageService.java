package com.vcc.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.vcc.dao.MessageDao;
import com.vcc.dao.ProfileDao;
import com.vcc.dao.RateDao;
import com.vcc.model.MessageAttribute;
import com.vcc.model.VccFwdCallLogs;
import com.vcc.model.VccServiceProvider;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.model.VccVoiceMessage;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VccMessageRequest;

public class VccMessageService implements MessageService {

	@Autowired
	ProfileDao voiceMessageDao;
	@Autowired
	RateDao rateService;
    @Autowired
    MessageDao messageDao;
	
	@Override
	public int getNextIndex() {
		return messageDao.getNextIndex();
	}

	@Override
	public int insertVoiceMessage(VccVoiceMessage vmsMessage) {
		return messageDao.insertVoiceMessage(vmsMessage);
	}

	

	public List<VccServiceProvider> getServiceList(ProfileRequest profileRequest) {
		return voiceMessageDao.getServiceList(profileRequest);
	}


	@Override
	public int insertFwdCallLogs(VccFwdCallLogs fwdCallLogs) {
		
		return voiceMessageDao.insertFwdCallLogs(fwdCallLogs);
	}

	@Override
	public int getMessageCount(VccMessageRequest messageRequest) {
		
		return messageDao.getMessageCount(messageRequest);
	}

	@Override
	public List<MessageAttribute> getMessageInfo(
			VccMessageRequest messageRequest) {
		
		return messageDao.getMessageInfo(messageRequest);
	}

	@Override
	public String getGreetingFile(String msisdn) {
	
		return messageDao.getGreetingFile(msisdn);
	}

	@Override
	public Boolean updateMsgStatus(String msisdn, int voiceMsgIndex) {
		
		return messageDao.updateMsgStatus(msisdn, voiceMsgIndex);
	}

	@Override
	public Boolean insertVoiceMsgWithScheduling(
			VccVoiceMessage vccVoiceMessage,
			VccUserCompleteDetails completeDetails) {
		
		return messageDao.insertVoiceMsgWithScheduling(vccVoiceMessage, completeDetails);
	}

	
	
}
