package com.vcc.handler;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.chain.VmChain;
import com.vcc.common.VccServices;
import com.vcc.domain.VmOperation;
import com.vcc.error.VmError;
import com.vcc.request.VmRequest;
import com.vcc.response.VmResponse;
import com.vcc.util.CopyAndDeleteVmFile;
import com.vcc.validation.FileValidation;

public class VmFileHandler {
	final static Logger logger = Logger.getLogger(VmFileHandler.class);
	private static VmFileHandler vmHandler = new VmFileHandler();
	private VmError vmError = new VmError();

	protected VmFileHandler() {

	}

	public static VmFileHandler getInstance() {
		return vmHandler;
	}

	public void process(VmRequest vmRequest, BindingResult bindingResult,
			VmResponse vmResponse, VccServices vccService) {
		
		VmChain chain = new FileValidation();
		VmChain copyDelFile = new CopyAndDeleteVmFile();
		VmChain saveVmFile = new VmOperation();
		chain.setNext(copyDelFile, vccService);
		copyDelFile.setNext(saveVmFile, vccService);
		chain.process(vmRequest, vmResponse, vmError);

	}
}
