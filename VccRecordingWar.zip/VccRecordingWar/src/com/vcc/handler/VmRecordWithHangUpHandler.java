package com.vcc.handler;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.google.gson.Gson;
import com.vcc.chain.VmChain;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.domain.FwdCallLogs;
import com.vcc.domain.VccSendNotification;
import com.vcc.domain.VmOperation;
import com.vcc.domain.VoiceNoteFilter;
import com.vcc.error.VmError;
import com.vcc.model.VccFwdCallLogs;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.response.VmResponse;
import com.vcc.services.VccVoiceNoteTempServicing;
import com.vcc.util.DeleteOldVmFile;
import com.vcc.util.MailboxFilter;
import com.vcc.util.ParseAndValidateRecordFile;

/*
 * Please check the ParseAndValidateRecordFile filter before making the VccRecordingWar live
 * We have done changes for ESL testing which must be reverted.
 */

public class VmRecordWithHangUpHandler {
	final static Logger logger = Logger
			.getLogger(VmRecordWithHangUpHandler.class);
	private Gson gson = new Gson();
	private VmError vmError = new VmError();
	private VccCommonOperation commonOperation = null;
	private VccServices vccServices;
	public VmRecordWithHangUpHandler() {

	}

	public void process(VmRequest vmRequest, BindingResult bindingResult,
			VmResponse vmResponse, VccServices vccServices) {
		
		
		if (vmRequest.getCallingNum() != null
				&& vmRequest.getCalledNum() != null
				&& vmRequest.getRecordFileName() != null) {
			logger.info("calling [" + vmRequest.getCallingNum() + "] called ["
					+ vmRequest.getCalledNum() + "] file ["
					+ vmRequest.getRecordFileName() + "] silence " + "["
					+ vmRequest.getIsSilentDetect() + "] call-uuid ["
					+ vmRequest.getCallUUID() + "] server ["
					+ vmRequest.getServerId() + "] answered ["
					+ vmRequest.getAnswerd() + "] hangup cause ["
					+ vmRequest.getHangupCause() + "] reason ["
					+ vmRequest.getReasonCode() + "] service ["
					+ vmRequest.getServiceType() + "] notification ["
					+ vmRequest.getNotificationSend() + "] recorded file ["
					+ vmRequest.getRecordTempPath() + "] IsCallAllowed ["
					+ vmRequest.getIsCallAllowed()
					+ "] service_type["+vmRequest.getServiceType()+"] isSuccess["+vmRequest.getIsSuccess()+"] request submitted to handler");
			vmRequest = this.setDuration(vmRequest);
			// int silence = vmRequest.getIsSilentDetect();
			commonOperation = new VccCommonOperation();
			vmRequest.setIsSilentDetect(commonOperation.getIsSilentDetected(vmRequest));
			commonOperation.addAndRemoveCountryCode(vmRequest);
			if (vmRequest.getServiceType().equalsIgnoreCase(
					AppConfig.config.getString("VN", "0100"))) {
				VoiceNoteFilter voiceNoteFilter = new VoiceNoteFilter();
				ProfileResponse profile = voiceNoteFilter.process(vmRequest,
						vmResponse, vmError, vccServices);
				vmRequest = this.setProfileDetail(profile, vmRequest);
				
			}
			boolean subscriberCheck = true;
			if (vmRequest.getAnswerd() == 1
					&& vmRequest.getServiceType().equalsIgnoreCase(
							AppConfig.config.getString("VM", "0010"))) {
				subscriberCheck = commonOperation.checkForSubscription(
						vmRequest, vccServices);
				if(subscriberCheck && vmRequest.getIsSuccess() != 1)
				{
					vmRequest.setIsSuccess(1);
					logger.info("callingNum[" + vmRequest.getCallingNum()
							+ "] calledNum[" + vmRequest.getCalledNum()
							+ "] susbcriberCheck["+subscriberCheck+"] IsSuccess [" + vmRequest.getIsSuccess()
							+ "] Service Type [" + vmRequest.getServiceType() + "] ");
				}
			}
			

			if ((vmRequest.isVoiceNoteActive() && vmRequest.getServiceType()
					.equalsIgnoreCase(AppConfig.config.getString("VN", "0100")))
					|| (vmRequest.getIsSuccess() == 1 && vmRequest
							.getServiceType().equalsIgnoreCase(
									AppConfig.config.getString("VM", "0010")))) {
				
				/*boolean subscriberCheck=commonOperation.checkForSubscription(vmRequest,vccServices);*/
				// Code for getting mailbox detail.
				MailboxFilter filter = new MailboxFilter();
				vmRequest = filter.getMailBoxDetails(vmRequest, vccServices);
				
				// if (silence == 1) {
				if(!subscriberCheck && vmRequest.getServiceType().equalsIgnoreCase(
						AppConfig.config.getString("VM", "0010")))
				{
					VccFwdCallLogs fwdCallLogs=new VccFwdCallLogs();
					commonOperation.setFwdCallLogs(fwdCallLogs,vmRequest);
					int dbStatus=vccServices.userService.insertFwdCallLogs(fwdCallLogs);
					logger.info("User got unsubscribed from some other platform, in between profile.check request and save.hangup request. Calling["
							+ vmRequest.getCallingNum()
							+ "] called["
							+ vmRequest.getCalledNum()
							+ "] call_uuid["
							+ vmRequest.getCallUUID()
							+ "] Service Type [" + vmRequest.getServiceType() + "] Not performing any task further, only inserting into vcc_fwd_call_logs with rate plan 0. Db insert Status["
							+ dbStatus + "]");
				}
				else if (vmRequest.getIsSilentDetect() == 1 || vmRequest.getRecordingDuration()<=AppConfig.config.getInt("IGNORE_RECORDING_LENGTH", 2)) {
					logger.warn("calling [" + vmRequest.getCallingNum()
							+ "] called [" + vmRequest.getCalledNum()
							+ "] call-uuid [" + vmRequest.getCallUUID()
							+ "] server [" + vmRequest.getServerId()
							+ "] silence ["+vmRequest.getIsSilentDetect()
							+ "] Recording Duration["+vmRequest.getRecordingDuration()
							+ "] Either SILENCE DETECTED or Recording Length is Less than or equal to ["+AppConfig.config.getInt("IGNORE_RECORDING_LENGTH", 2)+" seconds]. So Ignoring Recording.");
					// vmRequest.setIsSilentDetect(silence);
					VmChain chain = new DeleteOldVmFile();
					VmChain callFwdLog = new FwdCallLogs();
					VmChain sendNotification = new VccSendNotification();
					chain.setNext(callFwdLog, vccServices);
					callFwdLog.setNext(sendNotification, vccServices);
					chain.process(vmRequest, vmResponse, vmError);

				} 
				else if (AppConfig.config.getInt(
						"vcc_fixedline_record_enable", 0) == 0
						&& vmRequest.getSubType().equalsIgnoreCase("F")) {
					VmChain chain = new DeleteOldVmFile();
					VmChain callFwdLog = new FwdCallLogs();
					chain.setNext(callFwdLog, vccServices);
					chain.process(vmRequest, vmResponse, vmError);
					logger.warn("calling [" + vmRequest.getCallingNum()
							+ "] called [" + vmRequest.getCalledNum()
							+ "] call-uuid [" + vmRequest.getCallUUID()
							+ "] server [" + vmRequest.getServerId()
							+ "] fixed line not allowed for recording !!..");
					
				} else {
					logger.info("calling [" + vmRequest.getCallingNum()
							+ "] called [" + vmRequest.getCalledNum()
							+ "] call-uuid [" + vmRequest.getCallUUID()
							+ "] server [" + vmRequest.getServerId()
							+ "] voice mail is recorded !!..");

					VmChain chain = new DeleteOldVmFile(); // No Issue
					VmChain parseRecordFile = new ParseAndValidateRecordFile(); // No
																				// Issue
					VmChain saveRecord = new VmOperation(); // No Issue
					VmChain callFwdLog = new FwdCallLogs();
					VmChain sendNotification = new VccSendNotification();
					chain.setNext(parseRecordFile, vccServices);
					parseRecordFile.setNext(saveRecord, vccServices);
					saveRecord.setNext(callFwdLog, vccServices);
					callFwdLog.setNext(sendNotification, vccServices);
					chain.process(vmRequest, vmResponse, vmError);
				}
			} else if (vmRequest.getIsSuccess() == 1 && vmRequest.getServiceType().equalsIgnoreCase(AppConfig.config.getString("MCA", "0001"))) {
				logger.info("CallingNum ["
						+ vmRequest.getCallingNum()
						+ "] CalledNum ["
						+ vmRequest.getCalledNum()
						+ "] service ["
						+ AppConfig.config.getString(vmRequest.getServiceType()
								+ "_service_name")
						+ "]");
			
//				VmChain callFwdLog = new FwdCallLogs();
//				VmChain sendNotification = new VccSendNotification();
//				callFwdLog.setNext(sendNotification, vccServices);
//				callFwdLog.process(vmRequest, vmResponse, vmError);
				
				VmChain chain = new DeleteOldVmFile();
				VmChain callFwdLog = new FwdCallLogs();
				VmChain sendNotification = new VccSendNotification();
				chain.setNext(callFwdLog, vccServices);
				callFwdLog.setNext(sendNotification, vccServices);
				chain.process(vmRequest, vmResponse, vmError);
			} else {
				logger.info("CallingNum ["
						+ vmRequest.getCallingNum()
						+ "] CalledNum ["
						+ vmRequest.getCalledNum()
						+ "] User is not subscribed for ["
						+ AppConfig.config.getString(vmRequest.getServiceType()
								+ "_service_name")
						+ "] So Only sending request to MCA Handler."
						+ "Data is not inserted in VCC_VOICE_MSG, VCC_NOTIFICATION and VCC_Fwd_CALL_LOGS table");

				if (vmRequest.getServiceType().equalsIgnoreCase(
						AppConfig.config.getString("VM", "0010"))) {
					VccVoiceNoteTempServicing noteTempServicing = new VccVoiceNoteTempServicing();
					ProfileRequest profileRequest = gson.fromJson(
							gson.toJson(vmRequest), ProfileRequest.class);
					profileRequest.setHangupCause(vmRequest.getHangupCause());
					noteTempServicing.handleVoiceNote(profileRequest,
							vccServices);
				}
				VmChain parseRecordFile = new ParseAndValidateRecordFile();
				VmChain sendNotification = new VccSendNotification();
				parseRecordFile.setNext(sendNotification, vccServices);
				parseRecordFile.process(vmRequest, vmResponse, vmError);
				vmResponse.setIsSuccess(1);
			}
			commonOperation = null;
		} else {
			vmResponse.setIsSuccess(0);
			logger.error("[" + vmRequest.getCallingNum()
					+ "] save.hangup request param are missing. CalledNum["
					+ vmRequest.getCalledNum() + "] RecordfileName ["
					+ vmRequest.getRecordFileName() + "]");
		}
	}

	public VmRequest setProfileDetail(ProfileResponse profile,
			VmRequest vmRequest) {
		try {
			logger.debug("called [" + vmRequest.getCalledNum() + "] calling ["
					+ vmRequest.getCallingNum()
					+ "] profile detail set in request");
			vmRequest.setRatePlan(profile.getRatePlan());
			vmRequest.setIsUserIsOptedOut(profile.getIsUserIsOptedOut());
			vmRequest.setIsNotifyMeWithMCM(profile.getIsNotifyMeWithMCM());
			vmRequest.setIsMailBoxFull(profile.getIsMailBoxFull());
			vmRequest.setIsCallAllowed(profile.getIsCallAllowed());
			vmRequest.setIsVoiceMailDeleted(profile.getIsVoiceMailDeleted());
			vmRequest.setVccList(profile.getVccList());
			vmRequest.setVoiceNoteActive(profile.isVoiceNoteActive());
			// vmRequest.setIsSilentDetect(profile.getIsSilentDetect());
			vmRequest.setSubType(profile.getSubType());
		} catch (Exception e) {
			logger.error("called [" + vmRequest.getCalledNum() + "] calling ["
					+ vmRequest.getCallingNum()
					+ "] error while set profile detail: " + e.getMessage());
		}
		return vmRequest;
	}
	
	public VmRequest setDuration(VmRequest vmRequest) {
		try {
			if(vmRequest.getIsHangupByuser() == 1) {
				logger.debug("called [" + vmRequest.getCalledNum() + "] calling ["+ vmRequest.getCallingNum()+ "] call duration set in request");
				vmRequest.setRecordTempPath(vmRequest.getRecordTempPath()+vmRequest.getRecordFileName()+".wav");
				logger.debug("recordTempPath ["+vmRequest.getRecordTempPath()+"]");
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
			    Date firstDate = sdf.parse(vmRequest.getCallTime());
			    Date secondDate = new Date();
			    logger.debug("startTime ["+firstDate+"] endTime ["+secondDate+"]");
			    long diffInMillies = Math.abs(secondDate.getTime() - firstDate.getTime());
			    long diffInSecond = TimeUnit.SECONDS.convert(diffInMillies, TimeUnit.MILLISECONDS);
			    vmRequest.setRecordingDuration(Integer.parseInt(diffInSecond+""));
			    logger.debug("recordingDuration ["+vmRequest.getRecordingDuration()+"]");
			}
			if(vmRequest.getRecordingDuration() > 1000) {
				vmRequest.setRecordingDuration(vmRequest.getRecordingDuration() / 1000);
			}
		} catch (Exception e) {
			logger.error("called [" + vmRequest.getCalledNum() + "] calling ["
					+ vmRequest.getCallingNum()
					+ "] error while set call duration: " + e.getMessage());
		}
		return vmRequest;
	}
}
