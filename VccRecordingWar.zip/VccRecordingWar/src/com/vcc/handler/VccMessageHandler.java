package com.vcc.handler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.cache.VccExpiryCache;
import com.vcc.chain.VccChain;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.domain.VccMessageDetails;
import com.vcc.domain.VccMessageRetrieval;
import com.vcc.error.VmError;
import com.vcc.model.MessageStatus;
import com.vcc.request.VccMessageRequest;
import com.vcc.response.VccMessageResponse;
import com.vcc.util.MessageCountFileFilter;

public class VccMessageHandler {
	final static Logger logger = Logger.getLogger(VccMessageHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private VmError vmError = new VmError();

	public VccMessageHandler() {

	}
	/**
	 * return void the method is responsible for getting voice mail details of
	 * callingNum and set  message path and message details in cache and set message count details to client
	 * 
	 * @param messageRequest
	 *            the variable contain bean of VccMessageRequest ,which set by
	 *            url request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param messageResponse
	 *            the variable contain bean of VccMessageResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void processMessage(VccMessageRequest messageRequest,
			BindingResult bindingResult, VccMessageResponse messageResponse,
			VccServices vccServices) {

		if (messageRequest.getCallingNum() != null
				&& messageRequest.getLang() != 0) {

			VccChain chain = new VccMessageDetails();
			VccChain messageFile = new MessageCountFileFilter();
			chain.setNext(messageFile, vccServices);
			chain.process(messageRequest, messageResponse, vmError);
		} else {
			messageResponse.setIsSuccess(0);
			logger.error("[" + messageRequest.getCallingNum()
					+ "] Message Count param are missing ");
		}
	}
	/**
	 * return void the method is responsible for getting voice mail details of
	 * callingNum from cache and set  message path and message details in cache to client
	 * 
	 * @param messageRequest
	 *            the variable contain bean of VccMessageRequest ,which set by
	 *            url request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param messageResponse
	 *            the variable contain bean of VccMessageResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void retrieveMessage(VccMessageRequest messageRequest,
			BindingResult bindingResult, VccMessageResponse messageResponse,
			VccServices vccServices) {
		if (messageRequest.getCallingNum() != null
				&& messageRequest.getServiceType() != null) {

			VccChain chain = new VccMessageRetrieval();
			chain.setNext(null, vccServices);
			chain.process(messageRequest, messageResponse, vmError);
		} else {
			logger.error("[" + messageRequest.getCallingNum()
					+ "] Message Status change param are missing ");
		}
	}
	/**
	 * return void the method is responsible change the status of voice message in database
	 * after retrieving message by callingNum
	 * @param messageRequest
	 *            the variable contain bean of VccMessageRequest ,which set by
	 *            url request like - callingNum , calledNum,voiceMsgIndex
	 *            ,serviceType,callDuration,callTime etc
	 * @param messageResponse
	 *            the variable contain bean of VccMessageResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void changeMessageStatus(VccMessageRequest messageRequest,
			BindingResult bindingResult, VccMessageResponse messageResponse,
			VccServices vccServices) {

		if (messageRequest.getCallingNum() != null
				&& messageRequest.getServiceType() != null
				&& messageRequest.getRetrievalTime() != null
				&& messageRequest.getReadMsgIndex() != 0
				&& !messageRequest.getCatName().equalsIgnoreCase("S")
				&& messageRequest.getMsgDuration()>-1) {

			Date curDate = new Date();
			String msgStatusFor = null;
			int msgDuration = messageRequest.getMsgDuration();
			long diffSec = getRetSecond(messageRequest.getRetrievalTime(),
					curDate);
			logger.info(" change.message.status request >> ["+messageRequest.getCallingNum()+"] message duration ["+msgDuration+"] readDuration ["+diffSec+"] ");
			if (messageRequest.getServiceType().equals(
					AppConfig.config.getString("VN"))
					&& diffSec > msgDuration/2) {
				vccServices.messageService.updateMsgStatus(
						messageRequest.getCallingNum(),
						messageRequest.getReadMsgIndex());
				msgStatusFor = "VN";

			} else if (messageRequest.getServiceType().equals(
					AppConfig.config.getString("VM"))
					&& diffSec > msgDuration/2) {
				if (VccExpiryCache.pxmlmap.containsKey(messageRequest
						.getCallingNum() + "_status")) {
					MessageStatus messageStatus = (MessageStatus) VccExpiryCache.pxmlmap
							.get(messageRequest.getCallingNum() + "_status");

					messageStatus.setMsgRead(messageStatus.getMsgRead() + 1);
					logger.info("[" + messageRequest.getCallingNum()
							+ "] read msg update messageStastus ["
							+ messageStatus.getMsgRead() + "]");
				}
				vccServices.messageService.updateMsgStatus(
						messageRequest.getCallingNum(),
						messageRequest.getReadMsgIndex());
				msgStatusFor = "VN";
			} else {
				msgStatusFor = "NONE";
			}
			messageResponse.setIsSuccess(1);
			logger.info("[" + messageRequest.getCallingNum()
					+ "] save msg status for mailbox id ["
					+ messageRequest.getReadMsgIndex() + "] for ["
					+ msgStatusFor + "]");
		} else if(messageRequest.getCatName().equalsIgnoreCase("S")){
			
			messageResponse.setIsSuccess(1);
			logger.info("change.message.status request >>  [" + messageRequest.getCallingNum()
					+ "] save Message Status is not change ");
			
			
		}else
		{
			messageResponse.setIsSuccess(0);
			logger.error(" change.message.status request >> [" + messageRequest.getCallingNum()
					+ "] Message Status change param are missing ");
		}

	}
	/**
	 * return void the method is responsible for gathering difference between retrieval start and end time
	 * @param dateStart this variable contains message retrieval start time          
	 * @param dateStop this variable contains message retrieval end time
	 * @return time in second
	 * @see time
	 */
	private long getRetSecond(String dateStart, Date dateStop) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		Date d1 = null;
		Date d2 = null;
		logger.debug("date start [" + dateStart + "] and datestop [" + dateStop
				+ "]");
		try {
			d1 = format.parse(dateStart);
			d2 = format.parse(format.format(dateStop));
			logger.debug("Date parse date start [" + d1 + "] and datestop ["
					+ d2 + "]");
			// in milliseconds
			long diff = d2.getTime() - d1.getTime();

			long diffSeconds = diff / 1000;
			logger.debug("Date parse date start [" + d1 + "] and datestop ["
					+ d2 + "] diffrence is ["+diff+"] and ["+diffSeconds+"]");
			return diffSeconds;
		} catch (ParseException e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00001] [Exception in parsing while getting retrieval seconds] Error["+ e.getMessage() +"]");

			e.printStackTrace();
			return 0;

		}

	}

}
