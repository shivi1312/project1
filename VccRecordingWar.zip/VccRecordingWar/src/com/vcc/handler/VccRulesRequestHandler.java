package com.vcc.handler;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.List;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.model.VccSeriesRange;
import com.vcc.net.ConnectionPool;
import com.vcc.net.TextSocketConnection;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VccRuleEngineRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.response.VccRuleEngineResponse;
import com.vcc.util.TcpConnectionPool;
import com.vcc.util.TcpPool;

import edu.emory.mathcs.util.net.Connection;

public class VccRulesRequestHandler {

	final static Logger logger = Logger.getLogger(VccRulesRequestHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private Gson gson;
	private VccRuleEngineResponse vccRulesResponse = null;
	private List<VccSeriesRange> seriesRangesList = null;;

	public VccRulesRequestHandler() {
	}

	public void checkSubtypeProcess(ProfileRequest profileRequest,
			ProfileResponse profileResponse, VccServices vccServices) {
		int isSuccess = 0;
		String subType = AppConfig.config.getString("default_sub_type","N");
		if (profileRequest.getCallingNum() != null
				&& profileRequest.getServiceType() != null) {
			String json = getSubTypeRequestJsonObj(profileRequest);
			logger.debug("Rule Engine json request: " + json);
		//	sendRequestToVccRule(json);
			
			tcpWithVccRule(json);
			
			if (vccRulesResponse != null) {
				if (vccRulesResponse.getResult().equalsIgnoreCase("success")) {
					logger.info(" check.subType request >> [" + profileRequest.getCallingNum()
							+ "] success result resopnse from rule engine");
					isSuccess = 1;

					subType = vccRulesResponse.getSubType();

				} else if (vccRulesResponse.getResult()
						.equalsIgnoreCase("fail")) {
					logger.info("check.subType request >>  [" + profileRequest.getCallingNum()
							+ "] fail result resopnse from rule engine");
					isSuccess = 0;
				}
			} else {
				logger.info(" check.subType request >>  [" + profileRequest.getCallingNum()
						+ "] no resopnse from rule engine");
				isSuccess = 0;
			}
			profileResponse.setIsSuccess(isSuccess);
		
			profileResponse.setSubType(subType);
		} else {
			logger.error("check subtype request param are missing callingNum ["
					+ profileRequest.getCallingNum() + "]  serviceType ["
					+ profileRequest.getServiceType() + "]");
			profileResponse.setIsSuccess(0);
			profileResponse.setSubType(AppConfig.config.getString("default_sub_type","N"));
		}
	}

	public String getSubTypeRequestJsonObj(ProfileRequest profileRequest) {
		gson = new Gson();
		VccRuleEngineRequest vccRulesRequest = new VccRuleEngineRequest();
		vccRulesRequest.setMsisdn(profileRequest.getCallingNum());
		vccRulesRequest.setServiceType(profileRequest.getServiceType());
		vccRulesRequest.setInterFace(AppConfig.config
				.getString("default_interface"));
		vccRulesRequest.setChannel(AppConfig.config
				.getString("retrieval_channel"));
		vccRulesRequest.setTid(String.valueOf(System.nanoTime()));
		vccRulesRequest.setActionId(AppConfig.config
				.getString("subtype_actionId"));
		vccRulesRequest.setReqBy(profileRequest.getCallingNum());
		vccRulesRequest.setAppId(AppConfig.config.getString("app_id"));
		String jsonObj = gson.toJson(vccRulesRequest);
		return jsonObj;
	}

	public String getTriggerRequestJsonObj(ProfileRequest profileRequest) {
		gson = new Gson();
		VccRuleEngineRequest vccRulesRequest = new VccRuleEngineRequest();
		vccRulesRequest.setMsisdn(profileRequest.getCallingNum());
		vccRulesRequest.setServiceType(profileRequest.getServiceType());
		vccRulesRequest.setInterFace(AppConfig.config
				.getString("default_interface"));
		vccRulesRequest.setChannel(AppConfig.config
				.getString("retrieval_channel"));
		vccRulesRequest.setTid(String.valueOf(System.nanoTime()));
		vccRulesRequest.setActionId(AppConfig.config
				.getString("trigger_actionId"));
		vccRulesRequest.setActTrg(profileRequest.getActTrg());
		vccRulesRequest.setReqBy(profileRequest.getCallingNum());
		vccRulesRequest.setAppId(AppConfig.config.getString("app_id"));
		String jsonObj = gson.toJson(vccRulesRequest);
		return jsonObj;
	}
	
	
	public void sendRequestToVccRule(String json) {
		TextSocketConnection socketConnection = null;
		String resonse = null;
		ConnectionPool connectionPool=null;
		try {
			connectionPool = TcpPool.getRuleEngineConPool();
			socketConnection = connectionPool.getConnection();
			if(connectionPool!=null && socketConnection!=null)
			{
			logger.info("Rule Engine Server has connected!\n");
			logger.info("Rule Engine Sending string: '" + json + "'\n");
			socketConnection.write(json);
			resonse = socketConnection.readLine();
			if (resonse != null) {
				vccRulesResponse = gson.fromJson(resonse,
						VccRuleEngineResponse.class);
				logger.info(" Rule Engine response is: " + resonse);
			} else {
				logger.error("Rule engine response is : " + resonse);
			}
			}else
			{
				logger.info("Rule is not connected so can't be perform any opearation ");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				//connectionPool.returnConnection(socketConnection);
				socketConnection.close();
			} catch (Exception e) {
				logger.error("Error in closing socket connection ["+e+"]");
			}
		}

	}
	
	public void tcpWithVccRule(String json) {
		Connection socketConnection = null;
		String response = null;
		edu.emory.mathcs.util.net.ConnectionPool connectionPool=null;
		Socket client=null;
		OutputStream outToServer=null;
		DataOutputStream out=null;
		InputStream inFromServer=null;
		DataInputStream in=null;
		
		try {
			connectionPool = TcpConnectionPool.getRuleEngineConPool();
			socketConnection = connectionPool.getConnection();
			if(connectionPool!=null && socketConnection!=null)
			{
			logger.info("Rule Engine Server has connected!\n");
			logger.info("Rule Engine Sending string: '" + json + "'\n");
			client = socketConnection.getSocket();
			client.setSoTimeout(AppConfig.config.getInt("rule_engine_socket_timeout",1000));
			outToServer = client.getOutputStream();
			out = new DataOutputStream(outToServer);
			out.writeUTF(json.toString());
			out.flush();
			inFromServer = client.getInputStream();
			in = new DataInputStream(inFromServer);
			response = in.readUTF();
			out.close();
			in.close();
			socketConnection.returnToPool();
			if (response != null) {
				this.vccRulesResponse = gson.fromJson(response,
						VccRuleEngineResponse.class);
				logger.info(" Rule Engine response is: " + response);
			} else {
				logger.error("Rule engine response is : " + response);
			}
			}else
			{
				logger.info("Rule is not connected so can't be perform any opearation ");
			}

		} catch (SocketTimeoutException e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"90017] [SocketTimeout Exception while connecting to Rule Engine] Error["+ e.getMessage() +"]");

			if (socketConnection != null)
				socketConnection.close();
			try {
				if (out != null) {
					out.flush();
					out.close();
				}
				if (in != null)
					in.close();
				if (inFromServer != null)
					inFromServer.close();
				if (outToServer != null)
					outToServer.close();
			} catch (Exception e2) {
			}

			logger.error("Socket time out [" + e + "]");
		}
		
		catch (Exception e) {
			if(socketConnection!=null)
			socketConnection.close();
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00058] [Exception while connecting to Rule Engine] Error["+ e.getMessage() +"]");
			e.printStackTrace();
			logger.error("Rule engine not coonnected ["+e+"]");
			
			
		} finally {
			try {
				if(out!=null)
					out.close();
				if(in!=null)
					in.close();
		
					} catch (Exception e) {
						errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00059] [Exception in closing socket connection with Rule Engine] Error["+ e.getMessage() +"]");
				logger.error("Error in closing socket connection ["+e+"]");
			}
		}

	}
	

	public void manageTriggerProcess(ProfileRequest profileRequest,
			ProfileResponse profileResponse, VccServices vccServices) {
		int isSuccess = 0;
		
		if (profileRequest.getCallingNum() != null
				&& profileRequest.getServiceType() != null && profileRequest.getActTrg()!=0) {
			String json = getTriggerRequestJsonObj(profileRequest);
			logger.info("manage.trigger request Subscribe json request:  " + json);
			//sendRequestToVccRule(json);
			tcpWithVccRule(json);
			if (vccRulesResponse != null) {
				if (vccRulesResponse.getResult().equalsIgnoreCase("success")) {
					logger.info("[" + profileRequest.getCallingNum()
							+ "] success result resopnse from rule engine");
					isSuccess = 1;

					

				} else if (vccRulesResponse.getResult()
						.equalsIgnoreCase("fail")) {
					logger.info("[" + profileRequest.getCallingNum()
							+ "] fail result resopnse from rule engine");
					isSuccess = 0;
				}
			} else {
				logger.info("[" + profileRequest.getCallingNum()
						+ "] no resopnse from rule engine");
				isSuccess = -1;
			}
			profileResponse.setIsSuccess(isSuccess);
		
			
		} else {
			logger.error("acivate trigger request param are missing callingNum ["
					+ profileRequest.getCallingNum() + "]  serviceType ["
					+ profileRequest.getServiceType() + "] actTrg ["+profileRequest.getActTrg()+"]");
			profileResponse.setIsSuccess(-1);
		}
	}

	public void checkSubcribertypeProcess(ProfileRequest profileRequest,
			ProfileResponse profileResponse, VccServices vccServices) {
	
		boolean isExistWithInSeries = false;
		
		if(profileRequest.getFlowType().equalsIgnoreCase("ret"))
			this.seriesRangesList = vccServices.userService.isUserExistWithInRange(profileRequest.getCallingNum());
		else
			this.seriesRangesList = vccServices.userService.isUserExistWithInRange(profileRequest.getCalledNum());
			
		isExistWithInSeries = this.checkFixedList();

		if (isExistWithInSeries)
		{
			profileResponse.setSubType("F");
			profileResponse.setIsSuccess(1);
		}
		else
		{
			profileResponse.setSubType("N");
			
			//VccRulesRequestHandler rulesRequestHandler = new VccRulesRequestHandler();
			this.checkSubtypeProcess(profileRequest,
					profileResponse, vccServices);
			
			
		}
	
		
		
		
	}
	private boolean checkFixedList() {

		boolean status = false;

		for (VccSeriesRange vccSeriesRange : this.seriesRangesList) {

			if (vccSeriesRange.getGroupName().equalsIgnoreCase("fixedline")) {
				logger.info(" check.subType.ret request user in fixedline list ");
				status = true;
				break;
			} else  {
				logger.info("check.subType.ret request  user is not in fixedline list ");
				status = false;
				
			}
		}

		return status;
	}
	
}
