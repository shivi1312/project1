package com.vcc.handler;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.google.gson.JsonParser;
import com.telemune.vcc.expiringmap.ExpiringMap;
import com.vcc.cache.VccExpiryCache;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServiceFlag;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.domain.GroupOperation;
import com.vcc.error.VmError;
import com.vcc.model.GroupDetail;
import com.vcc.model.MessageStatus;
import com.vcc.model.VccSeriesRange;
import com.vcc.request.ProfileRequest;
import com.vcc.request.UserConfigRequest;
import com.vcc.response.UserConfigResponse;
import com.vcc.util.GroupCallRecordPathFilter;
import com.vcc.util.GroupNameRecordPathFilter;

public class VccUserConfigHandler {

	final static Logger logger = Logger.getLogger(VccUserConfigHandler.class);
	private GroupDetail groupDetail = null;
	private GroupNameRecordPathFilter groupNameRecordPathFilter = null;
	private GroupCallRecordPathFilter groupCallRecordPathFilter = null;
	private VmError vmError = null;
	ExpiringMap<String, Object> frndDetailMap = null;
	VccCommonOperation commonOperation = null;
	private List<String> frndList = null;
	private String frndKey = null;
	private List<VccSeriesRange> seriesRanges = null;
	private String serviceFlag = null;
	private int sizeOfGroup = 10;
	private int groupCount=0;
	public VccUserConfigHandler() {
	}

	public void addListprocess(UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, VccServices vccServices) {

		if (userConfigRequest.getCallingNum() != null
				&& userConfigRequest.getFrndMsisdn() != null
				&& userConfigRequest.getServiceType() != null
				&& userConfigRequest.getGroupId() != 0
				&& userConfigRequest.getRecordFileName() != null
				&& userConfigRequest.getType() != null) {

			logger.info(String
					.format("addtolist request >> callingNum [%s] frndMsisdn [%s] groupId [%s] fileName [%s] serviceType [%s] frndCount[%s]",
							userConfigRequest.getCallingNum(),
							userConfigRequest.getFrndMsisdn(),
							userConfigRequest.getGroupId(),
							userConfigRequest.getRecordFileName(),
							userConfigRequest.getServiceType(),
							userConfigRequest.getFrndCount()));

			this.sizeOfGroup = AppConfig.config.getInt("VM_GROUP_SIZE", 10);

			ProfileRequest profileRequest = new ProfileRequest();
			profileRequest.setCallingNum(userConfigRequest.getFrndMsisdn());
			profileRequest.setServiceType(userConfigRequest.getServiceType());
			logger.info("["+userConfigRequest.getCallingNum()+"] the max group size is ["+this.sizeOfGroup+"] and frnd count is ["+userConfigRequest.getFrndCount()+"]");
			if (this.sizeOfGroup <= userConfigRequest.getFrndCount() && !userConfigRequest.getType().equalsIgnoreCase("modify")) {
				userConfigResponse.setFrndCnt(userConfigRequest.getFrndCount());
				userConfigResponse.setIsSuccess(2);
			} else {
				if (vccServices.userService.isUserSubscribe(
						profileRequest.getCallingNum(),
						profileRequest.getServiceType())) {
					logger.info("[" + userConfigRequest.getCallingNum()
							+ "] the user ["
							+ userConfigRequest.getFrndMsisdn()
							+ "] which you want add in group is a subscriber");
					new GroupOperation().addFrnd(userConfigRequest,
							userConfigResponse, vccServices);
					userConfigResponse.setIsSubscriber(1);
					/*userConfigResponse.setFrndCnt(userConfigRequest
							.getFrndCount() + 1);
					userConfigResponse.setIsSuccess(1);*/
				} else {
					logger.info("["
							+ userConfigRequest.getCallingNum()
							+ "] the user ["
							+ userConfigRequest.getFrndMsisdn()
							+ "] which you want add in group is  not a subscriber");
					userConfigResponse.setIsSuccess(0);
					userConfigResponse.setIsSubscriber(0);

				}
			}
		} else {
			userConfigResponse.setIsSuccess(-1);
			logger.info(String
					.format(" addtolist request >>  callingNum [%s] frndMsisdn [%s] groupId [%s] fileName [%s] serviceType [%s] frndCount[%s]",
							userConfigRequest.getCallingNum(),
							userConfigRequest.getFrndMsisdn(),
							userConfigRequest.getGroupId(),
							userConfigRequest.getRecordFileName(),
							userConfigRequest.getServiceType(),
							userConfigRequest.getFrndCount()));

		}
	}

	public void addAllprocess(UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, VccServices vccServices) {
		int isSuccess = 0, frndCnt = 0;
		if (userConfigRequest.getCallingNum() != null
				&& userConfigRequest.getGroupId() != 0
				&& userConfigRequest.getServiceType() != null
				&& userConfigRequest.getType() != null) {

			logger.info(String.format(
					" addalltolist request >> callingNum [%s] groupId [%s] serviceType [%s] ",
					userConfigRequest.getCallingNum(),
					userConfigRequest.getGroupId(),
					userConfigRequest.getServiceType()));

			this.frndKey = "list_" + userConfigRequest.getCallingNum()+"_"+userConfigRequest.getGroupId();
			this.frndDetailMap = VccExpiryCache.pxmlmap;
			if (this.frndDetailMap.containsKey(this.frndKey)) {
				this.groupDetail = (GroupDetail) this.frndDetailMap
						.get(this.frndKey);
			
				if (userConfigRequest.getType().equalsIgnoreCase("create")
						&& vccServices.userConfigService
								.createGroup(this.groupDetail)) {
					logger.info("[" + userConfigRequest.getCallingNum()
							+ "] Group Id [" + userConfigRequest.getGroupId()
							+ "] created ");
					if (vccServices.userConfigService
							.insertFrndGroupList(this.groupDetail)) {
						logger.info("[" + userConfigRequest.getCallingNum()
								+ "] Group Id ["
								+ userConfigRequest.getGroupId()
								+ "] deatils  successfully Saved  ");
						isSuccess = 1;
						frndCnt = this.groupDetail.getFrndList().size();
						this.frndDetailMap.remove(this.frndKey);
					}
				} else if (userConfigRequest.getType().equalsIgnoreCase(
						"modify")) {
					if (vccServices.userConfigService
							.insertFrndGroupList(this.groupDetail)) {
						logger.info("[" + userConfigRequest.getCallingNum()
								+ "] Group Id ["
								+ userConfigRequest.getGroupId()
								+ "] successfully modified");
						isSuccess = 1;
						frndCnt = this.groupDetail.getFrndList().size();
						this.frndDetailMap.remove(this.frndKey);
					}

				}else
				{
					this.frndDetailMap.remove(this.frndKey);
				}
				if (isSuccess == 1) {
					MessageStatus messageStatus = (MessageStatus) VccExpiryCache.pxmlmap
							.get(userConfigRequest.getCallingNum() + "_status");
					if(messageStatus!=null)
					messageStatus.setFrndAdd(messageStatus.getFrndAdd() + 1);

				}
				
				
				userConfigResponse.setIsSuccess(isSuccess);
				userConfigResponse.setFrndCnt(frndCnt);
			} else {
				userConfigResponse.setIsSuccess(-1);
				logger.error("addalltolist request >>  erorr in creating group of msisdn ["
						+ userConfigRequest.getCallingNum() + "]");
			}
		} else {
			userConfigResponse.setIsSuccess(-1);
			logger.error("erorr in creating group of msisdn ["
					+ userConfigRequest.getCallingNum() + "]");
		}
	}

	public void addFrnd(UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse) {
		this.frndDetailMap = VccExpiryCache.pxmlmap;
		if (this.frndDetailMap.containsKey("list_"
				+ userConfigRequest.getCallingNum())) {
			this.groupDetail = (GroupDetail) this.frndDetailMap
					.get(userConfigRequest.getCallingNum());
			this.groupDetail.getFrndList().add(
					userConfigRequest.getFrndMsisdn());
			userConfigResponse.setIsSuccess(1);
		} else {
			this.frndList = new ArrayList<String>();
			this.groupDetail = new GroupDetail();
			this.groupDetail.setCallingNum(userConfigRequest.getCallingNum());
			this.groupDetail.setFileName(userConfigRequest.getFileName());
			this.groupDetail.setGroupId(userConfigRequest.getGroupId());
			this.groupDetail.setFrndList(this.frndList);
			this.groupDetail.getFrndList().add(
					userConfigRequest.getFrndMsisdn());
			this.frndDetailMap.put("list_" + userConfigRequest.getCallingNum(),
					groupDetail);
			userConfigResponse.setIsSuccess(1);
		}
	}

	public void groupValidationProcess(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse,
			VccServices vccServices) {
		vmError = new VmError();
		if (userConfigRequest.getCallingNum() != null
				&& userConfigRequest.getCallingNum() != ""
				&& userConfigRequest.getGroupId() != 0
				&& userConfigRequest.getType() != null
				&& userConfigRequest.getType() != "") {
			int groupExists = vccServices.userConfigService
					.checkGroupIdExists(userConfigRequest);
			logger.info(" groupId.validation request >> [" + userConfigRequest.getCallingNum()
					+ "] group id exists  [" + groupExists + "]");
			if (groupExists == 1) {
				if (userConfigRequest.getType().equalsIgnoreCase("modify")) {
					userConfigResponse.setIsSuccess(1);
					groupNameRecordPathFilter = new GroupNameRecordPathFilter();
					groupNameRecordPathFilter.execute(userConfigRequest,
							bindingResult, userConfigResponse, vmError,
							vccServices);
				} else {
					userConfigResponse.setIsSuccess(0);
					userConfigResponse.setGroupId(0);
					userConfigResponse.setRecordFileName("NA");
					userConfigResponse.setRecordFilePath("NA");
				}
			} else if (groupExists == 0
					&& userConfigRequest.getType().equalsIgnoreCase("create")) {
				userConfigResponse.setIsSuccess(1);
				userConfigResponse.setGroupId(userConfigRequest.getGroupId());

				groupNameRecordPathFilter = new GroupNameRecordPathFilter();
				groupNameRecordPathFilter
						.execute(userConfigRequest, bindingResult,
								userConfigResponse, vmError, vccServices);
			} else {
				userConfigResponse.setIsSuccess(0);
				userConfigResponse.setGroupId(0);
				userConfigResponse.setRecordFileName("NA");
				userConfigResponse.setRecordFilePath("NA");
			}
		} else {
			userConfigResponse.setIsSuccess(-1);
			userConfigResponse.setGroupId(0);
			userConfigResponse.setRecordFileName("NA");
			userConfigResponse.setRecordFilePath("NA");
			logger.error(String.format(
					" groupId.validation request >> error in request input callingNum [%s] and  GroupId [%s]",
					userConfigRequest.getCallingNum(),
					userConfigRequest.getGroupId()));
		}
	}

	public void groupListProcess(UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, BindingResult bindingResult,
			VccServices vccServices) {
		if (userConfigRequest.getCallingNum() != null
				&& userConfigRequest.getCallingNum() != ""
				&& userConfigRequest.getGroupId() != 0) {
			logger.info("grouplist.with.validation request >> [" + userConfigRequest.getCallingNum()
					+ "] find group id [" + userConfigRequest.getGroupId()
					+ "]");
			new GroupOperation().findGroup(userConfigRequest, bindingResult,
					userConfigResponse, vccServices);
		} else {
			userConfigResponse.setIsSuccess(-1);
			userConfigResponse.setInputCount(userConfigRequest.getInputCount()+1);
			logger.error("grouplist.with.validation request >>  error in getting request param calling num["
					+ userConfigRequest.getCallingNum() + "]  and group id ["
					+ userConfigRequest.getGroupId() + "]");
		}

	}

	public void groupDeleteProcess(UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, BindingResult bindingResult,
			VccServices vccServices) {

		if (userConfigRequest.getCallingNum() != null
				&& userConfigRequest.getGroupId() != 0) {
			logger.info(" group.delete request >> [" + userConfigRequest.getCallingNum()
					+ "] group id [" + userConfigRequest.getGroupId()
					+ "] is going to delete");
			new GroupOperation().deleteGroup(userConfigRequest, bindingResult,
					userConfigResponse, vccServices);

		} else {
			userConfigResponse.setIsSuccess(-1);
			logger.error("error in getting request param calling num["
					+ userConfigRequest.getCallingNum() + "]  and group id ["
					+ userConfigRequest.getGroupId() + "]");
		}

	}

	public void groupModifyProcess(UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, BindingResult bindingResult,
			VccServices vccServices) {

		if (userConfigRequest.getCallingNum() != null
				&& userConfigRequest.getCallingNum() != ""
				&& userConfigRequest.getGroupId() != 0
				&& userConfigRequest.getRecordFileName() != null) {
			logger.info("group.name.modify request >> [" + userConfigRequest.getCallingNum()
					+ "]  group id [" + userConfigRequest.getGroupId()
					+ "] is going modify group name ");
			new GroupOperation().updateGroupName(userConfigRequest,
					userConfigResponse, vccServices);

		} else {
			userConfigResponse.setIsSuccess(-1);
			logger.error("group.name.modify request >>  error in getting request param calling num["
					+ userConfigRequest.getCallingNum() + "]  and group id ["
					+ userConfigRequest.getGroupId() + "] and recordFile ["
					+ userConfigRequest.getRecordFileName() + "]");
		}

	}

	public void groupListDetails(UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, BindingResult bindingResult,
			VccServices vccServices) {

		if (userConfigRequest.getCallingNum() != null
				&& userConfigRequest.getCallingNum() != ""
				&& userConfigRequest.getGroupId() != 0) {
			logger.info(" grouplist.details request >>[" + userConfigRequest.getCallingNum()
					+ "]  group details for groupd id ["
					+ userConfigRequest.getGroupId() + "]  ");
			new GroupOperation().getMsisdnFilePath(userConfigRequest,
					bindingResult, userConfigResponse, vccServices);
		} else {
			userConfigResponse.setIsSuccess(-1);
			logger.error(" grouplist.details request >> error in getting request param calling num["
					+ userConfigRequest.getCallingNum() + "]  and group id ["
					+ userConfigRequest.getGroupId() + "]");
		}
	}

	public void groupExistsProcess(UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, BindingResult bindingResult,
			VccServices vccServices) {
		if (userConfigRequest.getCallingNum() != null
				&& userConfigRequest.getCallingNum() != ""
				&& userConfigRequest.getGroupId() != 0
				&& userConfigRequest.getLang() != 0
				&& userConfigRequest.getServiceType() != "") {

		}
	}

	public void deleteMsisdnProcess(UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, BindingResult bindingResult,
			VccServices vccServices) {

		if (userConfigRequest.getCallingNum() != null
				&& userConfigRequest.getCallingNum() != ""
				&& userConfigRequest.getGroupId() != 0
				&& userConfigRequest.getFrndMsisdn() != null) {
			logger.info("msisdn.delete request >> [" + userConfigRequest.getCallingNum()
					+ "]  delete msisdn[" + userConfigRequest.getFrndMsisdn()
					+ "] from group id [" + userConfigRequest.getGroupId()
					+ "] ");
			new GroupOperation().deleteMsisdnFromGroup(userConfigRequest,
					bindingResult, userConfigResponse, vccServices);

			if (VccExpiryCache.pxmlmap.containsKey(userConfigRequest
					.getCallingNum() + "_status")) {
				MessageStatus messageStatus = (MessageStatus) VccExpiryCache.pxmlmap
						.get(userConfigRequest.getCallingNum() + "_status");
				messageStatus.setFrndDel(messageStatus.getFrndDel() + 1);
			}

		} else {
			userConfigResponse.setIsSuccess(0);
			logger.error(" msisdn.delete request >> error in getting request param calling num["
					+ userConfigRequest.getCallingNum() + "]  and group id ["
					+ userConfigRequest.getGroupId() + "] and deleted number ["
					+ userConfigRequest.getFrndMsisdn() + "]");

		}
	}

	public void getAlternativeMsisdnProcess(
			UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, BindingResult bindingResult,
			VccServices vccServices) {

		if (userConfigRequest.getCallingNum() != null
				&& userConfigRequest.getLang() != 0
				&& userConfigRequest.getServiceType() != null) {
			userConfigRequest
					.setServiceFlagIndex(VccServiceFlag.alternative_msisdn_enable_disable);

			VccCommonOperation commonOperation = new VccCommonOperation();
			String altrenativeMsisdn = vccServices.userConfigService
					.getMsisdnFromAdvancedDetails(userConfigRequest);
			logger.info(" get.alternative.number request >> [" + userConfigRequest.getCallingNum()
					+ "]  alternative  msisdn[" + altrenativeMsisdn + "]  ");
			if (altrenativeMsisdn != null) {
				String msisdnFilePath = commonOperation.getMsisdnPath(
						altrenativeMsisdn, userConfigRequest.getLang());
				userConfigResponse.setIsSuccess(1);
				userConfigResponse.setFrndMsisdn(altrenativeMsisdn);
				userConfigResponse.setMsisdnFilePath(msisdnFilePath);
			} else {

				userConfigResponse.setIsSuccess(0);
			}

		} else {
			logger.info("get.alternative.number request >> [" + userConfigRequest.getCallingNum()
					+ "] Request param are missing lang ["
					+ userConfigRequest.getLang() + "] serviceType ["
					+ userConfigRequest.getServiceType() + "]");
			userConfigResponse.setIsSuccess(-1);
		}

	}

	public void addAlternativeMsisdnProcess(
			UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, BindingResult bindingResult,
			VccServices vccServices) {

		if (userConfigRequest.getCallingNum() != null
				&& userConfigRequest.getCalledNumB() != null
				&& userConfigRequest.getServiceType() != null) {
			commonOperation = new VccCommonOperation();
			this.seriesRanges = vccServices.userConfigService
					.isUserExistWithInRange(userConfigRequest.getCalledNumB());
			this.serviceFlag = vccServices.userConfigService.getServiceFlag(
					userConfigRequest.getCallingNum(),
					userConfigRequest.getServiceType());

			userConfigRequest
					.setServiceFlagIndex(VccServiceFlag.alternative_msisdn_enable_disable);
			Boolean isActive = commonOperation.checkServiceFlag(
					this.serviceFlag,
					VccServiceFlag.alternative_msisdn_enable_disable);
			if (this.serviceFlag != null && isActive && this.checkSeriesRange()) {
				if (vccServices.userConfigService
						.addAlternativeMsisdn(userConfigRequest)) {
					userConfigResponse.setIsSuccess(1);
					logger.info(" add.alternative.number request >> [" + userConfigRequest.getCallingNum()
							+ "]  alternative  msisdn["
							+ userConfigRequest.getCalledNumB() + "]  is added");
				} else {

					userConfigResponse.setIsSuccess(0);
					logger.info(" add.alternative.number request >>  [" + userConfigRequest.getCallingNum()
							+ "]  isActive [" + isActive
							+ "] alternative  msisdn["
							+ userConfigRequest.getCalledNumB()
							+ "] in range [" + this.checkSeriesRange()
							+ "]  so it is not added");
				}
			} else {
				logger.info("  [" + userConfigRequest.getCallingNum()
						+ "]  isActive [" + isActive + "] alternative  msisdn["
						+ userConfigRequest.getCalledNumB() + "] in range ["
						+ this.checkSeriesRange() + "]  so it is not added");
				userConfigResponse.setIsSuccess(0);

			}
			logger.info("[" + userConfigRequest.getCallingNum()
					+ "] calledNumB[" + userConfigRequest.getCalledNumB()
					+ "] serviceType [" + userConfigRequest.getServiceType()
					+ "] service flag [" + this.serviceFlag
					+ "] and serviceFlag status is[" + isActive
					+ "] Add alternative status is ["
					+ userConfigResponse.getIsSuccess() + "]");
		} else {
			logger.info("add.alternative.number request >>  [" + userConfigRequest.getCallingNum()
					+ "] Request param are missing calledNumB["
					+ userConfigRequest.getCalledNumB() + "] serviceType ["
					+ userConfigRequest.getServiceType() + "]");
			userConfigResponse.setIsSuccess(-1);
		}

	}

	public void actOrDctServiceFlagProcess(UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, BindingResult bindingResult,
			VccServices vccServices, int serviceFlagPos) {
		if (userConfigRequest.getCallingNum() != null

		&& userConfigRequest.getServiceType() != null) {
			commonOperation = new VccCommonOperation();
			// get Service flag
			String serviceFlag = vccServices.userConfigService.getServiceFlag(
					userConfigRequest.getCallingNum(),
					userConfigRequest.getServiceType());
			Boolean status = commonOperation.checkServiceFlag(serviceFlag,
					serviceFlagPos);
			int result = 0;
			if (!status && serviceFlag != null) {

				serviceFlag = commonOperation.changeServiceFlag(serviceFlag,
						serviceFlagPos);
				userConfigRequest.setServiceFlag(serviceFlag);
				result = vccServices.userConfigService
						.activateOrDeactivateNotification(userConfigRequest);
				logger.info(" [" + userConfigRequest.getCallingNum()
						+ "] ServiceFlag is [" + serviceFlag
						+ "]  Notification activate stauts is [" + result + "]");
				userConfigResponse.setIsSuccess(result);
				if (serviceFlagPos == VccServiceFlag.alternative_msisdn_enable_disable)
					userConfigResponse.setAltFlag(0);
				else if(serviceFlagPos == VccServiceFlag.notification_enable_disable)
					userConfigResponse.setNotiFlag(0);
				else if(serviceFlagPos == VccServiceFlag.message_header_enable_disable)
					userConfigResponse.setHeaderFlag(0);
				else
				{
					userConfigResponse.setAltFlag(0);
					userConfigResponse.setNotiFlag(0);
					userConfigResponse.setHeaderFlag(0);
				}
					

			} else if (status && serviceFlag != null) {
				serviceFlag = commonOperation.changeServiceFlag(serviceFlag,
						serviceFlagPos);

				userConfigRequest.setServiceFlag(serviceFlag);
				result = vccServices.userConfigService
						.activateOrDeactivateNotification(userConfigRequest);
				Boolean deleteStaus = vccServices.userConfigService
						.deleteAlternativenumber(
								userConfigRequest.getCallingNum(),
								serviceFlagPos);
				logger.info("[" + userConfigRequest.getCallingNum()
						+ "] ServiceFlag is [" + serviceFlag
						+ "] Notification deActivate stauts is [" + result
						+ "] delete alternative msisdn [" + deleteStaus + "]");
				userConfigResponse.setIsSuccess(result);

				if (serviceFlagPos == VccServiceFlag.alternative_msisdn_enable_disable)
					userConfigResponse.setAltFlag(1);
				else if(serviceFlagPos == VccServiceFlag.notification_enable_disable)
					userConfigResponse.setNotiFlag(1);
				else if(serviceFlagPos == VccServiceFlag.message_header_enable_disable)
					userConfigResponse.setHeaderFlag(1);
				else
				{
					userConfigResponse.setAltFlag(1);
					userConfigResponse.setNotiFlag(1);
					userConfigResponse.setHeaderFlag(1);
				}
				
			} else {
				userConfigResponse.setIsSuccess(0);
			}

		} else {
			logger.info("[" + userConfigRequest.getCallingNum()
					+ "] Request param are missing  serviceType ["
					+ userConfigRequest.getServiceType() + "]");
			userConfigResponse.setIsSuccess(-1);
		}

	}

	public void groupIdCheck(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse,
			VccServices vccServices) {

		if (userConfigRequest.getCallingNum() != null
				&& userConfigRequest.getCallingNum() != ""
				&& userConfigRequest.getGroupId() != 0) {
			int groupExists = vccServices.userConfigService
					.checkGroupIdExists(userConfigRequest);
			logger.info("check.groupId request >>[" + userConfigRequest.getCallingNum()
					+ "] group id Exists [" + groupExists + "]");
			if (groupExists == 1) {

				userConfigResponse.setIsSuccess(1);
				groupCallRecordPathFilter = new GroupCallRecordPathFilter();
				groupCallRecordPathFilter
						.execute(userConfigRequest, bindingResult,
								userConfigResponse, vmError, vccServices);
				if (userConfigRequest.getRatePlan() != 0) {

					int ratePlan = userConfigRequest.getRatePlan();
					String ratePlanJson = VccExpiryCache.getSysmap().get(
							"vcc_rate_plan");
					// logger.info("rate plan json "+ratePlanJson);
					JsonParser jsonParser = new JsonParser();
					String mailBoxId = jsonParser.parse(ratePlanJson)
							.getAsJsonObject().get("" + ratePlan + "")
							.getAsJsonObject().get("mailBoxId").toString();
					String mailBoxParamJson = VccExpiryCache.getSysmap().get(
							"vcc_mailbox_param");
					int recordingTime = Integer.parseInt(jsonParser
							.parse(mailBoxParamJson).getAsJsonObject()
							.get(mailBoxId).getAsJsonObject()
							.get("maxRecordingTime").toString());
					logger.info("aParty [" + userConfigRequest.getCallingNum()
							+ "] groupis [" + userConfigRequest.getGroupId()
							+ "] the recordingTime is [" + recordingTime
							+ "] for  [" + userConfigRequest.getCallingNum()
							+ "]");
					userConfigResponse.setRecordLength(recordingTime);
					userConfigResponse.setRecordTimeout(recordingTime);
				}

			} else {
				userConfigResponse.setIsSuccess(0);
				userConfigResponse.setGroupId(0);
				userConfigResponse.setRecordFileName("NA");
				userConfigResponse.setRecordFilePath("NA");
			}
		}else {
			if(userConfigRequest.getGroupId()==0)
				userConfigResponse.setIsSuccess(0);
			else
				userConfigResponse.setIsSuccess(-1);
			userConfigResponse.setGroupId(0);
			userConfigResponse.setRecordFileName("NA");
			userConfigResponse.setRecordFilePath("NA");
			logger.error(String.format(
					"check.groupId request >> error in request input callingNum [%s] and  GroupId [%s]",
					userConfigRequest.getCallingNum(),
					userConfigRequest.getGroupId()));
		}

	}

	public void groupCountProcess(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse,
			VccServices vccServices) {
	
		if(userConfigRequest.getCallingNum()!=null && userConfigRequest.getLang()!=0)
		{
			
			 this.groupCount = vccServices.userConfigService.groupCount(userConfigRequest.getCallingNum());
			 
			 userConfigResponse.setGroupCount(groupCount);
			 
			 StringBuilder stringBuilder = new StringBuilder();
			 
			 stringBuilder.append(AppConfig.config.getString("ivr_common_path"));
			 stringBuilder.append(File.separator);
			 stringBuilder.append(userConfigRequest.getLang());
			 stringBuilder.append(File.separator);
			 stringBuilder.append("YOU_HAVE.wav");
			 stringBuilder.append(",");
			 
			 stringBuilder.append(AppConfig.config.getString("ivr_digits_path"));
			 stringBuilder.append(File.separator);
			 stringBuilder.append(userConfigRequest.getLang());
			 stringBuilder.append(File.separator);
			 stringBuilder.append(this.groupCount);
			 stringBuilder.append(".wav");
			 stringBuilder.append(",");
			 
			 stringBuilder.append(AppConfig.config.getString("ivr_common_path"));
			 stringBuilder.append(File.separator);
			 stringBuilder.append(userConfigRequest.getLang());
			 stringBuilder.append(File.separator);
			 stringBuilder.append("VMRT_GROUP.wav");
			 
			 userConfigResponse.setGroupCountPath(stringBuilder.toString());
			 userConfigResponse.setIsSuccess(1);
			 
			 if(this.groupCount== AppConfig.config.getInt("VM_MAX_GROUP",20) || this.groupCount>= AppConfig.config.getInt("VM_MAX_GROUP",10))
			 {
				 
				 userConfigResponse.setIsGlimitFull(1);
				 
			 }else
			 {
				 userConfigResponse.setIsGlimitFull(0);
			 }
			 
			 
					 
			 
		}else
		{
			logger.info("group.count request >> parameters are missing of group count");
			 userConfigResponse.setIsSuccess(-1);
			
		}
	
		
	}

	private boolean checkSeriesRange() {

		boolean status = false;

		for (VccSeriesRange vccSeriesRange : this.seriesRanges) {

			if (vccSeriesRange.getGroupName().equalsIgnoreCase("operator")) {
				logger.info("user in operator range");
				status = true;
			} else if (vccSeriesRange.getGroupName().equalsIgnoreCase(
					"blacklist")) {
				logger.info("user Is blacklisted");
				status = false;
				break;
			}
		}
		logger.info("size of series range [" + this.seriesRanges.size()
				+ "] status [" + status + "]");
		return status;
	}

}
