package com.vcc.handler;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.google.gson.JsonParser;
import com.telemune.vcc.expiringmap.ExpiringMap;
import com.vcc.cache.VccExpiryCache;
import com.vcc.chain.VmChain;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.domain.GetProfileReply;
import com.vcc.domain.GetProfileRetrieval;
import com.vcc.domain.MessageOperation;
import com.vcc.domain.VmOperation;
import com.vcc.error.VmError;
import com.vcc.filter.ProfileClient;
import com.vcc.filter.ProfileFilterManager;
import com.vcc.model.MessageAttribute;
import com.vcc.model.MessageReader;
import com.vcc.model.MessageStatus;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.model.VccVoiceMessage;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VccMessageRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.response.VccMessageResponse;
import com.vcc.response.VmResponse;
import com.vcc.util.CallRecordPathFilter;
import com.vcc.util.DeleteOldVmFile;
import com.vcc.util.ParseAndValidateRecordFile;

public class VmRecordHandler {
	final static Logger logger = Logger.getLogger(VmRecordHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private VmError vmError = new VmError();
	private VccCommonOperation commonOperation = null;
	private MessageOperation messageOperation = null;
	private ExpiringMap<String, Object> msgReaderMap = null;
	private ProfileFilterManager profileFilterManager = null;
	private ProfileClient profileClient = null;
	private VccVoiceMessage vccVoiceMessage = null;
	private String msgRetKey = null;
	private List<MessageAttribute> msgLst = null;
	private Boolean status = false;
	private Boolean isSilentDetect = false;
	private String digits;

	public VmRecordHandler() {

	}

	public void saveRecordProcess(VmRequest vmRequest,
			BindingResult bindingResult, VmResponse vmResponse,
			VccServices vccServices) {

		if (vmRequest.getCallingNum() != null
				&& vmRequest.getCalledNum() != null
				&& vmRequest.getRecordFileName() != null){
			logger.info(" save.record >> [" + vmRequest.getCallingNum()
					+ "] save.vm request param are  calledNum ["
					+ vmRequest.getCalledNum() + "] recordfile ["
					+ vmRequest.getRecordFileName() + "] digits received ["
					+ vmRequest.getDigits() + "]");

			digits = vmRequest.getDigits();

			if (digits!=null && digits.equalsIgnoreCase(AppConfig.config.getString(
					"silenceDigits", "silence"))) {

				if (vmRequest.getRecordingDuration()
						/ AppConfig.config.getInt("record_duration_divisor",
								1000) == vmRequest.getRecordTimeout()) {
					isSilentDetect = true;
				} else if (vmRequest.getRecordingDuration()
						/ AppConfig.config.getInt("record_duration_divisor",
								1000)
						+ AppConfig.config.getInt("silence_negotiation", 0) >= vmRequest
							.getRecordTimeout()) {
					isSilentDetect = true;
				} else {
					isSilentDetect = false;
				}
			} else {
				isSilentDetect = false;
			}
			if (isSilentDetect) {

				logger.info("[" + vmRequest.getCallingNum()
						+ "] is silence found in recording [" + isSilentDetect
						+ "]");
				vmResponse.setIsSilentDetect(1);
				vmResponse.setIsSuccess(1);

			} else {
				commonOperation = new VccCommonOperation();
				commonOperation.addAndRemoveCountryCode(vmRequest);
				VmChain chain = new DeleteOldVmFile();
				VmChain parseRecordFile = new ParseAndValidateRecordFile();
				VmChain saveRecord = new VmOperation();
				chain.setNext(parseRecordFile, vccServices);
				parseRecordFile.setNext(saveRecord, vccServices);
				saveRecord.setNext(null, vccServices);
				chain.process(vmRequest, vmResponse, vmError);
				vmResponse.setIsSilentDetect(0);
				commonOperation = null;
			}
		} else {
			vmResponse.setIsSuccess(0);
			logger.error("[" + vmRequest.getCallingNum()
					+ "] save.vm request param are missing calledNum["
					+ vmRequest.getCalledNum() + "] recordfile ["
					+ vmRequest.getRecordFileName() + "]");
		}
	}

	public void cancelRecordProcess(VmRequest vmRequest,
			BindingResult bindingResult, VmResponse vmResponse,
			VccServices vccServices) {
		if (vmRequest.getCallingNum() != null
				&& vmRequest.getRecordFileName() != null) {
			logger.info(String.format("callingNum [%s] recordFileName [%s]",
					vmRequest.getCallingNum(), vmRequest.getRecordFileName()));
			commonOperation = new VccCommonOperation();
			if (vmRequest.getCalledNumB() != null) {
				vmRequest.setCallingNum(vmRequest.getCalledNumB());
			}
			boolean status = commonOperation.deletePhysicalFile(
					vmRequest.getRecordFileName(), vmRequest.getCallingNum(),
					null, AppConfig.config.getString("ivr_record_path"));
			if (status) {
				vmResponse.setIsSuccess(1);
			} else {
				vmResponse.setIsSuccess(0);
			}
		} else {
			logger.error("cancel record param are missing, callingNum ["
					+ vmRequest.getCallingNum() + "] recordFileName ["
					+ vmRequest.getRecordFileName() + "] ");
			vmResponse.setIsSuccess(-1);
		}
	}

	public void saveMsgProcess(VmRequest vmRequest,
			BindingResult bindingResult, VmResponse vmResponse,
			VccServices vccServices) {
		int status = 0;

		if (vmRequest.getCallingNum() != null
				&& vmRequest.getServiceType() != null
				&& vmRequest.getVoiceMsgIndex() != 0) {
			logger.info(String.format(
					"callingNum [%s]  ServiceType [%s] voiceMsgIndex [%s] ",
					vmRequest.getCallingNum(), vmRequest.getServiceType(),
					vmRequest.getVoiceMsgIndex()));
			this.msgRetKey = "ret_" + vmRequest.getCallingNum();
			this.msgReaderMap = VccExpiryCache.pxmlmap;
			if (this.msgReaderMap.containsKey(this.msgRetKey)) {

				MessageStatus msgStatus = (MessageStatus) VccExpiryCache.pxmlmap
						.get(vmRequest.getCallingNum() + "_status");

				status = vccServices.userService.updateVoiceMsgStatus(
						vmRequest, "S");
				msgStatus.setMsgSave(msgStatus.getMsgSave() + 1);

			} else {
				status = 0;
				logger.error("[" + vmRequest.getCallingNum()
						+ "] cache not exists ");
			}
		} else {
			status = -1;
			logger.info("[" + vmRequest.getCallingNum()
					+ "] request param of save msg missing service type ["
					+ vmRequest.getServiceType() + "] msgindex ["
					+ vmRequest.getVoiceMsgIndex() + "] ");
		}
		logger.info("[" + vmRequest.getCallingNum()
				+ "] the voice msg index saved satus is [" + status + "]");
		vmResponse.setIsSuccess(status);
	}

	public void deleteMsgProcess(VccMessageRequest messageRequest,
			BindingResult bindingResult, VccMessageResponse messageResponse,
			VccServices vccServices) {

		if (messageRequest.getCallingNum() != null
				&& messageRequest.getServiceType() != null
				&& messageRequest.getVoiceMsgIndex() != 0
				&& messageRequest.getCatName() != null) {
			commonOperation = new VccCommonOperation();
			logger.info(String
					.format("delete.msg request >> callingNum [%s]  ServiceType [%s] voiceMsgIndex [%s]",
							messageRequest.getCallingNum(),
							messageRequest.getServiceType(),
							messageRequest.getVoiceMsgIndex()));
			this.msgRetKey = "ret_" + messageRequest.getCallingNum();
			this.msgReaderMap = VccExpiryCache.pxmlmap;
			if (this.msgReaderMap.containsKey(this.msgRetKey)) {
				MessageReader messageReader = (MessageReader) msgReaderMap
						.get(this.msgRetKey);

				if (messageRequest.getCatName().equalsIgnoreCase("N")) {
					this.msgLst = messageReader.getNewmsg();
				} else if (messageRequest.getCatName().equalsIgnoreCase("R")) {
					this.msgLst = messageReader.getOldmsg();
				} else if (messageRequest.getCatName().equalsIgnoreCase("S")) {
					this.msgLst = messageReader.getSavemsg();
				}
				if (this.msgLst.size() > 0) {
					vccServices.userService.deleteVccVoiceMessage(
							messageRequest.getCallingNum(),
							messageRequest.getVoiceMsgIndex());
					if (VccExpiryCache.pxmlmap.containsKey(messageRequest
							.getCallingNum() + "_status")) {
						MessageStatus messageStatus = (MessageStatus) VccExpiryCache.pxmlmap
								.get(messageRequest.getCallingNum() + "_status");
						messageStatus.setMsgDel(messageStatus.getMsgDel() + 1);
					}
					for (int i = 0; i < msgLst.size(); i++) {
						MessageAttribute msgAttribute = msgLst.get(i);
						if (msgAttribute.getVoiceMsgIndex() == messageRequest
								.getVoiceMsgIndex()) {
							logger.debug("callingnum["
									+ messageRequest.getCallingNum()
									+ "] file [" + msgAttribute.getFileName()
									+ "]");
							Boolean status = commonOperation
									.deletePhysicalFile(
											msgAttribute.getFileName(),
											messageRequest.getCallingNum(),
											null,
											AppConfig.config
													.getString("ivr_record_path"));
							logger.info("callingnum["
									+ messageRequest.getCallingNum()
									+ "] file [" + msgAttribute.getFileName()
									+ "] deleted status [" + status + "]");
							this.msgLst.remove(msgAttribute);
						}
					}
					messageResponse.setIsSuccess(1);
					if (this.msgLst.size() <= 0) {

						messageResponse.setAvailable("L");

					} else if (messageRequest.getNxtIndex() != 0
							&& messageRequest.getNxtIndex() <= this.msgLst
									.size()) {
						messageResponse.setNxtIndex(messageRequest
								.getNxtIndex() - 1);
						if (messageRequest.getPrvIndex() > 0)
							messageResponse.setPrvIndex(messageRequest
									.getPrvIndex() - 1);
						else
							messageResponse.setPrvIndex(messageRequest
									.getPrvIndex());
						if (this.msgLst.size() == 1)
							messageResponse.setAvailable("S");
						else
							messageResponse.setAvailable("P");

					} else {
						messageResponse.setAvailable("L");
						messageResponse.setNxtIndex(0);
						messageResponse.setPrvIndex(0);
					}

				} else {
					logger.info("["
							+ messageRequest.getCallingNum()
							+ "] No msg found in list for delete because the msg list size is ["
							+ this.msgLst.size() + "]");
				}
			} else {
				messageResponse.setIsSuccess(0);
				logger.error("the calling num info  ["
						+ messageRequest.getCallingNum() + "] not in  chache ");
			}
		} else {
			logger.error(" delete.msg request >> ["
					+ messageRequest.getCallingNum()
					+ "] the request param are missing in delete message Request");
			messageResponse.setIsSuccess(-1);

		}
	}

	public void checkProfileRpy(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VccServices vccServices) {

		if (profileRequest.getCallingNum() != null
				&& profileRequest.getCalledNumB() != null
				&& profileRequest.getServiceType() != null
				&& profileRequest.getLang() != 0) {
			logger.info(String
					.format("callingNum [%s] callingNumB [%s] ServiceType [%s] lang [%s] ",
							profileRequest.getCallingNum(),
							profileRequest.getCalledNum(),
							profileRequest.getServiceType(),
							profileRequest.getLang()));
			profileClient = new ProfileClient();
			profileFilterManager = new ProfileFilterManager();
			profileResponse.setIsCallAllowed(1);
			
			// profileFilterManager.setFilter(new MailboxFilter());
			profileFilterManager.setFilter(new CallRecordPathFilter());
			profileFilterManager.setFilter(new GetProfileReply());
			profileClient.setFilterManager(profileFilterManager);
			profileClient.sendRequest(bindingResult, vccServices,
					profileRequest, profileResponse, vmError);

			if (profileResponse.getIsCallAllowed() == 1
					|| profileResponse.getIsSubscriber() == 1) {
				try {
					int ratePlan = profileResponse.getRatePlan();
					String ratePlanJson = VccExpiryCache.getSysmap().get(
							"vcc_rate_plan");
					// logger.info("rate plan json "+ratePlanJson);
					JsonParser jsonParser = new JsonParser();
					String mailBoxId = jsonParser.parse(ratePlanJson)
							.getAsJsonObject().get("" + ratePlan + "")
							.getAsJsonObject().get("mailBoxId").toString();
					String mailBoxParamJson = VccExpiryCache.getSysmap().get(
							"vcc_mailbox_param");
					int recordingTime = Integer.parseInt(jsonParser
							.parse(mailBoxParamJson).getAsJsonObject()
							.get(mailBoxId).getAsJsonObject()
							.get("maxRecordingTime").toString());
					logger.info("aParty [" + profileRequest.getCallingNum()
							+ "] bParty [" + profileRequest.getCalledNumB()
							+ "] the recordingTime is [" + recordingTime
							+ "] for  [" + profileRequest.getCalledNumB() + "]");
					profileResponse.setRecordLength(recordingTime);
					profileResponse.setRecordTimeout(recordingTime);
				} catch (Exception e) {
					errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00060] CallingNum["+profileRequest.getCallingNum()+"] CalledNum["+profileRequest.getCalledNum()+"] [Exception while getting MailBoxId from Global Cache] Error["+ e.getMessage() +"]");

					logger.error("Unable to get mailBoxid from Global cache ");
				}
			} else {
				logger.info("[" + profileRequest.getCallingNum()
						+ "]  the recordingTime is not set for  ["
						+ profileRequest.getCalledNumB() + "]");
			}

		} else {
			logger.error(String
					.format("check profile request param are missing callingNum [%s] callingNumB [%s] ServiceType [%s] lang [%s] ",
							profileRequest.getCallingNum(),
							profileRequest.getCalledNum(),
							profileRequest.getServiceType(),
							profileRequest.getLang()));
			profileResponse.setIsSuccess(-1);

		}
	}

	public void saveRpyMsg(VmRequest vmRequest, BindingResult bindingResult,
			VmResponse vmResponse, VccServices vccServices) {

		if (vmRequest.getCallingNum() != null
				&& (vmRequest.getCalledNumB() != null || vmRequest.getGroupId() != 0)
				&& vmRequest.getRecordFileName() != null
				&& vmRequest.getRecordingDuration() != 0)

		{

			commonOperation = new VccCommonOperation();
			logger.info(String.format(
					"callingNum [%s] callingNumB [%s] ServiceType [%s]  recordFileName [%s] "
							+ "callTime [%s] recordingDuration [%s] ",
					vmRequest.getCallingNum(), vmRequest.getCalledNumB(),
					vmRequest.getServiceType(), vmRequest.getRecordFileName(),
					vmRequest.getCallTime(), vmRequest.getRecordingDuration()));
			messageOperation = new MessageOperation();

			if (vmRequest.getCalledNumB() != null) {

				this.status = messageOperation.sendMsgToMsisdn(vmRequest,
						vmResponse, vccServices);
				logger.info("[" + vmRequest.getCallingNum()
						+ "] send message to [" + vmRequest.getCalledNumB()
						+ "] and sneding status is [" + this.status + "]");

			} else if (vmRequest.getGroupId() != 0) {

				this.status = messageOperation.sendMsgToGroup(vmRequest,
						vmResponse, vccServices);
				logger.info("[" + vmRequest.getCallingNum()
						+ "] send message to groupid ["
						+ vmRequest.getGroupId() + "] and sneding status is ["
						+ this.status + "]");
			}

		} else {
			logger.error("error in getting deatilsString"
					+ String.format(
							"callingNum [%s] callingNumB [%s] ServiceType [%s] recordFile [%s] recordPath [%s] "
									+ "callTime [%s] recordingDuration [%s] ",
							vmRequest.getCallingNum(),
							vmRequest.getCalledNumB(),
							vmRequest.getServiceType(),
							vmRequest.getRecordFileName(),
							vmRequest.getRecordFile(), vmRequest.getCallTime(),
							vmRequest.getRecordingDuration()));
			vmResponse.setIsSuccess(-1);
		}
	}

	public void scheduleVoiceMail(VmRequest vmRequest,
			BindingResult bindingResult, VmResponse vmResponse,
			VccServices vccServices) {

		if (vmRequest.getCallingNum() != null
				&& (vmRequest.getCalledNumB() != null || vmRequest.getGroupId() != 0)
				&& vmRequest.getServiceType() != null
				&& vmRequest.getRecordFileName() != null
				&& vmRequest.getScheduleDate() != null
				&& vmRequest.getScheduleTime() != null) {

			logger.info(String
					.format("callingNum [%s] callingNumB [%s] ServiceType [%s] recordFile [%s] "
							+ "callTime [%s] recordingDuration [%s] scheduleDate [%s] ",
							vmRequest.getCallingNum(),
							vmRequest.getCalledNumB(),
							vmRequest.getServiceType(),
							vmRequest.getRecordFileName(),
							vmRequest.getCallTime(),
							vmRequest.getRecordingDuration(),
							vmRequest.getScheduleDate()));
			messageOperation = new MessageOperation();

			if (vmRequest.getCalledNumB() != null) {

				this.status = messageOperation.sendMsgLaterToMsisdn(vmRequest,
						vmResponse, vccServices);
				logger.info("[" + vmRequest.getCallingNum()
						+ "] send message to [" + vmRequest.getCalledNumB()
						+ "] and sending status is [" + this.status + "]");

			} else if (vmRequest.getGroupId() != 0) {
				this.status = messageOperation.sendMsgLaterToGroup(vmRequest,
						vmResponse, vccServices);
				logger.info("[" + vmRequest.getCallingNum()
						+ "] send message to groupid ["
						+ vmRequest.getGroupId() + "] and sending status is ["
						+ this.status + "]");
			}

		} else {
			vmResponse.setIsSuccess(-1);
			logger.error(String
					.format(" scheduleVoiceMail reqest param are missing callingNum [%s] callingNumB [%s] ServiceType [%s] recordFile [%s] "
							+ "callTime [%s] recordingDuration [%s] scheduleDate [%s] ",
							vmRequest.getCallingNum(),
							vmRequest.getCalledNumB(),
							vmRequest.getServiceType(),
							vmRequest.getRecordFileName(),
							vmRequest.getCallTime(),
							vmRequest.getRecordingDuration(),
							vmRequest.getScheduleDate()));
		}
	}
}
