package com.vcc.domain;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.google.gson.Gson;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.handler.ProfileHandler;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.response.VmResponse;

public class VoiceNoteFilter {
	final static Logger logger = Logger.getLogger(VoiceNoteFilter.class);
	private Gson gson = new Gson();

	public ProfileResponse process(VmRequest vmRequest, VmResponse vmResponse,
			VmError vmError, VccServices vccServices) {
		ProfileHandler profileHandler = new ProfileHandler();
		ProfileResponse profileResponse = new ProfileResponse();
		ProfileRequest profileRequest = new ProfileRequest();
		try {
			logger.debug("calling ["+vmRequest.getCallingNum()+"] called ["+vmRequest.
					getCalledNum()+"] call-uuid ["+vmRequest.getCallUUID()+
					"] server ["+vmRequest.getServerId()+"] CallTime ["+vmRequest.getCallTime()+"] Profile check during hangup ..!!");
			profileRequest.setCallingNum(vmRequest.getCallingNum());
			profileRequest.setCalledNum(vmRequest.getCalledNum());
			profileRequest.setReleaseCode(vmRequest.getReleaseCode());
			profileRequest.setServiceType(vmRequest.getServiceType());
			profileRequest.setServerId(vmRequest.getServerId());
			profileRequest.setCallUUID(vmRequest.getCallUUID());
			profileRequest.setRecordingDuration(vmRequest.getRecordingDuration());
			profileRequest.setHangupCause(vmRequest.getHangupCause());
			profileRequest.setCallDuration(vmRequest.getCallDuration());
			profileRequest.setAnswerd(vmRequest.getAnswerd());
			profileRequest.setLang(vmRequest.getLang());
			profileRequest.setRecordFileName(vmRequest.getRecordFileName());
			profileRequest.setCallTime(vmRequest.getCallTime());
			profileRequest.setIsSilentDetect(vmRequest.getIsSilentDetect());
			profileRequest.setRecordTimeout(vmRequest.getRecordTimeout());
			BindingResult bindingResult = null;
			profileHandler.profileCheck(profileRequest, bindingResult,
					profileResponse, vccServices);
			//System.out.println("response data: "+gson.toJson(profileResponse));
			vmRequest.setRecordFileName(profileResponse.getRecordFileName());
			vmRequest.setActiveServiceList(profileRequest.getActiveServiceList());
			//profileResponse.setIsSilentDetect(this.getIsSilentDetected(vmRequest));
			logger.debug("response data: "+gson.toJson(profileResponse));
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("called [" + profileRequest.getCalledNum()
					+ "] calling [" + profileRequest.getCallingNum()
					+ "] Error while maintain profile: " + e.getMessage());
		}
		return profileResponse;
	}
	
	/*private int getIsSilentDetected(VmRequest vmRequest) {
		if (vmRequest.getIsSilentDetect() == 1) {
			if (vmRequest.getRecordingDuration()
					/ AppConfig.config.getInt("record_duration_divisor", 1000) == AppConfig.config
						.getInt("record_timeout_"
								+ vmRequest.getServiceType() + "", 10)) {
				return 1;
			} else if (vmRequest.getRecordingDuration()
					/ AppConfig.config.getInt("record_duration_divisor", 1000)
					+ AppConfig.config.getInt("silence_negotiation", 0) >= AppConfig.config
						.getInt("record_timeout_"
								+ vmRequest.getServiceType() + "", 10)) {
				return 1;
			} else {
				return 0;
			}
		} else {
			return 0;
		}
	}*/
	
}
