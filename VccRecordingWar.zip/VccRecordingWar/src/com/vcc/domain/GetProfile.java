package com.vcc.domain;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.cache.VccExpiryCache;
import com.vcc.chain.Profile;
import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.filter.Filter;
import com.vcc.model.VccServiceProvider;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.repository.Informer;
import com.vcc.repository.ServicingRepository;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.services.Servicing;


public class GetProfile implements Profile, Filter {

	final static Logger logger = Logger.getLogger(GetProfile.class);
	
	private List<VccServiceProvider> serviceList;
	private List<VccSubscriptionMaster> activeServiceList;
	private ServicingRepository servicingRepository;
	private Servicing servicing;

	public GetProfile() {

	}
	
	public void setActiveServiceList(List<VccSubscriptionMaster> activeServiceList) {
		this.activeServiceList = activeServiceList;
	}


	public void execute(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {
		if(profileResponse.getIsCallAllowed()==1)
			this.process(profileRequest, bindingResult, profileResponse, vmError,
				vccServices);
		else
			logger.warn("calling ["+profileRequest.getCallingNum()+"] called ["+profileRequest.
				getCalledNum()+"] call not allowed !!........");
	}
	/**
	 * return void 
	 * this method check the Profile of particular msisdn  
	 * @param profileRequest the variable contain bean of ProfileRequest ,which set by url request like - callingNum , calledNum ,serviceType etc  
	 * @param profileResponse the variable contain bean of  profileResponse , which actually return in url response like - isSuccess , isCallAllowed, isSubscriber 
	 * @param vmError vmError is a bean that is used to define which type of error generate in operation
	 * @param vccServices vccServices is a bean that contain reference of interface(UserService,MessageService,UserConfigService) 
	 * @return void     
	 * @see    nothing
	 */
	@SuppressWarnings("unchecked")
	public void process(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {
		try {
			this.serviceList = (List<VccServiceProvider>) VccExpiryCache.getGlobalmap().get("vcc_service_provider");
			servicingRepository = new ServicingRepository(profileRequest,
					profileResponse, vmError, vccServices, this.serviceList, this.activeServiceList);
			for (Informer informer = servicingRepository.getInformer(); informer
					.hasNext();) {
				servicing = (Servicing) informer.next();
				if (servicing != null)
					break;
			}
			if (servicing == null) {				
				servicing = servicingRepository.getDefaultBacker();
			}
			servicing.doConsent(profileRequest, profileResponse, vmError, vccServices,this.activeServiceList);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
