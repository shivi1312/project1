package com.vcc.domain;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.vcc.chain.VmChain;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.net.ConnectionPool;
import com.vcc.net.TextSocketConnection;
import com.vcc.persistent.client.Client;
import com.vcc.persistent.client.TcpConnectionUtil;
import com.vcc.request.VccNotificationRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.VmResponse;
import com.vcc.util.TcpPool;

public class VccSendNotification implements VmChain {
	final static Logger logger = Logger.getLogger(VccSendNotification.class);
	@SuppressWarnings("unused")
	private VmChain nextInVmChain;
	@SuppressWarnings("unused")
	private VccServices vccServices;
	private int isUserOptOut;
	private int isNotifyMeWithMCM;
	//private String releaseCode;
	private int status = 0;
	private int recordDuration = 0;
	private int callDuration = 0;
	private int answerd = 0;

	@Override
	public void setNext(VmChain nextInVmChain, VccServices vccServices) {
		this.nextInVmChain = nextInVmChain;
		this.vccServices = vccServices;

	}

	/**
	 * return void this method is responsible for to sending message
	 * notification after sending voice mail to B party
	 * 
	 * @param vmRequest
	 *            the variable contain bean of vmRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param vmResponse
	 *            the variable contain bean of vmResponse , which actually
	 *            return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	@Override
	public void process(VmRequest vmRequest, VmResponse vmResponse,
			VmError vmError) {
		String releaseCode = vmRequest.getReleaseCode();
		logger.info("### releaseCode="+releaseCode); //user-busy & no-answer

		if (vmRequest.getSubType().equalsIgnoreCase("F")) {
			logger.info(String
					.format("A-Party [%s] B-Party [%s] send notification of [%s] is [%s] subtype [%s] any error [%s]",
							vmRequest.getCallingNum(),
							vmRequest.getCalledNum(), AppConfig.config
									.getString(vmRequest.getServiceType()),
							this.status, vmRequest.getSubType(), vmError
									.getError()));
		} else if (AppConfig.config.getBoolean("mca_handler_hit_enable", true)) {
			logger.info("mca_handler_hit_enable flag is ["
					+ AppConfig.config.getBoolean("mca_handler_hit_enable",
							true) + "] now mca request is process");
			
			callDuration = vmRequest.getCallDuration();
			isUserOptOut = vmRequest.getIsUserIsOptedOut();
			isNotifyMeWithMCM = vmRequest.getIsNotifyMeWithMCM();
			//releaseCode = vmRequest.getReleaseCode();
			answerd = vmRequest.getAnswerd();
			recordDuration = vmRequest.getRecordingDuration();
			if (vmRequest.getServiceType().equalsIgnoreCase(AppConfig.config.getString("VN"))) {
				if(AppConfig.config.getInt("USER_BUSY_MCA_ACTIVATED", 1) == 0 && releaseCode.equalsIgnoreCase(AppConfig.config.getString("user-busy", "user-busy"))) {
					logger.info("USER_BUSY_MCA_ACTIVATED is disable for release code user-busy");
				} else if(AppConfig.config.getInt("NOREPLY_MCA_ACTIVATED", 1) == 0 && releaseCode.equalsIgnoreCase(AppConfig.config.getString("no-answer", "no-answer"))) {
					logger.info("NOREPLY_MCA_ACTIVATED is disable for release code no-answer");
				} else {
					if(vmRequest.getIsSilentDetect()==1){
						
						vmRequest.setType(AppConfig.config
								.getString("notifymewithmcn"));
						this.sendMcaNotification(vmRequest);
						
					}
					else if (this.isUserOptOut == 1
							|| releaseCode.equalsIgnoreCase(AppConfig.config
									.getString("user-busy", "user-busy"))
							|| this.isNotifyMeWithMCM == 1) {
						vmRequest.setType(AppConfig.config
								.getString("notifymewithmcn"));
						this.sendMcaNotification(vmRequest);
						// this.sendNotification(vmRequest);
					} else if (recordDuration <= 0 || callDuration <= 0
							|| answerd == 0) {
						vmRequest.setType(AppConfig.config
								.getString("notifymewithmcn"));
						this.sendMcaNotification(vmRequest);
						// this.sendNotification(vmRequest);
					} else if (answerd == 1) {
						vmRequest.setType(AppConfig.config.getString("notifyme"));
						this.sendMcaNotification(vmRequest);
						// this.sendNotification(vmRequest);
					}
				}
			}else if (vmRequest.getServiceType().equalsIgnoreCase(AppConfig.config.getString("VM"))) {
				if(AppConfig.config.getInt("USER_BUSY_MCA_ACTIVATED", 1) == 0 && releaseCode.equalsIgnoreCase(AppConfig.config.getString("user-busy", "user-busy"))) {
					logger.info("USER_BUSY_MCA_ACTIVATED is disable for release code user-busy");
				} else if(AppConfig.config.getInt("NOREPLY_MCA_ACTIVATED", 1) == 0 && releaseCode.equalsIgnoreCase(AppConfig.config.getString("no-answer", "no-answer"))) {
					logger.info("NOREPLY_MCA_ACTIVATED is disable for release code no-answer");
				} else {
					if (vmRequest.getIsSilentDetect() == 1) {
						vmRequest.setType(AppConfig.config.getString("notifymewithmcn"));
						this.sendMcaNotification(vmRequest);

					} else if ((this.isNotifyMeWithMCM == 0 || vmRequest
							.getServiceType().equalsIgnoreCase(
									AppConfig.config.getString("VM")))
							&& answerd == 1) {
						vmRequest.setType(AppConfig.config.getString("notifyme"));
						this.sendMcaNotification(vmRequest);
						// this.sendNotification(vmRequest);
					} else if ((this.isNotifyMeWithMCM == 0 || vmRequest
							.getServiceType().equalsIgnoreCase(
									AppConfig.config.getString("VM")))
							&& answerd == 0) {
						vmRequest.setType(AppConfig.config
								.getString("notifymewithmcn"));
						this.sendMcaNotification(vmRequest);

					}
				}
			}else {
				if(AppConfig.config.getInt("USER_BUSY_MCA_ACTIVATED", 1) == 0 && releaseCode.equalsIgnoreCase(AppConfig.config.getString("user-busy", "user-busy"))) {
					logger.info("USER_BUSY_MCA_ACTIVATED is disable for release code user-busy");
				} else if(AppConfig.config.getInt("NOREPLY_MCA_ACTIVATED", 1) == 0 && releaseCode.equalsIgnoreCase(AppConfig.config.getString("no-answer", "no-answer"))) {
					logger.info("NOREPLY_MCA_ACTIVATED is disable for release code no-answer");
				} else {
					vmRequest.setType(AppConfig.config.getString("notifymewithmcn"));
					vmRequest.setServiceType("0001");
					//added by sanchit on 17/09/2021
					VccCommonOperation commonOperation = new VccCommonOperation();
					String groupName = "whitelist";
					boolean isExistWithInSeries = commonOperation.isExistWithinGroup(vmRequest.getCalledNum(), groupName);
					
					if(isExistWithInSeries)
					{
						this.sendMcaNotification(vmRequest);
					}
					else
					{
						logger.info("Msisdn not in range so not sending request to mcaHandler...");
					}
					// end
				}
			}

			logger.info(String
					.format("A-Party [%s] B-Party [%s] send notification of [%s] is [%s] any error [%s]",
							vmRequest.getCallingNum(),
							vmRequest.getCalledNum(), AppConfig.config
									.getString(vmRequest.getServiceType()),
							this.status, vmError.getError()));
		} else {
			logger.info("mca_handler_hit_enable flag is ["
					+ AppConfig.config.getBoolean("mca_handler_hit_enable",
							true) + "] no mca request is process");
		}
	}

	/**
	 * return void this method is responsible for to sending message
	 * notification after sending voice mail to B party and send MCA request via
	 * socket
	 * 
	 * @param profileRequest
	 *            the variable contain bean of vmRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of vmResponse , which actually
	 *            return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	private void sendNotification(VmRequest vmRequest) {
		ConnectionPool connectionPool = null;
		TextSocketConnection socketConnection = null;
		VccNotificationRequest notificationRequest = new VccNotificationRequest();
		notificationRequest.setaParty(vmRequest.getCallingNum());
		notificationRequest.setbParty(vmRequest.getCalledNum());
		notificationRequest.setReasonCode(vmRequest.getReleaseCode());
		notificationRequest.setServiceType(vmRequest.getServiceType());
		notificationRequest.setCallTime(vmRequest.getCallTime());
		notificationRequest.setType(vmRequest.getType());
		//set lang by kuldeep 05-06-2021
		if(vmRequest.getLang() < 1) {
			notificationRequest.setLang(AppConfig.config.getInt("vms_default_language"));
		} else {
			notificationRequest.setLang(vmRequest.getLang());
		}
		
		Gson gson = new Gson();
		String data = gson.toJson(notificationRequest);

		try {
			connectionPool = TcpPool.getMcaConPool();
			logger.info("Total pool ["
					+ connectionPool.numberOfPooledConnections() + "]");
			socketConnection = connectionPool.getConnection();
			if (connectionPool != null && socketConnection != null) {

				logger.info("MCA Handler Server has connected!\n");
				logger.info("sending mca ntification Sending string: ''\n");
				logger.info("Sending Data to MCA Handler >>>>>>>" + data);
				socketConnection.write(data);
				logger.info("MCA Handler response: "
						+ socketConnection.readLine());

			} else {
				logger.info("Mca handler not connected so can't send notification");
			}
		} catch (Exception e) {
			logger.error("error in send mca notification [" + e + "]");
		} finally {
			try {
				socketConnection.close();

			} catch (Exception e) {
				logger.error("error in closing socket [" + e + "]");
			}
		}
	}

	/**
	 * return void this method is responsible for to sending message
	 * notification after sending voice mail to B party and send MCA request via
	 * socket
	 * 
	 * @param profileRequest
	 *            the variable contain bean of vmRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of vmResponse , which actually
	 *            return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	private void sendMcaNotification(VmRequest vmRequest) {

		VccNotificationRequest notificationRequest = new VccNotificationRequest();
		notificationRequest.setaParty(vmRequest.getCallingNum());
		notificationRequest.setbParty(vmRequest.getCalledNum());
		notificationRequest.setReasonCode(vmRequest.getReleaseCode());
		notificationRequest.setServiceType(vmRequest.getServiceType());
		notificationRequest.setCallTime(vmRequest.getCallTime());
		notificationRequest.setType(vmRequest.getType());
		//set lang by kuldeep 05-06-2021
		if(vmRequest.getLang() < 1) {
			notificationRequest.setLang(AppConfig.config.getInt("vms_default_language"));
		} else {
			notificationRequest.setLang(vmRequest.getLang());
		}
		
		Gson gson = new Gson();
		String json = gson.toJson(notificationRequest);
		Client client = null;
		try {
			client = TcpConnectionUtil.getInstance("mcahandler")
					.getConnection();
			logger.info("Sending Data to MCA Handler >>>>>>>" + json);
			client.write(json);
		} catch (Exception e) {
			logger.info("Exception while sending data to MCA Handler.. " + e);
			e.printStackTrace();
		}
		
	}

	/**
	 * return void the method is responsible for gathering difference between
	 * retrieval start and end time
	 * 
	 * @param dateStart
	 *            this variable contains message retrieval start time
	 * @param dateStop
	 *            this variable contains message retrieval end time
	 * @return time in second
	 * @see time
	 */
	public int getRetSecond(String dateStart, Date dateStop) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		Date d1 = null;
		Date d2 = null;
		logger.debug("date start [" + dateStart + "] and datestop [" + dateStop
				+ "]");
		try {
			d1 = format.parse(dateStart);
			d2 = format.parse(format.format(dateStop));
			logger.debug("Date parse date start [" + d1 + "] and datestop ["
					+ d2 + "]");
			// in milliseconds
			long diff = d2.getTime() - d1.getTime();

			int diffSeconds = (int) ((diff / 1000));
			logger.debug("total record duration is [" + diffSeconds + "] di["
					+ (diff / 1000 % 60) + "]");
			return diffSeconds;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;

		}

	}

}
