package com.vcc.domain;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.tele.config.AppConfig;
import com.vcc.chain.VmChain;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServiceFlag;
import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.model.VccVoiceMessage;
import com.vcc.request.UserConfigRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.VmResponse;

public class VmOperation implements VmChain {
	final static Logger logger = Logger.getLogger(VmOperation.class);
	private VmChain nextInVmChain;
	private Gson gson = new Gson();
	private VccServices vccServices;
	private int sendVoiceMsgstatus;
	private String serviceFlag = null;
	private VccUserCompleteDetails userCompleteDetails = null;
	private Boolean sendNotiStatus = false;
	private Boolean alternativeStatus = false;
	private VccVoiceMessage vmsMessage = null;
	private UserConfigRequest userConfigRequest = null;
	private int notiStatus = 0;
	VccCommonOperation commonOperation = null;
	private boolean notiFlag = true;
	private boolean altFlag = false;

	@Override
	public void setNext(VmChain nextInVmChain, VccServices vccServices) {
		this.nextInVmChain = nextInVmChain;
		this.vccServices = vccServices;
	}

	/**
	 * return void this method is responsible for to sending message voice mail
	 * to B party and message details insert entry in VCC_VOICE_MSG
	 * 
	 * @param vmRequest
	 *            the variable contain bean of vmRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param vmResponse
	 *            the variable contain bean of vmResponse , which actually
	 *            return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	@Override
	public void process(VmRequest vmRequest, VmResponse vmResponse,
			VmError vmError) {
		try {
			logger.debug("called [" + vmRequest.getCalledNum() + "] calling ["
					+ vmRequest.getCallingNum() + "] save record file in db");
			int recordDuration = 0;
			this.vmsMessage = new VccVoiceMessage();
			this.commonOperation = new VccCommonOperation();
			this.vmsMessage.setMessageStatus("N");
			

			this.vmsMessage.setOriginattingNumber(commonOperation
					.msisdnWithCountryCode(vmRequest.getCallingNum()));
			this.vmsMessage.setDesticationNumber(commonOperation
					.msisdnWithCountryCode(vmRequest.getCalledNum()));
			this.vmsMessage.setFileName(vmRequest.getRecordFileName());
			this.vmsMessage.setCallTime(vmRequest.getCallTime());
			this.vmsMessage.setOrginalNumber(commonOperation
					.msisdnWithCountryCode(vmRequest.getCalledNum()));

			this.vmsMessage.setRecordingTime(vmRequest.getRecordingDuration());

			/*if (vmRequest.getRecordingDuration() != 0) {
				this.vmsMessage.setRecordingTime(vmRequest
						.getRecordingDuration());

			} else {
				Date curDate = new Date();
				recordDuration = getRetSecond(vmRequest.getCallTime(), curDate);
				vmRequest.setRecordingDuration(recordDuration*1000); // add if record duration 0 from request
				this.vmsMessage.setRecordingTime(recordDuration);
			}*/
			this.vmsMessage.setServiceType(vmRequest.getServiceType());
				
			this.vmsMessage.setMsgPriority("H");
			this.vmsMessage.setMsgProtect("F");
			this.vmsMessage.setPassProtected("F");
			this.vmsMessage.setPassword("0000");
			
			/*Added by Vivek Kumar*/
			this.vmsMessage.setLocalMessageIndex(1);
			if(!AppConfig.config.getBoolean("copy_temp_file",true))
				vmRequest.setIsRecordFileExits(true);
			/*Completed*/
			
			logger.debug("called [" + vmRequest.getCalledNum() + "] calling ["
					+ vmRequest.getCallingNum() + "] mailbox full ["+vmRequest.getIsMailBoxFull()+
					"] old file deleted ["+vmRequest.getIsOldFileDeleted()+"] record file exist ["+
					vmRequest.getIsRecordFileExits()+"] local message index ["+vmsMessage.getLocalMessageIndex()+"]");
			if (vmRequest.getIsMailBoxFull() == 1
					&& vmRequest.getIsOldFileDeleted()	
					&& vmRequest.getIsRecordFileExits()
					&& vmsMessage.getLocalMessageIndex() > 0) {
				this.sendVoiceMsgstatus = vccServices.userService.insertVoiceMessage(vmsMessage);
				// logic write for insert into vcc_notification
				if (this.sendVoiceMsgstatus != 0)
				{
					this.sendNotiStatus = sendNotification(vmRequest,
							vccServices);
				}
			} else if (vmRequest.getIsMailBoxFull() == 0
					&& vmRequest.getIsRecordFileExits()
					&& vmsMessage.getLocalMessageIndex() > 0) {
				this.sendVoiceMsgstatus = vccServices.userService.insertVoiceMessage(vmsMessage);
				// logic write for insert into vcc_notification
				if (this.sendVoiceMsgstatus != 0)
					this.sendNotiStatus = sendNotification(vmRequest,vccServices);
			} else {
				this.sendVoiceMsgstatus = 0;
			}
			logger.info(String
					.format("A-Party [%s] B-Party [%s] saved file in db [%s] save notification [%s] any error [%s]",
							vmRequest.getCallingNum(),
							vmRequest.getCalledNum(), this.sendVoiceMsgstatus,
							this.sendNotiStatus, vmError.getError()));
			if (this.sendVoiceMsgstatus > 0 && !vmError.getError()
					&& vmRequest.getReasonCode().equalsIgnoreCase("normal"))
				vmResponse.setIsSuccess(1);
			else if (this.sendVoiceMsgstatus > 0 && !vmError.getError()) {
				nextInVmChain.process(vmRequest, vmResponse, vmError);
			} else if (this.sendVoiceMsgstatus == 0 && vmError.getError()) {
				nextInVmChain.process(vmRequest, vmResponse, vmError);
				vmResponse.setIsSuccess(-1);
			} else if (sendVoiceMsgstatus == 0) {
				vmResponse.setIsSuccess(0);
				nextInVmChain.process(vmRequest, vmResponse, vmError);
			} else
				vmResponse.setIsSuccess(0);
		} catch (Exception e) {
			e.printStackTrace();
			vmResponse.setIsSuccess(-1);
			logger.error(String
					.format("A-Party [%s] B-Party [%s] Exception saved data in db [%s]",
							vmRequest.getCallingNum(),
							vmRequest.getCalledNum(), e.getMessage()));
		}
	}
	public VccSubscriptionMaster getAuthDetail(List<VccSubscriptionMaster> master){
		VccSubscriptionMaster vccSub = null;
		try {
			if(master != null){
				for(VccSubscriptionMaster vccMaster: master){
					return vccMaster;
				}
			}
		}catch(Exception e){
			logger.error("Error while convert master to auth user: "+e.getMessage());
		}
		return vccSub;
	}
	public VccUserCompleteDetails getCompleteAuthDetail(List<VccUserCompleteDetails> master){
		VccUserCompleteDetails vccSub = null;
		try {
			if(master != null){
				for(VccUserCompleteDetails vccMaster: master){
					return vccMaster;
				}
			}
		}catch(Exception e){
			logger.error("Error while convert master to auth user: "+e.getMessage());
		}
		return vccSub;
	}
	private Boolean sendNotification(VmRequest vmRequest,
			VccServices vccServices) {

		this.vmsMessage.setNotificationSend(vmRequest.getNotificationSend());
		// get voice_msg_index
		/*this.vmsMessage.setVoiceMessageIndex(vccServices.userService
				.getVoiceMsgIndex(vmRequest));*/

		this.vmsMessage.setVoiceMessageIndex(0); //Added By AbhiShek Rana for decreasing the number of queries.
		
		// get user details
		//this.userCompleteDetails = vccServices.userService
			//	.getUserCompleteDetail(this.vmsMessage.getOrginalNumber());
		try {
			this.userCompleteDetails = gson.fromJson(gson.toJson(this.getAuthDetail(vmRequest.getActiveServiceList())),VccUserCompleteDetails.class);
			if(this.userCompleteDetails == null)
				this.userCompleteDetails = this.getCompleteAuthDetail(vccServices.userService.getUserCompleteDetail(this.vmsMessage.getOrginalNumber()));
		}catch(Exception e){
			logger.info(" [" + vmRequest.getCallingNum() + "] Error while convert in Complete detail: "+e.getMessage());
			this.userCompleteDetails = this.getCompleteAuthDetail(vccServices.userService.getUserCompleteDetail(this.vmsMessage.getOrginalNumber()));
		}
		if(this.userCompleteDetails.getSubType().equalsIgnoreCase("F"))
		{
			logger.info(" [" + vmRequest.getCallingNum() + "] send notify  to  ["
                    + this.vmsMessage.getDesticationNumber()
                    + "] notfication not send because subType is ["+this.userCompleteDetails.getSubType()+"]");
            commonOperation = null;
            return false;
		}else
		{
		// get service flag details
		/*this.serviceFlag = vccServices.userConfigService.getServiceFlag(
				this.vmsMessage.getOrginalNumber(),
				this.vmsMessage.getServiceType());*/
		if(this.userCompleteDetails != null)
			this.serviceFlag = this.userCompleteDetails.getServiceFlag();

		this.notiFlag = commonOperation.checkServiceFlag(serviceFlag,
				VccServiceFlag.notification_enable_disable);
		this.altFlag = this.alternativeStatus = commonOperation
				.checkServiceFlag(serviceFlag,
						VccServiceFlag.alternative_msisdn_enable_disable);

		
		//check and send notification to alternative number 
		if (this.serviceFlag != null && this.altFlag) {

			this.userConfigRequest = new UserConfigRequest();
			this.userConfigRequest.setCallingNum(this.vmsMessage
					.getOrginalNumber());
			this.userConfigRequest
					.setServiceFlagIndex(VccServiceFlag.alternative_msisdn_enable_disable);
			this.userConfigRequest.setServiceType(vmRequest.getServiceType());
			String destNumber = vccServices.userConfigService
					.getMsisdnFromAdvancedDetails(this.userConfigRequest);

		
			
			if (destNumber != null) {
				logger.info("[" + vmRequest.getCallingNum()
						+ "]   alternative no. found [" + destNumber + "]");
				this.vmsMessage.setDesticationNumber(destNumber);
				
				this.alternativeStatus = true;

			} else {

				logger.info("[" + vmRequest.getCallingNum()
						+ "]   alternative no. not found  sent noti to ["
						+ vmsMessage.getOrginalNumber() + "]");
				this.vmsMessage.setDesticationNumber(vmsMessage
						.getOrginalNumber());

			}
		}
		
		
		

		// send notification to calledNum 
		if (userCompleteDetails != null && this.notiFlag) {
			this.notiStatus = vccServices.userService.saveVccNotification(
					this.vmsMessage, this.userCompleteDetails);
		}

		logger.info(" [" + vmRequest.getCallingNum() + "] send notify  to  ["
				+ this.vmsMessage.getDesticationNumber()
				+ "] is send to alternative msisdn [" + this.alternativeStatus
				+ "]  notify send status [" + this.notiStatus + "]");
		commonOperation = null;
		return true;
		}
	}

	public String getCurrentTimeStamp() {
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
				.format(new Date());
	}

	/**
	 * return void the method is responsible for gathering difference between
	 * retrieval start and end time
	 * 
	 * @param dateStart
	 *            this variable contains message retrieval start time
	 * @param dateStop
	 *            this variable contains message retrieval end time
	 * @return time in second
	 * @see time
	 */
	public int getRetSecond(String dateStart, Date dateStop) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		Date d1 = null;
		Date d2 = null;
		logger.debug("date start [" + dateStart + "] and datestop [" + dateStop
				+ "]");
		try {
			d1 = format.parse(dateStart);
			d2 = format.parse(format.format(dateStop));
			logger.debug("Date parse date start [" + d1 + "] and datestop ["
					+ d2 + "]");
			// in milliseconds
			long diff = d2.getTime() - d1.getTime();

			int diffSeconds = (int) ((diff / 1000));
			logger.info("total record duration is [" + diffSeconds + "] di["
					+ (diff / 1000 % 60) + "]");
			return diffSeconds;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;

		}

	}

}
