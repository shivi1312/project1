package com.vcc.domain;

import java.util.List;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.vcc.chain.VmChain;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.model.VccFwdCallLogs;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.VmResponse;

public class FwdCallLogs implements VmChain {
	final static Logger logger = Logger.getLogger(FwdCallLogs.class);
	private VmChain nextInVmChain;
	private VccServices vccServices;
	private int status;
	private VccUserCompleteDetails userCompleteDetails = null;
	private Gson gson = new Gson();

	@Override
	public void setNext(VmChain nextInVmChain, VccServices vccServices) {
		this.nextInVmChain = nextInVmChain;
		this.vccServices = vccServices;

	}

	/**
	 * return void the method is responsible for create logs of call
	 * 
	 * @param vmRequest
	 *            the variable contain bean of VmRequest ,which set by url
	 *            request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param vmResponse
	 *            the variable contain bean of VmResponse , which actually
	 *            return in url response like - isSuccess
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @return void
	 * @see nothing
	 */
	@Override
	public void process(VmRequest vmRequest, VmResponse vmResponse,
			VmError vmError) {
		VccFwdCallLogs fwdCallLogs = new VccFwdCallLogs();

		this.setFwdCallLogs(fwdCallLogs, vmRequest);
		status = vccServices.userService.insertFwdCallLogs(fwdCallLogs);

		if (status == 1)
			vmResponse.setIsSuccess(1);
		else
			vmResponse.setIsSuccess(0);
		logger.info(String
				.format("A-Party [%s] B-Party [%s] call logs saved file in db [%s] any error [%s]",
						vmRequest.getCallingNum(), vmRequest.getCalledNum(),
						status, vmError.getError()));
		if (!vmError.getError()
				&& !vmRequest.getSubType().equalsIgnoreCase("F")) {
			this.nextInVmChain = new VccSendNotification();
			this.nextInVmChain.setNext(this.nextInVmChain, this.vccServices);
			logger.debug("next in chanin instance of ["
					+ nextInVmChain.getClass() + "]");
			nextInVmChain.process(vmRequest, vmResponse, vmError);
			/*
			 * new VccSendNotification().process(vmRequest, vmResponse,
			 * vmError);
			 */
		}
	}

	/**
	 * return void the method is responsible for create logs of call
	 * 
	 * @param vmRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param fwdCallLogs
	 *            the variable contain bean of VccFwdCallLogs , which actually
	 *            set data in bean
	 * @return void
	 * @see nothing
	 */
	private void setFwdCallLogs(VccFwdCallLogs fwdCallLogs, VmRequest vmRequest) {

		fwdCallLogs.setServerId(vmRequest.getServerId());
		fwdCallLogs.setCallId(vmRequest.getCallUUID());
		fwdCallLogs.setOriginatingNumber(vmRequest.getCallingNum());
		fwdCallLogs.setDestinationNumber(vmRequest.getCalledNum());
		fwdCallLogs.setCircuitId(vmRequest.getCircuitId());
		fwdCallLogs.setIamCauseCode(vmRequest.getReleaseCode());
		fwdCallLogs.setRelCauseCode(vmRequest.getHangupCause());
		
		if (vmRequest.getRecordFileName() == null
				|| vmRequest.getRecordFileName().equalsIgnoreCase("")
				|| vmRequest.getRecordFileName().equalsIgnoreCase("0"))
		{
			fwdCallLogs.setFileName("NA");
		}else{
			fwdCallLogs.setFileName(vmRequest.getRecordFileName());
		}
		fwdCallLogs.setMsgLength(vmRequest.getRecordingDuration());
		int vccMsgIndex = 0;
		fwdCallLogs.setVoiceMsgIndex(vccMsgIndex);
		fwdCallLogs.setCallTime(vmRequest.getCallTime());
		fwdCallLogs.setCallDuration(vmRequest.getCallDuration());
		fwdCallLogs.setAnswered(vmRequest.getAnswerd());
		fwdCallLogs.setServiceType(vmRequest.getServiceType());
		if(vmRequest.getSubType().equalsIgnoreCase("0"))
		{
			fwdCallLogs.setSubType("N");
		}
		else
		{
			fwdCallLogs.setSubType(vmRequest.getSubType());
		}
		logger.debug("### ratePlan: "+vmRequest.getRatePlan());
		if(vmRequest.getRatePlan() > 0) { //added by kuldeep 18-Nov-2020
			fwdCallLogs.setRatePlan(vmRequest.getRatePlan());
		} else {
			/*fwdCallLogs.setSubType(vmRequest.getSubType());*/
			this.userCompleteDetails = gson.fromJson(gson.toJson(this
					.getAuthDetail(vmRequest.getActiveServiceList())),
					VccUserCompleteDetails.class);
			try {
				if (this.userCompleteDetails == null)
				{
					/*this.userCompleteDetails = this.getCompleteAuthDetail(vccServices.userService.getUserCompleteDetail(vmRequest.getCalledNum()));*/
					this.userCompleteDetails=this.getCompleteAuthDetail(vccServices.userService.getUserCompleteDetail(gson.fromJson(
							gson.toJson(vmRequest), ProfileRequest.class)));
				}
			} catch (Exception e) {
				logger.error("callingNum[" + vmRequest.getCallingNum()
						+ "] calledNum[" + vmRequest.getCalledNum()
						+ "] Error while getting UserCompleteDetails["
						+ e.getMessage() + "]");
				this.userCompleteDetails=this.getCompleteAuthDetail(vccServices.userService.getUserCompleteDetail(gson.fromJson(
						gson.toJson(vmRequest), ProfileRequest.class)));
				/*this.userCompleteDetails = this.getCompleteAuthDetail(vccServices.userService.getUserCompleteDetail(vmRequest.getCalledNum()));*/
			}
			if(this.userCompleteDetails==null)
			{
				logger.info("Unable to get UserCompleteDetails. So inserting into vcc_fwd_call_logs with Rate Plan[0]");
				fwdCallLogs.setRatePlan(0);
			}
			else
			{
				fwdCallLogs.setRatePlan(this.userCompleteDetails.getRatePlan());
			}
		}
	}

	public VccSubscriptionMaster getAuthDetail(
			List<VccSubscriptionMaster> master) {
		VccSubscriptionMaster vccSub = null;
		try {
			if (master != null) {
				for (VccSubscriptionMaster vccMaster : master) {
					return vccMaster;
				}
			}
		} catch (Exception e) {
			logger.error("Error while convert master to auth user: "
					+ e.getMessage());
		}
		return vccSub;
	}
	public VccUserCompleteDetails getCompleteAuthDetail(List<VccUserCompleteDetails> master){
		VccUserCompleteDetails vccSub = null;
		try {
			if(master != null){
				for(VccUserCompleteDetails vccMaster: master){
					return vccMaster;
				}
			}
		}catch(Exception e){
			logger.error("Error while convert master to auth user: "+e.getMessage());
		}
		return vccSub;
	}

}
