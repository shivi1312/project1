package com.vcc.model;

public class VccRatePlan implements java.io.Serializable {

	private static final long serialVersionUID = -7218600989492811489L;
	private int planId;
	private int subCode;
	private int subValidity;
	private int renew;
	private int renewValidity;
	private String remarks;
	private int retrieveCode;
	private int recordCode;
	private int groupRecordCode;
	private String serviceType;
	private int pullSmsCode;
	private String planName;
	private String scope;
	private int mailBoxId;
	public int getPlanId() {
		return planId;
	}

	public void setPlanId(int planId) {
		this.planId = planId;
	}

	public int getSubCode() {
		return subCode;
	}

	public void setSubCode(int subCode) {
		this.subCode = subCode;
	}

	public int getSubValidity() {
		return subValidity;
	}

	public void setSubValidity(int subValidity) {
		this.subValidity = subValidity;
	}

	public int getRenew() {
		return renew;
	}

	public void setRenew(int renew) {
		this.renew = renew;
	}

	public int getRenewValidity() {
		return renewValidity;
	}

	public void setRenewValidity(int renewValidity) {
		this.renewValidity = renewValidity;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public int getRetrieveCode() {
		return retrieveCode;
	}

	public void setRetrieveCode(int retrieveCode) {
		this.retrieveCode = retrieveCode;
	}

	public int getRecordCode() {
		return recordCode;
	}

	public void setRecordCode(int recordCode) {
		this.recordCode = recordCode;
	}

	public int getGroupRecordCode() {
		return groupRecordCode;
	}

	public void setGroupRecordCode(int groupRecordCode) {
		this.groupRecordCode = groupRecordCode;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public int getPullSmsCode() {
		return pullSmsCode;
	}

	public void setPullSmsCode(int pullSmsCode) {
		this.pullSmsCode = pullSmsCode;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public int getMailBoxId() {
		return mailBoxId;
	}

	public void setMailBoxId(int mailBoxId) {
		this.mailBoxId = mailBoxId;
	}

}
