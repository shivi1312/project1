package com.vcc.model;

import java.util.Date;
import java.util.List;
import com.vcc.model.MessageAttribute;
import com.vcc.model.MessageStatus;

public class MessageReader {

	public MessageStatus messageStatus;
	public Date lastVisitTime;
	public List<MessageAttribute> newmsg;
	public List<MessageAttribute> oldmsg;
	public List<MessageAttribute> savemsg;
	public MessageStatus getMessageStatus() {
		return messageStatus;
	}
	public void setMessageStatus(MessageStatus messageStatus) {
		this.messageStatus = messageStatus;
	}
	public List<MessageAttribute> getNewmsg() {
		return newmsg;
	}
	public void setNewmsg(List<MessageAttribute> newmsg) {
		this.newmsg = newmsg;
	}
	public List<MessageAttribute> getOldmsg() {
		return oldmsg;
	}
	public void setOldmsg(List<MessageAttribute> oldmsg) {
		this.oldmsg = oldmsg;
	}
	public List<MessageAttribute> getSavemsg() {
		return savemsg;
	}
	public void setSavemsg(List<MessageAttribute> savemsg) {
		this.savemsg = savemsg;
	}
	public Date getLastVisitTime() {
		return lastVisitTime;
	}
	public void setLastVisitTime(Date lastVisitTime) {
		this.lastVisitTime = lastVisitTime;
	}
	
	
	
}
