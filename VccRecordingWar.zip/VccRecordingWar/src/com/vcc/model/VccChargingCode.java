package com.vcc.model;

public class VccChargingCode implements java.io.Serializable {

	private static final long serialVersionUID = -7218600989492811489L;
	private int chargingCode;
	private double amountPre;
	private double amountPost;
	private String  chargingCodeName;
	private long tariffPre;
	private long tariffPost;
	public int getChargingCode() {
		return chargingCode;
	}
	public void setChargingCode(int chargingCode) {
		this.chargingCode = chargingCode;
	}
	public double getAmountPre() {
		return amountPre;
	}
	public void setAmountPre(double amountPre) {
		this.amountPre = amountPre;
	}
	public double getAmountPost() {
		return amountPost;
	}
	public void setAmountPost(double amountPost) {
		this.amountPost = amountPost;
	}
	public String getChargingCodeName() {
		return chargingCodeName;
	}
	public void setChargingCodeName(String chargingCodeName) {
		this.chargingCodeName = chargingCodeName;
	}
	public long getTariffPre() {
		return tariffPre;
	}
	public void setTariffPre(long tariffPre) {
		this.tariffPre = tariffPre;
	}
	public long getTariffPost() {
		return tariffPost;
	}
	public void setTariffPost(long tariffPost) {
		this.tariffPost = tariffPost;
	}
	
}
