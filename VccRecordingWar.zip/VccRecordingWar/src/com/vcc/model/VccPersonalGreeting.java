package com.vcc.model;

import java.io.Serializable;

public class VccPersonalGreeting implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String msisdn;
	private String filePath;
	private int greetType;
	private int recordingTime;
	
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public int getGreetType() {
		return greetType;
	}
	public void setGreetType(int greetType) {
		this.greetType = greetType;
	}
	public int getRecordingTime() {
		return recordingTime;
	}
	public void setRecordingTime(int recordingTime) {
		this.recordingTime = recordingTime;
	}
	
	
	
}
