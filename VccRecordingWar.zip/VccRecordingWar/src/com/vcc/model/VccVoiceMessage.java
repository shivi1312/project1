package com.vcc.model;


@SuppressWarnings("serial")
public class VccVoiceMessage implements java.io.Serializable {

	private String messageStatus;
	private String originattingNumber;
	private String desticationNumber;
	private String callTime;
	private String fileName;
	private int voiceMessageIndex=0;
	private String fileSize;
	private int recordingTime;
	private String msgProtect;
	private String msgPriority;
	private String passProtected;
	private String password;
	private String orginalNumber;
	private int localMessageIndex;
	private String sendingTime;
	private String serviceType;
	private int count;
	private boolean notificationSend = true;

	
	
	public boolean getNotificationSend() {
		return notificationSend;
	}

	public void setNotificationSend(boolean notificationSend) {
		this.notificationSend = notificationSend;
	}

	public String getMessageStatus() {
		return messageStatus;
	}

	public void setMessageStatus(String messageStatus) {
		this.messageStatus = messageStatus;
	}


	public String getOriginattingNumber() {
		return originattingNumber;
	}

	public void setOriginattingNumber(String originattingNumber) {
		this.originattingNumber = originattingNumber;
	}

	public String getDesticationNumber() {
		return desticationNumber;
	}

	public void setDesticationNumber(String desticationNumber) {
		this.desticationNumber = desticationNumber;
	}

	public String getCallTime() {
		return callTime;
	}

	public void setCallTime(String callTime) {
		this.callTime = callTime;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getVoiceMessageIndex() {
		return voiceMessageIndex;
	}

	public void setVoiceMessageIndex(int voiceMessageIndex) {
		this.voiceMessageIndex = voiceMessageIndex;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

	public int getRecordingTime() {
		return recordingTime;
	}

	public void setRecordingTime(int recordingTime) {
		this.recordingTime = recordingTime;
	}

	public String getMsgProtect() {
		return msgProtect;
	}

	public void setMsgProtect(String msgProtect) {
		this.msgProtect = msgProtect;
	}

	public String getMsgPriority() {
		return msgPriority;
	}

	public void setMsgPriority(String msgPriority) {
		this.msgPriority = msgPriority;
	}

	public String getPassProtected() {
		return passProtected;
	}

	public void setPassProtected(String passProtected) {
		this.passProtected = passProtected;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOrginalNumber() {
		return orginalNumber;
	}

	public void setOrginalNumber(String orginalNumber) {
		this.orginalNumber = orginalNumber;
	}

	public int getLocalMessageIndex() {
		return localMessageIndex;
	}

	public void setLocalMessageIndex(int localMessageIndex) {
		this.localMessageIndex = localMessageIndex;
	}

	public String getSendingTime() {
		return sendingTime;
	}

	public void setSendingTime(String sendingTime) {
		this.sendingTime = sendingTime;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

}
