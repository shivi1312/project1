package com.vcc.model;

public class MessageStatus {

	private int msgRead=0;
	private int msgDel=0;
	private int msgMove=0;
	private int msgCopy=0;
	private int msgSave=0;
	private int msgRecord=0;
	private int grtAdd=0;
	private int grtDel=0;
	private int frndAdd=0;
	private int frndDel=0;
	private int dial=0;
	private int editPass=0;
	private int recorded=0;
	private int langChange=0;
	public int getMsgRead() {
		return msgRead;
	}
	public void setMsgRead(int msgRead) {
		this.msgRead = msgRead;
	}
	public int getMsgDel() {
		return msgDel;
	}
	public void setMsgDel(int msgDel) {
		this.msgDel = msgDel;
	}
	public int getMsgMove() {
		return msgMove;
	}
	public void setMsgMove(int msgMove) {
		this.msgMove = msgMove;
	}
	public int getMsgCopy() {
		return msgCopy;
	}
	public void setMsgCopy(int msgCopy) {
		this.msgCopy = msgCopy;
	}
	public int getMsgSave() {
		return msgSave;
	}
	public void setMsgSave(int msgSave) {
		this.msgSave = msgSave;
	}
	public int getMsgRecord() {
		return msgRecord;
	}
	public void setMsgRecord(int msgRecord) {
		this.msgRecord = msgRecord;
	}
	public int getGrtAdd() {
		return grtAdd;
	}
	public void setGrtAdd(int grtAdd) {
		this.grtAdd = grtAdd;
	}
	public int getGrtDel() {
		return grtDel;
	}
	public void setGrtDel(int grtDel) {
		this.grtDel = grtDel;
	}
	public int getFrndAdd() {
		return frndAdd;
	}
	public void setFrndAdd(int frndAdd) {
		this.frndAdd = frndAdd;
	}
	public int getFrndDel() {
		return frndDel;
	}
	public void setFrndDel(int frndDel) {
		this.frndDel = frndDel;
	}
	public int getDial() {
		return dial;
	}
	public void setDial(int dial) {
		this.dial = dial;
	}
	public int getEditPass() {
		return editPass;
	}
	public void setEditPass(int editPass) {
		this.editPass = editPass;
	}
	public int getRecorded() {
		return recorded;
	}
	public void setRecorded(int recorded) {
		this.recorded = recorded;
	}
	public int getLangChange() {
		return langChange;
	}
	public void setLangChange(int langChange) {
		this.langChange = langChange;
	}
	
}
