package com.vcc.model;

public class VccServiceProvider implements java.io.Serializable {
	
	private static final long serialVersionUID = -6879603910037049687L;
	private int serviceId;
	private String serviceOffer;
	private String subscription;
	private int priority;
	private String notification;
	private String serviceDefined;

	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public String getServiceOffer() {
		return serviceOffer;
	}

	public void setServiceOffer(String serviceOffer) {
		this.serviceOffer = serviceOffer;
	}

	public String getSubscription() {
		return subscription;
	}

	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getNotification() {
		return notification;
	}

	public void setNotification(String notification) {
		this.notification = notification;
	}

	public String getServiceDefined() {
		return serviceDefined;
	}

	public void setServiceDefined(String serviceDefined) {
		this.serviceDefined = serviceDefined;
	}

}
