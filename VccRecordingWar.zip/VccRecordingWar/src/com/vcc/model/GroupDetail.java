package com.vcc.model;

import java.util.List;

public class GroupDetail {
	
	private String callingNum;
	private List<String> frndList;
	private int groupId;
	private String fileName;
	private String serviceType;
	public String getCallingNum() {
		return callingNum;
	}
	public void setCallingNum(String callingNum) {
		this.callingNum = callingNum;
	}
	public List<String> getFrndList() {
		return frndList;
	}
	public void setFrndList(List<String> frndList) {
		this.frndList = frndList;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	
}
