package com.vcc.model;

/*
 * Use to store and retrieve user call details for vcc
 * This model is mapped to the vcc_fwd_call_logs table 
 * */
public class VccFwdCallLogs implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	/* By default store serverId which is used in case of call record */
	/* mapped to freeswitch server ip */
	private int  serverId;
	/* store user callUUid which unique for each user */
	/* mapped to callId */
	private String callId;
	/* used to retrieve a party msisdn number */
	/* mapped to originatingNumber */
	private String  originatingNumber;
	/* used to retrieve b party msisdn number*/
	/* mapped to destinationNumber */
	private String destinationNumber;
	/* store user circuit id of call */
	/* mapped to circuitId */
	private int circuitId;
	/* store user call forward reason code which is coming from msc */
	/* mapped to iamCauseCode */
	private String iamCauseCode;
	/* store user hangup reason code which is coming from freeswitch */
	/* mapped to relCauseCode */
	private String relCauseCode;
	/* store user voice mail length */
	/* mapped to msgLength */
	private int msgLength;
	/* store user voice msg index which is derived from vcc_voice_msg table */
	/* mapped to voiceMsgIndex */
	private int voiceMsgIndex;
	/* store user call active time */
	/* mapped to callTime */
	private String callTime;
	/* store user call total duration */
	/* mapped to callDuration */
	private int callDuration;
	/* store user answered */
	/* mapped to answered */
	private int answered;		
	/* service type used by user->0001->voice mail,0011->notify me,voice mail */
	/* mapped to service_type */
	private String serviceType;
	/* hold user type ex->postpaid,prepaid */
	/* mapped to sub_type */
	private String subType;
	/*store subscriber rate plan */
	/* mapped to ratePlan */
	private int ratePlan;
	
	/*store record file name */
	/* mapped to fileName */
	private String fileName;
	
	
		
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public int getServerId() {
		return serverId;
	}
	public void setServerId(int serverId) {
		this.serverId = serverId;
	}
	public String getCallId() {
		return callId;
	}
	public void setCallId(String callId) {
		this.callId = callId;
	}
	public String getOriginatingNumber() {
		return originatingNumber;
	}
	public void setOriginatingNumber(String originatingNumber) {
		this.originatingNumber = originatingNumber;
	}
	public String getDestinationNumber() {
		return destinationNumber;
	}
	public void setDestinationNumber(String destinationNumber) {
		this.destinationNumber = destinationNumber;
	}
	public int getCircuitId() {
		return circuitId;
	}
	public void setCircuitId(int circuitId) {
		this.circuitId = circuitId;
	}
	public String getIamCauseCode() {
		return iamCauseCode;
	}
	public void setIamCauseCode(String iamCauseCode) {
		this.iamCauseCode = iamCauseCode;
	}
	public String getRelCauseCode() {
		return relCauseCode;
	}
	public void setRelCauseCode(String relCauseCode) {
		this.relCauseCode = relCauseCode;
	}
	public int getMsgLength() {
		return msgLength;
	}
	public void setMsgLength(int msgLength) {
		this.msgLength = msgLength;
	}
	public int getVoiceMsgIndex() {
		return voiceMsgIndex;
	}
	public void setVoiceMsgIndex(int voiceMsgIndex) {
		this.voiceMsgIndex = voiceMsgIndex;
	}
	public String getCallTime() {
		return callTime;
	}
	public void setCallTime(String callTime) {
		this.callTime = callTime;
	}
	public int getCallDuration() {
		return callDuration;
	}
	public void setCallDuration(int callDuration) {
		this.callDuration = callDuration;
	}
	public int getAnswered() {
		return answered;
	}
	public void setAnswered(int answered) {
		this.answered = answered;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public int getRatePlan() {
		return ratePlan;
	}
	public void setRatePlan(int ratePlan) {
		this.ratePlan = ratePlan;
	}
	

	

}
