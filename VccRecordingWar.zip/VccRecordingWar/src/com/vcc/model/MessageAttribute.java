package com.vcc.model;

public class MessageAttribute {

	private String fileName;
	private String msgPath;
	private String senderNum;
	private String greetingMsg;
	private String msgStatus;
	private int voiceMsgIndex;
	private String originalNum;
	private int recordingDuration;
	private String serviceType;
	private String sendingTime;
	
	public String getMsgPath() {
		return msgPath;
	}
	public void setMsgPath(String msgPath) {
		this.msgPath = msgPath;
	}
	public String getSenderNum() {
		return senderNum;
	}
	public void setSenderNum(String senderNum) {
		this.senderNum = senderNum;
	}
	public String getGreetingMsg() {
		return greetingMsg;
	}
	public void setGreetingMsg(String greetingMsg) {
		this.greetingMsg = greetingMsg;
	}
	public String getMsgStatus() {
		return msgStatus;
	}
	public void setMsgStatus(String msgStatus) {
		this.msgStatus = msgStatus;
	}
	public int getVoiceMsgIndex() {
		return voiceMsgIndex;
	}
	public void setVoiceMsgIndex(int voiceMsgIndex) {
		this.voiceMsgIndex = voiceMsgIndex;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getOriginalNum() {
		return originalNum;
	}
	public void setOriginalNum(String originalNum) {
		this.originalNum = originalNum;
	}
	public int getRecordingDuration() {
		return recordingDuration;
	}
	public void setRecordingDuration(int recordingDuration) {
		this.recordingDuration = recordingDuration;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getSendingTime() {
		return sendingTime;
	}
	public void setSendingTime(String sendingTime) {
		this.sendingTime = sendingTime;
	}
	

}
