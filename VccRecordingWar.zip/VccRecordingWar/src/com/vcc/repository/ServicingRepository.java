package com.vcc.repository;

import java.util.List;

import org.apache.log4j.Logger;

import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.factory.ServicingFactory;
import com.vcc.model.VccServiceProvider;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.services.McaServicing;
import com.vcc.services.Servicing;
import com.vcc.services.VoiceMailServicing;
import com.vcc.services.VoiceNoteServicing;

public class ServicingRepository {

	final static Logger logger = Logger.getLogger(ServicingRepository.class);
	private List<VccServiceProvider> serviceList;
	private List<VccSubscriptionMaster> activeServiceList;
	private ServicingFactory backerFactory;
	private ProfileRequest profileRequest;

	public ServicingRepository(ProfileRequest profileRequest, ProfileResponse vmResponse, VmError vmError,
			VccServices vccServices, List<VccServiceProvider> serviceList2,
			List<VccSubscriptionMaster> activeServiceList2) {
		this.profileRequest = profileRequest;
		this.serviceList = serviceList2;
		this.activeServiceList = activeServiceList2;
		backerFactory = new ServicingFactory(profileRequest, vmResponse, vmError, vccServices, activeServiceList,
				serviceList,activeServiceList2);
	}
	
	/**
	 * return Servicing if calledNum not a subscriber than it return default
	 * ServiceType object
	 * 
	 * @return Servicing this return three type of
	 *         object(VoiceNoteServicing,VoiceMailServicing,McaServicing)
	 *         according to calledNum profile
	 * @see nothing
	 */
	public Servicing getDefaultBacker() {
		for (VccServiceProvider provider : this.serviceList) {
			if (this.profileRequest.getServiceType() != null && this.profileRequest.getServiceType()
					.equalsIgnoreCase(AppConfig.config.getString("VN", "0100"))) {
				logger.info(String.format("A-Party [%s] B-Party [%s] default service [%s]",
						profileRequest.getCallingNum(), profileRequest.getCalledNum(),
						AppConfig.config.getString("1_service_name", "Voice Note")));
				return new VoiceNoteServicing(provider, null, this.activeServiceList);
			} else if (this.profileRequest.getServiceType() != null && this.profileRequest.getServiceType()
					.equalsIgnoreCase(AppConfig.config.getString("VM", "0010"))) {
				logger.info(String.format("A-Party [%s] B-Party [%s] default service [%s]",
						profileRequest.getCallingNum(), profileRequest.getCalledNum(),
						AppConfig.config.getString("1_service_name", "Voice Mail")));
				return new VoiceMailServicing(provider, null, this.activeServiceList);
			} else if (this.profileRequest.getServiceType() != null && this.profileRequest.getServiceType()
					.equalsIgnoreCase(AppConfig.config.getString("MCA", "0001"))) {
				logger.info(
						String.format("A-Party [%s] B-Party [%s] default service [%s]", profileRequest.getCallingNum(),
								profileRequest.getCalledNum(), AppConfig.config.getString("1_service_name", "Mca")));
				return new McaServicing(provider, null, this.activeServiceList);
			} else if ((provider.getSubscription().equals("N") || provider.getSubscription().equals("D"))
					&& (provider.getServiceOffer().equals("VN"))) {
				logger.info(String.format("A-Party [%s] B-Party [%s] default service [%s]",
						profileRequest.getCallingNum(), profileRequest.getCalledNum(),
						AppConfig.config.getString("1_service_name", "Voice Note")));
				return new VoiceNoteServicing(provider, null, this.activeServiceList);
			} else if ((provider.getSubscription().equals("N") || provider.getSubscription().equals("D"))
					&& (provider.getServiceOffer().equals("VM"))) {
				logger.info(String.format("A-Party [%s] B-Party [%s] default service [%s]",
						profileRequest.getCallingNum(), profileRequest.getCalledNum(),
						AppConfig.config.getString("1_service_name", "Voice Mail")));
				return new VoiceMailServicing(provider, null, this.activeServiceList);
			} else if ((provider.getSubscription().equals("N") || provider.getSubscription().equals("D"))
					&& (provider.getServiceOffer().equals("MCA"))) {
				logger.info(
						String.format("A-Party [%s] B-Party [%s] default service [%s]", profileRequest.getCallingNum(),
								profileRequest.getCalledNum(), AppConfig.config.getString("1_service_name", "Mca")));
				return new McaServicing(provider, null, this.activeServiceList);
			} else {
				logger.info(String.format("A-Party [%s] B-Party [%s] default service [%s]",
						profileRequest.getCallingNum(), profileRequest.getCalledNum(),
						AppConfig.config.getString("1_service_name", "Voice Note")));
				return new VoiceNoteServicing(provider, null, this.activeServiceList);
			}
		}
		return null;
	}

	public Informer getInformer() {
		return new BackerInformer();
	}

	private class BackerInformer implements Informer {

		private int index;

		@Override
		public boolean hasNext() {
			if (index < serviceList.size()) {
				return true;
			}
			return false;
		}

		@Override
		public Object next() {
			if (this.hasNext()) {
				return backerFactory.getBackerType(serviceList.get(index++));
			}
			return null;
		}

	}

}
