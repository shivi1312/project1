package com.vcc.repository;

public interface Informer {
	public boolean hasNext();
	public Object next();
}
