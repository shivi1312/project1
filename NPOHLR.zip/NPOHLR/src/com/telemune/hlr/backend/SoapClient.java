package com.telemune.hlr.backend;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.w3c.dom.Document;

//import com.telemune.hlr.server.ServiceProviderLocator;
//import com.telemune.hlr.server.ServiceProviderPortType;

public class SoapClient {
	
	final private Logger logger = Logger.getLogger(SoapClient.class);
private int timeout=10;

    public SoapClient() {
    	try
    	{
this.timeout=Config.connectionTimeOut;
    	}
    	catch(Exception exp)
    	{
    		exp.printStackTrace();
    	}
	        	
	}
	
    public String getSubType(DataObject dataObject)
    {
    	String subType = "NA";
    	int result = -1;
		try
    	{
			result=1; // We are considering all msisdn as Prepaid at this site
			logger.info("msisdn["+dataObject.getMsisdn()+"] We are considering all msisdn as Prepaid at this site... subType is["+subType+"]");
			if(result == 1){ subType="P";
			dataObject.setIsPrePaidId("Y");
			dataObject.setResponse("0");
			}
			else { subType="O";
			dataObject.setIsPrePaidId("N");
			dataObject.setResponse("0");
			}
			System.out.println("msisdn["+dataObject.getMsisdn()+"] subType is["+subType+"]");
			return subType;
		
    	}
    	catch(Exception exp)
    	{
    		exp.printStackTrace();
    	}
    	return null;
    }
    
    public int upFlag(DataObject dataObject, String reqFlag)
    {
    	String upFlag = "NA";
		int result = -1;
		String provisioningJson=null;
		String responseJson=null;
		DocumentBuilderFactory dbFactory = null;
		DocumentBuilder dBuilder = null;
		Document doc = null;
		String returnCode=null;
		String returnDescription=null;
		
    	try
    	{
    		provisioningJson = getProvisioningdeprovisioningJson(dataObject.getMsisdn(),dataObject.getReqType(), reqFlag);
    		if ((!provisioningJson.equalsIgnoreCase("NA")) && (!"".equalsIgnoreCase(provisioningJson))) {
				logger.info("##>>msisdn["+dataObject.getMsisdn()+"] provisioningJson["+provisioningJson+"]");
				responseJson=sendPost(provisioningJson, "Provisioning", dataObject.getMsisdn());
			}
    		
    		// Added by Sanchit Atri
    		if ((responseJson!=null) && !("".equalsIgnoreCase(responseJson))) {
    			logger.info("\n\n###>>> msisdn["+dataObject.getMsisdn()+"] Provisioning Response: ["+responseJson+"]\n\n");
    			JSONObject jaob = new JSONObject(responseJson);

   		     returnDescription=jaob.getString("msg");
   		     returnCode=jaob.getString("processStatus");
   		     if (returnCode.equalsIgnoreCase("COMPLETED") && returnDescription.contains("SUCCESS")) {
   					result=1; // success case
   					logger.info("\n###>>> msisdn:["+dataObject.getMsisdn()+"] Provisioning Response: RetCode ["+returnCode+"]"
   							+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] Provisioning Response: RetDesc ["+returnDescription+"]");
   				} else {
   					result=-1; // fail case
   					logger.error("\n###>>> msisdn:["+dataObject.getMsisdn()+"] Provisioning Response: RetCode ["+returnCode+"]"
   							+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] Provisioning Response: RetDesc ["+returnDescription+"]");
   				}
   		     logger.info("result=="+result);
    		}
    		
    		if(result == 1){ upFlag="UP";
//			dataObject.setResponse("0");
			}
			else { upFlag="NOT UP"; 
//			dataObject.setResponse("-1");
			
			}
    		logger.info("msisdn["+dataObject.getMsisdn()+"] UpFlag status is["+upFlag+"]");
			System.out.println("msisdn["+dataObject.getMsisdn()+"] UpFlag status is["+upFlag+"]");
			return result;
    	}
    	catch(Exception exp)
    	{
    		logger.error(">>>msisdn:["+dataObject.getMsisdn()+"] Exception in upFlag method... ",exp);
			System.err.println(">>>msisdn:["+dataObject.getMsisdn()+"] Exception in upFlag method... "+exp);
		    exp.printStackTrace();
    	} finally {
			if (dbFactory!=null) {dbFactory=null;}
			if (dBuilder!=null) {dBuilder=null;}
			if (doc!=null) {doc=null;}
		}
    	
    	return result;
    }
    
    public int downFlag(DataObject dataObject, String reqFlag)
    {
    	String downFlag = "NA";
		int result = -1;
		String deprovisioningJson=null;
		String responseJson=null;
		String returnCode=null;
		String returnDescription=null;
		
    	try
    	{
    		deprovisioningJson = getProvisioningdeprovisioningJson(dataObject.getMsisdn(),dataObject.getReqType(),reqFlag);
    		if ((!deprovisioningJson.equalsIgnoreCase("NA")) && (!"".equalsIgnoreCase(deprovisioningJson))) {
				logger.info("##>>msisdn["+dataObject.getMsisdn()+"] deprovisioningJson["+deprovisioningJson+"]");
				responseJson=sendPost(deprovisioningJson, "Deprovisioning", dataObject.getMsisdn());
				
				
			}
    		// Added by Sanchit Atri
    		if ((responseJson!=null) && !("".equalsIgnoreCase(responseJson))) {
    			logger.info("\n\n###>>> msisdn["+dataObject.getMsisdn()+"] Deprovisioning Response: ["+responseJson+"]\n\n");
    			JSONObject jaob = new JSONObject(responseJson);

    			returnDescription=jaob.getString("msg");
      		     returnCode=jaob.getString("processStatus");
       		     if (returnCode.equalsIgnoreCase("COMPLETED") && returnDescription.contains("SUCCESS")) {
   					result=1; // success case
   					logger.info("\n###>>> msisdn:["+dataObject.getMsisdn()+"] Deprovisioning Response: RetCode ["+returnCode+"]"
   							+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] Deprovisioning Response: RetDesc ["+returnDescription+"]");
   				} else {
   					result=-1; // fail case
   					logger.error("\n###>>> msisdn:["+dataObject.getMsisdn()+"] Deprovisioning Response: RetCode ["+returnCode+"]"
   							+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] Deprovisioning Response: RetDesc ["+returnDescription+"]");
   				}
   		     logger.info("result=="+result);
    		}
    		
    		if(result == 1){ downFlag="DOWN";
			//dataObject.setResponse("0");
			}
			else { downFlag="NOT DOWN";
			//dataObject.setResponse("-1");
			}
    		logger.info("msisdn["+dataObject.getMsisdn()+"] downFlag status is["+downFlag+"]");
			System.out.println("msisdn["+dataObject.getMsisdn()+"] downFlag status is["+downFlag+"]");
			return result;
    	}
    	catch(Exception exp)
    	{
    		logger.error(">>>msisdn:["+dataObject.getMsisdn()+"] Exception in downFlag method... ",exp);
			System.err.println(">>>msisdn:["+dataObject.getMsisdn()+"] Exception in downFlag method... "+exp);
		    exp.printStackTrace();
    	}
    	return result;
    }
    
 // Updated by Sanchit Atri
    private String sendPost(String postJsonData, String req, String msisdn)  {
    logger.info("inside sendPost    JsonString ====="+postJsonData+"     req========"+req+"    msisdn==="+msisdn);

      StringBuffer response=response = new StringBuffer();;
      String url =Config.HLR_SOAP_URL;
      String apiClient=Config.API_CLIENT;
      String serviceId=Config.SERVICE_ID;
	
	  URL obj;
	  try {
			obj = new URL(url);
			
		  HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		  con.setRequestMethod("POST");
		  //con.setRequestProperty("User-Agent", USER_AGENT);
		  con.setRequestProperty("X-Api-Client", apiClient);
		  con.setRequestProperty("x-service-id", serviceId);
		  con.setRequestProperty("x-app-version", "1.0.0");
		  con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
		  con.setRequestProperty("Content-Type","application/json");
		 
		  con.setDoOutput(true);
		  DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		  wr.writeBytes(postJsonData);
		  wr.flush();
		  wr.close();
		 
		  int responseCode = con.getResponseCode();
			logger.info("\n>>>msisdn[" + msisdn + "]  Sending 'POST' " + req + " request to URL :[" + url + "]\n");
		  logger.info(">>>msisdn[" + msisdn + "] " + req + " post hit returnCode:[" + responseCode + "]");
		 
		  BufferedReader in = new BufferedReader(
		          new InputStreamReader(con.getInputStream()));
		  String output;
		  
		 
		  while ((output = in.readLine()) != null) {
		   response.append(output);
		  }
		  in.close();
		  logger.debug(">>>msisdn[" + msisdn + "] " + req + " post hit response:[" + response.toString() + "]");
	} catch (Exception e) {
		logger.error(">>>msisdn["+msisdn+"] Exception in sendPost method at " + req + " request... ",e);
	    e.printStackTrace();
	}
	  
	  return response.toString();
 }
 
    private String getMsisdnWithoutCountryCode(String msisdn)
    {
    	int msisdnLength=Integer.parseInt(Config.MSISDN_LENGTH);
    	if(msisdn.length()>msisdnLength)
    	{
    		msisdn=msisdn.substring(3);
    	}
    	logger.info("MSISDN without country code <<<<<<<<<>>>>>>>>>"+msisdn);
    	return msisdn;
    }
    
    private String getProvisioningdeprovisioningJson(String msisdn, int reqType,String reqFlag) {
    	logger.info("###>>> msisdn["+msisdn+"] Inside getProvisioningdeprovisioningJson method...");
    	String xml="";
    	String localMsisdnString=getMsisdnWithoutCountryCode(msisdn);
    	try {
    		//generateSerialNumber(msisdn);
    		
    		if (reqType==3) {
				logger.info("###>>> msisdn["+localMsisdnString+"] Generating Provisioning Xml, reqType["+reqType+"]");
				
			xml  = "{\r\n"
			  		+ "  \"processName\": \"MCA_PROVISIONING\",\r\n"
			  		+ "  \"inputParameters\": {\r\n"
			  		+ "      \"msisdn\":\""+localMsisdnString+"\",\r\n"
			  		+ "      "+reqFlag+""
			  		+ "      \"FTN\": \""+Config.FTN_NUMBER+"\"\r\n"
			  		+ "  }\r\n"
			  		+ "}";
			
			} else if(reqType==4){
				logger.info("###>>> msisdn["+localMsisdnString+"] Generating Deprovisioning Xml, reqType["+reqType+"]");
				
				xml  = "{\r\n"
				  		+ "  \"processName\": \"MCA_DE_PROVISIONING\",\r\n"
				  		+ "  \"inputParameters\": {\r\n"
				  		+ "      \"msisdn\":\""+localMsisdnString+"\",\r\n"
				  		+ "      "+reqFlag+""
				  		+ "      \"FTN\": \""+Config.FTN_NUMBER+"\"\r\n"
				  		+ "  }\r\n"
				  		+ "}";
				
				
			} else {
				logger.error("###>>> msisdn["+localMsisdnString+"] Wrong ReqType for Generating Deprovisioning Xml, reqType["+reqType+"]");
			}
			
		} catch (Exception e) {
			logger.error(">>>msisdn["+localMsisdnString+"] Exception in getprovisioningJson method... ",e);
			System.err.println(">>>msisdn["+localMsisdnString+"] Exception in getprovisioningJson method... "+e);
		    e.printStackTrace();
		}
    	return xml;
    }
    
	/*
	 * public String generateSerialNumber(String msisdn){ String serial=""; Date
	 * date = null; DateFormat sdf = null; String stringDate = null; try { date =
	 * new Date(); sdf = new SimpleDateFormat("yyyyMMdd.HHmmss.SSS"); stringDate =
	 * sdf.format(date); serial = Config.SERIAL_FORMAT.concat(stringDate);
	 * logger.info("###>>> msisdn["+msisdn+"] Serial Id Generated for Request["
	 * +serial+"]"); } catch (Exception e) { logger.error(">>>msisdn["+
	 * msisdn+"] Exception in generateSerialNumber method... ",e);
	 * e.printStackTrace(); } finally { if (date!=null) { date=null; } if
	 * (sdf!=null) { sdf=null; } if (stringDate!=null) { stringDate=null; } } return
	 * serial; }
	 */
    
    public static void main(String arg[])
    {
    	new SoapClient();
    	DataObject dataObject = new DataObject();
    	dataObject.setMsisdn("1");
    	//sop.upFlag(dataObject);
    	System.out.println("respose["+dataObject.getResponse()+"]");
    }
}
