package com.telemune.hlr.backend;

import org.apache.log4j.Logger;

public class SoapRequestHandler implements HlrInterface{

	final private Logger logger = Logger.getLogger(SoapRequestHandler.class);
	SoapClient client = null;
	public long objectNo ;
	
	public SoapRequestHandler(long i) {
		logger.info("Inside SoapRequestHandler Object no "+i+" created");
		client = new SoapClient();
		this.objectNo = i;
	}
	
	
	public int doProcessing(DataObject dataObject) {
		int responseCFNRY = -1;
		int responseCFB = -1;
		int responseCFNRC = -1;
		int responseCFU = -1;
		int result=-1;
		try
		{
		logger.info("##>isnide doProcessing in SoapRequestHandler request is ["+dataObject+"]");	
		if (Config.TESTING==1) {
			logger.info("\n\n\t\t**************Testing is Enabled***************\n\n");
			if ("SuccessTesting".equalsIgnoreCase(Config.TESTING_STRING)) {
				logger.info("Yes, TESTING_STRING contains the required String... TESTING_STRING ["+Config.TESTING_STRING+"]");
				if (dataObject.getReqType()==6) {
					dataObject.setIsPrePaidId("Y"); // In testing all msisdn is considered as Prepaid
					dataObject.setResponse("0");	
					logger.info(">>>>>"+dataObject.getMsisdn()+" is PrePaid");
					logger.debug("\n\tIn testing all msisdn considered as Prepaid");
				}
				else if (dataObject.getReqType()==3) {
					dataObject.setIsPrePaidId("Y"); // In testing all msisdn is considered as Prepaid
					dataObject.setResponse("0");
					logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Up Success");
				}
				else if (dataObject.getReqType()==4) {
					dataObject.setIsPrePaidId("Y"); // In testing all msisdn is considered as Prepaid
					dataObject.setResponse("0");
					logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Down Success");
				}
			} else {
				logger.info("No, TESTING_STRING doesn't contain the required String... TESTING_STRING ["+Config.TESTING_STRING+"]");
				if (dataObject.getReqType()==6) {
					dataObject.setResponse("-1");	
					logger.info(">>>>>"+dataObject.getMsisdn()+" subType NOT FOUND");
				}
				else if (dataObject.getReqType()==3) {
					dataObject.setResponse("-1");
					logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Up FAILURE");
				}
				else if (dataObject.getReqType()==4) {
					dataObject.setResponse("-1");
					logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Down FAILURE");
				}
			}
		}else {
			if(dataObject.getReqType() == 6)
			{
				client.getSubType(dataObject);
			}
			else if(dataObject.getReqType() == 3)
			{
				String flagsString="";
				if (Config.VCC_CFNRC_ENABLE==1) {
					flagsString="\"CFNRC\":1,\r\n";
					//responseCFNRC = client.upFlag(dataObject, "CFNRC:1");
				}
				
				if (Config.VCC_CFNRY_ENABLE==1) {
					flagsString=flagsString+"\"CFNRY\":1,\r\n";
					//responseCFNRY = client.upFlag(dataObject, "CFNRY");
				}
				
				if (Config.VCC_CFB_ENABLE==1) {
					//responseCFB = client.upFlag(dataObject, "CFB");
					flagsString=flagsString+"\"CFB\":1,\r\n";
				}
				
				
				  if (Config.VCC_CFU_ENABLE==1) { 
					  flagsString=flagsString+"\"CFU\":1,\r\n";
					  //responseCFU = client.upFlag(dataObject,"CFU"); 
					  }
				  responseCFNRC = client.upFlag(dataObject, flagsString);
				  
				logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] flag["+flagsString+"]"
						+ "VCC_CFNRY_ENABLE["+Config.VCC_CFNRY_ENABLE+"] Flag Up responseCFNRY["+result+"] "
						+ "VCC_CFB_ENABLE["+Config.VCC_CFB_ENABLE+"] Flag Up responseCFB["+result+"] "
						+ "VCC_CFNRC_ENABLE["+Config.VCC_CFNRC_ENABLE+"] Flag Up responseCFNRC["+result+"] "
						+ "VCC_CFU_ENABLE["+Config.VCC_CFU_ENABLE+"] Flag Up responseCFU["+result+"]");
				
			
				
				if (responseCFNRC == 1) {
					result = 1;
				}
				
				if(result == 1){ 
				dataObject.setResponse("0");
				}
				else { 
				dataObject.setResponse("-1");
				
				}
			}
			else if(dataObject.getReqType() == 4)
			{
				
				String flagsString="";
				if (Config.VCC_CFNRC_ENABLE==1) {
					flagsString="\"CFNRC\":0,\r\n";
					//responseCFNRC = client.upFlag(dataObject, "CFNRC:1");
				}
				
				if (Config.VCC_CFNRY_ENABLE==1) {
					flagsString=flagsString+"\"CFNRY\":0,\r\n";
					//responseCFNRY = client.upFlag(dataObject, "CFNRY");
				}
				
				if (Config.VCC_CFB_ENABLE==1) {
					//responseCFB = client.upFlag(dataObject, "CFB");
					flagsString=flagsString+"\"CFB\":0,\r\n";
				}
				
				
				  if (Config.VCC_CFU_ENABLE==1) { 
					  flagsString=flagsString+"\"CFU\":0,\r\n";
					  //responseCFU = client.upFlag(dataObject,"CFU"); 
					  }
				  result = client.downFlag(dataObject, flagsString);
				
				
				logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] flag["+flagsString+"]"
						+ "VCC_CFNRY_ENABLE["+Config.VCC_CFNRY_ENABLE+"] Flag Up responseCFNRY["+result+"] "
						+ "VCC_CFB_ENABLE["+Config.VCC_CFB_ENABLE+"] Flag Up responseCFB["+result+"] "
						+ "VCC_CFNRC_ENABLE["+Config.VCC_CFNRC_ENABLE+"] Flag Up responseCFNRC["+result+"] "
						+ "VCC_CFU_ENABLE["+Config.VCC_CFU_ENABLE+"] Flag Up responseCFU["+result+"]");
				
				

				if(result == 1){ 
				dataObject.setResponse("0");
				}
				else { 
				dataObject.setResponse("-1");
				
				}
			}
			logger.info("##>inside doProcessing in SoapRequestHandler Response is ["+dataObject+"]");	
			return 1;
		}

		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		return -1;
	}
		
	public boolean keepAlive() {
		 
		return false; //not requied in Soap
	}
	public boolean isConnected() {
		return false; //not required in Soap
	}


	public long getObjectNo() {
		// TODO Auto-generated method stub
		return objectNo;
	}
}
