package com.redhat.JpaDemo;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.FlushModeType;
import javax.persistence.LockModeType;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.metamodel.Metamodel;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        // It is use to create the object of EntityManager
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu"); // pu is persistence-unit name in persistence.xml file
        EntityManager em= emf.createEntityManager();
        
        User u  = new User();
        u.setName("abhi");
        u.setRole_id(2);
        em.getTransaction().begin();  // use before to do changes in db
        em.persist(u);
        em.getTransaction().commit();// use to commit the change in db 
       // User u = em.find(User.class, 102);
        
        System.out.println(u);

    }
}
