package com.vcc.updatebean;

public class DataHeader {

	private OrderItem OrderItem;
	private AdditionalInfo AdditionalInfo;
	public OrderItem getOrderItem() {
		return OrderItem;
	}
	public void setOrderItem(OrderItem orderItem) {
		OrderItem = orderItem;
	}
	public AdditionalInfo getAdditionalInfo() {
		return AdditionalInfo;
	}
	public void setAdditionalInfo(AdditionalInfo additionalInfo) {
		AdditionalInfo = additionalInfo;
	}	 
}
