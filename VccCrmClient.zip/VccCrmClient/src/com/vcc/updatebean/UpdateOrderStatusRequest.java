package com.vcc.updatebean;

public class UpdateOrderStatusRequest {

	private ApplicationHeader ApplicationHeader;
	private DataHeader DataHeader;
	public ApplicationHeader getApplicationHeader() {
		return ApplicationHeader;
	}
	public void setApplicationHeader(ApplicationHeader applicationHeader) {
		ApplicationHeader = applicationHeader;
	}
	public DataHeader getDataHeader() {
		return DataHeader;
	}
	public void setDataHeader(DataHeader dataHeader) {
		DataHeader = dataHeader;
	}
	
}
