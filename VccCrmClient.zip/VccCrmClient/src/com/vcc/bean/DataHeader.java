package com.vcc.bean;

public class DataHeader {

	private String Channel;
	private String SubChannel;
	private String Language;
	private String recieved_time;
	public String getChannel() {
		return Channel;
	}
	public void setChannel(String channel) {
		Channel = channel;
	}
	public String getSubChannel() {
		return SubChannel;
	}
	public void setSubChannel(String subChannel) {
		SubChannel = subChannel;
	}
	public String getLanguage() {
		return Language;
	}
	public void setLanguage(String language) {
		Language = language;
	}
	public String getRecieved_time() {
		return recieved_time;
	}
	public void setRecieved_time(String recieved_time) {
		this.recieved_time = recieved_time;
	}
	
	
	
}
