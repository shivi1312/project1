package com.vcc.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ApplicationHeader {
	private static final long serialVersionUID = 1L;
	
	
	
	private String RequestedSystem;
	
	private String RetryLimit;
	
	private String RequestedDate;
	
	private String TransactionID;

	public String getRequestedSystem() {
		return RequestedSystem;
	}


	public void setRequestedSystem(String RequestedSystem) {
		this.RequestedSystem = RequestedSystem;
	}


	public String getRetryLimit() {
		return this.RetryLimit;
	}


	public void setRetryLimit(String RetryLimit) {
		this.RetryLimit = RetryLimit;
	}


	public String getRequestedDate() {
		return this.RequestedDate;
	}


	public void setRequestedDate(String RequestedDate) {
		this.RequestedDate = RequestedDate;
	}

	public String getTransactionID() {
		return this.TransactionID;
	}


	public void setTransactionID(String TransactionID) {
		this.TransactionID = TransactionID;
	}	
}
