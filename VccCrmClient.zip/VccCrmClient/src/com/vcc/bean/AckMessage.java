package com.vcc.bean;

public class AckMessage {

	private String status;
	private String errorCode="";
	private String errorType="";
	private String errorDescription="";
	

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorType() {
		return errorType;
	}
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	public String toString() 
	{
        return " Status ["+status+"], ErrorCode ["+errorCode+"]";
	}
	

}
