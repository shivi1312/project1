package com.vcc.util;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppContext {

	public static ClassPathXmlApplicationContext applicationContext; 
		
	static{
		applicationContext=new ClassPathXmlApplicationContext("rest-servlet.xml");
	}
	public static ClassPathXmlApplicationContext getContext(){
	
		
		return applicationContext;
	}
	
}
