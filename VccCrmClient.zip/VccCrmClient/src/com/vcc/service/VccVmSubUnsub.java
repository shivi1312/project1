package com.vcc.service;

public interface VccVmSubUnsub 
{
	public String subscibe(String MSISDN,String tid,String profile,String lang,String subType);	
	public String unSubscibe(String MSISDN,String tid,String lang);	
}
