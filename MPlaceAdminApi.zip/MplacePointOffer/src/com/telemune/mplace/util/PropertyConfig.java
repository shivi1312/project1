package com.telemune.mplace.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;



public class PropertyConfig {
	private static Logger logger = Logger.getLogger(PropertyConfig.class);
	public static ConnPool conPool=null;
	public void loadingCongiguration()
	{

		String dbuser;
		String dbpass;
		String driver;
		String dburl;
		int port;
		int numOfConnection;
		int miniNumOfConnection;
		int dbAccomodation;
		
		Properties prop = new Properties();
		try
		{
			FileInputStream fins=new FileInputStream("properties/MplacePointOffer.properties");
			prop.load(fins);
			fins.close();
		}
		catch(FileNotFoundException fexp)
		{
			fexp.printStackTrace();
			logger.error(fexp.getMessage());
			System.exit(1);
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
			logger.error(exp.getMessage());
			System.exit(1);
		}

		try
		{
			numOfConnection = Integer.parseInt(prop.getProperty("NUM_OF_CONNECTION"));
			miniNumOfConnection = Integer.parseInt(prop.getProperty("MIN_NUM_OF_CONNECTION"));
			dbAccomodation = Integer.parseInt(prop.getProperty("DB_ACCOMODATION"));
			dbuser = prop.getProperty("DBUSER");
			dbpass = prop.getProperty("DBPASSWORD");
			driver = prop.getProperty("DRIVER");
			dburl = prop.getProperty("DBURL");
			port = Integer.parseInt(prop.getProperty("LOCAL_PORT"));
			
			/*
			 * conPool=new
			 * ConnPool(driver,dburl,dbuser,dbpass,miniNumOfConnection,numOfConnection,
			 * dbAccomodation); conPool.MakePool();
			 */
			
		}
		catch(NumberFormatException numexp)
		{
			numexp.printStackTrace();
		}
		catch (NullPointerException nullexp) {
			nullexp.printStackTrace();
		}
		catch (Exception exp) {
			exp.printStackTrace();
		}
	
	}
}
