package com.telemune.mplace.util;
import java.beans.PropertyVetoException;
import java.sql.*;
import com.mchange.v2.c3p0.ComboPooledDataSource;
/**
 * This class works as factory of Connection Pool
 * @author Sanchit
 * */
public class ConnPool
{ public static ComboPooledDataSource getDataSource() throws PropertyVetoException
{
    ComboPooledDataSource cpds = new ComboPooledDataSource();
    cpds.setJdbcUrl("jdbc:mysql://10.100.1.21:3306/mplace");
    cpds.setUser("mplace");
    cpds.setPassword("mplace");

    // Optional Settings
cpds.setInitialPoolSize(5);
    cpds.setMinPoolSize(5);
    cpds.setAcquireIncrement(5);
    cpds.setMaxPoolSize(20);
cpds.setMaxStatements(100);

    return cpds;
}
}
