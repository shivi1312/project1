/**
 * @author Ashish
 * Created on - 13 Feb, 2017
 */
package com.telemune.mplace.bean;

/**
 * This is the bean class used to hold the a pack 
 * @author Ashish
 */
public class PackBean implements Comparable<PackBean>
{
	/**
	 * Used to hold the unique ID of this pack
	 */
	private int packId=-99;
	
	/**
	 * Used to hold the name of this pack 
	 */
	private String packName=null;
	
	/**
	 * Used to hold the pack type id of this pack
	 * means ID of the type of this pack
	 */
	private int packTypeId=-99;
	
	/**
	 * Used to hold the description of this pack
	 */
	private String description=null;
	
	/**
	 * Used to hold the amount required to view this pack to user
	 */
	private double amountRequired=-1;
	
	/**
	 * Used to hold the priority of this pack
	 * this priority is used while showing packs to user and 
	 * are shown to user in order bases on this priority
	 */
	private int priority=-1;
	
	/**
	 * langId is used to hold language in which name and description
	 * of this pack is hold 
	 */
	private byte langId=-1;
	
	/**
	 * subType is used to hold user subscriber type to which this pack can be shown
	 */
	private String subType = "N";

	/**
	 * promptFile is used to hold the prompt file name of the particular pack
	 */
	private String promptFile = "NA";
	
	/**
	 * currentPackType is used to get the pack_type of low balance packs
	 */
	private int currentPackType = -1;
	
	/**
	 * Used to hold other properties of packs
	 */
	private String others = "NA";
	

	
	
	public int getCurrentPackType() {
		return currentPackType;
	}

	public void setCurrentPackType(int currentPackType) {
		this.currentPackType = currentPackType;
	}
	
	public String getPromptFile() {
		return promptFile;
	}

	public void setPromptFile(String promptFile) {
		this.promptFile = promptFile;
	}

	/**
	 * Default Constructor
	 */
	public PackBean()
	{
		
	}
	
	/**
	 * This constructor is used to create pack bean object with pack id
	 * @param packId
	 */
	public PackBean(int packId)
	{
		this.packId = packId;
	}
	
	/**
	 * @return {@link #packId}
	 */
	public int getPackId() {
		return packId;
	}

	/**
	 * @param packId
	 */
	public void setPackId(int packId) {
		this.packId = packId;
	}

	/**
	 * @return {@link #packName}
	 */
	public String getPackName() {
		return packName;
	}

	/**
	 * @param packName
	 */
	public void setPackName(String packName) {
		this.packName = packName;
	}

	/**
	 * @return {@link #packTypeId}
	 */
	public int getPackTypeId() {
		return packTypeId;
	}

	/**
	 * @param packTypeId
	 */
	public void setPackTypeId(int packTypeId) {
		this.packTypeId = packTypeId;
	}

	/**
	 * @return {@link #description}
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return {@link #amountRequired}
	 */
	public double getAmountRequired() {
		return amountRequired;
	}

	/**
	 * @param amountRequired
	 */
	public void setAmountRequired(double amountRequired) {
		this.amountRequired = amountRequired;
	}

	/**
	 * @return {@link #priority}
	 */
	public int getPriority() {
		return priority;
	}

	/**
	 * @param priority
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	/**
	 * @return {@link #langId}
	*/	
	public byte getLangId() {
		return langId;
	}
	
	/**
	 * @param langId
	*/
	public void setLangId(byte langId) {
		this.langId = langId;
	}

	/**
	 * @return {@link #subType}
	 */
	public String getSubType() {
		return subType;
	}

	/**
	 * @param subType
	 */
	public void setSubType(String subType) {
		this.subType = subType;
	}
	
	
	@Override
	public boolean equals(Object obj) 
	{	
		PackBean packBean = (PackBean)obj;
		return this.packId == packBean.packId;
	}

	/**
	 * This method is used for comparing packs to each other
	 * while sorting them based on priority
	 */
	@Override
    public int compareTo(PackBean packBean) {
        if(this.getPriority()>packBean.getPriority())
        	return 1;
        else if(this.getPriority()==packBean.getPriority())
        	return 0;
        else
        	return -1;
    }

	/**
	 * @return the others
	 */
	public String getOthers() {
		return others;
	}

	/**
	 * @param others the others to set
	 */
	public void setOthers(String others) {
		this.others = others;
	}
	

	/**
	 * @return the packOtherDetails
	 */

	
	/**
	 * This is an overridden method and is used to return the value of
	 * all the parameters of this class so that while printing the value of
	 * the object of this class it prints the values of the parameters
	 * @return all the variables and theirs values of the object of this class
	 */
	@Override
	public String toString() {
		return "PackBean [packId=" + packId + ", packName=" + packName + ", packTypeId=" + packTypeId + ", description="
				+ description + ", amountRequired=" + amountRequired + ", priority=" + priority + ", langId=" + langId
				+ ", subType=" + subType + ", promptFile=" + promptFile + ", currentPackType=" + currentPackType
				+ ", others=" + others +"]";
	}
	
}
