/**
 * @author MoHit
 * Created on - 13 Feb, 2017
 */
package com.telemune.mplace.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;


/**
 * This class is used to hold some parameters which need to be cached and will
 * be used throughout the application by different classes with the help of
 * TSSJavaUtil instance only
 * 
 */
public class CachedParameters {
	
	Logger logger = Logger.getLogger(CachedParameters.class);
	
	/**
	* Used to hold the database driver class to be used
	 */
	private String dbDriver = null;

	/**
	 * Used to hold the database URL to be used
	 */
	private String dbURL = null;

	/**
	 * Used to hold the database username to be used
	 */
	private String dbUsername = null;

	/**
	 * Used to hold the database password to be used
	 */
	private String dbPassword = null;

	/**
	 * Used to hold the minimum connection in pool
	 */
	private short dbMinPoolSize = 1;

	/**
	 * Used to hold the maximum connection in pool
	 */
	private short dbMaxPoolSize = 3;

	/**
	 * Used to hold no. of connection to be create when needed more
	 */
	private short dbAccomodation = 2;
	
	private int packActionType;
	
	private int packActionResponse;

}