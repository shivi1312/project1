package com.telemune.mplace.dao;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import java.util.Arrays;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.*;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.telemune.mplace.bean.PackBean;
import com.telemune.mplace.util.ConnPool;


public class Dboperation {
	private static Logger logger = Logger.getLogger("Dboperation");
	

	public static void main(String[] args) throws SQLException
	{
		HashMap<String, ArrayList<PackBean>> availablePacksMap = new HashMap<String, ArrayList<PackBean>>();
		HashMap<String,String> pointMap= new HashMap<String, String>();
		Dboperation db = new Dboperation();
		String other="";
		ComboPooledDataSource dataSource;
		try {
			dataSource = ConnPool.getDataSource();
			Connection con = dataSource.getConnection();
			
			    db.loadAvailablePacks(availablePacksMap, con);
			    logger.info("available packs=============="+Arrays.asList(availablePacksMap));
			    
			    PackBean packs=new PackBean();
			    ArrayList<PackBean> pb= availablePacksMap.get("PackBean");
			    
			    
			    
				
				  Iterator itr=pb.iterator();//getting the Iterator
				  while(itr.hasNext()){//check if iterator has the elements
				 // System.out.println("kkkkkk"+itr.next()); 
				  packs=(PackBean) itr.next();
				  other=packs.getOthers();
				  JSONParser parser = new JSONParser();
				  JSONObject json;
				  
				try {
					json = (JSONObject) parser.parse(other);
					String packActionType=(String)json.get("packActionType");
					String packActionResp=(String)json.get("packActionResp");
					
					
					if(packActionResp!=null && !packActionResp.equals("") && packActionType!=null && !packActionType.equals(""))
					{
						System.out.println("packActionType=="+packActionType);
						System.out.println("packActionResp=="+packActionResp);
						pointMap.put("packActionType", packActionResp);
						pointMap.put("packActionType", packActionResp);
					}
				//	System.out.println((String)json.get("packActionResp"));
			//		System.out.println((String)json.get("destNumb"));
					
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				   
				 
				   
				  }
				 
			    
			    packs=pb.get(1);
			    
			    System.out.println("other=========="+packs.getOthers());
			    
			    logger.info("<<<<<<<<<pb>>>>>>>>>>"+pb);
			  //  JSONObject json = new JSONObject(availablePacksMap.get("other"));
			    
			    
			    
			    
			    
			    
			    try {
			        TimeUnit.SECONDS.sleep(10000);
			    } catch (InterruptedException ie) {
			        Thread.currentThread().interrupt();
			    }
		} catch (PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	   
	    
	    
		/*
		 * try { ComboPooledDataSource dataSource = ConnPool.getDataSource(); connection
		 * = dataSource.getConnection(); pstmt =
		 * connection.prepareStatement("SELECT PACK_ID FROM pack_master");
		 * 
		 * System.out.println("The Connection Object is of Class: " +
		 * connection.getClass());
		 * 
		 * resultSet = pstmt.executeQuery(); while (resultSet.next()) {
		 * System.out.println(resultSet.getString(1) ); }
		 * 
		 * } catch (Exception e) { try { connection.rollback(); } catch (SQLException
		 * e1) { // TODO Auto-generated catch block e1.printStackTrace(); }
		 * e.printStackTrace(); }
		 */
		
	}
	public int loadAvailablePacks(HashMap<String, ArrayList<PackBean>> availablePacksMap, Connection con) {
		logger.info("loadAvailablePacks() >> Loading all available packs from Pack_Master: initial list is ["
				+ availablePacksMap + "] and database connection is [" + con + "]");

		PreparedStatement stmt = null;
		ResultSet rs = null;

		if (availablePacksMap == null)
			return -1;

		if (con == null)
			return -1;

		ArrayList<PackBean> packList = new ArrayList<PackBean>();
		PackBean packBean = null;

		String query=" SELECT PACK_TYPE,LANGUAGE_ID,SUB_TYPE,PACK_ID,PACK_NAME,DESCRIPTION,AMOUNT_REQUIRED,PRIORITY,PROMPT_FILE,OTHER FROM PACK_MASTER WHERE START_DATE<=now() AND END_DATE>=now() AND STATUS='A' AND SPECIAL_PACK_TYPE!=1 ORDER BY PACK_TYPE,LANGUAGE_ID,SUB_TYPE,PRIORITY desc";
		// loading details from pack_master table
		try {
			stmt = con.prepareStatement(query);
			String type = "N";
			logger.info("loadAvailablePacks() >> loading all available packs query ["
					+ query + "]");
			rs = stmt.executeQuery();
			while (rs.next()) {
						
						packBean = new PackBean();
						setPackBean(packBean, rs, type);
						packList.add(packBean);
						
						
			}

			availablePacksMap.put("PackBean", packList);
			
	
			//logger.info(
			//		"loadAvailablePacks() >> Total keys loaded from pack master are [" + availablePacksMap + "]");
			logger.info("loadAvailablePacks() >> available packs loaded from pack master are [" + availablePacksMap
					+ "]");
		} catch (SQLException sqle) {
			logger.error(" >> SQLException occurred while loading all available packs from database", sqle);
			return -1;
		} catch (NullPointerException npe) {
			logger.error(" >> NullPointerException occurred while loading all available packs from database, stmt:["
					+ stmt + "] or rs:[" + rs + "] may be null", npe);
			return -1;
		} catch (Exception e) {
			logger.error( " >> Exception occurred while loading all available packs from database", e);
			return -1;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
			} catch (Exception exp) {
				logger.error(
						" >> Exception While closing result set or statement");
			}
		}
		return 1;
	}
	
	public void setPackBean(PackBean packBean, ResultSet rs, String type) throws Exception {
		packBean.setPackId(rs.getInt("PACK_ID"));
		packBean.setPackName(rs.getString("PACK_NAME"));
		packBean.setPackTypeId(rs.getInt("PACK_TYPE"));
		packBean.setDescription(rs.getString("DESCRIPTION"));
		packBean.setAmountRequired(rs.getDouble("AMOUNT_REQUIRED"));
		packBean.setPriority(rs.getInt("PRIORITY"));
		packBean.setLangId(rs.getByte("LANGUAGE_ID"));
		packBean.setSubType(rs.getString("SUB_TYPE"));
		packBean.setPromptFile(rs.getString("PROMPT_FILE"));
		packBean.setOthers(rs.getString("OTHER"));

		if (type.equalsIgnoreCase("L")) {
			packBean.setCurrentPackType(rs.getInt("CURRENT_PACK_TYPE"));
		}
	}

}
