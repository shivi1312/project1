package com.telemune.mplace;

import java.util.LinkedHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class PointScheduler {
	public static LinkedHashMap<String, String> pointsMap=new LinkedHashMap<String, String>();
	public static void main(String[] args) {
		
		
		
        //run this task after 0 seconds and repeat after every 60 sec
        ScheduledExecutorService executorService;
        executorService = Executors.newSingleThreadScheduledExecutor();
        executorService.scheduleAtFixedRate(PointScheduler::run, 0, 60, TimeUnit.SECONDS);

	}
	
	 private static void run() {
	        System.out.println("Running: " + new java.util.Date());
	    }

}


