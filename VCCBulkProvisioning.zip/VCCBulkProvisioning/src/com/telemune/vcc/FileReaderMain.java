package com.telemune.vcc;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;

import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.jdbc.core.JdbcTemplate;
import com.google.gson.Gson;



public class FileReaderMain {
	private final static Logger logger = Logger.getLogger(FileReaderMain.class);
	private final static Logger reqFailLogger = Logger.getLogger("reqFailLogger");
	private final static Logger successLogger = Logger.getLogger("successLogger");
	static int multiTableEnable=AppConfig.config.getInt("multi_table_sub_check"); // added by sanchit
	
	public static void main(String args[])
	{
	
		
		  FileReaderBean bean=null;
		  
		  
		  try { PropertyConfigurator.configure("properties/fileLog.properties");
		  Scanner s = new Scanner(new File("CDRFile.txt")); 
		  String response=""; 
		  String serviceType;
		  Gson gson=new Gson(); 
		  String request=""; 
		  while (s.hasNextLine()){
		  
		  String line=s.nextLine(); // list.add(s.nextLine()); 
		  StringTokenizer st = new
		  StringTokenizer(line,","); 
		  while (st.hasMoreTokens()) {
		  
		  bean=new FileReaderBean(); 
		  bean.setMsisdn(st.nextToken());
		  
		  // For unsub using db , added by sanchit
		  if(AppConfig.config.getInt("unsub_using_db")==1)
		  {
			  
			//  bean.setServiceType(readServicetype(bean.getMsisdn()));
			 if(!readServicetype(bean.getMsisdn()).isEmpty()) 
			 {
			  Iterator iterator = readServicetype(bean.getMsisdn()).iterator();
		      while(iterator.hasNext()) {
		    	  serviceType=(String) iterator.next();
		    	  bean.setServiceType(serviceType);
		    	  //to set planName from app_config_param
		    	  if(setAllPlanName(serviceType)!=null && !setAllPlanName(serviceType).equals(""))
		    		  bean.setPlanName(setAllPlanName(serviceType));
		    	  
		    	  
		    	  logger.info("bean is"+bean.toString()); 
				  request= gson.toJson(bean);
				  logger.debug("response is"+request);
				  
				  response = sendReqToRuleEngine(request.toString()); 
				  bean =gson.fromJson(response.trim(),FileReaderBean.class);
		      }
			 }
		      else
		      {
		    	  logger.info("No data found in db for this msisdn -"+bean.getMsisdn());
		    	  
		      }
		      
		  }
		  
		  else
		  {
			  	  serviceType=bean.getServiceType();
			  	  //to set planName from app_config_param
			  	if(setAllPlanName(serviceType)!=null && !setAllPlanName(serviceType).equals(""))
		    		  bean.setPlanName(setAllPlanName(serviceType));
			
				  logger.info("bean is"+bean.toString()); 
				  request= gson.toJson(bean);
				  logger.debug("response is"+request);
				  
				  response = sendReqToRuleEngine(request.toString()); 
				  bean =gson.fromJson(response.trim(),FileReaderBean.class);
				 //bean.setResult("fail");
		  }
		  
		  
		  if (!bean.getResult().equalsIgnoreCase("success"))
		  { 
			  logger.info("inside failure condition"+line); 
			  reqFailLogger.info(line);
		  
		  } else { successLogger.info(line); } 
		  }
		  
		  }
		  
		  s.close();
		  
		  } catch(Exception e) {
		  logger.error("Exception into FileReader Class"+e.getMessage());
		  e.printStackTrace(); }
		 
		
	}
	

	public static String sendReqToRuleEngine(String request) {
		DataOutputStream out = null;
		DataInputStream reader = null;
		String response = "ERROR";
		try {
			Socket socket = new Socket(AppConfig.config.getString("rule_engine_ip"),AppConfig.config.getInt("rule_engine_port"));
			out = new DataOutputStream(socket.getOutputStream());
			out.writeUTF(request);
			out.flush();
			reader = new DataInputStream(socket.getInputStream());
			response = reader.readUTF();
			logger.info("response: " + response);
			out.close();
			reader.close();
			socket.close();

		}  catch (SocketException se) {
			logger.error("Socket Exception"+se.getMessage());
			se.printStackTrace();
		} catch (SocketTimeoutException ste) {
			logger.error("Socket Time out Exception"+ste.getMessage());
			ste.printStackTrace();
		}
		 catch (Exception e) {
			logger.error("Exception when send request to rule engine"+e.getMessage());
			e.printStackTrace();
		}
		return response;
	}
	
	private static List readServicetype(String msisdn) {
		DataSource dataSource;
		try {
			//logger.info("getting service type from DB");
			dataSource = (DataSource) AppContext.context.getBean("dataSource");
			
			// added by sanchit atri on 16-sep-2020
			String sql="";
			if(multiTableEnable==1)
			{
				String lastDigit=msisdn.substring(msisdn.length()-1);
				String tableName1="vcc_auth_user_"+lastDigit;
				String tableName2="VCC_SUBSCRIPTION_MASTER_"+lastDigit;
				sql="select b.service_type from "+tableName1+" a, "+tableName2+" b where a.msisdn=b.msisdn and a.msisdn=?";
				logger.info("Query->>>>>>>>>>>>>>>>>>>>>>>>>>>>"+sql);
			}
			else
			{
				sql="select b.service_type from vcc_auth_user a, vcc_subscription_master b where a.msisdn=b.msisdn and a.msisdn=?";
				logger.info("Query->>"+sql);
			}
			/*
			 * String
			 * sql="select b.service_type from vcc_auth_user a, vcc_subscription_master b where a.msisdn=b.msisdn and a.msisdn=?"
			 * ;
			 */
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			List serviceTypeList = jdbcTemplate.queryForList(sql, new Object[] { msisdn }, String.class);

			return serviceTypeList;

		} catch (Exception e) {
			logger.error("error in db operation for readServicetype details  [" + e + "]");
			return null;
		}

	}
	
	private static String setVmPlanName()
	{
		
		DataSource dataSource;
		try {
			dataSource = (DataSource) AppContext.context.getBean("dataSource");
			String sql="select Param_value from app_config_params where param_name=?";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String planNameVM = jdbcTemplate.queryForObject(sql, new Object[] { "VM_DEFAULT_PLAN" }, String.class);

			return planNameVM;

		} catch (Exception e) {
			logger.error("error in db operation for setVmPlanName details  [" + e + "]");
			return null;
		}
		
	}

	private static String setVnPlanName()
	{
		
		DataSource dataSource;
		try {
			dataSource = (DataSource) AppContext.context.getBean("dataSource");
			String sql="select Param_value from app_config_params where param_name=?";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String planNameVN = jdbcTemplate.queryForObject(sql, new Object[] { "VN_DEFAULT_PLAN" }, String.class);

			return planNameVN;

		} catch (Exception e) {
			logger.error("error in db operation for setVnPlanName details  [" + e + "]");
			return null;
		}
		
	}

	
	private static String setMcaPlanName()
	{
		
		DataSource dataSource;
		try {
			dataSource = (DataSource) AppContext.context.getBean("dataSource");
			String sql="select Param_value from app_config_params where param_name=?";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			String planNameMCA = jdbcTemplate.queryForObject(sql, new Object[] { "MCA_DEFAULT_PLAN" }, String.class);

			return planNameMCA;

		} catch (Exception e) {
			logger.error("error in db operation for setMcaPlanName details  [" + e + "]");
			return null;
		}
		
	}
	
	private static String setAllPlanName(String serviceType)
	{
		String planName="";
		if(serviceType.equals("0100"))
  	  {
  		  if(setVnPlanName()!=null && !setVnPlanName().equals(""))
  			  planName=setVnPlanName();
  		  else
  			  logger.info("No planName found for VN in app_config");
  	  }
  	  else if(serviceType.equals("0010"))
  	  {
  		  if(setVmPlanName()!=null && !setVnPlanName().equals(""))
  			  planName=setVmPlanName();
  		  else
  			  logger.info("No planName found for VN in app_config");
  	  }
  	  else if(serviceType.equals("0001"))
  	  {
  		  if(setMcaPlanName()!=null && !setVnPlanName().equals(""))
  			  planName=setMcaPlanName();
  		  else
  			  logger.info("No planName found for MCA in app_config");
  	  }
  	  return planName;
	}

	
}
