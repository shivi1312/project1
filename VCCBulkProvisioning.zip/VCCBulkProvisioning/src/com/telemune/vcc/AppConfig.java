package com.telemune.vcc;

import java.io.File;
import org.apache.commons.configuration.CombinedConfiguration;
import org.apache.commons.configuration.DefaultConfigurationBuilder;
import org.apache.log4j.Logger;

public class AppConfig {
	
	private final static Logger logger = Logger.getLogger(AppConfig.class);
	public static CombinedConfiguration config;
	
	static {
		try {
			DefaultConfigurationBuilder builder = new DefaultConfigurationBuilder();
			builder.setFile(new File("properties/config.xml"));
			config = builder.getConfiguration(true);
		} catch (Exception e) {
			logger.error("error in configuration [" + e + "]");
		}
	}
	
	
}
