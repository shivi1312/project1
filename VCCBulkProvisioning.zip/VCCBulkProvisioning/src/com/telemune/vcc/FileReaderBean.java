package com.telemune.vcc;

public class FileReaderBean {

	private String msisdn;
	private String serviceType=AppConfig.config.getString("serviceType","0010");
	private String subType=AppConfig.config.getString("subType","N");
	private String interFace=AppConfig.config.getString("interFace","ivr");
	private boolean cbcmEnable=AppConfig.config.getBoolean("cbcmEnable",true);
	private boolean notification=AppConfig.config.getBoolean("notification",true);
	private String result="fail";
	private String planName=AppConfig.config.getString("planName","basic");
	private int actionId=AppConfig.config.getInt("actionId",1);
	private String tid=AppConfig.config.getString("tid","1234567");
	private String channel=AppConfig.config.getString("channel","rec");
	
	private String lang =AppConfig.config.getString("langId","1"); // added by sanchit on 11-oct-2020
	
	
	
	
	
	
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public int getActionId() {
		return actionId;
	}
	public void setActionId(int actionId) {
		this.actionId = actionId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public boolean isCbcmEnable() {
		return cbcmEnable;
	}
	public void setCbcmEnable(boolean cbcmEnable) {
		this.cbcmEnable = cbcmEnable;
	}
	public boolean isNotification() {
		return notification;
	}
	public void setNotification(boolean notification) {
		this.notification = notification;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getInterFace() {
		return interFace;
	}
	public void setInterFace(String interFace) {
		this.interFace = interFace;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	
	@Override
	public String toString() {
		return "FileReaderBean [msisdn=" + msisdn + ", serviceType=" + serviceType + ", subType=" + subType
				+ ", interFace=" + interFace + ", cbcmEnable=" + cbcmEnable + ", notification=" + notification
				+ ", result=" + result + ", planName=" + planName + ", actionId=" + actionId + ", tid=" + tid
				+ ", channel=" + channel + ", lang=" + lang + "]";
	}
	
	
	
	
	
	
}
