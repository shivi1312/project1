delimiter //
drop procedure if exists SuspendService //
create Procedure SuspendService(In p_msisdn varchar(20),IN p_plan  int,IN p_lang  int,IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),OUT p_status int,OUT p_id  int)
isdone:begin

declare cont int;
declare l_temp int;
declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;


       set  p_status=1;
       set  p_id=1;
       set  l_temp=1;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status='S';
        if l_temp != 0 then
                set p_status=-28;
                LEAVE ISDONE;
        else
                set p_status=2;
                update crbt_subscriber_master set status='S',update_time=now() where msisdn=p_msisdn;
                commit;
                set p_status=2;
                insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),'SS',p_int,'N',p_updatedby,1);
                commit;
                set p_status=3;
                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,'SUSPENDED',p_subtype,p_int,p_updatedby);
                commit;
                set p_status=4;
        end if;
	SELECT CONCAT('p_status , p_id ',p_status, p_id);
end //

