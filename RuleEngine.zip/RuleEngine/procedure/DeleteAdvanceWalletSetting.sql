DELIMITER //
drop procedure if exists DeleteAdvanceWalletSetting //

CREATE PROCEDURE DeleteAdvanceWalletSetting(IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20), IN p_sys_wallet_id int, IN p_type int , OUT p_status int) 
ISDONE:BEGIN

DECLARE l_temp int  ;
DECLARE p_id    int ;
DECLARE l_priority int ;
DECLARE l_sys_wallet_setting int ;
DECLARE l_count int ;
DECLARE v_finished int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

                set p_status=(p_status*(-1));
                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
         SELECT p_status;
END;

START TRANSACTION;
	SET p_status = 1;
	SET l_priority = -1;
	SET l_sys_wallet_setting = 1;
	SET l_count = -1;


if p_sys_wallet_id <=0 then /*---checking for valid systemWalletId */
        SET p_status=-53;
        LEAVE ISDONE;
else
        select priority into l_priority from crbt_system_wallet_master where wallet_id=p_sys_wallet_id;

        if l_priority = 2 then
                 select count(*) into l_count from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A';
                 SET p_status=2;
                 if l_count >0 then
                         select setting into l_sys_wallet_setting from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A';
                         SET p_status=3;

                         update crbt_subscriber_wallet_detail set setting=l_sys_wallet_setting where wallet_id=p_sys_wallet_id and msisdn=p_msisdn;
--                         commit;
                         SET p_status=4;

                         insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1, CONCAT('A Advanced Profile For System Wallet ',p_sys_wallet_id,' is Deleted'),p_subtype,p_int,p_updatedby);
  --                       commit;
                         SET p_status=5;
			COMMIT;
                end if;

	else
                SET p_status=-56; /*--cannot change the setting for priority= 0 or 1*/
        --        LEAVE ISDONE;
        end if;
end if;

SELECT CONCAT(p_status);
END //
DELIMITER ;

