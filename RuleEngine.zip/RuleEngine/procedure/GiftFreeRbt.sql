delimiter //
drop procedure if exists GiftFreeRbt   //
create procedure GiftFreeRbt (IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20), IN p_rbt int ,IN p_fmsisdn varchar(20),IN p_chgcode int ,IN p_validityDays int ,OUT p_status  int)
isdone:begin

declare  l_temp          int;
declare  p_id int;
declare  l_isSystemRbtBased int;

declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
START TRANSACTION;
      set  p_status=1;
      call  GenerateCrbtCdrs (p_msisdn,p_chgcode,4,p_int,-1,0,now(),p_fmsisdn,p_rbt,0,p_subtype,p_status,p_id);
       # -- gift rbt cdrs

      select wallet_id into l_temp from crbt_wallet_master where msisdn=p_fmsisdn and wallet_name='DEFAULT';
      set p_status=4;
	select concat(l_temp,' ',p_rbt,' ',p_validityDays,' ',p_fmsisdn);
      insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,is_rbt_gifted,expiry_date) values (l_temp,p_rbt,((now() - interval 30 day)+ interval p_validityDays day),p_fmsisdn,1,now()+ interval p_validityDays day);
	select concat("After query p_status ",p_status);
      set p_status=5;
      -- commit;
      select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
     if l_isSystemRbtBased=1 then
     update crbt_subscriber_master set last_charged=((now - interval 30 day) + interval p_validityDays day), expiry_date=now()+ interval p_validityDays day, update_time=now(),rbt_code=p_rbt where msisdn=p_msisdn and last_charged<=((now()- interval 30 day) + interval p_validityDays day );
    	-- commit;
     end if;
     insert into crbt_rbt_gift_log (msisdn,subscriber_type,event_time,interface_type,op_code,friend_msisdn,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_int,1,p_fmsisdn,'N',p_updatedby,p_id);
     set p_status=6;
     -- commit;
     insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),0,concat('A RBT is Gifted to Friend ',p_fmsisdn),p_subtype,p_int,p_updatedby);
     set p_status=7;
     commit;
SELECT CONCAT('p_status ',p_status);
End //

