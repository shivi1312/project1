delimiter //
drop procedure if exists CheckForRenewMode //
create Procedure CheckForRenewMode(IN p_msisdn   varchar(20), OUT p_renewMode  int, OUT p_subType  varchar(20),OUT p_status  int)
isdone:begin
declare l_temp          int ;
declare l_subType       varchar(5);

declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;

        set   p_status=1;
        set l_temp=0;
        set p_renewMode=30;
        set p_subType='N';
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn;
        if l_temp!=0
        then
                select renew_mode into l_temp from  crbt_subscriber_master where msisdn=p_msisdn;
                set p_status=2;
                select sub_type into l_subType from  crbt_subscriber_master where msisdn=p_msisdn;
                set p_status=3;
                set p_renewMode=l_temp;
                set p_subType=l_subType;
 SELECT CONCAT('p_status ',p_status, ' p_renewMode ',p_renewMode);
                LEAVE ISDONE;
        else
                set p_status=-1;
        end if;
	SELECT CONCAT('p_status ',p_status, ' p_renewMode ',p_renewMode);
end //
