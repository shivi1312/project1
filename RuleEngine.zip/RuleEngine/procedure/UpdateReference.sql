delimiter //
drop procedure if exists UpdateReference //
create procedure UpdateReference(IN p_msisdn varchar(20) ,IN p_refId varchar(20) ,OUT p_status int)
ISDONE:BEGIN
declare l_temp int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=p_status=-1;

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;
	set p_status=-2;
	set l_temp=0;
        -- select count(*) into l_temp from crbt_reference where reference_id=p_refId;
        if l_temp!=0
        then
        --      update crbt_reference set status='S',update_time=now() where reference_id=p_refId;
                commit;
                set p_status=1;
		LEAVE ISDONE;
        end if;
End //

