delimiter //
drop procedure if exists CheckForSuspension //
create Procedure CheckForSuspension(IN p_msisdn  varchar(20), OUT p_status  int)
isdone:begin
declare l_temp          int ;
declare l_status varchar(3);
declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=-1;

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;


     set p_status=-1;
     set l_temp=0;
     set l_status='A';
     select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status != 'D';
     if l_temp!=0
     then
                select status into l_status from crbt_subscriber_master where msisdn=p_msisdn;
                if l_status = 'S' then
                        set p_status= -28;
                elseif l_status = 'I' then
                        set p_status=-29;
                else
                        set p_status=1;
                end if;
     else
                set p_status=-30;
    end if;
	SELECT CONCAT('p_status ',p_status);
end //
