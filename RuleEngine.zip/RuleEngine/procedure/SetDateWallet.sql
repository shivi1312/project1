DELIMITER //
drop procedure if exists SetDateWallet //

CREATE PROCEDURE SetDateWallet(IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_sys_wallet_id int,IN p_occasion varchar(20),IN p_chgdone int,IN p_date varchar(20),IN p_refid varchar(20),IN p_chgcode int,IN p_validityDays int,IN p_packId int,IN p_type int,OUT p_status int)
ISDONE:BEGIN

DECLARE l_temp int;
DECLARE p_id int;

DECLARE v_finished int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

                set p_status=(p_status*(-1));
                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
        # SELECT p_status;
END;

START TRANSACTION;
SET p_status=1;
SET p_id=-1;
           CALL AddWallet(p_msisdn,p_int,p_updatedby,p_subtype,p_sys_wallet_id,p_chgdone,p_refid,p_chgcode,p_validityDays,p_packId,p_type,p_status,l_temp);
           if p_status < 0
           then
            --      p_status:=-1;
                    LEAVE ISDONE;
           else
                  SET p_id=l_temp;
                  end if;
           SET p_status=2;

           SET l_temp=0;
--           select count(*) into l_temp from crbt_eventdate_rbt where msisdn=p_msisdn and STR_to_date(DATE_FORMAT(event_date,'%d%myy'),'%d%myy')=str_to_date(p_date,'%d%myy');
	select count(*) into l_temp from crbt_eventdate_rbt where msisdn=p_msisdn and date_Format(str_to_date(event_date,'%d-%m-%Y'),'%d-%m-%Y')=date_format(str_to_date(p_date,'%d-%m-%Y'),'%d-%m-%Y');
          if l_temp = 0 then
             SELECT CONCAT('Before insert crbt_eventdate_rbt and ltemp= ',l_temp);
--             insert into crbt_eventdate_rbt (msisdn,event_date,rbt_code,update_time,occasion_name,content_type) values (p_msisdn,to_date(p_date,'ddmmyy'),p_sys_wallet_id,now(),p_occasion,p_type);
	   insert into crbt_eventdate_rbt (msisdn,event_date,rbt_code,update_time,occasion_name,content_type) values (p_msisdn,str_to_date(p_date,'%d-%m-%Y'),p_sys_wallet_id,now(),p_occasion,p_type);
          	SELECT CONCAT('After insert crbt_eventdate_rbt and ltemp= ',l_temp);
                SET p_status=3;
                else
                   SELECT CONCAT('Before update crbt_eventdate_rbt and ltemp= ',l_temp);
--                   update crbt_eventdate_rbt set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and    str_to_date(date_format(event_date,'%d%myy'),'%d%myy')=str_to_date(p_date,'%d%myy');
		update crbt_eventdate_rbt set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and   date_format(str_to_date(event_date,'%d-%m-%Y'),'%d-%m-%Y')=date_format(str_to_date(p_date,'%d-%m-%Y'),'%d-%m-%Y');
                   SELECT CONCAT('Afetr update crbt_eventdate_rbt and ltemp= ',l_temp);
                end if;
                  -- commit;
                   SET p_status=4;

--                  if STR_to_date(p_date,'%d%myy') = STR_to_date(DATE_FORMAT(NOW(),'%d%myy'),'%d%myy')
		 if date_format(STR_to_date(p_date,'%d-%m-%Y'),'%d-%m-%Y') = date_format(NOW(),'%d-%m-%Y')
                  then
                        update crbt_subscriber_master set date_setting_validity=1 where msisdn=p_msisdn;
                    --    commit;
                  end if;
                      SET p_status=5;

                       insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,NOW(),p_sys_wallet_id,p_int,1,p_date,'N',p_updatedby,p_id,1);
                       SET p_status=6;
                      -- commit;
                 
		      insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,NOW(),1,CONCAT('A Wallet for Date ',p_date,' is set'),p_subtype,p_int,p_updatedby);
                       SET p_status=7;
                       commit;


		SELECT CONCAT('p_status ',p_status);

END //
DELIMITER ;

