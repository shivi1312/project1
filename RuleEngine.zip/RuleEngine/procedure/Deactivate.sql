delimiter //
drop procedure if exists Deactivate //
create procedure Deactivate (IN p_msisdn varchar(20)  ,IN p_int varchar(20) ,IN p_updatedby varchar(20) ,IN p_subtype varchar(20) ,OUT p_status int ,OUT p_id int )
ISDONE:BEGIN

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
 END;
 START TRANSACTION;

	set p_id=1;
	set p_status=4;
	select concat( 'after cdr');
	update crbt_subscriber_master set status='I', update_time=now() where msisdn=p_msisdn;
	set p_status=5;
--	commit;
	select concat( 'after deletion');
	insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),'I',p_int,'N',p_updatedby,1);
	set p_status=6;
--	commit;
	select concat( 'subscription log');
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,'DEACTIVATED',p_subtype,p_int,p_updatedby);
	set p_status=7;
--	commit;
	select concat( 'activity log');
	set p_status=8;
	commit;
End // 
