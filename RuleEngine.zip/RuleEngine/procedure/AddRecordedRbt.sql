delimiter //
drop procedure if exists AddRecordedRbt //
create procedure  AddRecordedRbt ( IN p_msisdn  varchar(20),IN  p_rbtpath  varchar(20),IN p_catId  int,IN p_subtype  varchar(20),IN call_Id  int,IN p_validityDays  int,IN p_packId  int,OUT p_status  int)
isdone:begin

declare p_id int;
declare l_temp int;
declare l_totalRecording int;
declare l_freeRecording int;
declare l_isSystemRbtBased int;
declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

                 delete from crbt_rbt where rbt_code=p_status;
                 commit;
                 set p_status=(p_id*(-1));
                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;

        set    p_id=-1;
        set    l_temp=-1;
        set    l_freeRecording=0;
        set l_totalRecording=0;
       -- select (rbt_code+1) into p_status from crbt_rbt;   -- need to check and update according to crbt_rbt's rbt_code pmrkey
	insert into rbt_code_seq_id values (null);
	set p_status=LAST_INSERT_ID(); -- added new
        set p_id=1;
        insert into crbt_rbt (rbt_code, masked_name,file_path,rbt_score,ivr_filepath,playable,show_on_web,show_in_sms,CONTENT_PROVIDER_CODE,cat_id,corp_id) values (p_status,'RECORDED',p_rbtpath,1,p_rbtpath,'Y','Y','Y',1,p_catId,0);
       -- commit;
        set p_id=2;
        insert into crbt_rbt_owner (msisdn,rbt_code,create_time,usage_status) values (p_msisdn,p_status,now(),'Y');
     --   commit;
        set p_id=3;
        select wallet_id into l_temp from crbt_wallet_master where msisdn=p_msisdn and wallet_name='DEFAULT';
        if l_temp >0  then
                set p_id=4;
                select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
                if l_isSystemRbtBased=1 then
                        insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,is_rbt_gifted,expiry_date) values (l_temp,p_status,((now() - interval 30 day)+ interval p_validityDays day),p_msisdn,3,now()+ interval p_validityDays day);
                else
                        insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,is_rbt_gifted,expiry_date) values (l_temp,p_status,now(),p_msisdn,3,now()+ interval p_validityDays day);
                end if;
--                commit;
                set p_id=5;
                if p_packId > 0 then
                        select TOTAL_RECORDING,FREE_RECORDING into l_totalRecording,l_freeRecording from crbt_promo_user_detail where MSISDN=p_msisdn and PROMO_ID=p_packId and status='A';
                        if l_totalRecording > 0 then
                                update crbt_promo_user_detail set TOTAL_RECORDING=TOTAL_RECORDING-1 where MSISDN=p_msisdn and PROMO_ID=p_packId;
                        elseif l_freeRecording > 0 then
                                update crbt_promo_user_detail  set FREE_RECORDING=FREE_RECORDING-1 where MSISDN=p_msisdn and PROMO_ID=p_packId;
                        end if;
                      --  commit;
                end if;
         select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
        if l_isSystemRbtBased=1 then
                update crbt_subscriber_master set last_charged=((now()- interval 30 day)+ interval p_validityDays day), expiry_date=now()+ interval p_validityDays day, update_time=now() where msisdn=p_msisdn and last_charged<=((now() - interval 30 day) + interval p_validityDays day);
         --       commit;
        end if;
                insert into crbt_rbt_record_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_status,'I',1,'N',p_msisdn,call_Id);
       --         commit;
                set p_id=6;
        else
                set p_id=7;
--                set p_status=(p_id*(-1));
        end if;
commit;
	SELECT CONCAT('p_status',p_status);
end //


