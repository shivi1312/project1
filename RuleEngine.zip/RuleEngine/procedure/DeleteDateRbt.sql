DELIMITER //
drop procedure if exists DeleteDateRbt //

CREATE PROCEDURE DeleteDateRbt(IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20), IN p_rbt int,IN p_date varchar(20), OUT p_status int)
ISDONE:BEGIN
DECLARE l_temp int;
DECLARE p_id int;
DECLARE v_finished int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

                set p_status=(p_status*(-1));
                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
         SELECT p_status;
END;

START TRANSACTION;


SET p_status=1;
SET p_id=-1;

-- delete from crbt_eventdate_rbt where msisdn=p_msisdn and rbt_code=p_rbt and str_to_date(date_format(event_date,'%d-%m-%Y'),'%d-%m-%Y')=str_to_date(p_date,'%d-%m-%Y');
	delete from crbt_eventdate_rbt where msisdn=p_msisdn and rbt_code=p_rbt and str_to_date(date_format(event_date,'%d%m%y'),'%d%m%y')=str_to_date(p_date,'%d%m%Y');
SELECT CONCAT('11111111111111111111111');		
--	commit;
	SET  p_status=4;

	if str_to_date(p_date,'%d%m%Y') = str_to_date(date_format(now(),'%d%m%Y'),'%d%m%Y')
	then
		update crbt_subscriber_master set date_setting_validity=0 where msisdn=p_msisdn;
--	commit;
		SELECT CONCAT('i2222222222211111111111111');		
	 end if;
	SET p_status=5;

               insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,now(),p_rbt,p_int,5,p_date,'N',p_updatedby,p_id,1);
 	SET p_status=6;
	-- commit;
		insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,CONCAT('A RBT for Date ',p_date,' is Deleted'),p_subtype,p_int,p_updatedby);
	SET p_status=7;
	-- commit;

COMMIT;
	SELECT CONCAT('p_status',p_status);

END //
DELIMITER ;

