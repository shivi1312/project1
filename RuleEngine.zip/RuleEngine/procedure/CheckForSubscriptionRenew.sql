delimiter //
drop procedure if exists CheckForSubscriptionRenew //
create procedure CheckForSubscriptionRenew(IN p_msisdn varchar(20),IN p_maxsub int,IN p_plan int,OUT p_status int)
ISDONE:BEGIN
declare l_temp	int;
declare l_status varchar(20);
declare l_last_charged date;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=p_status=-1;

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;

	set p_status=1;

	set l_temp=0;
--      select to_number(param_value) into l_temp from crbt_app_config_params where param_tag like 'WHITELIST_ENABLE';   done by shambhavi 15-09-2016
	select cast(param_value AS UNSIGNED)  into l_temp from crbt_app_config_params where param_tag='WHITELIST_ENABLE';
	if l_temp = 1 then
		select count(*) into l_temp from crbt_whitelist where cast(STARTS_AT AS UNSIGNED) <=cast(p_msisdn AS UNSIGNED) and cast(ENDS_AT AS UNSIGNED) >=cast(p_msisdn AS UNSIGNED);
		if l_temp = 0 then
			set p_status=-25;
			LEAVE ISDONE;
		end if;
	end if;

--      select count(msisdn) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status != 'D';  done by shambhavi 15-09-2016
	set l_temp=0;
	select count(msisdn) into l_temp from crbt_subscriber_master where status='A';
	if l_temp > p_maxsub
	then
		set p_status=-21;
		LEAVE ISDONE;
	end if;

	set l_temp=0;

	select count(range_id) into l_temp from OPERATOR_SUBSCRIBER where (cast(STARTS_AT AS UNSIGNED) <= cast(p_msisdn AS UNSIGNED) and cast(ENDS_AT AS UNSIGNED) >= cast(p_msisdn AS UNSIGNED) and p_msisdn not in (select EXCLUDE_NUM from OPERATOR_SUBSCRIBER_EXCLUDE)) or p_msisdn in ( select INCLUDE_NUM from OPERATOR_SUBSCRIBER_INCLUDE);
	select concat( 'in procedure subscriber msisdn===' , p_msisdn);
	select concat( 'in procedure subscriber l_temp===' , l_temp);

	if l_temp=0
	then
		set p_status=-22;
		LEAVE ISDONE;
	end if;


	select status,plan_indicator,last_charged into l_status,l_temp,l_last_charged from crbt_subscriber_master where msisdn=p_msisdn;
	if l_temp is not null
	then

		if l_temp != p_plan  and p_plan!=-1 then
			set p_status=-33;                  -- person is already subscribe with different plan
		elseif l_status = 'I' then
			set p_status=-40;
		elseif l_status='A' and datediff(l_last_charged, (date(now())-interval 30 day)) >2 then 
			set p_status=-58 ;
		else
			set p_status=-20 ;
		end if;
	else
		set p_status=1002;
	end if;
	SELECT CONCAT('p_status ',p_status);
End //

