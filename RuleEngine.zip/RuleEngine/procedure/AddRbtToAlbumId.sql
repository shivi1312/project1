DELIMITER //
drop procedure if exists AddRbtToAlbumId //
 create Procedure AddRbtToAlbumId (IN p_msisdn  varchar(20),IN p_int  varchar(20), IN p_updatedby  varchar(20),IN p_subtype  varchar(20),IN p_rbt  int,IN p_wltid  int,IN p_chgdone  int,IN p_refid  varchar(20),IN p_chgcode  int,IN p_validityDays  int,IN p_packId  int,OUT p_status  int,OUT p_id  int)
ISDONE:BEGIN
declare l_temp          int;
declare l_pre_amount  int;
declare l_post_amount  int;
declare l_final_amount int;
declare l_totalRbt int;
declare l_freeRbt int;
declare l_isSystemRbtBased int;

declare v_finished int;
DECLARE done INT DEFAULT FALSE;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING

BEGIN
#               DECLARE EXIT HANDLER FOR SQLEXCEPTION
                GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
		ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;
                  set p_status=-1;

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
		SELECT CONCAT('p_status ',p_status);
END;
 START TRANSACTION;

       set  p_status=1;
       set  l_freeRbt=0;
       set  l_totalRbt=0;
        if p_chgdone = 2
        then
            call AddFreeRbtToAlbId(p_msisdn,p_int,p_updatedby,p_subtype,p_rbt,p_wltid,p_chgcode,p_status,p_id);
        select concat('done AddRbtToAlbId 1');
                LEAVE ISDONE;
        end if;
        select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
        if p_subtype = 'O' then
                set l_final_amount=l_post_amount;
        else
                set l_final_amount=l_pre_amount;
        end if;

        select concat('done AddRbtToAlbId 2');
--         select max(cdr_id+1)  into p_id from crbt_event_cdr;
--        insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,tariff_id,amount,action) values (p_id,p_msisdn,p_int,NOW(),1,'N',p_rbt,p_subtype,p_refid,p_chgcode,l_final_amount,'R');
	insert into crbt_event_cdr (msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,tariff_id,amount,action) values (p_msisdn,p_int,NOW(),1,'N',p_rbt,p_subtype,p_refid,p_chgcode,l_final_amount,'R');
	SET p_id=LAST_INSERT_ID();
         set p_status=2;
select concat('done AddRbtToAlbId 3');
         set p_status=4;
        select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
        if l_isSystemRbtBased=1 then
                insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,expiry_date) values (p_wltid,p_rbt,((now() - interval 30 day)+ interval p_validityDays day),p_msisdn,now()+ interval p_validityDays day);
        else
                insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,expiry_date) values (p_wltid,p_rbt,now(),p_msisdn,now()+ interval p_validityDays day);
        end if;
--        commit;
        set p_status=5;
        select concat('done AddRbtToAlbId 4');
        if p_packId > 0 then
                select TOTAL_RBT,FREE_RBT into l_totalRbt,l_freeRbt from crbt_pack_master where MSISDN=p_msisdn and PACK_ID=p_packId and status='A';
                if l_totalRbt > 0 then
                        update crbt_pack_master set TOTAL_RBT=TOTAL_RBT-1 where MSISDN=p_msisdn and PACK_ID=p_packId;
                elseif l_freeRbt > 0 then
                        update crbt_pack_master set FREE_RBT=FREE_RBT-1 where MSISDN=p_msisdn and PACK_ID=p_packId;
                end if;
  --              commit;
        end if;
        select concat('done AddRbtToAlbId 5');
        select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
        if l_isSystemRbtBased=1 then
                update crbt_subscriber_master set last_charged=((now()- interval 30 day)+ interval p_validityDays day), expiry_date=now()+ interval p_validityDays day, update_time=now() where msisdn=p_msisdn and last_charged<=((now()- interval 30 day)+ interval p_validityDays day);
    --            commit;
        end if;
        insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_int,p_rbt,p_wltid,4,'Y',p_updatedby,p_id);
      --  commit;
        select concat('done AddRbtToAlbId 6');
        set p_status=6;
        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),0,concat('RBT Added To Album ',p_wltid),p_subtype,p_int,p_updatedby);
       -- commit;
        set p_status=7;
select concat('done AddRbtToAlbId 7');
        update crbt_rbt set rbt_score=rbt_score+1 where rbt_code=p_rbt;
       -- commit;
        set p_status=8;
        select concat('done AddRbtToAlbId 8');
	commit;
	SELECT CONCAT('p_i ',p_id, ' p_status ',p_status);
END //









