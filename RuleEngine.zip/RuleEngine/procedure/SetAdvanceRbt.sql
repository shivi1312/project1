DELIMITER //
DROP PROCEDURE IF EXISTS SetAdvanceRbt //
CREATE PROCEDURE   SetAdvanceRbt (IN p_msisdn  varchar(20),IN p_int  varchar(20),IN p_updatedby  varchar(20),IN p_subtype  varchar(20),IN p_advop  varchar(20),IN p_fmsisdn  varchar(20),IN p_opfor  int,OUT p_status  int)
ISDONE:BEGIN
declare    l_temp                   int ;
declare    l_ctrlid                int;
declare    l_catid varchar(10);
declare    p_id int;

declare cont int;
declare v_finished int;
DECLARE done INT DEFAULT FALSE;

declare    cursor_spl_ctrl_cat_id cursor  for  select param_value from crbt_app_config_params where param_tag='SPECIAL_CONTROL_CATID';

declare  cursor_sel_ctrl_code cursor  for  select control_id from crbt_rbt_control where cat_id=l_catid and control_name=upper(p_advop);
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING

BEGIN
#               DECLARE EXIT HANDLER FOR SQLEXCEPTION
                GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
		ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
		SELECT CONCAT('p_status ',p_status);
       END;
 START TRANSACTION;
SET p_status=1;
                                open cursor_spl_ctrl_cat_id ;
                                fetch cursor_spl_ctrl_cat_id into l_catid;
                                if v_finished = 1
                                then
                                                    close cursor_spl_ctrl_cat_id;
                                                    set p_status=-10;
                                                    LEAVE ISDONE;
                                else
                                                    close cursor_spl_ctrl_cat_id;
                                end if;

                                open cursor_sel_ctrl_code ;
                                fetch cursor_sel_ctrl_code into l_ctrlid;
                                if  v_finished = 1
                                then
                                                     close cursor_sel_ctrl_code;
                                                     set p_status=-11;
                                                     LEAVE ISDONE;
                                else
                                                     close cursor_sel_ctrl_code;
                               end if;

                                if p_opfor = 1
                                then
                                		update crbt_subscriber_master set rbt_code=l_ctrlid where msisdn=p_msisdn;
		                              # commit;
                                elseif p_opfor = 2
                                then

                   		              set l_temp=0;
                                	      select count(*) into l_temp from crbt_friend_detail where msisdn=p_msisdn and friend_msisdn=p_fmsisdn;
                                              if l_temp = 0
                                                 then
                                                 select concat( ' friend not exist crbt_friend_detail ' );

						insert into crbt_friend_detail (msisdn,friend_msisdn,friend_setting_string,control_rbt_code) values (p_msisdn,p_fmsisdn,'000000000000000000000000000000000000000000000000000000000000',l_ctrlid);
								
						--		commit;

						insert into crbt_friend_op_log (msisdn,subscriber_type,event_time,interface_type,op_code,friend_msisdn,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_int,1,p_fmsisdn,'N',p_updatedby,0);
						--	commit;
						insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('A Friend ',p_fmsisdn,' is Added'),p_subtype,p_int,p_updatedby);

						--	 commit;

						select concat( 'friend not exist  days inserting in crbt_friend_op_log' );
					#	commit;

                     #RETURN;
                      				else
							update crbt_friend_detail set control_rbt_code=l_ctrlid where msisdn=p_msisdn and friend_msisdn=p_fmsisdn;
					#		commit;
		      				end if;
 
		      	else
				set l_temp=0;
                    		select count(*) into l_temp from crbt_group_detail where msisdn=p_msisdn and masked_name=upper(p_fmsisdn);
					if l_temp = 0
			 		then
				 	set     p_status=-13;
					LEAVE ISDONE;
		 			else
			 			update crbt_group_detail set control_rbt_code=l_ctrlid where msisdn=p_msisdn and masked_name=upper(p_fmsisdn);
		-- commit;
					end if;
		    	end if;
				 set   p_id=-1;
				 set   p_status=2;

			insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,now(),l_ctrlid,p_int,6,p_fmsisdn,'N',p_updatedby,p_id,1);
		set   p_status=3;
		-- commit;
		insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('A Advance Setting is done for ',p_fmsisdn),p_subtype,p_int,p_updatedby);
                -- commit;
		 set p_status=4;
		COMMIT;
		SELECT CONCAT('p_status ',p_status);
        End //
