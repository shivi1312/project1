delimiter //
drop procedure if exists CheckTempRbt //
create Procedure CheckTempRbt(IN p_msisdn  varchar(20),IN p_int  varchar(20),IN p_rbt  int,OUT p_status  int)
isdone:begin
declare l_temp int;
declare l_rbt int;
declare l_temprbt int;
declare l_cpCode int;
declare l_rbtCount int;
declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, ") ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;

set  p_status=1;
set l_temprbt=p_rbt;
        set l_temp=0;
        select  count(*) into l_temp from map_logs where o_rbt=p_rbt;
        set p_status=2;

        if l_temp = 0 then
                LEAVE ISDONE;
        else
                select n_rbt into l_rbt from map_logs where  o_rbt=p_rbt;
        end if;

                set p_status=3;
        select count(*) into l_temp from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbt;
        if l_temp = 1  then
                LEAVE ISDONE;
        end if;
                        set p_status=4;
        select count(*) into l_temp from crbt_wallet_content where msisdn =p_msisdn and rbt_code=l_rbt;
        if l_temp=1 then
                set p_rbt=l_rbt;
                LEAVE ISDONE;
        end if;


                if p_int in ('S','W','C') then
                set p_status=10;
#        --LEAVE ISDONE;
        end if;

        set p_status=5;
        select count(*) into   l_temp from crbt_logging_count where cp_code in (select content_provider_code from crbt_rbt where rbt_code=p_rbt);
        if l_temp=0 then
                LEAVE ISDONE;
        end if;

        select current_count,rbt_count,cp_code into l_temp,l_rbtCount,l_cpCode from crbt_logging_count where cp_code in (select content_provider_code from crbt_rbt where rbt_code=p_rbt);
        if l_temp=l_rbtCount then
                set p_rbt=l_rbt;
                set p_status=6;
                else
                set p_status=7;
        end if;
if      l_temp >=l_rbtCount then
        update crbt_logging_count set current_count=0 where  cp_code in (select content_provider_code from crbt_rbt where rbt_code=l_temprbt);
                set p_status=8;
      --  commit;
else

        update crbt_logging_count set current_count=current_count+1 where  cp_code in (select content_provider_code from crbt_rbt where rbt_code=l_temprbt);
                set p_status=9;
      --  commit;
end if;
	commit;

	SELECT  CONCAT('p_status ',p_status);

end //

