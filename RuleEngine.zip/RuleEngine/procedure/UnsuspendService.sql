delimiter //
drop procedure if exists UnsuspendService //
create Procedure UnsuspendService(IN p_msisdn  varchar(20),IN p_int  varchar(20),IN p_updatedby  varchar(20),IN p_subtype  varchar(20),OUT p_status  int,OUT p_id  int)
isdone:begin
declare cont int;
declare l_temp int;
declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, ") ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;

       set  l_temp=0;
       set  p_status=1;
       set  p_id=1;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status='S';
        if l_temp = 0 then
                set p_status=-31;
                LEAVE ISDONE;
        else
                select param_value into l_temp from crbt_app_config_params where param_tag='ADD_DAYS_ON_UNSUSPENSION';
                if l_temp = 1 then
                        update crbt_subscriber_master set status='A', expiry_date=(now() + (now() -  update_time)) where msisdn=p_msisdn;
                        commit;
                        set p_status=2;
                else
                        update crbt_subscriber_master set status='A' where msisdn=p_msisdn;
                        commit;
                        set p_status=3;
                end if;
                update crbt_subscriber_master set update_time=now() where msisdn=p_msisdn;
 --               commit;
                set p_status=4;
                insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),'US',p_int,'N',p_updatedby,1);
   --             commit;
                set p_status=5;
                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,'UNSUSPENDED',p_subtype,p_int,p_updatedby);
                commit;
                set p_status=6;
        end if;
	SELECT CONCAT('p_status ',p_status);
end //

