delimiter //
drop procedure if exists GenerateCrbtCdrs //
create procedure GenerateCrbtCdrs ( IN p_msisdn varchar(20),IN p_chgcode int ,IN p_action int ,IN p_interface varchar(20),IN p_sc int ,IN p_daid int ,IN  p_cdate date  ,p_fmsisdn varchar(20),IN p_rbt int ,IN p_amt int ,IN p_subtype varchar(20),IN p_status varchar(20),OUT p_id  int)

isdone:begin
declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=p_id=-1;

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;
	-- select max(CDR_ID+1)  into p_id from crbt_cdrs;
	select concat("p_cdate ",p_cdate);
	insert into cdr_seq_id (sequence) values (null);
        -- commit;
        set p_id=LAST_INSERT_ID();
        insert into crbt_cdrs (MSISDN,TARIFFID,ACTION,INTERFACE,SERVICE_CLASS,DA_ID,CREATE_DATE,FMSISDN,RBT_CODE,AMOUNT,STATUS,CDR_ID ) values (p_msisdn,p_chgcode,p_action,p_interface,p_sc,p_daid,p_cdate,p_fmsisdn,p_rbt,p_amt,'N',p_id);
        -- commit;
        -- select (cdr_id+1)  into p_id from crbt_event_cdr;
        -- insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,TARIFF_ID,amount,RBT_CODE) values (p_id,p_msisdn,p_interface,now(),'R',1,'N',p_subtype,p_chgcode,p_amt,p_rbt);
        insert into crbt_event_cdr (msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,TARIFF_ID,amount,RBT_CODE) values (p_msisdn,p_interface,now(),'R',1,'N',p_subtype,p_chgcode,p_amt,p_rbt);
	set p_id=LAST_INSERT_ID();
        commit;

End //
