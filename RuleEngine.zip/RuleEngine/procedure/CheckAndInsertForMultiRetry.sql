delimiter //
drop procedure if exists CheckAndInsertForMultiRetry //
create procedure CheckAndInsertForMultiRetry(In p_msisdn varchar(20),In p_int varchar(20),In p_subtype varchar(20),In p_rbt  int,IN p_packId  int,IN p_reqId  int, IN p_langId  int, IN p_planId  int, In p_fmsisdn varchar(20),OUT p_status  int)
isdone:begin
declare cont int;
declare l_temp int;
declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, ") ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;


        set p_status=1;
        set l_temp=0;
       # --select count(*) into l_temp from crbt_pending_request where msisdn=p_msisdn and fmsisdn=p_fmsisdn and request_id=p_reqId and status='R';
        select count(*) into l_temp from crbt_pending_request where msisdn=p_msisdn and request_id=p_reqId and status='R';
        if l_temp > 0 then
                set p_status=0;
                LEAVE ISDONE;
        end if;
        if p_reqId = 4 then# ----gift request
                #----will do later
                set p_status=2;
        elseif p_reqId = 3 or p_reqId = 23 then
                select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn;
                if l_temp = 0 then
                        insert into crbt_pending_request(MSISDN,RBT_CODE,REQUEST_ID,REQUEST_TIME,SUB_TYPE,STATUS,LANGUAGE_ID,PLAN_INDICATOR,INTERFACE_USED,FMSISDN,RETRY_COUNT,FILE_PATH,CREATE_DATE) values(p_msisdn,0,27,now() + interval 2 minute,p_subtype,'R',p_langId,p_planId,p_int,p_fmsisdn,0,'NA',now());
                        -- commit;
                         set p_status=3;
                end if;
                insert into crbt_pending_request (MSISDN,RBT_CODE,REQUEST_ID,REQUEST_TIME,SUB_TYPE,STATUS,LANGUAGE_ID,PLAN_INDICATOR,INTERFACE_USED,FMSISDN,RETRY_COUNT,FILE_PATH,CREATE_DATE) values(p_msisdn,p_rbt,3,now() + interval 3 minute,p_subtype,'R',p_langId,p_planId,p_int,p_fmsisdn,0,'NA',now());
        -- commit;
                set p_status=4;
        end if;
        set p_status=5;
	commit;
SELECT CONCAT('p_status ',p_status);
end //

