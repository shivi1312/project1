DELIMITER // 
drop procedure if exists GiftRbt  //
create procedure GiftRbt ( IN p_msisdn  varchar(20),IN p_int  varchar(20),IN p_updatedby  varchar(20),IN p_subtype  varchar(20),IN p_rbt int, IN p_fmsisdn  varchar(20),IN p_validityDays  int,IN p_chgdone  int,IN p_refid  varchar(20),IN p_packId  int,IN p_chgcode  int,OUT p_status  int)
ISDONE:BEGIN
declare l_temp          int;
declare p_id int;
declare l_isSystemRbtBased int;
declare l_pre_amount  int;
declare l_post_amount  int;
declare l_final_amount int;
declare l_totalGift int;
declare l_freeGift int;
declare l_subStatus varchar(3);
declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING

BEGIN
#               DECLARE EXIT HANDLER FOR SQLEXCEPTION
                GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
	 	ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));
               SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';

       END;
 START TRANSACTION;


       set  l_subStatus='A';
       set  l_totalGift=0;
       set  l_freeGift=0;
       set  p_status=1;
       select concat('p_status-- ',p_status);
if p_chgdone = 2
        then
                call GiftFreeRbt(p_msisdn,p_int,p_updatedby,p_subtype,p_rbt,p_fmsisdn,p_chgcode,p_validityDays,p_status);
                LEAVE ISDONE;
        end if;
       	set  p_status=1;
        select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
        if p_subtype = 'O' then
                set l_final_amount=l_post_amount;
        else
                set l_final_amount=l_pre_amount;
        end if;
       -- select max(cdr_id+1) into p_id from crbt_event_cdr;
        set p_status=2;
--       insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,remarks,tariff_id,amount,action) values (p_id,p_msisdn,p_int,now(),1,'N',p_rbt,p_subtype,p_refid,p_fmsisdn,p_chgcode,l_final_amount,'G');
	insert into crbt_event_cdr (msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,remarks,tariff_id,amount,action) values (p_msisdn,p_int,now(),1,'N',p_rbt,p_subtype,p_refid,p_fmsisdn,p_chgcode,l_final_amount,'G');
	SET p_id=LAST_INSERT_ID();
        set p_status=3;
       -- commit;
        select concat('p_status-- ', p_status,'---MSISDN---',p_fmsisdn);

        select wallet_id into l_temp from crbt_wallet_master where msisdn=p_fmsisdn and wallet_name='DEFAULT';
        set p_status=4;
        select concat('p_status-- ',p_status);
        select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
        if l_isSystemRbtBased=1 then
          insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,is_rbt_gifted,expiry_date,fmsisdn) values (l_temp,p_rbt,((now()- interval 30 day)+ interval p_validityDays day),p_fmsisdn,1,now()+ interval p_validityDays day,p_msisdn);
        else
          insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,is_rbt_gifted,expiry_date,fmsisdn) values (l_temp,p_rbt,now(),p_fmsisdn,1,now()+ interval p_validityDays day,p_msisdn);
        end if;
       -- commit;
        if p_packId > 0 then
                select TOTAL_GIFT,FREE_GIFT into l_totalGift,l_freeGift from crbt_promo_user_detail where msisdn=p_msisdn and PROMO_ID=p_packId and status='A';
                if l_totalGift > 0 then
                        update crbt_promo_user_detail set TOTAL_GIFT=TOTAL_GIFT-1 where msisdn=p_msisdn and PROMO_ID=p_packId and status='A';
                elseif l_freeGift > 0 then
                        update crbt_promo_user_detail  set FREE_GIFT=FREE_GIFT-1 where msisdn=p_msisdn and PROMO_ID=p_packId and status='A';
                end if;
              --  commit;
        end if;
        set p_status=5;

        select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
        if l_isSystemRbtBased=1 then
          update crbt_subscriber_master set last_charged=((now() - interval 30 day)+ interval p_validityDays day ),expiry_date=now()+ interval p_validityDays day , update_time=now() where msisdn=p_fmsisdn and last_charged<=((now() - interval 30 day)+ interval p_validityDays day);
              --  commit;
        end if;


        insert into crbt_rbt_gift_log (msisdn,subscriber_type,event_time,interface_type,op_code,friend_msisdn,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_int,1,p_fmsisdn,'Y',p_updatedby,p_id);
        set p_status=6;
      --  commit;
        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),0,concat('A RBT is Gifted to Friend ',p_fmsisdn),p_subtype,p_int,p_updatedby);
        set p_status=7;
      --  commit;
        select count(*) into l_temp from crbt_app_config_params where param_tag='GIFT_CONFIRM_ENABLE';
        if l_temp = 1 then
                select CAST(param_value AS UNSIGNED) into l_temp from crbt_app_config_params where param_tag='GIFT_CONFIRM_ENABLE';
                if l_temp = 1 then
                        select count(*) into l_temp from gift_pending_request where fmsisdn=p_fmsisdn and rbt_code=p_rbt;
                        if l_temp >= 1 then
                                 -- select fmsisdn_sub_status into l_subStatus from  gift_pending_request where fmsisdn=p_fmsisdn and rbt_code=p_rbt and rownum<2;
                                 select fmsisdn_sub_status into l_subStatus from  gift_pending_request where fmsisdn=p_fmsisdn and rbt_code=p_rbt limit 2;
                                if l_subStatus = 'D' then
                                        call SetDefaultRbt(p_fmsisdn,p_int,p_updatedby,p_subtype,p_rbt,8,2500,2500,3,p_refid,p_chgcode,p_validityDays,p_packId,p_status,p_id);

                                end if;
                                set p_status=8;
                                delete from gift_pending_request where fmsisdn=p_fmsisdn and rbt_code=p_rbt;
        --                        commit;
                                set p_status=9;
                        end if;
                else
                set l_temp=-1;
           --     select count(*) into l_temp from crbt_subscriber_master where msisdn=p_fmsisdn and rbt_code=0 and date_format(date_registered,'%Y-%m-%d')=date_format(now(),'%Y-%m-%d');
		select count(*) into l_temp from crbt_subscriber_master where msisdn=p_fmsisdn and rbt_code=0 and date_format(date_registered,'%Y-%m-%d %H:%i:%s')=date_format(now(),'%Y-%m-%d %H:%i:%s');
                set p_status=8;
              		if l_temp > 0 then
                                       call  SetDefaultRbt(p_fmsisdn,p_int,p_updatedby,p_subtype,p_rbt,8,2500,2500,3,p_refid,p_chgcode,p_validityDays,p_packId,p_status,p_id);

                                        set p_status=9;
	                end if;
        	end if;
        end if;

commit;
End //
                                        
