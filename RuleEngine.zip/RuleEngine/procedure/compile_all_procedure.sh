mysql -usdp -psdp@12345 sdp -h10.168.3.87 < ActivatePromo.sql_bkp
echo "ActivatePromo.sql_bkp"
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < ParseStringToString.sql 
 echo "ParseStringToString.sql"	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SetDefaultRbt.sql 
 echo "SetDefaultRbt.sql"	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckForSubscription.sql 
 echo "CheckForSubscription.sql"
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckAndFindRatePlan.sql 
 echo "CheckAndFindRatePlan.sql"
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckForStatus.sql 
 echo "CheckForStatus.sql"
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < GenerateRBTSettingCDR.sql 
 echo "GenerateRBTSettingCDR.sql"
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < ChangeRatePlan.sql 
 echo "ChangeRatePlan.sql"
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckForGift.sql 
 echo "CheckForGift.sql"
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckRbtCode.sql 
 echo "CheckRbtCode.sql"
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < Subscribe.sql 
 echo "Subscribe.sql"
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < Deactivate.sql 
 echo "Deactivate.sql"	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < AddRbtToAlbumName.sql 
 echo "AddRbtToAlbumName.sql"	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < AddFreeRbtToAlbName.sql 
 echo "AddFreeRbtToAlbName.sql"	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < AddAlbum.sql 
 echo "AddAlbum.sql"	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < FreeSubscribe.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < AddRbtToAlbumId.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SetAdvanceRbt.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < GiftRbt.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SetDefaultWallet.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < GenerateCrbtCdrs.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < AddWallet.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < DeleteDefaultSetting.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < DeleteFriendSetting.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < DeleteGroupSetting.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < DeleteAdvanceSetting.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < DeleteRBT.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < DeleteAlbum.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckForSubscriptionRenew.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < AddRecordedRbt.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < AddFreeRbtToAlbId.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < GiftFreeRbt.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckRenewRbtCode.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < p_blacklist_msisdn.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < PrintVersion.sql_bkp
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < PrintVersion.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SetDefaultFreeRbt.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckForPackSubscription.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < RbtRenewModule.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < PackSubscribe.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckForPackUser.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < PackUpdate.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < FindRatePlan.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < RbtSuspend.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < RbtUnSuspend.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < PendingGiftAccept.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckAndInsertForMultiRetry.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckForSuspension.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < UnsuspendService.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SuspendService.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < StopRbtRenew.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckTempRbt.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < GiftSubscribe.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < UpdateReference.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < updatePendingRequest.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SetSubRenewStatus.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SetFriendWallet.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SetGroupWallet.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < DeleteWallet.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SetDateWallet.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < DeleteGroupWalletSetting.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckForGiftAccept.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < DeleteDateWallet.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < WalletUnSuspend.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckForWalletGift.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < DeleteDefaultWalletSetting.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < DeleteFriendWalletSetting.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < WalletSuspend.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckWalletCode.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckForWalletGiftAccept.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < GiftWallet.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < PendingWalletGiftAccept.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SetAdvanceWallet.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < DeleteAdvanceWalletSetting.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CorpUnsubscribe.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CorpSubscribe.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckForCorpSubscription.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < ActivateNewPromo.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < ValidatePromo.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckForDefaultPromo.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < RbtRenew.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SubscribeAndSetRbt.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckAndSetDefaultPack.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < ParseStringToInt.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SetDateRbt.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < DeleteDateRbt.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < CheckForPromoUser.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SetFriendRbt.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < SetGroupRbt.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < Unsubscribe.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < Activate.sql 
 echo	
mysql -usdp -psdp@12345 sdp -h10.168.3.87 < ActivatePromo.sql 
 echo	

