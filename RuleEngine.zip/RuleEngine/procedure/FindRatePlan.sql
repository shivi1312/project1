delimiter //
drop procedure if exists FindRatePlan //
create procedure FindRatePlan (In p_msisdn varchar(20),IN p_subType varchar(20),IN p_planName varchar(20),OUT p_planId  int,OUT p_status  int)
isdone:begin
declare l_temp int;
declare l_planId int;

declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;

       set  l_temp=0;
       set  p_status=1;
       set  p_planId=-1;
       set  l_planId=-1;

           select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn;
        if l_temp = 1 then
                select plan_indicator into p_planId from crbt_subscriber_master where msisdn=p_msisdn;
                set p_status=2;
		SELECT CONCAT('p_status ',p_status);
                LEAVE ISDONE;
        end if;
	
	SELECT CONCAT('p_status ',p_status);
End //

