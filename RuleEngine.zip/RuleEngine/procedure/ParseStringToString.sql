delimiter //
drop procedure if exists ParseStringToString //
create Procedure ParseStringToString(p_stringToBeParse  varchar(50) , p_stringFromParse  varchar(50) ,OUT p_result  varchar(50),OUT p_status  int)
isdone:begin
declare l_temp int;
declare l_temp1 int;
declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
#               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;

        set l_temp=0;
        set l_temp1=0;
        set p_result='NA';
        set p_status=1;
        set l_temp=locate(p_stringFromParse,p_stringToBeParse,1);
       -- set l_temp=locate(p_stringToBeParse,p_stringFromParse,1);
        set p_status=2;
         select concat('l_temp[',l_temp,'] in ParseString');
        set l_temp1=locate(',',p_stringToBeParse,l_temp);
        -- set l_temp1=locate(p_stringToBeParse,',',l_temp);
        set p_status=3;
        if l_temp1 = 0 then
                select concat('l_temp is 0');
		set l_temp1=length(p_stringToBeParse) - (l_temp+length(p_stringFromParse)-1);		
                -- set l_temp1=length(p_stringFromParse) - (l_temp+length(p_stringToBeParse)-1);
        else
                set l_temp1=l_temp1-(length(p_stringFromParse)+l_temp);
        end if;
        select concat('l_temp1[',l_temp1,'] in ParseString');
	set p_result=substr(p_stringToBeParse,l_temp+length(p_stringFromParse),l_temp1);
        -- set p_result=substr(p_stringFromParse,l_temp+length(p_stringToBeParse),l_temp1);
#        --p_result:=substr(p_stringToBeParse,l_temp+length(p_stringFromParse),l_temp1-(length(p_stringFromParse)+l_temp));
	select concat('p_result',p_result,'p_stringToBeParse[',p_stringToBeParse,'] l_temp+length(p_stringFromParse)[',l_temp+length(p_stringFromParse),'] l_temp1[',l_temp1);
        set p_status=4;
end //
