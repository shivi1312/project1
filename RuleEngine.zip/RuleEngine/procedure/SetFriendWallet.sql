delimiter //
drop procedure if exists SetFriendWallet //
create procedure SetFriendWallet(IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_sys_wallet_id int,IN p_days varchar(20),IN p_sttime int,IN p_entime int,IN p_chgdone int,IN p_fmsisdn varchar(20),IN p_refid varchar(20),IN p_chgcode int,IN p_validityDays int,IN p_packId int,IN p_type int,OUT p_status int,OUT p_id int)

ISDONE:BEGIN
declare l_temp	int;
declare l_length int;
declare l_char varchar (1);
declare l_index int;
declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
		ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=-1;

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';

       END;
 START TRANSACTION;

	set p_status=1;
	set p_id=-1;
	call AddWallet(p_msisdn,p_int,p_updatedby,p_subtype,p_sys_wallet_id,p_chgdone,p_refid,p_chgcode,p_validityDays,p_packId,p_type,p_status,l_temp);
	if p_status < 0
	then
		set p_status=-1;
		LEAVE ISDONE;
	else
		set p_id=l_temp;
	end if;


	set l_temp=0;
	select count(*) into l_temp from crbt_friend_detail where msisdn=p_msisdn and friend_msisdn=p_fmsisdn;
	if l_temp = 0 then
		if p_days = 8 AND p_sttime = 2500 AND p_entime = 2500
		then
			select concat( ' friend not exist crbt_friend_detail ' );
			insert into crbt_friend_detail (msisdn,friend_msisdn,friend_setting_string) values (p_msisdn,p_fmsisdn,'800000000000000000000000000000000000000000000000000000000000');
			set p_status=3;
		else
			insert into crbt_friend_detail (msisdn,friend_msisdn,friend_setting_string) values (p_msisdn,p_fmsisdn,'000000000000000000000000000000000000000000000000000000000000');
		end if;
	--	commit;
		-- insert into crbt_friend_setting (msisdn,friend_msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_fmsisdn,p_days,p_sttime,p_entime,p_sys_wallet_id,now());
		insert into crbt_friend_op_log (msisdn,subscriber_type,event_time,interface_type,op_code,friend_msisdn,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_int,1,p_fmsisdn,'N',p_updatedby,p_id);
	--	commit;
		insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('A Friend ',p_fmsisdn,' is Added'),p_subtype,p_int,p_updatedby);

	--	commit;

		select concat( 'friend not exist  days inserting in crbt_friend_op_log' );
	--	commit;
	end if;
	set l_temp=0;
	if p_days = 8
	then
		select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
		if l_temp = 0 then
			insert into crbt_friend_setting (msisdn,friend_msisdn,day,start_at,ends_at,rbt_code,update_time,content_type) values (p_msisdn,p_fmsisdn,p_days,p_sttime,p_entime,p_sys_wallet_id,now(),p_type);
	--		commit;
			select concat( 'days 8 crbt_friend setting' );
			if p_status != 3
			then
				set p_status=2;
			end if;
		else
			update crbt_friend_setting set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
			select concat( 'days 8 update crbt_friend setting' );
	--		commit;
		end if;

	else
		set l_length=LENGTH(p_days);
		IF l_length > 0
		THEN
			SET l_index = 1;
			WHILE l_index <= l_total_number do
#			FOR l_index IN 1 .. l_length
#                       LOOP
				select concat( 'in loop index ',l_index );
				set l_char = SUBSTR(p_days,l_index, 1);
				select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;

				if l_temp = 0 then
					select concat( 'before insert in crbt_friend_settingin loop index ',l_index );

					insert into crbt_friend_setting (msisdn,friend_msisdn,day,start_at,ends_at,rbt_code,update_time,LAST_CHARGED,content_type) values (p_msisdn,p_fmsisdn,l_char,p_sttime,p_entime,p_sys_wallet_id,now(),now(),p_type);

	--				commit;
					select concat( 'after insert in crbt_friend_settingin loop index ',l_index );

					set p_status=2;
				else
					select concat( 'before update in crbt_friend_settingin loop index ',l_index );
					
					update crbt_friend_setting set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;

	--				commit;

				end if;
			SET l_index= l_index+1;
			END WHILE;
#			END LOOP;
		END IF;
	end if;
	insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,now(),p_sys_wallet_id,p_int,1,p_fmsisdn,'N',p_updatedby,p_id,1);
--	commit;
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('A Wallet ',p_sys_wallet_id, ' For Friend ',p_fmsisdn,' is Set'),p_subtype,p_int,p_updatedby);
	commit;

	select concat( 'after inserting in crbt_rbt_op_log p_status ',p_status  );
End //
#delimiter

