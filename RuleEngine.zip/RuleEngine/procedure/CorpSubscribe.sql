DELIMITER //
drop procedure if exists CorpSubscribe //

CREATE PROCEDURE CorpSubscribe(IN p_msisdn varchar(20),IN p_plan int,IN p_lang int,IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_pin varchar(20),IN p_refid varchar(20),IN p_chgcode int,IN p_validityDays int,IN p_isPackSubscriber int,IN p_corpId bigint,IN p_corpName varchar(20),IN p_imsi varchar(20),IN p_rbtCode int,IN p_passwd varchar(20),IN p_day int,IN p_startTime int,IN p_endTime int,OUT p_status int,OUT p_id int)
ISDONE:BEGIN

DECLARE l_wltid int;
DECLARE l_temp int;
DECLARE l_pre_amount  int;
DECLARE l_post_amount  int;
DECLARE l_final_amount int;
DECLARE l_isSystemRbtBased int;
DECLARE l_paramValue int;
DECLARE l_packId int;
DECLARE l_isSub int;

DECLARE v_finished int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;
		if p_status > 1 then
                        delete from crbt_event_cdr where cdr_id=p_id;
                        commit;
                        delete from crbt_subscriber_master where msisdn=p_msisdn;
                        commit;
                        delete from crbt_subscription_log where msisdn=p_msisdn and call_id=p_id;
                        commit;
                end if;
                SET p_status=(p_status*(-1));

                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
        # SELECT p_status;
END;

START TRANSACTION;
	SET p_status=1;
        SET p_id=-1;
        select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
        if p_subtype = 'O' then
               SET  l_final_amount=l_post_amount;
        else
                SET l_final_amount=l_pre_amount;
        end if;
        SET p_status=2;

        /*select SCDR_ID.nextval into p_id from dual;*/
        insert into crbt_event_cdr (msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount) values (p_msisdn,'T',now(),'S',p_plan,'N',p_subtype,p_refid,p_chgcode,l_final_amount);
        SET p_status=3;
--        commit;
	
	SET p_id=LAST_INSERT_ID();

	insert into crbt_subscriber_master (msisdn,status,plan_indicator,rbt_code,password,tpin,language,sub_type,last_charged,expiry_date,IMSI, CORP_ID,IS_MONTHLY_CHARGEABLE,CORP_EXPIRY) values (p_msisdn,'A',p_plan,p_rbtCode,p_passwd,p_pin,p_lang,p_subtype,((now()- interval 30 day)+ interval p_validityDays day), now()+ interval p_validityDays day,p_imsi,p_corpId,'Y',now()+ interval p_validityDays day);
        SET p_status=4;
  --      commit;

        /*select wallet_id_seq.nextval into l_wltid from dual;
        insert into crbt_wallet_master (msisdn,wallet_id,create_date,wallet_name,ivr_name)      values (p_msisdn,l_wltid,now(),'DEFAULT',0);*/
	insert into crbt_wallet_master (msisdn,create_date,wallet_name,ivr_name) values (p_msisdn,now(),'DEFAULT',0);
        SET p_status=5;
    --    commit;
	
	SET l_wltid=LAST_INSERT_ID();
	
        insert into crbt_wallet_content (wallet_id,rbt_code,create_date,is_rbt_gifted,msisdn) values (l_wltid,p_rbtCode,now(),2,p_msisdn);
        SET p_status=6;
      --  commit;

        insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_day,p_startTime,p_endTime,p_rbtCode,now());
        SET p_status=7;
      --  commit;

	insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),'S','T','Y',p_updatedby,p_id);
        SET p_status=8;
    --    commit;

        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,CONCAT('SUBSCRIBED TO CORP:',p_corpName),p_subtype,'T',p_updatedby);
        SET p_status=9;
        commit;

	SELECT CONCAT(p_status);

END //
DELIMITER ;


