DELIMITER //
drop procedure if exists DeleteAdvanceSetting //
create  Procedure DeleteAdvanceSetting (IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_fmsisdn varchar(20),IN p_opfor  int,OUT p_status  int)
ISDONE:BEGIN
declare  l_temp     int ;
declare  p_id int;

declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;

       set p_status=1;
       if p_opfor = 1
               then
 	        select rbt_code into l_temp from crbt_default_detail where msisdn=p_msisdn and day=8 and start_at=2500 and ends_at=2500;
        	 set p_status=2;
              	update crbt_subscriber_master set rbt_code=l_temp where msisdn=p_msisdn;
              	 set p_status=3;
              --  commit;
       elseif  p_opfor = 2
               then
               set      l_temp=0;
               select count(*) into l_temp from crbt_friend_detail where msisdn=p_msisdn and friend_msisdn=p_fmsisdn;
               set p_status=4;
               	if l_temp=0
              	 then
              	 set  p_status=-12;
              	 LEAVE ISDONE;
               else
               	update crbt_friend_detail set control_rbt_code=0 where msisdn=p_msisdn and friend_msisdn=p_fmsisdn;
               	set p_status=5;
               --	commit;
               end if;
      else
               set l_temp=0;
               select count(*) into l_temp from crbt_group_detail where msisdn=p_msisdn and upper(masked_name)=upper(p_fmsisdn);
               set p_status=6;
               if l_temp = 0
               	then
               	set p_status=-13;
               LEAVE ISDONE;
   		 else
              	 update crbt_group_detail set control_rbt_code=0 where msisdn=p_msisdn and upper(masked_name)=upper(p_fmsisdn);
              	 set p_status=7;
              --	 commit;
              	 end if;
     end if;
               insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,now(),0,p_int,7,p_fmsisdn,'N',p_updatedby,-1,1);
               set p_status=8;
    --           commit;
               insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('A Advanced Profile For ',p_fmsisdn,' is Deleted'),p_subtype,p_int,p_updatedby);
      --         commit;
               set p_status=9;
               commit;
	
	SELECT CONCAT('p_status',p_status);

END // 
