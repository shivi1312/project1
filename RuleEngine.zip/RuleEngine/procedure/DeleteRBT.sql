DELIMITER //
DROP PROCEDURE IF  EXISTS DeleteRBT //
CREATE Procedure DeleteRBT (In p_msisdn  varchar(20),In p_int  varchar(20),In p_updatedby  varchar(20),In p_subtype  varchar(20),In p_rbt  int,OUT p_status  int,OUT p_updatecode  int,OUT p_filePath  varchar(20)) 
isdone:BEGIN
DECLARE l_temp          int ;
DECLARE l_cnt           int ;
DECLARE l_wltid         int ;

DECLARE chk_recorded varchar(50);
declare cont int;

declare v_finished int;
declare   sel_wlt_id cursor for  select wallet_id from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbt;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;

                    set  p_status=1;
                    set  l_temp=0;
                    set  l_cnt=0;
                    set  p_updatecode=0;
                    set  p_filePath='NA';
                         open sel_wlt_id;
                         fetch sel_wlt_id into l_wltid;
                         if v_finished = 1
                         then
                         close sel_wlt_id;
                    set  p_status=-17;
                         LEAVE ISDONE;
                         else
                         close sel_wlt_id;
                         end if;

                         select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_rbt;
                    set  p_status=2;
                         if l_temp = 0
                         then
                    set   p_updatecode=0;        -- no need to update default setting string
                         else
                         select count(*) into l_cnt from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_rbt and day=8 and start_at=2500 and ends_at=2500;
                    set  p_status=3;
                         if l_cnt = 0
                         then
                    set  p_updatecode=1; -- default setting will not be effected but default string needs to be updated
                         else
                         update crbt_default_detail set rbt_code=0 where msisdn=p_msisdn and day=8 and start_at=2500 and ends_at=2500;
                        -- commit;
                    set  p_status=4;
                         update crbt_subscriber_master set rbt_code=0 where msisdn=p_msisdn;
                        -- commit;
                    set  p_status=5;
			#	if user has more than one settings for this string only then string will be updated
                        if l_temp > 1
                        then
                    set p_updatecode=1;
                        end if;
                end if;
        end if;

                   set  l_temp=0;
                        select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and rbt_code=p_rbt;
                   set  p_status=6;
                        if l_temp > 0
                        then
                   set  p_updatecode=(p_updatecode + 2);
                        end if;

                   set  l_temp=0;
                        select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and rbt_code=p_rbt;
                   set  p_status=7;
                        if l_temp > 0
                        then
                   set  p_updatecode=(p_updatecode + 4);
                        end if;
                        select masked_name into chk_recorded from crbt_rbt where rbt_code=p_rbt;
                   set  p_status=8;

                        if chk_recorded = 'RECORDED' then
                        delete from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbt;
                        delete from crbt_rbt_owner where rbt_code=p_rbt and msisdn=p_msisdn;
                        delete from crbt_rbt where rbt_code=p_rbt;
                        -- commit;
                    set p_status:=9;
                        insert into crbt_rbt_record_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_rbt,'I',2,'N',p_msisdn,-1);
                      --  commit;
                   set  p_status=10;
                        else

#-----------------added by pankaj gupta for system default album starts----------------------
                   set  l_temp=-1;
                        select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and rbt_code=0 and content_type=0;
                   set  p_status=11;
                        if l_temp > 0 then
                        delete from  crbt_default_detail where msisdn=p_msisdn and rbt_code=p_rbt and content_type=0;
                      --  commit;
                   set  p_status=12;
                        end if;

                   set  l_temp=-1;
                        select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and rbt_code=0 and content_type=0;
                   set  p_status=13;
                        if l_temp > 0 then
                        delete from  crbt_group_setting where msisdn=p_msisdn and rbt_code=p_rbt and content_type=0;
                       -- commit;
                   set p_status=14;
                        end if;

                   set l_temp=-1;
                       select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and rbt_code=0 and content_type=0;
                   set p_status=15;
                       if l_temp > 0 then
                       delete from  crbt_friend_setting where msisdn=p_msisdn and rbt_code=p_rbt and content_type=0;
                     --  commit;
                   set p_status=16;
end if;

                   set l_temp=-1;
                      select count(*) into l_temp from crbt_eventdate_rbt where msisdn=p_msisdn and rbt_code=0 and content_type=0;
                   set p_status=17;
                       if l_temp > 0 then
                      delete from  crbt_eventdate_rbt where msisdn=p_msisdn and rbt_code=p_rbt and content_type=0;
                    --  commit;
                   set   p_status=18;
end if;

#-added by pankaj gupta for system default album ends----------------------
                      delete from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbt;
                    --  commit;
                   set   p_status=19;
                         end if;
                      insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_int,p_rbt,l_temp,5,'N',p_updatedby,-1);
                    --  commit;
                   set p_status=20;
                      insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('A RBT ',p_rbt, 'is Deleted from Album'),p_subtype,p_int,p_updatedby);
                    --   commit;
                   set     p_status=21;
		commit;
	SELECT CONCAT('p_status ', p_status, ' p_filePath ',p_filePath);
END //

