DELIMITER //
DROP PROCEDURE IF EXISTS DeleteGroupSetting //
CREATE PROCEDURE DeleteGroupSetting ( IN  p_msisdn  varchar(20),IN  p_int  varchar(20),IN  p_updatedby  varchar(20),IN p_subtype  varchar(20),IN p_rbt  int,IN p_days  int,IN p_sttime  int,IN p_entime  int,IN p_grp  varchar(20),OUT p_status  int,OUT p_grpid  int)
ISDONE:BEGIN
DECLARE l_length int;
DECLARE l_char varchar (1);

declare cont int;

declare v_finished int;
declare  sel_grp_id cursor  for  select groupid from crbt_group_detail where msisdn=p_msisdn and upper(masked_name)=upper(p_grp);
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;

                          set   p_status=1;
                          set   l_length=0;
                                open sel_grp_id;
                            fetch sel_grp_id into p_grpid;
                            if v_finished = 1
                            then
                                                       close sel_grp_id;
                                                       set p_status=-13;
                                                       LEAVE ISDONE;
                            else
                                                       close sel_grp_id;
                            end if;

if p_days = 8
then
                delete from crbt_group_setting where msisdn=p_msisdn and groupid=p_grpid and rbt_code=p_rbt and day=p_days and start_at=p_sttime and ends_at=p_entime;
            --    commit;
                set p_status=2; #-- this value will be checked in code and string will be updated
else
                set l_length=LENGTH(p_days);
                IF l_length > 0
                THEN
                SET cont = 1;
                WHILE cont <= l_length do
                                                     
                set l_char = SUBSTR(p_days,cont, 1);
                delete from crbt_group_setting where msisdn=p_msisdn and groupid=p_grpid and rbt_code=p_rbt and day=l_char and start_at=p_sttime and ends_at=p_entime;
              --  commit;
                set p_status=3;
                SET cont = cont + 1;
                END WHILE;
             
                END IF;
end if;
 insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,NOW(),p_rbt,p_int,5,p_grpid,'N',p_updatedby,-1,1);
-- commit;
 insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('Setting of group ',p_grp,' is deleted'),p_subtype,p_int,p_updatedby);
 commit;

SELECT CONCAT('p_status ',p_status,' p_grpid ',p_grpid);

END //

