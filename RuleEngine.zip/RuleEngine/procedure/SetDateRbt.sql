DELIMITER //
drop procedure if exists SetDateRbt //
create procedure SetDateRbt  ( IN p_msisdn  varchar(20),IN p_int  varchar(20),IN p_updatedby  varchar(20),IN p_subtype  varchar(20),IN p_rbt  int,IN p_occasion  varchar(20),IN p_chgdone  int,IN p_date  varchar(20),IN p_refid  varchar(20),IN p_chgcode  int,IN p_validityDays  int,IN p_packId  int,OUT p_status  int)
ISDONE:BEGIN

declare     l_temp          int;
declare     p_id int;
declare cont int;
declare v_finished int;
DECLARE done INT DEFAULT FALSE;


DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING

BEGIN
#               DECLARE EXIT HANDLER FOR SQLEXCEPTION
                GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
		ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=-1;

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';

       END;
 START TRANSACTION;

                    set  p_status=1;
                    set   p_id=-1;
                    call AddRbtToAlbumName(p_msisdn,p_int,p_updatedby,p_subtype,p_rbt,'DEFAULT',p_chgdone,p_refid,p_chgcode,p_validityDays,p_packId,p_status,l_temp); 
                    if p_status < 0
                    then
                    #     p_status:=-1;
                          LEAVE ISDONE;
                    else
                          set p_id=l_temp;
                    end if;
                          set p_status=2;
                          set  l_temp=0;
			SELECT CONCAT(p_status,'11111111');
 select count(*) into l_temp from crbt_eventdate_rbt where msisdn=p_msisdn and date_format(event_date,'%d-%m%-%y')=str_to_date(p_date,'%d%m%Y');
--	select count(*) into l_temp from crbt_eventdate_rbt where msisdn=p_msisdn and str_to_date(date_format(event_date,'%d%m%y'),'%d%m%y')=str_to_date(p_date,'%d%m%y');
			SELECT CONCAT(p_status,'i33333333');
                   if l_temp = 0 then
insert into crbt_eventdate_rbt (msisdn,event_date,rbt_code,update_time,occasion_name) values (p_msisdn,str_to_date(p_date,'%d%m%Y'),p_rbt,now(),p_occasion);
                          set p_status=3;
                   else
update crbt_eventdate_rbt set rbt_code=p_rbt,content_type=0 where msisdn=p_msisdn and   date_format(event_date,'%d-%m-%y')=str_to_date(p_date,'%d%m%Y');
                   end if;
--                   commit;
                          set p_status=4;
select concat(p_status,'i211111111111111111');
                   if str_to_date(p_date,'%d%m%Y') = str_to_date(date_format(now(),'%d%m%Y'),'%d%m%Y')
                   then
			update crbt_subscriber_master set date_setting_validity=1 where msisdn=p_msisdn;
			select concat(p_status,'found equal');
--		     	commit;
                   end if;
                          set p_status=5;

 insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,now(),p_rbt,p_int,1,p_date,'N',p_updatedby,p_id,1);
                          set p_status=6;
  --                commit;
insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('A RBT for Date ',p_date,' is set'),p_subtype,p_int,p_updatedby);
                           set p_status=7;
                  commit;
select concat(p_status);
END //


