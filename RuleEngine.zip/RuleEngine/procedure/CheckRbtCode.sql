DELIMITER  //
DROP PROCEDURE IF EXISTS  CheckRbtCode //
CREATE Procedure CheckRbtCode ( IN p_msisdn  varchar(20), IN p_rbtcode  int,OUT  p_status  int,OUT p_chgcode  int,OUT p_catid  int,OUT p_cpid  int)
isdone:BEGIN


DECLARE  l_temp      int ;
DECLARE  l_pv        varchar(10) ;
DECLARE  l_pi        int ;
DECLARE  l_ptag      varchar(50); -- added by Avishkar on 15.01.2020
DECLARE  l_cat       int ;
DECLARE  l_pcat      int ;
DECLARE  l_freecat   int ;
DECLARE  l_freeCp    int ; -- added by Avishkar on 15.01.2020
DECLARE  l_advcat    int ;
DECLARE  l_chgcode   int ;
DECLARE  l_fcenabled int ;
DECLARE  l_diffchgenabled     int ;
DECLARE  l_status    varchar(20);

DECLARE v_finished   int;
declare  cursor_rbt_code cursor for  select rbt_code,cat_id,charging_code,cat_id,content_provider_Code from crbt_rbt where rbt_code=p_rbtcode and (show_in_sms='Y' or show_on_web='Y' or playable='Y') and status!='U' ;

declare cursor_wlt_cnt cursor for select rbt_code,status from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbtcode;
-- declare   cursor_app_config cursor for  select param_value,param_id from crbt_app_config_params where param_tag in ('ADVERTISEMENT_CAT_ID','DIFFERENT_RBT_CHARGING_ENABLED','FREE_RBT_ENABLED','FREE_RBT_CAT_ID','FREE_RBT_CP_ID');
declare   cursor_app_config cursor for  select param_tag,param_value from crbt_app_config_params where param_tag in ('ADVERTISEMENT_CAT_ID','DIFFERENT_RBT_CHARGING_ENABLED','FREE_RBT_ENABLED','FREE_RBT_CAT_ID','FREE_RBT_CP_ID'); -- modified by Avishkar on 15.01.2020
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING

BEGIN
#               DECLARE EXIT HANDLER FOR SQLEXCEPTION
                GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
		ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=-1;

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';

       END;
 START TRANSACTION;

                     set  l_diffchgenabled=-1;
                     set  l_fcenabled=-1;
                     set  l_advcat=-1;
                     set  l_freecat=-1;
		     set  l_freeCp=-1; -- added by Avishkar on 09.01.2020

                     set   l_temp=-1;
                     set   l_pv=-1;
                     set   l_pi=-1;
		     set   l_ptag='NA'; -- added by Avishkar on 15.01.2020
                     set   l_cat=-1;
                     set   l_pcat=-1;
                     set   l_chgcode=-1;

                     set   p_catid=-99;
                     set   p_cpid=-99;
                     set   p_chgcode=-1;
                     set   p_status=0;
                                       open cursor_rbt_code ;
                                       fetch cursor_rbt_code into l_temp,l_cat,l_chgcode,p_catid,p_cpid;
                                        select concat('-----------------cursor1');
                                         if    v_finished = 1
                                                then
                                                  close cursor_rbt_code;
                                                  set p_status=-14;
                                                  LEAVE ISDONE;
                                         else
                                                  close cursor_rbt_code;
                                         end if;







                                         set l_temp=0;
                                         set p_chgcode=l_chgcode;
                                         open cursor_wlt_cnt ;
	                                        fetch cursor_wlt_cnt into l_temp,l_status;

        	                                  select concat('-----------------cursor2');
                                                  if v_finished = 1
                                                      then
							set v_finished=0; -- added by Avishkar on 15.01.2020
                                                      close cursor_wlt_cnt;
                                                      open cursor_app_config ;
                                                      cursor_app_config:LOOP
                                                                set l_temp=0;
                	                                        -- fetch cursor_app_config into l_pv,l_pi;
                	                                        fetch cursor_app_config into l_ptag,l_pv; -- modified by Avishkar on 15.01.2020
			                                        select concat('-----------------cursor3');
                                                                if  v_finished = 1
                                                                    then
                                                                       close cursor_app_config;
                                                                      LEAVE cursor_app_config;
                                                                else

                                                            	       set   l_temp= cast(l_pv AS UNSIGNED) ;
							-- modification start by Avishkar on 15.01.2020
			                                       -- 	select concat('>>>>l_temp  ' , l_temp  , 'l_pi  ' ,l_pi);
									select concat('>>>>l_temp  ' , l_temp  , 'l_ptag  ' , l_ptag);
									if l_ptag = 'ADVERTISEMENT_CAT_ID'
									then
                                                                                set  l_advcat=l_temp;
									elseif l_ptag = 'DIFFERENT_RBT_CHARGING_ENABLED'
									then
                                                                             set   l_diffchgenabled=l_temp;
									elseif l_ptag = 'FREE_RBT_ENABLED'
									then
                                                                                 set   l_fcenabled=l_temp;
									elseif l_ptag = 'FREE_RBT_CAT_ID'
									then
                                                                                 set  l_freecat=l_temp;
									elseif l_ptag = 'FREE_RBT_CP_ID'
									then
                                                                                 set  l_freeCp=l_temp;
									else
                                                                                 set  p_status=-1;
                                                                                 select concat('p_status :[',p_status,']');
                                                                                 close cursor_app_config;
                                                                                 LEAVE ISDONE;
                                                                       end if;


                                                        	/*	if l_pi = 89 --87
                                                        		then
			                                                        set  l_advcat=l_temp;
			                                                elseif l_pi = 132 --104
	        	                                                then
		                   	                                     set   l_diffchgenabled=l_temp;
	                                	                        elseif l_pi = 143 --105
		                                                        then
	                                        	               		 set   l_fcenabled=l_temp;
	                                                	        elseif l_pi = 135 --106
		                                                        then
                		                                	         set  l_freecat=l_temp;
									elseif l_pi = 606 -- this else if added by Avishkar on 09.01.2020
                                                                        then
                                                                                 set  l_freeCp=l_temp;
	                                                        	 else
		                                                        	 set  p_status=-1;
										 select concat('p_status :[',p_status,']');
		        	                                                 close cursor_app_config;
			                                                         LEAVE ISDONE;
                	  				               end if; */

							-- modification ends by Avishkar on 15.01.2020

			                                       end if;
        	        			    end loop cursor_app_config ;

                		                           select concat('l_temp  ' , l_temp);
                                		           if l_advcat = l_cat
		                                           then
 	        		                                  set  p_status=-24;
								  select concat('p_status :[',p_status,']');
                                		                  LEAVE ISDONE;
			                                   end if;


							select concat ('this is new log ',l_fcenabled,l_freeCp);
                		                           if l_fcenabled = 1 and (l_freecat = l_cat OR l_freeCp = p_cpid) -- modified by Avishkar on 15.01.2020
							
                                		           then
		             		                          set p_status=-26;
								  select concat('p_status :[',p_status,']');
                		        	                  LEAVE ISDONE;
                                		           end if;
                                                                                                                                          
		                                    	  if l_diffchgenabled = 1
                		                          then
                                		                      set p_status=-27;
								      select concat('p_status :[',p_status,']');
                                                		      LEAVE ISDONE;
		                                          end if;
                                                   set p_status=-15;
						   select concat('p_status :[',p_status,']');
                        		           LEAVE ISDONE;
                                       else
                                                      close cursor_wlt_cnt;
                                          end if;
                                                     if l_status='I' then
       		                                            set  p_status=-31;
							    select concat('p_status :[',p_status,']');
                                               else
                                                    set      p_status=-7;
							     select concat('p_status :[',p_status,']');
end if;
END //





                                                                        






                                  

                                                                       
