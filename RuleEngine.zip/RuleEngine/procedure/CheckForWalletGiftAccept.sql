DELIMITER //
drop procedure if exists CheckForWalletGiftAccept //

CREATE PROCEDURE CheckForWalletGiftAccept(IN p_msisdn varchar(20),INOUT p_sys_wallet_id  int, IN p_fmsisdn varchar(20),IN p_subType  varchar(20),IN p_interface  varchar(20),IN p_type  int,OUT p_status int)
ISDONE:BEGIN

DECLARE l_temp int;
DECLARE l_fmsisdn varchar(15);
DECLARE l_planId int;
DECLARE l_catid int;
DECLARE l_cpid int;

DECLARE v_finished int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

                set p_status=(p_status*(-1));
                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
         SELECT p_status;
END;

START TRANSACTION;
	SET p_status=5;
        SET l_temp=0;
        if p_sys_wallet_id = -1 then
                select count(*) into l_temp from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(NOW()-interval 1 day) and content_type=p_type;
        else
                select count(*) into l_temp from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(NOW()-interval 1 day) and rbt_code=p_sys_wallet_id and content_type=p_type;
        end if;
                SET p_status=1;
	SELECT concat('p_status ',p_status);

        if l_temp = 0 then
                SET p_status=-54; /*--no wallet to accept*/
                LEAVE ISDONE;
        end if;
                SET p_status=2;
	SELECT concat('p_status ',p_status);
        if p_sys_wallet_id = -1 then
                SET p_status=11;
                select rbt_code,fmsisdn,plan_id into p_sys_wallet_id,l_fmsisdn,l_planId from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(NOW()-interval 1 day) and content_type=p_type and REQUEST_TIME=(select max(REQUEST_TIME) from  GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and content_type=p_type);
	else
                SET p_status=14;
                select fmsisdn,plan_id into l_fmsisdn,l_planId from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and content_type=p_type and REQUEST_TIME>=(NOW()- interval 1 day) and REQUEST_TIME=(select max(REQUEST_TIME) from  GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type);
        end if;
	SELECT concat('p_status ',p_status);
        select count(*) into l_temp from operator_subscriber where cast(p_msisdn as unsigned integer) >= cast(STARTS_AT as unsigned integer) and cast(p_msisdn as unsigned integer) <= cast(ENDS_AT as unsigned integer);
               SET p_status=3;
        if l_temp = 0 then
                SET p_status=-22;
	SELECT concat('p_status ',p_status);
                LEAVE ISDONE;
        end if;
                SET p_status=4;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='D';
                SET p_status=6;
                SET p_status=5;
        if l_temp = 0 then
                SET p_status=-8;
	SELECT concat('p_status ',p_status);
        else
               /* --CheckRbtCode(p_msisdn,p_sys_wallet_id,p_status,p_chgcode);*/
               CALL  CheckWalletCode(p_msisdn,p_sys_wallet_id,p_subType,p_interface,p_type,p_status);
--	   LEAVE ISDONE ;
        end if;


	SELECT concat('p_status ',p_status);

END //
DELIMITER ;


