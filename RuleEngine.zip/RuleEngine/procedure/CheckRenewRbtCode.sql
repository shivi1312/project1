delimiter //
drop procedure if exists CheckRenewRbtCode //
create procedure CheckRenewRbtCode (IN p_msisdn varchar(20),IN p_rbtcode int ,OUT p_status  int,OUT p_chgcode  int) 
isdone:begin
declare    l_temp               int ;
declare     l_pv            varchar(10) ;
declare     l_pi                 int ;
declare     l_cat                int ;
declare     l_pcat               int ;
declare     l_freecat            int ;
declare     l_advcat             int ;
declare     l_chgcode            int ;
declare     l_fcenabled          int ;
declare     l_diffchgenabled     int ;
declare     l_playlistcat        int ;
declare     l_playlistenabled        int ;
declare cont int;

declare v_finished int;

#    -- param_id = 87  , param_tag = ADVERTISEMENT_CAT_ID
#    -- param_id = 104 , param_tag = DIFFERENT_RBT_CHARGING_ENABLED
##    -- param_id = 105 , param_tag = FREE_RBT_ENABLED
#    -- param_id = 106 , param_tag = FREE_RBT_CAT_ID
#    -- param_id = 123 , param_tag = PLAYLIST_CAT_ID
#    -- param_id = 124 , param_tag = PLAYLIST_ENABLED


    declare  cursor_rbt_code cursor for  select rbt_code,cat_id,charging_code from crbt_rbt where rbt_code=p_rbtcode ;
    declare  cursor_wlt_cnt cursor for  select rbt_code from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbtcode;
#--    cursor cursor_app_config is select param_value,param_id from crbt_app_config_params where param_id in (87,104,105,106,123);
    declare cursor_app_config cursor for  select param_value,param_id from crbt_app_config_params where param_tag in ('ADVERTISEMENT_CAT_ID','DIFFERENT_RBT_CHARGING_ENABLED','FREE_RBT_ENABLED','FREE_RBT_CAT_ID','PLAYLIST_CAT_ID','PLAYLIST_ENABLED');

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;

           set  l_diffchgenabled=-1;
           set  l_fcenabled=-1;
           set  l_advcat=-1;
           set  l_freecat=-1;
           set  l_playlistcat=-1;

            set p_status=0;
            open cursor_rbt_code ;
            fetch cursor_rbt_code into l_temp,l_cat,l_chgcode;
            select concat( 'after fetch ' , l_temp , ' ' , l_cat , ' ' , l_chgcode);
            if v_finished = 1
            then
                close cursor_rbt_code;
                set p_status=-14;
                LEAVE ISDONE;
            else
                close cursor_rbt_code;
            end if;
            SELECT CONCAT( 'after fetch ' , l_temp , ' ' ,l_cat ,' ' , l_chgcode);
            SET l_temp=0;
            set p_chgcode=l_chgcode;

            open cursor_wlt_cnt ;
            fetch cursor_wlt_cnt into l_temp;
	select concat( 'after fetch ' , l_temp );
            if v_finished = 1 
            then
                close cursor_wlt_cnt;
                set p_status=-15;
                LEAVE ISDONE;
            end if;
                close cursor_wlt_cnt;
            select concat( 'after fetch ' , l_temp );

                open cursor_app_config ;
                cursor_app_config:loop
                    set l_temp=0;
                    fetch cursor_app_config into l_pv,l_pi;
                        select concat( ' value ' ,l_pv , 'parm' ,l_pi);

                    if v_finished = 1
                    then
                        select concat( ' not found cursor_app_config');
                        close cursor_app_config;
                      LEAVE cursor_app_config;
                    else
                        set l_temp=CAST(l_pv AS UNSIGNED);

                        if l_pi = 87
                        then
                            set l_advcat=l_temp;
                        elseif l_pi = 104
                        then
                            set l_diffchgenabled=l_temp;
                        elseif l_pi = 105
                           then
                            set l_fcenabled=l_temp;
                        elseif l_pi = 106
                        then
                            set l_freecat=l_temp;
                        elseif l_pi = 123
                        then
                            set l_playlistcat=l_temp;
                        elseif l_pi = 124
                        then
                            set l_playlistenabled=l_temp;
                        else
                            select concat( 'not matching any ');
                            set p_status=-1;
                            close cursor_app_config;
                            LEAVE ISDONE;
                        end if;
                    end if;
                end loop cursor_app_config;


SELECT CONCAT( 'after fetch ' , l_advcat ,l_diffchgenabled , l_fcenabled , l_freecat , l_playlistcat );
                if l_advcat = l_cat
                then
                  set p_status=-24;
                  LEAVE ISDONE;
                end if;
            SELECT CONCAT( 'after fetch 1' , l_temp );

                if l_fcenabled = 1 and l_freecat = l_cat
                then
                  SET p_status=-26;
                  LEAVE ISDONE;
                end if;
            SELECT CONCAT( 'after fetch 2' ,l_temp );

                if l_playlistcat = l_cat and l_diffchgenabled = 1
                then
                  SET p_status=-29;
                  LEAVE ISDONE;
                elseif l_playlistcat = l_cat
                then
                  set p_status=-28;
                  LEAVE ISDONE;
                end if;
            SELECT CONCAT( 'after fetch 3' , l_temp );

                if l_diffchgenabled = 1
                then
                  SET p_status=-27;
                  LEAVE ISDONE;
                end if;
                 SET p_status=-7;
            SELECT CONCAT( 'after fetch 4' , l_temp , ' p_chgcode ',p_chgcode, ' p_status ',p_status);
END //  
