delimiter //
drop procedure if exists RbtRenew //
create procedure RbtRenew (IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_rbt_code int ,IN p_refid varchar(20),INp_chgcode int ,OUT p_status  int,OUT p_id int)
isdone:begin
declare cont int;
declare l_final_amount int;
declare l_post_amount int;
declare l_pre_amount int;
declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;

  update crbt_wallet_content set create_date=now(), status='A',expiry_date=now()+ interval 30 day where msisdn=p_msisdn and rbt_code=p_rbt_code ;
--  commit;
  set p_status=1;
set l_post_amount=0;
set l_pre_amount=0;
 set l_final_amount=0;
#  select SECDR_ID.nextval into p_id from dual;
#  select max(cdr_id+1)  into p_id from crbt_event_cdr;

-- call  GenerateRBTSettingCDR(p_msisdn,p_int,p_subtype,1,p_rbt_code,p_refid,p_chgcode,p_id);
	select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
                if p_subtype = 'O' then
                set l_final_amount=l_post_amount;
        else
                set  l_final_amount=l_pre_amount;
        end if;

  insert into crbt_event_cdr (msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,tariff_id,amount,action) values (p_msisdn,p_int,now(),1,'N',p_rbt_code,p_subtype,p_refid,p_chgcode,l_final_amount,'R');
	SET p_id=LAST_INSERT_ID();
  select concat( 'subscriber is postpaid ..secdr id ' , p_id);
  set p_status=3;
--  commit;
  set p_status=4;
  insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_int,p_rbt_code,0,6,'Y',p_updatedby,p_id);
  set p_status=6;
 -- commit;
  insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),0,concat('RBT Renewed ',p_rbt_code),p_subtype,p_int,p_updatedby);
  set p_status=7;
  commit;
SELECT CONCAT('p_status ',p_status);
END //
