DELIMITER //
drop procedure if exists SetAdvanceWallet //

CREATE PROCEDURE SetAdvanceWallet(IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype  varchar(20),IN p_sys_wallet_id  int,IN p_advop varchar(20),IN p_type int,OUT p_status int)

ISDONE:BEGIN

DECLARE l_temp     int ;
DECLARE l_ctrlid   int;
DECLARE l_catid    varchar(20);
DECLARE p_id       int;
DECLARE l_priority int;
DECLARE v_finished int;
DECLARE cursor_spl_ctrl_cat_id cursor FOR select param_value from crbt_app_config_params where param_tag='SPECIAL_CONTROL_CATID';
DECLARE cursor_sel_ctrl_code cursor FOR select control_id from crbt_rbt_control where cat_id=l_catid and control_name=upper(p_advop);

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

                set p_status=(p_status*(-1));
                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
         SELECT p_status;
END;

START TRANSACTION;
SET p_status=1;
SET l_priority=-1;

 open cursor_spl_ctrl_cat_id ;
 fetch cursor_spl_ctrl_cat_id into l_catid;
 	if v_finished=1
	 then
		close cursor_spl_ctrl_cat_id;
		SET p_status=-10;
		SELECT CONCAT('p_status',p_status);
		LEAVE ISDONE;
	else
		close cursor_spl_ctrl_cat_id;
	end if;

        open cursor_sel_ctrl_code ;
	fetch cursor_sel_ctrl_code into l_ctrlid;
	     	 if v_finished=1
		  then
		   close cursor_sel_ctrl_code;
		   SET p_status=-11;
			SELECT CONCAT('p_status',p_status);
		   LEAVE ISDONE;
		 else
			 close cursor_sel_ctrl_code;
		 end if;

	if p_sys_wallet_id <= 0 then
        	SET p_status=-53; /*----Invalid system Wallet id */
		SELECT CONCAT('p_status',p_status);
        	LEAVE ISDONE;
	else
        	select priority into l_priority from crbt_system_wallet_master where wallet_id=p_sys_wallet_id;
		if l_priority = 2 then
                	update crbt_subscriber_Wallet_detail set setting=l_ctrlid where msisdn=p_msisdn and wallet_id=p_sys_wallet_id;
	       --        commit;
               		 SET p_status=2;

        	        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,CONCAT('A Advance Setting is done for System Wallet ',p_sys_wallet_id),p_subtype,p_int,p_updatedby);
         --       commit;
               		 SET p_status=3;
--			COMMIT;
       		else
			SELECT CONCAT('p_status',p_status);
                	SET p_status=-56; /*----cannot change the setting for priority= 0 or 1 */
               		LEAVE ISDONE;
       		end if;
	end if;
COMMIT;
SELECT CONCAT('p_status',p_status);
-- COMMIT;
END //
DELIMITER ;

