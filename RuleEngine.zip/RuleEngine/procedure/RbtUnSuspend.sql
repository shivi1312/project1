delimiter //
drop procedure if exists RbtUnSuspend //
create procedure RbtUnSuspend ( IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_rbtCode int, OUT p_status int ,OUT p_id int )  
isdone:begin

declare cont int;
declare l_temp int;
declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, ") ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;

        set  p_status=1;
        set p_id=1;
        set l_temp=1;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='A';
        if l_temp != 0 then
                set p_status=-30;
                LEAVE ISDONE;
        end if;
        set p_status=1;
        if p_rbtCode != -1 then
                select count(*) into l_temp from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbtCode and rbt_code!=0 and status='S';
                if l_temp = 0 then
                        set p_status=-15;
                        LEAVE ISDONE;
                end if;
                update crbt_wallet_content set status='A' where msisdn=p_msisdn and rbt_code=p_rbtCode;
                -- commit;
                set p_status=2;
        else
                update crbt_wallet_content set status='A' where msisdn=p_msisdn and rbt_code!=0;
                -- commit;
                set p_status=3;
        end if;

                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('Rbt UnSuspended ',p_rbtCode),p_subtype,p_int,p_updatedby);
                -- commit;
                set p_status=4;
		commit;
	SELECT CONCAT('p_status ',p_status);
end //

