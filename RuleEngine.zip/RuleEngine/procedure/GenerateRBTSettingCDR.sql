DELIMITER //
DROP PROCEDURE IF EXISTS GenerateRBTSettingCDR //

CREATE Procedure GenerateRBTSettingCDR (IN p_msisdn  varchar(20),IN p_int  varchar(20),IN p_subtype  varchar(20),IN p_plan  int,IN p_rbt  int,IN p_refid  varchar(20),IN p_chgcode  int,OUT p_id  int)
ISDONE:BEGIN


declare        l_pre_amount  int;
declare        l_post_amount  int;
declare        l_final_amount int;

declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set  p_id=-1;

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;
                select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
                if p_subtype = 'O' then
                set l_final_amount=l_post_amount;
        else
                set  l_final_amount=l_pre_amount;
        end if;

--        select MAX(cdr_id+1) into p_id from crbt_event_cdr;
--        insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,tariff_id,amount,action) values (p_id,p_msisdn,p_int,now(),p_plan,'N',p_rbt,p_subtype,p_refid,p_chgcode,l_final_amount,'R');
        insert into crbt_event_cdr (msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,tariff_id,amount,action) values (p_msisdn,p_int,now(),p_plan,'N',p_rbt,p_subtype,p_refid,p_chgcode,l_final_amount,'R');
	set p_id=LAST_INSERT_ID();
        -- commit;

        select concat( 'subscriber is prepaid ..secdr id ' , p_id);
        commit;
End //


