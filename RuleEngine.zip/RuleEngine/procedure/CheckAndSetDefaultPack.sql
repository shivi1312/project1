delimiter //
drop procedure if exists CheckAndSetDefaultPack //
create Procedure CheckAndSetDefaultPack(IN p_msisdn  varchar(20),IN p_updatedby  varchar(20),IN p_int  varchar(20),OUT p_packId   int,OUT p_status   int)
ISDONE:begin
declare l_temp  int;
declare l_id  int;
declare l_plan  int;
declare l_lang  int;
declare l_subType varchar(3);
declare l_tpin  int;
declare l_totalRbt  int;
declare l_freeRbt  int;
declare l_totalGift  int;
declare l_freeGift  int;
declare l_totalRecording  int;
declare l_freeRecording  int;

declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;


 set l_temp=0;
 set p_packId=-1;
 set p_status=1;
 set l_id=1;
 set l_totalRbt=0;
 set l_freeRbt=0;
 set l_totalGift=0;
 set l_freeGift=0;
 set l_totalRecording=0;
 set l_freeRecording=0;

        select count(*) into l_temp from crbt_pack_detail where is_default_pack=1 and status='A';
        select concat('inside CheckAndSetDefaultPack 1');
        if l_temp=1 then
                select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn;

        select concat('inside CheckAndSetDefaultPack 2');
                if l_temp = 0 then
                        set p_packId=-1;
                        set p_status=2;
                        LEAVE ISDONE;
                end if;
                select pack_id into p_packId from crbt_pack_detail where is_default_pack=1 and status='A';
                select count(*) into l_temp from crbt_pack_master where msisdn=p_msisdn and pack_id=p_packId;
                set p_status=3;
 select concat('inside CheckAndSetDefaultPack 3 ---> pack_id[' , p_packId,'] p_status [',p_status ,']');
                if l_temp > 0 then
                        select TOTAL_RBT,FREE_RBT,TOTAL_GIFT,FREE_GIFT,TOTAL_RECORDING,FREE_RECORDING into l_totalRbt,l_freeRbt,l_totalGift,l_freeGift,l_totalRecording,l_freeRecording from crbt_pack_master where msisdn=p_msisdn and pack_id=p_packId;

                 select concat('inside CheckAndSetDefaultPack 4 ');
                        if l_totalRecording = 0 and l_freeRecording = 0 and l_totalGift = 0 and l_freeGift = 0 and l_totalRbt = 0 and l_freeRbt = 0 then
                              call   PackUpdate(p_msisdn,p_packId,p_int,p_updatedby,l_subType,p_status);
                        select concat('inside CheckAndSetDefaultPack 5 PackUpdate result  p_status [', p_status , ']');
                                if p_status < 0 then
                                        set p_status=-8;
                                end if;
                                LEAVE ISDONE;
                        else
                                set p_packId=-1;
                                set p_status=3;


 LEAVE ISDONE;
                        end if;
                end if;
#---             select plan_indicator,language,sub_type,password into l_plan,l_lang,l_subType,l_tpin from crbt_subscriber_master where msisdn=p_msisdn;
                 select plan_indicator,language,sub_type,tpin into l_plan,l_lang,l_subType,l_tpin from crbt_subscriber_master where msisdn=p_msisdn; #---change by pankaj because password was alphanumeric
                 select concat('inside CheckAndSetDefaultPack 6');
               call  PackSubscribe(p_msisdn,l_plan,l_lang,p_int,p_updatedby,l_subType,l_tpin,p_packId,'NA',-1,p_status,l_id);
 select concat('inside CheckAndSetDefaultPack 7');
                if p_status < 0 then
                        set p_status=-9;
                        set p_packId=-1;
                        LEAVE ISDONE;
                end if;
        else
                set p_status=1;
	SELECT CONCAT(p_status,'111111111111111');
                LEAVE ISDONE;
        end if;
        set p_status=4;
	SELECT CONCAT(p_status);
end //

