delimiter //
drop procedure if exists updatePendingRequest //


create Procedure updatePendingRequest(IN p_msisdn  varchar(20),IN p_int  varchar(20),IN p_rbtCode  int,OUT p_status  int) 
isdone:begin
declare l_temp int;
declare p_status int;
declare cont int;
declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, ") ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               
               set p_status=(p_status)*(-1);
                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;
                set p_status=1;
                set l_temp=1;
              select count(*) into l_temp from crbt_pending_request where msisdn=p_msisdn and rbt_code=p_rbtCode;
               if l_temp = 0 then
                set p_status=2;
	SELECT CONCAT('p_status ',p_status);	
                LEAVE ISDONE;
         else
                update crbt_pending_request set status='S' where msisdn=p_msisdn and rbt_code=p_rbtCode;
                commit;
                set p_status=3;
	SELECT CONCAT('p_status ',p_status);	
                LEAVE ISDONE;
        end if;
      End //
