 delimiter //
 drop procedure if exists RbtRenewModule //
create Procedure RbtRenewModule( In p_msisdn   varchar(20), In p_int   varchar(20), In p_updatedby   varchar(20), In p_plan  int, In p_subtype   varchar(20), In p_rbtCode  int, In p_days  int,In p_refid    varchar(20),In p_chgcode  int, OUT p_status  int,OUT p_id  int) 
 isdone:begin
declare         l_action   varchar (2);
declare         l_reqdata varchar (50);
declare         l_status varchar (2);
declare         newDate datetime;
declare         lastCharge datetime;
declare         l_lastCharged datetime;
declare         l_renewMode int(6);
declare         l_pre_amount  int;
declare         l_post_amount  int;
declare         l_final_amount int;


declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
END;
 START TRANSACTION;


       select status into l_action from crbt_subscriber_master where msisdn=p_msisdn;
        select renew_mode into l_renewMode from crbt_subscriber_master where msisdn=p_msisdn;
        if l_action = 'A' then
                if p_days = 1 then
                        set p_status=9;
                        set l_action='S1';
                        set l_reqdata='RENEWED FOR ONE DAY';
                elseif p_days = 7 then
                        set p_status=10;
                        set l_action='S2';
                        set l_reqdata='RENEWED FOR ONE WEEK';
                elseif p_days = 14 then
                        set p_status=11;
                        set l_action='S3';
                        set l_reqdata='RENEWED FOR TWO WEEK';
                elseif p_days = 21 then
                        set p_status=12;
                        set l_action='S4';
                        set l_reqdata='RENEWED FOR THREE WEEK';
                else
                        set l_status=13;
                        set l_action='S';
                        set l_reqdata='RENEWED FOR ONE MONTH';
                end if;

   else
                if p_days = 1 then
                        set p_status=14;
                        set l_action='A1';
                        set l_reqdata='ACTIVATED FOR ONE DAY';
                elseif p_days = 7 then
                        set p_status=15;
                        set l_action='A2';
                        set l_reqdata='ACTIVATED FOR ONE WEEK';
                elseif p_days = 14 then
                        set p_status=16;
                        set l_action='A3';
                        set l_reqdata='ACTIVATED FOR TWO WEEK';
                elseif p_days = 21 then
                        set p_status=17;
                        set l_action='A4';
                        set l_reqdata='ACTIVATED FOR THREE WEEK';
                else
                        set p_status=18;
                        set l_action='A';
                        set l_reqdata='ACTIVATED FOR ONE MONTH';
                end if;
               set  p_status=19;
        end if;
                set p_status=20;
                            select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
                            if p_subtype = 'O' then
                            set  l_final_amount=l_post_amount;
                            else
                            set l_final_amount=l_pre_amount;
                            end if;
               --             select max(cdr_id+1) into p_id from crbt_event_cdr  ;
                             insert into crbt_event_cdr (msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,tariff_id,amount) values (p_msisdn,p_int,now(),l_action,p_plan,'N',p_subtype,p_refid,p_chgcode,l_final_amount);
			     SET p_id=LAST_INSERT_ID();
                             select concat( 'subscriber is postpaid ..scdr id ' , p_id);
              set  p_status=2;
	--                     commit;

          --                   commit;
                           set p_status=25;

                select last_charged into l_lastCharged from crbt_subscriber_master where msisdn = p_msisdn;
                set newDate=((now()- interval 30 day) + interval p_days day);
                if newDate>l_lastCharged then
                        update crbt_subscriber_master set status='A',last_charged=newDate where msisdn = p_msisdn;
            --            commit;
                        set p_status=26;
                end if;
                update crbt_wallet_content set create_date=((now() - interval 30 day) + interval p_days day) where msisdn = p_msisdn and rbt_code=p_rbtCode;
	--            commit;
                set p_status=27;
            insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),l_action,p_int,'Y',p_updatedby,p_id);
          --  commit;
                set p_status=28;
            insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),0,l_reqdata,p_subtype,p_int,p_updatedby);
          --  commit;
               set  p_status=29;
                set p_id=l_renewMode;
	COMMIT;
	SELECT CONCAT('p_status ',p_status);
end //

