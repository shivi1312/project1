delimiter //
drop procedure if exists CheckForPackSubscription //
create Procedure CheckForPackSubscription(IN p_msisdn  varchar(20),IN p_int  varchar(20), OUT p_isSub  int,IN p_packId int,IN p_subType  varchar(20),OUT p_status  int)
ISDONE:begin

declare l_temp          int ;
declare l_isUser int;
declare l_count int;
declare l_status varchar(3);
declare l_subStatus varchar(3);
declare l_validSubType boolean;
declare l_packCount int;
declare l_scope varchar(100);
declare li_status int;

declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status)*(-1);


                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;


        set  p_status=1;
        set l_status='N';
        set l_isUser=-1;
        set l_temp=0;
        set l_count=-1;
        set p_isSub=-1;
        set l_packCount=-1;
        set l_scope='NA';
        set li_status=1;
        select count(*) into l_temp from crbt_pack_detail where pack_id=p_packId and status='A';
        if l_temp = 0 then
                set p_status=-30; # --- pack not exist
                LEAVE ISDONE;
        end if;
        set p_status=2;

        select valid_for, subscriber,scope into l_status,l_subStatus,l_scope from crbt_pack_detail where pack_id=p_packId;
	SELECT CONCAT('p_status ',p_status, ' l_status,l_subStatus,l_scope ',l_status,l_subStatus,l_scope);
        set p_status=3;
        if l_scope = 'P' and p_subType != 'P' then # --- user's subtype is not lie in valid sub type for pack
                set p_status=-32;
                LEAVE ISDONE;
        end if;
        if  l_scope = 'O' and p_subType != 'O' then
                set p_status=-32;
                LEAVE ISDONE;
        end if;
        set p_status=4;

        if l_status = 'FS' then # ---------- valid for very first time subscriber
                select count(*) into l_temp from crbt_subscriber_master_old where msisdn=p_msisdn;
                if l_temp = 0 then
                        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn;
                        if l_temp != 0 then
                                set p_status=-32;
                                LEAVE ISDONE;
                        end if;
                else
                        set p_status=-32;
                        LEAVE ISDONE;
                end if;
                set li_status=0;
                set p_status=5;
        elseif l_status = 'N' then  # --------- valid for non sub only
                set li_status=0;
                set p_status=5;
        else
                if l_status = 'S' then # ------------ valid for only subscriber
                        set p_status=6;
                        set li_status=1;
                elseif l_status = 'B' then # ------------ valid for both subs as well as non-sub
                        set p_status=7;
                        set li_status=2;
                else
               # ------- invalid value
                        set p_status=-1;
                        LEAVE ISDONE;
                end if;
                set p_status=8;
                if l_subStatus = 'A' then # -------- only for active users
                        set p_status=9;
                        set l_isUser=1;
                elseif l_subStatus = 'I' then
                        set p_status=10;
                        set l_isUser=0;
                elseif l_subStatus = 'B' then
                        set p_status=11;
                        set l_isUser=2;
                end if;
        end if;
        set p_status=12;
        select count(*) into l_count from crbt_subscriber_master where msisdn=p_msisdn and status!='D';
        set  p_status=13;
        if l_count = 0 then
                set p_status=14;
                if li_status = 0 or li_status = 2 then # ---- unsub user can purchase the bundle
                        set p_status=15; 
                        select param_value into l_temp from crbt_app_config_params where param_tag like 'WHITELIST_ENABLE';
                        set p_status=16;
                        if l_temp = 1 then
                                set p_status=17;
                                select count(*) into l_temp from crbt_whitelist where  cast(STARTS_AT AS UNSIGNED)  <= cast(p_msisdn AS UNSIGNED)  and cast(ENDS_AT AS UNSIGNED) >=cast(p_msisdn AS UNSIGNED);
                                if l_temp = 0 then
                                        set p_status=-25;
                                        LEAVE ISDONE;
                                end if;
                        end if;
                end if;
        else
                set p_status=18;
                select count(*) into l_packCount from crbt_pack_master where msisdn=p_msisdn and pack_id=p_packId and pack_expiry_date >= now();
                if l_packCount > 0 then # ---- pack already purchased
                        set p_status=-31;
                        LEAVE ISDONE;
                end if;
                set p_status=19;
                if li_status = 1 or li_status =2 then
                        select status into l_subStatus from crbt_subscriber_master where msisdn=p_msisdn;
                        if l_isUser = 1 and l_subStatus != 'A' then
                              #  -- user cant purchase pack
                                set p_status=-32;
                                LEAVE ISDONE;
                        elseif l_isUser = 0  and l_subStatus != 'I' then
                               #  -- user cant purchase pack
                                set p_status=-32;
                                LEAVE ISDONE;
                        end if;
                         if l_subStatus='A' then
                                set p_isSub=1;
                                set li_status=4;
                        else
                                set p_isSub=0;
                                set li_status=5;
                        end if;
                end if;
        end if;
SELECT CONCAT(p_status);
end //
