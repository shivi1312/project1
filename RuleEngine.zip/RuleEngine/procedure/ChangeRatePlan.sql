delimiter //
drop procedure if exists ChangeRatePlan //
create Procedure ChangeRatePlan (IN p_msisdn  varchar(20),IN p_plan  int,IN p_int  varchar(20),IN p_updatedby  varchar(20),IN p_refid  varchar(20),IN p_chgcode  int,IN p_validityDays  int,IN p_subtype  varchar(20),IN p_oldPlan int,OUT  p_status  int)
ISDONE:BEGIN
declare l_wltid                 int;
declare l_pre_amount  int;
declare l_post_amount  int;
declare l_final_amount int;
declare l_isSystemRbtBased int;
declare l_temp varchar(2);
declare l_id int;
-- Added by Avishkar
declare l_OnUpdDelRbtResult int; -- this parameter is used to fetch oldPlan Configuration to check whether all rbt need to be deleted or not while updating the plan.
declare l_scope varchar(1024); -- this parameter is used to fetch oldPlan Configuration
declare d_status int;
declare p_updatecode int;
declare p_filePath varchar(1024);
declare l_rbt_code int;
-- End of Added by Avishkar

declare v_finished int;
declare sel_rbt_code CURSOR FOR select rbt_code from crbt_wallet_content where msisdn=p_msisdn;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;
                 if p_status > 1 then
                                                                                                delete from crbt_event_cdr where cdr_id=l_id;
                                                                                                commit;
                 end if;
          
               set p_status=(p_status*(-1));
            
                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;

              set      p_status=1;
              select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
            if p_subtype = 'O' then
                            set l_final_amount=l_post_amount;
            else
                            set l_final_amount=l_pre_amount;
            end if;
            set p_status=2;

#        select SCDR_ID.nextval into l_id from dual;
         select max(cdr_id+1) into l_id from crbt_event_cdr;
        insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount) values (l_id,p_msisdn,p_int,now(),'S',p_plan,'N',p_subtype,p_refid,p_chgcode,l_final_amount);
        set p_status=3;
        commit;
				-- Added by Avishkar    
                                select scope into l_scope from crbt_rate_plan where PLAN_INDICATOR=p_oldPlan; -- fetching oldPlan configuration                          
                                select concat('OldPlan_Id[',p_oldPlan,'] Old_Scope[',l_scope,'] Plan Id[',p_plan,']');
                                call ParseStringToInt(l_scope,'ONUPD_DELRBT:',l_OnUpdDelRbtResult); -- fetching On_Update_Delete_Rbt configuration into l_OnUpdDelRbtResult parameter
                                select concat('l_OnUpdDelRbt[',l_OnUpdDelRbtResult,'] p_subType[',p_subType,'] p_status[',p_status,']');
                                -- End of Added by Avishkar

                                                                                          select status into l_temp from crbt_subscriber_master where msisdn=p_msisdn;
                                                                                if l_temp!='A' then
										-- Modify by Avishkar
                                                                                        if l_OnUpdDelRbtResult=1 then -- value 1 means all rbt deleted, so default rbt set while update plan.
                                                                                                update crbt_subscriber_master set plan_indicator=p_plan ,status='A', RBT_CODE=0, last_charged=((now()-interval 30 day)+ interval p_validityDays day),expiry_date=now()+ interval p_validityDays day, update_time=now() where msisdn=p_msisdn;
												insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),'A',p_int,'Y',p_updatedby,l_id);
                                                                                        else
												update crbt_subscriber_master set plan_indicator=p_plan ,status='A', last_charged=((now()- interval 30 day)+ interval p_validityDays day),expiry_date=now()+ interval p_validityDays day, update_time=now() where msisdn=p_msisdn;
                                                                                                insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),'A',p_int,'Y',p_updatedby,l_id);
											end if;
                                                                        else
											if l_OnUpdDelRbtResult=1 then -- value 1 means all rbt deleted, so default rbt set while update plan.
												update crbt_subscriber_master set plan_indicator=p_plan ,status='A', RBT_CODE=0, last_charged=last_charged+ interval p_validityDays day,expiry_date=expiry_date+ interval p_validityDays day, update_time=now() where msisdn=p_msisdn;
                                                                                        else
                                                                                                update crbt_subscriber_master set plan_indicator=p_plan ,status='A', last_charged=last_charged+ interval p_validityDays day,expiry_date=expiry_date+ interval p_validityDays day, update_time=now() where msisdn=p_msisdn;
                                                                                        end if;

        end if;
                                                                                                    commit;
										-- End of Modify by Avishkar
#end if;
                                                                                        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('CHANGE SUB PLAN To ',p_plan),p_subtype,p_int,p_updatedby);
                                                                                                commit;
                                                                                               set  p_status=8;
												
												 -- Added by Avishkar
                                                                                                if l_OnUpdDelRbtResult=1 then -- value 1 means we need to delete all rbt while plan update according to oldPlan configuration.

                                                                                                        open sel_rbt_code;
                                                                                                        -- fetch sel_rbt_code into l_rbt_code;
                                                                                                        sel_rbt_code:loop
                                                                                                        fetch sel_rbt_code into l_rbt_code;
                                                                                                        if v_finished=1
                                                                                                        then
                                                                                                                close sel_rbt_code;
                                                                                                                select concat('No rbt found');
                                                                                                                -- p_status:=9;
                                                                                                                -- EXIT;
														LEAVE sel_rbt_code;
                                                                                                                -- RETURN;
                                                                                                        else
                                                                                                                call DeleteRBT (p_msisdn,p_int,p_updatedby,p_subtype,l_rbt_code,d_status,p_updatecode,p_filePath) ;
                                                                                                                select concat('done DeleteRBT');
                                                                                                        end if;
                                                                                                                -- close sel_rbt_code;
                                                                                                        end loop sel_rbt_code;
                                                                                                        -- delete from crbt_wallet_content where msisdn=p_msisdn and RBT_CODE!=0;
                                                                                                        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,'PREVIOUS RBTS HAS BEEN DELETED DUE TO PLAN CHANGE',p_subtype,p_int,p_updatedby);
                                                                                                        commit;
                                                                                                        set p_status=9;
                                                                                                end if;
                                                                                                -- End of Added by Avishkar

END //
#delimiter 
