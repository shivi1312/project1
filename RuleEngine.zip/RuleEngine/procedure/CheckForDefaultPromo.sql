DELIMITER //
drop procedure if exists CheckForDefaultPromo //

CREATE PROCEDURE CheckForDefaultPromo(IN p_msisdn varchar(20),IN p_operation varchar(20), IN p_consentRequired int ,IN p_countryCode varchar(20),OUT p_packId int ,OUT p_status int) 
ISDONE:BEGIN

DECLARE l_temp int;
DECLARE l_promoId int;
DECLARE v_finished int;

DECLARE cur_defaultPromoList cursor FOR select promo_id from crbt_promo_list_master where is_default=1 and status='A' and USER_CONSENT=p_consentRequired and PROMO_TYPE=p_operation and now() between START_DATE and END_DATE and country_code=p_countryCode;

/* cursor cur_defaultPromoList is select promo_id from crbt_promo_list_master where is_default=1 and status='A' and USER_CONSENT=p_consentRequired and PROMO_TYPE=p_operation and now() between START_DATE and END_DATE and country_code=p_countryCode; */


DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

                set p_status=(p_status*(-1));
                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
        # SELECT p_status;
END;

START TRANSACTION;

	set l_temp=0;
        set p_packId=-1;
        set p_status=1;
        set l_promoId=0;
        SELECT CONCAT('inside CheckAndSetDefaultPack 1');
        open cur_defaultPromoList;
        LOOP
                fetch cur_defaultPromoList into l_promoId;
              
		if v_finished=1 then 
			close cur_defaultPromoList;
                        set p_status=1;
                        set p_packId=-1;
                        LEAVE ISDONE;

		else
			select count(*) into l_temp from crbt_promo_user_detail where msisdn=p_msisdn and promo_id=p_packId and country_code=p_countryCode;
                        set p_status=3;
                        SELECT CONCAT('inside CheckAndSetDefaultPack 3 ---> pack_id[', p_packId,'] p_status [',p_status ,']');
                        if l_temp = 0 then
                               set p_packId=l_promoId;
                               set p_status=2;
                                close cur_defaultPromoList;
                                LEAVE ISDONE;
                        end if;
		end if;
                set p_status=4;
        end loop;

END //
DELIMITER ;

