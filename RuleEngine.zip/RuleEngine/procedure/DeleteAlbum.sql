delimiter //
drop procedure if exists DeleteAlbum //
create  Procedure DeleteAlbum (IN p_msisdn  varchar(20),IN p_int  varchar(20),IN p_updatedby  varchar(20),IN p_subtype  varchar(20),IN p_albid  int,IN p_albname  varchar(20),OUt p_status  int)

isdone:begin
declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;

                 set p_status=1;
                 if p_albid = -1
                 then
                 Delete from crbt_wallet_master where msisdn=p_msisdn and upper(wallet_name)=upper(p_albname);
--                 commit;
                 set p_status=2;
                 insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('A Album ',p_albname,' is Deleted'),p_subtype,p_int,p_updatedby);
                 set p_status=3;
--                 commit;
                 else
                 Delete from crbt_wallet_master where msisdn=p_msisdn and wallet_id=p_albid ;
--                 commit;
                 set p_status=4;
                 insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('A Album ',p_albid,' is Deleted'),p_subtype,p_int,p_updatedby);
                 set p_status=5;
--                 commit;
                 end if;
--                 commit;
                insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_int,-1,p_albid,2,'N',p_updatedby,-1);
                set p_status=6;
                commit;
	SELECT CONCAT('p_status', p_status);
END//

