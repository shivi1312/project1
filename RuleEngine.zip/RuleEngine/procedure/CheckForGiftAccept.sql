delimiter //
drop procedure if exists CheckForGiftAccept //
create procedure CheckForGiftAccept (In p_msisdn varchar(20),IN p_rbt  int,IN p_fmsisdn  varchar(20),OUT p_chgcode  int,OUT p_planId  int,OUT p_status  int)
isdone:begin
declare  l_temp          int;
declare l_fmsisdn varchar(15);
declare l_planId int;
declare l_catid int;
declare l_cpid int;


declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, ") ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;


        set  p_status=5;
        set p_chgcode=-1;
        set p_planId=-1;
        set l_temp=0;
        if p_rbt = -1 then
               select count(*) into l_temp from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(now() - interval 1 day );
        else
                select count(*) into l_temp from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(now() - interval 1 day) and rbt_code=p_rbt;
        end if;
                set p_status=1;

        if l_temp = 0 then
		SELECT CONCAT('NO RECORD FOUND OVER GIFT_PENDING_REQUEST');
                set p_status=-35;
                LEAVE ISDONE;
        end if;
                set p_status=2;
        if p_rbt = -1 then
                set p_status=11;
                select rbt_code,fmsisdn,plan_id into p_rbt,l_fmsisdn,l_planId from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(now() - interval 1 day) and REQUEST_TIME=(select max(REQUEST_TIME) from  GIFT_PENDING_REQUEST where fmsisdn=p_msisdn);
        else
                set p_status=14;
                select fmsisdn,plan_id into l_fmsisdn,l_planId from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(now() - interval 1 day) and REQUEST_TIME=(select max(REQUEST_TIME) from  GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and rbt_code=p_rbt);
        end if;

select count(*) from operator_subscriber where cast(p_msisdn as UNSIGNED) >= cast(STARTS_AT as UNSIGNED) and cast( p_msisdn as UNSIGNED) <= cast(ENDS_AT as UNSIGNED);
#        select count(*) into l_temp from operator_subscriber where cast(p_msisdn  AS  UNSIGNED ) >= cast (STARTS_AT  AS UNSIGNED) and cast(p_msisdn  AS UNSIGNED ) <= cast(ENDS_AT  AS UNSIGNED);
                set p_status=3;
        if l_temp = 0 then
                set p_status=-22;
                set p_chgcode=-1;
                LEAVE ISDONE;
        end if;
                set p_status=4;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='D';
                set p_status=6;
                set p_planId=l_planId;
                set p_status=5;
        if l_temp = 0 then
                set p_status=-8;
                set  p_chgcode=-1;
        else
                call CheckRbtCode(p_msisdn,p_rbt,p_status,p_chgcode,l_catid,l_cpid);
        end if;
	SELECT CONCAT('p_status , p_chgcode, p_planId',p_status, p_chgcode, p_planId  );
end //
