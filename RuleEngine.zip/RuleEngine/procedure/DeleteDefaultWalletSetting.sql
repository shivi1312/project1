DELIMITER //
drop procedure if exists DeleteDefaultWalletSetting //

CREATE PROCEDURE DeleteDefaultWalletSetting(IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_sys_wallet_id int,IN p_days varchar(20),IN p_sttime int,IN p_entime int,IN p_type int,OUT p_status int)

ISDONE:BEGIN

DECLARE l_char varchar(1); 
DECLARE l_length INT;
DECLARE v_finished int;
DECLARE cont int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

                set p_status=-1;
                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
        # SELECT p_status;
END;

START TRANSACTION;
SET p_status=1;
            if p_days = 8
            then
                  delete from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and day=p_days and start_at=p_sttime and ends_at=p_entime and content_type=p_type;
           SET p_status=2;  /*-- this value will be checked in code and string will be updated*/

           else
            SET l_length=CHAR_LENGTH(p_days);

            	IF l_length > 0
              	THEN

			SET cont=1;
        			 # FOR l_index IN 1 .. l_length
	   		WHILE cont <= l_length do	
            
				SET l_char = SUBSTR(p_days,cont,1);

                		delete from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and day=l_char and start_at=p_sttime and ends_at=p_entime and content_type=p_type;
               			SET p_status=2; /*-- this value will be checked in code and string will be updated */
				SET cont = cont+1;
 	  		END WHILE;
        	  END IF;
	  END IF;

         insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,now(),p_sys_wallet_id,p_int,5,'DEFAULT','N',p_updatedby,-1,1);
         insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,'A Default Wallet profile is deleted',p_subtype,p_int,p_updatedby);
         commit;
select concat(p_status);



END //
DELIMITER ;

