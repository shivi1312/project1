delimiter //
drop procedure if exists SetDefaultWallet //
create procedure SetDefaultWallet (IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_sys_wallet_id  int,IN p_days varchar(20),IN p_sttime int,IN p_entime int,IN p_chgdone int,IN p_refid varchar(20),IN p_chgcode int,IN p_validityDays int,IN p_packId int,IN p_type int,OUT p_status int,OUT p_id int)
ISDONE:BEGIN

declare l_char varchar (1);
declare l_length int;
#declare l_length PLS_INTEGER;
declare l_temp int;
declare l_status int;
declare l_id int;
declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
 END;
 START TRANSACTION;


        set p_status=1;
        set p_id=-1;
        set l_temp=-1;
        select concat('Before AddWallet in SetDefaultWallet');
        call AddWallet(p_msisdn,p_int,p_updatedby,p_subtype,p_sys_wallet_id,p_chgdone,p_refid,p_chgcode,p_validityDays,p_packId,p_type,p_status,l_temp);
        select concat('After AddWallet in SetDefaultWallet');
        if p_status < 0
                then
                        select concat( 'exception occured AddWalllet ',p_status);
                        set p_status=p_status+ -50 ;
                        LEAVE ISDONE;
                else
                        set p_id=l_temp;
        end if;
        set l_temp=0;
        if p_days = 8 then
                select concat('before select from crbt_default_detail if pdays=8');
                select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
                select concat('After Select from crbt_default_detail if p_days=8');
                if l_temp = 0 then
                        insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time,content_type) values (p_msisdn,p_days,p_sttime,p_entime,p_sys_wallet_id,now(),p_type);
commit;
                        select concat('after insert crbt_default_detail');                                                
			set p_status=2;
                else
                        update crbt_default_detail set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
                        commit;
                        set p_status=3;
                end if;
        else
                set l_length=LENGTH(p_days);
                IF l_length > 0 THEN
			SET cont = 1;
			WHILE cont <= l_length do
                                set l_char = SUBSTR (p_days,l_index, 1);
                                select concat('Before select crbt_default_detail if days!=8');
select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;
                                select concat('After select crbt_default_detail if days!=8 where l_temp '||l_temp);                                                                                                                                                   
                                if l_temp = 0 then
                                        select concat('Before insert into crbt_default_detail if days!=8 where l_char',l_char);
                                        insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time,content_type,LAST_CHARGED) values (p_msisdn,l_char,p_sttime,p_entime,p_sys_wallet_id,now(),p_type,now());
                                        select concat('After update crbt_default_detail if days!=8');
                                        commit;
                                        set p_status=2;
                                else
                                        select concat('Before update crbt_default_detail if days!=8');
                                        update crbt_default_detail set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;
                                        select concat('after update crbt_default_detail if days!=8');
                                        commit;
                                        set p_status=3;
                                end if;
				SET cont = cont + 1;
			END WHILE;
                END IF;
        END IF;
        if p_days = 8 AND p_sttime = 2500 AND p_entime = 2500   then
                select concat('Before update crbt_subscriber_master');
                update crbt_subscriber_master set rbt_code=p_sys_wallet_id,active_features=2 where msisdn=p_msisdn;
                select concat('After update crbt_subscriber_master');
                commit;
                set p_status=5;
                end if;
                -- p_status:=6;
                select concat('Before insert crbt_rbt_op_log');
                insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,now(),p_sys_wallet_id,p_int,1,'DEFAULT','N',p_updatedby,p_id,1);
                commit;
                select concat('After insert crbt_rbt_op_log');
                -- p_status:=6;
                select concat('Before insert crbt_activity_detail_log');
                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('A System Wallet ' , p_sys_wallet_id , ' is Set Default'),p_subtype,p_int,p_updatedby);
                 commit;
                select concat('After insert crbt_activity_detail_log');
                 set l_temp=-1;
                 select concat('before select CRBT_SUBSCRIBER_WALLET_DETAIL');
                select count(*) into l_temp from CRBT_SUBSCRIBER_WALLET_DETAIL  where status='S' and msisdn=p_msisdn;
                select concat('After select CRBT_SUBSCRIBER_WALLET_DETAIL');
                if l_temp > 0 then
                        select concat('before walletUnSuspend');
                        call WalletUnSuspend(p_msisdn ,p_int ,p_updatedby,p_subtype,-1,p_type,l_status,l_id );
                        select concat('After WalletUnSuspend');
                end if;
	commit;
	SELECT CONCAT('p_status ',p_status, ' p_id ', p_id);
End //

