CREATE OR REPLACE PACKAGE CRBTNEW as
	Procedure Subscribe (p_msisdn in varchar2,p_plan in number,p_lang in number,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_pin in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_isPackSubscriber in number,p_status out number,p_id out number); 
	Procedure Unsubscribe (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_unsubReason in varchar2, p_status out number,p_id out number); 
	Procedure ChangeRatePlan (p_msisdn in varchar2,p_plan in number,p_int in varchar2,p_updatedby in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_subtype in varchar2,p_status out number); 
	Procedure CheckForGift (p_msisdn in varchar2,p_rbt in number,p_status out number,p_chgcode out number) ;
--changed
	Procedure SetDefaultRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_status out number,p_id out number);
	Procedure SetFriendRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_fmsisdn in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_status out number,p_id out number); 
	Procedure SetGroupRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_grpname in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_status out number,p_grpid out number); 
	Procedure GiftRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_fmsisdn in varchar2,p_validityDays in number,p_chgdone in number,p_refid in varchar2,p_packId in number,p_chgcode in number,p_status out number); 
	Procedure AddRbtToAlbumId (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_wltid in number,p_chgdone in number,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_status out number,p_id out number); 
  	Procedure AddRbtToAlbumName (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_wltname in varchar2,p_chgdone in number,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_status out number,p_id out number); 
	Procedure SetDateRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_occasion in varchar2,p_chgdone in number,p_date in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_status out number);
--done
 	Procedure SetAdvanceRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_advop in varchar2,p_fmsisdn in varchar2,p_opfor in number,p_status out number); 
 	Procedure CheckRbtCode (p_msisdn in varchar2,p_rbtcode in number,p_status out number,p_chgcode out number,p_catid out number,p_cpid out number);

 	Procedure DeleteDefaultSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_status out number) ; 
	Procedure DeleteFriendSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_fmsisdn in varchar2,p_status out number) ; 
 	Procedure DeleteGroupSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in number,p_sttime in number,p_entime in number,p_grp in varchar2,p_status out number,p_grpid out number) ; 
  	Procedure DeleteAdvanceSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_fmsisdn in varchar2,p_opfor in number,p_status out number) ; 
		
	Procedure DeleteRBT (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_status out number,p_updatecode out number,p_filePath out varchar2) ;

	Procedure DeleteAlbum (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_albid in number,p_albname in varchar2,p_status out number) ; 
  	Procedure GenerateRBTSettingCDR (p_msisdn in varchar2,p_int in varchar2,p_subtype in varchar2,p_plan in number,p_rbt in number,p_refid in varchar2,p_chgcode in number,p_id out number) ; 
	Procedure AddAlbum (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_wltname in varchar2,p_id out number); 
	Procedure CheckForSubscription(p_msisdn in varchar2,p_maxsub in number,p_plan in number,p_status out number);

	Procedure DeleteDateRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number, p_date in varchar2,p_status out number) ; 
 	Procedure Deactivate (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_status out number,p_id out number) ;
				Procedure Activate (p_msisdn in varchar2,p_plan in number ,p_int in varchar2,p_days in number,p_updatedby in varchar2,p_subtype in varchar2,p_refid in varchar2,p_chgcode in number,p_isactive in out number,p_status out number,p_id out number); 
--needs to check
	Procedure AddRecordedRbt (p_msisdn in varchar2, p_rbtpath in varchar2,p_catId in number,p_subtype in varchar2,call_Id in number,p_validityDays in number,p_packId in number,p_status out number) ; 
	Procedure AddFreeRbtToAlbName (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_wltname in varchar2,p_status out number,p_id out number) ; 
 	Procedure AddFreeRbtToAlbId (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_wltid in number,p_chgcode in number,p_status out number,p_id out number) ; 
	Procedure GiftFreeRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_fmsisdn in varchar2,p_chgcode in number,p_validityDays in number,p_status out number) ; 

 	Procedure GenerateCrbtCdrs (p_msisdn in varchar2,p_chgcode in number,p_action in number,p_interface in varchar2,p_sc in number,p_daid in number,p_cdate in date,p_fmsisdn in varchar2,p_rbt in number,p_amt in number,p_subtype in varchar2,p_status in varchar2,p_id out number); 

 	Procedure SubscribeAndSetRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_plan in number, p_lang in number, p_pin in varchar2,p_refid in varchar2,p_chgcode in number,p_status out number,p_id out number);

	Procedure RbtRenew (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt_code in number,p_refid in varchar2,p_chgcode in number,p_status out number,p_id out NUMBER);
	Procedure CheckRenewRbtCode (p_msisdn in varchar2,p_rbtcode in number,p_status out number,p_chgcode out number);
	Procedure PrintVersion ;
	Procedure p_blacklist_msisdn (p_msisdn in varchar2,p_fmsisdn in varchar2,p_status out number);
	Procedure CheckForStatus(p_msisdn in varchar2, p_status out number);
	Procedure SetDefaultFreeRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_validityDays in number,p_status out number,p_id out number) ;
	Procedure CheckForPackSubscription(p_msisdn in varchar2,p_int in varchar2, p_isSub out number,p_packId in number,p_subType in varchar2,p_status out number);
	Procedure CheckForRenewMode(p_msisdn in varchar2, p_renewMode out number, p_subType out varchar2,p_status out number);
	Procedure RbtRenewModule(p_msisdn in varchar2, p_int in varchar2, p_updatedby in varchar2, p_plan in number, p_subtype in varchar2, p_rbtCode in number, p_days in number,p_refid  in varchar2,p_chgcode in number, p_status out number,p_id out number);
	Procedure PackSubscribe (p_msisdn in varchar2,p_plan in number,p_lang in number,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_pin in varchar2,p_packid in number,p_refid in varchar2,p_chgcode in number,p_status out number,p_id out number) ; 
	Procedure ParseStringToInt(p_stringToBeParse in varchar2, p_stringFromParse in varchar2,p_result out number);
	Procedure CheckForPackUser(p_msisdn in varchar2,p_operation in number,p_packId out number,p_setting out number,p_ispackSub out number,p_status out number);
	Procedure CheckAndSetDefaultPack(p_msisdn in varchar2,p_updatedby in varchar2,p_int in varchar2,p_packId out number,p_status out number);
	Procedure PackUpdate(p_msisdn in varchar2,p_packid in number,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_status out number);
	Procedure FindRatePlan(p_msisdn in varchar2,p_planName in varchar2,p_planId out number,p_status out number);
	Procedure CheckAndFindRatePlan(p_msisdn in varchar2,p_subType in varchar2,p_planName in varchar2,p_planId out number,p_status out number);
	Procedure ParseStringToString(p_stringToBeParse in varchar2, p_stringFromParse in varchar2,p_result out varchar2,p_status out number);
	Procedure RbtSuspend(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbtCode in number, p_status out number,p_id out number);
	Procedure RbtUnSuspend(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbtCode in number, p_status out number,p_id out number);
	Procedure PendingGiftAccept(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbtCode in number, p_fmsisdn in varchar2, p_planId in number,p_status out number,p_id out number);
	Procedure CheckForGiftAccept (p_msisdn in varchar2,p_rbt in out number,p_fmsisdn in varchar2,p_chgcode out number,p_planId out number,p_status out number) ;
	Procedure CheckAndInsertForMultiRetry(p_msisdn in varchar2,p_int in varchar2,p_subtype in varchar2,p_rbt in out number,p_packId in number,p_reqId in number, p_langId in number, p_planId in number, p_fmsisdn in varchar2,p_status out number);
	Procedure CheckForSuspension(p_msisdn in varchar2, p_status out number);
	Procedure UnsuspendService(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_status out number,p_id out number);
	Procedure SuspendService(p_msisdn in varchar2,p_plan in number,p_lang in number,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_status out number,p_id out number);
	Procedure StopRbtRenew(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbtCode in number, p_status out number,p_id out number);
	Procedure CheckTempRbt(p_msisdn in varchar2,p_int in varchar2,p_rbt in out number,p_status out number); 
	Procedure GiftSubscribe (p_msisdn in varchar2,p_plan in number,p_lang in number,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_pin in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_fmsisdn in varchar2,p_status out number,p_id out number); 
	Procedure UpdateReference(p_msisdn in varchar2, p_refId in varchar2,p_status out number);
	Procedure updatePendingRequest(p_msisdn in varchar2,p_int in varchar2,p_rbtCode in number,p_status out number);
	
	-- ------------------------
------ procedure for system default
	
Procedure SetDefaultWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id  in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_type in number,p_status out number,p_id out number);
Procedure SetFriendWallet(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_fmsisdn in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_type in number,p_status out number,p_id out number);
Procedure SetGroupWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_grpname in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_type in number,p_status out number,p_grpid out number);
Procedure GenerateCrbtCdrs (p_msisdn in varchar2,p_chgcode in number,p_action in number,p_interface in varchar2,p_sc in number,p_daid in number,p_cdate in date,p_fmsisdn in varchar2,p_sys_wallet_id in number,p_amt in number,p_subtype in varchar2,p_status in varchar2,p_type in number,p_id out number);
Procedure AddWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_chgdone in number,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_type in number,p_status out number,p_id out number);
Procedure DeleteWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_type in number,p_status out number,p_updatecode out number,p_filePath out varchar2);

Procedure SetDateWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_occasion in varchar2,p_chgdone in number,p_date in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_type in number,p_status out number);

Procedure DeleteGroupWalletSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_days in number,p_sttime in number,p_entime in number,p_grp in varchar2,p_type in number,p_status out number,p_grpid out number);
 
Procedure DeleteDefaultWalletSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_days in varchar2,p_sttime in number,p_entime in number,p_type in number,p_status out number);
Procedure DeleteFriendWalletSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_days in varchar2,p_sttime in number,p_entime in number,p_fmsisdn in varchar2,p_type in number,p_status out number);
Procedure DeleteDateWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number, p_date in varchar2,p_type in number,p_status out number);
Procedure WalletSuspend(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_type in number, p_status out number,p_id out number);
Procedure WalletUnSuspend(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_type in number, p_status out number,p_id out number);
Procedure CheckForWalletGift (p_msisdn in varchar2,p_sys_wallet_id in number,p_subType in varchar2,p_interface in varchar2,p_type in number,p_status out number);
Procedure CheckWalletCode (p_msisdn in varchar2,p_sys_wallet_id in number,p_subType in varchar2,p_interface in varchar2,p_type in number,p_status out number);
Procedure CheckForWalletGiftAccept(p_msisdn in varchar2,p_sys_wallet_id in out number,p_fmsisdn  in varchar2,p_subType in varchar2,p_interface in varchar2,p_type in number,p_status out number);
Procedure GiftWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_fmsisdn in varchar2,p_validityDays in number,p_chgdone in number,p_refid in varchar2,p_packId in number,p_chgcode in number,p_type in number,p_status out number);
Procedure PendingWalletGiftAccept(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number, p_fmsisdn in varchar2, p_planId in number,p_type in number,p_status out number,p_id out number);
Procedure SetAdvanceWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_advop in varchar2,p_type in number,p_status out number);
Procedure DeleteAdvanceWalletSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_type in number,p_status out number);

--Added by shambhavi 25-04-2016
Procedure SetSubRenewStatus (p_msisdn in varchar2,p_int in varchar2, p_updatedby in varchar2,p_subtype in varchar2,p_renewstatus in varchar2,p_status out number);



End CRBTNEW;
/
show errors;

CREATE OR REPLACE PACKAGE BODY CRBTNEW as
Procedure Subscribe (p_msisdn in varchar2,p_plan in number,p_lang in number,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_pin in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_isPackSubscriber in number, p_status out number,p_id out number) is 
l_wltid 		number;
l_temp number;
l_pre_amount  number;
l_post_amount  number;
l_final_amount number;
l_isSystemRbtBased number;
l_paramValue number;
l_packId number;
l_isSub number;
Begin
	p_status:=1;
	p_id:=-1;

--p_status:=-1;
--RETURN;
	if p_chgcode = -2 then
		l_temp:=8;
	else
		l_temp:=p_chgcode;
	end if;
	select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=l_temp;
	dbms_output.put_line( 'in 1');
        if p_subtype = 'O' then
           	l_final_amount:=l_post_amount;
        else
	        l_final_amount:=l_pre_amount;
        end if;
        p_status:=2;

	select SCDR_ID.nextval into p_id from dual;
	dbms_output.put_line( 'in 2');
	insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount) values (p_id,p_msisdn,p_int,sysdate,'S',p_plan,'N',p_subtype,p_refid,l_temp,l_final_amount);
	p_status:=3;
	commit;
 select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
        if l_isSystemRbtBased=1 then
		if p_validityDays < 0 then
			    insert into crbt_subscriber_master (msisdn,status,plan_indicator,rbt_code,password,tpin,language,sub_type,last_charged,expiry_date) values (p_msisdn,'A',p_plan,0,p_pin,p_pin,p_lang,p_subtype,sysdate-30,sysdate);
		else
			insert into crbt_subscriber_master (msisdn,status,plan_indicator,rbt_code,password,tpin,language,sub_type,last_charged,expiry_date) values (p_msisdn,'A',p_plan,0,p_pin,p_pin,p_lang,p_subtype,sysdate-30+p_validityDays,sysdate+p_validityDays);
        	end if;
	    	commit;
	else
	    	insert into crbt_subscriber_master (msisdn,status,plan_indicator,rbt_code,password,tpin,language,sub_type,last_charged,expiry_date) values (p_msisdn,'A',p_plan,0,p_pin,p_pin,p_lang,p_subtype,sysdate-30+p_validityDays,sysdate+p_validityDays);
		commit;
	end if;

	p_status:=3;
	select wallet_id_seq.nextval into l_wltid from dual;
	insert into crbt_wallet_master (msisdn,wallet_id,create_date,wallet_name,ivr_name)	values (p_msisdn,l_wltid,sysdate,'DEFAULT',0);
	commit;
	p_status:=4;
	insert into crbt_wallet_content (wallet_id,rbt_code,create_date,is_rbt_gifted,msisdn) values (l_wltid,0,sysdate,0,p_msisdn);
	commit;
	p_status:=5;
	insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,8,2500,2500,0,sysdate);
	commit;
	p_status:=6;
	insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,'S',p_int,'Y',p_updatedby,p_id);
	commit;
	p_status:=7;
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'SUBSCRIBED',p_subtype,p_int,p_updatedby);
	commit;
	l_packId:=-1;
--	if p_isPackSubscriber = 0 then
		l_isSub:=-1;
		CheckForPackSubscription(p_msisdn,p_int,l_isSub,l_packId,p_subtype,p_status);
		if p_status >= 0 then
			CheckAndSetDefaultPack(p_msisdn,p_updatedby,p_int,l_packId,p_status);
		end if;
	--end if;
	select count(*) into l_temp from crbt_app_config_params where param_tag='LOYALTY_POINTS_ENABLE';
	if l_temp = 1 then
		select to_number(param_value) into l_paramValue from crbt_app_config_params where param_tag='LOYALTY_POINTS_ENABLE';
		if l_paramValue = 1 then
			insert into loyalty_points(msisdn,TIMESTAMP,UPDATED_BY,ACTION,AMOUNT,LOYALTY_POINTS) values(p_msisdn,sysdate,p_updatedby,1,l_final_amount,l_final_amount*0.10);
		end if;
	end if;
	p_status:=8;
	exception
		when others then
		if p_status > 1 then
			delete from crbt_event_cdr where cdr_id=p_id;
			commit;
			delete from crbt_subscriber_master where msisdn=p_msisdn;
			commit;
			delete from crbt_subscription_log where msisdn=p_msisdn and call_id=p_id;
			commit;
		end if;
		p_status:=(p_status*(-1));
End Subscribe;

Procedure Unsubscribe (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_unsubReason in varchar2, p_status out number,p_id out number) is 
l_temp 		number;
l_status 		varchar(2);
Begin
	l_temp:=0;
	p_status:=-1;
	p_id:=-1;
	select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn;
	if l_temp = 0 then
		p_status:=-24;
		RETURN;
	end if;
	select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status='D';
	if l_temp = 1 then
		p_status:=-24;
		RETURN;
	end if;
	p_status:=1;
	select SCDR_ID.nextval into p_id from dual;
        insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount) values (p_id,p_msisdn,p_int,sysdate,'U',1,'N',p_subtype,'00000000000',-1,0);
        dbms_output.put_line( 'subscriber is postpaid ..scdr id ' || p_id);
        p_status:=2;

	dbms_output.put_line( 'after cdr');
        insert into crbt_subscriber_master_old (select * from crbt_subscriber_master where msisdn=p_msisdn);
 	commit; 
	delete from crbt_subscriber_master where msisdn=p_msisdn;
	dbms_output.put_line( 'after deletion');
	p_status:=4;
	commit;
	insert into crbt_cdrs ( msisdn,TARIFFID,ACTION,INTERFACE,SERVICE_CLASS,DA_ID,CREATE_DATE,FMSISDN,RBT_CODE,AMOUNT,STATUS,CDR_ID) values (p_msisdn,-1,9,p_int,-1,0,sysdate,'NA',-1,0,'N',crbt_cdr_id.nextval);
	commit;
	p_status:=5;
	if p_int = 'M' then
		insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,'D',p_int,'N',p_updatedby,p_id);
	else
		insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id,unsub_reason) values (p_msisdn,p_subtype,sysdate,'U',p_int,'N',p_updatedby,p_id,p_unsubReason);
	end if;
	p_status:=7;
	commit;
	dbms_output.put_line( 'subscription log');
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'UNSUBSCRIBED',p_subtype,p_int,p_updatedby);
	p_status:=8;
	commit;
	dbms_output.put_line( 'activity log');
	p_status:=9;
	exception
		when others then
		p_status:=(p_status*(-1));
End Unsubscribe;

Procedure ChangeRatePlan (p_msisdn in varchar2,p_plan in number,p_int in varchar2,p_updatedby in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_subtype in varchar2, p_status out number) is 
l_wltid 		number;
l_pre_amount  number;
l_post_amount  number;
l_final_amount number;
l_isSystemRbtBased number;
l_temp varchar2(2);
l_id number;

Begin
	p_status:=1;
	select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
            if p_subtype = 'O' then
		            l_final_amount:=l_post_amount;
            else
		            l_final_amount:=l_pre_amount;
            end if;
            p_status:=2;

	select SCDR_ID.nextval into l_id from dual;
	insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount) values (l_id,p_msisdn,p_int,sysdate,'S',p_plan,'N',p_subtype,p_refid,p_chgcode,l_final_amount);
	p_status:=3;
	commit;
											select status into l_temp from crbt_subscriber_master where msisdn=p_msisdn;
										if l_temp!='A' then
												    update crbt_subscriber_master set plan_indicator=p_plan ,status='A', last_charged=sysdate-30+p_validityDays,expiry_date=sysdate+p_validityDays, update_time=sysdate where msisdn=p_msisdn;
												insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,'A',p_int,'Y',p_updatedby,l_id);
									else
												    update crbt_subscriber_master set plan_indicator=p_plan ,status='A', last_charged=last_charged+p_validityDays,expiry_date=expiry_date+p_validityDays, update_time=sysdate where msisdn=p_msisdn;
        end if;
												    commit;
--end if;
											insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'CHANGE SUB PLAN To '||p_plan,p_subtype,p_int,p_updatedby);
												commit;
																p_status:=8;
								exception
												when others then
												if p_status > 1 then
												delete from crbt_event_cdr where cdr_id=l_id;
												commit;
--												delete from crbt_subscriber_master where msisdn=p_msisdn;
		--										commit;
												end if;
												p_status:=(p_status*(-1));
	End ChangeRatePlan;
			
Procedure SetDefaultRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_status out number,p_id out number) is
				l_char varchar2 (1);
				l_length PLS_INTEGER;
				l_temp 		number;
l_status number;
l_id number;
				Begin
								p_status:=1;
								p_id:=-1;

--p_status:=-1;
--RETURN;
												AddRbtToAlbumName(p_msisdn,p_int,p_updatedby,p_subtype,p_rbt,'DEFAULT',p_chgdone,p_refid,p_chgcode,p_validityDays,p_packId,p_status,l_temp);
												if p_status < 0
												then
		dbms_output.put_line( 'exception occured AddRbtToAlbumName '||p_status);
																p_status:=p_status+ -50 ;
																RETURN;
												else
																p_id:=l_temp;
												end if;


												l_temp:=0;
												if p_days = 8
												then
select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
																				if l_temp = 0 then
insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_days,p_sttime,p_entime,p_rbt,sysdate);
																								commit;
																								p_status:=2;
																				else
update crbt_default_detail set rbt_code=p_rbt,content_type=0 where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime; 
																								commit;
														p_status:=3;
																				end if;
												else
																l_length:=LENGTH(p_days);
																IF l_length > 0
																THEN
																				FOR l_index IN 1 .. l_length
																				LOOP
																								l_char := SUBSTR (p_days,l_index, 1);
select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;
																								if l_temp = 0 then
insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,l_char,p_sttime,p_entime,p_rbt,sysdate);
																												commit;
																												p_status:=2;
																								else
	update crbt_default_detail set rbt_code=p_rbt,content_type=0 where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime; 
																												commit;
p_status:=3;
																								end if;
																				END LOOP;
																END IF;
												END IF;

											if p_days = 8 AND p_sttime = 2500 AND p_entime = 2500  
											then
			update crbt_subscriber_master set rbt_code=p_rbt where msisdn=p_msisdn;
												commit;
																p_status:=5;
								  	end if;
--p_status:=6;
insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_rbt,p_int,1,'DEFAULT','N',p_updatedby,p_id,1); 
											
	commit;
--p_status:=6;

insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Default RBT '|| p_rbt ||' is Set',p_subtype,p_int,p_updatedby);
												commit;
select count(*) into l_temp from crbt_wallet_content where status='S' and msisdn=p_msisdn;
if l_temp >0 then

							RbtUnSuspend(p_msisdn ,p_int ,p_updatedby,p_subtype,-1, l_status,l_id ); 
end if;
								exception
												when others then
												--				dbms_output.put_line( 'exception occured ');
											--	p_status:=-1;
												p_status:=(p_status*(-1));
	End SetDefaultRbt;


Procedure SetFriendRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_fmsisdn in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_status out number,p_id out number) is 
				l_temp 		number;
				l_length PLS_INTEGER;
				l_char varchar2 (1);
				Begin
								p_status:=1;
								p_id:=-1;
												AddRbtToAlbumName(p_msisdn,p_int,p_updatedby,p_subtype,p_rbt,'DEFAULT',p_chgdone,p_refid,p_chgcode,p_validityDays,p_packId,p_status,l_temp);
												if p_status < 0
												then
																p_status:=-1;
																RETURN;
												else
																p_id:=l_temp;
												end if;

							l_temp:=0;
				   select count(*) into l_temp from crbt_friend_detail where msisdn=p_msisdn and friend_msisdn=p_fmsisdn;
				   if l_temp = 0 then
												if p_days = 8 AND p_sttime = 2500 AND p_entime = 2500  
												then
												dbms_output.put_line( ' friend not exist crbt_friend_detail ' );
																insert into crbt_friend_detail (msisdn,friend_msisdn,friend_setting_string) values (p_msisdn,p_fmsisdn,'800000000000000000000000000000000000000000000000000000000000');
																p_status:=3;
												else
																insert into crbt_friend_detail (msisdn,friend_msisdn,friend_setting_string) values (p_msisdn,p_fmsisdn,'000000000000000000000000000000000000000000000000000000000000');
												end if;
												commit;
--																				insert into crbt_friend_setting (msisdn,friend_msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_fmsisdn,p_days,p_sttime,p_entime,p_rbt,sysdate);
												insert into crbt_friend_op_log (msisdn,subscriber_type,event_time,interface_type,op_code,friend_msisdn,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,1,p_fmsisdn,'N',p_updatedby,p_id);
												commit;
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Friend '||p_fmsisdn||' is Added',p_subtype,p_int,p_updatedby);

												commit;

												dbms_output.put_line( 'friend not exist  days inserting in crbt_friend_op_log' );
												commit;
								end if;
								l_temp:=0;
								if p_days = 8
								then
												select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
												if l_temp = 0 then
																insert into crbt_friend_setting (msisdn,friend_msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_fmsisdn,p_days,p_sttime,p_entime,p_rbt,sysdate);
																commit;
																dbms_output.put_line( 'days 8 crbt_friend setting' );
																if p_status != 3
																then
																				p_status:=2;
																end if;
												else
																update crbt_friend_setting set rbt_code=p_rbt,content_type=0 where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and day=p_days and start_at=p_sttime and ends_at=p_entime; 
																dbms_output.put_line( 'days 8 update crbt_friend setting' );
																commit;
												end if;
								else
												l_length:=LENGTH(p_days);
												IF l_length > 0
												THEN
																FOR l_index IN 1 .. l_length
																LOOP
																dbms_output.put_line( 'in loop index '||l_index );
																				l_char := SUBSTR (p_days,l_index, 1);
																				select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;
																				if l_temp = 0 then
																dbms_output.put_line( 'before insert in crbt_friend_settingin loop index '||l_index );
																								insert into crbt_friend_setting (msisdn,friend_msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_fmsisdn,l_char,p_sttime,p_entime,p_rbt,sysdate);
																								commit;
																dbms_output.put_line( 'after insert in crbt_friend_settingin loop index '||l_index );
																								p_status:=2;
																				else
																dbms_output.put_line( 'before update in crbt_friend_settingin loop index '||l_index );
																								update crbt_friend_setting set rbt_code=p_rbt,content_type=0 where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and day=l_char and start_at=p_sttime and ends_at=p_entime; 
																								commit;
																				end if;
																END LOOP;
												END IF;
								end if;
								insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_rbt,p_int,1,p_fmsisdn,'N',p_updatedby,p_id,1); 
								commit;
								insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A RBT '||p_rbt||' For Friend '||p_fmsisdn||' is Set',p_subtype,p_int,p_updatedby);
								commit;

																dbms_output.put_line( 'after inserting in crbt_rbt_op_log ' );
								exception
												when others then
												p_status:=-1;
	End SetFriendRbt;
				
Procedure SetGroupRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_grpname in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_status out number,p_grpid out number) is 
l_temp 		number;
p_id 		number;
l_length PLS_INTEGER;
l_char varchar2 (1);
cursor sel_grp_id is select groupid from crbt_group_detail where msisdn=p_msisdn and upper(masked_name)=upper(p_grpname);
Begin
	p_status:=1;
	p_id:=-1;
	AddRbtToAlbumName(p_msisdn,p_int,p_updatedby,p_subtype,p_rbt,'DEFAULT',p_chgdone,p_refid,p_chgcode,p_validityDays,p_packId,p_status,l_temp);
	if p_status < 0
	then
		p_status:=-1;
		RETURN;
	else
		p_id:=l_temp;
	end if;
	open sel_grp_id;
	fetch sel_grp_id into p_grpid;
	if sel_grp_id%NOTFOUND 
	then
		close sel_grp_id;
		p_status:=-13;
		RETURN;
	else
		close sel_grp_id;
	end if;
						
	l_temp:=0;
	if p_days = 8
	then
		select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and groupid=p_grpid and day=p_days and start_at=p_sttime and ends_at=p_entime;
		if l_temp = 0 then
			insert into crbt_group_setting (msisdn,groupid,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_grpid,p_days,p_sttime,p_entime,p_rbt,sysdate);
			commit;
			p_status:=2;
		else
			update crbt_group_setting set rbt_code=p_rbt,content_type=0 where msisdn=p_msisdn and groupid=p_grpid and day=p_days and start_at=p_sttime and ends_at=p_entime; 
			commit;
		end if;
	else
		l_length:=LENGTH(p_days);
		IF l_length > 0
		THEN
			FOR l_index IN 1 .. l_length
			LOOP
				l_char := SUBSTR (p_days,l_index, 1);
				select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and groupid=p_grpid and day=l_char and start_at=p_sttime and ends_at=p_entime;
				if l_temp = 0 then
				insert into crbt_group_setting (msisdn,groupid,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_grpid,l_char,p_sttime,p_entime,p_rbt,sysdate);
				commit;
				p_status:=2;
				else
					update crbt_group_setting set rbt_code=p_rbt,content_type=0 where msisdn=p_msisdn and groupid=p_grpid and day=l_char and start_at=p_sttime and ends_at=p_entime; 
					commit;
				end if;
			END LOOP;
		END IF;
	end if;
	insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_rbt,p_int,1,p_grpname,'N',p_updatedby,p_id,1); 
	commit;
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A RBT '||p_rbt||' For Group '||p_grpname||' is Set',p_subtype,p_int,p_updatedby);
	commit;
	exception
	when others then
		p_status:=-1;
End SetGroupRbt;

Procedure CheckForGift (p_msisdn in varchar2,p_rbt in number,p_status out number,p_chgcode out number) is 
l_temp 		number;
l_catid number;
l_cpid number;
Begin
	p_status:=0;

	select count(*) into l_temp from operator_subscriber where to_number(p_msisdn) >= to_number(STARTS_AT) and to_number(p_msisdn) <= to_number(ENDS_AT);
	if l_temp = 0 then
		p_status:=-22;
 		p_chgcode:=-1;
 		RETURN;
	end if;
	select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='D';
	if l_temp = 0 then
		p_status:=-8;
		p_chgcode:=-1;
	else
		CheckRbtCode(p_msisdn,p_rbt,p_status,p_chgcode,l_catid,l_cpid);
		RETURN;
	end if;
	exception
		when others then
			p_status:=-1;
End CheckForGift;

Procedure GiftRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_fmsisdn in varchar2,p_validityDays in number,p_chgdone in number,p_refid in varchar2,p_packId in number,p_chgcode in number,p_status out number) is 
l_temp 		number;
p_id number;
l_isSystemRbtBased number;
l_pre_amount  number;
l_post_amount  number;
l_final_amount number;
l_totalGift number;
l_freeGift number;
l_subStatus varchar2(3);
Begin
	l_subStatus:='A';
	l_totalGift:=0;
	l_freeGift:=0;
	p_status:=1;
	dbms_output.put_line('p_status-- '||p_status);

--p_status:=-1;
--return;
	if p_chgdone = 2 
	then
		GiftFreeRbt(p_msisdn,p_int,p_updatedby,p_subtype,p_rbt,p_fmsisdn,p_chgcode,p_validityDays,p_status);
		RETURN;
	end if;
	p_status:=1; 
	select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
        if p_subtype = 'O' then
     		l_final_amount:=l_post_amount;
	else
	     	l_final_amount:=l_pre_amount;
	end if;
	select SCDR_ID.nextval into p_id from dual;
	p_status:=2; 
	insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,remarks,tariff_id,amount,action) values (p_id,p_msisdn,p_int,sysdate,1,'N',p_rbt,p_subtype,p_refid,p_fmsisdn,p_chgcode,l_final_amount,'G');
	p_status:=3;
	commit;
	dbms_output.put_line('p_status-- '||p_status || '---MSISDN---'||p_fmsisdn);
										
	select wallet_id into l_temp from crbt_wallet_master where msisdn=p_fmsisdn and wallet_name='DEFAULT';
	p_status:=4;
	dbms_output.put_line('p_status-- '||p_status);
	select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
        if l_isSystemRbtBased=1 then
		insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,is_rbt_gifted,expiry_date,fmsisdn) values (l_temp,p_rbt,sysdate-30+p_validityDays,p_fmsisdn,1,sysdate+p_validityDays,p_msisdn);
	else
		insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,is_rbt_gifted,expiry_date,fmsisdn) values (l_temp,p_rbt,sysdate,p_fmsisdn,1,sysdate+p_validityDays,p_msisdn);
	end if;
	commit;
	if p_packId > 0 then
		select TOTAL_GIFT,FREE_GIFT into l_totalGift,l_freeGift from crbt_pack_master where msisdn=p_msisdn and PACK_ID=p_packId and status='A';
		if l_totalGift > 0 then
			update crbt_pack_master set TOTAL_GIFT=TOTAL_GIFT-1 where msisdn=p_msisdn and PACK_ID=p_packId and status='A';
		elsif l_freeGift > 0 then
			update crbt_pack_master set FREE_GIFT=FREE_GIFT-1 where msisdn=p_msisdn and PACK_ID=p_packId and status='A';
		end if;
		commit;
	end if;
	p_status:=5;
	select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
	if l_isSystemRbtBased=1 then
		update crbt_subscriber_master set last_charged=sysdate-30+p_validityDays,expiry_date=sysdate+p_validityDays, update_time=sysdate where msisdn=p_fmsisdn and last_charged<=(sysdate-30+p_validityDays);
        	commit;
	end if;
											

	insert into crbt_rbt_gift_log (msisdn,subscriber_type,event_time,interface_type,op_code,friend_msisdn,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,1,p_fmsisdn,'Y',p_updatedby,p_id); 
	p_status:=6;
	commit;
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,'A RBT is Gifted to Friend '||p_fmsisdn,p_subtype,p_int,p_updatedby);
	p_status:=7;
	commit;
	select count(*) into l_temp from crbt_app_config_params where param_tag='GIFT_CONFIRM_ENABLE';
	if l_temp = 1 then
		select to_number(param_value) into l_temp from crbt_app_config_params where param_tag='GIFT_CONFIRM_ENABLE';
		if l_temp = 1 then
			select count(*) into l_temp from gift_pending_request where fmsisdn=p_fmsisdn and rbt_code=p_rbt;
			if l_temp >= 1 then
				 select fmsisdn_sub_status into l_subStatus from  gift_pending_request where fmsisdn=p_fmsisdn and rbt_code=p_rbt and rownum<2;  
				if l_subStatus = 'D' then
					SetDefaultRbt(p_fmsisdn,p_int,p_updatedby,p_subtype,p_rbt,8,2500,2500,3,p_refid,p_chgcode,p_validityDays,p_packId,p_status,p_id);

				end if;
				p_status:=8;
				delete from gift_pending_request where fmsisdn=p_fmsisdn and rbt_code=p_rbt;
				commit;
				p_status:=9;
			end if;
		end if;
	end if;
	exception
		when others then
			p_status:=(p_status*(-1));
End GiftRbt;

Procedure AddRbtToAlbumId (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_wltid in number,p_chgdone in number,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_status out number,p_id out number) is
l_temp 		number;
l_pre_amount  number;
l_post_amount  number;
l_final_amount number;
l_totalRbt number;
l_freeRbt number;
l_isSystemRbtBased number;
Begin
	p_status:=1;
	l_freeRbt:=0;
	l_totalRbt:=0;
	if p_chgdone = 2
	then
	-- special for haiti implementation
		AddFreeRbtToAlbId(p_msisdn,p_int,p_updatedby,p_subtype,p_rbt,p_wltid,p_chgcode,p_status,p_id);
	dbms_output.put_line('done AddRbtToAlbId 1');	
		RETURN;
	end if;
 	select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
        if p_subtype = 'O' then
		l_final_amount:=l_post_amount;
        else
	        l_final_amount:=l_pre_amount;
        end if;

	dbms_output.put_line('done AddRbtToAlbId 2');	
 	select SCDR_ID.nextval into p_id from dual;
	insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,tariff_id,amount,action) values (p_id,p_msisdn,p_int,sysdate,1,'N',p_rbt,p_subtype,p_refid,p_chgcode,l_final_amount,'R');
	p_status:=2;
dbms_output.put_line('done AddRbtToAlbId 3');
	p_status:=4;
	select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
        if l_isSystemRbtBased=1 then
		insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,expiry_date) values (p_wltid,p_rbt,sysdate-30+p_validityDays,p_msisdn,sysdate+p_validityDays);
	else
		insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,expiry_date) values (p_wltid,p_rbt,sysdate,p_msisdn,sysdate+p_validityDays);
	end if;
	commit;
	p_status:=5;
	dbms_output.put_line('done AddRbtToAlbId 4');
	if p_packId > 0 then
		select TOTAL_RBT,FREE_RBT into l_totalRbt,l_freeRbt from crbt_pack_master where MSISDN=p_msisdn and PACK_ID=p_packId and status='A';
		if l_totalRbt > 0 then
			update crbt_pack_master set TOTAL_RBT=TOTAL_RBT-1 where MSISDN=p_msisdn and PACK_ID=p_packId;
		elsif l_freeRbt > 0 then
			update crbt_pack_master set FREE_RBT=FREE_RBT-1 where MSISDN=p_msisdn and PACK_ID=p_packId;
		end if;
		commit;
	end if;
	dbms_output.put_line('done AddRbtToAlbId 5');
	select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
	if l_isSystemRbtBased=1 then
		update crbt_subscriber_master set last_charged=sysdate-30+p_validityDays, expiry_date=sysdate+p_validityDays, update_time=sysdate where msisdn=p_msisdn and last_charged<=(sysdate-30+p_validityDays);
        	commit;
	end if;
	insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,p_rbt,p_wltid,4,'Y',p_updatedby,p_id);
	commit;
	dbms_output.put_line('done AddRbtToAlbId 6');
	p_status:=6;
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,'RBT Added To Album '||p_wltid,p_subtype,p_int,p_updatedby);
	commit;
	p_status:=7;
dbms_output.put_line('done AddRbtToAlbId 7');
	update crbt_rbt set rbt_score=rbt_score+1 where rbt_code=p_rbt;
	commit;
	p_status:=8;
	dbms_output.put_line('done AddRbtToAlbId 8');
	exception
		when others then
			p_status:=(p_status*(-1));
End AddRbtToAlbumId;

Procedure AddRbtToAlbumName (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_wltname in varchar2,p_chgdone in number,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_status out number,p_id out number) is 
l_temp 		number ;
l_totalRbt number;
l_freeRbt number;
l_isSystemRbtBased number;
Begin
	l_temp:=0;
	l_totalRbt:=0;
	l_freeRbt:=0;
	if p_chgdone = 2 
	then
		AddFreeRbtToAlbName( p_msisdn,p_int,p_updatedby,p_subtype,p_rbt,p_wltname,p_status,p_id) ;-- special for Haiti implementation.

		p_status:=1;
		p_id:=-1;
		RETURN;
	elsif p_chgdone != 1
	then
		p_status:=1;
		p_id:=-1;
		RETURN;
	end if;
	p_status:=1;				
	l_temp:= 0;
	GenerateRBTSettingCDR(p_msisdn,p_int,p_subtype,1,p_rbt,p_refid,p_chgcode,p_id);

	if p_id=-1
	then
		p_status:=-18;
		RETURN;
	end if;
												
	dbms_output.put_line('b4 AddAlbum ');
											
	AddAlbum (p_msisdn,p_int ,p_updatedby ,p_subtype ,p_rbt,p_wltname,l_temp); 
   	if l_temp=-1
	then
		p_status:=-1;
		RETURN;
	end if;
	p_status:=2;				
	dbms_output.put_line('after AddAlbum wallet_id'||l_temp);
	select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
        if l_isSystemRbtBased=1 then
		insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,expiry_date) values (l_temp,p_rbt,sysdate-30+p_validityDays,p_msisdn,sysdate+p_validityDays);
	else
		insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,expiry_date) values (l_temp,p_rbt,sysdate,p_msisdn,sysdate+p_validityDays);
	end if;
	commit;
	dbms_output.put_line('after AddAlbum wallet_id'||l_temp);
	p_status:=3;				
        if p_packId > 0 then
                select TOTAL_RBT,FREE_RBT into l_totalRbt,l_freeRbt from crbt_pack_master where MSISDN=p_msisdn and PACK_ID=p_packId and status='A';
                if l_totalRbt > 0 then
                        update crbt_pack_master set TOTAL_RBT=TOTAL_RBT-1 where MSISDN=p_msisdn and PACK_ID=p_packId;
                elsif l_freeRbt > 0 then
                        update crbt_pack_master set FREE_RBT=FREE_RBT-1 where MSISDN=p_msisdn and PACK_ID=p_packId;
                end if;
                commit;
        end if;
	p_status:=4;				
	if l_isSystemRbtBased=1 then
		update crbt_subscriber_master set last_charged=sysdate-30+p_validityDays, expiry_date=sysdate+p_validityDays, update_time=sysdate where msisdn=p_msisdn and last_charged<=(sysdate-30+p_validityDays);
        	commit;
	end if;
	p_status:=5;				
	insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,p_rbt,l_temp,4,'Y',p_updatedby,p_id);
	commit;
	p_status:=6;				
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,p_rbt||'RBT Added To Album '||p_wltname,p_subtype,p_int,p_updatedby);
	p_status:=7;				
	commit;
	update crbt_rbt set rbt_score=rbt_score+1 where rbt_code=p_rbt;
	p_status:=6;
	commit;
	exception
		when others then
			p_id:=-1;
			p_status:=(p_status*(-1));
End AddRbtToAlbumName;
				
				Procedure SetAdvanceRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_advop in varchar2,p_fmsisdn in varchar2,p_opfor in number,p_status out number) is 
				l_temp 			 number ;
				l_ctrlid 		number;
				l_catid varchar2(10);
				p_id number;
				cursor cursor_spl_ctrl_cat_id is select param_value from crbt_app_config_params where param_tag='SPECIAL_CONTROL_CATID';
				cursor cursor_sel_ctrl_code is select control_id from crbt_rbt_control where cat_id=l_catid and control_name=upper(p_advop);
				Begin
												p_status:=1;
												open cursor_spl_ctrl_cat_id ;
												fetch cursor_spl_ctrl_cat_id into l_catid;
												if cursor_spl_ctrl_cat_id%NOTFOUND 
												then
																close cursor_spl_ctrl_cat_id;
																p_status:=-10;
																RETURN;
												else
																close cursor_spl_ctrl_cat_id;
												end if;
												
												open cursor_sel_ctrl_code ;
												fetch cursor_sel_ctrl_code into l_ctrlid;
												if cursor_sel_ctrl_code%NOTFOUND 
												then
																close cursor_sel_ctrl_code;
																p_status:=-11;
																RETURN;
												else
																close cursor_sel_ctrl_code;
												end if;

												if p_opfor = 1 
												then
												update crbt_subscriber_master set rbt_code=l_ctrlid where msisdn=p_msisdn;
												commit;
												elsif p_opfor = 2
												then

            l_temp:=0;
				        select count(*) into l_temp from crbt_friend_detail where msisdn=p_msisdn and friend_msisdn=p_fmsisdn;
										  if l_temp = 0
											then
											
											dbms_output.put_line( ' friend not exist crbt_friend_detail ' );
															
																insert into crbt_friend_detail (msisdn,friend_msisdn,friend_setting_string,control_rbt_code) values (p_msisdn,p_fmsisdn,'000000000000000000000000000000000000000000000000000000000000',l_ctrlid);
												commit;

            	insert into crbt_friend_op_log (msisdn,subscriber_type,event_time,interface_type,op_code,friend_msisdn,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,1,p_fmsisdn,'N',p_updatedby,0);
												commit;
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Friend '||p_fmsisdn||' is Added',p_subtype,p_int,p_updatedby);

												commit;

												dbms_output.put_line( 'friend not exist  days inserting in crbt_friend_op_log' );
												commit;
             
       --    		RETURN;
																else
																				update crbt_friend_detail set control_rbt_code=l_ctrlid where msisdn=p_msisdn and friend_msisdn=p_fmsisdn;
																				commit;
																end if;
												else
																l_temp:=0;
																select count(*) into l_temp from crbt_group_detail where msisdn=p_msisdn and masked_name=upper(p_fmsisdn);
																if l_temp = 0
																then
																				p_status:=-13;
																				RETURN;
																else
																				update crbt_group_detail set control_rbt_code=l_ctrlid where msisdn=p_msisdn and masked_name=upper(p_fmsisdn); 
																				commit;
															end if;
												end if;
												p_id:=-1;
												p_status:=2;
			
												insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,l_ctrlid,p_int,6,p_fmsisdn,'N',p_updatedby,p_id,1); 
												p_status:=3;
												commit;
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Advance Setting is done for '||p_fmsisdn,p_subtype,p_int,p_updatedby);
												commit;
												p_status:=4;

								exception
												when others then
												p_status:=(p_status*(-1));
	End SetAdvanceRbt;
				
 Procedure CheckRbtCode (p_msisdn in varchar2,p_rbtcode in number,p_status out number,p_chgcode out number,p_catid out number,p_cpid out number) is 
				l_temp 			           number ;
				l_pv 	          varchar2(10) ;
				l_pi  			            number ;
				l_cat 			            number ;
				l_pcat 			           number ;
				l_freecat			         number ;
				l_advcat			          number ;
				l_chgcode            number ;
				l_fcenabled	         number ;
				l_diffchgenabled     number ;
				l_status	varchar2(2);
				
				-- param_id = 87  , param_tag = ADVERTISEMENT_CAT_ID
				-- param_id = 104 , param_tag = DIFFERENT_RBT_CHARGING_ENABLED
				-- param_id = 105 , param_tag = FREE_RBT_ENABLED
				-- param_id = 106 , param_tag = FREE_RBT_CAT_ID
				cursor cursor_rbt_code is select rbt_code,cat_id,charging_code,cat_id,content_provider_Code from crbt_rbt where rbt_code=p_rbtcode and (show_in_sms='Y' or show_on_web='Y' or playable='Y') ;
				cursor cursor_wlt_cnt is select rbt_code,status from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbtcode;
				--cursor cursor_app_config is select param_Value,param_id from crbt_app_config_params where param_id in (87,104,105,106);
    				cursor cursor_app_config is select param_value,param_id from crbt_app_config_params where param_tag in ('ADVERTISEMENT_CAT_ID','DIFFERENT_RBT_CHARGING_ENABLED','FREE_RBT_ENABLED','FREE_RBT_CAT_ID');
				Begin
			         l_diffchgenabled:=-1;
            l_fcenabled:=-1;
            l_advcat:=-1;
            l_freecat:=-1;									
				
    l_temp:=-1;
l_pv:=-1;
l_pi:=-1;
l_cat:=-1;
l_pcat:=-1;
l_chgcode:=-1;

	p_catid:=-99;
	p_cpid:=-99;
												p_chgcode:=-1;
												p_status:=0;

--p_status:=-26;
--return;
												open cursor_rbt_code ;
												fetch cursor_rbt_code into l_temp,l_cat,l_chgcode,p_catid,p_cpid;

dbms_output.put_line('-----------------cursor1');
												if cursor_rbt_code%NOTFOUND 
												then
																close cursor_rbt_code;
																p_status:=-14;
																RETURN;
												else
																close cursor_rbt_code;
												end if;
												l_temp:=0;
												p_chgcode:=l_chgcode;
												
												open cursor_wlt_cnt ;
												fetch cursor_wlt_cnt into l_temp,l_status;

dbms_output.put_line('-----------------cursor2');
												if cursor_wlt_cnt%NOTFOUND 
												then
																close cursor_wlt_cnt;
																open cursor_app_config ;
															 LOOP	
																				l_temp:=0;
																				fetch cursor_app_config into l_pv,l_pi;
dbms_output.put_line('-----------------cursor3');
																
																				if cursor_app_config%NOTFOUND
																				then
																								close cursor_app_config;
																								EXIT	;
																				else
																								l_temp:=to_number (l_pv);

dbms_output.put_line('>>>>l_temp  ' || l_temp  || 'l_pi  ' ||l_pi);	
																								if l_pi = 87 
																								then
																												l_advcat:=l_temp;
																								elsif l_pi = 104
																								then
																												l_diffchgenabled:=l_temp;
																								elsif l_pi = 105
																								then
																												l_fcenabled:=l_temp;
																								elsif l_pi = 106
																								then
																												l_freecat:=l_temp;
																								else
																												p_status:=-1;
																												close cursor_app_config;
																												RETURN;
																								end if;
																				end if;
                end loop; 
																dbms_output.put_line('l_temp  '	|| l_temp);		
																if l_advcat = l_cat 
																then
																		p_status:=-24;
																		RETURN;
																end if;
																				
                if l_fcenabled = 1 and l_freecat = l_cat
																then
																	 p_status:=-26;
																		RETURN;	
																end if;	
																						
																if l_diffchgenabled = 1 
																then
																		p_status:=-27;
																		RETURN;
																end if;
												p_status:=-15;
												RETURN;
												else
																close cursor_wlt_cnt;
												end if;
if l_status='I' then
												p_status:=-31;
else
												p_status:=-7;
end if;
								exception
												when others then
												p_status:=-1;
	End CheckRbtCode;

Procedure SetDateRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_occasion in varchar2,p_chgdone in number,p_date in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_status out number) is
				l_temp 		number;
				p_id number;
				Begin
								p_status:=1;
								p_id:=-1;
												AddRbtToAlbumName(p_msisdn,p_int,p_updatedby,p_subtype,p_rbt,'DEFAULT',p_chgdone,p_refid,p_chgcode,p_validityDays,p_packId,p_status,l_temp);
												if p_status < 0
												then
															--	p_status:=-1;
																RETURN;
												else
																p_id:=l_temp;
												end if;
								p_status:=2;

								l_temp:=0;
				    select count(*) into l_temp from crbt_eventdate_rbt where msisdn=p_msisdn and to_date(to_char(event_date,'ddmmyy'),'ddmmyy')=to_date(p_date,'ddmmyy');
				    if l_temp = 0 then
												insert into crbt_eventdate_rbt (msisdn,event_date,rbt_code,update_time,occasion_name) values (p_msisdn,to_date(p_date,'ddmmyy'),p_rbt,sysdate,p_occasion);
								p_status:=3;
								else
												update crbt_eventdate_rbt set rbt_code=p_rbt,content_type=0 where msisdn=p_msisdn and 	to_date(to_char(event_date,'ddmmyy'),'ddmmyy')=to_date(p_date,'ddmmyy');
								end if;
								commit;
								p_status:=4;

								if to_date(p_date,'ddmmyy') = to_date(to_char(sysdate,'ddmmyy'),'ddmmyy')
								then
												update crbt_subscriber_master set date_setting_validity=1 where msisdn=p_msisdn;
												commit;
								end if;
								p_status:=5;
								
								insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_rbt,p_int,1,p_date,'N',p_updatedby,p_id,1); 
								p_status:=6;
								commit;
								insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A RBT for Date '||p_date||' is set',p_subtype,p_int,p_updatedby);
								p_status:=7;
								commit;

								exception
												when others then
												p_status:=(p_status*(-1));
	End SetDateRbt;

 Procedure DeleteDefaultSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_status out number) is 
				l_char varchar2 (1);
				l_length PLS_INTEGER;
				Begin
								p_status:=1;
												if p_days = 8
												then
																delete from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_rbt and day=p_days and start_at=p_sttime and ends_at=p_entime;
																commit;
																p_status:=2; -- this value will be checked in code and string will be updated
												else
																l_length:=LENGTH(p_days);
																IF l_length > 0
																THEN
																				FOR l_index IN 1 .. l_length
																				LOOP
																								l_char := SUBSTR (p_days,l_index, 1);
																												delete from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_rbt and day=l_char and start_at=p_sttime and ends_at=p_entime;
																												commit;
																												p_status:=2; -- this value will be checked in code and string will be updated
																				END LOOP;
																END IF;
												END IF;

												insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_rbt,p_int,5,'DEFAULT','N',p_updatedby,-1,1); 
												commit;
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Default profile is deleted',p_subtype,p_int,p_updatedby);
												commit;


								exception
												when others then
												--				dbms_output.put_line( 'exception occured ');
												p_status:=-1;
												--p_status:=8;
	End DeleteDefaultSetting;

Procedure DeleteFriendSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_fmsisdn in varchar2,p_status out number) is 
				l_length PLS_INTEGER;
				l_char varchar2 (1);
				Begin
								p_status:=1;

								select count(*) into l_length from crbt_friend_detail where msisdn=p_msisdn and friend_msisdn=p_fmsisdn;

								if l_length = 0
								then
												p_status:=-12;
												RETURN;
								end if;
								l_length:=0;
								
								if p_days = 8
								then
												delete from crbt_friend_setting where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and rbt_code=p_rbt and day=p_days and start_at=p_sttime and ends_at=p_entime ;
												commit;
												p_status:=2; -- this value will be checked in code and string will be updated
								else
												l_length:=LENGTH(p_days);
												IF l_length > 0
												THEN
																FOR l_index IN 1 .. l_length
																LOOP
																				l_char := SUBSTR (p_days,l_index, 1);
																				delete from crbt_friend_setting where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and rbt_code=p_rbt and day=l_char and start_at=p_sttime and ends_at=p_entime ;
																				commit;
																   	p_status:=2; -- this value will be checked in code and string will be updated
																END LOOP;
												END IF;
								end if;
								insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_rbt,p_int,5,p_fmsisdn,'N',p_updatedby,-1,1); 
								commit;
								insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'Setting of friend '||p_fmsisdn||' is deleted',p_subtype,p_int,p_updatedby);
								commit;

								exception
												when others then
												p_status:=-1;
	End DeleteFriendSetting;

 Procedure DeleteGroupSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in number,p_sttime in number,p_entime in number,p_grp in varchar2,p_status out number,p_grpid out number) is 
				l_length PLS_INTEGER;
				l_char varchar2 (1);
				cursor sel_grp_id is select groupid from crbt_group_detail where msisdn=p_msisdn and upper(masked_name)=upper(p_grp);
				Begin
												p_status:=1;
												l_length:=0;
												open sel_grp_id;
												fetch sel_grp_id into p_grpid;
												if sel_grp_id%NOTFOUND 
												then
																close sel_grp_id;
																p_status:=-13;
																RETURN;
												else
																close sel_grp_id;
												end if;
												
								if p_days = 8
								then
												delete from crbt_group_setting where msisdn=p_msisdn and groupid=p_grpid and rbt_code=p_rbt and day=p_days and start_at=p_sttime and ends_at=p_entime; 
												commit;
												p_status:=2; -- this value will be checked in code and string will be updated
								else
												l_length:=LENGTH(p_days);
												IF l_length > 0
												THEN
																FOR l_index IN 1 .. l_length
																LOOP
																				l_char := SUBSTR (p_days,l_index, 1);
																				delete from crbt_group_setting where msisdn=p_msisdn and groupid=p_grpid and rbt_code=p_rbt and day=l_char and start_at=p_sttime and ends_at=p_entime; 
																				commit;
																   	p_status:=2; -- this value will be checked in code and string will be updated
																END LOOP;
												END IF;
								end if;
												
								insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_rbt,p_int,5,p_grpid,'N',p_updatedby,-1,1); 
								commit;
								insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'Setting of group '||p_grp||' is deleted',p_subtype,p_int,p_updatedby);
								commit;

												
								exception
												when others then
												p_status:=-1;
	End DeleteGroupSetting;

  Procedure DeleteAdvanceSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_fmsisdn in varchar2,p_opfor in number,p_status out number) is 
				l_temp 			 number ;
				p_id number;
				Begin
												p_status:=1;

												if p_opfor = 1 
												then
												select rbt_code into l_temp from crbt_default_detail where msisdn=p_msisdn and day=8 and start_at=2500 and ends_at=2500;
												p_status:=2;
												update crbt_subscriber_master set rbt_code=l_temp where msisdn=p_msisdn;
												p_status:=3;
												commit;
												elsif p_opfor = 2
												then
																l_temp:=0;
																select count(*) into l_temp from crbt_friend_detail where msisdn=p_msisdn and friend_msisdn=p_fmsisdn;
												p_status:=4;
																if l_temp=0
																then
																				p_status:=-12;
																				RETURN;
																else
																				update crbt_friend_detail set control_rbt_code=0 where msisdn=p_msisdn and friend_msisdn=p_fmsisdn;
												p_status:=5;
																				commit;
																end if;
												else
																l_temp:=0;
																select count(*) into l_temp from crbt_group_detail where msisdn=p_msisdn and upper(masked_name)=upper(p_fmsisdn);
												p_status:=6;
																if l_temp = 0
																then
																				p_status:=-13;
																				RETURN;
																else
																				update crbt_group_detail set control_rbt_code=0 where msisdn=p_msisdn and upper(masked_name)=upper(p_fmsisdn); 
												p_status:=7;
																				commit;
																end if;
												end if;
			
												insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,0,p_int,7,p_fmsisdn,'N',p_updatedby,-1,1); 
												p_status:=8;
												commit;
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Advanced Profile For '||p_fmsisdn||' is Deleted',p_subtype,p_int,p_updatedby);
												commit;
												p_status:=9;
												commit;

												--select masked_name into p_rbtname from crbt_rbt where rbt_code=p_rbt;
								exception
												when others then
												p_status:=(p_status*(-1));
	End DeleteAdvanceSetting;

Procedure DeleteRBT (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_status out number,p_updatecode out number,p_filePath out varchar2) is 
				--l_temp 		PLS_INTEGER ;
				l_temp 		number ;
				l_cnt 		number ;
				l_wltid 		number ;
				chk_recorded varchar2(50);
				cursor sel_wlt_id is select wallet_id from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbt;
				Begin
												p_status:=1;				
												l_temp:=0;
												l_cnt:=0;
												l_wltid:=0;
												p_updatecode:=0;
p_filePath:='NA';
												open sel_wlt_id;
												fetch sel_wlt_id into l_wltid;
												if sel_wlt_id % NOTFOUND 
												then
																close sel_wlt_id;
																p_status:=-17;
																RETURN;
												else
																close sel_wlt_id;
												end if;

												select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_rbt;
													p_status:=2;
												if l_temp = 0
												then
																p_updatecode:=0;	-- no need to update default setting string
												else
																select count(*) into l_cnt from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_rbt and day=8 and start_at=2500 and ends_at=2500;
													p_status:=3;
																if l_cnt = 0
																then
																				p_updatecode:=1; -- default setting will not be effected but default string needs to be updated
																else
																				update crbt_default_detail set rbt_code=0 where msisdn=p_msisdn and day=8 and start_at=2500 and ends_at=2500;
																				commit;
													p_status:=4;
																				update crbt_subscriber_master set rbt_code=0 where msisdn=p_msisdn;
																				commit;
													p_status:=5;
												--								 if user has more than one settings for this string only then string will be updated
																				if l_temp > 1
																				then
																								p_updatecode:=1;
																				end if;
																end if;
												end if;
												
												l_temp:=0;
												select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and rbt_code=p_rbt;
													p_status:=6;
												if l_temp > 0
												then
																p_updatecode:=(p_updatecode + 2);
												end if;
												
												l_temp:=0;
												select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and rbt_code=p_rbt;
													p_status:=7;
												if l_temp > 0
												then
																p_updatecode:=(p_updatecode + 4);
												end if;
												select masked_name into chk_recorded from crbt_rbt where rbt_code=p_rbt;
													p_status:=8;

if chk_recorded = 'RECORDED' then
                                                                   delete from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbt;
                                                                        delete from crbt_rbt_owner where rbt_code=p_rbt and msisdn=p_msisdn;
                                                                                                        delete from crbt_rbt where rbt_code=p_rbt;
                                                                                                        commit;
                                                                                                        p_status:=9;
                                                                                                        insert into crbt_rbt_record_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_rbt,'I',2,'N',p_msisdn,-1);
                                                                commit;
                                                        p_status:=10;
                                                                                                        else
                                                                                                
-----------------added by pankaj gupta for system default album starts----------------------
l_temp:=-1;
select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and rbt_code=0 and content_type=0;
p_status:=11;
if l_temp > 0 then 
	delete from  crbt_default_detail where msisdn=p_msisdn and rbt_code=p_rbt and content_type=0;
	commit;
	p_status:=12;
end if;

l_temp:=-1;
select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and rbt_code=0 and content_type=0;
p_status:=13;
if l_temp > 0 then
        delete from  crbt_group_setting where msisdn=p_msisdn and rbt_code=p_rbt and content_type=0;
        commit;
        p_status:=14;
end if;

l_temp:=-1;
select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and rbt_code=0 and content_type=0;
p_status:=15;
if l_temp > 0 then
        delete from  crbt_friend_setting where msisdn=p_msisdn and rbt_code=p_rbt and content_type=0;
        commit;
        p_status:=16;
end if;

l_temp:=-1;
select count(*) into l_temp from crbt_eventdate_rbt where msisdn=p_msisdn and rbt_code=0 and content_type=0;
p_status:=17;
if l_temp > 0 then
        delete from  crbt_eventdate_rbt where msisdn=p_msisdn and rbt_code=p_rbt and content_type=0;
        commit;
        p_status:=18;
end if;

-----------------added by pankaj gupta for system default album ends----------------------


delete from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbt;
commit;
p_status:=19;
                                                                                                end if;
                                                                                                insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,p_rbt,l_temp,5,'N',p_updatedby,-1);
                                                                                                commit;
                                                                                                        p_status:=20;
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A RBT '||p_rbt|| 'is Deleted from Album',p_subtype,p_int,p_updatedby);
												commit;
												p_status:=21;
								exception
												when others then
												p_status:=(p_status*(-1));
	End DeleteRBT;





	Procedure GenerateRBTSettingCDR (p_msisdn in varchar2,p_int in varchar2,p_subtype in varchar2,p_plan in number,p_rbt in number,p_refid in varchar2,p_chgcode in number,p_id out number) is 
	l_pre_amount  number;
	l_post_amount  number;
	l_final_amount number;

	Begin
	select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
	if p_subtype = 'O' then
	l_final_amount:=l_post_amount;
	else
	l_final_amount:=l_pre_amount;
	end if;

	select SCDR_ID.nextval into p_id from dual;
	insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,tariff_id,amount,action) values (p_id,p_msisdn,p_int,sysdate,p_plan,'N',p_rbt,p_subtype,p_refid,p_chgcode,l_final_amount,'R');
	commit;

	dbms_output.put_line( 'subscriber is prepaid ..secdr id ' || p_id);
	exception
	when others then
	p_id:=-1;
	End GenerateRBTSettingCDR;
	
	Procedure AddAlbum (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_wltname in varchar2,p_id out number) is 
				l_temp 		number ;
				cursor sel_wlt_id is select wallet_id from crbt_wallet_master where msisdn=p_msisdn and upper(wallet_name)=upper(p_wltname);
				Begin
		dbms_output.put_line('b4 AddAlbum '||p_msisdn||'-- '||p_int||'--p_wltname'||p_wltname);
												l_temp:=0;
												open sel_wlt_id;
												fetch sel_wlt_id into p_id;
												if sel_wlt_id%NOTFOUND 
												then
																close sel_wlt_id;
																l_temp:=0;
																select wallet_id_seq.nextval into p_id from dual;
																select max(ivr_name) into l_temp from crbt_wallet_master where msisdn=p_msisdn;
																l_temp:= (l_temp+1);
																insert into crbt_wallet_master (msisdn,wallet_id,create_date,wallet_name,ivr_name) values (p_msisdn,p_id,sysdate,upper(p_wltname),l_temp);
																commit;
												else
																close sel_wlt_id;
																RETURN;
												end if;
												insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,p_rbt,p_id,1,'N',p_updatedby,-1);
												commit;
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Album '||p_wltname||' is Added',p_subtype,p_int,p_updatedby);
												commit;


								exception
												when others then
												p_id:=-1;
	End AddAlbum;

Procedure CheckForSubscription(p_msisdn in varchar2,p_maxsub in number,p_plan in number,p_status out number) is
l_temp 		number ;
Begin
	p_status:=1;
	l_temp:=0;
	select to_number(param_value) into l_temp from crbt_app_config_params where param_tag like 'WHITELIST_ENABLE';
	if l_temp = 1 then
		select count(*) into l_temp from crbt_whitelist where to_number(STARTS_AT) <=to_number(p_msisdn) and to_number(ENDS_AT) >=to_number(p_msisdn);
		if l_temp = 0 then
			p_status:=-25;
			return;
		end if;
	end if;

	select count(msisdn) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status != 'D';
	if l_temp!=0
	then
		select plan_indicator into l_temp from  crbt_subscriber_master where msisdn=p_msisdn ;
		
		if l_temp != p_plan  and p_plan!=-1 then
			p_status:=-33;			-- person is already subscribe with different plan
		else
		p_status:=-20;
		end if;
		RETURN;
	end if;
	l_temp:=0;
	select count(msisdn) into l_temp from crbt_subscriber_master where status='A';
	if l_temp > p_maxsub
	then
		p_status:=-21;
		RETURN;
	end if;

	l_temp:=0;

	select count(range_id) into l_temp from OPERATOR_SUBSCRIBER where (to_number(STARTS_AT) <=to_number(p_msisdn) and to_number(ENDS_AT) >=to_number(p_msisdn) and p_msisdn not in (select EXCLUDE_NUM from OPERATOR_SUBSCRIBER_EXCLUDE)) or p_msisdn in ( select INCLUDE_NUM from OPERATOR_SUBSCRIBER_INCLUDE);
	dbms_output.put_line( 'in procedure subscriber msisdn===' || p_msisdn);
	dbms_output.put_line( 'in procedure subscriber l_temp===' || l_temp);
											
	if l_temp=0
	then
		p_status:=-22;
		RETURN;
	end if;

	exception
		when others then
			p_status:=-1;		
End CheckForSubscription;


				Procedure DeleteAlbum (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_albid in number,p_albname in varchar2,p_status out number) is 
				Begin
												p_status:=1;
												if p_albid = -1
												then
																Delete from crbt_wallet_master where msisdn=p_msisdn and upper(wallet_name)=upper(p_albname);
																commit;
																p_status:=2;
																insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Album '||p_albname||' is Deleted',p_subtype,p_int,p_updatedby);
																p_status:=3;
												commit;


												else
																Delete from crbt_wallet_master where msisdn=p_msisdn and wallet_id=p_albid ;
																commit;
																p_status:=4;
																insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Album '||p_albid||' is Deleted',p_subtype,p_int,p_updatedby);
																p_status:=5;
												commit;

												end if;
												commit;

												insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,-1,p_albid,2,'N',p_updatedby,-1);
																p_status:=6;
												commit;
								exception
												when others then
												p_status:=(p_status*(-1));
				end DeleteAlbum;
	
	Procedure DeleteDateRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number, p_date in varchar2,p_status out number) is 
				l_temp 		number;
				p_id number;
				Begin
								p_status:=1;
								p_id:=-1;

								delete crbt_eventdate_rbt where msisdn=p_msisdn and rbt_code=p_rbt and to_date(to_char(event_date,'ddmmyy'),'ddmmyy')=to_date(p_date,'ddmmyy');
								commit;
								p_status:=4;

								if to_date(p_date,'ddmmyy') = to_date(to_char(sysdate,'ddmmyy'),'ddmmyy')
								then
												update crbt_subscriber_master set date_setting_validity=0 where msisdn=p_msisdn;
												commit;
								end if;
								p_status:=5;
								
								insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_rbt,p_int,5,p_date,'N',p_updatedby,p_id,1); 
								p_status:=6;
								commit;
								insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A RBT for Date '||p_date||' is Deleted',p_subtype,p_int,p_updatedby);
								p_status:=7;
								commit;

								exception
												when others then
												p_status:=(p_status*(-1));
	End DeleteDateRbt;
				Procedure Deactivate (p_msisdn in varchar2  ,p_int in varchar2 ,p_updatedby in varchar2 ,p_subtype in varchar2 ,p_status out number ,p_id out number ) is 
				Begin
												p_id:=1;
												p_status:=4;
																dbms_output.put_line( 'after cdr');
												update crbt_subscriber_master set status='I', update_time=sysdate where msisdn=p_msisdn;
												p_status:=5;
												commit;
																dbms_output.put_line( 'after deletion');
												insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,'I',p_int,'N',p_updatedby,1);
												p_status:=6;
												commit;
																dbms_output.put_line( 'subscription log');
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'DEACTIVATED',p_subtype,p_int,p_updatedby);
												p_status:=7;
												commit;
																dbms_output.put_line( 'activity log');
												p_status:=8;
								exception
												when others then
												p_status:=(p_status*(-1));
	End Deactivate;

Procedure Activate (p_msisdn in varchar2,p_plan in number ,p_int in varchar2,p_days in number,p_updatedby in varchar2,p_subtype in varchar2,p_refid in varchar2,p_chgcode in number,p_isactive in out number,p_status out number,p_id out number) is 
l_action 		varchar2 (5);
l_reqdata varchar2 (50);
l_status varchar2 (2);
l_pre_amount  number;
l_post_amount  number;
l_final_amount number;
l_isSystemRbtBased number;
Begin
	p_status:=1;
	p_id:=1;
	if p_isactive = -1 then
		select status into l_status from crbt_subscriber_master where msisdn=p_msisdn; 
		if l_status = 'I' then
			p_isactive:=0;
		elsif l_status = 'A' then
			p_isactive:=1;
		else
			p_status:=-25;
			RETURN;
		end if;
	end if;
	p_status:=1;
	if p_isactive = 1 then
		l_action:='S'||p_days;
		l_reqdata:='RENEWED FOR '||p_days ||' DAYS';
        else
                l_action:='A' || p_days;
		l_reqdata:='ACTIVATED FOR '||p_days ||' DAYS';
	end if;

	p_status:=19;
	select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
	if p_subtype = 'O' then
		l_final_amount:=l_post_amount;
	else
		l_final_amount:=l_pre_amount;
	end if;
	l_isSystemRbtBased:=0;
	select count(*) into l_isSystemRbtBased from crbt_app_config_params where param_tag='RBT_BASED_SUBSCRIPTION';
	if l_isSystemRbtBased = 1 then
		select to_number(param_value) into l_isSystemRbtBased from crbt_app_config_params where param_tag='RBT_BASED_SUBSCRIPTION';
		p_status:=11;
	end if;
	if l_isSystemRbtBased = 1 and p_int='M' then
		p_status:=2;
	else
		select SCDR_ID.nextval into p_id from dual;
		insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,tariff_id,amount) values (p_id,p_msisdn,p_int,sysdate,l_action,p_plan,'N',p_subtype,p_refid,p_chgcode,l_final_amount);
	dbms_output.put_line( 'subscriber is postpaid ..scdr id ' || p_id);
	end if;
	p_status:=2;
	commit;
	p_status:=4;
	if p_days > 0 then
		update crbt_subscriber_master set status='A',last_charged=sysdate-30+p_days,expiry_date=sysdate+p_days, update_time=sysdate where msisdn = p_msisdn;
	else
		update crbt_subscriber_master set status='A',last_charged=sysdate,expiry_date=sysdate, update_time=sysdate where msisdn = p_msisdn;
	end if;
	commit;
	p_status:=5;
	insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,l_action,p_int,'Y',p_updatedby,p_id);
	commit;
	p_status:=9;
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,l_reqdata,p_subtype,p_int,p_updatedby);
	commit;
	p_status:=10;
	exception
		when others then
			delete from crbt_event_cdr where msisdn=p_msisdn and cdr_id=p_id;
			commit;
			p_status:=(p_status*(-1));
End Activate;
Procedure AddRecordedRbt (p_msisdn in varchar2, p_rbtpath in varchar2,p_catId in number,p_subtype in varchar2,call_Id in number,p_validityDays in number,p_packId in number,p_status out number) is 
p_id number;	
l_temp number;	
l_totalRecording number;
l_freeRecording number;
l_isSystemRbtBased number;
Begin
	p_id:=-1;
	l_temp:=-1;
	l_freeRecording:=0;
	l_totalRecording:=0;
	select crbt_rbt_code.nextval into p_status from dual;
	p_id:=1;
	insert into crbt_rbt (rbt_code, masked_name,file_path,rbt_score,ivr_filepath,playable,show_on_web,show_in_sms,CONTENT_PROVIDER_CODE,cat_id,corp_id) values (p_status,'RECORDED',p_rbtpath,1,p_rbtpath,'Y','Y','Y',1,p_catId,0); 
	commit;
	p_id:=2;
	insert into crbt_rbt_owner (msisdn,rbt_code,create_time,usage_status) values (p_msisdn,p_status,sysdate,'Y');
	commit;
	p_id:=3;
	select wallet_id into l_temp from crbt_wallet_master where msisdn=p_msisdn and wallet_name='DEFAULT';
	if l_temp >0  then
		p_id:=4;
		select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
	        if l_isSystemRbtBased=1 then
			insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,is_rbt_gifted,expiry_date) values (l_temp,p_status,sysdate-30+p_validityDays,p_msisdn,3,sysdate+p_validityDays);
		else
			insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,is_rbt_gifted,expiry_date) values (l_temp,p_status,sysdate,p_msisdn,3,sysdate+p_validityDays);
		end if;
		commit;
		p_id:=5;
	        if p_packId > 0 then
       			select TOTAL_RECORDING,FREE_RECORDING into l_totalRecording,l_freeRecording from crbt_pack_master where MSISDN=p_msisdn and PACK_ID=p_packId and status='A';
                	if l_totalRecording > 0 then
                        	update crbt_pack_master set TOTAL_RECORDING=TOTAL_RECORDING-1 where MSISDN=p_msisdn and PACK_ID=p_packId;
                	elsif l_freeRecording > 0 then
                        	update crbt_pack_master set FREE_RECORDING=FREE_RECORDING-1 where MSISDN=p_msisdn and PACK_ID=p_packId;
                	end if;
                	commit;
        	end if;

	select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
	if l_isSystemRbtBased=1 then
		update crbt_subscriber_master set last_charged=sysdate-30+p_validityDays, expiry_date=sysdate+p_validityDays, update_time=sysdate where msisdn=p_msisdn and last_charged<=(sysdate-30+p_validityDays);
        	commit;
	end if;
		insert into crbt_rbt_record_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_status,'I',1,'N',p_msisdn,call_Id); 
		commit;
		p_id:=6;
	else
		p_id:=7;
		p_status:=(p_id*(-1));
	end if;
	exception
		when others then
			delete from crbt_rbt where rbt_code=p_status;
			commit;
			p_status:=(p_id*(-1));
End AddRecordedRbt;

	Procedure AddFreeRbtToAlbName (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_wltname in varchar2,p_status out number,p_id out number) is 
				l_temp 		number ;
				Begin
												p_status:=1;
												p_id:=-1;
												GenerateCrbtCdrs (p_msisdn,-1,3,p_int,-1,0,sysdate,'NA',p_rbt,0,p_subtype,p_status,p_id);
												-- code for generating cdrs for free rbt
												
												AddAlbum (p_msisdn,p_int ,p_updatedby ,p_subtype ,p_rbt,p_wltname,l_temp); 
								   	if l_temp=-1
												then
												p_status:=-1;
												RETURN;
												end if;
												p_status:=2;				

												insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn) values (l_temp,p_rbt,add_months(trunc(sysdate),-2),p_msisdn);
												commit;
												p_status:=3;				
												insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,p_rbt,l_temp,4,'N',p_updatedby,p_id);
												commit;
												p_status:=4;				
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,'RBT Added To Album '||p_wltname,p_subtype,p_int,p_updatedby);
												p_status:=5;				
												commit;
												update crbt_rbt set rbt_score=rbt_score+1 where rbt_code=p_rbt;
												p_status:=6;
												commit;
								exception
												when others then
												p_id:=-1;
												p_status:=(p_status*(-1));
	End AddFreeRbtToAlbName;

 Procedure AddFreeRbtToAlbId (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_wltid in number,p_chgcode in number,p_status out number,p_id out number) is 
				l_temp 		number;
				Begin
												p_status:=1;

												GenerateCrbtCdrs (p_msisdn,p_chgcode,3,p_int,-1,0,sysdate,'NA',p_rbt,0,p_subtype,p_status,p_id);
												-- code for generating free rbt cdrs
												insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn) values (p_wltid,p_rbt,add_months(trunc(sysdate),-2),p_msisdn);
												p_status:=5;
												commit;
												insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,p_rbt,p_wltid,4,'N',p_updatedby,p_id);
												p_status:=6;
												commit;
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,'RBT Added To Album '||p_wltid,p_subtype,p_int,p_updatedby);
												p_status:=7;
												commit;
												update crbt_rbt set rbt_score=rbt_score+1 where rbt_code=p_rbt;
												p_status:=8;
												commit;

								exception
												when others then
												p_status:=(p_status*(-1));
												--p_id:=-1;
	End AddFreeRbtToAlbId ;

	Procedure GiftFreeRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_fmsisdn in varchar2,p_chgcode in number,p_validityDays in number,p_status out number) is 
				l_temp 		number;
				p_id number;
				l_isSystemRbtBased number;
				Begin
												p_status:=1;
												GenerateCrbtCdrs (p_msisdn,p_chgcode,4,p_int,-1,0,sysdate,p_fmsisdn,p_rbt,0,p_subtype,p_status,p_id);
												-- gift rbt cdrs 

												
												select wallet_id into l_temp from crbt_wallet_master where msisdn=p_fmsisdn and wallet_name='DEFAULT';
																p_status:=4;
												insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,is_rbt_gifted,expiry_date) values (l_temp,p_rbt,sysdate-30+p_validityDays,p_fmsisdn,1,sysdate+p_validityDays);
																p_status:=5;
												commit;
											select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
																if l_isSystemRbtBased=1 then
update crbt_subscriber_master set last_charged=sysdate-30+p_validityDays, expiry_date=sysdate+p_validityDays, update_time=sysdate,rbt_code=p_rbt where msisdn=p_msisdn and last_charged<=(sysdate-30+p_validityDays);
            commit;
												end if;

												insert into crbt_rbt_gift_log (msisdn,subscriber_type,event_time,interface_type,op_code,friend_msisdn,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,1,p_fmsisdn,'N',p_updatedby,p_id); 
												p_status:=6;
												commit;
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,'A RBT is Gifted to Friend '||p_fmsisdn,p_subtype,p_int,p_updatedby);
												p_status:=7;
												commit;

												--select masked_name into p_rbtname from crbt_rbt where rbt_code=p_rbt;
								exception
												when others then
												p_status:=(p_status*(-1));
	End GiftFreeRbt;

 Procedure GenerateCrbtCdrs (p_msisdn in varchar2,p_chgcode in number,p_action in number,p_interface in varchar2,p_sc in number,p_daid in number,p_cdate in date,p_fmsisdn in varchar2,p_rbt in number,p_amt in number,p_subtype in varchar2,p_status in varchar2,p_id out number) is 
				Begin
												
								    select crbt_cdr_id.nextval into p_id from dual;
												insert into crbt_cdrs (MSISDN,TARIFFID,ACTION,INTERFACE,SERVICE_CLASS,DA_ID,CREATE_DATE,FMSISDN,RBT_CODE,AMOUNT,STATUS,CDR_ID ) values (p_msisdn,p_chgcode,p_action,p_interface,p_sc,p_daid,p_cdate,p_fmsisdn,p_rbt,p_amt,'N',p_id);
												commit;
												select SCDR_ID.nextval into p_id from dual;
												insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,TARIFF_ID,amount,RBT_CODE) values (p_id,p_msisdn,p_interface,sysdate,'R',1,'N',p_subtype,p_chgcode,p_amt,p_rbt);
												commit;

												exception
												when others then
												p_id:=-1;
	End GenerateCrbtCdrs;



Procedure RbtRenew (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt_code in number,p_refid in varchar2,p_chgcode in number,p_status out number,p_id out NUMBER) is
  BEGIN
  update crbt_wallet_content set create_date=sysdate, status='A',expiry_date=sysdate+30 where msisdn=p_msisdn and rbt_code=p_rbt_code ;
  commit;
  p_status:=1;
  select SECDR_ID.nextval into p_id from dual;

 GenerateRBTSettingCDR(p_msisdn,p_int,p_subtype,1,p_rbt_code,p_refid,p_chgcode,p_id);

--  insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,tariff_id,amount,action) values (p_id,p_msisdn,p_int,sysdate,1,'N',p_rbt_code,p_subtype,p_refid,p_chgcode,l_final_amount,'R');
  dbms_output.put_line( 'subscriber is postpaid ..secdr id ' || p_id);
  p_status:=3;
  commit;
  p_status:=4;
  insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,p_rbt_code,0,6,'Y',p_updatedby,p_id);
  p_status:=6;
  commit;
  insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,'RBT Renewed '||p_rbt_code,p_subtype,p_int,p_updatedby);
  p_status:=7;
  commit;

exception
when others then
p_status:=(p_status*(-1));
END RbtRenew;


Procedure CheckRenewRbtCode (p_msisdn in varchar2,p_rbtcode in number,p_status out number,p_chgcode out number) is
    l_temp               number ;
    l_pv            varchar2(10) ;
    l_pi                 number ;
    l_cat                number ;
    l_pcat               number ;
    l_freecat            number ;
    l_advcat             number ;
    l_chgcode            number ;
    l_fcenabled          number ;
    l_diffchgenabled     number ;
    l_playlistcat        number ;
    l_playlistenabled        number ;

    -- param_id = 87  , param_tag = ADVERTISEMENT_CAT_ID
    -- param_id = 104 , param_tag = DIFFERENT_RBT_CHARGING_ENABLED
    -- param_id = 105 , param_tag = FREE_RBT_ENABLED
    -- param_id = 106 , param_tag = FREE_RBT_CAT_ID
    -- param_id = 123 , param_tag = PLAYLIST_CAT_ID
    -- param_id = 124 , param_tag = PLAYLIST_ENABLED

    cursor cursor_rbt_code is select rbt_code,cat_id,charging_code from crbt_rbt where rbt_code=p_rbtcode ;
    cursor cursor_wlt_cnt is select rbt_code from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbtcode;
--    cursor cursor_app_config is select param_value,param_id from crbt_app_config_params where param_id in (87,104,105,106,123);
    cursor cursor_app_config is select param_value,param_id from crbt_app_config_params where param_tag in ('ADVERTISEMENT_CAT_ID','DIFFERENT_RBT_CHARGING_ENABLED','FREE_RBT_ENABLED','FREE_RBT_CAT_ID','PLAYLIST_CAT_ID','PLAYLIST_ENABLED');
    Begin
            l_diffchgenabled:=-1;
            l_fcenabled:=-1;
            l_advcat:=-1;
            l_freecat:=-1;
            l_playlistcat:=-1;

            p_status:=0;
            open cursor_rbt_code ;
            fetch cursor_rbt_code into l_temp,l_cat,l_chgcode;
            dbms_output.put_line( 'after fetch ' || l_temp || ' ' || l_cat || ' ' || l_chgcode);
            if cursor_rbt_code%NOTFOUND
            then
                close cursor_rbt_code;
                p_status:=-14;
                RETURN;
            else
                close cursor_rbt_code;
            end if;
            dbms_output.put_line( 'after fetch ' || l_temp || ' ' || l_cat || ' ' || l_chgcode);
            l_temp:=0;
            p_chgcode:=l_chgcode;

            open cursor_wlt_cnt ;
            fetch cursor_wlt_cnt into l_temp;
dbms_output.put_line( 'after fetch ' || l_temp );
            if cursor_wlt_cnt%NOTFOUND
            then
                close cursor_wlt_cnt;
                p_status:=-15;
                RETURN;
            end if;
                close cursor_wlt_cnt;
            dbms_output.put_line( 'after fetch ' || l_temp );

                open cursor_app_config ;
                LOOP
                    l_temp:=0;
                    fetch cursor_app_config into l_pv,l_pi;
                        dbms_output.put_line( ' value ' || l_pv || 'parm' ||l_pi);

                    if cursor_app_config%NOTFOUND
                    then
                        dbms_output.put_line( ' not found cursor_app_config');
                        close cursor_app_config;
                        EXIT;
                    else
                        l_temp:=to_number (l_pv);

                        if l_pi = 87
                        then
                            l_advcat:=l_temp;
                        elsif l_pi = 104
                        then
                            l_diffchgenabled:=l_temp;
                        elsif l_pi = 105
                        then
                            l_fcenabled:=l_temp;
                        elsif l_pi = 106
                        then
                            l_freecat:=l_temp;
                        elsif l_pi = 123
                        then
                            l_playlistcat:=l_temp;
                        elsif l_pi = 124
                        then
                            l_playlistenabled:=l_temp;
                        else
                            dbms_output.put_line( 'not matching any ');
                            p_status:=-1;
                            close cursor_app_config;
                            RETURN;
                        end if;
                    end if;
                end loop;

dbms_output.put_line( 'after fetch ' || l_advcat || l_diffchgenabled || l_fcenabled || l_freecat || l_playlistcat );
                if l_advcat = l_cat
                then
                  p_status:=-24;
                  RETURN;
                end if;
            dbms_output.put_line( 'after fetch 1' || l_temp );

                if l_fcenabled = 1 and l_freecat = l_cat
                then
                  p_status:=-26;
                  RETURN;
                end if;
            dbms_output.put_line( 'after fetch 2' || l_temp );

                if l_playlistcat = l_cat and l_diffchgenabled = 1
                then
                  p_status:=-29;
                  RETURN;
                elsif l_playlistcat = l_cat
                then
                  p_status:=-28;
                  RETURN;
                end if;
            dbms_output.put_line( 'after fetch 3' || l_temp );

                if l_diffchgenabled = 1
                then
                  p_status:=-27;
                  RETURN;
                end if;
            p_status:=-7;
            dbms_output.put_line( 'after fetch 4' || l_temp );
        exception
            when others then
            p_status:=-1;
 End CheckRenewRbtCode;

--add by kapil
 Procedure SubscribeAndSetRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_plan in number, p_lang in number, p_pin in varchar2,p_refid in varchar2,p_chgcode in number,p_status out number,p_id out number) is
 l_char varchar2 (1);
 l_length PLS_INTEGER;
 l_temp 		number;
 l_wltid number;
 l_pre_amount  number;
 l_post_amount  number;
 l_final_amount number;

Begin
	p_status:=1;
	p_id:=-1;
		select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
            if p_subtype = 'O' then
		            l_final_amount:=l_post_amount;
            else
		            l_final_amount:=l_pre_amount;
            end if;
            p_status:=2;

	select SCDR_ID.nextval into p_id from dual;
	insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,tariff_id,amount,action) values (p_id,p_msisdn,p_int,sysdate,p_plan,'N',p_rbt,p_subtype,p_refid,p_chgcode,l_final_amount,'R');
	p_status:=2;
	commit;	
	p_status:=4;
	insert into crbt_subscriber_master (msisdn,status,plan_indicator,rbt_code,password,tpin,language) values (p_msisdn,'A',p_plan,0,p_pin,p_pin,p_lang);
	commit;
	p_status:=6;
	select wallet_id_seq.nextval into l_wltid from dual;
	insert into crbt_wallet_master (msisdn,wallet_id,create_date,wallet_name,ivr_name)	values (p_msisdn,l_wltid,sysdate,'DEFAULT',0);
	commit;
	p_status:=7;
	insert into crbt_wallet_content (wallet_id,rbt_code,create_date,is_rbt_gifted,msisdn) values (l_wltid,0,sysdate,0,p_msisdn);
	commit;
	p_status:=8;
	insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,8,2500,2500,0,sysdate);
	commit;
	p_status:=9;
	insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,'S',p_int,'Y',p_updatedby,p_id);
	commit;	
p_status:=10;
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'SUBSCRIBED',p_subtype,p_int,p_updatedby);
commit;

p_status:=11;							
if p_chgdone = 1 then
												--AddRbtToAlbumName(p_msisdn,p_int,p_updatedby,p_subtype,p_rbt,'DEFAULT',p_chgdone,p_refid,p_chgcode,p_status,l_temp);//needs to change
if p_status < 0
then
p_status:=-1;
RETURN;
else
p_id:=l_temp;
end if;
end if;


l_temp:=0;
if p_days = 8
then
select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
if l_temp = 0 then
insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_days,p_sttime,p_entime,p_rbt,sysdate);
commit;
p_status:=13;
else
update crbt_default_detail set rbt_code=p_rbt where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime; 
p_status:=14;
commit;
end if;
else
l_length:=LENGTH(p_days);
IF l_length > 0
THEN
FOR l_index IN 1 .. l_length
LOOP
l_char := SUBSTR (p_days,l_index, 1);
select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;
if l_temp = 0 then
insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,l_char,p_sttime,p_entime,p_rbt,sysdate);
commit;
p_status:=15;
else
update crbt_default_detail set rbt_code=p_rbt where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime; 
commit;
end if;
END LOOP;
END IF;
END IF;

if p_days = 8 AND p_sttime = 2500 AND p_entime = 2500  
then
update crbt_subscriber_master set rbt_code=p_rbt where msisdn=p_msisdn;
p_status:=16;
commit;
end if;
insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_rbt,p_int,1,'DEFAULT','N',p_updatedby,p_id,1); 
p_status:=17;
commit;
insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Default RBT is Set',p_subtype,p_int,p_updatedby);
p_status:=18;
commit;


exception
when others then
--				dbms_output.put_line( 'exception occured ');
p_status:=-1;

End SubscribeAndSetRbt; 


Procedure PrintVersion is
begin
dbms_output.put_line('Telemune Rule Engine Procedure Version [R4_0_1_0] ');

End PrintVersion;


Procedure p_blacklist_msisdn (p_msisdn in varchar2,p_fmsisdn in varchar2,p_status out number) is
l_temp          number;
begin
	p_status:=1;
	select count(*) into l_temp from crbt_subscriber_blacklist where msisdn=p_msisdn and blacklist_number=p_fmsisdn;
	if l_temp > 0 then
		p_status:=4;
	else
		insert into crbt_subscriber_blacklist (msisdn,blacklist_number,create_date) values (p_msisdn,p_fmsisdn,sysdate);
		p_status:=2;
		update crbt_subscriber_master set black_listed=1 where msisdn = p_msisdn;
		p_status:=3;
	end if;
	commit;
exception
	when others then
	p_status:=(p_status*(-1));
end p_blacklist_msisdn;

Procedure CheckForStatus(p_msisdn in varchar2, p_status out number) is
l_temp          number ;
Begin
	p_status:=-2;
	l_temp:=0;
	select count(msisdn) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status = 'I';
	if l_temp!=0
	then
		p_status:=1;
		RETURN;
	end if;
exception
	when others then
	p_status:=-1;
End CheckForStatus;


    Procedure SetDefaultFreeRbt (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbt in number,p_days in varchar2,p_sttime in number,p_entime in number,p_validityDays in number,p_status out number,p_id out number) is
    l_char varchar2 (1);
    l_length PLS_INTEGER;
    l_temp   number;
    Begin
        p_status:=1;
        p_id:=-1;
        l_temp:=-1;
		select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status in('I','D');
		if l_temp != 0
		then
			p_status:=-1;
			RETURN;
		end if;
            AddAlbum (p_msisdn,p_int ,p_updatedby ,p_subtype ,p_rbt,'DEFAULT',l_temp);
            if l_temp=-1
            then
            p_status:=-1;
            RETURN;
            end if;
            p_status:=2;
            dbms_output.put_line('l_temp '||l_temp);
            insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,expiry_date) values (l_temp,p_rbt,sysdate-30+p_validityDays,p_msisdn,sysdate+p_validityDays);
            commit;
            p_status:=3;
            insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,p_rbt,l_temp,4,'N',p_updatedby,p_id);
            commit;
            p_status:=4;
           insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,'Free RBT Added To Album DEFAULT',p_subtype,p_int,p_updatedby);
            p_status:=5;
            commit;
            insert into crbt_subscriber_free_rbt(msisdn,create_date,rbt_code,interface) values(p_msisdn,sysdate,p_rbt,p_int);
            commit;
            p_status:=6;
            update crbt_rbt set rbt_score=rbt_score+1 where rbt_code=p_rbt;
            p_status:=7;
            commit;
            l_temp:=0;
            update crbt_subscriber_master set last_charged=sysdate-30+p_validityDays, expiry_date=sysdate+p_validityDays, update_time=sysdate where msisdn=p_msisdn and last_charged<(sysdate-30+p_validityDays);
            commit;
            p_status:=8;
            if p_days = 8 
	    then
                select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
                    if l_temp = 0 
	            then
                        insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_days,p_sttime,p_entime,p_rbt,sysdate);
                        commit;
                        p_status:=9;
                    else
                        update crbt_default_detail set rbt_code=p_rbt where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
                        commit;
                    end if;
            else
                l_length:=LENGTH(p_days);
                IF l_length > 0
                THEN
                    FOR l_index IN 1 .. l_length
                    LOOP
                        l_char := SUBSTR (p_days,l_index, 1);
                        select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;
                        if l_temp = 0 then
                         insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,l_char,p_sttime,p_entime,p_rbt,sysdate);
                            commit;
                            p_status:=10;
                        else
                            update crbt_default_detail set rbt_code=p_rbt where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;
                            commit;
                        end if;
                    END LOOP;
                END IF;
            END IF;

           if p_days = 8 AND p_sttime = 2500 AND p_entime = 2500
           then
            update crbt_subscriber_master set rbt_code=p_rbt where msisdn=p_msisdn;
            commit;
                p_status:=11;
           end if;
            insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_rbt,p_int,1,'DEFAULT','N',p_updatedby,p_id,1);
            commit;
                p_status:=12;
            insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Default RBT is Set',p_subtype,p_int,p_updatedby);
            commit;
                p_status:=13;


        exception
            when others then
            p_status:=(p_status)*(-1);
 End SetDefaultFreeRbt;

Procedure CheckForPackSubscription(p_msisdn in varchar2,p_int in varchar2, p_isSub out number,p_packId in number,p_subType in varchar2,p_status out number) is
l_temp 		number ;
l_isUser number;
l_count number;
l_status varchar2(3);
l_subStatus varchar2(3);
l_validSubType boolean;
l_packCount number;
l_scope varchar2(100);
li_status number;
Begin
	p_status:=1;
	l_status:='N';
	l_isUser:=-1;
	l_temp:=0;
	l_count:=-1;
	p_isSub:=-1;
	l_packCount:=-1;
	l_scope:='NA';
	li_status:=1;
	select count(*) into l_temp from crbt_pack_detail where pack_id=p_packId and status='A';
	if l_temp = 0 then
		p_status:=-30; ---pack not exist
		RETURN;
	end if;
	p_status:=2;

	select valid_for, subscriber,scope into l_status,l_subStatus,l_scope from crbt_pack_detail where pack_id=p_packId;
	p_status:=3;
	if l_scope = 'P' and p_subType != 'P' then---user's subtype is not lie in valid sub type for pack
		p_status:=-32;
		RETURN;
	end if;
	if  l_scope = 'O' and p_subType != 'O' then 
                p_status:=-32;
                RETURN;
        end if;
	p_status:=4;

	if l_status = 'FS' then ----------valid for very first time subscriber
		select count(*) into l_temp from crbt_subscriber_master_old where msisdn=p_msisdn;
		if l_temp = 0 then
			select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn;
			if l_temp != 0 then
				p_status:=-32;
				RETURN;
			end if;
		else
			p_status:=-32;
			RETURN;
		end if;
		li_status:=0;
		p_status:=5;
	elsif l_status = 'N' then ---------valid for non sub only
		li_status:=0;
		p_status:=5;
	else
		if l_status = 'S' then ------------valid for only subscriber
			p_status:=6;
			li_status:=1;
		elsif l_status = 'B' then ------------valid for both subs as well as non-sub
			p_status:=7;
			li_status:=2;
		else
		-------invalid value
			p_status:=-1;
			RETURN;
		end if;
		p_status:=8;
		if l_subStatus = 'A' then --------only for active users
			p_status:=9;
			l_isUser:=1;
		elsif l_subStatus = 'I' then
			p_status:=10;
			l_isUser:=0;
		elsif l_subStatus = 'B' then
			p_status:=11;
			l_isUser:=2;
		end if;
	end if; 
	p_status:=12;
	select count(*) into l_count from crbt_subscriber_master where msisdn=p_msisdn and status!='D';
	p_status:=13;
	if l_count = 0 then 
		p_status:=14;
		if li_status = 0 or li_status = 2 then ----unsub user can purchase the bundle
			p_status:=15;
			select param_value into l_temp from crbt_app_config_params where param_tag like 'WHITELIST_ENABLE';
			p_status:=16;
			if l_temp = 1 then
				p_status:=17;
				select count(*) into l_temp from crbt_whitelist where to_number(STARTS_AT) <=to_number(p_msisdn) and to_number(ENDS_AT) >=to_number(p_msisdn);
				if l_temp = 0 then
					p_status:=-25;
					return;
				end if;
			end if;
		end if;
	else
		p_status:=18;
		select count(*) into l_packCount from crbt_pack_master where msisdn=p_msisdn and pack_id=p_packId and pack_expiry_date >= sysdate;
		if l_packCount > 0 then ----pack already purchased
			p_status:=-31;
			RETURN;
		end if;
		p_status:=19;
		if li_status = 1 or li_status =2 then
			select status into l_subStatus from crbt_subscriber_master where msisdn=p_msisdn;
			if l_isUser = 1 and l_subStatus != 'A' then
				--user cant purchase pack
				p_status:=-32;
				return;
			elsif l_isUser = 0  and l_subStatus != 'I' then
				 --user cant purchase pack
                                p_status:=-32;
                                return;
			end if;
			if l_subStatus='A' then
				p_isSub:=1;
				li_status:=4;
			else
				p_isSub:=0;
				li_status:=5;
			end if;
		end if;
	end if;
exception
	when others then
	p_status:=(p_status)*(-1);
End CheckForPackSubscription;


Procedure CheckForRenewMode(p_msisdn in varchar2, p_renewMode out number, p_subType out varchar2,p_status out number) is
l_temp          number ;
l_subType	varchar2(5);
Begin
	p_status:=1;
	l_temp:=0;
	p_renewMode:=30;
	p_subType:='N';
	select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn;
	if l_temp!=0
	then
		select renew_mode into l_temp from  crbt_subscriber_master where msisdn=p_msisdn;
		p_status:=2;
		select sub_type into l_subType from  crbt_subscriber_master where msisdn=p_msisdn;
		p_status:=3;
		p_renewMode:=l_temp;
		p_subType:=l_subType;
		RETURN;
	else
		p_status:=-1;
	end if;
exception
	when others then
	p_status:=(p_status)*(-1);
End CheckForRenewMode;


Procedure RbtRenewModule(p_msisdn in varchar2, p_int in varchar2, p_updatedby in varchar2, p_plan in number, p_subtype in varchar2, p_rbtCode in number, p_days in number,p_refid  in varchar2,p_chgcode in number, p_status out number,p_id out number) is
        l_action   varchar2 (2);
        l_reqdata varchar2 (50);
        l_status varchar2 (2);
        newDate date;
        lastCharge date;
        l_lastCharged date;
	l_renewMode number(6);
	l_pre_amount  number;
	l_post_amount  number;
	l_final_amount number;
    Begin
	select status into l_action from crbt_subscriber_master where msisdn=p_msisdn;
	select renew_mode into l_renewMode from crbt_subscriber_master where msisdn=p_msisdn; 
        if l_action = 'A' then
                if p_days = 1 then
                        p_status:=9;
                        l_action:='S1';
                        l_reqdata:='RENEWED FOR ONE DAY';
                elsif p_days = 7 then
                        p_status:=10;
                        l_action:='S2';
                        l_reqdata:='RENEWED FOR ONE WEEK';
                elsif p_days = 14 then
                        p_status:=11;
                        l_action:='S3';
                        l_reqdata:='RENEWED FOR TWO WEEK';
                elsif p_days = 21 then
                        p_status:=12;
                        l_action:='S4';
                        l_reqdata:='RENEWED FOR THREE WEEK';
                else
                        l_status:=13;
                        l_action:='S';
                        l_reqdata:='RENEWED FOR ONE MONTH';
                end if;
        else
                if p_days = 1 then
                        p_status:=14;
                        l_action:='A1';
                        l_reqdata:='ACTIVATED FOR ONE DAY';
                elsif p_days = 7 then
                        p_status:=15;
                        l_action:='A2';
                        l_reqdata:='ACTIVATED FOR ONE WEEK';
                elsif p_days = 14 then
                        p_status:=16;
                        l_action:='A3';
                        l_reqdata:='ACTIVATED FOR TWO WEEK';
                elsif p_days = 21 then
                        p_status:=17;
                        l_action:='A4';
                        l_reqdata:='ACTIVATED FOR THREE WEEK';
                else
                        p_status:=18;
                        l_action:='A';
                        l_reqdata:='ACTIVATED FOR ONE MONTH';
                end if;
                p_status:=19;
        end if;
                p_status:=20;
																select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
																if p_subtype = 'O' then
																l_final_amount:=l_post_amount;
																else
																l_final_amount:=l_pre_amount;
																end if;

																select SCDR_ID.nextval into p_id from dual;
																insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,tariff_id,amount) values (p_id,p_msisdn,p_int,sysdate,l_action,p_plan,'N',p_subtype,p_refid,p_chgcode,l_final_amount);
																dbms_output.put_line( 'subscriber is postpaid ..scdr id ' || p_id);
p_status:=2;
commit;

commit;
p_status:=25;

                select last_charged into l_lastCharged from crbt_subscriber_master where msisdn = p_msisdn;
                newDate:=sysdate-30+p_days;
                if newDate>l_lastCharged then
                        update crbt_subscriber_master set status='A',last_charged=newDate where msisdn = p_msisdn;
                        commit;
                        p_status:=26;
                end if;
                update crbt_wallet_content set create_date=sysdate-30+p_days where msisdn = p_msisdn and rbt_code=p_rbtCode;
            commit;
                p_status:=27;
            insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,l_action,p_int,'Y',p_updatedby,p_id);
            commit;
                p_status:=28;
            insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,l_reqdata,p_subtype,p_int,p_updatedby);
            commit;
                p_status:=29;
		p_id:=l_renewMode;
        exception
            when others then
            p_status:=(p_status*(-1));
End RbtRenewModule;


Procedure PackSubscribe (p_msisdn in varchar2,p_plan in number,p_lang in number,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_pin in varchar2,p_packid in number,p_refid in varchar2,p_chgcode in number,p_status out number,p_id out number) is 
l_rbt varchar2(200);
l_giftRbt varchar2(200);
l_recRbt varchar2(200);
l_totalRbt number;
l_freeRbt number;
l_totalGift number;
l_freeGift number;
l_totalRecording number;
l_freeRecording number;
l_packValidity number;
l_priority number;
l_temp number;
l_setting number;
	l_pre_amount  number;
	l_post_amount  number;
	l_final_amount number;
Begin
	p_status:=1;
	p_id:=-1;
	l_temp:=-1;
	l_priority:=-1;
	l_setting:=-1;
		 select rbt, gift_rbt, recording_rbt,offer_validity,priority into l_rbt, l_giftRbt, l_recRbt,l_packValidity,l_priority from crbt_pack_detail where pack_id=p_packid and status='A';
            if p_subtype = 'O' then
		            l_final_amount:=l_post_amount;
            else
		            l_final_amount:=l_pre_amount;
            end if;
            p_status:=2;

		select SCDR_ID.nextval into p_id from dual;
		insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount,pack_id) values (p_id,p_msisdn,p_int,sysdate,'P',p_plan,'N',p_subtype,p_refid,p_chgcode,l_final_amount,p_packid);
												p_status:=3;
												commit;

	select rbt, gift_rbt, recording_rbt,offer_validity,rbt_setting into l_rbt, l_giftRbt, l_recRbt,l_packValidity,l_setting from crbt_pack_detail where pack_id=p_packid and status='A';
	select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='D';
	if l_temp != 0 then
		select count(*) into l_temp from crbt_subscriber_master where status='A' and msisdn=p_msisdn;
		if l_temp = 0 then
			--return error
			p_status:=-12;
			RETURN;
		end if;
	else
		Subscribe(p_msisdn,p_plan,p_lang,p_int,p_updatedby,p_subtype,p_pin,p_refid,p_chgcode,l_packValidity,1,p_status,p_id);
		if p_status < 0 then
			--return error
			RETURN;
		end if;
	end if;	

	ParseStringToInt(l_rbt,'NOR:',l_totalRbt);
	ParseStringToInt(l_rbt,'NOFR:',l_freeRbt);
	
	ParseStringToInt(l_giftRbt,'NOR:',l_totalGift);
	ParseStringToInt(l_giftRbt,'NOFR:',l_freeGift);


	ParseStringToInt(l_recRbt,'NOR:',l_totalRecording);
	ParseStringToInt(l_recRbt,'NOFR:',l_freeRecording);
	update crbt_subscriber_master set last_charged=sysdate-30+l_packValidity,expiry_date=sysdate+l_packValidity, update_time=sysdate where msisdn=p_msisdn and last_charged<=(sysdate-30+l_packValidity);
	commit;
	p_status:=12;
	dbms_output.put_line('--'||p_msisdn||'--'||p_packid||'--'||l_totalRbt||'--'||l_freeRbt||'--'||l_totalGift||'--'||l_totalGift||'--'||l_totalRecording||'--'||l_freeRecording||'--'||l_packValidity||'--'||l_priority);	
	insert into crbt_pack_master (msisdn,pack_id,total_rbt,free_rbt,total_gift,free_gift,total_recording,free_recording,update_time,pack_sub_time,pack_expiry_date,priority) values(p_msisdn,p_packid,l_totalRbt,l_freeRbt,l_totalGift,l_freeGift,l_totalRecording,l_freeRecording,sysdate,sysdate,sysdate+l_packValidity,l_priority);
	p_status:=13;
	commit;
	-------added by kapil for busy rbt--------------------
	-------Pack type 1 means this is a busy rbt pack;
	select nvl(pack_type,0) into l_temp from crbt_pack_detail where pack_id=p_packid;
	p_status:=14;
	if l_temp=1 then
		update crbt_subscriber_master set active_features = 1 where msisdn=p_msisdn;
		commit;
	p_status:=15;
                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,'Busy RBT Pack activated '||p_packid,p_subtype,p_int,p_updatedby);
		commit;
	p_status:=16;
	end if;
	-------added by kapil for busy rbt--------------------
	
	insert into crbt_pack_purchase_log (msisdn,pack_id,interface,create_date,updated_by,sub_type,action) values(p_msisdn,p_packid,p_int,sysdate,p_updatedby,p_subtype,'S');
	p_status:=17;
	if l_setting = 2 then -------seq setting
		SetAdvanceRbt(p_msisdn,p_int,p_updatedby,p_subtype,'SEQ','DEFAULT',1,p_status);
	elsif l_setting = 3 then -----RANDOM setting
		SetAdvanceRbt(p_msisdn,p_int,p_updatedby,p_subtype,'RANDOM','DEFAULT',1,p_status);
	elsif l_setting = 4 then ------TOPMOST setting
		SetAdvanceRbt(p_msisdn,p_int,p_updatedby,p_subtype,'TOPMOST','DEFAULT',1,p_status);
	end if;
	p_status:=18;

	commit;
	exception
		when others then
		delete from crbt_pack_master where msisdn=p_msisdn and pack_id=p_packid;
		commit;
		delete from crbt_pack_purchase_log where msisdn=p_msisdn and pack_id=p_packid;
		commit;
		p_status:=(p_status*(-1));
End PackSubscribe;

Procedure ParseStringToInt(p_stringToBeParse in varchar2, p_stringFromParse in varchar2,p_result out number) is
l_temp number;
l_temp1 number;
Begin
	l_temp:=0;
	l_temp1:=0;
	p_result:=1;
	l_temp:=INSTR(p_stringToBeParse,p_stringFromParse,1,1);
	dbms_output.put_line('l_temp['||l_temp||'] in ParseString');
	p_result:=2;
 	l_temp1:=INSTR(p_stringToBeParse,',',l_temp,1);
	--if l_temp1 = 0 then
	--	l_temp1:=length(p_stringToBeParse);
	--end if;
	dbms_output.put_line('l_temp1['||l_temp1||'] in ParseString');
	p_result:=3;
	p_result:=to_number(substr(p_stringToBeParse,l_temp+length(p_stringFromParse),l_temp1-(length(p_stringFromParse)+l_temp)));
	exception
                when others then
		p_result:=(p_result)*(-1);
End ParseStringToInt;	

Procedure ParseStringToString(p_stringToBeParse in varchar2, p_stringFromParse in varchar2,p_result out varchar2,p_status out number) is
l_temp number;
l_temp1 number;
Begin
	l_temp:=0;
	l_temp1:=0;
	p_result:='NA';
	p_status:=1;
	l_temp:=INSTR(p_stringToBeParse,p_stringFromParse,1,1);
	p_status:=2;
	dbms_output.put_line('l_temp['||l_temp||'] in ParseString');
 	l_temp1:=INSTR(p_stringToBeParse,',',l_temp,1);
	p_status:=3;
	if l_temp1 = 0 then
		dbms_output.put_line('l_temp is 0');
		l_temp1:=length(p_stringToBeParse) - (l_temp+length(p_stringFromParse)-1);
	else
		l_temp1:=l_temp1-(length(p_stringFromParse)+l_temp);
	end if;
	dbms_output.put_line('l_temp1['||l_temp1||'] in ParseString');
	p_result:=substr(p_stringToBeParse,l_temp+length(p_stringFromParse),l_temp1);
	--p_result:=substr(p_stringToBeParse,l_temp+length(p_stringFromParse),l_temp1-(length(p_stringFromParse)+l_temp));
	p_status:=4;
	exception
                when others then
		p_status:=(p_status)*(-1);
End ParseStringToString;

Procedure CheckForPackUser(p_msisdn in varchar2,p_operation in number,p_packId out number,p_setting out number,p_ispackSub out number,p_status out number) is
	l_temp number;
	l_packId number;
	l_totalRbt number;
	l_freeRbt number;
	l_totalGift number;
	l_freeGift number;
	l_totalRecording number;
	l_freeRecording number;
	l_setting number;
	cursor sel_pack_master is select pack_id,total_rbt,free_rbt,total_gift,free_gift,total_recording,free_recording from crbt_pack_master where pack_expiry_date >= sysdate and msisdn=p_msisdn order by priority;
Begin
	l_setting:=-1;
	l_temp:=0;
	l_packId:=0;
	l_totalRbt:=0;
	l_freeRbt:=0;
	l_totalGift:=0;
	l_freeGift:=0;
	l_totalRecording:=0;
	l_freeRecording:=0;
	p_status:=-1;
	p_packId:=-1;
	p_setting:=0;
p_ispackSub:=0;
	select count(*) into l_temp from crbt_pack_master where msisdn=p_msisdn and (pack_expiry_date >= sysdate or auto_renew='Y');
	if l_temp = 0 then ---no pack for this user
		dbms_output.put_line('NOTFOUND 11');
		p_status:=1;
		return;
	end if;
p_ispackSub:=1;
	open sel_pack_master;
	LOOP
		fetch sel_pack_master into l_packId,l_totalRbt,l_freeRbt, l_totalGift,l_freeGift, l_totalRecording,l_freeRecording;
		if sel_pack_master%NOTFOUND then
			dbms_output.put_line('NOTFOUND 1');
			close sel_pack_master;
			EXIT;
		end if;
		dbms_output.put_line('NOTFOUND 13');
		select rbt_setting into l_setting from crbt_pack_detail where pack_id=l_packId;
		dbms_output.put_line('NOTFOUND 14');
		p_setting:=l_setting;
		p_packId:=l_packId;
		if l_totalRbt > 0 or l_totalGift > 0 or l_totalRecording > 0 then
			dbms_output.put_line('pack id case 1'||p_packId);
			p_status:=1;
		elsif p_operation = 1  AND (l_freeRbt > 0 or l_freeRbt = -99) then ----RBT PURCHASE
			dbms_output.put_line('pack id free case 1'||p_packId);
			p_status:=0;
			close sel_pack_master;
			RETURN;
		elsif p_operation = 2 AND (l_freeGift > 0 or l_freeGift = -99) then ---RBT GIFT
			dbms_output.put_line('pack id free case 2'||p_packId);
			p_status:=0;
			close sel_pack_master;
			RETURN;
		elsif p_operation = 3 AND (l_freeRecording > 0 or l_freeRecording = -99) then -- RBT RECORDING
			dbms_output.put_line('pack id free case 3'||p_packId);
			p_status:=0;
			close sel_pack_master;
			RETURN;
		end if;
	END LOOP;
	open sel_pack_master;
	LOOP
		fetch sel_pack_master into l_packId,l_totalRbt,l_freeRbt, l_totalGift,l_freeGift, l_totalRecording,l_freeRecording;
		if sel_pack_master%NOTFOUND then
			dbms_output.put_line('NOTFOUND 2');
			close sel_pack_master;
			p_packId:=-1;
			p_status:=1;
			p_setting:=0;
			RETURN;
		end if;
		select rbt_setting into l_setting from crbt_pack_detail where pack_id=l_packId;
		p_setting:=l_setting;
		p_packId:=l_packId;
		if l_totalRbt > 0 AND p_operation = 1 then
			dbms_output.put_line('pack id charged case 1'||p_packId);
			p_status:=1;
			close sel_pack_master;
			RETURN;
		elsif p_operation = 2 AND l_totalGift > 0 then ----RBT PURCHASE
			dbms_output.put_line('pack id charged case 2'||p_packId);
			p_status:=1;
			close sel_pack_master;
			RETURN;
		elsif p_operation = 3 AND l_totalRecording > 0 then ---RBT GIFT
			dbms_output.put_line('pack id charged case 3'||p_packId);
			p_status:=1;
			close sel_pack_master;
			RETURN;
		else -- INVALID CASE
			dbms_output.put_line('INVALID CASE');
			p_packId:=-1;
			p_status:=1;
			p_setting:=0;
		end if;
	END LOOP;
	exception
		when others then
			p_status:=(p_status*(-1));
End CheckForPackUser;


Procedure CheckAndSetDefaultPack(p_msisdn in varchar2,p_updatedby in varchar2,p_int in varchar2,p_packId out number,p_status out number) is
l_temp number;
l_id number;
l_plan number;
l_lang number;
l_subType varchar2(3);
l_tpin number;
l_totalRbt number;
l_freeRbt number;
l_totalGift number;
l_freeGift number;
l_totalRecording number;
l_freeRecording number;
Begin
	l_temp:=0;
	p_packId:=-1;
	p_status:=1;
	l_id:=1;
	l_totalRbt:=0;
	l_freeRbt:=0;
	l_totalGift:=0;
	l_freeGift:=0;
	l_totalRecording:=0;
	l_freeRecording:=0;

	select count(*) into l_temp from crbt_pack_detail where is_default_pack=1 and status='A';
	dbms_output.put_line('inside CheckAndSetDefaultPack 1');
	if l_temp=1 then
		select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn;

	dbms_output.put_line('inside CheckAndSetDefaultPack 2');
		if l_temp = 0 then
			p_packId:=-1;
			p_status:=2;
			RETURN;
		end if;
		select pack_id into p_packId from crbt_pack_detail where is_default_pack=1 and status='A';
		select count(*) into l_temp from crbt_pack_master where msisdn=p_msisdn and pack_id=p_packId;
		p_status:=3;
 dbms_output.put_line('inside CheckAndSetDefaultPack 3 ---> pack_id[' || p_packId||'] p_status ['||p_status ||']');
		if l_temp > 0 then
			select TOTAL_RBT,FREE_RBT,TOTAL_GIFT,FREE_GIFT,TOTAL_RECORDING,FREE_RECORDING into l_totalRbt,l_freeRbt,l_totalGift,l_freeGift,l_totalRecording,l_freeRecording from crbt_pack_master where msisdn=p_msisdn and pack_id=p_packId;

		 dbms_output.put_line('inside CheckAndSetDefaultPack 4 ');
			if l_totalRecording = 0 and l_freeRecording = 0 and l_totalGift = 0 and l_freeGift = 0 and l_totalRbt = 0 and l_freeRbt = 0 then
				PackUpdate(p_msisdn,p_packId,p_int,p_updatedby,l_subType,p_status);
			dbms_output.put_line('inside CheckAndSetDefaultPack 5 PackUpdate result : p_status ['|| p_status || ']');	
				if p_status < 0 then
					p_status:=-8;
				end if;
				RETURN;
			else
				p_packId:=-1;
				p_status:=3;
				RETURN;
			end if;
		end if;
---		select plan_indicator,language,sub_type,password into l_plan,l_lang,l_subType,l_tpin from crbt_subscriber_master where msisdn=p_msisdn;
		 select plan_indicator,language,sub_type,tpin into l_plan,l_lang,l_subType,l_tpin from crbt_subscriber_master where msisdn=p_msisdn; ---change by pankaj because password was alphanumeric
		 dbms_output.put_line('inside CheckAndSetDefaultPack 6');
		PackSubscribe(p_msisdn,l_plan,l_lang,p_int,p_updatedby,l_subType,l_tpin,p_packId,'NA',-1,p_status,l_id);
 dbms_output.put_line('inside CheckAndSetDefaultPack 7');
		if p_status < 0 then
			p_status:=-9;
			p_packId:=-1;
			RETURN;
		end if;
	else
		p_status:=1;
		RETURN;
	end if;
	p_status:=4;
	exception
		when others then
			p_status:=(p_status*(-1));
End CheckAndSetDefaultPack;


Procedure PackUpdate(p_msisdn in varchar2,p_packid in number,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_status out number) is 
l_rbt varchar2(200);
l_giftRbt varchar2(200);
l_recRbt varchar2(200);
l_totalRbt number;
l_freeRbt number;
l_totalGift number;
l_freeGift number;
l_totalRecording number;
l_freeRecording number;
l_packValidity number;
l_priority number;
l_temp number;
l_setting number;
p_id number;
	l_pre_amount  number;
	l_post_amount  number;
	l_final_amount number;
Begin
	p_status:=1;
	p_id:=-1;
	l_temp:=-1;
	l_priority:=-1;
	l_setting:=-1;
 	select rbt, gift_rbt, recording_rbt,offer_validity,priority into l_rbt, l_giftRbt, l_recRbt,l_packValidity,l_priority from crbt_pack_detail where pack_id=p_packid and status='A';
	select to_number(param_value) into l_temp from crbt_app_config_params where param_tag='FREE_CHARGE_CODE';
	select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=l_temp;
        if p_subtype = 'O' then
		l_final_amount:=l_post_amount;
        else
	        l_final_amount:=l_pre_amount;
        end if;
        p_status:=2;

	select SCDR_ID.nextval into p_id from dual;
	insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount,pack_id) values (p_id,p_msisdn,p_int,sysdate,'P',1,'N',p_subtype,'NA',l_temp,l_final_amount,p_packid);
	p_status:=3;
	commit;

	select rbt, gift_rbt, recording_rbt,offer_validity,rbt_setting into l_rbt, l_giftRbt, l_recRbt,l_packValidity,l_setting from crbt_pack_detail where pack_id=p_packid and status='A';

	ParseStringToInt(l_rbt,'NOR:',l_totalRbt);
	ParseStringToInt(l_rbt,'NOFR:',l_freeRbt);
	
	ParseStringToInt(l_giftRbt,'NOR:',l_totalGift);
	ParseStringToInt(l_giftRbt,'NOFR:',l_freeGift);


	ParseStringToInt(l_recRbt,'NOR:',l_totalRecording);
	ParseStringToInt(l_recRbt,'NOFR:',l_freeRecording);
	update crbt_subscriber_master set last_charged=sysdate-30+l_packValidity,expiry_date=sysdate+l_packValidity, update_time=sysdate where msisdn=p_msisdn and last_charged<=(sysdate-30+l_packValidity);
	commit;
	p_status:=12;
	update crbt_pack_master set total_rbt=l_totalRbt, free_rbt=l_freeRbt, total_gift=l_totalGift, free_gift=l_freeGift, total_recording=l_totalRecording, free_recording=l_freeRecording ,update_time=sysdate, pack_expiry_date=sysdate+l_packValidity where msisdn=p_msisdn and pack_id=p_packid;
	p_status:=13;
	commit;
	insert into crbt_pack_purchase_log (msisdn,pack_id,interface,create_date,updated_by,sub_type,action) values(p_msisdn,p_packid,p_int,sysdate,p_updatedby,p_subtype,'S');
	p_status:=14;
	commit;
	exception
		when others then
		delete from crbt_pack_master where msisdn=p_msisdn and pack_id=p_packid;
		commit;
		delete from crbt_pack_purchase_log where msisdn=p_msisdn and pack_id=p_packid;
		commit;
		p_status:=(p_status*(-1));
End PackUpdate;


Procedure FindRatePlan(p_msisdn in varchar2,p_planName in varchar2,p_planId out number,p_status out number) is
l_temp number;
l_planId number;
Begin
	l_temp:=0;
	p_status:=1;
	p_planId:=-1;
	l_planId:=-1;
	select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn;
	if l_temp = 1 then
		select plan_indicator into p_planId from crbt_subscriber_master where msisdn=p_msisdn;
		p_status:=2;
		RETURN;
	end if;	
	exception
		when others then
			p_status:=p_status*(-1);
End FindRatePlan;


Procedure CheckAndFindRatePlan(p_msisdn in varchar2,p_subType in varchar2,p_planName in varchar2,p_planId out number,p_status out number) is
l_countryCode number;
l_temp number;
l_planId number;
l_maskedName varchar2(100);
l_scope varchar2(1024);
l_subType varchar2(4);
CURSOR cur_rate_plan is select plan_indicator,scope from crbt_rate_plan where UPPER(masked_name)=UPPER(l_maskedName) and status='A' and country_code=l_countryCode;
CURSOR cur_masked_name is select masked_name from rate_plan_alias where UPPER(alias_name)=UPPER(p_planName);

Begin
	l_countryCode:=0;
	l_temp:=0;
	p_status:=1;
	p_planId:=-1;
	l_planId:=-1;
	OPEN cur_masked_name;
	fetch cur_masked_name into l_maskedName;
	if cur_masked_name%NOTFOUND then
		dbms_output.put_line('No Plan Found for this alias name');
		close cur_masked_name;
		p_planId:=-1;
		p_status:=0;
		RETURN;
	end if;
	close cur_masked_name;

	select count(*) into l_temp from OPERATOR_SUBSCRIBER where to_number(STARTS_AT) <=to_number(p_msisdn) and to_number(ENDS_AT) >=to_number(p_msisdn);
	if l_temp = 1 then
		select to_number(country_code) into l_countryCode from OPERATOR_SUBSCRIBER where to_number(STARTS_AT) <=to_number(p_msisdn) and to_number(ENDS_AT) >=to_number(p_msisdn);	
	else
		l_countryCode:=0;
	end if;

	dbms_output.put_line('Country Code['||l_countryCode||']');
	OPEN cur_rate_plan;
	LOOP
		fetch cur_rate_plan into l_planId,l_scope;
		if cur_rate_plan%NOTFOUND then
			dbms_output.put_line('No Plan Found for masked name['||l_maskedName||']');
			p_planId:=-1;
			p_status:=1;
			CLOSE cur_rate_plan;
                        RETURN;
		else
			dbms_output.put_line('Plan Id['||l_planId||'] Scope['||l_scope||']');
			ParseStringToString(l_scope,'SUBTYPE:',l_subType,p_status);
			dbms_output.put_line('l_subType['||l_subType||'] p_subType['||p_subType||'] p_status['||p_status||']');
			if l_subType = p_subType OR l_subType = 'B' then
				dbms_output.put_line('Plan Found for this masked name');
				p_planId:=l_planId;
				p_status:=9;
				CLOSE cur_rate_plan;
				RETURN;
			end if;
		end if;
	END LOOP;
	exception
		when others then
			p_status:=p_status*(-1);
End CheckAndFindRatePlan;


Procedure RbtSuspend(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbtCode in number, p_status out number,p_id out number) is
l_temp number;
Begin
        p_status:=1;
        p_id:=1;
        l_temp:=1;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='A';
        if l_temp != 0 then
                p_status:=-30;
                RETURN;
        end if;
        p_status:=1;
        if p_rbtCode != -1 then
                select count(*) into l_temp from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbtCode and rbt_code!=0 and status='A';
                if l_temp = 0 then
                        p_status:=-15;
                        RETURN;
                end if;
                update crbt_wallet_content set status='S' where msisdn=p_msisdn and rbt_code=p_rbtCode;
                commit;
                p_status:=2;
        else
                update crbt_wallet_content set status='S' where msisdn=p_msisdn and rbt_code!=0;
                commit;
                p_status:=3;
        end if;

                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'Rbt Suspended '||p_rbtCode,p_subtype,p_int,p_updatedby);
                commit;
                p_status:=4;
        exception
                when others then
                        p_status:=(p_status)*(-1);

End RbtSuspend;

Procedure RbtUnSuspend(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbtCode in number, p_status out number,p_id out number) is
l_temp number;
Begin
        p_status:=1;
        p_id:=1;
        l_temp:=1;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='A';
        if l_temp != 0 then
                p_status:=-30;
                RETURN;
        end if;
        p_status:=1;
        if p_rbtCode != -1 then
                select count(*) into l_temp from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbtCode and rbt_code!=0 and status='S';
                if l_temp = 0 then
                        p_status:=-15;
                        RETURN;
                end if;
                update crbt_wallet_content set status='A' where msisdn=p_msisdn and rbt_code=p_rbtCode;
                commit;
                p_status:=2;
        else
                update crbt_wallet_content set status='A' where msisdn=p_msisdn and rbt_code!=0;
                commit;
                p_status:=3;
        end if;

                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'Rbt UnSuspended '||p_rbtCode,p_subtype,p_int,p_updatedby);
                commit;
                p_status:=4;
        exception
                when others then
                        p_status:=(p_status)*(-1);

End RbtUnSuspend;

Procedure PendingGiftAccept(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbtCode in number, p_fmsisdn in varchar2, p_planId in number,p_status out number,p_id out number) is
l_temp number;
l_subStatus varchar2(3);
Begin
        p_status:=1;
        p_id:=1;
        l_temp:=1;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_fmsisdn;
        if l_temp = 0 then
                l_subStatus:='D';
	else
		select status into l_subStatus from crbt_subscriber_master where msisdn=p_fmsisdn;
        end if;
        p_status:=2;
	insert into GIFT_PENDING_REQUEST(MSISDN,FMSISDN,rbt_code,REQUEST_TIME,FMSISDN_SUB_STATUS,interface,updated_by,plan_id,sub_type) values(p_msisdn,p_fmsisdn,p_rbtCode,sysdate,l_subStatus,p_int,p_updatedby,p_planId,p_subType);
	commit;
        p_status:=3;
        exception
                when others then
                        p_status:=(p_status)*(-1);

End PendingGiftAccept;


Procedure CheckForGiftAccept (p_msisdn in varchar2,p_rbt in out number,p_fmsisdn  in varchar2,p_chgcode out number,p_planId out number,p_status out number) 
is
l_temp 		number;
l_fmsisdn varchar2(15);
l_planId number;
l_catid number;
l_cpid number;
Begin
	
	p_status:=5;
	p_chgcode:=-1;
	p_planId:=-1;
	l_temp:=0;
	if p_rbt = -1 then
		select count(*) into l_temp from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(sysdate-1);
	else
		select count(*) into l_temp from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(sysdate-1) and rbt_code=p_rbt;
	end if;
		p_status:=1;

	if l_temp = 0 then
		p_status:=-35;
		RETURN;
	end if;
		p_status:=2;
	if p_rbt = -1 then
		p_status:=11;
		select rbt_code,fmsisdn,plan_id into p_rbt,l_fmsisdn,l_planId from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(sysdate-1) and REQUEST_TIME=(select max(REQUEST_TIME) from  GIFT_PENDING_REQUEST where fmsisdn=p_msisdn);
	else
		p_status:=14;
		select fmsisdn,plan_id into l_fmsisdn,l_planId from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(sysdate-1) and REQUEST_TIME=(select max(REQUEST_TIME) from  GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and rbt_code=p_rbt);
	end if;
	select count(*) into l_temp from operator_subscriber where to_number(p_msisdn) >= to_number(STARTS_AT) and to_number(p_msisdn) <= to_number(ENDS_AT);
		p_status:=3;
	if l_temp = 0 then
		p_status:=-22;
 		p_chgcode:=-1;
 		RETURN;
	end if;
		p_status:=4;
	select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='D';
		p_status:=6;
		p_planId:=l_planId;
		p_status:=5;
	if l_temp = 0 then
		p_status:=-8;
		p_chgcode:=-1;
	else
		--CheckRbtCode(p_msisdn,p_rbt,p_status,p_chgcode);
		CheckRbtCode(p_msisdn,p_rbt,p_status,p_chgcode,l_catid,l_cpid);
		RETURN ;
	end if;
		--p_status:=6;
	exception
		when others then
			p_status:=(p_status)*(-1);

End CheckForGiftAccept;



Procedure CheckAndInsertForMultiRetry(p_msisdn in varchar2,p_int in varchar2,p_subtype in varchar2,p_rbt in out number,p_packId in number,p_reqId in number, p_langId in number, p_planId in number, p_fmsisdn in varchar2,p_status out number) is
l_temp number;
Begin
	p_status:=1;
	l_temp:=0;
	--select count(*) into l_temp from crbt_pending_request where msisdn=p_msisdn and fmsisdn=p_fmsisdn and request_id=p_reqId and status='R';
	select count(*) into l_temp from crbt_pending_request where msisdn=p_msisdn and request_id=p_reqId and status='R';
	if l_temp > 0 then
		p_status:=0;
		RETURN;
	end if;
	if p_reqId = 4 then ----gift request
		----will do later
		p_status:=2;
	elsif p_reqId = 3 or p_reqId = 23 then
		select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn;
		if l_temp = 0 then
			insert into crbt_pending_request(MSISDN,RBT_CODE,REQUEST_ID,REQUEST_TIME,SUB_TYPE,STATUS,LANGUAGE_ID,PLAN_INDICATOR,INTERFACE_USED,FMSISDN,RETRY_COUNT,FILE_PATH,CREATE_DATE) values(p_msisdn,0,27,sysdate+2/1440,p_subtype,'R',p_langId,p_planId,p_int,p_fmsisdn,0,'NA',sysdate);
			commit;
			 p_status:=3;
		end if;
		insert into crbt_pending_request (MSISDN,RBT_CODE,REQUEST_ID,REQUEST_TIME,SUB_TYPE,STATUS,LANGUAGE_ID,PLAN_INDICATOR,INTERFACE_USED,FMSISDN,RETRY_COUNT,FILE_PATH,CREATE_DATE) values(p_msisdn,p_rbt,3,sysdate+3/1440,p_subtype,'R',p_langId,p_planId,p_int,p_fmsisdn,0,'NA',sysdate);
	commit;
		p_status:=4;
	end if;
	p_status:=5;
	exception
		when others then
			p_status:=p_status*(-1);
End CheckAndInsertForMultiRetry;


Procedure CheckForSuspension(p_msisdn in varchar2, p_status out number) is
l_temp          number ;
l_status varchar2(3);
Begin
     p_status:=-1;
     l_temp:=0;
     l_status:='A';
     select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status != 'D';
     if l_temp!=0
     then
                select status into l_status from crbt_subscriber_master where msisdn=p_msisdn;
                if l_status = 'S' then
                        p_status:= -28;
                elsif l_status = 'I' then
                        p_status:=-29;
                else
                        p_status:=1;
                end if;
     else
                p_status:=-30;
    end if;
    exception
         when others then
            p_status:=-1;
End CheckForSuspension;


Procedure UnsuspendService(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_status out number,p_id out number) is
l_temp number;
Begin
        l_temp:=0;
        p_status:=1;
        p_id:=1;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status='S';
        if l_temp = 0 then
                p_status:=-31;
                RETURN;
        else
                select param_value into l_temp from crbt_app_config_params where param_tag='ADD_DAYS_ON_UNSUSPENSION';
                if l_temp = 1 then
                        update crbt_subscriber_master set status='A', expiry_date=(sysdate + (sysdate - update_time)) where msisdn=p_msisdn;
                        commit;
                        p_status:=2;
                else
                        update crbt_subscriber_master set status='A' where msisdn=p_msisdn;
                        commit;
                        p_status:=3;
                end if;
                update crbt_subscriber_master set update_time=sysdate where msisdn=p_msisdn;
                commit;
                p_status:=4;
                insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,'US',p_int,'N',p_updatedby,1);
                commit;
                p_status:=5;
                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'UNSUSPENDED',p_subtype,p_int,p_updatedby);
                commit;
                p_status:=6;
        end if;
        exception
                when others then
                        p_status:=(p_status)*(-1);
End UnsuspendService;



Procedure SuspendService(p_msisdn in varchar2,p_plan in number,p_lang in number,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_status out number,p_id out number) is
l_temp number;
Begin
        p_status:=1;
        p_id:=1;
        l_temp:=1;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status='S';
        if l_temp != 0 then
                p_status:=-28;
                RETURN;
        else
                p_status:=2;
                update crbt_subscriber_master set status='S',update_time=sysdate where msisdn=p_msisdn;
                commit;
                p_status:=2;
                insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,'SS',p_int,'N',p_updatedby,1);
                commit;
                p_status:=3;
                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'SUSPENDED',p_subtype,p_int,p_updatedby);
                commit;
                p_status:=4;
        end if;
        exception
                when others then
                        p_status:=(p_status)*(-1);
End SuspendService;


Procedure StopRbtRenew(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbtCode in number, p_status out number,p_id out number) is
l_temp number;
Begin
        p_status:=1;
        p_id:=1;
        l_temp:=1;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='A';
        if l_temp != 0 then
                p_status:=-30;
                RETURN;
        end if;
        p_status:=1;
        if p_rbtCode != -99 then
                select count(*) into l_temp from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbtCode and rbt_code!=0;
                if l_temp = 0 then
                        p_status:=-15;
                        RETURN;
                end if;
                update crbt_wallet_content set renew_enable='N' where msisdn=p_msisdn and rbt_code=p_rbtCode;
                commit;
                p_status:=2;
        else
                update crbt_wallet_content set renew_enable='N' where msisdn=p_msisdn and rbt_code!=0;
                commit;
                p_status:=3;
        end if;

                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'Rbt Renew Stop '||p_rbtCode,p_subtype,p_int,p_updatedby);
                commit;
                p_status:=4;
        exception
                when others then
                        p_status:=(p_status)*(-1);
                        p_status:=(p_status)*(-1);
End StopRbtRenew;



Procedure CheckTempRbt(p_msisdn in varchar2,p_int in varchar2,p_rbt in out number,p_status out number) is
l_temp number;
l_rbt number;
l_temprbt number;
l_cpCode number;
l_rbtCount number;
Begin
	p_status:=1;
l_temprbt:=p_rbt;
	l_temp:=0;
	select  count(*) into l_temp from map_logs where o_rbt=p_rbt;
	p_status:=2;	

	if l_temp = 0 then
		RETURN;
	else
		select n_rbt into l_rbt from map_logs where  o_rbt=p_rbt;
	end if;

		p_status:=3;
	select count(*) into l_temp from crbt_wallet_content where msisdn=p_msisdn and rbt_code=p_rbt;
	if l_temp = 1  then
		RETURN;
	end if;
			p_status:=4;
	select count(*) into l_temp from crbt_wallet_content where msisdn =p_msisdn and rbt_code=l_rbt;
	if l_temp=1 then
		p_rbt:=l_rbt;
		RETURN;
	end if;
	
	
		if p_int in ('S','W','C') then
		p_status:=10;
	--RETURN;
	end if;

	p_status:=5;
	select count(*) into   l_temp from crbt_logging_count where cp_code in (select content_provider_code from crbt_rbt where rbt_code=p_rbt);
	if l_temp=0 then
		RETURN;
	end if;

	select current_count,rbt_count,cp_code into l_temp,l_rbtCount,l_cpCode from crbt_logging_count where cp_code in (select content_provider_code from crbt_rbt where rbt_code=p_rbt);
	if l_temp=l_rbtCount then
		p_rbt:=l_rbt;
		p_status:=6;
		else
		p_status:=7;
	end if;
if	l_temp >=l_rbtCount then
	update crbt_logging_count set current_count=0 where  cp_code in (select content_provider_code from crbt_rbt where rbt_code=l_temprbt);
		p_status:=8;
	commit;
else

	update crbt_logging_count set current_count=current_count+1 where  cp_code in (select content_provider_code from crbt_rbt where rbt_code=l_temprbt);
		p_status:=9;
	commit;
end if;
	exception
		when others then
			p_status:=p_status*(-1);
End CheckTempRbt;


Procedure GiftSubscribe (p_msisdn in varchar2,p_plan in number,p_lang in number,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_pin in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_fmsisdn in varchar2, p_status out number,p_id out number) is 
l_wltid 		number;
l_temp number;
l_pre_amount  number;
l_post_amount  number;
l_final_amount number;
l_isSystemRbtBased number;
l_paramValue number;
l_packId number;
l_isSub number;
Begin
	p_status:=1;
	p_id:=-1;
	select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
        if p_subtype = 'O' then
           	l_final_amount:=l_post_amount;
        else
	        l_final_amount:=l_pre_amount;
        end if;
        p_status:=2;

	select SCDR_ID.nextval into p_id from dual;
	insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount) values (p_id,p_fmsisdn,p_int,sysdate,'S',p_plan,'N',p_subtype,p_refid,p_chgcode,l_final_amount);
	p_status:=3;
	commit;
	insert into crbt_subscriber_master (msisdn,status,plan_indicator,rbt_code,password,tpin,language,sub_type,last_charged,expiry_date) values (p_msisdn,'A',p_plan,0,p_pin,p_pin,p_lang,p_subtype,sysdate-30+p_validityDays,sysdate+p_validityDays);
	commit;

	p_status:=4;
	select wallet_id_seq.nextval into l_wltid from dual;
	insert into crbt_wallet_master (msisdn,wallet_id,create_date,wallet_name,ivr_name) values (p_msisdn,l_wltid,sysdate,'DEFAULT',0);
	commit;
	p_status:=5;
	insert into crbt_wallet_content (wallet_id,rbt_code,create_date,is_rbt_gifted,msisdn) values (l_wltid,0,sysdate,0,p_msisdn);
	commit;
	p_status:=6;
	insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,8,2500,2500,0,sysdate);
	commit;
	p_status:=7;
	insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,'S',p_int,'Y',p_updatedby,p_id);
	commit;
	p_status:=8;
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_fmsisdn,sysdate,1,'Subscription is Gifted to Friend '||p_msisdn,p_subtype,p_int,p_updatedby);
	commit;
	p_status:=9;
	exception
		when others then
		if p_status > 1 then
			delete from crbt_event_cdr where cdr_id=p_id;
			commit;
			delete from crbt_subscriber_master where msisdn=p_msisdn;
			commit;
			delete from crbt_subscription_log where msisdn=p_msisdn and call_id=p_id;
			commit;
		end if;
		p_status:=(p_status*(-1));
End GiftSubscribe;

Procedure UpdateReference(p_msisdn in varchar2, p_refId in varchar2,p_status out number) is
l_temp          number ;
Begin
	p_status:=-2;
	l_temp:=0;
	--select count(*) into l_temp from crbt_reference where reference_id=p_refId;
	if l_temp!=0
	then
	--	update crbt_reference set status='S',update_time=sysdate where reference_id=p_refId;
		commit;
		p_status:=1;
		RETURN;
	end if;
exception
	when others then
	p_status:=-1;
End UpdateReference;

Procedure updatePendingRequest(p_msisdn in varchar2,p_int in varchar2,p_rbtCode in number,p_status out number) is
l_temp number;
Begin
l_temp:=1;
p_status:=1;
        select count(*) into l_temp from crbt_pending_request where msisdn=p_msisdn and rbt_code=p_rbtCode;
         if l_temp = 0 then
                p_status:=2;
                return;
         else
                update crbt_pending_request set status='S' where msisdn=p_msisdn and rbt_code=p_rbtCode;
                commit;
                p_status:=3;
                return;
        end if;
         exception
                when others then
                        p_status:=(p_status)*(-1);
End updatePendingRequest;

Procedure checkAndSetProfile(p_msisdn in varchar2,p_plan in number,p_lang in number,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_rbtCode in number,p_stTime in number,p_endTime in number,p_status out number) is
l_temp number;
Begin
l_temp:=-1;
p_status:=1;
        select count(msisdn) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status != 'D';
        if l_temp = 0 then
                p_status:=-30;---not subscribed to CRBT system
                return;
         end if;
        p_status:=2;

        select active_features into l_temp from crbt_subscriber_master where msisdn=p_msisdn;
        if l_temp = 0 then
                p_status:=-38;---not a busy rbt subscriber
                return;
        end if;
        p_status:=3;

        select count(*) into l_temp from status_rbt_profile_details where msisdn=p_msisdn and start_time=p_stTime and end_time=p_endTime;
        p_status:=4;
        if l_temp = 0 then
                insert into status_rbt_profile_details (msisdn,rbt_code,start_time,end_time,update_time) values(p_msisdn,p_rbtCode,p_stTime,p_endTime,sysdate);
                p_status:=5;---new entry inserted
        else
                update status_rbt_profile_details set start_time=p_stTime, end_time=p_endTime,rbt_code=p_rbtCode,update_time=sysdate where msisdn=p_msisdn;
                p_status:=6;---existing entry updated
        end if;
        commit;

        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,'Profile RBT Set from '||p_stTime||'to'||p_endTime||p_rbtCode,p_subtype,p_int,p_updatedby);
        commit;
        p_status:=7;
        exception
                when others then
                        p_status:=(p_status)*(-1);


End checkAndSetProfile;

Procedure UnSetProfile(p_int in varchar2,p_updatedby in varchar2,p_status out number) is
l_temp number;
l_msisdn varchar2(20);
l_subType varchar2(2);
l_stTime number;
l_endTime number;
l_rbtCode number;
cursor sel_busy_rbt_record is select msisdn,start_time,end_time,rbt_code from status_rbt_profile_details where start_time<(to_number(to_char(sysdate,'HH24'))*100) and end_time <= (to_number(to_char(sysdate,'HH24'))*100);

Begin
l_temp:=-1;
p_status:=1;
l_rbtCode:=-1;
--l_subType:='N';
l_stTime:=-1;
l_endTime:=-1;

open sel_busy_rbt_record;
LOOP
fetch sel_busy_rbt_record into l_msisdn,l_stTime,l_endTime,l_rbtCode;
        if sel_busy_rbt_record%NOTFOUND then
                        dbms_output.put_line('sel_busy_rbt_record NOTFOUND');
                        close sel_busy_rbt_record;
                        p_status:=2;
                        return;
        end if;
        select sub_type into l_subType from crbt_subscriber_master where msisdn=l_msisdn;
        p_status:=3;

        delete from status_rbt_profile_details where start_time=l_stTime and end_time=l_endTime and rbt_code=l_rbtCode and msisdn=l_msisdn;
        commit;
        p_status:=4;
        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (l_msisdn,sysdate,1,'Profile RBT deactivated '||l_rbtCode,l_subType,p_int,p_updatedby);
        commit;
        p_status:=5;
END LOOP;
        exception
                when others then
                        p_status:=(p_status)*(-1);
End UnSetProfile;
--//////////////////////////////;


-------procedure for system default

Procedure SetDefaultWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id  in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_type in number,p_status out number,p_id out number) is
		l_char 		varchar2 (1);
		l_length 	PLS_INTEGER;
		l_temp 		number;
		l_status 	number;
		l_id 		number;
Begin
								
	p_status:=1;
	p_id:=-1;
	l_temp:=-1;
	dbms_output.put_line('Before AddWallet in SetDefaultWallet');
	AddWallet(p_msisdn,p_int,p_updatedby,p_subtype,p_sys_wallet_id,p_chgdone,p_refid,p_chgcode,p_validityDays,p_packId,p_type,p_status,l_temp);
	dbms_output.put_line('After AddWallet in SetDefaultWallet');
	if p_status < 0
		then
			dbms_output.put_line( 'exception occured AddWalllet '||p_status);
			p_status:=p_status+ -50 ;
			RETURN;
		else
			p_id:=l_temp;
	end if;
	l_temp:=0;
	if p_days = 8 then
		dbms_output.put_line('before select from crbt_default_detail if pdays=8');
		select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
		dbms_output.put_line('After Select from crbt_default_detail if p_days=8');
		if l_temp = 0 then
			insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time,content_type) values (p_msisdn,p_days,p_sttime,p_entime,p_sys_wallet_id,sysdate,p_type);	
commit;	
			dbms_output.put_line('after insert crbt_default_detail');	 					  p_status:=2;								 			    else
			update crbt_default_detail set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime; 	
			commit;
			p_status:=3;
		end if;
	else
		l_length:=LENGTH(p_days);
		IF l_length > 0	THEN
			FOR l_index IN 1 .. l_length
			LOOP
				l_char := SUBSTR (p_days,l_index, 1);
				dbms_output.put_line('Before select crbt_default_detail if days!=8');
select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;
				dbms_output.put_line('After select crbt_default_detail if days!=8 where l_temp '||l_temp);																					
				if l_temp = 0 then
					dbms_output.put_line('Before insert into crbt_default_detail if days!=8 where l_char'||l_char);
					insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time,content_type,LAST_CHARGED) values (p_msisdn,l_char,p_sttime,p_entime,p_sys_wallet_id,sysdate,p_type,sysdate);
					dbms_output.put_line('After update crbt_default_detail if days!=8');
   					commit;
					p_status:=2;
				else
					dbms_output.put_line('Before update crbt_default_detail if days!=8');
					update crbt_default_detail set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime; 
					dbms_output.put_line('after update crbt_default_detail if days!=8');
					commit;
					p_status:=3;
				end if;
			END LOOP;
		END IF;
	END IF;
	if p_days = 8 AND p_sttime = 2500 AND p_entime = 2500  	then
		dbms_output.put_line('Before update crbt_subscriber_master');
		update crbt_subscriber_master set rbt_code=p_sys_wallet_id,active_features=2 where msisdn=p_msisdn;
		dbms_output.put_line('After update crbt_subscriber_master');
		commit;
		p_status:=5;
	 	end if;
		--p_status:=6;
		dbms_output.put_line('Before insert crbt_rbt_op_log');
		insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_sys_wallet_id,p_int,1,'DEFAULT','N',p_updatedby,p_id,1); 
		commit;
		dbms_output.put_line('After insert crbt_rbt_op_log');
		--p_status:=6;
		dbms_output.put_line('Before insert crbt_activity_detail_log');
		insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A System Wallet ' || p_sys_wallet_id || ' is Set Default',p_subtype,p_int,p_updatedby);
		 commit;
		dbms_output.put_line('After insert crbt_activity_detail_log');
		 l_temp:=-1;
		 dbms_output.put_line('before select CRBT_SUBSCRIBER_WALLET_DETAIL');
		select count(*) into l_temp from CRBT_SUBSCRIBER_WALLET_DETAIL  where status='S' and msisdn=p_msisdn;
		dbms_output.put_line('After select CRBT_SUBSCRIBER_WALLET_DETAIL');
		if l_temp > 0 then
			dbms_output.put_line('before walletUnSuspend');
			WalletUnSuspend(p_msisdn ,p_int ,p_updatedby,p_subtype,-1,p_type,l_status,l_id ); 
			dbms_output.put_line('After WalletUnSuspend');
		end if;

	exception												  when others then
												--			dbms_output.put_line( 'exception occured ');
	      --p_status:=-1;
	      p_status:=(p_status*(-1));
End SetDefaultWallet;


Procedure SetFriendWallet(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_fmsisdn in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_type in number,p_status out number,p_id out number) is 
				l_temp 		number;
				l_length PLS_INTEGER;
				l_char varchar2 (1);
				Begin
								p_status:=1;
								p_id:=-1;
												AddWallet(p_msisdn,p_int,p_updatedby,p_subtype,p_sys_wallet_id,p_chgdone,p_refid,p_chgcode,p_validityDays,p_packId,p_type,p_status,l_temp);
												if p_status < 0
												then
																p_status:=-1;
																RETURN;
												else
																p_id:=l_temp;
												end if;


							l_temp:=0;
				   select count(*) into l_temp from crbt_friend_detail where msisdn=p_msisdn and friend_msisdn=p_fmsisdn;
				   if l_temp = 0 then
												if p_days = 8 AND p_sttime = 2500 AND p_entime = 2500  
												then
												dbms_output.put_line( ' friend not exist crbt_friend_detail ' );
																insert into crbt_friend_detail (msisdn,friend_msisdn,friend_setting_string) values (p_msisdn,p_fmsisdn,'800000000000000000000000000000000000000000000000000000000000');
																p_status:=3;
												else
																insert into crbt_friend_detail (msisdn,friend_msisdn,friend_setting_string) values (p_msisdn,p_fmsisdn,'000000000000000000000000000000000000000000000000000000000000');
												end if;
												commit;
--																				insert into crbt_friend_setting (msisdn,friend_msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_fmsisdn,p_days,p_sttime,p_entime,p_sys_wallet_id,sysdate);
												insert into crbt_friend_op_log (msisdn,subscriber_type,event_time,interface_type,op_code,friend_msisdn,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,1,p_fmsisdn,'N',p_updatedby,p_id);
												commit;
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Friend '||p_fmsisdn||' is Added',p_subtype,p_int,p_updatedby);

												commit;

												dbms_output.put_line( 'friend not exist  days inserting in crbt_friend_op_log' );
												commit;
								end if;
								l_temp:=0;
								if p_days = 8
								then
												select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
												if l_temp = 0 then
																insert into crbt_friend_setting (msisdn,friend_msisdn,day,start_at,ends_at,rbt_code,update_time,content_type) values (p_msisdn,p_fmsisdn,p_days,p_sttime,p_entime,p_sys_wallet_id,sysdate,p_type);
																commit;
																dbms_output.put_line( 'days 8 crbt_friend setting' );
																if p_status != 3
																then
																				p_status:=2;
																end if;
												else
																update crbt_friend_setting set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and day=p_days and start_at=p_sttime and ends_at=p_entime; 
																dbms_output.put_line( 'days 8 update crbt_friend setting' );
																commit;
												end if;
								else
												l_length:=LENGTH(p_days);
												IF l_length > 0
												THEN
																FOR l_index IN 1 .. l_length
																LOOP
																dbms_output.put_line( 'in loop index '||l_index );
																				l_char := SUBSTR (p_days,l_index, 1);
																				select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;
																				if l_temp = 0 then
																dbms_output.put_line( 'before insert in crbt_friend_settingin loop index '||l_index );
																								insert into crbt_friend_setting (msisdn,friend_msisdn,day,start_at,ends_at,rbt_code,update_time,LAST_CHARGED,content_type) values (p_msisdn,p_fmsisdn,l_char,p_sttime,p_entime,p_sys_wallet_id,sysdate,sysdate,p_type);
																								commit;
																dbms_output.put_line( 'after insert in crbt_friend_settingin loop index '||l_index );
																								p_status:=2;
																				else
																dbms_output.put_line( 'before update in crbt_friend_settingin loop index '||l_index );
																								update crbt_friend_setting set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and day=l_char and start_at=p_sttime and ends_at=p_entime; 
																								commit;
																				end if;
																END LOOP;
												END IF;
								end if;
								insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_sys_wallet_id,p_int,1,p_fmsisdn,'N',p_updatedby,p_id,1); 
								commit;
								insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Wallet '|| p_sys_wallet_id || ' For Friend '||p_fmsisdn||' is Set',p_subtype,p_int,p_updatedby);
								commit;

																dbms_output.put_line( 'after inserting in crbt_rbt_op_log ' );
								exception
												when others then
												p_status:=-1;
End SetFriendWallet;

Procedure SetGroupWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_days in varchar2,p_sttime in number,p_entime in number,p_chgdone in number,p_grpname in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_type in number,p_status out number,p_grpid out number) is 
	l_temp 		number;
	p_id 		number;
	l_length PLS_INTEGER;
	l_char varchar2 (1);
cursor sel_grp_id is select groupid from crbt_group_detail where msisdn=p_msisdn and upper(masked_name)=upper(p_grpname);
Begin
	p_status:=1;
	p_id:=-1;
	AddWallet(p_msisdn,p_int,p_updatedby,p_subtype,p_sys_wallet_id,p_chgdone,p_refid,p_chgcode,p_validityDays,p_packId,p_type,p_status,l_temp);
	if p_status < 0
	then
		p_status:=-1;
		RETURN;
	else
		p_id:=l_temp;
	end if;
	open sel_grp_id;
	fetch sel_grp_id into p_grpid;
	if sel_grp_id%NOTFOUND 
	then
		close sel_grp_id;
		p_status:=-13;
		RETURN;
	else
		close sel_grp_id;
	end if;
						
	l_temp:=0;
	if p_days = 8
	then
		select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and groupid=p_grpid and day=p_days and start_at=p_sttime and ends_at=p_entime;
		if l_temp = 0 then
			insert into crbt_group_setting (msisdn,groupid,day,start_at,ends_at,rbt_code,update_time,content_type) values (p_msisdn,p_grpid,p_days,p_sttime,p_entime,p_sys_wallet_id,sysdate,p_type);
			commit;
			p_status:=2;
		else
			update crbt_group_setting set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and groupid=p_grpid and day=p_days and start_at=p_sttime and ends_at=p_entime;
			commit;
		end if;
	else
		l_length:=LENGTH(p_days);
		IF l_length > 0
		THEN
			FOR l_index IN 1 .. l_length
			LOOP
				l_char := SUBSTR (p_days,l_index, 1);
				select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and groupid=p_grpid and day=l_char and start_at=p_sttime and ends_at=p_entime;
				if l_temp = 0 then
				dbms_output.put_line('Before insert into crbt_group_setting and l_temo='||l_temp);
				insert into crbt_group_setting (msisdn,groupid,day,start_at,ends_at,rbt_code,update_time,content_type) values (p_msisdn,p_grpid,l_char,p_sttime,p_entime,p_sys_wallet_id,sysdate,p_type);
				 dbms_output.put_line('After insert into crbt_group_setting and l_temo='||l_temp);
				commit;
				p_status:=2;
				else
					update crbt_group_setting set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and groupid=p_grpid and day=l_char and start_at=p_sttime and ends_at=p_entime; 
					commit;
				end if;
			END LOOP;
		END IF;
	end if;
	insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_sys_wallet_id,p_int,1,p_grpname,'N',p_updatedby,p_id,1); 
	commit;
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Wallet '|| p_sys_wallet_id ||' For Group '||p_grpname||' is Set',p_subtype,p_int,p_updatedby);
	commit;
	exception
	when others then
		p_status:=-1;
End SetGroupWallet;

Procedure GenerateCrbtCdrs (p_msisdn in varchar2,p_chgcode in number,p_action in number,p_interface in varchar2,p_sc in number,p_daid in number,p_cdate in date,p_fmsisdn in varchar2,p_sys_wallet_id in number,p_amt in number,p_subtype in varchar2,p_status in varchar2,p_type in number,p_id out number) is 
				Begin
												
								    select crbt_cdr_id.nextval into p_id from dual;
												insert into crbt_cdrs (MSISDN,TARIFFID,ACTION,INTERFACE,SERVICE_CLASS,DA_ID,CREATE_DATE,FMSISDN,RBT_CODE,AMOUNT,STATUS,CDR_ID ) values (p_msisdn,p_chgcode,p_action,p_interface,p_sc,p_daid,p_cdate,p_fmsisdn,p_sys_wallet_id,p_amt,'N',p_id);
												commit;
												select SCDR_ID.nextval into p_id from dual;
												insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,TARIFF_ID,amount,RBT_CODE) values (p_id,p_msisdn,p_interface,sysdate,'R',1,'N',p_subtype,p_chgcode,p_amt,p_sys_wallet_id);
												commit;

												exception
												when others then
												p_id:=-1;
End GenerateCrbtCdrs;




Procedure AddWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_chgdone in number,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_type in number,p_status out number,p_id out number) is 
l_temp 	number ;
l_totalRbt number;
l_freeRbt number;
l_isSystemRbtBased number;
l_renew_enable number;
l_count number;
l_sys_wallet_setting number;
Begin
	l_temp:=0;
	l_totalRbt:=0;
	l_freeRbt:=0;
	l_renew_enable:=-1;
	l_count:=-1;
	l_sys_wallet_setting:=1;
	l_isSystemRbtBased:=-1;
	
	if p_chgdone != 1
	then
		p_status:=1;
		p_id:=-1;
		RETURN;
	end if;
	p_status:=1;				
	l_temp:= 0;
	CRBTNEW.GenerateRBTSettingCDR(p_msisdn,p_int,p_subtype,1,p_sys_wallet_id,p_refid,p_chgcode,p_id);

	if p_id=-1
	then
		p_status:=-18;
		RETURN;
	end if;
												

	p_status:=2;				
	dbms_output.put_line('after AddAlbum wallet_id1  '||l_temp);
	dbms_output.put_line('before select renew_enable');
	select renew_enable into l_renew_enable from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A';
	dbms_output.put_line('After select renew_enable');
	p_status:=3;

	
	l_count:=-1;
	select count(*) into l_count from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A' and expiry_date>=sysdate;
	p_status:=4;
	if l_count >0 then 
		select setting into l_sys_wallet_setting from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A' and expiry_date>=sysdate;
		p_status:=5;
	end if;
	

insert into CRBT_SUBSCRIBER_WALLET_DETAIL(msisdn,wallet_id,create_date,expiry_date,last_charged_date,renew_enable,status,use_case,is_gifted,fmsisdn,setting) values(p_msisdn,p_sys_wallet_id,sysdate,sysdate+p_validityDays,sysdate,l_renew_enable,'A',0,0,'NA',l_sys_wallet_setting);

	commit;
	dbms_output.put_line('after AddAlbum wallet_id2   '||l_temp);
	p_status:=6;				
        
 select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
        
	if l_isSystemRbtBased=1 then	
		update crbt_subscriber_master set last_charged=sysdate-30+p_validityDays, expiry_date=sysdate+p_validityDays, update_time=sysdate where msisdn=p_msisdn and last_charged<=(sysdate-30+p_validityDays);
       		commit;
	end if;
	p_status:=7;				

	insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,p_sys_wallet_id,l_temp,4,'Y',p_updatedby,p_id);
	commit;
	p_status:=8;				
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,p_sys_wallet_id||'Added WALLET',p_subtype,p_int,p_updatedby);
	p_status:=9;				
	commit;
	--update crbt_rbt set rbt_score=rbt_score+1 where rbt_code=rbt_code;
	---p_status:=11;
	--commit;
	exception
		when others then
			p_id:=-1;
			p_status:=(p_status*(-1));
End AddWallet;


Procedure DeleteWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_type in number,p_status out number,p_updatecode out number,p_filePath out varchar2) is 
				--l_temp 		PLS_INTEGER ;
				l_temp 		number ;
				l_cnt 		number ;
				
				Begin
												p_status:=-1;				
												l_temp:=0;
												l_cnt:=0;
												p_updatecode:=0;
		
												select count(*) into l_cnt from CRBT_SUBSCRIBER_WALLET_DETAIL  where msisdn=p_msisdn and wallet_id=p_sys_wallet_id;												
												if l_cnt = 0 then
												p_status:=-17;
												RETURN;
												end if;
													
												l_cnt:=0;
												
												select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
												p_status:=2;
												if l_temp = 0
												then
																p_updatecode:=0;	-- no need to update default setting string
												else
																select count(*) into l_cnt from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and day=8 and start_at=2500 and ends_at=2500 and content_type=p_type;
													p_status:=3;
																if l_cnt = 0
																then
																				p_updatecode:=1; -- default setting will not be effected but default string needs to be updated
																else
																				update crbt_default_detail set rbt_code=0 ,content_type=0 where msisdn=p_msisdn and day=8 and start_at=2500 and ends_at=2500 and content_type=p_type;
																				commit;
													p_status:=4;
																				update crbt_subscriber_master set rbt_code=0 where msisdn=p_msisdn;
																				commit;
													p_status:=5;
												--								 if user has more than one settings for this string only then string will be updated
																				if l_temp > 1
																				then
																								p_updatecode:=1;
																				end if;
																end if;
												end if;
												
												l_temp:=0;
												select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
													p_status:=6;
												if l_temp > 0
												then
																p_updatecode:=(p_updatecode + 2);
												end if;
												
												l_temp:=0;
												select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
													p_status:=7;
												if l_temp > 0
												then
																p_updatecode:=(p_updatecode + 4);
												end if;


l_temp:=-1;
select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
p_status:=8;
if l_temp > 0 then
	delete from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
	commit;
	p_status:=9;
end if;

l_temp:=-1;
select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
p_status:=10;
if l_temp > 0 then
        delete from crbt_group_setting where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
        commit;
        p_status:=11;
end if;


l_temp:=-1;
select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
p_status:=12;
if l_temp > 0 then
        delete from crbt_friend_setting where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
        commit;
        p_status:=13;
end if;


l_temp:=-1;
select count(*) into l_temp from crbt_eventdate_rbt where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
p_status:=14;
if l_temp > 0 then
        delete from crbt_eventdate_rbt where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
        commit;
        p_status:=15;
end if;


												delete from crbt_subscriber_wallet_detail where msisdn=p_msisdn and wallet_id=p_sys_wallet_id;
                                                commit;
                                                p_status:=16;
                                                                                               
                                                insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,p_sys_wallet_id,l_temp,5,'N',p_updatedby,-1);
                                                commit;
                                                p_status:=17;
												
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Wallet '||p_sys_wallet_id|| 'is Deleted',p_subtype,p_int,p_updatedby);
												commit;
												p_status:=19;
								exception
												when others then
												p_status:=(p_status*(-1));
	End DeleteWallet;
	
	
	

Procedure SetDateWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_occasion in varchar2,p_chgdone in number,p_date in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_packId in number,p_type in number,p_status out number) is
				l_temp 		number;
				p_id number;
				Begin
								p_status:=1;
								p_id:=-1;
												AddWallet(p_msisdn,p_int,p_updatedby,p_subtype,p_sys_wallet_id,p_chgdone,p_refid,p_chgcode,p_validityDays,p_packId,p_type,p_status,l_temp);
												if p_status < 0
												then
															--	p_status:=-1;
																RETURN;
												else
																p_id:=l_temp;
												end if;
								p_status:=2;

								l_temp:=0;
				    select count(*) into l_temp from crbt_eventdate_rbt where msisdn=p_msisdn and to_date(to_char(event_date,'ddmmyy'),'ddmmyy')=to_date(p_date,'ddmmyy');
				    if l_temp = 0 then
								dbms_output.put_line('Before insert crbt_eventdate_rbt and ltemp= '||l_temp);
												insert into crbt_eventdate_rbt (msisdn,event_date,rbt_code,update_time,occasion_name,content_type) values (p_msisdn,to_date(p_date,'ddmmyy'),p_sys_wallet_id,sysdate,p_occasion,p_type);
								dbms_output.put_line('After insert crbt_eventdate_rbt and ltemp= '||l_temp);
								p_status:=3;
								else
								dbms_output.put_line('Before update crbt_eventdate_rbt and ltemp= '||l_temp);
												update crbt_eventdate_rbt set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and 	to_date(to_char(event_date,'ddmmyy'),'ddmmyy')=to_date(p_date,'ddmmyy');
								dbms_output.put_line('Afetr update crbt_eventdate_rbt and ltemp= '||l_temp);
								end if;
								commit;
								p_status:=4;

								if to_date(p_date,'ddmmyy') = to_date(to_char(sysdate,'ddmmyy'),'ddmmyy')
								then
												update crbt_subscriber_master set date_setting_validity=1 where msisdn=p_msisdn;
												commit;
								end if;
								p_status:=5;
								
								insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_sys_wallet_id,p_int,1,p_date,'N',p_updatedby,p_id,1); 
								p_status:=6;
								commit;
								insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Wallet for Date '||p_date||' is set',p_subtype,p_int,p_updatedby);
								p_status:=7;
								commit;

								exception
												when others then
												p_status:=(p_status*(-1));
End SetDateWallet;



Procedure DeleteDefaultWalletSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_days in varchar2,p_sttime in number,p_entime in number,p_type in number,p_status out number) is 
				l_char varchar2 (1);
				l_length PLS_INTEGER;
				Begin
								p_status:=1;
												if p_days = 8
												then
																delete from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and day=p_days and start_at=p_sttime and ends_at=p_entime and content_type=p_type;
																commit;
																p_status:=2; -- this value will be checked in code and string will be updated
												else
																l_length:=LENGTH(p_days);
																IF l_length > 0
																THEN
																				FOR l_index IN 1 .. l_length
																				LOOP
																								l_char := SUBSTR (p_days,l_index, 1);
																												delete from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and day=l_char and start_at=p_sttime and ends_at=p_entime and content_type=p_type;
																												commit;
																												p_status:=2; -- this value will be checked in code and string will be updated
																				END LOOP;
																END IF;
												END IF;

												insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_sys_wallet_id,p_int,5,'DEFAULT','N',p_updatedby,-1,1); 
												commit;
												insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Default Wallet profile is deleted',p_subtype,p_int,p_updatedby);
												commit;


								exception
												when others then
												--				dbms_output.put_line( 'exception occured ');
												p_status:=-1;
												--p_status:=8;
End DeleteDefaultWalletSetting;


Procedure DeleteFriendWalletSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_days in varchar2,p_sttime in number,p_entime in number,p_fmsisdn in varchar2,p_type in number,p_status out number) is 
				l_length PLS_INTEGER;
				l_char varchar2 (1);
				Begin
								p_status:=1;

								select count(*) into l_length from crbt_friend_detail where msisdn=p_msisdn and friend_msisdn=p_fmsisdn;

								if l_length = 0
								then
												p_status:=-12;
												RETURN;
								end if;
								l_length:=0;
								
								if p_days = 8
								then
												delete from crbt_friend_setting where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and rbt_code=p_sys_wallet_id and day=p_days and start_at=p_sttime and ends_at=p_entime and content_type=p_type;
												commit;
												p_status:=2; -- this value will be checked in code and string will be updated
								else
												l_length:=LENGTH(p_days);
												IF l_length > 0
												THEN
																FOR l_index IN 1 .. l_length
																LOOP
																				l_char := SUBSTR (p_days,l_index, 1);
																				delete from crbt_friend_setting where msisdn=p_msisdn and friend_msisdn=p_fmsisdn and rbt_code=p_sys_wallet_id and day=l_char and start_at=p_sttime and ends_at=p_entime and content_type=p_type ;
																				commit;
																   	p_status:=2; -- this value will be checked in code and string will be updated
																END LOOP;
												END IF;
								end if;
								insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_sys_wallet_id,p_int,5,p_fmsisdn,'N',p_updatedby,-1,1); 
								commit;
								insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'Wallet Setting of friend '||p_fmsisdn||' is deleted',p_subtype,p_int,p_updatedby);
								commit;

								exception
												when others then
												p_status:=-1;
End DeleteFriendWalletSetting;



Procedure DeleteGroupWalletSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_days in number,p_sttime in number,p_entime in number,p_grp in varchar2,p_type in number,p_status out number,p_grpid out number) is 
				l_length PLS_INTEGER;
				l_char varchar2 (1);
				cursor sel_grp_id is select groupid from crbt_group_detail where msisdn=p_msisdn and upper(masked_name)=upper(p_grp);
				Begin
												p_status:=1;
												l_length:=0;
												open sel_grp_id;
												fetch sel_grp_id into p_grpid;
												if sel_grp_id%NOTFOUND 
												then
																close sel_grp_id;
																p_status:=-13;
																RETURN;
												else
																close sel_grp_id;
												end if;
												
								if p_days = 8
								then
												delete from crbt_group_setting where msisdn=p_msisdn and groupid=p_grpid and rbt_code=p_sys_wallet_id and day=p_days and start_at=p_sttime and ends_at=p_entime and content_type=p_type; 
												commit;
												p_status:=2; -- this value will be checked in code and string will be updated
								else
												l_length:=LENGTH(p_days);
												IF l_length > 0
												THEN
																FOR l_index IN 1 .. l_length
																LOOP
																				l_char := SUBSTR (p_days,l_index, 1);
																				delete from crbt_group_setting where msisdn=p_msisdn and groupid=p_grpid and rbt_code=p_sys_wallet_id and day=l_char and start_at=p_sttime and ends_at=p_entime and content_type=p_type; 
																				commit;
																   	p_status:=2; -- this value will be checked in code and string will be updated
																END LOOP;
												END IF;
								end if;
												
								insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_sys_wallet_id,p_int,5,p_grpid,'N',p_updatedby,-1,1); 
								commit;
								insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'Wallet Setting of group '||p_grp||' is deleted',p_subtype,p_int,p_updatedby);
								commit;

												
								exception
												when others then
												p_status:=-1;
	End DeleteGroupWalletSetting;
	
	Procedure WalletSuspend(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_type in number, p_status out number,p_id out number) is
l_temp number;
Begin
        p_status:=1;
        p_id:=1;
        l_temp:=1;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='A';
        if l_temp != 0 then
                p_status:=-30;
                RETURN;
        end if;
        p_status:=1;
        if p_sys_wallet_id != -1 then
                select count(*) into l_temp from crbt_subscriber_wallet_detail where msisdn=p_msisdn and wallet_id=p_sys_wallet_id and wallet_id!=0 and status='A';
                if l_temp = 0 then
                        p_status:=-15;
                        RETURN;
                end if;
                update crbt_subscriber_wallet_detail set status='S' where msisdn=p_msisdn and wallet_id=p_sys_wallet_id;
                commit;
                p_status:=2;
        else
                update crbt_subscriber_wallet_detail set status='S' where msisdn=p_msisdn and wallet_id!=0;
                commit;
                p_status:=3;
        end if;

                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'Wallet Suspended '||p_sys_wallet_id,p_subtype,p_int,p_updatedby);
                commit;
                p_status:=4;
        exception
                when others then
                        p_status:=(p_status)*(-1);

End WalletSuspend;

Procedure WalletUnSuspend(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_type in number, p_status out number,p_id out number) is
l_temp number;
Begin
        p_status:=1;
        p_id:=1;
	l_temp:=1;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='A';
        if l_temp != 0 then
                p_status:=-30;
                RETURN;
        end if;
        p_status:=1;
        if p_sys_wallet_id != -1 then
                select count(*) into l_temp from crbt_subscriber_wallet_detail where msisdn=p_msisdn and wallet_id=p_sys_wallet_id and wallet_id!=0 and status='S';
                if l_temp = 0 then
                        p_status:=-15;
                        RETURN;
                end if;
                update crbt_subscriber_wallet_detail set status='A' where msisdn=p_msisdn and wallet_id=p_sys_wallet_id;
                commit;
                p_status:=2;
        else
                update crbt_subscriber_wallet_detail set status='A' where msisdn=p_msisdn and wallet_id!=0;
                commit;
                p_status:=3;
        end if;

                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'Wallet UnSuspended '||p_sys_wallet_id,p_subtype,p_int,p_updatedby);
                commit;
                p_status:=4;
        exception
                when others then
                        p_status:=(p_status)*(-1);

End WalletUnSuspend;


Procedure PendingWalletGiftAccept(p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number, p_fmsisdn in varchar2, p_planId in number,p_type in number,p_status out number,p_id out number) is
l_temp number;
l_subStatus varchar2(3);
Begin
        p_status:=1;
        p_id:=1;
        l_temp:=1;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_fmsisdn;
        if l_temp = 0 then
                l_subStatus:='D';
	else
		select status into l_subStatus from crbt_subscriber_master where msisdn=p_fmsisdn;
        end if;
        p_status:=2;
	insert into GIFT_PENDING_REQUEST(MSISDN,FMSISDN,rbt_code,REQUEST_TIME,FMSISDN_SUB_STATUS,interface,updated_by,plan_id,sub_type,content_type) values(p_msisdn,p_fmsisdn,p_sys_wallet_id,sysdate,l_subStatus,p_int,p_updatedby,p_planId,p_subType,p_type);
	commit;
        p_status:=3;
        exception
                when others then
                        p_status:=(p_status)*(-1);

End PendingWalletGiftAccept;


Procedure DeleteDateWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number, p_date in varchar2,p_type in number,p_status out number) is 
				l_temp 		number;
				p_id number;
				Begin
								p_status:=1;
								p_id:=-1;

								delete crbt_eventdate_rbt where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and to_date(to_char(event_date,'ddmmyy'),'ddmmyy')=to_date(p_date,'ddmmyy') and content_type=p_type;
								commit;
								p_status:=4;

								if to_date(p_date,'ddmmyy') = to_date(to_char(sysdate,'ddmmyy'),'ddmmyy')
								then
												update crbt_subscriber_master set date_setting_validity=0 where msisdn=p_msisdn;
												commit;
								end if;
								p_status:=5;
								
								insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,sysdate,p_sys_wallet_id,p_int,5,p_date,'N',p_updatedby,p_id,1); 
								p_status:=6;
								commit;
								insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Wallet for Date '||p_date||' is Deleted',p_subtype,p_int,p_updatedby);
								p_status:=7;
								commit;

								exception
												when others then
												p_status:=(p_status*(-1));
End DeleteDateWallet;




Procedure CheckForWalletGift (p_msisdn in varchar2,p_sys_wallet_id in number,p_subType in varchar2,p_interface in varchar2,p_type in number,p_status out number) is 
l_temp 		number;
l_catid number;
l_cpid number;
Begin
	p_status:=0;	
	dbms_output.put_line('Before select operator_subscriber ');
	select count(*) into l_temp from operator_subscriber where to_number(p_msisdn) >= to_number(STARTS_AT) and to_number(p_msisdn) <= to_number(ENDS_AT);
	dbms_output.put_line('After select operator_subscriber ');

	if l_temp = 0 then
		p_status:=-22;
 		RETURN;
	end if;
	 dbms_output.put_line('Before select crbt_subscriber_master ');
	select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='D';
	dbms_output.put_line('Before select crbt_subscriber_master ');

	if l_temp = 0 then
		p_status:=-8;
	else
		dbms_output.put_line('Before CheckWalletCode');
		CheckWalletCode(p_msisdn,p_sys_wallet_id,p_subType,p_interface,p_type,p_status);
	end if;
	exception
		when others then
			p_status:=-1;
End CheckForWalletGift;

Procedure CheckWalletCode (p_msisdn in varchar2,p_sys_wallet_id in number,p_subType in varchar2,p_interface in varchar2,p_type in number,p_status out number) is
        l_count number;
        l_scope varchar2(100);
        l_subType varchar2(2);
        Begin
        p_status:=-1;
        l_count:=-1;
        l_scope:='NA';
        l_subType:='N';
		dbms_output.put_line('Before select crbt_subscriber_wallet_detail1');	
		select count(*) into l_count from crbt_subscriber_wallet_detail where wallet_id=p_sys_wallet_id and msisdn=p_msisdn and status='A';
                if l_count > 0 then
                        p_status:=-50;  --Already purchased active user
                        return;
                else
                        p_status:=1;						 
                end if;
		
		l_count:=-1;		
		dbms_output.put_line('Before select crbt_subscriber_wallet_detail2');	
		select count(*) into l_count from crbt_subscriber_wallet_detail where wallet_id=p_sys_wallet_id and msisdn=p_msisdn and status='I';
                if l_count > 0 then
                        p_status:=-51;  --Already purchased inactive user
                        return;
                else
                        p_status:=2;						 
                end if;
				
		dbms_output.put_line('Before select crbt_subscriber_wallet_detail3');	
        select count(*) into l_count from crbt_system_Wallet_master  where wallet_id =p_sys_wallet_id and status='A' and expiry_date>=sysdate and start_date<=sysdate and (interface like '%'||p_interface||'%' or interface ='A');
        p_status:=3;
        if l_count > 0 then
		dbms_output.put_line('Before select crbt_subscriber_wallet_detail4');	
                select scope into l_scope from crbt_system_Wallet_master  where wallet_id =p_sys_wallet_id and status='A' and expiry_date>=sysdate and start_date<=sysdate and (interface like '%'||p_interface||'%' or interface ='A');
		dbms_output.put_line('Before select crbt_subscriber_wallet_detail5');	
                p_status:=4;


		dbms_output.put_line('Before CRBTNEW.ParseStringToString');
  
                CRBTNEW.ParseStringToString(l_scope,'SUBTYPE:',l_subType,p_status);
                dbms_output.put_line('l_subType['||l_subType||'] p_subType['||p_subType||'] p_status['||p_status||']');

		if l_subType is NOT null then
		  
		  if l_subType = p_subType OR l_subType = 'B' then
			p_status:=5;
                  else
                        p_status:=-52;  --not applicable to this subscriber
                        return;
		  end if;
		else
			p_status:=-60; 	--scope is blank             
			return;
		end if;
		  
             
        else
                p_status:=-53; --wallet id not exist
		return;
        end if;

	l_count:=0;
	select count(*) into l_count from crbt_subscriber_wallet_detail where wallet_id=p_sys_wallet_id and msisdn=p_msisdn and status='S';
	
	if l_count = 1 then
		p_status:=-57; -- Suspended Wallet not allowed		
	end if;

		return;		
        
		exception
        when others then
                p_status:=-1;
End CheckWalletCode;



Procedure CheckForWalletGiftAccept(p_msisdn in varchar2,p_sys_wallet_id in out number,p_fmsisdn  in varchar2,p_subType in varchar2,p_interface in varchar2,p_type in number,p_status out number) 
is
l_temp 		number;
l_fmsisdn varchar2(15);
l_planId number;
l_catid number;
l_cpid number;
Begin
	
	p_status:=5;
	l_temp:=0;
	if p_sys_wallet_id = -1 then
		select count(*) into l_temp from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(sysdate-1) and content_type=p_type;
	else
		select count(*) into l_temp from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(sysdate-1) and rbt_code=p_sys_wallet_id and content_type=p_type;
	end if;
		p_status:=1;

	if l_temp = 0 then
		p_status:=-54; ---no wallet to accept
		RETURN;
	end if;
		p_status:=2;
	if p_sys_wallet_id = -1 then
		p_status:=11;
		select rbt_code,fmsisdn,plan_id into p_sys_wallet_id,l_fmsisdn,l_planId from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and REQUEST_TIME>=(sysdate-1) and content_type=p_type and REQUEST_TIME=(select max(REQUEST_TIME) from  GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and content_type=p_type);
	else
		p_status:=14;
		select fmsisdn,plan_id into l_fmsisdn,l_planId from GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and content_type=p_type and REQUEST_TIME>=(sysdate-1) and REQUEST_TIME=(select max(REQUEST_TIME) from  GIFT_PENDING_REQUEST where fmsisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type);
	end if;
	select count(*) into l_temp from operator_subscriber where to_number(p_msisdn) >= to_number(STARTS_AT) and to_number(p_msisdn) <= to_number(ENDS_AT);
		p_status:=3;
	if l_temp = 0 then
		p_status:=-22;
 		RETURN;
	end if;
		p_status:=4;
	select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='D';
		p_status:=6;
		p_status:=5;
	if l_temp = 0 then
		p_status:=-8;
	else
		--CheckRbtCode(p_msisdn,p_sys_wallet_id,p_status,p_chgcode);
		CheckWalletCode(p_msisdn,p_sys_wallet_id,p_subType,p_interface,p_type,p_status);
		RETURN ;
	end if;
		--p_status:=6;
	exception
		when others then
			p_status:=(p_status)*(-1);

End CheckForWalletGiftAccept;

Procedure GiftWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_fmsisdn in varchar2,p_validityDays in number,p_chgdone in number,p_refid in varchar2,p_packId in number,p_chgcode in number,p_type in number,p_status out number) is 
	l_temp 		number;
	p_id number;
	l_isSystemRbtBased number;
	l_pre_amount  number;
	l_post_amount  number;
	l_final_amount number;
	l_totalGift number;
	l_freeGift number;
	l_subStatus varchar2(3);
	l_renew_enable number;
	l_count number;
	l_sys_wallet_setting number;
Begin
	l_subStatus:='A';
	l_totalGift:=0;
	l_freeGift:=0;
	l_renew_enable:=-1;
	l_count:=-1;
	l_sys_wallet_setting:=1;
	p_status:=1;
	dbms_output.put_line('p_status-- '||p_status);
	
	select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
        if p_subtype = 'O' then
     		l_final_amount:=l_post_amount;
	else
	     	l_final_amount:=l_pre_amount;
	end if;
	select SCDR_ID.nextval into p_id from dual;
	p_status:=2; 
	insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,remarks,tariff_id,amount,action) values (p_id,p_msisdn,p_int,sysdate,1,'N',p_sys_wallet_id,p_subtype,p_refid,p_fmsisdn,p_chgcode,l_final_amount,'G');
	p_status:=3;
	commit;
	dbms_output.put_line('p_status-- '||p_status || '---MSISDN---'||p_fmsisdn);
										
	select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
     
		
	
	select renew_enable into l_renew_enable from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A';
	p_status:=4;

	
	l_count:=-1;

		select count(*) into l_count from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A';
		p_status:=5;
		if l_count >0 then 
			select setting into l_sys_wallet_setting from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A';
			p_status:=6;
		end if;

dbms_output.put_line('***********************************************1 : '|| l_sys_wallet_setting);
		insert into CRBT_SUBSCRIBER_WALLET_DETAIL(msisdn,wallet_id,create_date,expiry_date,last_charged_date,renew_enable,status,use_case,is_gifted,fmsisdn,setting) values(p_fmsisdn,p_sys_wallet_id,sysdate-30+p_validityDays,sysdate+p_validityDays,sysdate,l_renew_enable,'A',0,1,p_msisdn,l_sys_wallet_setting);

dbms_output.put_line('***********************************************2');
	commit;
	
	if p_packId > 0 then
		select TOTAL_GIFT,FREE_GIFT into l_totalGift,l_freeGift from crbt_pack_master where msisdn=p_msisdn and PACK_ID=p_packId and status='A';
		if l_totalGift > 0 then
			update crbt_pack_master set TOTAL_GIFT=TOTAL_GIFT-1 where msisdn=p_msisdn and PACK_ID=p_packId and status='A';
		elsif l_freeGift > 0 then
			update crbt_pack_master set FREE_GIFT=FREE_GIFT-1 where msisdn=p_msisdn and PACK_ID=p_packId and status='A';
		end if;
		commit;
	end if;
	p_status:=7;
	
	if l_isSystemRbtBased=1 then
		update crbt_subscriber_master set last_charged=sysdate-30+p_validityDays,expiry_date=sysdate+p_validityDays, update_time=sysdate where msisdn=p_fmsisdn and last_charged<=(sysdate-30+p_validityDays);
        	commit;
	end if;
											

	insert into crbt_rbt_gift_log (msisdn,subscriber_type,event_time,interface_type,op_code,friend_msisdn,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,p_int,1,p_fmsisdn,'Y',p_updatedby,p_id); 
	p_status:=8;
	commit;
	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,0,'A Wallet is Gifted to Friend '||p_fmsisdn,p_subtype,p_int,p_updatedby);
	p_status:=9;
	commit;
	select count(*) into l_temp from crbt_app_config_params where param_tag='GIFT_CONFIRM_ENABLE';
	if l_temp = 1 then
		select to_number(param_value) into l_temp from crbt_app_config_params where param_tag='GIFT_CONFIRM_ENABLE';
		if l_temp = 1 then
			select count(*) into l_temp from gift_pending_request where fmsisdn=p_fmsisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
			if l_temp >= 1 then
				 select fmsisdn_sub_status into l_subStatus from  gift_pending_request where fmsisdn=p_fmsisdn and rbt_code=p_sys_wallet_id and content_type=p_type and rownum<2;  
				if l_subStatus = 'D' then
					SetDefaultWallet(p_fmsisdn,p_int,p_updatedby,p_subtype,p_sys_wallet_id,8,2500,2500,3,p_refid,p_chgcode,p_validityDays,p_packId,p_type,p_status,p_id);
				end if;
				p_status:=12;
				delete from gift_pending_request where fmsisdn=p_fmsisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
				commit;
				p_status:=13;
			end if;
		end if;
	end if;
	exception
		when others then
			p_status:=(p_status*(-1));
End GiftWallet;

Procedure SetAdvanceWallet (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_advop in varchar2,p_type in number,p_status out number) is
                                l_temp     number ;
                                l_ctrlid   number;
                                l_catid    varchar2(10);
                                p_id	   number;
				l_priority number;
                                cursor cursor_spl_ctrl_cat_id is select param_value from crbt_app_config_params where param_tag='SPECIAL_CONTROL_CATID';
                                cursor cursor_sel_ctrl_code is select control_id from crbt_rbt_control where cat_id=l_catid and control_name=upper(p_advop);
                                Begin
                                p_status:=1;
				l_priority:=-1;

                                open cursor_spl_ctrl_cat_id ;
                                fetch cursor_spl_ctrl_cat_id into l_catid;
                                if cursor_spl_ctrl_cat_id%NOTFOUND
                                 then
                                     close cursor_spl_ctrl_cat_id;
			             p_status:=-10;
		                     RETURN;
                                else
			             close cursor_spl_ctrl_cat_id;
                                end if;

                                open cursor_sel_ctrl_code ;
	                        fetch cursor_sel_ctrl_code into l_ctrlid;
                                if cursor_sel_ctrl_code%NOTFOUND
	                          then
         	 	              close cursor_sel_ctrl_code;
		                      p_status:=-11;
			              RETURN;
                                else
                                      close cursor_sel_ctrl_code;
                                end if;

if p_sys_wallet_id <= 0 then
        p_status:=-53; ----Invalid system Wallet id
        return;
else
	select priority into l_priority from crbt_system_wallet_master where wallet_id=p_sys_wallet_id;

        if l_priority = 2 then
		update crbt_subscriber_Wallet_detail set setting=l_ctrlid where msisdn=p_msisdn and wallet_id=p_sys_wallet_id;
		commit;
		p_status:=2;

		insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Advance Setting is done for System Wallet '||p_sys_wallet_id,p_subtype,p_int,p_updatedby);
		commit;
		p_status:=3;
	else
                p_status:=-56;----cannot change the setting for priority= 0 or 1
                return;
        end if;
end if;

				exception
                                when others then
                                p_status:=(p_status*(-1));
End SetAdvanceWallet;


Procedure DeleteAdvanceWalletSetting (p_msisdn in varchar2,p_int in varchar2,p_updatedby in varchar2,p_subtype in varchar2,p_sys_wallet_id in number,p_type in number,p_status out number) is
                                l_temp  number ;
                                p_id    number;
				l_priority number;
				l_sys_wallet_setting number;
				l_count number;
                                Begin
                                p_status:=1;
				l_priority:=-1;
				l_sys_wallet_setting:=1;
				l_count:=-1;

if p_sys_wallet_id <=0 then ---checking for valid systemWalletId
	p_status:=-53;
	return;
else
	select priority into l_priority from crbt_system_wallet_master where wallet_id=p_sys_wallet_id;

	if l_priority = 2 then
		 select count(*) into l_count from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A';
	         p_status:=2;
        	 if l_count >0 then
                	 select setting into l_sys_wallet_setting from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A';
	                 p_status:=3;	
		        
			 update crbt_subscriber_wallet_detail set setting=l_sys_wallet_setting where wallet_id=p_sys_wallet_id and msisdn=p_msisdn;
			 commit;
			 p_status:=4;

			 insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'A Advanced Profile For System Wallet '||p_sys_wallet_id||' is Deleted',p_subtype,p_int,p_updatedby);
		         commit;
	    	 	 p_status:=5;

		end if;	
					
	else
		p_status:=-56;----cannot change the setting for priority= 0 or 1
		return;	
	end if;
end if;
                                exception
                                when others then
                                p_status:=(p_status*(-1));
End DeleteAdvanceWalletSetting;


--Added by shambhavi 25-04-2016
Procedure SetSubRenewStatus (p_msisdn in varchar2,p_int in varchar2, p_updatedby in varchar2,p_subtype in varchar2,p_renewstatus in varchar2,p_status out number) is

                                                l_temp    number;
                                                Begin
                                                 p_status:=1;
                select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn;

        if l_temp = 0 then
                p_status:=-30;
                RETURN;
        end if;
	
                        update crbt_subscriber_master set is_monthly_chargeable=p_renewstatus where msisdn=p_msisdn;
                        commit;
                       p_status:=5;

                if p_renewstatus='Y' then

                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'Subscription Renew Enabled',p_subtype,p_int,p_updatedby);
                else
                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'Subscription Renew Disabled',p_subtype,p_int,p_updatedby);
                end if;
               p_status:=1;
              commit;

             exception
             when others then
         p_status:=(p_status*(-1));

        End SetSubRenewStatus;

--End of Added by shambhavi 25-04-2016

End CRBTNEW;			
/
show errors;
quit;

