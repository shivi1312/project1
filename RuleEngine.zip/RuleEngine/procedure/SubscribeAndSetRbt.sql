delimiter //
drop procedure if exists SubscribeAndSetRbt //
create Procedure SubscribeAndSetRbt (IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_rbt  int,IN p_days varchar(20),IN p_sttime  int,IN p_entime  int,IN p_chgdone int,IN p_plan  int, IN p_lang  int, IN p_pin varchar(20),IN p_refid varchar(20),IN p_chgcode  int,OUT p_status  int,OUT p_id int)
ISDONE:begin
declare  l_char varchar (1);
declare  l_length int;
declare  l_temp                 int;
declare  l_wltid int;
declare  l_pre_amount  int;
declare  l_post_amount  int;
declare  l_final_amount int;

declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;

        set   p_status=1;
        set p_id=-1;
	SET l_temp=0;
                select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
            if p_subtype = 'O' then
                            set l_final_amount=l_post_amount;
            else
                            set l_final_amount=l_pre_amount;
            end if;
            set p_status=2;

#        select SCDR_ID.nextval into p_id from dual;
      --   select max(cdr_id+1) from crbt_event_cdr;
 --       insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,tariff_id,amount,action) values (p_id,p_msisdn,p_int,now(),p_plan,'N',p_rbt,p_subtype,p_refid,p_chgcode,l_final_amount,'R');
	insert into crbt_event_cdr (msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,tariff_id,amount,action) values (p_msisdn,p_int,now(),p_plan,'N',p_rbt,p_subtype,p_refid,p_chgcode,l_final_amount,'R');
	set p_id=LAST_INSERT_ID();
        set p_status=2;
      --  commit;
SELECT CONCAT('p_status ',p_status,' p_id ',p_id);
        set p_status=4;
        insert into crbt_subscriber_master (msisdn,status,plan_indicator,rbt_code,password,tpin,language) values (p_msisdn,'A',p_plan,0,p_pin,p_pin,p_lang);
       -- commit;
        set p_status=6;
--        select  (wallet_id+1) into l_wltid from crbt_wallet_master;
	
      --  insert into crbt_wallet_master (msisdn,wallet_id,create_date,wallet_name,ivr_name)      values (p_msisdn,l_wltid,now(),'DEFAULT',0);
	insert into crbt_wallet_master (msisdn,create_date,wallet_name,ivr_name) values (p_msisdn,now(),'DEFAULT',0);
	set l_wltid = LAST_INSERT_ID();
      --  commit;
SELECT CONCAT('p_status ',p_status,' p_id ',p_id);
        set p_status=7;
        insert into crbt_wallet_content (wallet_id,rbt_code,create_date,is_rbt_gifted,msisdn) values (l_wltid,0,now(),0,p_msisdn);
      --  commit;
        set p_status=8;
        insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,8,2500,2500,0,now());
       -- commit;
        set p_status=9;
SELECT CONCAT('p_status ',p_status,' p_id ',p_id);
        insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),'S',p_int,'Y',p_updatedby,p_id);
       -- commit;
        set p_status=10;
        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,'SUBSCRIBED',p_subtype,p_int,p_updatedby);
        set p_status=11;
SELECT CONCAT('p_status ',p_status,' p_id ',p_id);	
--	COMMIT;
        if p_chgdone = 1 then
        #                                                                                        --AddRbtToAlbumName(p_msisdn,p_int,p_updatedby,p_subtype,p_rbt,'DEFAULT',p_chgdone,p_refid,p_chgcode,p_status,l_temp);//needs to change
       		if p_status < 0
        	then
      	 	 set p_status=-1;
      		  LEAVE ISDONE;
		else
			insert into call_id_seq values(null);
     		  SET p_id=LAST_INSERT_ID();
SELECT CONCAT('p_status ',p_status,' p_id ',p_id);	
		end if;
	end if;


       SET l_temp=0;
       if p_days = 8
       then
      	  select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
      	 if l_temp = 0 then
      	  insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_days,p_sttime,p_entime,p_rbt,now());
     --  commit;
      	  SET p_status=13;
      	 else
      	  update crbt_default_detail set rbt_code=p_rbt where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
      	  set p_status=14;
      	-- commit;
SELECT CONCAT('p_status ',p_status,' p_id ',p_id);	
      	 end if;
      else
       set l_length=LENGTH(p_days);
       IF l_length > 0
       THEN
       SET cont = 1;
                  WHILE cont <= l_length do

 
--     set l_char = SUBSTR(p_days,l_index, 1);
 	 set l_char = SUBSTR(p_days,cont, 1);
    	 select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;
     	if l_temp = 0 then
     		insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,l_char,p_sttime,p_entime,p_rbt,now());
  --   commit;
     		set p_status=15;
	else
     		update crbt_default_detail set rbt_code=p_rbt where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;
    -- commit;
    	end if;
      SET cont = cont + 1;
                        END WHILE;

      END IF;
     END IF;

     if p_days = 8 AND p_sttime = 2500 AND p_entime = 2500
     	then
    	 update crbt_subscriber_master set rbt_code=p_rbt where msisdn=p_msisdn;
  	   set p_status=16;
   --  commit;
SELECT CONCAT('p_status ',p_status,' p_id ',p_id);	
     end if;
    	 insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,now(),p_rbt,p_int,1,'DEFAULT','N',p_updatedby,p_id,1);
     set p_status=17;
    -- commit;
    	 insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,'A Default RBT is Set',p_subtype,p_int,p_updatedby);
     set p_status=18;
     commit; 

SELECT CONCAT('p_status ',p_status,' p_id ',p_id);
end //



