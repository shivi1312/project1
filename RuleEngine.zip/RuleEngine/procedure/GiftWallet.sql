DELIMITER //
drop procedure if exists GiftWallet //

CREATE PROCEDURE GiftWallet(IN p_msisdn  varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_sys_wallet_id int,IN p_fmsisdn varchar(20),IN p_validityDays int,IN p_chgdone int,IN p_refid varchar(20),IN p_packId int,IN p_chgcode int,IN p_type int,OUT p_status int)
ISDONE:BEGIN

	DECLARE l_temp int;
        DECLARE p_id int;
        DECLARE l_isSystemRbtBased int;
        DECLARE l_pre_amount  int;
        DECLARE l_post_amount  int;
        DECLARE l_final_amount int;
        DECLARE l_totalGift int;
        DECLARE l_freeGift int;
        DECLARE l_subStatus varchar(3);
        DECLARE l_renew_enable int;
        DECLARE l_count int;
        DECLARE l_sys_wallet_setting int;
	DECLARE v_finished int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

                set p_status=(p_status*(-1));
                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
        SELECT p_status;
END;

START TRANSACTION;
	SET l_subStatus='A';
        SET l_totalGift=0;
        SET l_freeGift=0;
        SET l_renew_enable=-1;
        SET l_count=-1;
        SET l_sys_wallet_setting=1;
        SET p_status=1;
        SELECT CONCAT('p_status-- ',p_status);

        select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
        if p_subtype = 'O' then
                SET l_final_amount=l_post_amount;
        else
                SET l_final_amount:=l_pre_amount;
        end if;
       /* select SCDR_ID.nextval into p_id from dual;
        SET p_status=2;*/
        insert into crbt_event_cdr (msisdn,interface_used,update_time,plan_indicator,status,rbt_code,sub_type,reference_id,remarks,tariff_id,amount,action) values (p_msisdn,p_int,now(),1,'N',p_sys_wallet_id,p_subtype,p_refid,p_fmsisdn,p_chgcode,l_final_amount,'G');
      	SET p_status=3;
--        commit;

	SET p_id=LAST_INSERT_ID();
	SET p_status=2;	


        SELECT CONCAT('p_status-- ',p_status , '---MSISDN---',p_fmsisdn);

        select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
        select renew_enable into l_renew_enable from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A';
        SET p_status=4;

	SET l_count=-1;

                select count(*) into l_count from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A';
                SET p_status=5;
                if l_count >0 then
                        select setting into l_sys_wallet_setting from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A';
                        SET p_status=6;
                end if;

SELECT CONCAT('***********************************************1 : ', l_sys_wallet_setting);
                insert into CRBT_SUBSCRIBER_WALLET_DETAIL(msisdn,wallet_id,create_date,expiry_date,last_charged_date,renew_enable,status,use_case,is_gifted,fmsisdn,setting) values(p_fmsisdn,p_sys_wallet_id, ((now() - interval 30 day)+ interval p_validityDays day), now()+ interval p_validityDays day,now(),l_renew_enable,'A',0,1,p_msisdn,l_sys_wallet_setting);

SELECT CONCAT('***********************************************2');
  --      commit;

        if p_packId > 0 then
                select TOTAL_GIFT,FREE_GIFT into l_totalGift,l_freeGift from crbt_pack_master where msisdn=p_msisdn and PACK_ID=p_packId and status='A';
                if l_totalGift > 0 then
                        update crbt_pack_master set TOTAL_GIFT=TOTAL_GIFT-1 where msisdn=p_msisdn and PACK_ID=p_packId and status='A';
                elseif l_freeGift > 0 then
                        update crbt_pack_master set FREE_GIFT=FREE_GIFT-1 where msisdn=p_msisdn and PACK_ID=p_packId and status='A';
                end if;
#     --          commit;
        end if;
        SET p_status=7;

	if l_isSystemRbtBased=1 then
                update crbt_subscriber_master set last_charged=((NOW()-interval 30 day)+ interval p_validityDays day),expiry_date=NOW()+interval p_validityDays day, update_time=NOW() where msisdn=p_fmsisdn and last_charged<=((NOW()- interval 30 day) + interval p_validityDays day);
  #  --            commit;
        end if;


        insert into crbt_rbt_gift_log (msisdn,subscriber_type,event_time,interface_type,op_code,friend_msisdn,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_int,1,p_fmsisdn,'Y',p_updatedby,p_id);
        SET p_status=8;
 #     --  commit;
        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),0,CONCAT('A Wallet is Gifted to Friend ',p_fmsisdn),p_subtype,p_int,p_updatedby);
        SET p_status=9;
  #    --  commit;
        select count(*) into l_temp from crbt_app_config_params where param_tag='GIFT_CONFIRM_ENABLE';
        if l_temp = 1 then
                select cast(param_value as unsigned integer) into l_temp from crbt_app_config_params where param_tag='GIFT_CONFIRM_ENABLE';
                if l_temp = 1 then
                        select count(*) into l_temp from gift_pending_request where fmsisdn=p_fmsisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
                        if l_temp >= 1 then
                                 select fmsisdn_sub_status into l_subStatus from  gift_pending_request where fmsisdn=p_fmsisdn and rbt_code=p_sys_wallet_id and content_type=p_type limit 0,2;
                                if l_subStatus = 'D' then
                                    CALL SetDefaultWallet(p_fmsisdn,p_int,p_updatedby,p_subtype,p_sys_wallet_id,8,2500,2500,3,p_refid,p_chgcode,p_validityDays,p_packId,p_type,p_status,p_id);
                                end if;
                                SET p_status=12;
                                delete from gift_pending_request where fmsisdn=p_fmsisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
   #     --                        commit;
		 SET p_status=13;
                        end if;
                end if;
        end if;

	select CONCAT('p_status ',p_status, ' p_id ',p_id );
	commit;

END //
DELIMITER ;

