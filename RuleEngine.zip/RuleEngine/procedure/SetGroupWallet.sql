DELIMITER //
drop procedure if exists SetGroupWallet //
create procedure SetGroupWallet (IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_sys_wallet_id int,IN p_days varchar(20),IN p_sttime int,IN p_entime int,IN p_chgdone int,IN p_grpname varchar(20),IN p_refid varchar(20),IN p_chgcode int,IN p_validityDays int,IN p_packId int,IN p_type int,OUT p_status int,OUT p_grpid int)

ISDONE:BEGIN

declare l_temp int;
declare p_id int;
#l_length PLS_INTEGER;
declare l_length int;
declare l_char varchar(1);

declare cont int;
declare v_finished int;
declare sel_grp_id cursor for select groupid from crbt_group_detail where msisdn=p_msisdn and upper(masked_name)=upper(p_grpname);
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING

BEGIN
                GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
		ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=-1;

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';

       END;
 START TRANSACTION;

	set p_status=1;
	set p_id=-1;
        call AddWallet(p_msisdn,p_int,p_updatedby,p_subtype,p_sys_wallet_id,p_chgdone,p_refid,p_chgcode,p_validityDays,p_packId,p_type,p_status,l_temp);
        if p_status < 0
        then
		set p_status=-1;
		LEAVE ISDONE;
        else
		set p_id=l_temp;
        end if;
        open sel_grp_id;
        fetch sel_grp_id into p_grpid;
        if v_finished = 1
        then
                close sel_grp_id;
		set p_status=-13;
		LEAVE ISDONE;
        else
                close sel_grp_id;
        end if;

	set l_temp=0;
        if p_days = 8
        then
                select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and groupid=p_grpid and day=p_days and start_at=p_sttime and ends_at=p_entime;
                if l_temp = 0 then
                        insert into crbt_group_setting (msisdn,groupid,day,start_at,ends_at,rbt_code,update_time,content_type) values (p_msisdn,p_grpid,p_days,p_sttime,p_entime,p_sys_wallet_id,now(),p_type);
--                        commit;
			set p_status=2;
                else
                        update crbt_group_setting set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and groupid=p_grpid and day=p_days and start_at=p_sttime and ends_at=p_entime;
  --                      commit;
                end if;
        else
		set l_length=LENGTH(p_days);
                IF l_length > 0
                THEN
			SET cont = 1;
			WHILE cont <= l_length do
                                set l_char = SUBSTR (p_days,l_index, 1);
                                select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and groupid=p_grpid and day=l_char and start_at=p_sttime and ends_at=p_entime;
                                if l_temp = 0 then
                                select concat('Before insert into crbt_group_setting and l_temo=',l_temp);
                                insert into crbt_group_setting (msisdn,groupid,day,start_at,ends_at,rbt_code,update_time,content_type) values (p_msisdn,p_grpid,l_char,p_sttime,p_entime,p_sys_wallet_id,now(),p_type);
                                select concat('After insert into crbt_group_setting and l_temo=',l_temp);
    --                            commit;
                                set p_status=2;
                                else
                                        update crbt_group_setting set rbt_code=p_sys_wallet_id,content_type=p_type where msisdn=p_msisdn and groupid=p_grpid and day=l_char and start_at=p_sttime and ends_at=p_entime;
                                        commit;
                                end if;
				SET cont = cont + 1;
			END WHILE;
                END IF;
        end if;
        insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,now(),p_sys_wallet_id,p_int,1,p_grpname,'N',p_updatedby,p_id,1);
      --  commit;
        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('A Wallet ',p_sys_wallet_id,' For Group ',p_grpname,' is Set'),p_subtype,p_int,p_updatedby);
        commit;
	SELECT CONCAT('p_status ',p_status);
End //

