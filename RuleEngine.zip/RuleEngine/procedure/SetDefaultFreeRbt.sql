delimiter //
drop procedure if exists SetDefaultFreeRbt //
create Procedure SetDefaultFreeRbt (IN p_msisdn  varchar(20),IN p_int  varchar(20),IN p_updatedby  varchar(20),IN p_subtype  varchar(20),IN p_rbt  int,IN p_days  varchar(20),IN p_sttime int,IN p_entime int ,IN p_validityDays int,OUT p_status int,OUT p_id int) 
isdone:begin
declare   l_char varchar (1);
declare     l_length int;
declare    l_temp   int;
declare l_index int;
declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;


        set    p_status=1;
        set p_id=-1;
        set l_temp=-1;
                select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status in('I','D');
                if l_temp != 0
                then
                        set p_status=-1;
                        LEAVE ISDONE;
                end if;
            call AddAlbum (p_msisdn,p_int ,p_updatedby ,p_subtype ,p_rbt,'DEFAULT',l_temp);
            if l_temp=-1
            then
            set p_status=-1;
            LEAVE ISDONE;
            end if;
            set p_status=2;
            select concat('l_temp ',l_temp);
            insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,expiry_date) values (l_temp,p_rbt,((now() - interval 30 day) + interval p_validityDays day),p_msisdn,now() + interval p_validityDays day);
           -- commit;
            set p_status=3;
            insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_int,p_rbt,l_temp,4,'N',p_updatedby,p_id);
           -- commit;
            set p_status=4;
           insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),0,'Free RBT Added To Album DEFAULT',p_subtype,p_int,p_updatedby);
            set p_status=5;
        --    commit;
            insert into crbt_subscriber_free_rbt(msisdn,create_date,rbt_code,interface) values(p_msisdn,now(),p_rbt,p_int);
          --   commit;
            set p_status=6;
            update crbt_rbt set rbt_score=rbt_score+1 where rbt_code=p_rbt;
            set p_status=7;
           -- commit;
            set l_temp=0;
            update crbt_subscriber_master set last_charged=((now() - interval 30 day)+ interval p_validityDays day), expiry_date=(now()+ interval p_validityDays day), update_time=now() where msisdn=p_msisdn and last_charged<((now()- interval 30 day)+ interval p_validityDays day);
	--  commit;
            set p_status=8;
            if p_days = 8
            then
                select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
                    if l_temp = 0
                    then
                        insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_days,p_sttime,p_entime,p_rbt,now());
                      --  commit;
                        set p_status=9;
                    else
                        update crbt_default_detail set rbt_code=p_rbt where msisdn=p_msisdn and day=p_days and start_at=p_sttime and ends_at=p_entime;
                      --  commit;
                    end if;
            else

                  set l_length=LENGTH(p_days);
                IF l_length > 0
                THEN
                       SET l_index = 1;
                      WHILE l_index <= l_total_number do
           #        FOR l_index IN 1 .. l_length
                       #LOOP 
                       set l_char = SUBSTR(p_days,l_index, 1);
                        select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;
                        if l_temp = 0 then
                         insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,l_char,p_sttime,p_entime,p_rbt,now());
                        --    commit;
                            set p_status=10;
                        else
                            update crbt_default_detail set rbt_code=p_rbt where msisdn=p_msisdn and day=l_char and start_at=p_sttime and ends_at=p_entime;
                          --  commit;
                        end if;
                           SET l_index= l_index+1;
                                                   END WHILE;

                   # END LOOP;
                END IF;
            END IF;

           if p_days = 8 AND p_sttime = 2500 AND p_entime = 2500
           then
            update crbt_subscriber_master set rbt_code=p_rbt where msisdn=p_msisdn;
--            commit;
                set p_status=11;
           end if;
            insert into crbt_rbt_op_log (msisdn,subscriber_type,event_time,rbt_code,interface_type,op_code,op_for,event_charged,updated_by,call_id,op_treatment) values (p_msisdn,p_subtype,now(),p_rbt,p_int,1,'DEFAULT','N',p_updatedby,p_id,1);
  --          commit;
                set p_status=12;
            insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,'A Default RBT is Set',p_subtype,p_int,p_updatedby);
    --          commit;
                set p_status=13;
	SELECT CONCAT('p_status', p_status, ' p_id ',p_id);
end //

