delimiter //
drop procedure if exists p_blacklist_msisdn //
create procedure p_blacklist_msisdn (IN p_msisdn varchar(20),IN p_fmsisdn varchar(20),OUT p_status int)
ISDONE:BEGIN
declare l_temp int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
 END;
 START TRANSACTION;

	set p_status=1;
        select count(*) into l_temp from crbt_subscriber_blacklist where msisdn=p_msisdn and blacklist_number=p_fmsisdn;
        if l_temp > 0 then
                set p_status=4;
        else
                insert into crbt_subscriber_blacklist (msisdn,blacklist_number,create_date) values (p_msisdn,p_fmsisdn,now());
                set p_status=2;
                update crbt_subscriber_master set black_listed=1 where msisdn = p_msisdn;
                set p_status=3;
        end if;
        commit;
	SELECT CONCAT('p_status ',p_status);
END //

