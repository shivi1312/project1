DELIMITER //
DROP PROCEDURE IF EXISTS AddAlbum //
CREATE  Procedure AddAlbum (IN p_msisdn  varchar(20),IN p_int  varchar(20),IN p_updatedby  varchar(20),IN p_subtype  varchar(20),IN p_rbt  int,IN p_wltname  varchar(20),OUT p_id  int)
ISDONE:BEGIN
DECLARE  l_temp          int ;
declare p_status        int;
declare cont int;
declare v_finished int;
declare sel_wlt_id cursor for  select wallet_id from crbt_wallet_master where msisdn=p_msisdn and upper(wallet_name)=upper(p_wltname);
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
 END;
 START TRANSACTION;

                select concat('b4 AddAlbum ',p_msisdn,'-- ',p_int,'--p_wltname',p_wltname);
                set  l_temp=0;
                open sel_wlt_id; 
                fetch sel_wlt_id into p_id;
                if v_finished = 1
                then
                close sel_wlt_id;
                set l_temp=0;
--                select max(wallet_id+1) into p_id from crbt_wallet_master;
                select max(ivr_name) into l_temp from crbt_wallet_master where msisdn=p_msisdn;
                set   l_temp= (l_temp+1);
--                insert into crbt_wallet_master (msisdn,wallet_id,create_date,wallet_name,ivr_name) values (p_msisdn,p_id,now(),upper(p_wltname),l_temp);
                select concat("l_temp ", l_temp);
		insert into crbt_wallet_master (msisdn,create_date,wallet_name,ivr_name) values (p_msisdn,now(),upper(p_wltname),l_temp);
		set p_id=LAST_INSERT_ID();
		select concat("walletId ", p_id);
                -- commit;
                else
                close sel_wlt_id;
                LEAVE ISDONE;
                end if;
                insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_int,p_rbt,p_id,1,'N',p_updatedby,-1);
                -- commit;
                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,concat('A Album ',p_wltname,' is Added'),p_subtype,p_int,p_updatedby);
                commit;
END //

