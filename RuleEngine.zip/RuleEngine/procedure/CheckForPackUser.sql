delimiter //
drop procedure if exists CheckForPackUser//
create Procedure CheckForPackUser(IN p_msisdn varchar(20),IN p_operation  int ,OUT p_packId  int ,OUT  p_setting int ,OUT p_ispackSub int ,OUT p_status int)
isdone:begin
declare v_finished int;
declare         l_temp int;
declare         l_packId int;
declare         l_totalRbt int;
declare         l_freeRbt int;
declare         l_totalGift int;
declare         l_freeGift int;
declare         l_totalRecording int;
declare         l_freeRecording int;
declare         l_setting int;

declare sel_pack_master cursor for  select pack_id,total_rbt,free_rbt,total_gift,free_gift,total_recording,free_recording from crbt_pack_master where pack_expiry_date >= now() and msisdn=p_msisdn order by priority;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, ") ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;


     set l_setting=-1;
     set l_temp=0;
     set l_packId=0;
     set l_totalRbt=0;
     set l_freeRbt=0;
     set l_totalGift=0;
     set l_freeGift=0;
     set l_totalRecording=0;
     set l_freeRecording=0;
     set p_status=-1;
     set p_packId=-1;
     set p_setting=0;
     set  p_ispackSub=0;
        select count(*) into l_temp from crbt_pack_master where msisdn=p_msisdn and (pack_expiry_date >= now() or auto_renew='Y');
        if l_temp = 0 then #---no pack for this user
                select concat('NOTFOUND 11');
                set p_status=1;
                LEAVE ISDONE;
        end if;
                set p_ispackSub=1;
        open sel_pack_master;
        sel_pack_master:LOOP
                fetch sel_pack_master into l_packId,l_totalRbt,l_freeRbt, l_totalGift,l_freeGift, l_totalRecording,l_freeRecording;
                if v_finished = 1 then
                        select concat('NOTFOUND 1');
                        close sel_pack_master;
                        LEAVE sel_pack_master;
                end if;
                select concat('NOTFOUND 13');
                select rbt_setting into l_setting from crbt_pack_detail where pack_id=l_packId;
                select concat('NOTFOUND 14');
                set p_setting=l_setting;
                set p_packId=l_packId;
                if l_totalRbt > 0 or l_totalGift > 0 or l_totalRecording > 0 then
                        select concat('pack id case 1'||p_packId);
                        set p_status=1;
                elseif p_operation = 1  AND (l_freeRbt > 0 or l_freeRbt = -99) then #----RBT PURCHASE
                        select cocat('pack id free case 1'||p_packId);
                        set p_status=0;
                        close sel_pack_master;
                        LEAVE ISDONE;
               elseif p_operation = 2 AND (l_freeGift > 0 or l_freeGift = -99) then #---RBT GIFT
                        select concat('pack id free case 2',p_packId);
                        set p_status=0;
                        close sel_pack_master;
                        LEAVE ISDONE;
                elseif p_operation = 3 AND (l_freeRecording > 0 or l_freeRecording = -99) then #-- RBT RECORDING
                        select concat('pack id free case 3',p_packId);
                        set p_status=0;
                        close sel_pack_master;
                        LEAVE ISDONE;
                end if;
        END LOOP sel_pack_master;
        open sel_pack_master;
        sel_pack_master:LOOP
                fetch sel_pack_master into l_packId,l_totalRbt,l_freeRbt, l_totalGift,l_freeGift, l_totalRecording,l_freeRecording;
                if v_finished = 1  then
                        select concat('NOTFOUND 2');
                        close sel_pack_master;
                        set p_packId=-1;
                        set p_status=1;
                        set p_setting=0;
                        LEAVE ISDONE;
                end if;
                select rbt_setting into l_setting from crbt_pack_detail where pack_id=l_packId;
                set p_setting=l_setting;
                set p_packId=l_packId;
                if l_totalRbt > 0 AND p_operation = 1 then
                        select concat('pack id charged case 1',p_packId);
                        set p_status=1;
                         close sel_pack_master;
                        LEAVE ISDONE;
                elseif p_operation = 2 AND l_totalGift > 0 then #----RBT PURCHASE
                        select concat('pack id charged case 2',p_packId);
                        set p_status=1;
                        close sel_pack_master;
                        LEAVE ISDONE;
                elseif p_operation = 3 AND l_totalRecording > 0 then #---RBT GIFT
                        select concat('pack id charged case 3',p_packId);
                        set p_status=1;
                        close sel_pack_master;
                        LEAVE ISDONE;
                else #-- INVALID CASE
                        select concat('INVALID CASE');
                        set p_packId=-1;
                        set p_status=1;
                        set p_setting=0;
                end if;
        END LOOP sel_pack_master;
	SELECT CONCAT('p_status',p_status);
	end //
