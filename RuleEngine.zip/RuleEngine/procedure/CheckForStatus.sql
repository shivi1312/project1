delimiter //
drop procedure if exists CheckForStatus //
create procedure  CheckForStatus(IN p_msisdn  varchar(20), OUT p_status  int) 
isdone:begin

declare l_temp          int ;


declare  l_id int;
declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=-1;

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;

        set  p_status=-2;
        set l_temp=0;
        select count(msisdn) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status = 'I';
        if l_temp!=0
        then
                set p_status=1;
                LEAVE ISDONE;
        end if;
end //
