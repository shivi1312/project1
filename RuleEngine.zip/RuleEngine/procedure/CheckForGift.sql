DELIMITER //
drop procedure if exists CheckForGift //
create procedure CheckForGift ( IN p_msisdn  varchar(20),IN p_rbt  int,OUT p_status  int, OUT p_chgcode  int)
ISDONE:BEGIN
declare l_temp          int;
declare l_catid int;
declare l_cpid int;
declare cont int;
declare v_finished int;
DECLARE done INT DEFAULT FALSE;



DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING

BEGIN
#               DECLARE EXIT HANDLER FOR SQLEXCEPTION
                GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
	--	ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=-1;

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';

       END;
 START TRANSACTION;
       set p_status=0;

        select count(*) into l_temp from operator_subscriber where  cast(p_msisdn AS UNSIGNED) >=  cast(STARTS_AT AS UNSIGNED)  and cast(p_msisdn AS UNSIGNED) <=  cast(ENDS_AT AS UNSIGNED) ;
        if l_temp = 0 then
                set p_status=-22;
                set p_chgcode=-1;
                LEAVE ISDONE;
        end if;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='D';
        if l_temp = 0 then
                set p_status=-8;
                set p_chgcode=-1;
        else
                call CheckRbtCode(p_msisdn,p_rbt,p_status,p_chgcode,l_catid,l_cpid);
                LEAVE ISDONE;
        end if;
End //




