DELIMITER //
drop procedure if exists DeleteWallet //

CREATE PROCEDURE DeleteWallet(IN p_msisdn  varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_sys_wallet_id int,IN p_type int,OUT p_status int,OUT p_updatecode int,OUT p_filePath varchar(20))
ISDONE:BEGIN

DECLARE l_temp  int ;
DECLARE l_cnt   int ;

DECLARE v_finished int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

                set p_status=(p_status*(-1));
                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
        # SELECT p_status;
END;

START TRANSACTION;
SET p_status=-1;
SET l_temp=0;
SET l_cnt=0;
SET p_updatecode=0;

         select count(*) into l_cnt from CRBT_SUBSCRIBER_WALLET_DETAIL  where msisdn=p_msisdn and wallet_id=p_sys_wallet_id;                                                                                          
         if l_cnt = 0 then
         	 SET p_status=-17;
         	 LEAVE ISDONE;
          end if;
		
		SET l_cnt=0;

		 select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
		 SET p_status=2;
	if l_temp = 0
         then
          	SET p_updatecode=0;       /* -- no need to update default setting */
         else
            select count(*) into l_cnt from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and day=8 and start_at=2500 and ends_at=2500 and content_type=p_type;
         SET p_status=3;
		if l_cnt = 0
        	 then
         	 SET p_updatecode=1; /*-- default setting will not be effected but default string needs to be updated */
       		else
          		update crbt_default_detail set rbt_code=0 ,content_type=0 where msisdn=p_msisdn and day=8 and start_at=2500 and ends_at=2500 and content_type=p_type;
         	--  commit;
         	  SET p_status=4;

         	 update crbt_subscriber_master set rbt_code=0 where msisdn=p_msisdn;
	--	 commit;
	           SET p_status=5;


    /* if user has more than one settings for this string only then string will be updated */

          		if l_temp > 1
		        then  
			    SET p_updatecode=1;
			end if;
                end if;
	 end if;
		SET l_temp=0;
		select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
		 SET p_status=6;
		 if l_temp > 0
		  then
			SET p_updatecode=(p_updatecode + 2);
		 end if;
		 SET l_temp=0;
  			 select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
                	 SET p_status=7;
		 if l_temp > 0
		 then
                  SET p_updatecode=(p_updatecode + 4);
                 end if;


	SET l_temp=-1;
	select count(*) into l_temp from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
		SET p_status=8;
	if l_temp > 0 then
        	delete from crbt_default_detail where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
        --	commit;
		SET p_status=9;
	end if;

	SET l_temp=-1;
	select count(*) into l_temp from crbt_group_setting where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
		SET p_status=10;
	if l_temp > 0 then
        	delete from crbt_group_setting where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
       	--	 commit;
       		SET  p_status=11;
	end if;

	SET l_temp=-1;
	select count(*) into l_temp from crbt_friend_setting where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
		SET p_status=12;
	if l_temp > 0 then
        	delete from crbt_friend_setting where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
       	 --	commit;
        	SET p_status=13;
	end if;


	SET l_temp=-1;
		select count(*) into l_temp from crbt_eventdate_rbt where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
		SET p_status=14;
	if l_temp > 0 then
        	delete from crbt_eventdate_rbt where msisdn=p_msisdn and rbt_code=p_sys_wallet_id and content_type=p_type;
        --	commit;
        	SET p_status=15;
	end if;


		 delete from crbt_subscriber_wallet_detail where msisdn=p_msisdn and wallet_id=p_sys_wallet_id;
	--	 commit;
		 SET p_status=16;

		 insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,NOW(),p_int,p_sys_wallet_id,l_temp,5,'N',p_updatedby,-1);
	--	 commit;
		 SET p_status=17;

		 insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,CONCAT('A Wallet ',p_sys_wallet_id, 'is Deleted'),p_subtype,p_int,p_updatedby);
	--	 commit;
		 SET p_status=19;
		COMMIT;

		SELECT CONCAT('p_status ',p_status);
		

END //
DELIMITER ;

