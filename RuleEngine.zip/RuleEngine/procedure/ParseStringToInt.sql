delimiter //
drop procedure if exists ParseStringToInt //
create Procedure ParseStringToInt(in p_stringToBeParse varchar(50), in p_stringFromParse varchar(50),out p_result  int)
isdone:begin
declare l_temp int;
declare l_temp1 int;

declare cont int;
declare p_status int;
declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
-- DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 DECLARE EXIT HANDLER FOR SQLEXCEPTION
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
       END;
 START TRANSACTION;

       set l_temp=0;
       set  l_temp1=0;
       set  p_result=1;
	select concat("We are here 1",p_stringFromParse," and tobe ",p_stringToBeParse);
       set l_temp=locate(p_stringFromParse,p_stringToBeParse,1);
	select concat("We are here 2",l_temp);
        select concat("l_temp[",l_temp,"] in ParseString");
       set  p_result=2;
       set  l_temp1=locate(',',p_stringToBeParse,l_temp);
#        --if l_temp1 = 0 then
#        --      l_temp1:=length(p_stringToBeParse);
#        --end if;
        select concat('l_temp1[',l_temp1,'] in ParseString');
        set p_result=3;
        #set p_result=cast(SUBSTRING(p_stringFromParse,l_temp+length(p_stringToBeParse),l_temp1-(length(p_stringFromParse)+l_temp))as UNSIGNED);

	select p_result;
        set p_result=CAST((substring(p_stringToBeParse,l_temp+length(p_stringFromParse),l_temp1-(length(p_stringFromParse)+l_temp))) AS UNSIGNED);
 
End //
