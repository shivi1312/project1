DELIMITER //
drop procedure if exists ActivatePromo //

CREATE PROCEDURE ActivatePromo(IN p_msisdn varchar(20), IN p_plan int,IN p_lang int,IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20), IN p_promoid int ,IN p_totalRbt  int, IN p_freeRbt int,IN p_totalGift int, IN p_freeGift int, IN p_totalRecording int , IN p_freeRecording int , IN p_priority int ,IN p_countryCode  varchar(20), OUT p_status int )
ISDONE:BEGIN

DECLARE l_rbt varchar(200);
DECLARE l_giftRbt varchar(200);
DECLARE l_recRbt varchar(200);
DECLARE l_totalRbt int(10);
DECLARE l_freeRbt int;
DECLARE l_totalGift int;
DECLARE l_freeGift int;
DECLARE l_totalRecording int;
DECLARE l_freeRecording int;
DECLARE l_packValidity int;
DECLARE l_priority int;
DECLARE l_temp int;
DECLARE l_setting int;
DECLARE l_pre_amount  int;
DECLARE l_post_amount  int;
DECLARE l_final_amount int; 
DECLARE l_expiry_date date;
DECLARE v_finished int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;
		
		delete from crbt_promo_user_detail where msisdn=p_msisdn and promo_id=p_promoid;
                commit;
	
	         set p_status=(p_status*(-1));
        	 
		SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
        # SELECT p_status;
END;

START TRANSACTION;

	set p_status=1;
       set l_temp=-1;
       set l_priority=-1;
       set l_setting=-1;
	
	  /* !Check for promo already activated */

        select count(*) into l_temp  from crbt_promo_user_detail where promo_id=p_promoid and msisdn=p_msisdn and status='A' and country_code=p_countryCode;
        if(l_temp>0) then
        set p_status=-209;
        LEAVE ISDONE;
        end if;
        /* !find expiry date of promo */
        select count(*) into l_temp  from  crbt_promo_list_master where promo_id=p_promoid and now() between start_date and end_date and status='A' and country_code=p_countryCode;
            set p_status=2;
        if l_temp>0 then
                 select end_date into l_expiry_date  from crbt_promo_list_master where promo_id=p_promoid and now() between start_date and end_date and status='A' and country_code=p_countryCode;
                set  p_status=3;
        /* !find user based promo */
                 select count(*) into l_temp from crbt_promo_user_detail where msisdn=p_msisdn and promo_id=p_promoid and pack_expiry_date>=now() and country_code=p_countryCode;
                if l_temp>0 then
                set p_status=4;
                update crbt_promo_user_detail set status='A' where msisdn=p_msisdn and promo_id=p_promoid;
                -- commit;
                else
        /*insert into crbt_promo_user_detail*/

		set p_status=5;
                insert into crbt_promo_user_detail(msisdn,promo_id,total_rbt,free_rbt,total_gift,free_gift,total_recording,free_recording,update_time,promo_sub_time,pack_expiry_date,priority,status,country_code)  values(p_msisdn,p_promoid,p_totalRbt,p_freeRbt,p_totalGift,p_freeGift,p_totalRecording,p_freeRecording,now(),now(),l_expiry_date,p_priority,'A',p_countryCode);
                -- commit;
                end if;
        else
                set p_status:=6;
                LEAVE ISDONE;
        end if;
       /* ----insert into crbt_activity_detail_log table */
         set p_status=7;
     insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),0,CONCAT('Promo is activated ',p_promoid),p_subtype,p_int,p_updatedby);
        commit;
	SELECT (p_status);
--        LEAVE ISDONE;

END //
DELIMITER ;

