delimiter //
drop procedure if exists PackSubscribe //
create Procedure PackSubscribe (in p_msisdn varchar(20),in p_plan  int, in p_lang int, in p_int varchar(20),in p_updatedby varchar(20),in p_subtype varchar(20),in p_pin varchar(20),in p_packid  int,in p_refid varchar(20),in p_chgcode  int,OUT p_status  int,OUT p_id  int)
ISDONE:begin
declare l_rbt varchar(200);
declare l_giftRbt varchar(200);
declare l_recRbt varchar(200);
declare l_totalRbt int;
declare l_freeRbt int;
declare l_totalGift int;
declare l_freeGift int;
declare l_totalRecording int;
declare l_freeRecording int;
declare l_packValidity int;
declare l_priority int;
declare l_temp int;
declare l_setting int;
declare l_pre_amount  int;
declare l_post_amount  int;
declare l_final_amount int;
DECLARE v_finished int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

		delete from crbt_pack_master where msisdn=p_msisdn and pack_id=p_packid;
              --  commit;
                delete from crbt_pack_purchase_log where msisdn=p_msisdn and pack_id=p_packid;
                commit;
                set p_status=(p_status*(-1));

              
                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
        # SELECT p_status;
END;
START TRANSACTION;
        set p_status=1;
        set p_id=-1;
        set l_temp=-1;
        set l_priority=-1;
        set l_setting=-1;
                 select rbt, gift_rbt, recording_rbt,offer_validity,priority into l_rbt, l_giftRbt, l_recRbt,l_packValidity,l_priority from crbt_pack_detail where pack_id=p_packid and status='A';
            if p_subtype = 'O' then
                            set l_final_amount=l_post_amount;
            else
                            set l_final_amount=l_pre_amount;
            end if;
            set p_status=2;

               -- select max(cdr_id+1) into p_id from crbt_event_cdr;
               -- insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount,pack_id) values (p_id,p_msisdn,p_int,now(),'P',p_plan,'N',p_subtype,p_refid,p_chgcode,l_final_amount,p_packid);
      		insert into crbt_event_cdr (msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount,pack_id) values (p_msisdn,p_int,now(),'P',p_plan,'N',p_subtype,p_refid,p_chgcode,l_final_amount,p_packid);           
		set p_id=LAST_INSERT_ID();		
                 set p_status=3;
                 commit;

        select rbt, gift_rbt, recording_rbt,offer_validity,rbt_setting into l_rbt, l_giftRbt, l_recRbt,l_packValidity,l_setting from crbt_pack_detail where pack_id=p_packid and status='A';
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status!='D';
        if l_temp != 0 then
                select count(*) into l_temp from crbt_subscriber_master where status='A' and msisdn=p_msisdn;
                if l_temp = 0 then
 #                       --return error
                        set p_status=-12;
                        LEAVE ISDONE;
                end if;
        else
                call Subscribe(p_msisdn,p_plan,p_lang,p_int,p_updatedby,p_subtype,p_pin,p_refid,p_chgcode,l_packValidity,1,p_status,p_id);
                if p_status < 0 then
#                        --return error
                        LEAVE ISDONE;
                end if;
        end if;



        call ParseStringToInt(l_rbt,'NOR:',l_totalRbt);
       call  ParseStringToInt(l_rbt,'NOFR:',l_freeRbt);

       call  ParseStringToInt(l_giftRbt,'NOR:',l_totalGift);
       call  ParseStringToInt(l_giftRbt,'NOFR:',l_freeGift);


        call ParseStringToInt(l_recRbt,'NOR:',l_totalRecording);
        call ParseStringToInt(l_recRbt,'NOFR:',l_freeRecording);
        update crbt_subscriber_master set last_charged=((now()- interval 30 day) + interval l_packValidity day),expiry_date=(now()+ interval l_packValidity day), update_time=now() where msisdn=p_msisdn and last_charged<=((now()- interval 30 day) + interval l_packValidity day);
        -- commit;
        set p_status=12;
        select concat('--',p_msisdn,'--',p_packid,'--',l_totalRbt,'--',l_freeRbt,'--',l_totalGift,'--',l_totalGift,'--',l_totalRecording,'--',l_freeRecording,'--',l_packValidity,'--',l_priority);
        insert into crbt_pack_master (msisdn,pack_id,total_rbt,free_rbt,total_gift,free_gift,total_recording,free_recording,update_time,pack_sub_time,pack_expiry_date,priority) values(p_msisdn,p_packid,l_totalRbt,l_freeRbt,l_totalGift,l_freeGift,l_totalRecording,l_freeRecording,now(),now(),now()+ interval l_packValidity day,l_priority);
        set p_status=13;
        -- commit;
#        -------added by kapil for busy rbt--------------------
        #-------Pack type 1 means this is a busy rbt pack;
       -- select nvl(pack_type,0) into l_temp from crbt_pack_detail where pack_id=p_packid;
	select IFNULL(pack_type,0) into l_temp from crbt_pack_detail where pack_id=p_packid;
        set p_status=14;
        if l_temp=1 then
                update crbt_subscriber_master set active_features = 1 where msisdn=p_msisdn;
                -- commit;
        set p_status=15;
                insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),0,'Busy RBT Pack activated ',p_packid,p_subtype,p_int,p_updatedby);
                -- commit;
        set p_status=16;
        end if;
       # -------added by kapil for busy rbt--------------------

        insert into crbt_pack_purchase_log (msisdn,pack_id,interface,create_date,updated_by,sub_type,action) values(p_msisdn,p_packid,p_int,now(),p_updatedby,p_subtype,'S');
        set p_status=17;
        if l_setting = 2 then #-------seq setting
               call  SetAdvanceRbt(p_msisdn,p_int,p_updatedby,p_subtype,'SEQ','DEFAULT',1,p_status);
        elseif l_setting = 3 then #-----RANDOM setting
              call   SetAdvanceRbt(p_msisdn,p_int,p_updatedby,p_subtype,'RANDOM','DEFAULT',1,p_status);
        elseif l_setting = 4 then #------TOPMOST setting
        call SetAdvanceRbt(p_msisdn,p_int,p_updatedby,p_subtype,'TOPMOST','DEFAULT',1,p_status);
        end if;
        set p_status=18;

        commit;
	SELECT CONCAT('p_status ', p_status);
end //
