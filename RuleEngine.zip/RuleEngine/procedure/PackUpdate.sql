delimiter //
drop procedure if exists PackUpdate //
create Procedure PackUpdate(In p_msisdn  varchar(200),In p_packid  int,IN p_int  varchar(200),In p_updatedby  varchar(200),IN p_subtype  varchar(200),OUT p_status  int)
ISDONE:begin
declare cont int;
declare l_rbt varchar(200);
declare l_giftRbt varchar(200);
declare l_recRbt varchar(200);
declare l_totalRbt int;
declare l_freeRbt int;
declare l_totalGift int;
declare l_freeGift int;
declare l_totalRecording int;
declare l_freeRecording int;
declare l_packValidity int;
declare l_priority int;
declare l_temp int;
declare l_setting int;
declare p_id int;
declare l_pre_amount  int;
declare l_post_amount  int;
declare l_final_amount int;
declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, ") ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;
                 delete from crbt_pack_master where msisdn=p_msisdn and pack_id=p_packid;
--                commit;
                delete from crbt_pack_purchase_log where msisdn=p_msisdn and pack_id=p_packid;
                commit;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;
        set p_status=1;
        set p_id=-1;
        set l_temp=-1;
        set l_priority=-1;
        set l_setting=-1;
        select rbt, gift_rbt, recording_rbt,offer_validity,priority into l_rbt, l_giftRbt, l_recRbt,l_packValidity,l_priority from crbt_pack_detail where pack_id=p_packid and status='A';
        select CAST(param_value AS UNSIGNED) into l_temp from crbt_app_config_params where param_tag='FREE_CHARGE_CODE';
        select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=l_temp;
        if p_subtype = 'O' then
                set l_final_amount=l_post_amount;
        else
                set l_final_amount=l_pre_amount;
        end if;
        set p_status=2;

--        select max(cdr_id+1)  into p_id from crbt_event_cdr;
  --      insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount,pack_id) values (p_id,p_msisdn,p_int,now(),'P',1,'N',p_subtype,'NA',l_temp,l_final_amount,p_packid);
	insert into crbt_event_cdr (msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount,pack_id) values (p_msisdn,p_int,now(),'P',1,'N',p_subtype,'NA',l_temp,l_final_amount,p_packid);    

	SET p_id=LAST_INSERT_ID();
    set p_status=3;
      --  commit;

        select rbt, gift_rbt, recording_rbt,offer_validity,rbt_setting into l_rbt, l_giftRbt, l_recRbt,l_packValidity,l_setting from crbt_pack_detail where pack_id=p_packid and status='A';

        call ParseStringToInt(l_rbt,'NOR',l_totalRbt);
        call ParseStringToInt(l_rbt,'NOFR',l_freeRbt);

        call ParseStringToInt(l_giftRbt,'NOR',l_totalGift);
        call ParseStringToInt(l_giftRbt,'NOFR',l_freeGift);

        call ParseStringToInt(l_recRbt,'NOR',l_totalRecording);
        call ParseStringToInt(l_recRbt,'NOFR',l_freeRecording);
        update crbt_subscriber_master set last_charged=((now() - interval 30 day) + interval l_packValidity day),expiry_date=now()+ interval l_packValidity day, update_time=now() where msisdn=p_msisdn and last_charged<=((now() - interval 30 day) + interval l_packValidity day);
      --  commit;
        set  p_status=12;
        update crbt_pack_master set total_rbt=l_totalRbt, free_rbt=l_freeRbt, total_gift=l_totalGift, free_gift=l_freeGift, total_recording=l_totalRecording, free_recording=l_freeRecording ,update_time=now(), pack_expiry_date=now()+ interval l_packValidity day where msisdn=p_msisdn and pack_id=p_packid;
        set p_status=13;
     --   commit;
        insert into crbt_pack_purchase_log (msisdn,pack_id,interface,create_date,updated_by,sub_type,action) values(p_msisdn,p_packid,p_int,now(),p_updatedby,p_subtype,'S');
        set p_status=14;

        commit;
	SELECT CONCAT('p_status ',p_status);
End //
