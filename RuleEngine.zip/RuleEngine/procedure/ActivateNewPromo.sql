DELIMITER //
drop procedure if exists ActivateNewPromo //
create Procedure ActivateNewPromo(IN p_msisdn varchar(20),IN p_promoid int,IN p_subType varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_countryCode varchar(20),OUT p_status int)
ISDONE:BEGIN
DECLARE l_temp int;
declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;

        set p_status=1;
        set l_temp=-1;
        select count(*) into l_temp from crbt_promo_user_detail where msisdn=p_msisdn and promo_id=p_promoid and pack_expiry_date>=now() and status='N' and country_code=p_countryCode;
        if l_temp>0 then
                 set p_status=2;
                 update crbt_promo_user_detail set status='A' where msisdn=p_msisdn and promo_id=p_promoid;
                 -- commit;
---- insert into crbt_activity_detail_log table
                 set p_status=3;
                 insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),0,concat('New Promo is activated/Updated ',p_promoid),p_subtype,p_int,p_updatedby);
               --  commit;
	SELECT CONCAT(p_status);
                LEAVE ISDONE;
        else
                 set p_status=0;
	SELECT CONCAT(p_status);
                 LEAVE ISDONE;
        end if;
	commit;
	SELECT CONCAT(p_status);
End //
