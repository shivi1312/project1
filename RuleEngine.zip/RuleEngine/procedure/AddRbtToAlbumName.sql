DELIMITER //
drop procedure if exists AddRbtToAlbumName //
create procedure  AddRbtToAlbumName ( IN p_msisdn  varchar(20),IN p_int  varchar(20), IN p_updatedby  varchar(20),IN p_subtype  varchar(20),IN p_rbt  int,IN p_wltname  varchar(20),IN p_chgdone  int,IN p_refid  varchar(20),IN p_chgcode  int,IN p_validityDays  int,IN p_packId  int,OUT p_status  int,OUT p_id  int)
ISDONE:BEGIN

declare l_temp          int ;
declare l_totalRbt int;
declare l_freeRbt int;
declare l_isSystemRbtBased int;

declare cont int;
declare v_finished int;
DECLARE done INT DEFAULT FALSE;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING

BEGIN
#               DECLARE EXIT HANDLER FOR SQLEXCEPTION
                GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
		ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;
               set p_id=-1;
               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';

       END;
 START TRANSACTION;


        set   l_temp=0;
        set l_totalRbt=0;
        set l_freeRbt=0;
        if p_chgdone = 2
        then
                call AddFreeRbtToAlbName( p_msisdn,p_int,p_updatedby,p_subtype,p_rbt,p_wltname,p_status,p_id) ;-- special for Haiti implementation.
		select concat("p_status after AddFreeRbtToAlbName ",p_status);

                set p_status=1;
                set p_id=-1;
                LEAVE ISDONE;
        elseif p_chgdone != 1
        then
                set p_status=1;
                set p_id=-1;
                LEAVE ISDONE;
        end if;
        set p_status=1;
        set l_temp= 0;
        call GenerateRBTSettingCDR(p_msisdn,p_int,p_subtype,1,p_rbt,p_refid,p_chgcode,p_id);

        if p_id=-1
        then
                set p_status=-18;
                LEAVE ISDONE;
              end if;

        select concat('b4 AddAlbum ');

        call AddAlbum (p_msisdn,p_int ,p_updatedby ,p_subtype ,p_rbt,p_wltname,l_temp);
        if l_temp=-1
        then
                set p_status=-1;
                LEAVE ISDONE;
        end if;
        set p_status=2;
        select concat('after AddAlbum wallet_id',l_temp);
        select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';
        if l_isSystemRbtBased=1 then
                insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,expiry_date) values (l_temp,p_rbt,((now()- interval 30 day)+INTERVAL p_validityDays DAY),p_msisdn,now()+ INTERVAL p_validityDays DAY);
        else
                insert into crbt_wallet_content (wallet_id,rbt_code,create_Date,msisdn,expiry_date) values (l_temp,p_rbt,now(),p_msisdn,now()+ INTERVAL p_validityDays DAY);
        end if;
        -- commit;
        select concat ('after AddAlbum wallet_id',l_temp);
        set p_status=3;
        if p_packId > 0 then
                select TOTAL_RBT,FREE_RBT into l_totalRbt,l_freeRbt from crbt_promo_user_detail where MSISDN=p_msisdn and PROMO_ID=p_packId and status='A';
                if l_totalRbt > 0 then
                        update crbt_promo_user_detail set TOTAL_RBT=TOTAL_RBT-1 where MSISDN=p_msisdn and PROMO_ID=p_packId;
                elseif l_freeRbt > 0 then
                        update crbt_promo_user_detail  set FREE_RBT=FREE_RBT-1 where MSISDN=p_msisdn and PROMO_ID=p_packId;
                end if;
                -- commit;
        end if;
        set p_status=4;
        if l_isSystemRbtBased=1 then
                update crbt_subscriber_master set last_charged=((now()- interval 30 day) + INTERVAL p_validityDays DAY), expiry_date=(now()+ INTERVAL p_validityDays DAY), update_time=now() where msisdn=p_msisdn and last_charged<=((now()-interval 30 day)+INTERVAL p_validityDays DAY);
                -- commit;
        end if;
        set p_status=5;
        insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_int,p_rbt,l_temp,4,'Y',p_updatedby,p_id);
        -- commit;
        set p_status=6;
        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),0,concat(p_rbt,'RBT Added To Album ',p_wltname),p_subtype,p_int,p_updatedby);
        set p_status=7;
        -- commit;
        update crbt_rbt set rbt_score=rbt_score+1 where rbt_code=p_rbt;
        set p_status=6;
         commit;
END //

            
