DELIMITER //
drop procedure if exists CheckForCorpSubscription //

CREATE PROCEDURE CheckForCorpSubscription(IN p_msisdn varchar(20) ,  IN p_maxsub int , IN p_plan int , IN p_corpid int , IN p_maxsubcorp int , OUT p_status int)
ISDONE:BEGIN

DECLARE l_temp int;
DECLARE l_totsub int;
DECLARE v_finished int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
#               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;
		
		set p_status=-1;
		SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
	# SELECT p_status;
END;

START TRANSACTION;

	set p_status = 1;
        set l_temp = 0;
        set l_totsub = 0;

	 select concat('p_status-- ',p_status);

	if p_maxsubcorp!=-99 then
                select count(msisdn) into l_totsub from crbt_subscriber_master where corp_id = p_corpid;
                if l_totsub >=p_maxsubcorp then
                       set p_status=-26;
                        LEAVE ISDONE;
                end if;
        end if;

	 select cast(param_value as unsigned integer) into l_temp from crbt_app_config_params where param_tag='WHITELIST_ENABLE';
        if l_temp = 1 then
               -- select count(*) into l_temp from crbt_whitelist where to_number(STARTS_AT) <=to_number(p_msisdn) and to_number(ENDS_AT) >=to_number(p_msisdn);
		select count(*) into l_temp from crbt_whitelist where (STARTS_AT) <= cast(p_msisdn  as unsigned integer) and (ENDS_AT) >=cast(p_msisdn  as unsigned integer);
                if l_temp = 0 then
                        set p_status=-25;
                        LEAVE ISDONE;
                end if;
        end if;

	select count(msisdn) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status != 'D';
        if l_temp!=0
        then
                select plan_indicator into l_temp from  crbt_subscriber_master where msisdn=p_msisdn ;

                if l_temp != p_plan  and p_plan!=-1 then
                       set p_status=-33;                  -- person is already subscribe with different plan
                else
                set p_status=-20;
                end if;
               	LEAVE ISDONE;
        end if;
        set l_temp=0;
        select count(msisdn) into l_temp from crbt_subscriber_master where status='A';
        if l_temp > p_maxsub
        then
              set  p_status=-21;
                LEAVE ISDONE;
        end if;

       set l_temp=0;

--	select count(range_id) into l_temp from OPERATOR_SUBSCRIBER where (to_number(STARTS_AT) <=to_number(p_msisdn) and to_number(ENDS_AT) >=to_number(p_msisdn) and p_msisdn not in (select EXCLUDE_NUM from OPERATOR_SUBSCRIBER_EXCLUDE)) or p_msisdn in ( select INCLUDE_NUM from OPERATOR_SUBSCRIBER_INCLUDE);

	select count(range_id) into l_temp from OPERATOR_SUBSCRIBER where( (STARTS_AT) <=cast(p_msisdn as unsigned integer) and (ENDS_AT) >=cast(p_msisdn as unsigned integer) and p_msisdn not in (select EXCLUDE_NUM from OPERATOR_SUBSCRIBER_EXCLUDE)) or p_msisdn in ( select INCLUDE_NUM from OPERATOR_SUBSCRIBER_INCLUDE);
        SELECT CONCAT('in procedure subscriber msisdn===' , p_msisdn);
        SELECT CONCAT('in procedure subscriber l_temp===', l_temp);

        if l_temp=0
        then
                SET p_status=-22;
                LEAVE ISDONE;
        end if;

	SELECT CONCAT('p_status');

END //

