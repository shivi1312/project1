delimiter //
drop procedure if exists PendingGiftAccept //
create Procedure PendingGiftAccept(In p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_rbtCode  int , In p_fmsisdn varchar(20), IN p_planId  int ,OUT p_status  int,OUT p_id  int) 
isdone:begin
declare l_temp int;
declare l_subStatus varchar(3);

declare cont int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, ") ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;


        set    p_status=1;
        set p_id=1;
        set l_temp=1;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_fmsisdn;
        if l_temp = 0 then
                set l_subStatus='D';
        else
                select status into l_subStatus from crbt_subscriber_master where msisdn=p_fmsisdn;
        end if;
        set p_status=2;
        insert into GIFT_PENDING_REQUEST(MSISDN,FMSISDN,rbt_code,REQUEST_TIME,FMSISDN_SUB_STATUS,interface,updated_by,plan_id,sub_type) values(p_msisdn,p_fmsisdn,p_rbtCode,now(),l_subStatus,p_int,p_updatedby,p_planId,p_subType);
        commit;
        set p_status=3;
	SELECT CONCAT('p_status ',p_status,' p_id ',p_id);
end //
