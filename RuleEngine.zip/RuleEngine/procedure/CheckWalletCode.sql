DELIMITER //
drop procedure if exists CheckWalletCode //

CREATE PROCEDURE CheckWalletCode(IN p_msisdn varchar(20),IN p_sys_wallet_id int,IN p_subType varchar(20),IN p_interface varchar(20),IN p_type int,OUT p_status int)
ISDONE:BEGIN

	DECLARE l_count int;
        DECLARE l_scope varchar(100);
        DECLARE l_subType varchar(2);
	DECLARE v_finished int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

                set p_status=-1;
                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
        # SELECT p_status;
END;

START TRANSACTION;

	SET p_status=-1;
        SET l_count=-1;
        SET l_scope='NA';
        SET l_subType='N';
                SELECT CONCAT('Before select crbt_subscriber_wallet_detail1');
                select count(*) into l_count from crbt_subscriber_wallet_detail where wallet_id=p_sys_wallet_id and msisdn=p_msisdn and status='A';
                if l_count > 0 then
                        SET p_status:=-50; /* --Already purchased active user*/
                        LEAVE ISDONE ;
                else
                        SET p_status=1;
                end if;

                SET l_count=-1;
                SELECT CONCAT('Before select crbt_subscriber_wallet_detail2');
                select count(*) into l_count from crbt_subscriber_wallet_detail where wallet_id=p_sys_wallet_id and msisdn=p_msisdn and status='I';
                if l_count > 0 then
                        SET p_status=-51; /* --Already purchased inactive user*/
                        LEAVE ISDONE ;
                else
                        SET p_status=2;
                end if;
	
	                SELECT CONCAT('Before select crbt_subscriber_wallet_detail3');
         select count(*) into l_count from crbt_system_Wallet_master  where wallet_id =p_sys_wallet_id and status='A' and expiry_date>=NOW() and start_date<=NOW() and (interface like concat('%',p_interface,'%') or interface ='A');
select count(*) into l_count from crbt_system_Wallet_master  where wallet_id =p_sys_wallet_id and status='A' and expiry_date>=NOW() and start_date<=NOW() and (interface like 'P' or interface ='A');
        SET p_status=3;
        if l_count > 0 then
                SELECT CONCAT('Before select crbt_subscriber_wallet_detail4');
                select scope into l_scope from crbt_system_Wallet_master  where wallet_id =p_sys_wallet_id and status='A' and expiry_date>=NOW() and start_date<=NOW() and (interface like concat('%',p_interface,'%') or interface ='A');
                SELECT CONCAT('Before select crbt_subscriber_wallet_detail5');
                SET p_status=4;


                SELECT CONCAT('Before ParseStringToString');

                CALL ParseStringToString(l_scope,'SUBTYPE:',l_subType,p_status);
                SELECT CONCAT('l_subType[',l_subType,'] p_subType[',p_subType,'] p_status[',p_status,']');

                if l_subType is NOT null then

                  if l_subType = p_subType OR l_subType = 'B' then
                       SET p_status=5;
                  else
                        SET p_status=-52; /* --not applicable to this subscriber */
                        LEAVE ISDONE;
                  end if;
                else
                        SET p_status=-60; /* --scope is blank */            
                        LEAVE ISDONE;
                end if;
	else
                SET p_status=-53; /* --wallet id not exist */
                LEAVE ISDONE;
        end if;

        SET l_count=0;
        select count(*) into l_count from crbt_subscriber_wallet_detail where wallet_id=p_sys_wallet_id and msisdn=p_msisdn and status='S';

        if l_count = 1 then
               SET p_status=-57; /* -- Suspended Wallet not allowed          */
        end if;

                 LEAVE ISDONE;


SELECT CONCAT('p_status',p_status);	

END //
DELIMITER ;

