DELIMITER //
drop procedure if exists GiftSubscribe //

CREATE PROCEDURE GiftSubscribe(IN p_msisdn varchar(20),IN p_plan int,IN p_lang int ,IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_pin varchar(20),IN p_refid varchar(20),IN p_chgcode int ,IN p_validityDays int ,IN p_fmsisdn varchar(20),OUT p_status int,OUT p_id int)
ISDONE:BEGIN

DECLARE l_wltid int;
DECLARE l_temp int;
DECLARE l_pre_amount  int ;
DECLARE l_post_amount  int;
DECLARE l_final_amount int;
DECLARE l_isSystemRbtBased int;
DECLARE l_paramValue int;
DECLARE l_packId int;
DECLARE l_isSub int;
DECLARE v_finished int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;
		if p_status > 1 then
                        delete from crbt_event_cdr where cdr_id=p_id;
                     --   commit;
                        delete from crbt_subscriber_master where msisdn=p_msisdn;
                     --   commit;
                        delete from crbt_subscription_log where msisdn=p_msisdn and call_id=p_id;
                        commit;
                end if;
               SET p_status=(p_status*(-1));

                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
         SELECT p_status;
END;

START TRANSACTION;

	SET p_status=1;
        SET p_id=-1;
        select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
        if p_subtype = 'O' then
               SET l_final_amount=l_post_amount;
        else
               SET l_final_amount=l_pre_amount;
        end if;
        SET p_status=2;

       -- select SCDR_ID.nextval into p_id from dual;
       -- insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount) values (p_id,p_fmsisdn,p_int,sysdate,'S',p_plan,'N',p_subtype,p_refid,p_chgcode,l_final_amount);
	
	insert into crbt_event_cdr (msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount) values (p_fmsisdn,p_int,NOW(),'S',p_plan,'N',p_subtype,p_refid,p_chgcode,l_final_amount);
	SET p_id=LAST_INSERT_ID();

        SET p_status=3;
       -- commit;
--        insert into crbt_subscriber_master (msisdn,status,plan_indicator,rbt_code,password,tpin,language,sub_type,last_charged,expiry_date) values (p_msisdn,'A',p_plan,0,p_pin,p_pin,p_lang,p_subtype,sysdate-30+p_validityDays,sysdate+p_validityDays);
	insert into crbt_subscriber_master (msisdn,status,plan_indicator,rbt_code,password,tpin,language,sub_type,last_charged,expiry_date) values (p_msisdn,'A',p_plan,0,p_pin,p_pin,p_lang,p_subtype,((NOW()- interval 30 day) + interval p_validityDays day),now() + interval p_validityDays day);
       -- commit;

       SET p_status=4;
--        select wallet_id_seq.nextval into l_wltid from dual;
        insert into crbt_wallet_master (msisdn,create_date,wallet_name,ivr_name) values (p_msisdn,NOW(),'DEFAULT',0);
	SET l_wltid=LAST_INSERT_ID();
       -- commit;
       SET p_status=5;
        insert into crbt_wallet_content (wallet_id,rbt_code,create_date,is_rbt_gifted,msisdn) values (l_wltid,0,NOW(),0,p_msisdn);
       -- commit;
       SET p_status=6;
        insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,8,2500,2500,0,NOW());
      --  commit;
        SET p_status=7;
	insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,NOW(),'S',p_int,'Y',p_updatedby,p_id);
      --  commit;
        SET p_status=8;
        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_fmsisdn,NOW(),1,CONCAT('Subscription is Gifted to Friend ',p_msisdn),p_subtype,p_int,p_updatedby);
      --  commit;
        SET p_status=9;
	COMMIT;
	SELECT CONCAT('p_status p_id ',p_status, p_id);
END //
DELIMITER ;



