DELIMITER //
drop procedure if exists PrintVersion //

CREATE PROCEDURE PrintVersion()
ISDONE:BEGIN

 DECLARE v_finished int;

 DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
        # SELECT p_status;
END;

START TRANSACTION;

	SELECT CONCAT('Telemune Rule Engine Procedure Version [R4_0_1_0] ');
--	LEAVE ISDONE;
END //
DELIMITER ;

