DELIMITER //
drop procedure if exists CorpUnsubscribe //

CREATE PROCEDURE CorpUnsubscribe(IN p_msisdn varchar(20),IN p_updatedby varchar(20), IN  p_corpId bigint , IN  p_corpName varchar(20) ,OUT  p_status int , OUT p_response int , OUT  p_id int ) 
ISDONE:BEGIN

DECLARE l_temp   int ;
DECLARE l_status varchar(2);
DECLARE l_planId int ;
DECLARE l_subtype varchar(1);
DECLARE l_cdrId bigint ; 

DECLARE v_finished int;

DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
 SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
	       SHOW WARNINGS;

		if p_response>=4 and p_response<=9 then
                              SET  p_response=-23;
                else
                       SET p_response=(p_response*(-1));
                end if;

                SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
        # SELECT p_status;
END;

START TRANSACTION;
	SET l_temp=0;
        SET p_status=-1;
        SET l_planId=-1;
        SET l_subtype='N';
        SET p_id=-1;
        SET p_response=-1;

        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and CORP_ID=p_corpId;
        if l_temp = 0 then
                SET p_response=-24;
                LEAVE ISDONE;
        end if;
        SET p_status=1;
        SET p_response=1;

        select PLAN_INDICATOR,SUB_TYPE into l_planId,l_subtype from CRBT_SUBSCRIBER_MASTER where MSISDN =p_msisdn  and CORP_ID=p_corpId;
        SET p_status=2;
        SET p_response=2;

        /*select SCDR_ID.nextval into p_id from dual; */
        insert into crbt_event_cdr (msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount) values (p_msisdn,'T',now() ,'U',1,'N',l_subtype,'00000000000',-1,0);
	
	SET p_id=LAST_INSERT_ID();

        SELECT CONCAT( 'subscriber is postpaid ..scdr id ', p_id);
        SET p_status=3;
        SET p_response=3;
        SELECT CONCAT('CRBT EVENT CDR');

        SELECT CONCAT( 'after cdr');
        insert into crbt_subscriber_master_old (select * from crbt_subscriber_master where msisdn=p_msisdn);

--	insert into crbt_subscriber_master_old (select * from crbt_subscriber_master where msisdn=p_msisdn);
--        commit;
        delete from crbt_subscriber_master where msisdn=p_msisdn;
        SELECT CONCAT( 'after deletion');
        SET p_status=4;
        SET p_response=4;
  --      commit;
        SELECT CONCAT('CRBT SUBSCRIBER MASTER');

/*        insert into crbt_cdrs ( msisdn,TARIFFID,ACTION,INTERFACE,SERVICE_CLASS,DA_ID,CREATE_DATE,FMSISDN,RBT_CODE,AMOUNT,STATUS,CDR_ID) values (p_msisdn,-1,9,'T',-1,0,now() ,'NA',-1,0,'N',crbt_cdr_id.nextval); */

	insert into cdr_seq_id values(null);
	SET l_cdrId=LAST_INSERT_ID();
	
	insert into crbt_cdrs ( msisdn,TARIFFID,ACTION,INTERFACE,SERVICE_CLASS,DA_ID,CREATE_DATE,FMSISDN,RBT_CODE,AMOUNT,STATUS,CDR_ID) values (p_msisdn,-1,9,'T',-1,0,now() ,'NA',-1,0,'N',l_cdrId);


        SET p_status=5;
        SET p_response=5;
    --    commit;
        SELECT CONCAT('CRBT CDRS');

        if l_subtype='P' then
                insert into CRBT_PREPAID_SUBSCRIPTION_CDR (MSISDN, INTERFACE_USED, UPDATE_TIME, ACTION, PLAN_INDICATOR, STATUS) values (p_msisdn, 'T', now() , 'U',l_planId, 'N');
          else
                insert into CRBT_SUBSCRIPTION_CDR (MSISDN, INTERFACE_USED, UPDATE_TIME, ACTION, PLAN_INDICATOR, STATUS) values (p_msisdn , 'T', now() , 'U',l_planId, 'N');
        end if;
        SET p_status=6;
        SET p_response=6;
      --  commit;
        SELECT CONCAT('SUBSCRITION CDR log');

        insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id,unsub_reason) values (p_msisdn,l_subtype,now() ,'U','T','N',p_updatedby,0,-1);
        SET p_status=7;
        SET p_response=7;
      --  commit;
	SELECT CONCAT( 'subscription log');

        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now() ,1,CONCAT('UNSUBSCRIBED FROM CORP:',p_corpName),l_subtype,'T',p_updatedby);
        SET p_status=8;
        SET p_response=8;
       -- commit;
        SELECT CONCAT('activity log');

        SET p_status=9;
        SET p_response=9;
	SELECT CONCAT('p_status',p_status);
END //
DELIMITER ;


