delimiter //
drop procedure if exists CheckAndFindRatePlan //
create procedure CheckAndFindRatePlan (IN p_msisdn varchar(20),IN p_subType varchar(20),IN p_planName varchar(20),OUT p_planId  int,OUT p_status  int) 
isdone:begin
declare l_countryCode int;
declare l_temp int;
declare l_planId int;
declare l_maskedName varchar(100);
declare l_scope varchar(1024);
declare l_subType varchar(4);
declare cont int;

declare v_finished int;
declare cur_rate_plan CURSOR for  select plan_indicator,scope from crbt_rate_plan where UPPER(masked_name)=UPPER(l_maskedName) and status='A' and country_code=l_countryCode;
declare  cur_masked_name CURSOR for  select masked_name from rate_plan_alias where UPPER(alias_name)=UPPER(p_planName);
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
            #   SELECT p_status;
       END;
 START TRANSACTION;

       set  l_countryCode=0;
       set  l_temp=0;
       set  p_status=1;
       set  p_planId=-1;
       set  l_planId=-1;
        OPEN cur_masked_name;
        fetch cur_masked_name into l_maskedName;
        if v_finished = 1  then
                select concat('No Plan Found for this alias name');
                close cur_masked_name;
                set p_planId=-1;
                set p_status=0;
                LEAVE ISDONE;
        end if;
        close cur_masked_name;

        select count(*) into l_temp from OPERATOR_SUBSCRIBER where CAST(STARTS_AT AS UNSIGNED) <=CAST(p_msisdn AS UNSIGNED) and CAST(ENDS_AT AS UNSIGNED) >=CAST(p_msisdn AS UNSIGNED);
        if l_temp = 1 then
                select cast(country_code AS UNSIGNED) into l_countryCode from OPERATOR_SUBSCRIBER where CAST(STARTS_AT AS UNSIGNED) <=CAST(p_msisdn AS UNSIGNED) and CAST(ENDS_AT AS UNSIGNED) >=CAST(p_msisdn AS UNSIGNED);
        else
                set l_countryCode=0;
        end if;

        select concat('Country Code[',l_countryCode,']');
        OPEN cur_rate_plan;
        cur_rate_plan:LOOP
                fetch cur_rate_plan into l_planId,l_scope;
                if v_finished = 1 then
                        select concat('No Plan Found for masked name[',l_maskedName,']');
                        set p_planId=-1;
                        set p_status=1;
                        CLOSE cur_rate_plan;
                        LEAVE ISDONE;
                else
                        select concat('Plan Id[',l_planId,'] Scope[',l_scope,']');
                        call ParseStringToString(l_scope,'SUBTYPE',l_subType,p_status);
			select concat('After Parsing p_status[',p_status,']');
                        select concat('l_subType[',l_subType,'] p_subType[',p_subType,'] p_status[',p_status,']');

                        if l_subType = p_subType OR l_subType = ':B' then
                                select concat('Plan Found for this masked name');
                                set p_planId=l_planId;
                                set  p_status=9;
                                CLOSE cur_rate_plan;
                                LEAVE ISDONE;
                        end if;
                end if;
        END LOOP cur_rate_plan;
END //

                              

