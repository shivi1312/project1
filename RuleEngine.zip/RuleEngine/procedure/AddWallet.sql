delimiter //
drop procedure if exists AddWallet //
create procedure AddWallet (IN p_msisdn varchar(20),IN p_int varchar(20),IN p_updatedby varchar(20),IN p_subtype varchar(20),IN p_sys_wallet_id int,IN p_chgdone int,IN p_refid varchar(20),IN p_chgcode int,IN p_validityDays int,IN p_packId int,IN p_type int,OUT p_status int,OUT p_id int)
ISDONE:BEGIN

declare l_temp  int;
declare l_totalRbt int;
declare l_freeRbt int;
declare l_isSystemRbtBased int;
declare l_renew_enable int;
declare l_count int;
declare l_sys_wallet_setting int;

declare v_finished int;
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
 BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
               ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));

                 SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
               SELECT p_status;
       END;
 START TRANSACTION;
        
	set l_temp=0;
	set l_totalRbt=0;
	set l_freeRbt=0;
	set l_renew_enable=-1;
	set l_count=-1;
	set l_sys_wallet_setting=1;
	set l_isSystemRbtBased=-1;

        if p_chgdone != 1
        then
		set p_status=1;
		set p_id=-1;
                LEAVE ISDONE;
        end if;
	set p_status=1;
	set l_temp= 0;
        call GenerateRBTSettingCDR(p_msisdn,p_int,p_subtype,1,p_sys_wallet_id,p_refid,p_chgcode,p_id);

        if p_id=-1
        then
		set p_status=-18;
		LEAVE ISDONE;
        end if;


	set p_status=2;
	select concat('after AddAlbum wallet_id1  ',l_temp);
	select concat('before select renew_enable');
        select renew_enable into l_renew_enable from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A';
	select concat('After select renew_enable');
	set p_status=3;


	set l_count=-1;
        select count(*) into l_count from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A' and expiry_date>=now();
	set p_status=4;
        if l_count >0 then
                select setting into l_sys_wallet_setting from crbt_system_wallet_master where wallet_id=p_sys_wallet_id and status='A' and expiry_date>=now();
		set p_status=5;
        end if;


insert into CRBT_SUBSCRIBER_WALLET_DETAIL(msisdn,wallet_id,create_date,expiry_date,last_charged_date,renew_enable,status,use_case,is_gifted,fmsisdn,setting) values(p_msisdn,p_sys_wallet_id,now(),now()+ interval p_validityDays day,now(),l_renew_enable,'A',0,0,'NA',l_sys_wallet_setting);

#--        commit;
	select concat('after AddAlbum wallet_id2   ',l_temp);
	set p_status=6;

 select param_value into l_isSystemRbtBased from crbt_app_Config_params where param_tag ='RBT_BASED_SUBSCRIPTION';

        if l_isSystemRbtBased=1 then
                update crbt_subscriber_master set last_charged=((now()- interval 30 day)+ interval p_validityDays day), expiry_date=now()+ interval p_validityDays day, update_time=now() where msisdn=p_msisdn and last_charged<=((now()- interval 30 day)+ interval p_validityDays day);
   #--             commit;
        end if;
	set p_status=7;

        insert into crbt_album_op_log (msisdn,subscriber_type,event_time,interface_type,rbt_code,album_id,op_code,event_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),p_int,p_sys_wallet_id,l_temp,4,'Y',p_updatedby,p_id);
     # --   commit;
	set p_status=8;
        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),0,concat(p_sys_wallet_id,'Added WALLET'),p_subtype,p_int,p_updatedby);
	set p_status=9;
     #--   commit;
         update crbt_rbt set rbt_score=rbt_score+1 where rbt_code=rbt_code;
         set p_status=11;
         commit;
	SELECT CONCAT(' p_status ',p_status,' p_id ',p_id);
End //

