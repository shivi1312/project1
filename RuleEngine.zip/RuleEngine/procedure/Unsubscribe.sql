delimiter //
drop procedure if exists Unsubscribe //
create procedure Unsubscribe ( IN p_msisdn  varchar(20), IN p_int  varchar(20), IN p_updatedby  varchar(20),IN p_subtype  varchar(20),IN p_unsubReason  varchar(20),OUT  p_status  int,OUT p_id  int)
ISDONE:BEGIN
declare l_temp          int;
declare l_status        varchar(2);
declare cdr_id		int;
declare v_finished      int; 
DECLARE CONTINUE HANDLER FOR NOT FOUND set v_finished = 1;
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
BEGIN
               GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
               SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
               SELECT @full_error;
		ROLLBACK;
               SHOW ERRORS;
               SHOW WARNINGS;

               set p_status=(p_status*(-1));
               SELECT 'An error has occurred, operation rollbacked and the stored procedure was terminated';
       END;
 START TRANSACTION;
                   set l_temp=0;
                   set p_status=-1;
                   set p_id=-1;
                    select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn;
			SELECT concat('p_msisdn for unsubscribe',p_msisdn,' l_temp ',l_temp);
        if l_temp = 0 then
                set p_status=-24;
                 LEAVE ISDONE;
        end if;
        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status='D';
        if l_temp = 1 then
                set p_status=-24;
                LEAVE ISDONE;
         end if;
        set p_status=1;
#        -- select SCDR_ID.nextval into p_id from dual;
         -- select max(cdr_id+1) into p_id from crbt_event_cdr;
-- insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount) values (p_id,p_msisdn,p_int,now(),'U',1,'N',p_subtype,'00000000000',-1,0);
insert into crbt_event_cdr (msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount) values (p_msisdn,p_int,now(),'U',1,'N',p_subtype,'00000000000',-1,0);
	set p_id=LAST_INSERT_ID();
        select concat( 'subscriber is postpaid ..scdr id ' ,p_id);
        set p_status=2;

        select concat( 'after cdr');
        insert into crbt_subscriber_master_old (select * from crbt_subscriber_master where msisdn=p_msisdn);

        -- commit;
	insert into cdr_seq_id (sequence) values (null);

        -- commit;
        delete from crbt_subscriber_master where msisdn=p_msisdn;
        select concat( 'after deletion');
        set p_status=4;
        set cdr_id=LAST_INSERT_ID();
        -- insert into crbt_cdrs ( msisdn,TARIFFID,ACTION,INTERFACE,SERVICE_CLASS,DA_ID,CREATE_DATE,FMSISDN,RBT_CODE,AMOUNT,STATUS,CDR_ID) values (p_msisdn,-1,9,p_int,-1,0,now(),'NA',-1,0,'N',(select max(cdr_id+1) from crbt_cdrs));
        insert into crbt_cdrs ( msisdn,TARIFFID,ACTION,INTERFACE,SERVICE_CLASS,DA_ID,CREATE_DATE,FMSISDN,RBT_CODE,AMOUNT,STATUS,CDR_ID) values (p_msisdn,-1,9,p_int,-1,0,now(),'NA',-1,0,'N',cdr_id);
        -- commit;
        set p_status=5;
        if p_int = 'M' then
                insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,now(),'D',p_int,'N',p_updatedby,p_id);
        else
                insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id,unsub_reason) values (p_msisdn,p_subtype,now(),'U',p_int,'N',p_updatedby,p_id,p_unsubReason);
        end if;
        set p_status=7;
        -- commit;
        select concat( 'subscription log');
        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,now(),1,'UNSUBSCRIBED',p_subtype,p_int,p_updatedby);
        set p_status=8;
        -- commit;
        select concat( 'activity log');
        set p_status=9;
	commit;
END //
#DELIMITER



         

