#/bin/sh

#set -x
. ~/.bash_profile

RULE_ENGINE_JAR=/home/pankaj/development/RULE_ENGINE_JAR/

javac -cp $RULE_ENGINE_JAR/lib_jdk6/apache-commons-lang.jar:$RULE_ENGINE_JAR/lib_jdk6/log4j-1.2.9.jar:$RULE_ENGINE_JAR/lib_jdk6/ojdbc14.jar:$RULE_ENGINE_JAR/lib_jdk6/RatePlanParser.jar:$RULE_ENGINE_JAR/lib_jdk6/commonUtil.jar:$RULE_ENGINE_JAR/lib_jdk6/c3p0-0.9.1.jar:$RULE_ENGINE_JAR/lib_V3.1/crbtrules.jar:$RULE_ENGINE_JAR/lib_V3.1/CRERequestLib.jar:$RULE_ENGINE_JAR/lib_jdk6/c3p0-0.9.1.jar:$RULE_ENGINE_JAR/lib_jdk6/gson-2.2.2.jar:$RULE_ENGINE_JAR/lib_jdk6/FileBaseLogging.jar:$RULE_ENGINE_JAR/lib_jdk6/http.jar:./  -d . src/telemune/engine/backend/common/*.java


java -cp $RULE_ENGINE_JAR/lib_jdk6/apache-commons-lang.jar:$RULE_ENGINE_JAR/lib_jdk6/log4j-1.2.9.jar:$RULE_ENGINE_JAR/lib_jdk6/ojdbc14.jar:$RULE_ENGINE_JAR/lib_jdk6/RatePlanParser.jar:$RULE_ENGINE_JAR/lib_jdk6/commonUtil.jar:$RULE_ENGINE_JAR/lib_jdk6/c3p0-0.9.1.jar:$RULE_ENGINE_JAR/lib_V3.1/crbtrules.jar:$RULE_ENGINE_JAR/lib_V3.1/CRERequestLib.jar:$RULE_ENGINE_JAR/lib_jdk6/c3p0-0.9.1.jar:$RULE_ENGINE_JAR/lib_jdk6/gson-2.2.2.jar:$RULE_ENGINE_JAR/lib_jdk6/FileBaseLogging.jar:$RULE_ENGINE_JAR/lib_jdk6/http.jar:./ telemune.engine.backend.common.RuleEngine &
