
package telemune.engine.backend.common;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.net.Socket;

import org.apache.log4j.Logger;

import com.telemune.crbt.CRERequestHandler;
import com.telemune.crbt.SetVariable;

import FileBaseLogging.FileLogWriter;
import commonutil.TLVParameters;

/**
 *THIS CLASS IS FOR READING THE REQUEST FROM CLIENT ON PARTICULAR DEFINE PORT THROUGH CRE INTERFACE AND THEN INSERT THE DATA INTO THE QUEUE
 *@author :- PANKAJ GUPTA
 *   
 */
class RequestReaderCRE implements Runnable
{
	String name;
	Thread thrd;
	Socket socket_me;
	DataInputStream reader = null;
	static Logger logger=Logger.getLogger("RequestReaderCRE");
	ResponseSender responseSender=null;
	FileLogWriter error_flw=null;

	/**
	 *THIS IS THE PARAMETERIZED CONSTRUCTOR OF RequestReaderCRE
	 *@param name :- REFERS TO THE NAME OF THE THREAD WHICH ARE RUNNING
	 *@param socket :- REFERS TO THR SOCKET ON WHCIH SERVERACCEPTORCRE IS LISTENING THE REQUEST COMMING FROM CLIENT
	 */
	RequestReaderCRE(String name,Socket socket)
	{
		thrd = new Thread(this,name);
		this.name = name;
		socket_me = socket;
		this.error_flw=GlobalRE.error_flw;
		logger.info("\nintializing thread to recv data: #" + name );
		responseSender=new ResponseSender();
	}
	/**
	 *THIS IS THE RUN FUNCTION OF THE THREAD RequestReaderCRE WHICH CALL THE FUNCTION getfromclient().....FOR GETTING THE DATA FROM CLIENT
	 */
	public void run()
	{
		logger.info("\nstarted thread to recv data: #" + name );
		getfromclient(name,socket_me);
	}
	/**
	 *THIS FUNCTION IS FOR GETTING THE DATA FROM CLIENT BY RECIEVING THE DATA AT THE DEFINE PORT 
	 *@param name :- REFERS TO THE THREAD NAME
	 *@param socket_me :- REFERS TO THE SOCKET ON WHICH APP GET THE DATA FROM CLIENT
	 *THIS CLASS BASICALLY MAINTAIN THE TCP/IP CONNECTION FROM CLIENT AND READ THE REQUEST FROM CLIENT
	 */
	public void getfromclient(String name,Socket socket_me)
	{
		try{
			reader = new DataInputStream(socket_me.getInputStream());}
		catch(Exception e)
		{	
			logger.error(GlobalRE.exception_error+"in getting the data input stream from socket",e);
		}
		logger.info("\nPreparing to recv  data thread# "+ name);
		try
		{
			while(true)
			{

				if (socket_me.isClosed())
				{
					logger.debug(GlobalRE.exception_error+"Socket closed : ["+socket_me+"]");
					thrd.stop();
					return;
				}
				else
				{	
					ByteArrayInputStream inbuf = null;
					//logger.info("reading Info ........");
					//logger.info("Socket==="+socket_me.toString());
					byte dataBuf1[] = new byte[4];
					int dataLen =0;
					try
					{

						logger.debug("reading Info ......starts.");
						if(reader.read(dataBuf1,0,4)==-1)
						{
							logger.warn("reader.read == -1 ...");
							try
							{
								socket_me.close();
								logger.warn("Destroy");
								logger.warn("socket closed");
								thrd.stop();
								return;
							}
							catch(Exception e)
							{
								logger.error(GlobalRE.exception_error+"in closing the socket in RequestReaderCRE",e);
							}

						}
						logger.debug("reading Info ......end.");
						int test=0;
						dataLen = dataLen | (dataBuf1[0] << 24);
						dataLen = dataLen  | (dataBuf1[1] << 16);
						dataLen = dataLen | (dataBuf1[2] << 8);
						test=(0x000000ff & dataBuf1[3]);
						dataLen = dataLen | test;
						logger.info("reading Info ......data len.."+dataLen);
					}
					catch (Exception e)
					{
						logger.fatal(GlobalRE.exception_error+"Getting exception in reading datalen....",e);
						try
						{
							thrd.sleep(1);
							socket_me.close();

						}
						catch(Exception eee)
						{
							logger.fatal(GlobalRE.exception_error+"Thread Sleep Exception in main");
						}	
					}
					if (dataLen==0)
					{	try
					{
						logger.info(" data length is ["+dataLen+"] so Sleeping.....n");
						continue;//thrd.sleep(10);
					}
					catch(Exception eee)
					{
						logger.error("Sleep Exception in main");
					}
					}

					logger.debug("recieved cre_req size="+dataLen);

					byte dataBuf[] =null;
					TLVParameters tcp_req =null;
					DataObjectRE dataObjectRE=null;
					SetVariable setVariable=null;
					CRERequestHandler creRequestHandler=null;

					try{
						dataBuf = new byte[dataLen];
						reader.read(dataBuf, 0, dataLen);
						inbuf = new ByteArrayInputStream(dataBuf);


						creRequestHandler=new CRERequestHandler();
						setVariable=creRequestHandler.decodeRequest(inbuf);

						if(setVariable!=null){
							tcp_req =new TLVParameters();
							setTLVParams(tcp_req,setVariable);

							dataObjectRE=new DataObjectRE();
							dataObjectRE.msisdn=tcp_req.getData(RETags.MSISDN);
							dataObjectRE.sock=socket_me;
							dataObjectRE.actionId=Integer.parseInt(tcp_req.getData(RETags.ACTION));
							dataObjectRE.requestMedia=RETags.cre;
							dataObjectRE.tlv_params=tcp_req;
							
							dataObjectRE.logPrefix=dataObjectRE.msisdn;//For logging purpose

							logger.debug(dataObjectRE.getLogLine()+"setVariable Bean Values >> "+setVariable.toString());
							//logger.info(dataObjectRE.getLogLine()+"got the request with parameter list size ["+dataObjectRE.creParamAl.size()+"]");

							if(GlobalRE.msisdn_map.containsKey(dataObjectRE.msisdn)){
								logger.info(dataObjectRE.getLogLine()+"Request already in process,So nothing to process. please try later...");
								dataObjectRE.tlv_params.setData(RETags.RESPONSE_CODE,ErrorCodesRE.REQUEST_ALREADY_IN_PROCESS_CODE);
								dataObjectRE.tlv_params.setData(RETags.RESPONSE_STRING,ErrorCodesRE.REQUEST_ALREADY_IN_PROCESS);
								responseSender.sendtoclient(dataObjectRE);						
							}else{
								//Thread.sleep(50000);
								GlobalRE.msisdn_map.put(dataObjectRE.msisdn,dataObjectRE.sock);
								logger.debug(dataObjectRE.getLogLine()+"data added in global que and msisdn map , msisdn record size :["+GlobalRE.msisdn_map.size()+"]");
								GlobalRE.que.put (dataObjectRE);
							}
						}
						else{
							logger.error(GlobalRE.exception_error+"no data is set into setVariable bean so cannot process the request");
						}
					}catch (Exception e) {
						logger.error(GlobalRE.exception_error+" in reading the data to corresponding datalen ["+dataLen+"] or in decoding and setting the data to setVariable bean ",e);
					}finally{
						dataBuf=null;	
						setVariable=null;
						dataObjectRE=null;
						creRequestHandler=null;
						tcp_req=null;
					}

				}
			}
		}
		catch(Exception e)
		{
			logger.error(GlobalRE.exception_error+"got exception in RequestReaderCRE.",e);
		}
	}

	/**
	 * This function basically decodes the integer data from the buffer received from the socket
	 * @param buf this is the buffer from which data is to be decoded
	 * @return integer This is the data decoded from the buffer  
	 * */

	public int readInt(ByteArrayInputStream buf)
	{
		int dataLen=0,test=0;
		byte []  dataBuf1=null;
		try{		
			dataBuf1=new byte[4];
			buf.read(dataBuf1,0,4);
			//logger.info(dataBuf1[0]+","+dataBuf1[1]+","+dataBuf1[2]+","+dataBuf1[3]);
			dataLen = dataLen | ((dataBuf1[0] << 24) &  0xff000000);
			dataLen = dataLen  | ((dataBuf1[1] << 16) & 0x00ff0000 );
			dataLen = dataLen | ((dataBuf1[2] << 8) &   0x0000ff00);
			test=(0x000000ff & dataBuf1[3]);
			dataLen = dataLen | test;
		}catch (Exception e) {
			logger.error(GlobalRE.exception_error+"in reading Integer data from CRE Request",e);
		}
		finally{
			dataBuf1=null;
		}
		return dataLen;
	}
	/**
	 * This function basically decodes the String data from the buffer received from the socket
	 * @param len this is the length of the string by which data is decoded from the buffer to this length
	 * @param buf this is the buffer from which data is to be decoded	 
	 * @return String This is the data decoded from the buffer  
	 * */
	public String readString(int len,ByteArrayInputStream buf)
	{
		byte[] dataBuf1=null;
		String param ="";
		try{
			dataBuf1=new byte[len];
			buf.read(dataBuf1,0,len);
			param = new String(dataBuf1);	    
		}catch (Exception e) {
			logger.error(GlobalRE.exception_error+"in reading String data from CRE Request",e);
		}
		finally{
			dataBuf1=null;
		}
		return param;
	}

	/**
	 * This is the function which set the data into the SetVariable bean from arraylist
	 * @param creParamAl_temp This is the arraylist from which data is extracted
	 * @param setVariableRE This is the bean object to which data is set from the arraylist
	 * */
	public void setTLVParams(TLVParameters tlvParameters,SetVariable setVariable){
		try{
			tlvParameters.setData(RETags.REQID,setVariable.getReqId());
			tlvParameters.setData(RETags.ACTION,setVariable.getActId());
			tlvParameters.setData(RETags.MSISDN,setVariable.getMsisdn());
			tlvParameters.setData(RETags.INTERFACE,setVariable.getInterfaceName());
			tlvParameters.setData(RETags.PLANIND,setVariable.getPlanId());
			tlvParameters.setData(RETags.LANGUAGE,setVariable.getLangId());
			tlvParameters.setData(RETags.UPDATEBY,setVariable.getUpdatedBy());
			tlvParameters.setData(RETags.SUBTYPE,setVariable.getSubType());
			tlvParameters.setData(RETags.REASON,setVariable.getReason());
			tlvParameters.setData(RETags.RBTCODE,setVariable.getRbtCode());
			tlvParameters.setData(RETags.DAYS,setVariable.getDays());
			tlvParameters.setData(RETags.STARTTIME,setVariable.getStartTime());
			tlvParameters.setData(RETags.ENDTIME,setVariable.getEndTime());
			tlvParameters.setData(RETags.CHECKRBT,setVariable.getCheckRbt());
			tlvParameters.setData(RETags.FMSISDN,setVariable.getFmsisdn());
			tlvParameters.setData(RETags.GROUPNAME,setVariable.getGroupName());
			tlvParameters.setData(RETags.ALBUMNAME,setVariable.getAlbumName());
			tlvParameters.setData(RETags.ADVOP,setVariable.getAdvop());
			tlvParameters.setData(RETags.CONTROLNAME,setVariable.getControlName());
			tlvParameters.setData(RETags.DATE,setVariable.getDate());
			tlvParameters.setData(RETags.RBTPATH,setVariable.getRbtPath());
			tlvParameters.setData(RETags.CATID,setVariable.getCatId());
			tlvParameters.setData(RETags.CALLID,setVariable.getCallId());
			tlvParameters.setData(RETags.ALBUMID,setVariable.getAlbumID());
			tlvParameters.setData(RETags.OCC,setVariable.getOccName());
			tlvParameters.setData(RETags.REFID,setVariable.getReferenceId());
			tlvParameters.setData(RETags.PACKID,setVariable.getPackId());
			tlvParameters.setData(RETags.HLRREQUEST,setVariable.getHlrRequest());
			tlvParameters.setData(RETags.PLANNAME,setVariable.getPlanName());
			
			//Changes for System Wallet			
			tlvParameters.setData(RETags.SYSTEM_WALLET_ID,setVariable.getSystemAlbumId());
			tlvParameters.setData(RETags.TYPE,setVariable.getType());
			////////////////
			//Added by shambhavi 25-04-2016
			tlvParameters.setData(RETags.SUB_RENEW_START_STOP,setVariable.getRenewStatus());
			tlvParameters.setData(RETags.CRBT_PROMO_ACTIVATION,setVariable.getPromoId());
			
			
		}catch (Exception e) {
			logger.error(GlobalRE.exception_error+" in setting TLV params from CRE params",e);
		}
	}
}

