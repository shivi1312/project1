
package telemune.engine.backend.common;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import FileBaseLogging.FileLogWriter;

/**
 * THIS CLASS IS FOR MONITORING THE THREADS THAT WHICH THREAD IS OPEN AND PERFORMED THE TASK
 *@author PANKAJ GUPTA
 * 
 */
public class ThreadMonitor implements Runnable
{
	private ThreadPoolExecutor executorPool;
	private int seconds;
	private boolean run=true;
	static FileLogWriter error_flw = null;
	static Logger logger=Logger.getLogger("ThreadMonitor");
	

/**
 *THIS IS THE CONSTRUCTOR OF THREAD MONITOR WHICH INITIALIZE THE ESSENTIAL PARAMETER
 *@param executor :-REFERS TO A THREAD POOL EXECUTOR OBJECT GOING TO BE MONITOR 
 *@param delay :- REFERS TO AN INTEGER VALUE WHICH IS FOR DEFINE THE DELAY TIME OF MONITOR THREAD IN SECONDS
 */
	public ThreadMonitor(ThreadPoolExecutor executor, int delay)
	{
		this.executorPool = executor;
		this.error_flw=GlobalRE.error_flw;
		this.seconds=delay;
	}
/**
 *THIS METHOD IS FOR SHUTDOWN THE MONITOR THREAD 
 */
	public void shutdown(){
		this.run=false;
	}

/**
 *
 *THIS IS THE RUN METHOD WHICH LOOK UP THE MONITORING OF THE THREADS 
 *THAT HOW MANY THREADS ARE ACTIVE 
 *HOW MANY TASK ARE COMPLETED
 *TOTAL TASK COUNT
 *IS THREAD SHUTDOWN
 *IS THREAD TERMINATED
 *
 *ALL THESE WORK ARE PERFORMED BY THIS RUN METHOD
 */
	@Override
		public void run()
		{
			while(run){
				try
				{
					logger.info(
							String.format("[monitor] [%d/%d] Active: %d, Completed: %d, Task: %d, isShutdown: %s, isTerminated: %s, Pending Queuesize %d",
								this.executorPool.getPoolSize(),
								this.executorPool.getCorePoolSize(),
								this.executorPool.getActiveCount(),
								this.executorPool.getCompletedTaskCount(),
								this.executorPool.getTaskCount(),
								this.executorPool.isShutdown(),
								this.executorPool.isTerminated(),
								this.executorPool.getQueue().size()));
					logger.info("Size of the Que"+GlobalRE.que.size());
					//System.out.println("Size of the Que"+GlobalRE.que_send.size());
				}
				catch(Exception es)
				{
					logger.error("Exception inside monitor thread"+es);
				}


				try {
					Thread.sleep(seconds*1000);
				} catch (InterruptedException e) {
					logger.error("Exception inside monitor thread"+e);
				}
			}

		}
}
