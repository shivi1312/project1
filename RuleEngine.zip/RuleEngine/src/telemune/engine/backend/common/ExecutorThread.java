package telemune.engine.backend.common;

import java.lang.reflect.Method;
import java.util.Hashtable;

import org.apache.log4j.Logger;

import FileBaseLogging.FileLogWriter;
import commonutil.TLVParameters;
import commonutil.TssStringUtill;
/**
 * THIS CLASS IS FOR EXECUTING EACH REQUEST AND SEND RESPONSE.
 * @author :- Pankaj Gupta
 */
public class ExecutorThread implements Runnable{
	static  Logger logger = Logger.getLogger("ExecutorThread");
    FileLogWriter error_flw = null;
    Class clazz=null;
    Object obj=null;
    Method methodToCall=null;
    DataObjectRE dataObjectRE;
    String className="";
    ResponseSender responseSender=null;
    
    
    
	
	/**
	 *THIS IS THE CONSTRUCTOR FOR THE CLASS ExecutorThread
	 *
	 */
	public ExecutorThread(DataObjectRE dataObjectRE){
		this.className=GlobalRE.fxnsClass;
		this.dataObjectRE=dataObjectRE;
		this.error_flw=GlobalRE.error_flw;
		responseSender=new ResponseSender();
	}
	
	/**
	 *This run method extract data from DataBean and perform action corresponding to requestId
	 *The action which is to be performed are read from state machine file which is loaded by CacheLoader 
	 *It also manage multiple threads using thread pool. 
	 */
	public void run() {
		Hashtable<String,ActionInfo> inner_hash=null;
		ActionInfo actionInfo=null;
		String nextState="";
		String nextEvent="";
		try{
			if(dataObjectRE!=null){
				logger.info(dataObjectRE.getLogLine()+"executing the request");
				clazz=(Class) Class.forName(className);//className is the appName
				obj=(Object) clazz.newInstance();
				
				
				inner_hash=(Hashtable<String,ActionInfo> )GlobalRE.state_cache.get(dataObjectRE.actionId+"");//state_cache.get(17)
				
				if(dataObjectRE.transactionId.equals("NA")){
					nextState=GlobalRE.start_state;//actionInfo.getNextState();	
				}else{
					nextState=GlobalRE.callback_state;
				}
				
				while(!nextState.equalsIgnoreCase("NULL")){
					
					if(!(nextState.equals(GlobalRE.start_state) || nextState.equals(GlobalRE.callback_state)))
					{
							nextState=nextState+"_"+nextEvent;
					}					
					try{
					actionInfo=(ActionInfo)inner_hash.get(nextState);
					nextState=actionInfo.getNextState();
					//logger.debug(dataObjectRE.getLogLine()+"getting action info as : ["+actionInfo.toString()+"]");
					logger.debug(dataObjectRE.getLogLine()+"currently executing method ["+actionInfo.getMethodName()+"] >> next state is ["+actionInfo.getNextState()+"]");
					}
					catch (Exception e) {
						logger.error(dataObjectRE.getLogLine()+"in getting detail of ["+nextState+"] returning from method ["+methodToCall+"] so calling ["+GlobalRE.unknown_event+"]");
						// state, event , function 
						try{
						methodToCall=(Method) clazz.getMethod(GlobalRE.unknown_event,TLVParameters.class);
						nextEvent=(String) methodToCall.invoke(obj,dataObjectRE.tlv_params);
						nextState="NULL";
						}catch (Exception ex) {
							logger.error(GlobalRE.exception_error+" in method invocation handleUnknownEvent()"+e.toString());
						}
						break;					
					}
								
					try{
					methodToCall=(Method) clazz.getMethod(actionInfo.getMethodName(),TLVParameters.class);
					nextEvent=(String) methodToCall.invoke(obj,dataObjectRE.tlv_params);
					//logger.debug(dataObjectRE.getLogLine()+"getting event : ["+nextEvent+"]");
					logger.debug(dataObjectRE.getLogLine()+"getting event : ["+nextEvent+"]");
					}
					catch (Exception e) {
						logger.error(GlobalRE.exception_error+" corresponding to "+dataObjectRE.getLogLine()+"in method invocation"+e.toString());
						break;
					}
				}
				
				//To exceute the endState of the jar class
				logger.debug(dataObjectRE.getLogLine()+"now executing ["+GlobalRE.end_event+"]");
				try{
					methodToCall=(Method) clazz.getMethod(GlobalRE.end_event,TLVParameters.class);
					methodToCall.invoke(obj,dataObjectRE.tlv_params);
				}catch (Exception e) {
					logger.error(GlobalRE.exception_error+"in exceuting the endState of the app"+e.toString());
				}
				
				
				if(dataObjectRE.tlv_params.getData(RETags.RESPONSE_CODE)==null){
					dataObjectRE.tlv_params.setData(RETags.RESPONSE_CODE,-1);
				}
				
				if(!TssStringUtill.ValidateParams(dataObjectRE.tlv_params.getData(RETags.RESPONSE_STRING))){
					dataObjectRE.tlv_params.setData(RETags.RESPONSE_STRING,ErrorCodesRE.UNKNOWN);
				}
				/*if(dataObjectRE.tlv_params.getData(RETags.RESPONSE_STRING)==null){
					if(dataObjectRE.tlv_params.getData(RETags.RESPONSE_TYPE)==null || dataObjectRE.tlv_params.getData(RETags.RESPONSE_TYPE).equals("NA")){
					dataObjectRE.tlv_params.setData(RETags.RESPONSE_STRING,ErrorCodesRE.UNKNOWN);
					}
				}*/
				
				//dataObjectRE.tlv_params.setData(GlobalRE.RESPONSE_TAG,40);
				if(!dataObjectRE.requestMedia.equals(RETags.http)){
					logger.info(dataObjectRE.getLogLine()+"exceution done successfully now sending response ["+dataObjectRE.tlv_params.getData(RETags.RESPONSE_CODE)+"] and response String ["+dataObjectRE.tlv_params.getData(RETags.RESPONSE_STRING)+"] to : ["+dataObjectRE.requestMedia+"]");
					responseSender.sendtoclient(dataObjectRE);	
				}
				
			}
			else{
				logger.error("no data to execute right now");
			}				
		}
		catch (Exception e) {
			logger.error(GlobalRE.exception_error+"in run() of ExecutorThread"+e.toString());			
		}
		finally{
			inner_hash=null;
			actionInfo=null;
			clazz=null;
			obj=null;
			methodToCall=null;			
			}
	}
}
