
package telemune.engine.backend.common;

/**
 * This is pojo class used to set variables received from CRE interface
 * */
public class SetVariableRE
{
	private int reqId=0;
	private int actId=0;
	private int priority=0;
	
	public int getReqId() {
		return reqId;
	}
	public void setReqId(int reqId) {
		this.reqId = reqId;
	}
	public int getActId() {
		return actId;
	}
	public void setActId(int actId) {
		this.actId = actId;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}

	
	
	private String msisdn = "";
	private String desc = "";
	private String dated = "";
	private String pwd = "";
        /**
         * 
         */
        public String fmsisdn = "";
        /**
         * 
         */
        public String subType = "";
        /**
         * 
         */
        public String updatedBy = "";
	private int langId;
	private int catId;
	private int planId;
	private int duration;
	private int locId;
	private int roomId;
	private int isSub=0;
	private int songId;
        private String referenceId="NA";
        /**
         * 
         */
        public int rbtCode;
        /**
         * 
         */
        public String days = "";
        /**
         * 
         */
        public int startTime;
        /**
         * 
         */
        public int endTime;
        /**
         * 
         */
        public int checkRbt;
        /**
         * 
         */
        public int groupId;
        /**
         * 
         */
        public String date = "";
        /**
         * 
         */
        public String rbtPath = "";
        /**
         * 
         */
        public int albumId;
        /**
         * 
         */
        public int callId;
	//public int chkRbt;
        /**
         * 
         */
        public String albumName = "";
        /**
         * 
         */
        public String name = "";
        /**
         * 
         */
        public String groupName = "";
        /**
         * 
         */
        public String controlName = "";
        /**
         * 
         */
        public String occName = "";
        /**
         * 
         */
        public String gender="M";
        /**
         * 
         */
        public int age=0;
        /**
         * 
         */
        public int reason=0;
        private String tpin= "9999";
        /**
         * 
         */
        public int requestCount;
        /**
         * 
         */
        public String defaultValue="";
        
        //ADDED FOR CRBTSMS
        
	private int groupID;
	private int albumID;
	//private String friendMsisdn;
	private String advop;
	private String interfaceName;
	private boolean subscribeFlag;
        private String planName;
        private int packId;
                                
        /**
         * 
         */
        public SetVariableRE()
	{
	 msisdn = "";
	 desc = "";
	 dated = "";
	 pwd = "";
	fmsisdn = "";
	subType = "";
	updatedBy = "";
	langId=0;
	catId=0;
	planId=0;
	duration=0;
	locId=0;
	roomId=0;
	isSub=0;
	songId=0;
	rbtCode=-1;
	 days = "";
	startTime=0;
	 endTime=0;
         checkRbt=0;
        groupId=-1;
	date = "";
	rbtPath = "";
	albumId=-1;
	callId=-1;
	//public int chkRbt;
	albumName = "";
	 name = "";
	groupName = "";
	controlName = "";
	occName = "";
	 gender="M";
	age=0;
	reason=0;
        tpin= "9999";
        requestCount=-1;
        defaultValue="";
        planName="DEFAULT";
        
        //ADDED FOR CRBTSMS

	groupID=-1;
	albumID=-1;
	//friendMsisdn="";
	advop="";
	interfaceName="NA";
	subscribeFlag=false;
        packId=-1;
        referenceId="NA";
	}
        
    public String toString()
    {
        return " msisdn ["+msisdn+"] fmsisdn ["+fmsisdn+"] subType ["+subType+"] updatedBy "+updatedBy+" langId "+langId+""
                + "catId "+catId+" planId ["+planId+"] songId ["+songId+"] rbtCode ["+rbtCode+"] days ["+days+"] startTime ["+startTime+"]"
                + "endTime ["+endTime+"] checkRbt "+checkRbt+" groupId "+groupId+" date "+date+" rbtPath "+rbtPath+" albumId "+albumId+" albumName "+albumName+""
                + "groupName ["+groupName+"] controlName ["+controlName+"]  occName "+occName+" planName ["+planName+"] groupID ["+groupID+"] packId ["+packId+"] referenceId ["+referenceId+"]";
        
    }

    public int getPackId() {
        return packId;
    }

    public void setPackId(int packId) {
        this.packId = packId;
    }
        

    
    public String getPlanName() {
        return planName;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

        
        /**
         * 
         * @return
         */
        public String getAdvop() {
            
        return advop;
    }

    /**
     * 
     * @param advop
     */
    public void setAdvop(String advop) {
        this.advop = advop;
    }

    /**
     * 
     * @return
     */
    public int getAge() {
        return age;
    }

    /**
     * 
     * @param age
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * 
     * @return
     */
    public int getAlbumID() {
        return albumID;
    }

    /**
     * 
     * @param albumID
     */
    public void setAlbumID(int albumID) {
        this.albumID = albumID;
    }

    /**
     * 
     * @return
     */
    public int getAlbumId() {
        return albumId;
    }

    /**
     * 
     * @param albumId
     */
    public void setAlbumId(int albumId) {
        this.albumId = albumId;
    }

    /**
     * 
     * @return
     */
    public String getAlbumName() {
        return albumName;
    }

    /**
     * 
     * @param albumName
     */
    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    /**
     * 
     * @return
     */
    public int getCallId() {
        return callId;
    }

    /**
     * 
     * @param callId
     */
    public void setCallId(int callId) {
        this.callId = callId;
    }

    /**
     * 
     * @return
     */
    public int getCatId() {
        return catId;
    }

    /**
     * 
     * @param catId
     */
    public void setCatId(int catId) {
        this.catId = catId;
    }

    /**
     * 
     * @return
     */
    public int getCheckRbt() {
        return checkRbt;
    }

    /**
     * 
     * @param checkRbt
     */
    public void setCheckRbt(int checkRbt) {
        this.checkRbt = checkRbt;
    }

    /**
     * 
     * @return
     */
    public String getControlName() {
        return controlName;
    }

    /**
     * 
     * @param controlName
     */
    public void setControlName(String controlName) {
        this.controlName = controlName;
    }

    /**
     * 
     * @return
     */
    public String getDate() {
        return date;
    }

    /**
     * 
     * @param date
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * 
     * @return
     */
    public String getDated() {
        return dated;
    }

    /**
     * 
     * @param dated
     */
    public void setDated(String dated) {
        this.dated = dated;
    }

    /**
     * 
     * @return
     */
    public String getDays() {
        return days;
    }

    /**
     * 
     * @param days
     */
    public void setDays(String days) {
        this.days = days;
    }

    /**
     * 
     * @return
     */
    public String getDefaultValue() {
        return defaultValue;
    }

    /**
     * 
     * @param defaultValue
     */
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    /**
     * 
     * @return
     */
    public String getDesc() {
        return desc;
    }

    /**
     * 
     * @param desc
     */
    public void setDesc(String desc) {
        this.desc = desc;
    }

    /**
     * 
     * @return
     */
    public int getDuration() {
        return duration;
    }

    /**
     * 
     * @param duration
     */
    public void setDuration(int duration) {
        this.duration = duration;
    }

    /**
     * 
     * @return
     */
    public int getEndTime() {
        return endTime;
    }

    /**
     * 
     * @param endTime
     */
    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    /**
     * 
     * @return
     */
    public String getFmsisdn() {
        return fmsisdn;
    }

    /**
     * 
     * @param fmsisdn
     */
    public void setFmsisdn(String fmsisdn) {
        this.fmsisdn = fmsisdn;
    }

    /**
     * 
     * @return
     */
    /*public String getFriendMsisdn() {
        return friendMsisdn;
    }*/

    /**
     * 
     * @param friendMsisdn
     */
    /*public void setFriendMsisdn(String friendMsisdn) {
        this.friendMsisdn = friendMsisdn;
    }*/

    /**
     * 
     * @return
     */
    public String getGender() {
        return gender;
    }

    /**
     * 
     * @param gender
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * 
     * @return
     */
    public int getGroupID() {
        return groupID;
    }

    /**
     * 
     * @param groupID
     */
    public void setGroupID(int groupID) {
        this.groupID = groupID;
    }

    /**
     * 
     * @return
     */
    public int getGroupId() {
        return groupId;
    }

    /**
     * 
     * @param groupId
     */
    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    /**
     * 
     * @return
     */
    public String getGroupName() {
        return groupName;
    }

    /**
     * 
     * @param groupName
     */
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    /**
     * 
     * @return
     */
    public String getInterfaceName() {
        return interfaceName;
    }

    /**
     * 
     * @param interfaceName
     */
    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    /**
     * 
     * @return
     */
    public int getIsSub() {
        return isSub;
    }

    /**
     * 
     * @param isSub
     */
    public void setIsSub(int isSub) {
        this.isSub = isSub;
    }

    /**
     * 
     * @return
     */
    public int getLangId() {
        return langId;
    }

    /**
     * 
     * @param langId
     */
    public void setLangId(int langId) {
        this.langId = langId;
    }

    /**
     * 
     * @return
     */
    public int getLocId() {
        return locId;
    }

    /**
     * 
     * @param locId
     */
    public void setLocId(int locId) {
        this.locId = locId;
    }

    /**
     * 
     * @return
     */
    public String getMsisdn() {
        return msisdn;
    }

    /**
     * 
     * @param msisdn
     */
    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    /**
     * 
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * 
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 
     * @return
     */
    public String getOccName() {
        return occName;
    }

    /**
     * 
     * @param occName
     */
    public void setOccName(String occName) {
        this.occName = occName;
    }

    /**
     * 
     * @return
     */
    public int getPlanId() {
        return planId;
    }

    /**
     * 
     * @param planId
     */
    public void setPlanId(int planId) {
        this.planId = planId;
    }

    /**
     * 
     * @return
     */
    public String getPwd() {
        return pwd;
    }

    /**
     * 
     * @param pwd
     */
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    /**
     * 
     * @return
     */
    public int getRbtCode() {
        return rbtCode;
    }

    /**
     * 
     * @param rbtCode
     */
    public void setRbtCode(int rbtCode) {
        this.rbtCode = rbtCode;
    }

    /**
     * 
     * @return
     */
    public String getRbtPath() {
        return rbtPath;
    }

    /**
     * 
     * @param rbtPath
     */
    public void setRbtPath(String rbtPath) {
        this.rbtPath = rbtPath;
    }

    /**
     * 
     * @return
     */
    public int getReason() {
        return reason;
    }

    /**
     * 
     * @param reason
     */
    public void setReason(int reason) {
        this.reason = reason;
    }

    /**
     * 
     * @return
     */
    public int getRequestCount() {
        return requestCount;
    }

    /**
     * 
     * @param requestCount
     */
    public void setRequestCount(int requestCount) {
        this.requestCount = requestCount;
    }

    /**
     * 
     * @return
     */
    public int getRoomId() {
        return roomId;
    }

    /**
     * 
     * @param roomId
     */
    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    /**
     * 
     * @return
     */
    public int getSongId() {
        return songId;
    }

    /**
     * 
     * @param songId
     */
    public void setSongId(int songId) {
        this.songId = songId;
    }

    /**
     * 
     * @return
     */
    public int getStartTime() {
        return startTime;
    }

    /**
     * 
     * @param startTime
     */
    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    /**
     * 
     * @return
     */
    public String getSubType() {
        return subType;
    }

    /**
     * 
     * @param subType
     */
    public void setSubType(String subType) {
        this.subType = subType;
    }

    /**
     * 
     * @return
     */
    public boolean isSubscribeFlag() {
        return subscribeFlag;
    }

    /**
     * 
     * @param subscribeFlag
     */
    public void setSubscribeFlag(boolean subscribeFlag) {
        this.subscribeFlag = subscribeFlag;
    }

   
    /**
     * 
     * @return
     */
    public String getTpin() {
        return tpin;
    }

    /**
     * 
     * @param tpin
     */
    public void setTpin(String tpin) {
        this.tpin = tpin;
    }

    /**
     * 
     * @return
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * 
     * @param updatedBy
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
        
        
        
        
        
                                
}

