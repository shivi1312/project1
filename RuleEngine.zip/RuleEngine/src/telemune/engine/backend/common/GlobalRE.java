package telemune.engine.backend.common;

import java.net.Socket;
import java.util.Hashtable;
import java.util.concurrent.ArrayBlockingQueue;

import FileBaseLogging.FileLogWriter;

/**
 *THIS CLASS IS FOR DEFINE THE VARIALE STATICALLY AND GLOBALLY
 */
public class GlobalRE 
{
   //public static ConnPool conPool=null;
	public static int max_limit=1000;
	public static int cntrcheck= 0;
	static String startClass="";
	static String fxnsClass=""; 
	//static String appJar="";
	static String hlrJar="";
	static String chargingJar="";
	static int hlrActive=0;
	static int chargingActive=0;
	
	
	static String start_state="START_STATE_INIT";
	static String callback_state="CALLBACK_INIT";
	static String end_event="endState";
	static String unknown_event="handleUnknownEvent";
	static String exception_error="#ERROR>>"; 
	
	
	public static Hashtable msisdn_map=new Hashtable<String,Socket>();
	public static  ArrayBlockingQueue<DataObjectRE> que=new ArrayBlockingQueue<DataObjectRE>(100000);
	
	public static  FileLogWriter error_flw = null;
	public static Hashtable state_cache=null;
	public static Hashtable<String,String> property_map=null;

	public static CacheLoaderRE cacheLoaderRE=null;
	
	// Added by rahul kumar on 17/03/2018
	static String crbtGlobals=""; 
    public static synchronized void rst( boolean rst)
	{
		if(rst)
			cntrcheck=0;
		else
			cntrcheck++;

	}

}
