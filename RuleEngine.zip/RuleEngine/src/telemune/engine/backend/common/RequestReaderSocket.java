
package telemune.engine.backend.common;

import java.io.DataInputStream;
import java.io.EOFException;
import java.net.Socket;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonParser;

import FileBaseLogging.FileLogWriter;
import commonutil.TLVParameters;

/**
 * THIS CLASS IS FOR READING THE REQUEST FROM CLIENT ON PARTICULAR DEFINE PORT AND THEN INSERT THE DATA INTO THE QUEUE
 *@author :- PANKAJ GUPTA
 **/
class RequestReaderSocket implements Runnable
{
	String name;
	Thread thrd;
	Socket socket_me;
	DataInputStream reader = null;
	static Logger logger=Logger.getLogger("RequestReaderSocket");
	ResponseSender responseSender=null;
	FileLogWriter error_flw=null;
	private String requestData;
	private Gson gson = new Gson();
	private JsonParser jsonParser = new JsonParser();

	/**
	 *THIS IS THE PARAMETERIZED CONSTRUCTOR OF REQUEST READER
	 *@param name :- REFERS TO THE NAME OF THE THREAD WHICH ARE RUNNING
	 *@param socket :- REFERS TO THR SOCKET ON WHCIH SERVER ACCEPTOR IS LISTENING THE REQUEST COMMING FROM CLIENT
	 */
	RequestReaderSocket(String name,Socket socket)
	{
		thrd = new Thread(this,name);
		this.name = name;
		socket_me = socket;
		this.error_flw=GlobalRE.error_flw;
		logger.info("\nintializing thread to recv data: #" + name );
		responseSender=new ResponseSender();
	}
	/**
	 *THIS IS THE RUN FUNCTION OF THE THREAD RequestReader WHICH CALL THE FUNCTION getfromclient().....FOR GETTING THE DATA FROM CLIENT
	 */
	public void run()
	{
		logger.info("\nstarted thread to recv data: #" + name );
		getfromclient(name,socket_me);
	}
	/**
	 *THIS FUNCTION IS FOR GETTING THE DATA FROM CLIENT BY RECIEVING THE DATA AT THE DEFINE PORT 
	 *@param name :- REFERS TO THE THREAD NAME
	 *@param socket_me :- REFERS TO THE SOCKET ON WHICH APP GET THE DATA FROM CLIENT
	 *THIS CLASS BASICALLY MAINTAIN THE TCP/IP CONNECTION FROM CLIENT AND READ THE REQUEST FROM CLIENT
	 */
	public void getfromclient(String name,Socket socket_me)
	{
		try{
			reader = new DataInputStream(socket_me.getInputStream());}
		catch(Exception e)
		{	
			logger.error(GlobalRE.exception_error+"in getting the data input stream from socket",e);
		}
		logger.info("\nPreparing to recv  data thread# "+ name);
		try
		{
			while(true)
			{

				if (socket_me.isClosed())
				{
					logger.debug(GlobalRE.exception_error+"Socket closed : ["+socket_me+"]");
					thrd.stop();
					return;
				}
				else
				{	
					try{
						requestData = reader.readUTF();
					}catch (EOFException e) {
						break;
					}
					logger.info("Received data from plain Socket is ["+requestData+"]");
					try
					{

						logger.debug("reading Info ......starts.");
						if(requestData.length()<=0)
						{
							logger.warn("reader.read == -1 ...");
							try
							{
								socket_me.close();
								logger.warn("Destroy || socket closed");
								thrd.stop();
								return;
							}
							catch(Exception e)
							{
								logger.error(GlobalRE.exception_error+"in closing the socket in RequestReader",e);
							}

						}
						logger.debug("reading Info ......end.");
						logger.info("reading Info ......data len.."+requestData.length());
					}
					catch (Exception e)
					{
						logger.fatal(GlobalRE.exception_error+"Getting exception in reading datalen....",e);
						try
						{
							thrd.sleep(1);
							socket_me.close();

						}
						catch(Exception eee)
						{
							logger.fatal(GlobalRE.exception_error+"Thread Sleep Exception in main");
						}	
					}
					if (requestData.length()<=0)
					{	
						try
						{
							logger.info("Sleeping.....n");
							continue;//thrd.sleep(10);
						}
						catch(Exception eee)
						{
							logger.info("Sleep Exception in main");
						}
					}

					logger.info("recieved tcp_req size="+requestData.length());

					TLVParameters tcp_req =null;
					DataObjectRE dataObjectRE=null;

					try{
						if(isJson(requestData))
						{
							tcp_req =new TLVParameters();
							setTLVParams(tcp_req, requestData);

							dataObjectRE=new DataObjectRE();
							dataObjectRE.sock=socket_me;
							dataObjectRE.tlv_params=tcp_req;
							dataObjectRE.requestMedia=RETags.socket;

							if(tcp_req.getData(RETags.MSISDN)!=null)
							{
								dataObjectRE.msisdn=tcp_req.getData(RETags.MSISDN);							
							}
							if(tcp_req.getData(RETags.ACTION)!=null)
							{
								dataObjectRE.actionId=Integer.parseInt(tcp_req.getData(RETags.ACTION));						
							}

							dataObjectRE.logPrefix=dataObjectRE.msisdn;//For logging purpose

							logger.info(dataObjectRE.getLogLine()+"got the request");
							if(GlobalRE.msisdn_map.containsKey(dataObjectRE.msisdn)){
								logger.info(dataObjectRE.getLogLine()+"Request already in process,So nothing to process. please try later...");
								dataObjectRE.tlv_params.setData(RETags.RESPONSE_CODE,ErrorCodesRE.REQUEST_ALREADY_IN_PROCESS_CODE);
								dataObjectRE.tlv_params.setData(RETags.RESPONSE_STRING,ErrorCodesRE.REQUEST_ALREADY_IN_PROCESS);
								responseSender.sendtoclient(dataObjectRE);						
							}else{
								GlobalRE.msisdn_map.put(dataObjectRE.msisdn,dataObjectRE.sock);
								logger.debug(dataObjectRE.getLogLine()+"data added in global que and msisdn map , msisdn record size :["+GlobalRE.msisdn_map.size()+"]");
								GlobalRE.que.put (dataObjectRE);
							}
						}
						else{
							logger.error(GlobalRE.exception_error+"requestData is not JSON , so cannot process the request");
						}
					}catch (Exception e) {
						logger.error(GlobalRE.exception_error+" in reading the data to corresponding datalen ["+requestData.length()+"] or in decoding and setting it to DataObject bean",e);
					}
					finally{
						tcp_req=null;
						dataObjectRE=null;
						requestData=null;
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error(GlobalRE.exception_error+"got exception in RequestReader.",e);		
		}		
	}

	/**
	 * This function is responsible to check that whether passed string is json or not
	 * */
	public boolean isJson(String requestData) {
		try {
			//gson.fromJson(requestData, Object.class);	
			if(jsonParser.parse(requestData).isJsonArray() || jsonParser.parse(requestData).isJsonObject())
			{
				return true;
			}
			return false;
		} catch (Exception ex) {
			logger.error(GlobalRE.exception_error+" in isJson() : ",ex);
			return false;
		}
	}
/**
 * This function is responsible for setting the extracted request data into TLV params
 * */
	public void setTLVParams(TLVParameters tlvParameters,String requestData)
	{
		try{
			tlvParameters.setData(RETags.MSISDN,jsonParser.parse(requestData).getAsJsonObject().get("msisdn").getAsString());
			tlvParameters.setData(RETags.ACTION,jsonParser.parse(requestData).getAsJsonObject().get("actionId").getAsString());			
			tlvParameters.setData(RETags.REQUEST_DATA_JSON,requestData);
		} catch (Exception ex) {
			logger.error(GlobalRE.exception_error+" in setTLVParams() : ",ex);
		}
	}
}

