/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package telemune.engine.backend.common;

import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

/**
 *THIS CLASS IS FOR HANDLING THE REJECTED WORK 
 * @author Pankaj
 * THIS CLASS IS HANDLE THAT REQUEST WHEN ALL THE THREAD ARE OPEN AND WORKING AND ALSO QUEUE IS FULL THEN THIS CLASS HANDLE THAT 
 * SITUATION BY WAAITING THE THAT REQUEST FOR A SECOND AND AGAIN TRY TO EXECUTE
 */
public class RejectedWorkHandler implements RejectedExecutionHandler{
 
	static Logger logger = Logger.getLogger("RejectedWorkHandler");
    
	/**
	 * This Takes the rejected task and put that back in queue after sometime
	 * */
  @Override
    public void rejectedExecution(Runnable r, ThreadPoolExecutor executor)  {
        logger.warn("TASK IS REJECTED BECOZ ,MAX THREAD IS OPEN  and WORKING QUEUE IS ALREDY FULL , SO WAIT FOR 1 SECOND  and AGAIN TRY TO EXECUTE : (To avoid this problem increase Number of thread(Best Option) or Increase  Working queue size)"+r.toString());

	    try {
		    Thread.sleep(1);
		    logger.info("Lets Try another time : "+Thread.currentThread().getName());
	    } catch (InterruptedException e) {
	    	logger.error("exception inside  rejected task "+e);
        }
           try{
               executor.execute(r);
           }
           catch(RejectedExecutionException re){

           logger.error("Problem In  Submitting task because Its too late processing, Please check your Processing time of Server(Good Option) or increase thread pool queue size(Bad Option) ",re);
           }
    }
}
