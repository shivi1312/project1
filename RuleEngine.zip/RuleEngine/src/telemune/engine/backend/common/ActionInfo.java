package telemune.engine.backend.common;

/**
 * THIS IS THE POJO CLASS WHICH LOADS THE DATA OF STATE MACHINE FILE
 * */
public class ActionInfo {
	public String className;
	public String methodName;
	public String nextState;
	public String nextEvent;
	
	@Override
	public String toString() {
		return "ActionInfo [className=" + className + ", methodName="
				+ methodName + ", nextState=" + nextState + ", nextEvent="
				+ nextEvent + "]";
	}
	
	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public String getNextState() {
		return nextState;
	}

	public void setNextState(String nextState) {
		this.nextState = nextState;
	}

	public String getNextEvent() {
		return nextEvent;
	}

	public void setNextEvent(String nextEvent) {
		this.nextEvent = nextEvent;
	}

	
}
