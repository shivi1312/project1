/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package telemune.engine.backend.common;


import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import FileBaseLogging.FileLogWriter;



/**
 * THIS CLASS MANAGE THE THREAD POOL OF ExecuterThread THREAD 
 * @author Pankaj Gupta
 * */
public class ExecuterThreadPoolManager implements Runnable {

	static Logger logger = Logger.getLogger("ExecuterThreadPoolManager");
	ThreadPoolExecutor executorPool = null;
	static FileLogWriter error_flw = null;
	
	

	/**
	 *THIS IS THE CONSTRUCTOR OF ContentThreadPoolManager IN WHICH WE INITIALIZE THE ESSENTIAL VARIABLES
	 *@param poolExecutor :- REFERS TO THE ThreadPoolExecutor OBJECT USED TO EXECUTE THE ExceuterThread THREAD	
	 */
	public ExecuterThreadPoolManager(ThreadPoolExecutor poolExecutor)
	{
		this.executorPool=poolExecutor;
		this.error_flw=GlobalRE.error_flw;		
	}
	/**
	 *
	 *THIS RUN METHOD READ THE GLOBAL QUEUE AND GET THE DATA FOR EXECUTER THREAD
	 *ALSO MANAGE THE MULTIPLE THREADS USING THE THREAD POOL
	 */
	public void run() {

		try{
			while (true) {


				if (GlobalRE.que.isEmpty()) {
					try {
						Thread.sleep(1);
						GlobalRE.rst(true);
					} catch (Exception se) {
						logger.error(GlobalRE.exception_error+"in ContentThreadPoolManager while sleeping thread",se);
					}

				}
				else{
					DataObjectRE dataObjectRE=null;
					try{

						logger.debug("THREAD POOL FOUND REQUEST TO PROCESS ");
						dataObjectRE=(DataObjectRE)GlobalRE.que.poll();
						logger.info(dataObjectRE.getLogLine()+"passing request to executer thread for execution having REQUEST_COUNT ["+GlobalRE.cacheLoaderRE.updateAndGetAppCounter()+"]");
						//logger.info(dataObjectRE.getLogLine()+"passing request to executer thread for execution");
						executorPool.execute(new ExecutorThread(dataObjectRE));
					}
					catch(Exception e){
						logger.error(GlobalRE.exception_error+"ContentThreadPoolManager request queue is already full ... so No more request can be taken.. discarding this request",e);
						//dataObject.response_data="-1";
						//global.que_send.put(dataObject);
						//System.exit(1);
						break;
					}

				}

			}//while(true)

		}
		catch(Exception e){

			logger.error(GlobalRE.exception_error+"In ContentThreadPoolManager run()",e);
		}

	}//run()


}


