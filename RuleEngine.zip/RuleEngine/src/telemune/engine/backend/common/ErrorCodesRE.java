package telemune.engine.backend.common;

/**
 * THIS INTERFACE IS USED FOR GENERATING ERROR CODES OR ERROR STRING FOR THE ERROR RESPONSE 
 */
public interface ErrorCodesRE {
	String REQUEST_ALREADY_IN_PROCESS="request is already in process. please try later";
	String UNKNOWN="Some error Occured, Please try later";
	int REQUEST_ALREADY_IN_PROCESS_CODE=-37;
	
}
