
package telemune.engine.backend.common;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.net.Socket;

import org.apache.log4j.Logger;

import FileBaseLogging.FileLogWriter;
import commonutil.TLVParameters;

/**
 * THIS CLASS IS FOR READING THE REQUEST FROM CLIENT ON PARTICULAR DEFINE PORT AND THEN INSERT THE DATA INTO THE QUEUE
 *@author :- PANKAJ GUPTA
 *   
 */
class RequestReaderTLV implements Runnable
{
	String name;
	Thread thrd;
	Socket socket_me;
	DataInputStream reader = null;
	static Logger logger=Logger.getLogger("RequestReaderTLV");
	ResponseSender responseSender=null;
	FileLogWriter error_flw=null;

	/**
	 *THIS IS THE PARAMETERIZED CONSTRUCTOR OF REQUEST READER
	 *@param name :- REFERS TO THE NAME OF THE THREAD WHICH ARE RUNNING
	 *@param socket :- REFERS TO THR SOCKET ON WHCIH SERVER ACCEPTOR IS LISTENING THE REQUEST COMMING FROM CLIENT
	 */
	RequestReaderTLV(String name,Socket socket)
	{
		thrd = new Thread(this,name);
		this.name = name;
		socket_me = socket;
		this.error_flw=GlobalRE.error_flw;
		logger.info("\nintializing thread to recv data: #" + name );
		responseSender=new ResponseSender();
	}
	/**
	 *THIS IS THE RUN FUNCTION OF THE THREAD RequestReader WHICH CALL THE FUNCTION getfromclient().....FOR GETTING THE DATA FROM CLIENT
	 */
	public void run()
	{
		logger.info("\nstarted thread to recv data: #" + name );
		getfromclient(name,socket_me);
	}
	/**
	 *THIS FUNCTION IS FOR GETTING THE DATA FROM CLIENT BY RECIEVING THE DATA AT THE DEFINE PORT 
	 *@param name :- REFERS TO THE THREAD NAME
	 *@param socket_me :- REFERS TO THE SOCKET ON WHICH APP GET THE DATA FROM CLIENT
	 *THIS CLASS BASICALLY MAINTAIN THE TCP/IP CONNECTION FROM CLIENT AND READ THE REQUEST FROM CLIENT
	 */
	public void getfromclient(String name,Socket socket_me)
	{
		try{
			reader = new DataInputStream(socket_me.getInputStream());}
		catch(Exception e)
		{	
			logger.error(GlobalRE.exception_error+"in getting the data input stream from socket",e);
		}
		logger.info("\nPreparing to recv  data thread# "+ name);
		try
		{
			while(true)
			{

				if (socket_me.isClosed())
				{
					logger.debug(GlobalRE.exception_error+"Socket closed : ["+socket_me+"]");
					thrd.stop();
					return;
				}
				else
				{	
					ByteArrayInputStream inbuf = null;
					//logger.info("reading Info ........");
					//logger.info("Socket==="+socket_me.toString());
					byte dataBuf1[] = new byte[4];
					int dataLen =0;
					try
					{

						logger.debug("reading Info ......starts.");
						if(reader.read(dataBuf1,0,4)==-1)
						{
							logger.warn("reader.read == -1 ...");
							try
							{
								socket_me.close();
								logger.warn("Destroy || socket closed");
								thrd.stop();
								return;
							}
							catch(Exception e)
							{
								logger.error(GlobalRE.exception_error+"in closing the socket in RequestReader",e);
							}

						}
						logger.debug("reading Info ......end.");
						int test=0;
						dataLen = dataLen | (dataBuf1[0] << 24);
						dataLen = dataLen  | (dataBuf1[1] << 16);
						dataLen = dataLen | (dataBuf1[2] << 8);
						test=(0x000000ff & dataBuf1[3]);
						dataLen = dataLen | test;
						logger.info("reading Info ......data len.."+dataLen);
					}
					catch (Exception e)
					{
						logger.fatal(GlobalRE.exception_error+"Getting exception in reading datalen....",e);
						try
						{
							thrd.sleep(1);
							socket_me.close();

						}
						catch(Exception eee)
						{
							logger.fatal(GlobalRE.exception_error+"Thread Sleep Exception in main");
						}	
					}
					if (dataLen==0)
					{	try
					{
						logger.info("Sleeping.....n");
						continue;//thrd.sleep(10);
					}
					catch(Exception eee)
					{
						logger.info("Sleep Exception in main");
					}
					}

					logger.info("recieved tcp_req size="+dataLen);

					byte dataBuf[] =null;
					TLVParameters tcp_req =null;
					DataObjectRE dataObjectRE=null;

					try{
						dataBuf = new byte[dataLen];
						reader.read(dataBuf, 0, dataLen);
						inbuf = new ByteArrayInputStream(dataBuf);

						tcp_req =new TLVParameters();
						tcp_req.decode(inbuf,dataLen);

						dataObjectRE=new DataObjectRE();
						dataObjectRE.sock=socket_me;
						dataObjectRE.tlv_params=tcp_req;
						dataObjectRE.requestMedia=RETags.tlv;
						if(tcp_req.getData(RETags.MSISDN)!=null)
						{
							dataObjectRE.msisdn=tcp_req.getData(RETags.MSISDN);							
						}
						if(tcp_req.getData(RETags.ACTION)!=null)
						{
							dataObjectRE.actionId=Integer.parseInt(tcp_req.getData(RETags.ACTION));						
						}
						
						dataObjectRE.logPrefix=dataObjectRE.msisdn;//For logging purpose
						
						logger.info(dataObjectRE.getLogLine()+"got the request");
						if(GlobalRE.msisdn_map.containsKey(dataObjectRE.msisdn)){
							logger.info(dataObjectRE.getLogLine()+"Request already in process,So nothing to process. please try later...");
							dataObjectRE.tlv_params.setData(RETags.RESPONSE_CODE,ErrorCodesRE.REQUEST_ALREADY_IN_PROCESS_CODE);
							dataObjectRE.tlv_params.setData(RETags.RESPONSE_STRING,ErrorCodesRE.REQUEST_ALREADY_IN_PROCESS);
							responseSender.sendtoclient(dataObjectRE);						
						}else{
							GlobalRE.msisdn_map.put(dataObjectRE.msisdn,dataObjectRE.sock);
							logger.debug(dataObjectRE.getLogLine()+"data added in global que and msisdn map , msisdn record size :["+GlobalRE.msisdn_map.size()+"]");
							GlobalRE.que.put (dataObjectRE);
						}
					}catch (Exception e) {
						logger.error(GlobalRE.exception_error+" in reading the data to corresponding datalen ["+dataLen+"] or in decoding and setting it to DataObject bean",e);
					}
					finally{
						dataBuf=null;
						tcp_req=null;
						dataObjectRE=null;
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error(GlobalRE.exception_error+"got exception in RequestReader.",e);		
		}		
	}
}

