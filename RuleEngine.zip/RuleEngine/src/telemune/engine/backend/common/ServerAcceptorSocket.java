

package telemune.engine.backend.common;

import java.net.ServerSocket;
import java.net.Socket;

import org.apache.log4j.Logger;


/**
 * THIS CLASS IS FOR MAKING THE TCP/IP CONNECTION FROM CLIENT
 *@author :- PANKAJ GUPTA
 * 
 */
public class ServerAcceptorSocket implements Runnable 
{
	Thread temp;
	Thread threq=null;
	ServerSocket server_socket = null;
	static Logger logger=Logger.getLogger("ServerAcceptorSocket");
	int port=-1;
	/**
	 * This is the constructor of ServerAccepter
	 * @param port to which socket has to listen
	 * */
	ServerAcceptorSocket(int port)
	{
		this.port=port;
	}
	/**
	 * This is the run method of ServerAccepter which get called  
	 * whenever its thread is started
	 * */
	public void run()
	{
		try 
		{
			temp=new Thread();
			try
			{
				server_socket = new ServerSocket(port);
				logger.info("##>>Server[Socket] waiting for client on port [" +server_socket.getLocalPort()+"]");
			}
			catch(Exception ee)
			{
				logger.fatal(GlobalRE.exception_error+" in creating new ServerSocket Object in thread",ee);
				return;
			}
			while(true)
			{
				Socket socket=null;
				try
				{
					socket = server_socket.accept();
					logger.info("##>>Connection accepted response " +
							socket.getInetAddress() +
							":" + socket.getPort());
				}
				catch(Exception ee)
				{
					logger.fatal(GlobalRE.exception_error+" in accepting SOCKET request exception in thread ",ee);
				}
				try
				{
					logger.info("##########started RequestReader thread########################");
					RequestReaderSocket obj_get_data = new RequestReaderSocket("threadCheckRequest"+socket.toString(),socket);
					threq=new Thread(obj_get_data);
					threq.start();

				}
				catch(Exception e)
				{
					logger.fatal(GlobalRE.exception_error+" in opening RequestReader thread",e);
					try
					{
						socket.close();
					}
					catch(Exception es)
					{
						logger.error(GlobalRE.exception_error+" in closing the socket",es);
					}
				}
				try
				{
					temp.sleep(1);
				}
				catch(Exception eee)
				{
					logger.error(GlobalRE.exception_error+" Sleep Exception in ServerAccepter",eee);
				}	
			}

		} 
		catch (Exception e) 
		{
			logger.error(GlobalRE.exception_error+" in run method",e);
		}
		finally
		{
			try
			{
				server_socket.close();
				logger.debug(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>All Threads  stopped in ServerAccpter<<<<<<<<<<<<<<<<<<<<<<<<");				
			}
			catch(Exception e)
			{
				logger.error(GlobalRE.exception_error+" server socket not closed and Threads cannot stoped: ",e);
			}
		}

	}
}
