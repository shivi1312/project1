
package telemune.engine.backend.common;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonParser;

import FileBaseLogging.FileLogWriter;
import commonutil.TLVAppInterface;
import commonutil.TLVParameters;
import commonutil.TssStringUtill;

/**
 *THIS CLASS IS FOR SENDING THE RESPONSE TO THE CLIENT BY READING THE INFORMATION FROM RESPONSE QUEUE
 *@author :- PANKAJ GUPTA
 *
 */
class ResponseSender 
{
	String name;
	//static Thread thrd;
	Socket socket_me;
	DataOutputStream stream_send_data;
	static FileLogWriter error_flw=null;
	static Logger logger=Logger.getLogger("ResponseSender");
	private Gson gson = new Gson();
	private JsonParser jsonParser = new JsonParser();

	/**
	 *THIS IS THE CONSTRUCTOR OF THE CLASS ResponseSender IN WHCIH WE ARE INITIALIZING THE PARAMETERS
	 *@param error_log :- REFERS TO THE OBJECT OF FILE LOG WRITER
	 */
	public ResponseSender()
	{
		this.error_flw=GlobalRE.error_flw;		
	}

	public void stop()
	{

	}
	//public void sendtoclient(String name,Socket socket_me)
	/**
	 *THIS FUNCTION IS FOR SENDING THE RESPONSE TO THE CLIENT BY READING THE RESPONSE QUEUE 
	 *@param DataObjectRE :- REFERS TO THE Bean name which contain details of request 
	 *this function basically calls the function to send the data to the client depending upon the type of interface used whether TLV or CRE.
	 */	

	public void sendtoclient(DataObjectRE dataObjectRE)
	{
		try
		{
			logger.info(dataObjectRE.getLogLine()+"sending response.............. requestMedia ["+dataObjectRE.requestMedia+"]");
			if(dataObjectRE.requestMedia.equals(RETags.tlv))
			{
				sendtoclientTLV(dataObjectRE);
			}	
			else if(dataObjectRE.requestMedia.equals(RETags.cre))
			{
				sendtoclientCRE(dataObjectRE);
			}
			else if(dataObjectRE.requestMedia.equals(RETags.socket))
			{
				sendtoclientSocket(dataObjectRE);
			}
			else if(dataObjectRE.requestMedia.equals(RETags.renew))
			{
				sendToClientRenewEngine(dataObjectRE);
			}
			else{
				logger.error(dataObjectRE.getLogLine()+"Invalid request media found");
			}
		}
		catch(Exception e)
		{
			logger.warn(GlobalRE.exception_error+"in sendtoclient()",e);			
		}
		finally
		{
			try{
				GlobalRE.msisdn_map.remove(dataObjectRE.msisdn);
				dataObjectRE=null;
				//logger.debug(dataObjectRE.getLogLine()+"data deleted msisdn map now size :["+GlobalRE.msisdn_map.size()+"]");
			}
			catch (Exception e) {
				logger.error(GlobalRE.exception_error+"in removing data from the record in sendtoclient()",e);
			}

		}
	}

	/**
	 *THIS FUNCTION IS FOR SENDING THE RESPONSE TO THE CLIENT BY READING THE RESPONSE QUEUE 
	 *@param DataObjectRE :- REFERS TO THE Bean name which contain details of request 
	 *this function basically send response to the client on the port where client is listening over TLV Interface
	 */

	public void sendtoclientTLV(DataObjectRE dataObjectRE)
	{
		logger.info(dataObjectRE.getLogLine()+"sending response..............");
		try
		{
			Socket sock=null;
			sock=dataObjectRE.sock;
			logger.debug(dataObjectRE.getLogLine()+"sending request to socket sendtoclientTLV() : ["+dataObjectRE.sock+"]");

			TLVParameters send_request =dataObjectRE.tlv_params; 
			ByteArrayOutputStream send_buf = new ByteArrayOutputStream();
			send_request.encode(send_buf);

			int send_requestLen = send_buf.size();
			try{

				if (sock.isClosed())
				{
					// write data in file
					logger.debug(dataObjectRE.getLogLine()+"scoket is closed for this request");
					error_flw.writeLog("socket is closed for request sendtoclientTLV() || msisdn : ["+dataObjectRE.msisdn+"] && socket object : ["+dataObjectRE.sock+"]");
					//return;							
				}
				else{
					stream_send_data = new DataOutputStream(sock.getOutputStream());
					logger.debug("writing Info buf size="+send_requestLen);
					byte[] len=new byte[4];
					len[3]=(byte)(send_requestLen );
					len[2]=(byte)((send_requestLen >> 8) );
					len[1]=(byte)((send_requestLen >> 16));
					len[0]=(byte)((send_requestLen >> 24));
					stream_send_data.write(len,0, 4);
					//stream_send_data.writeInt(send_requestLen);
					//System.out.println("Data length sent of  buf size="+send_requestLen);
					stream_send_data.write(send_buf.toByteArray(), 0, send_buf.toByteArray().length);
					//logger.info(data_element.reqid+"#Process Complete="+send_requestLen);
					//total_log.writeLog(data_element.getlog());
					logger.info(dataObjectRE.getLogLine()+"response successfully sent sendtoclientTLV()");
				}						
			}
			catch(IOException eee1)
			{
				logger.fatal(GlobalRE.exception_error+"in Sending Data sendtoclientTLV():: ",eee1);													
			}
			catch(Exception eee)
			{
				logger.fatal(GlobalRE.exception_error+"Exception Sending Data sendtoclientTLV():: "+eee.toString());						
			}					

		}
		catch(Exception e)
		{
			logger.warn(GlobalRE.exception_error+"in sendtoclientTLV()",e);			
		}
	}

	/**
	 *THIS FUNCTION IS FOR SENDING THE RESPONSE TO THE CLIENT BY READING THE RESPONSE QUEUE 
	 *@param DataObjectRE :- REFERS TO THE Bean name which contain details of request 
	 *this function basically send response to the client on the port where client is listening over CRE Interface
	 */

	public void sendtoclientCRE(DataObjectRE dataObjectRE)
	{
		logger.info(dataObjectRE.getLogLine()+"sending response sendtoclientCRE()..............");
		try
		{
			Socket sock=null;
			sock=dataObjectRE.sock;
			logger.debug(dataObjectRE.getLogLine()+"sending request to socket  sendtoclientCRE(): ["+dataObjectRE.sock+"]");

			//TLVParameters send_request =dataObjectRE.tlv_params; 
			//ByteArrayOutputStream send_buf = new ByteArrayOutputStream();
			//send_request.encode(send_buf);


			try{

				if (sock.isClosed())
				{
					// write data in file
					logger.debug(dataObjectRE.getLogLine()+"socket is closed for this request sendtoclientCRE() ");
					error_flw.writeLog("socket is closed for request sendtoclientCRE() || msisdn : ["+dataObjectRE.msisdn+"] && socket object : ["+dataObjectRE.sock+"]");
					//return;							
				}
				else{

					ByteArrayOutputStream send_buf_cre = new ByteArrayOutputStream();
					writeInt(Integer.parseInt(dataObjectRE.tlv_params.getData(RETags.REQID)),send_buf_cre);
					writeInt(Integer.parseInt(dataObjectRE.tlv_params.getData(RETags.ACTION)),send_buf_cre);
					writeInt(Integer.parseInt(dataObjectRE.tlv_params.getData(RETags.RESPONSE_CODE)),send_buf_cre);		
					writeString(dataObjectRE.tlv_params.getData(RETags.RESPONSE_STRING),send_buf_cre);

					int send_requestLen = send_buf_cre.size();
					stream_send_data = new DataOutputStream(sock.getOutputStream());
					logger.debug("writing Info buf size="+send_requestLen);
					byte[] len=new byte[4];
					len[3]=(byte)(send_requestLen );
					len[2]=(byte)((send_requestLen >> 8) );
					len[1]=(byte)((send_requestLen >> 16));
					len[0]=(byte)((send_requestLen >> 24));
					stream_send_data.write(len,0, 4);
					stream_send_data.write(send_buf_cre.toByteArray(), 0, send_buf_cre.toByteArray().length);;
					logger.info(dataObjectRE.getLogLine()+"response successfully sent");
				}						
			}
			catch(IOException eee1)
			{
				logger.fatal(GlobalRE.exception_error+"in Sending Data:: ",eee1);													
			}
			catch(Exception eee)
			{
				logger.fatal(GlobalRE.exception_error+"Exception Sending Data:: "+eee.toString());
			}					

		}
		catch(Exception e)
		{
			logger.warn(GlobalRE.exception_error+"in sendtoclient()",e);			
		}		
	}

	/**
	 * THIS FUNCTION IS FOR SENDING THE RESPONSE TO THE CLIENT VIA PLAIN SOCKET BY READING THE RESPONSE QUEUE 
	 * */
	public void sendtoclientSocket(DataObjectRE dataObjectRE)
	{
		logger.info(dataObjectRE.getLogLine()+"sending response..............");
		try
		{
			Socket sock=null;
			sock=dataObjectRE.sock;
			logger.debug(dataObjectRE.getLogLine()+"sending request to socket sendtoclientSocket() : ["+dataObjectRE.sock+"]");

			TLVParameters send_request =dataObjectRE.tlv_params; 
			ByteArrayOutputStream send_buf = new ByteArrayOutputStream();
			send_request.encode(send_buf);

			int send_requestLen = send_buf.size();
			try{

				if (sock.isClosed())
				{
					// write data in file
					logger.debug(dataObjectRE.getLogLine()+"scoket is closed for this request");
					error_flw.writeLog("socket is closed for request sendtoclientSocket() || msisdn : ["+dataObjectRE.msisdn+"] && socket object : ["+dataObjectRE.sock+"]");
					//return;							
				}
				else{

					if(!TssStringUtill.ValidateParams(dataObjectRE.tlv_params.getData(RETags.RESPONSE_STRING))){
						dataObjectRE.tlv_params.setData(RETags.RESPONSE_STRING,ErrorCodesRE.UNKNOWN);
					}

					if(!isJson((dataObjectRE.tlv_params.getData(RETags.RESPONSE_STRING))))
					{
						dataObjectRE.tlv_params.setData(RETags.RESPONSE_STRING,"{\"message\":\""+ErrorCodesRE.UNKNOWN+"\",\"result\":\"fail\"}");
					}

					stream_send_data = new DataOutputStream(sock.getOutputStream());
					logger.debug("writing Info buf size="+send_requestLen);

					stream_send_data.writeUTF(dataObjectRE.tlv_params.getData(RETags.RESPONSE_STRING));
					logger.info(dataObjectRE.getLogLine()+"response successfully sent sendtoclientSocket()");
				}						
			}
			catch(IOException eee1)
			{
				logger.fatal(GlobalRE.exception_error+"in Sending Data sendtoclientSocket():: ",eee1);													
			}
			catch(Exception eee)
			{
				logger.fatal(GlobalRE.exception_error+"Exception Sending Data sendtoclientSocket():: "+eee.toString());						
			}					

		}
		catch(Exception e)
		{
			logger.warn(GlobalRE.exception_error+"in sendtoclientSocket()",e);			
		}
	}

	/**
	 * This function is responsible to check whether the request Data is json or not
	 * */
	public boolean isJson(String requestData) {
		try {
			//gson.fromJson(requestData, Object.class);	
			if(jsonParser.parse(requestData).isJsonArray() || jsonParser.parse(requestData).isJsonObject())
			{
				return true;
			}
			return false;
		} catch (Exception ex) {
			logger.error(GlobalRE.exception_error+" in isJson() : ",ex);
			return false;
		}
	}

	/**
	 * This function basically encodes the integer data for sending to socket
	 * @param value this is the integer value which has to be encoded
	 * @param buf this is the buffer to which data is to be copied after encoding
	 * */
	public int writeInt(int value,ByteArrayOutputStream buf)
	{
		int i2send = value;
		byte buffer[] = new byte[4];
		buffer[0] = (byte) ((i2send >> 24) & 0xff);
		buffer[1] = (byte) ((i2send >> 16) & 0xff);
		buffer[2] = (byte) ((i2send >> 8) & 0xff);
		buffer[3] = (byte) ((i2send) & 0xff);
		buf.write(buffer,0,4);
		return 0;
	}

	/**
	 * This function basically encodes the integer data for sending to socket
	 * @param value this is the String data which has to be encoded
	 * @param buf this is the buffer to which data is to be copied after encoding
	 * */


	public void writeString(String value,ByteArrayOutputStream buf)
	{
		writeInt(value.length(),buf);
		buf.write(value.getBytes(),0,value.length());
	}
	
	/**
	 * This function is used to send Renew Engine Response
	 */
	public void sendToClientRenewEngine(DataObjectRE dataObjectRE)
	{

		logger.info("sending response to client RenewEngine.");
		try
		{
			Socket sock=null;
			sock=dataObjectRE.sock;
			logger.debug("sending request to socket  sendToClientRenewEngine(): ["+dataObjectRE.sock+"]");
			try{

				if (sock.isClosed())
				{
					logger.debug("socket is closed for this request sendToClientRenewEngine() ");
					error_flw.writeLog("socket is closed for request sendToClientRenewEngine() || socket object : ["+dataObjectRE.sock+"]");						
				}
				else{
					TLVAppInterface sendResponse=new TLVAppInterface();
					ByteArrayOutputStream send_buf_renew = new ByteArrayOutputStream();
					sendResponse.setData(RETags.RENEW_RESPONSE, dataObjectRE.tlv_params.getData(RETags.RENEW_RESPONSE));
					sendResponse.encode(send_buf_renew);
					int send_requestLen = send_buf_renew.size();
					stream_send_data = new DataOutputStream(sock.getOutputStream());
					logger.debug("writing Info buf size=" + send_requestLen);
					byte[] len = new byte[4];
					len[3] = (byte) (send_requestLen);
					len[2] = (byte) ((send_requestLen >> 8));
					len[1] = (byte) ((send_requestLen >> 16));
					len[0] = (byte) ((send_requestLen >> 24));
					stream_send_data.write(len, 0, 4);
					stream_send_data.write(send_buf_renew.toByteArray(), 0, send_buf_renew.toByteArray().length);
					logger.info("response successfully sent");
				}						
			}
			catch(IOException eee1)
			{
				logger.fatal(GlobalRE.exception_error+"in Sending Data:: ",eee1);													
			}
			catch(Exception eee)
			{
				logger.fatal(GlobalRE.exception_error+"Exception Sending Data:: "+eee.toString());
			}					

		}
		catch(Exception e)
		{
			logger.warn(GlobalRE.exception_error+"in sendtoclient()",e);			
		}		
	
	}
}
