package telemune.engine.backend.common;

/**
 * THIS IS THE INTERFACE WHICH CONATINS ALL THE TAGS WHICH IS USED IN THE RULE ENGINE
 * */
public interface RETags {
	//Common tags for Charging and CSE
		int MSISDN=1;
		int RBTCODE=4;//ITEM_CODE in case of CSE
		int INTERFACE=6;
		int SUBTYPE=8;
		int PACKID=14;//PACKAGE_TAG in case of CSE
		int LANGUAGE=21;
		int RESPONSE_CODE=7;
		int REQUEST_DATA=113;// Profile 
		
		//Charging specific tags
		int ACTION=2;
		int TARIFF=3; 
		int FMSISDN=5;
		int REQID=9;
		int AMOUNT=11;
		int CHG_REQTYPE=12;
		int CORP_ID=13;
		int RESPONSE_STRING=35;	

		//CSE Specific tags
		int TRANSACTION_ID=101;
		int CSE_REQTYPE=102;
		int REPORT=103;
		int SERVICE=104;
		int PMSISDN=105;
		int USERNAME=106;
	    int PASSWORD=107;
	    int IS_FREE=108;
	    int PSUB_TYPE=109;
	    int ITEM_NAME=110;
	    int ITEM_TYPE=111;
	    int PACK_VARS=112;
	    int RESPONSE_TYPE=201;
		
		//Tags getting in requests from various interface
		int PLANIND=51;
		int UPDATEBY=52;
		int REASON=53;
		int DAYS=54;
		int STARTTIME=55;
		int ENDTIME=56;
		int CHECKRBT=57;
		int GROUPNAME=58;
		int ALBUMNAME=59;
		int ADVOP=60;
		int CONTROLNAME=61;
		int DATE=62;
		int RBTPATH=63;
		int CATID=64;
		int CALLID=65;
		int ALBUMID=66;
		int OCC=67;
		int REFID=68;
		int HLRREQUEST=69;
		int PLANNAME=70;
		
		//Changes for System Wallet
		int SYSTEM_WALLET_ID=71;
		int TYPE=72;
		//Added by shambhavi 25-04-2016
		int SUB_RENEW_START_STOP=73;		
		//Added by rahul kumar on 22/03/2018
		int CRBT_PROMO_ACTIVATION=74;
		
		int REQUEST_DATA_JSON=100;
	
	String HTTP_RESPONSE_TYPE="RESPONSE_TYPE";
	String HTTP_RESPONSE_CODE="RESPONSE_CODE";
	String HTTP_REQUEST_DATA="REQUEST_DATA";
	String HTTP_TRANSACTION_ID="TRANSACTION_ID";
	String HTTP_TARIFF_ID="TARIFF_ID";

	String HTTP_ACTION="ACTION";
	String HTTP_ACTION_TYPE="ACTION_TYPE";
	
	
	String cre="CRE";
	String tlv="TLV";
	String http="HTTP";
	String renew="RENEW";
	
	String socket="socket";
	
	int D_INT=1;
	int D_STRING=2;
	
	//Added by Rahul kumar 13/03/2018 for Renew Engine to receive request 
	int RENEW_ENGINE_FLAG=1;
	int RENEW_ENGINE_TYPE=2;
	int RENEW_RESPONSE=3;
	int SUB_RENEW_ENGINE_IP=4;
	int SUB_RENEW_ENGINE_PORT=5;
	int SUB_RENEW_TIMEOUT=6;
	int RBT_RENEW_ENGINE_IP=7;
	int RBT_RENEW_ENGINE_PORT=8;
	int RBT_RENEW_TIMEOUT=9;
	
	
	String SUB_RENEW="SUB";
	String RBT_RENEW="RBT";
}
