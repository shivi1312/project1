
package telemune.engine.backend.common;

import java.lang.reflect.Field;
import java.net.ServerSocket;
import java.sql.Connection;
import java.util.Hashtable;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import commonutil.TssStringUtill;

/**
 *THIS IS THE MAIN CLASS WHICH INITIALIZE THE ACCEPTOR PORT FOR SEVER ACCEPTOR TO GET THE REQUEST FROM CLIENT
 *THIS CLASS ALSO INITIALIZE THE ExecuterThreadPoolManager for thread pool executor	
 *READ THE RULEENGINE.PROPERTIES FILE WHICH HELP TO GET THE VALUE OF DATABASE PARAMETER
 *IT ALSO INITIALIZE THE LOG FILE WRITER OBJECT AND THEIR FILE PATH 
 */

public class RuleEngine implements Runnable 
{
	static Thread thcntr; 
	static Thread temp; // local thread
	static Thread thCacheLoader; // cache loader thread
	static Thread thserverAcceptor; // server accepter thread
	static Thread thserverAcceptorCRE; // server accepter thread
	static Thread thserverAcceptorSocket; // server accepter thread
	static	ServerSocket server_socket = null; 
	static Thread thserverAcceptorRenew=null;

	static Logger logger=Logger.getLogger("RuleEngine");
	static Connection con=null;


	public void run()
	{
	}
	
	/**
	 * THIS IS THE MAIN METHOD WHICH INITIALIZE ALL THE THREADS i.e., SERVER ACCEPTER THREAD,
	 * ExecuterThreadPoolManager THREAD FOR THREADPOOL EXECUTER 
	 * */
	public static void main(String[] args) {

		String VERSION="R1_0_8_0";
		String SITE="RULE_ENGINE";

		PropertyConfigurator.configure("properties/log4j.properties");
		try{
			if(args[0].equalsIgnoreCase("-v"))
			{
				logger.info("\n******************************************************************************************");
				logger.info("\n                               Site "+SITE);
				logger.info("\n                               Version "+VERSION);
				logger.info("\n******************************************************************************************");
				logger.info("\n");
				System.exit(1);
			}
		}
		catch(Exception Arrayoutex)
		{
			System.out.println(GlobalRE.exception_error+"no argument is passed ["+Arrayoutex.toString()+"]");
		}

		temp=new Thread();
		try 
		{
			logger.info("\n******************************************************************************************");
			logger.info("\n                               Site "+SITE);
			logger.info("\n                               Version "+VERSION);
			logger.info("\n******************************************************************************************");
			logger.info("\n");


			int portTLV  = 1234; //default port
			int portCRE=15111;
			int portHTTP=9999;
			int portSocket=9099;
			int portRenew=18111;
			//int numofcon=-1;
			//int accomodation=-1;
			//	int minnumofcon=1;
			//	int numofcontentthreads=-1;
			//	int numofsmsthreads=-1;

			int executer_thread_queue_size=5;
			int minExecuterThread=4;
			int maxExecuterThread=10;
			int threadMonitorDelayTime=300;

			int cacheloadTime=30;

			ServerAcceptorTLV srvAcceptorTLV=null;//new ServerAcceptor(port);
			ServerAcceptorCRE srvAcceptorCRE=null;//new ServerAcceptor(port);
			ServerAcceptorHTTP srvAcceptorHTTP=null;//new ServerAcceptor(port);
			ServerAcceptorSocket srvAcceptorSocket=null;//new ServerAcceptor(port);
			ServerAcceptorRenew srvAcceptorRenew=null;// Added by Rahul kumar 13/03/2018
			
			int waiting= 2100; //default port

			int tlvOpen=1;
			int creOpen=1;
			int httpOpen=1;
			int socketOpen=1;
			int renewOpen=1;

			String server = "localhost"; //default host

			logger.info("Starting CacheLoader thread ..............");

			CacheLoaderRE cacheLoaderRE=new CacheLoaderRE();
			thCacheLoader=new Thread(cacheLoaderRE);
			thCacheLoader.start();
			
			GlobalRE.cacheLoaderRE=cacheLoaderRE;
			/**
			 * Added by rahul kumar
			 */
			String className=GlobalRE.crbtGlobals;
			Class clazz=(Class) Class.forName(className);
			Field appConfigParamsField=null;
			 for (Field f : clazz.getDeclaredFields()) 
			 {
				 try
				 {
					 f.setAccessible(true);
					 if(f.getName().equals("g_appConfig"))
					 {
						 appConfigParamsField=f;	
						 break;
					 }
				 }
				 catch(Exception e)
				 {
					 logger.error("Exception while getting g_appConfig property of CrbtGlobals of crbtrules.jar.");
				 }
			 }
			Hashtable appConfigParams=null;
			if(appConfigParamsField!=null)
			{
				appConfigParams=(Hashtable) appConfigParamsField.get(Hashtable.class);
				if(appConfigParams!=null && appConfigParams.size()>0 && appConfigParams.get("RENEWAL_RE_INTERACTION")!=null)
				{
					renewOpen=Integer.parseInt((String)appConfigParams.get("RENEWAL_RE_INTERACTION"));					
				}
			}
			logger.info("Getting RENEWAL_RE_INTERACTION["+renewOpen+"] from CRBT_APP_CONFIG_PARAMS,");			
			portTLV=Integer.parseInt(GlobalRE.property_map.get("tlv.port"));
			portCRE=Integer.parseInt(GlobalRE.property_map.get("cre.port"));
			portHTTP=Integer.parseInt(GlobalRE.property_map.get("http.port"));
			portSocket=Integer.parseInt(GlobalRE.property_map.get("socket.port"));
			if(renewOpen>0)
			{
				portRenew=Integer.parseInt(GlobalRE.property_map.get("renew.port")); // added by rahul kumar 
			}			
			GlobalRE.max_limit=Integer.parseInt(GlobalRE.property_map.get("max_limit"));
			executer_thread_queue_size=Integer.parseInt(GlobalRE.property_map.get("executer_thread_queue_size"));
			minExecuterThread=Integer.parseInt(GlobalRE.property_map.get("min_executer_thread"));
			maxExecuterThread=Integer.parseInt(GlobalRE.property_map.get("max_executer_thread"));
			threadMonitorDelayTime=Integer.parseInt(GlobalRE.property_map.get("thread_monitor_delay_time"));

			if(TssStringUtill.ValidateParams(GlobalRE.property_map.get("is_tlv_open"),GlobalRE.property_map.get("is_cre_open"),GlobalRE.property_map.get("is_http_open"),GlobalRE.property_map.get("is_socket_open"))){
				tlvOpen=Integer.parseInt(GlobalRE.property_map.get("is_tlv_open"));
				creOpen=Integer.parseInt(GlobalRE.property_map.get("is_cre_open"));
				httpOpen=Integer.parseInt(GlobalRE.property_map.get("is_http_open"));
				socketOpen=Integer.parseInt(GlobalRE.property_map.get("is_socket_open"));				
			}

			if(tlvOpen==0 && creOpen==0 && httpOpen==0 && socketOpen==0 && renewOpen==0){
				logger.error("CRITICAL ERROR || no port is opened , please open atleast one port to receive request");
				System.exit(1);
			}			


			ThreadPoolExecutor executorPool = new ThreadPoolExecutor(minExecuterThread,maxExecuterThread, 10, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(executer_thread_queue_size),new RejectedWorkHandler());

			logger.info("Intializing ExecuterThreadPoolManager Thread...");
			ExecuterThreadPoolManager executerThreadPoolManager= new ExecuterThreadPoolManager(executorPool);
			Thread threadPoolThread=new Thread(executerThreadPoolManager);
			threadPoolThread.start();

			logger.info("Intializing ThreadMonitor Thread...");
			ThreadMonitor thMonitor=new ThreadMonitor(executorPool,threadMonitorDelayTime);
			Thread monitorThread = new Thread(thMonitor);
			monitorThread.start();

			if(tlvOpen!=0)
			{
				logger.info("Intializing Acceptor Thread TLV...");
				try
				{
					srvAcceptorTLV=new ServerAcceptorTLV(portTLV);
					thserverAcceptor =new Thread(srvAcceptorTLV);
					thserverAcceptor.start();
				}
				catch(Exception ee)
				{
					logger.fatal(GlobalRE.exception_error+"got SOCKET exception in opening ServerAccepter TLV thread" +ee.toString());
					System.exit(1);
				}
			}
			if(creOpen!=0)
			{
				logger.info("Intializing Acceptor Thread CRE...");
				try
				{
					srvAcceptorCRE=new ServerAcceptorCRE(portCRE);
					thserverAcceptorCRE =new Thread(srvAcceptorCRE);
					thserverAcceptorCRE.start();
				}
				catch(Exception ee)
				{
					logger.fatal(GlobalRE.exception_error+"got SOCKET exception in opening ServerAccepter CRE thread" +ee.toString());
					System.exit(1);
				}			
			}
			if(httpOpen!=0)
			{
				logger.info("Intializing Acceptor Thread HTTP...");
				try
				{
					srvAcceptorHTTP=new ServerAcceptorHTTP(portHTTP);
					srvAcceptorHTTP.acceptHttpRequest();
				}
				catch(Exception ee)
				{
					logger.fatal(GlobalRE.exception_error+"got SOCKET exception in opening ServerAccepter HTTP thread" +ee.toString());
					System.exit(1);
				}
			}
			if(socketOpen!=0)
			{
				logger.info("Intializing Acceptor Thread Socket...");
				try
				{
					srvAcceptorSocket=new ServerAcceptorSocket(portSocket);
					thserverAcceptorSocket =new Thread(srvAcceptorSocket);
					thserverAcceptorSocket.start();
				}
				catch(Exception ee)
				{
					logger.fatal(GlobalRE.exception_error+"got SOCKET exception in opening ServerAccepter Socket thread" +ee.toString());
					System.exit(1);
				}
			}
			/**
			 * Added by Rahul Kumar for Renew Engine
			 */
			if(renewOpen!=0)
			{
				logger.info("Intializing Acceptor Thread Renew...");
				try
				{
					srvAcceptorRenew=new ServerAcceptorRenew(portRenew);
					thserverAcceptorRenew =new Thread(srvAcceptorRenew);
					thserverAcceptorRenew.start();
				}
				catch(Exception ee)
				{
					logger.fatal(GlobalRE.exception_error+"got SOCKET exception in opening ServerAccepter Renew thread" +ee.toString());
					System.exit(1);
				}			
			}
			logger.info("Application Started Successfully...");
			while(true)
			{
				try
				{
					if(tlvOpen!=0)
					{
						if(!thserverAcceptor.isAlive())
						{	
							logger.info("ServerAcceptor TLV not alive so Intializing again..");
							srvAcceptorTLV=new ServerAcceptorTLV(portTLV);
							thserverAcceptor =new Thread(srvAcceptorTLV);
							thserverAcceptor.start();

						}
					}
					if(creOpen!=0)
					{
						if(!thserverAcceptorCRE.isAlive())
						{	
							logger.info("ServerAcceptor CRE not alive so Intializing again..");
							srvAcceptorCRE=new ServerAcceptorCRE(portCRE);
							thserverAcceptorCRE =new Thread(srvAcceptorCRE);
							thserverAcceptorCRE.start();

						}
					}	
					
					if(socketOpen!=0)
					{
						if(!thserverAcceptorSocket.isAlive())
						{	
							logger.info("ServerAcceptor Socket not alive so Intializing again..");
							srvAcceptorSocket=new ServerAcceptorSocket(portSocket);
							thserverAcceptorSocket =new Thread(srvAcceptorSocket);
							thserverAcceptorSocket.start();

						}
					}
					
					if(!thCacheLoader.isAlive())
					{	
						logger.info("Cache Loader Thread not alive so Intializing again..");
						cacheLoaderRE=new CacheLoaderRE();
						thCacheLoader=new Thread(cacheLoaderRE);						
						thCacheLoader.start();

					}

					/*if (!thres.isAlive())
					{
						logger.info("Response Sender Thread  has been stoped , so restarting");
						obj_send_data = new ResponseSender("threadCheckResponses",total_flw);
						thres=new Thread(obj_send_data);
						thres.start();
					}*/
					/**
					 * Added by Rahul Kumar 13/03/2018 
					 */
					if(renewOpen!=0)
					{
						if(!thserverAcceptorRenew.isAlive())
						{	
							logger.info("ServerAcceptor Renew is not alive so Intializing again");
							srvAcceptorRenew=new ServerAcceptorRenew(portRenew);
							thserverAcceptorRenew =new Thread(srvAcceptorRenew);
							thserverAcceptorRenew.start();

						}
					}	
				}
				catch(Exception e)
				{
					logger.error(GlobalRE.exception_error+" in  initializing ServerAcceptor thread again",e);
					//System.exit(1);
				}
				try
				{
					temp.sleep(300*1000);
					logger.info("All Threads Running Successfully...");
				}
				catch(Exception eee)
				{
					logger.fatal(GlobalRE.exception_error+"Sleep Exception in main");					
				}	
			}

		} 
		catch (Exception e) 
		{
			logger.error(GlobalRE.exception_error+"in main so stoping all thread",e);
		}
		finally
		{
			try
			{
				//thres.stop();
				thserverAcceptor.stop();
				thserverAcceptorCRE.stop();
				thCacheLoader.stop();
				thserverAcceptorRenew.stop();
				logger.info("All Threads  stopped: ");
				//System.exit(1);
			}
			catch(Exception e)
			{
				logger.error(GlobalRE.exception_error+"Threads cannot stopped: ",e);			
			}
		}

	}
}
