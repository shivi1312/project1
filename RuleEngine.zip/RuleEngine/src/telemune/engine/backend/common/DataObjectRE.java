
package telemune.engine.backend.common;

import java.net.Socket;

import commonutil.TLVParameters;


/**
 *THIS IS THE POJO CLASS WHICH USED FOR GETTING THE REQUEST DATA AND ALSO IN RESPONSE DATA
 *
 */
public class DataObjectRE {
	public TLVParameters tlv_params;
	public Socket sock;
	public String msisdn="NA";		
	public int actionId=-1;
	public String transactionId="NA";
	public String requestMedia="NA";
	public String logPrefix="NA";
	
	public String getLogLine(){
		return "["+actionId+"]["+logPrefix+"]>>";
	}
}
