/**
 * 
 */
package telemune.engine.backend.common;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;

import FileBaseLogging.FileLogWriter;
import commonutil.TssStringUtill;


/**
 * THIS CLASS IS FOR LOAD THE CACHE FOR THE WHOLE SYSTEM 
 *@author :- Pankaj Gupta
 */

public class CacheLoaderRE implements Runnable
{
	static Logger logger=Logger.getLogger("CacheLoaderRE");
	
	FileLogWriter l_error_flw = null;
	Hashtable l_state_cache=null;
	Hashtable<String,String> l_property_map=null;	
	 
	Thread thtemp=new Thread();
	static int sleeptime=30;
	
	static int numofcon=30;
	static int minnumofcon=10;
	static int accomodation=5;
	static String dbuser="NA";
	static String dbpass="NA";
	static String dburl="NA";
	static String dbdriver="NA";
	static String dbType="NA"; // Added by Avishkar on 08.05.2019
	static String procedure_package="NA"; // Added by Avishkar on 08.05.2019
	static int construtorCalled=0;
	private static int appCounter = 0;
	private static long appCounterResetTimeDuration = 60000l;
	private static long appCounterLastResetTime = 0l;
	


	
	/**
	 *
	 *THIS IS THE PARAMETERIZED CONSTRUCTOR OF CACHELOADER CLASS IN WHICH WE ARE INITIALIZE THE SLEEP TIME OF THIS THREAD
	 */
	public CacheLoaderRE()
	{
		logger.info("Creating initial instance of CacheLoaderRE");
		cacheReLoad();
		initializeJar();
		sleeptime=Integer.parseInt(GlobalRE.property_map.get("reload_time"));
		construtorCalled=1;// to avoid cache loading at the time construtor calling
	}

	public CacheLoaderRE(int type)//To avoid calling of initializeJar in case of forcefully reloading call
	{
		logger.info("Reloading instance of CacheLoaderRE");
		cacheReLoad();		
		construtorCalled=1;// to avoid cache loading at the time construtor calling
	}

	
	/**
	 * A Synchronized Cache Reloader
	 * Which is reload the Property File & Application Configuration Parameters & database configuration
	 * & file log writer & jar name & state file configuration
	 */
	public synchronized void  cacheReLoad()
	{
		logger.info("############inside cacheReLoad()###############");
		try
		{
			loadPropertyFile();
			loadDBConfiguration();
			loadFileLogWriterConfiguration();
			loadJarName();			
			loadStateFileConfiguration();
			loadAppCounterData();
		}
		catch(Exception exp)
		{
			logger.error(GlobalRE.exception_error+"Error during reloading propertyFile ",exp);			
		}		
		logger.info("############end cacheReLoad()###############");
	}

	/**
	 *THIS IS THE RUN METHOD OF CACHELOADER THREAD WHICH STARTS CACHE RELOADING AFTER A FIX TIME INTERVAL
	 *DEFINED IN PROPERTY FILE  
	 */
	public void run()
	{
		while(true)
		{
			logger.info("############inside run()###############");
			try
			{
				try
				{
					if(construtorCalled==0){ // to avoid cache loading at the time construtor calling
					cacheReLoad();					
					}else{
						construtorCalled=0; 
					}
				}
				catch(Exception ees)
				{
					logger.fatal(GlobalRE.exception_error+"in cacheReLoad()......",ees);
				}
				logger.info("CacheLoaderRE now sleeping for ["+sleeptime+"] sec.");
				thtemp.sleep(sleeptime*1000);				
				//con.close();
			}
			catch(Exception e)
			{
				logger.error(GlobalRE.exception_error+"inside run() ",e);
			}
		}
	}//run()

	/**
	 * Load the Property File
	 */
	public void loadPropertyFile()
	{
		logger.info("#########Inside the loadPropertyFile()########################");
		Properties properties=null;
		try
		{	
			properties=new Properties();
			FileInputStream fins=new FileInputStream("properties/ruleEngine.properties");
			properties.load(fins);
		
			fins.close();
			
			l_property_map=new Hashtable<String,String>();
			
			Enumeration<?> propertyNames = properties.propertyNames();
			    
			    while (propertyNames.hasMoreElements()) {
			      String key = (String) propertyNames.nextElement();
			      l_property_map.put(key.trim(), properties.getProperty(key).trim());
			    }
		
			GlobalRE.property_map=l_property_map;
		}
		catch(Exception e)
		{
			logger.fatal(GlobalRE.exception_error+"FATAL Error in loading [ruleEngine.properties] properties file",e);
		}
		finally{
			properties=null;
			//l_property_map=null;
		}
		logger.info("#########End the loadPropertyFile() with size ["+GlobalRE.property_map.size()+"]########################");
	} //loadPropertyFile()

	/**
	 * This function loads database configuration from property file
	 */
	public void loadDBConfiguration(){
		logger.info("############inside loadDBConfiguration()###############");
		try{
			//String driver,String url,String username,String passwd,int minpoolsize,int maxpoolsize,int Accomodation
			dbuser=GlobalRE.property_map.get("dbuser");
			dbpass=GlobalRE.property_map.get("dbpassword");
			dburl=GlobalRE.property_map.get("dburl");
			dbdriver=GlobalRE.property_map.get("dbdriver");
			minnumofcon=Integer.parseInt(GlobalRE.property_map.get("dbminnumofcon"));
			numofcon=Integer.parseInt(GlobalRE.property_map.get("dbnumofcon"));
			accomodation=Integer.parseInt(GlobalRE.property_map.get("dbaccomodation"));
			dbType=GlobalRE.property_map.get("DB_TYPE"); // Added by Avishkar on 08.05.2019
			procedure_package=GlobalRE.property_map.get("PROCEDURE_PACKAGE"); // Added by Avishkar on 08.05.2019
		
		}catch (Exception e) {
			logger.error(GlobalRE.exception_error+"in loadDBConfiguration() ",e);			
		}//loadDBConfiguration()
		
		logger.info("############end loadDBConfiguration()###############");
	}

	/**
	 * This function loads file writer configuration from property file
	 * */
	public void loadFileLogWriterConfiguration(){
		logger.info("############inside loadFileLogWriterConfiguration()###############");
		try{
			l_error_flw = new FileLogWriter();
			l_error_flw.setNewFileInterval(Integer.parseInt(GlobalRE.property_map.get("error_log_file_interval")));
			l_error_flw.setFilename(GlobalRE.property_map.get("error_log_filename"));
			l_error_flw.setFilePath(GlobalRE.property_map.get("error_log_filepath"));
			l_error_flw.setArchiveFilePath(GlobalRE.property_map.get("error_log_filepath_arch"));
			l_error_flw.setArchiveFilename(GlobalRE.property_map.get("error_log_filename_arch"));
			l_error_flw.setArchiveFileExtension("");
			l_error_flw.initialize();			
			GlobalRE.error_flw=l_error_flw;
		}
		catch (Exception e) {
			logger.error(GlobalRE.exception_error+"in loadFileLogWriterConfiguration() ",e);			
		}finally{
			//l_error_flw = null;	
		}
		logger.info("############end loadFileLogWriterConfiguration()###############");		
	}//loadFileLogWriterConfiguration()

	/**
	 * This function loads jar names from property file
	 * */
	public void loadJarName(){
		logger.info("############inside loadJarName()###############");
		try{
			GlobalRE.startClass=GlobalRE.property_map.get("app.start.class");
			GlobalRE.fxnsClass=GlobalRE.property_map.get("app.fxns.class");
			GlobalRE.crbtGlobals=GlobalRE.property_map.get("app.crbtGlobals.class");
			/*GlobalRE.hlrJar=GlobalRE.property_map.get("hlr.jar");
			GlobalRE.chargingJar=GlobalRE.property_map.get("charging.jar");
			GlobalRE.hlrActive=Integer.parseInt(GlobalRE.property_map.get("hlr.int.active"));
			GlobalRE.chargingActive=Integer.parseInt(GlobalRE.property_map.get("charging.int.active"));*/
			
		}catch (Exception e) {
			logger.error(GlobalRE.exception_error+"in loadJarName() ",e);
			//System.exit(1);
		}
		logger.info("############end loadJarName()###############");
	}//loadJarName()

	/**
	 * This function basically initializes the jar 
	 * DB Pool connection are created first
	 * CacheLoader of Jar is called Connection creation 
	 * */
	public void initializeJar(){
		logger.info("############inside initializeJar()###############");
		Class clazz=null;
		Method methodToCall=null;
		try {
			clazz=(Class) Class.forName(GlobalRE.startClass);
			Object obj=clazz.newInstance();
			methodToCall=(Method) clazz.getMethod("makeDBPool",String.class,String.class,String.class,String.class,int.class,int.class,int.class,String.class,String.class);
			methodToCall.invoke(obj,dbdriver,dburl,dbuser,dbpass,minnumofcon,numofcon,accomodation,dbType,procedure_package); // dbType & procedure_package added by Avishkar on 08.05.2019 for dual db support. 
			Thread.sleep(1000);// Time for making connectionPool
			methodToCall=(Method) clazz.getMethod("initialize",FileLogWriter.class);
			methodToCall.invoke(obj,GlobalRE.error_flw);			
			logger.info("Initialized class ["+GlobalRE.startClass+"] successfully");
			
		} catch (Exception e) {
			logger.error(GlobalRE.exception_error+"in initializeJar() ",e); 
		}
		finally{
			clazz=null;
			methodToCall=null;
		}	
		logger.info("############end initializeJar()###############");
	}//initializeJar()
	 

	/**
	 *This function loads state machine data into the hashtable
	 */
	public void loadStateFileConfiguration(){
		logger.info("############inside loadStateFileConfiguration()###############");

		//Path path=null;
		Scanner scanner= null;
		Hashtable<String,ActionInfo> inner_Hash=null;//new Hashtable<String,String>();
		String currentLineArray[];
		ActionInfo actionInfo=null;
		FileInputStream fileInputStream=null;
		File file=null;
		try {
			//path = Paths.get("properties/state_machine.txt");
			//path = Paths.get(GlobalRE.property_map.get("state_machine_file_path")+"state_machine.txt");
			file =new File(GlobalRE.property_map.get("state_machine_file_path")+"state_machine.txt");
			//file =new File(GlobalRE.property_map.get("state_machine_file_path"));
			fileInputStream=new FileInputStream(file);
		//	scanner =  new Scanner(path,"UTF-8");
			scanner =  new Scanner(fileInputStream,"UTF-8");
			
			boolean isHashKey=true;
			String currentLine="",mainHashKey="",innerHashKey="",FinalInnerHashKey="";
			
			l_state_cache=new Hashtable();// to clear the cache initially
			inner_Hash=new Hashtable<String,ActionInfo>();
			
			while(scanner.hasNextLine())
			{	
				currentLine=scanner.nextLine().trim();	
				if(!(currentLine.isEmpty() || currentLine.contains("#")))
				{				
					if((currentLine.contains("[") || currentLine.contains("|")))
					{
						if(currentLine.contains("["))
						{
							innerHashKey="";
							innerHashKey=currentLine.substring(currentLine.indexOf("[")+1,currentLine.indexOf("]"))+"_";
						}
						else if(currentLine.contains("|"))
						{
							currentLineArray=currentLine.split("\\|");
							if(currentLineArray.length==3){
								if(TssStringUtill.ValidateParams(currentLineArray[0],currentLineArray[1],currentLineArray[2])){
									FinalInnerHashKey=innerHashKey+currentLineArray[0].trim();
									actionInfo=new ActionInfo();
									actionInfo.setMethodName(currentLineArray[1].trim());
									actionInfo.setNextState(currentLineArray[2].trim());
									inner_Hash.put(FinalInnerHashKey.trim(),actionInfo);							
								}else{
									logger.error(GlobalRE.exception_error+"in loadStateFileConfiguration() for key["+mainHashKey+"] inside state ["+innerHashKey+"] so ruleEngine will not startup<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
									System.exit(1);
								}
							}else{
								logger.error(GlobalRE.exception_error+"in loadStateFileConfiguration() for key["+mainHashKey+"] inside state ["+innerHashKey+"] so ruleEngine will not startup<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
								System.exit(1);
							}
						}	
					}
					else{
						inner_Hash=new Hashtable<String,ActionInfo>();
						mainHashKey=currentLine;
					}
					l_state_cache.put(mainHashKey, inner_Hash);
				}
			}
			GlobalRE.state_cache=l_state_cache;
			fileInputStream.close();
		}catch (IOException e) {
			logger.error(GlobalRE.exception_error+"in loadStateFileConfiguration() state machine file not found",e);
			System.exit(1);
		}
		catch (Exception e) {
			logger.error(GlobalRE.exception_error+"in loadStateFileConfiguration() ",e);
			System.exit(1);
		}finally{
			actionInfo=null;
			inner_Hash=null;
			currentLineArray=null;
			scanner=null;
		//	path=null;
			fileInputStream=null;
			file=null;
			//l_state_cache=null;
		}		
		logger.info("############end loadStateFileConfiguration() with hashtable size ["+GlobalRE.state_cache.size()+"]###############");
	}//loadStateFileConfiguration()

	/**
	* This method is used to update and return app counter and to reset it, if needed
	*/
	public static int updateAndGetAppCounter()
	{
		long currentTimeInMS = new Date().getTime();
                long appCounterLastResetDur = currentTimeInMS - appCounterLastResetTime;
                logger.debug("inside updateAppCounter() >> current time ["+currentTimeInMS+"] mili seconds app counter last reset ["+appCounterLastResetTime+"] mili seconds app counter last reset duration ["+appCounterLastResetDur+"] seconds app counter need to reset after duration ["+appCounterResetTimeDuration+"] seconds (from properties file or default if not found)");

                if(appCounterLastResetDur >= appCounterResetTimeDuration)
                {
                        appCounter = 0;
                        appCounterLastResetTime = currentTimeInMS;
                        logger.info("###################inside updateAppCounter() >> app counter last reset duration ["+appCounterLastResetDur+"] seconds app counter need to reset after duration ["+appCounterResetTimeDuration+"]  seconds (from properties file or default if not found) So resetting app Counter at ["+new Date()+"]");
                }
		return ++appCounter;
	}
	
	/**
	* This method is used for loading the data for request Counter means app_counter_reset_time from properties file
	*/
	private void loadAppCounterData()
	{
		logger.debug("############inside loadAppCounterData()###############");
		if(TssStringUtill.ValidateParams(GlobalRE.property_map.get("app_counter_reset_time"))){
			try{
				appCounterResetTimeDuration=Long.parseLong(GlobalRE.property_map.get("app_counter_reset_time"));
			}catch (Exception e) {
				logger.error(GlobalRE.exception_error+"errror in getting req_counter_reset_time so taking default time as ["+appCounterResetTimeDuration+"]sec");					
			}
		}
		logger.info("############end loadAppCounterData() with  req_counter_reset_time["+appCounterResetTimeDuration+"]###############");
	}
}
