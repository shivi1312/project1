package telemune.engine.backend.common;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.URI;

import org.apache.log4j.Logger;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import commonutil.TLVParameters;
import commonutil.TssStringUtill;

/**
 *THIS CLASS IS FOR READING THE REQUEST FROM CLIENT ON PARTICULAR DEFINED PORT THROUGH HTTP INTERFACE AND THEN INSERT THE DATA INTO THE QUEUE
 *@author :- PANKAJ GUPTA
 *   
 */
public class RequestReaderHTTP implements HttpHandler{
	static Logger logger=Logger.getLogger("RequestReaderHTTP");


/*
 * This is just the default constructor of RequestReaderHTTP
 * */
	public RequestReaderHTTP() {

	}

	/**
	 * This is main method which is executed on getting HTTP hit
	 * */
	public void handle(HttpExchange httpExchange) throws IOException
	{
		OutputStream responseBody = null;
		Headers responseHeaders = null;
		try{
			String requestMethod = httpExchange.getRequestMethod();
			logger.info(" inside HTTP handle || Request Type ["+requestMethod+"]");

			if (requestMethod.equalsIgnoreCase("POST"))
			{
				processPostRequest(httpExchange);			
			}
			else if(requestMethod.equalsIgnoreCase("GET"))
			{
				processGetRequest(httpExchange);
			}
			else
			{
				logger.info("Invalid Request Type["+requestMethod+"]");
			}

			responseBody = httpExchange.getResponseBody();
			responseHeaders = httpExchange.getResponseHeaders();
			responseHeaders.set("Content-Type", "text/plain");
			responseHeaders.set("SUCCESSFUL", "22");
			httpExchange.sendResponseHeaders(200, 0);

		}catch (Exception e) {
			logger.error(GlobalRE.exception_error+" in handle",e);
		}finally{
			responseBody.close();
			httpExchange.close();
			responseHeaders.clear();
		}
	}
	
	/**
	 * This is the function which is resposible for processing GET request
	 * */
	public void processGetRequest(HttpExchange exchange){
		URI requestedUri =null;
		try{
			requestedUri = exchange.getRequestURI();
			String query = (String)exchange.getRequestURI().toString();
			logger.info("in processGetRequest || QueryString is ["+query+"]");
			if(!query.equalsIgnoreCase("/favicon.ico")){
				msgExtractionGet(query);
			}
		}catch (Exception e) {
			logger.error(GlobalRE.exception_error+" in processGetRequest",e);
		}finally{
			requestedUri =null;
		}
	}

	/**
	 * This is the function is responsible for extraction of message from the GET request as query part 
	 * */
	public void msgExtractionGet(String query)
	{
		DataObjectRE dataObjectRE=null;
		TLVParameters tlvParameters=null;
		try{

			query+="&";
			query=query.replaceAll("%20"," ");
			dataObjectRE=new DataObjectRE();
			tlvParameters=new TLVParameters();

			//RESPONSE_CODE=10&TRANSACTION_ID=12_6786786&RESPONSE_TYPE=SUCCSESSFUL&RESPONSE_DATA=HELLO]

			String paramValue="NA";

			paramValue=getParamValue(RETags.HTTP_ACTION, query);
			if(!paramValue.equals("NA"))
			{
				if(paramValue.equalsIgnoreCase("RELOAD"))
				{
					Class clazz=null;
					Object obj=null;
					Method methodToCall=null;
					CacheLoaderRE cacheLoaderRE=null;
					try{
						paramValue=getParamValue(RETags.HTTP_ACTION_TYPE, query);
						if(paramValue.equalsIgnoreCase("RULEENGINE"))
						{
							logger.info("=====================================Cache Reloading (RuleEngine) started Successfully=================================");
							cacheLoaderRE=new CacheLoaderRE(1);//just to treat it as paramterized constructor to avoid initializeJar()
							logger.info("======================================Cache Reloading (RuleEngine) done Successfully===================================");
						}else if(paramValue.equalsIgnoreCase("JAR")){
							logger.info("=====================================Cache Reloading (Jar) started Successfully=================================");
							clazz=(Class) Class.forName(GlobalRE.property_map.get("cache_class"));//cache_class is the app CacheLoader class
							obj=(Object) clazz.newInstance();
							methodToCall=(Method) clazz.getMethod(GlobalRE.property_map.get("cache_function"));
							methodToCall.invoke(obj);
							logger.info("======================================Cache Reloading (Jar) done Successfully===================================");
						}else{
							logger.info("=====================================Cache Reloading (RuleEngine+Jar) started Successfully=================================");
							cacheLoaderRE=new CacheLoaderRE(1);//just to treat it as paramterized constructor to avoid initializeJar()
							clazz=(Class) Class.forName(GlobalRE.property_map.get("cache_class"));//cache_class is the app CacheLoader class
							obj=(Object) clazz.newInstance();
							methodToCall=(Method) clazz.getMethod(GlobalRE.property_map.get("cache_function"));
							methodToCall.invoke(obj);
							logger.info("======================================Cache Reloading (RuleEngine+Jar) done Successfully===================================");
						}
					}catch (Exception e) {
						logger.error(GlobalRE.exception_error+" in cache reloading in msgExtractionGet",e);						
					}finally{
						clazz=null;
						obj=null;
						methodToCall=null;
						cacheLoaderRE=null;
					}
				}

			}else
			{
				paramValue=getParamValue(RETags.HTTP_RESPONSE_CODE, query);
				if(!paramValue.equals("NA")){
					tlvParameters.setData(RETags.RESPONSE_CODE,paramValue);
				}

				paramValue=getParamValue(RETags.HTTP_REQUEST_DATA, query);
				if(!paramValue.equals("NA")){
					tlvParameters.setData(RETags.REQUEST_DATA,paramValue);
				}

				paramValue=getParamValue(RETags.HTTP_RESPONSE_TYPE, query);
				if(!paramValue.equals("NA")){
					tlvParameters.setData(RETags.RESPONSE_TYPE,paramValue);
				}

				paramValue=getParamValue(RETags.HTTP_TARIFF_ID, query);
				if(!paramValue.equals("NA")){
					tlvParameters.setData(RETags.TARIFF,paramValue);
				}


				paramValue=getParamValue(RETags.HTTP_TRANSACTION_ID, query);
				if(!paramValue.equals("NA")){
					dataObjectRE.transactionId=paramValue;
					tlvParameters.setData(RETags.TRANSACTION_ID,paramValue);
					dataObjectRE.actionId=Integer.parseInt(dataObjectRE.transactionId.subSequence(0,dataObjectRE.transactionId.indexOf("_")).toString());
					tlvParameters.setData(RETags.ACTION,dataObjectRE.actionId);

					dataObjectRE.logPrefix=dataObjectRE.transactionId;//For logging purpose
				}

				if(tlvParameters!=null){
					dataObjectRE.tlv_params=tlvParameters;
					dataObjectRE.requestMedia=RETags.http;
					GlobalRE.que.put (dataObjectRE);
				}
			}

		}catch (Exception e) {
			logger.error(GlobalRE.exception_error+" in msgExtractionGet",e);
		}finally{
			dataObjectRE=null;
			tlvParameters=null;
		}

	}
/**
 * This is the function which is responsible for extracting the value of particular tag from the Query String 
 * */
	public String getParamValue(String paramTag,String paramString){
		String paramValue="NA";
		int start_index=-1;
		try{		
			start_index=paramString.indexOf(paramTag)+paramTag.length()+1;
			if(start_index!=paramTag.length()){
				paramValue=paramString.substring(start_index,paramString.indexOf("&",start_index)).trim();
				if(!TssStringUtill.ValidateParams(paramValue)){
					logger.error("error in getting value for param_tag: ["+paramTag+"]");
					paramValue="NA";					
				}
				logger.debug("param_tag: ["+paramTag+"]paramValue : ["+paramValue+"]");
			}
		}catch (Exception e) {
			logger.error(GlobalRE.exception_error+"in getting paramValue from paramString ["+paramString+"] for paramTag ["+paramTag+"]",e);			
		}finally{
			return paramValue;
		}
	}

	/**
	 * This function is reponsible to process the post request
	 * */
	public void processPostRequest(HttpExchange httpExchange){
		/*	Headers header_map=null;
		InputStream inpuStream=null;
		BufferedReader bufferedReader=null;
		StringBuffer requestData = null;
		DataObjectRE dataObjectRE=null;
		TLVParameters tlvParameters=null;*/
		try{
			/*  header_map=httpExchange.getRequestHeaders();
              logger.info("in processPostRequest || Http header size ["+header_map.size()+"]");              

              dataObjectRE=new DataObjectRE();
              tlvParameters=new TLVParameters();

              List temp_al=null;

              if(header_map.get(RETags.TRANSACTION_ID)!=null || header_map.get(RETags.TRANSACTION_ID).size()!=null)
              {            	  
              temp_al=header_map.get(RETags.TRANSACTION_ID);
              for(int i=0;i<temp_al.size();i++){
            	if(temp_al.get(i)!=null){
            		dataObjectRE.transactionId=(String) temp_al.get(i);
            	}  
              }
              }

              /*inpuStream=httpExchange.getRequestBody();
              bufferedReader = new BufferedReader(new InputStreamReader(inpuStream));
 		      String line="";
 		      requestData = new StringBuffer(); 
 		      while((line = bufferedReader.readLine()) != null) {
 		    	  requestData.append(line);
 		    	  requestData.append('\r');
 		      }
 		      bufferedReader.close();
 		      logger.debug("This is request which we are getting "+requestData.toString());*/

		}catch (Exception e) {
			logger.error(GlobalRE.exception_error+" in processPostRequest",e);
		}finally{
			/*header_map=null;
			inpuStream=null;
			bufferedReader=null;
			requestData = null;
			dataObjectRE=null;
			tlvParameters=null;*/
		}		
	}


/**
 * This function is responsible to extract message part from POST request received by us
 * */
	public void msgExtractionPost(String query)
	{
		//Message Extraction from QueryString will come here
		/*String msg=query.substring(query.indexOf("msg")+4).replaceAll("%20"," ");
		  logger.debug("######--------------->msg is :["+msg+"]");*/		  
	}





}
