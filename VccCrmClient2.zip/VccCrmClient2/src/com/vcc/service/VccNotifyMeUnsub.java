package com.vcc.service;

public interface VccNotifyMeUnsub {
	public String unSubscibe(String MSISDN,String tid,String lang);

}
