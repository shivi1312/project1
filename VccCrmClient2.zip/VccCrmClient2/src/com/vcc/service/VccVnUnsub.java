package com.vcc.service;

public interface VccVnUnsub {
	public String unSubscibe(String MSISDN,String tid,String lang);

}
