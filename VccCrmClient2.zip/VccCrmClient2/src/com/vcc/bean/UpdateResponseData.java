package com.vcc.bean;

public class UpdateResponseData {

	private ResponseData responseData;
	private AckMessage ackMessage;
	public ResponseData getResponseData() {
		return responseData;
	}
	public void setResponseData(ResponseData responseData) {
		this.responseData = responseData;
	}
	public AckMessage getAckMessage() {
		return ackMessage;
	}
	public void setAckMessage(AckMessage ackMessage) {
		this.ackMessage = ackMessage;
	}
	public String toString() 
	{
        return "Response [" + responseData.toString() + " ], AckMessage ["+ackMessage.toString()+"]";
	}
}
