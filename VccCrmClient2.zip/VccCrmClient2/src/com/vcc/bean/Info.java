package com.vcc.bean;

public class Info {

	private String bl;
	private String optout;
	private String ct;

	public String getBl() {
		return bl;
	}

	public void setBl(String bl) {
		this.bl = bl;
	}

	public String getOptout() {
		return optout;
	}

	public void setOptout(String optout) {
		this.optout = optout;
	}

	public String getCt() {
		return ct;
	}

	public void setCt(String ct) {
		this.ct = ct;
	}
	
	
	
	
	
}
