package com.PasswordGenerator;

public class QuestionDetails {
	private String institute;
	private String branch;
	private String semester;
	private String subject;
	private String module;
	private String question_code;
	private String time;
	private String exam_date;
	private String doq;
	private String difficulty;

	public String getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}

	public String getInstitute() {
		return institute;
	}

	public void setInstitute(String institute) {
		this.institute = institute;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getSemester() {
		return semester;
	}

	public void setSemester(String semester) {
		this.semester = semester;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getQuestion_code() {
		return question_code;
	}

	public void setQuestion_code(String question_code) {
		this.question_code = question_code;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getExam_date() {
		return exam_date;
	}

	public void setExam_date(String exam_date) {
		this.exam_date = exam_date;
	}

	public String getDoq() {
		return doq;
	}

	public void setDoq(String doq) {
		this.doq = doq;
	}

}
