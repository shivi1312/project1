package com.PasswordGenerator;

public class Question {

	private String question;
	private String doq;
	private String marks;
	private String subject;
	private String branch;
	private String semester;
	private String module;
	private String institute;

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getInstitute() {
		return institute;
	}

	public void setInstitute(String institute) {
		this.institute = institute;
	}

	public String getQuestion() {
		return question;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getSemester() {
		return semester;
	}

	public void setSemester(String semester) {
		this.semester = semester;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getDoq() {
		return doq;
	}

	public void setDoq(String doq) {
		this.doq = doq;
	}

	public String getMarks() {
		return marks;
	}

	public void setMarks(String marks) {
		this.marks = marks;
	}
	

}
