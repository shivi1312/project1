package com.PasswordGenerator;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UserController
 */
@WebServlet("/UserController")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDao dao;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserController() {
		super();
		dao = new UserDaoImplent();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String actionRequest = request.getParameter("actionRequest");
		System.out.println("----------------------------------------------------- action  = "+actionRequest);
		if (actionRequest.equals("register")) {
			String name = request.getParameter("name");
			String emailId = request.getParameter("emailId");
			String username = request.getParameter("userName");
			String password = request.getParameter("password");
			String contactNumber = request.getParameter("contactNumber");
			System.out.println(name);
			System.out.println(emailId);
			User user = new User();
			user.setName(name);
			user.setEmailId(emailId);
			user.setUserName(username);
			user.setPassword(password);
			user.setContactNumber(contactNumber);
			System.out.println(user.getName());
			// boolean i=dao.loginUser(user);
			int i = dao.addUser(user);
			if (i == 1) {
				RequestDispatcher rd = request.getRequestDispatcher("checkEmail.jsp");
				rd.forward(request, response);
			} else if (i == 2) {
				RequestDispatcher rd = request.getRequestDispatcher("successRegistration.jsp");
				rd.forward(request, response);
			} else {
				System.out.println(i);
			}
		} else if (actionRequest.equals("login")) {
			String username = request.getParameter("userName");
			String password = request.getParameter("password");
			User user = new User();
			user.setUserName(username);
			user.setPassword(password);
			int i = dao.loginUser(user);
			if (i == 1) {
				System.out.println("You r successfully logged in");
				HttpSession session = request.getSession();
				session.setAttribute("username", username);
				RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
				rd.forward(request, response);
			} else {
				System.out.println("Your are not login");
				RequestDispatcher rd = request.getRequestDispatcher("checkEmail.jsp");
				rd.forward(request, response);
			}
		} else if (actionRequest.equals("addQuestion")) {
			String question = request.getParameter("question");
			String doq = request.getParameter("doq");
			String module = request.getParameter("module");
			String subject = request.getParameter("subject");
			String semester = request.getParameter("semester");
			String branch = request.getParameter("branch");
			Question ques = new Question();
			ques.setQuestion(question);
			ques.setDoq(doq);
			ques.setModule(module);
			ques.setSubject(subject);
			ques.setSemester(semester);
			ques.setBranch(branch);
			int i = dao.addQuestion(ques);
			if (i == 1) {
				RequestDispatcher rd = request.getRequestDispatcher("successQusetion.jsp");
				rd.forward(request, response);
			} else {
				RequestDispatcher rd = request.getRequestDispatcher("addQuestion.jsp");
				rd.forward(request, response);
			}
		} else if (actionRequest.equals("showPaper")) {
			String subject = request.getParameter("subject");
			String semester = request.getParameter("semester");
			String branch = request.getParameter("branch");
			System.out.println("Show Question = "+subject+" "+semester+" "+branch);
			Question ques = new Question();
			 ques.setSubject(subject);
			 ques.setSemester(semester);
			 ques.setBranch(branch);
			List<Question> list =  dao.showQuestion(ques);
			System.out.println(list);
			request.setAttribute("Que", list);
			RequestDispatcher rd = request.getRequestDispatcher("viewQuestion.jsp");
			rd.forward(request, response);
		} else if (actionRequest.equals("logout")) {
			HttpSession session = request.getSession(false);
			session.setAttribute("username", null);
			session.invalidate();
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		} else if (actionRequest.equals("createPaper")) {
			System.out.println("Exam Paper Controller......");
			String institute = request.getParameter("institute");
			String branch = request.getParameter("branch");
			String semester = request.getParameter("semester");
			String subject = request.getParameter("subject");
			String paperCode = request.getParameter("paperCode");
			String time = request.getParameter("time");
			String date = request.getParameter("date");
			QuestionDetails details = new QuestionDetails();
			details.setInstitute(institute);
			details.setBranch(branch);
			details.setSemester(semester);
			details.setSubject(subject);
			details.setQuestion_code(paperCode);
			details.setTime(time);
			details.setExam_date(date);
			UserDao dao = new UserDaoImplent();
			List<Question> list = dao.getExamQuestion(details);
			System.out.println("List = "+list);
			RequestDispatcher dispatcher = request.getRequestDispatcher("selectExamQuestion.jsp");
			request.setAttribute("details", details);
			request.setAttribute("question", list);
			dispatcher.forward(request, response);
		} else if (actionRequest.equals("delete_question")) {
			String question = request.getParameter("question");
			System.out.println(question);
			UserDao dao = new UserDaoImplent();
			int a = dao.deleteQuestion(question);
			if (a == 1) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("delete_question.jsp");
				dispatcher.forward(request, response);
			}
		} else if (actionRequest.equals("createUnitPaper")) {
			String institute = request.getParameter("institute");
			String branch = request.getParameter("branch");
			String semester = request.getParameter("semester");
			String difficulty = request.getParameter("difficulty");
			String subject = request.getParameter("subject");
			String module = request.getParameter("module");
			String paper_code = request.getParameter("paperCode");
			String time = request.getParameter("time");
			String date = request.getParameter("date");
			QuestionDetails details = new QuestionDetails();
			details.setInstitute(institute);
			details.setBranch(branch);
			details.setSemester(semester);
			details.setDifficulty(difficulty);
			details.setSubject(subject);
			details.setModule(module);
			details.setQuestion_code(paper_code);
			details.setTime(time);
			details.setExam_date(date);
			UserDao dao = new UserDaoImplent();
			List<Question> questions = dao.getQuestionByDifficulty(details);
			RequestDispatcher dispatcher = request.getRequestDispatcher("set_question.jsp");
			request.setAttribute("question_detail", details);
			request.setAttribute("question", questions);
			dispatcher.forward(request, response);

		} else if (actionRequest.equals("question_selected")) {
			String institute = request.getParameter("institute");
			String branch = request.getParameter("branch");
			String semester = request.getParameter("semester");
			String difficulty = request.getParameter("difficulty");
			String subject = request.getParameter("subject");
			String module = request.getParameter("module");
			String paperCode = request.getParameter("papercode");
			String time = request.getParameter("time");
			String date = request.getParameter("date");
			String questions[] = request.getParameterValues("questions");
			QuestionDetails details = new QuestionDetails();
			details.setInstitute(institute);
			details.setBranch(branch);
			details.setSemester(semester);
			details.setDifficulty(difficulty);
			details.setSubject(subject);
			details.setModule(module);
			details.setQuestion_code(paperCode);
			details.setTime(time);
			details.setExam_date(date);
			RequestDispatcher dispatcher = request.getRequestDispatcher("unit_paper.jsp");
			request.setAttribute("details", details);
			request.setAttribute("question", questions);
			dispatcher.forward(request, response);
		} else if (actionRequest.equals("exam_question_selected")) {
			String institute = request.getParameter("institute");
			String branch = request.getParameter("branch");
			String semester = request.getParameter("semester");
			String subject = request.getParameter("subject");
			String paperCode = request.getParameter("papercode");
			String time = request.getParameter("time");
			String date = request.getParameter("date");
			QuestionDetails details = new QuestionDetails();
			details.setInstitute(institute);
			details.setBranch(branch);
			details.setSemester(semester);
			details.setSubject(subject);
			details.setQuestion_code(paperCode);
			details.setTime(time);
			details.setExam_date(date);
			String easy_question[] = request.getParameterValues("easy_question");
			String medium_question[] = request.getParameterValues("medium_question");
			String defficult_question[] = request.getParameterValues("defficult_question");
			RequestDispatcher dispatcher = request.getRequestDispatcher("paper.jsp");
			request.setAttribute("details", details);
			request.setAttribute("easy_question", easy_question);
			request.setAttribute("medium_question", medium_question);
			request.setAttribute("defficult_question", defficult_question);
			dispatcher.forward(request, response);
		}
		else if (actionRequest.equals("contactUs")) {
			String name = request.getParameter("NAME");
			String email = request.getParameter("EMAIL");
			String phone = request.getParameter("PHONE");
			String message = request.getParameter("MESSAGE");
			
			ContactUs contact = new ContactUs();
			contact.setName(name);
			contact.setEmail(email);
			contact.setPhone(phone);
			contact.setMessage(message);
			UserDao dao=new UserDaoImplent();
			
			int i=dao.saveContact(contact);
			RequestDispatcher dispatcher = request.getRequestDispatcher("ContactUs.jsp");
			System.out.println("contact saving finished....");
			dispatcher.forward(request, response);
		}
	}
}
