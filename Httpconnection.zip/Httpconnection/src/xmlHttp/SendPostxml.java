package xmlHttp;

import java.io.IOException;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.ssl.SSLContextBuilder;

public class SendPostxml {

	public static void main(String[] args) throws IOException {
//try {
////		String request = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cai3=\"http://schemas.ericsson.com/cai3g1.2/\" xmlns:mtas=\"http://schemas.ericsson.com/ema/UserProvisioning/MTAS/\">\r\n"
////				+ "   <soapenv:Header>\r\n"
////				+ "      <cai3:SessionId>8bc4def3884147818caa08f532a75378</cai3:SessionId>\r\n"
////				+ "   </soapenv:Header>\r\n"
////				+ "   <soapenv:Body>\r\n"
////				+ "      <cai3:Get>\r\n"
////				+ "         <cai3:MOType>Subscription@http://schemas.ericsson.com/ema/UserProvisioning/MTAS/</cai3:MOType>\r\n"
////				+ "         <cai3:MOId>\r\n"
////				+ "            <mtas:publicId>sip:+18769907318@ims.mnc180.mcc338.3gppnetwork.org</mtas:publicId>\r\n"
////				+ "         </cai3:MOId>\r\n"
////				+ "      </cai3:Get>\r\n"
////				+ "   </soapenv:Body>\r\n"
////				+ "</soapenv:Envelope>";
//	
//	String request = "<soapenv:Envelope xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/' xmlns:cai3='http://schemas.ericsson.com/cai3g1.2/'><soapenv:Header/><soapenv:Body><cai3:Login><cai3:userId>TelemuneRBT</cai3:userId><cai3:pwd>System123@</cai3:pwd></cai3:Login></soapenv:Body></soapenv:Envelope>";
//
//
//		URL url = new URL("http://10.236.112.10:8080/CAI3G1.2/services/CAI3G1.2");
//		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//		System.out.println(connection);
//
//		
//	connection.setConnectTimeout(60000);
//		connection.setReadTimeout(60000);
//
//		
//		connection.setDoOutput(true);
//        System.out.println("---doOut");
//		connection.setUseCaches(true);
//		connection.setRequestMethod("POST");
//        System.out.println("---doOut");
//
//		connection.setRequestProperty("Accept", "text/xml");
//		connection.setRequestProperty("Content-Type", "text/xml");
//        System.out.println("---doOut");
//try {
//		OutputStream outputStream = connection.getOutputStream();
//		byte[] b = request.getBytes("UTF-8");
//		outputStream.write(b);
//		outputStream.flush();
//		outputStream.close();
//        System.out.println("---doOut");
//
//		InputStream inputStream = connection.getInputStream();
//		byte[] res = new byte[2048];
//		int i = 0;
//		StringBuilder response = new StringBuilder();
//		while ((i = inputStream.read(res)) != -1) {
//			response.append(new String(res, 0, i));
//		}
//		inputStream.close();
//
//		System.out.println("Response= " + response.toString());
//}
//catch(Exception e) {
//System.out.println(e);	
//}
//
//}
//catch (Exception e) {
//
//System.out.println(e);
//	}

		// start new code

		try {
			CloseableHttpClient httpClient = HttpClients.custom().build();

			HttpPost post = new HttpPost("http://10.236.112.10:8080/CAI3G1.2/services/CAI3G1.2");
			System.out.println(post.isAborted());

		

			post.addHeader("Content-Type", "text/xml");
			post.addHeader("Accept", "text/xml");
			post.addHeader("Except", "100-continue");

		

			StringBuffer responseXml = new StringBuffer();
			String xmlString = "<soapenv:Envelope xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/' xmlns:cai3='http://schemas.ericsson.com/cai3g1.2/'><soapenv:Header/><soapenv:Body><cai3:Login><cai3:userId>TelemuneRBT</cai3:userId><cai3:pwd>System123@</cai3:pwd></cai3:Login></soapenv:Body></soapenv:Envelope>";
				
			
			StringEntity entity = new StringEntity(xmlString);
			post.setEntity(entity);

			HttpResponse response = httpClient.execute(post);
			
			System.out.println(response.getStatusLine().getStatusCode());

//			if (response.getStatusLine().getStatusCode() != 200) {
//				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
//			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
