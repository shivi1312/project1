package xmlHttp;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;  
public class ReadXMLFileExample {
	public static void main(String argv[])   
	{  
	try   
	{  
	//creating a constructor of file class and parsing an XML file 
	String xml = Response=<?xml version='1.0' encoding='UTF-8'?><S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/"><S:Body><LoginResponse xmlns="http://schemas.ericsson.com/cai3g1.2/"><sessionId>392fa4d7e2854066814e4c2658d67b49</sessionId><baseSequenceId>1816513353</baseSequenceId></LoginResponse></S:Body></S:Envelope>	;
	//an instance of factory that gives a document builder  
	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
	//an instance of builder to parse the specified xml file  
	DocumentBuilder db = dbf.newDocumentBuilder();  
	Document doc = db.parse(xml);  
	doc.getDocumentElement().normalize();  
	System.out.println("Root element: " + doc.getDocumentElement().getNodeName());  
	NodeList nodeList = doc.getElementsByTagName("student");  
	// nodeList is not iterable, so we are using for loop  
	for (int itr = 0; itr < nodeList.getLength(); itr++)   
	{  
	Node node = nodeList.item(itr);  
	System.out.println("\nNode Name :" + node.getNodeName());  
	if (node.getNodeType() == Node.ELEMENT_NODE)   
	{  
	Element eElement = (Element) node;  
	System.out.println("Student id: "+ eElement.getElementsByTagName("sessionId").item(1).getTextContent());  
	
	}  
	} 
	
	}
	catch (Exception e)   
	{  
	e.printStackTrace();  
	 
	}  
	}
}



