package xmlHttp;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class Send {
public static void main(String[] args) {
	try {
		URL url = new URL("http://10.236.112.10:8080/CAI3G1.2/services/CAI3G1.2");
		HttpURLConnection http = (HttpURLConnection)url.openConnection();
		http.setRequestMethod("POST");
		http.setDoOutput(true);
		http.setRequestProperty("Content-Type", "application/soap+xml");
//
//		//String data = "<soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">\n  <soap12:Body>\n    <FahrenheitToCelsius xmlns=\"https://www.w3schools.com/xml/\">\n      <Fahrenheit>75</Fahrenheit>\n    </FahrenheitToCelsius>\n  </soap12:Body>\n</soap12:Envelope>";
//
////		String data = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cai3=\"http://schemas.ericsson.com/cai3g1.2/\" xmlns:mtas=\"http://schemas.ericsson.com/ema/UserProvisioning/MTAS/\">\r\n"
////		+ "   <soapenv:Header>\r\n"
////		+ "      <cai3:SessionId>8bc4def3884147818caa08f532a75378</cai3:SessionId>\r\n"
////		+ "   </soapenv:Header>\r\n"
////		+ "   <soapenv:Body>\r\n"
////		+ "      <cai3:Get>\r\n"
//		+ "         <cai3:MOType>Subscription@http://schemas.ericsson.com/ema/UserProvisioning/MTAS/</cai3:MOType>\r\n"
//		+ "         <cai3:MOId>\r\n"
//		+ "            <mtas:publicId>sip:+18769907318@ims.mnc180.mcc338.3gppnetwork.org</mtas:publicId>\r\n"
//		+ "         </cai3:MOId>\r\n"
//		+ "      </cai3:Get>\r\n"
//		+ "   </soapenv:Body>\r\n"
//		+ "</soapenv:Envelope>";
		
		String data = "<soapenv:Envelope xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/' xmlns:cai3='http://schemas.ericsson.com/cai3g1.2/'><soapenv:Header/><soapenv:Body><cai3:Login><cai3:userId>TelemuneRBT</cai3:userId><cai3:pwd>System123@</cai3:pwd></cai3:Login></soapenv:Body></soapenv:Envelope>";
		

		
		
		
		byte[] out = data.getBytes(StandardCharsets.UTF_8);

		OutputStream stream = http.getOutputStream();
		stream.write(out);

		System.out.println(http.getResponseCode() + " " + http.getResponseMessage());
		
		
		
		InputStream inputStream = http.getInputStream();
		byte[] res = new byte[2048];
		int i = 0;
		StringBuilder response = new StringBuilder();
		while ((i = inputStream.read(res)) != -1) {
			response.append(new String(res, 0, i));
		}
		inputStream.close();

		System.out.println("Response= " + response.toString());

		http.disconnect();
		
	} catch (Exception e) {
		e.printStackTrace();
	}

}
}
