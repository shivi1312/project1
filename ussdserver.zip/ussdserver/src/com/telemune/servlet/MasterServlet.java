package com.telemune.servlet;

import com.telemune.dbutilities.ConnectionPool;
import com.telemune.ussd.webif.Global;
import com.telemune.ussd.webif.USSDRequestBean;
import com.telemune.ussd.webif.TSSJavaUtil;
import com.telemune.ussd.webif.UssdRequestProcessor;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.xml.DOMConfigurator;
import org.apache.commons.lang.StringUtils;

public class MasterServlet extends HttpServlet
{
	static final Logger logger = Logger.getLogger(MasterServlet.class);
	ConnectionPool conPool=null;

	public void init()throws ServletException
	{
		logger.info("***********************Telemune USSD Server Module*****************************************************");
		logger.info("*************************************Cache Instance :" + TSSJavaUtil.instance());
		/*String envVar=System.getenv("CATALINA_HOME");
		envVar=(envVar==null ? "/home/tomcat/apache-tomcat-7.0.30/bin/ussdserver_log4j.properties":envVar+"/bin/ussdserver_log4j.properties");
		PropertyConfigurator.configure(envVar);*/
		
		String prefix =  getServletContext().getRealPath("/");
	    String file = getInitParameter("log4j-init-file");
	    // if the log4j-init-file is not set, then no point in trying
	    if(file != null) {
	        DOMConfigurator.configureAndWatch(prefix+file);
	        //PropertyConfigurator.configure(prefix+file);
	    }
		conPool=new ConnectionPool();
		//logger.info("Loger Property File Path ["+envVar+"]");	
		logger.info("Loger Property File Path ["+prefix+file+"]");
	}

	public void doService(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException
	{
		USSDRequestBean reqBean=null;
		UssdRequestProcessor ussdRequestProcessor=null;
		PrintWriter pr=null;

		try
		{
			if(!(conPool==null))
			{
				String smscId = null,data=null,msisdn=null;
				//RequestParameterBean localData_Object = null;

				logger.info("Request URI [ "+paramHttpServletRequest.getRequestURI()+" ] Get Query String [ "+paramHttpServletRequest.getQueryString()+" ]");
				
				smscId = paramHttpServletRequest.getParameter(Global.SMSC_ID_TAG);	
				data = paramHttpServletRequest.getParameter(Global.DATA_TAG);
				//data=data.trim().replace("%23","#");
				msisdn = paramHttpServletRequest.getParameter(Global.MSISDN_TAG);

				if(checkParameterIsNull(smscId,data,msisdn))
				{
					logger.info("Getting Parameter Lists ARE .... smscId [ "+smscId+" ] data [ "+data+" ] msisdn [ "+msisdn+" ]");
                    
					reqBean=new USSDRequestBean();

					reqBean.setSmscId(smscId.trim());
					reqBean.setData(data.trim());
					reqBean.setMsisdn(msisdn.trim());

					ussdRequestProcessor=new UssdRequestProcessor(conPool,reqBean);

					int response=ussdRequestProcessor.processRequest();
					
					//logger.error(msisdn+"reqBean["+reqBean+"]ussdRequestProcessor["+ussdRequestProcessor+"]response["+response+"]");

					if(response<0)
						logger.error(msisdn+"#Error Return from processRequest() function Error Code Is || "+response);
					else
						logger.info(msisdn+"#Success Return from processRequest() function Success result is || "+response);
					paramHttpServletRequest.setCharacterEncoding("UTF-8");
					paramHttpServletResponse.setCharacterEncoding("UTF-8");
					paramHttpServletResponse.setContentType("text/html; charset=UTF-8"); 

					pr= paramHttpServletResponse.getWriter();	
				
					if(reqBean.getMsg()!=null)
					pr.write(reqBean.getMsg());
					pr.close(); 						
				} else {
					logger.info("Some parameter is NULL so no process this request... smscId [ "+smscId+" ] data [ "+data+" ] msisdn [ "+msisdn+" ]");
				}
			} else {
				logger.error("Connection Pool Object NULL so can not process This Request || "+conPool);
			}
		} catch(Exception ex) {
			logger.error("Exception Inside Mster Servlet For Processing request",ex);
			ex.printStackTrace();

		} finally {
			reqBean=null;
			ussdRequestProcessor=null;
		}
	}

	// Check Validation of incoming command
	boolean checkParameterIsNull(String... parameterList) {
		logger.info("Inside checkParameterIsMssing Function Parameter Lists Are ... "+parameterList.toString());
		boolean validation = true;
		try {
			for (int loop = 0; loop < parameterList.length; loop++) {
				if (StringUtils.isBlank(parameterList[loop])) {
					validation = false;
					logger.info("Some Parameter is NULL so retturn FALSE flag || " + validation);
					break;
				} else {
					logger.debug("Parameter at index [ " + loop + " ] is [ " + parameterList[loop] + " ]");
				}
			}

		} catch (Exception ex) {
			logger.error("Exception Inside checkParameterIsNull() function ", ex);
		}

		return validation;
	}//checkParameterIsNull
	
	public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException
	{
     //        logger.info("########in do post");
		doService(paramHttpServletRequest,paramHttpServletResponse);
	}

	public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException
	{
		doService(paramHttpServletRequest,paramHttpServletResponse);
        //     logger.info("########in do GET");
	}

	public void destroy()
	{
		super.destroy();
	}
}
