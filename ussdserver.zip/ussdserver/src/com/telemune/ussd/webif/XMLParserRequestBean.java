package com.telemune.ussd.webif;

  /*

CallUUID
CallStatus
From
To
Digits
Direction
HangupCause


CallStatus Values Are

ringing
completed
in-progress

 */
 


public class XMLParserRequestBean {
	
	private String callUniqueId;
	private String callingNumber;
	private String calledNumber;
	private String digits;
	private String callDirection;
	private String callStatus;
	private String hangupCause;
	
	
	public XMLParserRequestBean() 
	{
		super();
		callDirection=Global.CALL_DIRECTION_VALUE;
	}

	
	public String getCallUniqueId() {
		return callUniqueId;
	}

	public void setCallUniqueId(String callUniqueId) {
		this.callUniqueId = callUniqueId;
	}

	public String getCallingNumber() {
		return callingNumber;
	}

	public void setCallingNumber(String callingNumber) {
		this.callingNumber = callingNumber;
	}

	public String getCalledNumber() {
		return calledNumber;
	}

	public void setCalledNumber(String calledNumber) {
		this.calledNumber = calledNumber;
	}

	public String getDigits() {
		return digits;
	}

	public void setDigits(String digits) {
		this.digits = digits;
	}

	public String getCallDirection() {
		return callDirection;
	}

	public void setCallDirection(String callDirection) {
		this.callDirection = callDirection;
	}

	public String getCallStatus() {
		return callStatus;
	}

	public void setCallStatus(String callStatus) {
		this.callStatus = callStatus;
	}

	
	public String getHangupCause() {
		return hangupCause;
	}

	public void setHangupCause(String hangupCause) {
		this.hangupCause = hangupCause;
	}


	@Override
	public String toString() {
		return "XMLParserRequestBean [callDirection=" + callDirection
				+ ", callStatus=" + callStatus + ", callUniqueId="
				+ callUniqueId + ", calledNumber=" + calledNumber
				+ ", callingNumber=" + callingNumber + ", digits=" + digits
				+ ", hangupCause=" + hangupCause + "]";
	}

	
	
}
