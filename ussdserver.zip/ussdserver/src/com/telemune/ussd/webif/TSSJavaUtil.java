package com.telemune.ussd.webif;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.log4j.Logger;

public class TSSJavaUtil
{
	private static final Logger logger = Logger.getLogger(TSSJavaUtil.class);
	private static ConcurrentHashMap<String, DataBean> cache = new ConcurrentHashMap<String, DataBean>();
	private static TSSJavaUtil instance_ = null;
	private static Properties properties = null;
	private String smsOriginationNumber = "TELEMUNE";
	private int timeOut = -1;
	private static String HTTPIP=null;
	private static String HTTPPORT=null;
	private static String STATUS="R";
	private static String MAX_HTTP_POOL_SIZE="300";
	private static String MIN_HTTP_ROUTE_SIZE="20";
	private static String MAX_HTTP_ROUTE_SIZE="250";
	private static String COUNTRY_CODE=null;

	private static String HTTP_URL="";

	public static synchronized TSSJavaUtil instance()
	{
		if (instance_ == null)
			instance_ = new TSSJavaUtil();
		return instance_;
	}

	public static synchronized TSSJavaUtil reloadCache()
	{
		instance_ = new TSSJavaUtil();
		return instance_;
	}

	private TSSJavaUtil()
	{
		logger.info("Inside constructor of GlobelCache()");

		properties = new Properties();
		try
		{
			String envVar=System.getenv("CATALINA_HOME");
			envVar=(envVar==null ? "/home/tomcat/apache-tomcat-7.0.30/bin/telemune_ussdserver.properties":envVar+"/bin/telemune_ussdserver.properties");
			FileInputStream localFileInputStream = new FileInputStream(envVar);
			properties.load(localFileInputStream);
			logger.info("Load Properties File [ "+envVar+" ]");
		}
		catch (Exception localException)
		{
			logger.error("Exception from properties file" + localException.toString());
			localException.printStackTrace();
			return;
		}

		String str = properties.getProperty("SHORTCODE");
		smsOriginationNumber = properties.getProperty("SMS_ORIGINATION_NUMBER");
		timeOut = Integer.parseInt(properties.getProperty("TIMEOUT"));


		HTTPIP = properties.getProperty("HTTPIP");
		HTTPPORT=properties.getProperty("HTTPPORT");
		STATUS=properties.getProperty("STATUS");
		MAX_HTTP_POOL_SIZE=properties.getProperty("MAX_HTTP_POOL_SIZE");
		MIN_HTTP_ROUTE_SIZE=properties.getProperty("MIN_HTTP_ROUTE_SIZE");
		MAX_HTTP_ROUTE_SIZE=properties.getProperty("MAX_HTTP_ROUTE_SIZE");
		COUNTRY_CODE=properties.getProperty("COUNTRY_CODE");
		HTTP_URL=properties.getProperty("HTTP_URL");

		logger.info("shortCode [" + str + "] SMS_ORIGINATION_NUMBER [" + this.smsOriginationNumber + "] and timeout " + timeOut + "]");
		logger.info(" HTTPIP [ "+HTTPIP+" ] HTTPPORT [ "+HTTPPORT+" ] STATUS [ "+STATUS+" ] MAX_HTTP_POOL_SIZE [ "+MAX_HTTP_POOL_SIZE+" ] MIN_HTTP_ROUTE_SIZE  ["+MIN_HTTP_ROUTE_SIZE+" ] MAX_HTTP_ROUTE_SIZE [ "+MAX_HTTP_ROUTE_SIZE+" ] COUNTRY_CODE [ "+COUNTRY_CODE+" ]");
	}

	public void loadPropertiesFile()
	{
		properties = new Properties();
		try
		{
			String envVar=System.getenv("CATALINA_HOME");
			envVar=(envVar==null ? "/home/tomcat/apache-tomcat-7.0.30/bin/telemune_ussdserver.properties":envVar+"/bin/telemune_ussdserver.properties");
			FileInputStream localFileInputStream = new FileInputStream(envVar);
			properties.load(localFileInputStream);
			logger.info("Load Properties File [ "+envVar+" ]");
		}
		catch (Exception localException)
		{
			logger.error("Exception from properties file" + localException.toString());
			localException.printStackTrace();
			return;
		}

		String str = properties.getProperty("SHORTCODE");
		smsOriginationNumber = properties.getProperty("SMS_ORIGINATION_NUMBER");
		timeOut = Integer.parseInt(properties.getProperty("TIMEOUT"));


		HTTPIP = properties.getProperty("HTTPIP");
		HTTPPORT=properties.getProperty("HTTPPORT");
		STATUS=properties.getProperty("STATUS");
		MAX_HTTP_POOL_SIZE=properties.getProperty("MAX_HTTP_POOL_SIZE");
		MIN_HTTP_ROUTE_SIZE=properties.getProperty("MIN_HTTP_ROUTE_SIZE");
		MAX_HTTP_ROUTE_SIZE=properties.getProperty("MAX_HTTP_ROUTE_SIZE");
		COUNTRY_CODE=properties.getProperty("COUNTRY_CODE");
		HTTP_URL=properties.getProperty("HTTP_URL");

		logger.info("shortCode [" + str + "] SMS_ORIGINATION_NUMBER [" + this.smsOriginationNumber + "] and timeout " + timeOut + "]");
		logger.info(" HTTPIP [ "+HTTPIP+" ] HTTPPORT [ "+HTTPPORT+" ] STATUS [ "+STATUS+" ] MAX_HTTP_POOL_SIZE [ "+MAX_HTTP_POOL_SIZE+" ] MIN_HTTP_ROUTE_SIZE  ["+MIN_HTTP_ROUTE_SIZE+" ] MAX_HTTP_ROUTE_SIZE [ "+MAX_HTTP_ROUTE_SIZE+" ] COUNTRY_CODE [ "+COUNTRY_CODE+" ]");

	
	}
	public String getSmsOriginationNumber()
	{
		return this.smsOriginationNumber;
	}



	public int getTimeOut()
	{
		return this.timeOut;
	}

	public DataBean getData(String paramString)
	{
		try
		{
			if (cache.containsKey(paramString))
				return (DataBean)cache.get(paramString);
			return null;
		}
		catch (Exception localException)
		{
			logger.error("Exception occoured in getData() method " ,localException);
		}
		return null;
	}

	public void putData(String paramString, DataBean paramDataBean)
	{
		try
		{
			cache.put(paramString, paramDataBean);
			logger.info("data has successfully inserted into cache for Transaction ID[" + paramString + "]");
		}
		catch (Exception localException)
		{
			logger.error("Exception occoured in putData() method ",localException);
		}
	}

	public void removeData(String paramString)
	{
		try
		{
			cache.remove(paramString);
			logger.info(paramString+"#Data has successfully removed from cache for Transaction ID" + paramString + "]");
		}
		catch (Exception localException)
		{
			logger.error("Exception occoured in removeData() method ",localException);
		}
	}

	public void putAndSendData(String msisdn, String transactionID, String smscID,String calledNumber)
	{
		logger.info("Inside putAndSendData() function for storing Cache Data with Msisdn [" + msisdn + "] transactionID [" + transactionID + "] and smscID [" + smscID + "] calledNumber [ "+calledNumber+" ]");

		DataBean localDataBean = new DataBean();
		localDataBean.setMsisdn(msisdn);
		localDataBean.setTranId(transactionID);
		localDataBean.setSmscId(smscID);
		localDataBean.setCalledNumber(calledNumber);
		instance().putData(transactionID, localDataBean);

	}

	public void removeAndPut(String paramString, DataBean paramDataBean)
	{
		try
		{
			cache.remove(paramString);
			logger.info("Dats has successfully removed from cache for Transaction ID [ " + paramString + "]");
			cache.put(paramString, paramDataBean);

			logger.info("Data has successfully inserted into cache for Transaction ID [" +paramString+ "]");
		}
		catch (Exception localException)
		{
			logger.error("Exception occoured in removeData() method ",localException);
		}
	}


	public static String getHTTPIP() {
		return HTTPIP;
	}

	public static void setHTTPIP(String hTTPIP) {
		HTTPIP = hTTPIP;
	}

	public static String getHTTPPORT() {
		return HTTPPORT;
	}

	public static void setHTTPPORT(String hTTPPORT) {
		HTTPPORT = hTTPPORT;
	}

	public static String getSTATUS() {
		return STATUS;
	}

	public static void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}

	public static String getMAX_HTTP_POOL_SIZE() {
		return MAX_HTTP_POOL_SIZE;
	}

	public static void setMAX_HTTP_POOL_SIZE(String mAXHTTPPOOLSIZE) {
		MAX_HTTP_POOL_SIZE = mAXHTTPPOOLSIZE;
	}

	public static String getMIN_HTTP_ROUTE_SIZE() {
		return MIN_HTTP_ROUTE_SIZE;
	}

	public static void setMIN_HTTP_ROUTE_SIZE(String mINHTTPROUTESIZE) {
		MIN_HTTP_ROUTE_SIZE = mINHTTPROUTESIZE;
	}

	public static String getMAX_HTTP_ROUTE_SIZE() {
		return MAX_HTTP_ROUTE_SIZE;
	}

	public static void setMAX_HTTP_ROUTE_SIZE(String mAXHTTPROUTESIZE) {
		MAX_HTTP_ROUTE_SIZE = mAXHTTPROUTESIZE;
	}

	public static String getCOUNTRY_CODE() {
		return COUNTRY_CODE;
	}

	public static void setCOUNTRY_CODE(String cOUNTRYCODE) {
		COUNTRY_CODE = cOUNTRYCODE;
	}

	public static String getHTTP_URL() {
		return HTTP_URL;
	}

	public static void setHTTP_URL(String hTTPURL) {
		HTTP_URL = hTTPURL;
	}

}

