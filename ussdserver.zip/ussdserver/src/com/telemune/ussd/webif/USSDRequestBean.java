package com.telemune.ussd.webif;

public class USSDRequestBean 
{
	
	private String smscId;
	private String data;
	private String msisdn;
	private String msg;
	
	
	public USSDRequestBean()
	{
		super();
	
	}

	public String getSmscId() {
		return smscId;
	}

	public void setSmscId(String smscId) {
		this.smscId = smscId;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
		public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}


	
}
