package com.telemune.ussd.webif;

public class ErrorCode 
{
	public static final int INSUFFICIENT_PARAMETER_ERROR=-11;
	public static final int NULL_RESPONSE_RETURN_FROM_PARSER=-12;
	public static final int ERROR_IN_PARSE_XML=-13;
	public static final int UNKNOWN_ERROR=-99;
	
}
