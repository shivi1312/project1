package com.telemune.ussd.webif;

public class DataBean
{

	private String tranId = "";
	private String smscId = "";
	private String msisdn="";
	private String calledNumber="";
	private String data="";

	public DataBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getTranId() {
		return tranId;
	}
	public void setTranId(String tranId) {
		this.tranId = tranId;
	}
	public String getSmscId() {
		return smscId;
	}
	public void setSmscId(String smscId) {
		this.smscId = smscId;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getCalledNumber() {
		return calledNumber;
	}
	public void setCalledNumber(String calledNumber) {
		this.calledNumber = calledNumber;
	}

	@Override
	public String toString() {
		return "DataBean [calledNumber=" + calledNumber + ", data=" + data
				+ ", msisdn=" + msisdn + ", smscId=" + smscId + ", tranId="
				+ tranId + "]";
	}

	

}
