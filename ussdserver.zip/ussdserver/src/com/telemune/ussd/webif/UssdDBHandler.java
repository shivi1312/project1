package com.telemune.ussd.webif;
/*
 * Rajendra
 */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.ResultSet;
import com.telemune.dbutilities.*;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import org.apache.log4j.Logger;
import java.util.*;
import org.apache.commons.lang.StringUtils;

public class UssdDBHandler {

	static final Logger logger=Logger.getLogger(UssdDBHandler.class);
	private ConnectionPool conPool=null;
	public UssdDBHandler(ConnectionPool conPool)
	{
		super();
		this.conPool=conPool;
	}

	public UssdDBHandler() 
	{
		super();
	}

	public int  sentLbsMessage(String message,String msisdn,int opCode,String smscId)
	{
		logger.info("Inside Function sentLbsMessage() send Message Templates [ "+message+" ] Msisdn [ "+msisdn+" ] OpCode [ "+opCode+" ] SMSC-ID [ "+smscId+" ]");
		int retVal=-1;
		String messageText=message;
		PreparedStatement pstmt=null;
		Connection con=null;
		con=conPool.getConnection();
		try
		{
			logger.info("Get Status from properties [ "+TSSJavaUtil.instance().getSTATUS()+"] SMS Origination Number [ "+TSSJavaUtil.instance().getSmsOriginationNumber()+" ]");
			if(!StringUtils.isBlank(messageText))
			{
				String query = "insert into GMAT_MESSAGE_STORE (RESPONSE_ID,REQUEST_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT,SUBMIT_TIME,STATUS,USSD_OPCODE,SMSC_ID) " +
				"values (GMAT_RESPONSE_ID_SEQ.nextval,GMAT_REQUEST_ID_SEQ.nextval,?,?,?,sysdate,?,?,?)";
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, TSSJavaUtil.instance().getSmsOriginationNumber());
				pstmt.setString(2, msisdn);
				pstmt.setString(3, message);
				pstmt.setString(4,TSSJavaUtil.instance().getSTATUS());
				pstmt.setInt(5, opCode);
				pstmt.setString(6, smscId);
				retVal = pstmt.executeUpdate();
				pstmt.close();

			}
			else
			{
				logger.info("Message Template is null");	
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			retVal=-99;
			logger.error("There is exception in sentLbsMessage function || ",ex);
		}finally
		{
			try {
				if(pstmt!=null)pstmt.close();
				if(con !=null)conPool.free(con);
			} catch (SQLException ex) {
				logger.error("Exception  Inside sentLbsMessage() function || ",ex);
			}
		}

		return retVal;
	}//sentLbsMessage()

}
