package com.telemune.ussd.webif;
/*
   CallUUID
   CallStatus
   From
   To
   Digits
   Direction
   HangupCause


   CallStatus Values Are

   ringing
   completed
   in-progress

*/

public  class Global 
{
	// XML Parser Parameter Lists...

	public static final String CALL_UNIQUE_ID="CallUUID";
	public static final String CALL_STATUS="CallStatus";
	public static final String CALLING_NUMBER="From";  // User Msisdn
	public static final String CALLED_NUMBER="To"; // Short Code
	public static final String DIGIT="Digits";
	public static final String CALL_DIRECTION="Direction";
	public static final String CALL_HANGUP_CAUSE="HangupCause";


	//Call Hangup cause...
	public static final String CALL_DISCONNECT_FROM_XML="NORMAL_CLEARING";
	public static final String CALL_DISCCONNECT_GATEWAY="TIMEOUT";
	public static final String CALL_DISCONNECT_ERROR="APPLICATION_ERROR";

	// Call Status Lists...

	public static final String CALL_IN_RING="ringing";
	public static final String CALL_COMPLETED="completed";
	public static final String CALL_IN_PROGREES="in-progress";

	// Call Direction

	public static final String CALL_DIRECTION_VALUE="inbound";

	// Parameter Get From USSD Gateway....

	public static String SMSC_ID_TAG="smscid"; 
	public static String MSISDN_TAG="msisdn";
	public static String DATA_TAG="params";



}
