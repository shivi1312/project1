package com.telemune.ussd.webif;

import java.io.ByteArrayInputStream;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import org.apache.log4j.Logger;

public class XMLParsingUtility 
{
	/*
	 * <?xml version="1.0" encoding="UTF-8"?>
  		<UssdEnvelop>
  		<Msisdn>TestMsisdn</Msisdn>
  		<Message>Test-Message</Message>
  		<TransactionId>123456</TransactionId>
  		<TransStatus>0</TransStatus>
  		</UssdEnvelop>
	 */
	static final Logger logger = Logger.getLogger(XMLParsingUtility.class);
	public XMLParserResponseBean  getXMLToBeanData(String xmlData)
	{
		XMLInputFactory xmlif=null;
		xmlif=XMLInputFactory.newInstance();
		xmlif.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES,Boolean.TRUE);
		xmlif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES,Boolean.FALSE);
		xmlif.setProperty(XMLInputFactory.IS_COALESCING, Boolean.FALSE);


		XMLStreamReader xmlr=null;
		XMLParserResponseBean resultBean=new XMLParserResponseBean();
		try
		{

			xmlr=xmlif.createXMLStreamReader(new ByteArrayInputStream(xmlData.getBytes("UTF-8")));
			int eventType = xmlr.getEventType();
			int reqType=-1;

			while (xmlr.hasNext()) 
			{
				eventType = xmlr.next();

				if(xmlr.isStartElement())
				{
					String tagName=xmlr.getName().toString();
					
					
					if(tagName.equalsIgnoreCase("UssdEnvelop"))
					{
						logger.info(" Tag Name || "+tagName);
						continue;
					}
					else
					{

						String text=xmlr.getElementText().trim();
						
						logger.info("Tag Name ["+tagName+"] Value ["+text+"]");

						if(tagName.equalsIgnoreCase("Msisdn"))
						{
							
							logger.info("Msisdn Text || "+text);
							
							resultBean.setMsisdn(text);
							continue;
						}
						else if(tagName.equalsIgnoreCase("TransactionId"))
						{
							
							logger.info("TransactionId Text || "+text);
							resultBean.setTransactionId(text);
							continue;
						}
						else if(tagName.equalsIgnoreCase("Message"))
						{
							
							logger.info("Message Text || "+text);
							resultBean.setMessage(text);
							continue;
						}
						else if(tagName.equalsIgnoreCase("TransStatus"))
						{
							
							logger.info("TransStatus Text || "+text);
							resultBean.setCallStatus(text);
							continue;
						}
						else
						{
							logger.info("No Any Case Match......");
						}
					}
				}

			}//while()
		} catch(Exception ex) {
			logger.error("Error Inside getXMLToBeanData() function....",ex);
			return null;
		} finally {
			try {
				if(xmlr!=null)xmlr.close();			
			} catch(Exception ex) {
				logger.warn("Error Inside closin xmlr object ....",ex);			
			}
		}
		return resultBean;
		
	}//getXMLToBeanData

	
	//Testing Data
	public static void main(String str [])
	{
		String data="<?xml version=\"1.0\" encoding=\"UTF-8\"?><UssdEnvelop><Msisdn>TestMsisdn</Msisdn><Message>Test-Message</Message><TransactionId>123456</TransactionId><TransStatus>0</TransStatus></UssdEnvelop>";
		//String data="<?xml version=\"1.0\" encoding=\"UTF-8\"?><UssdEnvelop><Msisdn value=\"TestMsisdn\"/><Message value=\"Test-Message\"/><TransactionId value=\"123456\"/><TransStatus value=\"0\"/></UssdEnvelop>";
		//getXMLToBeanData(data);
	}



}
