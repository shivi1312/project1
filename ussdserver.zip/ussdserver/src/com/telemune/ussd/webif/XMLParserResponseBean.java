package com.telemune.ussd.webif;

public class XMLParserResponseBean
{

	private String transactionId = "";
	private String msisdn="";
	private String callStatus="";
	private String message="";
	
	public XMLParserResponseBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getCallStatus() {
		return callStatus;
	}

	public void setCallStatus(String callStatus) {
		this.callStatus = callStatus;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}


	@Override
	public String toString() {
		return "XMLParserResponseBean [callStatus=" + callStatus + ", message="
				+ message + ", msisdn=" + msisdn + ", transactionId="
				+ transactionId + ", getCallStatus()=" + getCallStatus()
				+ ", getMessage()=" + getMessage() + ", getMsisdn()="
				+ getMsisdn() + ", getTransactionId()=" + getTransactionId()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	
}
