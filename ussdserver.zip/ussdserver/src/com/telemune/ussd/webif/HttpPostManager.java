package com.telemune.ussd.webif;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

public class HttpPostManager 
{
	static final Logger logger = Logger.getLogger(HttpPostManager.class);
	XMLParserRequestBean requestBean=null;

	public HttpPostManager(XMLParserRequestBean requestBean)
	{
		this.requestBean=requestBean;
	}
	

	public String processHttpRequest(int sendDigitVal)
	{
		String reqUrl=TSSJavaUtil.getHTTP_URL();
		logger.info(reqUrl+"#Http URL Inside processRequest() function Reuest Parameter List Are [ "+requestBean+" ] sendDigitVal [ "+sendDigitVal+" ]");
		StringBuffer responseXML=new StringBuffer();
		HttpPost mypost=null;
		String urlData="";
		BufferedReader rd=null;
		HttpResponse resp=null;
		try
		{
			//Parameter Lists..

			List<NameValuePair> urlParameters=getHitURLData(sendDigitVal);
			logger.info("Inside processHttpRequest() function Hit URL [ "+urlParameters.toString()+" ]");
			if(urlParameters!=null)
			{

				DefaultHttpClient dhc=new DefaultHttpClient(HttpPoolFactory.getHttpConPoolFactory());
				mypost=new HttpPost(reqUrl);
				
				mypost.setEntity(new UrlEncodedFormEntity(urlParameters,"UTF-8"));
				//mypost.setEntity(new UrlEncodedFormEntity(urlParameters,"UTF-16BE"));

				resp=dhc.execute(mypost);
				
				//rd = new BufferedReader( new InputStreamReader(resp.getEntity().getContent()));
				rd = new BufferedReader( new InputStreamReader(resp.getEntity().getContent(),Charset.forName("UTF-8").newDecoder()));
								
				/*
				String line = "";
				while ((line = rd.readLine()) != null) {
					responseXML.append(line);
				}
                                 */
				int value=0;
				while((value = rd.read()) != -1)
     			{
            	   	char c = (char)value;
           			responseXML.append(c);             
         		}
         
   				EntityUtils.consume(resp.getEntity());				
			} else {
				logger.error("Error Inside processHttpRequest() function getting NULL URL ||"+urlData);
				return null;
			}
		} catch (Exception ex) {
			logger.info("Error occure inside processRequest() function ",ex);
			return null;
		} finally {
			try {
				mypost=null;
				reqUrl=null;
				if(rd!=null)rd.close();
				if(resp!=null)EntityUtils.consume(resp.getEntity());
			} catch(Exception ex) {
				ex.printStackTrace();
			}
		}
		logger.debug("### Response XML ["+responseXML.toString());

		return responseXML.toString();
	}

	public List<NameValuePair> getHitURLData( int addDigitValue)
	{
		List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
		try
		{
			urlParameters.add(new BasicNameValuePair(Global.CALL_DIRECTION, this.requestBean.getCallDirection()));
			urlParameters.add(new BasicNameValuePair(Global.CALL_STATUS, this.requestBean.getCallStatus()));
			urlParameters.add(new BasicNameValuePair(Global.CALLING_NUMBER, this.requestBean.getCallingNumber()));
			urlParameters.add(new BasicNameValuePair(Global.CALLED_NUMBER, this.requestBean.getCalledNumber()));
			urlParameters.add(new BasicNameValuePair(Global.CALL_UNIQUE_ID,this.requestBean.getCallUniqueId()));
			if(addDigitValue>=0)
				urlParameters.add(new BasicNameValuePair(Global.DIGIT, this.requestBean.getDigits()));

		} catch(Exception ex) {
			logger.error("Error Inside getHitURLData() Function...",ex);
			return null;
		}
		return urlParameters;
	}
	
	public List<NameValuePair> getHitURLData(XMLParserRequestBean data)
	{
		List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
		try
		{
			urlParameters.add(new BasicNameValuePair(Global.CALL_DIRECTION,data.getCallDirection()));
			urlParameters.add(new BasicNameValuePair(Global.CALL_STATUS,data.getCallStatus()));
			urlParameters.add(new BasicNameValuePair(Global.CALLING_NUMBER,data.getCallingNumber()));
			urlParameters.add(new BasicNameValuePair(Global.CALLED_NUMBER,data.getCalledNumber()));
			urlParameters.add(new BasicNameValuePair(Global.CALL_UNIQUE_ID,data.getCallUniqueId()));
			urlParameters.add(new BasicNameValuePair(Global.CALL_HANGUP_CAUSE,data.getHangupCause()));

		} catch(Exception ex) {
			logger.error("Error Inside getHitURLData() Function...",ex);
			return null;
		}
		return urlParameters;
	}

	public void  processCallDisconnectRequest(XMLParserRequestBean data)
	{
		String reqUrl=TSSJavaUtil.getHTTP_URL();
		logger.info(reqUrl+"#Http URL Inside processRequest() function Reuest Parameter List Are [ "+data+" ]");
		HttpPost mypost=null;
		HttpResponse resp=null;
		try
		{
			//Parameter Lists..

			List<NameValuePair> urlParameters=getHitURLData(data);
			
			if(urlParameters!=null)
			{

				DefaultHttpClient dhc=new DefaultHttpClient(HttpPoolFactory.getHttpConPoolFactory());
				mypost=new HttpPost(reqUrl);
				
				mypost.setEntity(new UrlEncodedFormEntity(urlParameters));

				resp=dhc.execute(mypost);				
				
				logger.info("Status Code Return at call Disconnect [ "+resp.getStatusLine().getStatusCode()+" ]");				
				
				EntityUtils.consume(resp.getEntity());
			}
			else
			{
				logger.error("Error Inside processHttpRequest() function getting NULL URL ||");				
			}
		} catch (Exception ex) {
			logger.info("Error occure inside processRequest() function ",ex);
			
		} finally {
			try {
				if(mypost!=null) {
					mypost.releaseConnection();
					mypost=null;
				}				
				reqUrl=null;
				if(resp!=null)EntityUtils.consume(resp.getEntity());
			} catch(Exception ex) {
				ex.printStackTrace();
			}
		}
	}
}


