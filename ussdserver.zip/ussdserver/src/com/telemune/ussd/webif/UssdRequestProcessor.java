package com.telemune.ussd.webif;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import com.telemune.dbutilities.ConnectionPool;

public class UssdRequestProcessor 
{
	static final Logger logger = Logger.getLogger(UssdRequestProcessor.class);
	private ConnectionPool conPool=null;
	private USSDRequestBean reqBean=null;
	private static String errorMessage="PLEASE TRY LATER."; //Error String..
	public UssdRequestProcessor()
	{
		super();
	}

	public UssdRequestProcessor(ConnectionPool conPool,USSDRequestBean reqBean)
	{
		super();
		this.conPool=conPool;
		this.reqBean=reqBean;
	}

	public int processRequest()
	{
		int retVal=-1;
		String data=null,msisdn=null,smscId=null;
		HttpPostManager httpPostRequest=null;
		XMLParserRequestBean XMLParserBean=new XMLParserRequestBean();
		XMLParsingUtility parseXML=null;
		XMLParserResponseBean xmlResponseBean=null;
		int sendDigitVal=-1;
		int userError=0,proError=0; // set Default Success Value [0].
		String transactionID="-1";
		logger.info("Inside processRequest() Function Data [ "+reqBean.getData()+" ] Msisdn [ "+reqBean.getMsisdn()+" ] SMSC ID [ "+reqBean.getSmscId()+" ]");	
		try
		{
			data = reqBean.getData();
			msisdn = reqBean.getMsisdn();
			smscId = reqBean.getSmscId();
			String[] arrayOfString = data.split(" ");

			logger.info("Request Code at 0 index is [" + arrayOfString[0] + "] and length [" + arrayOfString.length + "]");

			data = "";
			transactionID = arrayOfString[1];

			int j;
			if(arrayOfString[0].equalsIgnoreCase("80"))
			{
				logger.info("Inside 80 Request ID..");

				j = 2;
				while (arrayOfString.length > j)
				{
					logger.info("FOR 80 index [" + j + "]  transactionID [" + transactionID + "] New data [" + arrayOfString[j] + "]");
					data = data + arrayOfString[(j++)];
					if (arrayOfString.length <= j)
						continue;
					data = data + " ";
				}
			} else if (arrayOfString[0].equalsIgnoreCase("74"))
			{
				logger.info("Inside 74 Request ID..");
				j = 7;
				while (arrayOfString.length > j)
				{
					logger.debug("FOR 74 index [" + j + "] transactionID [" + transactionID + "] new data[" + arrayOfString[j] + "]");
					data = data + arrayOfString[(j++)];
					if (arrayOfString.length <= j)
						continue;
					data = data + " ";
				}
			} else
			{
				logger.warn("Unknown Request Type Getted....");
				data = arrayOfString.toString();
			}

			logger.info("Finally Request List Are  data  [" + data + "] and Msisdn  [" + msisdn + "]  transactionID [" + transactionID + "]");

			//  Error INSUFFICIENT_PARAMETER_ERROR

			if(StringUtils.isBlank(data)||StringUtils.isBlank(transactionID))
			{
				logger.info(msisdn+"#For This Number Transaction Data Or TransactionID is NULL.... Data [ "+data+" ] Transaction ID [ "+transactionID+" ] So Return [INSUFFICIENT_PARAMETER_ERROR]");
				return ErrorCode.INSUFFICIENT_PARAMETER_ERROR;
			}

			data=data.trim();
			transactionID=transactionID.trim();

			XMLParserBean.setCallDirection(Global.CALL_DIRECTION_VALUE); // Call Direction Value.
			XMLParserBean.setCallingNumber(msisdn);

			// Before Send Request To XML Parser

			String responseXML=null;

			// Session Time Out From USSD Gateway...

			boolean ussdSessionTimeOut=false;

			if (TSSJavaUtil.instance().getData(transactionID) != null)
			{
				logger.info("Msisdn [" + msisdn + "] exists in cache for transactionID [" + transactionID + "]");
				TSSJavaUtil.instance();
				if (arrayOfString[0].equalsIgnoreCase("80"))
				{
					logger.info("80 Request Code ,Hence remove data from cache for msisdn [" + msisdn + "] Transaction ID [ "+transactionID+" ]");

					TSSJavaUtil.instance().removeData(transactionID);
					TSSJavaUtil.instance().putAndSendData(msisdn, transactionID, smscId,data); // Store New Data Into Cache....

					XMLParserBean.setCalledNumber(data);
					XMLParserBean.setCallUniqueId(transactionID);
					XMLParserBean.setCallStatus(Global.CALL_IN_RING); //Call In Ring

				}
				else
				{
					DataBean localDataBean = TSSJavaUtil.instance().getData(transactionID);
					String calledNumber = localDataBean.getCalledNumber();
					localDataBean.setSmscId(smscId);
					TSSJavaUtil.instance().removeAndPut(transactionID, localDataBean);

					logger.info("Request Code not equals to 80 Hence fetching id from cache for msisdn [" + msisdn + "] Key Value od Cache is [ "+transactionID+" ] From cache calledNumber[ "+localDataBean.getCalledNumber()+" ] SMSC -ID [ "+localDataBean.getSmscId()+" ]");

					XMLParserBean.setCalledNumber(calledNumber);
					XMLParserBean.setCallUniqueId(transactionID);
					XMLParserBean.setCallStatus(Global.CALL_IN_PROGREES);  //Call In Progess
					XMLParserBean.setDigits(data);
					sendDigitVal=1;  //Set User Input In digit..

					try
					{
						if(arrayOfString.length>4)
						{
							userError=Integer.parseInt(arrayOfString[2]);  // User Error 
							proError=Integer.parseInt(arrayOfString[3]);   // Pro Error
						}
					} catch(Exception errCode) {
						userError=0;proError=0; //Set Success Case.
						logger.error("Error in getting Error Code ",errCode);
					}

					if(userError>0||proError>0) //Session Time-OUT and Call Disconnect Error
					{
						logger.error("Session Time Out Error From Gateway userError [ "+userError+" ] proError [ "+proError+" ]");
						
						httpPostRequest=new HttpPostManager(XMLParserBean);
						throw new UserCallDisconnectException("1"); //1 Disconnect from USSD-Gateway
					}
				}
			} else {
				logger.info("Msisdn is not exists in cache,put the data in cache and also send request to XML Parser");

				XMLParserBean.setCalledNumber(data);
				XMLParserBean.setCallUniqueId(transactionID);
				XMLParserBean.setCallStatus(Global.CALL_IN_RING); //Call In Ring

				TSSJavaUtil.instance().putAndSendData(msisdn, transactionID, smscId,data); 	// Store New Data Into Cache....

			}
			//Before Send request To XML-Parser
			httpPostRequest=new HttpPostManager(XMLParserBean);

			//  Error NULL_RESPONSE_RETURN_FROM_PARSER
			if(StringUtils.isBlank(responseXML=httpPostRequest.processHttpRequest(sendDigitVal)))
			{
				logger.error(responseXML+"#Error Invalid Response Return from processHttpRequest() function So Call Disconnect and return [NULL_RESPONSE_RETURN_FROM_PARSER]..");
				retVal=ErrorCode.NULL_RESPONSE_RETURN_FROM_PARSER;

				throw new UserCallDisconnectException("2"); //2 XMLParser Response NULL

				/*
				   XMLParserBean.setCallStatus(Global.CALL_COMPLETED);
				   XMLParserBean.setHangupCause(Global.CALL_DISCONNECT_ERROR); // Error

				   xmlResponseBean=new XMLParserResponseBean();
				   xmlResponseBean.setCallStatus("0");  //Set 0 for Call Disconnect.
				   xmlResponseBean.setMsisdn(XMLParserBean.getCallingNumber());
				   xmlResponseBean.setMessage(this.errorMessage);

				   ussdSessionTimeOut=sendResponseToUser(transactionID,xmlResponseBean);

				   httpPostRequest.processCallDisconnectRequest(XMLParserBean);

				   return ErrorCode.NULL_RESPONSE_RETURN_FROM_PARSER;
				   */
			}

			logger.info("Response Return From processHttpRequest() Function is || "+responseXML);
			parseXML=new XMLParsingUtility();

			xmlResponseBean=parseXML.getXMLToBeanData(responseXML);

			//  Error ERROR_IN_PARSE_XML

			if(xmlResponseBean==null)
			{
				logger.error("Null Return From getXMLToBeanData() function So Call Disconnect and return [ERROR_IN_PARSE_XML]..");
				retVal=ErrorCode.ERROR_IN_PARSE_XML;
				throw new UserCallDisconnectException("3"); //3 Error in parsing XML.

				/*
				   XMLParserBean.setCallStatus(Global.CALL_COMPLETED);
				   XMLParserBean.setHangupCause(Global.CALL_DISCONNECT_ERROR); // Error

				   xmlResponseBean=new XMLParserResponseBean();
				   xmlResponseBean.setCallStatus("0");  //Set 0 for Call Disconnect.
				   xmlResponseBean.setMsisdn(XMLParserBean.getCallingNumber());
				   xmlResponseBean.setMessage(this.errorMessage);

				   ussdSessionTimeOut=sendResponseToUser(transactionID,xmlResponseBean);

				   httpPostRequest.processCallDisconnectRequest(XMLParserBean);

				   return ErrorCode.ERROR_IN_PARSE_XML;
				   */
			}

			//All request process successfully so send response to the used..
			StringBuffer sendSMSResponse=new StringBuffer();
			ussdSessionTimeOut=sendResponseToUser(transactionID,xmlResponseBean,sendSMSResponse);

			try
			{
				if(sendSMSResponse.length()>0)
					retVal=Integer.parseInt(sendSMSResponse.toString());
			} catch(Exception ex) {
				logger.error(sendSMSResponse.toString()+" # Response Exception From sendResponseToUser()",ex);
				retVal=-1;
			}

			if(ussdSessionTimeOut)
			{
				logger.info("Inside Call Disconnect Request Process....");

				XMLParserBean.setCallStatus(Global.CALL_COMPLETED);
				XMLParserBean.setHangupCause(Global.CALL_DISCONNECT_FROM_XML);
				httpPostRequest.processCallDisconnectRequest(XMLParserBean);
			}
		}
		catch(UserCallDisconnectException ex)
		{                        
			logger.warn("Inside UserCallDisconnectException [ "+ex.getMessage().trim()+" ]");
		         
            XMLParserBean.setCallStatus(Global.CALL_COMPLETED);
			if(ex.equals("1"))
				XMLParserBean.setHangupCause(Global.CALL_DISCCONNECT_GATEWAY); // Call Disconnect From Gateway
			else
				XMLParserBean.setHangupCause(Global.CALL_DISCONNECT_ERROR); //Call Disco

			XMLParserResponseBean xmlResBean=new XMLParserResponseBean();
			xmlResBean.setCallStatus("0");  //Set 0 for Call Disconnect.
			xmlResBean.setMsisdn(XMLParserBean.getCallingNumber());
			xmlResBean.setMessage(this.errorMessage);
			                          
			sendResponseToUser(transactionID,xmlResBean);                       
	
            logger.info("before CallDisconnectRequest httpPostRequest[ "+httpPostRequest+"]XMLParserBean["+XMLParserBean+"]");	
         	httpPostRequest.processCallDisconnectRequest(XMLParserBean);                       

		} catch(Exception ex) {
			logger.error("Exception inside processRequest() function || ",ex);
			retVal=ErrorCode.UNKNOWN_ERROR;
		} finally {
			httpPostRequest=null;
			XMLParserBean=null;
			parseXML=null;
			xmlResponseBean=null;
		}
		return retVal;
	}

	public boolean  sendResponseToUser(String transactionID,XMLParserResponseBean bean,StringBuffer sendSMSResponse)
	{
		logger.info("Inside sendResponseToUser() Function transactionID "+transactionID);

		boolean callDisconnect=false;
		DataBean databean=new DataBean();
		int opCode=-1;
		String smscId="-1";
		String data="";
		databean = TSSJavaUtil.instance().getData(transactionID);
		UssdDBHandler ussdDBhandler=new UssdDBHandler(this.conPool);
		try
		{
			if(!(databean==null))
			{
				if(bean.getCallStatus().equals("0")) //Call End Status.
				{
					logger.info("inside LAST Request Process");
					opCode = 17;
					TSSJavaUtil.instance().removeData(transactionID);
					data = (new StringBuilder()).append("81 ").append(transactionID).append(" 0 ").append(bean.getMessage()).toString();
					callDisconnect=true;  // Call Disconnection From XML Parser... 
				} else {
					opCode = 2;
					data = (new StringBuilder()).append("72 ").append(transactionID).append(" ").append(TSSJavaUtil.instance().getTimeOut()).append(" 0 ").append(bean.getMessage()).toString();     
				}

				//Insert Data into DB....

				sendSMSResponse.append(ussdDBhandler.sentLbsMessage(data, bean.getMsisdn(), opCode, databean.getSmscId()));
				reqBean.setMsg(data);

			} else {
				logger.warn(transactionID+"# transactionID Not Found in Cache So No send Any Response to User");
			}

		} catch(Exception ex) {
			logger.error("Exception inside sendResponseToUser() function || ",ex);

		} finally {
			databean=null;
			ussdDBhandler=null;
		}

		return callDisconnect;
	}

	public boolean  sendResponseToUser(String transactionID,XMLParserResponseBean bean)
	{
		boolean callDisconnect=false;
		DataBean databean=new DataBean();
		int opCode=17;
		String data="";
		databean = TSSJavaUtil.instance().getData(transactionID);
		UssdDBHandler ussdDBhandler=null;
		try
		{
			if(!(databean==null))
			{
				ussdDBhandler=new UssdDBHandler(this.conPool);
				data = (new StringBuilder()).append("81 ").append(transactionID).append(" 0 ").append(bean.getMessage()).toString();
				TSSJavaUtil.instance().removeData(transactionID);

				//Insert Data into DB....

				int smsSendResponse=ussdDBhandler.sentLbsMessage(data, bean.getMsisdn(), opCode, databean.getSmscId());
				//reqBean.setMsg(data);
				
				logger.debug("SMS Send Response || "+smsSendResponse);
			} else {
				logger.warn(transactionID+"# transactionID Not Found in Cache So No send Any Response to User");
			}

		} catch(Exception ex) {
			logger.error("Exception inside sendResponseToUser() function || ",ex);
		} finally {
			databean=null;
			ussdDBhandler=null;
		}
		return callDisconnect;
	}
}
