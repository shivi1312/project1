package com.telemune.ussd.webif;

public class UserCallDisconnectException extends Exception 
{


	public UserCallDisconnectException()
	{
		super("Call Disconnect Error");
	}

	public UserCallDisconnectException(String reason)
	{
		super(reason);
	}

	public UserCallDisconnectException(Exception exp)
	{
		super(exp.getMessage());

	}

	@Override
	public String toString()
	{
		return super.toString();
	}



}
