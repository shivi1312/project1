package com.telemune.ussd.webif;

import org.apache.http.HttpHost;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.log4j.Logger;

import com.telemune.servlet.MasterServlet;

public class HttpPoolFactory 
{
	static final Logger logger = Logger.getLogger(HttpPoolFactory.class);
	
	private static PoolingClientConnectionManager httpConPoolFactory=null;
	private static HttpHost localhost=null;
	private static SchemeRegistry schemeRegistry=null;
	private static String serverIP=TSSJavaUtil.getHTTPIP();
	private static int serverPort=Integer.parseInt(TSSJavaUtil.getHTTPPORT());
	
	
	static 
	{
		logger.info("Inside HttpPoolFactory serverIP [ "+TSSJavaUtil.getHTTPIP()+" ] serverPort [ "+TSSJavaUtil.getHTTPPORT()+" ]");
		schemeRegistry = new SchemeRegistry();
		schemeRegistry.register( new Scheme("http", serverPort, PlainSocketFactory.getSocketFactory()) );
		
		httpConPoolFactory = new PoolingClientConnectionManager(schemeRegistry);
		
		//httpConPoolFactory.setMaxTotal(300);
		//httpConPoolFactory.setDefaultMaxPerRoute(20);
		//HttpHost localhost = new HttpHost(serverIP, serverPort);
		//httpConPoolFactory.setMaxPerRoute(new HttpRoute(localhost), 250);
		
		httpConPoolFactory.setMaxTotal(Integer.parseInt(TSSJavaUtil.getMAX_HTTP_POOL_SIZE()));
		httpConPoolFactory.setDefaultMaxPerRoute(Integer.parseInt(TSSJavaUtil.getMIN_HTTP_ROUTE_SIZE()));
		HttpHost localhost = new HttpHost(serverIP, serverPort);
		httpConPoolFactory.setMaxPerRoute(new HttpRoute(localhost), Integer.parseInt(TSSJavaUtil.getMAX_HTTP_ROUTE_SIZE()));
		
    }

	public static PoolingClientConnectionManager getHttpConPoolFactory() {
		return httpConPoolFactory;
	}

	public static void setHttpConPoolFactory(PoolingClientConnectionManager httpConPoolFactory) {
		HttpPoolFactory.httpConPoolFactory = httpConPoolFactory;
	}	

}
