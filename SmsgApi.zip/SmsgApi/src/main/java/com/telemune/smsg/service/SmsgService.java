package com.telemune.smsg.service;

import com.telemune.smsg.model.SmsgBean;

public interface SmsgService {

	public void sendSMS(SmsgBean smsgbean, String Origination, String destination, String message);
}
