package com.telemune.smsg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.smsg.model.SmsgBean;
import com.telemune.smsg.repository.GmatRepository;
import com.telemune.smsg.service.SmsgService;
//import com.telemune.smsg.serviceimplementation.SmscServiceImpl;

@RestController
public class SmscController {
	@Autowired
 private  SmsgService smscserviceimpl;


	
	@GetMapping("/recieve")
	public ResponseEntity saveSms(@RequestParam("Origination_number") String Origination, @RequestParam("destination_number") String destination,
	@RequestParam("message") String message)
	{


			SmsgBean smsgbean = new SmsgBean();
			smsgbean.setOrigination_number(Origination);
			smsgbean.setDestination_number(destination);
			smsgbean.setMessage(message);
			smscserviceimpl.sendSMS(smsgbean, Origination, destination ,message);
			
			
			


			return ResponseEntity.status(HttpStatus.OK).body("OK");




}

}