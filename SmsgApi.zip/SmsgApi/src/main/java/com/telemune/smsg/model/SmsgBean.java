package com.telemune.smsg.model;

public class SmsgBean {

	private String Origination_number;

	private String Destination_number;

	private String Message;

	public String getOrigination_number() {
		return Origination_number;
	}

	public SmsgBean(String origination_number, String destination_number, String message) {
		super();
		Origination_number = origination_number;
		Destination_number = destination_number;
		this.Message = message;
	}

	public void setOrigination_number(String origination_number) {
		Origination_number = origination_number;
	}

	@Override
	public String toString() {
		return "SmsgBean [Origination_number=" + Origination_number + ", Destination_number=" + Destination_number
				+ ", message=" + Message + ", getOrigination_number()=" + getOrigination_number()
				+ ", getDestination_number()=" + getDestination_number() + ", getMessage()=" + getMessage()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

	public String getDestination_number() {
		return Destination_number;
	}

	public SmsgBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setDestination_number(String destination_number) {
		Destination_number = destination_number;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		this.Message = message;
	}




}