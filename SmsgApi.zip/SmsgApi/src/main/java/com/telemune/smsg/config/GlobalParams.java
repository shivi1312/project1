package com.telemune.smsg.config;

import org.hibernate.annotations.Synchronize;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import FileBaseLogging.FileLogWriter;

@Configuration

public  class GlobalParams {

	
	private static FileLogWriter fileLogWriter = new FileLogWriter();
	
	@Bean
	public FileLogWriter getFileLogWriter()
	{
		
		return fileLogWriter;
	}


}
