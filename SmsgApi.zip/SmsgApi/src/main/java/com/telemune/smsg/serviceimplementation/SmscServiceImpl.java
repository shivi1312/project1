    package com.telemune.smsg.serviceimplementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telemune.smsg.config.GlobalParams;
import com.telemune.smsg.entity.GmatMsg;
import com.telemune.smsg.model.SmsgBean;
import com.telemune.smsg.repository.GmatRepository;
import com.telemune.smsg.service.SmsgService;	



@Service
public class SmscServiceImpl implements  SmsgService  {
	@Autowired
	private GmatRepository gmatRepository;
	
	@Autowired(required = true)
	private GlobalParams globalParams;


	public void sendSMS(SmsgBean smsgbean, String Origination, String destination, String message) {
		try {
            makeCallLogs(smsgbean);
			GmatMsg msg = new GmatMsg();
			msg.setOrigin(Origination);
			msg.setDestination(destination);
			msg.setMessage(message);

			gmatRepository.save(msg);
		} catch (Exception e) {
		}
	}
	
	public synchronized void makeCallLogs(SmsgBean smsgbean) {
		try {
			globalParams.getFileLogWriter().writeLog(smsgbean.toString());
		} catch (Exception e) {
			
		}
	}

}
