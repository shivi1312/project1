package com.telemune.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmsgApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
