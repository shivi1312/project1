package com.telemune.marketplace.util;

/**
 * This interface is used to hold common data types in Marketplace.
 * 
 * @author Siddharth Singh Rawat
 *
 */
public interface MPCommonDataTypes {
	byte ORACLE_DB = 1;
	byte MYSQL_DB = 2;
	String DATE_FORMAT = "dd-MM-yyyy HH:mm:ss";
	String NO_FILE_PATH = "NA";

	String VALIDITY_TYPE_MO = "MO";
	String VALIDITY_TYPE_DY = "DY";
	String VALIDITY_TYPE_HR = "HR";
	String VALIDITY_TYPE_MI = "MI";
	String VALIDITY_TYPE_SC = "SC";

	String MONTH = "MONTH";
	String DAY = "DAY";
	String HOUR = "HOUR";
	String MINUTE = "MINUTE";
	String SECOND = "SECOND";

	String DATA_UNIT_TYPE_KB = "KB";
	String DATA_UNIT_TYPE_MB = "MB";
	String DATA_UNIT_TYPE_GB = "GB";
	String DATA_UNIT_TYPE_TB = "TB";
	int DATA_CONVERSION_CONSTANT_1024 = 1024;

	String DMC_DEFAULT_VALIDITY_TYPE = "DY";

	String TOKEN_AMOUNT = "$(AMOUNT)";
	String TOKEN_DATA = "$(DATA)";
	String TOKEN_VALIDITY_DAYS = "$(VALIDITY_DAYS)";
	String TOKEN_MIN_AMOUNT = "$(MIN_AMOUNT)";
	String TOKEN_MAX_AMOUNT = "$(MAX_AMOUNT)";
	String TOKEN_S_APPENDER = "$(S_APPENDER)";
	String TOKEN_VOLUME = "$(volume)";
	String TOKEN_BALANCE = "$(BALANCE)";
	String TOKEN_PACK_DESC = "$(pack_desc)";
	String TOKEN_PACK_NAME = "$(pack_name)";
	String TOKEN_DATE = "$(DATE)";

	String S = "s";
	String INTERVALFORMAT = "INTERVALFORMAT";
	String VAS = "VAS";

	int VAS_SMS_ACTION_TYPE = 11;
	int VAS_USSD_ACTION_TYPE = 12;
	int VAS_REDIRECTION_ACTION_TYPE = 13;
	int CHECK_DATA_BALANCE_ACTION_TYPE = 15;

	String UNDERSCORE_SEPARATOR = "_";

	String REQ_DATE_FORMAT = "dd-MM-yy HH:mm";
	String CURRENT_RESP_DATE_FORMAT = "yyyyMMddHHmmss";

	int GLOBAL_COUNTRY_CODE_LENGTH = 3;
	
	int DATA_MACRO_CREDIT_ACTION_TYPE = 4;
	int DATA_MACRO_CREDIT_AMOUNT_BASED_ACTION_TYPE = 40;
	int DATA_MACRO_CREDIT_VOLUME_BASED_ACTION_TYPE = 41;
	
	int PROMO_PACK_ACTION_TYPE = 20;
}
