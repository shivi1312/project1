/**
 * @author MoHit
 * Created on - 20 Feb, 2017
 */
package com.telemune.marketplace.util;

/**
 * Used to hold parameter names that are to be sent in response to the
 * requesting interface (XML parser)
 * 
 * @author MoHit
 */
public interface ResponseParameters {

	String USER_POINTS_INFO="userPointsInfo";
	/**
	 * 
	 */
	String USER_POINTS="user_points";
	/**
	 * Used to hold the variable name for holding requesting interface that the
	 * processing was successful or not if not then what was the result code
	 */
	String RESULT = "result";

	/**
	 * Used to hold the variable name for holding the message string that will be
	 * shown as response
	 */
	String FILE_PATH = "FilePath";

	/**
	 * used to hold the variable name for holding the main balance of user
	 */
	String BALANCE = "balance";

	/**
	 * Used to hold the variable name for holding subscriber type of user
	 * pre-paid(P) and post-paid(O)
	 */
	String SUB_TYPE = "subType";

	/**
	 * Used to hold the variable name for holding is continue value while check
	 * profile response means user can continue to access this API or not
	 */
	String IS_CONTINUE = "isContinue";

	/**
	 * Used to hold the variable name for holding user is pre-paid subscriber or not
	 */
	String IS_PREPAID = "isPrepaid";

	/**
	 * Used to hold the variable name for holding list of pack IDs that are browsed
	 * by user
	 */
	String PACK_BROWSE_LIST = "packBrowseList";

	/**
	 * Used to hold the variable name for holding pack purchase detail means pack or
	 * any service purchased by user was successful or not combination is like
	 * PACKID;RESULT example 2309;1
	 */
	String PACK_PURCHASE_DETAIL = "packPurchaseDetail";

	/**
	 * Used to hold the variable name for holding pack list shown to user in current
	 * response
	 */
	String PACK_LIST = "packList";

	/**
	 * Used to hold the variable name for holding unique ID of pack
	 */
	String PACK_ID = "packId";

	/**
	 * Used to hold the variable name for holding user's friend mobile number
	 */
	String FMSISDN = "fmsisdn";

	String NEXT_INDEX = "nextIndex";
	String PREV_INDEX = "prevIndex";
	String IS_MORE_AVAILABLE = "isMoreInfoAvailable";

	/**
	 * Used to hold the variable name for holding unique ID of pack
	 */
	String IS_PACK_TYPE = "isPackType";

	// Added By SIDDHARTH SINGH RAWAT

	/**
	 * Used to hold the variable name for holding product code of pack
	 */
	String PRODUCT_CODE = "productCode";

	/**
	 * Used to hold the variable name for holding current pack value
	 */
	String CURRENT_PACK = "currentPack";

	/**
	 * Used to hold the basePackType of top most parent pack type.
	 */
	String BASE_PACK_TYPE = "basePackType";

	/**
	 * Used to hold the basePackType of top most parent pack type.
	 */
	String CURRENT_PACK_TYPE_LIST = "currentPackTypeList";

	/**
	 * pack action type used to indicates the pack action of different packs.
	 */
	String PACK_ACTION_TYPE = "packActionType";

	/**
	 * Used to hold the Service Details (DMC Service Pack Details)
	 */
	String SERVICE_DETAIL = "serviceDetail";

	/**
	 * Used to hold the list of active accounts Id's
	 */
	String ACTIVE_ACCOUNT_ID_LIST = "activeAccIdList";

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * in case of successful request processing
	 */
	byte SUCCESS = 1;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * in case of request processing
	 */
	byte FAILURE = -1;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when user's balance is low
	 */
	byte LOW_BALANCE = -2;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when friend's mobile number entered by user is not valid
	 */
	byte INVALID_FMSISDN = -3;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when friend's mobile number entered by user is not in operator's allowed
	 * range
	 */
	byte FMSISDN_NOT_IN_RANGE = -4;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when friend's mobile number entered by user is not prepaid
	 */
	byte FMSISDN_IS_NOT_PREPAID = -5;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when volume to transfer entered by user is not valid
	 */
	byte INVALID_VOLUME = -6;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when volume to transfer entered by user is more than talk-time transfer
	 * maximum limit
	 */
	byte TRANSFER_VOLUME_EXCEED = -7;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when volume to transfer entered by user is more than talk-time balance of
	 * user
	 */
	byte LOW_TRANSFER_BALANCE = -8;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when user is not eligible for data transfer
	 */
	byte NOT_ELIGIBLE_FOR_DT = -9;

	/*
	 * Response Codes for IVR Flow SIDDHARTH
	 */

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when base file ivr path is not found
	 */
	byte BASE_FILE_PATH_NOT_FOUND_IVR = -50;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when invalid param found
	 */
	byte INVALID_PARAM_IVR = -51;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when we found unknown error
	 */
	byte UNKNOWN_ERROR_IVR = -52;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when we found error pressed digit
	 */
	byte INVALID_DIGIT_PRESSED_IVR = -53;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when friend's mobile number entered by user is not prepaid (IVR).
	 */
	byte FMSISDN_IS_NOT_PREPAID_IVR = -54;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when user are not able to purchase pack
	 */
	byte PACK_PURCHASE_FAILURE_IVR = -55;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when friend's mobile number entered by user is not valid (IVR)
	 */
	byte INVALID_FMSISDN_IVR = -56;

	/**
	 * Used to hold the value of result in IVR flow that is to be sent to requesting
	 * interface when friend's mobile number entered by user is not in operator's
	 * allowed range
	 */
	byte FMSISDN_NOT_IN_RANGE_IVR = -57;

	/**
	 * Used to hold the value of result in IVR flow that is to be sent to requesting
	 * interface when volume to transfer entered by user is more than talk-time
	 * transfer maximum limit
	 */
	byte TRANSFER_VOLUME_EXCEED_IVR = -58;

	/**
	 * Used to hold the value of result in case of IVR flow that is to be sent to
	 * requesting interface when volume to transfer entered by user is not valid
	 */
	byte INVALID_VOLUME_IVR = -59;

	/**
	 * Used to hold the value of result to be sent to requesting interface when we
	 * do not found any sub categories under any pack type
	 */
	byte NO_SUB_CATEGORIES = -60;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * when user's balance is low with fall back disabled
	 */
	byte LOW_BALANCE_FALL_BACK_DISABLE = -10;

	/**
	 * Used to hold the value of call duration in the case of improper hang up in
	 * IVR.
	 */
	byte IMPROPER_HANGUP_CALL_DURATION_RESPONSE_IVR = -20;

	/**
	 * Used to hold the value of result that is sent to the requesting interface at
	 * the time of talk-time failure with failure in crediting of the deducted
	 * amount in all deducted accounts including main balance account.
	 */
	byte TTT_FAILURE_WITH_CREDIT_TACF_MACF = -63;

	/**
	 * Used to hold the value of result that is sent to the requesting interface at
	 * the time of talk-time failure with successful crediting of the deducted
	 * amount in all deducted accounts with main balance account credit failure.
	 */
	byte TTT_FAILURE_WITH_CREDIT_TACS_MACF = -64;

	/**
	 * Used to hold the value of result that is sent to the requesting interface at
	 * the time of talk-time failure with failure in crediting of the deducted
	 * amount in all deducted accounts with main balance account credit success.
	 */
	byte TTT_FAILURE_WITH_CREDIT_TACF_MACS = -65;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * at the time of talk-time failure with successful credit in all the deducted
	 * accounts.
	 */
	byte TTT_FAILURE_WITH_CREDIT_TACS_MACS = -66;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * at the time of Data Macro Credit failure with credit return in main account
	 * failure.
	 */
	byte DMC_FAILURE_WITH_MACF = -41;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * at the time of Data Macro Credit failure with credit return in main account
	 * success.
	 */
	byte DMC_FAILURE_WITH_MACS = -42;

	/**
	 * Used to hold the value of result that is to be sent to requesting interface
	 * in case of there is no promotional packs for the requested user
	 */
	byte NO_PROMO_PACKS = -70;

	
	
}
