/**
 * @author MoHit
 * Created on - 10 Feb, 2017
 */
package com.telemune.marketplace.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.json.simple.JSONValue;

import com.charging.client.ThirdParty.Global;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.telemune.marketplace.beans.CachedParameters;
import com.telemune.marketplace.beans.DmcConversionConfig;
import com.telemune.marketplace.beans.MsisdnRange;
import com.telemune.marketplace.beans.PackBean;
import com.telemune.marketplace.beans.PackDetailConfig;
import com.telemune.marketplace.beans.PackOtherDetails;
import com.telemune.marketplace.beans.PackPackTypeCommonBean;
import com.telemune.marketplace.beans.PromoPackBean;
import com.telemune.marketplace.beans.PromotionPackOtherDetails;
import com.telemune.marketplace.beans.UserAccountInfoBean;
import com.telemune.marketplace.beans.UserDataBean;
import com.telemune.marketplace.db.ConnPool;
import com.telemune.marketplace.db.DBOperations;
import com.telemune.marketplace.db.DataBaseQueries;
import com.telemune.marketplace.expiringmap.ExpiringMap;

import FileBaseLogging.FileLogWriter;

/**
 * This is the singleton class and is used to hold some data in cache and to
 * provide some common functionality that is used frequently by other classes
 * 
 * @author MoHit
 */
public class TSSJavaUtil {

	/**
	 * Used for printing logs in this class
	 */
	private static Logger logger = Logger.getLogger(TSSJavaUtil.class);

	/**
	 * Used to hold the object of this class
	 */
	private static TSSJavaUtil instance = null;

	/**
	 * Used to hold the object of properties file loaded
	 */
	private static Properties propertiesFile = null;

	/**
	 * Used to hold the time duration (in milliseconds) after that cache needs to
	 * reload But from properties file it is defined in seconds
	 */
	private static long cacheReloadIntervalMS = 0l;

	/**
	 * Used to hold the time (in milliseconds) when cache was reload last But from
	 * properties file it is defined in seconds
	 */
	private static long lastCacheReloadTimeMS = 0l;

	/**
	 * Used to hold the time (in milliseconds) when app counter was reset last But
	 * from properties file it is defined in seconds
	 */
	private static long appCounterLastResetTimeMS = 0l;

	/**
	 * Used to hold the time duration (in milliseconds) after that app counter needs
	 * to reset But from properties file it is defined in seconds
	 */
	private static long appCounterResetTimeDurationMS = 1800000l;// 30 mins

	/**
	 * Used to hold the value of app counter Means this number of value have come to
	 * this app at a particular point of time
	 */
	private static int appCounter = 0;

	/**
	 * Used to hold the parameters that need to be cached
	 */
	private static CachedParameters cachedParameters = null;

	/**
	 * Used to hold Connection Pool reference
	 */
	private static ConnPool connPool = null;

	/**
	 * Used to hold properties file name
	 */

	private static String propFileName = "telemune_marketplaceApi_test.properties";

	//private static final String propFileName = "telemune_marketplaceApi.properties";
//	private static String propFileName = "telemune_marketplaceApi.properties";

	/**
	 * Used to hold file separator value
	 */
	public static final String FileSeparator = ",";

	private static FileLogWriter fileLogWriterCallDetailsLog = new FileLogWriter();

	// public static Date systemDate = new Date();

	/**
	 * @return the fileLogWriterCallDetailsLog
	 */
	public static FileLogWriter getFileLogWriterCallDetailsLog() {
		return fileLogWriterCallDetailsLog;
	}

	/**
	 * This table is used to hold the user account information with msisdn as a key.
	 */
	// private static Hashtable<String, List<UserAccountInfoBean>>
	// userAccountInfoTable = new Hashtable<>();

	/**
	 * This ExpiryMap is used to hold the user account information with msisdn as a
	 * key.
	 */
	private static ExpiringMap<String, List<UserAccountInfoBean>> userAccountInfoTable = ExpiringMap.builder()
			.expiration(3600, TimeUnit.SECONDS).build();

	/**
	 * @return the userAccountInfoTable
	 */
	public static ExpiringMap<String, List<UserAccountInfoBean>> getUserAccountInfoTable() {
		return userAccountInfoTable;
	}

	/**
	 * This method is used to maintain duration of call
	 */
	private HashMap<String, UserDataBean> callManagerMap = new HashMap<>();

	/**
	 * @return the callManagerMap
	 */
	public HashMap<String, UserDataBean> getCallManagerMap() {
		return callManagerMap;
	}

	/**
	 * @param callManagerMap the callManagerMap to set
	 */
	public void setCallManagerMap(HashMap<String, UserDataBean> callManagerMap) {
		this.callManagerMap = callManagerMap;
	}

	/**
	 * This method is used to return connPool Object in all other classes.
	 * 
	 * @return {@link #connPool}
	 */
	public ConnPool getConnPool() {
		return TSSJavaUtil.connPool;
	}

	/**
	 * This method is used to return CacheParameters in all other class.
	 * 
	 * @return {@link #cachedParameters}
	 */
	public CachedParameters getCacheParameters() {
		return TSSJavaUtil.cachedParameters;
	}

	/**
	 * This method is used to return the object of TSSJavaUtil (this) class It
	 * created a new object if not already exists or if last object creation time to
	 * current time interval is more than the defined in properties file to reload
	 * cache.<br>
	 * Modified coded for Multi-Threading and to reduce overhead.
	 * 
	 * 
	 * @author SIDDHARTH
	 * @return TssJavaUtil
	 */
	public static TSSJavaUtil checkAndRelaod() {
		long currentTimeMS = new java.util.Date().getTime();
		long lastReloadIntervalMS = currentTimeMS - TSSJavaUtil.lastCacheReloadTimeMS;
		logger.debug(">> current time [" + currentTimeMS + "], last cache time [" + TSSJavaUtil.lastCacheReloadTimeMS
				+ "], Configurable Reload Time Interval in milisec:[" + TSSJavaUtil.cacheReloadIntervalMS
				+ "], last cache reload time to current time interval [" + lastReloadIntervalMS + "]");

		if (TSSJavaUtil.instance == null) {
			try {

				synchronized (TSSJavaUtil.class) {

					if (TSSJavaUtil.instance == null) {
						logger.info(">> creating new instance of TSSJavaUtil() from checkAndRelaod() method.");
						TSSJavaUtil.instance = new TSSJavaUtil();
					}
				}

			} catch (Exception e) {
				logger.fatal(TSSJavaUtil.getLogInitial("00001")
						+ " >> can not instantiate TSSJavaUtil, Unable to load cache");
			}
			lastCacheReloadTimeMS = new java.util.Date().getTime();
		} else if (lastReloadIntervalMS > cacheReloadIntervalMS) {
			logger.info(
					">> reload cache as time interval is more than defined in proeprties file. cacheReloadIntervalMS ["
							+ cacheReloadIntervalMS + "]");
			try {

				// TSSJavaUtil.instance = new TSSJavaUtil();

				// Code to reduce overhead
				synchronized (TSSJavaUtil.class) {

					// Code to reduce overhead.
					// updating lastReloadIntervalMs and check aging.
					currentTimeMS = new java.util.Date().getTime();
					lastReloadIntervalMS = currentTimeMS - TSSJavaUtil.lastCacheReloadTimeMS;

					if (lastReloadIntervalMS > cacheReloadIntervalMS) {
						logger.info(
								">> going to reload cache by calling reloadCache() method from checkAndRelaod() method where lastReloadIntervalMS ["
										+ lastReloadIntervalMS + "] and cacheReloadIntervalMS [" + cacheReloadIntervalMS
										+ "]");
						TSSJavaUtil.reloadCache();
					}

				}

			} catch (Exception e) {
				logger.fatal(TSSJavaUtil.getLogInitial("00002") + " >> Unable to load cache");
			}
			lastCacheReloadTimeMS = new java.util.Date().getTime();
		}
		return TSSJavaUtil.instance;
	}

	public static TSSJavaUtil instance(String fileName) {
		propFileName=fileName;
		logger.info("initilised TSS instance from web.xml "+propFileName);
		return instance();
	}
	/**
	 * This method is used to return the object of TSSJavaUtil (this) class It
	 * created a new object if not already exists. Modified for multi-threaded
	 * application.
	 * 
	 * @return TSSJavaUtil
	 * @author SIDDHARTH
	 * 
	 */
	public static TSSJavaUtil instance() {
		if (TSSJavaUtil.instance == null) {

			try {

				synchronized (TSSJavaUtil.class) {
					if (TSSJavaUtil.instance == null) {
						logger.info(">> creating new instance of TSSJavaUtil() in instance() method.");
						TSSJavaUtil.instance = new TSSJavaUtil();
					}
				}

			} catch (Exception e) {
				logger.fatal(TSSJavaUtil.getLogInitial("00001")
						+ " >> can not instantiate TSSJavaUtil, Unable to load cache");
			}
			lastCacheReloadTimeMS = new java.util.Date().getTime();
		}
		return TSSJavaUtil.instance;
	}

	/**
	 * This method is used to forcefully create the object of TSSJavaUtil class
	 * 
	 * @author SIDDHARTH
	 * @return
	 */
	public static TSSJavaUtil reload() {
		logger.info(" >> going to reload the TSSJavautil cache");
		try {
			if (TSSJavaUtil.instance == null) {
				logger.info(">> creating new instance of TSSJavaUtil() first time");
				try {
					TSSJavaUtil.instance = new TSSJavaUtil();
				} catch (Exception e) {
					logger.fatal(TSSJavaUtil.getLogInitial("00001")
							+ " >> can not instantiate TSSJavaUtil, Unable to load cache");
				}
			} else {

				try {
					TSSJavaUtil.reloadCache();
				} catch (Exception e) {
					logger.fatal(TSSJavaUtil.getLogInitial("00002") + " >> Unable to load cache");
				}
			}

			return instance;
		} catch (Exception e) {
			logger.fatal(
					TSSJavaUtil.getLogInitial("00003") + " >> can not instantiate TSSJavaUtil, Unable to load cache",
					e);
			return null;
		}
	}

	/**
	 * This is the constructor of this class and it loads the properties file and
	 * other parameters in cache, this method creates a new temporary cache
	 * parameters class object and passes to different methods so that they can load
	 * the new data in this cache bean and then original cache parameters object is
	 * replaced by this temporary object after successful cache loading
	 * 
	 * @throws Exception
	 */
	private TSSJavaUtil() throws Exception {
		logger.info("\n\n\t\t >> Loading TSSJavaUtil Cache\n");

		// loading properties file
		if (loadPropertiesFile() != CodeStatus.SUCCESS)
			throw new Exception("Unable to load cache");

		CachedParameters tempCachedParameters = new CachedParameters();

		if (propertiesFile != null) {
			// setting all the constants' values from properties file
			if (setConstantsValue(tempCachedParameters) != CodeStatus.SUCCESS)
				throw new Exception("Unable to load cache");

			// Loading FileLogWriter properties
			if (loadFileLogWriterConfiguration(tempCachedParameters) != CodeStatus.SUCCESS)
				throw new Exception("Unable to load cache");

			fileLogWriterCallDetailsLog.initialize();

			// loading data for app counter
			loadAppCounterData();

			// making connection pool
			if (createConnectionPool(tempCachedParameters) != CodeStatus.SUCCESS)
				throw new Exception("Unable to load cache");

			// loading cache from database
			if (loadDBCache(tempCachedParameters) != CodeStatus.SUCCESS)
				throw new Exception("Unable to load cache");

			TSSJavaUtil.cachedParameters = tempCachedParameters;
		} else {
			logger.error(TSSJavaUtil.getLogInitial("00004") + " >> properties file is not initialized, so returning");
		}

	}

	/**
	 * This method is used to load the configuration properties file
	 * 
	 * @return status of execution of this method means success or exception
	 *         occurred etc
	 */
	private static CodeStatus loadPropertiesFile() {
		String propertiesFilePath = System.getenv("HOME") + "/.config/property/" + propFileName;
		logger.info(">> loading " + propFileName + " from path [" + propertiesFilePath + "]");
		try {
			FileInputStream propFileIS = new FileInputStream(propertiesFilePath);
			Properties localPropertiesFile = new Properties();
			localPropertiesFile.load(propFileIS);
			TSSJavaUtil.propertiesFile = localPropertiesFile;
			propFileIS.close();
		}

		catch (FileNotFoundException fnfe) {
			logger.error(TSSJavaUtil.getLogInitial("90006") + " >> can't find " + propFileName + " file ", fnfe);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (IOException ioe) {
			logger.error(TSSJavaUtil.getLogInitial("90002") + " >> can't read " + propFileName + " file ", ioe);
			return CodeStatus.EXCEPTION_OCCURED;
		}

		catch (NullPointerException npe) {
			logger.error(TSSJavaUtil.getLogInitial("90003") + " >> can't read " + propFileName
					+ " file, some value may be null", npe);
			return CodeStatus.EXCEPTION_OCCURED;
		}

		catch (Exception e) {
			logger.error(TSSJavaUtil.getLogInitial("00005") + " >> can't read " + propFileName + " file ", e);
			return CodeStatus.EXCEPTION_OCCURED;
		}
		logger.info(">> " + propFileName + " from path [" + propertiesFilePath
				+ "] is loaded successfully : properties file object [" + TSSJavaUtil.propertiesFile + "]");
		return CodeStatus.SUCCESS;
	}

	/**
	 * Used to set the values of some of the constants defined in {@link Global}
	 * class
	 * 
	 * @param tempCachedParameters
	 * @return status of execution of this method means success or exception
	 *         occurred etc
	 */
	private static CodeStatus setConstantsValue(CachedParameters tempCachedParameters) {
		logger.info(">> Setting values of all the constants");

		try {

			tempCachedParameters.setDbDriver(getPropertiesValue("DB_DRIVER").trim());
			tempCachedParameters.setDbURL(getPropertiesValue("DB_URL").trim());
			tempCachedParameters.setDbUsername(getPropertiesValue("DB_USER").trim());
			tempCachedParameters.setDbPassword(getPropertiesValue("DB_PASS").trim());

			tempCachedParameters.setSubTypeSource(getPropertiesValue("SUB_TYPE_SOURCE").trim());
			tempCachedParameters.setHlrIP(getPropertiesValue("HLR_IP").trim());

			tempCachedParameters.setTttProductCode(
					getPropertiesWithDefValue("TTT_PRODUCT_CODE", tempCachedParameters.getTttProductCode()));

			if ("1".equals(getPropertiesWithDefValue("WHITELIST_ENABLE", "0").trim()))
				tempCachedParameters.setWhiteListingEnable(true);
			else
				tempCachedParameters.setWhiteListingEnable(false);

			if ("1".equals(getPropertiesWithDefValue("DB_LOG_ON_CHECK_PRO_ENABLE", "0").trim()))
				tempCachedParameters.setDbLogOnCheckProfileEnable(true);
			else
				tempCachedParameters.setDbLogOnCheckProfileEnable(false);

			if ("1".equals(getPropertiesWithDefValue("CHARGING_TESTING_ENABLE", "0").trim()))
				tempCachedParameters.setChargingTestingEnable(true);
			else
				tempCachedParameters.setChargingTestingEnable(false);

			if ("1".equals(getPropertiesWithDefValue("PREV_OPTION_ON_PACK_DESCRPTION", "0").trim()))
				tempCachedParameters.setPrevOptionOnPackDescEnable(true);
			else
				tempCachedParameters.setPrevOptionOnPackDescEnable(false);

			String packBasedOnBalanceEnable = getPropertiesValue("PACK_BASED_ON_BALANCE_ENABLE").trim();
			if (packBasedOnBalanceEnable != null) {
				if ("1".equals(packBasedOnBalanceEnable))
					tempCachedParameters.setPackBasedOnBalanceEnable(true);
				else
					tempCachedParameters.setPackBasedOnBalanceEnable(false);
			} else {
				tempCachedParameters.setPackBasedOnBalanceEnable(tempCachedParameters.isPackBasedOnBalanceEnable());
			}

			String lowBalPackBasedOnBalanceEnable = getPropertiesValue("LOW_BALANCE_PACK_BASED_ON_BALANCE_ENABLE")
					.trim();
			if (lowBalPackBasedOnBalanceEnable != null) {
				if ("1".equals(lowBalPackBasedOnBalanceEnable))
					tempCachedParameters.setLowBalancePackBasedOnBalanceEnable(true);
				else
					tempCachedParameters.setLowBalancePackBasedOnBalanceEnable(false);
			} else {
				tempCachedParameters.setLowBalancePackBasedOnBalanceEnable(
						tempCachedParameters.isLowBalancePackBasedOnBalanceEnable());
			}

			TSSJavaUtil.cacheReloadIntervalMS = Integer.parseInt(getPropertiesValue("CACHE_RELOAD_SEC").trim()) * 1000l;// multiplied
																														// by
																														// 1000
																														// to
																														// convert
																														// in
																														// milliseconds

			tempCachedParameters.setDbMinPoolSize(Byte.parseByte(getPropertiesWithDefValue("DB_MIN_POOLSIZE",
					String.valueOf(tempCachedParameters.getDbMinPoolSize())).trim()));
			tempCachedParameters.setDbMaxPoolSize(Byte.parseByte(getPropertiesWithDefValue("DB_MAX_POOLSIZE",
					String.valueOf(tempCachedParameters.getDbMaxPoolSize())).trim()));
			tempCachedParameters.setDbAccomodation(Byte.parseByte(getPropertiesWithDefValue("DB_ACCOMMODATION",
					String.valueOf(tempCachedParameters.getDbAccomodation())).trim()));

			tempCachedParameters.setDefaultLangId(Byte.parseByte(getPropertiesWithDefValue("DEFAULT_LANGUAGE_ID",
					String.valueOf(tempCachedParameters.getDefaultLangId())).trim()));

			tempCachedParameters
					.setMaxUssdStringLength(Short.parseShort(getPropertiesWithDefValue("MAX_USSD_STRING_LENGTH",
							String.valueOf(tempCachedParameters.getMaxUssdStringLength())).trim()));
			tempCachedParameters.setMaxMenus(Byte.parseByte(
					getPropertiesWithDefValue("MAX_MENUS", String.valueOf(tempCachedParameters.getMaxMenus())).trim()));
			
			tempCachedParameters.setMaxWelcomePromoMenu(Byte.parseByte(
					getPropertiesWithDefValue("MAX_WELCOME_PROMO_MENUS", String.valueOf(tempCachedParameters.getMaxWelcomePromoMenu())).trim()));

			tempCachedParameters.setHlrPort(Short.parseShort(getPropertiesValue("HLR_PORT").trim()));
			tempCachedParameters.setHlrTimeout(Short.parseShort(getPropertiesValue("HLR_TIMEOUT_SEC").trim()) * 1000);

			tempCachedParameters.setTestingBalance(Double.parseDouble(getPropertiesWithDefValue("TESTING_BALANCE",
					String.valueOf(tempCachedParameters.getTestingBalance())).trim()));

			tempCachedParameters.setTttMaxLimit((Integer.parseInt(
					getPropertiesWithDefValue("TTT_MAX_LIMIT", String.valueOf(tempCachedParameters.getTttMaxLimit()))
							.trim())));

			// added to show double/float value or integer value in
			// balance/service charge/amount
			if ("1".equals(getPropertiesWithDefValue("FLOAT_VALUE_ENABLE", "1").trim()))
				tempCachedParameters.setFloatValueEnable(true);
			else
				tempCachedParameters.setFloatValueEnable(false);

			tempCachedParameters.setSmsOrigNumPrefixB(getPropertiesWithDefValue("SMS_ORIG_NUM_PREFIX_B", ""));

			tempCachedParameters.setSmsOrigNumberTTTA(getPropertiesWithDefValue("SMS_ORIGINATION_NUMBER_TTT_A",
					tempCachedParameters.getSmsOrigNumberTTTA()).trim());

			tempCachedParameters.setSmsOrigNumberBonusA(getPropertiesWithDefValue("SMS_ORIGINATION_NUMBER_BONUS_A",
					tempCachedParameters.getSmsOrigNumberBonusA()).trim());

			tempCachedParameters.setSmsOrigNumberDataTransferA(getPropertiesWithDefValue("SMS_ORIGINATION_NUMBER_DT_A",
					tempCachedParameters.getSmsOrigNumberDataTransferA()).trim());

			tempCachedParameters.setSmsOriginationNumberB(getPropertiesWithDefValue("SMS_ORIGINATION_NUMBER_B",
					tempCachedParameters.getSmsOriginationNumberB()).trim());

			tempCachedParameters.setInterfaceForTTTransferA(getPropertiesWithDefValue("TTT_SMS_ON_INTERFACE_A",
					tempCachedParameters.getInterfaceForTTTransferA()).toUpperCase().trim());

			tempCachedParameters.setInterfaceForTTTransferB(getPropertiesWithDefValue("TTT_SMS_ON_INTERFACE_B",
					tempCachedParameters.getInterfaceForTTTransferB()).toUpperCase().trim());

			tempCachedParameters.setInterfaceForBonusA(
					getPropertiesWithDefValue("BONUS_SMS_INTERFACE_A", tempCachedParameters.getInterfaceForBonusA())
							.toUpperCase().trim());

			tempCachedParameters.setInterfaceForBonusB(
					getPropertiesWithDefValue("BONUS_SMS_INTERFACE_B", tempCachedParameters.getInterfaceForBonusB())
							.toUpperCase().trim());

			tempCachedParameters.setInterfaceForDataTransferA(
					getPropertiesWithDefValue("DT_SMS_INTERFACE_A", tempCachedParameters.getInterfaceForDataTransferA())
							.toUpperCase().trim());

			tempCachedParameters.setInterfaceForDataTransferB(
					getPropertiesWithDefValue("DT_SMS_INTERFACE_B", tempCachedParameters.getInterfaceForDataTransferB())
							.toUpperCase().trim());

			tempCachedParameters.setTttServiceChargeOnNet(
					Double.parseDouble(getPropertiesValue("TTT_ONNET_SERVICE_CHARGE").trim()));
			tempCachedParameters.setTttServiceChargeOffNet(
					Double.parseDouble(getPropertiesValue("TTT_OFFNET_SERVICE_CHARGE").trim()));

			tempCachedParameters
					.setTransactionCdrLimit(Integer.parseInt(getPropertiesWithDefValue("TRANSACTION_CDR_LIMIT", "")));
			tempCachedParameters.setActivePlanViewLimit(
					Integer.parseInt(getPropertiesWithDefValue("ACTIVE_PLAN_AND_TRANSACTION_VIEW_LIMIT", "")));

			tempCachedParameters
					.setIvrBasePath(getPropertiesWithDefValue("IVR_BASE_PATH", tempCachedParameters.getIvrBasePath()));
			tempCachedParameters.setIvrPackPromptBasePath(
					getPropertiesWithDefValue("IVR_PACK_PROMPT_BASE_PATH", tempCachedParameters.getIvrBasePath()));
			tempCachedParameters.setMaxIvrMenu(Byte.parseByte(
					getPropertiesWithDefValue("IVR_MAX_MENUS", String.valueOf(tempCachedParameters.getMaxIvrMenu()))));

			tempCachedParameters.setIvrMaxActivePlan(Byte.parseByte(getPropertiesWithDefValue("IVR_MAX_ACTIVE_PLAN",
					String.valueOf(tempCachedParameters.getIvrMaxActivePlan()))));

			tempCachedParameters.setIsPreviousEnableIvr(Byte.parseByte(getPropertiesWithDefValue("IS_PREV_ENABLE_IVR",
					String.valueOf(tempCachedParameters.getIsPreviousEnableIvr()))));

			tempCachedParameters.setIsPrevOptionOnPackDescriptionEnableIvr(
					Byte.parseByte(getPropertiesWithDefValue("PREV_OPTION_ON_PACK_DESCRPTION_IVR",
							String.valueOf(tempCachedParameters.getIsPrevOptionOnPackDescriptionEnableIvr()))));
			tempCachedParameters.setInvalidFmsisdnBtIvrPromptEnable(
					Byte.parseByte(getPropertiesWithDefValue("INVALID_FMSISDN_BT_IVR_PROMPT",
							String.valueOf(tempCachedParameters.getInvalidFmsisdnBtIvrPromptEnable()))));
			tempCachedParameters.setFmsisdnNotInRangeBtIvrPrmptEnable(
					Byte.parseByte(getPropertiesWithDefValue("FMSISDN_NOT_IN_RANGE_BT_IVR_PROMPT",
							String.valueOf(tempCachedParameters.getFmsisdnNotInRangeBtIvrPrmptEnable()))));
			tempCachedParameters.setEnabledTestChargingResult(
					Byte.parseByte(getPropertiesWithDefValue("ENABLED_TEST_CHARGING_RESULT",
							String.valueOf(tempCachedParameters.getEnabledTestChargingResult()))));

			tempCachedParameters.setDataBaseType(Byte.parseByte(getPropertiesWithDefValue("DATABASE_TYPE",
					String.valueOf(tempCachedParameters.getDataBaseType()))));

			tempCachedParameters.setFallBackEnable(Byte.parseByte(getPropertiesWithDefValue("FALL_BACK_ENABLE",
					String.valueOf(tempCachedParameters.getFallBackEnable()))));

			tempCachedParameters.setShowBalanceInLowBalanceMsg(
					Byte.parseByte(getPropertiesWithDefValue("SHOW_BALANCE_IN_LOW_BALANCE_MSG",
							String.valueOf(tempCachedParameters.getShowBalanceInLowBalanceMsg()))));

			tempCachedParameters
					.setCallArchiveFileInterval(Byte.parseByte(getPropertiesWithDefValue("CALL_ARCHIVE_FILE_INTERVAL",
							String.valueOf(tempCachedParameters.getCallArchiveFileInterval()))));
			tempCachedParameters.setCallLogFileName(
					getPropertiesWithDefValue("CALL_LOG_FILE_NAME", tempCachedParameters.getCallLogFileName()));
			tempCachedParameters.setCallLogFilePath(
					getPropertiesWithDefValue("CALL_LOG_FILE_PATH", tempCachedParameters.getCallLogFilePath()));
			tempCachedParameters.setCallArchiveFilePath(
					getPropertiesWithDefValue("CALL_ARCHIVE_FILE_PATH", tempCachedParameters.getCallArchiveFilePath()));
			tempCachedParameters.setCallArchiveFileName(
					getPropertiesWithDefValue("CALL_ARCHIVE_FILE_NAME", tempCachedParameters.getCallArchiveFileName()));
			tempCachedParameters.setArchiveFileExtension(getPropertiesWithDefValue("SET_ARCHIVE_FILE_EXTENSION",
					tempCachedParameters.getArchiveFileExtension()));
			tempCachedParameters.setMaxIdleTime(Integer.parseInt(
					getPropertiesWithDefValue("MAX_IDLE_TIME", String.valueOf(tempCachedParameters.getMaxIdleTime()))));
			tempCachedParameters.setDmcAllowedSubType(getPropertiesWithDefValue("DMC_ALLOWED_SUB_TYPE",
					String.valueOf(tempCachedParameters.getDmcAllowedSubType())));

			tempCachedParameters.setCheckServiceBlanceAllowedSubType(
					getPropertiesWithDefValue("CHECK_SERVICE_BALANCE_ALLOWED_SUB_TYPE",
							String.valueOf(tempCachedParameters.getCheckServiceBlanceAllowedSubType())));
			tempCachedParameters.setCheckDataBalanceNumAllowedAfterDec(
					Byte.parseByte(getPropertiesWithDefValue("CHECK_DATA_BALANCE_NUMBER_ALLOWED_AFTER_DECIMAL",
							String.valueOf(tempCachedParameters.getCheckDataBalanceNumAllowedAfterDec()))));

			if ("0".equals(getPropertiesWithDefValue("CHECK_DATA_BALANCE_FLOAT_VALUE_ENABLE", "0").trim()))
				tempCachedParameters.setCheckDataBalanceFloatEnable(false);
			else
				tempCachedParameters.setFloatValueEnable(true);

			tempCachedParameters
					.setMaxActiveDataAccMenus(Byte.parseByte(getPropertiesWithDefValue("ACTIVE_DATA_ACCOUNT_MAX_MENUS",
							String.valueOf(tempCachedParameters.getMaxActiveDataAccMenus())).trim()));

			tempCachedParameters.setCheckDataBlanceDateFormat(getPropertiesWithDefValue(
					"CHECK_DATA_BALANCE_DATE_FORMAT", tempCachedParameters.getCheckDataBlanceDateFormat()));

			tempCachedParameters.setUnlimitedDataAccountTypes(getPropertiesWithDefValue("UNLIMITED_DATA_ACCOUNT_TYPES",
					tempCachedParameters.getUnlimitedDataAccountTypes()));

			tempCachedParameters.setMysqlSequenceGeneratedFromSeqTable(
					Byte.parseByte(getPropertiesWithDefValue("MYSQL_SEQUENCE_GENERATED_FROM_SEQ_TABLE",
							String.valueOf(tempCachedParameters.getMysqlSequenceGeneratedFromSeqTable())).trim()));

			String showPromoPacksBasedOnBalance = getPropertiesValue("SHOW_PROMOTION_PACK_BASED_ON_BALANCE").trim();
			if (showPromoPacksBasedOnBalance != null) {
				if (showPromoPacksBasedOnBalance.equals("1"))
					tempCachedParameters.setShowPromotionPacksBasedOnBalance(true);
				else
					tempCachedParameters.setShowPromotionPacksBasedOnBalance(false);
			} else {
				tempCachedParameters
						.setShowPromotionPacksBasedOnBalance(tempCachedParameters.isShowPromotionPacksBasedOnBalance());
			}

			tempCachedParameters.setIsDiameterChargingEnable(
					Byte.parseByte(getPropertiesWithDefValue("IS_DIAMETER_BASED_CHARGING_ENABLE",
							String.valueOf(tempCachedParameters.getIsDiameterChargingEnable())).trim()));

			
			tempCachedParameters.setCustomerCareIvrPromptBasePath(getPropertiesWithDefValue("CUSTOMER_CARE_IVR_BASE_PATH",
					tempCachedParameters.getCustomerCareIvrPromptBasePath()));
			
			// loading parameters for charging
			Global.loadConfiguration(propertiesFile);

		} catch (NullPointerException npe) {
			logger.error(TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occured while parsing value from properties file, some values may be null",
					npe);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (NumberFormatException nfe) {
			logger.error(TSSJavaUtil.getLogInitial("90004")
					+ " >> NumberFormatException occured while parsing value from String to Number ", nfe);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(TSSJavaUtil.getLogInitial("00006")
					+ " >> Exception occured while parsing value from properties file ", e);
			return CodeStatus.EXCEPTION_OCCURED;
		}
		logger.info(">> values of all the constants are set successfully : " + tempCachedParameters);
		return CodeStatus.SUCCESS;
	}

	/**
	 * This method is used for loading the data for app Counter means
	 * COUNTER_RESET_TIME from properties file
	 */
	private static void loadAppCounterData() {
		logger.info(">> loading data for App Counter");
		String counterResetTimeDur = getPropertiesValue("COUNTER_RESET_TIME");
		if (counterResetTimeDur != null && !"".equals(counterResetTimeDur)) {
			try {
				TSSJavaUtil.appCounterResetTimeDurationMS = Long.parseLong(counterResetTimeDur) * 1000l;// multiplied
																										// by
																										// 1000
																										// to
																										// convert
																										// in
																										// milliseconds
			} catch (NumberFormatException nfe) {
				logger.warn(TSSJavaUtil.getLogInitial("90004")
						+ " >> Exception occurred while parsing COUNTER_RESET_TIME from properties file as long number so using default value as ["
						+ appCounterResetTimeDurationMS + "] mili seconds", nfe);
				return;
			} catch (Exception e) {
				logger.warn(TSSJavaUtil.getLogInitial("00007")
						+ " >> Exception occurred while parsing COUNTER_RESET_TIME from properties file as long number so using default value as ["
						+ appCounterResetTimeDurationMS + "] mili seconds");
				return;
			}
		} else {
			logger.warn(TSSJavaUtil.getLogInitial("00008")
					+ " >> COUNTER_RESET_TIME not defined in properties file so using default ["
					+ TSSJavaUtil.appCounterResetTimeDurationMS + "] mili seconds");
			return;
		}
		logger.info(">> data for App Counter is loaded successfully");
	}

	/**
	 * This method is used to create or re-create connection pool with database
	 * after destroying old connection pool
	 * 
	 * @param tempCachedParameters
	 * @return status of execution of this method means success or failure
	 */
	private CodeStatus createConnectionPool(CachedParameters tempCachedParameters) {
		logger.info(" >> Going to create connection pool");
		long currentTime = System.currentTimeMillis();
		if (TSSJavaUtil.connPool == null || TSSJavaUtil.connPool.destroyConnectionPool()) {

			ConnPool tempConnPool = new ConnPool();
			boolean status = tempConnPool.makePool(tempCachedParameters.getDbDriver(), tempCachedParameters.getDbURL(),
					tempCachedParameters.getDbUsername(), tempCachedParameters.getDbPassword(),
					tempCachedParameters.getDbMinPoolSize(), tempCachedParameters.getDbMaxPoolSize(),
					tempCachedParameters.getDbAccomodation(), tempCachedParameters.getMaxIdleTime());

			TSSJavaUtil.connPool = tempConnPool;
			logger.info(" >> connection pool creating status [" + status + "]  Time Taken:["
					+ (System.currentTimeMillis() - currentTime) + "]");
			return CodeStatus.SUCCESS;
		} else {
			logger.error(TSSJavaUtil.getLogInitial("00009")
					+ " >> Unable to destroy old connection pool, so not creating new connection pool");
			return CodeStatus.FAILURE;
		}
	}

	/**
	 * This method is used to load the data from database using db operations class
	 * 
	 * @param tempCachedParameters
	 * @return status of execution of this method means success or failure etc
	 */
	private static CodeStatus loadDBCache(CachedParameters tempCachedParameters) {
		logger.info(" >> Going to fetch the required data from database");

		DBOperations dbOps = new DBOperations();
		CodeStatus status = null;
		Connection con = null;

		try {
			con = TSSJavaUtil.connPool.getConnection();

			if (con == null) {
				logger.error(TSSJavaUtil.getLogInitial("00010") + " >> connection to database is [" + con
						+ "] so not loading cache from database");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			// DataBase Queries Constructor. Used to created database queries depends upon
			// selected database type. (SIDDHARTH)
			new DataBaseQueries().constructQuery(tempCachedParameters.getDataBaseType());

			// loading APP_CONFIG_PARAM ranges added by SIDDHARTH
			status = dbOps.new CacheLoader().loadAppConfigParam(tempCachedParameters.getAppConfigParamMap(), con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("00138")
						+ " >> unable to MPLACE_APP_CONFIG_PARAMS so returning failure : status [" + status + "]");
				return CodeStatus.FAILURE;
			}

			// loading service action details added by SIDDHARTH
			status = dbOps.new CacheLoader().loadServiceActionDetails(tempCachedParameters.getServiceActionDetailMap(),
					con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("00138")
						+ " >> unable to load Service Action Details so returning failure : status [" + status + "]");
				return CodeStatus.FAILURE;
			}

			// Used to load Data Macro Credit Conversion Configuration
			if (!fillDmcConversionConfigList(tempCachedParameters)) {
				logger.error("Unable to load Data Macro Credit Service Configurations.");
			}

			// Used to load Data Packs Details for CADD
			if (!fillDataPackDetailsMapForCADD(tempCachedParameters)) {
				logger.error("Unable to load Data Packs Configurations for Check Data Balance service.");
			}

			// Used to load POD users their promotional packs
			/*
			 * status = dbOps.new
			 * CacheLoader().loadPromoUsersAndServiceDetails(tempCachedParameters.
			 * getPromoServiceMap(), con); if (status != CodeStatus.SUCCESS) {
			 * logger.error(TSSJavaUtil.getLogInitial("00012") +
			 * " >> unable to load available Packs so returning failure : status [" + status
			 * + "]"); return CodeStatus.FAILURE; }
			 */

			// Used to load promotional packs detail
			status = dbOps.new CacheLoader().loadPromotionPacksDetail(tempCachedParameters.getPromoPackDetailsMap(),
					con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("00012")
						+ " >> unable to load available Packs so returning failure : status [" + status + "]");
				return CodeStatus.FAILURE;
			}

			// Filling POD Packs Detail Service map
			if (!fillPromotionPackDetailMap(tempCachedParameters)) {
				logger.error("Unable to load Data Packs Configurations for Check Data Balance service.");
			}

			// loading MSISDN ranges
			status = dbOps.new CacheLoader().loadMsisdnRanges(tempCachedParameters.getMsisdnRangeList(), con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("00011")
						+ " >> unable to load MSISDN ranges so returning failure : status [" + status + "]");
				return CodeStatus.FAILURE;
			}

			// loading packs
			status = dbOps.new CacheLoader().loadAvailablePacks(tempCachedParameters.getAvailablePacksMap(), con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("00012")
						+ " >> unable to load available Packs so returning failure : status [" + status + "]");
				return CodeStatus.FAILURE;
			}

			status = dbOps.new CacheLoader()
					.loadAvailableLowBalancePacks(tempCachedParameters.getAvailableLowBalancePacksMap(), con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("00012")
						+ " >> unable to load available low balance Packs so returning failure : status [" + status
						+ "]");
				return CodeStatus.FAILURE;
			}

			// loading all available pack type
			status = dbOps.new CacheLoader().loadAllAvailablePackType(tempCachedParameters.getAvailablePackTypeMap(),
					tempCachedParameters.getPackTypeDetailsMap(), con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("000326")
						+ ">> unable to load all available pack type so returning failue : status[" + status + "]");
				return CodeStatus.FAILURE;
			}

			// loading ussd menu details
			status = dbOps.new CacheLoader().loadUSSDMenus(tempCachedParameters.getUssdMenuDetailsMap(), con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("00013")
						+ " >> unable to load USSD menu details so returning failure : status [" + status + "]");
				return CodeStatus.FAILURE;
			}

			// loading whitelisted and blacklisted MSISDNs
			status = dbOps.new CacheLoader().loadWhiteBlacklistedMSISDNs(tempCachedParameters.getWhiteListedMSISDNs(),
					tempCachedParameters.getBlackListedMSISDNs(), con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("00014")
						+ " >> unable to load whitelisted and blacklisted MSISDNs so returning failure : status ["
						+ status + "]");
				return CodeStatus.FAILURE;
			}

			// loading available pack types
			status = dbOps.new CacheLoader().loadAvailablePackTypes(tempCachedParameters.getAvailablePackTypeIDs(),
					tempCachedParameters.getAvailablePackTypes(),
					tempCachedParameters.getAvailablePackTypeParallelEnableMap(), con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("00015")
						+ ">> unable to load available pack types so returning failure");
				return CodeStatus.FAILURE;
			}

			// loading product codes and service charge details
			status = dbOps.new CacheLoader()
					.loadProductCodesAndServiceChargeDetails(tempCachedParameters.getSrvcChargeDetails(), con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("00016")
						+ " >> unable to load product codes and service charge details so returning failure");
				return CodeStatus.FAILURE;
			}

			// loading transfer validity configuration
			status = dbOps.new CacheLoader()
					.loadTransferValidityConfig(tempCachedParameters.getTransferValidityConfig(), con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("00017")
						+ " >> unable to load transfer validity configuration so returning failure");
				return CodeStatus.FAILURE;
			}

			// loading templates from LBS templates
			status = dbOps.new CacheLoader().loadLBSTemplates(tempCachedParameters.getLbsTemplates(), con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("00179")
						+ " >> unable to load LBS templates from database so returning failure");
				return CodeStatus.FAILURE;
			}

			
			/*
			 * Added by Richard on 7th November 2019
			 * 
			 * Loading Error Codes Menu Strings
			 */
			status = dbOps.new CacheLoader().loadErrorCodesMenuMap(tempCachedParameters.getErrorCodesMenuMap(), con);
			if (status != CodeStatus.SUCCESS) {
				logger.error(TSSJavaUtil.getLogInitial("00380")
						+ " >> unable to load Error Code Menu Map from database so returning failure");
				return CodeStatus.FAILURE;
			}
			
			// Commented by abhishek because these two table are missing on site.

			// loading short code related details for Direct Dial.
			/*
			 * status = dbOps.new
			 * CacheLoader().loadShortcodeMappingDetails(tempCachedParameters.
			 * getShortCodeMappedDetails(), con); if (status != CodeStatus.SUCCESS) {
			 * logger.error(TSSJavaUtil.getLogInitial("00291") +
			 * " >> unable to load Shortcode Mapping details for Direct Dial from database so returning failure"
			 * ); return CodeStatus.FAILURE; }
			 */

			// loading virtual code related details for Direct Dial.
			/*
			 * status = dbOps.new CacheLoader()
			 * .loadVirtualcodeMappingDetails(tempCachedParameters.
			 * getVirtualCodeMappedDetails(), con); if (status != CodeStatus.SUCCESS) {
			 * logger.error(TSSJavaUtil.getLogInitial("00294") +
			 * " >> unable to load Virtual Code Mapping details for Direct Dial from database so returning failure"
			 * ); return CodeStatus.FAILURE; }
			 */

			// closing connection
			// con.close();
		} catch (NullPointerException npe) {
			logger.error(TSSJavaUtil.getLogInitial("90003")
					+ ">> NullPointerException occurred while closing connection so returning failure, con:[" + con
					+ "] may be null.", npe);
			return CodeStatus.FAILURE;
		} catch (Exception e) {
			logger.error(TSSJavaUtil.getLogInitial("00018")
					+ ">> Exception occurred while closing connection so returning failure", e);
			return CodeStatus.FAILURE;
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (Exception exp) {
				logger.warn(" >> Exception While closing resultSet or pstatement or connection while loading cache");
			}
		}
		return CodeStatus.SUCCESS;
	}

	private static boolean fillPromotionPackDetailMap(CachedParameters tempCachedParameters) {

		logger.info(
				"Inside fillPromotionPackDetailMap to fill Data Macro Credit Advance Setting Configurations for Amount and Servie Based");

		if (tempCachedParameters.getPromoPackDetailsMap() == null) {
			logger.error("getPromoPackDetailsMap found null so return flase.");
			return false;
		}

		try {

			for (Map.Entry<String, PromoPackBean> entry : tempCachedParameters.getPromoPackDetailsMap().entrySet()) {
				logger.debug("Filling JSON in getPromoPackDetailsMap with KEY[" + entry.getKey() + "] Value["
						+ entry.getValue() + "].");
				entry.getValue().setPromotionPackOtherDetails(
						(new Gson().fromJson(entry.getValue().getOther(), PromotionPackOtherDetails.class)));
			}
		} catch (Exception e) {
			logger.error("Exception while filling dmcConversionConfigList. Exception:" + e.getMessage());
			e.printStackTrace();
			return false;
		}

		return true;
	}

	/**
	 * This method is used to fill the Data Pack Details Configuration Map. It used
	 * to fill the information required for Check Active Data Details (CADD)
	 * service.
	 * 
	 * @param tempCachedParameters
	 * @author SIDDHARTH
	 * @return True (If method execute without exception) / False
	 */
	private static boolean fillDataPackDetailsMapForCADD(CachedParameters tempCachedParameters) {

		logger.info("Inside fillDataPackDetailConfigMap to fill Data Pack Detail Configurations.");
		ArrayList<PackDetailConfig> tempArrayList = null;
		if (tempCachedParameters.getServiceActionDetailMap() == null
				|| tempCachedParameters.getPackDetailConfigMap() == null) {
			logger.warn("Either serviceActionDetailMap or getPackDetailConfigMap found null so return flase.");
			return false;
		}

		try {

			if (tempCachedParameters.getServiceActionDetailMap()
					.containsKey(MPCommonDataTypes.CHECK_DATA_BALANCE_ACTION_TYPE)) {
				String jsonString = tempCachedParameters.getServiceActionDetailMap()
						.get(MPCommonDataTypes.CHECK_DATA_BALANCE_ACTION_TYPE);

				logger.debug("fillDataPackDetailConfigMap jsonString: " + jsonString);

				tempArrayList = new Gson().fromJson(jsonString, new TypeToken<List<PackDetailConfig>>() {
				}.getType());

			}

			if (tempArrayList == null || tempArrayList.isEmpty()) {
				logger.warn("ArrayList of PackDetailConfig found null or empty.");
				return false;
			} else {
				logger.info("ArrayList of PackDetailConfig Size [" + tempArrayList.size() + "]");
				tempCachedParameters.getPackDetailConfigMap().clear();

				for (PackDetailConfig packDetailConfig : tempArrayList) {
					tempCachedParameters.getPackDetailConfigMap().put(packDetailConfig.getAccountId(),
							packDetailConfig);
				}
			}
		} catch (Exception e) {
			logger.error("Exception while filling fillDataPackDetailConfigMap. Exception:" + e.getMessage());
			e.printStackTrace();
			return false;
		}

		return true;
	}

	/**
	 * This method is used to fill all the configuration details of DMC Amount Based
	 * Service and DMC Volume Based Service.
	 * 
	 * @param tempCachedParameters
	 * @return false in case of any error or not able to fill DMC configuration
	 *         details else return true.
	 */
	private static boolean fillDmcConversionConfigList(CachedParameters tempCachedParameters) {

		logger.info(
				"Inside fillDmcConversionConfigList to fill Data Macro Credit Advance Setting Configurations for Amount and Servie Based");
		ArrayList<DmcConversionConfig> tempArrayList = null;
		String jsonStringDMCAB = "";
		String jsonStringDMCVB = "";

		if (tempCachedParameters.getServiceActionDetailMap() == null
				|| tempCachedParameters.getDmcAbConversionConfigList() == null
				|| tempCachedParameters.getDmcVbConversionConfigList() == null) {
			logger.error(
					"Either serviceActionDetailMap or DmcAbConversionConfigList or DmcVbConversionConfigList found null so return flase.");
			return false;
		}

		try {

			if (tempCachedParameters.getServiceActionDetailMap()
					.containsKey(MPCommonDataTypes.DATA_MACRO_CREDIT_AMOUNT_BASED_ACTION_TYPE)) {
				jsonStringDMCAB = tempCachedParameters.getServiceActionDetailMap()
						.get(MPCommonDataTypes.DATA_MACRO_CREDIT_AMOUNT_BASED_ACTION_TYPE);
				logger.debug("DATA MACRO CREDIT AMOUNT BASED jsonStringDMCAB = " + jsonStringDMCAB);
				tempArrayList = new Gson().fromJson(jsonStringDMCAB, new TypeToken<List<DmcConversionConfig>>() {
				}.getType());

				if (tempArrayList == null || tempArrayList.isEmpty()) {
					logger.error("Filled DmcAbConversionConfigList list found null or empty.");
					return false;
				} else {
					logger.info("dmcConversionConfigList size[" + tempArrayList.size() + "]");
					tempCachedParameters.getDmcAbConversionConfigList().clear();
					tempCachedParameters.getDmcAbConversionConfigList().addAll(tempArrayList);
				}
			}

			tempArrayList = null;
			if (tempCachedParameters.getServiceActionDetailMap()
					.containsKey(MPCommonDataTypes.DATA_MACRO_CREDIT_VOLUME_BASED_ACTION_TYPE)) {
				jsonStringDMCVB = tempCachedParameters.getServiceActionDetailMap()
						.get(MPCommonDataTypes.DATA_MACRO_CREDIT_VOLUME_BASED_ACTION_TYPE);
				logger.debug("DATA MACRO CREDIT VOLUME BASED jsonStringDMCVB = " + jsonStringDMCVB);
				tempArrayList = new Gson().fromJson(jsonStringDMCVB, new TypeToken<List<DmcConversionConfig>>() {
				}.getType());

				if (tempArrayList == null || tempArrayList.isEmpty()) {
					logger.error("Filled DmcVbConversionConfigList list found null or empty.");
					return false;
				} else {
					logger.info("DmcVbConversionConfigList size[" + tempArrayList.size() + "]");
					tempCachedParameters.getDmcVbConversionConfigList().clear();
					tempCachedParameters.getDmcVbConversionConfigList().addAll(tempArrayList);
				}
			}

		} catch (Exception e) {
			logger.error("Exception while filling dmcConversionConfigList. Exception:" + e.getMessage());
			e.printStackTrace();
			return false;
		}

		return true;
	}

	/**
	 * This method is used to return String value defined for the key passed from
	 * properties file
	 * 
	 * @param key
	 * @return String value defined for the key
	 */
	public static String getPropertiesValue(String key) {
		if (key == null || key.equalsIgnoreCase("")) {
			logger.error(TSSJavaUtil.getLogInitial("00019") + ">> Having Key [" + key + "] so retunrning null");
			return null;
		} else {
			String tempValue = propertiesFile.getProperty(key.trim());
			if (tempValue == null || "".equals(tempValue)) {
				logger.warn(TSSJavaUtil.getLogInitial("00020") + "\n\n\tkey [" + key
						+ "] is not defined in properties file\n\n");
				return tempValue;
			}
			return tempValue.trim();
		}
	}

	/**
	 * This method is used to return String value defined for the key passed from
	 * properties file
	 * 
	 * @param key
	 * @return String value defined for the key
	 */
	public static String getPropertiesWithDefValue(String key, String defaultValue) {
		if (key == null || key.equalsIgnoreCase("") || defaultValue == null) {
			logger.error(TSSJavaUtil.getLogInitial("00021") + ">> Having Key [" + key + "] so returning null");
			return defaultValue;
		} else {
			String tempValue = propertiesFile.getProperty(key.trim());
			if (tempValue == null || "".equals(tempValue)) {
				logger.warn(TSSJavaUtil.getLogInitial("00022") + "\n\n\tkey [" + key
						+ "] is not defined in properties file so retunring default value [" + defaultValue.trim()
						+ "]\n\n");
				return defaultValue.trim();
			}
			return tempValue.trim();
		}
	}

	/**
	 * This method is used to update and return app counter and to reset it, if
	 * needed
	 */
	public int updateAndGetAppCounter() {
		long currentTimeInMS = new java.util.Date().getTime();
		long appCounterLastResetDur = currentTimeInMS - appCounterLastResetTimeMS;
		logger.debug(">> current time [" + currentTimeInMS + "] mili seconds app counter last reset ["
				+ appCounterLastResetTimeMS + "] mili seconds app counter last reset duration ["
				+ appCounterLastResetDur + "] mili seconds app counter need to reset after duration ["
				+ appCounterResetTimeDurationMS + "] mili seconds (from properties file or default if not found)");

		if (appCounterLastResetDur > appCounterResetTimeDurationMS) {
			appCounter = 0;
			appCounterLastResetTimeMS = currentTimeInMS;
			logger.info(">> app counter last reset duration [" + appCounterLastResetDur
					+ "] mili seconds app counter need to reset after duration [" + appCounterResetTimeDurationMS
					+ "]  mili seconds (from properties file or default if not found) So resetting app Counter at ["
					+ new Date() + "]");
		}
		return ++appCounter;
	}

	/**
	 * This method is used to return the country code of passed mobile number
	 * 
	 * @param msisdn
	 * @return countryCode
	 */
	public String getCountryCode(String msisdn) {
		logger.debug(">> here to return country code of number : msisdn [" + msisdn + "]");

		String receivedNum = msisdn.toString();

		// checking in operator range
		for (int i = 0; i < cachedParameters.getMsisdnRangeList().size(); i++) {
			MsisdnRange range = cachedParameters.getMsisdnRangeList().get(i);
			if (Long.parseLong(receivedNum) >= Long.parseLong(range.getStartsFrom())
					&& Long.parseLong(receivedNum) <= Long.parseLong(range.getEndsAt())) {
				return range.getCountryCode();
				// return "221";
			}
		}
		// if not found in any range
		logger.warn(TSSJavaUtil.getLogInitial("00279") + " >> Msisdn [" + receivedNum
				+ "] not found in the operator subscriber range");
		return "";

	}// ends getCountryCode()

	/**
	 * This method is used to convert the passed mobile number in international
	 * number
	 * 
	 * @param msisdn
	 * @return true if MSISDN is in range else false
	 */
	public boolean getInternationalNumber(StringBuffer msisdn) {
		logger.debug(">> converting msisdn to international number : msisdn [" + msisdn + "]");

		if (msisdn == null || "".equals(msisdn.toString())) {
			logger.warn(TSSJavaUtil.getLogInitial("00023") + " >> msisdn received is [" + msisdn + "] so returning");
			return false;
		}

		String receivedNum = msisdn.toString();

		// removing extra digits
		if (receivedNum.startsWith("00")) {
			receivedNum = receivedNum.substring(2);
		}
		if (receivedNum.startsWith("0") || receivedNum.startsWith("+")) {
			receivedNum = receivedNum.substring(1);
		}

		// checking in operator range
		for (int i = 0; i < cachedParameters.getMsisdnRangeList().size(); i++) {
			MsisdnRange range = cachedParameters.getMsisdnRangeList().get(i);
			if (Long.parseLong(receivedNum) >= Long.parseLong(range.getStartsFrom())
					&& Long.parseLong(receivedNum) <= Long.parseLong(range.getEndsAt())) {
				if (!receivedNum.startsWith(range.getCountryCode())) {
					receivedNum = range.getCountryCode() + receivedNum;
					msisdn.delete(0, msisdn.length());
					msisdn.append(receivedNum);
				}
				logger.info(" >> Msisdn [" + receivedNum + "] found in the operator subscriber range " + range);
				return true;
			}
		}
		// if not found in any range
		logger.warn(TSSJavaUtil.getLogInitial("00024") + " >> Msisdn [" + receivedNum
				+ "] not found in the operator subscriber range");
		return false;

	}// ends getInternationalNumber()

	/**
	 * This Method is used to get the Prompt File Path of any Pack or Pack Type.
	 * 
	 * @param commonBean
	 * @return promptFileName
	 * @author SIDDHARTH
	 */
	public String getPromptFilePath(PackPackTypeCommonBean commonBean) {
		String promptFileName = "";
		try {
			if (commonBean != null)
				promptFileName = commonBean.getLanguageId() + File.separator + commonBean.getPormptFilePath();

			else {
				promptFileName = IvrMenu.NO_FILE_PATH_IVR;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return promptFileName;
		}

		return promptFileName;
	}

	/**
	 * This method is used to get the prompt file of the given digit Converting the
	 * number into wav file.
	 * 
	 * @param number
	 * @param langId
	 * @param ivr_base_path
	 * @return number prompt file path
	 * @author SIDDHARTH
	 */
	public String getNumberPrompt(String number, byte langId, String ivr_base_path) {
		String numberPrompt = "";
		try {
			logger.info(" >> Inside getNumberPrompt() to get the prompt of the Number:[" + number
					+ "] where LanguageId:[" + langId + "]");
			// added to show pack amount in double/float if true else in Integer
			if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
				for (int i = 0; i < number.length(); i++) {
					char digit = number.charAt(i);
					if (digit == '.')
						numberPrompt += ivr_base_path + langId + File.separator + IvrMenu.POINT_WAV_IVR
								+ TSSJavaUtil.FileSeparator;
					else
						numberPrompt += ivr_base_path + langId + File.separator + digit + IvrMenu.PROMPT_EXTENSION
								+ TSSJavaUtil.FileSeparator;
				}
			} else {
				for (int i = 0; i < number.length(); i++) {
					char digit = number.charAt(i);
					if (digit == '.') {
						break;
					}
					numberPrompt += ivr_base_path + langId + File.separator + digit + IvrMenu.PROMPT_EXTENSION
							+ TSSJavaUtil.FileSeparator;
				}

			}

			if (numberPrompt.length() == 0 || numberPrompt == null) {
				numberPrompt = "NA";
			}

			else {
				numberPrompt = numberPrompt.substring(0, numberPrompt.length() - 1);
			}

			logger.info(
					">>(IVR) Final Number Prompt of Number:[" + number + "] is  NumberPrompt:[" + numberPrompt + "]");
		} catch (Exception e) {
			logger.error(" >>>> getNumberPrompt()  >> Some Error Found while converting Number into Prompt !!!");
			e.printStackTrace();
			return numberPrompt;
		}

		return numberPrompt;
	}

	/**
	 * This method is used to get the Currency prompt file path for requested
	 * language Id.
	 * 
	 * @param langId
	 * @return Currency Prompt File Path
	 * @author SIDDHARTH
	 */
	public String getCurrencyPrompt(byte langId) {
		String currencyPrompt = "";
		String ivr_base_path = "";
		try {
			ivr_base_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
			if (ivr_base_path.equalsIgnoreCase("NA") || ivr_base_path.equalsIgnoreCase("") || ivr_base_path == null) {
				logger.error(" >> (IVR)  Base file path is not found .");
				return currencyPrompt;
			} else {

				if (langId == 1)
					currencyPrompt = ivr_base_path + langId + File.separator + IvrMenu.CURRENCY_CFA_WAV_IVR;

				else if (langId == 2)
					currencyPrompt = ivr_base_path + langId + File.separator + IvrMenu.CURRENCY_DOLLAR_WAV_IVR;

				else
					currencyPrompt = IvrMenu.NO_FILE_PATH_IVR;

			}

		} catch (Exception e) {
			e.printStackTrace();
			return currencyPrompt;
		}

		return currencyPrompt;
	}

	/**
	 * This method is used to get the pressed number file path form the IvrMenu
	 * Interface
	 * 
	 * @param number
	 * @return pressed number file path
	 * @author SIDDHARTH
	 */
	public String getPressNumberPrompt(int number) {
		if (number == 1) {
			return IvrMenu.PRESS_1_FOR;
		} else if (number == 2) {
			return IvrMenu.PRESS_2_FOR;
		} else if (number == 3) {
			return IvrMenu.PRESS_3_FOR;
		} else if (number == 4) {
			return IvrMenu.PRESS_4_FOR;
		} else if (number == 5) {
			return IvrMenu.PRESS_5_FOR;
		} else if (number == 6) {
			return IvrMenu.PRESS_6_FOR;
		} else if (number == 7) {
			return IvrMenu.PRESS_7_FOR;
		} else if (number == 8) {
			return IvrMenu.PRESS_8_FOR;
		} else {
			return IvrMenu.NO_FILE_PATH_IVR;
		}
	}

	/**
	 * This method is used to get the time prompt file path
	 * 
	 * @param timeString
	 * @param ivrBasePath
	 * @param langId
	 * @author SIDDHARTH
	 */
	public String getTimePrompt(String timeString, String ivrBasePath, byte langId) {
		String timePrompt = "";

		try {
			String[] timeElements = timeString.split(":");
			String hourString = timeElements[0].trim();
			String minuteString = timeElements[1].trim();
			String secondString = timeElements[2].trim();
			logger.debug("(IVR) getTimePrompt() -->> timeString:[" + timeString + "], langId:[" + langId
					+ "], timeElement:[" + timeElements + "].");

			if (timeElements.length == 3) {
				if (hourString.startsWith("0")) {
					hourString = hourString.substring(1, hourString.length());
				}
				if (minuteString.startsWith("0")) {
					minuteString = minuteString.substring(1, minuteString.length());
				}
				if (secondString.startsWith("0")) {
					secondString = secondString.substring(1, secondString.length());
				}

				timePrompt = ivrBasePath + langId + File.separator + hourString.trim() + IvrMenu.PROMPT_EXTENSION
						+ FileSeparator + ivrBasePath + langId + File.separator + IvrMenu.HOUR_WAV_IVR + FileSeparator
						+ ivrBasePath + langId + File.separator + minuteString + IvrMenu.PROMPT_EXTENSION
						+ FileSeparator + ivrBasePath + langId + File.separator + IvrMenu.MINUTE_WAV_IVR + FileSeparator
						+ ivrBasePath + langId + File.separator + secondString + IvrMenu.PROMPT_EXTENSION
						+ FileSeparator + ivrBasePath + langId + File.separator + IvrMenu.SECOND_WAV_IVR;
			} else {
				logger.error("TimeString is not having a proper format !!!");
				return IvrMenu.NO_FILE_PATH_IVR;
			}

			logger.info("TimePrompt:[" + timePrompt + "]");
		} catch (Exception e) {
			e.printStackTrace();
			return IvrMenu.NO_FILE_PATH_IVR;
		}

		return timePrompt;
	}

	/**
	 * This method returns the IVR prompt of the selected month
	 * 
	 * @param month
	 * @author SIDDHARTH
	 */
	public String getMonthPrompt(String month) {
		if (month.equalsIgnoreCase("JAN")) {
			return IvrMenu.JANUARY_WAV_IVR;
		} else if (month.equalsIgnoreCase("FEB")) {
			return IvrMenu.FEBRUARY_WAV_IVR;
		} else if (month.equalsIgnoreCase("MAR")) {
			return IvrMenu.MARCH_WAV_IVR;
		} else if (month.equalsIgnoreCase("APR")) {
			return IvrMenu.APRIL_WAV_IVR;
		} else if (month.equalsIgnoreCase("MAY")) {
			return IvrMenu.MAY_WAV_IVR;
		} else if (month.equalsIgnoreCase("JUN")) {
			return IvrMenu.JUNE_WAV_IVR;
		} else if (month.equalsIgnoreCase("JUL")) {
			return IvrMenu.JULY_WAV_IVR;
		} else if (month.equalsIgnoreCase("AUG")) {
			return IvrMenu.AUGUST_WAV_IVR;
		} else if (month.equalsIgnoreCase("SEP")) {
			return IvrMenu.SEPTEMBER_WAV_IVR;
		} else if (month.equalsIgnoreCase("OCT")) {
			return IvrMenu.OCTOBER_WAV_IVR;
		} else if (month.equalsIgnoreCase("NOV")) {
			return IvrMenu.NOVEMBER_WAV_IVR;
		} else if (month.equalsIgnoreCase("DEC")) {
			return IvrMenu.DECEMBER_WAV_IVR;
		} else
			return IvrMenu.NO_FILE_PATH_IVR;
	}

	/**
	 * This method use to get unique Exception code string in all Java classes
	 * 
	 * @param code
	 * @return string that is to be printed in case of warnigng, error and fatal
	 *         logs
	 */
	public static String getLogInitial(String code) {
		return "[MP-API-" + code + "] ";
	}

	public String getPromptFilePathPackBean(PackBean packBean) {
		String promptFileName = "";
		try {
			if (packBean != null)
				promptFileName = packBean.getLangId() + File.separator + packBean.getPromptFile();

			else {
				promptFileName = IvrMenu.NO_FILE_PATH_IVR;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return promptFileName;
		}

		return promptFileName;
	}

	/**
	 * This method is used to get the validity type of Pack
	 * 
	 * @param validityType
	 * @return validity type of pack
	 * @author SIDDHARTH
	 */
	public static String getValadityType(String validityType) {
		String valadityTypeStr = "NA";
		try {
			if (MPCommonDataTypes.VALIDITY_TYPE_MO.equals(validityType)) {
				valadityTypeStr = MPCommonDataTypes.MONTH;
			} else if (MPCommonDataTypes.VALIDITY_TYPE_DY.equals(validityType)) {
				valadityTypeStr = MPCommonDataTypes.DAY;
			} else if (MPCommonDataTypes.VALIDITY_TYPE_HR.equals(validityType)) {
				valadityTypeStr = MPCommonDataTypes.HOUR;
			} else if (MPCommonDataTypes.VALIDITY_TYPE_MI.equals(validityType)) {
				valadityTypeStr = MPCommonDataTypes.MINUTE;
			} else if (MPCommonDataTypes.VALIDITY_TYPE_SC.equals(validityType)) {
				valadityTypeStr = MPCommonDataTypes.SECOND;
			} else {
				logger.error("ValidityType:[" + validityType + "] not found");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return valadityTypeStr;
	}

	/**
	 * This method is used to get the formatted Date in IVR Siddharth
	 * 
	 * @param dateString
	 * @param ivrBasePath
	 * @param langId
	 * @return requested date path string in IVR
	 * @author SIDDHARTH
	 */
	public String getFormattedIvrDate(String dateString, String ivrBasePath, byte langId) {
		String formattedDate = "";
		StringBuffer datePromptBuffer = new StringBuffer();
		try {
			SimpleDateFormat currFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy HH:mm:ss");
			Date d1 = null;
			d1 = currFormat.parse(dateString);
			formattedDate = dateFormat.format(d1);

			logger.debug(" >> formattedDate [" + formattedDate + "].");
			String[] splittedDate = formattedDate.split(" ");
			String dayPrompt = splittedDate[0].trim();
			if (dayPrompt.startsWith("0")) {
				dayPrompt = dayPrompt.substring(1, dayPrompt.length());
			}
			logger.debug(
					" >> formattedDate [" + formattedDate + "],  splittedDate.length:[" + splittedDate.length + "].");

			datePromptBuffer.append(ivrBasePath).append(langId).append(File.separator).append(dayPrompt)
					.append(IvrMenu.PROMPT_EXTENSION).append(TSSJavaUtil.FileSeparator).append(ivrBasePath)
					.append(langId).append(File.separator)
					.append(TSSJavaUtil.instance().getMonthPrompt(splittedDate[1].trim()))
					.append(TSSJavaUtil.FileSeparator).append(ivrBasePath).append(langId).append(File.separator)
					.append(splittedDate[2]).append(IvrMenu.PROMPT_EXTENSION).append(TSSJavaUtil.FileSeparator)
					.append(TSSJavaUtil.instance().getTimePrompt(splittedDate[3].trim(), ivrBasePath, langId));

		} catch (Exception e) {
			logger.error("Exception while converting date in desired format" + e.getMessage());
			e.printStackTrace();
			return datePromptBuffer.toString();
		}

		return datePromptBuffer.toString();
	}

	/**
	 * This method is used to convert the object to UserData JSONString
	 * 
	 * @param userDataBean
	 * @return jsonString
	 * @author SIDDHARTH
	 */
	public String getUserDataJsonString(UserDataBean userDataBean) {
		String jsonString = "";

		try {
			HashMap<String, Object> hashMap = new HashMap<>();
			hashMap.put("MSISDN", userDataBean.getMsisdn());
			hashMap.put("REQUEST_ID", userDataBean.getRequestId());
			hashMap.put("FMSISDN", userDataBean.getFmsisdn());
			hashMap.put("INTERFACE", userDataBean.getInterfaceUsed());
			hashMap.put("SHORT_CODE", userDataBean.getShortCode());
			hashMap.put("CALL_START_TIME", userDataBean.getCallStartTime());
			hashMap.put("CALL_HANGUP_TIME", userDataBean.getCallHangUpTime());
			hashMap.put("ACCESSED_PACKS_DETAILS", userDataBean.getAccessedPacksRecords().toString());
			jsonString = JSONValue.toJSONString(hashMap);
			logger.debug("Retrieved JsonString: " + jsonString);
		} catch (Exception e) {
			logger.error("Exception while converting Object to JSONStrting.");
			e.printStackTrace();
		}

		return jsonString;
	}

	/**
	 * Used to set the properties of FileLogWriter
	 * 
	 * @param tempCachedParameters
	 * @author SIDDHARTH
	 * @return status of execution of this method means success or exception
	 *         occurred etc
	 */
	private static CodeStatus loadFileLogWriterConfiguration(CachedParameters tempCachedParameters) {
		logger.info(">> Setting porperties of FileLogWriter.");

		try {

			fileLogWriterCallDetailsLog.setNewFileInterval(tempCachedParameters.getCallArchiveFileInterval());
			fileLogWriterCallDetailsLog.setFilename(tempCachedParameters.getCallLogFileName());
			fileLogWriterCallDetailsLog.setFilePath(tempCachedParameters.getCallLogFilePath());
			fileLogWriterCallDetailsLog.setArchiveFilePath(tempCachedParameters.getCallArchiveFilePath());
			fileLogWriterCallDetailsLog.setArchiveFilename(tempCachedParameters.getCallArchiveFileName());
			fileLogWriterCallDetailsLog.setArchiveFileExtension(tempCachedParameters.getArchiveFileExtension());

		} catch (NullPointerException npe) {
			logger.error(TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occured while inserting value into FileLogWriter ", npe);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (NumberFormatException nfe) {
			logger.error(TSSJavaUtil.getLogInitial("90004")
					+ " >> NumberFormatException occured while inserting value into FileLogWriter ", nfe);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(TSSJavaUtil.getLogInitial("00340")
					+ " >> Exception occured while occured while inserting value into FileLogWriter ", e);
			return CodeStatus.EXCEPTION_OCCURED;
		}
		logger.info(">>All porperties of FileLogWriter set successfully.");
		return CodeStatus.SUCCESS;
	}

	/**
	 * This method takes PARAM_TAG and returns PARAM_VALUE define in
	 * MPLACE_APP_CONFIG_PARAMS.
	 * 
	 * @param paramName
	 * @author SIDDHARTH
	 * @return PARAM_VALUE
	 */
	public String getAppConfigParamValue(String paramTag) {
		String paramValue = "";
		try {
			String param = paramTag.toUpperCase();
			paramValue = (String) TSSJavaUtil.instance().getCacheParameters().getAppConfigParamMap().get(param).trim();
			if (paramValue == null) {
				logger.error("\nPARAM_VALUE for PARAM_TAG:[" + paramTag
						+ "] not Defined or null in MPLACE_APP_CONFIG_PARAMS table.\n");
			}
		} catch (Exception e) {
			logger.error("\nException while getting value for PARAM_TAG:[" + paramTag + "]\n" + e);
			e.printStackTrace();
			return "EXCEPTION";
		}
		logger.debug("Values found ==>> PARAM_TAG[" + paramTag + "] PARAM_VALUE[" + paramValue + "]");
		return paramValue;
	}

	/**
	 * This method is used to get PackOtherDeatils object from JSONString Siddharth
	 * 
	 * @param packOtherDetailsJSONString
	 * @return PackOtherDetails Object
	 */
	public static PackOtherDetails getPackOtherDetails(String packOtherDetailsJSONString) {
		PackOtherDetails packOtherDetails = null;
		try {
			packOtherDetails = new Gson().fromJson(packOtherDetailsJSONString, PackOtherDetails.class);
		} catch (Exception e) {
			logger.error("Exception while getting PackOtherDetails object from JSONString. Exception:" + e);
			e.printStackTrace();
		}
		return packOtherDetails;
	}

	/**
	 * This method is used to load the properties file and after that its loads
	 * Constant Values, File Log Writer Configuration, AppCounter Data and DBCache.
	 * This method creates a new temporary cache parameters class object and passes
	 * to different methods so that they can load the new data in this cache bean
	 * and then original cache parameters object is replaced by this temporary
	 * object after successful cache loading
	 * 
	 * @author SIDDHARTH
	 * @throws Exception
	 */
	private static void reloadCache() throws Exception {
		logger.info("\n\n\t\t >> Loading MarketPlace Cache\n");

		// loading properties file
		if (loadPropertiesFile() != CodeStatus.SUCCESS)
			throw new Exception("Unable to load cache");

		CachedParameters tempCachedParameters = new CachedParameters();

		if (propertiesFile != null) {
			// setting all the constants' values from properties file
			if (setConstantsValue(tempCachedParameters) != CodeStatus.SUCCESS)
				throw new Exception("Unable to load cache");

			// Loading FileLogWriter properties
			if (loadFileLogWriterConfiguration(tempCachedParameters) != CodeStatus.SUCCESS)
				throw new Exception("Unable to load cache");

			fileLogWriterCallDetailsLog.initialize();

			// loading data for app counter
			loadAppCounterData();

			// loading cache from database
			if (loadDBCache(tempCachedParameters) != CodeStatus.SUCCESS)
				throw new Exception("Unable to load cache");

			TSSJavaUtil.cachedParameters = tempCachedParameters;
		} else {
			logger.error(TSSJavaUtil.getLogInitial("00004") + " >> properties file is not initialized, so returning");
		}

	}

	/**
	 * This method is used to check the input string is integer or not
	 * 
	 * @param digit
	 * @return true if Integer / false
	 */
	public static boolean isInteger(String digit) {
		try {
			Integer.parseInt(digit);
		} catch (Exception e) {
			logger.warn("Exception: " + e.getMessage());
			return false;
		}
		return true;
	}

}