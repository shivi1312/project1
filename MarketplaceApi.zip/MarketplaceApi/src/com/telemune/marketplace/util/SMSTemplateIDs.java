/**
 * @author MoHit
 * Created on - 10 March, 2017
 */
package com.telemune.marketplace.util;

/**
 * Used to hold all the SMS template IDs used in this API
 * @author MoHit
 */
public interface SMSTemplateIDs {
	/**
     * Used to hold SMS template id that is to be used while sending SMS to
     * A party for OFFNET talk-time transfer is success
     */
    int TTT_SUCCESS_TEMPLATE_ID_A_OFFNET = 101;
    
    /**
     * Used to hold SMS template id that is to be used while sending SMS to
     * A party for ONNET talk-time transfer is success
     */
    int TTT_SUCCESS_TEMPLATE_ID_A_ONNET = 102;
    
    /**
     * Used to hold SMS template id that is to be used while sending SMS to
     * B party for OFFNET talk-time transfer is success
     */
    int TTT_SUCCESS_TEMPLATE_ID_B_OFFNET = 103;
    
    /**
     * Used to hold SMS template id that is to be used while sending SMS to
     * B party for ONNET talk-time transfer is success
     */
    int TTT_SUCCESS_TEMPLATE_ID_B_ONNET = 104;
    
    /**
     * Used to hold SMS template id that is to be used while sending SMS to
     * A party for bonus (gift) transfer is success
     */
    int BONUS_SUCCESS_TEMPLATE_ID_A = 105;
    
    /**
     * Used to hold SMS template id that is to be used while sending SMS to
     * B party for bonus (gift) transfer is success
     */
    int BONUS_SUCCESS_TEMPLATE_ID_B = 106;
    
    /**
     * Used to hold SMS template id that is to be used while sending SMS to
     * A party for data transfer is success
     */
    int DT_SUCCESS_TEMPLATE_ID_A = 107;
    
    /**
     * Used to hold SMS template id that is to be used while sending SMS to
     * B party for data transfer is success
     */
    int DT_SUCCESS_TEMPLATE_ID_B = 108;
}
