/**
 * @author MoHit
 * Created on - 21 Feb, 2017
 */
package com.telemune.marketplace.util;

/**
 * Used to hold some specific pack type names these are used in code
 * for getting their pack type IDs. These must be exactly equal to
 * the pack type names defined in database
 * @author MoHit
 */
public interface PackTypes {

	/**
	 * Used for check balance
	 */
	String CHECK_BALANCE		= "CHECK_BALANCE";
	
	/**
	 * Used for data transfer
	 */
	String TALK_TIME_TRANSFER	= "TALK_TIME_TRANSFER";
	
	/**
	 * Used for data macro credit transfer
	 */
	String DATA_MACRO_CREDIT_CONVERSION = "DATA_MACRO_CREDIT_CONVERSION";
}
