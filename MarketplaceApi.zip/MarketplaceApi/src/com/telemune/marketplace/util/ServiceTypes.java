/**
 * @author MoHit
 * Created on - 21 Feb, 2017
 */
package com.telemune.marketplace.util;

/**
 * Used to hold some specific service types
 * for internal usage
 * @author MoHit
 */
public interface ServiceTypes {
	String CHECK_BALANCE			= "CHECK_BALANCE";
	String PACK_PURHCASE			= "PACK_PURCHASE";
	String TALK_TIME_TRANSFER		= "TALK_TIME_TRANSFER";
	String BONUS_TRANSFER			= "BONUS_TRANSFER";
	String DATA_TRANSFER			= "DATA_TRANSFER";
	String CHECK_TRANSFER_BALANCE	= "CHECK_TRANSFER_BALANCE";
	String CHECK_DT_ELIGIBILITY		= "CHECK_DT_ELIGIBILITY";
	
	String ON_NET					= "ON_NET";
	String OFF_NET					= "OFF_NET";
	String EURO_OFF_NET				= "EURO_OFF_NET";
	String DATA						= "DATA";
	String GIFT						= "GIFT";
	
	String TALK_TIME_TRANSFER_ONNET	= "TALK_TIME_TRANSFER_ONNET";
	String TALK_TIME_TRANSFER_OFFNET= "TALK_TIME_TRANSFER_OFFNET";
	String DATA_MACRO_CREDIT = "DATA_MACRO_CREDIT";
}
