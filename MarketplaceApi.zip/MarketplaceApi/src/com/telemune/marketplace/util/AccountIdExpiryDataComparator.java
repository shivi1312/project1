package com.telemune.marketplace.util;

import java.util.Comparator;

import com.telemune.marketplace.beans.UserAccountInfoBean;

/**
 * This class is a custom comparator class used to order the UserAccounts
 * Information according to the AccountId and ExpiryDate. It first sort the
 * UserAccountInfoBean according to AccountId then it sort it according to the
 * ExpiryDate.
 * 
 * @author SIDDHARTH SINGH RAWAT
 */
public class AccountIdExpiryDataComparator implements Comparator<UserAccountInfoBean> {

	@Override
	public int compare(UserAccountInfoBean o1, UserAccountInfoBean o2) {
		int comp = o1.getAcctId().compareTo(o2.getAcctId());
		if (comp != 0) {
			return -comp;
		}

		return (o1.getExpiryTime().compareTo(o2.getExpiryTime()));
	}

}
