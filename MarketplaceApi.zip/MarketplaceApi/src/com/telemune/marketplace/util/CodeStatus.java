/**
 * @author MoHit
 * Created on - 10 Feb, 2017
 */
package com.telemune.marketplace.util;

/**
 * This enum is used for holding some fixed codes for common status of code
 * like exception occurred, success, etc
 * @author MoHit
 */
public enum CodeStatus {
	SUCCESS,
	FAILURE,
	CONNECTION_IS_NULL,
	EXCEPTION_OCCURED,
	CHARGING_FAILED,
	INVALID_REQUEST,
	LOW_BALANCE,
	LOW_TTT_BALANCE,
	NOT_ELIGIBLE_FOR_DT,
	ALREADY_REFER_SAME_PLAN
}
