package com.telemune.marketplace.beans;

/**
 * This bean is used to hold the value of purchased pack by user.
 * 
 * @author Siddharth Singh Rawat
 *
 */
public class UserPackPurchaseBean {

	
	private String transaction_Id;
	private String msisdn;
	private int pack_Id;
	private int pack_Type;
	private String pack_Name;
	private int lang_Id;
	private String description;
	private String expiry_Date;
	private int validity_Days;
	private String validity_type;
	private String promptFilePath;
	private String others;
	
	public UserPackPurchaseBean(){
		
	}
	public UserPackPurchaseBean(String transactionId,String msisdn,int pack_Id,String pack_Name,int lang_Id,String description,
			String expiry_Date,int validity_Days,String validity_type,String others,int pack_type){
		super();
		this.transaction_Id = transactionId;
		this.msisdn = msisdn;
		this.pack_Id = pack_Id;
		this.pack_Name = pack_Name;
		this.lang_Id = lang_Id;
		this.description = description;
		this.expiry_Date = expiry_Date;
		this.validity_Days = validity_Days;
		this.validity_type=validity_type;
		this.others = others;
		this.pack_Type= pack_type;
		
		
	}
	
	public String getPromptFilePath() {
		return promptFilePath;
	}
	public void setPromptFilePath(String promptFilePath) {
		this.promptFilePath = promptFilePath;
	}
	public String getTransaction_Id() {
		return transaction_Id;
	}
	public void setTransaction_Id(String transaction_Id) {
		this.transaction_Id = transaction_Id;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public int getPack_Id() {
		return pack_Id;
	}
	public void setPack_Id(int pack_Id) {
		this.pack_Id = pack_Id;
	}
	public String getPack_Name() {
		return pack_Name;
	}
	public void setPack_Name(String pack_Name) {
		this.pack_Name = pack_Name;
	}
	public int getLang_Id() {
		return lang_Id;
	}
	public void setLang_Id(int lang_Id) {
		this.lang_Id = lang_Id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getExpiry_Date() {
		return expiry_Date;
	}
	public void setExpiry_Date(String expiry_Date) {
		this.expiry_Date = expiry_Date;
	}
	public int getValidity_Days() {
		return validity_Days;
	}
	public void setValidity_Days(int validity_Days) {
		this.validity_Days = validity_Days;
	}
	public String getOthers() {
		return others;
	}
	public void setOthers(String others) {
		this.others = others;
	}
	public String getValidity_type() {
		return validity_type;
	}
	public void setValidity_type(String validity_type) {
		this.validity_type = validity_type;
	}
	@Override
	public String toString() {
		return "UserPackPurchaseBean [transaction_Id=" + transaction_Id
				+ ", msisdn=" + msisdn + ", pack_Id=" + pack_Id
				+ ", pack_Name=" + pack_Name + ", lang_Id=" + lang_Id
				+ ", description=" + description + ", expiry_Date="
				+ expiry_Date + ", validity_Days=" + validity_Days
				+ ", validity_type=" + validity_type + ", others=" + others
				+ ", promptFilePath="+promptFilePath + "]";
	}
	public int getPack_Type() {
		return pack_Type;
	}
	public void setPack_Type(int pack_Type) {
		this.pack_Type = pack_Type;
	}
	
	
}
