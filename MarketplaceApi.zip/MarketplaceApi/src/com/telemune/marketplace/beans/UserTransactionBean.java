package com.telemune.marketplace.beans;

/**
 * This bean is used to hold the value for user's transaction.
 * 
 * @author Siddharth Singh Rawat
 *
 */
public class UserTransactionBean {

	private String transaction_Id;
	private String msisdn;
	private String fmsisdn;
	private int pack_Id;
	private String pack_Name;
	private int lang_Id;
	private String create_date;
	private String expiry_Date;
	private int validity_Days;
	private String validity_type;
	private int volume;
	private String transaction_Type;
	private String transaction_Message;
	private String others;
	private String promptFilePath="";
	/**
	 * Used to hold the value of user's shortCode
	 */
	private String shortCode = null;
	
	/**
	 * Used to hold the value of user's selected language
	 */
	private byte languageId = -1;
	
	/**
	 * Used to hold the value of user interface
	 * I - IVR
	 * U - USSD
	 */
	private String userInterface = null;
	
	public UserTransactionBean (String transaction_Id,String msisdn,String fmsisdn,int pack_Id,String pack_Name,int lang_Id,
			String expiry_Date,int validity_Days,String validity_type,int volume,String transaction_Type,String transaction_Message,String shortCode,byte languageId,String userInterface,String others){
		super();
		this.transaction_Id= transaction_Id;
		this.msisdn=msisdn;
		this.fmsisdn=fmsisdn;
		this.pack_Id=pack_Id;
		this.pack_Name=pack_Name;
		this.lang_Id=lang_Id;
		this.expiry_Date=expiry_Date;
		this.validity_Days=validity_Days;
		this.validity_type=validity_type;
		this.volume=volume;
		this.transaction_Type=transaction_Type;
		this.transaction_Message=transaction_Message;
		this.shortCode = shortCode;
		this.languageId = languageId;
		this.userInterface = userInterface;
		this.others= others;
		
	}
	
	/**
	 * @return the shortCode
	 */
	public String getShortCode() {
		return shortCode;
	}

	/**
	 * @param shortCode the shortCode to set
	 */
	public void setShortCode(String shortCode) {
		this.shortCode = shortCode;
	}

	

	/**
	 * @return the languageId
	 */
	public byte getLanguageId() {
		return languageId;
	}

	/**
	 * @param languageId the languageId to set
	 */
	public void setLanguageId(byte languageId) {
		this.languageId = languageId;
	}

	/**
	 * @return the userInterface
	 */
	public String getUserInterface() {
		return userInterface;
	}

	/**
	 * @param userInterface the userInterface to set
	 */
	public void setUserInterface(String userInterface) {
		this.userInterface = userInterface;
	}

	public String getPromptFilePath() {
		return promptFilePath;
	}
	public void setPromptFilePath(String promptFilePath) {
		this.promptFilePath = promptFilePath;
	}
	public UserTransactionBean(){
		
	}
	public String getTransaction_Id() {
		return transaction_Id;
	}
	public void setTransaction_Id(String transaction_Id) {
		this.transaction_Id = transaction_Id;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getFmsisdn() {
		return fmsisdn;
	}
	public void setFmsisdn(String fmsisdn) {
		this.fmsisdn = fmsisdn;
	}
	public int getPack_Id() {
		return pack_Id;
	}
	public void setPack_Id(int pack_Id) {
		this.pack_Id = pack_Id;
	}
	public String getPack_Name() {
		return pack_Name;
	}
	public void setPack_Name(String pack_Name) {
		this.pack_Name = pack_Name;
	}
	public int getLang_Id() {
		return lang_Id;
	}
	public void setLang_Id(int lang_Id) {
		this.lang_Id = lang_Id;
	}
	public String getExpiry_Date() {
		return expiry_Date;
	}
	public void setExpiry_Date(String expiry_Date) {
		this.expiry_Date = expiry_Date;
	}
	public int getValidity_Days() {
		return validity_Days;
	}
	public void setValidity_Days(int validity_Days) {
		this.validity_Days = validity_Days;
	}
	public int getVolume() {
		return volume;
	}
	public void setVolume(int volume) {
		this.volume = volume;
	}
	public String getTransaction_Type() {
		return transaction_Type;
	}
	public void setTransaction_Type(String transaction_Type) {
		this.transaction_Type = transaction_Type;
	}
	public String getTransaction_Message() {
		return transaction_Message;
	}
	public void setTransaction_Message(String transaction_Message) {
		this.transaction_Message = transaction_Message;
	}
	public String getOthers() {
		return others;
	}
	public void setOthers(String others) {
		this.others = others;
	}
	

	public String getValidity_type() {
		return validity_type;
	}

	public void setValidity_type(String validity_type) {
		this.validity_type = validity_type;
	}

	public String getCreate_date() {
		return create_date;
	}
	public void setCreate_date(String create_date) {
		this.create_date = create_date;
	}

	
	@Override
	public String toString() {
		return "UserTransactionBean [transaction_Id=" + transaction_Id + ", msisdn=" + msisdn + ", fmsisdn=" + fmsisdn
				+ ", pack_Id=" + pack_Id + ", pack_Name=" + pack_Name + ", lang_Id=" + lang_Id + ", create_date="
				+ create_date + ", expiry_Date=" + expiry_Date + ", validity_Days=" + validity_Days + ", validity_type="
				+ validity_type + ", volume=" + volume + ", transaction_Type=" + transaction_Type
				+ ", transaction_Message=" + transaction_Message + ", others=" + others + ", promptFilePath="
				+ promptFilePath + ", shortCode=" + shortCode + ", languageId=" + languageId + ", userInterface="
				+ userInterface + "]";
	}
	
}
