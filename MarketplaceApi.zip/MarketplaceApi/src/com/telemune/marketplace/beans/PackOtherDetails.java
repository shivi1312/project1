package com.telemune.marketplace.beans;

/**
 * This bean is used to hold the additional details of System Pack
 * 
 * @author Siddharth Singh Rawat
 *
 */
public class PackOtherDetails {

	/**
	 * Used to hold the pack action type of pack
	 */
	private int packActionType = -1;
	
	/**
	 * Used to hold packActionResponse
	 */
	private String packActionResp = "NA";
	
	/**
	 * Used to hold destination number in case of SMS
	 */
	private String destNumb = "NA";
	
	/**
	 * Used to hold the prompt in case of IVR
	 */
	private String vasPrompt = "NA";

	
	
	/**
	 * @return the packActionResp
	 */
	public String getPackActionResp() {
		return packActionResp;
	}

	/**
	 * @param packActionResp the packActionResp to set
	 */
	public void setPackActionResp(String packActionResp) {
		this.packActionResp = packActionResp;
	}

	/**
	 * @return the destNumb
	 */
	public String getDestNumb() {
		return destNumb;
	}

	/**
	 * @param destNumb the destNumb to set
	 */
	public void setDestNumb(String destNumb) {
		this.destNumb = destNumb;
	}

	/**
	 * @return the packActionType
	 */
	public int getPackActionType() {
		return packActionType;
	}

	/**
	 * @param packActionType
	 *            the packActionType to set
	 */
	public void setPackActionType(int packActionType) {
		this.packActionType = packActionType;
	}

	/**
	 * @return the vasPrompt
	 */
	public String getVasPrompt() {
		return vasPrompt;
	}

	/**
	 * @param vasPrompt the vasPrompt to set
	 */
	public void setVasPrompt(String vasPrompt) {
		this.vasPrompt = vasPrompt;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PackOtherDetails [packActionType=" + packActionType + ", packActionResp=" + packActionResp
				+ ", destNumb=" + destNumb + ", vasPrompt=" + vasPrompt + "]";
	}

}
