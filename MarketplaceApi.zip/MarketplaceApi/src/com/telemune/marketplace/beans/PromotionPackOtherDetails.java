package com.telemune.marketplace.beans;

/**
 * This class is used to hold the other details related to Promotional Packs.
 * 
 * @author SIDDHARTH SINGH RAWAT
 *
 */
public class PromotionPackOtherDetails {

	/**
	 * Used to hold the product code of this promotional pack
	 */
	private String productCode = "";

	/**
	 * Used to hold the name of promotional pack
	 */
	private String packName = "";

	/**
	 * Used to hold the description of promotional pack
	 */
	private String packDescription = "";

	/**
	 * Used to hold the priority of promotional pack
	 */
	private int priority = 1;

	/**
	 * Used to hold the minimum amount required to to view this promotional pack
	 */
	private int amountRequired = -1;

	/**
	 * Used to hold the applicable service charge for current promotional pack
	 */
	private double serviceCharge = -1d;

	/**
	 * Used to hold volume to be availed/deducted for this pack
	 */
	private int volume = 0;

	/**
	 * Used to hold volume type means volume availed is of what type KB - KiloBytes
	 * MB - MegaBytes GB - GegaBytes CF - CFA
	 */
	private String volumeType = null;

	/**
	 * Used to hold validity of this pack means for how much period of time this
	 * pack will be active in user's account
	 */
	private int validity = -1;

	/**
	 * Used to hold validity type means validity was in MO - Months DY - Days HR -
	 * Hours MI - Minutes SC - Seconds
	 */
	private String validityType = null;

	/**
	 * promptFilePath is used to hold the prompt file name for this promotional pack
	 */
	private String promptFile = "NA";

	/**
	 * Used to hold the value of action type
	 */
	private int actionType = 20;

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode
	 *            the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the packName
	 */
	public String getPackName() {
		return packName;
	}

	/**
	 * @param packName
	 *            the packName to set
	 */
	public void setPackName(String packName) {
		this.packName = packName;
	}

	/**
	 * @return the packDescription
	 */
	public String getPackDescription() {
		return packDescription;
	}

	/**
	 * @param packDescription
	 *            the packDescription to set
	 */
	public void setPackDescription(String packDescription) {
		this.packDescription = packDescription;
	}

	/**
	 * @return the priority
	 */
	public int getPriority() {
		return priority;
	}

	/**
	 * @param priority
	 *            the priority to set
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}

	/**
	 * @return the amountRequired
	 */
	public int getAmountRequired() {
		return amountRequired;
	}

	/**
	 * @param amountRequired
	 *            the amountRequired to set
	 */
	public void setAmountRequired(int amountRequired) {
		this.amountRequired = amountRequired;
	}

	/**
	 * @return the serviceCharge
	 */
	public double getServiceCharge() {
		return serviceCharge;
	}

	/**
	 * @param serviceCharge
	 *            the serviceCharge to set
	 */
	public void setServiceCharge(double serviceCharge) {
		this.serviceCharge = serviceCharge;
	}

	/**
	 * @return the volume
	 */
	public int getVolume() {
		return volume;
	}

	/**
	 * @param volume
	 *            the volume to set
	 */
	public void setVolume(int volume) {
		this.volume = volume;
	}

	/**
	 * @return the volumeType
	 */
	public String getVolumeType() {
		return volumeType;
	}

	/**
	 * @param volumeType
	 *            the volumeType to set
	 */
	public void setVolumeType(String volumeType) {
		this.volumeType = volumeType;
	}

	/**
	 * @return the validity
	 */
	public int getValidity() {
		return validity;
	}

	/**
	 * @param validity
	 *            the validity to set
	 */
	public void setValidity(int validity) {
		this.validity = validity;
	}

	/**
	 * @return the validityType
	 */
	public String getValidityType() {
		return validityType;
	}

	/**
	 * @param validityType
	 *            the validityType to set
	 */
	public void setValidityType(String validityType) {
		this.validityType = validityType;
	}

	/**
	 * @return the promptFile
	 */
	public String getPromptFile() {
		return promptFile;
	}

	/**
	 * @param promptFile
	 *            the promptFile to set
	 */
	public void setPromptFile(String promptFile) {
		this.promptFile = promptFile;
	}

	/**
	 * @return the actionType
	 */
	public int getActionType() {
		return actionType;
	}

	/**
	 * @param actionType
	 *            the actionType to set
	 */
	public void setActionType(int actionType) {
		this.actionType = actionType;
	}

	@Override
	public String toString() {
		return "PromotionPackOtherDetails [productCode=" + productCode + ", packName=" + packName + ", packDescription="
				+ packDescription + ", priority=" + priority + ", amountRequired=" + amountRequired + ", serviceCharge="
				+ serviceCharge + ", volume=" + volume + ", volumeType=" + volumeType + ", validity=" + validity
				+ ", validityType=" + validityType + ", promptFile=" + promptFile + ", actionType=" + actionType + "]";
	}

}
