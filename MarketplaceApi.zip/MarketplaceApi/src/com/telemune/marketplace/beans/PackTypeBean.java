package com.telemune.marketplace.beans;

/**
 * This is a bean class used to hold the information of PackType (Category)
 * 
 * @author SIDDHARTH
 *
 */
public class PackTypeBean {

	/**
	 * Used to hold the PackType (unique id)
	 */
	private int packType = -1;

	/**
	 * Used to hold the description of PackType
	 */
	private String description;

	/**
	 * Used to hold the status of the selected PackType
	 */
	private String status = "";

	/**
	 * Used to hold the name of selected PackType
	 */
	private String packTypeName;

	/**
	 * Used to hold the PackType id of immediate parent PackType
	 */
	private int parentPackType;

	/**
	 * Used to hold the value which indicates that the selected packs of the
	 * PackType can be used as a parallel packs or not.
	 */
	private int parallelPackEnable = -1;
	
	/**
	 * Used to hold the prompt file name for the selected PackType.
	 */
	private String packTypePromptFile = "";
	
	/**
	 * Used to hold the value of the selected language.
	 */
	private int languageId = -1;
	
	/**
	 * Used to hold the priority of current selected PackType 
	 */
	private int priority = 1;
	
	/**
	 * Used to hold the Base Pack Type value of the PackType. Used to distinguish the flow of PackType. 
	 */
	private String basePackType = "NA";

	public int getPackType() {
		return packType;
	}

	public void setPackType(int packType) {
		this.packType = packType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPackTypeName() {
		return packTypeName;
	}

	public void setPackTypeName(String packTypeName) {
		this.packTypeName = packTypeName;
	}

	public int getParentPackType() {
		return parentPackType;
	}

	public void setParentPackType(int parentPackType) {
		this.parentPackType = parentPackType;
	}

	public int getParallelPackEnable() {
		return parallelPackEnable;
	}

	public void setParallelPackEnable(int parallelPackEnable) {
		this.parallelPackEnable = parallelPackEnable;
	}

	public String getPackTypePromptFile() {
		return packTypePromptFile;
	}

	public void setPackTypePromptFile(String packTypePromptFile) {
		this.packTypePromptFile = packTypePromptFile;
	}

	public int getLanguageId() {
		return languageId;
	}

	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getBasePackType() {
		return basePackType;
	}

	public void setBasePackType(String basePackType) {
		this.basePackType = basePackType;
	}

	@Override
	public String toString() {
		return "PackTypeBean [packType=" + packType + ", description=" + description + ", status=" + status
				+ ", packTypeName=" + packTypeName + ", parentPackType=" + parentPackType + ", parallelPackEnable="
				+ parallelPackEnable + ", packTypePromptFile=" + packTypePromptFile + ", languageId=" + languageId
				+ ", priority=" + priority + ", basePackType=" + basePackType + "]";
	}
}
