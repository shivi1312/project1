/**
 * @author MoHit
 * Created on - 21 Feb, 2017
 */
package com.telemune.marketplace.beans;

/**
 * Used to hold the volume transfer validity details
 * (used for talk-time transfer)
 * @author MoHit
 */
public class TransferValidity {

	/**
	 * Used to hold start range of this validity
	 */
	private int 	minVolume		= -1;
	
	/**
	 * Used to hold end range of this validity
	 */
	private int		maxVolume		= -1;
	
	/**
	 * Used to hold how many days validity is to provide
	 * to the B party user to use the volume transfered by A party
	 * if that volume lies within this range
	 */
	private short	validityDays	= -1;
	
	/**
	 * @return {@link #minVolume}
	 */
	public int getMinVolume() {
		return minVolume;
	}
	
	/**
	 * @param minVolume
	 */
	public void setMinVolume(int minVolume) {
		this.minVolume = minVolume;
	}
	
	/**
	 * @return {@link #maxVolume}
	 */
	public int getMaxVolume() {
		return maxVolume;
	}
	
	/**
	 * @param maxVolume
	 */
	public void setMaxVolume(int maxVolume) {
		this.maxVolume = maxVolume;
	}
	
	/**
	 * @return {@link #validityDays}
	 */
	public short getValidityDays() {
		return validityDays;
	}
	
	/**
	 * @param validityDays
	 */
	public void setValidityDays(short validityDays) {
		this.validityDays = validityDays;
	}
	
	/**
	 * Used to initialize all the parameters
	 * @param minVolume
	 * @param maxVolume
	 * @param validityDays
	 */
	public TransferValidity(int minVolume, int maxVolume, short validityDays) {
		super();
		this.minVolume = minVolume;
		this.maxVolume = maxVolume;
		this.validityDays = validityDays;
	}
	
	@Override
	/**
	 * This is an overridden method and is used to return the value of
	 * all the parameters of this class so that while printing the value of
	 * the object of this class it prints the values of the parameters
	 * @return all the variables and theirs values of the object of this class
	 */
	public String toString() {
		return "TransferValidity [minVolume=" + minVolume + ", maxVolume="
				+ maxVolume + ", validityDays=" + validityDays + "]";
	}
	
	
}
