/**
 * @author MoHit
 * Created on - 21 Feb, 2017
 */
package com.telemune.marketplace.beans;

/**
 * Used to hold the service charge and volume and 
 * validity related details of a pack
 * @author MoHit
 */
public class ServiceCharge {

	/**
	 * Used to hold service charge of this pack
	 */
	private double	serviceCharge	= -1;
	
	/**
	 * Used to hold product code of this pack
	 */
	private String	productCode		= null;
	
	/**
	 * Used to hold volume to be availed/deducted for this pack
	 */
	private int		volume			= 0;
	
	/**
	 * Used to hold volume type means volume availed is of what type
	 * KB - KiloBytes
	 * MB - MegaBytes
	 * GB - GegaBytes
	 * CF - CFA
	 */
	private String volumeType		= null;
	
	/**
	 * Used to hold validity of this pack means for how much
	 * period of time this pack will be active in user's account
	 */
	private int		validity	= -1;
	
	/**
	 * Used to hold validity type means validity was in
	 * MO - Months
	 * DY - Days
	 * HR - Hours
	 * MI - Minutes
	 * SC - Seconds
	 */
	private String validityType		= null;
	
	/**
	 * @return {@link #productCode}
	 */
	public String getProductCode() {
		return productCode;
	}
	/**
	 * @param productCode
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	/**
	 * @return {@link #serviceCharge}
	 */
	public double getServiceCharge() {
		return serviceCharge;
	}
	/**
	 * @param serviceCharge
	 */
	public void setServiceCharge(double serviceCharge) {
		this.serviceCharge = serviceCharge;
	}
	/**
	 * @return {@link #volume}
	 */
	public int getVolume() {
		return volume;
	}
	/**
	 * @param volume
	 */
	public void setVolume(int volume) {
		this.volume = volume;
	}
	/**
	 * @return {@link #validity}
	 */
	public int getValidity() {
		return validity;
	}
	/**
	 * @param validity
	 */
	public void setValidityDays(int validity) {
		this.validity = validity;
	}
	/**
	 * @return {@link #volumeType}
	 */
	public String getVolumeType() {
		return volumeType;
	}
	/**
	 * @param volumeType
	 */
	public void setVolumeType(String volumeType) {
		this.volumeType = volumeType;
	}
	/**
	 * @return {@link #validityType}
	 */
	public String getValidityType() {
		return validityType;
	}
	/**
	 * @param validityType
	 */
	public void setValidityType(String validityType) {
		this.validityType = validityType;
	}
	/**
	 * Used to initialize all the parameters
	 * @param serviceCharge
	 * @param productCode
	 * @param volume
	 * @param validity
	 */
	public ServiceCharge(double serviceCharge, String productCode, int volume, String volumeType,
			int validity, String validityType) {
		super();
		this.serviceCharge = serviceCharge;
		this.productCode = productCode;
		this.volume = volume;
		this.volumeType = volumeType;
		this.validity = validity;
		this.validityType = validityType;
	}
	
	@Override
	/**
	 * This is an overridden method and is used to return the value of
	 * all the parameters of this class so that while printing the value of
	 * the object of this class it prints the values of the parameters
	 * @return all the variables and theirs values of the object of this class
	 */
	public String toString() {
		return "ServiceCharge [serviceCharge=" + serviceCharge
				+ ", productCode=" + productCode + ", volume=" + volume
				+ ", volumeType=" + volumeType + ", validity="
				+ validity + ", validityType=" + validityType + "]";
	}
	
}
