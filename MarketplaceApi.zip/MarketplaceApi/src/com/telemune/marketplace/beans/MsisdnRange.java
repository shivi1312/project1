/**
 * @author MoHit
 * Created on - 10 Feb, 2017
 */
package com.telemune.marketplace.beans;

/**
 * This is the bean class used to hold the range of MSISDNs allowed for a country code
 * @author MoHit
 */
public class MsisdnRange {
	
	/**
	 * This parameter is used to hold the start value of range
	 */
	private String startsFrom = null;
	
	/**
	 * This parameter is used to hold the start value of range
	 */
	private String endsAt = null;
	
	/**
	 * This parameter is used to hold the country code corresponding to a range defined
	 */
	private String countryCode = null;
	
	
	/**
	 * Used to return the value of start value of range from the object of this class
	 * @return {@link #startsFrom}
	 */
	public String getStartsFrom() {
		return startsFrom;
	}
	
	/**
	 * Used to set the value of start value of range in the object of this class
	 * @param startsFrom
	 */
	public void setStartsFrom(String startsFrom) {
		this.startsFrom = startsFrom;
	}
	
	/**
	 * Used to return the value of end value of range from the object of this class
	 * @return {@link #endsAt}
	 */
	public String getEndsAt() {
		return endsAt;
	}
	
	/**
	 * Used to set the value of end value of range in the object of this class
	 * @param endsAt
	 */
	public void setEndsAt(String endsAt) {
		this.endsAt = endsAt;
	}
	
	/**
	 * Used to return the value of country code corresponding to a range defined
	 * @return {@link #countryCode}
	 */
	public String getCountryCode() {
		return countryCode;
	}
	
	/**
	 * Used to set the value of country code corresponding to a range defined
	 * @param countryCode
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	
	/**
	 * Used to initialized all the parameters
	 * @param startsFrom
	 * @param endsAt
	 * @param countryCode
	 */
	public MsisdnRange(String startsFrom, String endsAt, String countryCode) {
		super();
		this.startsFrom = startsFrom;
		this.endsAt = endsAt;
		this.countryCode = countryCode;
	}
	
	/**
	 * This is an overridden method and is used to return the value of
	 * all the parameters of this class so that while printing the value of
	 * the object of this class it prints the values of the parameters
	 * @return all the variables and theirs values of the object of this class
	 */
	@Override
	public String toString() {
		return "MsisdnRange [startsFrom=" + startsFrom + ", endsAt=" + endsAt
				+ ", countryCode=" + countryCode + ", getStartsFrom()="
				+ getStartsFrom() + ", getEndsAt()=" + getEndsAt()
				+ ", getCountryCode()=" + getCountryCode() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
}
