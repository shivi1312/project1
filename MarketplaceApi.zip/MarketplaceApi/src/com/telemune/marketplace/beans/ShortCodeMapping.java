package com.telemune.marketplace.beans;

public class ShortCodeMapping {
	
	
	
	
	public ShortCodeMapping(String serviceType, byte numOfParameter) {
		super();
		this.serviceType = serviceType;
		this.numOfParameter = numOfParameter;
	}

	/**
	 * Used to hold service type used for internal usage of code
	 */
	private String serviceType      = null;
	
	/**
	 * Used to hold the number of parameters should exist in short code. It depends on different service Types.
	 */
	private byte numOfParameter        = 0;

	
	

	/**
	 * @return {@link #serviceType}
	 */
	public String getServiceType() {
		return serviceType;
	}

	/**
	 * @param serviceType
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	/**
	 * @return {@link #numOfParameter}
	 */
	public byte getNumOfParameter() {
		return numOfParameter;
	}

	/**
	 * 
	 * @param numOfParameter
	 */
	public void setNumOfParameter(byte numOfParameter) {
		this.numOfParameter = numOfParameter;
	}

	@Override
	public String toString() {
		return "ShortCodeMapping [serviceType=" + serviceType 
				+ ", numOfParameter=" + numOfParameter + "]";
	}

	
	

	
	
	
	

}
