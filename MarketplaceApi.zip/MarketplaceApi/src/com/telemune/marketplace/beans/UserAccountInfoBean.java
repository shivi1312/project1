package com.telemune.marketplace.beans;

/**
 * This class is used to hold the account details of user's active data packs
 * used in Check Data Balance Service.
 * 
 * @author SIDDHARTH SINGH RAWAT
 */
public class UserAccountInfoBean implements Comparable<UserAccountInfoBean> {

	private String acctId = "";
	private String expiryTime = "";
	private String balance = "";
	private String accName = "";
	private String productName = "";
	private String packName = "";

	/**
	 * @return the balance
	 */
	public String getBalance() {
		return balance;
	}

	/**
	 * @param balance
	 *            the balance to set
	 */
	public void setBalance(String balance) {
		this.balance = balance;
	}

	/**
	 * @return the acctId
	 */
	public String getAcctId() {
		return acctId;
	}

	/**
	 * @param acctId
	 *            the acctId to set
	 */
	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}

	/**
	 * @return the expiryTime
	 */
	public String getExpiryTime() {
		return expiryTime;
	}

	/**
	 * @param expiryTime
	 *            the expiryTime to set
	 */
	public void setExpiryTime(String expiryTime) {
		this.expiryTime = expiryTime;
	}

	/**
	 * @return the accName
	 */
	public String getAccName() {
		return accName;
	}

	/**
	 * @param accName
	 *            the accName to set
	 */
	public void setAccName(String accName) {
		this.accName = accName;
	}

	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * @param productName
	 *            the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}

	@Override
	public int compareTo(UserAccountInfoBean o) {
		return -(this.acctId.compareTo(o.acctId));
	}

	/**
	 * @return the packName
	 */
	public String getPackName() {
		return packName;
	}

	/**
	 * @param packName
	 *            the packName to set
	 */
	public void setPackName(String packName) {
		this.packName = packName;
	}

	@Override
	public String toString() {
		return "UserAccountInfoBean [acctId=" + acctId + ", expiryTime=" + expiryTime + ", balance=" + balance
				+ ", accName=" + accName + ", productName=" + productName + ", packName=" + packName + "]";
	}

}
