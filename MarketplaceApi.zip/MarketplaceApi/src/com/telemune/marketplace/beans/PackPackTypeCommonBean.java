package com.telemune.marketplace.beans;

/**
 * PackPackTypeCommonBean holds pack and packType data Used to show Pack and
 * PackType at the same level. Used to show dynamic Pack and Pack Type.
 * 
 * @author Siddharth Singh Rawat
 */
public class PackPackTypeCommonBean implements Comparable<PackPackTypeCommonBean> {

	/**
	 * Used to hold the pack id (unique in the case of packs and default in the case
	 * of pack type
	 */
	private int packId = -99;

	/**
	 * Used to hold the product code of pack (In the case of Packs only)
	 */
	private String productCode = "NA";

	/**
	 * Used to hold the name of packs and pack type
	 */
	private String packPackTypeName = "NA";

	/**
	 * Used to hold the pack type ID
	 */
	private int packType = -99;

	/**
	 * Used to hold the description in packs and pack type
	 */
	private String description = "NA";

	/**
	 * Used to hold the languageId of selected pack or pack type
	 */
	private int languageId = -1;

	/**
	 * Used to hold the priority of packs and pack type
	 */
	private int priority = 1;

	/**
	 * promptFilePath is used to hold the prompt file name of the particular pack or
	 * pack type
	 */
	private String pormptFilePath;

	/**
	 * Used to distinguish between pack and pack type
	 */
	private String type = "NA";

	/**
	 * Used to hold the value of parentPackType of packs and pack type
	 */
	private int parentPackType = -99;

	/**
	 * Used to hold the amount required to view this packs
	 */
	private double amountRequired = -1;

	/**
	 * Used to hold the value of current selected pack type
	 */
	private int currentPackType = -99;

	public int getPackId() {
		return packId;
	}

	public void setPackId(int packId) {
		this.packId = packId;
	}

	public String getPackPackTypeName() {
		return packPackTypeName;
	}

	public void setPackPackTypeName(String packPackTypeName) {
		this.packPackTypeName = packPackTypeName;
	}

	public int getPackType() {
		return packType;
	}

	public void setPackType(int packType) {
		this.packType = packType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getLanguageId() {
		return languageId;
	}

	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getPormptFilePath() {
		return pormptFilePath;
	}

	public void setPormptFilePath(String pormptFilePath) {
		this.pormptFilePath = pormptFilePath;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getParentPackType() {
		return parentPackType;
	}

	public void setParentPackType(int parentPackType) {
		this.parentPackType = parentPackType;
	}

	public double getAmountRequired() {
		return amountRequired;
	}

	public void setAmountRequired(double amountRequired) {
		this.amountRequired = amountRequired;
	}

	@Override
	public int compareTo(PackPackTypeCommonBean o) {
		int comparePriority = o.getPriority();
		return comparePriority - this.priority;
	}

	public int getCurrentPackType() {
		return currentPackType;
	}

	public void setCurrentPackType(int currentPackType) {
		this.currentPackType = currentPackType;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode
	 *            the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	
	@Override
	public String toString() {
		return "PackPackTypeCommonBean [packId=" + packId + ", productCode=" + productCode + ", packPackTypeName="
				+ packPackTypeName + ", packType=" + packType + ", description=" + description + ", languageId="
				+ languageId + ", priority=" + priority + ", pormptFilePath=" + pormptFilePath + ", type=" + type
				+ ", parentPackType=" + parentPackType + ", amountRequired=" + amountRequired + ", currentPackType="
				+ currentPackType + "]";
	}

}
