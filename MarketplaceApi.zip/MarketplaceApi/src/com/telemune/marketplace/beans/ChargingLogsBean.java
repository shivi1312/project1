/**
 * Created on - 21 Feb, 2017
 * @author MoHit
 */
package com.telemune.marketplace.beans;

/**
 * Used to hold the parameters that are to be inserted in charging logs tables
 * @author MoHit
 */
public class ChargingLogsBean {

	/**
	 * Used to hold mobile number of user
	 */
	private String	msisdn			= null;
	
	/**
	 * @return the shortCode
	 */
	public String getShortCode() {
		return shortCode;
	}
	/**
	 * @param shortCode the shortCode to set
	 */
	public void setShortCode(String shortCode) {
		this.shortCode = shortCode;
	}
	
	/**
	 * @return the languageId
	 */
	public byte getLanguageId() {
		return languageId;
	}
	/**
	 * @param languageId the languageId to set
	 */
	public void setLanguageId(byte languageId) {
		this.languageId = languageId;
	}
	/**
	 * @return the userInterface
	 */
	public String getUserInterface() {
		return userInterface;
	}
	/**
	 * @param userInterface the userInterface to set
	 */
	public void setUserInterface(String userInterface) {
		this.userInterface = userInterface;
	}

	/**
	 * Used to hold user's Friend's mobile number to which
	 * user has transfered or gifted any pack or service
	 */
	private String	fmsisdn			= null;
	
	/**
	 * Used to hold unique transaction ID generated to process
	 * this request with charging
	 */
	private String	transactionId	= null;
	
	/**
	 * Used to hold pack type id means which type of pack user has purchased
	 */
	private int		type			= -1;
	
	/**
	 * Used to hold unique product code of pack
	 */
	private String	productCode		= null;
	
	/**
	 * Used to hold service charge amount deducted from user's account for
	 * this service pack purchase
	 */
	private double	serviceCharge	= -1;
	
	/**
	 * Used to hold volume availed from/to user's account
	 * it may be currency or data (MB, GB etc) etc
	 */
	private int		volume			= -1;
	
	/**
	 * Used to hold validity period for which particular pack or service is
	 * availed to user
	 */
	private int		validityDays	= -1;
	
	/**
	 * Used to hold sub type of user means pre-paid(P), post-paid(O) etc
	 */
	private String	subType			= null;
	
	/**
	 * Used to hold response status of this transaction
	 * means 1 if success etc
	 */
	private int		responseStatus	= -1;
	
	/**
	 * Used to hold unique request id received from XML parser
	 * or any requesting interface
	 */
	private String	requestId		= null;
	
	/**
	 * Used to hold packId that is purchased by user
	 */
	private int packId				= -1;
	
	/**
	 * Used to hold volume type means volume availed is of what type
	 * KB - KiloBytes
	 * MB - MegaBytes
	 * GB - GegaBytes
	 * CF - CFA
	 */
	private String volumeType		= null;
	
	/**
	 * Used to hold validity type means validity was in
	 * MO - Months
	 * DY - Days
	 * HR - Hours
	 * MI - Minutes
	 * SC - Seconds
	 */
	private String validityType		= null;
	
	
	/**
	 * Used to hold the value of user shortCode
	 */
	private String shortCode = null;
	
	/**
	 * Used to hold the value of user selected language
	 */
	private byte languageId = -1;
	
	/**
	 * Used to hold the value of user interface
	 * I - IVR
	 * U - USSD
	 */
	private String userInterface = null;
	
	/**
	 * @return {@link #msisdn}
	 */
	public String getMsisdn() {
		return msisdn;
	}
	/**
	 * @param msisdn
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	/**
	 * @return {@link #fmsisdn}
	 */
	public String getFmsisdn() {
		return fmsisdn;
	}
	/**
	 * @param fmsisdn
	 */
	public void setFmsisdn(String fmsisdn) {
		this.fmsisdn = fmsisdn;
	}
	/**
	 * @return {@link #transactionId}
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return {@link #type}
	 */
	public int getType() {
		return type;
	}
	/**
	 * @param type
	 */
	public void setType(int type) {
		this.type = type;
	}
	/**
	 * @return {@link #productCode}
	 */
	public String getProductCode() {
		return productCode;
	}
	/**
	 * @param productCode
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	/**
	 * @return {@link #serviceCharge}
	 */
	public double getServiceCharge() {
		return serviceCharge;
	}
	/**
	 * @param serviceCharge
	 */
	public void setServiceCharge(double serviceCharge) {
		this.serviceCharge = serviceCharge;
	}
	/**
	 * @return {@link #volume}
	 */
	public int getVolume() {
		return volume;
	}
	/**
	 * @param volume
	 */
	public void setVolume(int volume) {
		this.volume = volume;
	}
	/**
	 * @return {@link #validityDays}
	 */
	public int getValidityDays() {
		return validityDays;
	}
	/**
	 * @param validityDays
	 */
	public void setValidityDays(int validityDays) {
		this.validityDays = validityDays;
	}
	/**
	 * @return {@link #subType}
	 */
	public String getSubType() {
		return subType;
	}
	/**
	 * @param subType
	 */
	public void setSubType(String subType) {
		this.subType = subType;
	}
	/**
	 * @return {@link #responseStatus}
	 */
	public int getResponseStatus() {
		return responseStatus;
	}
	/**
	 * @param responseStatus
	 */
	public void setResponseStatus(int responseStatus) {
		this.responseStatus = responseStatus;
	}
	/**
	 * @return {@link #requestId}
	 */
	public String getRequestId() {
		return requestId;
	}
	/**
	 * @param requestId
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	/**
	 * @return {@link #packId}
	 */
	public int getPackId() {
		return packId;
	}
	/**
	 * @param packId
	 */
	public void setPackId(int packId) {
		this.packId = packId;
	}
	/**
	 * @return {@link #volumeType}
	 */
	public String getVolumeType() {
		return volumeType;
	}
	/**
	 * @param volumeType
	 */
	public void setVolumeType(String volumeType) {
		this.volumeType = volumeType;
	}
	/**
	 * @return {@link #validityType}
	 */
	public String getValidityType() {
		return validityType;
	}
	/**
	 * @param validityType
	 */
	public void setValidityType(String validityType) {
		this.validityType = validityType;
	}
	/**
	 * Used to initialize all the parameters
	 * @param msisdn
	 * @param fmsisdn
	 * @param transactionId
	 * @param type
	 * @param productCode
	 * @param serviceCharge
	 * @param volume
	 * @param validityDays
	 * @param subType
	 * @param responseStatus
	 * @param requestId
	 * @param packId
	 * @param volumeType
	 * @param validityType
	 */
	public ChargingLogsBean(String msisdn, String fmsisdn, String transactionId,
			int type, String productCode, double serviceCharge, int volume,
			int validityDays, String subType, int responseStatus,
			String requestId, int packId, String volumeType, String validityType, String shortCode,byte languageId,String userInterface) {
		super();
		this.msisdn = msisdn;
		this.fmsisdn = fmsisdn;
		this.transactionId = transactionId;
		this.type = type;
		this.productCode = productCode;
		this.serviceCharge = serviceCharge;
		this.volume = volume;
		this.validityDays = validityDays;
		this.subType = subType;
		this.responseStatus = responseStatus;
		this.requestId = requestId;
		this.packId = packId;
		this.volumeType = volumeType;
		this.validityDays = validityDays;
		this.validityType = validityType;
		this.shortCode = shortCode;
		this.languageId = languageId;
		this.userInterface = userInterface;
	}
	
	
	
	@Override
	/**
	 * This is an overridden method and is used to return the value of
	 * all the parameters of this class so that while printing the value of
	 * the object of this class it prints the values of the parameters
	 * @return all the variables and theirs values of the object of this class
	 */
	public String toString() {
		return "ChargingLogsBean [msisdn=" + msisdn + ", fmsisdn=" + fmsisdn + ", transactionId=" + transactionId
				+ ", type=" + type + ", productCode=" + productCode + ", serviceCharge=" + serviceCharge + ", volume="
				+ volume + ", validityDays=" + validityDays + ", subType=" + subType + ", responseStatus="
				+ responseStatus + ", requestId=" + requestId + ", packId=" + packId + ", volumeType=" + volumeType
				+ ", validityType=" + validityType + ", shortCode=" + shortCode + ", languageId=" + languageId
				+ ", userInterface=" + userInterface + "]";
	}

}
