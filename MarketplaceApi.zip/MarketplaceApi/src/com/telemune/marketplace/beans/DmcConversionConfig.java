package com.telemune.marketplace.beans;

import java.util.HashMap;
import java.util.Map;

/**
 * This class is used to hold the configuration related details in Data Macro
 * Credit Service.
 * 
 * @author Siddharth Singh Rawat
 *
 */
public class DmcConversionConfig {

	/**
	 * Used to hold the minimum volume range
	 */
	private int minRange;

	/**
	 * Used to hold the maximum volume range
	 */
	private int maxRange;

	/**
	 * Used to hold the price per MB for different configurable days
	 */
	private Map<Integer, Double> priceConfigMap = new HashMap<>();

	/**
	 * @return the priceConfigMap
	 */
	public Map<Integer, Double> getPriceConfigMap() {
		return priceConfigMap;
	}

	/**
	 * @param priceConfigMap
	 *            the priceConfigMap to set
	 */
	public void setPriceConfigMap(Map<Integer, Double> priceConfigMap) {
		this.priceConfigMap = priceConfigMap;
	}

	/**
	 * @return the minRange
	 */
	public int getMinRange() {
		return minRange;
	}

	/**
	 * @param minRange
	 *            the minRange to set
	 */
	public void setMinRange(int minRange) {
		this.minRange = minRange;
	}

	/**
	 * @return the maxRange
	 */
	public int getMaxRange() {
		return maxRange;
	}

	/**
	 * @param maxRange
	 *            the maxRange to set
	 */
	public void setMaxRange(int maxRange) {
		this.maxRange = maxRange;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DmcMultiConfigBean [minRange=" + minRange + ", maxRange=" + maxRange + ", priceConfigMap="
				+ priceConfigMap + "]";
	}

}
