package com.telemune.marketplace.beans;

public class VirtualCodeMapping {
	
	
	
	public VirtualCodeMapping(int packId, int packTypeId, int superPackType) {
		super();
		this.packId = packId;
		this.packTypeId = packTypeId;
		this.superPackType = superPackType;
	}

	/**
	 * Used to hold the unique ID of this pack
	 */
	private int packId=-99;
	
	/**
	 * Used to hold the pack type id of this pack
	 * means ID of the type of this pack
	 */
	private int packTypeId=-99;
	
	/**
	 * Used to hold the parent pack type Id of packs.
	 * means either pack is for data transfer or bonus transfer or pack purchase.
	 */
	private int superPackType = -99;

	
	/**
	 * @return {@link #superPackType}
	 */
	public int getSuperPackType() {
		return superPackType;
	}

	/**
	 * @param superPackType
	 */
	public void setSuperPackType(int superPackType) {
		this.superPackType = superPackType;
	}

	/**
	 * @return {@link #packId}
	 */
	public int getPackId() {
		return packId;
	}

	/**
	 * @param packId
	 */
	public void setPackId(int packId) {
		this.packId = packId;
	}

	/**
	 * @return {@link #packTypeId}
	 */
	public int getPackTypeId() {
		return packTypeId;
	}

	/**
	 * @param packTypeId
	 */
	public void setPackTypeId(int packTypeId) {
		this.packTypeId = packTypeId;
	}

	@Override
	public String toString() {
		return "VirtualCodeMapping [packId=" + packId + ", "
				+ "packTypeId=" + packTypeId + ", superPackType="
				+ superPackType + "]";
	}

	
	
}
