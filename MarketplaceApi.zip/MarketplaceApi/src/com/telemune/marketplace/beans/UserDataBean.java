/**
 * @author MoHit modified by SIDDHARTH
 * Created on - 10 Feb, 2017
 */
package com.telemune.marketplace.beans;

import java.util.ArrayList;

/**
 * This is a bean class and is used to hold the data that is received in request
 * 
 * @author SIDDHARTH
 */
/**
 * @author Mittal
 *
 */
public class UserDataBean {
	/**
	 * Used to hold MSISDN of the user who is requesting
	 */
	private String msisdn = null;

	/**
	 * Used to hold all the pack Id's browsed by user
	 */
	private String packBrowseList = "";

	/**
	 * Used to hold the unique request id send by XML Parser or any other requesting
	 * interface for this request
	 */
	private String requestId = null;

	/**
	 * Used to hold the digits pressed by user
	 */
	private String digits = null;

	/**
	 * Used to hold the value of index mean user is request for next(N) page of
	 * packs or previous(P) or same(S)
	 */
	private String index = "N";

	/**
	 * Used to hold the short code that is dialed by user to access this service
	 */
	private String shortCode = "NA";

	/**
	 * Used to hold the interface used by the user to request
	 */
	private String interfaceUsed = null;

	/**
	 * Used to hold the subscriber type of user means pre-paid, post-paid etc
	 */
	private String subType = "N";

	/**
	 * Used to hold the FMSISDN that is entered by user to gift or transfer
	 * something to the friend
	 */
	private String fmsisdn = "NA";

	/**
	 * Used to hold the list of packs shown to user in current response
	 */
	private String packList = "";

	/**
	 * Used to hold the language ID selected by the user to see response in
	 */
	private byte langId = -1;

	/**
	 * Used to hold the ID of pack type means of which type of packs user wants to
	 * browse
	 */
	private int packTypeId = -1;

	/**
	 * Used to hold the user's account balance
	 */
	private double balance = -1;

	/**
	 * Used to hold the response given to requesting interface 1- success, -1 Error,
	 * -2 Insufficient Balance
	 */
	private byte result = -1;

	/**
	 * Used to hold the Message which will shown to user
	 */
	private String filePath = null;

	/**
	 * Used to hold the details i.e. which pack was purchase and what was the result
	 * of purchasing its combination is like PACKID;RESULT example 2104;1
	 */
	private String packPurchaseDetail = "NA";

	/**
	 * Used to hold the details i.e. which pack was purchase and what was the result
	 * of purchasing
	 */
	private int packId = -1;

	/**
	 * Used to hold the net type means request is for on net or off net talktime
	 * transfer
	 */
	private String netType = null;

	/**
	 * Used to hold the volume entered by user to transfer
	 */
	private int volume = 0;

	/**
	 * Used to hold service type used for internal usage of code
	 */
	private String serviceType = null;

	private int virtualCode = 0;
	private String pageId = "1";

	private String pageContent = "0";

	private String prevIndex = "-1";
	private String nextIndex = "1";

	private String more = "N";

	/**
	 * Used to hold the number of menus showing to user.
	 */
	private byte totalMenuShown = 0;

	/**
	 * Used to distinguish Pack Type (Category) or Pack
	 */
	private String isPackType = "N";

	/**
	 * Used to hold the value of base Pack Type (Dynamic Get Packs)
	 */
	private String basePackType = "NA";

	/**
	 * Used to hold the list of current pack type
	 */
	private String currentPackTypeList = "";

	/**
	 * Used for Low Balance Packs
	 */
	private String isLowBalancePack = "N";

	/**
	 * Used to hold the call start time
	 */
	private String callStartTime = "";

	/**
	 * Used to hold the callDuration
	 */
	private int callDuration = 0;

	/**
	 * Used to hold the call hang up time
	 */
	private String callHangUpTime = "";

	/**
	 * Used to hold the accessed packs records.
	 */
	private ArrayList<AccessedPackRecordBean> accessedPacksRecordList = new ArrayList<>();

	/**
	 * Used to hold last accessed pack time
	 */
	private String lastPackAccessedTime = "";

	/**
	 * Used to hold the amount that we want to convert
	 */
	private int balToConvert = 0;

	/**
	 * Used to hold the value of Pack Action Type
	 */
	private int packActionType = -1;

	/**
	 * Used to hold the details of service.
	 */
	private String serviceDetail = "";

	/**
	 * Used to hold the active account Id's of user
	 */
	private String activeAccIdList = "NA";

	/**
	 * Used to hold the amount of volume that we want to convert
	 */
	private int volToConvert = 0;

	/**
	 * Used to hold the amount or volume that we want to convert.
	 */
	private int dataToConvert = 0;

	/**
	 * Used to hold the product code of pack
	 */
	private String productCode = "NA";

	/**
	 *  Used to get userPoints from operator end
	 */
	private long userPoints=-1L;
	/**
	 * to get User Points
	 * @return long
	 */
	private String userPointsInfo="";
	
	/**
	 * @author Sanchit Atri
	 * to get User refer code
	 * 
	 */
	private String referCode="";
	
	/**
	 * @author Sanchit Atri
	 * to get User refer validity
	 * 
	 */
	private int referValidity=0;
	
	
	
	/**
	 * @author Sanchit Atri
	 * to get User refer validity
	 * @return referValidity
	 */
	
	public int getReferValidity() {
		return referValidity;
	}
	public void setReferValidity(int referValidity) {
		this.referValidity = referValidity;
	}
	
	/**
	 * @author Sanchit Atri
	 * to get User refer code
	 * @return referCode
	 */
	public String getReferCode() {
		return referCode;
	}
	public void setReferCode(String referCode) {
		this.referCode = referCode;
	}
	public String getUserPointsInfo() {
		return userPointsInfo;
	}
	public void setUserPointsInfo(String userPointsInfo) {
		this.userPointsInfo = userPointsInfo;
	}
	public long getUserPoints() {
		return userPoints;
	}
	/**
	 * to set user Points
	 * @param userPoints as Long
	 */

	public void setUserPoints(long userPoints) {
		this.userPoints = userPoints;
	}

	/**
	 * @return the accessedPacksRecords
	 */
	public ArrayList<AccessedPackRecordBean> getAccessedPacksRecords() {
		return accessedPacksRecordList;
	}

	/**
	 * @param accessedPacksRecords
	 *            the accessedPacksRecords to set
	 */
	public void addAccessedPacksRecords(AccessedPackRecordBean accessedPacksRecordBean) {
		this.accessedPacksRecordList.add(accessedPacksRecordBean);
	}

	public void addAllAccessedPacksRecords(ArrayList<AccessedPackRecordBean> accessedPacksRecordBeanList) {
		this.accessedPacksRecordList.clear();
		this.accessedPacksRecordList.addAll(accessedPacksRecordBeanList);
	}

	public byte getTotalMenuShown() {
		return totalMenuShown;
	}

	public void setTotalMenuShown(byte totalMenuShown) {
		this.totalMenuShown = totalMenuShown;
	}

	public String getMore() {
		return more;
	}

	public void setMore(String more) {
		this.more = more;
	}

	public String getPageId() {
		return pageId;
	}

	public void setPageId(String pageId) {
		this.pageId = pageId;
	}

	public String getPageContent() {
		return pageContent;
	}

	public void setPageContent(String pageContent) {
		this.pageContent = pageContent;
	}

	/**
	 * 
	 * @return {@link #virtualCode}
	 */
	public int getVirtualCode() {
		return virtualCode;
	}

	/**
	 * @param virtualCode
	 */
	public void setVirtualCode(int virtualCode) {
		this.virtualCode = virtualCode;
	}

	/**
	 * @return {@link #msisdn}
	 */
	public String getMsisdn() {
		return msisdn;
	}

	/**
	 * @param msisdn
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	/**
	 * @return {@link #packBrowseList}
	 */
	public String getPackBrowseList() {
		return packBrowseList;
	}

	/**
	 * @param packBrowseList
	 */
	public void setPackBrowseList(String packBrowseList) {
		this.packBrowseList = packBrowseList;
	}

	/**
	 * @return {@link #requestId}
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return {@link #digits}
	 */
	public String getDigits() {
		return digits;
	}

	/**
	 * @param digits
	 */
	public void setDigits(String digits) {
		this.digits = digits;
	}

	/**
	 * @return {@link #index}
	 */
	public String getIndex() {
		return index;
	}

	/**
	 * @param index
	 */
	public void setIndex(String index) {
		this.index = index;
	}

	/**
	 * @return {@link #shortCode}
	 */
	public String getShortCode() {
		return shortCode;
	}

	/**
	 * @param shortCode
	 */
	public void setShortCode(String shortCode) {
		this.shortCode = shortCode;
	}

	/**
	 * @return {@link #interfaceUsed}
	 */
	public String getInterfaceUsed() {
		return interfaceUsed;
	}

	/**
	 * @param interfaceUsed
	 */
	public void setInterfaceUsed(String interfaceUsed) {
		this.interfaceUsed = interfaceUsed;
	}

	/**
	 * @return {@link #subType}
	 */
	public String getSubType() {
		return subType;
	}

	/**
	 * @param subType
	 */
	public void setSubType(String subType) {
		this.subType = subType;
	}

	/**
	 * @return {@link #fmsisdn}
	 */
	public String getFmsisdn() {
		return fmsisdn;
	}

	/**
	 * @param fmsisdn
	 */
	public void setFmsisdn(String fmsisdn) {
		this.fmsisdn = fmsisdn;
	}

	/**
	 * @return {@link #packList}
	 */
	public String getPackList() {
		return packList;
	}

	/**
	 * @param packList
	 */
	public void setPackList(String packList) {
		this.packList = packList;
	}

	/**
	 * @return {@link #langId}
	 */
	public byte getLangId() {
		return langId;
	}

	/**
	 * @param langId
	 */
	public void setLangId(byte langId) {
		this.langId = langId;
	}

	/**
	 * @return {@link #packTypeId}
	 */
	public int getPackTypeId() {
		return packTypeId;
	}

	/**
	 * @param packTypeId
	 */
	public void setPackTypeId(int packTypeId) {
		this.packTypeId = packTypeId;
	}

	/**
	 * @return {@link #balance}
	 */
	public double getBalance() {
		return balance;
	}

	/**
	 * @param balance
	 */
	public void setBalance(double balance) {
		this.balance = balance;
	}

	/**
	 * @return {@link #result}
	 */
	public byte getResult() {
		return result;
	}

	/**
	 * @param result
	 */
	public void setResult(byte result) {
		this.result = result;
	}

	/**
	 * @return {@link #filePath}
	 */
	public String getFilePath() {
		return filePath;
	}

	/**
	 * @param filePath
	 */
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	/**
	 * @return {@link #packPurchaseDetail}
	 */
	public String getPackPurchaseDetail() {
		return packPurchaseDetail;
	}

	/**
	 * @param packPurchaseDetail
	 */
	public void setPackPurchaseDetail(String packPurchaseDetail) {
		this.packPurchaseDetail = packPurchaseDetail;
	}

	/**
	 * @return {@link #packId}
	 */
	public int getPackId() {
		return packId;
	}

	/**
	 * 
	 * @param packId
	 */
	public void setPackId(int packId) {
		this.packId = packId;
	}

	/**
	 * @return {@link #netType}
	 */
	public String getNetType() {
		return netType;
	}

	/**
	 * @param netType
	 */
	public void setNetType(String netType) {
		this.netType = netType;
	}

	/**
	 * @return {@link #volume}
	 */
	public int getVolume() {
		return volume;
	}

	/**
	 * @param volume
	 */
	public void setVolume(int volume) {
		this.volume = volume;
	}

	/**
	 * @return {@link #serviceType}
	 */
	public String getServiceType() {
		return serviceType;
	}

	/**
	 * @param serviceType
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getPrevIndex() {
		return prevIndex;
	}

	public void setPrevIndex(String prevIndex) {
		this.prevIndex = prevIndex;
	}

	public String getNextIndex() {
		return nextIndex;
	}

	public void setNextIndex(String nextIndex) {
		this.nextIndex = nextIndex;
	}

	public String getIsPackType() {
		return isPackType;
	}

	public void setIsPackType(String isPackType) {
		this.isPackType = isPackType;
	}

	public String getBasePackType() {
		return basePackType;
	}

	public void setBasePackType(String basePackType) {
		this.basePackType = basePackType;
	}

	public String getCurrentPackTypeList() {
		return currentPackTypeList;
	}

	public void setCurrentPackTypeList(String currentPackTypeList) {
		this.currentPackTypeList = currentPackTypeList;
	}

	public String getIsLowBalancePack() {
		return isLowBalancePack;
	}

	public void setIsLowBalancePack(String isLowBalancePack) {
		this.isLowBalancePack = isLowBalancePack;
	}

	/**
	 * @return the callStartTime
	 */
	public String getCallStartTime() {
		return callStartTime;
	}

	/**
	 * @param callStartTime
	 *            the callStartTime to set
	 */
	public void setCallStartTime(String callStartTime) {
		this.callStartTime = callStartTime;
	}

	/**
	 * @return the callDuration
	 */
	public int getCallDuration() {
		return callDuration;
	}

	/**
	 * @param callDuration
	 *            the callDuration to set
	 */
	public void setCallDuration(int callDuration) {
		this.callDuration = callDuration;
	}

	/**
	 * @return the lastPackAccessedTime
	 */
	public String getLastPackAccessedTime() {
		return lastPackAccessedTime;
	}

	/**
	 * @param lastPackAccessedTime
	 *            the lastPackAccessedTime to set
	 */
	public void setLastPackAccessedTime(String lastPackAccessedTime) {
		this.lastPackAccessedTime = lastPackAccessedTime;
	}

	/**
	 * @return the callHangUpTime
	 */
	public String getCallHangUpTime() {
		return callHangUpTime;
	}

	/**
	 * @param callHangUpTime
	 *            the callHangUpTime to set
	 */
	public void setCallHangUpTime(String callHangUpTime) {
		this.callHangUpTime = callHangUpTime;
	}

	/**
	 * @return the balToConvert
	 */
	public int getBalToConvert() {
		return balToConvert;
	}

	/**
	 * @param balToConvert
	 *            the balToConvert to set
	 */
	public void setBalToConvert(int balToConvert) {
		this.balToConvert = balToConvert;
	}

	/**
	 * @return the packActionType
	 */
	public int getPackActionType() {
		return packActionType;
	}

	/**
	 * @param packActionType
	 *            the packActionType to set
	 */
	public void setPackActionType(int packActionType) {
		this.packActionType = packActionType;
	}

	/**
	 * @return the serviceDetail
	 */
	public String getServiceDetail() {
		return serviceDetail;
	}

	/**
	 * @param serviceDetail
	 *            the serviceDetail to set
	 */
	public void setServiceDetail(String serviceDetail) {
		this.serviceDetail = serviceDetail;
	}

	/**
	 * @return the activeAccIdList
	 */
	public String getActiveAccIdList() {
		return activeAccIdList;
	}

	/**
	 * @param activeAccIdList
	 *            the activeAccIdList to set
	 */
	public void setActiveAccIdList(String activeAccIdList) {
		this.activeAccIdList = activeAccIdList;
	}

	/**
	 * @return the volToConvert
	 */
	public int getVolToConvert() {
		return volToConvert;
	}

	/**
	 * @param volToConvert
	 *            the volToConvert to set
	 */
	public void setVolToConvert(int volToConvert) {
		this.volToConvert = volToConvert;
	}

	/**
	 * @return the dataToConvert
	 */
	public int getDataToConvert() {
		return dataToConvert;
	}

	/**
	 * @param dataToConvert
	 *            the dataToConvert to set
	 */
	public void setDataToConvert(int dataToConvert) {
		this.dataToConvert = dataToConvert;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode
	 *            the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	@Override
	public String toString() {
		return "UserDataBean [msisdn=" + msisdn + ", packBrowseList=" + packBrowseList + ", requestId=" + requestId
				+ ", digits=" + digits + ", index=" + index + ", shortCode=" + shortCode + ", interfaceUsed="
				+ interfaceUsed + ", subType=" + subType + ", fmsisdn=" + fmsisdn + ", packList=" + packList
				+ ", langId=" + langId + ", packTypeId=" + packTypeId + ", balance=" + balance + ", result=" + result
				+ ", filePath=" + filePath + ", packPurchaseDetail=" + packPurchaseDetail + ", packId=" + packId
				+ ", netType=" + netType + ", volume=" + volume + ", serviceType=" + serviceType + ", virtualCode="
				+ virtualCode + ", pageId=" + pageId + ", pageContent=" + pageContent + ", prevIndex=" + prevIndex
				+ ", nextIndex=" + nextIndex + ", more=" + more + ", totalMenuShown=" + totalMenuShown + ", isPackType="
				+ isPackType + ", basePackType=" + basePackType + ", currentPackTypeList=" + currentPackTypeList
				+ ", isLowBalancePack=" + isLowBalancePack + ", callStartTime=" + callStartTime + ", callDuration="
				+ callDuration + ", callHangUpTime=" + callHangUpTime + ", accessedPacksRecordList="
				+ accessedPacksRecordList + ", lastPackAccessedTime=" + lastPackAccessedTime + ", balToConvert="
				+ balToConvert + ", packActionType=" + packActionType + ", serviceDetail=" + serviceDetail
				+ ", activeAccIdList=" + activeAccIdList + ", volToConvert=" + volToConvert + ", dataToConvert="
				+ dataToConvert + ", productCode=" + productCode + ", userPoints=" + userPoints + ", userPointsInfo="
				+ userPointsInfo + ", referCode=" + referCode + ", referValidity=" + referValidity + "]";
	}

}
