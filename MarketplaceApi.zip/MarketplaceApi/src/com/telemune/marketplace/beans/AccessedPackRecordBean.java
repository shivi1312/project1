package com.telemune.marketplace.beans;

/**
 * This bean is used to hold the record of accessed packs by the user.
 * 
 * @author Siddharth Singh Rawat
 */
public class AccessedPackRecordBean {

	/**
	 * Used to hold the value of pack Type
	 */
	private int packtypeId = -1;

	/**
	 * Used to hold the value of pack access time
	 */
	private String packAccTm = "";

	/**
	 * Used to hold the value of last pack access Type
	 */
	private String lastPackAccTm = "";

	/**
	 * @return the packTypeID
	 */
	public int getPackTypeID() {
		return packtypeId;
	}

	/**
	 * @param packTypeID
	 *            the packTypeID to set
	 */
	public void setPackTypeID(int packTypeID) {
		this.packtypeId = packTypeID;
	}

	/**
	 * @return the currentDateString
	 */
	public String getCurrentDateString() {
		return packAccTm;
	}

	/**
	 * @param currentDateString
	 *            the currentDateString to set
	 */
	public void setCurrentDateString(String currentDateString) {
		this.packAccTm = currentDateString;
	}

	/**
	 * @return the lastPackAccessedTime
	 */
	public String getLastPackAccessedTime() {
		return lastPackAccTm;
	}

	/**
	 * @param lastPackAccessedTime
	 *            the lastPackAccessedTime to set
	 */
	public void setLastPackAccessedTime(String lastPackAccessedTime) {
		this.lastPackAccTm = lastPackAccessedTime;
	}

	/**
	 * @param packTypeID
	 * @param currentDateString
	 * @param lastPackAccessedTime
	 */
	public AccessedPackRecordBean(int packTypeID, String currentDateString, String lastPackAccessedTime) {
		super();
		this.packtypeId = packTypeID;
		this.packAccTm = currentDateString;
		this.lastPackAccTm = lastPackAccessedTime;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "[packtypeId=" + packtypeId + ", packAccTm=" + packAccTm + ", lastPackAccTm=" + lastPackAccTm + "]";
	}
}
