/**
 *  Created on - 17 Jan, 2018
 * 	@author AbhiShek Rana
 */
package com.telemune.marketplace.beans;

/**
 * This bean is used to hold the values of user detail.
 * 
 * @author Siddharth Singh Rawat
 *
 */
public class UserProfileBean {

	public String userId;
	public String msisdn;
	public int language;
	public String password;
	public String name;
	public String email_Id;
	public String status;
	public String gender;
	public String date_registered;
	public String last_Visit_Time;
	public String SubType;
	public String others;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public int getLanguage() {
		return language;
	}
	public void setLanguage(int language) {
		this.language = language;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail_Id() {
		return email_Id;
	}
	public void setEmail_Id(String email_Id) {
		this.email_Id = email_Id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDate_registered() {
		return date_registered;
	}
	public void setDate_registered(String date_registered) {
		this.date_registered = date_registered;
	}
	public String getLast_Visit_Time() {
		return last_Visit_Time;
	}
	public void setLast_Visit_Time(String last_Visit_Time) {
		this.last_Visit_Time = last_Visit_Time;
	}
	public String getSubType() {
		return SubType;
	}
	public void setSubType(String subType) {
		SubType = subType;
	}
	public String getOthers() {
		return others;
	}
	public void setOthers(String others) {
		this.others = others;
	}
	@Override
	public String toString() {
		return "UserProfileBean [userId=" + userId + ", msisdn=" + msisdn
				+ ", language=" + language + ", password=" + password
				+ ", name=" + name + ", email_Id=" + email_Id + ", status="
				+ status + ", gender=" + gender + ", date_registered="
				+ date_registered + ", last_Visit_Time=" + last_Visit_Time
				+ ", SubType=" + SubType + ", others=" + others + "]";
	}
	
}
