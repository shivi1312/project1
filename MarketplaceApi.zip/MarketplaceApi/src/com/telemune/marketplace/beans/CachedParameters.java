/**
 * @author MoHit
 * Created on - 13 Feb, 2017
 */
package com.telemune.marketplace.beans;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.telemune.marketplace.util.TSSJavaUtil;
import com.telemune.marketplace.util.UssdMenuNames;

/**
 * This class is used to hold some parameters which need to be cached and will
 * be used throughout the application by different classes with the help of
 * TSSJavaUtil instance only
 * 
 * @author MoHit
 */
public class CachedParameters {
	/**
	 * Used to print logs in this class
	 */
	Logger logger = Logger.getLogger(CachedParameters.class);

	/**
	 * Used to hold the database driver class to be used
	 */
	private String dbDriver = null;

	/**
	 * Used to hold the database URL to be used
	 */
	private String dbURL = null;

	/**
	 * Used to hold the database username to be used
	 */
	private String dbUsername = null;

	/**
	 * Used to hold the database password to be used
	 */
	private String dbPassword = null;

	/**
	 * Used to hold the minimum connection in pool
	 */
	private short dbMinPoolSize = 1;

	/**
	 * Used to hold the maximum connection in pool
	 */
	private short dbMaxPoolSize = 3;

	/**
	 * Used to hold no. of connection to be create when needed more
	 */
	private short dbAccomodation = 2;

	/**
	 * Used to hold the default language ID to be used
	 */
	private byte defaultLangId = 1;

	/**
	 * Used to hold MSISDNs supported range list means only those MSISDNs will be
	 * allowed to access this application which lies under the ranges in this list
	 * of ranges
	 */
	private ArrayList<MsisdnRange> msisdnRangeList = new ArrayList<MsisdnRange>();

	/**
	 * Used to hold all availablePacks that can be shown to user by this API
	 */
	private HashMap<String, ArrayList<PackBean>> availablePacksMap = new HashMap<String, ArrayList<PackBean>>();

	/**
	 * Used to hold all availableLowBalancePacks that can be shown to user by this
	 * API
	 */
	private HashMap<String, ArrayList<PackBean>> availableLowBalancePacksMap = new HashMap<String, ArrayList<PackBean>>();
	
	
	/*
	 * Added By Richard on 7th November 2019
	 * 
	 * Used to hold errors coming from API while pack purchasing and accordingly show the USSD menu message.
	 * 
	 */
	private HashMap<String,String> errorCodesMenuMap = new HashMap<String,String>();

	/**
	 * Used to hold PACK_BASED_ON_BALANCE_ENABLE property file parameter 1 means
	 * packs will be shown according to main balance of user else all packs will be
	 * shown
	 */
	private boolean packBasedOnBalanceEnable = false;

	private boolean LowBalancePackBasedOnBalanceEnable = false;

	/**
	 * used to hold maximum length of response message which is returned to
	 * requesting interface. It cannot be more than maximum number of menus.
	 */
	private short maxUssdStringLength = 160;

	/**
	 * Used to hold maximum menus that can be returned to the requesting interface
	 * if does not exceed maximum length
	 */
	private byte maxMenus = 5;

	/**
	 * Used to hold the Maximum active plans to shown in IVR
	 */
	private byte ivrMaxActivePlan = 5;

	public byte getIvrMaxActivePlan() {
		return ivrMaxActivePlan;
	}

	public void setIvrMaxActivePlan(byte ivrMaxActivePlan) {
		this.ivrMaxActivePlan = ivrMaxActivePlan;
	}

	/**
	 * Used to hold all menu names and strings that are to be used to show response
	 * to user
	 */
	private HashMap<String, String> ussdMenuDetailsMap = new HashMap<String, String>();

	/**
	 * Used to hold that white-listing is enable or not if true that means only
	 * white-listed MSISDNs can access this API
	 */
	private boolean whiteListingEnable = false;

	/**
	 * Used to hold the MSISDN that are white-listed to this system
	 */
	private ArrayList<String> whiteListedMSISDNs = new ArrayList<String>();

	/**
	 * Used to hold the MSISDN that are blacklisted to this system
	 */
	private ArrayList<String> blackListedMSISDNs = new ArrayList<String>();

	/**
	 * Used to hold that we have to put the entry in database on first (check
	 * profile) hit or not
	 */
	private boolean dbLogOnCheckProfileEnable = false;

	/**
	 * Used to hold available pack types based on their IDs
	 */
	private HashMap<Integer, String> availablePackTypes = new HashMap<Integer, String>();

	/**
	 * Used to hold available pack type IDs based on their names
	 */
	private HashMap<String, Integer> availablePackTypeIDs = new HashMap<String, Integer>();

	private HashMap<Integer, Integer> availablePackTypeParallelEnableMap = new HashMap<Integer, Integer>();

	/**
	 * Used to hold service charge details of all the packs
	 */
	private HashMap<Integer, ServiceCharge> srvcChargeDetails = new HashMap<Integer, ServiceCharge>();

	/**
	 * Used to hold virtual code based details in case of direct dial
	 */
	private HashMap<Integer, VirtualCodeMapping> virtualCodeMappedDetails = new HashMap<Integer, VirtualCodeMapping>();

	/**
	 * Used to hold short code based details in case of direct dial
	 */
	private HashMap<String, ShortCodeMapping> shortCodeMappedDetails = new HashMap<String, ShortCodeMapping>();

	/**
	 * Used to hold volume transfer validity configuration for talk time transfer
	 * means for a volume transfer range what will be the validity
	 */
	private HashMap<Integer, ArrayList<TransferValidity>> transferValidityConfig = new HashMap<Integer, ArrayList<TransferValidity>>();

	/**
	 * Used to hold the sub-type source H-HLR, C-Charging, P-Prepaid, O-Postpaid
	 */
	private String subTypeSource = "P";

	/**
	 * Used to hold the HLR IP where HLR is running
	 */
	private String hlrIP = "NA";

	/**
	 * Used to hold the HLR Port on which HLR is listening
	 */
	private short hlrPort = -1;

	/**
	 * Used to hold charging test case is enable or not if enable then we will not
	 * request to charging interface for any request
	 */
	private boolean chargingTestingEnable = false;

	/**
	 * Used to hold HLR timeout in seconds means for how many seconds we have to
	 * wait for the response from HLR
	 */
	private int hlrTimeout = 30;

	/**
	 * Used to hold the service charge to be deducted for talk time transfer ONNET
	 */
	private double tttServiceChargeOnNet = 0.0;

	/**
	 * Used to hold the service charge to be deducted for talk time transfer ONNET
	 */
	private double tttServiceChargeOffNet = 0.0;

	/**
	 * Used to hold that previous option is to be shown or not while showing pack
	 * purchase description/confirmation
	 */
	private boolean prevOptionOnPackDescEnable = false;

	/**
	 * Used to hold product code to be used for talk time transfer this is not sent
	 * to charging but used for log maintaining
	 */
	private String tttProductCode = "-100";

	/**
	 * Used to hold main balance to be shown when testing is enable
	 */
	private double testingBalance = 1000;

	/**
	 * Used to hold maximum limit of talk time transfer means user can not transfer
	 * volume more than this value
	 */
	private int tttMaxLimit = -99;

	/**
	 * Used to show that double value in user balance/amount/service charge if it is
	 * enable then balance/amount/service charge will be shown as float value
	 * otherwise will be shown as an integer
	 */
	private boolean floatValueEnable = false;

	/**
	 * Used to hold prefix value for origination number that is used replace country
	 * code from A party's MSISDN that is used as origination number while sending
	 * SMS to B party only
	 */
	private String smsOrigNumPrefixB = "";

	/**
	 * Used to hold interfaces for which SMS is allowed to send to A party in case
	 * of talk-time transfer success.
	 */
	private String interfaceForTTTransferA = "NA";

	/**
	 * Used to hold interfaces for which SMS is allowed to send to B party in case
	 * of talk-time transfer success.
	 */
	private String interfaceForTTTransferB = "NA";

	/**
	 * Used to hold interfaces for which SMS is allowed to send to A party in case
	 * of bonus transfer (gift) success.
	 */
	private String interfaceForBonusA = "NA";

	/**
	 * Used to hold interfaces for which SMS is allowed to send to B party in case
	 * of bonus transfer (gift) success.
	 */
	private String interfaceForBonusB = "NA";

	/**
	 * Used to hold interfaces for which SMS is allowed to send to A party in case
	 * of data transfer success.
	 */
	private String interfaceForDataTransferA = "NA";

	/**
	 * Used to hold interfaces for which SMS is allowed to send to B party in case
	 * of data transfer success.
	 */
	private String interfaceForDataTransferB = "NA";

	/**
	 * Used to hold SMS origination number while sending SMS to B party
	 */
	private String smsOriginationNumberB = "Marketplace";

	/**
	 * Used to hold SMS origination number while sending SMS to A party in case of
	 * talk-time transfer.
	 */
	private String smsOrigNumberTTTA = "Marketplace";

	/**
	 * Used to hold SMS origination number while sending SMS to A party in case of
	 * bonus transfer (gift).
	 */
	private String smsOrigNumberBonusA = "Marketplace";

	/**
	 * Used to hold SMS origination number while sending SMS to A party in case of
	 * data transfer.
	 */
	private String smsOrigNumberDataTransferA = "Marketplace";

	// Added By SIDDARTH

	/**
	 * Used to hold SMS templates these SMS templates are used to send SMS to users
	 */
	private HashMap<String, String> lbsTemplates = new HashMap<String, String>();

	private int transactionCdrLimit = 3;

	private int activePlanViewLimit = 3;

	/**
	 * Used to hold IVR Prompt Base File Path
	 */
	private String ivrBasePath = "";

	/**
	 * Used to hold IVR Pack Prompt Base File Path
	 */
	private String ivrPackPromptBasePath = "";

	/**
	 * Used to hold the max prompt to play in the IVR flow
	 */
	private byte maxIvrMenu = 5;
	
	private byte maxWelcomePromoMenu = 5;

	public byte getMaxWelcomePromoMenu() {
		return maxWelcomePromoMenu;
	}

	public void setMaxWelcomePromoMenu(byte maxWelcomePromoMenu) {
		this.maxWelcomePromoMenu = maxWelcomePromoMenu;
	}

	/**
	 * Used to hold the value for Enable/Disable previous option in the IVR flow
	 */
	private byte isPreviousEnableIvr = 0;

	/**
	 * Used to hold the value for Enable/Disable previous option in pack description
	 * of IVR flow
	 */
	private byte isPrevOptionOnPackDescriptionEnableIvr = 0;

	/**
	 * Used to hold the value for Enable/Disable INVALID_FMSISDN_BT_IVR_PROMPT in
	 * the IVR flow
	 */
	private byte invalidFmsisdnBtIvrPromptEnable = 0;

	/**
	 * Used to hold the value for Enable/Disable FMSISDN_NOT_IN_RANGE_BT_IVR_PROMPT
	 * in the IVR flow
	 */

	/**
	 * Used to hold all available Packs type that can be shown to user by this API
	 */
	private HashMap<String, ArrayList<PackTypeBean>> availablePackTypeMap = new HashMap<String, ArrayList<PackTypeBean>>();

	private byte fmsisdnNotInRangeBtIvrPrmptEnable = 0;

	/**
	 * Used to hold the value for Test Charging Result
	 */
	private byte enabledTestChargingResult = 1;

	/**
	 * This variable used to hold the value of selected database.
	 * DataBaseType:[1=ORACLE, 2=MYSQL].
	 */
	private byte dataBaseType = 1;

	/**
	 * This variable is used to hold the value which shows Fall Back is enabled or
	 * not. {1:ENABLE , 0:DISABLE}
	 */
	private byte fallBackEnable = 1;

	/**
	 * This variable value determine whether to show balance in low balance message
	 * or not {1:SHOW-BLANACE , 0:HIDE-BALANCE}
	 */
	private byte showBalanceInLowBalanceMsg = 1;

	/**
	 * Used to get the information of the particular packType by it's PackTypeId
	 */
	private HashMap<Integer, PackTypeBean> packTypeDetailsMap = new HashMap<Integer, PackTypeBean>();

	/**
	 * used to set file interval
	 */
	private byte callArchiveFileInterval = 1;

	private String callLogFileName = "NA";

	private String callLogFilePath = "NA";

	private String callArchiveFilePath = "NA";

	private String callArchiveFileName = "NA";

	private String archiveFileExtension = ".d";

	/**
	 * maxIdleTime used to hold the Seconds a Connection can remain pooled but
	 * unused before being discarded. Zero means idle connections never expire.
	 */
	private int maxIdleTime = 300;

	/**
	 * This map is used to hold the values of MPLACE_APP_CONFIG_PARAMS
	 */
	private HashMap<String, String> appConfigParamMap = new HashMap<String, String>();

	/**
	 * This map is use to hold the values of service action details with key as
	 * service ID
	 */
	private Map<Integer, String> serviceActionDetailMap = new HashMap<>();

	/**
	 * This arrayList will hold all the Data Macro Credit Amount Based Service
	 * related configuration and conversion constants.
	 */
	private ArrayList<DmcConversionConfig> dmcAbConversionConfigList = new ArrayList<>();

	/**
	 * This arrayList will hold all the Data Macro Credit Volume Based Service
	 * related configuration and conversion constants.
	 */
	private ArrayList<DmcConversionConfig> dmcVbConversionConfigList = new ArrayList<>();

	/**
	 * This HashTable will hold all the pack details configuration.
	 */
	private Hashtable<String, PackDetailConfig> packDetailConfigMap = new Hashtable<>();

	/**
	 * used to give Data Macro Credit Service permission to selected SUB TYPE.
	 * {O=PostPaid, P=PrePaid, A=All/No Restriction}
	 */
	private String dmcAllowedSubType = "A";

	/**
	 * Used to give Data Macro Credit Service permission to selected SUB TYPE.
	 * {O=PostPaid, P=PrePaid, A=All/No Restriction}
	 */
	private String checkServiceBlanceAllowedSubType = "A";

	/**
	 * Used to hold the total allowed number after decimal in check user data
	 * balance. Only applicable if CHECK_DATA_BALANCE_FLOAT_VALUE_ENABLE=1 in
	 * property file.
	 */
	private byte checkDataBalanceNumAllowedAfterDec = 2;

	/**
	 * Used to check weather float value is enable in Check Data Balance or not.
	 */
	private boolean isCheckDataBalanceFloatEnable = false;

	/**
	 * Used to hold the value of maximum active data account shown to user in case
	 * of check data account
	 */
	private byte maxActiveDataAccMenus = 8;

	/**
	 * Used to set the required date format in check data balance
	 */
	private String checkDataBlanceDateFormat = "dd-MM-yy HH:mm";

	/**
	 * Used to hold the account type of unlimited data packs
	 */
	private String unlimitedDataAccountTypes = "";

	/**
	 * Used to define sequence generated strategy in case of MYSQL (1=Form Sequence
	 * Table)
	 */
	private byte mysqlSequenceGeneratedFromSeqTable = 1;

	/**
	 * Used to show Promotion Packs based on user balance. false = Show all
	 * promotion packs. true = Show only those packs whose amount is greater than or
	 * equal to user balance.
	 */
	private boolean showPromotionPacksBasedOnBalance = false;

	/**
	 * This map is used to hold the values of PROMOTION_SERVICE_MAPPING details
	 * table. This tables having list of all promotion MSISDN and there promotions.
	 */
	// private HashMap<String, String> promoServiceMap = new HashMap<>();

	/**
	 * This map is used to hold the values all Promotion Packs
	 */
	private HashMap<String, PromoPackBean> promoPackDetailsMap = new HashMap<>();

	/**
	 * @return the promoServiceMap
	 */
	// public HashMap<String, String> getPromoServiceMap() {
	// return promoServiceMap;
	// }

	/**
	 * @param promoServiceMap the promoServiceMap to set
	 */
	// public void setPromoServiceMap(HashMap<String, String> promoServiceMap) {
	// this.promoServiceMap = promoServiceMap;
	// }

	/**
	 * This parameter is used to hold the value which charing based is 1 = if
	 * charging is Diameter based 0 = is charging is not Diameter bases (POST
	 * Charging)
	 */
	private byte isDiameterChargingEnable = 1;
	
	private String customerCareIvrPromptBasePath="";

	public String getCustomerCareIvrPromptBasePath() {
		return customerCareIvrPromptBasePath;
	}

	public void setCustomerCareIvrPromptBasePath(String customerCareIvrPromptBasePath) {
		this.customerCareIvrPromptBasePath = customerCareIvrPromptBasePath;
	}

	public byte getIsDiameterChargingEnable() {
		return isDiameterChargingEnable;
	}

	public void setIsDiameterChargingEnable(byte isDiameterChargingEnable) {
		this.isDiameterChargingEnable = isDiameterChargingEnable;
	}

	/**
	 * @return the promoPackDetailsMap
	 */
	public HashMap<String, PromoPackBean> getPromoPackDetailsMap() {
		return promoPackDetailsMap;
	}

	/**
	 * @param promoPackDetailsMap the promoPackDetailsMap to set
	 */
	public void setPromoPackDetailsMap(HashMap<String, PromoPackBean> promoPackDetailsMap) {
		this.promoPackDetailsMap = promoPackDetailsMap;
	}

	/**
	 * @return the showPromotionPacksBasedOnBalance
	 */
	public boolean isShowPromotionPacksBasedOnBalance() {
		return showPromotionPacksBasedOnBalance;
	}

	/**
	 * @param showPromotionPacksBasedOnBalance the showPromotionPacksBasedOnBalance
	 *                                         to set
	 */
	public void setShowPromotionPacksBasedOnBalance(boolean showPromotionPacksBasedOnBalance) {
		this.showPromotionPacksBasedOnBalance = showPromotionPacksBasedOnBalance;
	}

	/**
	 * @return the mysqlSequenceGeneratedFromSeqTable
	 */
	public byte getMysqlSequenceGeneratedFromSeqTable() {
		return mysqlSequenceGeneratedFromSeqTable;
	}

	/**
	 * @param mysqlSequenceGeneratedFromSeqTable the
	 *                                           mysqlSequenceGeneratedFromSeqTable
	 *                                           to set
	 */
	public void setMysqlSequenceGeneratedFromSeqTable(byte mysqlSequenceGeneratedFromSeqTable) {
		this.mysqlSequenceGeneratedFromSeqTable = mysqlSequenceGeneratedFromSeqTable;
	}

	/**
	 * @return the unlimitedDataAccountTypes
	 */
	public String getUnlimitedDataAccountTypes() {
		return unlimitedDataAccountTypes;
	}

	/**
	 * @param unlimitedDataAccountTypes the unlimitedDataAccountTypes to set
	 */
	public void setUnlimitedDataAccountTypes(String unlimitedDataAccountTypes) {
		this.unlimitedDataAccountTypes = unlimitedDataAccountTypes;
	}

	/**
	 * @return the checkDataBalanceNumAllowedAfterDec
	 */
	public byte getCheckDataBalanceNumAllowedAfterDec() {
		return checkDataBalanceNumAllowedAfterDec;
	}

	/**
	 * @param checkDataBalanceNumAllowedAfterDec the
	 *                                           checkDataBalanceNumAllowedAfterDec
	 *                                           to set
	 */
	public void setCheckDataBalanceNumAllowedAfterDec(byte checkDataBalanceNumAllowedAfterDec) {
		this.checkDataBalanceNumAllowedAfterDec = checkDataBalanceNumAllowedAfterDec;
	}

	/**
	 * @return the maxActiveDataAccMenus
	 */
	public byte getMaxActiveDataAccMenus() {
		return maxActiveDataAccMenus;
	}

	/**
	 * @param maxActiveDataAccMenus the maxActiveDataAccMenus to set
	 */
	public void setMaxActiveDataAccMenus(byte maxActiveDataAccMenus) {
		this.maxActiveDataAccMenus = maxActiveDataAccMenus;
	}

	/**
	 * @return the packDetailConfigMap
	 */
	public Hashtable<String, PackDetailConfig> getPackDetailConfigMap() {
		return packDetailConfigMap;
	}

	/**
	 * @param packDetailConfigMap the packDetailConfigMap to set
	 */
	public void setPackDetailConfigMap(Hashtable<String, PackDetailConfig> packDetailConfigMap) {
		this.packDetailConfigMap = packDetailConfigMap;
	}

	/**
	 * @return the callLogFileName
	 */
	public String getCallLogFileName() {
		return callLogFileName;
	}

	/**
	 * @return the dmcAllowedSubType
	 */
	public String getDmcAllowedSubType() {
		return dmcAllowedSubType;
	}

	/**
	 * @param dmcAllowedSubType the dmcAllowedSubType to set
	 */
	public void setDmcAllowedSubType(String dmcAllowedSubType) {
		this.dmcAllowedSubType = dmcAllowedSubType;
	}

	/**
	 * @return the checkServiceBlanceAllowedSubType
	 */
	public String getCheckServiceBlanceAllowedSubType() {
		return checkServiceBlanceAllowedSubType;
	}

	/**
	 * @param checkServiceBlanceAllowedSubType the checkServiceBlanceAllowedSubType
	 *                                         to set
	 */
	public void setCheckServiceBlanceAllowedSubType(String checkServiceBlanceAllowedSubType) {
		this.checkServiceBlanceAllowedSubType = checkServiceBlanceAllowedSubType;
	}

	/**
	 * @return the isCheckDataBalanceFloatEnable
	 */
	public boolean isCheckDataBalanceFloatEnable() {
		return isCheckDataBalanceFloatEnable;
	}

	/**
	 * @param isCheckDataBalanceFloatEnable the isCheckDataBalanceFloatEnable to set
	 */
	public void setCheckDataBalanceFloatEnable(boolean isCheckDataBalanceFloatEnable) {
		this.isCheckDataBalanceFloatEnable = isCheckDataBalanceFloatEnable;
	}

	/**
	 * @param callLogFileName the callLogFileName to set
	 */
	public void setCallLogFileName(String callLogFileName) {
		this.callLogFileName = callLogFileName;
	}

	/**
	 * @return the callLogFilePath
	 */
	public String getCallLogFilePath() {
		return callLogFilePath;
	}

	/**
	 * @param callLogFilePath the callLogFilePath to set
	 */
	public void setCallLogFilePath(String callLogFilePath) {
		this.callLogFilePath = callLogFilePath;
	}

	/**
	 * @return the callArchiveFilePath
	 */
	public String getCallArchiveFilePath() {
		return callArchiveFilePath;
	}

	/**
	 * @param callArchiveFilePath the callArchiveFilePath to set
	 */
	public void setCallArchiveFilePath(String callArchiveFilePath) {
		this.callArchiveFilePath = callArchiveFilePath;
	}

	/**
	 * @return the callArchiveFileName
	 */
	public String getCallArchiveFileName() {
		return callArchiveFileName;
	}

	/**
	 * @param callArchiveFileName the callArchiveFileName to set
	 */
	public void setCallArchiveFileName(String callArchiveFileName) {
		this.callArchiveFileName = callArchiveFileName;
	}

	public byte getInvalidFmsisdnBtIvrPromptEnable() {
		return invalidFmsisdnBtIvrPromptEnable;
	}

	public void setInvalidFmsisdnBtIvrPromptEnable(byte invalidFmsisdnBtIvrPromptEnable) {
		this.invalidFmsisdnBtIvrPromptEnable = invalidFmsisdnBtIvrPromptEnable;
	}

	public byte getFmsisdnNotInRangeBtIvrPrmptEnable() {
		return fmsisdnNotInRangeBtIvrPrmptEnable;
	}

	public void setFmsisdnNotInRangeBtIvrPrmptEnable(byte fmsisdnNotInRangeBtIvrPrmptEnable) {
		this.fmsisdnNotInRangeBtIvrPrmptEnable = fmsisdnNotInRangeBtIvrPrmptEnable;
	}

	public byte getIsPrevOptionOnPackDescriptionEnableIvr() {
		return isPrevOptionOnPackDescriptionEnableIvr;
	}

	public void setIsPrevOptionOnPackDescriptionEnableIvr(byte isPrevOptionOnPackDescriptionEnableIvr) {
		this.isPrevOptionOnPackDescriptionEnableIvr = isPrevOptionOnPackDescriptionEnableIvr;
	}

	public byte getIsPreviousEnableIvr() {
		return isPreviousEnableIvr;
	}

	public void setIsPreviousEnableIvr(byte isPreviousEnableIvr) {
		this.isPreviousEnableIvr = isPreviousEnableIvr;
	}

	public String getIvrBasePath() {
		return ivrBasePath;
	}

	public void setIvrBasePath(String ivrBasePath) {
		this.ivrBasePath = ivrBasePath;
	}

	public byte getMaxIvrMenu() {
		return maxIvrMenu;
	}

	public void setMaxIvrMenu(byte maxIvrMenu) {
		this.maxIvrMenu = maxIvrMenu;
	}

	/**
	 * @return {@link #smsOrigNumberBonusA}
	 */
	public String getSmsOrigNumberBonusA() {
		return smsOrigNumberBonusA;
	}

	/**
	 * @param smsOrigNumberBonusA
	 */
	public void setSmsOrigNumberBonusA(String smsOrigNumberBonusA) {
		this.smsOrigNumberBonusA = smsOrigNumberBonusA;
	}

	/**
	 * @return {@link #smsOrigNumberDataTransferA}
	 */
	public String getSmsOrigNumberDataTransferA() {
		return smsOrigNumberDataTransferA;
	}

	/**
	 * @param smsOrigNumberDataTransferA
	 */
	public void setSmsOrigNumberDataTransferA(String smsOrigNumberDataTransferA) {
		this.smsOrigNumberDataTransferA = smsOrigNumberDataTransferA;
	}

	/**
	 * @return {@link #smsOrigNumberTTTA}
	 */
	public String getSmsOrigNumberTTTA() {
		return smsOrigNumberTTTA;
	}

	/**
	 * @param smsOrigNumberTTTA
	 */
	public void setSmsOrigNumberTTTA(String smsOrigNumberTTTA) {
		this.smsOrigNumberTTTA = smsOrigNumberTTTA;
	}

	/**
	 * @return {@link #interfaceForTTTransferA}
	 */
	public String getInterfaceForTTTransferA() {
		return interfaceForTTTransferA;
	}

	/**
	 * @param interfaceForTTTransferA
	 */
	public void setInterfaceForTTTransferA(String interfaceForTTTransferA) {
		this.interfaceForTTTransferA = interfaceForTTTransferA;
	}

	/**
	 * @return {@link #interfaceForTTTransferB}
	 */
	public String getInterfaceForTTTransferB() {
		return interfaceForTTTransferB;
	}

	/**
	 * @param interfaceForTTTransferB
	 */
	public void setInterfaceForTTTransferB(String interfaceForTTTransferB) {
		this.interfaceForTTTransferB = interfaceForTTTransferB;
	}

	/**
	 * @return {@link #interfaceForBonusA}
	 */
	public String getInterfaceForBonusA() {
		return interfaceForBonusA;
	}

	/**
	 * @param interfaceForBonusA
	 */
	public void setInterfaceForBonusA(String interfaceForBonusA) {
		this.interfaceForBonusA = interfaceForBonusA;
	}

	/**
	 * @return {@link #interfaceForBonusB}
	 */
	public String getInterfaceForBonusB() {
		return interfaceForBonusB;
	}

	/**
	 * @param interfaceForBonusB
	 */
	public void setInterfaceForBonusB(String interfaceForBonusB) {
		this.interfaceForBonusB = interfaceForBonusB;
	}

	/**
	 * @return {@link #interfaceForDataTransferA}
	 */
	public String getInterfaceForDataTransferA() {
		return interfaceForDataTransferA;
	}

	/**
	 * @param interfaceForDataTransferA
	 */
	public void setInterfaceForDataTransferA(String interfaceForDataTransferA) {
		this.interfaceForDataTransferA = interfaceForDataTransferA;
	}

	/**
	 * @return {@link #interfaceForDataTransferB}
	 */

	public String getInterfaceForDataTransferB() {
		return interfaceForDataTransferB;
	}

	/**
	 * @param interfaceForDataTransferB
	 */
	public void setInterfaceForDataTransferB(String interfaceForDataTransferB) {
		this.interfaceForDataTransferB = interfaceForDataTransferB;
	}

	/**
	 * @return {@link #smsOrigNumPrefixB}
	 */
	public String getSmsOrigNumPrefixB() {
		return smsOrigNumPrefixB;
	}

	/**
	 * @param smsOrigNumPrefixB
	 */
	public void setSmsOrigNumPrefixB(String smsOrigNumPrefixB) {
		this.smsOrigNumPrefixB = smsOrigNumPrefixB;
	}

	/**
	 * @return {@link #dbDriver}
	 */
	public String getDbDriver() {
		return dbDriver;
	}

	/**
	 * @param dbDriver
	 */
	public void setDbDriver(String dbDriver) {
		this.dbDriver = dbDriver;
	}

	/**
	 * @return {@link #dbURL}
	 */
	public String getDbURL() {
		return dbURL;
	}

	/**
	 * @param dbURL
	 */
	public void setDbURL(String dbURL) {
		this.dbURL = dbURL;
	}

	/**
	 * @return tttServiceChargeOnNet
	 */

	public double getTttServiceChargeOnNet() {
		return tttServiceChargeOnNet;
	}

	/**
	 * @param tttServiceChargeOnNet
	 */
	public void setTttServiceChargeOnNet(double tttServiceChargeOnNet) {
		this.tttServiceChargeOnNet = tttServiceChargeOnNet;
	}

	/**
	 * @return tttServiceChargeOffNet
	 */
	public double getTttServiceChargeOffNet() {
		return tttServiceChargeOffNet;
	}

	/**
	 * @param tttServiceChargeOffNet
	 */
	public void setTttServiceChargeOffNet(double tttServiceChargeOffNet) {
		this.tttServiceChargeOffNet = tttServiceChargeOffNet;
	}

	/**
	 * @return {@link #dbUsername}
	 */
	public String getDbUsername() {
		return dbUsername;
	}

	/**
	 * @param dbUsername
	 */
	public void setDbUsername(String dbUsername) {
		this.dbUsername = dbUsername;
	}

	/**
	 * @return {@link #dbPassword}
	 */
	public String getDbPassword() {
		return dbPassword;
	}

	/**
	 * @param dbPassword
	 */
	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}

	/**
	 * @return {@link #dbMinPoolSize}
	 */
	public short getDbMinPoolSize() {
		return dbMinPoolSize;
	}

	/**
	 * @param dbMinPoolSize
	 */
	public void setDbMinPoolSize(short dbMinPoolSize) {
		this.dbMinPoolSize = dbMinPoolSize;
	}

	/**
	 * @return {@link #dbMaxPoolSize}
	 */
	public short getDbMaxPoolSize() {
		return dbMaxPoolSize;
	}

	/**
	 * @param dbMaxPoolSize
	 */
	public void setDbMaxPoolSize(short dbMaxPoolSize) {
		this.dbMaxPoolSize = dbMaxPoolSize;
	}

	/**
	 * @return {@link #dbAccomodation}
	 */
	public short getDbAccomodation() {
		return dbAccomodation;
	}

	/**
	 * @param dbAccomodation
	 */
	public void setDbAccomodation(short dbAccomodation) {
		this.dbAccomodation = dbAccomodation;
	}

	/**
	 * @return {@link #defaultLangId}
	 */
	public byte getDefaultLangId() {
		return defaultLangId;
	}

	/**
	 * @param defaultLangId
	 */
	public void setDefaultLangId(byte defaultLangId) {
		this.defaultLangId = defaultLangId;
	}

	/**
	 * @return {@link #msisdnRangeList}
	 */
	public ArrayList<MsisdnRange> getMsisdnRangeList() {
		return msisdnRangeList;
	}

	/**
	 * @param msisdnRangeList
	 */
	public void setMsisdnRangeList(ArrayList<MsisdnRange> msisdnRangeList) {
		this.msisdnRangeList = msisdnRangeList;
	}

	/**
	 * @return {@link #availablePacksMap}
	 */
	public HashMap<String, ArrayList<PackBean>> getAvailablePacksMap() {
		return availablePacksMap;
	}

	/**
	 * @param availablePacksMap
	 */
	public void setAvailablePacksMap(HashMap<String, ArrayList<PackBean>> availablePacksMap) {
		this.availablePacksMap = availablePacksMap;
	}

	/**
	 * @return {@link #packBasedOnBalanceEnable}
	 */
	public boolean isPackBasedOnBalanceEnable() {
		return packBasedOnBalanceEnable;
	}

	/**
	 * @param packBasedOnBalanceEnable
	 */
	public void setPackBasedOnBalanceEnable(boolean packBasedOnBalanceEnable) {
		this.packBasedOnBalanceEnable = packBasedOnBalanceEnable;
	}

	/**
	 * 
	 * @return {@link #maxUssdStringLength}
	 */
	public short getMaxUssdStringLength() {
		return maxUssdStringLength;
	}

	/**
	 * 
	 * @param maxUssdStringLength
	 */
	public void setMaxUssdStringLength(short maxUssdStringLength) {
		this.maxUssdStringLength = maxUssdStringLength;
	}

	/**
	 * @return {@link #maxMenus}
	 */
	public byte getMaxMenus() {
		return maxMenus;
	}

	/**
	 * @param maxMenus
	 */
	public void setMaxMenus(byte maxMenus) {
		this.maxMenus = maxMenus;
	}

	/**
	 * @return {@link #ussdMenuDetailsMap}
	 */
	public HashMap<String, String> getUssdMenuDetailsMap() {
		return ussdMenuDetailsMap;
	}

	/**
	 * @param ussdMenuDetailsMap
	 */
	public void setUssdMenuDetailsMap(HashMap<String, String> ussdMenuDetailsMap) {
		this.ussdMenuDetailsMap = ussdMenuDetailsMap;
	}

	/**
	 * @return {@link #whiteListingEnable}
	 */
	public boolean isWhiteListingEnable() {
		return whiteListingEnable;
	}

	/**
	 * @param whiteListingEnable
	 */
	public void setWhiteListingEnable(boolean whiteListingEnable) {
		this.whiteListingEnable = whiteListingEnable;
	}

	/**
	 * @return {@link #whiteListedMSISDNs}
	 */
	public ArrayList<String> getWhiteListedMSISDNs() {
		return whiteListedMSISDNs;
	}

	/**
	 * @param whiteListedMSISDNs
	 */
	public void setWhiteListedMSISDNs(ArrayList<String> whiteListedMSISDNs) {
		this.whiteListedMSISDNs = whiteListedMSISDNs;
	}

	/**
	 * @return {@link #blackListedMSISDNs}
	 */
	public ArrayList<String> getBlackListedMSISDNs() {
		return blackListedMSISDNs;
	}

	/**
	 * @param blackListedMSISDNs
	 */
	public void setBlackListedMSISDNs(ArrayList<String> blackListedMSISDNs) {
		this.blackListedMSISDNs = blackListedMSISDNs;
	}

	/**
	 * @return {@link #dbLogOnCheckProfileEnable}
	 */
	public boolean isDbLogOnCheckProfileEnable() {
		return dbLogOnCheckProfileEnable;
	}

	/**
	 * @param dbLogOnCheckProfileEnable
	 */
	public void setDbLogOnCheckProfileEnable(boolean dbLogOnCheckProfileEnable) {
		this.dbLogOnCheckProfileEnable = dbLogOnCheckProfileEnable;
	}

	/**
	 * @return {@link #availablePackTypes}
	 */
	public HashMap<Integer, String> getAvailablePackTypes() {
		return availablePackTypes;
	}

	/**
	 * @param availablePackTypes
	 */
	public void setAvailablePackTypes(HashMap<Integer, String> availablePackTypes) {
		this.availablePackTypes = availablePackTypes;
	}

	/**
	 * @return {@link #srvcChargeDetails}
	 */
	public HashMap<Integer, ServiceCharge> getSrvcChargeDetails() {
		return srvcChargeDetails;
	}

	/**
	 * @param srvcChargeDetails
	 */
	public void setSrvcChargeDetails(HashMap<Integer, ServiceCharge> srvcChargeDetails) {
		this.srvcChargeDetails = srvcChargeDetails;
	}

	/**
	 * @return {@link #transferValidityConfig}
	 */
	public HashMap<Integer, ArrayList<TransferValidity>> getTransferValidityConfig() {
		return transferValidityConfig;
	}

	/**
	 * @param transferValidityConfig
	 */
	public void setTransferValidityConfig(HashMap<Integer, ArrayList<TransferValidity>> transferValidityConfig) {
		this.transferValidityConfig = transferValidityConfig;
	}

	/**
	 * @return {@link #subTypeSource}
	 */
	public String getSubTypeSource() {
		return subTypeSource;
	}

	/**
	 * @param subTypeSource
	 */
	public void setSubTypeSource(String subTypeSource) {
		this.subTypeSource = subTypeSource;
	}

	/**
	 * @return {@link #hlrIP}
	 */
	public String getHlrIP() {
		return hlrIP;
	}

	/**
	 * @param hlrIP
	 */
	public void setHlrIP(String hlrIP) {
		this.hlrIP = hlrIP;
	}

	/**
	 * @return {@link #hlrPort}
	 */
	public short getHlrPort() {
		return hlrPort;
	}

	/**
	 * @param hlrPort
	 */
	public void setHlrPort(short hlrPort) {
		this.hlrPort = hlrPort;
	}

	/**
	 * @return {@link #chargingTestingEnable}
	 */
	public boolean isChargingTestingEnable() {
		return chargingTestingEnable;
	}

	/**
	 * @param chargingTestingEnable
	 */
	public void setChargingTestingEnable(boolean chargingTestingEnable) {
		this.chargingTestingEnable = chargingTestingEnable;
	}

	/**
	 * @return {@link #hlrTimeout}
	 */
	public int getHlrTimeout() {
		return hlrTimeout;
	}

	/**
	 * @param hlrTimeout
	 */
	public void setHlrTimeout(int hlrTimeout) {
		this.hlrTimeout = hlrTimeout;
	}

	/**
	 * @return {@link #prevOptionOnPackDescEnable}
	 */
	public boolean isPrevOptionOnPackDescEnable() {
		return prevOptionOnPackDescEnable;
	}

	/**
	 * @param prevOptionOnPackDescEnable
	 */
	public void setPrevOptionOnPackDescEnable(boolean prevOptionOnPackDescEnable) {
		this.prevOptionOnPackDescEnable = prevOptionOnPackDescEnable;
	}

	/**
	 * @return {@link #tttProductCode}
	 */
	public String getTttProductCode() {
		return tttProductCode;
	}

	/**
	 * @param tttProductCode
	 */
	public void setTttProductCode(String tttProductCode) {
		this.tttProductCode = tttProductCode;
	}

	/**
	 * @return {@link #testingBalance}
	 */
	public double getTestingBalance() {
		return testingBalance;
	}

	/**
	 * @param testingBalance
	 */
	public void setTestingBalance(double testingBalance) {
		this.testingBalance = testingBalance;
	}

	/**
	 * @return {@link #tttMaxLimit}
	 */
	public int getTttMaxLimit() {
		return tttMaxLimit;
	}

	/**
	 * @param tttMaxLimit
	 */
	public void setTttMaxLimit(int tttMaxLimit) {
		this.tttMaxLimit = tttMaxLimit;
	}

	/**
	 * @return {@link #smsOriginationNumberB}
	 */
	public String getSmsOriginationNumberB() {
		return smsOriginationNumberB;
	}

	/**
	 * @param smsOriginationNumberB
	 */
	public void setSmsOriginationNumberB(String smsOriginationNumberB) {
		this.smsOriginationNumberB = smsOriginationNumberB;
	}

	/**
	 * @return {@link #floatValueEnable}
	 */
	public boolean isFloatValueEnable() {
		return floatValueEnable;
	}

	/**
	 * @param floatValueEnable
	 */
	public void setFloatValueEnable(boolean floatValueEnable) {
		this.floatValueEnable = floatValueEnable;
	}

	/**
	 * @return {@link #lbsTemplates}
	 */
	public HashMap<String, String> getLbsTemplates() {
		return lbsTemplates;
	}

	/**
	 * @param lbsTemplates
	 */
	public void setLbsTemplates(HashMap<String, String> lbsTemplates) {
		this.lbsTemplates = lbsTemplates;
	}

	/**
	 * @return {@link #availablePackTypeIDs}
	 */
	public HashMap<String, Integer> getAvailablePackTypeIDs() {
		return availablePackTypeIDs;
	}

	/**
	 * @param availablePackTypeIDs
	 */
	public void setAvailablePackTypeIDs(HashMap<String, Integer> availablePackTypeIDs) {
		this.availablePackTypeIDs = availablePackTypeIDs;
	}

	/**
	 * @return {@link #virtualCodeMappedDetails}
	 */
	public HashMap<Integer, VirtualCodeMapping> getVirtualCodeMappedDetails() {
		return virtualCodeMappedDetails;
	}

	/**
	 * @param virtualCodeMappedDetails
	 */
	public void setVirtualCodeMappedDetails(HashMap<Integer, VirtualCodeMapping> virtualCodeMappedDetails) {
		this.virtualCodeMappedDetails = virtualCodeMappedDetails;
	}

	/**
	 * @return {@link #shortCodeMappedDetails}
	 */
	public HashMap<String, ShortCodeMapping> getShortCodeMappedDetails() {
		return shortCodeMappedDetails;
	}

	/**
	 * @param shortCodeMappedDetails
	 */
	public void setShortCodeMappedDetails(HashMap<String, ShortCodeMapping> shortCodeMappedDetails) {
		this.shortCodeMappedDetails = shortCodeMappedDetails;
	}

	/**
	 * 
	 * @param key this is the combination of menu name and language ID of user
	 *            concatenated with underscore (_)
	 * @return the menu string based on passed key else default value
	 */
	public String getUssdMenuString(String key) {
		if (ussdMenuDetailsMap.get(key) == null) {
			logger.warn(TSSJavaUtil.getLogInitial("00210") + " >> No menu found for key [" + key + "]");
			return UssdMenuNames.DEFAULT_MENU_STRING;
		} else
			logger.info("The USSD menu return string key is [" + key + "] and value is [" + ussdMenuDetailsMap.get(key)
					+ "]");
		return ussdMenuDetailsMap.get(key);
	}

	/**
	 * Used to get pack id based on pack type name
	 * 
	 * @param packTypeName name of pack type
	 * @return packTypeId based on the pack type name passed
	 */
	public int getPackTypeId(String packTypeName) {
		return availablePackTypeIDs.get(packTypeName);
	}

	/**
	 * Used to return product code of a pack
	 * 
	 * @param packId unique ID of pack
	 * @return product code of the pack
	 */
	public String getProductCode(int packId) {
		if (srvcChargeDetails.get(packId) != null)
			return srvcChargeDetails.get(packId).getProductCode();
		logger.warn(TSSJavaUtil.getLogInitial("00211") + " >> product code not found in cache for this pack id ["
				+ packId + "] " + "so returning NA");
		return "NA";
	}

	/**
	 * Used to return service charge details of a pack
	 * 
	 * @param packId unique ID of pack
	 * @return service charge details of the given pack ID
	 */
	public ServiceCharge getServiceChargeDetails(int packId) {
		return srvcChargeDetails.get(packId);
	}

	/**
	 * Used to return validity days based on pack type and volume. packTypeId
	 * (unique id of a pack type), volume (volume requested to transfer)
	 * 
	 * @param packTypeId
	 * @param volume
	 * @author SIDDHARTH
	 * @return validity days
	 */
	public int getTransferValidityDays(int packTypeId, int volume) {
		int result = -1;
		try {
			ArrayList<TransferValidity> list = transferValidityConfig.get(packTypeId);
			if (list != null) {
				for (int i = 0; i < list.size(); i++) {
					if (volume >= list.get(i).getMinVolume() && volume <= list.get(i).getMaxVolume()) {
						logger.info("Validity Days found [" + list.get(i).getValidityDays() + "] for volume [" + volume
								+ "]");
						return list.get(i).getValidityDays();
					}
				}
			}
		} catch (Exception e) {
			logger.error("Excepiton while getting validity days for (DMC-AB) Macro Data Credit Service where packType["
					+ packTypeId + "] volume[" + volume + "]. Excepiton: " + e.getMessage());
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * Used to return message from lbs templates
	 * 
	 * @param key combination of template ID and language of user
	 * @return SMS template message
	 */
	public String getLbsTemplateMessage(String key) {
		if (this.lbsTemplates == null) {
			logger.warn(TSSJavaUtil.getLogInitial("00212") + "lbs templates cache is null");
			return null;
		}
		return this.lbsTemplates.get(key);
	}

	/**
	 * Used to get pack description based on pack type ID
	 * 
	 * @param packTypeID unique ID of pack type
	 * @return description of pack type
	 */
	public String getPackTypeDescription(int packTypeID) {
		if (this.availablePackTypes == null) {
			logger.warn(TSSJavaUtil.getLogInitial("00213") + "no pack types are found in cache so returning blank");
			return "";
		}
		if (this.availablePackTypes.get(packTypeID) != null) {
			return this.availablePackTypes.get(packTypeID);
		}
		logger.warn(TSSJavaUtil.getLogInitial("00214")
				+ "no pack types description is found in cache for pack type ID [" + packTypeID + "]");
		return "";
	}

	public int getTransactionCdrLimit() {
		return transactionCdrLimit;
	}

	public void setTransactionCdrLimit(int transactionCdrLimit) {
		this.transactionCdrLimit = transactionCdrLimit;
	}

	public int getActivePlanViewLimit() {
		return activePlanViewLimit;
	}

	public void setActivePlanViewLimit(int activePlanViewLimit) {
		this.activePlanViewLimit = activePlanViewLimit;
	}

	public HashMap<String, ArrayList<PackBean>> getAvailableLowBalancePacksMap() {
		return availableLowBalancePacksMap;
	}

	public void setAvailableLowBalancePacksMap(HashMap<String, ArrayList<PackBean>> availableLowBalancePacksMap) {
		this.availableLowBalancePacksMap = availableLowBalancePacksMap;
	}

	public HashMap<String,String> getErrorCodesMenuMap() {
		return errorCodesMenuMap;
	}

	public void setErrorCodesMenuMap(HashMap<String,String> errorCodesMenuMap) {
		this.errorCodesMenuMap = errorCodesMenuMap;
	}

	public boolean isLowBalancePackBasedOnBalanceEnable() {
		return LowBalancePackBasedOnBalanceEnable;
	}

	public void setLowBalancePackBasedOnBalanceEnable(boolean lowBalancePackBasedOnBalanceEnable) {
		LowBalancePackBasedOnBalanceEnable = lowBalancePackBasedOnBalanceEnable;
	}

	public HashMap<Integer, Integer> getAvailablePackTypeParallelEnableMap() {
		return availablePackTypeParallelEnableMap;
	}

	public void setAvailablePackTypeParallelEnableMap(HashMap<Integer, Integer> availablePackTypeParallelEnable) {
		this.availablePackTypeParallelEnableMap = availablePackTypeParallelEnable;
	}

	public String getIvrPackPromptBasePath() {
		return ivrPackPromptBasePath;
	}

	public void setIvrPackPromptBasePath(String ivrPackPromptBasePath) {
		this.ivrPackPromptBasePath = ivrPackPromptBasePath;
	}

	public byte getEnabledTestChargingResult() {
		return enabledTestChargingResult;
	}

	public void setEnabledTestChargingResult(byte enabledTestChargingResult) {
		this.enabledTestChargingResult = enabledTestChargingResult;
	}

	public HashMap<String, ArrayList<PackTypeBean>> getAvailablePackTypeMap() {
		return availablePackTypeMap;
	}

	public void setAvailablePackTypeMap(HashMap<String, ArrayList<PackTypeBean>> availablePackTypeMap) {
		this.availablePackTypeMap = availablePackTypeMap;
	}

	public HashMap<Integer, PackTypeBean> getPackTypeDetailsMap() {
		return packTypeDetailsMap;
	}

	public void setPackTypeDetailsMap(HashMap<Integer, PackTypeBean> packTypeDetailsMap) {
		this.packTypeDetailsMap = packTypeDetailsMap;
	}

	/**
	 * @return the dataBaseType
	 */
	public byte getDataBaseType() {
		return dataBaseType;
	}

	/**
	 * @param dataBaseType the dataBaseType to set
	 */
	public void setDataBaseType(byte dataBaseType) {
		this.dataBaseType = dataBaseType;
	}

	/**
	 * @return the fallBackEnable
	 */
	public byte getFallBackEnable() {
		return fallBackEnable;
	}

	/**
	 * @param fallBackEnable the fallBackEnable to set
	 */
	public void setFallBackEnable(byte fallBackEnable) {
		this.fallBackEnable = fallBackEnable;
	}

	/**
	 * @return the showBalanceInLowBalanceMsg
	 */
	public byte getShowBalanceInLowBalanceMsg() {
		return showBalanceInLowBalanceMsg;
	}

	/**
	 * @param showBalanceInLowBalanceMsg the showBalanceInLowBalanceMsg to set
	 */
	public void setShowBalanceInLowBalanceMsg(byte showBalanceInLowBalanceMsg) {
		this.showBalanceInLowBalanceMsg = showBalanceInLowBalanceMsg;
	}

	/**
	 * @return the callArchiveFileInterval
	 */
	public byte getCallArchiveFileInterval() {
		return callArchiveFileInterval;
	}

	/**
	 * @param callArchiveFileInterval the callArchiveFileInterval to set
	 */
	public void setCallArchiveFileInterval(byte callArchiveFileInterval) {
		this.callArchiveFileInterval = callArchiveFileInterval;
	}

	/**
	 * @return the archiveFileExtension
	 */
	public String getArchiveFileExtension() {
		return archiveFileExtension;
	}

	/**
	 * @param archiveFileExtension the archiveFileExtension to set
	 */
	public void setArchiveFileExtension(String archiveFileExtension) {
		this.archiveFileExtension = archiveFileExtension;
	}

	/**
	 * @return the appConfigParamMap
	 */
	public HashMap<String, String> getAppConfigParamMap() {
		return appConfigParamMap;
	}

	/**
	 * @param appConfigParamMap the appConfigParamMap to set
	 */
	public void setAppConfigParamMap(HashMap<String, String> appConfigParamMap) {
		this.appConfigParamMap = appConfigParamMap;
	}

	/**
	 * @return the maxIdleTime
	 */
	public int getMaxIdleTime() {
		return maxIdleTime;
	}

	/**
	 * @param maxIdleTime the maxIdleTime to set
	 */
	public void setMaxIdleTime(int maxIdleTime) {
		this.maxIdleTime = maxIdleTime;
	}

	/**
	 * @return the serviceActionDetailMap
	 */
	public Map<Integer, String> getServiceActionDetailMap() {
		return serviceActionDetailMap;
	}

	/**
	 * @param serviceActionDetailMap the serviceActionDetailMap to set
	 */
	public void setServiceActionDetailMap(Map<Integer, String> serviceActionDetailMap) {
		this.serviceActionDetailMap = serviceActionDetailMap;
	}

	/**
	 * @return the checkDataBlanceDateFormat
	 */
	public String getCheckDataBlanceDateFormat() {
		return checkDataBlanceDateFormat;
	}

	/**
	 * @param checkDataBlanceDateFormat the checkDataBlanceDateFormat to set
	 */
	public void setCheckDataBlanceDateFormat(String checkDataBlanceDateFormat) {
		this.checkDataBlanceDateFormat = checkDataBlanceDateFormat;
	}

	/**
	 * @return the dmcAbConversionConfigList
	 */
	public ArrayList<DmcConversionConfig> getDmcAbConversionConfigList() {
		return dmcAbConversionConfigList;
	}

	/**
	 * @param dmcAbConversionConfigList the dmcAbConversionConfigList to set
	 */
	public void setDmcAbConversionConfigList(ArrayList<DmcConversionConfig> dmcAbConversionConfigList) {
		this.dmcAbConversionConfigList = dmcAbConversionConfigList;
	}

	/**
	 * @return the dmcVbConversionConfigList
	 */
	public ArrayList<DmcConversionConfig> getDmcVbConversionConfigList() {
		return dmcVbConversionConfigList;
	}

	/**
	 * @param dmcVbConversionConfigList the dmcVbConversionConfigList to set
	 */
	public void setDmcVbConversionConfigList(ArrayList<DmcConversionConfig> dmcVbConversionConfigList) {
		this.dmcVbConversionConfigList = dmcVbConversionConfigList;
	}

	/**
	 * This is an overridden method and is used to return the value of all the
	 * parameters of this class so that while printing the value of the object of
	 * this class it prints the values of the parameters
	 * 
	 * @return all the variables and theirs values of the object of this class
	 */
	@Override
	public String toString() {
		return "CachedParameters [dbDriver=" + dbDriver + ", dbURL=" + dbURL + ", dbUsername=" + dbUsername
				+ ", dbPassword=" + dbPassword + ", dbMinPoolSize=" + dbMinPoolSize + ", dbMaxPoolSize=" + dbMaxPoolSize
				+ ", dbAccomodation=" + dbAccomodation + ", defaultLangId=" + defaultLangId + ", msisdnRangeList="
				+ msisdnRangeList + ", availablePacksMap=" + availablePacksMap + ", availableLowBalancePacksMap="
				+ availableLowBalancePacksMap + ", packBasedOnBalanceEnable=" + packBasedOnBalanceEnable
				+ ", LowBalancePackBasedOnBalanceEnable=" + LowBalancePackBasedOnBalanceEnable
				+ ", maxUssdStringLength=" + maxUssdStringLength + ", maxMenus=" + maxMenus + ", ivrMaxActivePlan="
				+ ivrMaxActivePlan + ", ussdMenuDetailsMap=" + ussdMenuDetailsMap + ", whiteListingEnable="
				+ whiteListingEnable + ", whiteListedMSISDNs=" + whiteListedMSISDNs + ", blackListedMSISDNs="
				+ blackListedMSISDNs + ", dbLogOnCheckProfileEnable=" + dbLogOnCheckProfileEnable
				+ ", availablePackTypes=" + availablePackTypes + ", availablePackTypeIDs=" + availablePackTypeIDs
				+ ", availablePackTypeParallelEnableMap=" + availablePackTypeParallelEnableMap + ", srvcChargeDetails="
				+ srvcChargeDetails + ", virtualCodeMappedDetails=" + virtualCodeMappedDetails
				+ ", shortCodeMappedDetails=" + shortCodeMappedDetails + ", transferValidityConfig="
				+ transferValidityConfig + ", subTypeSource=" + subTypeSource + ", hlrIP=" + hlrIP + ", hlrPort="
				+ hlrPort + ", chargingTestingEnable=" + chargingTestingEnable + ", hlrTimeout=" + hlrTimeout
				+ ", tttServiceChargeOnNet=" + tttServiceChargeOnNet + ", tttServiceChargeOffNet="
				+ tttServiceChargeOffNet + ", prevOptionOnPackDescEnable=" + prevOptionOnPackDescEnable
				+ ", tttProductCode=" + tttProductCode + ", testingBalance=" + testingBalance + ", tttMaxLimit="
				+ tttMaxLimit + ", floatValueEnable=" + floatValueEnable + ", smsOrigNumPrefixB=" + smsOrigNumPrefixB
				+ ", interfaceForTTTransferA=" + interfaceForTTTransferA + ", interfaceForTTTransferB="
				+ interfaceForTTTransferB + ", interfaceForBonusA=" + interfaceForBonusA + ", interfaceForBonusB="
				+ interfaceForBonusB + ", interfaceForDataTransferA=" + interfaceForDataTransferA
				+ ", interfaceForDataTransferB=" + interfaceForDataTransferB + ", smsOriginationNumberB="
				+ smsOriginationNumberB + ", smsOrigNumberTTTA=" + smsOrigNumberTTTA + ", smsOrigNumberBonusA="
				+ smsOrigNumberBonusA + ", smsOrigNumberDataTransferA=" + smsOrigNumberDataTransferA + ", lbsTemplates="
				+ lbsTemplates + ", transactionCdrLimit=" + transactionCdrLimit + ", activePlanViewLimit="
				+ activePlanViewLimit + ", ivrBasePath=" + ivrBasePath + ", ivrPackPromptBasePath="
				+ ivrPackPromptBasePath + ", maxIvrMenu=" + maxIvrMenu + ", isPreviousEnableIvr=" + isPreviousEnableIvr
				+ ", isPrevOptionOnPackDescriptionEnableIvr=" + isPrevOptionOnPackDescriptionEnableIvr
				+ ", invalidFmsisdnBtIvrPromptEnable=" + invalidFmsisdnBtIvrPromptEnable + ", availablePackTypeMap="
				+ availablePackTypeMap + ", fmsisdnNotInRangeBtIvrPrmptEnable=" + fmsisdnNotInRangeBtIvrPrmptEnable
				+ ", enabledTestChargingResult=" + enabledTestChargingResult + ", dataBaseType=" + dataBaseType
				+ ", fallBackEnable=" + fallBackEnable + ", showBalanceInLowBalanceMsg=" + showBalanceInLowBalanceMsg
				+ ", packTypeDetailsMap=" + packTypeDetailsMap + ", callArchiveFileInterval=" + callArchiveFileInterval
				+ ", callLogFileName=" + callLogFileName + ", callLogFilePath=" + callLogFilePath
				+ ", callArchiveFilePath=" + callArchiveFilePath + ", callArchiveFileName=" + callArchiveFileName
				+ ", archiveFileExtension=" + archiveFileExtension + ", maxIdleTime=" + maxIdleTime
				+ ", appConfigParamMap=" + appConfigParamMap + ", serviceActionDetailMap=" + serviceActionDetailMap
				+ ", dmcAbConversionConfigList=" + dmcAbConversionConfigList + ", dmcVbConversionConfigList="
				+ dmcVbConversionConfigList + ", packDetailConfigMap=" + packDetailConfigMap + ", dmcAllowedSubType="
				+ dmcAllowedSubType + ", checkServiceBlanceAllowedSubType=" + checkServiceBlanceAllowedSubType
				+ ", checkDataBalanceNumAllowedAfterDec=" + checkDataBalanceNumAllowedAfterDec
				+ ", isCheckDataBalanceFloatEnable=" + isCheckDataBalanceFloatEnable + ", maxActiveDataAccMenus="
				+ maxActiveDataAccMenus + ", checkDataBlanceDateFormat=" + checkDataBlanceDateFormat
				+ ", unlimitedDataAccountTypes=" + unlimitedDataAccountTypes + ", mysqlSequenceGeneratedFromSeqTable="
				+ mysqlSequenceGeneratedFromSeqTable + ", showPromotionPacksBasedOnBalance="
				+ showPromotionPacksBasedOnBalance + ", promoPackDetailsMap=" + promoPackDetailsMap
				+ "] isDiameterChargingEnable [" + isDiameterChargingEnable + "]";
	}

}