/**
 * @author MoHit
 * Created on - 10 Feb, 2017
 */
package com.telemune.marketplace.beans.response;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAttribute;

/**
 * @author MoHit
 * This is a bean class and is used to hold the variable and 
 * its value these variables are send in the response
 */
public class VariableAndValue implements Serializable 
{
	private static final long serialVersionUID = 1L; 

	/**
	 * This parameters is used to hold the name of the variable
	 */
	private String name;
	/**
	 * This parameters is used to hold the value of the variable
	 */
	private String value;
	
	/**
	 * Default constructor
	 * Does nothing
	 */
	public VariableAndValue(){} 

	/**
	 * Used to initialize all the parameters
	 * @param name
	 * @param value
	 */
	public VariableAndValue(String name, String value){
		this.name = name; 
		this.value = value; 
	}
	
	@XmlAttribute
	/**
	 * @return {@link #name}
	 */
	public String getName() { 
		return name; 
	} 
	
	/**
	 * @param name
	 */
	public void setName(String name) { 
		this.name = name; 
	}
	
	@XmlAttribute
	/**
	 * @return {@link #value}
	 */
	public String getValue() { 
		return value; 
	} 
	
	/**
	 * @param value
	 */
	public void setValue(String value) { 
		this.value = value; 
	}

	@Override
	/**
	 * This is an overridden method and is used to return the value of
	 * all the parameters of this class so that while printing the value of
	 * the object of this class it prints the values of the parameters
	 * @return all the variables and theirs values of the object of this class
	 */
	public String toString() {
		return "Var [name=" + name + ", value=" + value + "]";
	}
	
	
} 
