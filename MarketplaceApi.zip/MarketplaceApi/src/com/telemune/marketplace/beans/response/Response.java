/**
 * @author MoHit
 * Created on - 10 Feb, 2017
 */
package com.telemune.marketplace.beans.response;

import java.io.Serializable;
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="response")
/**
 * @author MoHit
 * This is a bean class and is used to hold the data that is to be sent as response
 */
public class Response implements Serializable 
{
	private static final long serialVersionUID = 1L;

	/**
	 * This is the variable that holds list of the beans containing variable and its value
	 * that we'll send in response
	 */
	private ArrayList<VariableAndValue> variableList = null;

	/**
	 * Default constructor
	 * Does nothing
	 */
	public Response(){}
	
	/**
	 * @param variableList
	 */
	public Response(ArrayList<VariableAndValue> variableList) {
		super();
		this.variableList = variableList;
	}
	
	/**
	 * @return {@link #variableList}
	 */
	@XmlElement(name="var")
	public ArrayList<VariableAndValue> getVariableList() {
		return variableList;
	}

	/**
	 * @param variableList
	 */
	public void setVariableList(ArrayList<VariableAndValue> variableList) {
		this.variableList = variableList;
	}

	@Override
	/**
	 * This is an overridden method and is used to return the value of
	 * all the parameters of this class so that while printing the value of
	 * the object of this class it prints the values of the parameters
	 * @return all the variables and theirs values of the object of this class
	 */
	public String toString() {
		return "Response [variableList=" + variableList + "]";
	}
	
}
