package com.telemune.marketplace.beans;

/**
 * This class is used to hold the Promotion Packs Details.
 * 
 * @author SIDDHARTH SINGH RAWAT
 *
 */
public class PromoPackBean {

	/**
	 * Used to hold the unique ID of this promotional pack
	 */
	private int packId = -99;

	/**
	 * Used to hold the product code of this promotional pack
	 */
	private String prductCode = "NA";

	/**
	 * Used to hold the immediate category id under which this pack exists.
	 */
	private int packType = -1;

	/**
	 * Used to hold the supported language id
	 */
	private byte languageId = 1;

	/**
	 * Used to hold the subscription type for which this pack applicable
	 */
	private String subType = "P";

	/**
	 * Used to hold the current status of promotional pack A : For Active I :
	 * Inactive
	 */
	private String status = "I";

	/**
	 * Used to hold the details of promotion packs in json format
	 */
	private String other = "{}";

	/**
	 * It is used to hold the promotion packs details
	 */
	private PromotionPackOtherDetails promotionPackOtherDetails;

	/**
	 * @return the packId
	 */
	public int getPackId() {
		return packId;
	}

	/**
	 * @param packId
	 *            the packId to set
	 */
	public void setPackId(int packId) {
		this.packId = packId;
	}

	/**
	 * @return the prductCode
	 */
	public String getPrductCode() {
		return prductCode;
	}

	/**
	 * @param prductCode
	 *            the prductCode to set
	 */
	public void setPrductCode(String prductCode) {
		this.prductCode = prductCode;
	}

	/**
	 * @return the packType
	 */
	public int getPackType() {
		return packType;
	}

	/**
	 * @param packType
	 *            the packType to set
	 */
	public void setPackType(int packType) {
		this.packType = packType;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the promotionPackOtherDetails
	 */
	public PromotionPackOtherDetails getPromotionPackOtherDetails() {
		return promotionPackOtherDetails;
	}

	/**
	 * @param promotionPackOtherDetails
	 *            the promotionPackOtherDetails to set
	 */
	public void setPromotionPackOtherDetails(PromotionPackOtherDetails promotionPackOtherDetails) {
		this.promotionPackOtherDetails = promotionPackOtherDetails;
	}

	/**
	 * @return the languageId
	 */
	public byte getLanguageId() {
		return languageId;
	}

	/**
	 * @param languageId
	 *            the languageId to set
	 */
	public void setLanguageId(byte languageId) {
		this.languageId = languageId;
	}

	/**
	 * @return the subType
	 */
	public String getSubType() {
		return subType;
	}

	/**
	 * @param subType
	 *            the subType to set
	 */
	public void setSubType(String subType) {
		this.subType = subType;
	}

	/**
	 * @return the other
	 */
	public String getOther() {
		return other;
	}

	/**
	 * @param other
	 *            the other to set
	 */
	public void setOther(String other) {
		this.other = other;
	}

	@Override
	public String toString() {
		return "PromoPackBean [packId=" + packId + ", prductCode=" + prductCode + ", packType=" + packType
				+ ", languageId=" + languageId + ", subType=" + subType + ", status=" + status + ", other=" + other
				+ ", promotionPackOtherDetails=" + promotionPackOtherDetails + "]";
	}

}
