/**
 *  Created on - 17 Jan, 2018
 * 	@author AbhiShek Rana
 */
package com.telemune.marketplace.manager;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;

import com.telemune.marketplace.beans.UserDataBean;
import com.telemune.marketplace.beans.UserPackPurchaseBean;
import com.telemune.marketplace.beans.UserProfileBean;
import com.telemune.marketplace.beans.UserTransactionBean;
import com.telemune.marketplace.db.DBOperations;
import com.telemune.marketplace.util.CodeStatus;
import com.telemune.marketplace.util.IvrMenu;
import com.telemune.marketplace.util.ResponseParameters;
import com.telemune.marketplace.util.TSSJavaUtil;
import com.telemune.marketplace.util.UssdMenuNames;

public class UserManager {

	private static Logger logger = Logger.getLogger(UserManager.class);

	List<UserPackPurchaseBean> contestList = null;

	public CodeStatus getUserProfile(UserDataBean userDataBean, UserProfileBean profileBean) {
		logger.info(
				" [" + userDataBean.getRequestId() + "]>> Loading User Profile. UserDataBean [" + userDataBean + "]");
		CodeStatus status = new DBOperations().new UserProfile().getUserCompleteProfile(userDataBean, profileBean);
		StringBuffer stringBuffer = new StringBuffer();
		if (CodeStatus.SUCCESS.equals(status)) {
			stringBuffer.append(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.MESSAGE_HEADER_LAST_VISIT + "_" + userDataBean.getLangId())
					+ this.getFormattedDate(profileBean.getLast_Visit_Time(), userDataBean.getLangId()));
			userDataBean.setFilePath(stringBuffer.toString());
			userDataBean.setResult(ResponseParameters.SUCCESS);
			return CodeStatus.SUCCESS;
		} else {
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		}
	}

	public CodeStatus getUserActivePlan(UserDataBean userDataBean, UserPackPurchaseBean profileBean) {
		logger.info(" [" + userDataBean.getRequestId() + "]>> Loading User Active Plans. UserProfileBean ["
				+ userDataBean + "]");

		ArrayList<UserPackPurchaseBean> purchaseList = new ArrayList<UserPackPurchaseBean>();
		CodeStatus status = new DBOperations().new UserProfile().getUserActivePlan(userDataBean, purchaseList);
		StringBuffer stringBuffer = new StringBuffer();
		if (CodeStatus.SUCCESS.equals(status)) {
			for (int i = 0; i < purchaseList.size(); i++) {
				stringBuffer.append(purchaseList.get(i).getPack_Name()
						+ TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
								UssdMenuNames.MESSAGE_HEADER_VALID_TILL + "_" + userDataBean.getLangId())
						+ this.getFormattedDate(purchaseList.get(i).getExpiry_Date(), userDataBean.getLangId()));
				stringBuffer.append("!");
			}
			userDataBean.setFilePath(this.getAvailableData(userDataBean, stringBuffer, "ACTIVEPLAN"));
			userDataBean.setResult(ResponseParameters.SUCCESS);
			return CodeStatus.SUCCESS;
		} else if (CodeStatus.EXCEPTION_OCCURED.equals(status)) {
			stringBuffer.append(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setFilePath(stringBuffer.toString());
			userDataBean.setResult(ResponseParameters.FAILURE);
			return CodeStatus.FAILURE;
		} else {
			stringBuffer.append(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.NO_ACTIVE_PLAN_AVAILABLE + "_" + userDataBean.getLangId()));
			userDataBean.setFilePath(stringBuffer.toString());
			userDataBean.setResult(ResponseParameters.FAILURE);
			return CodeStatus.FAILURE;
		}
	}

	public CodeStatus getUserLastTransaction(UserDataBean userDataBean, UserTransactionBean transactionBean) {
		logger.info(" [" + userDataBean.getRequestId() + "]>> Loading User Last Transaction. UserProfileBean ["
				+ userDataBean + "]");
		ArrayList<UserTransactionBean> transactionList = new ArrayList<UserTransactionBean>();
		CodeStatus status = new DBOperations().new UserProfile().getUserTransaction(userDataBean, transactionList);

		StringBuffer stringBuffer = new StringBuffer();
		if (CodeStatus.SUCCESS.equals(status)) {
			for (int i = 0; i < transactionList.size(); i++) {
				stringBuffer.append(transactionList.get(i).getTransaction_Message() + " - "
						+ transactionList.get(i).getPack_Name() + " on "
						+ this.getFormattedDate(transactionList.get(i).getCreate_date(), userDataBean.getLangId()));
				stringBuffer.append("!");
			}
			userDataBean.setFilePath(this.getAvailableData(userDataBean, stringBuffer, "CDR"));
			userDataBean.setResult(ResponseParameters.SUCCESS);
			return CodeStatus.SUCCESS;
		} else if (CodeStatus.EXCEPTION_OCCURED.equals(status)) {
			stringBuffer.append(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setFilePath(stringBuffer.toString());
			userDataBean.setResult(ResponseParameters.FAILURE);
			return CodeStatus.FAILURE;
		} else {
			stringBuffer.append(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.NO_TRANSACTION_HEADER + "_" + userDataBean.getLangId()));
			userDataBean.setFilePath(stringBuffer.toString());
			userDataBean.setResult(ResponseParameters.FAILURE);
			return CodeStatus.FAILURE;
		}
	}

	public String getFormattedDate(String lastVisitTime, Byte langId) {
		String formattedDate = "";
		try {
			SimpleDateFormat currFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat dateFormat;

			if (langId == 1)
				dateFormat = new SimpleDateFormat("dd MMM yyyy HH:mm:ss", new Locale("fr", "FR"));
			else
				dateFormat = new SimpleDateFormat("dd MMM yyyy HH:mm:ss");
			Date d1 = null;
			d1 = currFormat.parse(lastVisitTime);
			formattedDate = dateFormat.format(d1);
		} catch (Exception e) {
			logger.error("Exception while converting date in desired format" + e.getMessage());
		}
		return formattedDate;
	}

	public String getAvailableData(UserDataBean userDataBean, StringBuffer stringBuffer, String type) {

		String spilittedData[] = stringBuffer.toString().split("!");
		StringBuffer finalData = new StringBuffer();
		int prevIndex = -1;
		int nextIndex = -1;
		String prevData = "";
		String nextData = "";
		int maxLength = 0;

		int maxMenu = TSSJavaUtil.instance().getCacheParameters().getActivePlanViewLimit();
		String menuHeader = "";
		if (type.equalsIgnoreCase("ACTIVEPLAN")) {
			maxLength = TSSJavaUtil.instance().getCacheParameters().getMaxUssdStringLength() - TSSJavaUtil.instance()
					.getCacheParameters()
					.getUssdMenuString(UssdMenuNames.ACTIVE_PLAN_HEADER + "_" + userDataBean.getLangId()).length() - 2;
			menuHeader = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.ACTIVE_PLAN_HEADER + "_" + userDataBean.getLangId()) + "\n";
		} else if (type.equalsIgnoreCase("CDR")) {
			maxLength = TSSJavaUtil.instance().getCacheParameters().getMaxUssdStringLength() - TSSJavaUtil.instance()
					.getCacheParameters()
					.getUssdMenuString(UssdMenuNames.TRANSACTION_HEADER + "_" + userDataBean.getLangId()).length() - 2;
			menuHeader = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.TRANSACTION_HEADER + "_" + userDataBean.getLangId()) + "\n";
		}
		// First Request
		if (Integer.parseInt(userDataBean.getPrevIndex()) == -1 && userDataBean.getIndex().equals("N")) {
			logger.info(
					"[" + userDataBean.getRequestId() + "] Next request getting information [" + type + "] PrevIndex ["
							+ userDataBean.getPrevIndex() + "] " + "NextIndex[" + userDataBean.getNextIndex() + "] ");
			nextData = menuHeader;
			prevData = nextData;
			int count = 0;
			for (int i = 0; i < spilittedData.length; i++) {
				count++;
				nextData += count + "." + spilittedData[i] + "\n";

				logger.debug(userDataBean.getRequestId() + " and MSISDN:[" + userDataBean.getMsisdn()
						+ "] Data to process FIRST REQUEST (nextData) :[" + nextData.toString() + "] count:[" + count
						+ "] DataLength:[" + nextData.length() + "] maxLength:[" + maxLength + "] maxMenu:[" + maxMenu
						+ "] prevData:[" + prevData.toString() + "] spilittedData:[" + spilittedData[i]
						+ "] spilittedDataLength:[" + spilittedData.length + "]");

				if (nextData.length() >= maxLength || count > maxMenu) {
					logger.info(userDataBean.getRequestId() + " Configuration of Maximum USSD string length is"
							+ " not proper, Increase length to show Packs to user. MSISDN:[" + userDataBean.getMsisdn()
							+ "]");
					prevIndex = i - 1;
					nextIndex = i;
					if (nextIndex != spilittedData.length)
						userDataBean.setMore("Y");
					break;
				}
				prevIndex = i;
				nextIndex = i + 1;
				prevData = nextData;
			}
			finalData.append(prevData);
			userDataBean.setPrevIndex("" + prevIndex);
			userDataBean.setNextIndex("" + nextIndex);
			logger.info("[" + userDataBean.getRequestId() + "] Final Data [" + finalData.toString()
					+ "] Updated Values : " + "PrevIndex [" + userDataBean.getPrevIndex() + "] NextIndex["
					+ userDataBean.getNextIndex() + "] ");
		}
		// next Request
		else if (Integer.parseInt(userDataBean.getPrevIndex()) != -1
				&& Integer.parseInt(userDataBean.getNextIndex()) != -1 && userDataBean.getIndex().equals("N")) {
			logger.info(
					"[" + userDataBean.getRequestId() + "] Next request getting information [" + type + "] PrevIndex ["
							+ userDataBean.getPrevIndex() + "] " + "NextIndex[" + userDataBean.getNextIndex() + "] ");
			nextData = menuHeader;
			prevData = nextData;
			int count = 0;
			for (int i = Integer.parseInt(userDataBean.getNextIndex()); i < spilittedData.length; i++) {
				count++;
				nextData += count + "." + spilittedData[i] + "\n";
				logger.debug(userDataBean.getRequestId() + " and MSISDN:[" + userDataBean.getMsisdn()
						+ "] Data to process NEXT REQUEST (nextData) :[" + nextData.toString() + "] count:[" + count
						+ "] DataLength:[" + nextData.length() + "] maxLength:[" + maxLength + "] maxMenu:[" + maxMenu
						+ "] prevData:[" + prevData.toString() + "]");
				if (nextData.length() >= maxLength || count > maxMenu) {
					logger.info(userDataBean.getRequestId() + " Configuration of Maximum USSD string length is"
							+ " not proper, Increase length to show Packs to user. MSISDN:[" + userDataBean.getMsisdn()
							+ "]");
					prevIndex = i - 1;
					nextIndex = i;
					if (nextIndex != spilittedData.length)
						userDataBean.setMore("Y");
					break;
				}
				prevIndex = i;
				nextIndex = i + 1;
				prevData = nextData;
			}

			finalData.append(prevData);
			userDataBean.setPrevIndex("" + prevIndex);
			userDataBean.setNextIndex("" + nextIndex);
			logger.info("[" + userDataBean.getRequestId() + "] Final Data [" + finalData.toString()
					+ "] Updated Values : " + "PrevIndex [" + userDataBean.getPrevIndex() + "] NextIndex["
					+ userDataBean.getNextIndex() + "] ");
		} else {
			finalData.append(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
		}
		if (userDataBean.getMore().equals("Y")) {
			finalData.append(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.STRING_NEXT_OPTION_PACKS + "_" + userDataBean.getLangId()));
		}
		return finalData.toString();
	}

	public CodeStatus getUserActivePlanIvr(UserDataBean userDataBean, UserPackPurchaseBean profileBean) {
		logger.info(" [" + userDataBean.getRequestId() + "]>>(IVR) Loading User Active Plans. UserProfileBean ["
				+ userDataBean + "]");

		String ivrBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
		if (ivrBasePath.equalsIgnoreCase("") || ivrBasePath.equalsIgnoreCase("NA") || ivrBasePath == null) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
					+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:[" + userDataBean.getMsisdn()
					+ "].");
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		}
		String ivrPackPromptBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrPackPromptBasePath();
		if (ivrPackPromptBasePath.equalsIgnoreCase("") || ivrPackPromptBasePath.equalsIgnoreCase("NA")
				|| ivrPackPromptBasePath == null) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00325")
					+ " >> (IVR) ivrPackPromptBasePath found is null or Empty or NA for MSISDN:["
					+ userDataBean.getMsisdn() + "].");
			userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		}

		ArrayList<UserPackPurchaseBean> purchaseList = new ArrayList<UserPackPurchaseBean>();
		CodeStatus status = new DBOperations().new UserProfile().getUserActivePlan(userDataBean, purchaseList);
		StringBuffer stringBuffer = new StringBuffer();
		String promptString = "";

		if (CodeStatus.SUCCESS.equals(status)) {
			for (int i = 0; i < purchaseList.size(); i++) {
				if (!purchaseList.get(i).getPromptFilePath().equalsIgnoreCase("NA")
						&& !purchaseList.get(i).getPromptFilePath().equals("")) {
					stringBuffer.append(ivrPackPromptBasePath + userDataBean.getLangId() + File.separator
							+ purchaseList.get(i).getPromptFilePath() + TSSJavaUtil.FileSeparator + ivrBasePath
							+ userDataBean.getLangId() + File.separator + IvrMenu.VALID_TILL_WAV_IVR
							+ TSSJavaUtil.FileSeparator
							+ TSSJavaUtil.instance().getFormattedIvrDate(purchaseList.get(i).getExpiry_Date(),
									ivrBasePath, userDataBean.getLangId())
							+ TSSJavaUtil.FileSeparator);
					stringBuffer.append("#_#");
				} else
					logger.warn(userDataBean.getRequestId() + " --->> (IVR) " + TSSJavaUtil.getLogInitial("00306")
							+ " >> No Prompt File Found for Pack_ID :[" + purchaseList.get(i).getPack_Id()
							+ "] and LanguageId:[" + userDataBean.getLangId() + "]");
			}

			promptString = this.getAvailableIvrData(userDataBean, stringBuffer, ivrBasePath, "ACTIVEPLAN");

			if (promptString.equals("") || promptString == null) {
				return CodeStatus.FAILURE;
			}

			userDataBean.setFilePath(promptString);
			userDataBean.setResult(ResponseParameters.SUCCESS);
			return CodeStatus.SUCCESS;
		} else if (CodeStatus.EXCEPTION_OCCURED.equals(status)) {
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			return CodeStatus.FAILURE;
		} else {
			stringBuffer.append(ivrBasePath + userDataBean.getLangId() + File.separator);
			stringBuffer.append(IvrMenu.NO_ACTIVE_PLAN_AVAILABLE_WAV_IVR);
			userDataBean.setFilePath(stringBuffer.toString());
			userDataBean.setResult(ResponseParameters.FAILURE);
			return CodeStatus.FAILURE;
		}
	}

	public String getAvailableIvrData(UserDataBean userDataBean, StringBuffer promptFilePath, String ivrBasePath,
			String type) {

		if (promptFilePath.length() < 1) {
			logger.warn("(IVR)-->> getAvailableIvrData() -->> promptFile found null/Empty/NA");
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return null;
		}

		String spilittedData[] = promptFilePath.toString().split("#_#");
		StringBuffer finalData = new StringBuffer();
		int prevIndex = -1;
		int nextIndex = -1;

		/*
		 * StringBuffer prevData = new StringBuffer(); StringBuffer nextData = new
		 * StringBuffer();
		 */
		String prevData = "";
		String nextData = "";

		int maxAllowedActivePlans = TSSJavaUtil.instance().getCacheParameters().getIvrMaxActivePlan();
		String menuHeader = "";
		if (type.equalsIgnoreCase("ACTIVEPLAN")) {
			menuHeader = ivrBasePath + userDataBean.getLangId() + File.separator + IvrMenu.ACTIVE_PLAN_HEADER_WAV_IVR
					+ TSSJavaUtil.FileSeparator;
		} else if (type.equalsIgnoreCase("CDR")) {
			menuHeader = ivrBasePath + userDataBean.getLangId() + File.separator + IvrMenu.TRANSACTION_HEADER_WAV_IVR
					+ TSSJavaUtil.FileSeparator;
		}

		try {
			// First Request
			if (Integer.parseInt(userDataBean.getPrevIndex()) == -1 && userDataBean.getIndex().equals("N")) {
				logger.info("[" + userDataBean.getRequestId() + "] Next request getting information [" + type
						+ "] PrevIndex [" + userDataBean.getPrevIndex() + "] " + "NextIndex["
						+ userDataBean.getNextIndex() + "] ");
				nextData = menuHeader;
				prevData = nextData;
				int count = 0;
				for (int i = 0; i < spilittedData.length && count <= maxAllowedActivePlans; i++) {
					count++;
					nextData += spilittedData[i];
					if (count == maxAllowedActivePlans) {
						prevIndex = i - 1;
						nextIndex = i;
						if (nextIndex != spilittedData.length)
							userDataBean.setMore("Y");
						break;
					}
					prevIndex = i;
					nextIndex = i + 1;
					prevData = nextData;
				}
				finalData.append(prevData);
			}
			// next Request
			else if (Integer.parseInt(userDataBean.getPrevIndex()) != -1
					&& Integer.parseInt(userDataBean.getNextIndex()) != -1 && userDataBean.getIndex().equals("N")) {
				logger.info("[" + userDataBean.getRequestId() + "] Next request getting information [" + type
						+ "] PrevIndex [" + userDataBean.getPrevIndex() + "] " + "NextIndex["
						+ userDataBean.getNextIndex() + "] ");
				nextData = menuHeader;
				prevData = nextData;
				int count = 0;
				for (int i = Integer.parseInt(userDataBean.getNextIndex()); i < spilittedData.length
						&& count <= maxAllowedActivePlans; i++) {
					count++;
					nextData += spilittedData[i];
					if (count == maxAllowedActivePlans) {
						prevIndex = i;
						nextIndex = i + 1;
						if (nextIndex != spilittedData.length)
							userDataBean.setMore("Y");
						break;
					}
					prevIndex = i;
					nextIndex = i + 1;
					prevData = nextData;
				}

				finalData.append(nextData);
			} else {
				return null;
			}

			String finalStr = finalData.substring(0, finalData.length() - 1);
			if (userDataBean.getMore().equalsIgnoreCase("Y")) {
				finalStr += TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.NEXT_PACK_WAV_IVR;
			}
			userDataBean.setPrevIndex("" + prevIndex);
			userDataBean.setNextIndex("" + nextIndex);

			logger.info("[" + userDataBean.getRequestId() + "] Final Data [" + finalData.toString()
					+ "] Updated Values : " + "PrevIndex [" + userDataBean.getPrevIndex() + "] NextIndex["
					+ userDataBean.getNextIndex() + "] ");
			return finalStr;

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >>(IVR) Error in fetching user's active plan, MSISDN:[" + userDataBean.getMsisdn()
					+ "]  Error ", npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return null;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00220")
					+ " >> (IVR) Error in fetch user's active plan, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ",
					e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return null;
		}
	}

	public CodeStatus getUserLastTransactionIvr(UserDataBean userDataBean) {
		logger.info(" [" + userDataBean.getRequestId() + "]>>(IVR) Loading User Last Transaction. UserProfileBean ["
				+ userDataBean + "]");

		String ivrBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
		if (ivrBasePath.equalsIgnoreCase("") || ivrBasePath.equalsIgnoreCase("NA") || ivrBasePath == null) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
					+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:[" + userDataBean.getMsisdn()
					+ "].");
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		}
		String ivrPackPromptBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrPackPromptBasePath();
		if (ivrPackPromptBasePath.equalsIgnoreCase("") || ivrPackPromptBasePath.equalsIgnoreCase("NA")
				|| ivrPackPromptBasePath == null) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00325")
					+ " >> (IVR) ivrPackPromptBasePath found is null or Empty or NA for MSISDN:["
					+ userDataBean.getMsisdn() + "].");
			userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		}
		ArrayList<UserTransactionBean> transactionList = new ArrayList<UserTransactionBean>();
		CodeStatus status = new DBOperations().new UserProfile().getUserTransaction(userDataBean, transactionList);

		StringBuffer stringBuffer = new StringBuffer();
		if (CodeStatus.SUCCESS.equals(status)) {
			for (int i = 0; i < transactionList.size(); i++) {
				if (!transactionList.get(i).getPromptFilePath().equalsIgnoreCase("NA")
						&& !transactionList.get(i).getPromptFilePath().equals("")) {

					stringBuffer.append(ivrPackPromptBasePath + userDataBean.getLangId() + File.separator
							+ transactionList.get(i).getPromptFilePath() + TSSJavaUtil.FileSeparator);
					if (transactionList.get(i).getTransaction_Type().trim().equalsIgnoreCase("PP")) {
						stringBuffer.append(ivrBasePath + userDataBean.getLangId() + File.separator
								+ IvrMenu.PP_ON_WAV_IVR + TSSJavaUtil.FileSeparator);
					} else if (transactionList.get(i).getTransaction_Type().trim().equalsIgnoreCase("TT")) {
						stringBuffer.append(ivrBasePath + userDataBean.getLangId() + File.separator
								+ IvrMenu.TTT_ON_WAV_IVR + TSSJavaUtil.FileSeparator);
					} else if (transactionList.get(i).getTransaction_Type().trim().equalsIgnoreCase("BT")) {
						stringBuffer.append(ivrBasePath + userDataBean.getLangId() + File.separator
								+ IvrMenu.BT_ON_WAV_IVR + TSSJavaUtil.FileSeparator);
					} else if (transactionList.get(i).getTransaction_Type().trim().equalsIgnoreCase("DT")) {
						stringBuffer.append(ivrBasePath + userDataBean.getLangId() + File.separator
								+ IvrMenu.DT_ON_WAV_IVR + TSSJavaUtil.FileSeparator);
					} else {
						logger.error(userDataBean.getRequestId()
								+ " >> (IVR) Proper Transaction Type not found. Transaction Type:["
								+ transactionList.get(i).getTransaction_Type() + "] MSISDN:[" + userDataBean.getMsisdn()
								+ "].");
						userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
						userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
						return CodeStatus.FAILURE;
					}
					stringBuffer.append(TSSJavaUtil.instance().getFormattedIvrDate(
							transactionList.get(i).getCreate_date(), ivrBasePath, userDataBean.getLangId()));
					stringBuffer.append("#_#");

				} else
					logger.warn(userDataBean.getRequestId() + " --->> (IVR) " + TSSJavaUtil.getLogInitial("00306")
							+ " >> No Prompt File Found for Pack_ID :[" + transactionList.get(i).getPack_Id()
							+ "] and LanguageId:[" + userDataBean.getLangId() + "]");

			}

			String promptString = this.getAvailableIvrData(userDataBean, stringBuffer, ivrBasePath, "CDR");

			if (promptString.equals("") || promptString == null) {
				return CodeStatus.FAILURE;
			}

			userDataBean.setFilePath(promptString);
			userDataBean.setResult(ResponseParameters.SUCCESS);
			return CodeStatus.SUCCESS;
		} else if (CodeStatus.EXCEPTION_OCCURED.equals(status)) {
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			return CodeStatus.FAILURE;
		} else {
			String promptFilePath = ivrBasePath + userDataBean.getLangId() + File.separator
					+ IvrMenu.NO_TRANSACTION_HEADER_WAV_IVR;
			userDataBean.setFilePath(promptFilePath);
			userDataBean.setResult(ResponseParameters.FAILURE);
			return CodeStatus.FAILURE;
		}
	}
}
