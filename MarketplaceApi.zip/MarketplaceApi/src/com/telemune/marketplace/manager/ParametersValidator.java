/**
 * @author MoHit
 * Created on - 14 Feb, 2017
 */
package com.telemune.marketplace.manager;

import java.io.File;

import org.apache.log4j.Logger;

import com.telemune.marketplace.beans.UserDataBean;
import com.telemune.marketplace.beans.VirtualCodeMapping;
import com.telemune.marketplace.util.CodeStatus;
import com.telemune.marketplace.util.IvrMenu;
import com.telemune.marketplace.util.MPCommonDataTypes;
import com.telemune.marketplace.util.ResponseParameters;
import com.telemune.marketplace.util.ServiceTypes;
import com.telemune.marketplace.util.TSSJavaUtil;
import com.telemune.marketplace.util.UssdMenuNames;

/**
 * This class is used to validate the request parameters
 * 
 * @author MoHit
 */
public class ParametersValidator {
	/**
	 * Used for printing logs in this class
	 */
	private static Logger logger = Logger.getLogger(ParametersValidator.class);

	/**
	 * This method is used to validate the MSISDN
	 * 
	 * @param msisdn
	 * @param userDataBean
	 * @return true if MSISDN is valid otherwise false
	 */
	private boolean isValidMSISDN(String msisdn, UserDataBean userDataBean) {
		logger.debug(userDataBean.getRequestId() + " >> validating MSISDN [" + msisdn + "]");

		// checking MSISDN not to be null or blank
		if (msisdn == null || "".equals(msisdn)) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00079")
					+ " >> msisdn is blank or null [" + msisdn + "] so returning error");
			return false;
		}

		// checking MSISDN in range and converting to international number
		StringBuffer interMSISDN = new StringBuffer(msisdn);

		try {
			if (!TSSJavaUtil.instance().getInternationalNumber(interMSISDN)) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00080")
						+ " >> msisdn not in range [" + interMSISDN + "] so returning error");
				return false;
			}
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> msisdn is not valid [" + interMSISDN + "] so returning error");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00081")
					+ " >> msisdn is not valid [" + interMSISDN + "] so returning error");
			return false;
		}

		userDataBean.setMsisdn(interMSISDN.toString());
		logger.debug(userDataBean.getRequestId() + " >> international number is [" + interMSISDN + "] : msisdn ["
				+ msisdn + "]");
		return true;

	}// isValidMSISDN() ends

	/**
	 * This method is used to validate the FMSISDN
	 * 
	 * @param fmsisdn
	 * @param userDataBean
	 * @return true if FMSISDN is valid otherwise false
	 */
	private boolean isValidFMSISDN(String fmsisdn, UserDataBean userDataBean) {
		logger.debug(userDataBean.getRequestId() + " >> validating FMSISDN [" + fmsisdn + "]");

		// checking FMSISDN not to be null or blank
		if (fmsisdn == null || "".equals(fmsisdn)) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00082")
					+ " >> fmsisdn is blank or null [" + fmsisdn + "] so returning error");

			String filePath = "";

			if (ServiceTypes.TALK_TIME_TRANSFER.equals(userDataBean.getServiceType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_FMSISDN_TTT + "_" + userDataBean.getLangId());
			} else if (ServiceTypes.BONUS_TRANSFER.equals(userDataBean.getServiceType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_FMSISDN_BT + "_" + userDataBean.getLangId());
			} else if (ServiceTypes.DATA_TRANSFER.equals(userDataBean.getServiceType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_FMSISDN_DT + "_" + userDataBean.getLangId());
			} else if (ServiceTypes.TALK_TIME_TRANSFER_ONNET.equals(userDataBean.getServiceType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_FMSISDN_TTT + "_" + userDataBean.getLangId());
			} else if (ServiceTypes.TALK_TIME_TRANSFER_OFFNET.equals(userDataBean.getServiceType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_FMSISDN_TTT + "_" + userDataBean.getLangId());
			} else {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_FMSISDN + "_" + userDataBean.getLangId());
			}

			filePath = filePath.replace("$(fmsisdn)", "");
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_FMSISDN);

			return false;
		}

		// checking FMSISDN in range and converting to international number
		StringBuffer interFMSISDN = new StringBuffer(fmsisdn);

		try {
			if (!TSSJavaUtil.instance().getInternationalNumber(interFMSISDN)) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00083")
						+ " >> fmsisdn not in range [" + interFMSISDN + "] so returning error");

				String filePath = "";

				if (ServiceTypes.TALK_TIME_TRANSFER.equals(userDataBean.getServiceType())) {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.FMSISDN_NOT_IN_RANGE_TTT + "_" + userDataBean.getLangId());
				} else if (ServiceTypes.BONUS_TRANSFER.equals(userDataBean.getServiceType())) {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.FMSISDN_NOT_IN_RANGE_BT + "_" + userDataBean.getLangId());
				} else if (ServiceTypes.DATA_TRANSFER.equals(userDataBean.getServiceType())) {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.FMSISDN_NOT_IN_RANGE_DT + "_" + userDataBean.getLangId());
				} else if (ServiceTypes.TALK_TIME_TRANSFER_ONNET.equals(userDataBean.getServiceType())) {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.FMSISDN_NOT_IN_RANGE_TTT + "_" + userDataBean.getLangId());
				} else if (ServiceTypes.TALK_TIME_TRANSFER_OFFNET.equals(userDataBean.getServiceType())) {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.FMSISDN_NOT_IN_RANGE_TTT + "_" + userDataBean.getLangId());
				} else {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.FMSISDN_NOT_IN_RANGE + "_" + userDataBean.getLangId());
				}

				filePath = filePath.replace("$(fmsisdn)", fmsisdn);

				userDataBean.setFilePath(filePath);
				userDataBean.setResult(ResponseParameters.FMSISDN_NOT_IN_RANGE);
				return false;
			}
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00084")
					+ " >> fmsisdn is not valid [" + interFMSISDN + "] so returning error");

			String filePath = "";

			if (ServiceTypes.TALK_TIME_TRANSFER.equals(userDataBean.getServiceType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_FMSISDN_TTT + "_" + userDataBean.getLangId());
			} else if (ServiceTypes.BONUS_TRANSFER.equals(userDataBean.getServiceType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_FMSISDN_BT + "_" + userDataBean.getLangId());
			} else if (ServiceTypes.DATA_TRANSFER.equals(userDataBean.getServiceType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_FMSISDN_DT + "_" + userDataBean.getLangId());
			} else if (ServiceTypes.TALK_TIME_TRANSFER_ONNET.equals(userDataBean.getServiceType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_FMSISDN_TTT + "_" + userDataBean.getLangId());
			} else if (ServiceTypes.TALK_TIME_TRANSFER_OFFNET.equals(userDataBean.getServiceType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_FMSISDN_TTT + "_" + userDataBean.getLangId());
			} else {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_FMSISDN + "_" + userDataBean.getLangId());
			}

			filePath = filePath.replace("$(fmsisdn)", fmsisdn);
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_FMSISDN);
			return false;
		}

		userDataBean.setFmsisdn(interFMSISDN.toString());
		logger.debug(userDataBean.getRequestId() + " >> international fmsisdn is [" + interFMSISDN + "] : fmsisdn ["
				+ fmsisdn + "]");
		return true;

	}// isValidFMSISDN() ends

	/**
	 * This method is used to validate the MSISDN
	 * 
	 * @param msisdn
	 * @param userDataBean
	 * @return true if MSISDN is valid otherwise false
	 */
	private boolean isValidMSISDNForCheckProfile(String msisdn, UserDataBean userDataBean) {
		logger.debug(userDataBean.getRequestId() + " >> validating MSISDN [" + msisdn + "]");

		// checking MSISDN not to be null or blank
		if (msisdn == null || "".equals(msisdn)) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00085")
					+ " >> msisdn is blank or null [" + msisdn + "] so returning error");
			return false;
		}

		// checking MSISDN in range and converting to international number
		StringBuffer interMSISDN = new StringBuffer(msisdn);

		try {
			if (!TSSJavaUtil.instance().getInternationalNumber(interMSISDN)) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00086")
						+ " >> msisdn not in range [" + interMSISDN + "] so returning error");
				return false;
			}
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> msisdn is not valid [" + interMSISDN + "] so returning error");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00087")
					+ " >> msisdn is not valid [" + interMSISDN + "] so returning error");
			return false;
		}
		userDataBean.setMsisdn(interMSISDN.toString());
		logger.debug(userDataBean.getRequestId() + " >> international number is [" + interMSISDN + "] : msisdn ["
				+ msisdn + "]");

		// checking MSISDN not to be blacklisted
		if (TSSJavaUtil.instance().getCacheParameters().getBlackListedMSISDNs().contains(userDataBean.getMsisdn())) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00088")
					+ " >> msisdn is blacklisted [" + userDataBean.getMsisdn() + "] so returning error");
			return false;
		}

		// checking MSISDN to be in whiteList
		if (TSSJavaUtil.instance().getCacheParameters().isWhiteListingEnable() && !TSSJavaUtil.instance()
				.getCacheParameters().getWhiteListedMSISDNs().contains(userDataBean.getMsisdn())) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00089")
					+ " >> msisdn must be whitelisted because whitelisting is enable [" + msisdn
					+ "] so returning error");
			return false;
		}

		return true;

	}// isValidMSISDNForCheckProfile() ends

	/**
	 * Used to validate parameters for check profile request and to prepare and put
	 * all the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param userDataBean
	 * @return
	 */
	public boolean validateForCheckProfile(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, UserDataBean userDataBean) {
		logger.info(requestId + " >> Validating parameters for check profile request for msisdn [" + msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? !"".equals(shortCode) ? shortCode : userDataBean.getShortCode()
				: userDataBean.getShortCode());

		userDataBean.setPackBrowseList("NA");

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException nfe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid, Cannot be parsed from String to Number so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00090") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00091") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00092") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating MSISDN
		if (!isValidMSISDNForCheckProfile(msisdn, userDataBean)) {
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForCheckProfile() ends

	public boolean validateForGetUserTransaction(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String prevIndex, String nextIndex, String index, UserDataBean userDataBean) {
		logger.info(
				requestId + " >> Validating parameters for get user transaction request for msisdn [" + msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? !"".equals(shortCode) ? shortCode : userDataBean.getShortCode()
				: userDataBean.getShortCode());

		userDataBean.setPackBrowseList("NA");
		userDataBean.setPrevIndex(prevIndex);
		userDataBean.setNextIndex(nextIndex);
		userDataBean.setIndex(index);

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException nfe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid, Cannot be parsed from String to Number so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00090") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00091") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00092") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating MSISDN
		if (!isValidMSISDNForCheckProfile(msisdn, userDataBean)) {
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}

	public boolean validateForGetActivePlan(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String prevIndex, String nextIndex, String index, UserDataBean userDataBean) {
		logger.info(requestId + " >> Validating parameters for get active plan request for msisdn [" + msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? !"".equals(shortCode) ? shortCode : userDataBean.getShortCode()
				: userDataBean.getShortCode());

		userDataBean.setPackBrowseList("NA");
		userDataBean.setPrevIndex(prevIndex);
		userDataBean.setNextIndex(nextIndex);
		userDataBean.setIndex(index);

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException nfe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid, Cannot be parsed from String to Number so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00090") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00091") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00092") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating MSISDN
		if (!isValidMSISDNForCheckProfile(msisdn, userDataBean)) {
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}

	/**
	 * Used to validate parameters for get balance request and to prepare and put
	 * all the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param userDataBean
	 * @return
	 */
	public boolean validateForGetBalance(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String subType, UserDataBean userDataBean) {
		logger.info(requestId + " >> Validating parameters for get balance request for msisdn [" + msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException nfe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid, Cannot be parsed from String to Number so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00093") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00094") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00095") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForGetBalance() ends

	/**
	 * Used to validate parameters for get packs request and to prepare and put all
	 * the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param packTypeId
	 * @param packBrowseList
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param index
	 * @param balance
	 * @param packList
	 * @param userDataBean
	 * @return
	 */
	public boolean validateForGetPacks(String msisdn, String langId, String packTypeId, String packBrowseList,
			String requestId, String interfaceUsed, String shortCode, String subType, String index, String balance,
			String packList, UserDataBean userDataBean, String isPackType, String digit) {
		logger.info(requestId + " >> Validating parameters for get packs request for msisdn [" + msisdn + "]");

		userDataBean.setPackBrowseList(packBrowseList);
		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackList(packList != null ? packList : userDataBean.getPackList());
		userDataBean.setIndex(index != null ? !"".equals(index) ? index.toUpperCase() : userDataBean.getIndex()
				: userDataBean.getIndex());
		userDataBean.setDigits(digit);

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >>langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException nfe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >>langId [" + langId
					+ "] is not valid, Cannot be parsed from String to Number so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00096") + " >>langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00126") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00127") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating packTypeId
		try {
			userDataBean.setPackTypeId(Integer.parseInt(packTypeId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00097") + " >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating balance
		try {
			userDataBean.setBalance(Double.parseDouble(balance.trim()));
		} catch (NullPointerException npe) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> balance ["
					+ balance + "] is not valid (must be a double number)" + "so setting default ["
					+ userDataBean.getBalance() + "] : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> balance ["
					+ balance + "] is not valid (must be a double number)" + "so setting default ["
					+ userDataBean.getBalance() + "] : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00098") + " >> balance ["
					+ balance + "] is not valid (must be a double number)" + "so setting default ["
					+ userDataBean.getBalance() + "] : msisdn [" + msisdn + "]");
			return false;
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		if (isPackType == null) {
			logger.error(userDataBean.getRequestId() + " >> " + TSSJavaUtil.getLogInitial("00327")
					+ " >> isPackType found null for MSISDN:[" + userDataBean.getMsisdn() + "].");
			return false;
		} else {
			if (!isPackType.equalsIgnoreCase("Y") && !isPackType.equalsIgnoreCase("N")) {
				logger.error(userDataBean.getRequestId() + " >> " + TSSJavaUtil.getLogInitial("00331")
						+ " >> isPackType is not Y or N. MSISDN:[" + userDataBean.getMsisdn() + "].");
				return false;
			}
			userDataBean.setIsPackType(isPackType);
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForGetPacks() ends

	/**
	 * Used to validate parameters for get pack description by ID request and to
	 * prepare and put all the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packId
	 * @param packTypeId
	 * @param userDataBean
	 * @param isLowBalancePack
	 * @param currentPackTypeList
	 * @return
	 */
	public boolean validateForGetPackDescriptionById(String msisdn, String langId, String requestId,
			String interfaceUsed, String shortCode, String subType, String packId, String balance, String packTypeId,
			UserDataBean userDataBean, String isLowBalancePack, String currentPackTypeList) {
		// validating packId
		try {
			userDataBean.setPackId(Integer.parseInt(packId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + ">> packId [" + packId
					+ "] is not valid (must be an integer)" + "so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + ">> packId [" + packId
					+ "] must be an integer, so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00099") + ">> packId [" + packId
					+ "] is not valid (must be an integer)" + "so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		return this.validateForGetPackDescription(msisdn, langId, requestId, interfaceUsed, shortCode, subType, null,
				null, packTypeId, balance, userDataBean, isLowBalancePack, currentPackTypeList);

	}// validateForGetPackDescriptionById() ends

	/**
	 * Used to validate parameters for get pack description request and to prepare
	 * and put all the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packList
	 * @param digits
	 * @param packTypeId
	 * @param userDataBean
	 * @param isLowBalancePack
	 * @param currentPackTypeList
	 * @return
	 */
	public boolean validateForGetPackDescription(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String subType, String packList, String digits, String packTypeId, String balance,
			UserDataBean userDataBean, String isLowBalancePack, String currentPackTypeList) {
		logger.info(
				requestId + "  >> Validating parameters for get pack description request for msisdn [" + msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackList(packList != null ? packList : userDataBean.getPackList());
		userDataBean.setDigits(digits);
		userDataBean.setBalance(Integer.parseInt(balance));

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + ">> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + ">> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00100") + ">> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00128") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00129") + ">> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating packTypeId
		try {
			userDataBean.setPackTypeId(Integer.parseInt(packTypeId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + ">> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + ">> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00101") + ">> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		if (!isLowBalancePack.isEmpty() && isLowBalancePack != null) {
			userDataBean.setIsLowBalancePack(isLowBalancePack);
		} else {
			logger.error(
					userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00332") + ">> isLowBalancePack ["
							+ isLowBalancePack + "]  " + " isLowBalance found null or empty : msisdn [" + msisdn + "]");
			return false;
		}

		if (!currentPackTypeList.isEmpty() && currentPackTypeList != null) {
			userDataBean.setCurrentPackTypeList(currentPackTypeList);
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00332")
					+ ">> currentPackTypeList [" + currentPackTypeList + "]  "
					+ " currentPackTypeList found null or empty : msisdn [" + msisdn + "]");
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForGetPackDescription() ends

	/**
	 * Used to validate parameters for purchase pack request and to prepare and put
	 * all the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param packBrowseList
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packId
	 * @param packTypeId
	 * @param userDataBean
	 * @return
	 */
	public boolean validateForPurchasePack(String msisdn, String langId, String packBrowseList, String requestId,
			String interfaceUsed, String shortCode, String subType, String packId, String packTypeId,
			UserDataBean userDataBean) {
		logger.info(requestId + "  >> Validating parameters for pack purchase request for msisdn [" + msisdn + "]");

		userDataBean.setPackBrowseList(packBrowseList != null ? packBrowseList : userDataBean.getPackBrowseList());
		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00102") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00130") + "  >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00131") + "  >> interface ["
						+ interfaceUsed + "] " + "must be of one character so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating packId
		try {
			userDataBean.setPackId(Integer.parseInt(packId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00103") + " >> packId ["
					+ packId + "] is not valid (must be an integer)" + "so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> packId ["
					+ packId + "] is not valid (must be an integer)" + "so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00103") + " >> packId ["
					+ packId + "] is not valid (must be an integer)" + "so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating packTypeId
		try {
			userDataBean.setPackTypeId(Integer.parseInt(packTypeId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00104") + ">> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + ">> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00104") + ">> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + "  >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForPurchasePack() ends

	/**
	 * Used to validate parameters for validate FMSISDN request and to prepare and
	 * put all the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param requestId
	 * @param fmsisdn
	 * @param langId
	 * @param serviceType
	 * @param userDataBean
	 * @return
	 */
	public boolean validateFMSISDN(String msisdn, String requestId, String fmsisdn, String langId, String serviceType,
			UserDataBean userDataBean, String interfaceUsed) {
		logger.info(requestId + "  >> Validating parameters for validate FMSISDN request for msisdn [" + msisdn + "]");

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00105") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00132") + " >> requestId [" + requestId
					+ "] is null or blank " + "so returning error : msisdn [" + msisdn + "]");
			userDataBean.setResult(ResponseParameters.FAILURE);
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
		}

		// interface checking
		if (interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00130") + "  >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00131") + "  >> interface ["
						+ interfaceUsed + "] " + "must be of one character so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating service type
		try {
			String tempServiceType = serviceType.trim().toUpperCase();
			if (ServiceTypes.TALK_TIME_TRANSFER.equals(tempServiceType)) {
				userDataBean.setServiceType(ServiceTypes.TALK_TIME_TRANSFER);
			} else if (ServiceTypes.DATA_TRANSFER.equals(tempServiceType)) {
				userDataBean.setServiceType(ServiceTypes.DATA_TRANSFER);
			} else if (ServiceTypes.BONUS_TRANSFER.equals(tempServiceType)) {
				userDataBean.setServiceType(ServiceTypes.BONUS_TRANSFER);
			} else {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00133") + " >> serviceType ["
						+ serviceType + "] is not supported " + "must be " + ServiceTypes.TALK_TIME_TRANSFER + " or "
						+ ServiceTypes.BONUS_TRANSFER + " or " + ServiceTypes.DATA_TRANSFER + " so using "
						+ ServiceTypes.TALK_TIME_TRANSFER + " : msisdn [" + msisdn + "]");
				userDataBean.setServiceType(ServiceTypes.TALK_TIME_TRANSFER);
			}

		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> serviceType ["
					+ serviceType + "] is not valid " + "must be " + ServiceTypes.TALK_TIME_TRANSFER + " or "
					+ ServiceTypes.BONUS_TRANSFER + " or " + ServiceTypes.DATA_TRANSFER + " so using "
					+ ServiceTypes.TALK_TIME_TRANSFER + " : msisdn [" + msisdn + "]");
			userDataBean.setServiceType(ServiceTypes.TALK_TIME_TRANSFER);
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00106") + " >> serviceType ["
					+ serviceType + "] is not valid " + "must be " + ServiceTypes.TALK_TIME_TRANSFER + " or "
					+ ServiceTypes.BONUS_TRANSFER + " or " + ServiceTypes.DATA_TRANSFER + " so using "
					+ ServiceTypes.TALK_TIME_TRANSFER + " : msisdn [" + msisdn + "]");
			userDataBean.setServiceType(ServiceTypes.TALK_TIME_TRANSFER);
			return false;
		}

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
			// validating FMSISDN for IVR
			if (!isValidFMSISDNforIvr(fmsisdn, userDataBean)) {
				return false;
			}
		} else {
			// validating FMSISDN
			if (!isValidFMSISDN(fmsisdn, userDataBean)) {
				return false;
			}
		}

		userDataBean.setMsisdn(msisdn);
		logger.info(
				userDataBean.getRequestId() + "  >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForCallLogs() ends

	/**
	 * Used to validate parameters for call logs request and to prepare and put all
	 * the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param packBrowseList
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param balance
	 * @param packPurchaseDetail
	 * @param fmsisdn
	 * @param userDataBean
	 * @return
	 */
	public boolean validateForCallLogs(String msisdn, String langId, String packBrowseList, String requestId,
			String interfaceUsed, String shortCode, String subType, String balance, String packPurchaseDetail,
			String fmsisdn, UserDataBean userDataBean) {
		logger.info(requestId + "  >> Validating parameters for call logs request for msisdn [" + msisdn + "]");

		userDataBean
				.setPackBrowseList(packBrowseList != null ? !"".equals(packBrowseList) ? packBrowseList : "NA" : "NA");

		userDataBean.setPackPurchaseDetail(packPurchaseDetail);

		userDataBean.setFmsisdn(fmsisdn != null ? !"".equals(fmsisdn) ? fmsisdn : userDataBean.getFmsisdn()
				: userDataBean.getFmsisdn());

		userDataBean.setShortCode(shortCode != null ? !"".equals(shortCode) ? shortCode : userDataBean.getShortCode()
				: userDataBean.getShortCode());

		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + ">> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00107") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00134") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00135") + ">> interface ["
						+ interfaceUsed + "] " + "must be of one character so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating balance
		try {
			userDataBean.setBalance(Double.parseDouble(balance.trim()));
		} catch (NullPointerException npe) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00108") + " >> balance ["
					+ balance + "] is not valid (must be a double number)" + "so setting default ["
					+ userDataBean.getBalance() + "] : msisdn [" + msisdn + "]");
		} catch (NumberFormatException ex) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> balance ["
					+ balance + "] is not valid (must be a double number)" + "so setting default ["
					+ userDataBean.getBalance() + "] : msisdn [" + msisdn + "]");
		} catch (Exception e) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00108") + " >> balance ["
					+ balance + "] is not valid (must be a double number)" + "so setting default ["
					+ userDataBean.getBalance() + "] : msisdn [" + msisdn + "]");
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + "  >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForCallLogs() ends

	/**
	 * Used to validate parameters for get talk time transfer description request
	 * and to prepare and put all the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param netType
	 * @param volume
	 * @param fmsisdn
	 * @param userDataBean
	 * @return
	 */
	public boolean validateForTTTDescription(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String subType, String netType, String volume, String fmsisdn,
			UserDataBean userDataBean) {
		logger.info(requestId + "  >> Validating parameters for get talk time transfer description request for msisdn ["
				+ msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackPurchaseDetail("-1:-1");

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + "  >> langId ["
					+ langId + "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00109") + "  >> langId ["
					+ langId + "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00136") + "  >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00137") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating netType
		if (ServiceTypes.ON_NET.equalsIgnoreCase(netType)) {
			userDataBean.setNetType(ServiceTypes.ON_NET);
		} else if (ServiceTypes.OFF_NET.equalsIgnoreCase(netType)) {
			userDataBean.setNetType(ServiceTypes.OFF_NET);
		} else if (ServiceTypes.EURO_OFF_NET.equalsIgnoreCase(netType)) {
			userDataBean.setNetType(ServiceTypes.EURO_OFF_NET);
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00138") + " >> netType ["
					+ netType + "] must be " + ServiceTypes.ON_NET + " or " + ServiceTypes.OFF_NET + " or "
					+ ServiceTypes.EURO_OFF_NET + " so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
			// validating FMSISDN for IVR
			if (!isValidFMSISDNforIvr(fmsisdn, userDataBean)) {
				return false;
			}

			// validating volume for IVR
			if (!isValidVolumeforIvr(userDataBean, volume, msisdn)) {
				return false;
			}
		} else {
			// validating FMSISDN
			if (!isValidFMSISDN(fmsisdn, userDataBean)) {
				userDataBean.setResult(ResponseParameters.FAILURE);
				return false;
			}
			// validating volume
			if (!isValidVolume(userDataBean, volume, msisdn)) {
				return false;
			}
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForTTT() ends

	/**
	 * Used to validate parameters for talk time transfer request and to prepare and
	 * put all the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param netType
	 * @param volume
	 * @param fmsisdn
	 * @param userDataBean
	 * @return
	 */
	public boolean validateForTTT(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String subType, String netType, String volume, String fmsisdn,
			UserDataBean userDataBean) {
		logger.info(requestId + "  >> Validating parameters for get talk time transfer description request for msisdn ["
				+ msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackPurchaseDetail("-1:-1");

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00111") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00139") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00140") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating netType
		if (ServiceTypes.ON_NET.equalsIgnoreCase(netType)) {
			userDataBean.setNetType(ServiceTypes.ON_NET);
		} else if (ServiceTypes.OFF_NET.equalsIgnoreCase(netType)) {
			userDataBean.setNetType(ServiceTypes.OFF_NET);
		} else if (ServiceTypes.EURO_OFF_NET.equalsIgnoreCase(netType)) {
			userDataBean.setNetType(ServiceTypes.EURO_OFF_NET);
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00141") + " >> netType ["
					+ netType + "] must be " + ServiceTypes.ON_NET + " or " + ServiceTypes.OFF_NET + " or "
					+ ServiceTypes.EURO_OFF_NET + " so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating volume
		try {
			userDataBean.setVolume(Integer.parseInt(volume.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> volume ["
					+ volume + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> volume ["
					+ volume + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00112") + " >> volume ["
					+ volume + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
			// validating FMSISDN for IVR
			if (!isValidFMSISDNforIvr(fmsisdn, userDataBean)) {
				return false;
			}
		} else {
			// validating FMSISDN
			if (!isValidFMSISDN(fmsisdn, userDataBean)) {
				return false;
			}
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForTTT() ends

	/**
	 * Used to validate parameters for get bonus transfer description request and to
	 * prepare and put all the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packList
	 * @param digits
	 * @param packTypeId
	 * @param fmsisdn
	 * @param userDataBean
	 * @return
	 */
	public boolean validateForBonusTransferDesc(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String subType, String packList, String digits, String packTypeId, String fmsisdn,
			String balance, UserDataBean userDataBean) {
		logger.info(requestId + "  >> Validating parameters for get bonus transfer description request for msisdn ["
				+ msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackPurchaseDetail("-1:-1");
		userDataBean.setPackList(packList != null ? packList : userDataBean.getPackList());
		userDataBean.setBalance(Integer.parseInt(balance));
		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00113") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00142") + "  >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00143") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating digits
		try {
			userDataBean.setDigits(String.valueOf(Integer.parseInt(digits.trim())));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> digits ["
					+ digits + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> digits ["
					+ digits + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00114") + " >> digits ["
					+ digits + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating packTypeId
		try {
			userDataBean.setPackTypeId(Integer.parseInt(packTypeId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> packTypeId ["
					+ packTypeId + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn
					+ "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> packTypeId ["
					+ packTypeId + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn
					+ "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00115") + " >> packTypeId ["
					+ packTypeId + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn
					+ "]");
			return false;
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
			// validating FMSISDN for IVR
			if (!isValidFMSISDNforIvr(fmsisdn, userDataBean)) {
				return false;
			}
		} else {
			// validating FMSISDN
			if (!isValidFMSISDN(fmsisdn, userDataBean)) {
				return false;
			}
		}

		logger.info(
				userDataBean.getRequestId() + "  >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForBonusTransfer() ends

	/**
	 * Used to validate parameters for get data transfer description request and to
	 * prepare and put all the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packList
	 * @param digits
	 * @param packTypeId
	 * @param fmsisdn
	 * @param userDataBean
	 * @return
	 */
	public boolean validateForDataTransferDesc(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String subType, String packList, String digits, String packTypeId, String fmsisdn,
			UserDataBean userDataBean) {
		logger.info(requestId + " >> Validating parameters for get bonus transfer description request for msisdn ["
				+ msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackPurchaseDetail("-1:-1");
		userDataBean.setPackList(packList != null ? packList : userDataBean.getPackList());

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00116") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " >> " + TSSJavaUtil.getLogInitial("00144") + " >>requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00145") + "  >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating digits
		try {
			userDataBean.setDigits(String.valueOf(Integer.parseInt(digits.trim())));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> digits ["
					+ digits + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> digits ["
					+ digits + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00117") + " >> digits ["
					+ digits + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating packTypeId
		try {
			userDataBean.setPackTypeId(Integer.parseInt(packTypeId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> packTypeId ["
					+ packTypeId + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn
					+ "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> packTypeId ["
					+ packTypeId + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn
					+ "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00118") + " >> packTypeId ["
					+ packTypeId + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn
					+ "]");
			return false;
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
			// validating FMSISDN for IVR
			if (!isValidFMSISDNforIvr(fmsisdn, userDataBean)) {
				return false;
			}
		} else {
			// validating FMSISDN
			if (!isValidFMSISDN(fmsisdn, userDataBean)) {
				return false;
			}
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForDataTransferDesc() ends

	/**
	 * Used to validate parameters for bonus transfer and to prepare and put all the
	 * parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packId
	 * @param packTypeId
	 * @param fmsisdn
	 * @param userDataBean
	 * @return
	 */
	public boolean validateForBonusTransfer(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String subType, String packId, String packTypeId, String fmsisdn,
			UserDataBean userDataBean) {
		logger.info(requestId + "  >> Validating parameters for bonus transfer request for msisdn [" + msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackPurchaseDetail("-1:-1");

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00119") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00146") + "  >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00147") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating packId
		try {
			userDataBean.setPackId(Integer.parseInt(packId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + "  >> packId ["
					+ packId + "] is not valid (must be an integer)" + "so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + "  >> packId ["
					+ packId + "] is not valid (must be an integer)" + "so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00120") + "  >> packId ["
					+ packId + "] is not valid (must be an integer)" + "so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating packTypeId
		try {
			userDataBean.setPackTypeId(Integer.parseInt(packTypeId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + "  >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + "  >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00121") + "  >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
			// validating FMSISDN for IVR
			if (!isValidFMSISDNforIvr(fmsisdn, userDataBean)) {
				return false;
			}
		} else {
			// validating FMSISDN
			if (!isValidFMSISDN(fmsisdn, userDataBean)) {
				return false;
			}
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForBonusTransfer() ends

	/**
	 * Used to validate parameters for data transfer and to prepare and put all the
	 * parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packId
	 * @param packTypeId
	 * @param fmsisdn
	 * @param userDataBean
	 * @return
	 */
	public boolean validateForDataTransfer(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String subType, String packId, String packTypeId, String fmsisdn,
			UserDataBean userDataBean) {
		logger.info(requestId + " >> Validating parameters for data transfer request for msisdn [" + msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackPurchaseDetail("-1:-1");

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00122") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00148") + " >>requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00149") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating packId
		try {
			userDataBean.setPackId(Integer.parseInt(packId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> packId ["
					+ packId + "] is not valid (must be an integer)" + "so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> packId ["
					+ packId + "] is not valid (must be an integer)" + "so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00123") + " >> packId ["
					+ packId + "] is not valid (must be an integer)" + "so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating packTypeId
		try {
			userDataBean.setPackTypeId(Integer.parseInt(packTypeId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00124") + " >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
			// validating FMSISDN for IVR
			if (!isValidFMSISDNforIvr(fmsisdn, userDataBean)) {
				return false;
			}
		} else {
			// validating FMSISDN
			if (!isValidFMSISDN(fmsisdn, userDataBean)) {
				return false;
			}
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForDataTransfer() ends

	/**
	 * Used to validate parameters for check data transfer eligibility request and
	 * to prepare and put all the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param userDataBean
	 * @return
	 */
	public boolean validateForCheckDTEligibility(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String subType, UserDataBean userDataBean) {
		logger.info(requestId + " >> Validating parameters for check data transfer eligibility request for msisdn ["
				+ msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackPurchaseDetail("-1:-1");

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00125") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00150") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00151") + "  >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForCheckDTEligibility() ends

	/**
	 * Used to validate parameters for direct dial request and to prepare and put
	 * all the parameters into a java bean
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param userDataBean
	 * @return true if success otherwise false
	 */
	public boolean validateForDirectDial(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String subType, UserDataBean userDataBean) {
		logger.info(requestId + "  >> Validating parameters for direct dial request for msisdn [" + msisdn + "]");

		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00298") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00299") + "  >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00300") + "  >> interface ["
						+ interfaceUsed + "] " + "must be of one character so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating MSISDN
		if (!isValidMSISDNForCheckProfile(msisdn, userDataBean)) {
			return false;
		}
		if (!this.validateMsisdnSubType(userDataBean)) {
			return false;
		}

		if (!new DirectDialHandler().checkAndParseShortCode(shortCode, userDataBean)) {
			return false;
		}

		if (ServiceTypes.PACK_PURHCASE.equals(userDataBean.getServiceType())
				|| ServiceTypes.BONUS_TRANSFER.equals(userDataBean.getServiceType())
				|| ServiceTypes.DATA_TRANSFER.equals(userDataBean.getServiceType())) {
			if (!isValidVirtualCode(userDataBean)) {
				return false;
			}
		}

		if (ServiceTypes.TALK_TIME_TRANSFER_ONNET.equals(userDataBean.getServiceType())
				|| ServiceTypes.TALK_TIME_TRANSFER_OFFNET.equals(userDataBean.getServiceType())
				|| ServiceTypes.BONUS_TRANSFER.equals(userDataBean.getServiceType())
				|| ServiceTypes.DATA_TRANSFER.equals(userDataBean.getServiceType())) {
			// validating FMSISDN
			if (!isValidFMSISDN(userDataBean.getFmsisdn(), userDataBean)) {
				return false;
			}
			if (!this.validateFmsisdnSubType(userDataBean)) {
				return false;
			}

		}

		logger.info(userDataBean.getRequestId()
				+ "  >> In case of Direct Dial, all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForDirectDial() ends

	/**
	 * Used to validate virtual codes. handles either virtual code does not found in
	 * db or the pack Id is not for service type for which user is trying.
	 * 
	 * @param userDataBean
	 * @return true if virtual code is valid otherwise false.
	 */
	private boolean isValidVirtualCode(UserDataBean userDataBean) {
		logger.debug(
				userDataBean.getRequestId() + " >> validating virtual code [" + userDataBean.getVirtualCode() + "]");

		VirtualCodeMapping virtualCode = TSSJavaUtil.instance().getCacheParameters().getVirtualCodeMappedDetails()
				.get(userDataBean.getVirtualCode());

		if (virtualCode == null) {
			logger.info(userDataBean.getRequestId() + " >> Invalid virtual code," + "As code ["
					+ userDataBean.getVirtualCode() + "] did not found in configuration table ");
			String filepath = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.VIRTUAL_CODE_NOT_FOUND + "_" + userDataBean.getLangId());
			filepath = filepath.replace("$(virtual_code)", String.valueOf(userDataBean.getVirtualCode()));
			userDataBean.setFilePath(filepath);
			return false;
		} else {
			logger.debug(userDataBean.getRequestId() + " >> Virtual code has been matched in the configuration table. "
					+ "Now getting pack_id etc. for service Type [" + userDataBean.getServiceType() + "] "
					+ "super_pack_type for match is [" + virtualCode.getSuperPackType() + "]");

			if (TSSJavaUtil.instance().getCacheParameters().getPackTypeId(userDataBean.getServiceType()) != virtualCode
					.getSuperPackType()) {
				logger.info(userDataBean.getRequestId() + " >> Invalid virtual code," + "As code ["
						+ userDataBean.getVirtualCode() + "] did not found for serviceType " + "["
						+ userDataBean.getServiceType() + "]");
				if (ServiceTypes.PACK_PURHCASE.equals(userDataBean.getServiceType())) {
					String filepath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.INVALID_VIRTUAL_CODE_PP + "_" + userDataBean.getLangId());
					filepath = filepath.replace("$(virtual_code)", String.valueOf(userDataBean.getVirtualCode()));
					userDataBean.setFilePath(filepath);
				} else if (ServiceTypes.DATA_TRANSFER.equals(userDataBean.getServiceType())) {
					String filepath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.INVALID_VIRTUAL_CODE_DT + "_" + userDataBean.getLangId());
					filepath = filepath.replace("$(virtual_code)", String.valueOf(userDataBean.getVirtualCode()));
					userDataBean.setFilePath(filepath);
				} else if (ServiceTypes.BONUS_TRANSFER.equals(userDataBean.getServiceType())) {
					String filepath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.INVALID_VIRTUAL_CODE_BT + "_" + userDataBean.getLangId());
					filepath = filepath.replace("$(virtual_code)", String.valueOf(userDataBean.getVirtualCode()));
					userDataBean.setFilePath(filepath);
				}
				return false;
			}

			logger.info(
					userDataBean.getRequestId() + " >>VirtualCode [" + userDataBean.getVirtualCode() + "] is correct "
							+ "for selected service Type [" + userDataBean.getServiceType() + "], So Continue");
			userDataBean.setPackId(virtualCode.getPackId());
			userDataBean.setPackTypeId(virtualCode.getPackTypeId());
		}

		return true;

	}// isValidVirtualCode() ends

	/**
	 * This method is used to receive the request for validate the friend mobile
	 * number in case of Direct Dial
	 * 
	 * @param userDataBean
	 * @return true if subType is Pre-Paid otherwise false
	 */
	public boolean validateFmsisdnSubType(UserDataBean userDataBean) {
		logger.info(
				userDataBean.getRequestId() + " >> GOING to validate SUBTYPE of FMSISDN [" + userDataBean.getFmsisdn()
						+ "] in case of " + "DIRECT DIAL msisdn : [" + userDataBean.getMsisdn() + "].\n\n\n\n");

		ChargingManager chargingManager = new ChargingManager();

		String msisdn = userDataBean.getMsisdn();
		String subType = userDataBean.getSubType();

		userDataBean.setMsisdn(userDataBean.getFmsisdn());

		CodeStatus status = chargingManager.new HLRHandler().checkSubscriberType(userDataBean);

		userDataBean.setMsisdn(msisdn);

		if (CodeStatus.SUCCESS != status) {
			String filePath = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
			userDataBean.setFilePath(filePath);
			userDataBean.setSubType(subType);
			return false;
		} else if ("O".equalsIgnoreCase(userDataBean.getSubType())) {
			logger.info(userDataBean.getRequestId()
					+ " >> In case of Direct Dial, FMSISDN subType is checked successfully ["
					+ userDataBean.getSubType() + "] " + " : msisdn [" + userDataBean.getMsisdn()
					+ "], So returning false");

			String filePath = "";

			if (ServiceTypes.TALK_TIME_TRANSFER.equals(userDataBean.getServiceType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.FMSISDN_IS_NOT_PREPAID_TTT + "_" + userDataBean.getLangId());
			} else if (ServiceTypes.BONUS_TRANSFER.equals(userDataBean.getServiceType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.FMSISDN_IS_NOT_PREPAID_BT + "_" + userDataBean.getLangId());
			} else if (ServiceTypes.DATA_TRANSFER.equals(userDataBean.getServiceType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.FMSISDN_IS_NOT_PREPAID_DT + "_" + userDataBean.getLangId());
			} else {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.FMSISDN_IS_NOT_PREPAID + "_" + userDataBean.getLangId());
			}

			filePath = filePath.replace("$(fmsisdn)", userDataBean.getFmsisdn());
			userDataBean.setFilePath(filePath);
			userDataBean.setSubType(subType);
			return false;
		} else if ("P".equalsIgnoreCase(userDataBean.getSubType())) {
			logger.debug(userDataBean.getRequestId() + "  >> In Direct Dial, FMSISDN's [" + userDataBean.getFmsisdn()
					+ "] subType is [" + userDataBean.getSubType() + "] " + ": msisdn [" + userDataBean.getMsisdn()
					+ "]");
			userDataBean.setSubType(subType);
			return true;
		}
		userDataBean.setSubType(subType);
		return true;

	}// validateFmsisdnSubType() ends

	/**
	 * This method is used to receive the request for validate the user's mobile
	 * number in case of Direct Dial
	 * 
	 * @param userDataBean
	 * @return true if subType is Pre-Paid otherwise false
	 */
	public boolean validateMsisdnSubType(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >> GOING to validate SUBTYPE of User's MSISDN ["
				+ userDataBean.getMsisdn() + "] in case of " + "DIRECT DIAL msisdn : [" + userDataBean.getMsisdn()
				+ "].\n\n\n\n");

		CodeStatus status = new ChargingManager().new HLRHandler().checkSubscriberType(userDataBean);

		if (CodeStatus.SUCCESS != status) {
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.INVALID_SHORT_CODE + "_" + userDataBean.getLangId()));
			return false;
		} else if ("O".equalsIgnoreCase(userDataBean.getSubType())) {
			logger.info(userDataBean.getRequestId()
					+ " >> In case of Direct Dial, MSISDN subType is checked successfully [" + userDataBean.getSubType()
					+ "] " + " : msisdn [" + userDataBean.getMsisdn() + "], So returning false");

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.INVALID_SHORT_CODE + "_" + userDataBean.getLangId()));
			return false;
		} else if ("P".equalsIgnoreCase(userDataBean.getSubType())) {
			logger.info(userDataBean.getRequestId() + "  >> In Direct Dial, MSISDN's [" + userDataBean.getMsisdn()
					+ "] subType is [" + userDataBean.getSubType() + "]");
			return true;
		}
		userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
				.getUssdMenuString(UssdMenuNames.INVALID_SHORT_CODE + "_" + userDataBean.getLangId()));
		return false;

	}// validateMsisdnSubType() ends

	/**
	 * This method is used to validate the FMSISDN for Ivr
	 * 
	 * @param fmsisdn
	 * @param userDataBean
	 * @return true if FMSISDN is valid otherwise false
	 */
	private boolean isValidFMSISDNforIvr(String fmsisdn, UserDataBean userDataBean) {
		logger.debug(userDataBean.getRequestId() + " >> validating FMSISDN for IVR [" + fmsisdn + "]");

		String filePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
				+ File.separator;

		// checking FMSISDN not to be null or blank
		if (fmsisdn == null || "".equals(fmsisdn)) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00082")
					+ " >>(IVR) fmsisdn is blank or null [" + fmsisdn + "] so returning error");

			if (ServiceTypes.TALK_TIME_TRANSFER.equals(userDataBean.getServiceType())) {
				filePath += IvrMenu.INVALID_FMSISDN_TTT_WAV_IVR;
			} else if (ServiceTypes.BONUS_TRANSFER.equals(userDataBean.getServiceType())) {
				filePath += IvrMenu.INVALID_FMSISDN_BT_WAV_IVR;
			} else if (ServiceTypes.DATA_TRANSFER.equals(userDataBean.getServiceType())) {

				if (TSSJavaUtil.instance().getCacheParameters().getInvalidFmsisdnBtIvrPromptEnable() == 1)
					filePath += IvrMenu.INVALID_FMSISDN_DT_WAV_IVR;
				else
					filePath += IvrMenu.UNKNOWN_ERROR_WAV_IVR;
			} else if (ServiceTypes.TALK_TIME_TRANSFER_ONNET.equals(userDataBean.getServiceType())) {
				filePath += IvrMenu.INVALID_FMSISDN_TTT_WAV_IVR;
			} else if (ServiceTypes.TALK_TIME_TRANSFER_OFFNET.equals(userDataBean.getServiceType())) {
				filePath += IvrMenu.INVALID_FMSISDN_TTT_WAV_IVR;
			} else {
				filePath += IvrMenu.INVALID_FMSISDN_WAV_IVR;
			}

			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_FMSISDN_IVR);

			return false;
		}

		// checking FMSISDN in range and converting to international number
		StringBuffer interFMSISDN = new StringBuffer(fmsisdn);

		try {
			if (!TSSJavaUtil.instance().getInternationalNumber(interFMSISDN)) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00083")
						+ " >>(IVR) fmsisdn not in range [" + interFMSISDN + "] so returning error");

				if (ServiceTypes.TALK_TIME_TRANSFER.equals(userDataBean.getServiceType())) {
					filePath += IvrMenu.FMSISDN_NOT_IN_RANGE_TTT_WAV_IVR;
				} else if (ServiceTypes.BONUS_TRANSFER.equals(userDataBean.getServiceType())) {
					if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
							|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
						filePath += IvrMenu.FMSISDN_NOT_IN_RANGE_BT_WAV_IVR;
					} else
						filePath += IvrMenu.UNKNOWN_ERROR_WAV_IVR;
				} else if (ServiceTypes.DATA_TRANSFER.equals(userDataBean.getServiceType())) {
					filePath += IvrMenu.FMSISDN_NOT_IN_RANGE_DT_WAV_IVR;

				} else if (ServiceTypes.TALK_TIME_TRANSFER_ONNET.equals(userDataBean.getServiceType())) {
					filePath += IvrMenu.FMSISDN_NOT_IN_RANGE_TTT_WAV_IVR;
				} else if (ServiceTypes.TALK_TIME_TRANSFER_OFFNET.equals(userDataBean.getServiceType())) {
					filePath += IvrMenu.FMSISDN_NOT_IN_RANGE_TTT_WAV_IVR;
				} else {
					filePath += IvrMenu.FMSISDN_NOT_IN_RANGE_WAV_IVR;
				}

				userDataBean.setFilePath(filePath);
				userDataBean.setResult(ResponseParameters.FMSISDN_NOT_IN_RANGE_IVR);
				return false;
			}
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00084")
					+ " >> fmsisdn is not valid [" + interFMSISDN + "] so returning error");

			String promptFilePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath()
					+ userDataBean.getLangId() + File.separator;

			if (ServiceTypes.TALK_TIME_TRANSFER.equals(userDataBean.getServiceType())) {
				promptFilePath += IvrMenu.INVALID_FMSISDN_TTT_WAV_IVR;
			} else if (ServiceTypes.BONUS_TRANSFER.equals(userDataBean.getServiceType())) {
				if (TSSJavaUtil.instance().getCacheParameters().getInvalidFmsisdnBtIvrPromptEnable() == 1)
					promptFilePath += IvrMenu.INVALID_FMSISDN_BT_WAV_IVR;
				else
					promptFilePath += IvrMenu.UNKNOWN_ERROR_WAV_IVR;
			} else if (ServiceTypes.DATA_TRANSFER.equals(userDataBean.getServiceType())) {
				promptFilePath += IvrMenu.INVALID_FMSISDN_DT_WAV_IVR;
			} else if (ServiceTypes.TALK_TIME_TRANSFER_ONNET.equals(userDataBean.getServiceType())) {
				promptFilePath += IvrMenu.INVALID_FMSISDN_TTT_WAV_IVR;
			} else if (ServiceTypes.TALK_TIME_TRANSFER_OFFNET.equals(userDataBean.getServiceType())) {
				promptFilePath += IvrMenu.INVALID_FMSISDN_TTT_WAV_IVR;
			} else {
				promptFilePath += IvrMenu.INVALID_FMSISDN_WAV_IVR;
			}

			userDataBean.setFilePath(promptFilePath);
			userDataBean.setResult(ResponseParameters.INVALID_FMSISDN);
			return false;
		}

		userDataBean.setFmsisdn(interFMSISDN.toString());
		logger.debug(userDataBean.getRequestId() + " >> (IVR) international fmsisdn is [" + interFMSISDN
				+ "] : fmsisdn [" + fmsisdn + "]");
		return true;

	}// isValidFMSISDNforIvr() ends

	public boolean isValidVolume(UserDataBean userDataBean, String volume, String msisdn) {
		try {
			int volumeInt = Integer.parseInt(volume.trim());
			int maxLimit = TSSJavaUtil.instance().getCacheParameters().getTttMaxLimit();
			if (maxLimit != -99 && volumeInt > maxLimit) {
				logger.warn(userDataBean.getRequestId() + "  " + TSSJavaUtil.getLogInitial("00215") + " >> volume ["
						+ volume + "] is not valid " + "(can not be more than " + maxLimit
						+ ") so returning failure : msisdn [" + msisdn + "]");
				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.TRANSFER_VOLUME_EXCEEDED + "_" + userDataBean.getLangId());
				filePath = filePath.replace("$(volume)", String.valueOf(volumeInt));
				filePath = filePath.replace("$(max_volume)",
						String.valueOf(TSSJavaUtil.instance().getCacheParameters().getTttMaxLimit()));
				userDataBean.setFilePath(filePath);
				userDataBean.setResult(ResponseParameters.TRANSFER_VOLUME_EXCEED);
				return false;
			} else if (volumeInt <= 0) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00216") + " >> volume ["
						+ volume + "] is not valid " + "(should be more than 0) so returning failure : msisdn ["
						+ msisdn + "]");
				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_VOLUME + "_" + userDataBean.getLangId());
				filePath = filePath.replace("$(volume)", volume);
				userDataBean.setFilePath(filePath);
				userDataBean.setResult(ResponseParameters.INVALID_VOLUME);
				return false;
			}

			userDataBean.setVolume(volumeInt);
			// checking user has enough ttt and main account balance or not
			if (new ChargingManager().checkBalanceForTTT(userDataBean) != CodeStatus.SUCCESS) {
				return false;
			}

		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> volume [" + volume
					+ "] is not valid " + "(must be an integer) so returning failure : msisdn [" + msisdn + "]");
			String filePath = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.INVALID_VOLUME + "_" + userDataBean.getLangId());
			filePath = filePath.replace("$(volume)", volume);
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME);
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> volume [" + volume
					+ "] is not valid " + "(must be an integer) so returning failure : msisdn [" + msisdn + "]");
			String filePath = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.INVALID_VOLUME + "_" + userDataBean.getLangId());
			filePath = filePath.replace("$(volume)", volume);
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME);
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00110") + " >> volume [" + volume
					+ "] is not valid " + "(must be an integer) so returning failure : msisdn [" + msisdn + "]");
			String filePath = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.INVALID_VOLUME + "_" + userDataBean.getLangId());
			filePath = filePath.replace("$(volume)", volume);
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME);
			return false;
		}
		return true;
	}

	public boolean isValidVolumeforIvr(UserDataBean userDataBean, String volume, String msisdn) {
		try {
			String promptFilePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath()
					+ userDataBean.getLangId() + File.separator;
			int volumeInt = Integer.parseInt(volume.trim());
			int maxLimit = TSSJavaUtil.instance().getCacheParameters().getTttMaxLimit();
			if (maxLimit != -99 && volumeInt > maxLimit) {
				logger.warn(userDataBean.getRequestId() + "  " + TSSJavaUtil.getLogInitial("00215")
						+ " (IVR) >> volume [" + volume + "] is not valid " + "(can not be more than " + maxLimit
						+ ") so returning failure : msisdn [" + msisdn + "]");

				promptFilePath += IvrMenu.TRANSFER_VOLUME_EXCEEDED_WAV_IVR;
				userDataBean.setFilePath(promptFilePath);
				userDataBean.setResult(ResponseParameters.TRANSFER_VOLUME_EXCEED_IVR);
				return false;
			} else if (volumeInt <= 0) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00216")
						+ " >> (IVR) volume [" + volume + "] is not valid "
						+ "(should be more than 0) so returning failure : msisdn [" + msisdn + "]");
				promptFilePath += IvrMenu.INVALID_VOLUME_WAV_IVR;
				userDataBean.setFilePath(promptFilePath);
				userDataBean.setResult(ResponseParameters.INVALID_VOLUME_IVR);
				return false;
			}

			userDataBean.setVolume(volumeInt);
			// checking user has enough ttt and main account balance or not
			if (new ChargingManager().checkBalanceForTTTIvr(userDataBean) != CodeStatus.SUCCESS) {
				return false;
			}

		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >>(IVR) volume ["
					+ volume + "] is not valid " + "(must be an integer) so returning failure : msisdn [" + msisdn
					+ "]");
			String filePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
					+ File.separator + IvrMenu.INVALID_VOLUME_WAV_IVR;
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME_IVR);
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >>(IVR) volume ["
					+ volume + "] is not valid " + "(must be an integer) so returning failure : msisdn [" + msisdn
					+ "]");
			String filePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
					+ File.separator + IvrMenu.INVALID_VOLUME_WAV_IVR;
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME_IVR);
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00110") + " >>(IVR) volume ["
					+ volume + "] is not valid " + "(must be an integer) so returning failure : msisdn [" + msisdn
					+ "]");
			String filePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
					+ File.separator + IvrMenu.INVALID_VOLUME_WAV_IVR;
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME_IVR);
			return false;
		}
		return true;
	}

	/**
	 * This method is used to validate all the parameters for Data Macro Credit
	 * Service Conversion and set all the values into UserBean.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param serviceDetail
	 * @param actionType
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return boolean true (If all parameters are valid)/false
	 */
	public boolean validateForDMCConversion(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String subType, String serviceDetail, String actionType, UserDataBean userDataBean) {
		logger.info(requestId + " >> (DMC) Validating parameters for Data Macro Credit Conversion request for msisdn ["
				+ msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackPurchaseDetail("-1:-1");
		userDataBean.setServiceDetail(serviceDetail != null ? serviceDetail : userDataBean.getServiceDetail());

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00116") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " >> " + TSSJavaUtil.getLogInitial("00144") + " >>requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00145") + "  >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		// validating actionType
		try {
			userDataBean.setPackActionType(Integer.parseInt(actionType.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> actionType ["
					+ actionType + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> actionType ["
					+ actionType + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00114") + " >> actionType ["
					+ actionType + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}

	/**
	 * This method is used to validate all the parameter for Data Macro Credit
	 * Volume Based Conversion Service and set all the values into UserBean.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param dataToConvert
	 * @param digits
	 * @param packList
	 * @param actionType
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return boolean true (If all parameters are valid)/false
	 */
	public boolean validateForDMCPackDetails(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String dataToConvert, String digits, String packList, String actionType,
			UserDataBean userDataBean) {
		logger.info(requestId
				+ " >> (DMC) Validating parameters for Data Macro Credit Pack Details request for actionType ["
				+ actionType + "] and msisdn [" + msisdn + "]");

		String filePath = "";
		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean.setPackPurchaseDetail("-1:-1");
		userDataBean.setPackList(packList != null ? packList : userDataBean.getPackList());

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00116") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " >> " + TSSJavaUtil.getLogInitial("00144") + " >>requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00145") + "  >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		// validating digits
		try {
			userDataBean.setDigits(String.valueOf(Integer.parseInt(digits.trim())));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> digits [" + digits
					+ "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> digits [" + digits
					+ "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00114") + " >> digits [" + digits
					+ "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validate dataToConvert
		try {
			userDataBean.setDataToConvert(Integer.parseInt(dataToConvert.trim()));
		} catch (NullPointerException npe) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> dataToConvert ["
					+ dataToConvert + "] is not valid (must not be null)" + "so setting default ["
					+ userDataBean.getBalToConvert() + "] : msisdn [" + msisdn + "]");
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				filePath += IvrMenu.INVALID_VOLUME_WAV_IVR;
			} else {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_VOLUME + "_" + userDataBean.getLangId());
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_VOLUME, dataToConvert);
			}
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME);
			return false;
		} catch (NumberFormatException ex) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> dataToConvert ["
					+ dataToConvert + "] is not valid (must be an Integer number)" + "so setting default ["
					+ userDataBean.getBalToConvert() + "] : msisdn [" + msisdn + "]");
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				filePath += IvrMenu.INVALID_VOLUME_WAV_IVR;
			} else {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_VOLUME + "_" + userDataBean.getLangId());
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_VOLUME, dataToConvert);
			}
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME);
			return false;
		} catch (Exception e) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00098") + " >> dataToConvert ["
					+ dataToConvert + "] is not valid (must be a Integer number)" + "so setting default ["
					+ userDataBean.getBalToConvert() + "] : msisdn [" + msisdn + "]");
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				filePath += IvrMenu.INVALID_VOLUME_WAV_IVR;
			} else {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_VOLUME + "_" + userDataBean.getLangId());
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_VOLUME, dataToConvert);
			}
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME);
			return false;
		}

		// validating actionType
		try {
			userDataBean.setPackActionType(Integer.parseInt(actionType.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> actionType ["
					+ actionType + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> actionType ["
					+ actionType + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00114") + " >> actionType ["
					+ actionType + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}

	/**
	 * This method is used to validate all the parameter for Available Options for
	 * Data Macro Credit Volume Based Service (For New Multiple Configuration) and
	 * set all the parameter into UserBean if all the parameter are valid.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param dataToConvert
	 * @param actionType
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return boolean true (If all parameters are valid)/false
	 */
	public boolean validateForDMCAvailableOptions(String msisdn, String langId, String requestId, String interfaceUsed,
			String shortCode, String subType, String dataToConvert, String actionType, UserDataBean userDataBean) {
		logger.info(requestId
				+ " >> Validating parameters for Data Macro Credit Service to get available custom packs with actionType ["
				+ actionType + "] and  msisdn [" + msisdn + "]");
		String filePath = "";
		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackPurchaseDetail("-1:-1");

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00116") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " >> " + TSSJavaUtil.getLogInitial("00144") + " >>requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00145") + "  >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		// validate dataToConvert
		try {
			userDataBean.setDataToConvert(Integer.parseInt(dataToConvert.trim()));
		} catch (NullPointerException npe) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> dataToConvert ["
					+ dataToConvert + "] is not valid (must not be null)" + "so setting default ["
					+ userDataBean.getDataToConvert() + "] : msisdn [" + msisdn + "]");
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				filePath += IvrMenu.INVALID_VOLUME_WAV_IVR;
			} else {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_VOLUME + "_" + userDataBean.getLangId());
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_VOLUME, dataToConvert);
			}
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME);
			return false;
		} catch (NumberFormatException ex) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> dataToConvert ["
					+ dataToConvert + "] is not valid (must be an Integer number)" + "so setting default ["
					+ userDataBean.getDataToConvert() + "] : msisdn [" + msisdn + "]");
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				filePath += IvrMenu.INVALID_VOLUME_WAV_IVR;
			} else {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_VOLUME + "_" + userDataBean.getLangId());
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_VOLUME, dataToConvert);
			}
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME);
			return false;
		} catch (Exception e) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00098") + " >> dataToConvert ["
					+ dataToConvert + "] is not valid (must be a Integer number)" + "so setting default ["
					+ userDataBean.getBalToConvert() + "] : msisdn [" + msisdn + "]");
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				filePath += IvrMenu.INVALID_VOLUME_WAV_IVR;
			} else {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_VOLUME + "_" + userDataBean.getLangId());
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_VOLUME, dataToConvert);
			}
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME);
			return false;
		}

		// validating actionType
		try {
			userDataBean.setPackActionType(Integer.parseInt(actionType.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> actionType ["
					+ actionType + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> actionType ["
					+ actionType + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00114") + " >> actionType ["
					+ actionType + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}

	/**
	 * Used to validate parameters for User Active Data Account request and put all
	 * the parameters into a UserDataBean POJO
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param balance
	 * @param actionType
	 * @param subType
	 * @param packList
	 * @param digits
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return True (If all parameters are valid) / False
	 */
	public boolean validateForGetUserActiveServiceDataAccounts(String msisdn, String langId, String requestId,
			String interfaceUsed, String shortCode, String subType, String activeAccIdList, UserDataBean userDataBean) {
		logger.info(requestId
				+ " >> Validating parameters for validateForgetUserActiceServiceDataAccounts request for msisdn ["
				+ msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? !"".equals(shortCode) ? shortCode : userDataBean.getShortCode()
				: userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setActiveAccIdList(activeAccIdList != null ? activeAccIdList : userDataBean.getActiveAccIdList());

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException nfe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid, Cannot be parsed from String to Number so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00090") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		// Validating requestId and Interface
		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00091") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00092") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating MSISDN
		if (!isValidMSISDNForCheckProfile(msisdn, userDataBean)) {
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}

	/**
	 * Used to validate parameters for get user data account detail request and put
	 * all the parameters into a UserDataBean POJO
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param balance
	 * @param actionType
	 * @param subType
	 * @param packList
	 * @param digits
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return boolean true (If all parameters are valid) / false
	 */
	public boolean validateForGetUserDataAccountDetail(String msisdn, String langId, String requestId,
			String interfaceUsed, String shortCode, String subType, String activeAccIdList, String digits,
			UserDataBean userDataBean) {
		logger.info(requestId + " >> Validating parameters for validateForGetUserDataAccountDetail request for msisdn ["
				+ msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? !"".equals(shortCode) ? shortCode : userDataBean.getShortCode()
				: userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setActiveAccIdList(activeAccIdList != null ? activeAccIdList : userDataBean.getActiveAccIdList());

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException nfe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid, Cannot be parsed from String to Number so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00090") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		// Validating requestId and Interface
		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00091") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00092") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating MSISDN
		if (!isValidMSISDNForCheckProfile(msisdn, userDataBean)) {
			return false;
		}

		// validating digits
		try {
			userDataBean.setDigits(String.valueOf(Integer.parseInt(digits.trim())));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> digits ["
					+ digits + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> digits ["
					+ digits + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00114") + " >> digits ["
					+ digits + "] is not valid " + "(must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}

	/**
	 * 
	 * Used to validate parameters for data macro credit amount based conversion
	 * request and put all the parameters into a UserDataBean POJO.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param balToConvert
	 * @param userDataBean
	 * @return boolean true (If all parameters are valid) / false
	 */
	public boolean validateForDMCAmountBasedConversion(String msisdn, String langId, String requestId,
			String interfaceUsed, String shortCode, String subType, String balToConvert, UserDataBean userDataBean) {
		logger.info(requestId
				+ " >> Validating parameters for data macro credit amount based conversion request for msisdn ["
				+ msisdn + "]");
		String filePath = "";
		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackPurchaseDetail("-1:-1");

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00116") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " >> " + TSSJavaUtil.getLogInitial("00144") + " >>requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00145") + "  >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		// validate balToConvert
		try {
			userDataBean.setBalToConvert(Integer.parseInt(balToConvert.trim()));
		} catch (NullPointerException npe) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> balToConvert ["
					+ balToConvert + "] is not valid (must not be null)" + "so setting default ["
					+ userDataBean.getBalToConvert() + "] : msisdn [" + msisdn + "]");
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				filePath += IvrMenu.INVALID_VOLUME_WAV_IVR;
			} else {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_VOLUME + "_" + userDataBean.getLangId());
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_VOLUME, balToConvert);
			}
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME);
			return false;
		} catch (NumberFormatException ex) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> balToConvert ["
					+ balToConvert + "] is not valid (must be an Integer number)" + "so setting default ["
					+ userDataBean.getBalToConvert() + "] : msisdn [" + msisdn + "]");
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				filePath += IvrMenu.INVALID_VOLUME_WAV_IVR;
			} else {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_VOLUME + "_" + userDataBean.getLangId());
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_VOLUME, balToConvert);
			}
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME);
			return false;
		} catch (Exception e) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00098") + " >> balToConvert ["
					+ balToConvert + "] is not valid (must be a Integer number)" + "so setting default ["
					+ userDataBean.getBalToConvert() + "] : msisdn [" + msisdn + "]");
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				filePath += IvrMenu.INVALID_VOLUME_WAV_IVR;
			} else {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_VOLUME + "_" + userDataBean.getLangId());
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_VOLUME, balToConvert);
			}
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.INVALID_VOLUME);
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}

	/**
	 * Used to validate parameters for get promotional packs request and set all the
	 * values into the the UserDataBean.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param packTypeId
	 * @param packBrowseList
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param index
	 * @param balance
	 * @param packList
	 * @param userDataBean
	 * @param digit
	 * @return boolean true (If all parameters are valid)/false
	 */
	public boolean validateForGetPromotionPacks(String msisdn, String langId, String packTypeId, String packBrowseList,
			String requestId, String interfaceUsed, String shortCode, String subType, String index, String balance,
			String packList, UserDataBean userDataBean) {
		logger.info(
				requestId + " >> Validating parameters for get promotion packs request for msisdn [" + msisdn + "]");

		userDataBean.setPackBrowseList(packBrowseList);
		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackList(packList != null ? packList : userDataBean.getPackList());
		userDataBean.setIndex(index != null ? !"".equals(index) ? index.toUpperCase() : userDataBean.getIndex()
				: userDataBean.getIndex());

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >>langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException nfe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >>langId [" + langId
					+ "] is not valid, Cannot be parsed from String to Number so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00096") + " >>langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00126") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			}
			else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00127") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating packTypeId
		try {
			userDataBean.setPackTypeId(Integer.parseInt(packTypeId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00097") + " >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating balance
		try {
			userDataBean.setBalance(Double.parseDouble(balance.trim()));
		} catch (NullPointerException npe) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> balance ["
					+ balance + "] is not valid (must be a double number)" + "so setting default ["
					+ userDataBean.getBalance() + "] : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> balance ["
					+ balance + "] is not valid (must be a double number)" + "so setting default ["
					+ userDataBean.getBalance() + "] : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00098") + " >> balance ["
					+ balance + "] is not valid (must be a double number)" + "so setting default ["
					+ userDataBean.getBalance() + "] : msisdn [" + msisdn + "]");
			return false;
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		logger.info(userDataBean.getRequestId()
				+ " >> all parameters are valid for Promotional Packs : user data bean [" + userDataBean + "]");

		return true;

	}

	/**
	 * Used to validate parameters for get promotional packs description request and
	 * to prepare and put all the parameters into the userDataBean.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packList
	 * @param digits
	 * @param packTypeId
	 * @param userDataBean
	 * @return boolean true (If all parameters are valid)/false
	 */
	public boolean validateForGetPromoPackDescription(String msisdn, String langId, String requestId,
			String interfaceUsed, String shortCode, String subType, String packList, String digits, String balance,
			UserDataBean userDataBean) {
		logger.info(requestId + "  >> Validating parameters for get promotional pack description request for msisdn ["
				+ msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());
		userDataBean.setPackList(packList != null ? packList : userDataBean.getPackList());
		userDataBean.setDigits(digits);
		userDataBean.setBalance(Integer.parseInt(balance));

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + ">> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + ">> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00100") + ">> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00128") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00129") + ">> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		logger.info(userDataBean.getRequestId()
				+ " >> all parameters are valid for get paromotional packs description hit : user data bean ["
				+ userDataBean + "]");

		return true;

	}// validateForGetPromoPackDescription() method ends

	/**
	 * Used to validate parameters for purchase promotional pack request and to
	 * prepare and put all the parameters into UserDataBean.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param packBrowseList
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packId
	 * @param packTypeId
	 * @param userDataBean
	 * @return boolean true (If all parameters are valid)/false
	 */
	public boolean validateForPurchasePromoPack(String msisdn, String langId, String packBrowseList, String requestId,
			String interfaceUsed, String shortCode, String subType, String productCode, String packTypeId,
			UserDataBean userDataBean) {
		logger.info(requestId + "  >> Validating parameters for promotional pack purchase request for msisdn [" + msisdn
				+ "]");

		userDataBean.setPackBrowseList(packBrowseList != null ? packBrowseList : userDataBean.getPackBrowseList());
		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());
		userDataBean.setProductCode(productCode != null ? productCode : userDataBean.getProductCode());
		userDataBean
				.setSubType(subType != null ? !"".equals(subType) ? subType.toUpperCase() : userDataBean.getSubType()
						: userDataBean.getSubType());

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException ex) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00102") + " >> langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00130") + "  >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00131") + "  >> interface ["
						+ interfaceUsed + "] " + "must be of one character so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating packTypeId
		try {
			userDataBean.setPackTypeId(Integer.parseInt(packTypeId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00104") + ">> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + ">> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00104") + ">> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}

		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		logger.info(
				userDataBean.getRequestId() + "  >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForPurchasePromoPack() ends
	
	
	
	/**
	 * @author Sanchit Atri on 22/11/2021
	 * This method is used to validate the parameters of method referPack()
	 * 
	 * @param fmsisdn
	 * @param userDataBean
	 * @param msisdn
	 * @param langId
	 * @param packTypeId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @return true if all parameters are valid otherwise false
	 */
	public boolean validateForReferPacks(String msisdn, String langId, String packTypeId,
			String requestId, String interfaceUsed, String shortCode, UserDataBean userDataBean, String fmsisdn) {
		logger.info(requestId + " >> Validating parameters for get packs request for msisdn [" + msisdn + "]");

		userDataBean.setShortCode(shortCode != null ? shortCode : userDataBean.getShortCode());

		// validating language
		try {
			userDataBean.setLangId(Byte.parseByte(langId.trim()));
		} catch (NullPointerException npe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >>langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (NumberFormatException nfe) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >>langId [" + langId
					+ "] is not valid, Cannot be parsed from String to Number so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		} catch (Exception e) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00096") + " >>langId [" + langId
					+ "] is not valid so setting " + "default language ID ["
					+ TSSJavaUtil.instance().getCacheParameters().getDefaultLangId() + "] : msisdn [" + msisdn + "]");
			userDataBean.setLangId(TSSJavaUtil.instance().getCacheParameters().getDefaultLangId());
			return false;
		}

		if (requestId == null || "".equals(requestId) || interfaceUsed == null || "".equals(interfaceUsed)) {
			logger.error(requestId + " " + TSSJavaUtil.getLogInitial("00126") + " >> requestId [" + requestId
					+ "] or interface [" + interfaceUsed + "] " + "is null or blank so returning error : msisdn ["
					+ msisdn + "]");
			return false;
		} else {
			userDataBean.setRequestId(requestId.trim());
			if (interfaceUsed.trim().length() == 1) {
				userDataBean.setInterfaceUsed(interfaceUsed.trim().toUpperCase());
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00127") + " >> interface ["
						+ interfaceUsed + "] must be of one character " + "so returning error : msisdn [" + msisdn
						+ "]");
				return false;
			}
		}

		// validating packTypeId
		try {
			userDataBean.setPackTypeId(Integer.parseInt(packTypeId.trim()));
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00097") + " >> packTypeId ["
					+ packTypeId + "] is not valid (must be an integer) so returning error : msisdn [" + msisdn + "]");
			return false;
		}


		// validating MSISDN
		if (!isValidMSISDN(msisdn, userDataBean)) {
			return false;
		}

		// validating FMSISDN
				if (!isValidFMSISDNForReferral(fmsisdn, userDataBean)) {
					return false;
				}


		logger.info(
				userDataBean.getRequestId() + " >> all parameters are valid : user data bean [" + userDataBean + "]");

		return true;

	}// validateForReferPacks() ends
	
	/**
	 * This method is used to validate the FMSISDN
	 * 
	 * @param fmsisdn
	 * @param userDataBean
	 * @return true if FMSISDN is valid otherwise false
	 */
	private boolean isValidFMSISDNForReferral(String fmsisdn, UserDataBean userDataBean) {
		logger.debug(userDataBean.getRequestId() + " >> validating FMSISDN [" + fmsisdn + "]");

		// checking FMSISDN not to be null or blank
		if (fmsisdn == null || "".equals(fmsisdn)) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00082")
					+ " >> fmsisdn is blank or null [" + fmsisdn + "] so returning error");

			return false;
		}

		// checking FMSISDN in range and converting to international number
				StringBuffer interFMSISDN = new StringBuffer(fmsisdn);

				try {
					if (!TSSJavaUtil.instance().getInternationalNumber(interFMSISDN)) {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00080")
								+ " >> msisdn not in range [" + interFMSISDN + "] so returning error");
						return false;
					}
				} catch (NullPointerException npe) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
							+ " >> msisdn is not valid [" + interFMSISDN + "] so returning error");
					return false;
				} catch (Exception e) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00081")
							+ " >> msisdn is not valid [" + interFMSISDN + "] so returning error");
					return false;
				}

				userDataBean.setFmsisdn(interFMSISDN.toString());
				logger.debug(userDataBean.getRequestId() + " >> international number is [" + interFMSISDN + "] : msisdn ["
						+ fmsisdn + "]");
				return true;

	}// isValidFMSISDNForReferral() ends
	
}
