/**
 * @author Telemune
 */
package com.telemune.marketplace.manager;

import java.io.*;
import java.net.*;
import java.util.*; 
import java.lang.String;
import org.apache.log4j.*;

import com.telemune.marketplace.util.TSSJavaUtil;

/**
 * This class is used to interact with HLR interface for checking
 * subscriber type of user means pre-paid or post-paid
 * @author Telemune
 */
public class FetchMsrn
{

	private final static int SERVICE_NORMAL_MSRN = 1;
	private final static int SERVICE_INTERROGATE_MSRN = 15;
	private final static int SERVICE_FORWARDING_INFO = 2;
	private final static int SERVICE_ACTIVATE_SS = 3;
	private final static int SERVICE_DEACTIVATE_SS = 4;
	private final static int SERVICE_MSRN_NO_FORWARD = 5;
	private final static int SERVICE_SRI = 6;
	private final static int SERVICE_DEACTIVATE_IMSI = 12;
	private final static int SERVICE_ACTIVATE_IMSI = 13;
	private final static int SERVICE_RETRIEVE_IMSI = 9;
    private static Logger logger=Logger.getLogger(FetchMsrn.class);
    
   
	

    /**
     * This method is used to check subscriber type of MSISDN means
     * pre-paid or post-paid
     * @param service
     * @param msisdn
     * @param msrnBuf
     * @param mscNo
     * @param imsiBuf
     * @param scfAddress
     * @param serviceKey
     * @param isroaming
     * @param isprepaid
     * @param error
     * @param busyNumber
     * @param noReplyNumber
     * @param unreachableNumber
     * @param cfuActive
     * @param cfuActiveStr
     * @return if 1 means pre-paid else if 2 then post-paid
     */
	public static int fetchmsrn(int service, String msisdn, StringBuffer  msrnBuf, String mscNo, StringBuffer imsiBuf, String scfAddress, Integer serviceKey, Boolean isroaming, Boolean isprepaid, Integer error, String busyNumber, String noReplyNumber, String unreachableNumber, Boolean cfuActive, StringBuffer cfuActiveStr)
	{
		int retVal = -1;
		Socket socket = null;
		DataOutputStream writer = null;
		DataInputStream reader = null;
				
		logger.info("HLR IP ["+TSSJavaUtil.instance().getCacheParameters().getHlrIP()+"] " +
					"HLR PORT ["+TSSJavaUtil.instance().getCacheParameters().getHlrPort()+"] " +
					"Msisdn ["+msisdn+"]");

		try
		{
			socket = new Socket (TSSJavaUtil.instance().getCacheParameters().getHlrIP(),
								TSSJavaUtil.instance().getCacheParameters().getHlrPort());
			socket.setSoTimeout(TSSJavaUtil.instance().getCacheParameters().getHlrTimeout());
		}
		catch (SocketException se)
		{			
			logger.error(TSSJavaUtil.getLogInitial("90011")+"getting error in opening socket", se);			
			return -1;
		}
		catch (Exception e)
		{
			logger.error(TSSJavaUtil.getLogInitial("00025")+"getting error while opening socket", e);
			return -1;
		}
		logger.debug("Socket Connection established");
		String requestBuffer = "";
		int requestId = 1;

		requestBuffer = requestBuffer + requestId + "\n" + service;	
		String msrn = "";
		String imsi = "";
		String forwardNumber = "";


		switch(service)
		{
			case SERVICE_NORMAL_MSRN:    // request for normal msrn query...
			case SERVICE_INTERROGATE_MSRN:    // request for normal msrn query...
			case SERVICE_ACTIVATE_SS:		//	request for activate SS
			case SERVICE_DEACTIVATE_SS:		// request for deativate SS
			case SERVICE_RETRIEVE_IMSI:		// request for deativate SS
			case SERVICE_MSRN_NO_FORWARD:		//	request for msrn without forwarded info
			case SERVICE_SRI:		//	request for SRI..( to check prepaid)
				if (msisdn == null)
				{
					msisdn = "";
				}
				requestBuffer = requestBuffer + "\n" + msisdn;
				break;
			case SERVICE_FORWARDING_INFO:		//	request for update location...
			case SERVICE_DEACTIVATE_IMSI:
			case SERVICE_ACTIVATE_IMSI:
				if (msisdn == null)
				{
					msisdn = "";
				}
				if (mscNo == null)
				{
					mscNo = "";
				}
				requestBuffer = requestBuffer + "\n" + msisdn + "\n" + mscNo + "\n" + imsi;
				break;
			default:
				logger.warn(TSSJavaUtil.getLogInitial("00026")+ ">> Unknown Service Request\n");
		}

		int length = requestBuffer.length(); 

		
		try
		{
			reader = new DataInputStream(socket.getInputStream());
			writer = new DataOutputStream(socket.getOutputStream());
		}
		catch (IOException ioe)
		{
			logger.error(TSSJavaUtil.getLogInitial("90002")+"getting failed  to get input/output stream ", ioe);
			return -1;
		}
		catch(Exception e)
		{
			logger.error(TSSJavaUtil.getLogInitial("00027")+ "getting failed  to get input/output stream", e);
			return -1;
		}
		logger.debug("input/output stream established");

		try
		{
			logger.debug("writing to output stream");
			writer.writeInt (length);
			writer.write(requestBuffer.getBytes(), 0, requestBuffer.length());

			// This can be made a different method.
			//
			logger.debug("reading stream");
			int responseLen = reader.readInt();
			byte responseBuf[] = new byte[responseLen+1];
			reader.read(responseBuf, 0, responseLen);

			responseBuf[responseLen] = '\0';
			logger.debug("socket closed");

			String response = new String (responseBuf);
			logger.debug("response  "+response);
			// Parse the response string, it in the following form (each token is on seperate line)
			// 919821299990            -- msrn
			// 919821100002            -- vlr
			// 404.......              -- imsi
			// 919821900001						 -- scf Addr
			// 600										 -- servicekey
			// N                       -- roaming
			// N                       -- prepaid
			StringTokenizer st = new StringTokenizer(response);
			//String []tokens = response.split("\\n");
			String []tokens = new String[st.countTokens()];
			int ctr = 0;
			while(st.hasMoreTokens())
			{
				tokens[ctr]= st.nextToken();
				
				ctr++;
			}

			logger.info("Tokens Length [" + tokens.length + "]" );

			msrn = tokens[1];
			if (msrn.equals("NULL"))
			{
				msrn = "";
			}
			//msrnBuf = msrnBuf.append(msrn);


			mscNo = tokens[2];
			if (mscNo.equals("NULL"))
			{
				mscNo = "";
			}
			imsi = tokens[3];

			if (imsi.equals("NULL"))
			{
				imsi = "";
			}
			imsiBuf.append(imsi);

			scfAddress = tokens[4];
			if (scfAddress.equals("NULL"))
			{
				scfAddress = "";
			}
			try
			{
				serviceKey = new Integer(tokens[5]);
			}
			catch(NumberFormatException nfe)
			{
				serviceKey = new Integer(0);
				//nfe.printStackTrace();
				logger.error(TSSJavaUtil.getLogInitial("90004")+"getting error while parsing serviceKey token into Integer", nfe);
			}
			if (tokens[6].equals("N"))
			{
				isprepaid = new Boolean(false);
				retVal=2;
			}
			else
			{
				isprepaid = new Boolean(true);
				retVal=1;
			}
			logger.debug("6.Is  prepaid value  [ "+isprepaid+" ]  Token [6]");
			if (tokens[7].equals("N"))
				isroaming = new Boolean(false);
			else
			     isroaming = new Boolean(true);
				logger.debug("7.Is roaming is [ "+isroaming+" ]");        
			if (tokens[8].equals("NULL"))
			{
		         error = new Integer (0);
			}
			else
			{
				try
				{
					error = new Integer(tokens[8]);
				}
				catch(NumberFormatException nfe)
				{
					error = new Integer(-1);
					logger.error(TSSJavaUtil.getLogInitial("90004")+"getting error while parsing error token into Integer", nfe);

				}
		       	}
			logger.debug("8.Error Value [ "+error+" ]");

	busyNumber = tokens[9];
	if (busyNumber.equals("NULL"))
	{
		busyNumber = "";
	}

	logger.debug("9.Busy Number [ "+busyNumber+" ]");

	noReplyNumber = tokens[10];

	if (noReplyNumber.equals("NULL"))
	{
		noReplyNumber = "";
	}

	logger.debug("10.No Reply  Number [ "+noReplyNumber+" ]");

	unreachableNumber = tokens[11];

	if (unreachableNumber.equals("NULL"))
	{
		unreachableNumber = "";
	}

	logger.debug("11.Un Reachable  Number [ "+unreachableNumber+" ]");  
       //    if (tokens[11].equals("N"))

	if (tokens[12].charAt(0)=='N')
	{
		cfuActive = new Boolean(false);
		//cfuActiveStr=cfuActiveStr.append("false");
	}
	else
	{
		cfuActive = new Boolean(true);
		//	cfuActiveStr = cfuActiveStr.append("true");
	}


	logger.debug("12.CFU Active [ "+cfuActive+" ]");

	forwardNumber = tokens[13];
	if (forwardNumber.equals("NULL"))
	{
		forwardNumber = "";
	}

	//	msrnBuf = msrnBuf.append(forwardNumber);

	logger.debug("13.Forword Number [ "+cfuActive+" ]");


	logger.debug("Return Value from HLR is [ "+error.intValue()+" ] ");
     


	if (error.intValue() != 0)
	{
		logger.warn(TSSJavaUtil.getLogInitial("00028")+msisdn+"#Error Return From HLR Return Value is [ "+error.intValue()+" ]");
		retVal= -1; // Error Return From HLR
	}
	else
	{
		logger.info(msisdn+"#Success Return from HLR Return Value is [ "+error.intValue()+" ] Token 6 Value is [ "+tokens[6]+" ]");

		if (tokens[6].equalsIgnoreCase(("N")))
		{
			logger.info(msisdn+"# is Post Paid Number");

			retVal= 2;  // Postpaid Number

			//isprepaid = new Boolean(false);
		}
		else
		{
			logger.info(msisdn+"# is Prepaid Number");

			retVal=1;  // Prepaid Number

			// isprepaid = new Boolean(true);
		}
	}
          logger.info("exiting fetchmsrn:with  return value= "+error.intValue()+" isPrepaid["+isprepaid+"] retValue:["+retVal+"]");
          
      }
      catch(SocketException se)
      {
               logger.error(TSSJavaUtil.getLogInitial("90011")+"getting error in closing socket", se);
      }
      catch(Exception e)
      {	
		logger.error(TSSJavaUtil.getLogInitial("00029")+"getting error in fetchMsrn() ", e);
      }
	finally
	{
		try
		{
			socket.close();			
		}
		catch(Exception e)
		{
			logger.error(TSSJavaUtil.getLogInitial("00030")+"Exception while closing the socket connection",e);			
		}
	}
	
		return retVal;
   } //fetchmsrn
}