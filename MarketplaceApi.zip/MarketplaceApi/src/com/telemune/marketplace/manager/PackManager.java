package com.telemune.marketplace.manager;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.telemune.marketplace.beans.PackBean;
import com.telemune.marketplace.beans.PackPackTypeCommonBean;
import com.telemune.marketplace.beans.PackTypeBean;
import com.telemune.marketplace.beans.PromoPackBean;
import com.telemune.marketplace.beans.ServiceCharge;
import com.telemune.marketplace.beans.UserDataBean;
import com.telemune.marketplace.db.DBOperations;
import com.telemune.marketplace.util.CodeStatus;
import com.telemune.marketplace.util.IvrMenu;
import com.telemune.marketplace.util.MPCommonDataTypes;
import com.telemune.marketplace.util.ResponseParameters;
import com.telemune.marketplace.util.ServiceTypes;
import com.telemune.marketplace.util.TSSJavaUtil;
import com.telemune.marketplace.util.UssdMenuNames;

/**
 * This class is created to to manage Packs and PackType
 * 
 * @author Siddharth
 */
public class PackManager {

	/**
	 * Used for printing logs in this class
	 */
	private static Logger logger = Logger.getLogger(PackManager.class);

	/**
	 * This method is used to fetch the system packs and categories dynamically
	 * according to the provided hierarchy and order of packs or categories.
	 * 
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return Code Status
	 */
	public CodeStatus fetchAvailablePacks(UserDataBean userDataBean) {
		logger.info(" >> Loading packs according to UserDataBean received. UserDataBean [" + userDataBean + "]");

		if (userDataBean == null)
			return CodeStatus.FAILURE;

		String retString = "";
		String getPackKey = "";
		String getPackTypeKey = "";
		String filePath = "";
		int tempPackTypeId = -1;
		ArrayList<PackBean> allAvailablePackList = new ArrayList<PackBean>();
		ArrayList<PackTypeBean> allAvailablePackTypeList = new ArrayList<PackTypeBean>();
		ArrayList<PackPackTypeCommonBean> packPackTypeList = new ArrayList<PackPackTypeCommonBean>();
		try {
			if (!userDataBean.getPackList().equalsIgnoreCase("NA") && !userDataBean.getPackList().equals("")) {
				String[] packListArr = userDataBean.getPackList().split(",");

				if (!userDataBean.getDigits().equalsIgnoreCase("N")) {

					if (!TSSJavaUtil.isInteger(userDataBean.getDigits())) {
						filePath = TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId());
						userDataBean.setResult(ResponseParameters.FAILURE);
						userDataBean.setFilePath(filePath);
						logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00342") + " digit["
								+ userDataBean.getDigits() + "] is not valid, digit Must be an Integer. MSISDN:["
								+ userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}

					int digits = Integer.parseInt(userDataBean.getDigits());
					logger.debug(userDataBean.getRequestId() + "] >>  digits:[" + digits + "] packListArr length:["
							+ packListArr.length + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
					if (digits <= 0 || digits > packListArr.length) {
						// INVALID REQUEST if digit value pressed is more than available packs in menu
						filePath = TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId());
						userDataBean.setResult(ResponseParameters.FAILURE);
						userDataBean.setFilePath(filePath);
						logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00250")
								+ " ] >>  total returned file path length:[" + filePath.length() + "] MSISDN:["
								+ userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					} else {
						String packId = packListArr[digits - 1];
						tempPackTypeId = userDataBean.getPackTypeId();

						logger.info("TSSJavaUtil.instance().getCacheParameters().getPackTypeDetailsMap() ==>> "
								+ TSSJavaUtil.instance().getCacheParameters().getPackTypeDetailsMap()
										.get(Integer.parseInt(packId)));
						if (TSSJavaUtil.instance().getCacheParameters().getPackTypeDetailsMap()
								.get(Integer.parseInt(packId)) != null) {
							userDataBean.setBasePackType(TSSJavaUtil.instance().getCacheParameters()
									.getPackTypeDetailsMap().get(Integer.parseInt(packId)).getBasePackType());

						}
						userDataBean.setPackTypeId(Integer.parseInt(packId));
						logger.debug(userDataBean.getRequestId() + "] >>  packTypeId:[" + userDataBean.getPackTypeId()
								+ "], BasePackType:[" + userDataBean.getBasePackType() + "], SelectedPackId:[" + packId
								+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
					}
				}
			}

			getPackTypeKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId();
			getPackKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();

			if (userDataBean.getIsPackType().equalsIgnoreCase("Y")) {
				logger.info(userDataBean.getRequestId() + " >> key for available pack Type is getPackKey:[" + getPackKey
						+ "] getPackTypeKey:[" + getPackTypeKey + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

				allAvailablePackTypeList = TSSJavaUtil.instance().getCacheParameters().getAvailablePackTypeMap()
						.get(getPackTypeKey);
				allAvailablePackList = TSSJavaUtil.instance().getCacheParameters().getAvailablePacksMap()
						.get(getPackKey);

				logger.info(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00331")
						+ " >> allAvailablePackTypeList: " + allAvailablePackTypeList + ",  allAvailablePackList:"
						+ allAvailablePackList);

				if (allAvailablePackList == null && allAvailablePackTypeList == null) {
					logger.info(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00329")
							+ " >>  No pack type or pack found for user, pack key is:[" + getPackKey
							+ "], pack type key:[" + getPackTypeKey + "] " + "MSISDN:[" + userDataBean.getMsisdn()
							+ "]");

					// TODO Need to modify to resolve bug fix
					logger.info(">> KEY ["
							+ userDataBean.getPackActionType() + "] value [" + TSSJavaUtil.instance()
									.getCacheParameters().getAvailablePackTypes().get(userDataBean.getPackActionType())
							+ "] MSISDN [" + userDataBean.getMsisdn() + "]");

					userDataBean.setResult(ResponseParameters.NO_SUB_CATEGORIES);
					userDataBean.setFilePath(MPCommonDataTypes.NO_FILE_PATH);
					userDataBean.setPackTypeId(tempPackTypeId);
					userDataBean.setIsPackType("D");

					return CodeStatus.FAILURE;
				} else if (allAvailablePackTypeList == null) {
					logger.info(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00330")
							+ " >>  No pack type found for user, key is [" + getPackTypeKey + "] " + "MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.NO_SUB_CATEGORIES);
					userDataBean.setFilePath(MPCommonDataTypes.NO_FILE_PATH);
					userDataBean.setIsPackType("N");
					userDataBean.setPackList("NA");
				}

			}

			else if (userDataBean.getIsPackType().equalsIgnoreCase("N")) {
				logger.info(userDataBean.getRequestId() + " >> key for available packs is getPackKey:[" + getPackKey
						+ "], isPackType:[" + userDataBean.getIsPackType() + "] MSISDN:[" + userDataBean.getMsisdn()
						+ "]");

				if (allAvailablePackList == null || allAvailablePackList.isEmpty()) {
					allAvailablePackList = TSSJavaUtil.instance().getCacheParameters().getAvailablePacksMap()
							.get(getPackKey);
				}

				if (allAvailablePackList == null) {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00219")
							+ " >>  No packs found for user, key is [" + getPackKey + "] " + "MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					userDataBean.setFilePath(MPCommonDataTypes.NO_FILE_PATH);
					userDataBean.setResult(ResponseParameters.NO_SUB_CATEGORIES);
					userDataBean.setPackTypeId(tempPackTypeId);
					userDataBean.setIsPackType("D");
					return CodeStatus.FAILURE;
				}

			}

			else {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00328")
						+ " >> proper isPackType key is not forund, isPackType:[" + userDataBean.getIsPackType() + "] "
						+ "MSISDN:[" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(MPCommonDataTypes.NO_FILE_PATH);
				return CodeStatus.FAILURE;
			}

			fillPacks(allAvailablePackList, packPackTypeList);
			fillPackType(allAvailablePackTypeList, packPackTypeList);

			Collections.sort(packPackTypeList);
			logger.debug("packPackTypeList : " + packPackTypeList);

			boolean isBalanceEnable = TSSJavaUtil.instance().getCacheParameters().isPackBasedOnBalanceEnable();

			logger.debug(userDataBean.getRequestId() + " >>  received Pack List in request is:["
					+ userDataBean.getPackList() + "], MSISDN:[" + userDataBean.getMsisdn() + "]");
			// if current pack list is empty then this is first request for
			// getPacks
			if ((userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList()))
					&& "N".equalsIgnoreCase(userDataBean.getIndex())
					|| !userDataBean.getDigits().equalsIgnoreCase("N")) {
				retString = getPacksForFirstRequest(userDataBean, packPackTypeList, isBalanceEnable);
			} else {
				// else block is used for Next/Previous/Same request
				if (userDataBean.getIndex().equalsIgnoreCase("N")) {
					// If index is N then request for Next Packs
					retString = getNextReqPacks(userDataBean, packPackTypeList, isBalanceEnable);
				} else if (userDataBean.getIndex().equalsIgnoreCase("P")) {
					// If index is P then request for Previous Packs
					retString = getPrevReqPacks(userDataBean, packPackTypeList, isBalanceEnable);
				} else if (userDataBean.getIndex().equalsIgnoreCase("S")) {
					// If index is S then request is for same packs, which will
					// user requests from description of any pack and then
					// request for previous packs
					retString = getSameReqPacks(userDataBean, packPackTypeList, isBalanceEnable);
				}
			} // main else-if ends

		} catch (NullPointerException npe) {
			logger.error(
					userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
							+ " >> Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ",
					npe);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(
					userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00220")
							+ " >> Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ",
					e);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		}

		if (retString == null || "".equals(retString)) {
			logger.info(userDataBean.getRequestId() + " >>  MSISDN:[" + userDataBean.getMsisdn()
					+ "]  get response null in retString:[" + retString + "]");
			userDataBean.setResult(ResponseParameters.FAILURE);
			// userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR+"_"+userDataBean.getLangId()));
			// //file path already set from statement control returns
			return CodeStatus.FAILURE;
		}

		userDataBean.setResult(ResponseParameters.SUCCESS);
		logger.debug(userDataBean.getRequestId() + " >>  pack browsing list is:[" + userDataBean.getPackBrowseList()
				+ "] current pack list is:[" + userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn()
				+ "]");
		logger.info(userDataBean.getRequestId() + " >>  filePath returned to XML is:[" + userDataBean.getFilePath()
				+ "] result:[" + userDataBean.getResult() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		return CodeStatus.SUCCESS;
	}// fetchAvailablePacks() ends

	/**
	 * Used to find the pack id's according to request received from user
	 * 
	 * @param userDataBean
	 * @return
	 */
	public CodeStatus fetchAvailableLowBalancePacks(UserDataBean userDataBean) {
		logger.info(" >> Loading low balance packs according to UserDataBean received. UserDataBean [" + userDataBean
				+ "]");

		if (userDataBean == null)
			return CodeStatus.FAILURE;

		String retString = "";
		ArrayList<PackPackTypeCommonBean> commonPackPackTypeList = new ArrayList<PackPackTypeCommonBean>();
		try {
			String getPackKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			logger.info(userDataBean.getRequestId() + " >>  >> key for available low balance packs is getPackKey:["
					+ getPackKey + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			ArrayList<PackBean> allAvailablePackList = TSSJavaUtil.instance().getCacheParameters()
					.getAvailableLowBalancePacksMap().get(getPackKey);

			if (allAvailablePackList == null) {

				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00219")
						+ " >>  No packs found for user, key is [" + getPackKey + "] " + "MSISDN:["
						+ userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.NO_PACKS_AVAILABLE + "_" + userDataBean.getLangId()));

				return CodeStatus.FAILURE;
			}

			fillPacks(allAvailablePackList, commonPackPackTypeList);

			boolean isBalanceEnable = TSSJavaUtil.instance().getCacheParameters()
					.isLowBalancePackBasedOnBalanceEnable();

			logger.debug("Low Balance Packs :" + commonPackPackTypeList);
			logger.debug(userDataBean.getRequestId() + " >>  received Pack List in request is:["
					+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			// if current pack list is empty then this is first request for
			// getPacks
			if ((userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList()))
					&& "N".equalsIgnoreCase(userDataBean.getIndex())) {
				retString = getPacksForFirstRequest(userDataBean, commonPackPackTypeList, isBalanceEnable);
			} else {
				// else block is used for Next/Previous/Same request
				if (userDataBean.getIndex().equalsIgnoreCase("N")) {
					// If index is N then request for Next Packs
					retString = getNextReqPacks(userDataBean, commonPackPackTypeList, isBalanceEnable);
				} else if (userDataBean.getIndex().equalsIgnoreCase("P")) {
					// If index is P then request for Previous Packs
					retString = getPrevReqPacks(userDataBean, commonPackPackTypeList, isBalanceEnable);
				} else if (userDataBean.getIndex().equalsIgnoreCase("S")) {
					// If index is S then request is for same packs, which will
					// user requests from description of any pack and then
					// request for previous packs
					retString = getSameReqPacks(userDataBean, commonPackPackTypeList, isBalanceEnable);
				}
			} // main else-if ends

		} catch (NullPointerException npe) {
			logger.error(
					userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
							+ " >> Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ",
					npe);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(
					userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00220")
							+ " >> Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ",
					e);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		}

		if (retString == null || "".equals(retString)) {
			logger.info(userDataBean.getRequestId() + " >>  MSISDN:[" + userDataBean.getMsisdn()
					+ "]  get response null in retString:[" + retString + "]");
			userDataBean.setResult(ResponseParameters.FAILURE);
			// userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR+"_"+userDataBean.getLangId()));
			// //file path already set from statement control returns
			return CodeStatus.FAILURE;
		}

		userDataBean.setResult(ResponseParameters.SUCCESS);
		logger.debug(userDataBean.getRequestId() + " >>  pack browsing list is:[" + userDataBean.getPackBrowseList()
				+ "] current pack list is:[" + userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn()
				+ "]");
		logger.info(userDataBean.getRequestId() + " >>  filePath returned to XML is:[" + userDataBean.getFilePath()
				+ "] result:[" + userDataBean.getResult() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		return CodeStatus.SUCCESS;
	}// fetchAvailableLowBalancePacks() ends

	/**
	 * 
	 * @param userDataBean
	 * @param allAvailablePackList
	 * @return
	 */
	public String getPacksForFirstRequest(UserDataBean userDataBean, ArrayList<PackPackTypeCommonBean> packPackTypeList,
			boolean isBalanceEnable) {
		CodeStatus status = null;
		try {
			// packList is equal to null means it is first hit
			int currentPackIndex = 0; // used to iterate all available packs
			logger.info(userDataBean.getRequestId() + " >>  packTypeId:[" + userDataBean.getPackTypeId() + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			StringBuffer isMorePacksAvailable = new StringBuffer();

			currentPackIndex = getNextPacksForUserCriteria(currentPackIndex, packPackTypeList, userDataBean,
					isMorePacksAvailable, isBalanceEnable);

			if ("".equals(userDataBean.getPackList()) || userDataBean.getPackList() == null
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00221")
						+ " >> Pack List is null or empty, No packs available for User." + " packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.NO_PACKS_AVAILABLE + "_" + userDataBean.getLangId()));
				return null;
			}

			int moreMenuAvailable = packPackTypeList.size() - currentPackIndex;
			logger.debug(userDataBean.getRequestId() + " >> isMorePacksAvailable:[" + isMorePacksAvailable
					+ "] moreMenuAvailable:[" + moreMenuAvailable + "] available pack size:[" + packPackTypeList.size()
					+ "]  MSISDN:[" + userDataBean.getMsisdn() + "]");

			int maxUssdStringLengthAvailable = TSSJavaUtil.instance().getCacheParameters().getMaxUssdStringLength()// max
																													// allowed
																													// length
					- TSSJavaUtil.instance().getCacheParameters().getPackTypeDescription(userDataBean.getPackTypeId())
							.length()// header description of pack type
					- TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.PRESS + "_" + userDataBean.getLangId()).length()// press
																												// string(Tapez).
					- 2;// for 2 next lines

			if ((moreMenuAvailable > 0 && "1".equalsIgnoreCase(isMorePacksAvailable.toString()))
					|| (userDataBean.getFilePath().length() > maxUssdStringLengthAvailable)) {
				// we have to show the option for Next Menu but not for prev
				status = generateFilePathString(userDataBean, true, false);
			} else if (moreMenuAvailable == 0
					&& userDataBean.getFilePath().length() <= (maxUssdStringLengthAvailable)) {
				// we have to not to show the option for not Next Menu and also
				// not for prev
				status = generateFilePathString(userDataBean, false, false);
			} else if ((moreMenuAvailable == 0 && userDataBean.getFilePath()
					.length() > (maxUssdStringLengthAvailable - TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.STRING_NEXT_OPTION_PACKS + "_" + userDataBean.getLangId())
							.length()))) {
				// we have to show the option for Next Menu but not for prev
				status = generateFilePathString(userDataBean, true, false);
			} else {
				// no need to show the option for Next or prev Menu
				status = generateFilePathString(userDataBean, false, false);
			}
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> Exception occurred while fetching packs for user" + " MSISDN:[" + userDataBean.getMsisdn()
					+ "]", npe);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return null;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00222")
					+ " >> Exception occurred while fetching packs for user" + " MSISDN:[" + userDataBean.getMsisdn()
					+ "]", e);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return null;
		}

		if (status == CodeStatus.SUCCESS) {
			logger.info(userDataBean.getRequestId() + " >>  filePath generated for user to be shown is " + ":["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return userDataBean.getFilePath();
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00223")
					+ " >> filePath generated for user to be shown is " + ":[" + userDataBean.getFilePath()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return null;
		}

	}

	/**
	 * 
	 * @param userDataBean
	 * @param allAvailablePackList
	 * @return
	 */
	public String getNextReqPacks(UserDataBean userDataBean, ArrayList<PackPackTypeCommonBean> packPackTypeList,
			boolean isBalanceEnable) {
		CodeStatus status = null;

		try {
			logger.info(userDataBean.getRequestId() + " >>  packTypeId:[" + userDataBean.getPackTypeId() + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			String packList = userDataBean.getPackList();
			int tempIndex = packList.lastIndexOf(",");
			int currPackIndex = -1;

			logger.debug(userDataBean.getRequestId() + " >>  tempIndex:[" + tempIndex + "] Current Packs List:["
					+ packList + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			String tempPackId = null;
			if (tempIndex != -1) {
				// tempPackId is used to hold last Id of pack shown in previous
				// request
				tempPackId = packList.substring(tempIndex + 1);

			} else {
				if ((packList == null || "".equals(packList))) {
					// handle for if packList is empty
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00224")
							+ " >>received packList is empty in Next Option Menu request. PackList:[" + packList
							+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
					return null;
				} else {
					tempPackId = packList.trim();
				}
			}
			logger.debug(userDataBean.getRequestId() + " >>  tempPackId:[" + tempPackId + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			// currPackIndex hold index of current pack/packType id in arrayList
			for (PackPackTypeCommonBean commonBean : packPackTypeList) {
				if (commonBean.getPackType() == Integer.parseInt(tempPackId)
						|| commonBean.getPackId() == Integer.parseInt(tempPackId)) {
					currPackIndex = packPackTypeList.indexOf(commonBean);
					break;
				}
			}

			logger.debug(userDataBean.getRequestId() + " >>  currentPackIndex:[" + currPackIndex + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			if (currPackIndex == -1) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00225") + " >>  pack id:["
						+ tempPackId + "] not found in the list of available packs for user.  packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
				userDataBean.setPackList("");
				return null;
			}

			// means last shown pack was last pack available in system
			if (packPackTypeList.size() - 1 == currPackIndex) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00226")
						+ " >> No More packs available for User, so its invalid request. packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId()));
				return null;
			}

			StringBuffer isMorePacksAvailable = new StringBuffer();

			currPackIndex = getNextPacksForUserCriteria(currPackIndex + 1, packPackTypeList, userDataBean,
					isMorePacksAvailable, isBalanceEnable);
			logger.debug(userDataBean.getRequestId() + " >>  returned Pack Index:[" + currPackIndex + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			if ("".equals(userDataBean.getPackList()) || userDataBean.getPackList() == null
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00227")
						+ " >>  Pack List is null or empty, No More packs available for User, packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.NO_MORE_PACKS_AVAILABLE + "_" + userDataBean.getLangId()));
				return null;
			}

			int moreMenuAvailable = packPackTypeList.size() - currPackIndex;
			logger.debug(userDataBean.getRequestId() + " >>  isMorePacksAvailable:[" + isMorePacksAvailable
					+ "] moreMenuAvailable:[" + moreMenuAvailable + "] all available pack list size["
					+ packPackTypeList.size() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			int maxUssdStringLengthAvailable = TSSJavaUtil.instance().getCacheParameters().getMaxUssdStringLength()// max
																													// allowed
																													// length
					- TSSJavaUtil.instance().getCacheParameters().getPackTypeDescription(userDataBean.getPackTypeId())
							.length()// header description of pack type
					- TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.PRESS + "_" + userDataBean.getLangId()).length()// press
																												// string
					- 2;// for 2 next lines

			if ((moreMenuAvailable > 0 && "1".equalsIgnoreCase(isMorePacksAvailable.toString()))
					|| userDataBean.getFilePath().length() > maxUssdStringLengthAvailable) {
				// we have to show the option for Next Menu also for prev
				status = generateFilePathString(userDataBean, true, true);
			} else if (moreMenuAvailable == 0 && userDataBean.getFilePath()
					.length() <= (maxUssdStringLengthAvailable - TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.STRING_PREV_OPTION_PACKS + "_" + userDataBean.getLangId())
							.length())) {
				// we have to not to show the option for next Menu but for prev
				status = generateFilePathString(userDataBean, false, true);
			} else if ((moreMenuAvailable == 0 && userDataBean.getFilePath()
					.length() > (maxUssdStringLengthAvailable - TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.STRING_PREV_OPTION_PACKS + "_" + userDataBean.getLangId())
							.length()))) {
				// we have to show the option for Next Menu also for prev
				status = generateFilePathString(userDataBean, true, true);
			} else {
				// we have to show the option for prev Menu but not for next
				status = generateFilePathString(userDataBean, false, true);
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >>  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setPackList("");
			return null;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >>  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", ex);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setPackList("");
			return null;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00228") + " >>  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setPackList("");
			return null;
		}

		if (status == CodeStatus.SUCCESS) {
			logger.info(userDataBean.getRequestId() + " >>  filePath returned value is:[" + userDataBean.getFilePath()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return userDataBean.getFilePath();
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00233")
					+ " >>  filePath returned value is:[" + userDataBean.getFilePath() + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");
			return null;
		}

	}

	/**
	 * 
	 * @param userDataBean
	 * @param allAvailablePackList
	 * @return
	 */
	public String getPrevReqPacks(UserDataBean userDataBean, ArrayList<PackPackTypeCommonBean> packPackTypeList,
			boolean isBalanceEnable) {
		CodeStatus status = null;

		// hold index of current pack id in arrayList
		int currPackIndex = -1;
		try {
			String packList = userDataBean.getPackList();

			logger.info(userDataBean.getRequestId() + " >>  packTypeId:[" + userDataBean.getPackTypeId()
					+ "] packList [" + packList + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			int tempIndex = packList.indexOf(",");
			logger.debug(userDataBean.getRequestId() + " >>  tempIndex:[" + tempIndex + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");
			String tempPackId = null;
			if (tempIndex != -1) {

				// tempPackId is used to hold last Id of pack shown in previous request
				tempPackId = packList.substring(0, tempIndex);
			} else {
				if ((packList == null || "".equals(packList))) {
					// handle for if packList is empty
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00229")
							+ " >>  packList is empty or null[" + userDataBean.getPackList() + "] MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
					return null;
				} else {
					tempPackId = packList.trim();
				}
			}
			logger.debug(userDataBean.getRequestId() + " >>  tempPackId:[" + tempPackId + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			for (PackPackTypeCommonBean commonBean : packPackTypeList) {
				if (commonBean.getPackType() == Integer.parseInt(tempPackId)) {
					currPackIndex = packPackTypeList.indexOf(commonBean);
					break;
				}
				if (commonBean.getPackId() == Integer.parseInt(tempPackId)) {
					currPackIndex = packPackTypeList.indexOf(commonBean);
					break;
				}
			}

			if (currPackIndex == -1) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00230")
						+ " >> currPackIndex[" + currPackIndex + "] pack id:[" + tempPackId
						+ "] not found in the list of available packs for user.  packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
				userDataBean.setPackList("");
				return null;
			}

			currPackIndex = getPrevPacksForUserCriteria(currPackIndex - 1, packPackTypeList, userDataBean,
					isBalanceEnable);
			logger.debug(userDataBean.getRequestId() + " >>  returned PackIndex:[" + currPackIndex + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			if ("".equals(userDataBean.getPackList()) || userDataBean.getPackList() == null
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00231")
						+ " >>  Pack List is null or empty, No More packs available for User, so its invalid request. packList:["
						+ userDataBean.getPackList() + "]");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId()));
				return null;
			}

			// parameter to show Previous Menu Message in Previous request
			int moreMenuAvailable = packPackTypeList.size() - currPackIndex;
			logger.debug(userDataBean.getRequestId() + " >>  moreMenuAvailable:[" + moreMenuAvailable
					+ "] all available pack list size[" + packPackTypeList.size() + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			int maxUssdStringLengthAvailable = TSSJavaUtil.instance().getCacheParameters().getMaxUssdStringLength()// max
																													// allowed
																													// length
					- TSSJavaUtil.instance().getCacheParameters().getPackTypeDescription(userDataBean.getPackTypeId())
							.length()// header description of pack type
					- TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.PRESS + "_" + userDataBean.getLangId()).length()// press
																												// string
					- 2;// for 2 next lines

			if (moreMenuAvailable < packPackTypeList.size()
					|| userDataBean.getFilePath().length() > maxUssdStringLengthAvailable) {
				// we have to show the option for Next Menu also for prev
				status = generateFilePathString(userDataBean, true, true);
			} else if (moreMenuAvailable == packPackTypeList.size() && userDataBean.getFilePath()
					.length() <= (maxUssdStringLengthAvailable - TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.STRING_NEXT_OPTION_PACKS + "_" + userDataBean.getLangId())
							.length())) {
				// we have to show the option for Next Menu but not for prev
				status = generateFilePathString(userDataBean, true, false);
			} else if ((moreMenuAvailable == packPackTypeList.size() && userDataBean.getFilePath()
					.length() > (maxUssdStringLengthAvailable - TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.STRING_NEXT_OPTION_PACKS + "_" + userDataBean.getLangId())
							.length()))) {
				// we have to show the option for Next Menu also for prev
				status = generateFilePathString(userDataBean, true, true);
			} else {
				// we have to show the option for Next Menu but not for prev
				status = generateFilePathString(userDataBean, true, false);
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >>  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setPackList("");
			return null;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >>  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", ex);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setPackList("");
			return null;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00232") + " >>  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setPackList("");
			return null;
		}

		if (status == CodeStatus.SUCCESS) {
			logger.info(userDataBean.getRequestId() + " >>  filePath returned value is:[" + userDataBean.getFilePath()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return userDataBean.getFilePath();
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00234")
					+ " >>  filePath returned value is:[" + userDataBean.getFilePath() + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");
			return null;
		}
	}

	/**
	 * 
	 * @param userDataBean
	 * @param allAvailablePackList
	 * @return
	 */
	public String getSameReqPacks(UserDataBean userDataBean, ArrayList<PackPackTypeCommonBean> packPackTypeList,
			boolean isBalanceEnable) {
		try {
			logger.info(userDataBean.getRequestId() + " >>  packTypeId:[" + userDataBean.getPackTypeId() + "] "
					+ "packList [" + userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			int tempIndex = userDataBean.getPackList().indexOf(",");
			userDataBean.setFilePath("");
			String tempPackId = null;
			if (tempIndex != -1) {
				// tempPackId is used to hold first Id of pack shown in same request
				tempPackId = userDataBean.getPackList().substring(0, tempIndex);
			} else {
				if ("".equals(userDataBean.getPackList()) || userDataBean.getPackList() == null
						|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00235")
							+ " >>  Pack List is null or empty, packList:[" + userDataBean.getPackList() + "] MSISDN:["
							+ userDataBean.getMsisdn() + "] ");
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
					userDataBean.setPackList("");
					return null;
				} else {
					// if only one pack id is in request userDataBean pack list
					tempPackId = userDataBean.getPackList().trim();
				}
			}
			logger.debug(userDataBean.getRequestId() + " >>  tempPackId:[" + tempPackId + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			// currPackIndex hold index of current pack id in arrayList
			short firstIndex = (short) packPackTypeList.indexOf(new PackBean(Integer.parseInt(tempPackId)));
			short lastIndex = firstIndex;
			logger.debug(userDataBean.getRequestId() + " >> currPackIndex:[" + firstIndex + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");
			PackPackTypeCommonBean commonBean = null;

			if (firstIndex == -1) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00236") + " >>   pack id:["
						+ tempPackId + "] not found in the list of available packs for user. packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
				userDataBean.setPackList("");
				return null;
			}

			if (userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00237")
						+ " >> Pack List is null or empty, packList:[" + userDataBean.getPackList() + "] MSISDN:["
						+ userDataBean.getMsisdn() + "] ");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId()));
				return null;
			}

			String[] packListArr = userDataBean.getPackList().split(",");
			logger.debug(userDataBean.getRequestId() + " >>  packListArr Length:[" + packListArr.length + "] ");
			if (packListArr.length > 1) {
				for (int i = 1; i <= packListArr.length; i++, lastIndex++) {
					commonBean = packPackTypeList.get(lastIndex);
					userDataBean
							.setFilePath(userDataBean.getFilePath()
									+ TSSJavaUtil.instance().getCacheParameters()
											.getUssdMenuString(UssdMenuNames.STRING_FOR_USSD_PACKS + "_"
													+ userDataBean.getLangId())
											.replace("@@@", String.valueOf(i))
									+ commonBean.getPackPackTypeName() + "\n");

					// \n is used to end one Pack Description
				}
				lastIndex--; // decremented because to updated to last
								// traversing index
			} else {
				commonBean = packPackTypeList.get(lastIndex);
				userDataBean
						.setFilePath(
								userDataBean.getFilePath()
										+ TSSJavaUtil.instance().getCacheParameters()
												.getUssdMenuString(UssdMenuNames.STRING_FOR_USSD_PACKS + "_"
														+ userDataBean.getLangId())
												.replace("@@@", String.valueOf(1))
										+ commonBean.getPackPackTypeName() + "\n");
			}

			logger.debug(
					userDataBean.getRequestId() + " >>  firstIndex:[" + firstIndex + "] lastIndex:[" + lastIndex + "]");
			if (lastIndex < packPackTypeList.size() - 1)// next show
			{
				userDataBean
						.setFilePath(userDataBean.getFilePath()
								+ TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
										UssdMenuNames.STRING_NEXT_OPTION_PACKS + "_" + userDataBean.getLangId())
								+ "\n");
			}
			if (firstIndex > 0)// show prev
			{
				userDataBean
						.setFilePath(userDataBean.getFilePath()
								+ TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
										UssdMenuNames.STRING_PREV_OPTION_PACKS + "_" + userDataBean.getLangId())
								+ "\n");
			}

			userDataBean.setFilePath(userDataBean.getFilePath().substring(0, userDataBean.getFilePath().length() - 1));
			userDataBean.setPackBrowseList(userDataBean.getPackBrowseList() + "," + userDataBean.getPackList());

			logger.info(userDataBean.getRequestId() + " >>  MSISDN:[" + userDataBean.getMsisdn()
					+ "] filePath returned is:[" + userDataBean.getFilePath() + "]");
			return userDataBean.getFilePath();
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setPackList("");
			return null;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", ex);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setPackList("");
			return null;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00238") + " >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setPackList("");
			return null;
		}

	}

	/**
	 * 
	 * @param userDataBean
	 * @param showOptionForNext
	 * @param showOptionForPrev
	 */
	private CodeStatus generateFilePathString(UserDataBean userDataBean, boolean showOptionForNext,
			boolean showOptionForPrev) {
		logger.info(userDataBean.getRequestId() + " >>  filePath:[" + userDataBean.getFilePath() + "] "
				+ "showOptionForNext:[" + showOptionForNext + "] showOptionForPrev:[" + showOptionForPrev + "] "
				+ "MSISDN:[" + userDataBean.getMsisdn() + "] index:[" + userDataBean.getIndex() + "]");

		int filePathLength = userDataBean.getFilePath().length();

		int maxUssdStrLength = TSSJavaUtil.instance().getCacheParameters().getMaxUssdStringLength()// max
																									// allowed
																									// length
				- TSSJavaUtil.instance().getCacheParameters().getPackTypeDescription(userDataBean.getPackTypeId())
						.length()// header description of pack type
				- TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.PRESS + "_" + userDataBean.getLangId()).length()// press
																											// string
				- 2;// for 2 next lines

		String strNextPackMessage = TSSJavaUtil.instance().getCacheParameters()
				.getUssdMenuString(UssdMenuNames.STRING_NEXT_OPTION_PACKS + "_" + userDataBean.getLangId());
		int strNextPackLength = strNextPackMessage.length();

		String strPrevPackMessage = TSSJavaUtil.instance().getCacheParameters()
				.getUssdMenuString(UssdMenuNames.STRING_PREV_OPTION_PACKS + "_" + userDataBean.getLangId());
		int strPrevPackLength = strPrevPackMessage.length();

		logger.debug(userDataBean.getRequestId() + " >>  filePathLength:[" + filePathLength + "] maxUssdStrLength:["
				+ maxUssdStrLength + "] strNextPackMessage:[" + strNextPackMessage + "] strNextPackLength:["
				+ strNextPackLength + "] strPrevPackMessage:[" + strPrevPackMessage + "] strPrevPackLength:["
				+ strPrevPackLength + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		String tempFilePath = "";

		if (showOptionForNext == true && showOptionForPrev == true) {
			// to show both next and previous menu in filepath string
			int maxStrLength = maxUssdStrLength - (strNextPackLength + strPrevPackLength);

			if (maxStrLength <= 0) {
				// if maxStrLength is < 0 return from here only that
				// configuration of max ussd string length is not proper
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00239")
						+ " >>  Configuration of Maximum USSD string length is"
						+ " not proper, Increase length to show Packs to user. MSISDN:[" + userDataBean.getMsisdn()
						+ "]");
				tempFilePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
				userDataBean.setFilePath(tempFilePath);
				userDataBean.setPackList("");
				return CodeStatus.FAILURE;
			}

			logger.debug(userDataBean.getRequestId() + " >>  maxStrLength:[" + maxStrLength + "] MSISDN:["
					+ userDataBean.getMsisdn() + "] ");
			if ("P".equals(userDataBean.getIndex())) {
				if (filePathLength > maxStrLength)
					tempFilePath = userDataBean.getFilePath().substring(filePathLength - maxStrLength, filePathLength);
				else
					tempFilePath = userDataBean.getFilePath();

				logger.debug(userDataBean.getRequestId() + " >> tempFilePath:[" + tempFilePath + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				if (tempFilePath.startsWith("\n")) {
					logger.debug(userDataBean.getRequestId() + " >>  tempFilePath starts with \n MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					tempFilePath = tempFilePath.substring(1, tempFilePath.length());
				} else {
					logger.debug(userDataBean.getRequestId() + " >>  tempFilePath not starts with \n MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					int tempIndex = tempFilePath.indexOf("\n");
					logger.debug(userDataBean.getRequestId() + " >>  tempIndex:[" + tempIndex + "] MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					if (tempIndex != -1 && tempIndex != tempFilePath.length() - 1) {
						tempFilePath = tempFilePath.substring(tempIndex + 1, tempFilePath.length());
					} else {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00240")
								+ " >>  Configuration of Maximum USSD string "
								+ "length is not proper, Increase length to show Packs to user. MSISDN:["
								+ userDataBean.getMsisdn() + "]");
						tempFilePath = TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
						userDataBean.setFilePath(tempFilePath);
						userDataBean.setPackList("");
						return CodeStatus.FAILURE;
					}
				}
				// used to number pack names in previous request
				int i = 1;
				while (tempFilePath.contains("@@@")) {
					tempFilePath = tempFilePath.replaceFirst("@@@", String.valueOf(i));
					i++;
				}
			} else {
				if (filePathLength > maxStrLength)
					tempFilePath = userDataBean.getFilePath().substring(0, maxStrLength);
				else
					tempFilePath = userDataBean.getFilePath();

				int tempIndex = tempFilePath.lastIndexOf("\n");
				logger.debug(userDataBean.getRequestId() + " >>  tempIndex:[" + tempIndex + "] tempFilePath:" + "["
						+ tempFilePath + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				if (tempIndex > 0) {
					tempFilePath = tempFilePath.substring(0, tempIndex + 1);
				} else {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00241")
							+ " >>  Configuration of Maximum USSD string length is "
							+ "not proper, Increase length to show Packs to user. MSISDN:[" + userDataBean.getMsisdn()
							+ "]");
					tempFilePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
					userDataBean.setFilePath(tempFilePath);
					userDataBean.setPackList("");
					return CodeStatus.FAILURE;
				}
			}
			userDataBean.setFilePath(tempFilePath);
			this.generateResponseList(userDataBean, tempFilePath.split("\n").length);

			logger.debug(userDataBean.getRequestId() + " >> packList:[" + userDataBean.getPackList() + "] filePath:["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			tempFilePath = tempFilePath + strNextPackMessage + "\n" + strPrevPackMessage;

			logger.debug(userDataBean.getRequestId() + " >>  final retured tempFilePath length:["
					+ tempFilePath.length() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
			userDataBean.setFilePath(tempFilePath);
		} else if (showOptionForNext == true) {
			// to show both next and previous menu in filepath string
			int maxStrLength = maxUssdStrLength - (strNextPackLength);
			tempFilePath = null;
			logger.debug(userDataBean.getRequestId() + " >> maxStrLength:[" + maxStrLength + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			if (maxStrLength <= 0) {
				// if maxStrLength is < 0 return from here only that
				// configuration of max ussd string length is not proper
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00242")
						+ " >>  Configuration of Maximum USSD string length is not proper, Increase length to show Packs to user. MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				tempFilePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
				userDataBean.setFilePath(tempFilePath);
				userDataBean.setPackList("");
				return CodeStatus.FAILURE;
			}

			if ("P".equals(userDataBean.getIndex())) {
				if (filePathLength > maxStrLength)
					tempFilePath = userDataBean.getFilePath().substring(filePathLength - maxStrLength, filePathLength);
				else
					tempFilePath = userDataBean.getFilePath();

				logger.debug(userDataBean.getRequestId() + " >>  tempFilePath:[" + tempFilePath + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");

				if (tempFilePath.startsWith("\n")) {
					logger.debug(userDataBean.getRequestId() + " >>  tempFilePath starts with \n MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					tempFilePath = tempFilePath.substring(1, tempFilePath.length());
				} else {
					int tempIndex = tempFilePath.indexOf("\n");
					logger.debug(userDataBean.getRequestId() + " >>  tempIndex:[" + tempIndex + "] MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					if (tempIndex != -1 && tempIndex != tempFilePath.length() - 1) {
						// substring temp file path from index +1
						tempFilePath = tempFilePath.substring(tempIndex + 1, tempFilePath.length());
					} else {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00243")
								+ " >> Configuration of Maximum USSD string length is not proper, Increase length to show Packs to user. MSISDN:["
								+ userDataBean.getMsisdn() + "]");
						tempFilePath = TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
						userDataBean.setFilePath(tempFilePath);
						userDataBean.setPackList("");
						return CodeStatus.FAILURE;
					}
				}
				// used to number pack names in previous request
				int i = 1;
				while (tempFilePath.contains("@@@")) {
					tempFilePath = tempFilePath.replaceFirst("@@@", String.valueOf(i));
					i++;
				}

			} else {
				if (filePathLength > maxStrLength)
					tempFilePath = userDataBean.getFilePath().substring(0, maxStrLength);
				else
					tempFilePath = userDataBean.getFilePath();

				int tempIndex = tempFilePath.lastIndexOf("\n");
				logger.debug(userDataBean.getRequestId() + " >> tempIndex:[" + tempIndex + "] tempFilePath:["
						+ tempFilePath + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				if (tempIndex > 0) {
					tempFilePath = tempFilePath.substring(0, tempIndex + 1);
				} else {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00244")
							+ " >>  Configuration of Maximum USSD string length is not proper, Increase length to show Packs to user. MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					tempFilePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
					userDataBean.setFilePath(tempFilePath);
					userDataBean.setPackList("");
					return CodeStatus.FAILURE;
				}
			}

			userDataBean.setFilePath(tempFilePath);
			this.generateResponseList(userDataBean, tempFilePath.split("\n").length);
			logger.debug(userDataBean.getRequestId() + " >> packList:[" + userDataBean.getPackList() + "] filePath:["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			tempFilePath = tempFilePath + strNextPackMessage;
			logger.debug(userDataBean.getRequestId() + " >>  final retured tempFilePath:[" + tempFilePath.length()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			userDataBean.setFilePath(tempFilePath);
		} else if (showOptionForPrev) {
			// to show only previous menu string as next menu does not exist
			int maxStrLength = maxUssdStrLength - (strPrevPackLength);
			logger.debug(userDataBean.getRequestId() + " >>  maxStrLength:[" + maxStrLength + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			if (maxStrLength <= 0) {
				// if maxStrLength is < 0 return from here only that
				// configuration of max ussd string length is not proper
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00245")
						+ " >>  Configuration of Maximum USSD string length is not proper, Increase length to show Packs to user. MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				tempFilePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
				userDataBean.setFilePath(tempFilePath);
				userDataBean.setPackList("");
				return CodeStatus.FAILURE;
			}

			if ("P".equals(userDataBean.getIndex())) {
				if (maxStrLength < filePathLength)
					tempFilePath = userDataBean.getFilePath().substring(filePathLength - maxStrLength, filePathLength);
				else
					tempFilePath = userDataBean.getFilePath();

				logger.debug(userDataBean.getRequestId() + " >> tempFilePath:[" + tempFilePath + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");

				if (tempFilePath.startsWith("\n")) {
					logger.debug(userDataBean.getRequestId() + " >>  starts with \n. MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					tempFilePath = tempFilePath.substring(1, tempFilePath.length());
				} else {
					int tempIndex = tempFilePath.indexOf("\n");
					logger.debug(userDataBean.getRequestId() + " >>  tempIndex:[" + tempIndex + "] MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					if (tempIndex != -1 && tempIndex != tempFilePath.length() - 1) {
						tempFilePath = tempFilePath.substring(tempIndex + 1, tempFilePath.length());
					} else {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00246")
								+ " >>  Configuration of Maximum USSD string length is not proper, Increase length to show Packs to user. MSISDN:["
								+ userDataBean.getMsisdn() + "]");
						tempFilePath = TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
						userDataBean.setFilePath(tempFilePath);
						userDataBean.setPackList("");
						return CodeStatus.FAILURE;
					}
				}
				// used to number pack names in previous request
				int i = 1;
				while (tempFilePath.contains("@@@")) {
					tempFilePath = tempFilePath.replaceFirst("@@@", String.valueOf(i));
					i++;
				}

			} else {
				if (filePathLength > maxStrLength)
					tempFilePath = userDataBean.getFilePath().substring(0, maxStrLength);
				else
					tempFilePath = userDataBean.getFilePath();

				int tempIndex = tempFilePath.lastIndexOf("\n");
				logger.debug(userDataBean.getRequestId() + " >> tempIndex:[" + tempIndex + "] tempFilePath:["
						+ tempFilePath + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				if (tempIndex > 0) {
					tempFilePath = tempFilePath.substring(0, tempIndex + 1);
				} else {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00247")
							+ " >>  Configuration of Maximum USSD string length is not proper, Increase length to show Packs to user MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					tempFilePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
					userDataBean.setFilePath(tempFilePath);
					userDataBean.setPackList("");
					return CodeStatus.FAILURE;
				}

			}
			userDataBean.setFilePath(tempFilePath);
			this.generateResponseList(userDataBean, tempFilePath.split("\n").length);

			logger.debug(userDataBean.getRequestId() + " >> packList:[" + userDataBean.getPackList() + "] filePath:["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			tempFilePath = tempFilePath + strPrevPackMessage;

			logger.debug(userDataBean.getRequestId() + " >> final returned tempFilePath:[" + tempFilePath.length()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			userDataBean.setFilePath(tempFilePath);
		} else {
			this.generateResponseList(userDataBean, userDataBean.getFilePath().split("\n").length);
			logger.debug(userDataBean.getRequestId() + " >>  packList:[" + userDataBean.getPackList() + "] filePath:["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			logger.debug(userDataBean.getRequestId() + " >>  final retured tempFilePath:["
					+ userDataBean.getFilePath().length() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			// All pack Id's will be shown
		}

		// now appending header in packs
		String finalFilePath = TSSJavaUtil.instance().getCacheParameters()
				.getPackTypeDescription(userDataBean.getPackTypeId()) + "\n"
				+ TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
						UssdMenuNames.PRESS + "_" + userDataBean.getLangId())
				+ "\n" + userDataBean.getFilePath();
		userDataBean.setFilePath(finalFilePath);
		logger.debug(userDataBean.getRequestId() + " >>>  finalFilePath:[" + finalFilePath + "]   MSISDN:["
				+ userDataBean.getMsisdn() + "]");

		return CodeStatus.SUCCESS;

	}

	/**
	 * 
	 * @param currentPackIndex
	 * @param packPackTypeList
	 * @param userDataBean
	 * @return
	 */
	public int getNextPacksForUserCriteria(int currentPackIndex, ArrayList<PackPackTypeCommonBean> packPackTypeList,
			UserDataBean userDataBean, StringBuffer isMorePacksAvailable, boolean balanceBasedEnable) {
		logger.debug(userDataBean.getRequestId() + " >>  currentPackIndex:[" + currentPackIndex + "] MSISDN:["
				+ userDataBean.getMsisdn() + "]");
		int retCurrentIndex = -1;
		byte checkMaxMenus = 0; // used to check condition for max menu

		// maximum menus can be shown as configured in property file
		byte maxUssdMenus = TSSJavaUtil.instance().getCacheParameters().getMaxMenus();

		logger.info(userDataBean.getRequestId() + " >> all available packs for packTypeId:["
				+ userDataBean.getPackTypeId() + "] are:[" + packPackTypeList + "]  currentPackIndex:["
				+ currentPackIndex + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		PackPackTypeCommonBean commonBean = null;
		String filePath = "";

		// boolean balanceBasedEnable =
		// TSSJavaUtil.instance().getCacheParameters().isPackBasedOnBalanceEnable();
		logger.debug(userDataBean.getRequestId() + " >>  balanceBasedEnable:[" + balanceBasedEnable
				+ "], maxUssdMenus:[" + maxUssdMenus + "], MSISDN:[" + userDataBean.getMsisdn() + "]");
		userDataBean.setPackList("");

		for (retCurrentIndex = currentPackIndex; retCurrentIndex < packPackTypeList.size()
				&& checkMaxMenus < maxUssdMenus; retCurrentIndex++) {
			commonBean = packPackTypeList.get(retCurrentIndex);

			if (userDataBean.getIsPackType().equalsIgnoreCase("Y")) {

				if ((balanceBasedEnable && (commonBean.getAmountRequired() == -1
						|| commonBean.getAmountRequired() <= userDataBean.getBalance())) || !balanceBasedEnable) {

					filePath = filePath
							+ TSSJavaUtil.instance().getCacheParameters()
									.getUssdMenuString(
											UssdMenuNames.STRING_FOR_USSD_PACKS + "_" + userDataBean.getLangId())
									.replace("@@@", String.valueOf(checkMaxMenus + 1))
							+ commonBean.getPackPackTypeName() + "\n";
					// System.out.println(checkMaxMenus+ " ------ " + filePath);
					checkMaxMenus++;

					if (commonBean.getPackId() < 0) {
						userDataBean.setPackList(userDataBean.getPackList() + commonBean.getPackType() + ",");
					} else {
						userDataBean.setPackList(userDataBean.getPackList() + commonBean.getPackId() + ",");
					}
				}
			} else {
				if ((balanceBasedEnable && (commonBean.getAmountRequired() == -1
						|| commonBean.getAmountRequired() <= userDataBean.getBalance())) || !balanceBasedEnable) {
					// need to append file path

					filePath = filePath
							+ TSSJavaUtil.instance().getCacheParameters()
									.getUssdMenuString(
											UssdMenuNames.STRING_FOR_USSD_PACKS + "_" + userDataBean.getLangId())
									.replace("@@@", String.valueOf(checkMaxMenus + 1))
							+ commonBean.getPackPackTypeName() + "\n";
					checkMaxMenus++;
					userDataBean.setPackList(userDataBean.getPackList() + commonBean.getPackId() + ",");
					userDataBean.setCurrentPackTypeList(
							userDataBean.getCurrentPackTypeList() + commonBean.getCurrentPackType() + ",");
				}
			}
		}

		checkMaxMenus = (byte) retCurrentIndex; // checkMaxMenus is used to
												// check weather more packs are
												// available to user
		// code to check weather more packs are available to user according to
		// balance
		logger.debug("checkMaxMenu:[" + checkMaxMenus + "] size:[" + packPackTypeList.size() + "]");
		for (; checkMaxMenus < packPackTypeList.size(); checkMaxMenus++) {
			commonBean = packPackTypeList.get(checkMaxMenus);
			if (userDataBean.getIsPackType().equalsIgnoreCase("Y")) {
				isMorePacksAvailable.append(1);
				logger.debug(userDataBean.getRequestId()
						+ " >> still more PACK/PACK TYPE are available for user, isMorePacksAvailable:["
						+ isMorePacksAvailable + "]");
				break;
			} else {
				if ((balanceBasedEnable && (commonBean.getAmountRequired() == -1
						|| commonBean.getAmountRequired() <= userDataBean.getBalance()))
						// if balance needs to be checked and balance more than
						// amount
						|| !balanceBasedEnable
				// or balance does not matter
				// In these cases show the pack
				) {
					logger.debug("isMorePacksAvailable:[" + isMorePacksAvailable + "]");
					// if more packs available then append 1
					isMorePacksAvailable.append(1);
					logger.debug(userDataBean.getRequestId()
							+ " >> still more packs are available for user, isMorePacksAvailable:["
							+ isMorePacksAvailable + "]");
					break;
				}
			}
		}

		userDataBean.setFilePath(filePath);

		logger.debug(userDataBean.getRequestId() + ">>  returned current index:[" + retCurrentIndex
				+ "] total available packs size:[" + packPackTypeList.size() + "] MSISDN:[" + userDataBean.getMsisdn()
				+ "]");

		return retCurrentIndex;
	}

	/**
	 * 
	 * @param currentPackIndex
	 * @param allAvailablePackList
	 * @param userDataBean
	 * @return
	 */
	public int getPrevPacksForUserCriteria(int currentPackIndex, ArrayList<PackPackTypeCommonBean> packPackTypeList,
			UserDataBean userDataBean, boolean balanceBasedEnable) {
		logger.debug(userDataBean.getRequestId() + " >>  currentPackIndex:[" + currentPackIndex + "] MSISDN:["
				+ userDataBean.getMsisdn() + "]");
		int retCurrentIndex = -1;

		// used to check condition for max menu
		byte checkMaxMenus = 0;

		// maximum menus can be shown as configured in property file
		byte maxUssdMenus = TSSJavaUtil.instance().getCacheParameters().getMaxMenus();
		logger.info(
				userDataBean.getRequestId() + " >>  all available packs for packTypeId:[" + userDataBean.getPackTypeId()
						+ "] are:[" + packPackTypeList + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		PackPackTypeCommonBean commonBean = null;
		String filePath = "";
		String tempFilePath = "";
		String tempPackList = "";

		// boolean balanceBasedEnable =
		// TSSJavaUtil.instance().getCacheParameters().isPackBasedOnBalanceEnable();
		logger.debug(userDataBean.getRequestId() + " >>  balanceBasedEnable:[" + balanceBasedEnable + "] MSISDN:["
				+ userDataBean.getMsisdn() + "]");
		userDataBean.setPackList("");
		for (retCurrentIndex = currentPackIndex; retCurrentIndex >= 0
				&& checkMaxMenus < maxUssdMenus; retCurrentIndex--) {
			commonBean = packPackTypeList.get(retCurrentIndex);

			if ((balanceBasedEnable && (commonBean.getAmountRequired() == -1
					|| commonBean.getAmountRequired() <= userDataBean.getBalance()))
					// if balance needs to be checked and balance more than
					// amount
					|| !balanceBasedEnable
			// or balance does not matter
			// In these cases show the pack
			) {
				// need to append file path
				checkMaxMenus++;
				tempFilePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.STRING_FOR_USSD_PACKS + "_" + userDataBean.getLangId())
						+ commonBean.getPackPackTypeName() + "\n";

				filePath = tempFilePath + filePath;
				tempPackList = commonBean.getPackId() + ",";
				userDataBean.setPackList(tempPackList + userDataBean.getPackList());
			}
		}

		// if no pack found
		if (filePath == null || filePath.equalsIgnoreCase("")) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00248")
					+ " >>  No Packs Found for User :[" + userDataBean.getFilePath() + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
		}
		if (filePath.length() > 0 || filePath != null || !filePath.equalsIgnoreCase("")) {
			userDataBean.setFilePath("\n" + filePath);
		}

		logger.debug(userDataBean.getRequestId() + " >> retCurrentIndex:[" + retCurrentIndex
				+ "] total available packs size:[" + packPackTypeList.size() + "] MSISDN:[" + userDataBean.getMsisdn()
				+ "]");

		retCurrentIndex = retCurrentIndex + 1;
		return retCurrentIndex;
	}

	/**
	 * This method is used to generate response list
	 * 
	 * @param userDataBean
	 * @param totalPacksShown
	 */
	public void generateResponseList(UserDataBean userDataBean, int totalPacksShown) {
		logger.info(userDataBean.getRequestId()
				+ " >>  this method set currrent pack and currentPackType list which will be shown to user:  index:["
				+ userDataBean.getIndex() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

		logger.debug(userDataBean.getRequestId() + " >>  packList:[" + userDataBean.getPackList()
				+ "] currentPackTypeList:[" + userDataBean.getCurrentPackTypeList() + "] totalPackShown:["
				+ totalPacksShown + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		String packListArray[] = userDataBean.getPackList().split(",");
		String currentPackTypeListArray[] = null;

		if (!userDataBean.getCurrentPackTypeList().equalsIgnoreCase("NA")
				&& !userDataBean.getCurrentPackTypeList().isEmpty() && userDataBean.getCurrentPackTypeList() != null) {
			currentPackTypeListArray = userDataBean.getCurrentPackTypeList().split(",");
		}

		String tempPackList = "";
		String tempCurrentPackTypeList = "";

		if ("P".equals(userDataBean.getIndex())) {
			logger.debug(userDataBean.getRequestId() + " >>  x:[" + (packListArray.length - totalPacksShown)
					+ "] Array Length:[" + packListArray.length + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			for (int x = packListArray.length - totalPacksShown; x < packListArray.length; x++) {
				tempPackList += packListArray[x] + ",";
				if (!userDataBean.getCurrentPackTypeList().equalsIgnoreCase("NA")
						&& !userDataBean.getCurrentPackTypeList().isEmpty()
						&& userDataBean.getCurrentPackTypeList() != null) {
					tempCurrentPackTypeList += currentPackTypeListArray[x] + ",";
				}
			}
		} else {
			for (int x = 0; x < totalPacksShown; x++) {
				tempPackList += packListArray[x] + ",";
				if (!userDataBean.getCurrentPackTypeList().equalsIgnoreCase("NA")
						&& !userDataBean.getCurrentPackTypeList().isEmpty()
						&& userDataBean.getCurrentPackTypeList() != null) {
					tempCurrentPackTypeList += currentPackTypeListArray[x] + ",";
				}
			}
		}

		userDataBean.setPackList(tempPackList.substring(0, tempPackList.length() - 1));
		if (!tempCurrentPackTypeList.isEmpty() && tempCurrentPackTypeList != null) {
			userDataBean
					.setCurrentPackTypeList(tempCurrentPackTypeList.substring(0, tempCurrentPackTypeList.length() - 1));
		}

		if (userDataBean.getPackBrowseList() == null || "".equals(userDataBean.getPackBrowseList())) {
			userDataBean.setPackBrowseList(userDataBean.getPackList());
		} else {
			userDataBean.setPackBrowseList(userDataBean.getPackBrowseList() + "," + userDataBean.getPackList());
		}
		logger.debug(userDataBean.getRequestId() + " >>  Current Pack List:[" + userDataBean.getPackList()
				+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

	}

	/**
	 * This method is used to get pack description according to digits pressed by
	 * user packList is split into array and using pressed digits pack id is found
	 * 
	 * @param userDataBean
	 * @return
	 */
	public CodeStatus fetchPackDescription(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + "] >>  fecthing pack description for Pack List (PackId):["
				+ userDataBean.getPackList() + "] digits:[" + userDataBean.getDigits() + "]  MSISDN:["
				+ userDataBean.getMsisdn() + "]");
		String filePath = null;
		try {
			if (userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00249")
						+ " ] >>  packList is empty or null or NA [" + userDataBean.getPackList() + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePath);
				return CodeStatus.FAILURE;
			}

			String[] packListArr = userDataBean.getPackList().split(",");

			int digits = Integer.parseInt(userDataBean.getDigits());
			logger.debug(userDataBean.getRequestId() + "] >>  digits:[" + digits + "] packListArr length:["
					+ packListArr.length + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			if (digits <= 0 || digits > packListArr.length) {
				// INVALID REQUEST if digit value pressed is more than available
				// packs in menu
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId());
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePath);
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00250")
						+ " ] >>  total returned file path length:[" + filePath.length() + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				return CodeStatus.FAILURE;
			} else {
				String packId = packListArr[digits - 1];
				if (userDataBean.getIsLowBalancePack().equalsIgnoreCase("Y")) {
					if (userDataBean.getCurrentPackTypeList().isEmpty() || userDataBean.getCurrentPackTypeList() == null
							|| userDataBean.getCurrentPackTypeList().equalsIgnoreCase("NA")) {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00249")
								+ " ] >>  CurrentPackTypeList is empty or null ["
								+ userDataBean.getCurrentPackTypeList() + "] MSISDN:[" + userDataBean.getMsisdn()
								+ "]");
						filePath = TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
						userDataBean.setResult(ResponseParameters.FAILURE);
						userDataBean.setFilePath(filePath);
						return CodeStatus.FAILURE;
					}

					userDataBean.setPackTypeId(
							Integer.parseInt(userDataBean.getCurrentPackTypeList().split(",")[digits - 1]));

				}

				userDataBean.setPackId(Integer.parseInt(packId));
				logger.debug(userDataBean.getRequestId() + "] >>  packId:[" + userDataBean.getPackId() + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");

				String getPackKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
						+ userDataBean.getSubType();
				logger.info(userDataBean.getRequestId() + "] >>  >> key for available packs is getPackKey:["
						+ getPackKey + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

				ArrayList<PackBean> allAvailablePackList = TSSJavaUtil.instance().getCacheParameters()
						.getAvailablePacksMap().get(getPackKey);
				if (allAvailablePackList == null) {
					logger.error(
							userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00251") + " ] >> MSISDN:["
									+ userDataBean.getMsisdn() + "] pack list not found for user so sending failure");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
					userDataBean.setPackId(-1);
					return CodeStatus.FAILURE;
				}

				int packIndex = allAvailablePackList.indexOf(new PackBean(userDataBean.getPackId())); // packIndex
																										// hold
																										// index
																										// of
																										// current
																										// pack
																										// id
																										// in
																										// arrayList
				if (packIndex < 0) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00252")
							+ " ] >> MSISDN:[" + userDataBean.getMsisdn() + "] pack id not found in the list of packs "
							+ "for user so sending failure");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
					userDataBean.setPackId(-1);
					return CodeStatus.FAILURE;
				}

				PackBean packBean = allAvailablePackList.get(packIndex);
				logger.debug("packBean" + packBean.toString());

				// For handling low balance of User
				if (packBean.getAmountRequired() > userDataBean.getBalance()) {
					// System.out.println("inside low balance");
					logger.info(userDataBean.getRequestId() + " MSISDN[" + userDataBean.getMsisdn() + "] "
							+ "User has Low Balance for purhcasing pack. User Balance [" + userDataBean.getBalance()
							+ "] " + "Amount Require to purchase Pack [" + packBean.getAmountRequired() + "]");
					filePath = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.PACK_PURCHASE_LOW_BALANCE + "_" + userDataBean.getLangId());

					String[] filePathArr = filePath.split("##");

					if (filePathArr.length == 3) {
						if (TSSJavaUtil.instance().getCacheParameters().getShowBalanceInLowBalanceMsg() == 1) {
							filePath = filePathArr[0] + filePathArr[1].replace("$(BALANCE)",
									String.valueOf((int) userDataBean.getBalance())) + filePathArr[2];
						} else {
							filePath = filePathArr[0] + filePathArr[2];
						}
					}

					if (TSSJavaUtil.instance().getCacheParameters().getFallBackEnable() == 1) {
						userDataBean.setResult(ResponseParameters.LOW_BALANCE);
					} else {
						userDataBean.setResult(ResponseParameters.LOW_BALANCE_FALL_BACK_DISABLE);
					}
					userDataBean.setFilePath(filePath);
					return CodeStatus.FAILURE;

				}

				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_CONFIRM + "_" + userDataBean.getLangId());

				logger.debug("Other Details :" + packBean.getPackOtherDetails());
				// For VAS-Services
				if (packBean.getPackOtherDetails() != null) {
					logger.debug("Other Details :" + packBean.getPackOtherDetails());
					userDataBean.setPackActionType(packBean.getPackOtherDetails().getPackActionType());

					if (packBean.getPackOtherDetails().getPackActionType() == MPCommonDataTypes.VAS_SMS_ACTION_TYPE) {
						filePath = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
								UssdMenuNames.VAS_SMS_PACK_PURCHASE_CONFIRM + "_" + userDataBean.getLangId());
					}
				}

				if (UssdMenuNames.DEFAULT_MENU_STRING.equals(filePath)) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00253") + " >> "
							+ UssdMenuNames.PACK_PURCHASE_CONFIRM + " is "
							+ "not defined in USSD menus cache so returning error");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(filePath);
					return CodeStatus.FAILURE;
				}

				filePath = filePath.replace("$(pack_desc)", packBean.getDescription());
				filePath = filePath.replace("$(pack_name)", packBean.getPackName());

				ServiceCharge serviceCharge = TSSJavaUtil.instance().getCacheParameters()
						.getServiceChargeDetails(userDataBean.getPackId());

				if (serviceCharge == null) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00254")
							+ " >> Service charge details are not found for " + "pack id [" + userDataBean.getPackId()
							+ "] : msisdn [" + userDataBean.getMsisdn() + "]");

					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
					userDataBean.setPackId(-1);

					return CodeStatus.FAILURE;
				}

				// added to show pack amount in double/float if true else in
				// Integer
				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					filePath = filePath.replace("$(pack_amount)", String.valueOf(serviceCharge.getVolume()));
				} else {
					filePath = filePath.replace("$(pack_amount)", String.valueOf((int) serviceCharge.getVolume()));
				}

				int maxStrLength = TSSJavaUtil.instance().getCacheParameters().getMaxUssdStringLength();
				if (TSSJavaUtil.instance().getCacheParameters().isPrevOptionOnPackDescEnable()) {
					int showPrevOptionLenth = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.STRING_PREV_OPTION_PACKS + "_" + userDataBean.getLangId())
							.length();
					maxStrLength = maxStrLength - (showPrevOptionLenth + 1);
				}

				logger.debug(userDataBean.getRequestId() + "] >>  filePath length:[" + filePath.length()
						+ "] maxUssdLength:[" + maxStrLength + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				if (filePath.length() > maxStrLength) {
					filePath = filePath.substring(0, maxStrLength);
					logger.info(userDataBean.getRequestId()
							+ "] >>  Pack Description will not properly seen, check maximum ussd string length configuration. PackDescription:["
							+ filePath + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				}
				if (TSSJavaUtil.instance().getCacheParameters().isPrevOptionOnPackDescEnable()) {
					filePath = filePath + "\n" + TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.STRING_PREV_OPTION_PACKS + "_" + userDataBean.getLangId());
				}
				logger.debug(userDataBean.getRequestId() + "] >>  total returned file path length:[" + filePath.length()
						+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setFilePath(filePath);
				return CodeStatus.SUCCESS;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", ex);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00255") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		}

	}// fetchPackDescription() ends

	/**
	 * This method is used to get pack description based on pack Id
	 * 
	 * @param userDataBean
	 * @return
	 */
	public CodeStatus fetchPackDescriptionById(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + "] >>  fecthing pack description for PackId:["
				+ userDataBean.getPackId() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		String filePath = null;
		try {
			String getPackKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			logger.info(userDataBean.getRequestId() + "] >>  >> key for available packs is getPackKey:[" + getPackKey
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			ArrayList<PackBean> allAvailablePackList = TSSJavaUtil.instance().getCacheParameters()
					.getAvailablePacksMap().get(getPackKey);
			if (allAvailablePackList == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00256") + " ] >> MSISDN:["
						+ userDataBean.getMsisdn() + "] pack list not found for user so sending failure");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
				return CodeStatus.FAILURE;
			}

			int packIndex = allAvailablePackList.indexOf(new PackBean(userDataBean.getPackId())); // packIndex
																									// hold
																									// index
																									// of
																									// current
																									// pack
																									// id
																									// in
																									// arrayList
			if (packIndex < 0) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00257") + " ] >> MSISDN:["
						+ userDataBean.getMsisdn() + "] pack id not found in the list of packs "
						+ "for user so sending failure");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
				return CodeStatus.FAILURE;
			}
			PackBean packBean = allAvailablePackList.get(packIndex);

			filePath = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_CONFIRM + "_" + userDataBean.getLangId());
			if (UssdMenuNames.DEFAULT_MENU_STRING.equals(filePath)) {
				logger.error(userDataBean.getRequestId() + "  " + TSSJavaUtil.getLogInitial("00258") + "  >> "
						+ UssdMenuNames.PACK_PURCHASE_CONFIRM + " is "
						+ "not defined in USSD menus cache so returning error");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePath);
				return CodeStatus.FAILURE;
			}

			filePath = filePath.replace("$(pack_desc)", packBean.getDescription());
			filePath = filePath.replace("$(pack_name)", packBean.getPackName());

			ServiceCharge serviceCharge = TSSJavaUtil.instance().getCacheParameters()
					.getServiceChargeDetails(userDataBean.getPackId());
			if (serviceCharge == null) {
				logger.error(userDataBean.getRequestId() + "  " + TSSJavaUtil.getLogInitial("00259")
						+ " >> Service charge details are not found for " + "pack id [" + userDataBean.getPackId()
						+ "] : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));

				return CodeStatus.FAILURE;
			}

			// added to show pack amount in double/float if true else in Integer
			if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
				filePath = filePath.replace("$(pack_amount)", String.valueOf(serviceCharge.getVolume()));
			} else {
				filePath = filePath.replace("$(pack_amount)", String.valueOf((int) serviceCharge.getVolume()));
			}

			int maxStrLength = TSSJavaUtil.instance().getCacheParameters().getMaxUssdStringLength();

			logger.debug(userDataBean.getRequestId() + "] >>  filePath length:[" + filePath.length()
					+ "] maxUssdlENGTH:[" + maxStrLength + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			if (filePath.length() > maxStrLength) {
				filePath = filePath.substring(0, maxStrLength);
				logger.info(userDataBean.getRequestId()
						+ "] >> Pack Description will not properly seen, check maximum ussd string length configuration. PackDescription:["
						+ filePath + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			}
			// filePath = filePath+ "\n" +
			// TSSJavaUtil.instance().getCacheParameters().getStrForPreviousPacks();
			logger.debug(userDataBean.getRequestId() + "] >> total returned file path length:[" + filePath.length()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			userDataBean.setResult(ResponseParameters.SUCCESS);
			userDataBean.setFilePath(filePath);
			return CodeStatus.SUCCESS;

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00260") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		}

	}// fetchPackDescriptionById() ends

	/**
	 * This method is used to generate talk time transfer description according to
	 * fmsisdn and volume and net type entered by user
	 * 
	 * @param userDataBean
	 * @return
	 */
	public CodeStatus generateTTTDescription(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >>  generating talk time transfer description" + "MSISDN:["
				+ userDataBean.getMsisdn() + "] fmsisdn [" + userDataBean.getFmsisdn() + "] volume ["
				+ userDataBean.getVolume() + "] " + "net type [" + userDataBean.getNetType() + "]");
		String filePath = null;
		try {
			if (ServiceTypes.ON_NET.equals(userDataBean.getNetType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.TTT_CONFIRM_ONNET + "_" + userDataBean.getLangId());
				if (UssdMenuNames.DEFAULT_MENU_STRING.equals(filePath)) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00261") + " >> "
							+ UssdMenuNames.TTT_CONFIRM_ONNET + " is "
							+ "not defined in USSD menus cache so returning error");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(filePath);
					return CodeStatus.FAILURE;
				}
			} else if (ServiceTypes.OFF_NET.equals(userDataBean.getNetType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.TTT_CONFIRM_OFFNET + "_" + userDataBean.getLangId());
				if (UssdMenuNames.DEFAULT_MENU_STRING.equals(filePath)) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00262") + ">> "
							+ UssdMenuNames.TTT_CONFIRM_OFFNET + " is "
							+ "not defined in USSD menus cache so returning error");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(filePath);
					return CodeStatus.FAILURE;
				}
			} else if (ServiceTypes.EURO_OFF_NET.equals(userDataBean.getNetType())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.TTT_CONFIRM_EURO_OFFNET + "_" + userDataBean.getLangId());
				if (UssdMenuNames.DEFAULT_MENU_STRING.equals(filePath)) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00263") + " >> "
							+ UssdMenuNames.TTT_CONFIRM_EURO_OFFNET + " is "
							+ "not defined in USSD menus cache so returning error");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(filePath);
					return CodeStatus.FAILURE;
				}
			}

			filePath = filePath.replace("$(volume)", String.valueOf(userDataBean.getVolume()));
			filePath = filePath.replace("$(fmsisdn)", userDataBean.getFmsisdn());

			// added to show service charge in double/float if true else in
			// Integer
			if (ServiceTypes.ON_NET.equals(userDataBean.getNetType())) {
				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					filePath = filePath.replace("$(service_charge)",
							String.valueOf(TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOnNet()));
				} else {
					filePath = filePath.replace("$(service_charge)", String
							.valueOf((int) TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOnNet()));
				}
			} else if (ServiceTypes.OFF_NET.equals(userDataBean.getNetType())) {
				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					filePath = filePath.replace("$(service_charge)",
							String.valueOf(TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOffNet()));
				} else {
					filePath = filePath.replace("$(service_charge)", String
							.valueOf((int) TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOffNet()));
				}
			}

			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.SUCCESS);

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " ] >>MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.FAILURE;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00264") + " ] >>MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.FAILURE;
		}
		logger.debug(userDataBean.getRequestId() + "] >>  total returned file path length:[" + filePath.length()
				+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		userDataBean.setResult(ResponseParameters.SUCCESS);
		userDataBean.setFilePath(filePath);
		return CodeStatus.SUCCESS;
	}// generateTTTDescription() ends

	/**
	 * This method is used to generate bonus transfer description according to
	 * fmsisdn and pack id and pack type id
	 * 
	 * @param userDataBean
	 * @return
	 */
	public CodeStatus generateBonusTransferDesc(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >>  generating bonus transfer description" + "MSISDN:["
				+ userDataBean.getMsisdn() + "] fmsisdn [" + userDataBean.getFmsisdn() + "] digits ["
				+ userDataBean.getDigits() + "] " + "packTypeId [" + userDataBean.getPackTypeId() + "] packList ["
				+ userDataBean.getPackList() + "]");

		String filePath = null;

		try {
			if (userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00265")
						+ " ] >>  packList is empty or null or NA [" + userDataBean.getPackList() + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePath);
				return CodeStatus.FAILURE;
			}

			String[] packListArr = userDataBean.getPackList().split(",");

			int digits = Integer.parseInt(userDataBean.getDigits());
			logger.debug(userDataBean.getRequestId() + "] >>  digits:[" + digits + "] packListArr length:["
					+ packListArr.length + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			if (digits <= 0 || digits > packListArr.length) {
				// INVALID REQUEST if digit value pressed is more than available
				// packs in menu
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId());
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePath);
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00266")
						+ " ] >> digits pressed are not valid for this request MSISDN:[" + userDataBean.getMsisdn()
						+ "]");
				return CodeStatus.FAILURE;
			}

			String packId = packListArr[digits - 1];
			userDataBean.setPackId(Integer.parseInt(packId));

			String getPackKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			logger.info(userDataBean.getRequestId() + "] >>  >> key for available packs is getPackKey:[" + getPackKey
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			ArrayList<PackBean> allAvailablePackList = TSSJavaUtil.instance().getCacheParameters()
					.getAvailablePacksMap().get(getPackKey);
			if (allAvailablePackList == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00267") + " ] >> MSISDN:["
						+ userDataBean.getMsisdn() + "] pack list not found for user so sending failure");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
				return CodeStatus.FAILURE;
			}

			// packIndex hold index of current pack id in arrayList
			int packIndex = allAvailablePackList.indexOf(new PackBean(userDataBean.getPackId()));

			if (packIndex < 0) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00268") + " ] >> MSISDN:["
						+ userDataBean.getMsisdn() + "] pack id not found in the list of packs "
						+ "for user so sending failure");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
				return CodeStatus.FAILURE;
			}

			PackBean packBean = allAvailablePackList.get(packIndex);

			// For handling low balance of User
			if (packBean.getAmountRequired() > userDataBean.getBalance()) {
				logger.info(userDataBean.getRequestId() + " MSISDN[" + userDataBean.getMsisdn() + "] "
						+ "User has Low Balance for purhcasing pack. User Balance [" + userDataBean.getBalance() + "] "
						+ "Amount Require to purchase Pack [" + packBean.getAmountRequired() + "]");
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.BONUS_LOW_BALANCE + "_" + userDataBean.getLangId());
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setFilePath(filePath);
				return CodeStatus.FAILURE;

			}

			filePath = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.GIFT_BONUS_PACKAGE_CONFIRM + "_" + userDataBean.getLangId());
			if (UssdMenuNames.DEFAULT_MENU_STRING.equals(filePath)) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00269") + "  >> "
						+ UssdMenuNames.GIFT_BONUS_PACKAGE_CONFIRM + " is "
						+ "not defined in USSD menus cache so returning error");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePath);
				return CodeStatus.FAILURE;
			}

			filePath = filePath.replace("$(description)", packBean.getDescription());
			filePath = filePath.replace("$(fmsisdn)", userDataBean.getFmsisdn());

			ServiceCharge serviceCharge = TSSJavaUtil.instance().getCacheParameters()
					.getServiceChargeDetails(userDataBean.getPackId());

			if (serviceCharge == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00270")
						+ " >> Service charge details are not found for " + "pack id [" + userDataBean.getPackId()
						+ "] : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));

				return CodeStatus.FAILURE;
			}

			logger.debug(userDataBean.getRequestId() + "  >> Service charge details are " + serviceCharge);

			// added to show service_charge in double/float if true else in
			// Integer
			if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {

				filePath = filePath.replace("$(service_charge)",
						String.valueOf(serviceCharge.getServiceCharge() + serviceCharge.getVolume()));
				logger.debug(userDataBean.getRequestId() + " Addition of serv_charge and volume in float is  ####### "
						+ (serviceCharge.getServiceCharge() + serviceCharge.getVolume()));
				// filePath = filePath.replace("$(service_charge)",
				// String.valueOf(serviceCharge.getServiceCharge()));
			} else {
				logger.debug(userDataBean.getRequestId() + " Addition of serv_charge and volume in float is  ####### "
						+ (int) (serviceCharge.getServiceCharge() + serviceCharge.getVolume()));
				filePath = filePath.replace("$(service_charge)",
						String.valueOf((int) (serviceCharge.getServiceCharge() + serviceCharge.getVolume())));
				// filePath = filePath.replace("$(service_charge)",
				// String.valueOf((int)serviceCharge.getServiceCharge()));
			}

			filePath = filePath.replace("$(validity_days)", String.valueOf(serviceCharge.getValidity()));

			String validityTypeStr = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(serviceCharge.getValidityType().toUpperCase() + "_" + userDataBean.getLangId());
			filePath = filePath.replace("$(validity_type)", validityTypeStr);

			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.SUCCESS);

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Exception " + "occurred while generating bonus description ", npe);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.FAILURE;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Exception " + "occurred while generating bonus description ", ex);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.FAILURE;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00271") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Exception " + "occurred while generating bonus description ", e);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.FAILURE;
		}
		logger.debug(userDataBean.getRequestId() + "] >>  total returned file path length:[" + filePath.length()
				+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		userDataBean.setResult(ResponseParameters.SUCCESS);
		userDataBean.setFilePath(filePath);
		return CodeStatus.SUCCESS;
	}// generateBonusTransferDesc() ends

	/**
	 * This method is used to generate data transfer description according to
	 * fmsisdn and pack id and pack type id
	 * 
	 * @param userDataBean
	 * @return
	 */
	public CodeStatus generateDataTransferDesc(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >> generating data transfer description" + "MSISDN:["
				+ userDataBean.getMsisdn() + "] fmsisdn [" + userDataBean.getFmsisdn() + "] digits ["
				+ userDataBean.getDigits() + "] " + "packTypeId [" + userDataBean.getPackTypeId() + "] packList ["
				+ userDataBean.getPackList() + "]");

		String filePath = null;
		try {
			if (userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00272")
						+ " ] >> packList is empty or null or NA [" + userDataBean.getPackList() + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePath);
				return CodeStatus.FAILURE;
			}

			String[] packListArr = userDataBean.getPackList().split(",");

			int digits = Integer.parseInt(userDataBean.getDigits());
			logger.debug(userDataBean.getRequestId() + "] >> digits:[" + digits + "] packListArr length:["
					+ packListArr.length + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			if (digits <= 0 || digits > packListArr.length) {
				// INVALID REQUEST if digit value pressed is more than available
				// packs in menu
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId());
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePath);
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00273")
						+ " ] >> digits pressed are not valid for this request MSISDN:[" + userDataBean.getMsisdn()
						+ "]");
				return CodeStatus.FAILURE;
			}

			String packId = packListArr[digits - 1];
			userDataBean.setPackId(Integer.parseInt(packId));

			String getPackKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			logger.info(userDataBean.getRequestId() + "] >> key for available packs is getPackKey:[" + getPackKey
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			ArrayList<PackBean> allAvailablePackList = TSSJavaUtil.instance().getCacheParameters()
					.getAvailablePacksMap().get(getPackKey);
			if (allAvailablePackList == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00274") + " ] >> MSISDN:["
						+ userDataBean.getMsisdn() + "] pack list not found for user so sending failure");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
				return CodeStatus.FAILURE;
			}

			int packIndex = allAvailablePackList.indexOf(new PackBean(userDataBean.getPackId())); // packIndex
																									// hold
																									// index
																									// of
																									// current
																									// pack
																									// id
																									// in
																									// arrayList
			if (packIndex < 0) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00275") + " ] >> MSISDN:["
						+ userDataBean.getMsisdn() + "] pack id not found in the list of packs "
						+ "for user so sending failure");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
				return CodeStatus.FAILURE;
			}

			PackBean packBean = allAvailablePackList.get(packIndex);

			filePath = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.DATA_TRANSFER_CONFIRM + "_" + userDataBean.getLangId());
			if (UssdMenuNames.DEFAULT_MENU_STRING.equals(filePath)) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00276") + " >> "
						+ UssdMenuNames.DATA_TRANSFER_CONFIRM + " is "
						+ "not defined in USSD menus cache so returning error");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePath);
				return CodeStatus.FAILURE;
			}

			filePath = filePath.replace("$(description)", packBean.getDescription());
			filePath = filePath.replace("$(fmsisdn)", userDataBean.getFmsisdn());

			ServiceCharge serviceCharge = TSSJavaUtil.instance().getCacheParameters()
					.getServiceChargeDetails(userDataBean.getPackId());

			if (serviceCharge == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00277")
						+ " >> Service charge details are not found for " + "pack id [" + userDataBean.getPackId()
						+ "] : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));

				return CodeStatus.FAILURE;
			}

			logger.debug(userDataBean.getRequestId() + " >> Service charge details are " + serviceCharge);

			// added to show service_charge in double/float if true else in
			// Integer
			if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
				filePath = filePath.replace("$(service_charge)", String.valueOf(serviceCharge.getServiceCharge()));
			} else {
				filePath = filePath.replace("$(service_charge)",
						String.valueOf((int) serviceCharge.getServiceCharge()));
			}

			filePath = filePath.replace("$(validity_days)", String.valueOf(serviceCharge.getValidity()));

			String validityTypeStr = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(serviceCharge.getValidityType().toUpperCase() + "_" + userDataBean.getLangId());
			filePath = filePath.replace("$(validity_type)", validityTypeStr);

			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.SUCCESS);

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Exception " + "occurred while generating bonus description ", npe);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.FAILURE;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Exception " + "occurred while generating bonus description ", ex);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.FAILURE;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00278") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Exception " + "occurred while generating bonus description ", e);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.FAILURE;
		}
		logger.debug(userDataBean.getRequestId() + "] >> total returned file path length:[" + filePath.length()
				+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		userDataBean.setResult(ResponseParameters.SUCCESS);
		userDataBean.setFilePath(filePath);
		return CodeStatus.SUCCESS;
	}// generateDataTransferDesc() ends

	/**
	 * Used to return pack details using key and pack id
	 * 
	 * @param key
	 * @param packId
	 * @return
	 */
	public PackBean getPackDetails(String key, int packId) {
		logger.debug(" >> key [" + key + "] packId [" + packId + "]");
		if (TSSJavaUtil.instance().getCacheParameters().getAvailablePacksMap().get(key) == null)
			return null;

		ArrayList<PackBean> packList = TSSJavaUtil.instance().getCacheParameters().getAvailablePacksMap().get(key);
		for (int i = 0; i < packList.size(); i++) {
			if (packList.get(i).getPackId() == packId)
				return packList.get(i);
		}
		return null;
	}

	/**
	 * Used to find the pack id's according to request received from user (IVR)
	 * 
	 * @param userDataBean
	 * @return
	 */
	public CodeStatus fetchAvailablePacksForIVR(UserDataBean userDataBean) {

		logger.info(" >> Loading IVR packs according to UserDataBean received. UserDataBean [" + userDataBean + "]");

		if (userDataBean == null)
			return CodeStatus.FAILURE;

		String retString = "";

		String getPackTypeKey = "";
		String getPackKey = "";
		int tempPackTypeId = -1;
		ArrayList<PackBean> allAvailablePackList = new ArrayList<PackBean>();
		ArrayList<PackTypeBean> allAvailablePackTypeList = new ArrayList<PackTypeBean>();
		ArrayList<PackPackTypeCommonBean> packPackTypeList = new ArrayList<PackPackTypeCommonBean>();
		try {
			String ivrBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
			if (ivrBasePath.equalsIgnoreCase("") || ivrBasePath.equalsIgnoreCase("NA") || ivrBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			String ivrPackPromptBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrPackPromptBasePath();
			if (ivrPackPromptBasePath.equalsIgnoreCase("") || ivrPackPromptBasePath.equalsIgnoreCase("NA")
					|| ivrPackPromptBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00325")
						+ " >> (IVR) ivrPackPromptBasePath found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			if (!userDataBean.getPackList().equalsIgnoreCase("NA") && !userDataBean.getPackList().equals("")) {
				String[] packListArr = userDataBean.getPackList().split(",");

				if (!userDataBean.getDigits().equalsIgnoreCase("N")) {
					int digits = Integer.parseInt(userDataBean.getDigits());
					logger.debug(userDataBean.getRequestId() + "] >>  digits:[" + digits + "] packListArr length:["
							+ packListArr.length + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
					if (digits <= 0 || digits > packListArr.length) {
						// INVALID REQUEST if digit value pressed is more than available packs in menu

						userDataBean.setResult(ResponseParameters.INVALID_DIGIT_PRESSED_IVR);
						userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
						logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00250")
								+ " ] >> (IVR) total returned file path:[" + userDataBean.getFilePath() + "] MSISDN:["
								+ userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					} else {
						String packId = packListArr[digits - 1];
						tempPackTypeId = userDataBean.getPackTypeId();

						logger.info("TSSJavaUtil.instance().getCacheParameters().getPackTypeDetailsMap() ==>> "
								+ TSSJavaUtil.instance().getCacheParameters().getPackTypeDetailsMap()
										.get(Integer.parseInt(packId)));
						if (TSSJavaUtil.instance().getCacheParameters().getPackTypeDetailsMap()
								.get(Integer.parseInt(packId)) != null) {
							userDataBean.setBasePackType(TSSJavaUtil.instance().getCacheParameters()
									.getPackTypeDetailsMap().get(Integer.parseInt(packId)).getBasePackType());

						}
						userDataBean.setPackTypeId(Integer.parseInt(packId));
						logger.debug(userDataBean.getRequestId() + "] >>  packTypeId:[" + userDataBean.getPackTypeId()
								+ "], BasePackType:[" + userDataBean.getBasePackType() + "], SelectedPackId:[" + packId
								+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
					}
				}
			}

			getPackTypeKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId();
			getPackKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();

			if (userDataBean.getIsPackType().equalsIgnoreCase("Y")) {
				logger.info(userDataBean.getRequestId() + " >> key for available pack Type is getPackKey:[" + getPackKey
						+ "] getPackTypeKey:[" + getPackTypeKey + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

				allAvailablePackTypeList = TSSJavaUtil.instance().getCacheParameters().getAvailablePackTypeMap()
						.get(getPackTypeKey);
				allAvailablePackList = TSSJavaUtil.instance().getCacheParameters().getAvailablePacksMap()
						.get(getPackKey);

				logger.debug(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00331")
						+ " >> allAvailablePackTypeList: " + allAvailablePackTypeList + ",  allAvailablePackList:"
						+ allAvailablePackList);

				if (allAvailablePackList == null && allAvailablePackTypeList == null) {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00329")
							+ " >>  No pack type or pack found for user, pack key is:[" + getPackKey
							+ "], pack type key:[" + getPackTypeKey + "] " + "MSISDN:[" + userDataBean.getMsisdn()
							+ "]");

					userDataBean.setResult(ResponseParameters.NO_SUB_CATEGORIES);
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					userDataBean.setPackTypeId(tempPackTypeId);
					userDataBean.setIsPackType("D");

					return CodeStatus.FAILURE;
				}

				else if (allAvailablePackTypeList == null) {
					logger.info(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00305")
							+ " >>(IVR) No pack Type found for user, key is [" + getPackKey + "] " + "MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.NO_SUB_CATEGORIES);
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					userDataBean.setIsPackType("N");
					userDataBean.setPackList("NA");
				}

			}

			else if (userDataBean.getIsPackType().equalsIgnoreCase("N")) {
				logger.info(userDataBean.getRequestId() + " >> key for available packs is getPackKey:[" + getPackKey
						+ "], isPackType:[" + userDataBean.getIsPackType() + "] MSISDN:[" + userDataBean.getMsisdn()
						+ "]");

				if (allAvailablePackList == null || allAvailablePackList.isEmpty()) {
					allAvailablePackList = TSSJavaUtil.instance().getCacheParameters().getAvailablePacksMap()
							.get(getPackKey);
				}

				if (allAvailablePackList == null) {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00219")
							+ " >>  No packs found for user, key is [" + getPackKey + "] " + "MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					userDataBean.setResult(ResponseParameters.NO_SUB_CATEGORIES);
					userDataBean.setPackTypeId(tempPackTypeId);
					userDataBean.setIsPackType("D");
					return CodeStatus.FAILURE;
				}

			}

			else {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00328")
						+ " >> proper isPackType key is not forund, isPackType:[" + userDataBean.getIsPackType() + "] "
						+ "MSISDN:[" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);

			}

			fillPacks(allAvailablePackList, packPackTypeList);
			fillPackType(allAvailablePackTypeList, packPackTypeList);

			Collections.sort(packPackTypeList);

			logger.info("packPackTypeList Size:[" + packPackTypeList + "]: ");

			boolean isBalanceEnable = TSSJavaUtil.instance().getCacheParameters().isPackBasedOnBalanceEnable();

			logger.debug(userDataBean.getRequestId() + " >> (IVR) received Pack List in request is:["
					+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			// if current pack list is empty then this is first request for
			// getPacks
			if ((userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList()))
					&& "N".equalsIgnoreCase(userDataBean.getIndex())
					|| !userDataBean.getDigits().equalsIgnoreCase("N")) {
				retString = getPacksForIVRFirstRequest(userDataBean, packPackTypeList, isBalanceEnable, ivrBasePath,
						ivrPackPromptBasePath);
			} else {
				// else block is used for Next/Previous/Same request
				if (userDataBean.getIndex().equalsIgnoreCase("N")) {
					// If index is N then request for Next Packs
					retString = getNextIVRReqPacks(userDataBean, packPackTypeList, isBalanceEnable, ivrBasePath,
							ivrPackPromptBasePath);
				} else if (userDataBean.getIndex().equalsIgnoreCase("P")) {
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
					return CodeStatus.FAILURE;
					// If index is P then request for Previous Packs
					// retString =
					// getPrevIVRReqPacks(userDataBean,allAvailablePackList,isBalanceEnable);
				} else if (userDataBean.getIndex().equalsIgnoreCase("S")) {
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
					return CodeStatus.FAILURE;
					// If index is S then request is for same packs, which will
					// user requests from description of any pack and then
					// request for previous packs
					// retString =
					// getSameIVRReqPacks(userDataBean,allAvailablePackList,isBalanceEnable);
				}
			} // main else-if ends

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >>(IVR) Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ",
					npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00220")
					+ " >> (IVR) Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		}

		if (retString == null || "".equals(retString)) {
			logger.info(userDataBean.getRequestId() + " >> (IVR)  MSISDN:[" + userDataBean.getMsisdn()
					+ "]  get response null in retString:[" + retString + "]");
			// userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR+"_"+userDataBean.getLangId()));
			// file path already set from statement control returns
			return CodeStatus.FAILURE;
		}

		userDataBean.setResult(ResponseParameters.SUCCESS);
		logger.debug(userDataBean.getRequestId() + " >> (IVR)  pack browsing list is:["
				+ userDataBean.getPackBrowseList() + "] current pack list is:[" + userDataBean.getPackList()
				+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		logger.info(userDataBean.getRequestId() + " >>(IVR)  filePath returned to XML is:[" + userDataBean.getFilePath()
				+ "] result:[" + userDataBean.getResult() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		return CodeStatus.SUCCESS;

	}

	public String getPacksForIVRFirstRequest(UserDataBean userDataBean,
			ArrayList<PackPackTypeCommonBean> packPackTypeList, boolean isBalanceEnable, String ivrBasePath,
			String ivrPackPromptBasePath) {

		CodeStatus status = null;
		String filePathIvr = "";
		try {

			// packList is equal to null means it is first hit
			int currentPackIndex = 0; // used to iterate all available packs
			logger.info(userDataBean.getRequestId() + " >> (IVR) packTypeId:[" + userDataBean.getPackTypeId()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			StringBuffer isMorePacksAvailable = new StringBuffer();

			currentPackIndex = getNextIVRPacksForUserCriteria(currentPackIndex, packPackTypeList, userDataBean,
					isMorePacksAvailable, isBalanceEnable, ivrBasePath, ivrPackPromptBasePath);

			if ("".equals(userDataBean.getPackList()) || userDataBean.getPackList() == null
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00307")
						+ " >> (IVR) Pack List is null or empty, No packs available for User." + " packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				String filePath = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.NO_PACKS_AVAILABLE_WAV_IVR;
				userDataBean.setFilePath(filePath);
				userDataBean.setResult(ResponseParameters.FAILURE);
				return null;
			}

			int moreMenuAvailable = packPackTypeList.size() - currentPackIndex;
			logger.debug(userDataBean.getRequestId() + " >> isMorePacksAvailable:[" + isMorePacksAvailable
					+ "] moreMenuAvailable:[" + moreMenuAvailable + "] available pack size:[" + packPackTypeList.size()
					+ "]  MSISDN:[" + userDataBean.getMsisdn() + "]");

			filePathIvr = userDataBean.getFilePath();
			this.generatePackListIvr(userDataBean);

			if ((moreMenuAvailable > 0 && "1".equalsIgnoreCase(isMorePacksAvailable.toString()))
					&& filePathIvr != null) {
				filePathIvr += TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.NEXT_PACK_WAV_IVR;
			}

			if (filePathIvr != null && !filePathIvr.equals("")) {
				status = CodeStatus.SUCCESS;
				userDataBean.setFilePath(filePathIvr);
			}

			else {
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			}

			logger.debug(userDataBean.getRequestId() + ">> (IVR) FilePathIvr[" + userDataBean.getFilePath()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >>(IVR) Exception occurred while fetching packs for user" + " MSISDN:["
					+ userDataBean.getMsisdn() + "]", npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return null;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00222")
					+ " >>(IVR) Exception occurred while fetching packs for user" + " MSISDN:["
					+ userDataBean.getMsisdn() + "]", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return null;
		}

		if (status == CodeStatus.SUCCESS) {
			logger.info(userDataBean.getRequestId() + " >> (IVR)  filePath generated for user to be shown is " + ":["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return userDataBean.getFilePath();
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00308")
					+ " >>(IVR) CodeStatus != success filePath generated for user to be shown is " + ":["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return null;
		}

	}

	/**
	 * @author richard
	 * 
	 * @param userDataBean
	 * @param packPackTypeList
	 * @param isBalanceEnable
	 * @param ivrBasePath
	 * @param ivrPackPromptBasePath
	 * @return
	 */
	public String getWelcomePromoPacksForIVRFirstRequest(UserDataBean userDataBean,
			ArrayList<PackPackTypeCommonBean> packPackTypeList, boolean isBalanceEnable, String ivrBasePath,
			String ivrPackPromptBasePath) {

		CodeStatus status = null;
		String filePathIvr = "";
		try {

			// packList is equal to null means it is first hit
			int currentPackIndex = 0; // used to iterate all available packs
			logger.info(userDataBean.getRequestId() + " >> (IVR) packTypeId:[" + userDataBean.getPackTypeId()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			StringBuffer isMorePacksAvailable = new StringBuffer();

			currentPackIndex = getNextIVRWelcomePromoPacksForUserCriteria(currentPackIndex, packPackTypeList, userDataBean,
					isMorePacksAvailable, isBalanceEnable, ivrBasePath, ivrPackPromptBasePath);

			if ("".equals(userDataBean.getPackList()) || userDataBean.getPackList() == null
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00307")
						+ " >> (IVR) Pack List is null or empty, No promotion packs available for User." + " packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				String filePath = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.NO_PROMO_PACK_AVAILABLE;
				userDataBean.setFilePath(filePath);
				userDataBean.setResult(ResponseParameters.FAILURE);
				return null;
			}
			
			logger.debug(userDataBean.getRequestId() + " >> available pack size:[" + packPackTypeList.size()
					+ "]  MSISDN:[" + userDataBean.getMsisdn() + "]");

			filePathIvr = userDataBean.getFilePath();
			this.generatePackListIvr(userDataBean);

			if (filePathIvr != null && !filePathIvr.equals("")) {
				status = CodeStatus.SUCCESS;
				userDataBean.setFilePath(filePathIvr);
			}

			else {
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			}

			logger.debug(userDataBean.getRequestId() + ">> (IVR) FilePathIvr[" + userDataBean.getFilePath()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >>(IVR) Exception occurred while fetching packs for user" + " MSISDN:["
					+ userDataBean.getMsisdn() + "]", npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return null;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00222")
					+ " >>(IVR) Exception occurred while fetching packs for user" + " MSISDN:["
					+ userDataBean.getMsisdn() + "]", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return null;
		}

		if (status == CodeStatus.SUCCESS) {
			logger.info(userDataBean.getRequestId() + " >> (IVR)  filePath generated for user to be shown is " + ":["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return userDataBean.getFilePath();
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00308")
					+ " >>(IVR) CodeStatus != success filePath generated for user to be shown is " + ":["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return null;
		}

	
	}
	
	
	public String getPromoPacksForIVRFirstRequest(UserDataBean userDataBean,
			ArrayList<PackPackTypeCommonBean> packPackTypeList, boolean isBalanceEnable, String ivrBasePath,
			String ivrPackPromptBasePath) {

		CodeStatus status = null;
		String filePathIvr = "";
		try {

			// packList is equal to null means it is first hit
			int currentPackIndex = 0; // used to iterate all available packs
			logger.info(userDataBean.getRequestId() + " >> (IVR) packTypeId:[" + userDataBean.getPackTypeId()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			StringBuffer isMorePacksAvailable = new StringBuffer();

			currentPackIndex = getNextIVRPromoPacksForUserCriteria(currentPackIndex, packPackTypeList, userDataBean,
					isMorePacksAvailable, isBalanceEnable, ivrBasePath, ivrPackPromptBasePath);

			if ("".equals(userDataBean.getPackList()) || userDataBean.getPackList() == null
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00307")
						+ " >> (IVR) Pack List is null or empty, No packs available for User." + " packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				String filePath = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.NO_PROMO_PACK_AVAILABLE;
				userDataBean.setFilePath(filePath);
				userDataBean.setResult(ResponseParameters.FAILURE);
				return null;
			}

			int moreMenuAvailable = packPackTypeList.size() - currentPackIndex;
			logger.debug(userDataBean.getRequestId() + " >> isMorePacksAvailable:[" + isMorePacksAvailable
					+ "] moreMenuAvailable:[" + moreMenuAvailable + "] available pack size:[" + packPackTypeList.size()
					+ "]  MSISDN:[" + userDataBean.getMsisdn() + "]");

			filePathIvr = userDataBean.getFilePath();
			this.generatePackListIvr(userDataBean);

			if ((moreMenuAvailable > 0 && "1".equalsIgnoreCase(isMorePacksAvailable.toString()))
					&& filePathIvr != null) {
				filePathIvr += TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.PRESS_9_FOR + TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.MORE_PACKS;
				userDataBean.setMore("Y");
			}

			if (filePathIvr != null && !filePathIvr.equals("")) {
				status = CodeStatus.SUCCESS;
				userDataBean.setFilePath(filePathIvr);
			}

			else {
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			}

			logger.debug(userDataBean.getRequestId() + ">> (IVR) FilePathIvr[" + userDataBean.getFilePath()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >>(IVR) Exception occurred while fetching packs for user" + " MSISDN:["
					+ userDataBean.getMsisdn() + "]", npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return null;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00222")
					+ " >>(IVR) Exception occurred while fetching packs for user" + " MSISDN:["
					+ userDataBean.getMsisdn() + "]", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return null;
		}

		if (status == CodeStatus.SUCCESS) {
			logger.info(userDataBean.getRequestId() + " >> (IVR)  filePath generated for user to be shown is " + ":["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return userDataBean.getFilePath();
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00308")
					+ " >>(IVR) CodeStatus != success filePath generated for user to be shown is " + ":["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return null;
		}

	
	}
	
	public int getNextIVRWelcomePromoPacksForUserCriteria(int currentPackIndex, ArrayList<PackPackTypeCommonBean> packPackTypeList,
			UserDataBean userDataBean, StringBuffer isMorePacksAvailable, boolean balanceBasedEnable,
			String ivrBasePath, String ivrPackPromptBasePath) {
		logger.debug(userDataBean.getRequestId() + " >> (IVR) currentPackIndex:[" + currentPackIndex + "] MSISDN:["
				+ userDataBean.getMsisdn() + "]");
		int retCurrentIndex = -1;
		int totalMenuShown = 0;
		byte checkMaxMenus = 0; // used to check condition for max menu
		String filePathIvr = "";
		StringBuffer filePathBuffer = new StringBuffer();
		byte maxIVRMenu = TSSJavaUtil.instance().getCacheParameters().getMaxWelcomePromoMenu();

		logger.info(userDataBean.getRequestId() + " >> (IVR) all available packs for packTypeId:["
				+ userDataBean.getPackTypeId() + "] are:[" + packPackTypeList + "]  currentPackIndex:["
				+ currentPackIndex + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		PackPackTypeCommonBean commonBean = null;

		// boolean balanceBasedEnable =
		// TSSJavaUtil.instance().getCacheParameters().isPackBasedOnBalanceEnable();
		logger.debug(userDataBean.getRequestId() + " >> (IVR)  balanceBasedEnable:[" + balanceBasedEnable + "] MSISDN:["
				+ userDataBean.getMsisdn() + "]");
		userDataBean.setPackList("");

		
		filePathBuffer.append(ivrBasePath).append(userDataBean.getLangId()).append(File.separator)
				.append(IvrMenu.WELCOME).append(TSSJavaUtil.FileSeparator).append(ivrBasePath)
				.append(userDataBean.getLangId()).append(File.separator).append(IvrMenu.YOUR_POD).append(TSSJavaUtil.FileSeparator);
		
		for (retCurrentIndex = currentPackIndex; retCurrentIndex < packPackTypeList.size()
				&& checkMaxMenus < maxIVRMenu; retCurrentIndex++) {

			commonBean = packPackTypeList.get(retCurrentIndex);
			
			if ((balanceBasedEnable && (commonBean.getAmountRequired() == -1
					|| commonBean.getAmountRequired() <= userDataBean.getBalance())) || !balanceBasedEnable) {
				// need to append file path
				if (!commonBean.getPormptFilePath().contentEquals("NA")
						&& !"".equalsIgnoreCase(commonBean.getPormptFilePath())) {

					filePathBuffer.append(ivrPackPromptBasePath)
							.append(TSSJavaUtil.instance().getPromptFilePath(commonBean))
							.append(TSSJavaUtil.FileSeparator);

					checkMaxMenus++;
					userDataBean.setPackList(userDataBean.getPackList() + commonBean.getProductCode() + ",");
					userDataBean.setCurrentPackTypeList(
							userDataBean.getCurrentPackTypeList() + commonBean.getCurrentPackType() + ",");
				} else
					logger.warn(userDataBean.getRequestId() + " --->> (IVR) " + TSSJavaUtil.getLogInitial("00306")
							+ " >> getNextIVRPromoPacksForUserCriteria(), No Prompt File Found for Pack_ID :["
							+ userDataBean.getPackId() + "] and LanguageId:[" + userDataBean.getLangId()
							+ "]  PackBean:[" + commonBean + "].");
			}

		}

		// checkMaxMenus is used to check weather more packs are available to
		// user
		userDataBean.setTotalMenuShown(checkMaxMenus);
		checkMaxMenus = (byte) retCurrentIndex;

		// code to check weather more packs are available to user according to
		// balance
		logger.debug("checkMaxMenu:[" + checkMaxMenus + "] size:[" + packPackTypeList.size() + "] PackList:["
				+ userDataBean.getPackList() + "].");

		filePathIvr = filePathBuffer.toString();
		if (!filePathIvr.equalsIgnoreCase("") && filePathIvr != null) {
			filePathIvr = filePathIvr.substring(0, filePathIvr.length() - 1);
		}

		logger.debug("(IVR) appended file path in getNextIVRPacksForUserCriteria()  -->> FILE_PATH_IVR:[" + filePathIvr
				+ "].");
		userDataBean.setFilePath(filePathIvr);
		logger.debug(userDataBean.getRequestId() + ">>  returned current index:[" + retCurrentIndex
				+ "] total available packs size:[" + packPackTypeList.size() + "] MSISDN:[" + userDataBean.getMsisdn()
				+ "], TotalMenuShown:[" + totalMenuShown + "]");

		return retCurrentIndex;
	}
	
	
	public int getNextIVRPromoPacksForUserCriteria(int currentPackIndex, ArrayList<PackPackTypeCommonBean> packPackTypeList,
			UserDataBean userDataBean, StringBuffer isMorePacksAvailable, boolean balanceBasedEnable,
			String ivrBasePath, String ivrPackPromptBasePath) {
		logger.debug(userDataBean.getRequestId() + " >> (IVR) currentPackIndex:[" + currentPackIndex + "] MSISDN:["
				+ userDataBean.getMsisdn() + "]");
		int retCurrentIndex = -1;
		int totalMenuShown = 0;
		byte checkMaxMenus = 0; // used to check condition for max menu
		String filePathIvr = "";
		StringBuffer filePathBuffer = new StringBuffer();
		byte maxIVRMenu = TSSJavaUtil.instance().getCacheParameters().getMaxIvrMenu();

		logger.info(userDataBean.getRequestId() + " >> (IVR) all available packs for packTypeId:["
				+ userDataBean.getPackTypeId() + "] are:[" + packPackTypeList + "]  currentPackIndex:["
				+ currentPackIndex + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		PackPackTypeCommonBean commonBean = null;

		// boolean balanceBasedEnable =
		// TSSJavaUtil.instance().getCacheParameters().isPackBasedOnBalanceEnable();
		logger.debug(userDataBean.getRequestId() + " >> (IVR)  balanceBasedEnable:[" + balanceBasedEnable + "] MSISDN:["
				+ userDataBean.getMsisdn() + "]");
		userDataBean.setPackList("");

		for (retCurrentIndex = currentPackIndex; retCurrentIndex < packPackTypeList.size()
				&& checkMaxMenus < maxIVRMenu; retCurrentIndex++) {

			commonBean = packPackTypeList.get(retCurrentIndex);
			
			if ((balanceBasedEnable && (commonBean.getAmountRequired() == -1
					|| commonBean.getAmountRequired() <= userDataBean.getBalance())) || !balanceBasedEnable) {
				// need to append file path
				if (!commonBean.getPormptFilePath().contentEquals("NA")
						&& !"".equalsIgnoreCase(commonBean.getPormptFilePath())) {

					filePathBuffer.append(ivrBasePath).append(userDataBean.getLangId()).append(File.separator)
							.append(TSSJavaUtil.instance().getPressNumberPrompt(checkMaxMenus + 1))
							.append(TSSJavaUtil.FileSeparator).append(ivrPackPromptBasePath)
							.append(TSSJavaUtil.instance().getPromptFilePath(commonBean))
							.append(TSSJavaUtil.FileSeparator);

					checkMaxMenus++;
					userDataBean.setPackList(userDataBean.getPackList() + commonBean.getProductCode() + ",");
					userDataBean.setCurrentPackTypeList(
							userDataBean.getCurrentPackTypeList() + commonBean.getCurrentPackType() + ",");
				} else
					logger.warn(userDataBean.getRequestId() + " --->> (IVR) " + TSSJavaUtil.getLogInitial("00306")
							+ " >> getNextIVRPromoPacksForUserCriteria(), No Prompt File Found for Pack_ID :["
							+ userDataBean.getPackId() + "] and LanguageId:[" + userDataBean.getLangId()
							+ "]  PackBean:[" + commonBean + "].");
			}

		}

		filePathBuffer.append(ivrBasePath).append(userDataBean.getLangId()).append(File.separator)
		.append(IvrMenu.PRESS_0).append(TSSJavaUtil.FileSeparator).append(ivrBasePath).append(userDataBean.getLangId()).append(File.separator)
		.append(IvrMenu.TO_GO_BACK);
		
		// checkMaxMenus is used to check weather more packs are available to
		// user
		userDataBean.setTotalMenuShown(checkMaxMenus);
		checkMaxMenus = (byte) retCurrentIndex;

		// code to check weather more packs are available to user according to
		// balance
		logger.debug("checkMaxMenu:[" + checkMaxMenus + "] size:[" + packPackTypeList.size() + "] PackList:["
				+ userDataBean.getPackList() + "].");
		for (; checkMaxMenus < packPackTypeList.size(); checkMaxMenus++) {

			if ((balanceBasedEnable && (commonBean.getAmountRequired() < 0
					|| commonBean.getAmountRequired() <= userDataBean.getBalance()))
					// if balance needs to be checked and balance more than
					// amount
					|| !balanceBasedEnable
			// or balance does not matter
			// In these cases show the pack
			) {
				logger.debug("isMorePacksAvailable:[" + isMorePacksAvailable + "]");
				// if more packs available then append 1
				isMorePacksAvailable.append(1);
				logger.debug(userDataBean.getRequestId()
						+ " >> still more packs are available for user, isMorePacksAvailable:[" + isMorePacksAvailable
						+ "]");
				break;
			}
		}

		filePathIvr = filePathBuffer.toString();
		/*if (!filePathIvr.equalsIgnoreCase("") && filePathIvr != null) {
			filePathIvr = filePathIvr.substring(0, filePathIvr.length() - 1);
		}*/

		logger.debug("(IVR) appended file path in getNextIVRPacksForUserCriteria()  -->> FILE_PATH_IVR:[" + filePathIvr
				+ "].");
		userDataBean.setFilePath(filePathIvr);
		logger.debug(userDataBean.getRequestId() + ">>  returned current index:[" + retCurrentIndex
				+ "] total available packs size:[" + packPackTypeList.size() + "] MSISDN:[" + userDataBean.getMsisdn()
				+ "], TotalMenuShown:[" + totalMenuShown + "]");

		return retCurrentIndex;
	}
	
	
	public int getNextIVRPacksForUserCriteria(int currentPackIndex, ArrayList<PackPackTypeCommonBean> packPackTypeList,
			UserDataBean userDataBean, StringBuffer isMorePacksAvailable, boolean balanceBasedEnable,
			String ivrBasePath, String ivrPackPromptBasePath) {
		logger.debug(userDataBean.getRequestId() + " >> (IVR) currentPackIndex:[" + currentPackIndex + "] MSISDN:["
				+ userDataBean.getMsisdn() + "]");
		int retCurrentIndex = -1;
		int totalMenuShown = 0;
		byte checkMaxMenus = 0; // used to check condition for max menu
		String filePathIvr = "";
		StringBuffer filePathBuffer = new StringBuffer();
		String validityPrompt = "";
		// maximum menus can be shown as configured in property file
		byte maxIVRMenu = TSSJavaUtil.instance().getCacheParameters().getMaxIvrMenu();

		logger.info(userDataBean.getRequestId() + " >> (IVR) all available packs for packTypeId:["
				+ userDataBean.getPackTypeId() + "] are:[" + packPackTypeList + "]  currentPackIndex:["
				+ currentPackIndex + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		PackPackTypeCommonBean commonBean = null;

		// boolean balanceBasedEnable =
		// TSSJavaUtil.instance().getCacheParameters().isPackBasedOnBalanceEnable();
		logger.debug(userDataBean.getRequestId() + " >> (IVR)  balanceBasedEnable:[" + balanceBasedEnable + "] MSISDN:["
				+ userDataBean.getMsisdn() + "]");
		userDataBean.setPackList("");
		for (retCurrentIndex = currentPackIndex; retCurrentIndex < packPackTypeList.size()
				&& checkMaxMenus < maxIVRMenu; retCurrentIndex++) {
			commonBean = packPackTypeList.get(retCurrentIndex);

			if (userDataBean.getIsPackType().equalsIgnoreCase("Y")) {

				if ((balanceBasedEnable && (commonBean.getAmountRequired() == -1
						|| commonBean.getAmountRequired() <= userDataBean.getBalance())) || !balanceBasedEnable) {

					if (!commonBean.getPormptFilePath().contentEquals("NA")
							&& !"".equalsIgnoreCase(commonBean.getPormptFilePath())) {

						filePathBuffer.append(ivrBasePath).append(userDataBean.getLangId()).append(File.separator)
								.append(TSSJavaUtil.instance().getPressNumberPrompt(checkMaxMenus + 1))
								.append(TSSJavaUtil.FileSeparator).append(ivrPackPromptBasePath)
								.append(TSSJavaUtil.instance().getPromptFilePath(commonBean))
								.append(TSSJavaUtil.FileSeparator);

						checkMaxMenus++;

						if (commonBean.getPackId() < 0) {
							userDataBean.setPackList(userDataBean.getPackList() + commonBean.getPackType() + ",");
						} else {
							// Coding for Append Validity prompt to Packs Only
							logger.debug("Going to Append Validity prompt in Packs");
							validityPrompt = this.validityPromptAppender(commonBean.getPackId(), ivrBasePath,
									userDataBean);
							filePathBuffer.append(validityPrompt);
							userDataBean.setPackList(userDataBean.getPackList() + commonBean.getPackId() + ",");
						}
					} else
						logger.warn(userDataBean.getRequestId() + " --->> (IVR) " + TSSJavaUtil.getLogInitial("00306")
								+ " >> getNextIVRPacksForUserCriteria(), No Prompt File Found for PackType :["
								+ userDataBean.getPackId() + "] and LanguageId:[" + userDataBean.getLangId()
								+ "]  PackBean:[" + commonBean + "].");

				}
			} else {
				if ((balanceBasedEnable && (commonBean.getAmountRequired() == -1
						|| commonBean.getAmountRequired() <= userDataBean.getBalance())) || !balanceBasedEnable) {
					// need to append file path
					if (!commonBean.getPormptFilePath().contentEquals("NA")
							&& !"".equalsIgnoreCase(commonBean.getPormptFilePath())) {

						filePathBuffer.append(ivrBasePath).append(userDataBean.getLangId()).append(File.separator)
								.append(TSSJavaUtil.instance().getPressNumberPrompt(checkMaxMenus + 1))
								.append(TSSJavaUtil.FileSeparator).append(ivrPackPromptBasePath)
								.append(TSSJavaUtil.instance().getPromptFilePath(commonBean))
								.append(TSSJavaUtil.FileSeparator);

						// Coding for Append Validity prompt to Packs Only
						validityPrompt = this.validityPromptAppender(commonBean.getPackId(), ivrBasePath, userDataBean);
						filePathBuffer.append(validityPrompt);

						checkMaxMenus++;
						userDataBean.setPackList(userDataBean.getPackList() + commonBean.getPackId() + ",");
						userDataBean.setCurrentPackTypeList(
								userDataBean.getCurrentPackTypeList() + commonBean.getCurrentPackType() + ",");
					} else
						logger.warn(userDataBean.getRequestId() + " --->> (IVR) " + TSSJavaUtil.getLogInitial("00306")
								+ " >> getNextIVRPacksForUserCriteria(), No Prompt File Found for Pack_ID :["
								+ userDataBean.getPackId() + "] and LanguageId:[" + userDataBean.getLangId()
								+ "]  PackBean:[" + commonBean + "].");
				}
			}
		}

		// checkMaxMenus is used to check weather more packs are available to
		// user
		userDataBean.setTotalMenuShown(checkMaxMenus);
		checkMaxMenus = (byte) retCurrentIndex;

		// code to check weather more packs are available to user according to
		// balance
		logger.debug("checkMaxMenu:[" + checkMaxMenus + "] size:[" + packPackTypeList.size() + "] PackList:["
				+ userDataBean.getPackList() + "].");
		for (; checkMaxMenus < packPackTypeList.size(); checkMaxMenus++) {
			commonBean = packPackTypeList.get(checkMaxMenus);
			if (userDataBean.getIsPackType().equalsIgnoreCase("Y")) {
				isMorePacksAvailable.append(1);
				logger.debug(userDataBean.getRequestId()
						+ " >> (IVR) still more PACK TYPE are available for user, isMorePacksAvailable:["
						+ isMorePacksAvailable + "]");
				break;
			} else {

				if ((balanceBasedEnable && (commonBean.getAmountRequired() == -1
						|| commonBean.getAmountRequired() <= userDataBean.getBalance()))
						// if balance needs to be checked and balance more than
						// amount
						|| !balanceBasedEnable
				// or balance does not matter In these cases show the pack
				) {
					// if more packs available then append 1
					isMorePacksAvailable.append(1);
					logger.debug(userDataBean.getRequestId()
							+ " >> (IVR) still more packs are available for user, isMorePacksAvailable:["
							+ isMorePacksAvailable + "]");
					break;
				}
			}
		}

		filePathIvr = filePathBuffer.toString();
		if (!filePathIvr.equalsIgnoreCase("") && filePathIvr != null) {
			filePathIvr = filePathIvr.substring(0, filePathIvr.length() - 1);
		}

		logger.debug("(IVR) appended file path in getNextIVRPacksForUserCriteria()  -->> FILE_PATH_IVR:[" + filePathIvr
				+ "].");
		userDataBean.setFilePath(filePathIvr);
		logger.debug(userDataBean.getRequestId() + ">>  returned current index:[" + retCurrentIndex
				+ "] total available packs size:[" + packPackTypeList.size() + "] MSISDN:[" + userDataBean.getMsisdn()
				+ "], TotalMenuShown:[" + totalMenuShown + "]");

		return retCurrentIndex;
	}

	/**
	 * This method is used to append the validity prompt to the current file path
	 * 
	 * @param packId
	 * @param ivrBasePath
	 * @param userDataBean
	 * @return
	 */
	private String validityPromptAppender(int packId, String ivrBasePath, UserDataBean userDataBean) {
		ServiceCharge serviceCharge = TSSJavaUtil.instance().getCacheParameters().getServiceChargeDetails(packId);

		if (serviceCharge == null) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00317")
					+ " >> (IVR) Service charge details are not found for " + "pack id [" + userDataBean.getPackId()
					+ "] : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		String validityPrompt = ivrBasePath + userDataBean.getLangId() + File.separator + IvrMenu.VALID_TILL_WAV_IVR
				+ TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId() + File.separator
				+ serviceCharge.getValidity() + IvrMenu.PROMPT_EXTENSION + TSSJavaUtil.FileSeparator + ivrBasePath
				+ userDataBean.getLangId() + File.separator + serviceCharge.getValidityType() + IvrMenu.PROMPT_EXTENSION
				+ TSSJavaUtil.FileSeparator;

		return validityPrompt;
	}

	public String getNextIVRReqPacks(UserDataBean userDataBean, ArrayList<PackPackTypeCommonBean> packPackTypeList,
			boolean isBalanceEnable, String ivrBasePath, String ivrPackPromptBasePath) {
		CodeStatus status = null;

		try {
			logger.info(userDataBean.getRequestId() + " >> (IVR)  packTypeId:[" + userDataBean.getPackTypeId()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "] PackpackTypeList["+packPackTypeList+"]");

			String packList = userDataBean.getPackList();
			int tempIndex = packList.lastIndexOf(",");
			int currPackIndex = -1;

			logger.debug(userDataBean.getRequestId() + " >>(IVR)  tempIndex:[" + tempIndex + "] Current Packs List:["
					+ packList + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			String tempPackId = null;
			if (tempIndex != -1) {
				// tempPackId is used to hold last Id of pack shown in previous
				// request
				tempPackId = packList.substring(tempIndex + 1);
			} else {
				if ((packList == null || "".equals(packList))) {
					// handle for if packList is empty
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00309")
							+ " >> (IVR) received packList is empty in Next Option Menu request. PackList:[" + packList
							+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					return null;
				} else {
					tempPackId = packList.trim();
				}
			}
			logger.debug(userDataBean.getRequestId() + " >> (IVR) tempPackId:[" + tempPackId + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			// currentPackIndex hold index of current pack id in arrayList
			for (PackPackTypeCommonBean commonBean : packPackTypeList) {
				if (commonBean.getPackType() == Integer.parseInt(tempPackId)
						|| commonBean.getPackId() == Integer.parseInt(tempPackId)) {
					currPackIndex = packPackTypeList.indexOf(commonBean);
					break;
				}
			}

			logger.debug(userDataBean.getRequestId() + " >> (IVR) currentPackIndex:[" + currPackIndex + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			if (currPackIndex == -1) {
				logger.error(
						userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00225") + " >>(IVR) pack id:["
								+ tempPackId + "] not found in the list of available packs for user.  packList:["
								+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				userDataBean.setPackList("");
				return null;
			}

			// means last shown pack was last pack available in system
			if (packPackTypeList.size() - 1 == currPackIndex) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00226")
						+ " >> No More packs available for User, so its invalid request. packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				String filePathIvr = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.INVALID_REQUEST_IVR_WAV;
				userDataBean.setFilePath(filePathIvr);
				userDataBean.setResult(ResponseParameters.FAILURE);
				return null;
			}

			StringBuffer isMorePacksAvailable = new StringBuffer();

			currPackIndex = getNextIVRPacksForUserCriteria(currPackIndex + 1, packPackTypeList, userDataBean,
					isMorePacksAvailable, isBalanceEnable, ivrBasePath, ivrPackPromptBasePath);
			logger.debug(userDataBean.getRequestId() + " >> (IVR)  returned Pack Index:[" + currPackIndex + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			if ("".equals(userDataBean.getPackList()) || userDataBean.getPackList() == null
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00311")
						+ " >> (IVR)  Pack List is null or empty, No More packs available for User, packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				String filePathIvr = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.NO_MORE_PACKS_AVAILABLE_WAV_IVR;
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePathIvr);
				return null;
			}

			int moreMenuAvailable = packPackTypeList.size() - currPackIndex;
			logger.debug(userDataBean.getRequestId() + " >>  isMorePacksAvailable:[" + isMorePacksAvailable
					+ "] moreMenuAvailable:[" + moreMenuAvailable + "] all available pack list size["
					+ packPackTypeList.size() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			String filePath = userDataBean.getFilePath();
			this.generatePackListIvr(userDataBean);
			if (moreMenuAvailable > 0 && "1".equalsIgnoreCase(isMorePacksAvailable.toString())) {
				if (TSSJavaUtil.instance().getCacheParameters().getIsPreviousEnableIvr() == 1) {
					filePath += TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId() + File.separator
							+ IvrMenu.PREV_PACK_WAV_IVR + TSSJavaUtil.FileSeparator + ivrBasePath
							+ userDataBean.getLangId() + File.separator + IvrMenu.NEXT_PACK_WAV_IVR;
				} else {
					filePath += TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId() + File.separator
							+ IvrMenu.NEXT_PACK_WAV_IVR;
				}
			} else {

				if (TSSJavaUtil.instance().getCacheParameters().getIsPreviousEnableIvr() == 1) {
					filePath += TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId() + File.separator
							+ IvrMenu.PREV_PACK_WAV_IVR;
				}
			}

			if (filePath != null && !filePath.equals("")) {
				userDataBean.setFilePath(filePath);
				status = CodeStatus.SUCCESS;
			}

			else {
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			}

			logger.debug(userDataBean.getRequestId() + ">> (IVR) FilePathIvr[" + userDataBean.getFilePath()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >>(IVR)  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			userDataBean.setPackList("");
			return null;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >>(IVR)  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", ex);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			userDataBean.setPackList("");
			return null;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00310") + " >>(IVR)  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			userDataBean.setPackList("");
			return null;
		}

		if (status == CodeStatus.SUCCESS) {
			logger.info(userDataBean.getRequestId() + " >> (IVR) filePath returned value is:["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return userDataBean.getFilePath();
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00312")
					+ " >> (IVR) CodeStatus != SUCCESS, filePath returned value is:[" + userDataBean.getFilePath()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return null;
		}

	}
	
	/**
	 * 
	 * @author richard
	 * 
	 * 
	 * @param userDataBean
	 * @param packPackTypeList
	 * @param isBalanceEnable
	 * @param ivrBasePath
	 * @param ivrPackPromptBasePath
	 * @return
	 */
	public String getNextIVRPromoReqPacks(UserDataBean userDataBean, ArrayList<PackPackTypeCommonBean> packPackTypeList,
			boolean isBalanceEnable, String ivrBasePath, String ivrPackPromptBasePath) {
		CodeStatus status = null;

		try {
			logger.info(userDataBean.getRequestId() + " >> (IVR)  packTypeId:[" + userDataBean.getPackTypeId()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			String packList = userDataBean.getPackList();
			int tempIndex = packList.lastIndexOf(",");
			int currPackIndex = -1;

			logger.debug(userDataBean.getRequestId() + " >>(IVR)  tempIndex:[" + tempIndex + "] Current Packs List:["
					+ packList + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			String tempPackId = null;
			if (tempIndex != -1) {
				// tempPackId is used to hold last Id of pack shown in previous
				// request
				tempPackId = packList.substring(tempIndex + 1);
			} else {
				if ((packList == null || "".equals(packList))) {
					// handle for if packList is empty
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00309")
							+ " >> (IVR) received packList is empty in Next Option Menu request. PackList:[" + packList
							+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					return null;
				} else {
					tempPackId = packList.trim();
				}
			}
			logger.debug(userDataBean.getRequestId() + " >> (IVR) tempPackId:[" + tempPackId + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			// currentPackIndex hold index of current pack id in arrayList
			for (PackPackTypeCommonBean commonBean : packPackTypeList) {
				if (commonBean.getProductCode().equalsIgnoreCase(tempPackId)
						|| commonBean.getPackId() == Integer.parseInt(tempPackId)) {
					currPackIndex = packPackTypeList.indexOf(commonBean);
					break;
				}
			}

			logger.debug(userDataBean.getRequestId() + " >> (IVR) currentPackIndex:[" + currPackIndex + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			if (currPackIndex == -1) {
				logger.error(
						userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00225") + " >>(IVR) pack id:["
								+ tempPackId + "] not found in the list of available packs for user.  packList:["
								+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				userDataBean.setPackList("");
				return null;
			}

			// means last shown pack was last pack available in system
			if (packPackTypeList.size() - 1 == currPackIndex) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00226")
						+ " >> No More packs available for User, so its invalid request. packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				String filePathIvr = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.INVALID_REQUEST_IVR_WAV;
				userDataBean.setFilePath(filePathIvr);
				userDataBean.setResult(ResponseParameters.FAILURE);
				return null;
			}

			StringBuffer isMorePacksAvailable = new StringBuffer();

			currPackIndex = getNextIVRPromoPacksForUserCriteria(currPackIndex + 1, packPackTypeList, userDataBean,
					isMorePacksAvailable, isBalanceEnable, ivrBasePath, ivrPackPromptBasePath);
			logger.debug(userDataBean.getRequestId() + " >> (IVR)  returned Pack Index:[" + currPackIndex + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			if ("".equals(userDataBean.getPackList()) || userDataBean.getPackList() == null
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00311")
						+ " >> (IVR)  Pack List is null or empty, No More packs available for User, packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				String filePathIvr = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.NO_MORE_PACKS_AVAILABLE_WAV_IVR;
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePathIvr);
				return null;
			}

			int moreMenuAvailable = packPackTypeList.size() - currPackIndex;
			logger.debug(userDataBean.getRequestId() + " >>  isMorePacksAvailable:[" + isMorePacksAvailable
					+ "] moreMenuAvailable:[" + moreMenuAvailable + "] all available pack list size["
					+ packPackTypeList.size() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			String filePath = userDataBean.getFilePath();
			this.generatePackListIvr(userDataBean);
			if (moreMenuAvailable > 0 && "1".equalsIgnoreCase(isMorePacksAvailable.toString())) {
				if (TSSJavaUtil.instance().getCacheParameters().getIsPreviousEnableIvr() == 1) {
					filePath += TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId() + File.separator
							+ IvrMenu.PREV_PACK_WAV_IVR + TSSJavaUtil.FileSeparator + ivrBasePath
							+ userDataBean.getLangId() + File.separator + IvrMenu.NEXT_PACK_WAV_IVR;
				} else {
					filePath += TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId() + File.separator
							+ IvrMenu.NEXT_PACK_WAV_IVR;
				}
			} else {

				if (TSSJavaUtil.instance().getCacheParameters().getIsPreviousEnableIvr() == 1) {
					filePath += TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId() + File.separator
							+ IvrMenu.PREV_PACK_WAV_IVR;
				}
			}

			if (filePath != null && !filePath.equals("")) {
				userDataBean.setFilePath(filePath);
				status = CodeStatus.SUCCESS;
			}

			else {
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			}

			logger.debug(userDataBean.getRequestId() + ">> (IVR) FilePathIvr[" + userDataBean.getFilePath()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >>(IVR)  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			userDataBean.setPackList("");
			return null;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >>(IVR)  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", ex);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			userDataBean.setPackList("");
			return null;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00310") + " >>(IVR)  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			userDataBean.setPackList("");
			return null;
		}

		if (status == CodeStatus.SUCCESS) {
			logger.info(userDataBean.getRequestId() + " >> (IVR) filePath returned value is:["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return userDataBean.getFilePath();
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00312")
					+ " >> (IVR) CodeStatus != SUCCESS, filePath returned value is:[" + userDataBean.getFilePath()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return null;
		}

	}
	

	public CodeStatus fetchPackDescriptionIVR(UserDataBean userDataBean) {

		logger.info(userDataBean.getRequestId() + "] >> (IVR) fecthing pack description for Pack List (PackId):["
				+ userDataBean.getPackList() + "] digits:[" + userDataBean.getDigits() + "]  MSISDN:["
				+ userDataBean.getMsisdn() + "]");
		String filePath = null;
		String ivr_base_path=null;
		
		try {
			
			if(userDataBean.getInterfaceUsed().equalsIgnoreCase("C"))
			{
				ivr_base_path = TSSJavaUtil.instance().getCacheParameters().getCustomerCareIvrPromptBasePath();
			}
			else
			{
				ivr_base_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
			}
			if (ivr_base_path.equalsIgnoreCase("") || ivr_base_path.equalsIgnoreCase("NA") || ivr_base_path == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			String ivrPackPromptBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrPackPromptBasePath();
			if (ivrPackPromptBasePath.equalsIgnoreCase("") || ivrPackPromptBasePath.equalsIgnoreCase("NA")
					|| ivrPackPromptBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00325")
						+ " >> (IVR) ivrPackPromptBasePath found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			if (userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00314")
						+ " ] >> (IVR) -- fetchPackDescriptionIVR() -- packList is empty or null or NA ["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			String[] packListArr = userDataBean.getPackList().split(",");

			int digits = Integer.parseInt(userDataBean.getDigits());
			logger.debug(userDataBean.getRequestId() + "] >> (IVR) -- fetchPackDescriptionIVR() -- digits:[" + digits
					+ "] packListArr length:[" + packListArr.length + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			if (digits <= 0 || digits > packListArr.length) {
				// INVALID REQUEST if digit value pressed is more than available
				// packs in menu
				userDataBean.setResult(ResponseParameters.INVALID_DIGIT_PRESSED_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00250")
						+ " ] >> (IVR) total returned file path:[" + userDataBean.getFilePath() + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				return CodeStatus.FAILURE;
			} else {
				String packId = packListArr[digits - 1];

				if (userDataBean.getIsLowBalancePack().equalsIgnoreCase("Y")) {
					if (userDataBean.getCurrentPackTypeList().isEmpty() || userDataBean.getCurrentPackTypeList() == null
							|| userDataBean.getCurrentPackTypeList().equalsIgnoreCase("NA")) {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00249")
								+ " ] >> (IVR)  CurrentPackTypeList is empty or null ["
								+ userDataBean.getCurrentPackTypeList() + "] MSISDN:[" + userDataBean.getMsisdn()
								+ "]");
						userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
						userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
						return CodeStatus.FAILURE;
					}

					userDataBean.setPackTypeId(
							Integer.parseInt(userDataBean.getCurrentPackTypeList().split(",")[digits - 1]));

				}

				userDataBean.setPackId(Integer.parseInt(packId));
				logger.debug(userDataBean.getRequestId() + "] >>  packId:[" + userDataBean.getPackId() + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");

				String getPackKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
						+ userDataBean.getSubType();
				logger.info(userDataBean.getRequestId() + "] >>  (IVR) >> key for available packs is getPackKey:["
						+ getPackKey + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

				ArrayList<PackBean> allAvailablePackList = TSSJavaUtil.instance().getCacheParameters()
						.getAvailablePacksMap().get(getPackKey);
				if (allAvailablePackList == null) {
					logger.error(
							userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00251") + " ] >> MSISDN:["
									+ userDataBean.getMsisdn() + "] pack list not found for user so sending failure");
					userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					userDataBean.setPackId(-1);
					return CodeStatus.FAILURE;
				}

				// packIndex hold index of current pack id in arrayList
				int packIndex = allAvailablePackList.indexOf(new PackBean(userDataBean.getPackId()));
				if (packIndex < 0) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00315")
							+ " ] >> (IVR) MSISDN:[" + userDataBean.getMsisdn()
							+ "] pack id is not found in the list of packs." + "for user so sending failure");
					userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					userDataBean.setPackId(-1);
					return CodeStatus.FAILURE;
				}

				PackBean packBean = allAvailablePackList.get(packIndex);

				// For handling low balance of User
				if (packBean.getAmountRequired() > userDataBean.getBalance()) {

					logger.info(userDataBean.getRequestId() + " MSISDN[" + userDataBean.getMsisdn() + "] "
							+ "User has Low Balance for purhcasing pack. User Balance [" + userDataBean.getBalance()
							+ "] " + "Amount Require to purchase Pack [" + packBean.getAmountRequired() + "]");
					filePath = ivr_base_path + userDataBean.getLangId() + File.separator
							+ IvrMenu.PACK_PURCHASE_LOW_BALANCE_IVR;
					userDataBean.setResult(ResponseParameters.LOW_BALANCE);
					userDataBean.setFilePath(filePath);
					return CodeStatus.FAILURE;

				}

				ServiceCharge serviceCharge = TSSJavaUtil.instance().getCacheParameters()
						.getServiceChargeDetails(userDataBean.getPackId());

				if (serviceCharge == null) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00317")
							+ " >> (IVR) Service charge details are not found for " + "pack id ["
							+ userDataBean.getPackId() + "] : msisdn [" + userDataBean.getMsisdn() + "]");

					userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
					userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					userDataBean.setPackId(-1);

					return CodeStatus.FAILURE;
				}

				// Creating file path for pack description
				
				if(userDataBean.getInterfaceUsed().equalsIgnoreCase("C"))
				{
					filePath = ivrPackPromptBasePath + userDataBean.getLangId() + File.separator
							+ packBean.getPromptFile() + TSSJavaUtil.FileSeparator + ivr_base_path
							+ userDataBean.getLangId() + File.separator + IvrMenu.TO_ACTIVATE
							+ TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId() + File.separator
							+ IvrMenu.PRESS_1 + TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId()
							+ File.separator + IvrMenu.TO_GO_BACK + TSSJavaUtil.FileSeparator + ivr_base_path
							+ userDataBean.getLangId() + File.separator + IvrMenu.PRESS_0;
				}
				else
				{
					filePath = ivr_base_path + userDataBean.getLangId() + File.separator
							+ IvrMenu.PACK_PURCHASE_CONFIRM_1_WAV_IVR + TSSJavaUtil.FileSeparator + ivrPackPromptBasePath
							+ userDataBean.getLangId() + File.separator + packBean.getPromptFile()
							+ TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId() + File.separator
							+ IvrMenu.VALID_TILL_WAV_IVR + TSSJavaUtil.FileSeparator + ivr_base_path
							+ userDataBean.getLangId() + File.separator + serviceCharge.getValidity()
							+ IvrMenu.PROMPT_EXTENSION + TSSJavaUtil.FileSeparator + ivr_base_path
							+ userDataBean.getLangId() + File.separator + serviceCharge.getValidityType()
							+ IvrMenu.PROMPT_EXTENSION;
				}
				

				/*
				 * if(PACK_AMOUNT_PROMOT) { filePath += TSSJavaUtil.FileSeparator +
				 * ivr_base_path + userDataBean.getLangId() + File.separator +
				 * IvrMenu.PACK_PURCHASE_CONFIRM_2_WAV_IVR + TSSJavaUtil.FileSeparator +
				 * TSSJavaUtil.instance().getNumberPrompt(String.valueOf(serviceCharge.getVolume
				 * ()), userDataBean.getLangId(), ivr_base_path) + TSSJavaUtil.FileSeparator +
				 * TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId()); }
				 */

				if (filePath.equalsIgnoreCase(IvrMenu.NO_FILE_PATH_IVR) || filePath == null) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00318")
							+ " >> (IVR) File Path found is either NA or null.");
					userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					return CodeStatus.FAILURE;
				}

				if (TSSJavaUtil.instance().getCacheParameters().getIsPrevOptionOnPackDescriptionEnableIvr() == 1) {

					filePath = filePath + TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId()
							+ File.separator + IvrMenu.PREV_OPTION_PACKS_WAV_IVR;
				}

				logger.debug(userDataBean.getRequestId() + "] >>  total returned file path length:[" + filePath.length()
						+ "], File Path : [" + filePath + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setFilePath(filePath);
				return CodeStatus.SUCCESS;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", ex);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00255") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		}

	} // end of fetchPackDescriptionIVR()

	public CodeStatus fetchPackDescriptionByIdIVR(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId()
				+ "] >> (IVR) -- fetchPackDescriptionByIdIVR --  fecthing pack description for PackId:["
				+ userDataBean.getPackId() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		String filePath = null;
		try {
			String getPackKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			logger.info(userDataBean.getRequestId() + "] >> (IVR) key for available packs is getPackKey:[" + getPackKey
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			String ivr_base_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
			if (ivr_base_path.equalsIgnoreCase("") || ivr_base_path.equalsIgnoreCase("NA") || ivr_base_path == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			String ivrPackPromptBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrPackPromptBasePath();
			if (ivrPackPromptBasePath.equalsIgnoreCase("") || ivrPackPromptBasePath.equalsIgnoreCase("NA")
					|| ivrPackPromptBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00325")
						+ " >> (IVR) ivrPackPromptBasePath found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			ArrayList<PackBean> allAvailablePackList = TSSJavaUtil.instance().getCacheParameters()
					.getAvailablePacksMap().get(getPackKey);
			if (allAvailablePackList == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00319")
						+ " ] >> (IVR) MSISDN:[" + userDataBean.getMsisdn()
						+ "] pack list not found for user where key [" + getPackKey + "] so sending failure");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			// packIndex hold index of current pack id in arrayList
			int packIndex = allAvailablePackList.indexOf(new PackBean(userDataBean.getPackId()));
			if (packIndex < 0) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00320")
						+ " (IVR) -- fetchPackDescriptionByIdIVR() --  MSISDN:[" + userDataBean.getMsisdn()
						+ "] pack id not found in the list of packs for user, so sending FAILURE");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			PackBean packBean = allAvailablePackList.get(packIndex);

			ServiceCharge serviceCharge = TSSJavaUtil.instance().getCacheParameters()
					.getServiceChargeDetails(userDataBean.getPackId());
			if (serviceCharge == null) {
				logger.error(userDataBean.getRequestId() + "  " + TSSJavaUtil.getLogInitial("00317")
						+ " >> Service charge details are not found for " + "pack id [" + userDataBean.getPackId()
						+ "] : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);

				return CodeStatus.FAILURE;
			}

			// Creating file path for pack description

			else {
				filePath = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.PACK_PURCHASE_CONFIRM_1_WAV_IVR + TSSJavaUtil.FileSeparator + ivrPackPromptBasePath
						+ userDataBean.getLangId() + File.separator + packBean.getPromptFile()
						+ TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.PACK_PURCHASE_CONFIRM_2_WAV_IVR + TSSJavaUtil.FileSeparator
						+ TSSJavaUtil.instance().getNumberPrompt(serviceCharge.getVolumeType(),
								userDataBean.getLangId(), ivr_base_path);
			}

			if (filePath.equalsIgnoreCase(IvrMenu.NO_FILE_PATH_IVR) || filePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00318")
						+ " >> (IVR) File Path found is either NA or null.");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			if (TSSJavaUtil.instance().getCacheParameters().isPrevOptionOnPackDescEnable()) {
				filePath = filePath + TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId()
						+ File.separator + IvrMenu.PREV_OPTION_PACKS_WAV_IVR;
			}

			userDataBean.setResult(ResponseParameters.SUCCESS);
			userDataBean.setFilePath(filePath);
			return CodeStatus.SUCCESS;

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00260") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		}

	}// fetchPackDescriptionByIdIVR() ends

	public CodeStatus generateTTTDescriptionIVR(UserDataBean userDataBean) {

		logger.info(userDataBean.getRequestId() + " >> (IVR) generating talk time transfer description" + "MSISDN:["
				+ userDataBean.getMsisdn() + "] fmsisdn [" + userDataBean.getFmsisdn() + "] volume ["
				+ userDataBean.getVolume() + "] " + "net type [" + userDataBean.getNetType() + "]");
		StringBuffer filePathBuffer = new StringBuffer();

		String fmsisdn = userDataBean.getFmsisdn()
				.replaceFirst(TSSJavaUtil.instance().getCountryCode(userDataBean.getFmsisdn()), "");

		try {
			String ivr_base_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
			if (ivr_base_path.equalsIgnoreCase("") || ivr_base_path.equalsIgnoreCase("NA") || ivr_base_path == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			if (ServiceTypes.ON_NET.equals(userDataBean.getNetType())) {

				filePathBuffer.append(ivr_base_path).append(userDataBean.getLangId()).append(File.separator)
						.append(IvrMenu.TTT_CONFIRM_ONNET_1_WAV_IVR).append(TSSJavaUtil.FileSeparator)
						.append(TSSJavaUtil.instance().getNumberPrompt(String.valueOf(userDataBean.getVolume()),
								userDataBean.getLangId(), ivr_base_path))
						.append(TSSJavaUtil.FileSeparator)
						.append(TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId()))
						.append(TSSJavaUtil.FileSeparator).append(ivr_base_path).append(userDataBean.getLangId())
						.append(File.separator).append(IvrMenu.TTT_CONFIRM_ONNET_2_WAV_IVR)
						.append(TSSJavaUtil.FileSeparator)
						.append(TSSJavaUtil.instance().getNumberPrompt(fmsisdn, userDataBean.getLangId(),
								ivr_base_path))
						.append(TSSJavaUtil.FileSeparator).append(ivr_base_path).append(userDataBean.getLangId())
						.append(File.separator).append(IvrMenu.TTT_CONFIRM_ONNET_3_WAV_IVR);

			} else if (ServiceTypes.OFF_NET.equals(userDataBean.getNetType())) {

				filePathBuffer.append(ivr_base_path).append(userDataBean.getLangId()).append(File.separator)
						.append(IvrMenu.TTT_CONFIRM_OFFNET_1_WAV_IVR).append(TSSJavaUtil.FileSeparator)
						.append(TSSJavaUtil.instance().getNumberPrompt(String.valueOf(userDataBean.getVolume()),
								userDataBean.getLangId(), ivr_base_path))
						.append(TSSJavaUtil.FileSeparator)
						.append(TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId()))
						.append(TSSJavaUtil.FileSeparator).append(ivr_base_path).append(userDataBean.getLangId())
						.append(File.separator).append(IvrMenu.TTT_CONFIRM_OFFNET_2_WAV_IVR)
						.append(TSSJavaUtil.FileSeparator)
						.append(TSSJavaUtil.instance().getNumberPrompt(fmsisdn, userDataBean.getLangId(),
								ivr_base_path))
						.append(TSSJavaUtil.FileSeparator).append(ivr_base_path).append(userDataBean.getLangId())
						.append(File.separator).append(IvrMenu.TTT_CONFIRM_OFFNET_3_WAV_IVR);

			} else if (ServiceTypes.EURO_OFF_NET.equals(userDataBean.getNetType())) {

				filePathBuffer.append(ivr_base_path).append(userDataBean.getLangId()).append(File.separator)
						.append(IvrMenu.TTT_CONFIRM_EURO_OFFNET_1_WAV_IVR).append(TSSJavaUtil.FileSeparator)
						.append(TSSJavaUtil.instance().getNumberPrompt(String.valueOf(userDataBean.getVolume()),
								userDataBean.getLangId(), ivr_base_path))
						.append(TSSJavaUtil.FileSeparator)
						.append(TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId()))
						.append(TSSJavaUtil.FileSeparator).append(ivr_base_path).append(userDataBean.getLangId())
						.append(File.separator).append(IvrMenu.TTT_CONFIRM_EURO_OFFNET_2_WAV_IVR)
						.append(TSSJavaUtil.FileSeparator)
						.append(TSSJavaUtil.instance().getNumberPrompt(fmsisdn, userDataBean.getLangId(),
								ivr_base_path))
						.append(TSSJavaUtil.FileSeparator).append(ivr_base_path).append(userDataBean.getLangId())
						.append(File.separator).append(IvrMenu.TTT_CONFIRM_EURO_OFFNET_3_WAV_IVR);
			}

			// added to show service charge in double/float if true else in
			// Integer
			if (ServiceTypes.ON_NET.equals(userDataBean.getNetType())) {

				/*
				 * if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
				 * filePath = filePath + TSSJavaUtil.FileSeparator +
				 * TSSJavaUtil.instance().getNumberPrompt( String.valueOf(
				 * TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOnNet()),
				 * userDataBean.getLangId(), ivr_base_path); } else { filePath = filePath +
				 * TSSJavaUtil.FileSeparator +
				 * TSSJavaUtil.instance().getNumberPrompt(String.valueOf( (int)
				 * TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOnNet()),
				 * userDataBean.getLangId(), ivr_base_path); }
				 * 
				 * 
				 * filePath = filePath + TSSJavaUtil.FileSeparator + ivr_base_path +
				 * userDataBean.getLangId() + File.separator +
				 * IvrMenu.TTT_ONNET_SERVICE_CHARGE_IVR;
				 */
				filePathBuffer.append(TSSJavaUtil.FileSeparator).append(ivr_base_path).append(userDataBean.getLangId())
						.append(File.separator).append(IvrMenu.TTT_ONNET_SERVICE_CHARGE_IVR);

			} else if (ServiceTypes.OFF_NET.equals(userDataBean.getNetType())) {

				/*
				 * if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
				 * filePath = filePath + TSSJavaUtil.FileSeparator +
				 * TSSJavaUtil.instance().getNumberPrompt( String.valueOf(
				 * TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOffNet()),
				 * userDataBean.getLangId(), ivr_base_path); } else { filePath = filePath +
				 * TSSJavaUtil.FileSeparator +
				 * TSSJavaUtil.instance().getNumberPrompt(String.valueOf( (int)
				 * TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOffNet()),
				 * userDataBean.getLangId(), ivr_base_path); }
				 * 
				 * filePath = filePath + TSSJavaUtil.FileSeparator + ivr_base_path +
				 * userDataBean.getLangId() + File.separator +
				 * IvrMenu.TTT_OFFNET_SERVICE_CHARGE_IVR;
				 * 
				 */

				filePathBuffer.append(TSSJavaUtil.FileSeparator).append(ivr_base_path).append(userDataBean.getLangId())
						.append(File.separator).append(IvrMenu.TTT_OFFNET_SERVICE_CHARGE_IVR);
			}

			filePathBuffer.append(TSSJavaUtil.FileSeparator)
					.append(TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId()));

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " ] >>MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00264") + " ] >>MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		}
		logger.debug(userDataBean.getRequestId() + "] >> (IVR)  total returned file path length:["
				+ filePathBuffer.length() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		userDataBean.setResult(ResponseParameters.SUCCESS);
		userDataBean.setFilePath(filePathBuffer.toString());
		return CodeStatus.SUCCESS;
	}// end of generateTTTDescriptionIVR()

	public CodeStatus generateBonusTransferDescIVR(UserDataBean userDataBean) {

		logger.info(userDataBean.getRequestId() + " >> (IVR)  generating bonus transfer description" + "MSISDN:["
				+ userDataBean.getMsisdn() + "] fmsisdn [" + userDataBean.getFmsisdn() + "] digits ["
				+ userDataBean.getDigits() + "] " + "packTypeId [" + userDataBean.getPackTypeId() + "] packList ["
				+ userDataBean.getPackList() + "]");

		String filePathIvr = "";

		try {

			String ivr_base_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
			if (ivr_base_path.equalsIgnoreCase("") || ivr_base_path.equalsIgnoreCase("NA") || ivr_base_path == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			String ivrPackPromptBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrPackPromptBasePath();
			if (ivrPackPromptBasePath.equalsIgnoreCase("") || ivrPackPromptBasePath.equalsIgnoreCase("NA")
					|| ivrPackPromptBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00325")
						+ " >> (IVR) ivrPackPromptBasePath found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			if (userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00265")
						+ " ] >> (IVR)  packList is empty or null or NA [" + userDataBean.getPackList() + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			String[] packListArr = userDataBean.getPackList().split(",");

			int digits = Integer.parseInt(userDataBean.getDigits());
			logger.debug(userDataBean.getRequestId() + "] >> (IVR) digits:[" + digits + "] packListArr length:["
					+ packListArr.length + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			if (digits <= 0 || digits > packListArr.length) {
				// INVALID REQUEST if digit value pressed is more than available
				// packs in menu
				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.INVALID_REQUEST_IVR_WAV;
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePathIvr);
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00266")
						+ " ] >> (IVR) digits pressed are not valid for this request MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				return CodeStatus.FAILURE;
			}

			String packId = packListArr[digits - 1];
			userDataBean.setPackId(Integer.parseInt(packId));

			String getPackKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			logger.info(userDataBean.getRequestId() + "] >> (IVR)  >> key for available packs is getPackKey:["
					+ getPackKey + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			ArrayList<PackBean> allAvailablePackList = TSSJavaUtil.instance().getCacheParameters()
					.getAvailablePacksMap().get(getPackKey);
			if (allAvailablePackList == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00267") + " ] >> MSISDN:["
						+ userDataBean.getMsisdn() + "] pack list not found for user so sending failure");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			// packIndex hold index of current pack id in arrayList
			int packIndex = allAvailablePackList.indexOf(new PackBean(userDataBean.getPackId()));

			if (packIndex < 0) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00268") + " ] >> MSISDN:["
						+ userDataBean.getMsisdn() + "] pack id not found in the list of packs "
						+ "for user so sending failure");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			PackBean packBean = allAvailablePackList.get(packIndex);

			// For handling low balance of User
			if (packBean.getAmountRequired() > userDataBean.getBalance()) {
				logger.info(userDataBean.getRequestId() + " (IVR) MSISDN[" + userDataBean.getMsisdn() + "] "
						+ "User has Low Balance for purhcasing pack. User Balance [" + userDataBean.getBalance() + "] "
						+ "Amount Require to purchase Pack [" + packBean.getAmountRequired() + "]");
				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.BONUS_LOW_BALANCE_WAV_IVR;
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setFilePath(filePathIvr);
				return CodeStatus.FAILURE;

			}

			ServiceCharge serviceCharge = TSSJavaUtil.instance().getCacheParameters()
					.getServiceChargeDetails(userDataBean.getPackId());

			if (serviceCharge == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00270")
						+ " >> (IVR) Service charge details are not found for " + "pack id [" + userDataBean.getPackId()
						+ "] : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			logger.info(userDataBean.getRequestId()
					+ " (IVR) >> Total service charge [String.valueOf(serviceCharge.getServiceCharge() + serviceCharge.getVolume())] = ["
					+ String.valueOf(serviceCharge.getServiceCharge() + serviceCharge.getVolume()) + "].");
			logger.debug(userDataBean.getRequestId() + "  >> Service charge details are " + serviceCharge);

			filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
					+ IvrMenu.GIFT_BONUS_PACKAGE_CONFIRM_1_WAV_IVR + TSSJavaUtil.FileSeparator + ivrPackPromptBasePath
					+ TSSJavaUtil.instance().getPromptFilePathPackBean(packBean) + TSSJavaUtil.FileSeparator
					+ ivr_base_path + userDataBean.getLangId() + File.separator
					+ IvrMenu.GIFT_BONUS_PACKAGE_CONFIRM_2_WAV_IVR + TSSJavaUtil.FileSeparator
					+ TSSJavaUtil.instance().getNumberPrompt(
							String.valueOf(serviceCharge.getServiceCharge() + serviceCharge.getVolume()),
							userDataBean.getLangId(), ivr_base_path)
					+ TSSJavaUtil.FileSeparator + TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId());

			userDataBean.setFilePath(filePathIvr);
			userDataBean.setResult(ResponseParameters.SUCCESS);

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Exception " + "occurred while generating bonus description ", npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Exception " + "occurred while generating bonus description ", ex);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00271") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Exception " + "occurred while generating bonus description ", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		}
		logger.debug(userDataBean.getRequestId() + "] >> (IVR) total returned filePathIVR:[" + filePathIvr
				+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		userDataBean.setResult(ResponseParameters.SUCCESS);
		userDataBean.setFilePath(filePathIvr);
		return CodeStatus.SUCCESS;

	}// end of generateBonusTransferDescIVR()

	/**
	 * This method is used to generate data transfer description according to
	 * fmsisdn and pack id and pack type id fro IVR
	 * 
	 * @param userDataBean
	 * @return
	 */
	public CodeStatus generateDataTransferDescIvr(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >> (IVR) generating data transfer description" + "MSISDN:["
				+ userDataBean.getMsisdn() + "] fmsisdn [" + userDataBean.getFmsisdn() + "] digits ["
				+ userDataBean.getDigits() + "] " + "packTypeId [" + userDataBean.getPackTypeId() + "] packList ["
				+ userDataBean.getPackList() + "]");

		String filePathIvr = "";
		try {
			String ivr_base_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
			if (ivr_base_path.equalsIgnoreCase("") || ivr_base_path.equalsIgnoreCase("NA") || ivr_base_path == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			String ivrPackPromptBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrPackPromptBasePath();
			if (ivrPackPromptBasePath.equalsIgnoreCase("") || ivrPackPromptBasePath.equalsIgnoreCase("NA")
					|| ivrPackPromptBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00325")
						+ " >> (IVR) ivrPackPromptBasePath found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			if (userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00272")
						+ " ] >> packList is empty or null or NA [" + userDataBean.getPackList() + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			String[] packListArr = userDataBean.getPackList().split(",");

			int digits = Integer.parseInt(userDataBean.getDigits());
			logger.debug(userDataBean.getRequestId() + "] >> (IVR) digits:[" + digits + "] packListArr length:["
					+ packListArr.length + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			if (digits <= 0 || digits > packListArr.length) {
				// INVALID REQUEST if digit value pressed is more than available
				// packs in menu
				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.INVALID_REQUEST_IVR_WAV;
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePathIvr);
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00273")
						+ " ] >> (IVR) digits pressed are not valid for this request MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				return CodeStatus.FAILURE;
			}

			String packId = packListArr[digits - 1];
			userDataBean.setPackId(Integer.parseInt(packId));

			String getPackKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			logger.info(userDataBean.getRequestId() + "] >> key for available packs is getPackKey:[" + getPackKey
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			ArrayList<PackBean> allAvailablePackList = TSSJavaUtil.instance().getCacheParameters()
					.getAvailablePacksMap().get(getPackKey);
			if (allAvailablePackList == null) {
				logger.error(
						userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00274") + " ] >> (IVR) MSISDN:["
								+ userDataBean.getMsisdn() + "] pack list not found for user so sending failure");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			// packIndex holds the index of current pack id in arrayList
			int packIndex = allAvailablePackList.indexOf(new PackBean(userDataBean.getPackId()));

			if (packIndex < 0) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00275")
						+ " ] >> (IVR) MSISDN:[" + userDataBean.getMsisdn()
						+ "] pack id not found in the list of packs " + "for user so sending failure");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			PackBean packBean = allAvailablePackList.get(packIndex);

			filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
					+ IvrMenu.DATA_TRANSFER_CONFIRM_1_WAV_IVR + TSSJavaUtil.FileSeparator + ivrPackPromptBasePath
					+ TSSJavaUtil.instance().getPromptFilePathPackBean(packBean) + TSSJavaUtil.FileSeparator
					+ ivr_base_path + userDataBean.getLangId() + File.separator
					+ IvrMenu.DATA_TRANSFER_CONFIRM_2_WAV_IVR + TSSJavaUtil.FileSeparator
					+ TSSJavaUtil.instance().getNumberPrompt(userDataBean.getFmsisdn(), userDataBean.getLangId(),
							ivr_base_path)
					+ TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId() + File.separator
					+ IvrMenu.DATA_TRANSFER_CONFIRM_3_WAV_IVR;

			userDataBean.setFilePath(filePathIvr);
			userDataBean.setResult(ResponseParameters.SUCCESS);

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Exception " + "occurred while generating bonus description ", npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Exception " + "occurred while generating bonus description ", ex);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00278") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Exception " + "occurred while generating bonus description ", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		}
		logger.debug(userDataBean.getRequestId() + "] >> total returned filePathIvr:[" + filePathIvr + "] MSISDN:["
				+ userDataBean.getMsisdn() + "]");
		userDataBean.setResult(ResponseParameters.SUCCESS);
		userDataBean.setFilePath(filePathIvr);
		return CodeStatus.SUCCESS;
	}// generateDataTransferDescIvr()
		// ends

	/**
	 * 
	 * @param userDataBean
	 */
	public void generatePackListIvr(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId()
				+ " >>  this method set currrent pack list which will be shown to user:  index:["
				+ userDataBean.getIndex() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

		logger.debug(userDataBean.getRequestId() + " >>  packList:[" + userDataBean.getPackList() + "] totalPackShown:["
				+ userDataBean.getTotalMenuShown() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		String packListArray[] = userDataBean.getPackList().split(",");
		String tempPackList = "";

		if ("P".equals(userDataBean.getIndex())) {
			logger.debug(userDataBean.getRequestId() + " >>  x:["
					+ (packListArray.length - userDataBean.getTotalMenuShown()) + "] Array Length:["
					+ packListArray.length + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			for (int x = packListArray.length - userDataBean.getTotalMenuShown(); x < packListArray.length; x++) {
				tempPackList += packListArray[x] + ",";
			}
		} else {
			for (int x = 0; x < userDataBean.getTotalMenuShown(); x++) {
				tempPackList += packListArray[x] + ",";
			}
		}

		userDataBean.setPackList(tempPackList.substring(0, tempPackList.length() - 1));

		if (userDataBean.getPackBrowseList() == null || "".equals(userDataBean.getPackBrowseList())) {
			userDataBean.setPackBrowseList(userDataBean.getPackList());
		} else {
			userDataBean.setPackBrowseList(userDataBean.getPackBrowseList() + "," + userDataBean.getPackList());
		}
		logger.debug(userDataBean.getRequestId() + " >>  Current Pack List:[" + userDataBean.getPackList()
				+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

	}

	/**
	 * Used to find the pack id's according to request received from user (IVR) Low
	 * Balance Packs
	 * 
	 * @param userDataBean
	 * @return
	 */
	public CodeStatus fetchAvailableIvrLowBalancePacks(UserDataBean userDataBean) {
		logger.info(" >>(IVR) Loading low balance packs according to UserDataBean received. UserDataBean ["
				+ userDataBean + "]");

		if (userDataBean == null)
			return CodeStatus.FAILURE;

		String retString = "";
		String filePathIvr = "";
		ArrayList<PackPackTypeCommonBean> commonPackPackTypeList = new ArrayList<PackPackTypeCommonBean>();
		try {
			String ivrBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
			if (ivrBasePath.equalsIgnoreCase("") || ivrBasePath.equalsIgnoreCase("NA") || ivrBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			String ivrPackPromptBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrPackPromptBasePath();
			if (ivrPackPromptBasePath.equalsIgnoreCase("") || ivrPackPromptBasePath.equalsIgnoreCase("NA")
					|| ivrPackPromptBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00325")
						+ " >> (IVR) ivrPackPromptBasePath found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			String getPackKey = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			logger.info(userDataBean.getRequestId() + " >> (IVR) key for available low balance packs is getPackKey:["
					+ getPackKey + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			ArrayList<PackBean> allAvailablePackList = TSSJavaUtil.instance().getCacheParameters()
					.getAvailableLowBalancePacksMap().get(getPackKey);

			if (allAvailablePackList == null) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00305")
						+ " >>(IVR) No packs found for user, key is [" + getPackKey + "] " + "MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				filePathIvr = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.NO_PACKS_AVAILABLE_WAV_IVR;
				userDataBean.setFilePath(filePathIvr);
				userDataBean.setResult(ResponseParameters.FAILURE);
				return CodeStatus.FAILURE;
			}

			fillPacks(allAvailablePackList, commonPackPackTypeList);
			boolean isBalanceEnable = TSSJavaUtil.instance().getCacheParameters()
					.isLowBalancePackBasedOnBalanceEnable();

			logger.debug(userDataBean.getRequestId() + " >>  received Pack List in request is:["
					+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			// if current pack list is empty then this is first request for
			// getPacks
			if ((userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList()))
					&& "N".equalsIgnoreCase(userDataBean.getIndex())) {
				retString = getPacksForIVRFirstRequest(userDataBean, commonPackPackTypeList, isBalanceEnable,
						ivrBasePath, ivrPackPromptBasePath);
			} else {
				// else block is used for Next/Previous/Same request
				if (userDataBean.getIndex().equalsIgnoreCase("N")) {
					// If index is N then request for Next Packs
					retString = getNextIVRReqPacks(userDataBean, commonPackPackTypeList, isBalanceEnable, ivrBasePath,
							ivrPackPromptBasePath);
				} else if (userDataBean.getIndex().equalsIgnoreCase("P")) {

					// If index is P then request for Previous Packs

					// retString = getPrevReqPacks(userDataBean,
					// allAvailablePackList, isBalanceEnable);
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					userDataBean.setResult(ResponseParameters.INVALID_DIGIT_PRESSED_IVR);
					return CodeStatus.FAILURE;
				} else if (userDataBean.getIndex().equalsIgnoreCase("S")) {
					// If index is S then request is for same packs, which will
					// user requests from description of any pack and then
					// request for previous packs

					// retString = getSameReqPacks(userDataBean,
					// allAvailablePackList, isBalanceEnable);
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					userDataBean.setResult(ResponseParameters.INVALID_DIGIT_PRESSED_IVR);
					return CodeStatus.FAILURE;

				}
			} // main else-if ends

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >>(IVR) Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ",
					npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00220")
					+ " >>(IVR) Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		}

		if (retString == null || "".equals(retString)) {
			logger.info(userDataBean.getRequestId() + " >>  MSISDN:[" + userDataBean.getMsisdn()
					+ "]  get response null in retString:[" + retString + "]");
			// userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR+"_"+userDataBean.getLangId()));
			// //file path already set from statement control returns
			return CodeStatus.FAILURE;
		}

		userDataBean.setResult(ResponseParameters.SUCCESS);
		logger.debug(userDataBean.getRequestId() + " >>(IVR)  pack browsing list is:["
				+ userDataBean.getPackBrowseList() + "] current pack list is:[" + userDataBean.getPackList()
				+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		logger.info(userDataBean.getRequestId() + " >>(IVR) filePath returned to XML is:[" + userDataBean.getFilePath()
				+ "] result:[" + userDataBean.getResult() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		return CodeStatus.SUCCESS;
	}// fetchAvailableIvrLowBalancePacks() ends

	public static void main(String[] args) {

		// System.out.println("program starts");
		// String filePath = "1-Data Transfer Packs\n2-Voice Unlimited\n3-SMS
		// Unlimited Packs\n";
		// System.out.println("filePath length-- "+filePath.length());
		// PackManager packRef = new PackManager();
		// packRef.generateFilePathStringPrevious(filePath,false);
	}

	private void fillPacks(List<PackBean> allPacks, List<PackPackTypeCommonBean> commonPackPackTypeList) {
		if (allPacks != null && !allPacks.isEmpty()) {
			for (PackBean packBean : allPacks) {
				PackPackTypeCommonBean commonBean = new PackPackTypeCommonBean();
				commonBean.setPackId(packBean.getPackId());
				commonBean.setPackPackTypeName(packBean.getPackName());
				commonBean.setDescription(packBean.getDescription());
				commonBean.setLanguageId(packBean.getLangId());
				commonBean.setPackType(packBean.getPackTypeId());
				commonBean.setAmountRequired(packBean.getAmountRequired());
				commonBean.setPormptFilePath(packBean.getPromptFile());
				commonBean.setPriority(packBean.getPriority());
				commonBean.setType("P");
				commonBean.setCurrentPackType(packBean.getCurrentPackType());
				commonPackPackTypeList.add(commonBean);
			}
		}
	}

	private void fillPackType(List<PackTypeBean> allPackType, List<PackPackTypeCommonBean> commonPackPackTypeList) {
		if (allPackType != null && !allPackType.isEmpty()) {
			for (PackTypeBean packTypeBean : allPackType) {
				PackPackTypeCommonBean commonBean = new PackPackTypeCommonBean();
				commonBean.setPackPackTypeName(packTypeBean.getPackTypeName());
				commonBean.setDescription(packTypeBean.getDescription());
				commonBean.setLanguageId(packTypeBean.getLanguageId());
				commonBean.setPackType(packTypeBean.getPackType());
				commonBean.setPormptFilePath(packTypeBean.getPackTypePromptFile());
				commonBean.setPriority(packTypeBean.getPriority());
				commonBean.setParentPackType(packTypeBean.getParentPackType());
				commonBean.setType("PT");
				commonPackPackTypeList.add(commonBean);
			}
		}
	}

	/**
	 * This method is used to fetch all the available configured promotional packs
	 * for the requested user.
	 * 
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return CodeStatus
	 */
	public CodeStatus fetchAvailablePromotionPack(UserDataBean userDataBean) {
		if (userDataBean == null)
			return CodeStatus.FAILURE;

		String retString = "";
		boolean isBalanceEnable = false;
		int result = -1;
		ArrayList<PackPackTypeCommonBean> packPackTypeList = new ArrayList<PackPackTypeCommonBean>();

		try {
			isBalanceEnable = TSSJavaUtil.instance().getCacheParameters().isPackBasedOnBalanceEnable();

			logger.info(userDataBean.getRequestId()
					+ " >> Loading All Promotion Packs according to UserDataBean received with isBalanceEnable ["
					+ isBalanceEnable + "] and UserDataBean [" + userDataBean + "]");

			result = fillPromoPacksList(packPackTypeList, userDataBean);
			logger.debug(userDataBean.getRequestId() + " >> Result[" + result
					+ "] from fillPromoPacksList mehtod where msisdn[" + userDataBean.getMsisdn() + "]");

			if (result == -1 || packPackTypeList == null) {
				logger.error(
						userDataBean.getRequestId() + " >> Exception in fillPromoPacksList method. either the result ["
								+ result + "] received is not positive or packPackTypeList [" + packPackTypeList
								+ "] is null where msisdn[" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
				return CodeStatus.EXCEPTION_OCCURED;
			}

			if (packPackTypeList.isEmpty()) {
				logger.info(userDataBean.getRequestId() + " >> No promotion packs found for requested msisdn["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.NO_PROMO_PACKS);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.POD_NO_PACKS_AVAILABLE + "_" + userDataBean.getLangId()));
				return CodeStatus.SUCCESS;
			}

			// Sorting the promotion packs
			Collections.sort(packPackTypeList);

			// if current pack list is empty then this is first request for
			// getPacks
			if ((userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList()))
					&& "N".equalsIgnoreCase(userDataBean.getIndex())) {
				retString = getPromotionPacksForFirstRequest(userDataBean, packPackTypeList, isBalanceEnable);
			} else {
				// else block is used for Next/Previous/Same request
				if (userDataBean.getIndex().equalsIgnoreCase("N")) {
					// If index is N then request for Next Packs
					retString = getNextReqPromotionPacks(userDataBean, packPackTypeList, isBalanceEnable);
				} else {
					logger.error(userDataBean.getRequestId() + " >> Unsupported Index [" + userDataBean.getIndex()
							+ "]  msisdn[" + userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
					return CodeStatus.FAILURE;
				}
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> Getting NullPointerException in fetch all Available promotion Packs for MSISDN:["
					+ userDataBean.getMsisdn() + "]  Error ", npe);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00220")
					+ " >> Error in fetch all Available promotion Packs for MSISDN:[" + userDataBean.getMsisdn()
					+ "]  Error ", e);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		}

		if (retString == null || "".equals(retString)) {
			logger.info(userDataBean.getRequestId() + " >>  MSISDN:[" + userDataBean.getMsisdn()
					+ "]  get response null in retString:[" + retString + "]");
			userDataBean.setResult(ResponseParameters.FAILURE);
			return CodeStatus.FAILURE;
		}

		userDataBean.setResult(ResponseParameters.SUCCESS);

		logger.info(userDataBean.getRequestId() + " >>  pack browsing list is:[" + userDataBean.getPackBrowseList()
				+ "] current promotion packs product code list is:[" + userDataBean.getPackList()
				+ "], isMorePackAvailable [" + userDataBean.getMore() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		return CodeStatus.SUCCESS;
	}
	
	
	/**
	 * Used to fetch Customer Care Promotional packs
	 * 
	 * @author richard
	 * 
	 * @param userDataBean
	 * @return
	 */
	public CodeStatus fetchAvailableCustomerCarePromotionPackForIVR(UserDataBean userDataBean) {
		if (userDataBean == null)
			return CodeStatus.FAILURE;

		String retString = "";
		boolean isBalanceEnable = false;
		int result = -1;
		ArrayList<PackPackTypeCommonBean> packPackTypeList = new ArrayList<PackPackTypeCommonBean>();
		String filePath ="";
		
		try {
			
			String ivrBasePath = TSSJavaUtil.instance().getCacheParameters().getCustomerCareIvrPromptBasePath();
			if (ivrBasePath.equalsIgnoreCase("") || ivrBasePath.equalsIgnoreCase("NA") || ivrBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			String ivrPackPromptBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrPackPromptBasePath();
			if (ivrPackPromptBasePath.equalsIgnoreCase("") || ivrPackPromptBasePath.equalsIgnoreCase("NA")
					|| ivrPackPromptBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00325")
						+ " >> (IVR) ivrPackPromptBasePath found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			
			isBalanceEnable = TSSJavaUtil.instance().getCacheParameters().isPackBasedOnBalanceEnable();

			logger.info(userDataBean.getRequestId()
					+ " >> Loading All Promotion Packs according to UserDataBean received with isBalanceEnable ["
					+ isBalanceEnable + "] and UserDataBean [" + userDataBean + "]");

			result = fillPromoPacksList(packPackTypeList, userDataBean);
			logger.debug(userDataBean.getRequestId() + " >> Result[" + result
					+ "] from fillPromoPacksList mehtod where msisdn[" + userDataBean.getMsisdn() + "]");

			if (result == -1 || packPackTypeList == null) {
				logger.error(
						userDataBean.getRequestId() + " >> Exception in fillPromoPacksList method. either the result ["
								+ result + "] received is not positive or packPackTypeList [" + packPackTypeList
								+ "] is null where msisdn[" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				filePath = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.UNKNOWN_ERROR_WAV_IVR;
				userDataBean.setFilePath(filePath);
				return CodeStatus.EXCEPTION_OCCURED;
			}

			if (packPackTypeList.isEmpty()) {
				logger.info(userDataBean.getRequestId() + " >> No promotion packs found for requested msisdn["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.NO_PROMO_PACKS);
				filePath = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.NO_PROMO_PACK_AVAILABLE;
				userDataBean.setFilePath(filePath);
				return CodeStatus.SUCCESS;
			}

			// Sorting the promotion packs
			Collections.sort(packPackTypeList);
			
			
			for(PackPackTypeCommonBean promoPackBean : packPackTypeList)
			{
				userDataBean.setProductCode(promoPackBean.getProductCode());
				if (promoPackBean.getAmountRequired() > userDataBean.getBalance()) {
					logger.info(userDataBean.getRequestId() + " MSISDN[" + userDataBean.getMsisdn() + "] "
							+ "User has Low Balance for purhcasing promotional pack. User Balance ["
							+ userDataBean.getBalance() + "] " + "Amount Require to purchase Pack ["
							+ promoPackBean.getAmountRequired() + "]");

					filePath = ivrBasePath + userDataBean.getLangId() + File.separator
							+ IvrMenu.PACK_PURCHASE_LOW_BALANCE_IVR;
					userDataBean.setResult(ResponseParameters.LOW_BALANCE);
					userDataBean.setFilePath(filePath);
					return CodeStatus.FAILURE;

				}
				
				String promoDesPromptFile=promoPackBean.getPormptFilePath();
				
				promoDesPromptFile=promoDesPromptFile.substring(0, promoDesPromptFile.length()-4)+"_PD"+IvrMenu.PROMPT_EXTENSION;
				
				filePath = ivrPackPromptBasePath + userDataBean.getLangId() + File.separator + promoDesPromptFile
						+ TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.PRESS_1 + TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId()
						+ File.separator + IvrMenu.TO_CONFIRM + TSSJavaUtil.FileSeparator + ivrBasePath
						+ userDataBean.getLangId() + File.separator + IvrMenu.PRESS_0 + TSSJavaUtil.FileSeparator
						+ ivrBasePath + userDataBean.getLangId() + File.separator + IvrMenu.TO_GO_BACK;
				
				break;
			}

			if (filePath.equalsIgnoreCase(IvrMenu.NO_FILE_PATH_IVR) || filePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00318")
						+ " >> (IVR) File Path found is either NA or null.");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}	
			
			if (TSSJavaUtil.instance().getCacheParameters().getIsPrevOptionOnPackDescriptionEnableIvr() == 1) {

				filePath = filePath + TSSJavaUtil.FileSeparator + ivrBasePath + userDataBean.getLangId()
						+ File.separator + IvrMenu.PREV_OPTION_PACKS_WAV_IVR;
			}
			
			userDataBean.setResult(ResponseParameters.SUCCESS);
			userDataBean.setFilePath(filePath);
			return CodeStatus.SUCCESS;
		

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >>(IVR) Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ",
					npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00220")
					+ " >> (IVR) Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		}
	}
	
	
	/**
	 * 
	 * Used to fetch promotional packs for IVR
	 * 
	 * @author richard
	 * 
	 * @param userDataBean
	 * @return
	 */
	public CodeStatus fetchAvailablePromotionPackForIVR(UserDataBean userDataBean) {
		if (userDataBean == null)
			return CodeStatus.FAILURE;

		String retString = "";
		boolean isBalanceEnable = false;
		int result = -1;
		ArrayList<PackPackTypeCommonBean> packPackTypeList = new ArrayList<PackPackTypeCommonBean>();
		String filePath ="";
		
		try {
			
			String ivrBasePath = TSSJavaUtil.instance().getCacheParameters().getCustomerCareIvrPromptBasePath();
			if (ivrBasePath.equalsIgnoreCase("") || ivrBasePath.equalsIgnoreCase("NA") || ivrBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			String ivrPackPromptBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrPackPromptBasePath();
			if (ivrPackPromptBasePath.equalsIgnoreCase("") || ivrPackPromptBasePath.equalsIgnoreCase("NA")
					|| ivrPackPromptBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00325")
						+ " >> (IVR) ivrPackPromptBasePath found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			
			isBalanceEnable = TSSJavaUtil.instance().getCacheParameters().isPackBasedOnBalanceEnable();

			logger.info(userDataBean.getRequestId()
					+ " >> Loading All Promotion Packs according to UserDataBean received with isBalanceEnable ["
					+ isBalanceEnable + "] and UserDataBean [" + userDataBean + "]");

			result = fillPromoPacksList(packPackTypeList, userDataBean);
			logger.debug(userDataBean.getRequestId() + " >> Result[" + result
					+ "] from fillPromoPacksList mehtod where msisdn[" + userDataBean.getMsisdn() + "]");

			if (result == -1 || packPackTypeList == null) {
				logger.error(
						userDataBean.getRequestId() + " >> Exception in fillPromoPacksList method. either the result ["
								+ result + "] received is not positive or packPackTypeList [" + packPackTypeList
								+ "] is null where msisdn[" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				filePath = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.UNKNOWN_ERROR_WAV_IVR;
				userDataBean.setFilePath(filePath);
				return CodeStatus.EXCEPTION_OCCURED;
			}

			if (packPackTypeList.isEmpty()) {
				logger.info(userDataBean.getRequestId() + " >> No promotion packs found for requested msisdn["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.NO_PROMO_PACKS);
				filePath = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.NO_PROMO_PACK_AVAILABLE;
				userDataBean.setFilePath(filePath);
				return CodeStatus.SUCCESS;
			}

			// Sorting the promotion packs
			Collections.sort(packPackTypeList);

			// if current pack list is empty then this is first request for
			// getPacks
			if ((userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList()))
					&& "N".equalsIgnoreCase(userDataBean.getIndex())) {
				retString = getPromoPacksForIVRFirstRequest(userDataBean, packPackTypeList, isBalanceEnable, ivrBasePath,
						ivrPackPromptBasePath);
			} else {
				// else block is used for Next/Previous/Same request
				if (userDataBean.getIndex().equalsIgnoreCase("N")) {
					// If index is N then request for Next Packs
					retString = getNextIVRPromoReqPacks(userDataBean, packPackTypeList, isBalanceEnable, ivrBasePath,
							ivrPackPromptBasePath);
				} else if (userDataBean.getIndex().equalsIgnoreCase("P")) {
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
					return CodeStatus.FAILURE;
					// If index is P then request for Previous Packs
					// retString =
					// getPrevIVRReqPacks(userDataBean,allAvailablePackList,isBalanceEnable);
				} else if (userDataBean.getIndex().equalsIgnoreCase("S")) {
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
					return CodeStatus.FAILURE;
					// If index is S then request is for same packs, which will
					// user requests from description of any pack and then
					// request for previous packs
					// retString =
					// getSameIVRReqPacks(userDataBean,allAvailablePackList,isBalanceEnable);
				}
			} // main else-if ends
		
			
			

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >>(IVR) Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ",
					npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00220")
					+ " >> (IVR) Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		}

		if (retString == null || "".equals(retString)) {
			logger.info(userDataBean.getRequestId() + " >>  MSISDN:[" + userDataBean.getMsisdn()
					+ "]  get response null in retString:[" + retString + "]");
			userDataBean.setResult(ResponseParameters.FAILURE);
			return CodeStatus.FAILURE;
		}

		userDataBean.setResult(ResponseParameters.SUCCESS);

		logger.info(userDataBean.getRequestId() + " >>  pack browsing list is:[" + userDataBean.getPackBrowseList()
				+ "] current promotion packs product code list is:[" + userDataBean.getPackList()
				+ "], isMorePackAvailable [" + userDataBean.getMore() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		return CodeStatus.SUCCESS;
	}
	
	
	public CodeStatus fetchAvailableWelcomePromotionPackForIVR(UserDataBean userDataBean) {
		if (userDataBean == null)
			return CodeStatus.FAILURE;

		String retString = "";
		boolean isBalanceEnable = false;
		int result = -1;
		ArrayList<PackPackTypeCommonBean> packPackTypeList = new ArrayList<PackPackTypeCommonBean>();
		String filePath ="";
		
		try {
			
			String ivrBasePath = TSSJavaUtil.instance().getCacheParameters().getCustomerCareIvrPromptBasePath();
			if (ivrBasePath.equalsIgnoreCase("") || ivrBasePath.equalsIgnoreCase("NA") || ivrBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			String ivrPackPromptBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrPackPromptBasePath();
			if (ivrPackPromptBasePath.equalsIgnoreCase("") || ivrPackPromptBasePath.equalsIgnoreCase("NA")
					|| ivrPackPromptBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00325")
						+ " >> (IVR) ivrPackPromptBasePath found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			
			isBalanceEnable = TSSJavaUtil.instance().getCacheParameters().isPackBasedOnBalanceEnable();

			logger.info(userDataBean.getRequestId()
					+ " >> Loading All Promotion Packs according to UserDataBean received with isBalanceEnable ["
					+ isBalanceEnable + "] and UserDataBean [" + userDataBean + "]");

			result = fillPromoPacksList(packPackTypeList, userDataBean);
			logger.debug(userDataBean.getRequestId() + " >> Result[" + result
					+ "] from fillPromoPacksList mehtod where msisdn[" + userDataBean.getMsisdn() + "]");

			if (result == -1 || packPackTypeList == null) {
				logger.error(
						userDataBean.getRequestId() + " >> Exception in fillPromoPacksList method. either the result ["
								+ result + "] received is not positive or packPackTypeList [" + packPackTypeList
								+ "] is null where msisdn[" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				filePath = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.UNKNOWN_ERROR_WAV_IVR;
				userDataBean.setFilePath(filePath);
				return CodeStatus.EXCEPTION_OCCURED;
			}

			if (packPackTypeList.isEmpty()) {
				logger.info(userDataBean.getRequestId() + " >> No promotion packs found for requested msisdn["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.NO_PROMO_PACKS);
				filePath = ivrBasePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.NO_PROMO_PACK_AVAILABLE;
				userDataBean.setFilePath(filePath);
				return CodeStatus.SUCCESS;
			}

			// Sorting the promotion packs
			Collections.sort(packPackTypeList);

			// if current pack list is empty then this is first request for
			// getPacks
			
			retString = getWelcomePromoPacksForIVRFirstRequest(userDataBean, packPackTypeList, isBalanceEnable, ivrBasePath,
						ivrPackPromptBasePath);
		
			

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >>(IVR) Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ",
					npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00220")
					+ " >> (IVR) Error in fetch Available Packs, MSISDN:[" + userDataBean.getMsisdn() + "]  Error ", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		}

		if (retString == null || "".equals(retString)) {
			logger.info(userDataBean.getRequestId() + " >>  MSISDN:[" + userDataBean.getMsisdn()
					+ "]  get response null in retString:[" + retString + "]");
			userDataBean.setResult(ResponseParameters.FAILURE);
			return CodeStatus.FAILURE;
		}

		userDataBean.setResult(ResponseParameters.SUCCESS);

		logger.info(userDataBean.getRequestId() + " >>  pack browsing list is:[" + userDataBean.getPackBrowseList()
				+ "] current promotion packs product code list is:[" + userDataBean.getPackList()
				+ "], isMorePackAvailable [" + userDataBean.getMore() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		return CodeStatus.SUCCESS;
	}
	
	

	/**
	 * This method is used to fill the configured promotion pack for the requested
	 * user.
	 * 
	 * @param commonPackPackTypeList
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return positive result in case of success else return negative result
	 */
	private int fillPromoPacksList(ArrayList<PackPackTypeCommonBean> commonPackPackTypeList,
			UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId()
				+ " >> Inside fillPromoPacksList to fill the details of all the configured Promotional Packs for the requested msisdn["
				+ userDataBean.getMsisdn() + "]");
		int result = -1;
		try {
			PackPackTypeCommonBean commonBean;
			DBOperations dbOperations = new DBOperations();
			;
			String promoPackMapKey = "";
			HashMap<String, PromoPackBean> promoPackMap = TSSJavaUtil.instance().getCacheParameters()
					.getPromoPackDetailsMap();

			// Fetching all the available promotional packs for the requested msisdn

			/*
			 * String availablePromotions =
			 * TSSJavaUtil.instance().getCacheParameters().getPromoServiceMap()
			 * .get(userDataBean.getMsisdn());
			 */

			String availablePromoProductCodes = dbOperations.getAvailablePromoProductCodes(userDataBean);

			logger.debug(userDataBean.getRequestId() + " >> Total promoPack [" + promoPackMap.size()
					+ "] found in the system where availablePromotions for the requested msisdn["
					+ userDataBean.getMsisdn() + "] is [" + availablePromoProductCodes + "]");

			if (availablePromoProductCodes != null && !availablePromoProductCodes.isEmpty()) {
				String[] productCodeArr = availablePromoProductCodes.split(",");
				for (String productCode : productCodeArr) {
					promoPackMapKey = productCode + MPCommonDataTypes.UNDERSCORE_SEPARATOR + userDataBean.getLangId()
							+ MPCommonDataTypes.UNDERSCORE_SEPARATOR + userDataBean.getSubType();
					PromoPackBean promoPackBean = promoPackMap.get(promoPackMapKey);

					logger.debug(userDataBean.getRequestId() + " >> promoPackMapKey[" + promoPackMapKey
							+ "] promoPackBean [" + promoPackBean + "]");
					if (promoPackBean != null) {
						commonBean = new PackPackTypeCommonBean();
						commonBean.setPackId(promoPackBean.getPackId());
						commonBean.setProductCode(promoPackBean.getPrductCode());
						commonBean.setPackPackTypeName(promoPackBean.getPromotionPackOtherDetails().getPackName());
						commonBean.setDescription(promoPackBean.getPromotionPackOtherDetails().getPackDescription());
						commonBean.setLanguageId(promoPackBean.getLanguageId());
						commonBean.setPackType(promoPackBean.getPackType());
						commonBean.setAmountRequired(promoPackBean.getPromotionPackOtherDetails().getAmountRequired());
						commonBean.setPormptFilePath(promoPackBean.getPromotionPackOtherDetails().getPromptFile());
						commonBean.setPriority(promoPackBean.getPromotionPackOtherDetails().getPriority());
						commonPackPackTypeList.add(commonBean);
						result = 1;
					} else {
						logger.error(userDataBean.getRequestId() + " >> No packs found for the promoPackMapKey ["
								+ promoPackMapKey + "], need to update details for product code [" + productCode
								+ "] in system. : msisdn [" + userDataBean.getMsisdn() + "].");
						result = -2;
					}
				}

			} else {
				logger.info(userDataBean.getRequestId()
						+ " >> No configurerd promotion pack found where availablePromoProductCodes ["
						+ availablePromoProductCodes + "] found for the requested MSISDN[" + userDataBean.getMsisdn()
						+ "]");
				result = -3;
			}

			logger.info(userDataBean.getRequestId()
					+ " >> Size of commonPackPackTypeList after filling configurable promotion packs is ["
					+ commonPackPackTypeList.size() + "] for MSISDN[" + userDataBean.getMsisdn() + "]");
		} catch (Exception ex) {
			logger.error(userDataBean.getRequestId()
					+ " >> Exception occur in fillPromoPacksList() method while getting all the promotioanl packs for the requested MSISDN:["
					+ userDataBean.getMsisdn() + "]. Error:", ex);
			ex.printStackTrace();
			return -1;
		}

		return result;
	}

	private String getNextReqPromotionPacks(UserDataBean userDataBean,
			ArrayList<PackPackTypeCommonBean> packPackTypeList, boolean isBalanceEnable) {
		CodeStatus status = null;

		try {
			logger.info(userDataBean.getRequestId() + " >>  packTypeId:[" + userDataBean.getPackTypeId() + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			String packList = userDataBean.getPackList();
			int tempIndex = packList.lastIndexOf(",");
			int currPackIndex = -1;

			logger.debug(userDataBean.getRequestId() + " >>  tempIndex:[" + tempIndex + "] Current Packs List:["
					+ packList + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			String tempPackId = null;
			if (tempIndex != -1) {
				// tempPackId is used to hold last Id of pack shown in previous
				// request
				tempPackId = packList.substring(tempIndex + 1);

			} else {
				if ((packList == null || "".equals(packList))) {
					// handle for if packList is empty
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00224")
							+ " >>received packList is empty in Next Option Menu request. PackList:[" + packList
							+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
					return null;
				} else {
					tempPackId = packList.trim();
				}
			}
			logger.debug(userDataBean.getRequestId() + " >>  tempPackId:[" + tempPackId + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			// currPackIndex hold index of current pack/packType id in arrayList
			for (PackPackTypeCommonBean commonBean : packPackTypeList) {
				if (commonBean.getProductCode().equals(tempPackId.trim())) {
					currPackIndex = packPackTypeList.indexOf(commonBean);
					break;
				}
			}

			logger.debug(userDataBean.getRequestId() + " >>  currentPackIndex:[" + currPackIndex + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			if (currPackIndex == -1) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00225") + " >>  pack id:["
						+ tempPackId + "] not found in the list of available packs for user.  packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
				userDataBean.setPackList("");
				return null;
			}

			// means last shown pack was last pack available in system
			if (packPackTypeList.size() - 1 == currPackIndex) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00226")
						+ " >> No More packs available for User, so its invalid request. packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId()));
				return null;
			}

			StringBuffer isMorePacksAvailable = new StringBuffer();

			currPackIndex = getNextPromotionPacksForUserCriteria(currPackIndex + 1, packPackTypeList, userDataBean,
					isMorePacksAvailable, isBalanceEnable);
			logger.debug(userDataBean.getRequestId() + " >>  returned Pack Index:[" + currPackIndex + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			if ("".equals(userDataBean.getPackList()) || userDataBean.getPackList() == null
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00227")
						+ " >>  Pack List is null or empty, No More packs available for User, packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.NO_MORE_PACKS_AVAILABLE + "_" + userDataBean.getLangId()));
				return null;
			}

			int moreMenuAvailable = packPackTypeList.size() - currPackIndex;
			logger.debug(userDataBean.getRequestId() + " >>  isMorePacksAvailable:[" + isMorePacksAvailable
					+ "] moreMenuAvailable:[" + moreMenuAvailable + "] all available pack list size["
					+ packPackTypeList.size() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			int maxUssdStringLengthAvailable = TSSJavaUtil.instance().getCacheParameters().getMaxUssdStringLength()// max
																													// allowed
																													// length
					- TSSJavaUtil.instance().getCacheParameters().getPackTypeDescription(userDataBean.getPackTypeId())
							.length()// header description of pack type
					- TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.PRESS + "_" + userDataBean.getLangId()).length()// press
																												// string
					- 2;// for 2 next lines

			if ((moreMenuAvailable > 0 && "1".equalsIgnoreCase(isMorePacksAvailable.toString()))
					|| userDataBean.getFilePath().length() > maxUssdStringLengthAvailable) {
				// we have to show the option for Next Menu also for prev
				status = generateFilePathString(userDataBean, true, true);
			} else if (moreMenuAvailable == 0 && userDataBean.getFilePath()
					.length() <= (maxUssdStringLengthAvailable - TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.STRING_PREV_OPTION_PACKS + "_" + userDataBean.getLangId())
							.length())) {
				// we have to not to show the option for next Menu but for prev
				status = generateFilePathString(userDataBean, false, true);
			} else if ((moreMenuAvailable == 0 && userDataBean.getFilePath()
					.length() > (maxUssdStringLengthAvailable - TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.STRING_PREV_OPTION_PACKS + "_" + userDataBean.getLangId())
							.length()))) {
				// we have to show the option for Next Menu also for prev
				status = generateFilePathString(userDataBean, true, true);
			} else {
				// we have to show the option for prev Menu but not for next
				status = generateFilePathString(userDataBean, false, true);
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " >>  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setPackList("");
			return null;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " >>  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", ex);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setPackList("");
			return null;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00228") + " >>  MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setPackList("");
			return null;
		}

		if (status == CodeStatus.SUCCESS) {
			logger.info(userDataBean.getRequestId() + " >>  filePath returned value is:[" + userDataBean.getFilePath()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return userDataBean.getFilePath();
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00233")
					+ " >>  filePath returned value is:[" + userDataBean.getFilePath() + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");
			return null;
		}

	}

	public String getPromotionPacksForFirstRequest(UserDataBean userDataBean,
			ArrayList<PackPackTypeCommonBean> packPackTypeList, boolean isBalanceEnable) {
		CodeStatus status = null;
		try {
			// packList is equal to null means it is first hit
			int currentPackIndex = 0; // used to iterate all available packs
			logger.info(userDataBean.getRequestId() + " >>  packTypeId:[" + userDataBean.getPackTypeId() + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			StringBuffer isMorePacksAvailable = new StringBuffer();

			currentPackIndex = getNextPromotionPacksForUserCriteria(currentPackIndex, packPackTypeList, userDataBean,
					isMorePacksAvailable, isBalanceEnable);

			if ("".equals(userDataBean.getPackList()) || userDataBean.getPackList() == null
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00221")
						+ " >> Pack List is null or empty, No packs available for User." + " packList:["
						+ userDataBean.getPackList() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.NO_PACKS_AVAILABLE + "_" + userDataBean.getLangId()));
				return null;
			}

			int moreMenuAvailable = packPackTypeList.size() - currentPackIndex;
			logger.debug(userDataBean.getRequestId() + " >> isMorePacksAvailable:[" + isMorePacksAvailable
					+ "] moreMenuAvailable:[" + moreMenuAvailable + "] available pack size:[" + packPackTypeList.size()
					+ "]  MSISDN:[" + userDataBean.getMsisdn() + "]");

			int maxUssdStringLengthAvailable = TSSJavaUtil.instance().getCacheParameters().getMaxUssdStringLength()// max
																													// allowed
																													// length
					- TSSJavaUtil.instance().getCacheParameters().getPackTypeDescription(userDataBean.getPackTypeId())
							.length()// header description of pack type
					- TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.PRESS + "_" + userDataBean.getLangId()).length()// press
																												// string(Tapez).
					- 2;// for 2 next lines

			if ((moreMenuAvailable > 0 && "1".equalsIgnoreCase(isMorePacksAvailable.toString()))
					|| (userDataBean.getFilePath().length() > maxUssdStringLengthAvailable)) {
				// we have to show the option for Next Menu but not for prev
				userDataBean.setMore("Y");
				status = generateFilePathString(userDataBean, true, false);
			} else if (moreMenuAvailable == 0
					&& userDataBean.getFilePath().length() <= (maxUssdStringLengthAvailable)) {
				// we have to not to show the option for not Next Menu and also
				// not for prev
				status = generateFilePathString(userDataBean, false, false);
			} else if ((moreMenuAvailable == 0 && userDataBean.getFilePath()
					.length() > (maxUssdStringLengthAvailable - TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.STRING_NEXT_OPTION_PACKS + "_" + userDataBean.getLangId())
							.length()))) {
				// we have to show the option for Next Menu but not for prev
				status = generateFilePathString(userDataBean, true, false);
				userDataBean.setMore("Y");
			} else {
				// no need to show the option for Next or prev Menu
				status = generateFilePathString(userDataBean, false, false);
			}
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> Exception occurred while fetching packs for user" + " MSISDN:[" + userDataBean.getMsisdn()
					+ "]", npe);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return null;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00222")
					+ " >> Exception occurred while fetching packs for user" + " MSISDN:[" + userDataBean.getMsisdn()
					+ "]", e);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return null;
		}

		if (status == CodeStatus.SUCCESS) {
			logger.info(userDataBean.getRequestId() + " >>  filePath generated for user to be shown is " + ":["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return userDataBean.getFilePath();
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00223")
					+ " >> filePath generated for user to be shown is " + ":[" + userDataBean.getFilePath()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return null;
		}

	}

	private int getNextPromotionPacksForUserCriteria(int currentPackIndex,
			ArrayList<PackPackTypeCommonBean> packPackTypeList, UserDataBean userDataBean,
			StringBuffer isMorePacksAvailable, boolean balanceBasedEnable) {
		logger.debug(userDataBean.getRequestId() + " >>  currentPackIndex:[" + currentPackIndex + "] MSISDN:["
				+ userDataBean.getMsisdn() + "]");
		int retCurrentIndex = -1;
		byte checkMaxMenus = 0; // used to check condition for max menu

		// maximum menus can be shown as configured in property file
		byte maxUssdMenus = TSSJavaUtil.instance().getCacheParameters().getMaxMenus();

		logger.info(userDataBean.getRequestId() + " >> all available packs for packTypeId:["
				+ userDataBean.getPackTypeId() + "] are:[" + packPackTypeList + "]  currentPackIndex:["
				+ currentPackIndex + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		PackPackTypeCommonBean commonBean = null;
		String filePath = "";

		// boolean balanceBasedEnable =
		// TSSJavaUtil.instance().getCacheParameters().isPackBasedOnBalanceEnable();
		logger.debug(userDataBean.getRequestId() + " >>  balanceBasedEnable:[" + balanceBasedEnable
				+ "], maxUssdMenus:[" + maxUssdMenus + "], MSISDN:[" + userDataBean.getMsisdn() + "]");
		userDataBean.setPackList("");

		for (retCurrentIndex = currentPackIndex; retCurrentIndex < packPackTypeList.size()
				&& checkMaxMenus < maxUssdMenus; retCurrentIndex++) {
			commonBean = packPackTypeList.get(retCurrentIndex);

			if ((balanceBasedEnable && (commonBean.getAmountRequired() == -1
					|| commonBean.getAmountRequired() <= userDataBean.getBalance())) || !balanceBasedEnable) {
				// need to append file path

				filePath = filePath
						+ TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.STRING_FOR_USSD_PACKS + "_" + userDataBean.getLangId())
								.replace("@@@", String.valueOf(checkMaxMenus + 1))
						+ commonBean.getPackPackTypeName() + "\n";
				checkMaxMenus++;
				userDataBean.setPackList(userDataBean.getPackList() + commonBean.getProductCode() + ",");
			}

		}

		checkMaxMenus = (byte) retCurrentIndex; // checkMaxMenus is used to
												// check weather more packs are
												// available to user
		// code to check weather more packs are available to user according to
		// balance
		logger.debug("checkMaxMenu:[" + checkMaxMenus + "] size:[" + packPackTypeList.size() + "]");
		for (; checkMaxMenus < packPackTypeList.size(); checkMaxMenus++) {
			commonBean = packPackTypeList.get(checkMaxMenus);

			if ((balanceBasedEnable && (commonBean.getAmountRequired() < 0
					|| commonBean.getAmountRequired() <= userDataBean.getBalance()))
					// if balance needs to be checked and balance more than
					// amount
					|| !balanceBasedEnable
			// or balance does not matter
			// In these cases show the pack
			) {
				logger.debug("isMorePacksAvailable:[" + isMorePacksAvailable + "]");
				// if more packs available then append 1
				isMorePacksAvailable.append(1);
				logger.debug(userDataBean.getRequestId()
						+ " >> still more packs are available for user, isMorePacksAvailable:[" + isMorePacksAvailable
						+ "]");
				break;
			}

		}

		userDataBean.setFilePath(filePath);

		logger.debug(userDataBean.getRequestId() + ">>  returned current index:[" + retCurrentIndex
				+ "] total available packs size:[" + packPackTypeList.size() + "] MSISDN:[" + userDataBean.getMsisdn()
				+ "]");

		return retCurrentIndex;
	}

	/**
	 * This method is used to get description of promotional pack selected by user.
	 * 
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return CodeStatus
	 */
	public CodeStatus fetchPromoPackDescription(UserDataBean userDataBean) {
		logger.info(
				userDataBean.getRequestId() + "] >>  fecthing Promotional pack description where product code list:["
						+ userDataBean.getPackList() + "] and selected digits:[" + userDataBean.getDigits()
						+ "] where MSISDN:[" + userDataBean.getMsisdn() + "]");
		String filePath = null;
		try {
			if (userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00249")
						+ " ] >>  product code list is empty or null or NA [" + userDataBean.getPackList()
						+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePath);
				return CodeStatus.FAILURE;
			}

			String[] packListArr = userDataBean.getPackList().split(",");

			int digits = Integer.parseInt(userDataBean.getDigits());
			logger.info(userDataBean.getRequestId() + "] >>  digits:[" + digits + "] packListArr length:["
					+ packListArr.length + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			if (digits <= 0 || digits > packListArr.length) {
				// INVALID REQUEST if digit value pressed is more than available
				// packs in menu
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId());
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePath);
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00250")
						+ " ] >>  total returned file path length:[" + filePath.length() + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				return CodeStatus.FAILURE;
			} else {

				String productCode = packListArr[digits - 1];
				userDataBean.setProductCode(productCode);

				String promoPackKey = productCode + "_" + userDataBean.getLangId() + "_" + userDataBean.getSubType();

				logger.info(userDataBean.getRequestId() + "] >>  >> key for available packs is promoPackKey["
						+ promoPackKey + "] MSISDN[" + userDataBean.getMsisdn() + "]");

				PromoPackBean promoPackBean = TSSJavaUtil.instance().getCacheParameters().getPromoPackDetailsMap()
						.get(promoPackKey);

				if (promoPackBean == null) {
					logger.error(userDataBean.getRequestId() + " ] >> MSISDN:[" + userDataBean.getMsisdn()
							+ "]promoPackBean not found for user so sending failure");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
					userDataBean.setProductCode("NA");
					return CodeStatus.FAILURE;
				}

				// For handling low balance of User
				if (promoPackBean.getPromotionPackOtherDetails().getAmountRequired() > userDataBean.getBalance()) {
					logger.info(userDataBean.getRequestId() + " MSISDN[" + userDataBean.getMsisdn() + "] "
							+ "User has Low Balance for purhcasing promotional pack. User Balance ["
							+ userDataBean.getBalance() + "] " + "Amount Require to purchase Pack ["
							+ promoPackBean.getPromotionPackOtherDetails().getAmountRequired() + "]");

					filePath = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.POD_PACK_PURCHASE_DESC_LOW_BALANCE + "_" + userDataBean.getLangId());

					String[] filePathArr = filePath.split("##");

					if (filePathArr.length == 3) {
						if (TSSJavaUtil.instance().getCacheParameters().getShowBalanceInLowBalanceMsg() == 1) {
							filePath = filePathArr[0] + filePathArr[1] + filePathArr[2];
						} else {
							filePath = filePathArr[0] + filePathArr[2];
						}
					}

					filePath = filePath.replace(MPCommonDataTypes.TOKEN_BALANCE,
							String.valueOf((int) userDataBean.getBalance()));

					userDataBean.setResult(ResponseParameters.LOW_BALANCE);
					userDataBean.setFilePath(filePath);
					return CodeStatus.FAILURE;

				}

				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_CONFIRM + "_" + userDataBean.getLangId());

				if (UssdMenuNames.DEFAULT_MENU_STRING.equals(filePath)) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00253") + " >> "
							+ UssdMenuNames.PACK_PURCHASE_CONFIRM + " is "
							+ "not defined in USSD menus cache so returning error");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(filePath);
					return CodeStatus.FAILURE;
				}

				filePath = filePath.replace("$(pack_desc)",
						promoPackBean.getPromotionPackOtherDetails().getPackDescription());
				filePath = filePath.replace("$(pack_name)", promoPackBean.getPromotionPackOtherDetails().getPackName());

				// added to show pack amount in double/float if true else in
				// Integer
				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					filePath = filePath.replace("$(pack_amount)",
							String.valueOf(promoPackBean.getPromotionPackOtherDetails().getVolume()));
				} else {
					filePath = filePath.replace("$(pack_amount)",
							String.valueOf((int) promoPackBean.getPromotionPackOtherDetails().getVolume()));
				}

				int maxStrLength = TSSJavaUtil.instance().getCacheParameters().getMaxUssdStringLength();
				if (TSSJavaUtil.instance().getCacheParameters().isPrevOptionOnPackDescEnable()) {
					int showPrevOptionLenth = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.STRING_PREV_OPTION_PACKS + "_" + userDataBean.getLangId())
							.length();
					maxStrLength = maxStrLength - (showPrevOptionLenth + 1);
				}

				logger.debug(userDataBean.getRequestId() + "] >>  filePath length:[" + filePath.length()
						+ "] maxUssdLength:[" + maxStrLength + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				if (filePath.length() > maxStrLength) {
					filePath = filePath.substring(0, maxStrLength);
					logger.info(userDataBean.getRequestId()
							+ "] >>  Pack Description will not properly seen, check maximum ussd string length configuration. PackDescription:["
							+ filePath + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				}
				if (TSSJavaUtil.instance().getCacheParameters().isPrevOptionOnPackDescEnable()) {
					filePath = filePath + "\n" + TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.STRING_PREV_OPTION_PACKS + "_" + userDataBean.getLangId());
				}
				logger.debug(userDataBean.getRequestId() + "] >>  total returned file path length:[" + filePath.length()
						+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.SUCCESS);

				userDataBean.setFilePath(filePath);
				return CodeStatus.SUCCESS;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", ex);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00255") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.EXCEPTION_OCCURED;
		}

	}// fetchPromoPackDescription() ends
	
	
	/**
	 * This method is used to get description of promotional pack selected by user
	 * 
	 * @author richard
	 * 
	 * @param userDataBean
	 * @return
	 */
	public CodeStatus fetchPromoPackDescriptionForIVR(UserDataBean userDataBean) {
		
		logger.info(
				userDataBean.getRequestId() + "] >>  fecthing Promotional pack description where product code list:["
						+ userDataBean.getPackList() + "] and selected digits:[" + userDataBean.getDigits()
						+ "] where MSISDN:[" + userDataBean.getMsisdn() + "]");
		String filePath = null;
		try {
			
			String ivr_base_path = TSSJavaUtil.instance().getCacheParameters().getCustomerCareIvrPromptBasePath();
			if (ivr_base_path.equalsIgnoreCase("") || ivr_base_path.equalsIgnoreCase("NA") || ivr_base_path == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			String ivrPackPromptBasePath = TSSJavaUtil.instance().getCacheParameters().getIvrPackPromptBasePath();
			if (ivrPackPromptBasePath.equalsIgnoreCase("") || ivrPackPromptBasePath.equalsIgnoreCase("NA")
					|| ivrPackPromptBasePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00325")
						+ " >> (IVR) ivrPackPromptBasePath found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			
			
			
			
			if (userDataBean.getPackList() == null || "".equals(userDataBean.getPackList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00249")
						+ " ] >>  product code list is empty or null or NA [" + userDataBean.getPackList()
						+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			String[] packListArr = userDataBean.getPackList().split(",");

			int digits = Integer.parseInt(userDataBean.getDigits());
			logger.info(userDataBean.getRequestId() + "] >>  digits:[" + digits + "] packListArr length:["
					+ packListArr.length + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			if (digits <= 0 || digits > packListArr.length) {
				// INVALID REQUEST if digit value pressed is more than available
				// packs in menu
				userDataBean.setResult(ResponseParameters.INVALID_DIGIT_PRESSED_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00250")
				+ " ] >> (IVR) total returned file path:[" + userDataBean.getFilePath() + "] MSISDN:["
				+ userDataBean.getMsisdn() + "]");
				return CodeStatus.FAILURE;
			} else {

				String productCode = packListArr[digits - 1];
				userDataBean.setProductCode(productCode);

				String promoPackKey = productCode + "_" + userDataBean.getLangId() + "_" + userDataBean.getSubType();

				logger.info(userDataBean.getRequestId() + "] >>  >> key for available packs is promoPackKey["
						+ promoPackKey + "] MSISDN[" + userDataBean.getMsisdn() + "]");

				PromoPackBean promoPackBean = TSSJavaUtil.instance().getCacheParameters().getPromoPackDetailsMap()
						.get(promoPackKey);

				if (promoPackBean == null) {
					logger.error(userDataBean.getRequestId() + " ] >> MSISDN:[" + userDataBean.getMsisdn()
							+ "]promoPackBean not found for user so sending failure");
					userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					userDataBean.setProductCode("NA");
					return CodeStatus.FAILURE;
				}

				// For handling low balance of User
				if (promoPackBean.getPromotionPackOtherDetails().getAmountRequired() > userDataBean.getBalance()) {
					logger.info(userDataBean.getRequestId() + " MSISDN[" + userDataBean.getMsisdn() + "] "
							+ "User has Low Balance for purhcasing promotional pack. User Balance ["
							+ userDataBean.getBalance() + "] " + "Amount Require to purchase Pack ["
							+ promoPackBean.getPromotionPackOtherDetails().getAmountRequired() + "]");

					filePath = ivr_base_path + userDataBean.getLangId() + File.separator
							+ IvrMenu.PACK_PURCHASE_LOW_BALANCE_IVR;
					userDataBean.setResult(ResponseParameters.LOW_BALANCE);
					userDataBean.setFilePath(filePath);
					return CodeStatus.FAILURE;

				}

				String promoDesPromptFile=promoPackBean.getPromotionPackOtherDetails().getPromptFile();
				
				promoDesPromptFile=promoDesPromptFile.substring(0, promoDesPromptFile.length()-4)+"_PD"+IvrMenu.PROMPT_EXTENSION;
				
				
				filePath = ivrPackPromptBasePath + userDataBean.getLangId() + File.separator + promoDesPromptFile
						+ TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.TO_CONFIRM + TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId()
						+ File.separator + IvrMenu.PRESS_1 + TSSJavaUtil.FileSeparator + ivr_base_path
						+ userDataBean.getLangId() + File.separator + IvrMenu.TO_GO_BACK + TSSJavaUtil.FileSeparator
						+ ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.PRESS_0;
				
				/*filePath = ivrPackPromptBasePath
						+ userDataBean.getLangId() + File.separator + promoDesPromptFile+ TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.PRESS_1 + TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.TO_ACTIVATE + TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.PRESS_0 + TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.TO_GO_BACK;*/
				

				if (filePath.equalsIgnoreCase(IvrMenu.NO_FILE_PATH_IVR) || filePath == null) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00318")
							+ " >> (IVR) File Path found is either NA or null.");
					userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					return CodeStatus.FAILURE;
				}	
				
				if (TSSJavaUtil.instance().getCacheParameters().getIsPrevOptionOnPackDescriptionEnableIvr() == 1) {

					filePath = filePath + TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId()
							+ File.separator + IvrMenu.PREV_OPTION_PACKS_WAV_IVR;
				}
				
				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setFilePath(filePath);
				return CodeStatus.SUCCESS;
			}

		} 
		catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", npe);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (NumberFormatException ex) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90004") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", ex);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00255") + " ] >> MSISDN:["
					+ userDataBean.getMsisdn() + "] Error ", e);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		}
	}
	

}