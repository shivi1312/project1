package com.telemune.marketplace.manager;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.telemune.marketplace.beans.DmcConversionConfig;
import com.telemune.marketplace.beans.UserAccountInfoBean;
import com.telemune.marketplace.beans.UserDataBean;
import com.telemune.marketplace.expiringmap.ExpiringMap;
import com.telemune.marketplace.util.CodeStatus;
import com.telemune.marketplace.util.IvrMenu;
import com.telemune.marketplace.util.MPCommonDataTypes;
import com.telemune.marketplace.util.MPTags;
import com.telemune.marketplace.util.PackTypes;
import com.telemune.marketplace.util.ResponseParameters;
import com.telemune.marketplace.util.TSSJavaUtil;
import com.telemune.marketplace.util.UssdMenuNames;

/**
 * This ServiceManager class is used to manage MarketPlace Services.
 * 
 * @author SIDDHARTH SINGH RAWAT
 */
public class ServicesManager {

	/**
	 * Used for printing logs in this class
	 */
	private static Logger logger = Logger.getLogger(ServicesManager.class);

	/**
	 * This method is used to get all Data Macro Credit available custom packs for
	 * requested amount or volume.(New Multiple Configuration).
	 * 
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return CodeStatus
	 */
	public CodeStatus getNewDMCAvailableOptions(UserDataBean userDataBean) {
		int minTransferLimit = 0;
		int maxTransferLimit = 0;
		int volToConvert = 0;
		int amount = 0;
		int result = -1;

		String filePath = "";

		CodeStatus status = null;

		try {
			logger.info(userDataBean.getRequestId()
					+ " >> (DMC) inside getNewDMCAvailableOptions to get all the available DMC custom packs for requested data where userDataBean: "
					+ userDataBean.toString());

			if (userDataBean.getPackActionType() == MPCommonDataTypes.DATA_MACRO_CREDIT_VOLUME_BASED_ACTION_TYPE) {
				minTransferLimit = Integer
						.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_VB_MIN_LIMIT));
				maxTransferLimit = Integer
						.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_VB_MAX_LIMIT));
				volToConvert = userDataBean.getDataToConvert();

				logger.info(userDataBean.getRequestId() + " >> (DMC-VB) minTransferLimit [" + minTransferLimit
						+ "], maxTransferLimit [" + maxTransferLimit + "], actionType ["
						+ userDataBean.getPackActionType() + "], volToConvert [" + volToConvert + "] msisdn ["
						+ userDataBean.getMsisdn() + "]");

				if (volToConvert >= minTransferLimit && volToConvert <= maxTransferLimit) {
					logger.info(userDataBean.getRequestId() + " >> (DMC-VB) volume to convert [" + volToConvert
							+ "] is valid for Data Macro Credit Volume Based Convertion.");
				} else {
					logger.info(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00344")
							+ " >> (DMC-VB) Data Macro Credit Volume Based Get Available Opiton FAILED because volume:["
							+ volToConvert + "] does not lie between minTransferLimit[" + minTransferLimit
							+ "] maxTransferLimit[" + maxTransferLimit + "].");
					userDataBean.setResult(ResponseParameters.FAILURE);

					if (volToConvert < minTransferLimit) {
						filePath = TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.DMC_VB_MIN_RANGE + "_" + userDataBean.getLangId());

						// Setting token values in file path
						filePath = filePath.replace(MPCommonDataTypes.TOKEN_MIN_AMOUNT,
								String.valueOf(minTransferLimit));
					} else {
						filePath = TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.DMC_VB_MAX_RANGE + "_" + userDataBean.getLangId());

						// Setting token values in file path
						filePath = filePath.replace(MPCommonDataTypes.TOKEN_MAX_AMOUNT,
								String.valueOf(maxTransferLimit));
					}

					userDataBean.setFilePath(filePath);
					return CodeStatus.FAILURE;
				}

				// This method is used to get available Data Macro Credit Custom packs for
				// selected volume
				result = this.setDMCVolumeBasedAvailableOption(userDataBean);
				logger.debug(userDataBean.getRequestId()
						+ " >> (DMC-VB) setDMCVolumeBasedAvailableOption method Result [" + result + "].");

				if (result > 0 && userDataBean.getFilePath() != null && !userDataBean.getFilePath().isEmpty()) {
					filePath = userDataBean.getFilePath();
					// Appending Header
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.PRESS + "_" + userDataBean.getLangId()) + "\n" + filePath;

					userDataBean.setFilePath(filePath);
					userDataBean.setResult(ResponseParameters.SUCCESS);

				} else {
					logger.error(userDataBean.getRequestId()
							+ " >> (DMC-VB) Error while getting Data Macro Credit Volume Based available options for requested volume ["
							+ volToConvert + "]  where msisdn [" + userDataBean.getMsisdn() + "].");
					return CodeStatus.FAILURE;
				}

				status = CodeStatus.SUCCESS;

			} // End of Data Macro Credit Service Volume Based
			else if (userDataBean.getPackActionType() == MPCommonDataTypes.DATA_MACRO_CREDIT_AMOUNT_BASED_ACTION_TYPE) {

				minTransferLimit = Integer
						.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_MIN_LIMIT));
				maxTransferLimit = Integer
						.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_MAX_LIMIT));
				amount = userDataBean.getDataToConvert();

				logger.info(userDataBean.getRequestId() + " >> (DMC-AB) minTransferLimit [" + minTransferLimit
						+ "], maxTransferLimit [" + maxTransferLimit + "], actionType ["
						+ userDataBean.getPackActionType() + "], amount [" + amount + "] msisdn ["
						+ userDataBean.getMsisdn() + "]");

				if (amount >= minTransferLimit && amount <= maxTransferLimit) {
					logger.info(userDataBean.getRequestId() + " >> (DMC-AB) Amount [" + amount
							+ "] is valid for Data Macro Credit Convertion.");
				} else {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00335")
							+ " >> (DMC-AB) Data macro credit transfer FAILED because amount:[" + amount
							+ "] does not lie between minTransferLimit:[" + minTransferLimit + "] maxTransferLimit:["
							+ maxTransferLimit + "].");
					userDataBean.setResult(ResponseParameters.FAILURE);

					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_BAL_NOT_IN_RANGE + "_" + userDataBean.getLangId());

					// Setting token values in file path
					filePath = filePath.replace(MPCommonDataTypes.TOKEN_MIN_AMOUNT, String.valueOf(minTransferLimit))
							.replace(MPCommonDataTypes.TOKEN_MAX_AMOUNT, String.valueOf(maxTransferLimit));

					userDataBean.setFilePath(filePath);
					return CodeStatus.FAILURE;
				}

				// This method is used to get available Data Macro Credit Service custom packs
				// for requested amount
				result = this.setDMCAmountBasedAvailableOption(userDataBean);
				logger.debug(userDataBean.getRequestId()
						+ " >> (DMC-AB) setDMCAmountBasedAvailableOption method Result [" + result + "]");

				if (result > 0 && userDataBean.getFilePath() != null && !userDataBean.getFilePath().isEmpty()) {
					filePath = userDataBean.getFilePath();
					// Appending Header
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.PRESS + "_" + userDataBean.getLangId()) + "\n" + filePath;

					userDataBean.setFilePath(filePath);
					userDataBean.setResult(ResponseParameters.SUCCESS);

				} else {
					logger.error(userDataBean.getRequestId()
							+ " >> (DMC-AB) Error while getting Data Macro Credit Amount Based available options for requested amount ["
							+ amount + "]  where msisdn [" + userDataBean.getMsisdn() + "].");

					return CodeStatus.FAILURE;
				}

				status = CodeStatus.SUCCESS;

			} else {
				logger.error(userDataBean.getRequestId() + " >> Unknown Action Type ["
						+ userDataBean.getPackActionType() + "] found. msisdn[" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));

				status = CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> (DMC) Null Pointer Exception occurred in Data Macro Credit Service while get available custom packs for requested data where msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00336")
					+ " >> (DMC) Exception occurred in Data Macro Credit Service while get available custom packs for requested data where msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		}

		return status;

	}

	/**
	 * This method is used to get the Data Macro Credit Pack Details for requested
	 * custom pack.
	 * 
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return CodeStatus
	 */
	public CodeStatus getDmcPackDetails(UserDataBean userDataBean) {

		logger.info(userDataBean.getRequestId() + " >> (DMC) in getDmcPackDetails with Action Type ["
				+ userDataBean.getPackActionType() + "] and Interface [" + userDataBean.getInterfaceUsed() + "].");

		int validityDays = -1;
		int convertedAmount = -1;
		int convertedVolume = -1;
		int volToConvert = 0;
		int digit = 0;
		int minTransferMbVB = 0;
		int maxTransferMbVB = 0;
		int minTransferLimit = 0;
		int maxTransferLimit = 0;
		int amount = 0;

		String conversionDataType = "";
		String filePath = "";
		CodeStatus status = null;
		String dmcValidityType = "";
		String serviceDetail = "";

		try {

			conversionDataType = TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_DATA_TYPE);
			dmcValidityType = TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_VALIDITY_TYPE);

			// Setting default Conversion Data Type if Data Type is not found in allowed
			// DATA TYPE:[TB|GB|MB|KB]
			if (!conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_TB)
					&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_GB)
					&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_MB)
					&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_KB)) {
				logger.error(userDataBean.getRequestId() + " >> (DMC) convertedDataType:[" + conversionDataType
						+ "] not found in allowed Data Type:[" + MPCommonDataTypes.DATA_UNIT_TYPE_TB + "|"
						+ MPCommonDataTypes.DATA_UNIT_TYPE_GB + "|" + MPCommonDataTypes.DATA_UNIT_TYPE_MB + "|"
						+ MPCommonDataTypes.DATA_UNIT_TYPE_KB
						+ "] for DMCP convertion so setting DEFAULT CONVERSION DATA TYPE:["
						+ MPCommonDataTypes.DATA_UNIT_TYPE_MB + "]");
				conversionDataType = MPCommonDataTypes.DATA_UNIT_TYPE_MB;
			}

			if (dmcValidityType == null || dmcValidityType.isEmpty() || dmcValidityType.equalsIgnoreCase("EXCEPTION")) {
				// Setting Default value
				dmcValidityType = MPCommonDataTypes.DMC_DEFAULT_VALIDITY_TYPE;
			}

			if (userDataBean.getPackList() == null || userDataBean.getPackList().isEmpty()) {
				logger.warn(userDataBean.getRequestId() + " >> (DMC) packList [" + userDataBean.getPackList()
						+ "] is found null or Empty. msisdn [" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));

				return CodeStatus.FAILURE;
			}

			if (userDataBean.getPackActionType() == MPCommonDataTypes.DATA_MACRO_CREDIT_VOLUME_BASED_ACTION_TYPE) {
				minTransferMbVB = Integer
						.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_VB_MIN_LIMIT));
				maxTransferMbVB = Integer
						.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_VB_MAX_LIMIT));
				volToConvert = userDataBean.getDataToConvert();
				digit = Integer.parseInt(userDataBean.getDigits());

				logger.info(userDataBean.getRequestId() + " >> (DMC-VB) conversionDataType [" + conversionDataType
						+ "], dmcValidityType [" + dmcValidityType + "], minTransferMbVB [" + minTransferMbVB
						+ "], maxTransferMbVB [" + maxTransferMbVB + "], volToConvert [" + volToConvert + "], digit ["
						+ digit + "]");

				if (volToConvert < minTransferMbVB || volToConvert > maxTransferMbVB) {
					logger.warn(userDataBean.getRequestId() + " >> (DMC-VB) volToConvert [" + volToConvert
							+ "] must lie between minTransferMbVB [" + minTransferMbVB + "] maxTransferMbVB ["
							+ maxTransferMbVB + "] range. msisdn [" + userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));

					return CodeStatus.FAILURE;
				}

				String[] packArray = userDataBean.getPackList().split(TSSJavaUtil.FileSeparator);
				logger.debug(userDataBean.getRequestId() + " >> (DMC-VB) Total Data Macro Credit Packs found ["
						+ packArray.length + "]");

				if (digit <= 0 || digit > packArray.length) {

					// INVALID REQUEST if digit value pressed is more than available packs in menu
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId());
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(filePath);

					logger.warn(userDataBean.getRequestId()
							+ ">> (DMC-VB) Invalid Digit Pressed. Invalid option is selected by user MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					return CodeStatus.FAILURE;

				} else {

					String selectedPack = packArray[digit - 1];
					String[] selectedPackDetailArr = selectedPack.split(MPCommonDataTypes.UNDERSCORE_SEPARATOR);

					logger.debug(userDataBean.getRequestId() + ">> (DMC-VB) selectedPack[" + selectedPack + "] length ["
							+ selectedPackDetailArr.length + "] must be equals to 3 : msisdn ["
							+ userDataBean.getMsisdn() + "]");
					if (selectedPackDetailArr.length == 3) {
						logger.info(userDataBean.getRequestId() + " >> digit pressed [" + digit
								+ "]  selected pack number [" + selectedPackDetailArr[0] + "] converted Amount ["
								+ selectedPackDetailArr[1] + "] MB, validiy [" + selectedPackDetailArr[2] + "] Days.");
						if (Integer.parseInt(selectedPackDetailArr[0]) == digit) {
							convertedAmount = Integer.parseInt(selectedPackDetailArr[1]);
							validityDays = Integer.parseInt(selectedPackDetailArr[2]);

						} else {
							logger.error(userDataBean.getRequestId() + " >> (DMC-VB) digit pressed [" + digit
									+ "] is not equals to selected pack number [" + selectedPackDetailArr[0]
									+ "] so not setting convertedData and validityDays.");
							userDataBean.setResult(ResponseParameters.FAILURE);
							userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
									.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
							return CodeStatus.FAILURE;
						}
					} else {
						logger.error(userDataBean.getRequestId() + " >> (DMC-VB) length of selectedPackDetailArr ["
								+ selectedPackDetailArr.length + "] not matched. Length Must be 3 : msisdn ["
								+ userDataBean.getMsisdn() + "]");
						userDataBean.setResult(ResponseParameters.FAILURE);
						userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
						return CodeStatus.FAILURE;
					}
				}

				logger.info(userDataBean.getRequestId() + " >> (DMC-VB) convertedAmount[" + convertedAmount
						+ "] validityDays[" + validityDays + "] minTransferMbVB [" + minTransferMbVB
						+ "] maxTransferMbVB [" + maxTransferMbVB + "] msisdn [" + userDataBean.getMsisdn() + "]");

				if (validityDays <= 0) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00070")
							+ " >> (DMC-VB) no validity days configuration found for Data Macro Credit Service for volume ["
							+ volToConvert + "] validity days [" + validityDays + "] so returning failure : "
							+ "msisdn [" + userDataBean.getMsisdn() + "]");

					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
					return CodeStatus.FAILURE;
				}

				// Setting service detail
				serviceDetail = convertedAmount + MPCommonDataTypes.UNDERSCORE_SEPARATOR + volToConvert
						+ MPCommonDataTypes.UNDERSCORE_SEPARATOR + validityDays;

				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMC_VB_CONVERSION_DETAIL + "_" + userDataBean.getLangId());

				// Setting token values in file path
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_AMOUNT, String.valueOf(convertedAmount))
						.replace(MPCommonDataTypes.TOKEN_DATA, String.valueOf(volToConvert))
						.replace(MPCommonDataTypes.TOKEN_VALIDITY_DAYS, String.valueOf(validityDays));

				if (validityDays > 1) {
					// Setting days in message as validity is more than 1 day.
					filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, MPCommonDataTypes.S);
				} else {
					// Setting days in message as validity is 1 day
					filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, "");
				}

				userDataBean.setFilePath(filePath);
				userDataBean.setServiceDetail(serviceDetail);
				userDataBean.setResult(ResponseParameters.SUCCESS);
				status = CodeStatus.SUCCESS;

			} else if (userDataBean
					.getPackActionType() == MPCommonDataTypes.DATA_MACRO_CREDIT_AMOUNT_BASED_ACTION_TYPE) {

				minTransferLimit = Integer
						.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_MIN_LIMIT));
				maxTransferLimit = Integer
						.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_MAX_LIMIT));
				amount = userDataBean.getDataToConvert();
				digit = Integer.parseInt(userDataBean.getDigits());

				logger.info(userDataBean.getRequestId() + " >> (DMC-AB) conversionDataType [" + conversionDataType
						+ "] dmcValidityType [" + dmcValidityType + "] minTransferLimit [" + minTransferLimit
						+ "] maxTransferLimit [" + maxTransferLimit + "] amount [" + amount + "].");

				String[] packArray = userDataBean.getPackList().split(TSSJavaUtil.FileSeparator);
				logger.debug(userDataBean.getRequestId() + " >> (DMC-AB) Total Data Macro Credit Packs found ["
						+ packArray.length + "]");

				if (digit <= 0 || digit > packArray.length) {
					// INVALID REQUEST if digit value pressed is more than available packs in menu
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId());
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(filePath);

					logger.warn(userDataBean.getRequestId()
							+ ">> (DMC-AB) Invalid Digit Pressed. Invalid option is selected by user MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					return CodeStatus.FAILURE;
				} else {

					String selectedPack = packArray[digit - 1];
					String[] selectedPackDetailArr = selectedPack.split(MPCommonDataTypes.UNDERSCORE_SEPARATOR);

					logger.debug(userDataBean.getRequestId() + ">> (DMC-AB) selectedPack[" + selectedPack + "] length ["
							+ selectedPackDetailArr.length + "] must equals to 3 : msisdn [" + userDataBean.getMsisdn()
							+ "]");
					if (selectedPackDetailArr.length == 3) {
						logger.info(userDataBean.getRequestId() + " >> (DMC-AB) digit pressed [" + digit
								+ "]  selected pack number [" + selectedPackDetailArr[0] + "] converted Volume ["
								+ selectedPackDetailArr[1] + "] MB, validiy [" + selectedPackDetailArr[2] + "] Days.");
						if (Integer.parseInt(selectedPackDetailArr[0]) == digit) {
							convertedVolume = Integer.parseInt(selectedPackDetailArr[1]);
							validityDays = Integer.parseInt(selectedPackDetailArr[2]);

						} else {
							logger.error(userDataBean.getRequestId() + " >> (DMC-AB) digit pressed [" + digit
									+ "] is not equals to selected pack number [" + selectedPackDetailArr[0]
									+ "] so not setting convertedData and validityDays.");
							userDataBean.setResult(ResponseParameters.FAILURE);
							userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
									.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
							return CodeStatus.FAILURE;
						}
					} else {
						logger.error(userDataBean.getRequestId() + " >> (DMC-AB) length of selectedPackDetailArr ["
								+ selectedPackDetailArr.length + "] not matched. Length Must be 3 : msisdn ["
								+ userDataBean.getMsisdn() + "]");
						userDataBean.setResult(ResponseParameters.FAILURE);
						userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
						return CodeStatus.FAILURE;
					}
				}

				logger.info(userDataBean.getRequestId() + " >> (DMC-AB) convertedVolume[" + convertedVolume
						+ "] validityDays[" + validityDays + "] minTransferLimit [" + minTransferLimit
						+ "] maxTransferLimit [" + maxTransferLimit + "] msisdn [" + userDataBean.getMsisdn() + "]");

				if (amount > maxTransferLimit || amount < minTransferLimit) {
					logger.warn(userDataBean.getRequestId() + " >> (DMC-AB) amount [" + amount
							+ "] must lie between minTransferLimit [" + minTransferLimit + "] maxTransferLimit ["
							+ maxTransferLimit + "] range. msisdn [" + userDataBean.getMsisdn() + "]");

					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));

					return CodeStatus.FAILURE;
				}

				if (validityDays <= 0) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00070")
							+ " >> (DMC-AB) no validity days configuration found for Data Macro Credit Service for amount ["
							+ amount + "] so returning failure : " + " validity days [" + validityDays + "] msisdn ["
							+ userDataBean.getMsisdn() + "]");

					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));

					return CodeStatus.FAILURE;
				}

				// Setting service detail
				serviceDetail = amount + MPCommonDataTypes.UNDERSCORE_SEPARATOR + convertedVolume
						+ MPCommonDataTypes.UNDERSCORE_SEPARATOR + validityDays;

				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMC_AB_CONVERSION_DETAIL + "_" + userDataBean.getLangId());

				// Setting token values in file path
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_AMOUNT, String.valueOf(amount))
						.replace(MPCommonDataTypes.TOKEN_DATA, String.valueOf(convertedVolume))
						.replace(MPCommonDataTypes.TOKEN_VALIDITY_DAYS, String.valueOf(validityDays));

				if (validityDays > 1) {
					// Setting days in message as validity is more than 1 day.
					filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, MPCommonDataTypes.S);
				} else {
					// Setting days in message as validity is 1 day
					filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, "");
				}

				userDataBean.setFilePath(filePath);
				userDataBean.setServiceDetail(serviceDetail);
				userDataBean.setResult(ResponseParameters.SUCCESS);
				status = CodeStatus.SUCCESS;

			} else {
				logger.error(userDataBean.getRequestId() + " >> Unknown Action Type ["
						+ userDataBean.getPackActionType() + "] found msisdn[" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));

				status = CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> (DMC) Exception occurred in data macro credit conversion msisdn [" + userDataBean.getMsisdn()
					+ "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00336")
					+ " >> (DMC) Exception occurred in data macro credit conversion for msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
			status = CodeStatus.EXCEPTION_OCCURED;
		}

		return status;

	} // getdmcPackDetails ends

	/**
	 * This method is use to get the list of all available Data Macro Credit Volume
	 * Based Service packs for given volume and set created pack list into
	 * UserDataBean.
	 * 
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return result 1 for success | negative value for failure/Exception
	 */
	private int setDMCVolumeBasedAvailableOption(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId()
				+ " >> (DMC-VB) inside setDMCVolumeBasedAvailableOption to get Data Macro Credit Volume Based Available Options for requested volume.");

		int result = -1;
		int count = 1;
		int volToConvert = 0;
		boolean dmcConfigRangeFound = false;
		String filePath = "";
		String packList = "";
		int packAmount = 0;
		try {

			volToConvert = userDataBean.getDataToConvert();
			String dataMacroPackTemplate = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.DMC_VB_PACK_TEMPLATE + "_" + userDataBean.getLangId());
			ArrayList<DmcConversionConfig> dmcConversionConfigList = TSSJavaUtil.instance().getCacheParameters()
					.getDmcVbConversionConfigList();

			if (dmcConversionConfigList == null || dmcConversionConfigList.isEmpty()) {
				logger.error(userDataBean.getRequestId()
						+ " >> (DMC-VB) dmcConversionConfigList found null or Empty. MSISDN ["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.NO_PACKS_AVAILABLE + "_" + userDataBean.getLangId()));
				return result;
			}

			logger.debug(userDataBean.getRequestId() + " >> (DMC-VB) dmcConversionConfigList Size ["
					+ dmcConversionConfigList.size() + "] volToConvert [" + volToConvert + "] msisdn ["
					+ userDataBean.getMsisdn() + "]");

			for (DmcConversionConfig dmcConversionConfig : dmcConversionConfigList) {
				if (volToConvert <= dmcConversionConfig.getMaxRange()
						&& volToConvert >= dmcConversionConfig.getMinRange()) {
					logger.debug(
							userDataBean.getRequestId() + " >> (DMC-VB) Data Macro Credit Volume Based Configurations ["
									+ dmcConversionConfig.toString() + "] found for requested volume to convert ["
									+ volToConvert + "]");

					for (Map.Entry<Integer, Double> entry : dmcConversionConfig.getPriceConfigMap().entrySet()) {
						packAmount = this.getDMCVolumeBasedPackAmount(volToConvert, entry.getValue());

						if (packAmount <= 0) {
							logger.warn(userDataBean.getRequestId() + " >> (DMC-VB) Converted Amount [" + packAmount
									+ "] for Data Macro Credit Volume Based Servie Packs must be positive");

						} else {
							dmcConfigRangeFound = true;
							filePath = filePath + count + "-" + dataMacroPackTemplate + "\n";
							packList = packList + count + MPCommonDataTypes.UNDERSCORE_SEPARATOR + packAmount
									+ MPCommonDataTypes.UNDERSCORE_SEPARATOR + entry.getKey()
									+ TSSJavaUtil.FileSeparator;

							filePath = filePath.replace(MPCommonDataTypes.TOKEN_AMOUNT, String.valueOf(packAmount))
									.replace(MPCommonDataTypes.TOKEN_VALIDITY_DAYS, String.valueOf(entry.getKey()));

							if (entry.getKey() > 1) {
								filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, MPCommonDataTypes.S);
							} else {
								filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, "");
							}
							count++;

						}
					}

					break;
				}
			}

			// Setting packList and filePath in UserdDataBean
			if (dmcConfigRangeFound) {
				result = 1;
				userDataBean.setPackList(packList);
				userDataBean.setFilePath(filePath);
			} else {
				logger.error(userDataBean.getRequestId() + " >> (DMC-VB) No packs found . MSISDN ["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.NO_PACKS_AVAILABLE + "_" + userDataBean.getLangId()));
			}
		} catch (Exception e) {
			result = -1;
			logger.error(
					"\n(DMC-VB) Exception occur while getting available options for Data Macro Credit Volume Based service.\n"
							+ e);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			e.printStackTrace();
		}

		logger.debug(userDataBean.getRequestId() + " >> (DMC-VB) setDMCVolumeBasedAvailableOption() file Path ["
				+ userDataBean.getFilePath() + "] packList[" + userDataBean.getPackList() + "]");
		return result;
	}

	/**
	 * This method is used to get the Data Macro Credit Volume Based Service pack
	 * amount for requested volume.
	 * 
	 * @param volume
	 * @param currencyConverterConstant
	 * @return converted amount
	 */
	private int getDMCVolumeBasedPackAmount(int volume, Double currencyConverterConstant) {
		int result = 0;
		try {
			result = (int) Math.round(volume * currencyConverterConstant);
		} catch (Exception e) {
			logger.error("(DMC-VB) Exception occur in getDMCVolumeBasedPackAmount where volume[" + volume
					+ "] dmcCurrencyConverter[" + currencyConverterConstant + "]");
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * This method is used to get the Data Macro Credit Amount Based Service pack
	 * volume for requested amount.
	 * 
	 * @param amount
	 * @param currencyConverterConstant
	 * @return converted amount
	 */
	private int getDMCAmountBasedPackVolume(int amount, Double currencyConverterConstant) {
		int result = 0;
		try {
			result = (int) Math.round(amount / currencyConverterConstant);
		} catch (Exception e) {
			logger.error("(DMC-AB) Exception occur in getDMCAmountBasedPackVolume where amount[" + amount
					+ "] dmcCurrencyConverter[" + currencyConverterConstant + "]");
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * This method is used to set the user's active data account into its filePath.
	 * 
	 * @author SIDDHARTH
	 * @param userDataBean
	 * @return CodeStatus
	 */
	public CodeStatus setUserActiveDataAccountDetails(UserDataBean userDataBean) {
		CodeStatus status = null;
		try {

			int currentPackIndex = 0; // used to iterate all available packs
			String lastActivePack = "";
			List<UserAccountInfoBean> userActiveAccInfoList = TSSJavaUtil.getUserAccountInfoTable()
					.get(userDataBean.getMsisdn().trim());

			// Setting currentPackIndex
			if (userDataBean.getActiveAccIdList() != null && !userDataBean.getActiveAccIdList().isEmpty()
					&& userDataBean.getActiveAccIdList().equalsIgnoreCase("NA")) {

				String[] activePackArr = userDataBean.getActiveAccIdList().split(",");
				lastActivePack = activePackArr[activePackArr.length - 1];

				logger.debug(userDataBean.getRequestId() + " >> ActiveAccIdList [" + userDataBean.getActiveAccIdList()
						+ "] lastActivePack [" + lastActivePack + "]  MSISDN [" + userDataBean.getMsisdn() + "]");

				for (UserAccountInfoBean bean : userActiveAccInfoList) {
					if (bean.getAcctId().equals(lastActivePack)) {
						currentPackIndex = userActiveAccInfoList.lastIndexOf(bean);
						currentPackIndex = currentPackIndex + 1;
						break;
					}
				}

			}

			if (currentPackIndex == -1) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00225")
						+ " >>  lastActivePack [" + lastActivePack
						+ "] not found in the list of available active data packs of user.  userActiveAccInfoList :["
						+ userActiveAccInfoList + "] MSISDN:[" + userDataBean.getMsisdn() + "] ");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
				userDataBean.setActiveAccIdList("");
				return CodeStatus.FAILURE;
			}

			logger.info(userDataBean.getRequestId() + " >> lastActivePack [" + lastActivePack
					+ "] updated currentPackIndex [" + currentPackIndex + "]  MSISDN [" + userDataBean.getMsisdn()
					+ "]");

			int totalUserDataActivePacks = TSSJavaUtil.getUserAccountInfoTable().get(userDataBean.getMsisdn().trim())
					.size();

			currentPackIndex = getUserActiveDataPacksForUserCriteria(currentPackIndex, userDataBean);

			if (userDataBean.getActiveAccIdList() == null || "".equals(userDataBean.getActiveAccIdList())
					|| "NA".equalsIgnoreCase(userDataBean.getPackList())) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00221")
						+ " >> User's Active Pack List is null or empty, No active data packs available for User."
						+ " ActiveAccIdList [" + userDataBean.getActiveAccIdList() + "] MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.NO_PACKS_AVAILABLE + "_" + userDataBean.getLangId()));
				return CodeStatus.FAILURE;
			}

			int moreMenuAvailable = totalUserDataActivePacks - currentPackIndex;

			// Max allowed length
			int maxUssdStringLengthAvailable = TSSJavaUtil.instance().getCacheParameters().getMaxUssdStringLength()
					- TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.CHECK_DATA_BALANCE_HEADER + "_" + userDataBean.getLangId())
							.length()// string(Tapez).
					- 2;// for 2 next lines

			int nextOptionLength = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.STRING_NEXT_OPTION_PACKS + "_" + userDataBean.getLangId())
					.length();

			logger.debug(userDataBean.getRequestId() + " >> moreMenuAvailable:[" + moreMenuAvailable
					+ "] totalUserDataActivePacks:[" + totalUserDataActivePacks + "] maxUssdStringLengthAvailable ["
					+ maxUssdStringLengthAvailable + "]  FilePath-Length [" + userDataBean.getFilePath().length()
					+ "] nextOptionLength [" + nextOptionLength + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			if ((moreMenuAvailable > 0) || (userDataBean.getFilePath().length() > (maxUssdStringLengthAvailable))) {
				// we have to show the option for Next Menu but not for prev
				status = generateActiveDataPackFilePath(userDataBean, true);
				userDataBean.setMore("Y");
			} else if (moreMenuAvailable == 0
					&& userDataBean.getFilePath().length() <= (maxUssdStringLengthAvailable)) {
				// we have to not to show the option for not Next Menu and also
				// not for prev
				status = generateActiveDataPackFilePath(userDataBean, false);
			} else if ((moreMenuAvailable == 0
					&& userDataBean.getFilePath().length() > (maxUssdStringLengthAvailable - nextOptionLength))) {
				// we have to show the option for Next Menu but not for prev
				status = generateActiveDataPackFilePath(userDataBean, true);
				userDataBean.setMore("Y");
			} else {
				// no need to show the option for Next or prev Menu
				status = generateActiveDataPackFilePath(userDataBean, false);
			}
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> Exception occurred while fetching user's data packs " + " MSISDN:["
					+ userDataBean.getMsisdn() + "]", npe);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.FAILURE;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00222")
					+ " >> Exception occurred while fetching user's data packs" + " MSISDN:[" + userDataBean.getMsisdn()
					+ "]", e);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			return CodeStatus.FAILURE;
		}

		if (status == CodeStatus.SUCCESS) {
			logger.info(userDataBean.getRequestId() + " >>  filePath generated for user to be shown is " + ":["
					+ userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return status;
		} else {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00223")
					+ " >> (ERROR) filePath generated for user to be shown is " + ":[" + userDataBean.getFilePath()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			return CodeStatus.FAILURE;
		}

	}

	/**
	 * This method is used to set the user's active packs based on index.
	 * 
	 * @param currentPackIndex
	 * @param userDataBean
	 * @return packIndex
	 */
	private int getUserActiveDataPacksForUserCriteria(int currentPackIndex, UserDataBean userDataBean) {
		logger.debug(userDataBean.getRequestId()
				+ " >> inside getUserActiveDataPacksForUserCriteria for setting file path with currentPackIndex:["
				+ currentPackIndex + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		int retCurrentIndex = -1;
		byte checkMaxMenus = 0; // used to check condition for max menu

		try {
			// maximum menus can be shown as configured in property file
			byte maxActiveDataAccUssdMenus = TSSJavaUtil.instance().getCacheParameters().getMaxActiveDataAccMenus();
			List<UserAccountInfoBean> userActiveAccInfoList = null;
			UserAccountInfoBean activeAccInfoBean = null;
			String filePath = "";

			userDataBean.setActiveAccIdList("");
			userActiveAccInfoList = TSSJavaUtil.getUserAccountInfoTable().get(userDataBean.getMsisdn().trim());

			for (retCurrentIndex = currentPackIndex; retCurrentIndex < userActiveAccInfoList.size()
					&& checkMaxMenus < maxActiveDataAccUssdMenus; retCurrentIndex++) {
				activeAccInfoBean = userActiveAccInfoList.get(retCurrentIndex);

				if (!userDataBean.getActiveAccIdList().contains(activeAccInfoBean.getAcctId())) {
					filePath = filePath
							+ TSSJavaUtil.instance().getCacheParameters()
									.getUssdMenuString(
											UssdMenuNames.STRING_FOR_USSD_PACKS + "_" + userDataBean.getLangId())
									.replace("@@@", String.valueOf(checkMaxMenus + 1))
							+ activeAccInfoBean.getPackName() + "\n";

					checkMaxMenus++;
					userDataBean.setActiveAccIdList(
							userDataBean.getActiveAccIdList() + activeAccInfoBean.getAcctId() + ",");
				}

			}

			checkMaxMenus = (byte) retCurrentIndex;

			logger.debug("checkMaxMenu:[" + checkMaxMenus + "] size:[" + userActiveAccInfoList.size() + "]");
			if (userActiveAccInfoList.size() > checkMaxMenus) {
				logger.debug(userDataBean.getRequestId()
						+ " >> still more active data packs are available for user, Remaning Packs :["
						+ (userActiveAccInfoList.size() - checkMaxMenus) + "]");
			}

			userDataBean.setFilePath(filePath);
			logger.debug(userDataBean.getRequestId() + ">>  returned current index:[" + retCurrentIndex
					+ "] total available active data pack size:[" + userActiveAccInfoList.size()
					+ "] Current ActiveAccountIdList [" + userDataBean.getActiveAccIdList() + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");
		} catch (Exception e) {
			retCurrentIndex = -1;
			logger.error(
					"Exception occur in getUserActiveDataPacksForUserCriteria method while getting user's active data packs. Exception: "
							+ e.getMessage());
			e.printStackTrace();
		}

		return retCurrentIndex;
	}

	/**
	 * This method is used to check the allowed length for USSD message and set the
	 * packs to be shown according to the max USSD allowed length.
	 * 
	 * @param userDataBean
	 * @param showOptionForNext
	 * @param showOptionForPrev
	 * @author SIDDHARTH
	 * @return CodeStatus
	 */
	private CodeStatus generateActiveDataPackFilePath(UserDataBean userDataBean, boolean showOptionForNext) {
		logger.info(userDataBean.getRequestId() + " >>  filePath:[" + userDataBean.getFilePath() + "] "
				+ "showOptionForNext:[" + showOptionForNext + "] MSISDN:[" + userDataBean.getMsisdn() + "] index:["
				+ userDataBean.getIndex() + "]");

		int filePathLength = userDataBean.getFilePath().length();

		int maxUssdStrLength = TSSJavaUtil.instance().getCacheParameters().getMaxUssdStringLength()// max
																									// allowed
																									// length
				- TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.CHECK_DATA_BALANCE_HEADER + "_" + userDataBean.getLangId())
						.length()// press string
				- 2;// for 2 next lines

		String strNextPackMessage = TSSJavaUtil.instance().getCacheParameters()
				.getUssdMenuString(UssdMenuNames.STRING_NEXT_OPTION_PACKS + "_" + userDataBean.getLangId());
		int strNextPackLength = strNextPackMessage.length();

		/*
		 * String strPrevPackMessage = TSSJavaUtil.instance().getCacheParameters()
		 * .getUssdMenuString(UssdMenuNames.STRING_PREV_OPTION_PACKS + "_" +
		 * userDataBean.getLangId()); int strPrevPackLength =
		 * strPrevPackMessage.length();
		 */

		logger.debug(userDataBean.getRequestId() + " >>  filePathLength:[" + filePathLength + "] maxUssdStrLength:["
				+ maxUssdStrLength + "] strNextPackMessage:[" + strNextPackMessage + "] strNextPackLength:["
				+ strNextPackLength + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		String tempFilePath = "";

		if (showOptionForNext == true) {
			// to show next option menu in filepath string
			int maxStrLength = maxUssdStrLength - (strNextPackLength);
			tempFilePath = null;
			logger.debug(userDataBean.getRequestId() + " >> maxStrLength:[" + maxStrLength + "] MSISDN:["
					+ userDataBean.getMsisdn() + "]");

			if (maxStrLength <= 0) {
				// if maxStrLength is < 0 return from here only that
				// configuration of max ussd string length is not proper
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00242")
						+ " >>  Configuration of Maximum USSD string length is not proper, Increase length to show Active Data Packs to user. MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				tempFilePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
				userDataBean.setFilePath(tempFilePath);
				userDataBean.setActiveAccIdList("");
				return CodeStatus.FAILURE;
			}

			if (filePathLength > maxStrLength)
				tempFilePath = userDataBean.getFilePath().substring(0, maxStrLength);
			else
				tempFilePath = userDataBean.getFilePath();

			int tempIndex = tempFilePath.lastIndexOf("\n");
			logger.debug(userDataBean.getRequestId() + " >> tempIndex:[" + tempIndex + "] tempFilePath:[" + tempFilePath
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			if (tempIndex > 0) {
				tempFilePath = tempFilePath.substring(0, tempIndex + 1);
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00244")
						+ " >>  Configuration of Maximum USSD string length is not proper, Increase length to show User's Active Data Packs to user. MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				tempFilePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
				userDataBean.setFilePath(tempFilePath);
				userDataBean.setActiveAccIdList("");
				return CodeStatus.FAILURE;
			}

			userDataBean.setFilePath(tempFilePath);
			this.generateActiveAccountsPerPage(userDataBean, tempFilePath.split("\n").length);
			logger.debug(userDataBean.getRequestId() + " >> ActiveAccIdList:[" + userDataBean.getActiveAccIdList()
					+ "] filePath:[" + userDataBean.getFilePath() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			tempFilePath = tempFilePath + strNextPackMessage;
			logger.debug(userDataBean.getRequestId() + " >>  final retured tempFilePath:[" + tempFilePath.length()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			userDataBean.setFilePath(tempFilePath);
		} else {
			this.generateActiveAccountsPerPage(userDataBean, userDataBean.getFilePath().split("\n").length);
			logger.debug(userDataBean.getRequestId() + " >>  ActiveAccIdList:[" + userDataBean.getActiveAccIdList()
					+ "] filePath:[" + userDataBean.getFilePath() + "] filePath-Length ["
					+ userDataBean.getFilePath().length() + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

			// All pack Id's will be shown
		}

		// now appending header in packs
		String finalFilePath = TSSJavaUtil.instance().getCacheParameters()
				.getUssdMenuString(UssdMenuNames.CHECK_DATA_BALANCE_HEADER + "_" + userDataBean.getLangId()) + "\n"
				+ userDataBean.getFilePath();
		userDataBean.setFilePath(finalFilePath);
		logger.debug(userDataBean.getRequestId() + " >>>  finalFilePath:[" + finalFilePath + "]   MSISDN:["
				+ userDataBean.getMsisdn() + "]");

		return CodeStatus.SUCCESS;

	}

	private void generateActiveAccountsPerPage(UserDataBean userDataBean, int totalPacksShown) {
		logger.info(userDataBean.getRequestId()
				+ " >>  this method set ActiveAccIdList which will be shown to user. MSISDN:["
				+ userDataBean.getMsisdn() + "]");

		logger.debug(userDataBean.getRequestId() + " >>  activeAccIdList:[" + userDataBean.getActiveAccIdList()
				+ "]  totalPackShown:[" + totalPacksShown + "] MSISDN:[" + userDataBean.getMsisdn() + "]");

		String tempActiveAccIdList = "";

		try {
			String activeAccIdListArray[] = userDataBean.getActiveAccIdList().split(",");

			for (int x = 0; x < totalPacksShown; x++) {
				tempActiveAccIdList += activeAccIdListArray[x] + ",";
			}

			userDataBean.setActiveAccIdList(tempActiveAccIdList.substring(0, tempActiveAccIdList.length() - 1));

			logger.debug(userDataBean.getRequestId() + " >>  Current Pack List:[" + userDataBean.getPackList()
					+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId()
					+ " >> Exception in generateActiveAccountsPerPage while getting user active data packs. Exception: "
					+ e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * This method is used to convert the Data in requested format. It takes the the
	 * data in byte and converted it into the requested format. It returns the
	 * converted data into double (In Decimal format) with configurable digits after
	 * decimal.
	 * 
	 * @param balance
	 * @param conversionDataType
	 * @param requestId
	 * @author SIDDHARTH
	 * @return convertedData in requested format (double)
	 */
	private double dataConverter(long balance, String conversionDataType, String requestId) {
		logger.info(requestId + " >> Inside dataConverter method with balance [" + balance + "] conversionDataType ["
				+ conversionDataType + "].");
		double convertedData = -1;
		byte numberAllowedAfterDecimal = 2;

		try {
			numberAllowedAfterDecimal = TSSJavaUtil.instance().getCacheParameters()
					.getCheckDataBalanceNumAllowedAfterDec();
			int decimalConvNumber = (int) Math.pow(10, numberAllowedAfterDecimal);
			logger.debug(requestId + " >> numberAllowedAfterDecimal [" + numberAllowedAfterDecimal
					+ "] decimalConvNumber [" + decimalConvNumber + "]");
			if (MPCommonDataTypes.DATA_UNIT_TYPE_TB.equalsIgnoreCase(conversionDataType)) {
				convertedData = ((double) (Math.round((balance / ((long) MPCommonDataTypes.DATA_CONVERSION_CONSTANT_1024
						* MPCommonDataTypes.DATA_CONVERSION_CONSTANT_1024
						* MPCommonDataTypes.DATA_CONVERSION_CONSTANT_1024
						* MPCommonDataTypes.DATA_CONVERSION_CONSTANT_1024)) * decimalConvNumber)) / decimalConvNumber);
			} else if (MPCommonDataTypes.DATA_UNIT_TYPE_GB.equalsIgnoreCase(conversionDataType)) {
				convertedData = ((double) (Math.round((balance / ((long) MPCommonDataTypes.DATA_CONVERSION_CONSTANT_1024
						* MPCommonDataTypes.DATA_CONVERSION_CONSTANT_1024
						* MPCommonDataTypes.DATA_CONVERSION_CONSTANT_1024)) * decimalConvNumber)) / decimalConvNumber);
			} else if (MPCommonDataTypes.DATA_UNIT_TYPE_MB.equalsIgnoreCase(conversionDataType)) {
				convertedData = ((double) (Math.round((balance / ((long) MPCommonDataTypes.DATA_CONVERSION_CONSTANT_1024
						* MPCommonDataTypes.DATA_CONVERSION_CONSTANT_1024)) * decimalConvNumber)) / decimalConvNumber);
			} else if (MPCommonDataTypes.DATA_UNIT_TYPE_KB.equalsIgnoreCase(conversionDataType)) {
				convertedData = ((double) (Math
						.round((balance / (long) MPCommonDataTypes.DATA_CONVERSION_CONSTANT_1024) * decimalConvNumber))
						/ decimalConvNumber);
			} else {
				throw new Exception("unsupported volume type");
			}

			logger.info(requestId + " >> balance [" + balance + "] conversionDataType [" + conversionDataType
					+ "] decimalConvNumber [" + decimalConvNumber + "] convertedData [" + convertedData + "]");
		} catch (Exception e) {
			convertedData = -1;
			logger.error(requestId + " >> Exception occurred in dataConverter while converting user data.", e);
			e.printStackTrace();
		}
		return convertedData;
	}

	/**
	 * This method is used to get the user's data account detail.
	 * 
	 * @param userDataBean
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred etc.
	 */
	public CodeStatus getUserDataAccountDetail(UserDataBean userDataBean) {
		logger.debug(userDataBean.getRequestId() + " >> Going to get user's data balance : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		List<UserAccountInfoBean> userAccountList = null;
		ExpiringMap<String, List<UserAccountInfoBean>> userAccountInfoTable = null;

		SimpleDateFormat reDateFormat;
		String reqFormatStr = "";
		String currResponseFormat = "";
		String filePath = "";
		String expiryTime = "";
		String expDateTimeInReqFormat = "";
		String conversionDataType = "";
		String packName = "";
		String selectedAccType = "";
		double convertedData = 0;
		long dataBalance = 0l;
		boolean accountIdFound = false;

		try {
			reqFormatStr = TSSJavaUtil.instance().getCacheParameters().getCheckDataBlanceDateFormat();
			currResponseFormat = MPCommonDataTypes.CURRENT_RESP_DATE_FORMAT;
			reDateFormat = new SimpleDateFormat(reqFormatStr);
			conversionDataType = TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DEFAULT_USER_DATA_TYPE);

			String[] selectedAccTypeArr = userDataBean.getActiveAccIdList().split(",");

			if (!TSSJavaUtil.isInteger(userDataBean.getDigits())) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId());
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePath);
				userDataBean.setPackPurchaseDetail(
						MPCommonDataTypes.CHECK_DATA_BALANCE_ACTION_TYPE + ":" + ResponseParameters.FAILURE);
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00342") + " digit["
						+ userDataBean.getDigits() + "] is not valid, digit Must be an Integer. MSISDN:["
						+ userDataBean.getMsisdn() + "]");
				return CodeStatus.FAILURE;
			}

			int digits = Integer.parseInt(userDataBean.getDigits());
			logger.debug(userDataBean.getRequestId() + "] >>  digits:[" + digits + "] packListArr length:["
					+ selectedAccTypeArr.length + "] MSISDN:[" + userDataBean.getMsisdn() + "]");
			if (digits <= 0 || digits > selectedAccTypeArr.length) {
				// INVALID REQUEST if digit value pressed is more than available packs in menu
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.INVALID_REQUEST + "_" + userDataBean.getLangId());
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(filePath);
				userDataBean.setPackPurchaseDetail(
						MPCommonDataTypes.CHECK_DATA_BALANCE_ACTION_TYPE + ":" + ResponseParameters.FAILURE);
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00344")
						+ " ] >> Invalid selected option total returned file path length:[" + filePath.length()
						+ "] MSISDN:[" + userDataBean.getMsisdn() + "]");
				return CodeStatus.FAILURE;
			} else {
				selectedAccType = selectedAccTypeArr[digits - 1];
			}

			logger.info(userDataBean.getRequestId() + " >> reqFormatStr [" + reqFormatStr + "] currResponseFormat ["
					+ currResponseFormat + "] conversionDataType [" + conversionDataType + "]  ActiveAccountIdList["
					+ userDataBean.getActiveAccIdList() + "] digit [" + userDataBean.getDigits() + "] selectedAccType ["
					+ selectedAccType + "]");

			// Setting default Conversion Data Type if Data Type is not found in allowed
			// DATA TYPE:[TB|GB|MB|KB]
			if (!conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_TB)
					&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_GB)
					&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_MB)
					&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_KB)) {
				logger.error("convertedDataType:[" + conversionDataType + "] not found in allowed Data Type:["
						+ MPCommonDataTypes.DATA_UNIT_TYPE_TB + "|" + MPCommonDataTypes.DATA_UNIT_TYPE_GB + "|"
						+ MPCommonDataTypes.DATA_UNIT_TYPE_MB + "|" + MPCommonDataTypes.DATA_UNIT_TYPE_KB
						+ "] for DMCP convertion so setting DEFAULT CONVERSION DATA TYPE:["
						+ MPCommonDataTypes.DATA_UNIT_TYPE_MB + "]");
				conversionDataType = MPCommonDataTypes.DATA_UNIT_TYPE_MB;
			}

			if (TSSJavaUtil.instance().getCacheParameters().getUnlimitedDataAccountTypes().contains(selectedAccType)) {
				logger.info(userDataBean.getRequestId() + " >> Selected Account Type [" + selectedAccType
						+ "] is Unlimited Data Account. So Setting Template for Unlimited Data Pack where MSISDN["
						+ userDataBean.getMsisdn() + "]");
				filePath = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
						UssdMenuNames.CHECK_UNLIMITED_DATA_BALANCE_TEMPLATE + "_" + userDataBean.getLangId());
			} else {
				logger.info(userDataBean.getRequestId() + " >> Selected Account Type [" + selectedAccType
						+ "] is Normal Data Account. So Setting Template for Normal Data Pack where MSISDN["
						+ userDataBean.getMsisdn() + "]");
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.CHECK_DATA_BALANCE_TEMPLATE + "_" + userDataBean.getLangId());
			}

			userAccountInfoTable = TSSJavaUtil.getUserAccountInfoTable();
			userAccountList = userAccountInfoTable.get(userDataBean.getMsisdn().trim());

			if (userAccountList != null && !userAccountList.isEmpty()) {
				for (UserAccountInfoBean userAccountInfoBean : userAccountList) {
					if (userAccountInfoBean.getAcctId().trim().equals(selectedAccType)) {
						accountIdFound = true;
						dataBalance = dataBalance + Long.parseLong(userAccountInfoBean.getBalance());
						expiryTime = userAccountInfoBean.getExpiryTime();
						packName = userAccountInfoBean.getPackName();
					}
				}
			} else {
				logger.warn(userDataBean.getRequestId() + " >> userAccountList [" + userAccountList
						+ "] not found for the requested MSISDN [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.CHECK_BALANCE_FAILURE + "_" + userDataBean.getLangId()));
				userDataBean.setPackPurchaseDetail(
						MPCommonDataTypes.CHECK_DATA_BALANCE_ACTION_TYPE + ":" + ResponseParameters.FAILURE);
				return CodeStatus.FAILURE;
			}

			if (!accountIdFound) {
				logger.error(userDataBean.getRequestId() + " >> Selected selectedAccType [" + selectedAccType
						+ "] not found in the user's active account list. MSISDN [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.CHECK_BALANCE_FAILURE + "_" + userDataBean.getLangId()));
				userDataBean.setPackPurchaseDetail(
						MPCommonDataTypes.CHECK_DATA_BALANCE_ACTION_TYPE + ":" + ResponseParameters.FAILURE);
				return CodeStatus.FAILURE;
			}

			logger.info(userDataBean.getRequestId() + " >> accountIdFound [" + accountIdFound + "] dataBalance ["
					+ dataBalance + "] conversionDataType [" + conversionDataType + "]  MSISDN ["
					+ userDataBean.getMsisdn() + "]");
			convertedData = this.dataConverter(dataBalance, conversionDataType, userDataBean.getRequestId());

			if (convertedData < 0) {
				logger.error(userDataBean.getRequestId() + " Error occurred while converting Data convertedData ["
						+ convertedData + "] conversionDataType [" + conversionDataType + "]   MSISDN ["
						+ userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.CHECK_BALANCE_FAILURE + "_" + userDataBean.getLangId()));
				userDataBean.setPackPurchaseDetail(
						MPCommonDataTypes.CHECK_DATA_BALANCE_ACTION_TYPE + ":" + ResponseParameters.FAILURE);
				return CodeStatus.FAILURE;
			}

			// Now Checking for float data (enable or not)
			if (TSSJavaUtil.instance().getCacheParameters().isCheckDataBalanceFloatEnable()) {
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_DATA, String.valueOf(convertedData));
			} else {
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_DATA, String.valueOf((int) convertedData));
			}

			logger.info("convertedData [" + convertedData + "] expiryTime [" + expiryTime + "] currResponseFormat ["
					+ currResponseFormat + "]");
			expDateTimeInReqFormat = reDateFormat.format(new SimpleDateFormat(currResponseFormat).parse(expiryTime));

			// Now Going to replace the token in file path
			filePath = filePath.replace(MPCommonDataTypes.TOKEN_DATE, expDateTimeInReqFormat);

			// Setting Pack Name in file path
			filePath = filePath.replace(MPCommonDataTypes.TOKEN_PACK_NAME, packName.trim());

			logger.info(userDataBean.getRequestId() + " >> filePath [" + filePath + "] MSISDN ["
					+ userDataBean.getMsisdn() + "]");
			userDataBean.setResult(ResponseParameters.SUCCESS);
			userDataBean.setFilePath(filePath);
			userDataBean.setPackPurchaseDetail(
					MPCommonDataTypes.CHECK_DATA_BALANCE_ACTION_TYPE + ":" + ResponseParameters.SUCCESS);

			return CodeStatus.SUCCESS;
		} catch (

		NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occurred while checking user balance " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.CHECK_BALANCE_FAILURE + "_" + userDataBean.getLangId()));
			userDataBean.setPackPurchaseDetail(
					MPCommonDataTypes.CHECK_DATA_BALANCE_ACTION_TYPE + ":" + ResponseParameters.FAILURE);

			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00065")
					+ " >> Exception occurred while checking user balance " + ": msisdn [" + userDataBean.getMsisdn()
					+ "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.CHECK_BALANCE_FAILURE + "_" + userDataBean.getLangId()));
			userDataBean.setPackPurchaseDetail(
					MPCommonDataTypes.CHECK_DATA_BALANCE_ACTION_TYPE + ":" + ResponseParameters.FAILURE);

			return CodeStatus.EXCEPTION_OCCURED;
		}

	}

	/**
	 * This method is use to get the list of all available Data Macro Credit Amount
	 * Based Custom Service packs for given amount and set created pack list into
	 * UserDataBean.
	 * 
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return result 1 for success | negative value for failure/Exception
	 */
	private int setDMCAmountBasedAvailableOption(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId()
				+ " >> (DMC-AB) inside setDMCAmountBasedAvailableOption to get Data Macro Credit Amount Based Available Options for requested amount ["
				+ userDataBean.getDataToConvert() + "] for msisdn [" + userDataBean.getMsisdn() + "].");

		int result = -1;
		int count = 1;
		int balToConvert = 0;
		boolean dmcConfigRangeFound = false;
		String filePath = "";
		String packList = "";
		int packVolume = 0;
		try {

			balToConvert = userDataBean.getDataToConvert();
			String dataMacroPackTemplate = TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.DMC_AB_PACK_TEMPLATE + "_" + userDataBean.getLangId());
			ArrayList<DmcConversionConfig> dmcConversionConfigList = TSSJavaUtil.instance().getCacheParameters()
					.getDmcAbConversionConfigList();

			if (dmcConversionConfigList == null || dmcConversionConfigList.isEmpty()) {
				logger.error(userDataBean.getRequestId()
						+ " >> (DMC-AB) dmcConversionConfigList found null or Empty. MSISDN ["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.NO_PACKS_AVAILABLE + "_" + userDataBean.getLangId()));
				return result;
			}

			logger.debug(userDataBean.getRequestId() + " >> (DMC-AB) dmcConversionConfigList Size ["
					+ dmcConversionConfigList.size() + "] balToConvert [" + balToConvert + "] msisdn ["
					+ userDataBean.getMsisdn() + "]");

			for (DmcConversionConfig dmcConversionConfig : dmcConversionConfigList) {
				if (balToConvert <= dmcConversionConfig.getMaxRange()
						&& balToConvert >= dmcConversionConfig.getMinRange()) {
					logger.debug(
							userDataBean.getRequestId() + " >> (DMC-AB) Data Macro Credit Amount Based Configurations ["
									+ dmcConversionConfig.toString() + "] found for requested balance to convert ["
									+ balToConvert + "]");

					for (Map.Entry<Integer, Double> entry : dmcConversionConfig.getPriceConfigMap().entrySet()) {
						packVolume = this.getDMCAmountBasedPackVolume(balToConvert, entry.getValue());

						if (packVolume <= 0) {
							logger.warn(userDataBean.getRequestId() + " >> (DMC-AB) Converted Volume [" + packVolume
									+ "] for Data Macro Credit Amount Based Servie Packs must be positive");

						} else {
							dmcConfigRangeFound = true;
							filePath = filePath + count + "-" + dataMacroPackTemplate + "\n";
							packList = packList + count + MPCommonDataTypes.UNDERSCORE_SEPARATOR + packVolume
									+ MPCommonDataTypes.UNDERSCORE_SEPARATOR + entry.getKey()
									+ TSSJavaUtil.FileSeparator;

							filePath = filePath.replace(MPCommonDataTypes.TOKEN_DATA, String.valueOf(packVolume))
									.replace(MPCommonDataTypes.TOKEN_VALIDITY_DAYS, String.valueOf(entry.getKey()));

							if (entry.getKey() > 1) {
								filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, MPCommonDataTypes.S);
							} else {
								filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, "");
							}
							count++;

						}
					}

					break;
				}
			}

			// Setting packList and filePath in UserdDataBean
			if (dmcConfigRangeFound) {
				result = 1;
				userDataBean.setPackList(packList);
				userDataBean.setFilePath(filePath);
			} else {
				logger.error(userDataBean.getRequestId() + " >> (DMC-AB) No packs found . MSISDN ["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.NO_PACKS_AVAILABLE + "_" + userDataBean.getLangId()));
			}
		} catch (Exception e) {
			result = -1;
			logger.error(
					"\n(DMC-AB) Exception occur while getting available options for Data Macro Credit Amount Based service.\n"
							+ e);
			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			e.printStackTrace();
		}

		logger.debug(userDataBean.getRequestId() + " >> (DMC-AB) setDMCAmountBasedAvailableOption() file Path ["
				+ userDataBean.getFilePath() + "] packList[" + userDataBean.getPackList() + "]");
		return result;
	}

}
