/**
 * @author bhavna
 * Created on 28 Mar, 2017
 */
package com.telemune.marketplace.manager;

import org.apache.log4j.Logger;

import com.telemune.marketplace.beans.ShortCodeMapping;
import com.telemune.marketplace.beans.UserDataBean;
import com.telemune.marketplace.util.ServiceTypes;
import com.telemune.marketplace.util.TSSJavaUtil;
import com.telemune.marketplace.util.UssdMenuNames;

/**
 * This class handles the short codes in case of Direct Dial only.
 * @author bhavna
 */


public class DirectDialHandler {
	
	/**
	 * Used for printing logs in this class
	 */
	private static Logger logger = Logger.getLogger(DirectDialHandler.class);
	
	
	
	/**
	 * This method is used to validate the shortCode for Direct Dial
	 * matches the short code from DB by doing substring
	 * @param shortCode
	 * @param userDataBean
	 * @return true if shortCode is valid otherwise false
	 */
	public boolean checkAndParseShortCode(String shortCode, UserDataBean userDataBean)
	{
		logger.debug(userDataBean.getRequestId()+" >> In case of Direct Dial, validating ShortCode ["+shortCode+"]");
		
		
		//checking SHORT_CODE not to be null or blank
		if(shortCode==null || "".equals(shortCode))
		{
			logger.error(userDataBean.getRequestId()+" "+TSSJavaUtil.getLogInitial("00301")+ " >> In case of Direct Dial, shortcode is blank or null ["+shortCode+"] so returning error");
			return false;
		}
		
		if(!shortCode.endsWith("#") || !shortCode.contains("*") || shortCode.lastIndexOf("*")==shortCode.length()-2)
		{
			logger.info(userDataBean.getRequestId()+ " >> Invalid shortcode "
					+ "either it does not end with '#' or does't contain '*' or contains '*' before #, so returning invalid shortcode");
			String filePath = TSSJavaUtil.instance().getCacheParameters().
					getUssdMenuString(UssdMenuNames.INVALID_SHORT_CODE+"_"+userDataBean.getLangId());
			filePath = filePath.replace("$(short_code)", shortCode);
			userDataBean.setFilePath(filePath);
			return false;
		}
		
		String tempShortCode = shortCode;
		boolean shortCodeExist = false;
		
		while(tempShortCode.contains("*"))
		{
			logger.debug(userDataBean.getRequestId()+" Matching shortcode ["+tempShortCode+"] with configuration table");
			
			if(!TSSJavaUtil.instance().getCacheParameters().getShortCodeMappedDetails().containsKey(tempShortCode))
			{
					tempShortCode = tempShortCode.substring(0,tempShortCode.lastIndexOf("*"));
					tempShortCode = tempShortCode+"#";
			}
			else
			{
				logger.info(userDataBean.getRequestId()+  " >> Shortcode ["+tempShortCode+"] found in configuration table for direct dial.");
				shortCodeExist = true;

				ShortCodeMapping shortCodeBean = TSSJavaUtil.instance().getCacheParameters().getShortCodeMappedDetails().get(tempShortCode);
				
				userDataBean.setShortCode(shortCode);
				userDataBean.setServiceType(shortCodeBean.getServiceType());
				
				logger.info(userDataBean.getRequestId()+  " >> Shortcode ["+tempShortCode+"] found in configuration table for direct dial. details ["+shortCodeBean+"]");
				
				return this.parseShortCode(shortCodeBean.getNumOfParameter(),userDataBean);
			}
		}//while
		if(!shortCodeExist)
		{
			logger.info(userDataBean.getRequestId()+ "  >> Invalid shortcode "
					+ " as it did not find in configuration table, so returning invalid shortcode");
			String filePath = TSSJavaUtil.instance().getCacheParameters().
					getUssdMenuString(UssdMenuNames.INVALID_SHORT_CODE+"_"+userDataBean.getLangId());
			filePath = filePath.replace("$(short_code)", shortCode);
			userDataBean.setFilePath(filePath);
			return false;
		}
		return true;
	}//isValidShortCode() ends
	
	
	
	
		
	/**
	 * Used to parse short code
	 * get the serviceType corresponding to that short code.  
	 * @param numOfParameters
	 * @param userDataBean
	 * @return true if success otherwise false
	 */
	public boolean parseShortCode(byte numOfParameters,UserDataBean userDataBean)
	{
		//remove # from the end of string.
		String shortCode = userDataBean.getShortCode().substring(0, userDataBean.getShortCode().length()-1);
		String[] paramsInShortCode = shortCode.split("\\*");
		int count = paramsInShortCode.length-1;
		
		if(count!=numOfParameters)
		{
			logger.info(userDataBean.getRequestId()+ "  >> Invalid shortcode "
					+ " as Number of parameters in shortcode should be ["+numOfParameters+"] but recieved ["+count+"] for serviceType "
					+ "["+userDataBean.getServiceType()+"], so returning invalid short code syntax");
			String filePath = TSSJavaUtil.instance().getCacheParameters().
					getUssdMenuString(UssdMenuNames.INVALID_SHORT_CODE_SYNTAX+"_"+userDataBean.getLangId());
			filePath = filePath.replace("$(short_code)", userDataBean.getShortCode());
			userDataBean.setFilePath(filePath);
			return false;
		}
		
		
		if(ServiceTypes.PACK_PURHCASE.equalsIgnoreCase(userDataBean.getServiceType()))
		{
			try
			{
				userDataBean.setVirtualCode(Integer.parseInt(paramsInShortCode[numOfParameters].trim()));
			}
			catch(NumberFormatException nfe)
			{
				logger.info(userDataBean.getRequestId()+ " >> virtualCode recieved in shortcode ["+paramsInShortCode[numOfParameters]+"] "
						+ "but it must be an integer : msisdn ["+userDataBean.getMsisdn()+"] serviceType : ["+userDataBean.getServiceType()+"]");
				String filePath = TSSJavaUtil.instance().getCacheParameters().
						getUssdMenuString(UssdMenuNames.INVALID_VIRTUAL_CODE_PP+"_"+userDataBean.getLangId());
				filePath = filePath.replace("$(virtual_code)", String.valueOf(userDataBean.getVirtualCode()));
				userDataBean.setFilePath(filePath);
				return false;
			}
			catch(Exception e)
			{
				logger.info(userDataBean.getRequestId()+ " >> virtualCode recieved in shortcode ["+paramsInShortCode[numOfParameters]+"] "
						+ "but it must be an integer : msisdn ["+userDataBean.getMsisdn()+"] serviceType : ["+userDataBean.getServiceType()+"]");
				String filePath = TSSJavaUtil.instance().getCacheParameters().
						getUssdMenuString(UssdMenuNames.INVALID_VIRTUAL_CODE_PP+"_"+userDataBean.getLangId());
				filePath = filePath.replace("$(virtual_code)", String.valueOf(userDataBean.getVirtualCode()));
				userDataBean.setFilePath(filePath);
				return false;
			}
		}
		else if(ServiceTypes.DATA_TRANSFER.equalsIgnoreCase(userDataBean.getServiceType()))
		{
			userDataBean.setFmsisdn(paramsInShortCode[3].trim());
			try
			{
				userDataBean.setVirtualCode(Integer.parseInt(paramsInShortCode[4].trim()));
			}
			catch(NumberFormatException nfe)
			{
				logger.info(userDataBean.getRequestId()+ " >> virtualCode recieved in shortcode ["+paramsInShortCode[numOfParameters]+"] "
						+ "but it must be an integer : msisdn ["+userDataBean.getMsisdn()+"] serviceType : ["+userDataBean.getServiceType()+"]");
				String filePath = TSSJavaUtil.instance().getCacheParameters().
						getUssdMenuString(UssdMenuNames.INVALID_VIRTUAL_CODE_DT+"_"+userDataBean.getLangId());
				filePath = filePath.replace("$(virtual_code)", String.valueOf(userDataBean.getVirtualCode()));
				userDataBean.setFilePath(filePath);
				return false;
			}
			catch(Exception e)
			{
				logger.info(userDataBean.getRequestId()+ " >> virtualCode recieved in shortcode ["+paramsInShortCode[numOfParameters]+"] "
						+ "but it must be an integer : msisdn ["+userDataBean.getMsisdn()+"] serviceType : ["+userDataBean.getServiceType()+"]");
				String filePath = TSSJavaUtil.instance().getCacheParameters().
						getUssdMenuString(UssdMenuNames.INVALID_VIRTUAL_CODE_DT+"_"+userDataBean.getLangId());
				filePath = filePath.replace("$(virtual_code)", String.valueOf(userDataBean.getVirtualCode()));
				userDataBean.setFilePath(filePath);
				return false;
			}
		}
		else if(ServiceTypes.BONUS_TRANSFER.equalsIgnoreCase(userDataBean.getServiceType()))
		{
			userDataBean.setFmsisdn(paramsInShortCode[3].trim());
			try
			{
				userDataBean.setVirtualCode(Integer.parseInt(paramsInShortCode[4].trim()));
			}
			catch(NumberFormatException nfe)
			{
				logger.info(userDataBean.getRequestId()+ " >> virtualCode recieved in shortcode ["+paramsInShortCode[numOfParameters]+"] "
						+ "but it must be an integer : msisdn ["+userDataBean.getMsisdn()+"] serviceType : ["+userDataBean.getServiceType()+"]");
				String filePath = TSSJavaUtil.instance().getCacheParameters().
						getUssdMenuString(UssdMenuNames.INVALID_VIRTUAL_CODE_BT+"_"+userDataBean.getLangId());
				filePath = filePath.replace("$(virtual_code)", String.valueOf(userDataBean.getVirtualCode()));
				userDataBean.setFilePath(filePath);
				return false;
			}
			catch(Exception e)
			{
				logger.info(userDataBean.getRequestId()+ " >> virtualCode recieved in shortcode ["+paramsInShortCode[numOfParameters]+"] "
						+ "but it must be an integer : msisdn ["+userDataBean.getMsisdn()+"] serviceType : ["+userDataBean.getServiceType()+"]");
				String filePath = TSSJavaUtil.instance().getCacheParameters().
						getUssdMenuString(UssdMenuNames.INVALID_VIRTUAL_CODE_BT+"_"+userDataBean.getLangId());
				filePath = filePath.replace("$(virtual_code)", String.valueOf(userDataBean.getVirtualCode()));
				userDataBean.setFilePath(filePath);
				return false;
			}
		}
		else if(ServiceTypes.TALK_TIME_TRANSFER_ONNET.equalsIgnoreCase(userDataBean.getServiceType()) ||
				ServiceTypes.TALK_TIME_TRANSFER_OFFNET.equalsIgnoreCase(userDataBean.getServiceType()))
		{
			if(ServiceTypes.TALK_TIME_TRANSFER_ONNET.equalsIgnoreCase(userDataBean.getServiceType()))
			{
				userDataBean.setNetType(ServiceTypes.ON_NET);
			}
			else
			{
				userDataBean.setNetType(ServiceTypes.OFF_NET);
			}
			userDataBean.setFmsisdn(paramsInShortCode[3].trim());
			try
			{
				userDataBean.setVolume(Integer.parseInt(paramsInShortCode[4].trim()));
			}
			catch(NumberFormatException nfe)
			{
				logger.info(userDataBean.getRequestId()+ " "+TSSJavaUtil.getLogInitial("90004")+ "volume recieved in shortcode ["+paramsInShortCode[numOfParameters]+"] "
						+ "but it must be an integer : msisdn ["+userDataBean.getMsisdn()+"] serviceType : ["+userDataBean.getServiceType()+"]");
				String filePath = TSSJavaUtil.instance().getCacheParameters().
						getUssdMenuString(UssdMenuNames.INVALID_VOLUME+"_"+userDataBean.getLangId());
				filePath = filePath.replace("$(virtual_code)", String.valueOf(userDataBean.getVirtualCode()));
				userDataBean.setFilePath(filePath);
				return false;
			}
			catch(Exception e)
			{
				logger.info(userDataBean.getRequestId()+ " >> volume recieved in shortcode ["+paramsInShortCode[numOfParameters]+"] "
						+ "but it must be an integer : msisdn ["+userDataBean.getMsisdn()+"] serviceType : ["+userDataBean.getServiceType()+"]");
				String filePath = TSSJavaUtil.instance().getCacheParameters().
						getUssdMenuString(UssdMenuNames.INVALID_VOLUME+"_"+userDataBean.getLangId());
				filePath = filePath.replace("$(virtual_code)", String.valueOf(userDataBean.getVirtualCode()));
				userDataBean.setFilePath(filePath);
				return false;
			}
		}
		
		return true;
	}

}
