package com.telemune.marketplace.manager;

import org.apache.log4j.Logger;

import com.telemune.marketplace.beans.UserDataBean;
import com.telemune.marketplace.db.DBOperations;
import com.telemune.marketplace.util.CodeStatus;

/**
 * This class is created to manage all referral related business code
 * 
 * @author Sanchit Atri 22/11/21
 */

public class ReferralManager {

	/**
	 * Used for printing logs in this class
	 */
	private static Logger logger = Logger.getLogger(ReferralManager.class);
	
	public CodeStatus submitRefrralDetails(UserDataBean userDataBean)
	{
		logger.info(" >> submit referral Details in DB using UserDataBean [" + userDataBean + "]");

		if (userDataBean == null)
			return CodeStatus.FAILURE;
		DBOperations dbOps= new DBOperations();
		
		CodeStatus=dbOps
		
		return CodeStatus.FAILURE;

	}

}
