/**
 *  Created on - 14 Feb, 2017
 * 	@author MoHit
 */
package com.telemune.marketplace.manager;

import java.io.File;
import java.security.spec.RSAOtherPrimeInfo;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import org.apache.log4j.Logger;

import com.charging.client.ThirdParty.BalanceInfoBean;
import com.charging.client.ThirdParty.Data_Object;
import com.charging.client.ThirdParty.Global;
import com.charging.client.ThirdParty.ThirdPartyRequest;
import com.charging.client.ThirdParty.TransferManager;
import com.charging.client.reqbal.BalanceRecord;
import com.charging.client.reqbal.RequestBean;
import com.google.gson.Gson;
import com.telemune.marketplace.beans.ChargingLogsBean;
import com.telemune.marketplace.beans.PackBean;
import com.telemune.marketplace.beans.PackDetailConfig;
import com.telemune.marketplace.beans.PromoPackBean;
import com.telemune.marketplace.beans.ServiceCharge;
import com.telemune.marketplace.beans.UserAccountInfoBean;
import com.telemune.marketplace.beans.UserDataBean;
import com.telemune.marketplace.beans.UserPackPurchaseBean;
import com.telemune.marketplace.beans.UserTransactionBean;
import com.telemune.marketplace.db.DBOperations;
import com.telemune.marketplace.db.DBOperations.LogsManager;
import com.telemune.marketplace.db.DBOperations.SMSSender;
import com.telemune.marketplace.expiringmap.ExpiringMap;
import com.telemune.marketplace.util.AccountIdExpiryDataComparator;
import com.telemune.marketplace.util.CodeStatus;
import com.telemune.marketplace.util.IvrMenu;
import com.telemune.marketplace.util.MPCommonDataTypes;
import com.telemune.marketplace.util.MPTags;
import com.telemune.marketplace.util.PackTypes;
import com.telemune.marketplace.util.ResponseParameters;
import com.telemune.marketplace.util.ServiceTypes;
import com.telemune.marketplace.util.TSSJavaUtil;
import com.telemune.marketplace.util.UssdMenuNames;

/**
 * This class is created to interact with charging and HLR to get sub type of
 * user, get balance purchase packs, transfer talk-time, bonus, data , Data
 * Macro Credit Service etc.
 * 
 * @author MoHit modified by SIDDHARTH
 */
public class ChargingManager {
	/**
	 * Used for printing logs in this class
	 */
	private static Logger logger = Logger.getLogger(ChargingManager.class);

	public class HLRHandler {
		/**
		 * This method is used to interact with HLR and find User's Subscriber Type
		 * means pre-paid or post-paid
		 * 
		 * @param userDataBean
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc. Also sets the result and sub type value into
		 *         user data bean object
		 */
		public CodeStatus checkSubscriberType(UserDataBean userDataBean) {
			logger.debug(userDataBean.getRequestId() + " >> Going to check subscriber type " + "of user : msisdn ["
					+ userDataBean.getMsisdn() + "]");

			String subTypeSource = TSSJavaUtil.instance().getCacheParameters().getSubTypeSource().trim();

			if ("P".equalsIgnoreCase(subTypeSource)) {
				logger.info(userDataBean.getRequestId() + " >> subTypeSource in properties file is [" + subTypeSource
						+ "] so retrurning sub type [" + subTypeSource + "] : msisdn [" + userDataBean.getMsisdn()
						+ "]");
				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setSubType("P");
				return CodeStatus.SUCCESS;
			} else if ("O".equalsIgnoreCase(subTypeSource)) {
				logger.info(userDataBean.getRequestId() + " >> subTypeSource in properties file" + " is ["
						+ subTypeSource + "] so retrurning sub type [" + subTypeSource + "] : msisdn ["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setSubType("O");
				return CodeStatus.SUCCESS;
			} else if ("H".equalsIgnoreCase(subTypeSource)) {
				logger.info(userDataBean.getRequestId() + " >> subTypeSource in properties file" + " is ["
						+ subTypeSource + "] so going to request HLR  : msisdn [" + userDataBean.getMsisdn() + "]");
				String vlr = "", scfAddress = "", busyNumber = "", noReplyNumber = "", unreachableNumber = "";
				StringBuffer msrnBuf = new StringBuffer();
				StringBuffer imsiBuf = new StringBuffer();
				StringBuffer cfuActiveStr = new StringBuffer();
				int serviceKey = 0;
				int msrnError = 0;
				Boolean isRoaming = true;
				Boolean isPrepaid = true;
				Boolean cfuActive = true;

				int subTypeReturned = -1;
				try {
					subTypeReturned = FetchMsrn.fetchmsrn(6, userDataBean.getMsisdn(), msrnBuf, vlr, imsiBuf,
							scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber,
							unreachableNumber, cfuActive, cfuActiveStr);
				} catch (Exception e) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00061")
							+ " >> Exception occurred while checking user sub type from HLR " + ": msisdn ["
							+ userDataBean.getMsisdn() + "]", e);
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setSubType("N");
					return CodeStatus.EXCEPTION_OCCURED;
				}

				if (subTypeReturned == 1) // prepaid
				{
					logger.info(userDataBean.getRequestId() + " >> Subtype checked from HLR " + "response is ["
							+ subTypeReturned + "] means P-PREPAID : msisdn [" + userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.SUCCESS);
					userDataBean.setSubType("P");
					return CodeStatus.SUCCESS;
				} else if (subTypeReturned == 2) // PostPaid
				{
					logger.info(userDataBean.getRequestId() + " >> Subtype checked from HLR " + "response is ["
							+ subTypeReturned + "] means O-POSTPAID : msisdn [" + userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.SUCCESS);
					userDataBean.setSubType("O");
					return CodeStatus.SUCCESS;
				} else {
					logger.info(userDataBean.getRequestId() + " >> Subtype checked from HLR " + "response is ["
							+ subTypeReturned + "] means Undefined subType : msisdn [" + userDataBean.getMsisdn()
							+ "]");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setSubType("N");
					return CodeStatus.FAILURE;
				}

			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00062")
						+ " >> Check Sub Type source [" + subTypeSource + "] "
						+ "defined in properties file is not valid, must be P, O or H : msisdn ["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setSubType("N");
				return CodeStatus.FAILURE;
			}

		}// ends checkSubscriberType()

	}// HLRHandler

	/**
	 * This method is used to check user's main account Balance
	 * 
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred etc. Also sets result, main account balance, pack
	 *         purchase detail, message to be shown to user into user data bean
	 *         object.
	 */
	public CodeStatus checkUserBalance(UserDataBean userDataBean) {
		logger.debug(userDataBean.getRequestId() + " >> Going to check user balance : " + "msisdn ["
				+ userDataBean.getMsisdn() + "]");

		Data_Object dataObject = new Data_Object();
		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.CHECK_BALANCE);

		try {
			long currentTimeMS = new java.util.Date().getTime();
			String transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >> Going to check user service balance with data object " + "["
					+ dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			int result = -1;
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				dataObject.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				userDataBean.setUserPoints((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00063")
						+ " >> charging testing is enable so sending success : " + "msisdn [" + userDataBean.getMsisdn()
						+ "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId() + " >> Check Balance SUCCESS final result is [" + result + "]"
						+ " and user main balance is [" + dataObject.getAcc_2000_balance() + "] : msisdn ["
						+ userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setBalance(dataObject.getAcc_2000_balance());

				
				
				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.CHECK_BALANCE_SUCCESS + "_" + userDataBean.getLangId());

				// added to show balance in float/double or integer if true then
				// float or double else Integer
				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					filePath = filePath.replace("$(balance)", String.valueOf(userDataBean.getBalance()));
				} else {
					filePath = filePath.replace("$(balance)", String.valueOf((int) userDataBean.getBalance()));
				}
				userDataBean.setFilePath(filePath);

				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.CHECK_BALANCE) + ":"
								+ result);
				
				/**
				 * set user points from balance. where account is 2623.
				 * 
				 */
				if (!TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				try {
					logger.info("checking all  balances:"+dataObject.accountDetailInfoTable);
				if(dataObject.accountDetailInfoTable.get(2623)!=null)
				{
					BalanceInfoBean balInfo=dataObject.accountDetailInfoTable.get(2623);
					userDataBean.setUserPoints(balInfo.getBalance()/100);
				}
				else
				{
					userDataBean.setUserPoints(0);
				}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				}
				String userPointsInfo = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.CHECK_POINTS_SUCCESS + "_" + userDataBean.getLangId());

				// added to show balance in float/double or integer if true then
				// float or double else Integer
				userPointsInfo = userPointsInfo.replace("$(userPoints)", String.valueOf(userDataBean.getUserPoints()));
				userDataBean.setUserPointsInfo(userPointsInfo);

				
				return CodeStatus.SUCCESS;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00064")
						+ " >> Check Balance FAILURE final result is [" + result + "]" + " and user's balance is ["
						+ dataObject.getAcc_2000_balance() + "] : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.CHECK_BALANCE_FAILURE + "_" + userDataBean.getLangId()));

				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.CHECK_BALANCE) + ":"
								+ result);

				return CodeStatus.FAILURE;
			}
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occurred while checking user service balance " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.CHECK_BALANCE_FAILURE + "_" + userDataBean.getLangId()));

			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.CHECK_BALANCE) + ":-1");

			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00065")
					+ " >> Exception occurred while checking user service balance " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.CHECK_BALANCE_FAILURE + "_" + userDataBean.getLangId()));

			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.CHECK_BALANCE) + ":-1");

			return CodeStatus.EXCEPTION_OCCURED;
		}

	}// checkUserBalance() ends

	/**
	 * Used to purchase pack for user
	 * 
	 * @param userDataBean
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred, low balance etc. Also sets result, pack purchase
	 *         detail, message to be shown to user into user data bean object.
	 */
	public CodeStatus purchasePack(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >> Going to purchase pack " + userDataBean);

		CodeStatus status = null;
		String transactionId = null;
		DBOperations dbOperations = new DBOperations();

		Data_Object dataObject = new Data_Object();

		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.PACK_PURHCASE);
		dataObject.setProductCode(TSSJavaUtil.instance().getCacheParameters().getProductCode(userDataBean.getPackId()));

		ServiceCharge serviceCharge = TSSJavaUtil.instance().getCacheParameters()
				.getServiceChargeDetails(userDataBean.getPackId());

		if (serviceCharge == null) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00066")
					+ " >> Service charge details are not found for " + "pack id [" + userDataBean.getPackId()
					+ "] : msisdn [" + userDataBean.getMsisdn() + "]");

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId()));

			return CodeStatus.EXCEPTION_OCCURED;
		}
		dataObject.setServiceAmount(serviceCharge.getVolume());

		PackBean packBean = null;
		try {
			long currentTimeMS = new java.util.Date().getTime();
			transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >> Going to purchase pack for user with charging"
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			String key = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			packBean = new PackManager().getPackDetails(key, userDataBean.getPackId());

			if (packBean == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00067") + " >> This pack ["
						+ userDataBean.getPackId() + "] is not found in cache " + "under key [" + key
						+ "] so can not purchase. This pack is not available : msisdn [" + userDataBean.getMsisdn()
						+ "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId()));

				return CodeStatus.FAILURE;
			}

			if (packBean.getPackOtherDetails().getPackActionType() == MPCommonDataTypes.VAS_SMS_ACTION_TYPE) {
				// For VAS - SMS
				if (packBean.getPackOtherDetails() == null) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00344")
							+ " >> packOtherDetails found null : msisdn [" + userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + ResponseParameters.FAILURE);
					String filePath = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.VAS_SMS_PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId());
					userDataBean.setFilePath(filePath);
					userDataBean.setPackActionType(MPCommonDataTypes.VAS_SMS_ACTION_TYPE);
					status = CodeStatus.FAILURE;
				} else {
					logger.info(userDataBean.getRequestId() + " >>  packActionId["
							+ packBean.getPackOtherDetails().getPackActionType() + "] : msisdn ["
							+ userDataBean.getMsisdn() + "]");

					// Sending SMS for VAS-SMS service
					status = dbOperations.new SMSSender().sendSMSForVAS(userDataBean, packBean);

					if (status == CodeStatus.SUCCESS) {
						userDataBean.setResult(ResponseParameters.SUCCESS);
						userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + ResponseParameters.SUCCESS);

						String filePath = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
								UssdMenuNames.VAS_SMS_PACK_PURCHASE_SUCCESS + "_" + userDataBean.getLangId());
						userDataBean.setFilePath(filePath);
						userDataBean.setPackActionType(packBean.getPackOtherDetails().getPackActionType());
						status = CodeStatus.SUCCESS;
					} else {
						userDataBean.setResult(ResponseParameters.FAILURE);
						userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + ResponseParameters.FAILURE);
						String filePath = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
								UssdMenuNames.VAS_SMS_PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId());
						userDataBean.setFilePath(filePath);
						userDataBean.setPackActionType(packBean.getPackOtherDetails().getPackActionType());
						status = CodeStatus.FAILURE;
					}
				}
			} else if (packBean.getPackOtherDetails().getPackActionType() == MPCommonDataTypes.VAS_USSD_ACTION_TYPE) {
				// For VAS - USSD
				if (packBean.getPackOtherDetails() == null) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00344")
							+ " >> packOtherDetails found null : msisdn [" + userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + ResponseParameters.FAILURE);
					String filePath = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.VAS_SMS_PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId());
					userDataBean.setFilePath(filePath);
					userDataBean.setPackActionType(MPCommonDataTypes.VAS_USSD_ACTION_TYPE);
					status = CodeStatus.FAILURE;
				} else {

					logger.info(userDataBean.getRequestId() + " >>  packActionId["
							+ packBean.getPackOtherDetails().getPackActionType() + "]  : msisdn ["
							+ userDataBean.getMsisdn() + "]");

					userDataBean.setResult(ResponseParameters.SUCCESS);
					userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + ResponseParameters.SUCCESS);
					userDataBean.setFilePath(packBean.getPackOtherDetails().getPackActionResp());
					userDataBean.setPackActionType(packBean.getPackOtherDetails().getPackActionType());
					status = CodeStatus.SUCCESS;
				}

			} else if (packBean.getPackOtherDetails()
					.getPackActionType() == MPCommonDataTypes.VAS_REDIRECTION_ACTION_TYPE) {
				// For VAS - Redirection
				if (packBean.getPackOtherDetails() == null) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00344")
							+ " >> packOtherDetails found null : msisdn [" + userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + ResponseParameters.FAILURE);
					String filePath = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.VAS_SMS_PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId());
					userDataBean.setFilePath(filePath);
					userDataBean.setPackActionType(MPCommonDataTypes.VAS_REDIRECTION_ACTION_TYPE);
					status = CodeStatus.FAILURE;
				} else {
					logger.info(userDataBean.getRequestId() + " >>  packActionId["
							+ packBean.getPackOtherDetails().getPackActionType() + "]  : msisdn ["
							+ userDataBean.getMsisdn() + "]");

					userDataBean.setResult(ResponseParameters.SUCCESS);
					userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + ResponseParameters.SUCCESS);
					userDataBean.setFilePath(packBean.getPackOtherDetails().getPackActionResp());
					userDataBean.setPackActionType(packBean.getPackOtherDetails().getPackActionType());
					status = CodeStatus.SUCCESS;
				}
			} else {
				// For Pack Purchase
				TransferManager transferManager = new TransferManager();

				int result = -1;
				if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
					// charging testing is enable so sending success
					result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
					dataObject
							.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00068")
							+ " >> charging testing is enable so sending success : " + "msisdn ["
							+ userDataBean.getMsisdn() + "]");
				} else {
					// sending request to charging
					result = transferManager.doCharging(dataObject);
				}

				if (result == 1)// success
				{
					logger.info(userDataBean.getRequestId() + " >> Pack purchased successfully final result is ["
							+ result + "]");
					userDataBean.setResult(ResponseParameters.SUCCESS);
					userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

					String filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_SUCCESS + "_" + userDataBean.getLangId());

					filePath = filePath.replace("$(pack_name)", packBean.getPackName());
					filePath = filePath.replace("$(pack_desc)", packBean.getDescription());

					userDataBean.setFilePath(filePath);

					status = CodeStatus.SUCCESS;
				} else if (result == -2)// low balance
				{
					logger.info(userDataBean.getRequestId() + " >> Pack purchase failed LOW BALANCE final result is ["
							+ result + "]");

					String filePath = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.PACK_PURCHASE_LOW_BALANCE + "_" + userDataBean.getLangId());

					filePath = filePath.replace("$(volume)", String.valueOf(serviceCharge.getVolume()));
					filePath = filePath.replace("$(available_balance)",
							String.valueOf(dataObject.getAcc_2000_balance()));
					logger.debug(userDataBean.getRequestId()
							+ "] The file path for low balance in case of pack purchase is [" + filePath
							+ "] and msisdn is [" + userDataBean.getMsisdn() + "]");

					// userDataBean.setResult(ResponseParameters.FAILURE);

					String[] filePathArr = filePath.split("##");
					if (filePathArr.length == 3) {
						filePath = filePathArr[0] + filePathArr[2];
					}
					userDataBean.setResult(ResponseParameters.LOW_BALANCE);
					userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);
					userDataBean.setFilePath(filePath);

					status = CodeStatus.LOW_BALANCE;
				} else// failure
				{
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00188")
							+ " >> Pack purchase failed final result is [" + result + "]");

					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);
					
					/*
					 * Commented By Richard on 7th November 2019
					 * 
					 * We are categorizing error strings while pack purchasing
					 * 
					 */ 
					/*userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId()));*/
					if (!TSSJavaUtil.instance().getCacheParameters().getErrorCodesMenuMap()
							.containsKey(result + "_" + userDataBean.getLangId()))
					{
						logger.info("[" + userDataBean.getRequestId() + "] Unspecified Error code received. ErrorCode["
								+ result + "] So considering it as error code 99.");
						result=99;
					}
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters().getErrorCodesMenuMap()
							.get(result + "_" + userDataBean.getLangId()));
					
					status = CodeStatus.FAILURE;
				}

			} // End of Pack Purchase Action

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occurred while purchasing pack for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00069")
					+ " >> Exception occurred while purchasing pack for user " + ": msisdn [" + userDataBean.getMsisdn()
					+ "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		}

		// Now maintaining charging logs
		ChargingLogsBean chgLogsBean = new ChargingLogsBean(userDataBean.getMsisdn(), userDataBean.getFmsisdn(),
				transactionId, userDataBean.getPackTypeId(), dataObject.getProductCode(), 0, serviceCharge.getVolume(),
				serviceCharge.getValidity(), userDataBean.getSubType(), userDataBean.getResult(),
				userDataBean.getRequestId(), userDataBean.getPackId(), serviceCharge.getVolumeType(),
				serviceCharge.getValidityType(), userDataBean.getShortCode(), userDataBean.getLangId(),
				userDataBean.getInterfaceUsed());

		if (status == CodeStatus.SUCCESS) {
			dbOperations.new LogsManager().maintainChargingLogs(chgLogsBean, true);

			// Added by AbhiShek Rana on 16 january 2018 for maintaining user
			// Modified by SIDDHARTH RAWAT 21 Feb 19
			// pack purchase.
			UserPackPurchaseBean packPurchaseBean = new UserPackPurchaseBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getPackId(), packBean.getPackName(), userDataBean.getLangId(),
					packBean.getDescription(), "NA", serviceCharge.getValidity(), serviceCharge.getValidityType(), "NA",
					packBean.getPackTypeId());

			dbOperations.new LogsManager().maintainUserPurchaseDetails(packPurchaseBean);

			// For maintaining user transaction
			UserTransactionBean transactionBean = new UserTransactionBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getFmsisdn(), userDataBean.getPackId(), packBean.getPackName(),
					userDataBean.getLangId(), "NA", serviceCharge.getValidity(), serviceCharge.getValidityType(),
					serviceCharge.getVolume(), "PP",
					TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.MESSAGE_HEADER_PACK_PURCHASE + "_" + userDataBean.getLangId()),
					userDataBean.getShortCode(), userDataBean.getLangId(), userDataBean.getInterfaceUsed(), "NA");
			dbOperations.new LogsManager().maintainUserTransactionCDRS(transactionBean);
		} else
			dbOperations.new LogsManager().maintainChargingLogs(chgLogsBean, false);

		return status;

	}// purchasePack() ends

	/**
	 * Used to purchase promotional pack for user
	 * 
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred, low balance etc. Also sets result, pack purchase
	 *         detail, message to be shown to user into user data bean object.
	 */
	public CodeStatus purchasePromotionPack(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >> Going to purchase Promotion pack " + userDataBean);

		CodeStatus status = null;
		String transactionId = null;
		DBOperations dbOperations = new DBOperations();

		Data_Object dataObject = new Data_Object();

		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.PACK_PURHCASE);
		int packVolume = 0;
		String packVolumeType = "";
		int packValidity = 0;
		String packValidityType = "";
		String packName = "";
		String packDescription = "";

		try {
			HashMap<String, PromoPackBean> promoPackDetailsMap = TSSJavaUtil.instance().getCacheParameters()
					.getPromoPackDetailsMap();

			if (promoPackDetailsMap != null && !promoPackDetailsMap.isEmpty()) {

				dataObject.setProductCode(userDataBean.getProductCode());
				String promoPackKey = userDataBean.getProductCode() + MPCommonDataTypes.UNDERSCORE_SEPARATOR
						+ userDataBean.getLangId() + MPCommonDataTypes.UNDERSCORE_SEPARATOR + userDataBean.getSubType();

				PromoPackBean promoPackBean = promoPackDetailsMap.get(promoPackKey);
				logger.info(userDataBean.getRequestId() + " >> promoPackKey[" + promoPackKey + "] promoPackBean : "
						+ promoPackBean);
				if (promoPackBean != null) {
					packVolume = promoPackBean.getPromotionPackOtherDetails().getVolume();
					packVolumeType = promoPackBean.getPromotionPackOtherDetails().getVolumeType();
					packValidity = promoPackBean.getPromotionPackOtherDetails().getValidity();
					packValidityType = promoPackBean.getPromotionPackOtherDetails().getValidityType();
					dataObject.setServiceAmount(packVolume);
					userDataBean.setPackId(promoPackBean.getPackId());
					packName = promoPackBean.getPromotionPackOtherDetails().getPackName();
					packDescription = promoPackBean.getPromotionPackOtherDetails().getPackDescription();
				} else {
					logger.error(userDataBean.getRequestId() + " >> No Promotional packs promoPackBean[" + promoPackBean
							+ "] found for the requested promoPackKey [" + promoPackKey + "]. MSISDN["
							+ userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + ResponseParameters.FAILURE);
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId()));
					return CodeStatus.EXCEPTION_OCCURED;
				}
			} else {
				logger.error(userDataBean.getRequestId()
						+ " >> No Promotinol Packs found in the systme. Please check the sytem configuration of Promotional Packs. MSISDN["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId()));
				return CodeStatus.EXCEPTION_OCCURED;
			}

			long currentTimeMS = new java.util.Date().getTime();
			transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >> Going to purchase pack for user with charging"
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			// For Pack Purchase
			TransferManager transferManager = new TransferManager();

			int result = -1;
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				dataObject.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00068")
						+ " >> charging testing is enable so sending success : " + "msisdn [" + userDataBean.getMsisdn()
						+ "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId() + " >> Promotion Pack purchased successfully final result is ["
						+ result + "]");
				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_SUCCESS + "_" + userDataBean.getLangId());

				filePath = filePath.replace("$(pack_name)", packName);
				filePath = filePath.replace("$(pack_desc)", packDescription);

				userDataBean.setFilePath(filePath);

				status = CodeStatus.SUCCESS;
			} else if (result == -2)// low balance
			{
				logger.info(userDataBean.getRequestId() + " >> Pack purchase failed LOW BALANCE final result is ["
						+ result + "]");

				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.POD_PACK_PURCHASE_LOW_BALANCE + "_" + userDataBean.getLangId());

				filePath = filePath
						.replace(MPCommonDataTypes.TOKEN_BALANCE, String.valueOf((int) userDataBean.getBalance()))
						.replace(MPCommonDataTypes.TOKEN_PACK_NAME, packName)
						.replace(MPCommonDataTypes.TOKEN_PACK_DESC, packDescription);

				logger.debug(
						userDataBean.getRequestId() + "] The file path for low balance in case of pack purchase is ["
								+ filePath + "] and msisdn is [" + userDataBean.getMsisdn() + "]");

				// userDataBean.setResult(ResponseParameters.FAILURE);

				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);
				userDataBean.setFilePath(filePath);

				status = CodeStatus.LOW_BALANCE;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00188")
						+ " >> Promo Pack purchase failed final result is [" + result + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId()));

				status = CodeStatus.FAILURE;
			}

			// End of Promotional Pack Purchase Action

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occurred while purchasing promotional pack for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + ResponseParameters.FAILURE);

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00069")
					+ " >> Exception occurred while purchasing promotional pack for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + ResponseParameters.FAILURE);

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.PACK_PURCHASE_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		}

		// Now maintaining charging logs
		ChargingLogsBean chgLogsBean = new ChargingLogsBean(userDataBean.getMsisdn(), userDataBean.getFmsisdn(),
				transactionId, userDataBean.getPackTypeId(), dataObject.getProductCode(), 0, packVolume, packValidity,
				userDataBean.getSubType(), userDataBean.getResult(), userDataBean.getRequestId(),
				userDataBean.getPackId(), packVolumeType, packValidityType, userDataBean.getShortCode(),
				userDataBean.getLangId(), userDataBean.getInterfaceUsed());

		if (status == CodeStatus.SUCCESS) {
			dbOperations.new LogsManager().maintainChargingLogs(chgLogsBean, true);
			UserPackPurchaseBean packPurchaseBean = new UserPackPurchaseBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getPackId(), packName, userDataBean.getLangId(), packDescription, "NA", packValidity,
					packValidityType, "NA", userDataBean.getPackTypeId());

			dbOperations.new LogsManager().maintainUserPurchaseDetails(packPurchaseBean);

			// For maintaining user transaction
			UserTransactionBean transactionBean = new UserTransactionBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getFmsisdn(), userDataBean.getPackId(), packName, userDataBean.getLangId(), "NA",
					packValidity, packValidityType, packVolume, "PP",
					TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.MESSAGE_HEADER_PACK_PURCHASE + "_" + userDataBean.getLangId()),
					userDataBean.getShortCode(), userDataBean.getLangId(), userDataBean.getInterfaceUsed(), "NA");
			dbOperations.new LogsManager().maintainUserTransactionCDRS(transactionBean);
		} else
			dbOperations.new LogsManager().maintainChargingLogs(chgLogsBean, false);

		return status;

	}// purchasePromotionPack() ends

	
	/**
	 * Used to purchase promotional packs for IVR
	 * 
	 * @author richard
	 * 
	 * @param userDataBean
	 * @return
	 */
	public CodeStatus purchasePromotionPackForIVR(UserDataBean userDataBean) {
		
		
		logger.info(userDataBean.getRequestId() + " >> Going to purchase Promotion pack " + userDataBean);

		CodeStatus status = null;
		String transactionId = null;
		DBOperations dbOperations = new DBOperations();

		Data_Object dataObject = new Data_Object();

		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.PACK_PURHCASE);
		int packVolume = 0;
		String packVolumeType = "";
		int packValidity = 0;
		String ivr_base_file_path = "";
		String packValidityType = "";
		String packName = "";
		String packDescription = "";

		try {
			
			ivr_base_file_path = TSSJavaUtil.instance().getCacheParameters().getCustomerCareIvrPromptBasePath();
			if (ivr_base_file_path.equalsIgnoreCase("NA") || ivr_base_file_path.equalsIgnoreCase("")
					|| ivr_base_file_path == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00320")
						+ " >> (IVR)  Base file path is not found for MSISDN[" + userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}
			
			HashMap<String, PromoPackBean> promoPackDetailsMap = TSSJavaUtil.instance().getCacheParameters()
					.getPromoPackDetailsMap();

			if (promoPackDetailsMap != null && !promoPackDetailsMap.isEmpty()) {

				dataObject.setProductCode(userDataBean.getProductCode());
				String promoPackKey = userDataBean.getProductCode() + MPCommonDataTypes.UNDERSCORE_SEPARATOR
						+ userDataBean.getLangId() + MPCommonDataTypes.UNDERSCORE_SEPARATOR + userDataBean.getSubType();

				PromoPackBean promoPackBean = promoPackDetailsMap.get(promoPackKey);
				logger.info(userDataBean.getRequestId() + " >> promoPackKey[" + promoPackKey + "] promoPackBean : "
						+ promoPackBean);
				if (promoPackBean != null) {
					packVolume = promoPackBean.getPromotionPackOtherDetails().getVolume();
					packVolumeType = promoPackBean.getPromotionPackOtherDetails().getVolumeType();
					packValidity = promoPackBean.getPromotionPackOtherDetails().getValidity();
					packValidityType = promoPackBean.getPromotionPackOtherDetails().getValidityType();
					dataObject.setServiceAmount(packVolume);
					userDataBean.setPackId(promoPackBean.getPackId());
					packName = promoPackBean.getPromotionPackOtherDetails().getPackName();
					packDescription = promoPackBean.getPromotionPackOtherDetails().getPackDescription();
				} else {
					logger.error(userDataBean.getRequestId() + " >> No Promotional packs promoPackBean[" + promoPackBean
							+ "] found for the requested promoPackKey [" + promoPackKey + "]. MSISDN["
							+ userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + ResponseParameters.FAILURE);
					String filePath = ivr_base_file_path + userDataBean.getLangId() + File.separator
							+ IvrMenu.PACK_PURCHASE_FAILURE_WAV_IVR;
					userDataBean.setFilePath(filePath);
					return CodeStatus.EXCEPTION_OCCURED;
				}
			} else {
				logger.error(userDataBean.getRequestId()
						+ " >> No Promotinol Packs found in the systme. Please check the sytem configuration of Promotional Packs. MSISDN["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");
				String filePath = ivr_base_file_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.PACK_PURCHASE_FAILURE_WAV_IVR;
				userDataBean.setFilePath(filePath);
				return CodeStatus.EXCEPTION_OCCURED;
			}

			long currentTimeMS = new java.util.Date().getTime();
			transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >> Going to purchase pack for user with charging"
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			// For Pack Purchase
			TransferManager transferManager = new TransferManager();

			int result = -1;
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				dataObject.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00068")
						+ " >> charging testing is enable so sending success : " + "msisdn [" + userDataBean.getMsisdn()
						+ "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId() + " >> Promotion Pack purchased successfully final result is ["
						+ result + "]");
				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				String filePath = ivr_base_file_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.PACK_PURCHASE_SUCCESS_WAV_IVR;
				userDataBean.setFilePath(filePath);
				status = CodeStatus.SUCCESS;
				
			} else if (result == -2)// low balance
			{
				logger.info(userDataBean.getRequestId() + " >> Pack purchase failed LOW BALANCE final result is ["
						+ result + "]");

				String filePath = ivr_base_file_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.PACK_PURCHASE_LOW_BALANCE_IVR;
				

				logger.debug(
						userDataBean.getRequestId() + "] The file path for low balance in case of pack purchase is ["
								+ filePath + "] and msisdn is [" + userDataBean.getMsisdn() + "]");

				// userDataBean.setResult(ResponseParameters.FAILURE);

				userDataBean.setFilePath(filePath);
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				status = CodeStatus.LOW_BALANCE;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00188")
						+ " >> Promo Pack purchase failed final result is [" + result + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);
				String filePath = ivr_base_file_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.PACK_PURCHASE_FAILURE_WAV_IVR;
				userDataBean.setFilePath(filePath);
				status = CodeStatus.FAILURE;
			}

			// End of Promotional Pack Purchase Action

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occurred while purchasing pack for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);

			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00069")
					+ " >> Exception occurred while purchasing pack for user " + ": msisdn [" + userDataBean.getMsisdn()
					+ "]", e);

			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);

			status = CodeStatus.EXCEPTION_OCCURED;
		}

		// Now maintaining charging logs
		ChargingLogsBean chgLogsBean = new ChargingLogsBean(userDataBean.getMsisdn(), userDataBean.getFmsisdn(),
				transactionId, userDataBean.getPackTypeId(), dataObject.getProductCode(), 0, packVolume, packValidity,
				userDataBean.getSubType(), userDataBean.getResult(), userDataBean.getRequestId(),
				userDataBean.getPackId(), packVolumeType, packValidityType, userDataBean.getShortCode(),
				userDataBean.getLangId(), userDataBean.getInterfaceUsed());

		if (status == CodeStatus.SUCCESS) {
			dbOperations.new LogsManager().maintainChargingLogs(chgLogsBean, true);
			UserPackPurchaseBean packPurchaseBean = new UserPackPurchaseBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getPackId(), packName, userDataBean.getLangId(), packDescription, "NA", packValidity,
					packValidityType, "NA", userDataBean.getPackTypeId());

			dbOperations.new LogsManager().maintainUserPurchaseDetails(packPurchaseBean);

			// For maintaining user transaction
			UserTransactionBean transactionBean = new UserTransactionBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getFmsisdn(), userDataBean.getPackId(), packName, userDataBean.getLangId(), "NA",
					packValidity, packValidityType, packVolume, "PP",
					TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.MESSAGE_HEADER_PACK_PURCHASE + "_" + userDataBean.getLangId()),
					userDataBean.getShortCode(), userDataBean.getLangId(), userDataBean.getInterfaceUsed(), "NA");
			dbOperations.new LogsManager().maintainUserTransactionCDRS(transactionBean);
		} else
			dbOperations.new LogsManager().maintainChargingLogs(chgLogsBean, false);

		return status;

	}
	
	
	
	/**
	 * Used to transfer talk time
	 * 
	 * @param userDataBean
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred, low balance etc. Also sets result, pack purchase
	 *         detail, message to be shown to user into user data bean object.
	 */
	public CodeStatus talkTimeTransfer(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >> Going to transfer talk time " + userDataBean);

		CodeStatus status = null;
		String transactionId = null;
		Data_Object dataObject = new Data_Object();
		int packTypeId = -1;
		double serviceCharge = 0.0;
		int validityDays = -1;

		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.TALK_TIME_TRANSFER);
		dataObject.setAccType(userDataBean.getNetType());
		dataObject.setCurrAcctChgAmt(userDataBean.getVolume());
		dataObject.setFmsisdn(userDataBean.getFmsisdn());

		packTypeId = TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER);
		if (ServiceTypes.ON_NET.equals(userDataBean.getNetType())) {
			serviceCharge = TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOnNet();
		} else if (ServiceTypes.OFF_NET.equals(userDataBean.getNetType())) {
			serviceCharge = TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOffNet();
		}
		/*
		 * serviceCharge =
		 * TSSJavaUtil.instance().getCacheParameters().getTttServiceCharge();
		 */
		dataObject.setServiceAmount(serviceCharge);

		try {
			// setting validity
			validityDays = TSSJavaUtil.instance().getCacheParameters().getTransferValidityDays(packTypeId,
					userDataBean.getVolume());
			if (validityDays <= 0) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00070")
						+ " >> no validity days configuration found for " + "pack type [" + packTypeId
						+ "] and volume [" + userDataBean.getVolume() + "] so returning failure : " + "msisdn ["
						+ userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER)
								+ ":-1");

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.TTT_FAILURE + "_" + userDataBean.getLangId()));

				return CodeStatus.FAILURE;
			}

			dataObject.setNb_day(validityDays);

			long currentTimeMS = new java.util.Date().getTime();
			transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >> Going to transfer with charging for user with charging"
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			int result = -1;
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				dataObject.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				dataObject.setVolumeBalance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00071")
						+ " >> charging testing is enable so using success : " + "msisdn [" + userDataBean.getMsisdn()
						+ "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId() + " >> Talk time transfered successfully final result is ["
						+ result + "]");

				userDataBean.setResult(ResponseParameters.SUCCESS);

				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER) + ":"
								+ result);

				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.TTT_SUCCESS + "_" + userDataBean.getLangId());

				filePath = filePath.replace("$(volume)", String.valueOf(userDataBean.getVolume()));
				filePath = filePath.replace("$(fmsisdn)", String.valueOf(userDataBean.getFmsisdn()));

				// if true then show service charge value in float or double
				// else in Integer
				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					filePath = filePath.replace("$(service_charge)", String.valueOf(serviceCharge));
				} else {
					filePath = filePath.replace("$(service_charge)", String.valueOf((int) serviceCharge));
				}

				userDataBean.setFilePath(filePath);

				status = CodeStatus.SUCCESS;
			} else if (result == -2)// low balance
			{
				logger.info(userDataBean.getRequestId() + " >> Talk time transfer FAILED LOW BALANCE final result is ["
						+ result + "]");

				// userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);

				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER) + ":"
								+ result);

				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.TTT_LOW_BALANCE + "_" + userDataBean.getLangId());

				// if true then show service charge value in float or double
				// else in Integer
				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					filePath = filePath.replace("$(service_charge)", String.valueOf(serviceCharge));
				} else {
					filePath = filePath.replace("$(service_charge)", String.valueOf((int) serviceCharge));
				}

				filePath = filePath.replace("$(available_balance)", String.valueOf(dataObject.getAcc_2000_balance()));
				logger.debug(userDataBean.getRequestId()
						+ "] The file path for low balance in case of talktime transfer is [" + filePath
						+ "] and msisdn :[" + userDataBean.getMsisdn() + "]");
				userDataBean.setFilePath(filePath);

				status = CodeStatus.LOW_BALANCE;
			} else if (result == -3)// low talk time transfer balance
			{
				logger.info(userDataBean.getRequestId()
						+ " >> Tallktime transfer FAILED user has LOW TTT BALANCE final result is " + "[" + result
						+ "] : msisdn [" + userDataBean.getMsisdn() + "]");

				// userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setResult(ResponseParameters.LOW_TRANSFER_BALANCE);
				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER) + ":"
								+ result);

				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.TTT_LOW_VOLUME_BALANCE + "_" + userDataBean.getLangId());

				filePath = filePath.replace("$(volume)", String.valueOf(userDataBean.getVolume()));
				filePath = filePath.replace("$(available_balance)", String.valueOf(dataObject.getVolumeBalance()));
				logger.debug(userDataBean.getRequestId()
						+ "] The file path for low volume balance in case of talktime transfer is [" + filePath
						+ "] and msisdn :[" + userDataBean.getMsisdn() + "]");
				userDataBean.setFilePath(filePath);

				status = CodeStatus.LOW_TTT_BALANCE;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00072")
						+ " >> Talk time transfer FAILED final result is [" + result + "]");

				if (result == -63) {
					userDataBean.setResult(ResponseParameters.TTT_FAILURE_WITH_CREDIT_TACF_MACF);
				} else if (result == -64) {
					userDataBean.setResult(ResponseParameters.TTT_FAILURE_WITH_CREDIT_TACS_MACF);
				} else if (result == -65) {
					userDataBean.setResult(ResponseParameters.TTT_FAILURE_WITH_CREDIT_TACF_MACS);
				} else if (result == -66) {
					userDataBean.setResult(ResponseParameters.TTT_FAILURE_WITH_CREDIT_TACS_MACS);
				} else {
					userDataBean.setResult(ResponseParameters.FAILURE);
				}

				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER) + ":"
								+ result);

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.TTT_FAILURE + "_" + userDataBean.getLangId()));

				status = CodeStatus.FAILURE;
			}

		} catch (NullPointerException e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occurred while talk time transfer for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);

			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER) + ":-1");

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.TTT_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00073")
					+ " >> Exception occurred while talk time transfer for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);

			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER) + ":-1");

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.TTT_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		}

		DBOperations dbOps = new DBOperations();

		// Now maintaining charging logs
		ChargingLogsBean chgLogsBean = new ChargingLogsBean(userDataBean.getMsisdn(), userDataBean.getFmsisdn(),
				transactionId, packTypeId, TSSJavaUtil.instance().getCacheParameters().getTttProductCode(),
				serviceCharge, userDataBean.getVolume(), validityDays, userDataBean.getSubType(),
				userDataBean.getResult(), userDataBean.getRequestId(), -1, "NA", "DY", userDataBean.getShortCode(),
				userDataBean.getLangId(), userDataBean.getInterfaceUsed());

		if (status == CodeStatus.SUCCESS) {
			dbOps.new SMSSender().sendSMSForTTTB(userDataBean, validityDays);
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, true);

			// Added by AbhiShek Rana on 16 january 2018 for maintaining user
			// Transaction.
			UserTransactionBean transactionBean = new UserTransactionBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getFmsisdn(), packTypeId, "NA", userDataBean.getLangId(), "NA", validityDays, "DY",
					userDataBean.getVolume(), "TT",
					TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.MESSAGE_HEADER_TALKTIME_TRANSFER + "_" + userDataBean.getLangId()),
					userDataBean.getShortCode(), userDataBean.getLangId(), userDataBean.getInterfaceUsed(), "NA");
			dbOps.new LogsManager().maintainUserTransactionCDRS(transactionBean);

		} else
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, false);

		return status;

	}// talkTimeTransfer() ends

	/**
	 * Used to transfer bonus (gift) from A party to B party
	 * 
	 * @param userDataBean
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred, low balance etc. Also sets result, pack purchase
	 *         detail, message to be shown to user into user data bean object.
	 */
	public CodeStatus bonusTransfer(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >> Going to transfer bonus " + userDataBean);

		CodeStatus status = null;
		String transactionId = null;
		Data_Object dataObject = new Data_Object();
		ServiceCharge serviceChargeDetails = null;
		PackBean packBean = null;

		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.BONUS_TRANSFER);
		dataObject.setFmsisdn(userDataBean.getFmsisdn());
		dataObject.setAccType(ServiceTypes.GIFT);
		dataObject.setProductCode(TSSJavaUtil.instance().getCacheParameters().getProductCode(userDataBean.getPackId()));

		try {
			serviceChargeDetails = TSSJavaUtil.instance().getCacheParameters()
					.getServiceChargeDetails(userDataBean.getPackId());

			if (serviceChargeDetails == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00074")
						+ " >> Service charge details are not found for " + "pack id [" + userDataBean.getPackId()
						+ "] so returning failure : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.BONUS_FAILURE + "_" + userDataBean.getLangId()));

				return CodeStatus.FAILURE;
			}

			String key = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			packBean = new PackManager().getPackDetails(key, userDataBean.getPackId());

			if (packBean == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00075")
						+ " >> This bonus pack [" + userDataBean.getPackId() + "] is not found in cache "
						+ "under key [" + key + "] so can not be avialed to user. This pack is not available : msisdn ["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.BONUS_FAILURE + "_" + userDataBean.getLangId()));

				return CodeStatus.FAILURE;
			}

			dataObject.setNb_day(serviceChargeDetails.getValidity());
			dataObject.setCurrAcctChgAmt(serviceChargeDetails.getVolume());
			dataObject.setServiceAmount(serviceChargeDetails.getServiceCharge());

			long currentTimeMS = new java.util.Date().getTime();
			transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >> Going to transfer bonus for user with charging"
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			int result = -1;
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				dataObject.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00078")
						+ " >> charging testing is enable so using success : " + "msisdn [" + userDataBean.getMsisdn()
						+ "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId() + " >> Bonus is transfered successfully final result is ["
						+ result + "]");

				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.GIFT_BONUS_SUCCESS + "_" + userDataBean.getLangId());

				filePath = filePath.replace("$(pack_name)", packBean.getPackName());
				filePath = filePath.replace("$(validity_days)", String.valueOf(serviceChargeDetails.getValidity()));

				String validityTypeStr = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
						serviceChargeDetails.getValidityType().toUpperCase() + "_" + userDataBean.getLangId());
				filePath = filePath.replace("$(validity_type)", validityTypeStr);

				filePath = filePath.replace("$(fmsisdn)", String.valueOf(userDataBean.getFmsisdn()));

				// if true then show service charge value in float or double
				// else in Integer
				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					filePath = filePath.replace("$(service_charge)",
							String.valueOf(serviceChargeDetails.getServiceCharge() + serviceChargeDetails.getVolume()));
				} else {
					filePath = filePath.replace("$(service_charge)", String
							.valueOf((int) serviceChargeDetails.getServiceCharge() + serviceChargeDetails.getVolume()));
				}

				userDataBean.setFilePath(filePath);

				status = CodeStatus.SUCCESS;
			} else if (result == -2)// low balance
			{
				logger.info(userDataBean.getRequestId() + " >> Bonus transfer FAILED LOW BALANCE final result is ["
						+ result + "]");

				// userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.BONUS_LOW_BALANCE + "_" + userDataBean.getLangId());

				// if true then show service charge value in float or double
				// else in Integer
				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					filePath = filePath.replace("$(service_charge)",
							String.valueOf(serviceChargeDetails.getServiceCharge()) + serviceChargeDetails.getVolume());
				} else {
					filePath = filePath.replace("$(service_charge)", String.valueOf(
							(int) (serviceChargeDetails.getServiceCharge() + serviceChargeDetails.getVolume())));
				}
				filePath = filePath.replace("$(available_balance)", String.valueOf(dataObject.getAcc_2000_balance()));

				logger.debug(
						userDataBean.getRequestId() + "] The file path for low balance in case of bonus transfer is ["
								+ filePath + "] and msisdn :[" + userDataBean.getMsisdn() + "]");

				userDataBean.setFilePath(filePath);
				/*
				 * userDataBean.setFilePath(TSSJavaUtil.instance(). getCacheParameters().
				 * getUssdMenuString(UssdMenuNames.BONUS_LOW_BALANCE+"_"+
				 * userDataBean.getLangId()));
				 */

				status = CodeStatus.LOW_BALANCE;
			} else if (result == -3)// low bonus volume balance
			{
				logger.info(userDataBean.getRequestId()
						+ " >> Bonus transfer FAILED LOW VOLUME BALANCE final result is [" + result + "]");

				// userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.BONUS_LOW_VOLUME_BALANCE + "_" + userDataBean.getLangId());

				// if true then show service charge value in float or double
				// else in Integer
				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					filePath = filePath.replace("$(service_charge)",
							String.valueOf(serviceChargeDetails.getServiceCharge()) + serviceChargeDetails.getVolume());
				} else {
					filePath = filePath.replace("$(service_charge)", String.valueOf(
							(int) (serviceChargeDetails.getServiceCharge() + serviceChargeDetails.getVolume())));
				}
				filePath = filePath.replace("$(available_balance)", String.valueOf(dataObject.getAcc_2000_balance()));

				logger.debug(userDataBean.getRequestId()
						+ "] The file path for low volume balance in case of bonus transfer is [" + filePath
						+ "] and msisdn :[" + userDataBean.getMsisdn() + "]");

				userDataBean.setFilePath(filePath);
				/*
				 * userDataBean.setFilePath(TSSJavaUtil.instance(). getCacheParameters().
				 * getUssdMenuString(UssdMenuNames.BONUS_LOW_VOLUME_BALANCE+"_"+
				 * userDataBean.getLangId()));
				 */

				status = CodeStatus.LOW_BALANCE;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00076")
						+ " >> Bonus transfer FAILED final result is [" + result + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.BONUS_FAILURE + "_" + userDataBean.getLangId()));

				status = CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occurred while bonus transfer for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.BONUS_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00077")
					+ " >> Exception occurred while bonus transfer for user " + ": msisdn [" + userDataBean.getMsisdn()
					+ "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.BONUS_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		}

		// Now maintaining charging logs
		ChargingLogsBean chgLogsBean = new ChargingLogsBean(userDataBean.getMsisdn(), userDataBean.getFmsisdn(),
				transactionId, userDataBean.getPackTypeId(), serviceChargeDetails.getProductCode(),
				serviceChargeDetails.getServiceCharge(), serviceChargeDetails.getVolume(),
				serviceChargeDetails.getValidity(), userDataBean.getSubType(), userDataBean.getResult(),
				userDataBean.getRequestId(), userDataBean.getPackId(), serviceChargeDetails.getVolumeType(),
				serviceChargeDetails.getValidityType(), userDataBean.getShortCode(), userDataBean.getLangId(),
				userDataBean.getInterfaceUsed());

		DBOperations dbOps = new DBOperations();

		if (status == CodeStatus.SUCCESS) {
			userDataBean.setVolume(serviceChargeDetails.getVolume());
			dbOps.new SMSSender().sendSMSToBForBonus(userDataBean, packBean, serviceChargeDetails);
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, true);

			// Added by AbhiShek Rana on 16 january 2018 for maintaining user
			// Transaction.
			UserTransactionBean transactionBean = new UserTransactionBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getFmsisdn(), packBean.getPackId(), packBean.getPackName(), userDataBean.getLangId(),
					"NA", serviceChargeDetails.getValidity(), serviceChargeDetails.getValidityType(),
					serviceChargeDetails.getVolume(), "BT",
					TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.MESSAGE_HEADER_BONUS_TRANSFER + "_" + userDataBean.getLangId()),
					userDataBean.getShortCode(), userDataBean.getLangId(), userDataBean.getInterfaceUsed(), "NA");
			dbOps.new LogsManager().maintainUserTransactionCDRS(transactionBean);

		} else
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, false);

		return status;

	}// bonusTransfer() ends

	/**
	 * Used to transfer data from A party to B party
	 * 
	 * @param userDataBean
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred, low balance etc. Also sets result, pack purchase
	 *         detail, message to be shown to user into user data bean object.
	 */
	public CodeStatus dataTransfer(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >> Going to transfer data " + userDataBean);
		int result = -1;
		CodeStatus status = null;
		String transactionId = null;
		Data_Object dataObject = new Data_Object();
		ServiceCharge serviceChargeDetails = null;
		PackBean packBean = null;

		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.DATA_TRANSFER);
		dataObject.setFmsisdn(userDataBean.getFmsisdn());
		dataObject.setAccType(ServiceTypes.DATA);
		dataObject.setProductCode(TSSJavaUtil.instance().getCacheParameters().getProductCode(userDataBean.getPackId()));

		try {
			serviceChargeDetails = TSSJavaUtil.instance().getCacheParameters()
					.getServiceChargeDetails(userDataBean.getPackId());

			if (serviceChargeDetails == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00152")
						+ "  >> Service charge details are not found for " + "pack id [" + userDataBean.getPackId()
						+ "] so returning failure : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DATA_TRANSFER_FAILURE + "_" + userDataBean.getLangId()));

				return CodeStatus.FAILURE;
			}

			String key = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			packBean = new PackManager().getPackDetails(key, userDataBean.getPackId());

			if (packBean == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00153")
						+ "  >> This data pack [" + userDataBean.getPackId() + "] is not found in cache "
						+ "under key [" + key + "] so can not be avialed to user. This pack is not available : msisdn ["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.BONUS_FAILURE + "_" + userDataBean.getLangId()));

				return CodeStatus.FAILURE;
			}

			dataObject.setNb_day(serviceChargeDetails.getValidity());
			if ("TB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
				dataObject.setCurrAcctChgAmt((long) serviceChargeDetails.getVolume() * 1024 * 1024 * 1024 * 1024);
			} else if ("GB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
				dataObject.setCurrAcctChgAmt((long) serviceChargeDetails.getVolume() * 1024 * 1024 * 1024);
			} else if ("MB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
				dataObject.setCurrAcctChgAmt((long) serviceChargeDetails.getVolume() * 1024 * 1024);
			} else if ("KB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
				dataObject.setCurrAcctChgAmt((long) serviceChargeDetails.getVolume() * 1024);
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00280")
						+ " >> Data transfer FAILED due to " + "unsupported volume type ["
						+ serviceChargeDetails.getVolumeType() + "] and the final result is [" + result + "]");

				throw new Exception("unsupported volume type");
			}
			logger.debug("The volume passed to charging jar in case of  [" + serviceChargeDetails.getVolumeType()
					+ "] is " + dataObject.getCurrAcctChgAmt());

			dataObject.setServiceAmount(serviceChargeDetails.getServiceCharge());

			long currentTimeMS = new java.util.Date().getTime();
			transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >> Going to transfer data for user with charging"
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				dataObject.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				dataObject.setVolumeBalance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00154")
						+ "  >>charging testing is enable so using success : " + "msisdn [" + userDataBean.getMsisdn()
						+ "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId() + " >> Data is transfered successfully final result is ["
						+ result + "]");

				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DATA_TRANSFER_SUCCESS + "_" + userDataBean.getLangId());

				filePath = filePath.replace("$(pack_name)", packBean.getPackName());
				filePath = filePath.replace("$(validity_days)", String.valueOf(serviceChargeDetails.getValidity()));

				String validityTypeStr = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
						serviceChargeDetails.getValidityType().toUpperCase() + "_" + userDataBean.getLangId());
				filePath = filePath.replace("$(validity_type)", validityTypeStr);

				filePath = filePath.replace("$(fmsisdn)", String.valueOf(userDataBean.getFmsisdn()));

				// if true then show service charge value in float or double
				// else in Integer
				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					filePath = filePath.replace("$(service_charge)",
							String.valueOf(serviceChargeDetails.getServiceCharge()));
				} else {
					filePath = filePath.replace("$(service_charge)",
							String.valueOf((int) serviceChargeDetails.getServiceCharge()));
				}

				userDataBean.setFilePath(filePath);

				status = CodeStatus.SUCCESS;
			} else if (result == -2)// low balance
			{
				logger.info(userDataBean.getRequestId() + " >> Data transfer FAILED LOW BALANCE final result is ["
						+ result + "]");

				// userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DT_LOW_BALANCE + "_" + userDataBean.getLangId());

				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					filePath = filePath.replace("$(service_charge)",
							String.valueOf(serviceChargeDetails.getServiceCharge()));
				} else {
					filePath = filePath.replace("$(service_charge)",
							String.valueOf((int) serviceChargeDetails.getServiceCharge()));
				}

				filePath = filePath.replace("$(available_balance)", String.valueOf(dataObject.getAcc_2000_balance()));

				logger.debug(
						userDataBean.getRequestId() + "] The file path for low balance in case of data transfer is ["
								+ filePath + "] and msisdn :[" + userDataBean.getMsisdn() + "]");

				userDataBean.setFilePath(filePath);

				/*
				 * userDataBean.setFilePath(TSSJavaUtil.instance(). getCacheParameters().
				 * getUssdMenuString(UssdMenuNames.DT_LOW_BALANCE+"_"+
				 * userDataBean.getLangId()));
				 */

				status = CodeStatus.LOW_BALANCE;
			} else if (result == -3)// low bonus volume balance
			{
				logger.info(userDataBean.getRequestId()
						+ " >> Data transfer FAILED LOW VOLUME BALANCE final result is [" + result + "]");

				// userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DT_LOW_VOLUME_BALANCE + "_" + userDataBean.getLangId());

				if ("TB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
					dataObject.setVolumeBalance((long) dataObject.getVolumeBalance() / (1024 * 1024 * 1024 * 1024));
				} else if ("GB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
					dataObject.setVolumeBalance((long) dataObject.getVolumeBalance() / (1024 * 1024 * 1024));
				} else if ("MB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
					dataObject.setVolumeBalance((long) dataObject.getVolumeBalance() / (1024 * 1024));
				} else if ("KB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
					dataObject.setVolumeBalance((long) dataObject.getVolumeBalance() / 1024);
				}
				filePath = filePath.replace("$(volume)", String.valueOf(serviceChargeDetails.getVolume()));
				filePath = filePath.replace("$(available_balance)", String.valueOf(dataObject.getVolumeBalance()));

				logger.debug(userDataBean.getRequestId()
						+ "] The file path for low volume balance in case of data transfer is [" + filePath
						+ "] and msisdn :[" + userDataBean.getMsisdn() + "]");

				userDataBean.setFilePath(filePath);
				/*
				 * userDataBean.setFilePath(TSSJavaUtil.instance(). getCacheParameters().
				 * getUssdMenuString(UssdMenuNames.DT_LOW_VOLUME_BALANCE+"_"+
				 * userDataBean.getLangId()));
				 */

				status = CodeStatus.LOW_BALANCE;
			}

			else if (result == -9)// Not eligible for data transfer.
			{
				logger.info(userDataBean.getRequestId() + " >> User is not eligible for data transfer final result is ["
						+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.NOT_ELIGIBLE_FOR_DT + "_" + userDataBean.getLangId()));
				status = CodeStatus.NOT_ELIGIBLE_FOR_DT;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00155")
						+ " >> Data transfer FAILED final result is [" + result + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DATA_TRANSFER_FAILURE + "_" + userDataBean.getLangId()));

				status = CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> Exception occurred while data transfer for user " + ": msisdn [" + userDataBean.getMsisdn()
					+ "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.DATA_TRANSFER_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00156")
					+ " >> Exception occurred while data transfer for user " + ": msisdn [" + userDataBean.getMsisdn()
					+ "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.DATA_TRANSFER_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		}

		// Now maintaining charging logs
		ChargingLogsBean chgLogsBean = new ChargingLogsBean(userDataBean.getMsisdn(), userDataBean.getFmsisdn(),
				transactionId, userDataBean.getPackTypeId(), serviceChargeDetails.getProductCode(),
				serviceChargeDetails.getServiceCharge(), serviceChargeDetails.getVolume(),
				serviceChargeDetails.getValidity(), userDataBean.getSubType(), userDataBean.getResult(),
				userDataBean.getRequestId(), userDataBean.getPackId(), serviceChargeDetails.getVolumeType(),
				serviceChargeDetails.getValidityType(), userDataBean.getShortCode(), userDataBean.getLangId(),
				userDataBean.getInterfaceUsed());

		DBOperations dbOps = new DBOperations();

		if (status == CodeStatus.SUCCESS) {
			userDataBean.setVolume(serviceChargeDetails.getVolume());
			dbOps.new SMSSender().sendSMSToBForDT(userDataBean, packBean, serviceChargeDetails);
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, true);

			// Added by AbhiShek Rana on 16 january 2018 for maintaining user
			// Transaction.
			UserTransactionBean transactionBean = new UserTransactionBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getFmsisdn(), packBean.getPackId(), packBean.getPackName(), userDataBean.getLangId(),
					"NA", serviceChargeDetails.getValidity(), serviceChargeDetails.getValidityType(),
					serviceChargeDetails.getVolume(), "DT",
					TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.MESSAGE_HEADER_DATA_TRANSFER + "_" + userDataBean.getLangId()),
					userDataBean.getShortCode(), userDataBean.getLangId(), userDataBean.getInterfaceUsed(), "NA");
			dbOps.new LogsManager().maintainUserTransactionCDRS(transactionBean);

		} else
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, false);

		return status;

	}// dataTransfer() ends

	/**
	 * Used to check user balance for talk time transfer means user have enough main
	 * account balance and enough talk-time balance or not
	 * 
	 * @param userDataBean
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred, low balance etc.
	 */
	public CodeStatus checkBalanceForTTT(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >> Going to check balance for transfer talk time " + userDataBean);

		Data_Object dataObject = new Data_Object();
		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.CHECK_TRANSFER_BALANCE);
		dataObject.setAccType(userDataBean.getNetType());
		dataObject.setCurrAcctChgAmt(userDataBean.getVolume());
		if (ServiceTypes.ON_NET.equals(userDataBean.getNetType())) {
			dataObject.setServiceAmount(TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOnNet());
		} else if (ServiceTypes.OFF_NET.equals(userDataBean.getNetType())) {
			dataObject.setServiceAmount(TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOffNet());
		}

		try {
			long currentTimeMS = new java.util.Date().getTime();
			dataObject.setTransId(userDataBean.getMsisdn() + "" + currentTimeMS);

			logger.info(userDataBean.getRequestId() + " >> Going to check balance for talk time transfer with charging "
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			int result = -1;
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00157")
						+ " >> charging testing is enable so using success : " + "msisdn [" + userDataBean.getMsisdn()
						+ "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId()
						+ " >> user has enough balance to transfer talk time final result is [" + result
						+ "] : msisdn [" + userDataBean.getMsisdn() + "]");
				return CodeStatus.SUCCESS;
			} else if (result == -2)// low main balance
			{
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00217")
						+ " >> User do not have enough main account balance to talk time transfer"
						+ " so returning failure : msisdn [" + userDataBean.getMsisdn() + "]");
				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.TTT_LOW_BALANCE + "_" + userDataBean.getLangId());
				if (ServiceTypes.ON_NET.equals(userDataBean.getNetType())) {
					if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
						filePath = filePath.replace("$(service_charge)",
								String.valueOf(TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOnNet()));
					} else {
						filePath = filePath.replace("$(service_charge)", String
								.valueOf((int) TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOnNet()));
					}

				} else if (ServiceTypes.OFF_NET.equals(userDataBean.getNetType())) {
					if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
						filePath = filePath.replace("$(service_charge)", String
								.valueOf(TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOffNet()));
					} else {
						filePath = filePath.replace("$(service_charge)", String.valueOf(
								(int) TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOffNet()));
					}

				}
				filePath = filePath.replace("$(available_balance)", String.valueOf(dataObject.getAcc_2000_balance()));

				userDataBean.setFilePath(filePath);
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);

				return CodeStatus.LOW_BALANCE;
			} else if (result == -3)// low talk time transfer balance
			{
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00218") + " >> volume ["
						+ userDataBean.getVolume() + "] is not enough "
						+ "(user do not have enough talk time balance) so returning failure : msisdn ["
						+ userDataBean.getMsisdn() + "]");
				String filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.TTT_LOW_VOLUME_BALANCE + "_" + userDataBean.getLangId());
				filePath = filePath.replace("$(volume)", String.valueOf(userDataBean.getVolume()));
				filePath = filePath.replace("$(available_balance)", String.valueOf(dataObject.getVolumeBalance()));
				userDataBean.setFilePath(filePath);
				userDataBean.setResult(ResponseParameters.LOW_TRANSFER_BALANCE);
				return CodeStatus.LOW_TTT_BALANCE;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00158")
						+ " >>checkBalanceForTTT(), Unable to check user talk time transfer balance final result is ["
						+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
				return CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> Exception occurred while check talk time transfer balance for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00159")
					+ " >> Exception occurred while check talk time transfer balance for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);
			return CodeStatus.EXCEPTION_OCCURED;
		}

	}// talkTimeTransfer() ends

	/**
	 * Used to check user eligibility for data transfer means user can transfer data
	 * to his/her friend or not
	 * 
	 * @param userDataBean
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred, not eligible etc. Also sets result, pack purchase
	 *         detail, message to be shown to user into user data bean object.
	 */
	public CodeStatus checkDTEligibility(UserDataBean userDataBean) {
		logger.debug(userDataBean.getRequestId() + " >> Going to check eligibility for data transfer " + userDataBean);

		Data_Object dataObject = new Data_Object();
		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.CHECK_DT_ELIGIBILITY);
		dataObject.setAccType(ServiceTypes.DATA);

		try {
			long currentTimeMS = new java.util.Date().getTime();
			dataObject.setTransId(userDataBean.getMsisdn() + "" + currentTimeMS);
			logger.info(userDataBean.getRequestId() + " >> Going to check eligibility for data transfer with charging "
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			int result = -1;
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00160")
						+ " >> charging testing is enable so using success : " + "msisdn [" + userDataBean.getMsisdn()
						+ "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// eligible
			{
				logger.info(userDataBean.getRequestId() + " >> User is eligible for data transfer final result is ["
						+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.SUCCESS);
				return CodeStatus.SUCCESS;
			} else if (result == -9)// not eligible
			{
				logger.info(userDataBean.getRequestId() + " >> User is not eligible for data transfer final result is ["
						+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.NOT_ELIGIBLE_FOR_DT + "_" + userDataBean.getLangId()));
				userDataBean.setResult(ResponseParameters.NOT_ELIGIBLE_FOR_DT);
				return CodeStatus.NOT_ELIGIBLE_FOR_DT;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00161")
						+ " >> Unable to check eligible for data transfer final result is [" + result + "] : msisdn ["
						+ userDataBean.getMsisdn() + "]");

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
				userDataBean.setResult(ResponseParameters.FAILURE);
				return CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> Exception occurred while check eligiblility for data transfer for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setResult(ResponseParameters.FAILURE);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00162")
					+ " >> Exception occurred while check eligiblility for data transfer for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId()));
			userDataBean.setResult(ResponseParameters.FAILURE);
			return CodeStatus.EXCEPTION_OCCURED;
		}

	}// checkDTEligibility() ends

	public CodeStatus purchasePackIVR(UserDataBean userDataBean) {

		logger.info(userDataBean.getRequestId() + " >> (IVR) Going to purchase pack " + userDataBean);

		CodeStatus status = null;
		String transactionId = null;
		String ivr_base_file_path = "";
		String filePath = "";

		Data_Object dataObject = new Data_Object();

		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.PACK_PURHCASE);
		dataObject.setProductCode(TSSJavaUtil.instance().getCacheParameters().getProductCode(userDataBean.getPackId()));

		if(userDataBean.getInterfaceUsed().equalsIgnoreCase("C"))
		{
			ivr_base_file_path = TSSJavaUtil.instance().getCacheParameters().getCustomerCareIvrPromptBasePath();
		}
		else
		{
			ivr_base_file_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
		}
		
		if (ivr_base_file_path.equalsIgnoreCase("NA") || ivr_base_file_path.equalsIgnoreCase("")
				|| ivr_base_file_path == null) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00320")
					+ " >> (IVR)  Base file path is not found for MSISDN[" + userDataBean.getMsisdn() + "].");
			userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		}

		ServiceCharge serviceCharge = TSSJavaUtil.instance().getCacheParameters()
				.getServiceChargeDetails(userDataBean.getPackId());

		if (serviceCharge == null) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00066")
					+ " >> Service charge details are not found for " + "pack id [" + userDataBean.getPackId()
					+ "] : msisdn [" + userDataBean.getMsisdn() + "]");

			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		}

		dataObject.setServiceAmount(serviceCharge.getVolume());

		PackBean packBean = null;
		try {
			long currentTimeMS = new java.util.Date().getTime();
			transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >> (IVR) Going to purchase pack for user with charging"
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			String key = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			packBean = new PackManager().getPackDetails(key, userDataBean.getPackId());

			if (packBean == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00067") + " >> This pack ["
						+ userDataBean.getPackId() + "] is not found in cache " + "under key [" + key
						+ "] so can not purchase. This pack is not available : msisdn [" + userDataBean.getMsisdn()
						+ "]");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);

				return CodeStatus.FAILURE;
			}

			TransferManager transferManager = new TransferManager();

			int result = -1;
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				dataObject.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00068")
						+ " >> charging testing is enable so sending success : " + "msisdn [" + userDataBean.getMsisdn()
						+ "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId() + " >> (IVR) Pack purchased successfully final result is ["
						+ result + "]");
				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				// file path for success prompt in the case of success

				filePath = ivr_base_file_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.PACK_PURCHASE_SUCCESS_WAV_IVR;
				userDataBean.setFilePath(filePath);
				status = CodeStatus.SUCCESS;
			} else if (result == -2)// low balance
			{
				logger.info(userDataBean.getRequestId() + " >> (IVR) Pack purchase failed LOW BALANCE final result is ["
						+ result + "]");

				filePath = ivr_base_file_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.PACK_PURCHASE_LOW_BALANCE_IVR;
				logger.debug(userDataBean.getRequestId()
						+ "] (IVR) The file path for low balance in case of pack purchase is [" + filePath
						+ "] and msisdn is [" + userDataBean.getMsisdn() + "]");

				// userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);
				userDataBean.setFilePath(filePath);

				status = CodeStatus.LOW_BALANCE;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00188")
						+ " >> (IVR) Pack purchase failed final result is [" + result + "]");
				filePath = ivr_base_file_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.PACK_PURCHASE_FAILURE_WAV_IVR;

				userDataBean.setResult(ResponseParameters.PACK_PURCHASE_FAILURE_IVR);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);
				userDataBean.setFilePath(filePath);
				status = CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occurred while purchasing pack for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);

			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00069")
					+ " >> Exception occurred while purchasing pack for user " + ": msisdn [" + userDataBean.getMsisdn()
					+ "]", e);

			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);

			status = CodeStatus.EXCEPTION_OCCURED;
		}

		// Now maintaining charging logs
		ChargingLogsBean chgLogsBean = new ChargingLogsBean(userDataBean.getMsisdn(), userDataBean.getFmsisdn(),
				transactionId, userDataBean.getPackTypeId(), dataObject.getProductCode(), 0, serviceCharge.getVolume(),
				serviceCharge.getValidity(), userDataBean.getSubType(), userDataBean.getResult(),
				userDataBean.getRequestId(), userDataBean.getPackId(), serviceCharge.getVolumeType(),
				serviceCharge.getValidityType(), userDataBean.getShortCode(), userDataBean.getLangId(),
				userDataBean.getInterfaceUsed());

		if (status == CodeStatus.SUCCESS) {
			new DBOperations().new LogsManager().maintainChargingLogs(chgLogsBean, true);

			// Added by AbhiShek Rana on 16 january 2018 for maintaining user
			// pack purchase.
			UserPackPurchaseBean packPurchaseBean = new UserPackPurchaseBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getPackId(), packBean.getPackName(), userDataBean.getLangId(),
					packBean.getDescription(), "NA", serviceCharge.getValidity(), serviceCharge.getValidityType(), "NA",
					packBean.getPackTypeId());

			new DBOperations().new LogsManager().maintainUserPurchaseDetails(packPurchaseBean);

			// Added by AbhiShek Rana on 16 january 2018 for maintaining user
			// Transaction.
			UserTransactionBean transactionBean = new UserTransactionBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getFmsisdn(), userDataBean.getPackId(), packBean.getPackName(),
					userDataBean.getLangId(), "NA", serviceCharge.getValidity(), serviceCharge.getValidityType(),
					serviceCharge.getVolume(), "PP",
					TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.MESSAGE_HEADER_PACK_PURCHASE + "_" + userDataBean.getLangId()),
					userDataBean.getShortCode(), userDataBean.getLangId(), userDataBean.getInterfaceUsed(), "NA");
			new DBOperations().new LogsManager().maintainUserTransactionCDRS(transactionBean);
		} else
			new DBOperations().new LogsManager().maintainChargingLogs(chgLogsBean, false);

		return status;

	}

	public CodeStatus talkTimeTransferIVR(UserDataBean userDataBean) {

		logger.info(userDataBean.getRequestId() + " >> (IVR) Going to transfer talk time " + userDataBean);

		CodeStatus status = null;
		String transactionId = null;
		Data_Object dataObject = new Data_Object();
		int packTypeId = -1;
		double serviceCharge = 0.0;
		int validityDays = -1;
		String filePathIvr = "";

		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.TALK_TIME_TRANSFER);
		dataObject.setAccType(userDataBean.getNetType());
		dataObject.setCurrAcctChgAmt(userDataBean.getVolume());
		dataObject.setFmsisdn(userDataBean.getFmsisdn());

		packTypeId = TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER);
		if (ServiceTypes.ON_NET.equals(userDataBean.getNetType())) {
			serviceCharge = TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOnNet();
		} else if (ServiceTypes.OFF_NET.equals(userDataBean.getNetType())) {
			serviceCharge = TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOffNet();
		}
		/*
		 * serviceCharge =
		 * TSSJavaUtil.instance().getCacheParameters().getTttServiceCharge();
		 */
		dataObject.setServiceAmount(serviceCharge);

		try {
			String ivr_base_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
			if (ivr_base_path.equalsIgnoreCase("") || ivr_base_path.equalsIgnoreCase("NA") || ivr_base_path == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			// setting validity
			validityDays = TSSJavaUtil.instance().getCacheParameters().getTransferValidityDays(packTypeId,
					userDataBean.getVolume());
			if (validityDays <= 0) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00070")
						+ " >> (IVR) no validity days configuration found for " + "pack type [" + packTypeId
						+ "] and volume [" + userDataBean.getVolume() + "] so returning failure : " + "msisdn ["
						+ userDataBean.getMsisdn() + "].");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER)
								+ ":-1");

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.TTT_FAILURE_WAV_IVR;
				userDataBean.setFilePath(filePathIvr);

				return CodeStatus.FAILURE;
			}

			dataObject.setNb_day(validityDays);

			long currentTimeMS = new java.util.Date().getTime();
			transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >>(IVR) Going to transfer with charging for user with charging"
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			int result = -1;
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				dataObject.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				dataObject.setVolumeBalance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00071")
						+ " >> charging testing is enable so using success : " + "msisdn [" + userDataBean.getMsisdn()
						+ "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId()
						+ " >> (IVR) Talk time transfered successfully final result is [" + result + "]");
				userDataBean.setResult(ResponseParameters.SUCCESS);

				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER) + ":"
								+ result);

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.TTT_SUCCESS_WAV_IVR;
				userDataBean.setFilePath(filePathIvr);

				status = CodeStatus.SUCCESS;
			} else if (result == -2)// low balance
			{
				logger.info(userDataBean.getRequestId()
						+ " >> (IVR) Talk time transfer FAILED LOW BALANCE final result is [" + result + "]");

				// userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER) + ":"
								+ result);

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.TTT_LOW_BALANCE_1_WAV_IVR + TSSJavaUtil.FileSeparator
						+ TSSJavaUtil.instance().getNumberPrompt(String.valueOf(serviceCharge),
								userDataBean.getLangId(), ivr_base_path)
						+ TSSJavaUtil.FileSeparator + TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId())
						+ TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.TTT_LOW_BALANCE_2_WAV_IVR;

				logger.debug(userDataBean.getRequestId()
						+ "] (IVR) The file path for low balance in case of talktime transfer is [" + filePathIvr
						+ "] and msisdn :[" + userDataBean.getMsisdn() + "]");
				userDataBean.setFilePath(filePathIvr);
				status = CodeStatus.LOW_BALANCE;
			} else if (result == -3)// low talk time transfer balance
			{
				logger.info(userDataBean.getRequestId()
						+ " >> (IVR) Tallktime transfer FAILED user has LOW TTT BALANCE final result is " + "[" + result
						+ "] : msisdn [" + userDataBean.getMsisdn() + "]");

				// userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER) + ":"
								+ result);

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.TTT_LOW_VOLUME_BALANCE_1_WAV_IVR + TSSJavaUtil.FileSeparator
						+ TSSJavaUtil.instance().getNumberPrompt(String.valueOf(userDataBean.getVolume()),
								userDataBean.getLangId(), ivr_base_path)
						+ TSSJavaUtil.FileSeparator + TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId())
						+ TSSJavaUtil.FileSeparator + ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.TTT_LOW_VOLUME_BALANCE_2_WAV_IVR;

				logger.debug(userDataBean.getRequestId()
						+ "] The file path for low volume balance in case of talktime transfer is [" + filePathIvr
						+ "] and msisdn :[" + userDataBean.getMsisdn() + "]");
				userDataBean.setFilePath(filePathIvr);

				status = CodeStatus.LOW_TTT_BALANCE;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00072")
						+ " >>(IVR) Talk time transfer FAILED - result:[" + result + "] MSISDN:["
						+ userDataBean.getMsisdn() + "].");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER) + ":"
								+ result);

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.TTT_FAILURE_WAV_IVR;
				userDataBean.setFilePath(filePathIvr);

				status = CodeStatus.FAILURE;
			}

		} catch (NullPointerException e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occurred while talk time transfer for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);

			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER) + ":-1");
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);

			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00073")
					+ " >> Exception occurred while talk time transfer for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.TALK_TIME_TRANSFER) + ":-1");
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);

			status = CodeStatus.EXCEPTION_OCCURED;
		}

		DBOperations dbOps = new DBOperations();

		// Now maintaining charging logs
		ChargingLogsBean chgLogsBean = new ChargingLogsBean(userDataBean.getMsisdn(), userDataBean.getFmsisdn(),
				transactionId, packTypeId, TSSJavaUtil.instance().getCacheParameters().getTttProductCode(),
				serviceCharge, userDataBean.getVolume(), validityDays, userDataBean.getSubType(),
				userDataBean.getResult(), userDataBean.getRequestId(), -1, "NA", "DY", userDataBean.getShortCode(),
				userDataBean.getLangId(), userDataBean.getInterfaceUsed());

		if (status == CodeStatus.SUCCESS) {
			dbOps.new SMSSender().sendSMSForTTTB(userDataBean, validityDays);
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, true);

			// Added by AbhiShek Rana on 16 january 2018 for maintaining user
			// Transaction.
			UserTransactionBean transactionBean = new UserTransactionBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getFmsisdn(), packTypeId, "NA", userDataBean.getLangId(), "NA", validityDays, "DY",
					userDataBean.getVolume(), "TT",
					TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.MESSAGE_HEADER_TALKTIME_TRANSFER + "_" + userDataBean.getLangId()),
					userDataBean.getShortCode(), userDataBean.getLangId(), userDataBean.getInterfaceUsed(), "NA");
			dbOps.new LogsManager().maintainUserTransactionCDRS(transactionBean);

		} else
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, false);

		return status;

	}// talkTimeTransferIVR() ends

	/**
	 * Used to transfer bonus (gift) from A party to B party (IVR)
	 * 
	 * @param userDataBean
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred, low balance etc. Also sets result, pack purchase
	 *         detail, message to be shown to user into user data bean object.
	 */
	public CodeStatus bonusTransferIvr(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >> (IVR) Going to transfer bonus " + userDataBean);

		CodeStatus status = null;
		String transactionId = null;
		Data_Object dataObject = new Data_Object();
		ServiceCharge serviceChargeDetails = null;
		PackBean packBean = null;
		String filePathIvr = "";

		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.BONUS_TRANSFER);
		dataObject.setFmsisdn(userDataBean.getFmsisdn());
		dataObject.setAccType(ServiceTypes.GIFT);
		dataObject.setProductCode(TSSJavaUtil.instance().getCacheParameters().getProductCode(userDataBean.getPackId()));

		try {
			String ivr_base_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
			if (ivr_base_path.equalsIgnoreCase("") || ivr_base_path.equalsIgnoreCase("NA") || ivr_base_path == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			serviceChargeDetails = TSSJavaUtil.instance().getCacheParameters()
					.getServiceChargeDetails(userDataBean.getPackId());

			if (serviceChargeDetails == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00074")
						+ " >> (IVR) Service charge details are not found for " + "pack id [" + userDataBean.getPackId()
						+ "] so returning failure : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.BONUS_FAILURE_WAV_IVR;
				userDataBean.setFilePath(filePathIvr);

				return CodeStatus.FAILURE;
			}

			String key = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			packBean = new PackManager().getPackDetails(key, userDataBean.getPackId());

			if (packBean == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00075")
						+ " >> This bonus pack [" + userDataBean.getPackId() + "] is not found in cache "
						+ "under key [" + key + "] so can not be avialed to user. This pack is not available : msisdn ["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.BONUS_FAILURE_WAV_IVR;
				userDataBean.setFilePath(filePathIvr);

				return CodeStatus.FAILURE;
			}

			dataObject.setNb_day(serviceChargeDetails.getValidity());
			dataObject.setCurrAcctChgAmt(serviceChargeDetails.getVolume());
			dataObject.setServiceAmount(serviceChargeDetails.getServiceCharge());

			long currentTimeMS = new java.util.Date().getTime();
			transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >> (IVR) Going to transfer bonus for user with charging"
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			int result = -1;
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				dataObject.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00078")
						+ " >> (IVR) charging testing is enable so using success : " + "msisdn ["
						+ userDataBean.getMsisdn() + "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId() + " >> Bonus is transfered successfully final result is ["
						+ result + "]");

				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.GIFT_BONUS_SUCCESS_WAV_IVR;
				userDataBean.setFilePath(filePathIvr);

				status = CodeStatus.SUCCESS;
			} else if (result == -2)// low balance
			{
				logger.info(userDataBean.getRequestId()
						+ " >> (IVR) Bonus transfer FAILED LOW BALANCE final result is [" + result + "]");

				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.BONUS_LOW_BALANCE_WAV_IVR;

				logger.debug(
						userDataBean.getRequestId() + "] The file path for low balance in case of bonus transfer is ["
								+ filePathIvr + "] and msisdn :[" + userDataBean.getMsisdn() + "]");

				userDataBean.setFilePath(filePathIvr);
				status = CodeStatus.LOW_BALANCE;
			} else if (result == -3)// low bonus volume balance
			{
				logger.info(userDataBean.getRequestId()
						+ " >> (IVR) Bonus transfer FAILED LOW VOLUME BALANCE final result is [" + result + "]");

				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.BONUS_LOW_VOLUME_BALANCE_WAV_IVR;

				logger.debug(userDataBean.getRequestId()
						+ "] The file path for low volume balance in case of bonus transfer is [" + filePathIvr
						+ "] and msisdn :[" + userDataBean.getMsisdn() + "]");
				userDataBean.setFilePath(filePathIvr);

				status = CodeStatus.LOW_BALANCE;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00076")
						+ " >> (IVR) Bonus transfer FAILED final result is [" + result + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);
				String filePath = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.BONUS_FAILURE_WAV_IVR;
				userDataBean.setFilePath(filePath);

				status = CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> (IVR) NullPointerException occurred while bonus transfer for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");
			String filePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
					+ File.separator + IvrMenu.BONUS_FAILURE_WAV_IVR;
			userDataBean.setFilePath(filePath);

			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00077")
					+ " >> (IVR) Exception occurred while bonus transfer for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

			String filePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
					+ File.separator + IvrMenu.BONUS_FAILURE_WAV_IVR;
			userDataBean.setFilePath(filePath);
			status = CodeStatus.EXCEPTION_OCCURED;
		}

		// Now maintaining charging logs
		ChargingLogsBean chgLogsBean = new ChargingLogsBean(userDataBean.getMsisdn(), userDataBean.getFmsisdn(),
				transactionId, userDataBean.getPackTypeId(), serviceChargeDetails.getProductCode(),
				serviceChargeDetails.getServiceCharge(), serviceChargeDetails.getVolume(),
				serviceChargeDetails.getValidity(), userDataBean.getSubType(), userDataBean.getResult(),
				userDataBean.getRequestId(), userDataBean.getPackId(), serviceChargeDetails.getVolumeType(),
				serviceChargeDetails.getValidityType(), userDataBean.getShortCode(), userDataBean.getLangId(),
				userDataBean.getInterfaceUsed());

		DBOperations dbOps = new DBOperations();

		if (status == CodeStatus.SUCCESS) {
			userDataBean.setVolume(serviceChargeDetails.getVolume());
			dbOps.new SMSSender().sendSMSToBForBonus(userDataBean, packBean, serviceChargeDetails);
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, true);

			// Added by AbhiShek Rana on 16 january 2018 for maintaining user
			// Transaction.
			UserTransactionBean transactionBean = new UserTransactionBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getFmsisdn(), packBean.getPackId(), packBean.getPackName(), userDataBean.getLangId(),
					"NA", serviceChargeDetails.getValidity(), serviceChargeDetails.getValidityType(),
					serviceChargeDetails.getVolume(), "BT",
					TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.MESSAGE_HEADER_BONUS_TRANSFER + "_" + userDataBean.getLangId()),
					userDataBean.getShortCode(), userDataBean.getLangId(), userDataBean.getInterfaceUsed(), "NA");
			dbOps.new LogsManager().maintainUserTransactionCDRS(transactionBean);

		} else
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, false);

		return status;

	}// bonusTransferIvr() ends

	/**
	 * Used to check user eligibility for data transfer means user can transfer data
	 * to his/her friend or not (IVR)
	 * 
	 * @param userDataBean
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred, not eligible etc. Also sets result, pack purchase
	 *         detail, message to be shown to user into user data bean object.
	 */
	public CodeStatus checkDTEligibilityIvr(UserDataBean userDataBean) {
		logger.debug(
				userDataBean.getRequestId() + " >> (IVR) Going to check eligibility for data transfer " + userDataBean);

		Data_Object dataObject = new Data_Object();
		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.CHECK_DT_ELIGIBILITY);
		dataObject.setAccType(ServiceTypes.DATA);

		try {
			long currentTimeMS = new java.util.Date().getTime();
			dataObject.setTransId(userDataBean.getMsisdn() + "" + currentTimeMS);
			String ivr_base_file_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
			if (ivr_base_file_path.equalsIgnoreCase("NA") || ivr_base_file_path.equalsIgnoreCase("")
					|| ivr_base_file_path == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00320")
						+ " >> (IVR)  Base file path is not found for MSISDN[" + userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			logger.info(userDataBean.getRequestId() + " >> Going to check eligibility for data transfer with charging "
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			int result = -1;
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00160")
						+ " >>(IVR) charging testing is enable so using success : " + "msisdn ["
						+ userDataBean.getMsisdn() + "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// eligible
			{
				logger.info(userDataBean.getRequestId() + " >> User is eligible for data transfer final result is ["
						+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.SUCCESS);
				return CodeStatus.SUCCESS;
			} else if (result == -9)// not eligible
			{
				logger.info(userDataBean.getRequestId()
						+ " >> (IVR) User is not eligible for data transfer final result is [" + result + "] : msisdn ["
						+ userDataBean.getMsisdn() + "]");
				String filePath = ivr_base_file_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.NOT_ELIGIBLE_FOR_DT_WAV_IVR;

				userDataBean.setFilePath(filePath);
				userDataBean.setResult(ResponseParameters.NOT_ELIGIBLE_FOR_DT);
				return CodeStatus.NOT_ELIGIBLE_FOR_DT;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00161")
						+ " >> (IVR) Unable to check eligible for data transfer final result is [" + result
						+ "] : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				return CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> (IVR) Exception occurred while check eligiblility for data transfer for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00162")
					+ " >> (IVR) Exception occurred while check eligiblility for data transfer for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
			return CodeStatus.EXCEPTION_OCCURED;
		}

	}// checkDTEligibilityIvr() ends

	/**
	 * Used to transfer data from A party to B party (IVR)
	 * 
	 * @param userDataBean
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred, low balance etc. Also sets result, pack purchase
	 *         detail, message to be shown to user into user data bean object.
	 */
	public CodeStatus dataTransferIvr(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >> (IVR) Going to transfer data " + userDataBean);
		int result = -1;
		CodeStatus status = null;
		String transactionId = null;
		Data_Object dataObject = new Data_Object();
		ServiceCharge serviceChargeDetails = null;
		PackBean packBean = null;
		String filePathIvr = "";
		String ivr_base_path = "";

		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.DATA_TRANSFER);
		dataObject.setFmsisdn(userDataBean.getFmsisdn());
		dataObject.setAccType(ServiceTypes.DATA);
		dataObject.setProductCode(TSSJavaUtil.instance().getCacheParameters().getProductCode(userDataBean.getPackId()));

		try {

			ivr_base_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
			if (ivr_base_path.equalsIgnoreCase("") || ivr_base_path.equalsIgnoreCase("NA") || ivr_base_path == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
						+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
						+ userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			serviceChargeDetails = TSSJavaUtil.instance().getCacheParameters()
					.getServiceChargeDetails(userDataBean.getPackId());

			if (serviceChargeDetails == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00152")
						+ "  >> Service charge details are not found for " + "pack id [" + userDataBean.getPackId()
						+ "] so returning failure : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.DATA_TRANSFER_FAILURE_WAV_IVR;
				userDataBean.setFilePath(filePathIvr);
				return CodeStatus.FAILURE;
			}

			String key = userDataBean.getPackTypeId() + "_" + userDataBean.getLangId() + "_"
					+ userDataBean.getSubType();
			packBean = new PackManager().getPackDetails(key, userDataBean.getPackId());

			if (packBean == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00153")
						+ "  >>(IVR) This data pack [" + userDataBean.getPackId() + "] is not found in cache "
						+ "under key [" + key + "] so can not be avialed to user. This pack is not available : msisdn ["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.DATA_TRANSFER_FAILURE_WAV_IVR;
				userDataBean.setFilePath(filePathIvr);
				return CodeStatus.FAILURE;
			}

			dataObject.setNb_day(serviceChargeDetails.getValidity());
			if ("TB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
				dataObject.setCurrAcctChgAmt((long) serviceChargeDetails.getVolume() * 1024 * 1024 * 1024 * 1024);
			} else if ("GB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
				dataObject.setCurrAcctChgAmt((long) serviceChargeDetails.getVolume() * 1024 * 1024 * 1024);
			} else if ("MB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
				dataObject.setCurrAcctChgAmt((long) serviceChargeDetails.getVolume() * 1024 * 1024);
			} else if ("KB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
				dataObject.setCurrAcctChgAmt((long) serviceChargeDetails.getVolume() * 1024);
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00280")
						+ " >> (IVR) Data transfer FAILED due to " + "unsupported volume type ["
						+ serviceChargeDetails.getVolumeType() + "] and the final result is [" + result + "]");

				throw new Exception("unsupported volume type");
			}
			logger.debug("(IVR) The volume passed to charging jar in case of  [" + serviceChargeDetails.getVolumeType()
					+ "] is " + dataObject.getCurrAcctChgAmt());

			dataObject.setServiceAmount(serviceChargeDetails.getServiceCharge());

			long currentTimeMS = new java.util.Date().getTime();
			transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >>(IVR) Going to transfer data for user with charging"
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				dataObject.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				dataObject.setVolumeBalance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00154")
						+ "  >> (IVR) charging testing is enable so using success : " + "msisdn ["
						+ userDataBean.getMsisdn() + "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId() + " >> (IVR) Data is transfered successfully final result is ["
						+ result + "]");

				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				String filePath = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.DATA_TRANSFER_SUCCESS_WAV_IVR;
				userDataBean.setFilePath(filePath);

				status = CodeStatus.SUCCESS;
			} else if (result == -2)// low balance
			{
				logger.info(userDataBean.getRequestId() + " >>(IVR) Data transfer FAILED LOW BALANCE final result is ["
						+ result + "]");

				// userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.DT_LOW_BALANCE_WAV_IVR;

				logger.debug(userDataBean.getRequestId()
						+ "] (IVR) The file path for low balance in case of data transfer is [" + filePathIvr
						+ "] and msisdn :[" + userDataBean.getMsisdn() + "]");

				userDataBean.setFilePath(filePathIvr);
				status = CodeStatus.LOW_BALANCE;
			} else if (result == -3)// low bonus volume balance
			{
				logger.info(userDataBean.getRequestId()
						+ " >> (IVR) Data transfer FAILED LOW VOLUME BALANCE final result is [" + result + "]");

				// userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.DT_LOW_VOLUME_BALANCE_WAV_IVR;

				if ("TB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
					dataObject.setVolumeBalance((long) dataObject.getVolumeBalance() / (1024 * 1024 * 1024 * 1024));
				} else if ("GB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
					dataObject.setVolumeBalance((long) dataObject.getVolumeBalance() / (1024 * 1024 * 1024));
				} else if ("MB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
					dataObject.setVolumeBalance((long) dataObject.getVolumeBalance() / (1024 * 1024));
				} else if ("KB".equalsIgnoreCase(serviceChargeDetails.getVolumeType())) {
					dataObject.setVolumeBalance((long) dataObject.getVolumeBalance() / 1024);
				}

				logger.debug(userDataBean.getRequestId()
						+ "] (IVR) The file path for low volume balance in case of data transfer is [" + filePathIvr
						+ "] and msisdn :[" + userDataBean.getMsisdn() + "]");

				userDataBean.setFilePath(filePathIvr);
				status = CodeStatus.LOW_BALANCE;
			}

			else if (result == -9)// Not eligible for data transfer.
			{
				logger.info(userDataBean.getRequestId() + " >> User is not eligible for data transfer final result is ["
						+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);
				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.NOT_ELIGIBLE_FOR_DT_WAV_IVR;
				userDataBean.setFilePath(filePathIvr);
				status = CodeStatus.NOT_ELIGIBLE_FOR_DT;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00155")
						+ " >> (IVR) Data transfer FAILED final result is [" + result + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":" + result);

				filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
						+ IvrMenu.DATA_TRANSFER_FAILURE_WAV_IVR;
				userDataBean.setFilePath(filePathIvr);
				status = CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> (IVR) Exception occurred while data transfer for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

			filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
					+ IvrMenu.DATA_TRANSFER_FAILURE_WAV_IVR;
			userDataBean.setFilePath(filePathIvr);
			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00156")
					+ " >> (IVR) Exception occurred while data transfer for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(userDataBean.getPackId() + ":-1");

			filePathIvr = ivr_base_path + userDataBean.getLangId() + File.separator
					+ IvrMenu.DATA_TRANSFER_FAILURE_WAV_IVR;
			userDataBean.setFilePath(filePathIvr);
			status = CodeStatus.EXCEPTION_OCCURED;
		}

		// Now maintaining charging logs
		ChargingLogsBean chgLogsBean = new ChargingLogsBean(userDataBean.getMsisdn(), userDataBean.getFmsisdn(),
				transactionId, userDataBean.getPackTypeId(), serviceChargeDetails.getProductCode(),
				serviceChargeDetails.getServiceCharge(), serviceChargeDetails.getVolume(),
				serviceChargeDetails.getValidity(), userDataBean.getSubType(), userDataBean.getResult(),
				userDataBean.getRequestId(), userDataBean.getPackId(), serviceChargeDetails.getVolumeType(),
				serviceChargeDetails.getValidityType(), userDataBean.getShortCode(), userDataBean.getLangId(),
				userDataBean.getInterfaceUsed());

		DBOperations dbOps = new DBOperations();

		if (status == CodeStatus.SUCCESS) {
			userDataBean.setVolume(serviceChargeDetails.getVolume());
			dbOps.new SMSSender().sendSMSToBForDT(userDataBean, packBean, serviceChargeDetails);
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, true);

			// Added by AbhiShek Rana on 16 january 2018 for maintaining user
			// Transaction.
			UserTransactionBean transactionBean = new UserTransactionBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getFmsisdn(), packBean.getPackId(), packBean.getPackName(), userDataBean.getLangId(),
					"NA", serviceChargeDetails.getValidity(), serviceChargeDetails.getValidityType(),
					serviceChargeDetails.getVolume(), "DT",
					TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.MESSAGE_HEADER_DATA_TRANSFER + "_" + userDataBean.getLangId()),
					userDataBean.getShortCode(), userDataBean.getLangId(), userDataBean.getInterfaceUsed(), "NA");
			dbOps.new LogsManager().maintainUserTransactionCDRS(transactionBean);

		} else
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, false);

		return status;

	}// dataTransferIvr() ends

	/**
	 * This method is used to check user's main account Balance in case of IVR
	 * 
	 * @param userDataBean
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred etc. Also sets result, main account balance, pack
	 *         purchase detail, message to be shown to user into user data bean
	 *         object. Used to set Balance Prompt.
	 */
	public CodeStatus checkUserBalanceIvr(UserDataBean userDataBean) {
		logger.debug(userDataBean.getRequestId() + " >>(IVR) Going to check user balance : " + "msisdn ["
				+ userDataBean.getMsisdn() + "]");

		String promptFilePath = "";
		String ivrBaseFilePath = "";
		Data_Object dataObject = new Data_Object();
		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.CHECK_BALANCE);

		try {
			ivrBaseFilePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
			if (ivrBaseFilePath.equalsIgnoreCase("NA") || ivrBaseFilePath.equalsIgnoreCase("")
					|| ivrBaseFilePath == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00320")
						+ " >> (IVR)  Base file path is not found for MSISDN[" + userDataBean.getMsisdn() + "].");
				userDataBean.setResult(ResponseParameters.UNKNOWN_ERROR_IVR);
				userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
				return CodeStatus.FAILURE;
			}

			long currentTimeMS = new java.util.Date().getTime();
			String transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >>(IVR) Going to check balance of user with data object " + "["
					+ dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			int result = -1;
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				dataObject.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00063")
						+ " >>(IVR) charging testing is enable so sending success : " + "msisdn ["
						+ userDataBean.getMsisdn() + "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId() + " >>(IVR) Check Balance SUCCESS final result is [" + result
						+ "]" + " and user's balance is [" + dataObject.getAcc_2000_balance() + "] : msisdn ["
						+ userDataBean.getMsisdn() + "]");

				userDataBean.setBalance(dataObject.getAcc_2000_balance());
				promptFilePath = ivrBaseFilePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.CHECK_BALANCE_SUCCESS_1_WAV_IVR + TSSJavaUtil.FileSeparator
						+ TSSJavaUtil.instance().getNumberPrompt(String.valueOf(userDataBean.getBalance()),
								userDataBean.getLangId(), ivrBaseFilePath)
						+ TSSJavaUtil.FileSeparator
						+ TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId());
				userDataBean.setFilePath(promptFilePath);
				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.CHECK_BALANCE) + ":"
								+ result);
				userDataBean.setResult(ResponseParameters.SUCCESS);

				return CodeStatus.SUCCESS;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00064")
						+ " >>(IVR) Check Balance FAILURE final result is [" + result + "]" + " and user's balance is ["
						+ dataObject.getAcc_2000_balance() + "] : msisdn [" + userDataBean.getMsisdn() + "]");

				promptFilePath = ivrBaseFilePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.CHECK_BALANCE_FAILURE_WAV_IVR;
				userDataBean.setFilePath(promptFilePath);
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(
						TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.CHECK_BALANCE) + ":"
								+ result);

				return CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occurred while checking user balance " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(ivrBaseFilePath + userDataBean.getLangId() + File.separator
					+ IvrMenu.CHECK_BALANCE_FAILURE_WAV_IVR);
			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.CHECK_BALANCE) + ":-1");

			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00065")
					+ " >> Exception occurred while checking user balance " + ": msisdn [" + userDataBean.getMsisdn()
					+ "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setFilePath(ivrBaseFilePath + userDataBean.getLangId() + File.separator
					+ IvrMenu.CHECK_BALANCE_FAILURE_WAV_IVR);
			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.CHECK_BALANCE) + ":-1");

			return CodeStatus.EXCEPTION_OCCURED;
		}

	}// checkUserBalanceIvr() ends

	/**
	 * Used to check user balance for talk time transfer means user have enough main
	 * account balance and enough talk-time balance or not
	 * 
	 * @param userDataBean
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred, low balance etc.
	 */
	public CodeStatus checkBalanceForTTTIvr(UserDataBean userDataBean) {
		logger.info(
				userDataBean.getRequestId() + " >>(Ivr) Going to check balance for transfer talk time " + userDataBean);

		String filePathIvr = "";
		Data_Object dataObject = new Data_Object();
		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.CHECK_TRANSFER_BALANCE);
		dataObject.setAccType(userDataBean.getNetType());
		dataObject.setCurrAcctChgAmt(userDataBean.getVolume());

		String ivrBaseFilePath = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
		if (ivrBaseFilePath.equalsIgnoreCase("NA") || ivrBaseFilePath.equalsIgnoreCase("") || ivrBaseFilePath == null) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00320")
					+ " >> (IVR)  Base file path is not found for MSISDN[" + userDataBean.getMsisdn() + "].");
			userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
			userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
			return CodeStatus.FAILURE;
		}

		if (ServiceTypes.ON_NET.equals(userDataBean.getNetType())) {
			dataObject.setServiceAmount(TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOnNet());
		} else if (ServiceTypes.OFF_NET.equals(userDataBean.getNetType())) {
			dataObject.setServiceAmount(TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOffNet());
		}

		try {
			long currentTimeMS = new java.util.Date().getTime();
			dataObject.setTransId(userDataBean.getMsisdn() + "" + currentTimeMS);

			logger.info(userDataBean.getRequestId()
					+ " >>(IVR) Going to check balance for talk time transfer with charging " + " with data object ["
					+ dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			int result = -1;
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00157")
						+ " >>(IVR) charging testing is enable so using success : " + "msisdn ["
						+ userDataBean.getMsisdn() + "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId()
						+ " >>(IVR) user has enough balance to transfer talk time final result is [" + result
						+ "] : msisdn [" + userDataBean.getMsisdn() + "]");
				return CodeStatus.SUCCESS;
			} else if (result == -2)// low main balance
			{
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00217")
						+ " >> User do not have enough main account balance to talk time transfer"
						+ " so returning failure : msisdn [" + userDataBean.getMsisdn() + "]");

				logger.debug(userDataBean.getRequestId()
						+ "] (IVR) The file path for low balance in case of talktime transfer is [" + filePathIvr
						+ "] and msisdn :[" + userDataBean.getMsisdn() + "]");
				userDataBean.setFilePath(filePathIvr);

				if (ServiceTypes.ON_NET.equals(userDataBean.getNetType())) {

					filePathIvr = ivrBaseFilePath + userDataBean.getLangId() + File.separator
							+ IvrMenu.TTT_LOW_BALANCE_1_WAV_IVR + TSSJavaUtil.FileSeparator
							+ TSSJavaUtil.instance().getNumberPrompt(
									String.valueOf(
											TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOnNet()),
									userDataBean.getLangId(), ivrBaseFilePath)
							+ TSSJavaUtil.FileSeparator
							+ TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId())
							+ TSSJavaUtil.FileSeparator + ivrBaseFilePath + userDataBean.getLangId() + File.separator
							+ IvrMenu.TTT_LOW_BALANCE_2_WAV_IVR;

				} else if (ServiceTypes.OFF_NET.equals(userDataBean.getNetType())) {

					filePathIvr = ivrBaseFilePath + userDataBean.getLangId() + File.separator
							+ IvrMenu.TTT_LOW_BALANCE_1_WAV_IVR + TSSJavaUtil.FileSeparator
							+ TSSJavaUtil.instance().getNumberPrompt(
									String.valueOf(
											TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOffNet()),
									userDataBean.getLangId(), ivrBaseFilePath)
							+ TSSJavaUtil.FileSeparator
							+ TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId())
							+ TSSJavaUtil.FileSeparator + ivrBaseFilePath + userDataBean.getLangId() + File.separator
							+ IvrMenu.TTT_LOW_BALANCE_2_WAV_IVR;

				}

				userDataBean.setFilePath(filePathIvr);
				userDataBean.setResult(ResponseParameters.LOW_BALANCE);

				return CodeStatus.LOW_BALANCE;
			} else if (result == -3)// low talk time transfer balance
			{
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00218") + " >>(IVR) volume ["
						+ userDataBean.getVolume() + "] is not enough "
						+ "(user do not have enough talk time balance) so returning failure : msisdn ["
						+ userDataBean.getMsisdn() + "]");

				filePathIvr = ivrBaseFilePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.TTT_LOW_VOLUME_BALANCE_1_WAV_IVR + TSSJavaUtil.FileSeparator
						+ TSSJavaUtil.instance().getNumberPrompt(String.valueOf(userDataBean.getVolume()),
								userDataBean.getLangId(), ivrBaseFilePath)
						+ TSSJavaUtil.FileSeparator + TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId())
						+ TSSJavaUtil.FileSeparator + ivrBaseFilePath + userDataBean.getLangId() + File.separator
						+ IvrMenu.TTT_LOW_VOLUME_BALANCE_2_WAV_IVR;

				userDataBean.setFilePath(filePathIvr);
				userDataBean.setResult(ResponseParameters.LOW_TRANSFER_BALANCE);
				return CodeStatus.LOW_TTT_BALANCE;
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00158")
						+ " >>(IVR) checkBalanceForTTT(), Unable to check user talk time transfer balance final result is ["
						+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
				return CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> Exception occurred while check talk time transfer balance for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00159")
					+ " >> Exception occurred while check talk time transfer balance for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);
			return CodeStatus.EXCEPTION_OCCURED;
		}

	}// checkBalanceForTTTIvr() ends

	/**
	 * This method is used in Data Macro Credit Service in which user can convert
	 * its main account balance into DATA.
	 * 
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return CodeStatus
	 */
	public CodeStatus dmcAmountBasedConversion(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId()
				+ " >> DMC-AB(Data Macro Credit Amount Based) Going to convert balance into data with Interface ["
				+ userDataBean.getInterfaceUsed() + "] and userDataBean" + userDataBean);
		int result = -1;
		int validityDays = -1;
		int packTypeId = -1;
		int minTransferLimit = 0;
		int maxTransferLimit = 0;
		int convertedData = 0;
		int chargingAmount = 0;

		String dmcProductCode = "-2000";
		String conversionDataType = "";
		String filePath = "";
		CodeStatus status = null;
		String transactionId = "";
		String dmcValidityType = "";
		String ivr_base_path = "";
		Data_Object dataObject = new Data_Object();
		StringBuffer filePathBuffer = new StringBuffer();

		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.DATA_MACRO_CREDIT);
		dataObject.setAccType(ServiceTypes.DATA_MACRO_CREDIT);

		try {
			minTransferLimit = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_MIN_LIMIT));
			maxTransferLimit = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_MAX_LIMIT));

			conversionDataType = TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_DATA_TYPE);
			packTypeId = TSSJavaUtil.instance().getCacheParameters()
					.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION);
			dmcProductCode = TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_AB_PRODUCT_CODE);
			dmcValidityType = TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_VALIDITY_TYPE);
			chargingAmount = userDataBean.getBalToConvert();

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				ivr_base_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
				if (ivr_base_path.equalsIgnoreCase("") || ivr_base_path.equalsIgnoreCase("NA")
						|| ivr_base_path == null) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
							+ " >> (IVR) Base file path found is null or Empty or NA for MSISDN:["
							+ userDataBean.getMsisdn() + "].");
					userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
							.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + ResponseParameters.FAILURE);
					userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					return CodeStatus.FAILURE;
				}
			}

			// Setting default Conversion Data Type if Data Type is not found in allowed
			// DATA TYPE:[TB|GB|MB|KB]
			if (!conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_TB)
					&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_GB)
					&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_MB)
					&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_KB)) {
				logger.error("convertedDataType:[" + conversionDataType + "] not found in allowed Data Type:["
						+ MPCommonDataTypes.DATA_UNIT_TYPE_TB + "|" + MPCommonDataTypes.DATA_UNIT_TYPE_GB + "|"
						+ MPCommonDataTypes.DATA_UNIT_TYPE_MB + "|" + MPCommonDataTypes.DATA_UNIT_TYPE_KB
						+ "] for DMCP convertion so setting DEFAULT CONVERSION DATA TYPE:["
						+ MPCommonDataTypes.DATA_UNIT_TYPE_MB + "]");
				conversionDataType = MPCommonDataTypes.DATA_UNIT_TYPE_MB;
			}

			if (dmcValidityType == null || dmcValidityType.isEmpty() || dmcValidityType.equalsIgnoreCase("EXCEPTION")) {
				// Setting Default value
				dmcValidityType = MPCommonDataTypes.DMC_DEFAULT_VALIDITY_TYPE;
			}

			logger.info(userDataBean.getRequestId() + " >> (DMC-AB) minTransferLimit[" + minTransferLimit
					+ "] maxTransferLimit[" + maxTransferLimit + "] chargingAmount[" + chargingAmount
					+ "] conversionDataType [" + conversionDataType + "] packTypeId [" + packTypeId
					+ "] dmcProductCode [" + dmcProductCode + "] dmcValidityType [" + dmcValidityType + "] : msisdn ["
					+ userDataBean.getMsisdn() + "]");

			if (chargingAmount >= minTransferLimit && chargingAmount <= maxTransferLimit) {
				logger.info(userDataBean.getRequestId() + " >> (DMC-AB) Amount [" + chargingAmount
						+ "] is valid for Data Macro Credit Convertion.");
				dataObject.setServiceAmount(chargingAmount);
			} else {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00337")
						+ " >> (DMC-AB) Data macro credit amount based conversion FAILED because chargingAmount:["
						+ chargingAmount + "] does not lie between minTransferLimit:[" + minTransferLimit
						+ "] and maxTransferLimit:[" + maxTransferLimit + "].");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
						.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + ResponseParameters.FAILURE);

				if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_BAL_NOT_IN_RANGE + "_" + userDataBean.getLangId());

					// Setting tokens values
					filePath = filePath.replace(MPCommonDataTypes.TOKEN_MIN_AMOUNT, String.valueOf(minTransferLimit))
							.replace(MPCommonDataTypes.TOKEN_MAX_AMOUNT, String.valueOf(maxTransferLimit));
				} else if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
						|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
					filePathBuffer.append(ivr_base_path).append(userDataBean.getLangId()).append(File.separator)
							.append(IvrMenu.DMC_BALANCE_NOT_IN_RANGE_IVR);
					filePath = filePathBuffer.toString();
				}
				userDataBean.setFilePath(filePath);
				return CodeStatus.FAILURE;
			}

			// Now going to set convertedData
			convertedData = this.getConvertedDataForDMC(chargingAmount);

			if (convertedData < 0) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00345")
						+ " >> (DMC-AB) Data macro transfer FAILED because convertedData:[" + convertedData
						+ "] must be positive.");
				if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
						|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
					userDataBean.setFilePath(
							ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.DMC_FAILURE_IVR);
				} else {
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
				}
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
						.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + ResponseParameters.FAILURE);
				return CodeStatus.FAILURE;
			}

			if (MPCommonDataTypes.DATA_UNIT_TYPE_TB.equalsIgnoreCase(conversionDataType)) {
				dataObject.setCurrAcctChgAmt((long) convertedData * 1024 * 1024 * 1024 * 1024);
			} else if (MPCommonDataTypes.DATA_UNIT_TYPE_GB.equalsIgnoreCase(conversionDataType)) {
				dataObject.setCurrAcctChgAmt((long) convertedData * 1024 * 1024 * 1024);
			} else if (MPCommonDataTypes.DATA_UNIT_TYPE_MB.equalsIgnoreCase(conversionDataType)) {
				dataObject.setCurrAcctChgAmt((long) convertedData * 1024 * 1024);
			} else if (MPCommonDataTypes.DATA_UNIT_TYPE_KB.equalsIgnoreCase(conversionDataType)) {
				dataObject.setCurrAcctChgAmt((long) convertedData * 1024);
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00280")
						+ " >> Data transfer FAILED due to unsupported volume type [" + conversionDataType + "]");

				throw new Exception("unsupported volume type");
			}
			logger.debug(userDataBean.getRequestId() + " >> (DMC-AB) The converted data [" + convertedData + " "
					+ conversionDataType + "] going to pass to the charging jar after conversion is ["
					+ dataObject.getCurrAcctChgAmt() + "] where msisdn [" + userDataBean.getMsisdn() + "]");

			// setting validity days according to the configuration
			validityDays = TSSJavaUtil.instance().getCacheParameters().getTransferValidityDays(packTypeId,
					convertedData);
			if (validityDays <= 0) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00070")
						+ " >> (DMC-AB) no validity days configuration found for pack type [" + packTypeId
						+ "] and volume [" + userDataBean.getVolume() + "] so returning failure : " + "msisdn ["
						+ userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
						|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
					userDataBean.setFilePath(
							ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.DMC_FAILURE_IVR);
				} else {
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
				}

				userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
						.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + ResponseParameters.FAILURE);
				return CodeStatus.FAILURE;
			}

			// Setting validity days
			dataObject.setNb_day(validityDays);

			long currentTimeMS = new java.util.Date().getTime();
			transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >> (DMC-AB) Going to transfer data for user with charging"
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				dataObject.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				dataObject.setVolumeBalance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00154")
						+ "  >>charging testing is enable so using success : " + "msisdn [" + userDataBean.getMsisdn()
						+ "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId()
						+ " >> (DMC-AB) Data Macro Credit is successful with final result is [" + result + "]");

				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
						.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + result);

				if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMC_AB_SUCCESS + "_" + userDataBean.getLangId());

					// Setting token values in file path
					filePath = filePath.replace(MPCommonDataTypes.TOKEN_AMOUNT, String.valueOf(chargingAmount))
							.replace(MPCommonDataTypes.TOKEN_DATA, String.valueOf(convertedData))
							.replace(MPCommonDataTypes.TOKEN_VALIDITY_DAYS, String.valueOf(validityDays));

					if (validityDays > 1) {
						// Setting days in message as validity is more than 1 day.
						filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, MPCommonDataTypes.S);
					} else {
						// Setting days in message as validity is 1 day
						filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, "");
					}

				} else if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
						|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {

					filePathBuffer.append(ivr_base_path).append(userDataBean.getLangId()).append(File.separator)
							.append(IvrMenu.DMC_SUCCESS_1_IVR).append(TSSJavaUtil.FileSeparator)
							.append(TSSJavaUtil.instance().getNumberPrompt(String.valueOf(chargingAmount),
									userDataBean.getLangId(), ivr_base_path))
							.append(TSSJavaUtil.FileSeparator)
							.append(TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId()))
							.append(TSSJavaUtil.FileSeparator).append(ivr_base_path).append(userDataBean.getLangId())
							.append(File.separator).append(IvrMenu.DMC_SUCCESS_2_IVR).append(TSSJavaUtil.FileSeparator)
							.append(TSSJavaUtil.instance().getNumberPrompt(String.valueOf(convertedData),
									userDataBean.getLangId(), ivr_base_path))
							.append(TSSJavaUtil.FileSeparator).append(ivr_base_path).append(userDataBean.getLangId())
							.append(File.separator).append(IvrMenu.DMC_SUCCESS_3_IVR).append(TSSJavaUtil.FileSeparator)
							.append(TSSJavaUtil.instance().getNumberPrompt(String.valueOf(validityDays),
									userDataBean.getLangId(), ivr_base_path));

					if (validityDays > 1) {
						// Setting days in message as validity is more than 1 day.
						filePathBuffer.append(TSSJavaUtil.FileSeparator).append(ivr_base_path)
								.append(userDataBean.getLangId()).append(File.separator).append(IvrMenu.DAYS_IVR);
					} else {
						// Setting day in message as validity is 1 day
						filePathBuffer.append(TSSJavaUtil.FileSeparator).append(ivr_base_path)
								.append(userDataBean.getLangId()).append(File.separator).append(IvrMenu.DAY_IVR);
					}

					filePath = filePathBuffer.toString();
				}
				userDataBean.setFilePath(filePath);

				status = CodeStatus.SUCCESS;
			} else if (result == -2) {
				// Case of low main balance
				logger.info(userDataBean.getRequestId()
						+ " >> (DMC-AB) Data Macro Credit is  not successful (LOW MAIN BALANCE) with final result is ["
						+ result + "]");

				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
						.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + result);

				if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_LOW_BALANCE + "_" + userDataBean.getLangId());
					filePath = filePath.replace(MPCommonDataTypes.TOKEN_BALANCE,
							String.valueOf(userDataBean.getBalance()));
				} else if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
						|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
					filePath = ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.DMC_LOW_BALANCE_IVR;
				}
				userDataBean.setFilePath(filePath);

				status = CodeStatus.LOW_BALANCE;
			} else {
				// failure
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00341")
						+ " >> (DMC-AB) Data Macro Credit transfer FAILED final result is [" + result + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
						.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + result);
				if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId());
				} else if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
						|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
					filePath = ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.DMC_FAILURE_IVR;
				}
				userDataBean.setFilePath(filePath);
				status = CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> (DMC-AB) Exception occurred in macro data credit conversion for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION)
							+ ":" + ResponseParameters.FAILURE);

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				userDataBean.setFilePath(
						ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.DMC_FAILURE_IVR);
			} else {
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
			}

			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00401")
					+ " >> (DMC-AB) Exception occurred in data macro credit conversion for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION)
							+ ":" + ResponseParameters.FAILURE);

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				userDataBean.setFilePath(
						ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.DMC_FAILURE_IVR);
			} else {
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
			}

			status = CodeStatus.EXCEPTION_OCCURED;
		}

		DBOperations dbOps = new DBOperations();

		// Now maintaining charging logs
		ChargingLogsBean chgLogsBean = new ChargingLogsBean(userDataBean.getMsisdn(), userDataBean.getFmsisdn(),
				transactionId, packTypeId, dmcProductCode, chargingAmount, convertedData, validityDays,
				userDataBean.getSubType(), userDataBean.getResult(), userDataBean.getRequestId(), -1,
				conversionDataType, dmcValidityType, userDataBean.getShortCode(), userDataBean.getLangId(),
				userDataBean.getInterfaceUsed());

		if (status == CodeStatus.SUCCESS) {
			userDataBean.setVolume(convertedData);

			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, true);

			UserTransactionBean transactionBean = new UserTransactionBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getFmsisdn(), packTypeId, "NA", userDataBean.getLangId(), "NA", validityDays,
					dmcValidityType, userDataBean.getVolume(), "DMC",
					TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.MESSAGE_HEADER_DMCP_CONVERSION + "_" + userDataBean.getLangId()),
					userDataBean.getShortCode(), userDataBean.getLangId(), userDataBean.getInterfaceUsed(), "NA");
			dbOps.new LogsManager().maintainUserTransactionCDRS(transactionBean);
		} else
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, false);

		return status;

	}

	/**
	 * This method is used for (DMC) Data Macro Credit Service in which user can
	 * convert its main account balance into DATA according to the configurations.
	 * 
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return CodeStatus
	 */
	public CodeStatus dmcConversion(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId()
				+ " >> (DMC) Going to convert user balance by using Data Macro Credit Service with Interface ["
				+ userDataBean.getInterfaceUsed() + "] and actionType [" + userDataBean.getPackActionType() + "]");
		int result = -1;
		int validityDays = -1;
		int packTypeId = -1;
		int minTransferLimitVB = 0;
		int maxTransferLimitVB = 0;
		int minTransferLimitAB = 0;
		int maxTransferLimitAB = 0;
		int convertedData = 0;
		int chargingAmount = 0;
		String dmcProductCode = "-4000";
		String dmcAbProductCode = "-2000";
		String dmcVbProductCode = "-2001";
		String conversionDataType = "";
		String filePath = "";
		CodeStatus status = null;
		String transactionId = "";
		String dmcValidityType = "";

		Data_Object dataObject = new Data_Object();

		dataObject.setMsisdn(userDataBean.getMsisdn());
		dataObject.setServiceType(ServiceTypes.DATA_MACRO_CREDIT);
		dataObject.setAccType(ServiceTypes.DATA_MACRO_CREDIT);

		try {
			minTransferLimitVB = Integer
					.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_VB_MIN_LIMIT));
			maxTransferLimitVB = Integer
					.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_VB_MAX_LIMIT));
			minTransferLimitAB = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_MIN_LIMIT));
			maxTransferLimitAB = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_MAX_LIMIT));
			conversionDataType = TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_DATA_TYPE);
			packTypeId = TSSJavaUtil.instance().getCacheParameters()
					.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION);
			dmcVbProductCode = TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_VB_PRODUCT_CODE);
			dmcAbProductCode = TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_AB_PRODUCT_CODE);
			dmcValidityType = TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_VALIDITY_TYPE);

			logger.info(userDataBean.getRequestId() + " >> (DMC-VB) actionType [" + userDataBean.getPackActionType()
					+ "] minTransferLimitVB [" + minTransferLimitVB + "] maxTransferLimitVB [" + maxTransferLimitVB
					+ "] minTransferLimitAB [" + minTransferLimitAB + "] maxTransferLimitAB [" + maxTransferLimitAB
					+ "]  conversionDataType [" + conversionDataType + "] packTypeId [" + packTypeId
					+ "] dmcAbProductCode [" + dmcAbProductCode + "] dmcVbProductCode [" + dmcVbProductCode
					+ "] dmcValidityType [" + dmcValidityType + "] userDataBean [" + userDataBean.toString()
					+ "] msisdn [" + userDataBean.getMsisdn() + "]");

			if (userDataBean.getServiceDetail() != null || userDataBean.getServiceDetail().isEmpty()) {

				// Setting default Conversion Data Type if Data Type is not found in allowed
				// DATA TYPE:[TB|GB|MB|KB]
				if (!conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_TB)
						&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_GB)
						&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_MB)
						&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_KB)) {
					logger.error("convertedDataType:[" + conversionDataType + "] not found in allowed Data Type:["
							+ MPCommonDataTypes.DATA_UNIT_TYPE_TB + "|" + MPCommonDataTypes.DATA_UNIT_TYPE_GB + "|"
							+ MPCommonDataTypes.DATA_UNIT_TYPE_MB + "|" + MPCommonDataTypes.DATA_UNIT_TYPE_KB
							+ "] for DMCP convertion so setting DEFAULT CONVERSION DATA TYPE:["
							+ MPCommonDataTypes.DATA_UNIT_TYPE_MB + "]");
					conversionDataType = MPCommonDataTypes.DATA_UNIT_TYPE_MB;
				}

				if (dmcValidityType == null || dmcValidityType.isEmpty()
						|| dmcValidityType.equalsIgnoreCase("EXCEPTION")) {
					// Setting Default value
					dmcValidityType = MPCommonDataTypes.DMC_DEFAULT_VALIDITY_TYPE;
				}

				String[] selectedPackDetailArr = userDataBean.getServiceDetail()
						.split(MPCommonDataTypes.UNDERSCORE_SEPARATOR);
				logger.debug(userDataBean.getRequestId() + " >> (DMC) selectedPackDetailArr length ["
						+ selectedPackDetailArr.length + "] must be equal to 3.");
				if (selectedPackDetailArr.length == 3) {
					logger.info(userDataBean.getRequestId() + " >> (DMC) Balance to conver [" + selectedPackDetailArr[0]
							+ "] Data in MB [" + selectedPackDetailArr[1] + "] for Validity Days ["
							+ selectedPackDetailArr[2] + "]");
					chargingAmount = Integer.parseInt(selectedPackDetailArr[0].trim());
					convertedData = Integer.parseInt(selectedPackDetailArr[1].trim());
					validityDays = Integer.parseInt(selectedPackDetailArr[2].trim());
				} else {
					logger.error(userDataBean.getRequestId() + " >> (DMC) selectedPackDetailArr length ["
							+ selectedPackDetailArr.length + "] must be equal to 3 : msisdn ["
							+ userDataBean.getMsisdn() + "]");
					userDataBean.setResult(ResponseParameters.FAILURE);
					userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
							.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + ResponseParameters.FAILURE);

					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
					return CodeStatus.FAILURE;
				}

			} else {
				logger.error(userDataBean.getRequestId() + " >> (DMC) ServiceDetail [" + userDataBean.getServiceDetail()
						+ "] found null or Empty.");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
						.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
				return CodeStatus.FAILURE;
			}

			// Setting product code
			if (userDataBean.getPackActionType() == MPCommonDataTypes.DATA_MACRO_CREDIT_AMOUNT_BASED_ACTION_TYPE) {
				dmcProductCode = dmcAbProductCode;
			} else if (userDataBean
					.getPackActionType() == MPCommonDataTypes.DATA_MACRO_CREDIT_VOLUME_BASED_ACTION_TYPE) {
				dmcProductCode = dmcVbProductCode;
			} else {
				logger.error(userDataBean.getRequestId() + " >> Proper action type [" + userDataBean.getPackActionType()
						+ "] not found. So product code remains default : [" + dmcProductCode + "]");
			}

			logger.info(userDataBean.getRequestId() + " >> (DMC) Going to set values for chargingAmount["
					+ chargingAmount + "] convertedData [" + convertedData + "] validityDays [" + validityDays
					+ "] dmcProductCode [" + dmcProductCode + "]");

			// Checking service amount in case of Data Macro Credit Amount Based
			if ((userDataBean.getPackActionType() == MPCommonDataTypes.DATA_MACRO_CREDIT_AMOUNT_BASED_ACTION_TYPE)
					&& (chargingAmount < minTransferLimitAB || chargingAmount > maxTransferLimitAB)) {
				logger.warn(userDataBean.getRequestId() + " >> (DMC-AB) chargingAmount [" + chargingAmount
						+ "] must lie between minTransferLimitAB [" + minTransferLimitAB + "] maxTransferLimitAB ["
						+ maxTransferLimitAB + "] range actionType [" + userDataBean.getPackActionType() + "]. msisdn ["
						+ userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
						.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));

				return CodeStatus.FAILURE;
			}

			dataObject.setServiceAmount(chargingAmount);

			// Checking data in case of Data Macro Credit Volume Based
			if ((userDataBean.getPackActionType() == MPCommonDataTypes.DATA_MACRO_CREDIT_VOLUME_BASED_ACTION_TYPE)
					&& (convertedData < minTransferLimitVB || convertedData > maxTransferLimitVB)) {
				logger.warn(userDataBean.getRequestId() + " >> (DMC-VB) convertedData [" + convertedData
						+ "] must lie between minTransferLimitVB [" + minTransferLimitVB + "] maxTransferLimitVB ["
						+ maxTransferLimitVB + "] range. msisdn [" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
						.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + ResponseParameters.FAILURE);

				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));

				return CodeStatus.FAILURE;
			}

			if (MPCommonDataTypes.DATA_UNIT_TYPE_TB.equalsIgnoreCase(conversionDataType)) {
				dataObject.setCurrAcctChgAmt((long) convertedData * 1024 * 1024 * 1024 * 1024);
			} else if (MPCommonDataTypes.DATA_UNIT_TYPE_GB.equalsIgnoreCase(conversionDataType)) {
				dataObject.setCurrAcctChgAmt((long) convertedData * 1024 * 1024 * 1024);
			} else if (MPCommonDataTypes.DATA_UNIT_TYPE_MB.equalsIgnoreCase(conversionDataType)) {
				dataObject.setCurrAcctChgAmt((long) convertedData * 1024 * 1024);
			} else if (MPCommonDataTypes.DATA_UNIT_TYPE_KB.equalsIgnoreCase(conversionDataType)) {
				dataObject.setCurrAcctChgAmt((long) convertedData * 1024);
			} else {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00280")
						+ " >> Data transfer FAILED due to unsupported volume type [" + conversionDataType + "]");

				throw new Exception("unsupported volume type");
			}
			logger.debug(userDataBean.getRequestId() + " >> (DMC) The converted data [" + convertedData + " "
					+ conversionDataType + "] going to pass to the charging jar after conversion is ["
					+ dataObject.getCurrAcctChgAmt() + "]");

			if (validityDays <= 0) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00070")
						+ " >> (DMC) no validity days configuration found for pack type [" + packTypeId
						+ "] and volume [" + userDataBean.getVolume() + "] so returning failure : " + "msisdn ["
						+ userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
				userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
						.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + ResponseParameters.FAILURE);

				return CodeStatus.FAILURE;
			}

			// Setting Validity Days
			dataObject.setNb_day(validityDays);

			long currentTimeMS = new java.util.Date().getTime();
			transactionId = userDataBean.getMsisdn() + "" + currentTimeMS;
			dataObject.setTransId(transactionId);

			logger.info(userDataBean.getRequestId() + " >> (DMC) Going to transfer data for user with charging"
					+ " with data object [" + dataObject + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			TransferManager transferManager = new TransferManager();

			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {
				// charging testing is enable so sending success
				result = TSSJavaUtil.instance().getCacheParameters().getEnabledTestChargingResult();
				dataObject.setAcc_2000_balance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				dataObject.setVolumeBalance((int) TSSJavaUtil.instance().getCacheParameters().getTestingBalance());
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00154")
						+ "  >>charging testing is enable so using success : " + "msisdn [" + userDataBean.getMsisdn()
						+ "]");
			} else {
				// sending request to charging
				result = transferManager.doCharging(dataObject);
			}

			if (result == 1)// success
			{
				logger.info(userDataBean.getRequestId()
						+ " >> (DMC) Data Macro Credit is successful with final result is [" + result + "]");

				userDataBean.setResult(ResponseParameters.SUCCESS);
				userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
						.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + result);

				if (userDataBean.getPackActionType() == MPCommonDataTypes.DATA_MACRO_CREDIT_AMOUNT_BASED_ACTION_TYPE) {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMC_AB_SUCCESS + "_" + userDataBean.getLangId());
				} else if (userDataBean
						.getPackActionType() == MPCommonDataTypes.DATA_MACRO_CREDIT_VOLUME_BASED_ACTION_TYPE) {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMC_VB_SUCCESS + "_" + userDataBean.getLangId());
				} else {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMC_VB_SUCCESS + "_" + userDataBean.getLangId());
				}

				// Setting token values in file path
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_AMOUNT, String.valueOf(chargingAmount))
						.replace(MPCommonDataTypes.TOKEN_DATA, String.valueOf(convertedData))
						.replace(MPCommonDataTypes.TOKEN_VALIDITY_DAYS, String.valueOf(validityDays));

				if (validityDays > 1) {
					// Setting days in message as validity is more than 1 day.
					filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, MPCommonDataTypes.S);
				} else {
					// Setting days in message as validity is 1 day
					filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, "");
				}

				userDataBean.setFilePath(filePath);

				status = CodeStatus.SUCCESS;
			} else if (result == -2) {
				// Case of low main balance
				logger.info(userDataBean.getRequestId()
						+ " >> (DMC) Data Macro Credit is not successful (LOW MAIN BALANCE) with final result is ["
						+ result + "]");

				userDataBean.setResult(ResponseParameters.LOW_BALANCE);
				userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
						.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + result);
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMCP_LOW_BALANCE + "_" + userDataBean.getLangId());
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_BALANCE, String.valueOf(userDataBean.getBalance()));

				userDataBean.setFilePath(filePath);

				status = CodeStatus.FAILURE;
			} else {
				// failure
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00341")
						+ " >> (DMC) Data Macro Credit transfer FAILED final result is [" + result + "]");

				if (result == -41) {
					userDataBean.setResult(ResponseParameters.DMC_FAILURE_WITH_MACF);
				} else if (result == -42) {
					userDataBean.setResult(ResponseParameters.DMC_FAILURE_WITH_MACS);
				} else {
					userDataBean.setResult(ResponseParameters.FAILURE);
				}

				userDataBean.setPackPurchaseDetail(TSSJavaUtil.instance().getCacheParameters()
						.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION) + ":" + result);
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId());
				userDataBean.setFilePath(filePath);
				status = CodeStatus.FAILURE;
			}

		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> (DMC) Exception occurred while macro data credit conversion for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION)
							+ ":" + ResponseParameters.FAILURE);

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00401")
					+ " >> (DMC) Exception occurred while data macro credit conversion for user " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);
			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION)
							+ ":" + ResponseParameters.FAILURE);

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));

			status = CodeStatus.EXCEPTION_OCCURED;
		}

		DBOperations dbOps = new DBOperations();

		// Now maintaining charging logs
		ChargingLogsBean chgLogsBean = new ChargingLogsBean(userDataBean.getMsisdn(), userDataBean.getFmsisdn(),
				transactionId, packTypeId, dmcProductCode, chargingAmount, convertedData, validityDays,
				userDataBean.getSubType(), userDataBean.getResult(), userDataBean.getRequestId(), -1,
				conversionDataType, dmcValidityType, userDataBean.getShortCode(), userDataBean.getLangId(),
				userDataBean.getInterfaceUsed());

		if (status == CodeStatus.SUCCESS) {
			userDataBean.setVolume(convertedData);

			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, true);

			UserTransactionBean transactionBean = new UserTransactionBean(transactionId, userDataBean.getMsisdn(),
					userDataBean.getFmsisdn(), packTypeId, "NA", userDataBean.getLangId(), "NA", validityDays,
					dmcValidityType, userDataBean.getVolume(), "DMC",
					TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.MESSAGE_HEADER_DMCP_CONVERSION + "_" + userDataBean.getLangId()),
					userDataBean.getShortCode(), userDataBean.getLangId(), userDataBean.getInterfaceUsed(), "NA");
			dbOps.new LogsManager().maintainUserTransactionCDRS(transactionBean);
		} else
			dbOps.new LogsManager().maintainChargingLogs(chgLogsBean, false);

		return status;

	}

	/**
	 * This method is used to get the Data Macro Credit Amount Based details of
	 * requested amount.
	 * 
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return CodeStatus
	 */
	public CodeStatus getDMCAccountBasedDetails(UserDataBean userDataBean) {
		logger.info(userDataBean.getRequestId() + " >> (DMC-AB) inside getDMCAccountBasedDetails with Interface ["
				+ userDataBean.getInterfaceUsed() + "] userDataBean : " + userDataBean);
		int validityDays = -1;
		int packTypeId = -1;
		int minTransferLimit = 0;
		int maxTransferLimit = 0;
		int convertedData = -1;
		int amount = 0;

		StringBuffer filePathBuffer = new StringBuffer();
		String conversionDataType = "";
		String filePath = "";
		CodeStatus status = null;
		String dmcValidityType = "";
		String ivr_base_path = "";

		try {
			minTransferLimit = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_MIN_LIMIT));
			maxTransferLimit = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_MAX_LIMIT));
			conversionDataType = TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_DATA_TYPE);
			packTypeId = TSSJavaUtil.instance().getCacheParameters()
					.getPackTypeId(PackTypes.DATA_MACRO_CREDIT_CONVERSION);
			dmcValidityType = TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_VALIDITY_TYPE);
			amount = userDataBean.getBalToConvert();

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				ivr_base_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
				if (ivr_base_path.equalsIgnoreCase("") || ivr_base_path.equalsIgnoreCase("NA")
						|| ivr_base_path == null) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00316")
							+ " >> (DMC-AB)-(IVR) Base file path found is null or Empty or NA for MSISDN:["
							+ userDataBean.getMsisdn() + "].");
					userDataBean.setResult(ResponseParameters.BASE_FILE_PATH_NOT_FOUND_IVR);
					userDataBean.setFilePath(IvrMenu.NO_FILE_PATH_IVR);
					return CodeStatus.FAILURE;
				}
			}

			// Setting default Conversion Data Type if Data Type is not found in allowed
			// DATA TYPE:[TB|GB|MB|KB]
			if (!conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_TB)
					&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_GB)
					&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_MB)
					&& !conversionDataType.equalsIgnoreCase(MPCommonDataTypes.DATA_UNIT_TYPE_KB)) {
				logger.error("(DMC-AB) convertedDataType:[" + conversionDataType + "] not found in allowed Data Type:["
						+ MPCommonDataTypes.DATA_UNIT_TYPE_TB + "|" + MPCommonDataTypes.DATA_UNIT_TYPE_GB + "|"
						+ MPCommonDataTypes.DATA_UNIT_TYPE_MB + "|" + MPCommonDataTypes.DATA_UNIT_TYPE_KB
						+ "] for DMCP convertion so setting DEFAULT CONVERSION DATA TYPE:["
						+ MPCommonDataTypes.DATA_UNIT_TYPE_MB + "]");
				conversionDataType = MPCommonDataTypes.DATA_UNIT_TYPE_MB;
			}

			if (dmcValidityType == null || dmcValidityType.isEmpty() || dmcValidityType.equalsIgnoreCase("EXCEPTION")) {
				// Setting Default value
				dmcValidityType = MPCommonDataTypes.DMC_DEFAULT_VALIDITY_TYPE;
			}

			logger.info(userDataBean.getRequestId() + " >> (DMC-AB) minTransferLimit[" + minTransferLimit
					+ "] maxTransferLimit[" + maxTransferLimit + "] amount[" + amount + "] conversionDataType ["
					+ conversionDataType + "] packTypeId [" + packTypeId + "] dmcValidityType [" + dmcValidityType
					+ "] amount [" + amount + "] : msisdn [" + userDataBean.getMsisdn() + "]");

			if (amount >= minTransferLimit && amount <= maxTransferLimit) {
				logger.info(userDataBean.getRequestId() + " >> (DMC-AB) Amount [" + amount
						+ "] is valid for Data Macro Credit Convertion.");
			} else {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00335")
						+ " >> (DMC-AB) Data macro transfer FAILED because amount:[" + amount
						+ "] does not lie between minTransferLimit:[" + minTransferLimit + "] maxTransferLimit:["
						+ maxTransferLimit + "].");
				userDataBean.setResult(ResponseParameters.FAILURE);
				if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_BAL_NOT_IN_RANGE + "_" + userDataBean.getLangId());

					// Setting token values in file path
					filePath = filePath.replace(MPCommonDataTypes.TOKEN_MIN_AMOUNT, String.valueOf(minTransferLimit))
							.replace(MPCommonDataTypes.TOKEN_MAX_AMOUNT, String.valueOf(maxTransferLimit));
				} else if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
						|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
					filePath = ivr_base_path + userDataBean.getLangId() + File.separator
							+ IvrMenu.DMC_BALANCE_NOT_IN_RANGE_IVR;
				}

				userDataBean.setFilePath(filePath);
				return CodeStatus.FAILURE;
			}

			// Now going to set convertedData
			convertedData = this.getConvertedDataForDMC(amount);

			if (convertedData < 0) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00345")
						+ " >> (DMC-AB) Data macro transfer FAILED because convertedData[" + convertedData
						+ "] must be positive.");
				userDataBean.setResult(ResponseParameters.FAILURE);
				if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
						|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
					userDataBean.setFilePath(
							ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.DMC_FAILURE_IVR);
				} else {
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
				}
				return CodeStatus.FAILURE;
			}

			// setting validity days according to the configuration
			validityDays = TSSJavaUtil.instance().getCacheParameters().getTransferValidityDays(packTypeId,
					convertedData);
			if (validityDays <= 0) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00070")
						+ " >> (DMC-AB) no validity days configuration found for pack type [" + packTypeId
						+ "] and volume [" + convertedData + "] so returning failure : " + "msisdn ["
						+ userDataBean.getMsisdn() + "]");

				userDataBean.setResult(ResponseParameters.FAILURE);

				if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
						|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
					userDataBean.setFilePath(
							ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.DMC_FAILURE_IVR);
				} else {
					userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
				}
				return CodeStatus.FAILURE;
			}

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMC_AB_CONVERSION_DETAIL + "_" + userDataBean.getLangId());

				// Setting token values in file path
				filePath = filePath.replace(MPCommonDataTypes.TOKEN_AMOUNT, String.valueOf(amount))
						.replace(MPCommonDataTypes.TOKEN_DATA, String.valueOf(convertedData))
						.replace(MPCommonDataTypes.TOKEN_VALIDITY_DAYS, String.valueOf(validityDays));

				if (validityDays > 1) {
					// Setting days in message as validity is more than 1 day.
					filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, MPCommonDataTypes.S);
				} else {
					// Setting days in message as validity is 1 day
					filePath = filePath.replace(MPCommonDataTypes.TOKEN_S_APPENDER, "");
				}

			} else if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {

				filePathBuffer.append(ivr_base_path).append(userDataBean.getLangId()).append(File.separator)
						.append(IvrMenu.DMC_CONVERSION_DETAIL_1_WAV_IVR).append(TSSJavaUtil.FileSeparator)
						.append(TSSJavaUtil.instance().getNumberPrompt(String.valueOf(amount), userDataBean.getLangId(),
								ivr_base_path))
						.append(TSSJavaUtil.FileSeparator)
						.append(TSSJavaUtil.instance().getCurrencyPrompt(userDataBean.getLangId()))
						.append(TSSJavaUtil.FileSeparator).append(ivr_base_path).append(userDataBean.getLangId())
						.append(File.separator).append(IvrMenu.DMC_CONVERSION_DETAIL_2_WAV_IVR)
						.append(TSSJavaUtil.FileSeparator)
						.append(TSSJavaUtil.instance().getNumberPrompt(String.valueOf(convertedData),
								userDataBean.getLangId(), ivr_base_path))
						.append(TSSJavaUtil.FileSeparator).append(ivr_base_path).append(userDataBean.getLangId())
						.append(File.separator).append(IvrMenu.DMC_CONVERSION_DETAIL_3_WAV_IVR)
						.append(TSSJavaUtil.FileSeparator).append(TSSJavaUtil.instance().getNumberPrompt(
								String.valueOf(validityDays), userDataBean.getLangId(), ivr_base_path));

				if (validityDays > 1) {
					// Setting days in message as validity is more than 1 day.
					filePathBuffer.append(TSSJavaUtil.FileSeparator).append(ivr_base_path)
							.append(userDataBean.getLangId()).append(File.separator).append(IvrMenu.DAYS_IVR);
				} else {
					// Setting day in message as validity is 1 day
					filePathBuffer.append(TSSJavaUtil.FileSeparator).append(ivr_base_path)
							.append(userDataBean.getLangId()).append(File.separator).append(IvrMenu.DAY_IVR);
				}

				filePath = filePathBuffer.toString();
			}
			userDataBean.setFilePath(filePath);
			userDataBean.setResult(ResponseParameters.SUCCESS);
			status = CodeStatus.SUCCESS;
		} catch (NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> (DMC-AB) Exception occurred while getting data macro credit amount based converted data details msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				userDataBean.setFilePath(
						ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.DMC_FAILURE_IVR);
			} else {
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
			}
			status = CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00336")
					+ " >> (DMC-AB) Exception occurred while getting converted data details in Data Macro Credit Amount Based for msisdn ["
					+ userDataBean.getMsisdn() + "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				userDataBean.setFilePath(
						ivr_base_path + userDataBean.getLangId() + File.separator + IvrMenu.DMC_FAILURE_IVR);
			} else {
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.DMCP_FAILURE + "_" + userDataBean.getLangId()));
			}
			status = CodeStatus.EXCEPTION_OCCURED;
		}

		return status;

	}

	/**
	 * This method is used to get Converted Data value for (DMC-AB) Data Macro
	 * Credit Service.
	 * 
	 * @author SIDDHARTH
	 * @param amount
	 * @return converted data in DMC-AB
	 */
	private int getConvertedDataForDMC(int amount) {
		int convertedData = -1;
		double dataConversionConstant = 0;

		try {
			dataConversionConstant = Double
					.parseDouble(TSSJavaUtil.instance().getAppConfigParamValue(MPTags.DMC_CONVERSION_CONSTANT).trim());
			convertedData = (int) Math.round(amount * dataConversionConstant);
		} catch (Exception e) {
			logger.error(
					"\n(DMC-AB) Exception while getting Converted Data Value for Data Macro Credit service. amount:["
							+ amount + "]\n" + e);
			e.printStackTrace();
			return convertedData;
		}
		logger.debug("convertedData[" + convertedData + "] for amount[" + amount + "]");
		return convertedData;
	}

	/**
	 * This method is used to get the user's active data account details.
	 * 
	 * @param userDataBean
	 * @author SIDDHARTH
	 * @return status of the execution of this method means success, failure,
	 *         exception occurred etc.
	 */
	public CodeStatus getUserDataAccountDetails(UserDataBean userDataBean) {
		logger.debug(userDataBean.getRequestId() + " >> Going to get user's active data balance : " + "msisdn ["
				+ userDataBean.getMsisdn() + "]");

		CodeStatus status;
		Data_Object dataObject = new Data_Object();
		ArrayList<BalanceInfoBean> balList = new ArrayList<BalanceInfoBean>();
		List<UserAccountInfoBean> userAccountList = new ArrayList<>();
		Hashtable<String, PackDetailConfig> packDetailConfigs = null;
		ExpiringMap<String, List<UserAccountInfoBean>> userAccountInfoTable;
		int checkBalanceResponse = -1;
		byte isDiameterBasedEnable = 0;

		try {

			ThirdPartyRequest thirdPartyRequest = new ThirdPartyRequest();
			isDiameterBasedEnable = TSSJavaUtil.instance().getCacheParameters().getIsDiameterChargingEnable();
			if (TSSJavaUtil.instance().getCacheParameters().isChargingTestingEnable()) {

				// charging testing is enable so sending success
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00063")
						+ " >> charging testing is enable so sending success : " + "msisdn [" + userDataBean.getMsisdn()
						+ "]");

				BalanceInfoBean balBean = new BalanceInfoBean();
				balBean.setAccId("5199");
				balBean.setBalance(452369);
				balBean.setExpiryTime("20220711230826");
				balList.add(balBean);
				checkBalanceResponse = 1;

			} else {
				// sending request to charging
				dataObject.setMsisdn(userDataBean.getMsisdn().substring(MPCommonDataTypes.GLOBAL_COUNTRY_CODE_LENGTH));
				dataObject.setIndex(1);
				if (isDiameterBasedEnable == 1) {
					logger.info(userDataBean.getRequestId()
							+ " Diameter Based Charging is Enable, isDiameterBasedEnable [" + isDiameterBasedEnable
							+ "]. So going to check user account data through Diameter Charging Jar where MSISDN:["
							+ userDataBean.getMsisdn() + "]");
					checkBalanceResponse = thirdPartyRequest.checkBalanceDiameter(dataObject, balList);
				} else {
					logger.info(userDataBean.getRequestId()
							+ " Diameter Based Charging is not Enable, isDiameterBasedEnable [" + isDiameterBasedEnable
							+ "] . So going to check user account data where MSISDN:[" + userDataBean.getMsisdn()
							+ "]");
					checkBalanceResponse = thirdPartyRequest.checkBalance(dataObject, balList);
				}
			}

			if (checkBalanceResponse == 1) {
				// success
				logger.info(userDataBean.getRequestId() + " >> Check User Data Balance SUCCESS checkBalanceResponse ["
						+ checkBalanceResponse + "] with total active account found [" + balList.size() + "] : msisdn ["
						+ userDataBean.getMsisdn() + "]");

				packDetailConfigs = TSSJavaUtil.instance().getCacheParameters().getPackDetailConfigMap();

				if (packDetailConfigs == null || packDetailConfigs.isEmpty()) {
					logger.warn(userDataBean.getRequestId() + " >> No packs configuration found. packDetailConfigs ["
							+ packDetailConfigs + "] where Msisdn [" + userDataBean.getMsisdn() + "]");
				}

				for (BalanceInfoBean record : balList) {
					logger.debug(userDataBean.getRequestId() + " >> Going to process for account type ["
							+ record.getAccId() + "]");
					if (packDetailConfigs.containsKey(record.getAccId())) {
						UserAccountInfoBean userAccountInfoBean = new UserAccountInfoBean();
						userAccountInfoBean.setAcctId(record.getAccId());
						userAccountInfoBean.setBalance(String.valueOf(record.getBalance()));
						userAccountInfoBean.setExpiryTime(record.getExpiryTime());
						userAccountInfoBean.setAccName(packDetailConfigs.get(record.getAccId()).getAccountName());
						userAccountInfoBean.setProductName(packDetailConfigs.get(record.getAccId()).getProductName());
						userAccountInfoBean.setPackName(packDetailConfigs.get(record.getAccId()).getPackName());
						userAccountList.add(userAccountInfoBean);
						logger.debug(userDataBean.getRequestId() + " >> configured active AccountId found["
								+ userAccountInfoBean.getAcctId() + "].");
					}
				}

				// Collections.sort(userAccountList);
				Collections.sort(userAccountList, new AccountIdExpiryDataComparator());
				logger.info(userDataBean.getRequestId() + " >> Total Active Data Account found for user are ["
						+ userAccountList.size() + "]");

				// Now setting values in UserAccountInfoTable
				userAccountInfoTable = TSSJavaUtil.getUserAccountInfoTable();
				userAccountInfoTable.put(userDataBean.getMsisdn().trim(), userAccountList);

				logger.info(userDataBean.getRequestId() + " >> Size of userAccountInfoTable ["
						+ userAccountInfoTable.size() + "]");

				status = new ServicesManager().setUserActiveDataAccountDetails(userDataBean);

				if (status != CodeStatus.SUCCESS) {
					logger.warn(userDataBean.getRequestId()
							+ " >> response from setUserActiveDataAccountDetails is status [" + status
							+ "] so setting result [" + ResponseParameters.FAILURE + "] ");
					userDataBean.setResult(ResponseParameters.FAILURE);
					if (userDataBean.getFilePath() == null || userDataBean.getFilePath().isEmpty())
						userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
								UssdMenuNames.CHECK_BALANCE_FAILURE + "_" + userDataBean.getLangId()));
				}
			} else// failure
			{
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00064")
						+ " >> Check User Data Balance FAILURE due to not getting proper response: checkBalanceResponse["
						+ checkBalanceResponse + "] : msisdn [" + userDataBean.getMsisdn() + "]");
				userDataBean.setResult(ResponseParameters.FAILURE);
				userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.CHECK_BALANCE_FAILURE + "_" + userDataBean.getLangId()));
				return CodeStatus.FAILURE;
			}

			userDataBean.setResult(ResponseParameters.SUCCESS);
			return CodeStatus.SUCCESS;
		} catch (

		NullPointerException npe) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occurred while checking user balance " + ": msisdn ["
					+ userDataBean.getMsisdn() + "]", npe);

			userDataBean.setResult(ResponseParameters.FAILURE);

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.CHECK_BALANCE_FAILURE + "_" + userDataBean.getLangId()));

			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.CHECK_BALANCE) + ":-1");

			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00065")
					+ " >> Exception occurred while checking user balance " + ": msisdn [" + userDataBean.getMsisdn()
					+ "]", e);

			userDataBean.setResult(ResponseParameters.FAILURE);

			userDataBean.setFilePath(TSSJavaUtil.instance().getCacheParameters()
					.getUssdMenuString(UssdMenuNames.CHECK_BALANCE_FAILURE + "_" + userDataBean.getLangId()));

			userDataBean.setPackPurchaseDetail(
					TSSJavaUtil.instance().getCacheParameters().getPackTypeId(PackTypes.CHECK_BALANCE) + ":-1");

			return CodeStatus.EXCEPTION_OCCURED;
		}

	}

}
