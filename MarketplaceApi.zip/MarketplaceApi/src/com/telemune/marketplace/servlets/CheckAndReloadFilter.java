/**
 * @author MoHit
 * Created on - 07 March, 2017
 */
package com.telemune.marketplace.servlets;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import com.telemune.marketplace.util.TSSJavaUtil;

/**
 * This filter is called when request is received by this API
 * before start request processing
 * @author MoHit
 */
public class CheckAndReloadFilter implements Filter
{
	Logger logger = Logger.getLogger(CheckAndReloadFilter.class);
	
	@Override
	public void init(FilterConfig arg0) throws ServletException 
	{
		logger.info("Check and reload filter is started");
	}
    
	@Override
	/**
	 * Used to check for every request that do we need to reload the cache or not
	 */
	public void doFilter(ServletRequest req, ServletResponse resp,  
	    FilterChain chain) throws IOException, ServletException 
	{
	    logger.debug("Checking cache need to be reloaded or not");
	    TSSJavaUtil.checkAndRelaod();
	    chain.doFilter(req, resp);
	}  
	
	@Override
	public void destroy()
	{
		logger.info("Check and reload filter is destroyed");
	}  


}
