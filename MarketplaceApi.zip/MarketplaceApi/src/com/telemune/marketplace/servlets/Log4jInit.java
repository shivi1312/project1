/**
 * @author MoHit
 * Created on - 10 Feb, 2017
 */

package com.telemune.marketplace.servlets;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.xml.DOMConfigurator;

import com.telemune.marketplace.util.TSSJavaUtil;

/**
 * This class is used to initialize the logging details using marketplaceApi_config.xml
 * @author MoHit
 */
public class Log4jInit extends HttpServlet {
	
	/**
	 * serialVersionUID used for serialization
	 */
	private static final long serialVersionUID = -5040371953475869692L;
	
	
	@Override
	/**
	 * This method is used to initialize the logging details using marketplaceApi_config.xml
	 * and to create the object of TSSJavaUtil first time to load the cache
	 */
	public void init() {  
		//String prefixPath =  getServletContext().getRealPath("/");
		//System.out.println("inside init() of Log4j >> prefix path for configuration file is ["+prefixPath+"]");
		String fileName = getInitParameter("log4j-init-file");
		//System.out.println("inside init() of Log4j >> file name of configuration file is ["+fileName+"]");
		String logFileName = System.getenv("HOME")+"/.config/property/"+fileName;
		if(fileName != null) {
			//DOMConfigurator.configureAndWatch(prefixPath+"/WEB-INF/classes/"+fileName);
			System.out.println("Log File Path [ "+logFileName+" ]");
			DOMConfigurator.configureAndWatch(logFileName);
		}
		//creating instance of TSSJavautil
		String propFileName=getServletContext().getInitParameter("PROPERTY_FILE_NAME");
		TSSJavaUtil.instance(propFileName);
	}
	
	@Override
	/**
	 * This method is used to destroy the older connection pool and is called
	 * when this servlet is destroyed 
	 */
	public void destroy()
	{
		System.out.println("MarketplaceApi - destroy() of Log4jInit >> Destroying older connection pool");
		TSSJavaUtil.instance().getConnPool().destroyConnectionPool();
		System.out.println("MarketplaceApi - destroy() of Log4jInit >> Destroyed older connection pool");
	}
}
