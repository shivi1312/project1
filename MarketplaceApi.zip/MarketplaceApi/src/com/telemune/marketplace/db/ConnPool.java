/**
 * @author MoHit
 * Created on - 10 Feb, 2017
 */
package com.telemune.marketplace.db;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.mchange.v2.c3p0.DataSources;
import com.telemune.marketplace.util.TSSJavaUtil;

/**
 * This class is used to create connection pool to connect with database
 * @author MoHit
 */
public class ConnPool {

	/**
	 * Used for printing logs in this class
	 */
	Logger logger=Logger.getLogger(ConnPool.class);
	
	/**
	 * used to hold the ConnectionPool object
	 */
	private ComboPooledDataSource cpds = null;
	
	/**
	 * This method is used to make a connection pool with database using the parameters passed into it
	 * @param driver
	 * @param url
	 * @param username
	 * @param passwd
	 * @param minpoolsize
	 * @param maxpoolsize
	 * @param Accomodation
	 * @return true is pool is created else false
	 */
	public boolean makePool(String driver,String url,String username,String passwd,int minpoolsize,int maxpoolsize,int Accomodation, int maxIdleTime)
	{
          try
          {
        	  cpds=new ComboPooledDataSource();
        	  cpds.setDriverClass(driver);
              cpds.setJdbcUrl(url);
              cpds.setUser(username);
              cpds.setPassword(passwd);
              cpds.setMaxPoolSize(maxpoolsize);
              cpds.setMinPoolSize(minpoolsize);
              cpds.setAcquireIncrement(Accomodation);
              cpds.setMaxIdleTime(maxIdleTime);
              return true;
          }
          catch (PropertyVetoException e) {
        	  logger.error(TSSJavaUtil.getLogInitial("90029")+" >> Error in Making Connection Pool ",e);
        	  return false;
          }
          catch(NullPointerException npe)
          {
                  logger.error(TSSJavaUtil.getLogInitial("90003")+"Error in Making Connection Pool, cpds:["+cpds+"] may be null",npe);
                  return false;
          }
          catch(Exception exp)
          {
                  logger.error(TSSJavaUtil.getLogInitial("00058")+"Error in Making Connection Pool ",exp);
                  return false;
          }
         
	}
  
	/**
	 * This method is used to get the connection from connection pool
	 * @return connection object
	 */
	public Connection getConnection()
	{
		Connection con=null;
		try{
			con= cpds.getConnection();
		}
		catch(NullPointerException npe)
        {
                logger.error(TSSJavaUtil.getLogInitial("90003")+"NullPointerException occurred, cpds:["+cpds+"]",npe);
        }
		catch(Exception e)
		{
			logger.error(TSSJavaUtil.getLogInitial("00059")+">> Exception occurred while creating connection ",e);
		}
		return con;
	}

	/**
	 * Used to destroy the connection pool
	 * @return true if destroyed successfully
	 */
	public boolean destroyConnectionPool()
	{
		if(cpds!=null)
		{
			try{
				DataSources.destroy(cpds);
			}
			catch(SQLException sqlE){
				logger.error(TSSJavaUtil.getLogInitial("90001")+">> SQLException occured while destroying connection pool ",sqlE);
				return false;
			}
			catch(Exception e)
            {
                    logger.error(TSSJavaUtil.getLogInitial("00060")+"Exception occured while destroying connection pool ",e);
                    return false;
            }
			return true;
		}
		else
		{
			logger.info(">> connection pool is not initialized yet, so not destroying");
			return true;
		}
	}
	
}
