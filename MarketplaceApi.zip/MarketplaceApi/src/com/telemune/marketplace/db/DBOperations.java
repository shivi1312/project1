/**
 * @author MoHit
 * Created on - 10 Feb, 2017
 */
package com.telemune.marketplace.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.telemune.marketplace.beans.ChargingLogsBean;
import com.telemune.marketplace.beans.MsisdnRange;
import com.telemune.marketplace.beans.PackBean;
import com.telemune.marketplace.beans.PackTypeBean;
import com.telemune.marketplace.beans.PromoPackBean;
import com.telemune.marketplace.beans.ServiceCharge;
import com.telemune.marketplace.beans.ShortCodeMapping;
import com.telemune.marketplace.beans.TransferValidity;
import com.telemune.marketplace.beans.UserDataBean;
import com.telemune.marketplace.beans.UserPackPurchaseBean;
import com.telemune.marketplace.beans.UserProfileBean;
import com.telemune.marketplace.beans.UserTransactionBean;
import com.telemune.marketplace.beans.VirtualCodeMapping;
import com.telemune.marketplace.util.CodeStatus;
import com.telemune.marketplace.util.MPCommonDataTypes;
import com.telemune.marketplace.util.SMSTemplateIDs;
import com.telemune.marketplace.util.ServiceTypes;
import com.telemune.marketplace.util.TSSJavaUtil;

import FileBaseLogging.FileLogWriter;

/**
 * This class is used to perform the database operations select, insert etc
 * queries are performed by this class for the other classes that uses this
 * class. It has many functions like loads the data from database to cache
 * parameters, inserts entry into database to maintain logs, inserts entry into
 * database to send SMS etc.
 * 
 * @author MoHit
 */
public class DBOperations {
	/**
	 * Used for printing logs in this class
	 */
	private static Logger logger = Logger.getLogger(DBOperations.class);

	public class CacheLoader {
		/**
		 * Used to load MSISDN ranges from database into cache, MSISDN those comes under
		 * any of these ranges will only be allowed to access this API
		 * 
		 * @param msisdnRangeList
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus loadMsisdnRanges(ArrayList<MsisdnRange> msisdnRangeList, Connection con) {
			logger.info("loadMsisdnRanges() >> Loading all MSISDN ranges from operator subscriber: initial list is ["
					+ msisdnRangeList + "] and database connection is [" + con + "]");

			PreparedStatement pstmt = null;
			ResultSet rs = null;

			if (msisdnRangeList == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			// loading details from operator subscriber table
			try {
				pstmt = con.prepareStatement(DataBaseQueries.LOAD_MSISDN_RANGES);
				logger.debug("loadMsisdnRanges() >> loading operator ranges query ["
						+ DataBaseQueries.LOAD_MSISDN_RANGES + "]");
				rs = pstmt.executeQuery();

				MsisdnRange range = null;
				while (rs.next()) {
					range = new MsisdnRange(rs.getString("STARTS_AT"), rs.getString("ENDS_AT"),
							rs.getString("COUNTRY_CODE"));
					logger.debug("loadMsisdnRanges() >> range adding " + range);
					msisdnRangeList.add(range);
				}

				logger.info("loadMsisdnRanges() >> msisdn ranges loaded from operator subscriber are ["
						+ msisdnRangeList + "]");
			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while loading MSISDN ranges from database", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading MSISDN ranges from database, pstmt:[" + pstmt
						+ "] rs:[" + rs + "] may be null", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(TSSJavaUtil.getLogInitial("00031")
						+ " >> Exception occurred while loading MSISDN ranges from database", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00032") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;

		}// loadMsisdnRanges() ends

		/**
		 * Used to load All available packs from database into cache
		 * 
		 * @param availablePacksMap
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus loadAvailablePacks(HashMap<String, ArrayList<PackBean>> availablePacksMap, Connection con) {
			logger.info("loadAvailablePacks() >> Loading all available packs from Pack_Master: initial list is ["
					+ availablePacksMap + "] and database connection is [" + con + "]");

			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (availablePacksMap == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			ArrayList<PackBean> packList = null;
			ArrayList<PackBean> packListForBothSubTypes = new ArrayList<PackBean>();
			PackBean packBean = null;

			String prevAvailablePackKey = "-99_-99_N";

			// loading details from pack_master table
			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_ALL_AVAILABLE_PACKS);
				String type = "N";
				logger.debug("loadAvailablePacks() >> loading all available packs query ["
						+ DataBaseQueries.LOAD_ALL_AVAILABLE_PACKS + "]");
				rs = stmt.executeQuery();
				String currAvailablePackKey = null;
				while (rs.next()) {
					if ("B".equalsIgnoreCase(rs.getString("SUB_TYPE"))) {
						packBean = new PackBean();
						setPackBean(packBean, rs, type);
						packListForBothSubTypes.add(packBean);
					} else {
						currAvailablePackKey = rs.getInt("PACK_TYPE") + "_" + rs.getByte("LANGUAGE_ID") + "_"
								+ rs.getString("SUB_TYPE").toUpperCase();
						if (currAvailablePackKey.equalsIgnoreCase(prevAvailablePackKey)) {
							packBean = new PackBean();
							setPackBean(packBean, rs, type);
							packList.add(packBean);
							availablePacksMap.put(currAvailablePackKey, packList);
							prevAvailablePackKey = currAvailablePackKey; // Y
						} else {
							packBean = new PackBean();
							packList = new ArrayList<PackBean>();
							setPackBean(packBean, rs, type);
							packList.add(packBean);
							availablePacksMap.put(currAvailablePackKey, packList);
							prevAvailablePackKey = currAvailablePackKey;
						}

						logger.debug(">>>>>> availablePacksMap for key:[" + currAvailablePackKey + "] is : "
								+ availablePacksMap.get(currAvailablePackKey));
					}

				}

				ArrayList<PackBean> list = null;
				// now loading packs for both sub types
				if (packListForBothSubTypes.size() > 0) {
					logger.info("loadAvailablePacks() >> now loading packs for both subtypes, total found ["
							+ packListForBothSubTypes.size() + "]");
					for (int i = 0; i < packListForBothSubTypes.size(); i++) {
						packBean = packListForBothSubTypes.get(i);

						// for prepaid
						currAvailablePackKey = packBean.getPackTypeId() + "_" + packBean.getLangId() + "_P";

						if (availablePacksMap.containsKey(currAvailablePackKey)) {
							list = availablePacksMap.get(currAvailablePackKey);
							list.add(packBean);
							Collections.sort(list);
						} else {
							packList = new ArrayList<PackBean>();
							packList.add(packBean);
							availablePacksMap.put(currAvailablePackKey, packList);
						}

						// for postpaid
						currAvailablePackKey = packBean.getPackTypeId() + "_" + packBean.getLangId() + "_O";

						if (availablePacksMap.containsKey(currAvailablePackKey)) {
							list = availablePacksMap.get(currAvailablePackKey);
							list.add(packBean);
							Collections.sort(list);
						} else {
							packList = new ArrayList<PackBean>();
							packList.add(packBean);
							availablePacksMap.put(currAvailablePackKey, packList);
						}

					}
				}

				logger.info(
						"loadAvailablePacks() >> Total keys loaded from pack master are [" + availablePacksMap + "]");
				logger.debug("loadAvailablePacks() >> available packs loaded from pack master are [" + availablePacksMap
						+ "]");
			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while loading all available packs from database", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading all available packs from database, stmt:["
						+ stmt + "] or rs:[" + rs + "] may be null", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(TSSJavaUtil.getLogInitial("00033")
						+ " >> Exception occurred while loading all available packs from database", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00034") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;
		}// loadAvailablePacks() ends

		// Function Added by AbhiShek Rana for loading lowbalance pack on 23
		// January 2018.
		/**
		 * Used to load All available LowBalance packs from database into cache
		 * 
		 * @param availableLowBalancePacksMap
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus loadAvailableLowBalancePacks(HashMap<String, ArrayList<PackBean>> availableLowBalancePacksMap,
				Connection con) {
			logger.info(
					"loadAvailablePacks() >> Loading all available low balance packs from Pack_Master: initial list is ["
							+ availableLowBalancePacksMap + "] and database connection is [" + con + "]");

			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (availableLowBalancePacksMap == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			ArrayList<PackBean> packList = null;
			ArrayList<PackBean> packListForBothSubTypes = new ArrayList<PackBean>();
			PackBean packBean = null;

			String prevAvailablePackKey = "-99_-99_N";

			// loading details from pack_master table
			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_ALL_LOW_BALANCE_AVAILABLE_PACKS);
				String type = "L";
				logger.debug("loadAvailablePacks() >> loading all available packs query ["
						+ DataBaseQueries.LOAD_ALL_LOW_BALANCE_AVAILABLE_PACKS + "]");
				rs = stmt.executeQuery();
				String currAvailablePackKey = null;
				while (rs.next()) {
					if ("B".equalsIgnoreCase(rs.getString("SUB_TYPE"))) {
						packBean = new PackBean();
						setPackBean(packBean, rs, type);
						packListForBothSubTypes.add(packBean);
					} else {
						currAvailablePackKey = rs.getInt("PACK_TYPE") + "_" + rs.getByte("LANGUAGE_ID") + "_"
								+ rs.getString("SUB_TYPE").toUpperCase();
						if (currAvailablePackKey.equalsIgnoreCase(prevAvailablePackKey)) {
							packBean = new PackBean();
							setPackBean(packBean, rs, type);
							packList.add(packBean);
							availableLowBalancePacksMap.put(currAvailablePackKey, packList);
							prevAvailablePackKey = currAvailablePackKey;
						} else {
							packBean = new PackBean();
							packList = new ArrayList<PackBean>();
							setPackBean(packBean, rs, type);
							packList.add(packBean);
							availableLowBalancePacksMap.put(currAvailablePackKey, packList);
							prevAvailablePackKey = currAvailablePackKey;
						}
					}
				}

				ArrayList<PackBean> list = null;
				// now loading packs for both sub types
				if (packListForBothSubTypes.size() > 0) {
					logger.info("loadAvailableLowBalancePacks() >> now loading packs for both subtypes, total found ["
							+ packListForBothSubTypes.size() + "]");
					for (int i = 0; i < packListForBothSubTypes.size(); i++) {
						packBean = packListForBothSubTypes.get(i);

						// for prepaid
						currAvailablePackKey = packBean.getPackTypeId() + "_" + packBean.getLangId() + "_P";

						if (availableLowBalancePacksMap.containsKey(currAvailablePackKey)) {
							list = availableLowBalancePacksMap.get(currAvailablePackKey);
							list.add(packBean);
							Collections.sort(list);
						} else {
							packList = new ArrayList<PackBean>();
							packList.add(packBean);
							availableLowBalancePacksMap.put(currAvailablePackKey, packList);
						}

						// for postpaid
						currAvailablePackKey = packBean.getPackTypeId() + "_" + packBean.getLangId() + "_O";

						if (availableLowBalancePacksMap.containsKey(currAvailablePackKey)) {
							list = availableLowBalancePacksMap.get(currAvailablePackKey);
							list.add(packBean);
							Collections.sort(list);
						} else {
							packList = new ArrayList<PackBean>();
							packList.add(packBean);
							availableLowBalancePacksMap.put(currAvailablePackKey, packList);
						}

					}
				}

				logger.info("loadAvailableLowBalancePacks() >> Total keys loaded from pack master are ["
						+ availableLowBalancePacksMap + "]");
				logger.debug("loadAvailableLowBalancePacks() >> available packs loaded from pack master are ["
						+ availableLowBalancePacksMap + "]");
			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while loading all LowBalance available packs from database", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading all LowBalance available packs from database, stmt:["
						+ stmt + "] or rs:[" + rs + "] may be null", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(
						TSSJavaUtil.getLogInitial("00033")
								+ " >> Exception occurred while loading all LowBalance available packs from database",
						e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00034") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;
		}// loadAvailableLowBalancePacks() ends

		/**
		 * Used to load All Error Codes and corresponding error strings/menus from database 
		 * These error string will be sent to user when corresponding error occurred while 
		 * pack purchasing
		 * 
		 * @param errorCodesMenuMap
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus loadErrorCodesMenuMap(HashMap<String, String> errorCodesMenuMap, Connection con) {
			logger.info("loadErrorCodesMenuMap() >> Loading all Error Codes menu string from database : initial map is ["
					+ errorCodesMenuMap + "] and database connection is [" + con + "]");

			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (errorCodesMenuMap == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_ERROR_CODES_MENU_MAP);
				logger.debug(
						"loadErrorCodesMenu() >> loading Error Codes Menu String query [" + DataBaseQueries.LOAD_ERROR_CODES_MENU_MAP + "]");
				rs = stmt.executeQuery();
				while (rs.next()) {
					errorCodesMenuMap.put(rs.getString("ERR_CODE") + "_" + rs.getByte("LANG_ID"),
							rs.getString("ERR_STR"));
				}

				logger.info(
						"loadErrorCodesMenu() >> All Error Codes Menus String are loaded from database [" + errorCodesMenuMap + "]");
			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while loading Error Codes Menus String from database", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading Error Codes Menus String from database, stmt:[" + stmt
						+ "] or rs:[" + rs + "] may be null ", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(TSSJavaUtil.getLogInitial("00035")
						+ " >> Exception occurred while loading Error Codes Menus String from database", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00036") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;
		}// loadErrorCodeMenus() ends
		
		
		/**
		 * Used to load All USSD menus from database these menus are used to send
		 * response to user when user sends request with USSD
		 * 
		 * @param ussdMenuDetailsMap
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus loadUSSDMenus(HashMap<String, String> ussdMenuDetailsMap, Connection con) {
			logger.info("loadUSSDMenus() >> Loading all USSD Menus from database : initial map is ["
					+ ussdMenuDetailsMap + "] and database connection is [" + con + "]");

			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (ussdMenuDetailsMap == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_USS_MENUS);
				logger.debug(
						"loadUSSDMenus() >> loading all USSD Menus query [" + DataBaseQueries.LOAD_USS_MENUS + "]");
				rs = stmt.executeQuery();
				while (rs.next()) {
					ussdMenuDetailsMap.put(rs.getString("MENU_NAME") + "_" + rs.getByte("LANGUAGE_ID"),
							rs.getString("MENU_STRING"));
				}

				logger.info(
						"loadUSSDMenus() >> All USSD Menus are loaded from database are [" + ussdMenuDetailsMap + "]");
			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while loading USSD Menus from database", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading USSD Menus from database, stmt:[" + stmt
						+ "] or rs:[" + rs + "] may be null ", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(TSSJavaUtil.getLogInitial("00035")
						+ " >> Exception occurred while loading USSD Menus from database", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00036") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;
		}// loadUSSDMenus() ends

		/**
		 * Used to load All white-listed and blacklisted MSISDNs means all the MSISDNs
		 * that are white-listed or blacklisted to this API
		 * 
		 * @param whiteListedMSISDNs
		 * @param blackListedMSISDNs
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus loadWhiteBlacklistedMSISDNs(ArrayList<String> whiteListedMSISDNs,
				ArrayList<String> blackListedMSISDNs, Connection con) {
			logger.info(
					"loadWhiteBlacklistedMSISDNs() >> Loading all whitelisted and blacklisted MSISDNs from database : initial "
							+ "whiteListedMSISDNs [" + whiteListedMSISDNs + "] and blackListedMSISDNs ["
							+ blackListedMSISDNs + "] and database connection is [" + con + "]");

			// Statement stmt = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (whiteListedMSISDNs == null || blackListedMSISDNs == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_WHITE_BLACK_LISTED_MSISDNS);
				logger.debug("loadWhiteBlacklistedMSISDNs() >> loading all USSD Menus query ["
						+ DataBaseQueries.LOAD_WHITE_BLACK_LISTED_MSISDNS + "]");
				rs = stmt.executeQuery();
				while (rs.next()) {
					if ("W".equalsIgnoreCase(rs.getString("TYPE"))) {
						whiteListedMSISDNs.add(rs.getString("MSISDN"));
					} else if ("B".equalsIgnoreCase(rs.getString("TYPE"))) {
						blackListedMSISDNs.add(rs.getString("MSISDN"));
					}
				}

				logger.info("loadWhiteBlacklistedMSISDNs() >> All whitelisted MSISDNs are [" + whiteListedMSISDNs
						+ "] blacklisted MSISDN are [" + blackListedMSISDNs + "]");
			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> Exception occurred while loading whitelisted and blacklisted MSISDNs from database",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading whitelisted and blacklisted MSISDNs from database, stmt:["
						+ stmt + "] or rs:[" + rs + "] may be null", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(TSSJavaUtil.getLogInitial("00037")
						+ " >> Exception occurred while loading whitelisted and blacklisted MSISDNs from database", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00038") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;
		}// loadWhiteBlacklistedMSISDNs() ends

		/**
		 * Used to load all available pack types and puts them into two cache variables
		 * in first one key is pack type ID and value is its description that is used to
		 * show that which type of packs user is seeing and in second one key is name of
		 * pack type and value is its ID that is used to get the pack type ID for any
		 * particular pack type
		 * 
		 * @param availablePackTypes
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus loadAvailablePackTypes(HashMap<String, Integer> availablePackTypeIDs,
				HashMap<Integer, String> availablePackTypes,
				HashMap<Integer, Integer> availablePackTypeParallelEnableMap, Connection con) {
			logger.info("loadAvailablePackTypes() >> Loading all available pack types from database : initial "
					+ "availablePackTypes [" + availablePackTypes + "] and database connection is [" + con + "]");

			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (availablePackTypes == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_AVAILABLE_PACK_TYPES);
				logger.debug("loadAvailablePackTypes() >> loading all pack types query ["
						+ DataBaseQueries.LOAD_AVAILABLE_PACK_TYPES + "]");
				rs = stmt.executeQuery();
				while (rs.next()) {
					if (rs.getInt("PARENT_PACK_TYPE") == -2) {
						availablePackTypeIDs.put(rs.getString("PACK_TYPE_NAME"), rs.getInt("PACK_TYPE"));
					}
					availablePackTypes.put(rs.getInt("PACK_TYPE"), rs.getString("DESCRIPTION"));
					availablePackTypeParallelEnableMap.put(rs.getInt("PACK_TYPE"), rs.getInt("PARALLEL_PACK_ENABLE"));
				}

				logger.info("loadAvailablePackTypes() >> All availablePackTypes are [" + availablePackTypes
						+ "] and availablePackTypeIDs are [" + availablePackTypeIDs + "]");
			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while loading all pack types from database", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading all pack types, stmt:[" + stmt + "] or rs:["
						+ rs + "] may be null", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(TSSJavaUtil.getLogInitial("00039")
						+ " >> Exception occurred while loading all pack types from database", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00040") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;
		}// loadAvailablePackTypes() ends

		/**
		 * Used to load product codes and service charge details, these details are
		 * about the packs means for any pack what is the product code, how much service
		 * charge is to be deducted, how much volume is to avail for how much validity
		 * etc
		 * 
		 * @param srvcChargeDetails
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus loadProductCodesAndServiceChargeDetails(HashMap<Integer, ServiceCharge> srvcChargeDetails,
				Connection con) {
			logger.info(
					"loadProductCodesAndServiceChargeDetails() >> Loading all product codes and service charge details : initial "
							+ "srvcChargeDetails [" + srvcChargeDetails + "] and database connection is [" + con + "]");

			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (srvcChargeDetails == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_PROD_CODE_AND_SERV_CHARGE);
				logger.debug(
						"loadProductCodesAndServiceChargeDetails() >> loading all product codes and service charges query ["
								+ DataBaseQueries.LOAD_PROD_CODE_AND_SERV_CHARGE + "]");
				rs = stmt.executeQuery();

				while (rs.next()) {
					srvcChargeDetails.put(rs.getInt("PACK_ID"),
							new ServiceCharge(rs.getDouble("SERVICE_CHARGE"), rs.getString("PRODUCT_CODE"),
									rs.getInt("VOLUME"), rs.getString("VOLUME_TYPE"), rs.getInt("VALIDITY_DAYS"),
									rs.getString("VALIDITY_TYPE")));
				}

				logger.info("loadProductCodesAndServiceChargeDetails() >> srvcChargeDetails loaded are ["
						+ srvcChargeDetails + "]");
			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while loading product codes and service charge details from database",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading product codes and service charge details, stmt:["
						+ stmt + "] or rs:[" + rs + "] may be null", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(TSSJavaUtil.getLogInitial("00041")
						+ " >> Exception occurred while loading product codes and service charge details from database",
						e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00042") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;
		}// loadProductCodesAndServiceChargeDetails() ends

		/**
		 * Used to load transfer validity configuration means if any user transfer
		 * talk-time to his/her friend then for how much validity that talk-time will be
		 * transfered to the user is checked from the cache that is loaded by this
		 * method
		 * 
		 * @param transferValidityConfig
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus loadTransferValidityConfig(
				HashMap<Integer, ArrayList<TransferValidity>> transferValidityConfig, Connection con) {
			logger.info(
					"loadTransferValidityConfig() >> Loading all transfer validity configuration from database : initial "
							+ "transferValidityConfig [" + transferValidityConfig + "] and database connection is ["
							+ con + "]");

			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (transferValidityConfig == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_TRANSFER_VALIDITY_CONFIG);
				logger.debug("loadTransferValidityConfig() >> loading all transfer validity configuration query ["
						+ DataBaseQueries.LOAD_TRANSFER_VALIDITY_CONFIG + "]");
				rs = stmt.executeQuery();

				int previousType = -1;
				ArrayList<TransferValidity> validityConfigList = null;
				while (rs.next()) {
					if (rs.getInt("TYPE") != previousType)// means first
															// iteration or new
															// pack type
															// received
					{
						validityConfigList = new ArrayList<TransferValidity>();
						validityConfigList.add(new TransferValidity(rs.getInt("MIN_VOLUME"), rs.getInt("MAX_VOLUME"),
								rs.getShort("VALIDITY_DAYS")));
						transferValidityConfig.put(rs.getInt("TYPE"), validityConfigList);
						previousType = rs.getInt("TYPE");
					} else {
						validityConfigList.add(new TransferValidity(rs.getInt("MIN_VOLUME"), rs.getInt("MAX_VOLUME"),
								rs.getShort("VALIDITY_DAYS")));
					}
				}

				logger.info("loadTransferValidityConfig() >> transferValidityConfig loaded are ["
						+ transferValidityConfig + "]");
			} catch (SQLException sqle) {
				logger.error(
						TSSJavaUtil.getLogInitial("90001")
								+ " >> Exception occurred while loading transfer validity configuration from database",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading transfer validity configuration, stmt:["
						+ stmt + "] rs:[" + rs + "] may be null ", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(
						TSSJavaUtil.getLogInitial("00043")
								+ " >> Exception occurred while loading transfer validity configuration from database",
						e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00044") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;
		}// loadTransferValidityConfig() ends

		/**
		 * Used to load LBS templates data, these templates then used to send SMS to
		 * users
		 * 
		 * @param lbsTemplates
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus loadLBSTemplates(HashMap<String, String> lbsTemplates, Connection con) {
			logger.info(">> Loading LBS templates from database : initial map is [" + lbsTemplates
					+ "] and database connection is [" + con + "]");

			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (lbsTemplates == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_LBS_TEMPLATES);
				logger.debug(">> loading LBS templates query [" + DataBaseQueries.LOAD_LBS_TEMPLATES + "]");
				rs = stmt.executeQuery();
				while (rs.next()) {
					lbsTemplates.put(rs.getString("TEMPLATE_ID") + "_" + rs.getByte("LANGUAGE_ID"),
							rs.getString("TEMPLATE_MESSAGE"));
				}

				logger.info(" >> LBS templates loaded from database are [" + lbsTemplates + "]");
			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> Exception occurred while loading lbs templates from database", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(TSSJavaUtil.getLogInitial("00178")
						+ " >> Exception occurred while loading LBS templates from database", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00180") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;
		}// loadUSSDMenus() ends

		/**
		 * Used to load virtual codes with their corresponding pack id and pack_type id
		 * Means In case of Direct Dial short code may contains virtual code. that
		 * virtual code defines which one pack the user wants to purchase or transfer.
		 * 
		 * @param virtualCodeMappingDetails
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus loadVirtualcodeMappingDetails(HashMap<Integer, VirtualCodeMapping> virtualCodeMappingDetails,
				Connection con) {
			logger.info("Loading all virtual codes and pack details : initial " + "virtualCodeMappingDetails ["
					+ virtualCodeMappingDetails + "] and database connection is [" + con + "]");

			if (virtualCodeMappingDetails == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			PreparedStatement stmt = null;
			ResultSet rs = null;

			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_VIRTUAL_CODE_MAPPING);
				logger.debug("loading all virtual codes and pack details query ["
						+ DataBaseQueries.LOAD_VIRTUAL_CODE_MAPPING + "]");
				rs = stmt.executeQuery();

				while (rs.next()) {
					virtualCodeMappingDetails.put(rs.getInt("VIRTUAL_CODE"), new VirtualCodeMapping(
							rs.getInt("PACK_ID"), rs.getInt("PACK_TYPE"), rs.getInt("SUPER_PACK_TYPE")));
				}

				logger.info("virtualCodeMappingDetails loaded are [" + virtualCodeMappingDetails + "]");
			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while loading virtual codes and pack details from database", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading virtual codes and pack details, stmt:["
						+ stmt + "] or rs:[" + rs + "] may be null", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(
						TSSJavaUtil.getLogInitial("00286")
								+ " >> Exception occurred while loading virtual codes and pack details from database",
						e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00287") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;
		}// loadVirtualcodeMappingDetails() ends

		/**
		 * Used to load short codes with other details like service type,number of
		 * parameters in short code etc. Means In case of Direct Dial, we can recognize
		 * that this short code from user is for which service.
		 * 
		 * @param shortCodeMappingDetails
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus loadShortcodeMappingDetails(HashMap<String, ShortCodeMapping> shortCodeMappingDetails,
				Connection con) {
			logger.info("Loading all short codes and other details : initial " + "shortCodeMappingDetails ["
					+ shortCodeMappingDetails + "] and database connection is [" + con + "]");

			if (shortCodeMappingDetails == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			PreparedStatement stmt = null;
			ResultSet rs = null;

			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_SHORT_CODE_MAPPING);
				logger.debug("loading all short codes and other details query ["
						+ DataBaseQueries.LOAD_SHORT_CODE_MAPPING + "]");
				rs = stmt.executeQuery();

				while (rs.next()) {
					shortCodeMappingDetails.put(rs.getString("SHORT_CODE"),
							new ShortCodeMapping(rs.getString("SERVICE_TYPE"), rs.getByte("NUM_OF_PARAMS")));
				}

				logger.info("loadShortcodeMappingDetails loaded are [" + shortCodeMappingDetails + "]");
			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while loading short codes with other details for direct dial from database",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading short codes with other details for direct dial, stmt:["
						+ stmt + "] or rs:[" + rs + "] may be null", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(TSSJavaUtil.getLogInitial("00284")
						+ " >> Exception occurred while loading short codes with other details for direct dial from database",
						e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00285") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;
		}// loadShortcodeMappingDetails() ends

		/**
		 * This method is used to set values fetched from data into the pack bean object
		 * 
		 * @param packBean
		 * @param rs
		 */
		public void setPackBean(PackBean packBean, ResultSet rs, String type) throws Exception {
			packBean.setPackId(rs.getInt("PACK_ID"));
			packBean.setPackName(rs.getString("PACK_NAME"));
			packBean.setPackTypeId(rs.getInt("PACK_TYPE"));
			packBean.setDescription(rs.getString("DESCRIPTION"));
			packBean.setAmountRequired(rs.getDouble("AMOUNT_REQUIRED"));
			packBean.setPriority(rs.getInt("PRIORITY"));
			packBean.setLangId(rs.getByte("LANGUAGE_ID"));
			packBean.setSubType(rs.getString("SUB_TYPE"));
			packBean.setPromptFile(rs.getString("PROMPT_FILE"));
			packBean.setOthers(rs.getString("OTHER"));
			packBean.setPackOtherDetails(TSSJavaUtil.getPackOtherDetails(packBean.getOthers()));
			if (type.equalsIgnoreCase("L")) {
				packBean.setCurrentPackType(rs.getInt("CURRENT_PACK_TYPE"));
			}
		}

		/**
		 * This method is used to set values fetched from data into the pack type bean
		 * object
		 * 
		 * @param packTypeBean
		 * @param rs
		 */
		public void setPackTypeBean(PackTypeBean packTypeBean, ResultSet rs) throws Exception {
			packTypeBean.setPackType(rs.getInt("PACK_TYPE"));
			packTypeBean.setDescription(rs.getString("DESCRIPTION"));
			packTypeBean.setPackTypeName(rs.getString("PACK_TYPE_NAME"));
			packTypeBean.setPackTypePromptFile(rs.getString("PACK_TYPE_PROMPT_FILE"));
			packTypeBean.setLanguageId(rs.getByte("LANGUAGE_ID"));
			packTypeBean.setParallelPackEnable(rs.getInt("PARALLEL_PACK_ENABLE"));
			packTypeBean.setPriority(rs.getInt("PRIORITY"));
			packTypeBean.setBasePackType(rs.getString("BASE_PACK_TYPE"));
		}

		/**
		 * Used to load All available packs Types from database into cache
		 * 
		 * @param availablePacksTypeMap
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 * @author SIDDHARTH
		 */
		public CodeStatus loadAllAvailablePackType(HashMap<String, ArrayList<PackTypeBean>> availablePacksTypeMap,
				HashMap<Integer, PackTypeBean> packTypeDetailsMap, Connection con) {
			logger.info(
					"loadAllAvailablePackType() >> Loading all available packs type from PACK_TYPE_MASTER on the basis of key: initial list is ["
							+ availablePacksTypeMap + "] and database connection is [" + con + "]");

			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			if (packTypeDetailsMap == null)
				return CodeStatus.FAILURE;

			ArrayList<PackTypeBean> packTypeList = null;
			PackTypeBean packTypeBean = null;

			String prevAvailablePackKey = "-99_-99_N";

			// loading details from PACK_TYPE_MASTER table
			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_ALL_AVAILABLE_PACK_TYPES);
				logger.debug("loadAllAvailablePackType() >> loading all available packs query ["
						+ DataBaseQueries.LOAD_ALL_AVAILABLE_PACK_TYPES + "]");
				rs = stmt.executeQuery();
				String currAvailablePackKey = null;
				while (rs.next()) {
					currAvailablePackKey = rs.getInt("PARENT_PACK_TYPE") + "_" + rs.getByte("LANGUAGE_ID");
					packTypeBean = new PackTypeBean();
					if (currAvailablePackKey.equalsIgnoreCase(prevAvailablePackKey)) {
						setPackTypeBean(packTypeBean, rs);
						packTypeList.add(packTypeBean);
						availablePacksTypeMap.put(currAvailablePackKey, packTypeList);
						// prevAvailablePackKey = currAvailablePackKey;
					} else {
						packTypeList = new ArrayList<PackTypeBean>();
						setPackTypeBean(packTypeBean, rs);
						packTypeList.add(packTypeBean);
						availablePacksTypeMap.put(currAvailablePackKey, packTypeList);
						prevAvailablePackKey = currAvailablePackKey;
					}
					packTypeDetailsMap.put(packTypeBean.getPackType(), packTypeBean);
				}

				logger.info("loadAllAvailablePackType() >> Total keys loaded from pack type master are ["
						+ availablePacksTypeMap + "]");
			} catch (SQLException sqle) {
				logger.error(
						TSSJavaUtil.getLogInitial("90001")
								+ " >> SQLException occurred while loading all available pack type from database",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading all available pack type from database loadAllAvailablePackType(), stmt:["
						+ stmt + "] or rs:[" + rs + "] may be null", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(TSSJavaUtil.getLogInitial("00033")
						+ " >> Exception occurred while loading all available pack type from database loadAllAvailablePackType() ",
						e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(TSSJavaUtil.getLogInitial("00034")
							+ " >> Exception While closing result set or statement loadAllAvailablePackType()");
				}
			}
			return CodeStatus.SUCCESS;
		}// loadAvailabePackType() ends

		/**
		 * Used to load MPLACE_APP_CONFIG_PARAMS values required for system based
		 * configuration.
		 * 
		 * @param appConfigParamMap
		 * @param con
		 * @author SIDDHARTH
		 * @return CodeStatus
		 */
		public CodeStatus loadAppConfigParam(HashMap<String, String> appConfigParamMap, Connection con) {
			logger.info(
					"loadAppConfigParam() >> Loading all TAGS and VALUES from MPLACE_APP_CONFIG_PARAMS : database connection is ["
							+ con + "]");

			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (appConfigParamMap == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			// Going to load details from MPLACE_APP_CONFIG_PARAMS table
			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_APP_CONFIG_PARAMS);
				logger.debug("loadAppConfigParam() >> loading app config param values query ["
						+ DataBaseQueries.LOAD_APP_CONFIG_PARAMS + "]");
				rs = stmt.executeQuery();

				while (rs.next()) {
					appConfigParamMap.put(rs.getString("PARAM_TAG"), rs.getString("PARAM_VALUE"));
				}

				logger.info("loadAppConfigParam() >> appConfigParamMap SIZE [" + appConfigParamMap.size() + "]");
			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while loading MPLACE_APP_CONFIG_PARAMS values from database",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading MPLACE_APP_CONFIG_PARAMS values from database, stmt:["
						+ stmt + "] rs:[" + rs + "] may be null", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(
						TSSJavaUtil.getLogInitial("00338")
								+ " >> Exception occurred while loading MPLACE_APP_CONFIG_PARAMS values from database",
						e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(TSSJavaUtil.getLogInitial("00339")
							+ " loadAppConfigParam >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;

		}

		/**
		 * Used to load Service action details.
		 * 
		 * @param serviceActionDetailMap
		 * @param con
		 * @return CodeStatus
		 */
		public CodeStatus loadServiceActionDetails(Map<Integer, String> serviceActionDetailMap, Connection con) {
			logger.info(
					"loadServiceActionDetails() >> Loading all Service Action Details from SERVICE_ACTION_DETAILS : database connection is ["
							+ con + "]");

			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (serviceActionDetailMap == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			// Going to load details from SERVICE_ACTION_DETAILS table
			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_SERVICE_ACTION_DETAILS);
				logger.debug("loadAppConfigParam() >> loading service action detsils query ["
						+ DataBaseQueries.LOAD_SERVICE_ACTION_DETAILS + "]");
				rs = stmt.executeQuery();

				while (rs.next()) {
					serviceActionDetailMap.put(Integer.parseInt(rs.getString("SERVICE_ID")), rs.getString("DATA"));
				}

				logger.info("loadServiceActionDetails() >> serviceActionDetailMap SIZE ["
						+ serviceActionDetailMap.size() + "]");
			} catch (SQLException sqle) {
				logger.error(
						TSSJavaUtil.getLogInitial("90001")
								+ " >> SQLException occurred while loading SERVICE_ACTION_DETAILS values from database",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading SERVICE_ACTION_DETAILS values from database, stmt:["
						+ stmt + "] rs:[" + rs + "] may be null", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(
						TSSJavaUtil.getLogInitial("00338")
								+ " >> Exception occurred while loading SERVICE_ACTION_DETAILS values from database",
						e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(TSSJavaUtil.getLogInitial("00339")
							+ " loadAppConfigParam >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;

		}

		public CodeStatus loadPromoUsersAndServiceDetails(HashMap<String, String> promoServiceMap, Connection con) {
			logger.info(
					"loadPromoUsersAndServiceDetails() >> Loading all available packs from Pack_Master: initial list is ["
							+ promoServiceMap + "] and database connection is [" + con + "]");

			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (promoServiceMap == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			// loading details from pack_master table
			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_ALL_PROMO_SERVICE_MAPPING);
				logger.debug("loadAvailablePacks() >> loading all available packs query ["
						+ DataBaseQueries.LOAD_ALL_PROMO_SERVICE_MAPPING + "]");
				rs = stmt.executeQuery();
				while (rs.next()) {
					promoServiceMap.put(rs.getString("MSISDN").trim(), rs.getString("SCOPE"));
				}

				logger.info("inside loadPromoUsersAndServiceDetails with promoServiceMap size[" + promoServiceMap.size()
						+ "]");
			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while loading all available packs from database", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading all available packs from database, stmt:["
						+ stmt + "] or rs:[" + rs + "] may be null", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(TSSJavaUtil.getLogInitial("00033")
						+ " >> Exception occurred while loading all available packs from database", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00034") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;
		}

		/**
		 * This method is used to fill all the promotional pack details used in
		 * promotion of day (POD) service.
		 * 
		 * @param promoPackDetailsMap
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus loadPromotionPacksDetail(HashMap<String, PromoPackBean> promoPackDetailsMap, Connection con) {
			logger.info(
					"loadPromotionPacksDetail() >> Loading all available Promotion Packs from POD service: initial map to fill ["
							+ promoPackDetailsMap + "] and database connection is [" + con + "]");

			PreparedStatement stmt = null;
			ResultSet rs = null;

			if (promoPackDetailsMap == null)
				return CodeStatus.FAILURE;

			if (con == null)
				return CodeStatus.CONNECTION_IS_NULL;

			PromoPackBean promoPackBean;
			String key = "";
			// loading details from pack_master table
			try {
				stmt = con.prepareStatement(DataBaseQueries.LOAD_ALL_PROMO_PACK_DETAILS);
				logger.debug("loadAvailablePacks() >> loading all available packs query ["
						+ DataBaseQueries.LOAD_ALL_PROMO_PACK_DETAILS + "]");
				rs = stmt.executeQuery();
				while (rs.next()) {
					promoPackBean = new PromoPackBean();
					key = rs.getString("PRODUCT_CODE").trim() + "_" + rs.getString("LANGUAGE_ID").trim() + "_"
							+ rs.getString("SUB_TYPE").trim();

					promoPackBean.setPackId(rs.getInt("PACK_ID"));
					promoPackBean.setPrductCode(rs.getString("PRODUCT_CODE"));
					promoPackBean.setLanguageId(rs.getByte("LANGUAGE_ID"));
					promoPackBean.setSubType(rs.getString("SUB_TYPE"));
					promoPackBean.setPackType(rs.getInt("PACK_TYPE"));
					promoPackBean.setOther(rs.getString("OTHER"));

					logger.info("Going to set the values of Prompt Packs Details with KEY[" + key + "]");
					promoPackDetailsMap.put(key, promoPackBean);
				}

				logger.info("Total Prompt found [" + promoPackDetailsMap.size() + "].");

			} catch (SQLException sqle) {
				logger.error(TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while loading all available packs from database", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while loading all available packs from database, stmt:["
						+ stmt + "] or rs:[" + rs + "] may be null", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(TSSJavaUtil.getLogInitial("00033")
						+ " >> Exception occurred while loading all available packs from database", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
				} catch (Exception exp) {
					logger.warn(
							TSSJavaUtil.getLogInitial("00034") + " >> Exception While closing result set or statement");
				}
			}
			return CodeStatus.SUCCESS;
		}

	}// CacheLoader inner class ends

	/**
	 * This method used for local testing of methods of this class
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		HashMap<String, ArrayList<PackBean>> availablePacksMap = new HashMap<String, ArrayList<PackBean>>();
		DBOperations db = new DBOperations();
		// Connection con =
		// TSSJavaUtil.instance().getConnPool().getConnection();
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.168.2.127:1521:mastera", "marketplace",
				"marketplace");
		// System.out.println("con:[" + con + "]");
		db.new CacheLoader().loadAvailablePacks(availablePacksMap, con);
	}

	public class LogsManager {

		/**
		 * Used to maintain call logs of this API into database means some details about
		 * the user's complete session to use Marketplace
		 * 
		 * @param userDataBean
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus maintainCallLogs(UserDataBean userDataBean) {
			logger.info(userDataBean.getRequestId()
					+ " maintainCallLogs() >> Here going to insert entry into database for call logs : "
					+ userDataBean);
			Connection con = TSSJavaUtil.instance().getConnPool().getConnection();
			if (con == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00045")
						+ "  >> connection to database is [" + con + "] "
						+ "so not inserting entry into database for call logs : msisdn [" + userDataBean.getMsisdn()
						+ "]");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			// fetching pack purchase detail means pack purchase ID and result
			int packPurchaseId = -1;
			byte packPurchaseResult = -1;
			String accessedPacksRecords = "";
			FileLogWriter fileLogWriter = TSSJavaUtil.getFileLogWriterCallDetailsLog();

			// Getting jsonString from Object
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")) {
				accessedPacksRecords = TSSJavaUtil.instance().getUserDataJsonString(userDataBean);
				logger.info("Going to maintain Accessed Packs Records in File.");
				fileLogWriter.writeLog(accessedPacksRecords);
			}

			try {
				packPurchaseId = Integer.parseInt(userDataBean.getPackPurchaseDetail().split(":")[0]);
				packPurchaseResult = Byte.parseByte(userDataBean.getPackPurchaseDetail().split(":")[1]);

			} catch (Exception e) {
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00046")
						+ "  >> User has not tried for purchase so using pack purchase ID [" + packPurchaseId + "] "
						+ "pack purchase result [" + packPurchaseResult + "] : msisdn [" + userDataBean.getMsisdn()
						+ "]");
			}

			long currentTime = System.currentTimeMillis();
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			try {
				logger.debug(userDataBean.getRequestId() + " maintainCallLogs() >> call logs query ["
						+ DataBaseQueries.CALL_LOGS + "]");
				pstmt = con.prepareStatement(DataBaseQueries.CALL_LOGS);

				pstmt.setString(1, userDataBean.getMsisdn());
				pstmt.setString(2, userDataBean.getInterfaceUsed());
				pstmt.setString(3, userDataBean.getPackBrowseList());
				pstmt.setInt(4, packPurchaseId);
				pstmt.setInt(5, packPurchaseResult);
				pstmt.setString(6, userDataBean.getShortCode());
				pstmt.setDouble(7, userDataBean.getBalance());
				pstmt.setString(8, userDataBean.getSubType());
				pstmt.setString(9, userDataBean.getRequestId());
				pstmt.setString(10, userDataBean.getFmsisdn());
				pstmt.setString(11, userDataBean.getCallStartTime());
				pstmt.setInt(12, userDataBean.getCallDuration());

				int result = pstmt.executeUpdate();

				logger.debug(userDataBean.getRequestId() + " Time taken by CALL_LOGS Query ["
						+ (System.currentTimeMillis() - currentTime) + "]");
				if (result > 0) {
					logger.info(userDataBean.getRequestId()
							+ " maintainCallLogs() >> entry for call logs into database is done successfully "
							+ "query result is [" + result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
					return CodeStatus.SUCCESS;
				} else {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00047")
							+ "  >> Failed to insert entry for call logs into database " + "query result is [" + result
							+ "] : msisdn [" + userDataBean.getMsisdn() + "]");
					return CodeStatus.FAILURE;
				}

			} catch (SQLException sqle) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ "  >> SQLException occurred while inserting entry into database for call logs : msisdn ["
						+ userDataBean.getMsisdn() + "]", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ "  >> NullPointerException occurred while inserting entry into database for call logs : msisdn ["
						+ userDataBean.getMsisdn() + "] con:[" + con + "] pstmt:[" + pstmt + "] rs:[" + rs
						+ "] may be null.", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00048")
						+ " >> Exception occurred while inserting entry into database for call logs : msisdn ["
						+ userDataBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (con != null)
						con.close();
				} catch (Exception exp) {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00049")
							+ "  >> Exception While closing result set or statement or connection : msisdn ["
							+ userDataBean.getMsisdn() + "]");
				}
			}

		}// maintainCallLogs() ends

		/**
		 * Used to maintain charging logs into database in both the cases either
		 * charging of user was successful or failed because of any reason, then details
		 * are inserted into database charging logs table
		 * 
		 * @param chargingLogsBean
		 * @param isChargingSuccess
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus maintainChargingLogs(ChargingLogsBean chargingLogsBean, boolean isChargingSuccess) {
			logger.info(chargingLogsBean.getRequestId()
					+ " maintainChargingLogs() >> Here going to insert entry into database"
					+ " for charging logs, isChargingSuccess [" + isChargingSuccess + "] : " + chargingLogsBean);
			Connection con = TSSJavaUtil.instance().getConnPool().getConnection();

			if (con == null) {
				logger.error(chargingLogsBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00050")
						+ "  >> connection to database is [" + con + "] "
						+ "so not inserting entry into database for charging logs : msisdn ["
						+ chargingLogsBean.getMsisdn() + "]");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			if (chargingLogsBean.getProductCode() == null || "".equals(chargingLogsBean.getProductCode()))
				chargingLogsBean.setProductCode("NA");

			// maintaining transaction CDRS
			if (isChargingSuccess) {
				this.maintainTransactionCDRS(chargingLogsBean, con);
			}

			PreparedStatement pstmt = null;

			try {
				logger.debug(chargingLogsBean.getRequestId() + " maintainChargingLogs() >> call logs query ["
						+ DataBaseQueries.CHARGING_LOGS + "]");
				pstmt = con.prepareStatement(DataBaseQueries.CHARGING_LOGS);

				pstmt.setString(1, chargingLogsBean.getMsisdn());
				pstmt.setString(2, chargingLogsBean.getFmsisdn());
				pstmt.setString(3, chargingLogsBean.getTransactionId());
				pstmt.setInt(4, chargingLogsBean.getType());
				pstmt.setString(5, chargingLogsBean.getProductCode());
				pstmt.setDouble(6, chargingLogsBean.getServiceCharge());
				pstmt.setInt(7, chargingLogsBean.getVolume());
				pstmt.setInt(8, chargingLogsBean.getValidityDays());
				pstmt.setString(9, chargingLogsBean.getSubType());
				pstmt.setInt(10, chargingLogsBean.getResponseStatus());
				pstmt.setInt(11, chargingLogsBean.getPackId());
				pstmt.setString(12, chargingLogsBean.getVolumeType());
				pstmt.setString(13, chargingLogsBean.getValidityType());
				pstmt.setString(14, chargingLogsBean.getShortCode());
				pstmt.setInt(15, chargingLogsBean.getLanguageId());
				pstmt.setString(16, chargingLogsBean.getUserInterface());

				int result = pstmt.executeUpdate();
				logger.info(chargingLogsBean.getRequestId()
						+ " maintainChargingLogs() >> entry for charging logs into database " + "query result is ["
						+ result + "] : msisdn [" + chargingLogsBean.getMsisdn() + "]");

				pstmt.close();

				if (result > 0) {
					return CodeStatus.SUCCESS;
				} else {
					logger.error(chargingLogsBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00051")
							+ "  >> Failed to insert entry for charging logs into database " + "query result is ["
							+ result + "] : msisdn [" + chargingLogsBean.getMsisdn() + "]");
					return CodeStatus.FAILURE;
				}

			} catch (SQLException sqle) {
				logger.error(chargingLogsBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while inserting entry into database" + " for call logs : msisdn ["
						+ chargingLogsBean.getMsisdn() + "]", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(chargingLogsBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred while inserting entry into database"
						+ " for call logs : msisdn [" + chargingLogsBean.getMsisdn() + "] pstmt:[" + pstmt + "]", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(chargingLogsBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00052")
						+ "  >> Exception occurred while inserting entry into database" + " for call logs : msisdn ["
						+ chargingLogsBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
					if (con != null)
						con.close();
				} catch (Exception exp) {
					logger.warn(chargingLogsBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00053")
							+ "  >> Exception While closing result set or statement or connection : msisdn ["
							+ chargingLogsBean.getMsisdn() + "]");
				}
			}

		}// maintainChargingLogs() ends

		/**
		 * Used to maintain transaction CDRS into database only if user's request for
		 * any service and charging for that was successful, then details are inserted
		 * into database charging logs table
		 * 
		 * @param chargingLogsBean
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		private CodeStatus maintainTransactionCDRS(ChargingLogsBean chargingLogsBean, Connection con) {
			logger.info(chargingLogsBean.getRequestId()
					+ " maintainTransactionCDRS() >> Here going to insert entry into database"
					+ " for transaction CDRS " + chargingLogsBean.getMsisdn());

			if (con == null) {
				logger.error(chargingLogsBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00054")
						+ "  >> connection to database is [" + con + "] "
						+ "so not inserting entry into database for charging logs : msisdn ["
						+ chargingLogsBean.getMsisdn() + "]");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			PreparedStatement pstmt = null;
			int result = -1;

			try {
				logger.debug(chargingLogsBean.getRequestId()
						+ " maintainTransactionCDRS() >> now maintaining transaction CDRS, " + "query ["
						+ DataBaseQueries.TRANSACTION_CDRS + "]");

				pstmt = con.prepareStatement(DataBaseQueries.TRANSACTION_CDRS);

				pstmt.setString(1, chargingLogsBean.getMsisdn());
				pstmt.setString(2, chargingLogsBean.getFmsisdn());
				pstmt.setString(3, chargingLogsBean.getTransactionId());
				pstmt.setInt(4, chargingLogsBean.getType());
				pstmt.setString(5, chargingLogsBean.getProductCode());
				pstmt.setDouble(6, chargingLogsBean.getServiceCharge());
				pstmt.setInt(7, chargingLogsBean.getVolume());
				pstmt.setInt(8, chargingLogsBean.getValidityDays());
				pstmt.setString(9, chargingLogsBean.getSubType());
				pstmt.setInt(10, chargingLogsBean.getPackId());
				pstmt.setString(11, chargingLogsBean.getVolumeType());
				pstmt.setString(12, chargingLogsBean.getValidityType());
				pstmt.setString(13, chargingLogsBean.getShortCode());
				pstmt.setInt(14, chargingLogsBean.getLanguageId());
				pstmt.setString(15, chargingLogsBean.getUserInterface());

				result = pstmt.executeUpdate();

				if (result > 0) {
					logger.info(chargingLogsBean.getRequestId()
							+ " maintainTransactionCDRS() >> transaction CDRS entry into " + "database result is ["
							+ result + "]");
					return CodeStatus.SUCCESS;
				} else {
					logger.error(chargingLogsBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00055")
							+ " >> Failed to insert entry for " + "transaction CDRS into database query result is ["
							+ result + "] : msisdn [" + chargingLogsBean.getMsisdn() + "]");
					return CodeStatus.FAILURE;
				}

			} catch (SQLException sqle) {
				logger.error(chargingLogsBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while inserting entry into database"
						+ " for transaction CDRS : msisdn [" + chargingLogsBean.getMsisdn() + "]", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(chargingLogsBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ "  >> NullPointerException occurred while inserting entry into database"
						+ " for transaction CDRS : msisdn [" + chargingLogsBean.getMsisdn() + "] pstmt:[" + pstmt + "]",
						npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(chargingLogsBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00056")
						+ " >> Exception occurred while inserting entry into database"
						+ " for transaction CDRS : msisdn [" + chargingLogsBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
				} catch (Exception exp) {
					logger.warn(chargingLogsBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00057")
							+ " >> Exception While closing pstatement : msisdn [" + chargingLogsBean.getMsisdn() + "]");
				}
			}

		}// maintainTransactionCDRS() ends

		/**
		 * Used to insert user profile into database means some details about the user's
		 * If user profile is exist then update last_visit_time of user.
		 * 
		 * @param userDataBean
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus maintainUserProfile(UserDataBean userDataBean) {
			logger.info(userDataBean.getRequestId()
					+ " maintainUserProfile() >> Here going to insert entry into database for maintain user profile : "
					+ userDataBean);
			Connection con = TSSJavaUtil.instance().getConnPool().getConnection();

			if (con == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00045")
						+ "  >> connection to database is [" + con + "] "
						+ "so not inserting entry into database for user profile : msisdn [" + userDataBean.getMsisdn()
						+ "]");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			PreparedStatement pstmt = null;
			ResultSet rs = null;

			try {
				logger.debug(userDataBean.getRequestId() + " maintainUserProfile() >> GetUserProfile query ["
						+ DataBaseQueries.GET_USER_PROFILE + "]");

				// long currentTime = System.currentTimeMillis();
				pstmt = con.prepareStatement(DataBaseQueries.GET_USER_PROFILE);
				pstmt.setString(1, userDataBean.getMsisdn());
				rs = pstmt.executeQuery();
				// changes by Ashu to handle rs and pstmt
				int recordExist = 0;
				if (rs.next())
					recordExist = 1;

				// Code modified by Siddharth
				// logger.debug(userDataBean.getRequestId() + " Time taken by GET_USER_PROFILE
				// Query ["+(System.currentTimeMillis() - currentTime)+"]");

				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();

				if (recordExist == 1)
				// upto this line changes by ashu
				{
					logger.debug(userDataBean.getRequestId() + " maintainUserProfile() >> UpdateUserProfile query ["
							+ DataBaseQueries.UPDATE_USER_PROFILE + "]");

					// currentTime = System.currentTimeMillis();
					pstmt = con.prepareStatement(DataBaseQueries.UPDATE_USER_PROFILE);
					pstmt.setString(1, userDataBean.getMsisdn());
					int result = pstmt.executeUpdate();

					// logger.debug(userDataBean.getRequestId() + " Time taken by
					// UPDATE_USER_PROFILE Query ["+(System.currentTimeMillis() - currentTime)+"]");
					if (result > 0) {
						logger.info(userDataBean.getRequestId()
								+ " maintainUserProfile() >> entry for maintain user profile into database is updated successfully "
								+ "query result is [" + result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
						return CodeStatus.SUCCESS;
					} else {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00047")
								+ "  >> Failed to update entry user profile into database " + "query result is ["
								+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}
				} else {
					logger.debug(userDataBean.getRequestId() + " maintainUserProfile() >> userProfile query ["
							+ DataBaseQueries.INSERT_USER_PROFILE + "]");

					// currentTime = System.currentTimeMillis();
					pstmt = null;
					pstmt = con.prepareStatement(DataBaseQueries.INSERT_USER_PROFILE);

					pstmt.setString(1, userDataBean.getMsisdn());
					pstmt.setString(2, userDataBean.getMsisdn());
					pstmt.setInt(3, userDataBean.getLangId());
					pstmt.setString(4, userDataBean.getSubType());
					int result = pstmt.executeUpdate();

					// logger.debug(userDataBean.getRequestId() + " Time taken by
					// INSERT_USER_PROFILE Query ["+(System.currentTimeMillis() - currentTime)+"]");
					if (result > 0) {
						logger.info(userDataBean.getRequestId()
								+ " maintainUserProfile() >> entry for maintain user profile into database is done successfully "
								+ "query result is [" + result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
						return CodeStatus.SUCCESS;
					} else {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00047")
								+ "  >> Failed to insert entry user profile into database " + "query result is ["
								+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}
				}
			} catch (SQLException sqle) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ "  >> SQLException occurred while inserting entry into database for user profile : msisdn ["
						+ userDataBean.getMsisdn() + "]", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ "  >> NullPointerException occurred while inserting entry into database for user profile : msisdn ["
						+ userDataBean.getMsisdn() + "] con:[" + con + "] pstmt:[" + pstmt + "] rs:[" + rs
						+ "] may be null.", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00048")
						+ " >> Exception occurred while inserting entry into database for user profile : msisdn ["
						+ userDataBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (con != null)
						con.close();
				} catch (Exception exp) {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00049")
							+ "  >> Exception While closing result set or statement or connection : msisdn ["
							+ userDataBean.getMsisdn() + "]");
				}
			}

		}// maintainUserProfile() ends

		/**
		 * Used to maintain user pack purchase detail into database only if user's
		 * request for any service and charging for that was successful, then details
		 * are inserted into database
		 * 
		 * @param packPurchaseBean contains user data.
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus maintainUserPurchaseDetails(UserPackPurchaseBean packPurchaseBean) {
			logger.info(packPurchaseBean.getTransaction_Id()
					+ " maintainUserPurchaseDetails() >> Here going to insert entry into database"
					+ " for user pack purchase details " + packPurchaseBean.getMsisdn());
			Connection con = TSSJavaUtil.instance().getConnPool().getConnection();

			if (con == null) {
				logger.error(packPurchaseBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("00054")
						+ "  >> connection to database is [" + con + "] "
						+ "so not inserting entry into database for user pack purchase detail : msisdn ["
						+ packPurchaseBean.getMsisdn() + "]");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			PreparedStatement pstmt = null;
			int result = -1;
			int oldDelResult = -1;

			try {
				// Modified by SIDDHARTH 21 Feb 19 (Need to check for expiry date)
				boolean existingPurchaseStatus = this.checkUserExistingPurchase(packPurchaseBean, con); // For
																										// same
				// Modified by SIDDHARTH 21 Feb 19 // pack
				boolean purchaseStatus = this.checkUserPackPurchaseDetails(packPurchaseBean, con); // For
																									// different
																									// pack
																									// of
																									// same
																									// pack_type

				if (existingPurchaseStatus) {
					// User is alreay purchased requested pack. So update expiry
					// time -

					// Query Modified by Siddharth
					logger.debug(packPurchaseBean.getTransaction_Id()
							+ " maintainUserPurchaseDetails() >> now maintaining user pack purchase details. User Purchased already Active Pack. "
							+ "query [" + DataBaseQueries.UPDATE_EXISTING_USER_PACK_PURCHASE_DETAILS + "]");

					logger.debug("packPurchaseBean:" + packPurchaseBean + "with ValidityType:["
							+ TSSJavaUtil.getValadityType(packPurchaseBean.getValidity_type()) + "].");

					if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.ORACLE_DB) {
						pstmt = con.prepareStatement(DataBaseQueries.UPDATE_EXISTING_USER_PACK_PURCHASE_DETAILS);
						pstmt.setInt(1, packPurchaseBean.getValidity_Days());
						pstmt.setString(2, TSSJavaUtil.getValadityType(packPurchaseBean.getValidity_type()));
						pstmt.setString(3, packPurchaseBean.getTransaction_Id());
						pstmt.setString(4, packPurchaseBean.getMsisdn());
						pstmt.setInt(5, packPurchaseBean.getPack_Id());
						pstmt.setInt(6, packPurchaseBean.getPack_Type());
						result = pstmt.executeUpdate();
					} else if (TSSJavaUtil.instance().getCacheParameters()
							.getDataBaseType() == MPCommonDataTypes.MYSQL_DB) {
						String query = DataBaseQueries.UPDATE_EXISTING_USER_PACK_PURCHASE_DETAILS;

						query = query.replace(MPCommonDataTypes.INTERVALFORMAT,
								TSSJavaUtil.getValadityType(packPurchaseBean.getValidity_type()));
						pstmt = con.prepareStatement(query);
						pstmt.setInt(1, packPurchaseBean.getValidity_Days());
						pstmt.setString(2, packPurchaseBean.getTransaction_Id());
						pstmt.setString(3, packPurchaseBean.getMsisdn());
						pstmt.setInt(4, packPurchaseBean.getPack_Id());
						pstmt.setInt(5, packPurchaseBean.getPack_Type());
						result = pstmt.executeUpdate();
					} else {
						logger.error(packPurchaseBean.getTransaction_Id() + " >> DatabaseType["
								+ TSSJavaUtil.instance().getCacheParameters().getDataBaseType()
								+ "] not found. Allowed DataBaseType[" + MPCommonDataTypes.ORACLE_DB + ","
								+ MPCommonDataTypes.MYSQL_DB + "]");
					}

					if (result > 0) {
						logger.info(packPurchaseBean.getTransaction_Id()
								+ " maintainUserPurchaseDetails() >> userPurchasedetails entry into "
								+ "database result is [" + result + "]");
						return CodeStatus.SUCCESS;
					} else {
						logger.error(packPurchaseBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("00055")
								+ " >> Failed to update entry for "
								+ "user pack purchase details into database query result is [" + result + "] : msisdn ["
								+ packPurchaseBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}

				} else if (!existingPurchaseStatus && purchaseStatus) {
					// User is not already purchased requested pack but trying
					// to purchase parallel pack of already purchased pack type-

					if (TSSJavaUtil.instance().getCacheParameters().getAvailablePackTypeParallelEnableMap()
							.get(packPurchaseBean.getPack_Type()) == 0) {
						logger.debug(packPurchaseBean.getTransaction_Id()
								+ " Parallel Pack for requested packType is disable, So First Deleting old packs."
								+ "MSISND[" + packPurchaseBean.getMsisdn() + "] Pack_Id["
								+ packPurchaseBean.getPack_Id() + "] Pack_Type[" + packPurchaseBean.getPack_Type()
								+ "]");
						// Delete old packs
						oldDelResult = this.deleteOldPackDetails(packPurchaseBean, con);

						if (oldDelResult > 0) {
							// Inserting pack data after deleting old data-
							result = this.insertUserPackPurchaseDetails(packPurchaseBean, con);
							if (result > 0) {
								logger.info(packPurchaseBean.getTransaction_Id()
										+ " maintainUserPurchaseDetails() >> userPurchasedetails entry into "
										+ "database result is [" + result + "]");
								return CodeStatus.SUCCESS;
							} else {
								logger.error(packPurchaseBean.getTransaction_Id() + " "
										+ TSSJavaUtil.getLogInitial("00055") + " >> Failed to update entry for "
										+ "user pack purchase details into database query result is [" + result
										+ "] : msisdn [" + packPurchaseBean.getMsisdn() + "]");
								return CodeStatus.FAILURE;
							}
						} else {
							logger.error(packPurchaseBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("00055")
									+ " >> Failed to update entry for "
									+ "user pack purchase details into database query result is [" + result
									+ "] : msisdn [" + packPurchaseBean.getMsisdn() + "]");
							return CodeStatus.FAILURE;
						}
					} else {
						// parallel packs are allowed so inserting new entry.
						logger.info(packPurchaseBean.getTransaction_Id()
								+ " Parallel Pack for requested packType is Enable." + "MSISND["
								+ packPurchaseBean.getMsisdn() + "] Pack_Id[" + packPurchaseBean.getPack_Id()
								+ "] Pack_Type[" + packPurchaseBean.getPack_Type() + "]");
						result = this.insertUserPackPurchaseDetails(packPurchaseBean, con);
						if (result > 0) {
							logger.info(packPurchaseBean.getTransaction_Id()
									+ " maintainUserPurchaseDetails() >> userPurchasedetails entry into "
									+ "database result is [" + result + "]");
							return CodeStatus.SUCCESS;
						} else {
							logger.error(packPurchaseBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("00055")
									+ " >> Failed to insert entry for "
									+ "user pack purchase details into database query result is [" + result
									+ "] : msisdn [" + packPurchaseBean.getMsisdn() + "]");
							return CodeStatus.FAILURE;
						}
					}
				} else {// neither purshased requested pack nor any pack of
						// requested pack_type So inserting details.

					// Inserting data -

					result = this.insertUserPackPurchaseDetails(packPurchaseBean, con);
					if (result > 0) {
						logger.info(packPurchaseBean.getTransaction_Id()
								+ " maintainUserPurchaseDetails() >> userPurchasedetails entry into "
								+ "database result is [" + result + "]");
						return CodeStatus.SUCCESS;
					} else {
						logger.error(packPurchaseBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("00055")
								+ " >> Failed to insert entry for "
								+ "user pack purchase details into database query result is [" + result + "] : msisdn ["
								+ packPurchaseBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}

				}
			} catch (SQLException sqle) {
				logger.error(
						packPurchaseBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("90001")
								+ " >> SQLException occurred while inserting entry into database"
								+ " for user pack purchase details: msisdn [" + packPurchaseBean.getMsisdn() + "]",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(packPurchaseBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("90003")
						+ "  >> NullPointerException occurred while inserting entry into database"
						+ " for user pack purchase details : msisdn [" + packPurchaseBean.getMsisdn() + "] pstmt:["
						+ pstmt + "]", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(packPurchaseBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("00056")
						+ " >> Exception occurred while inserting entry into database"
						+ " for user pack purchase details : msisdn [" + packPurchaseBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
					if (con != null)
						con.close();
				} catch (Exception exp) {
					logger.warn(packPurchaseBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("00057")
							+ " >> Exception While closing result set or pstatement or connection : msisdn ["
							+ packPurchaseBean.getMsisdn() + "]");
				}
			}

		}// maintainUserPurchaseDetails end

		/**
		 * Used to maintain User transaction CDRS into database only if user's request
		 * for any service and charging for that was successful.
		 * 
		 * @param chargingLogsBean
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus maintainUserTransactionCDRS(UserTransactionBean transactionBean) {
			logger.info(transactionBean.getTransaction_Id()
					+ " maintainUserTransactionCDRS() >> Here going to insert entry into database"
					+ " for User transaction CDRS " + transactionBean.getMsisdn());
			Connection con = TSSJavaUtil.instance().getConnPool().getConnection();
			if (con == null) {
				logger.error(transactionBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("00054")
						+ "  >> connection to database is [" + con + "] "
						+ "so not inserting entry into database for user Transaction CDRS: msisdn ["
						+ transactionBean.getMsisdn() + "]");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			PreparedStatement pstmt = null;
			int result = -1;
			try {
				logger.debug(transactionBean.getTransaction_Id()
						+ " maintainUserTransactionCDRS() >> now maintaining user transaction CDRS, " + "query ["
						+ DataBaseQueries.USER_TRANSACTION_CDRS + "]");

				if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.ORACLE_DB) {
					pstmt = con.prepareStatement(DataBaseQueries.USER_TRANSACTION_CDRS);
					pstmt.setString(1, transactionBean.getTransaction_Id());
					pstmt.setString(2, transactionBean.getMsisdn());
					pstmt.setString(3, transactionBean.getFmsisdn());
					pstmt.setInt(4, transactionBean.getPack_Id());
					pstmt.setString(5, transactionBean.getPack_Name());
					pstmt.setInt(6, transactionBean.getLang_Id());
					pstmt.setInt(7, transactionBean.getValidity_Days());
					pstmt.setString(8, TSSJavaUtil.getValadityType(transactionBean.getValidity_type()));
					pstmt.setInt(9, transactionBean.getValidity_Days());
					pstmt.setInt(10, transactionBean.getVolume());
					pstmt.setString(11, transactionBean.getTransaction_Type());
					pstmt.setString(12, transactionBean.getTransaction_Message());
					pstmt.setString(13, transactionBean.getValidity_type());
					result = pstmt.executeUpdate();
				} else if (TSSJavaUtil.instance().getCacheParameters()
						.getDataBaseType() == MPCommonDataTypes.MYSQL_DB) {
					String query = DataBaseQueries.USER_TRANSACTION_CDRS;
					query = query.replace(MPCommonDataTypes.INTERVALFORMAT,
							TSSJavaUtil.getValadityType(transactionBean.getValidity_type()));
					pstmt = con.prepareStatement(query);
					pstmt.setString(1, transactionBean.getTransaction_Id());
					pstmt.setString(2, transactionBean.getMsisdn());
					pstmt.setString(3, transactionBean.getFmsisdn());
					pstmt.setInt(4, transactionBean.getPack_Id());
					pstmt.setString(5, transactionBean.getPack_Name());
					pstmt.setInt(6, transactionBean.getLang_Id());
					pstmt.setInt(7, transactionBean.getValidity_Days());
					pstmt.setInt(8, transactionBean.getValidity_Days());
					pstmt.setInt(9, transactionBean.getVolume());
					pstmt.setString(10, transactionBean.getTransaction_Type());
					pstmt.setString(11, transactionBean.getTransaction_Message());
					pstmt.setString(12, transactionBean.getValidity_type());
					result = pstmt.executeUpdate();
				} else {
					logger.error(transactionBean.getTransaction_Id() + " >> DatabaseType["
							+ TSSJavaUtil.instance().getCacheParameters().getDataBaseType()
							+ "] not found. Allowed DataBaseType[" + MPCommonDataTypes.ORACLE_DB + ","
							+ MPCommonDataTypes.MYSQL_DB + "]");
				}

				if (result > 0) {
					logger.info(transactionBean.getTransaction_Id()
							+ " maintainUserTransactionCDRS() >> user transaction CDRS entry into "
							+ "database result is [" + result + "]");
					return CodeStatus.SUCCESS;
				} else {
					logger.error(transactionBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("00055")
							+ " >> Failed to insert entry for "
							+ "user transaction CDRS into database query result is [" + result + "] : msisdn ["
							+ transactionBean.getMsisdn() + "]");
					return CodeStatus.FAILURE;
				}

			} catch (SQLException sqle) {
				logger.error(transactionBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while inserting entry into database"
						+ " for user transaction CDRS : msisdn [" + transactionBean.getMsisdn() + "]", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(transactionBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("90003")
						+ "  >> NullPointerException occurred while inserting entry into database"
						+ " for user transaction CDRS : msisdn [" + transactionBean.getMsisdn() + "] pstmt:[" + pstmt
						+ "]", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(transactionBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("00056")
						+ " >> Exception occurred while inserting entry into database"
						+ " for user transaction CDRS : msisdn [" + transactionBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
					if (con != null)
						con.close();
				} catch (Exception exp) {
					logger.warn(transactionBean.getTransaction_Id() + " " + TSSJavaUtil.getLogInitial("00057")
							+ " >> Exception While closing pstatement or connection where : msisdn ["
							+ transactionBean.getMsisdn() + "]");
				}
			}

		}// maintainUserTransactionCDRS() ends

		public boolean checkUserExistingPurchase(UserPackPurchaseBean userBean, Connection con) {
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			boolean status = false;
			try {
				logger.debug(userBean.getTransaction_Id()
						+ " checkUserExistingPurchase() >> now checking existing user pack purchase details, "
						+ "query [" + DataBaseQueries.CHECK_EXISTING_USER_PACK_PURCHASE + "]");

				pstmt = con.prepareStatement(DataBaseQueries.CHECK_EXISTING_USER_PACK_PURCHASE);
				pstmt.setString(1, userBean.getMsisdn());
				pstmt.setInt(2, userBean.getPack_Id());
				pstmt.setInt(3, userBean.getPack_Type());
				rs = pstmt.executeQuery();
				if (rs.next()) {
					status = true;
				} else {
					status = false;
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
				} catch (Exception exp) {
					logger.warn(">> Exception While closing resultSet or pstatement or connection : msisdn ["
							+ userBean.getMsisdn() + "]");
				}

			}

			logger.info("Returning status. MSISND [" + userBean.getMsisdn() + "] " + "RequestID["
					+ userBean.getTransaction_Id() + "] status [" + status + "]");
			return status;
		}

		public boolean checkUserPackPurchaseDetails(UserPackPurchaseBean userBean, Connection con) {
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			boolean status = false;
			try {
				logger.debug(userBean.getTransaction_Id()
						+ " checkUserPackPurchaseDetails() >> now checking user pack purchase details, " + "query ["
						+ DataBaseQueries.CHECK_USER_PACK_PURCHASE + "]");

				pstmt = con.prepareStatement(DataBaseQueries.CHECK_USER_PACK_PURCHASE);
				pstmt.setString(1, userBean.getMsisdn());
				pstmt.setInt(2, userBean.getPack_Type());
				rs = pstmt.executeQuery();
				if (rs.next()) {
					status = true;
				} else {
					status = false;
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
				} catch (Exception exp) {
					logger.warn(">> Exception While closing resultSet or pstatement or connection : msisdn ["
							+ userBean.getMsisdn() + "]");
				}

			}
			logger.info("Returning status. MSISDN [" + userBean.getMsisdn() + "] " + "RequestID["
					+ userBean.getTransaction_Id() + "] status [" + status + "]");
			return status;
		}

		public int insertUserPackPurchaseDetails(UserPackPurchaseBean packPurchaseBean, Connection con) {
			logger.debug(packPurchaseBean.getTransaction_Id()
					+ " maintainUserPurchaseDetails() >> now maintaining user pack purchase details, " + "query ["
					+ DataBaseQueries.INSERT_USER_PACK_PURCHASE_DETAILS + "]");
			int result = -1;
			PreparedStatement pstmt = null;
			try {
				if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.ORACLE_DB) {
					pstmt = con.prepareStatement(DataBaseQueries.INSERT_USER_PACK_PURCHASE_DETAILS);
					pstmt.setString(1, packPurchaseBean.getTransaction_Id());
					pstmt.setString(2, packPurchaseBean.getMsisdn());
					pstmt.setInt(3, packPurchaseBean.getPack_Id());
					pstmt.setString(4, packPurchaseBean.getPack_Name());
					pstmt.setInt(5, packPurchaseBean.getLang_Id());
					pstmt.setString(6, packPurchaseBean.getDescription());
					pstmt.setInt(7, packPurchaseBean.getValidity_Days());
					pstmt.setString(8, TSSJavaUtil.getValadityType(packPurchaseBean.getValidity_type()));
					pstmt.setInt(9, packPurchaseBean.getValidity_Days());
					pstmt.setString(10, packPurchaseBean.getValidity_type());
					pstmt.setInt(11, packPurchaseBean.getPack_Type());
					result = pstmt.executeUpdate();

				} else if (TSSJavaUtil.instance().getCacheParameters()
						.getDataBaseType() == MPCommonDataTypes.MYSQL_DB) {
					String query = DataBaseQueries.INSERT_USER_PACK_PURCHASE_DETAILS;

					query = query.replace(MPCommonDataTypes.INTERVALFORMAT,
							TSSJavaUtil.getValadityType(packPurchaseBean.getValidity_type()));

					pstmt = con.prepareStatement(query);
					pstmt.setString(1, packPurchaseBean.getTransaction_Id());
					pstmt.setString(2, packPurchaseBean.getMsisdn());
					pstmt.setInt(3, packPurchaseBean.getPack_Id());
					pstmt.setString(4, packPurchaseBean.getPack_Name());
					pstmt.setInt(5, packPurchaseBean.getLang_Id());
					pstmt.setString(6, packPurchaseBean.getDescription());
					pstmt.setInt(7, packPurchaseBean.getValidity_Days());
					pstmt.setInt(8, packPurchaseBean.getValidity_Days());
					pstmt.setString(9, packPurchaseBean.getValidity_type());
					pstmt.setInt(10, packPurchaseBean.getPack_Type());
					result = pstmt.executeUpdate();
				} else {
					logger.error(packPurchaseBean.getTransaction_Id() + " >> DatabaseType["
							+ TSSJavaUtil.instance().getCacheParameters().getDataBaseType()
							+ "] not found. Allowed DataBaseType[" + MPCommonDataTypes.ORACLE_DB + ","
							+ MPCommonDataTypes.MYSQL_DB + "]");
				}
				if (pstmt != null)
					pstmt.close();
			} catch (Exception e) {
				logger.error("Exception while inserting data in USER_PACK_PURCHASE_DETAILS table. MSISDN["
						+ packPurchaseBean.getMsisdn() + "] " + "TransactioID[" + packPurchaseBean.getTransaction_Id()
						+ "] ");
				result = -1;
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
				} catch (Exception exp) {
					logger.warn(
							">> Exception in insertUserPackPurchaseDetails method While closing resultSet or pstatement or connection.");
				}

			}
			return result;
		}

		public int deleteOldPackDetails(UserPackPurchaseBean packPurchaseBean, Connection con) {
			logger.debug(packPurchaseBean.getTransaction_Id()
					+ " deleteOldPackDetails() >> now deleting from user pack purchase details, " + "query ["
					+ DataBaseQueries.DELETE_USER_PACK_PURCHASE_DETAILS + "]");
			PreparedStatement pstmt = null;
			int result = -1;
			try {
				pstmt = con.prepareStatement(DataBaseQueries.DELETE_USER_PACK_PURCHASE_DETAILS);

				pstmt.setString(1, packPurchaseBean.getMsisdn());
				pstmt.setInt(2, packPurchaseBean.getPack_Type());
				result = pstmt.executeUpdate();
				pstmt.close();
			} catch (Exception e) {
				logger.error("Exception while deleting data from USER_PACK_PURCHASE_DETAILS table. MSISDN["
						+ packPurchaseBean.getMsisdn() + "] " + "TransactioID[" + packPurchaseBean.getTransaction_Id()
						+ "] ");
				result = -1;
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
				} catch (Exception exp) {
					logger.warn(
							">> Exception in insertUserPackPurchaseDetails method While closing resultSet or pstatement or connection.");
				}

			}

			return result;
		}

	}// LogsManager class ends

	public class SMSSender {

		/**
		 * Used to insert entry into database to send SMS to B party if talk-time is
		 * successfully transfered from A party to B party
		 * 
		 * @param userDataBean
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus sendSMSForTTTB(UserDataBean userDataBean, int validityDays) {
			logger.info(userDataBean.getRequestId()
					+ " >> Here going to insert entry into database for sending SMS to user, validityDays ["
					+ validityDays + "]" + " : " + userDataBean);

			int sequenceId = -99;
			String query = "";
			Connection con = TSSJavaUtil.instance().getConnPool().getConnection();
			String key = null;
			if (con == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00163")
						+ " >>connection to database is [" + con + "] "
						+ "so not inserting entry into database for sending SMS : msisdn [" + userDataBean.getMsisdn()
						+ "]");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			this.sendSMSForTTTA(userDataBean, validityDays, con);
			PreparedStatement pstmt = null;

			try {
				if (!TSSJavaUtil.instance().getCacheParameters().getInterfaceForTTTransferB().equalsIgnoreCase("NA")
						&& (TSSJavaUtil.instance().getCacheParameters().getInterfaceForTTTransferB()
								.equalsIgnoreCase("A"))
						|| (TSSJavaUtil.instance().getCacheParameters().getInterfaceForTTTransferB()
								.contains(userDataBean.getInterfaceUsed()))) {

					query = DataBaseQueries.SEND_SMS;

					if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
							&& TSSJavaUtil.instance().getCacheParameters()
									.getMysqlSequenceGeneratedFromSeqTable() != 1) {
						logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
								+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
								+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
								+ "] going to modify query. Not going to generate Sequence Id from Table.");

						// Updating query
						query = DataBaseQueries.SEND_SMS_1;
					}

					logger.debug(userDataBean.getRequestId() + " >> send ttt success sms query [" + query + "]");
					pstmt = con.prepareStatement(query);
					if ("MSISDN"
							.equalsIgnoreCase(TSSJavaUtil.instance().getCacheParameters().getSmsOriginationNumberB())) {
						String origNum = userDataBean.getMsisdn().replaceFirst(
								TSSJavaUtil.instance().getCountryCode(userDataBean.getMsisdn()),
								TSSJavaUtil.instance().getCacheParameters().getSmsOrigNumPrefixB());
						logger.debug("After replacement with country code the orig_num is [" + origNum + "]");
						pstmt.setString(1, origNum);
						logger.info(userDataBean.getRequestId() + " Sending SMS from ORIG_NUM [" + origNum + "]");
					} else {
						logger.debug("Sending SMS from ORIG_NUM ["
								+ TSSJavaUtil.instance().getCacheParameters().getSmsOriginationNumberB() + "]");
						pstmt.setString(1, TSSJavaUtil.instance().getCacheParameters().getSmsOriginationNumberB());
					}
					pstmt.setString(2, userDataBean.getFmsisdn());

					if (ServiceTypes.OFF_NET.equalsIgnoreCase(userDataBean.getNetType())) {
						key = SMSTemplateIDs.TTT_SUCCESS_TEMPLATE_ID_B_OFFNET + "_" + userDataBean.getLangId();
					} else if (ServiceTypes.ON_NET.equalsIgnoreCase(userDataBean.getNetType())) {
						key = SMSTemplateIDs.TTT_SUCCESS_TEMPLATE_ID_B_ONNET + "_" + userDataBean.getLangId();
					}
					String message = TSSJavaUtil.instance().getCacheParameters().getLbsTemplateMessage(key);
					if (message == null) {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00164")
								+ " >> message is not found in lbs template cache for key [" + key + "] "
								+ "so not inserting entry into database for sending SMS : msisdn ["
								+ userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}
					if (ServiceTypes.OFF_NET.equalsIgnoreCase(userDataBean.getNetType())) {
						message = message.replace("$(volume)", String.valueOf(userDataBean.getVolume()));
						message = message.replace("$(validity)", String.valueOf(validityDays));
					} else if (ServiceTypes.ON_NET.equalsIgnoreCase(userDataBean.getNetType())) {
						message = message.replace("$(volume)", String.valueOf(userDataBean.getVolume()));
						message = message.replace("$(validity)", String.valueOf(validityDays));
					}

					pstmt.setString(3, message);

					// Code to get the sequenceId for MySql By Siddharth
					if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
							&& TSSJavaUtil.instance().getCacheParameters()
									.getMysqlSequenceGeneratedFromSeqTable() == 1) {
						logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
								+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
								+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
								+ "] so setting ResponseId from Sequence Table.");
						sequenceId = this.getGeneratedSequenceId(userDataBean);
						pstmt.setInt(4, sequenceId);
					}

					int result = pstmt.executeUpdate();
					logger.info(userDataBean.getRequestId() + " >> entry for sending SMS to B party into database "
							+ "query result is [" + result + "] message [" + message + "] : msisdn ["
							+ userDataBean.getMsisdn() + "]");

					pstmt.close();

					if (result > 0) {
						return CodeStatus.SUCCESS;
					} else {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00165")
								+ " >> Failed to insert entry for " + "sending SMS into database, query result is ["
								+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}

				} else {
					logger.info(userDataBean.getRequestId() + " >> Not sending SMS to User B because "
							+ "SMS allowed on interfaces in this case are ["
							+ TSSJavaUtil.instance().getCacheParameters().getInterfaceForTTTransferB() + "] "
							+ "but request is from [" + userDataBean.getInterfaceUsed() + "] , msisdn ["
							+ userDataBean.getMsisdn() + "]");
					return CodeStatus.SUCCESS;
				}
			} catch (SQLException sqle) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ "  >> SQLException occurred during insertion, msisdn [" + userDataBean.getMsisdn() + "]",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred, msisdn [" + userDataBean.getMsisdn() + "] pstmt:[" + pstmt
						+ "]", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00166")
						+ " >> Exception occurred while inserting entry into database" + " for sending SMS : msisdn ["
						+ userDataBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
					if (con != null)
						con.close();
				} catch (Exception exp) {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00167")
							+ " >> Exception While closing  prepared statement " + "or connection : msisdn ["
							+ userDataBean.getMsisdn() + "]");
				}
			}

		}// sendSMSForTTTB() ends

		/**
		 * This method is used to get the generated sequence
		 * 
		 * @param id
		 * @return sequenceId
		 * @author siddharth
		 */
		public int getGeneratedSequenceId(UserDataBean userDataBean) {
			logger.info(userDataBean.getRequestId() + " >> Inside getGeneratedSequenceId method to get sequenceId");

			Statement stmt = null;
			ResultSet rs = null;
			int numRow = 0;
			int sequenceId = -99;

			Connection con = TSSJavaUtil.instance().getConnPool().getConnection();

			if (con == null) {
				logger.error(userDataBean.getRequestId() + " >> connection to database is [" + con + "]. so returning ["
						+ sequenceId + "]");
				return sequenceId;
			}

			try {
				stmt = con.createStatement();
				String query = DataBaseQueries.INSERT_SEQUENCE;
				logger.info("Query:" + DataBaseQueries.INSERT_SEQUENCE);

				numRow = stmt.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);

				rs = stmt.getGeneratedKeys();
				if (rs.next()) {
					sequenceId = rs.getInt(1);
				}

				logger.info(userDataBean.getRequestId() + " >> Response of getGeneratedSequenceId >> numRow[" + numRow
						+ "] sequenceId[" + sequenceId + "]");

				rs.close();
				stmt.close();
				con.close();
			} // try
			catch (SQLException sqle) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ "  >> SQLException occurred during insertion, msisdn [" + userDataBean.getMsisdn() + "]",
						sqle);
				return sequenceId;
			} catch (NullPointerException npe) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred, msisdn [" + userDataBean.getMsisdn() + "]", npe);
				return sequenceId;
			} catch (Exception e) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00295")
						+ " >> Exception occurred while inserting entry into database in getGeneratedSequenceId method : msisdn ["
						+ userDataBean.getMsisdn() + "]", e);
				return sequenceId;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
					if (con != null)
						con.close();
				} catch (Exception exp) {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00296")
							+ " >> Exception While closing result set or statement " + "or connection : msisdn ["
							+ userDataBean.getMsisdn() + "]");
				}
			}

			return sequenceId;
		}// end of getGeneratedSequenceId

		/**
		 * Used to insert entry into database to send SMS to A party if talk-time is
		 * successfully transfered from A party to B party
		 * 
		 * @param userDataBean
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */

		public CodeStatus sendSMSForTTTA(UserDataBean userDataBean, int validityDays, Connection con) {

			logger.info(userDataBean.getRequestId()
					+ " >> Here going to insert entry into database for sending SMS to User A, validityDays ["
					+ validityDays + "]" + " : " + userDataBean);

			String query = "";
			int sequenceId = -99;
			String key = null;
			double serviceCharge = 0.0;
			if (ServiceTypes.ON_NET.equals(userDataBean.getNetType())) {
				serviceCharge = TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOnNet();
			} else if (ServiceTypes.OFF_NET.equals(userDataBean.getNetType())) {
				serviceCharge = TSSJavaUtil.instance().getCacheParameters().getTttServiceChargeOffNet();
			}

			PreparedStatement pstmt = null;
			try {
				if (!TSSJavaUtil.instance().getCacheParameters().getInterfaceForTTTransferA().equalsIgnoreCase("NA")
						&& (TSSJavaUtil.instance().getCacheParameters().getInterfaceForTTTransferA()
								.equalsIgnoreCase("A"))
						|| (TSSJavaUtil.instance().getCacheParameters().getInterfaceForTTTransferA()
								.contains(userDataBean.getInterfaceUsed()))) {

					query = DataBaseQueries.SEND_SMS;

					if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
							&& TSSJavaUtil.instance().getCacheParameters()
									.getMysqlSequenceGeneratedFromSeqTable() != 1) {
						logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
								+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
								+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
								+ "] going to modify query. Not going to generate Sequence Id from Table.");

						// Updating query
						query = DataBaseQueries.SEND_SMS_1;
					}

					logger.debug(userDataBean.getRequestId() + " >> send ttt success sms query [" + query + "]");
					pstmt = con.prepareStatement(query);

					logger.debug("Sending SMS to Party A from ORIG_NUM ["
							+ TSSJavaUtil.instance().getCacheParameters().getSmsOrigNumberTTTA() + "]");
					pstmt.setString(1, TSSJavaUtil.instance().getCacheParameters().getSmsOrigNumberTTTA());
					pstmt.setString(2, userDataBean.getMsisdn());

					if (ServiceTypes.OFF_NET.equals(userDataBean.getNetType())) {
						key = SMSTemplateIDs.TTT_SUCCESS_TEMPLATE_ID_A_OFFNET + "_" + userDataBean.getLangId();
					} else if (ServiceTypes.ON_NET.equals(userDataBean.getNetType())) {
						key = SMSTemplateIDs.TTT_SUCCESS_TEMPLATE_ID_A_ONNET + "_" + userDataBean.getLangId();
					}
					String message = TSSJavaUtil.instance().getCacheParameters().getLbsTemplateMessage(key);
					if (message == null) {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00281")
								+ " >> message is not found in lbs template cache for key [" + key + "] "
								+ "so not inserting entry into database for sending SMS to Party 'A' : msisdn ["
								+ userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}
					if (ServiceTypes.OFF_NET.equalsIgnoreCase(userDataBean.getNetType())) {
						message = message.replace("$(volume)", String.valueOf(userDataBean.getVolume()));
						message = message.replace("$(fmsisdn)", userDataBean.getFmsisdn());

						if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
							message = message.replace("$(service_charge)", String.valueOf(serviceCharge));
						} else {
							message = message.replace("$(service_charge)", String.valueOf((int) serviceCharge));
						}
					} else if (ServiceTypes.ON_NET.equalsIgnoreCase(userDataBean.getNetType())) {
						message = message.replace("$(volume)", String.valueOf(userDataBean.getVolume()));
						message = message.replace("$(fmsisdn)", userDataBean.getFmsisdn());
						if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
							message = message.replace("$(service_charge)", String.valueOf(serviceCharge));
						} else {
							message = message.replace("$(service_charge)", String.valueOf((int) serviceCharge));
						}
					}

					pstmt.setString(3, message);

					// Code to get the sequenceId for MySql By Siddharth
					if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
							&& TSSJavaUtil.instance().getCacheParameters()
									.getMysqlSequenceGeneratedFromSeqTable() == 1) {
						logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
								+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
								+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
								+ "] so setting ResponseId from Sequence Table.");
						sequenceId = this.getGeneratedSequenceId(userDataBean);
						pstmt.setInt(4, sequenceId);
					}

					int result = pstmt.executeUpdate();
					logger.info(userDataBean.getRequestId() + " >> entry for sending SMS to Party A into database "
							+ "query result is [" + result + "] message [" + message + "] : msisdn ["
							+ userDataBean.getMsisdn() + "]");

					pstmt.close();

					if (result > 0) {
						return CodeStatus.SUCCESS;
					} else {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00165")
								+ " >> Failed to insert entry for "
								+ "sending SMS to Party A into database, query result is [" + result + "] : msisdn ["
								+ userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}

				} // if NA work
				else {
					logger.info(userDataBean.getRequestId() + " >> Not sending SMS to User A because "
							+ "SMS allowed on interfaces in this case are ["
							+ TSSJavaUtil.instance().getCacheParameters().getInterfaceForTTTransferA() + "] "
							+ "but request is from [" + userDataBean.getInterfaceUsed() + "] , msisdn ["
							+ userDataBean.getMsisdn() + "]");
					return CodeStatus.SUCCESS;
				}

			} // try
			catch (SQLException sqle) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ "  >> SQLException occurred during insertion, msisdn [" + userDataBean.getMsisdn() + "]",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred, msisdn [" + userDataBean.getMsisdn() + "] pstmt:[" + pstmt
						+ "]", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00283")
						+ " >> Exception occurred while inserting entry into database"
						+ " for sending SMS to Party A: msisdn [" + userDataBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
				} catch (Exception exp) {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00290")
							+ " >> Exception While closing prepaired statement " + ": msisdn ["
							+ userDataBean.getMsisdn() + "]");
				}
			}
		}// sendSMSForTTTA() ends

		/**
		 * Used to insert entry into database to send SMS to B party if bonus is
		 * successfully transfered (gifted) from A party to B party
		 * 
		 * @param userDataBean
		 * @param packBean
		 * @param serviceChargeDetails
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus sendSMSToBForBonus(UserDataBean userDataBean, PackBean packBean,
				ServiceCharge serviceChargeDetails) {
			logger.info(userDataBean.getRequestId()
					+ " >> Here going to insert entry into database for sending SMS to user" + " : " + userDataBean
					+ " packBean [" + packBean + "] serviceChargeDetails [" + serviceChargeDetails + "]");

			String query = "";
			int sequenceId = -99;
			Connection con = TSSJavaUtil.instance().getConnPool().getConnection();

			if (con == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00168")
						+ " >> connection to database is [" + con + "] "
						+ "so not inserting entry into database for sending SMS : msisdn [" + userDataBean.getMsisdn()
						+ "]");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			this.sendSMSToAForBonus(userDataBean, packBean, serviceChargeDetails, con);
			PreparedStatement pstmt = null;

			try {
				if (!TSSJavaUtil.instance().getCacheParameters().getInterfaceForBonusB().equalsIgnoreCase("NA")
						&& (TSSJavaUtil.instance().getCacheParameters().getInterfaceForBonusB().equalsIgnoreCase("A"))
						|| (TSSJavaUtil.instance().getCacheParameters().getInterfaceForBonusB()
								.contains(userDataBean.getInterfaceUsed()))) {

					query = DataBaseQueries.SEND_SMS;

					if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
							&& TSSJavaUtil.instance().getCacheParameters()
									.getMysqlSequenceGeneratedFromSeqTable() != 1) {
						logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
								+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
								+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
								+ "] going to modify query. Not going to generate Sequence Id from Table.");

						// Updating query
						query = DataBaseQueries.SEND_SMS_1;
					}

					logger.debug(userDataBean.getRequestId() + " >> send bonus to User B then success sms query ["
							+ query + "]");
					pstmt = con.prepareStatement(query);
					if ("MSISDN"
							.equalsIgnoreCase(TSSJavaUtil.instance().getCacheParameters().getSmsOriginationNumberB())) {
						String origNum = userDataBean.getMsisdn().replaceFirst(
								TSSJavaUtil.instance().getCountryCode(userDataBean.getMsisdn()),
								TSSJavaUtil.instance().getCacheParameters().getSmsOrigNumPrefixB());
						logger.debug("After replacement with country code the orig_num is [" + origNum + "]");
						pstmt.setString(1, origNum);
						logger.info(userDataBean.getRequestId()
								+ " Sending SMS to User B for Bonus transfer from ORIG_NUM [" + origNum + "]");
					} else {
						logger.debug("Sending SMS from ORIG_NUM ["
								+ TSSJavaUtil.instance().getCacheParameters().getSmsOriginationNumberB() + "]");
						pstmt.setString(1, TSSJavaUtil.instance().getCacheParameters().getSmsOriginationNumberB());
					}
					pstmt.setString(2, userDataBean.getFmsisdn());
					String key = SMSTemplateIDs.BONUS_SUCCESS_TEMPLATE_ID_B + "_" + userDataBean.getLangId();
					String message = TSSJavaUtil.instance().getCacheParameters().getLbsTemplateMessage(key);
					if (message == null) {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00169")
								+ " >> message is not found in lbs template cache for key [" + key + "] "
								+ "so not inserting entry into database for sending SMS : msisdn ["
								+ userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}
					message = message.replace("$(pack_name)", packBean.getPackName());
					message = message.replace("$(pack_desc)", packBean.getDescription());
					message = message.replace("$(validity)", String.valueOf(serviceChargeDetails.getValidity()));

					String validityTypeStr = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							serviceChargeDetails.getValidityType().toUpperCase() + "_" + userDataBean.getLangId());
					message = message.replace("$(validity_type)", validityTypeStr);

					pstmt.setString(3, message);

					// Code to get the sequenceId for MySql By Siddharth
					if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
							&& TSSJavaUtil.instance().getCacheParameters()
									.getMysqlSequenceGeneratedFromSeqTable() == 1) {
						logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
								+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
								+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
								+ "] so setting ResponseId from Sequence Table.");
						sequenceId = this.getGeneratedSequenceId(userDataBean);
						pstmt.setInt(4, sequenceId);
					}

					int result = pstmt.executeUpdate();
					logger.info(userDataBean.getRequestId() + " >> entry for sending SMS to User B into database "
							+ "query result is [" + result + "] message [" + message + "] : msisdn ["
							+ userDataBean.getMsisdn() + "]");

					pstmt.close();

					if (result > 0) {
						return CodeStatus.SUCCESS;
					} else {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00170")
								+ "  >> Failed to insert entry for " + "sending SMS into database, query result is ["
								+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}
				} else {
					logger.info(userDataBean.getRequestId() + " >> Not sending SMS to User B because "
							+ "SMS allowed on interfaces in this case are ["
							+ TSSJavaUtil.instance().getCacheParameters().getInterfaceForBonusB() + "] "
							+ "but request is from [" + userDataBean.getInterfaceUsed() + "] , msisdn ["
							+ userDataBean.getMsisdn() + "]");
					return CodeStatus.SUCCESS;
				}
			}

			catch (SQLException sqle) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ "  >> SQLException occurred during insertion, msisdn [" + userDataBean.getMsisdn() + "]",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred, msisdn [" + userDataBean.getMsisdn() + "] pstmt:[" + pstmt
						+ "]", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00171")
						+ "  >> Exception occurred while inserting entry into database" + " for sending SMS : msisdn ["
						+ userDataBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
					if (con != null)
						con.close();
				} catch (Exception exp) {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00172")
							+ " >> Exception While closing result set or statement " + "or connection : msisdn ["
							+ userDataBean.getMsisdn() + "]");
				}
			}

		}// sendSMSToBForBonus() ends

		/**
		 * Used to insert entry into database to send SMS for VAS
		 * 
		 * @param userDataBean
		 * @param packBean
		 * @author siddharth
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus sendSMSForVAS(UserDataBean userDataBean, PackBean packBean) {
			logger.info(userDataBean.getRequestId()
					+ " >> inside sendSMSForVAS() for insert entry into database for sending SMS to user fro VAS"
					+ " : " + userDataBean + " packActionType [" + packBean.getPackOtherDetails().getPackActionType()
					+ "]");

			Connection con = TSSJavaUtil.instance().getConnPool().getConnection();

			if (con == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00168")
						+ " >> connection to database is [" + con + "] "
						+ "so not inserting entry into database for sending SMS : msisdn [" + userDataBean.getMsisdn()
						+ "]");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			PreparedStatement pstmt = null;
			int sequenceId = -99;
			String origNum = "";
			String destNum = "";
			String message = "";
			String query = "";

			try {

				query = DataBaseQueries.SEND_SMS;

				if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
						&& TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable() != 1) {
					logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
							+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
							+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
							+ "] going to modify query. Not going to generate Sequence Id from Table.");

					// Updating query
					query = DataBaseQueries.SEND_SMS_1;
				}

				logger.info(userDataBean.getRequestId() + " >> Sending SMS for VAS, QUERY [" + query + "]");

				pstmt = con.prepareStatement(query);

				origNum = userDataBean.getMsisdn();

				if (packBean.getPackOtherDetails() != null) {
					destNum = packBean.getPackOtherDetails().getDestNumb();
					message = packBean.getPackOtherDetails().getPackActionResp();
				} else {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00344")
							+ " >> packOtherDetails found null : msisdn [" + userDataBean.getMsisdn() + "]");
					return CodeStatus.FAILURE;
				}
				pstmt.setString(1, origNum);
				pstmt.setString(2, destNum);
				if (message == null || message.equalsIgnoreCase("NA")) {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00343")
							+ " >> message is not found in Response JSON. "
							+ "so not inserting entry into database for sending SMS : msisdn ["
							+ userDataBean.getMsisdn() + "]");
					return CodeStatus.FAILURE;
				}
				message = message.replace("$(pack_name)", packBean.getPackName());
				message = message.replace("$(pack_desc)", packBean.getDescription());

				pstmt.setString(3, message);

				// Code to get the sequenceId for MySql By Siddharth
				if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
						&& TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable() == 1) {
					logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
							+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
							+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
							+ "] so setting ResponseId from Sequence Table.");
					sequenceId = this.getGeneratedSequenceId(userDataBean);
					pstmt.setInt(4, sequenceId);
				}

				int result = pstmt.executeUpdate();
				logger.info(userDataBean.getRequestId() + " >> entry for sending SMS for VAS Service into database "
						+ "query result is [" + result + "], Origination Number [" + origNum + "],  Destination Number["
						+ destNum + "],  message [" + message + "] : msisdn [" + userDataBean.getMsisdn() + "]");

				pstmt.close();

				if (result > 0) {
					return CodeStatus.SUCCESS;
				} else {
					logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00170")
							+ "  >> Failed to insert entry for "
							+ "sending SMS for VAS into database, query result is [" + result
							+ "], Origination Number [" + origNum + "],  Destination Number[" + destNum
							+ "], : msisdn [" + userDataBean.getMsisdn() + "]");
					return CodeStatus.FAILURE;
				}
			}

			catch (SQLException sqle) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ "  >> SQLException occurred during insertion, msisdn [" + userDataBean.getMsisdn() + "]",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred, msisdn [" + userDataBean.getMsisdn() + "] pstmt:[" + pstmt
						+ "]", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00171")
						+ "  >> Exception occurred while inserting entry into database" + " for sending SMS : msisdn ["
						+ userDataBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
					if (con != null)
						con.close();
				} catch (Exception exp) {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00172")
							+ " >> Exception While closing result set or statement " + "or connection : msisdn ["
							+ userDataBean.getMsisdn() + "]");
				}
			}

		}

		/**
		 * Used to insert entry into database to send SMS to A party if bonus is
		 * successfully transfered (gifted) from A party to B party
		 * 
		 * @param userDataBean
		 * @param packBean
		 * @param serviceChargeDetails
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus sendSMSToAForBonus(UserDataBean userDataBean, PackBean packBean,
				ServiceCharge serviceChargeDetails, Connection con) {
			logger.info(userDataBean.getRequestId()
					+ " >> Here going to insert entry into database for sending SMS to user A" + " : " + userDataBean
					+ " packBean [" + packBean + "] serviceChargeDetails [" + serviceChargeDetails + "]");

			String query = "";
			int sequenceId = -99;
			PreparedStatement pstmt = null;
			try {
				if (!TSSJavaUtil.instance().getCacheParameters().getInterfaceForBonusA().equalsIgnoreCase("NA")
						&& (TSSJavaUtil.instance().getCacheParameters().getInterfaceForBonusA().equalsIgnoreCase("A"))
						|| (TSSJavaUtil.instance().getCacheParameters().getInterfaceForBonusA()
								.contains(userDataBean.getInterfaceUsed()))) {

					query = DataBaseQueries.SEND_SMS;

					if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
							&& TSSJavaUtil.instance().getCacheParameters()
									.getMysqlSequenceGeneratedFromSeqTable() != 1) {
						logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
								+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
								+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
								+ "] going to modify query. Not going to generate Sequence Id from Table.");

						// Updating query
						query = DataBaseQueries.SEND_SMS_1;
					}

					logger.debug(userDataBean.getRequestId() + " >> send bonus to User A then success sms query ["
							+ query + "]");
					pstmt = con.prepareStatement(query);
					pstmt.setString(1, TSSJavaUtil.instance().getCacheParameters().getSmsOrigNumberBonusA());
					pstmt.setString(2, userDataBean.getMsisdn());
					String key = SMSTemplateIDs.BONUS_SUCCESS_TEMPLATE_ID_A + "_" + userDataBean.getLangId();
					String message = TSSJavaUtil.instance().getCacheParameters().getLbsTemplateMessage(key);
					if (message == null) {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00169")
								+ " >> message is not found in lbs template cache for key [" + key + "] "
								+ "so not inserting entry into database for sending SMS : msisdn ["
								+ userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}
					message = message.replace("$(pack_name)", packBean.getPackName());
					message = message.replace("$(pack_desc)", packBean.getDescription());
					message = message.replace("$(validity)", String.valueOf(serviceChargeDetails.getValidity()));

					String validityTypeStr = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							serviceChargeDetails.getValidityType().toUpperCase() + "_" + userDataBean.getLangId());
					message = message.replace("$(validity_type)", validityTypeStr);

					message = message.replace("$(fmsisdn)", userDataBean.getFmsisdn());
					if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
						message = message.replace("$(service_charge)", String
								.valueOf(serviceChargeDetails.getServiceCharge() + serviceChargeDetails.getVolume()));
					} else {
						message = message.replace("$(service_charge)", String.valueOf(
								(int) serviceChargeDetails.getServiceCharge() + serviceChargeDetails.getVolume()));
					}

					pstmt.setString(3, message);

					// Code to get the sequenceId for MySql By Siddharth
					if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
							&& TSSJavaUtil.instance().getCacheParameters()
									.getMysqlSequenceGeneratedFromSeqTable() == 1) {
						logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
								+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
								+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
								+ "] so setting ResponseId from Sequence Table.");
						sequenceId = this.getGeneratedSequenceId(userDataBean);
						pstmt.setInt(4, sequenceId);
					}

					int result = pstmt.executeUpdate();
					logger.info(userDataBean.getRequestId() + " >> entry for sending SMS to User A into database "
							+ "query result is [" + result + "] message [" + message + "] : msisdn ["
							+ userDataBean.getMsisdn() + "]");

					pstmt.close();

					if (result > 0) {
						return CodeStatus.SUCCESS;
					} else {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00288")
								+ "  >> Failed to insert entry for " + "sending SMS into database, query result is ["
								+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}
				} else {
					logger.info(userDataBean.getRequestId() + " >> Not sending SMS to User A because "
							+ "SMS allowed on interfaces in this case are ["
							+ TSSJavaUtil.instance().getCacheParameters().getInterfaceForBonusA() + "] "
							+ "but request is from [" + userDataBean.getInterfaceUsed() + "] , msisdn ["
							+ userDataBean.getMsisdn() + "]");
					return CodeStatus.SUCCESS;
				}
			}

			catch (SQLException sqle) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ "  >> SQLException occurred during insertion, msisdn [" + userDataBean.getMsisdn() + "]",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred, msisdn [" + userDataBean.getMsisdn() + "] pstmt:[" + pstmt
						+ "]", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00171")
						+ "  >> Exception occurred while inserting entry into database" + " for sending SMS : msisdn ["
						+ userDataBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
				} catch (Exception exp) {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00289")
							+ " >> Exception While closing result set or statement " + "or connection : msisdn ["
							+ userDataBean.getMsisdn() + "]");
				}
			}

		}// sendSMSToAForBonus() ends

		/**
		 * Used to insert entry into database to send SMS to B party if data is
		 * successfully transfered from A party to B party
		 * 
		 * @param userDataBean
		 * @param packBean
		 * @param serviceChargeDetails
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus sendSMSToBForDT(UserDataBean userDataBean, PackBean packBean,
				ServiceCharge serviceChargeDetails) {
			logger.info(userDataBean.getRequestId()
					+ " >> Here going to insert entry into database for sending SMS to user B" + " : " + userDataBean
					+ " packBean [" + packBean + "] serviceChargeDetails [" + serviceChargeDetails + "]");

			Connection con = TSSJavaUtil.instance().getConnPool().getConnection();

			if (con == null) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00173")
						+ " >> connection to database is [" + con + "] "
						+ "so not inserting entry into database for sending SMS : msisdn [" + userDataBean.getMsisdn()
						+ "]");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			this.sendSMSToAForDT(userDataBean, packBean, serviceChargeDetails, con);

			PreparedStatement pstmt = null;
			String query = "";
			int sequenceId = -99;

			try {
				if (!TSSJavaUtil.instance().getCacheParameters().getInterfaceForDataTransferB().equalsIgnoreCase("NA")
						&& (TSSJavaUtil.instance().getCacheParameters().getInterfaceForDataTransferB()
								.equalsIgnoreCase("A"))
						|| (TSSJavaUtil.instance().getCacheParameters().getInterfaceForDataTransferB()
								.contains(userDataBean.getInterfaceUsed()))) {

					query = DataBaseQueries.SEND_SMS;

					if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
							&& TSSJavaUtil.instance().getCacheParameters()
									.getMysqlSequenceGeneratedFromSeqTable() != 1) {
						logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
								+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
								+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
								+ "] going to modify query. Not going to generate Sequence Id from Table.");

						// Updating query
						query = DataBaseQueries.SEND_SMS_1;
					}

					logger.debug(userDataBean.getRequestId()
							+ " >> send data transfer to user B then success sms query [" + query + "]");
					pstmt = con.prepareStatement(query);
					if ("MSISDN"
							.equalsIgnoreCase(TSSJavaUtil.instance().getCacheParameters().getSmsOriginationNumberB())) {
						String origNum = userDataBean.getMsisdn().replaceFirst(
								TSSJavaUtil.instance().getCountryCode(userDataBean.getMsisdn()),
								TSSJavaUtil.instance().getCacheParameters().getSmsOrigNumPrefixB());
						logger.debug("After replacement with country code the orig_num is [" + origNum + "]");
						pstmt.setString(1, origNum);
						logger.info(userDataBean.getRequestId()
								+ " Sending SMS to User B for DT transfer from ORIG_NUM [" + origNum + "]");
					} else {
						logger.debug("Sending SMS from ORIG_NUM ["
								+ TSSJavaUtil.instance().getCacheParameters().getSmsOriginationNumberB() + "]");
						pstmt.setString(1, TSSJavaUtil.instance().getCacheParameters().getSmsOriginationNumberB());
					}
					pstmt.setString(2, userDataBean.getFmsisdn());

					String key = SMSTemplateIDs.DT_SUCCESS_TEMPLATE_ID_B + "_" + userDataBean.getLangId();
					String message = TSSJavaUtil.instance().getCacheParameters().getLbsTemplateMessage(key);
					if (message == null) {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00174")
								+ " >> message is not found in lbs template cache for key [" + key + "] "
								+ "so not inserting entry into database for sending SMS : msisdn ["
								+ userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}

					message = message.replace("$(pack_name)", packBean.getPackName());
					message = message.replace("$(pack_desc)", packBean.getDescription());

					message = message.replace("$(volume)", String.valueOf(serviceChargeDetails.getVolume()));
					String volumeTypeStr = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							serviceChargeDetails.getVolumeType().toUpperCase() + "_" + userDataBean.getLangId());
					message = message.replace("$(volume_type)", volumeTypeStr);

					message = message.replace("$(validity)", String.valueOf(serviceChargeDetails.getValidity()));
					String validityTypeStr = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							serviceChargeDetails.getValidityType().toUpperCase() + "_" + userDataBean.getLangId());
					message = message.replace("$(validity_type)", validityTypeStr);

					pstmt.setString(3, message);

					// Code to get the sequenceId for MySql By Siddharth
					if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
							&& TSSJavaUtil.instance().getCacheParameters()
									.getMysqlSequenceGeneratedFromSeqTable() == 1) {
						logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
								+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
								+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
								+ "] so setting ResponseId from Sequence Table.");
						sequenceId = this.getGeneratedSequenceId(userDataBean);
						pstmt.setInt(4, sequenceId);
					}

					int result = pstmt.executeUpdate();
					logger.info(userDataBean.getRequestId() + " >> entry for sending SMS to User B into database "
							+ "query result is [" + result + "] key [" + key + "] message [" + message + "] : msisdn ["
							+ userDataBean.getMsisdn() + "]");

					pstmt.close();

					if (result > 0) {
						return CodeStatus.SUCCESS;
					} else {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00175")
								+ "  >> Failed to insert entry for " + "sending SMS into database, query result is ["
								+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}
				} else {
					logger.info(userDataBean.getRequestId() + " >> Not sending SMS to User B because "
							+ "SMS allowed on interfaces in this case are ["
							+ TSSJavaUtil.instance().getCacheParameters().getInterfaceForDataTransferB() + "] "
							+ "but request is from [" + userDataBean.getInterfaceUsed() + "] , msisdn ["
							+ userDataBean.getMsisdn() + "]");
					return CodeStatus.SUCCESS;
				}
			} // try

			catch (SQLException sqle) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ "  >> SQLException occurred during insertion, msisdn [" + userDataBean.getMsisdn() + "]",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred, msisdn [" + userDataBean.getMsisdn() + "] pstmt:[" + pstmt
						+ "]", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00176")
						+ " >> Exception occurred while inserting entry into database" + " for sending SMS : msisdn ["
						+ userDataBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
					if (con != null)
						con.close();
				} catch (Exception exp) {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00177")
							+ " >> Exception While closing result set or statement " + "or connection : msisdn ["
							+ userDataBean.getMsisdn() + "]");
				}
			}

		}// sendSMSToBForDT() ends

		/**
		 * Used to insert entry into database to send SMS to A party if data is
		 * successfully transfered from A party to B party
		 * 
		 * @param userDataBean
		 * @param packBean
		 * @param serviceChargeDetails
		 * @param con
		 * @return status of the execution of this method means success, failure,
		 *         exception occurred etc.
		 */
		public CodeStatus sendSMSToAForDT(UserDataBean userDataBean, PackBean packBean,
				ServiceCharge serviceChargeDetails, Connection con) {
			logger.info(userDataBean.getRequestId()
					+ " >> Here going to insert entry into database for sending SMS to user B" + " : " + userDataBean
					+ " packBean [" + packBean + "] serviceChargeDetails [" + serviceChargeDetails + "]");

			String query = "";
			int sequenceId = -99;
			PreparedStatement pstmt = null;

			try {
				if (!TSSJavaUtil.instance().getCacheParameters().getInterfaceForDataTransferA().equalsIgnoreCase("NA")
						&& (TSSJavaUtil.instance().getCacheParameters().getInterfaceForDataTransferA()
								.equalsIgnoreCase("A"))
						|| (TSSJavaUtil.instance().getCacheParameters().getInterfaceForDataTransferA()
								.contains(userDataBean.getInterfaceUsed()))) {

					query = DataBaseQueries.SEND_SMS;

					if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
							&& TSSJavaUtil.instance().getCacheParameters()
									.getMysqlSequenceGeneratedFromSeqTable() != 1) {
						logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
								+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
								+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
								+ "] going to modify query. Not going to generate Sequence Id from Table.");

						// Updating query
						query = DataBaseQueries.SEND_SMS_1;
					}

					logger.debug(userDataBean.getRequestId()
							+ " >> send data transfer to user A then success sms query [" + query + "]");
					pstmt = con.prepareStatement(query);
					logger.debug("Sending SMS from ORIG_NUM ["
							+ TSSJavaUtil.instance().getCacheParameters().getSmsOrigNumberDataTransferA() + "]");
					pstmt.setString(1, TSSJavaUtil.instance().getCacheParameters().getSmsOrigNumberDataTransferA());
					pstmt.setString(2, userDataBean.getMsisdn());

					String key = SMSTemplateIDs.DT_SUCCESS_TEMPLATE_ID_A + "_" + userDataBean.getLangId();
					String message = TSSJavaUtil.instance().getCacheParameters().getLbsTemplateMessage(key);
					if (message == null) {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00292")
								+ " >> message is not found in lbs template cache for key [" + key + "] "
								+ "so not inserting entry into database for sending SMS : msisdn ["
								+ userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}

					message = message.replace("$(pack_name)", packBean.getPackName());
					message = message.replace("$(pack_desc)", packBean.getDescription());
					message = message.replace("$(volume)", String.valueOf(serviceChargeDetails.getVolume()));

					String volumeTypeStr = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							serviceChargeDetails.getVolumeType().toUpperCase() + "_" + userDataBean.getLangId());
					message = message.replace("$(volume_type)", volumeTypeStr);

					message = message.replace("$(fmsisdn)", userDataBean.getFmsisdn());
					if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
						message = message.replace("$(service_charge)",
								String.valueOf(serviceChargeDetails.getServiceCharge()));
					} else {
						message = message.replace("$(service_charge)",
								String.valueOf((int) serviceChargeDetails.getServiceCharge()));
					}

					pstmt.setString(3, message);

					// Code to get the sequenceId for MySql By Siddharth
					if (TSSJavaUtil.instance().getCacheParameters().getDataBaseType() == MPCommonDataTypes.MYSQL_DB
							&& TSSJavaUtil.instance().getCacheParameters()
									.getMysqlSequenceGeneratedFromSeqTable() == 1) {
						logger.info("DataBaseType found [" + MPCommonDataTypes.MYSQL_DB
								+ "] {1:Oracle, 2:MySql} with MysqlSequenceGeneratedFromSeqTable ["
								+ TSSJavaUtil.instance().getCacheParameters().getMysqlSequenceGeneratedFromSeqTable()
								+ "] so setting ResponseId from Sequence Table.");
						sequenceId = this.getGeneratedSequenceId(userDataBean);
						pstmt.setInt(4, sequenceId);
					}

					int result = pstmt.executeUpdate();
					logger.info(userDataBean.getRequestId() + " >> entry for sending SMS to User A into database "
							+ "query result is [" + result + "] key [" + key + "] message [" + message + "] : msisdn ["
							+ userDataBean.getMsisdn() + "]");

					pstmt.close();

					if (result > 0) {
						return CodeStatus.SUCCESS;
					} else {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00293")
								+ "  >> Failed to insert entry for " + "sending SMS into database, query result is ["
								+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					}
				} else {
					logger.info(userDataBean.getRequestId() + " >> Not sending SMS to User A because "
							+ "SMS allowed on interfaces in this case are ["
							+ TSSJavaUtil.instance().getCacheParameters().getInterfaceForDataTransferA() + "] "
							+ "but request is from [" + userDataBean.getInterfaceUsed() + "] , msisdn ["
							+ userDataBean.getMsisdn() + "]");
					return CodeStatus.SUCCESS;
				}
			} // try

			catch (SQLException sqle) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ "  >> SQLException occurred during insertion, msisdn [" + userDataBean.getMsisdn() + "]",
						sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ " >> NullPointerException occurred, msisdn [" + userDataBean.getMsisdn() + "] pstmt:[" + pstmt
						+ "]", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00295")
						+ " >> Exception occurred while inserting entry into database" + " for sending SMS : msisdn ["
						+ userDataBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (pstmt != null)
						pstmt.close();
				} catch (Exception exp) {
					logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00296")
							+ " >> Exception While closing result set or statement " + "or connection : msisdn ["
							+ userDataBean.getMsisdn() + "]");
				}
			}

		}// sendSMSToAForDT() ends

	}// SMSSender class ends

	public class UserProfile {

		public CodeStatus getUserCompleteProfile(UserDataBean dataBean, UserProfileBean profileBean) {

			logger.info(
					dataBean.getRequestId() + " getUserCompleteProfile() >> Here going to select entry from database"
							+ " for user Profile " + dataBean.getMsisdn());
			Connection con = TSSJavaUtil.instance().getConnPool().getConnection();
			if (con == null) {
				logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00054")
						+ "  >> connection to database is [" + con + "] "
						+ "so not selecting data from USER_PROFILE_MASTER : msisdn [" + dataBean.getMsisdn() + "]");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				logger.debug(dataBean.getRequestId() + " getUserCompleteProfile >> " + "query ["
						+ DataBaseQueries.GET_USER_PROFILE + "]");

				pstmt = con.prepareStatement(DataBaseQueries.GET_USER_PROFILE);

				pstmt.setString(1, dataBean.getMsisdn());
				rs = pstmt.executeQuery();
				if (rs.next()) {
					profileBean.setUserId(rs.getString("USER_ID"));
					profileBean.setMsisdn("MSISDN");
					profileBean.setLanguage(rs.getInt("LANGUAGE"));
					profileBean.setPassword(rs.getString("PASSWORD"));
					profileBean.setName(rs.getString("NAME"));
					profileBean.setEmail_Id(rs.getString("MAIL_ID"));
					profileBean.setStatus(rs.getString("STATUS"));
					profileBean.setGender(rs.getString("GENDER"));
					profileBean.setDate_registered(rs.getString("DATE_REGISTERED"));
					profileBean.setLast_Visit_Time(rs.getString("LAST_VISIT_TIME"));
					profileBean.setOthers(rs.getString("OTHERS"));
					profileBean.setSubType(rs.getString("SUB_TYPE"));

					logger.info(
							"[" + dataBean.getRequestId() + "] Fetched profileBean[" + profileBean.toString() + "] ");

					return CodeStatus.SUCCESS;
				} else {
					logger.info("[" + dataBean.getRequestId() + "] MSISDN[" + dataBean.getMsisdn()
							+ "] No Profile Found !!");
					return CodeStatus.FAILURE;
				}
			} catch (SQLException sqle) {
				logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while getting entry from database"
						+ " from USER_PROFILE_MASTER : msisdn [" + dataBean.getMsisdn() + "]", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ "  >> NullPointerException occurred while getting entry from database"
						+ " from USER_PROFILE_MASTER : msisdn [" + dataBean.getMsisdn() + "] pstmt:[" + pstmt + "]",
						npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00056")
						+ " >> Exception occurred while getting entry from database"
						+ " from USER_PROFILE_MASTER : msisdn [" + dataBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (con != null)
						con.close();

				} catch (Exception exp) {
					logger.warn(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00057")
							+ " >> Exception While closing result ser or pstatement or connection while : msisdn ["
							+ dataBean.getMsisdn() + "]");
				}
			}
		}

		public CodeStatus getUserActivePlan(UserDataBean dataBean, ArrayList<UserPackPurchaseBean> purchaseList) {

			logger.info(dataBean.getRequestId() + " getUserActivePlan() >> Here going to select entry from database"
					+ " for user Profile " + dataBean.getMsisdn());
			UserPackPurchaseBean packPurchaseBean = null;
			Connection con = TSSJavaUtil.instance().getConnPool().getConnection();
			if (con == null) {
				logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00054")
						+ "  >> connection to database is [" + con + "] "
						+ "so not selecting data from USER_PACK_PURCHASE_DETAILS : msisdn [" + dataBean.getMsisdn()
						+ "]");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				logger.debug(dataBean.getRequestId() + " getUserActivePlan >> " + "query ["
						+ DataBaseQueries.GET_USER_ACTIVE_PACK + "]");

				pstmt = con.prepareStatement(DataBaseQueries.GET_USER_ACTIVE_PACK);
				pstmt.setString(1, dataBean.getMsisdn());
				/*
				 * pstmt.setInt(2, erow+1); pstmt.setInt(3, srow);
				 */

				rs = pstmt.executeQuery();
				while (rs.next()) {
					packPurchaseBean = new UserPackPurchaseBean();
					packPurchaseBean.setTransaction_Id(rs.getString("TRANSACTION_ID"));
					packPurchaseBean.setMsisdn(rs.getString("MSISDN"));
					packPurchaseBean.setPack_Id(rs.getInt("PACK_ID"));
					packPurchaseBean.setPack_Name(rs.getString("PACK_NAME"));
					packPurchaseBean.setLang_Id(rs.getInt("LANG_ID"));
					packPurchaseBean.setDescription(rs.getString("DESCRIPTION"));
					packPurchaseBean.setExpiry_Date(rs.getString("EXPIRY_DATE"));
					packPurchaseBean.setValidity_Days(rs.getInt("VALIDITY_DAYS"));
					packPurchaseBean.setValidity_type(rs.getString("VALIDITY_TYPE"));
					packPurchaseBean.setPromptFilePath(rs.getString("PROMPT_FILE"));
					packPurchaseBean.setOthers(rs.getString("OTHERS"));
					purchaseList.add(packPurchaseBean);
				}
				if (purchaseList.size() > 0) {
					logger.warn(dataBean.getRequestId() + " >>(IVR) Total entries found [" + purchaseList.size()
							+ "] where msisdn [" + dataBean.getMsisdn() + "]");
					return CodeStatus.SUCCESS;
				} else {
					logger.warn(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00322")
							+ "(IVR) >> getUserActivePlan() no active plan found for the msisdn ["
							+ dataBean.getMsisdn() + "].");
					return CodeStatus.FAILURE;
				}
			} catch (SQLException sqle) {
				logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while getting entry from database"
						+ " from USER_PACK_PURCHASE_DETAILS : msisdn [" + dataBean.getMsisdn() + "]", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ "  >> NullPointerException occurred while getting entry from database"
						+ " from USER_PACK_PURCHASE_DETAILS : msisdn [" + dataBean.getMsisdn() + "] pstmt:[" + pstmt
						+ "]", npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00056")
						+ " >> Exception occurred while getting entry from database"
						+ " from USER_PACK_PURCHASE_DETAILS : msisdn [" + dataBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (con != null)
						con.close();

				} catch (Exception exp) {
					logger.warn(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00057")
							+ " >> Exception While closing resultSet or pstatement or connection : msisdn ["
							+ dataBean.getMsisdn() + "]");
				}
			}
		}

		public CodeStatus getUserTransaction(UserDataBean dataBean, ArrayList<UserTransactionBean> transactionList) {

			UserTransactionBean transactionBean = null;
			logger.info(dataBean.getRequestId() + " getUserTransaction() >> Here going to select entry from database"
					+ " for user transaction detail " + dataBean.getMsisdn());
			Connection con = TSSJavaUtil.instance().getConnPool().getConnection();
			if (con == null) {
				logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00054")
						+ "  >> connection to database is [" + con + "] "
						+ "so not selecting data from USER_TRANSACTION_CDRS : msisdn [" + dataBean.getMsisdn() + "]");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				logger.debug(dataBean.getRequestId() + " getUserTransaction >> " + "query ["
						+ DataBaseQueries.GET_USER_TRANSACTION_CDRS + "]");

				pstmt = con.prepareStatement(DataBaseQueries.GET_USER_TRANSACTION_CDRS);

				pstmt.setString(1, dataBean.getMsisdn());
				pstmt.setInt(2, TSSJavaUtil.instance().getCacheParameters().getTransactionCdrLimit());
				rs = pstmt.executeQuery();
				while (rs.next()) {
					transactionBean = new UserTransactionBean();
					transactionBean.setTransaction_Id(rs.getString("TRANSACTION_ID"));
					transactionBean.setMsisdn(rs.getString("MSISDN"));
					transactionBean.setFmsisdn(rs.getString("FMSISDN"));
					transactionBean.setPack_Id(rs.getInt("PACK_ID"));
					transactionBean.setPack_Name(rs.getString("PACK_NAME"));
					transactionBean.setLang_Id(rs.getInt("LANG_ID"));
					transactionBean.setCreate_date(rs.getString("CREATE_DATE"));
					transactionBean.setExpiry_Date(rs.getString("EXPIRY_DATE"));
					transactionBean.setValidity_Days(rs.getInt("VALIDITY_DAYS"));
					transactionBean.setVolume(rs.getInt("VOLUME"));
					transactionBean.setTransaction_Type(rs.getString("TRANSACTION_TYPE"));
					transactionBean.setTransaction_Message(rs.getString("TRANSACTION_MESSAGE"));
					transactionBean.setOthers(rs.getString("OTHERS"));
					transactionBean.setValidity_type(rs.getString("VALIDITY_TYPE"));
					transactionBean.setPromptFilePath(rs.getString("PROMPT_FILE"));
					transactionList.add(transactionBean);
				}
				if (transactionList.size() > 0) {
					return CodeStatus.SUCCESS;
				} else {
					return CodeStatus.FAILURE;
				}
			} catch (SQLException sqle) {
				logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
						+ " >> SQLException occurred while getting entry from database"
						+ " from USER_TRANSACTION_CDRS : msisdn [" + dataBean.getMsisdn() + "]", sqle);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (NullPointerException npe) {
				logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
						+ "  >> NullPointerException occurred while getting entry from database"
						+ " from USER_TRANSACTION_CDRS : msisdn [" + dataBean.getMsisdn() + "] pstmt:[" + pstmt + "]",
						npe);
				return CodeStatus.EXCEPTION_OCCURED;
			} catch (Exception e) {
				logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00056")
						+ " >> Exception occurred while getting entry from database"
						+ " from USER_TRANSACTION_CDRS : msisdn [" + dataBean.getMsisdn() + "]", e);
				return CodeStatus.EXCEPTION_OCCURED;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (con != null)
						con.close();

				} catch (Exception exp) {
					logger.warn(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00057")
							+ " >> Exception While closing resultSet or pstatement or connection  : msisdn ["
							+ dataBean.getMsisdn() + "]");
				}
			}
		}

	}

	/**
	 * This method is used to get the list of available promotional packs product
	 * code for the requested user.
	 * 
	 * @param dataBean
	 * @author SIDDHARTH
	 * @return comma separated list of available promotional packs product codes in
	 *         normal execution | null in case of any exception | empty
	 */
	public String getAvailablePromoProductCodes(UserDataBean dataBean) {
		logger.info(dataBean.getRequestId()
				+ " Inside getAvailablePromoProductCodes() to get the configured promotional packs for msisdn:"
				+ dataBean.getMsisdn());
		Connection con = TSSJavaUtil.instance().getConnPool().getConnection();
		if (con == null) {
			logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00054")
					+ "  >> connection to database is [" + con + "] "
					+ "so not selecting data for getAvailablePromoProductCodes : msisdn [" + dataBean.getMsisdn()
					+ "]");
			return null;
		}

		String promoPacks = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			logger.debug(dataBean.getRequestId() + " getAvailablePromoProductCodes() method for user >> query ["
					+ DataBaseQueries.GET_USER_POROMOTIONAL_PACKS + "] msisdn:" + dataBean.getMsisdn());

			pstmt = con.prepareStatement(DataBaseQueries.GET_USER_POROMOTIONAL_PACKS);
			pstmt.setString(1, dataBean.getMsisdn());
			rs = pstmt.executeQuery();
			if (rs.next()) {
				promoPacks = rs.getString("SCOPE");
			}
		} catch (SQLException sqle) {
			logger.error(
					dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90001")
							+ " >> SQLException occurred while getting entry from database"
							+ " from getAvailablePromoProductCodes() method : msisdn [" + dataBean.getMsisdn() + "]",
					sqle);
			return null;
		} catch (NullPointerException npe) {
			logger.error(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("90003")
					+ "  >> NullPointerException occurred while getting entry from database"
					+ " from getAvailablePromoProductCodes() method : msisdn [" + dataBean.getMsisdn() + "] pstmt:["
					+ pstmt + "]", npe);
			return null;
		} catch (Exception e) {
			logger.error(
					dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00056")
							+ " >> Exception occurred while getting entry from database"
							+ " from getAvailablePromoProductCodes() method : msisdn [" + dataBean.getMsisdn() + "]",
					e);
			return null;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (Exception exp) {
				logger.warn(dataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00057")
						+ " >> Exception While closing resultSet or pstatement or connection  : msisdn ["
						+ dataBean.getMsisdn() + "]");
				promoPacks = null;
			}
		}
		return promoPacks;
	}
	
	
	
	/**
	 * @author Sanchit Atri
	 * This method insert the data in referral_details table for pack refer
	 * 
	 * @param userDataBean
	 * @return
	 */
	
	@SuppressWarnings("resource")
	public CodeStatus manageReferralPacksDetails(UserDataBean userDataBean) {
		logger.info("manageReferralPacksDetails() >> manage Referral packs deatils in db");
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			con = TSSJavaUtil.instance().getConnPool().getConnection();

			if (con == null) {
				logger.error(TSSJavaUtil.getLogInitial("00010") + " >> connection to database is [" + con
						+ "] so not loading tables from database");
				return CodeStatus.CONNECTION_IS_NULL;
			}

			stmt = con.prepareStatement(DataBaseQueries.LOAD_REFERRAL_PACKS_DETAILS);
			logger.debug("manageReferralPacksDetails() >> loading entries with same msisdn,fmsisdn and product code ["
					+ DataBaseQueries.LOAD_REFERRAL_PACKS_DETAILS + "]");
			rs = stmt.executeQuery();
			 if(rs.next()) {
				 logger.info("manageReferralPacksDetails() >> Same pack already refer to same friend  Product code -[" + userDataBean.getProductCode()
					+ "] and Fmsisdn is  [" + userDataBean.getFmsisdn() + "]");
				 return CodeStatus.ALREADY_REFER_SAME_PLAN;
			 }
			 else
			 {
				 logger.info("manageReferralPacksDetails() >> Same pack already refer to same friend  Product code -[" + userDataBean.getProductCode()
					+ "] and Fmsisdn is  [" + userDataBean.getFmsisdn() + "]");
				 
				 
				 stmt = con.prepareStatement(DataBaseQueries.INSERT_REFERRAL_PACKS_DETAILS);
				 
				 logger.debug("manageReferralPacksDetails() >> insert entries of referral details in DB ["
							+ DataBaseQueries.INSERT_REFERRAL_PACKS_DETAILS + "]");
					rs = stmt.executeQuery();
					
					
					stmt.setString(1, userDataBean.getMsisdn());
					stmt.setString(2, userDataBean.getFmsisdn());
					stmt.setInt(3, userDataBean.getPackId());
					stmt.setString(5, userDataBean.getReferCode());
					stmt.setInt(6, userDataBean.getReferValidity());
					
					int result = stmt.executeUpdate();
					logger.info(userDataBean.getRequestId()
							+ " manageReferralPacksDetails() >> entry for charging logs into database " + "query result is ["
							+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
					

					stmt.close();

					if (result > 0) {
						return CodeStatus.SUCCESS;
					} else {
						logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00051")
								+ "  >> Failed to insert entry into referral_details table " + "query result is ["
								+ result + "] : msisdn [" + userDataBean.getMsisdn() + "]");
						return CodeStatus.FAILURE;
					
					}
			 }

			
		} catch (SQLException sqle) {
			logger.error(TSSJavaUtil.getLogInitial("90001")
					+ " >> SQLException occurred while loading all pack types from database", sqle);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (NullPointerException npe) {
			logger.error(TSSJavaUtil.getLogInitial("90003")
					+ " >> NullPointerException occurred while loading data, stmt:[" + stmt + "] or rs:["
					+ rs + "] may be null", npe);
			return CodeStatus.EXCEPTION_OCCURED;
		} catch (Exception e) {
			logger.error(TSSJavaUtil.getLogInitial("00039")
					+ " >> Exception occurred while loading data from database", e);
			return CodeStatus.EXCEPTION_OCCURED;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
			} catch (Exception exp) {
				logger.warn(
						TSSJavaUtil.getLogInitial("00040") + " >> Exception While closing result set or statement");
			}
		}
	}// manageReferralPacksDetails() ends
	

}// DbOperations class ends