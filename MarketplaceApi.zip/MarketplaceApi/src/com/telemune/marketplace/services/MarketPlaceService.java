/**
 * @author MoHit
 * Created on - 14 Feb, 2017
 */
package com.telemune.marketplace.services;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.telemune.marketplace.beans.AccessedPackRecordBean;
import com.telemune.marketplace.beans.UserDataBean;
import com.telemune.marketplace.beans.UserPackPurchaseBean;
import com.telemune.marketplace.beans.UserProfileBean;
import com.telemune.marketplace.beans.UserTransactionBean;
import com.telemune.marketplace.beans.response.Response;
import com.telemune.marketplace.beans.response.VariableAndValue;
import com.telemune.marketplace.db.DBOperations;
import com.telemune.marketplace.manager.ChargingManager;
import com.telemune.marketplace.manager.PackManager;
import com.telemune.marketplace.manager.ParametersValidator;
import com.telemune.marketplace.manager.ServicesManager;
import com.telemune.marketplace.manager.UserManager;
import com.telemune.marketplace.util.CodeStatus;
import com.telemune.marketplace.util.IvrMenu;
import com.telemune.marketplace.util.MPCommonDataTypes;
import com.telemune.marketplace.util.ResponseParameters;
import com.telemune.marketplace.util.ServiceTypes;
import com.telemune.marketplace.util.TSSJavaUtil;
import com.telemune.marketplace.util.UssdMenuNames;

@Path("/MarketplaceServices")
/**
 * This class is used to receive the requests and to provide service for
 * accessing data
 * 
 * @author MoHit
 */
public class MarketPlaceService {

	/**
	 * Used for printing logs in this class
	 */
	private static Logger logger = Logger.getLogger(MarketPlaceService.class);

	@GET
	@Path("/reloadCache")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * Used to reload the cache of MarketplaceApi
	 * 
	 * @return response of this request in variable name and value format
	 */
	public Response handleReloadCache() {
		logger.info("\n\n\n\n\t\t\t >> Goining to reload the cache of MarketplaceApi\n");
		System.out.println("handleReloadCache");
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (TSSJavaUtil.reload() == null) {
			responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
			responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, "UNABLE TO RELAOD CACHE"));
			logger.error("\n\n\t\t " + TSSJavaUtil.getLogInitial("00187") + " >> UNABLE TO RELAOD CACHE\n\n\n");
		} else {
			responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.SUCCESS)));
			responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, "CACHE RELOADED SUCCESSFULLY"));
			logger.info("\n\n\t\t >> CACHE RELOADED SUCCESSFULLY\n\n\n");
		}
		return new Response(responseList);

	}// handleReloadCache() ends

	/**
	 * This method is used to get users active data accounts. It first validates all
	 * the parameters required for this request and then get the user's active data
	 * accounts.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param actionType
	 * @param subType
	 * @param activeAccountIds
	 * @param digits
	 * @author SIDDHARTH
	 * @return Returns the active User's data account details. Response of this
	 *         request in variable name and value format.
	 */
	@GET
	@Path("/getUserActiveServiceDataAccounts")
	@Produces(MediaType.APPLICATION_XML)
	public Response getUserActiceServiceDataAccounts(@QueryParam("msisdn") String msisdn,
			@QueryParam("langId") String langId, @QueryParam("requestId") String requestId,
			@QueryParam("interface") String interfaceUsed, @QueryParam("shortCode") String shortCode,
			@QueryParam("subType") String subType, @QueryParam("activeAccIdList") String activeAccIdList) {
		logger.info("\n\n\n\t\t\t >> Get User's Active Data Accounts procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "] activeAccIdList [" + activeAccIdList + "]"
				+ "\n\n\n");

		CodeStatus status;
		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForGetUserActiveServiceDataAccounts(msisdn, langId,
				requestId, interfaceUsed, shortCode, subType, activeAccIdList, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
			if (userDataBean.getFilePath() == null || userDataBean.getFilePath().isEmpty()) {
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			} else {
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
			}

			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00181")
					+ " >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		status = new ChargingManager().getUserDataAccountDetails(userDataBean);

		// code modification to remove low balance error
		if (status != CodeStatus.SUCCESS && status != CodeStatus.LOW_BALANCE) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00208")
					+ " >> Unable to get active data accounts status [" + status + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(
				new VariableAndValue(ResponseParameters.ACTIVE_ACCOUNT_ID_LIST, userDataBean.getActiveAccIdList()));
		responseList.add(new VariableAndValue(ResponseParameters.IS_MORE_AVAILABLE, userDataBean.getMore()));

		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] getUserActiceServiceDataAccounts final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// getUserActiveServiceDataAccounts ends

	/**
	 * This method is used to get users active data account detail. It first
	 * validates all the parameters required for this request and then get the
	 * requested balance of user
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param activeAccountIds
	 * @param digits
	 * @author SIDDHARTH
	 * @return Returns the User's data account details. Response of this request in
	 *         variable name and value format.
	 */
	@GET
	@Path("/getUserDataAccountDetail")
	@Produces(MediaType.APPLICATION_XML)
	public Response getUserDataBalance(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("activeAccIdList") String activeAccIdList, @QueryParam("digits") String digits) {
		logger.info("\n\n\n\t\t\t >> Get User's Data Account Detail procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "] activeAccIdList [" + activeAccIdList
				+ "] digits [" + digits + "]" + "\n\n\n");

		CodeStatus status;
		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForGetUserDataAccountDetail(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, activeAccIdList, digits, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
			responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00181")
					+ " >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		status = new ServicesManager().getUserDataAccountDetail(userDataBean);

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00208")
					+ " >> Unable to convet data status [" + status + "] " + "so returning error : msisdn ["
					+ userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(
				new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL, userDataBean.getPackPurchaseDetail()));

		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] getUserActiceServiceDataAccounts final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// getUserDataAccountDetail ends

	@GET
	@Path("/getUserActivePlan")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to get the user profile which contains user profile
	 * information It first validates all the parameters required for this request
	 * and then check profile of user
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @return response of this request in variable name and value format. This
	 *         method returns the basic information of user like
	 *         msisdn,user_id,password,name etc.
	 */
	public Response handleGetUserActivePlan(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("prevIndex") String prevIndex,
			@QueryParam("nextIndex") String nextIndex, @QueryParam("index") String index) {
		logger.info("\n\n\n\t\t\t >> GET USER ACTIVE PLAN procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "]  prevIndex [" + prevIndex + "]  nextIndex [" + nextIndex
				+ "] index [" + index + "]." + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForGetActivePlan(msisdn, langId, requestId,
				interfaceUsed, shortCode, prevIndex, nextIndex, index, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {

			if (interfaceUsed.equalsIgnoreCase("I") || interfaceUsed.equalsIgnoreCase("O")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				// added to show balance in float/double or Integer if true then
				// float or double else Integer

				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00181")
					+ " >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		UserPackPurchaseBean packBean = new UserPackPurchaseBean();

		CodeStatus status;
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
			status = new UserManager().getUserActivePlanIvr(userDataBean, packBean);
		} else
			status = new UserManager().getUserActivePlan(userDataBean, packBean);

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00323")
					+ "  >> There is some problem while getting user's active plans >> MSISDN:["
					+ userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(new VariableAndValue(ResponseParameters.PREV_INDEX, userDataBean.getPrevIndex()));
		responseList.add(new VariableAndValue(ResponseParameters.NEXT_INDEX, userDataBean.getNextIndex()));
		responseList.add(new VariableAndValue(ResponseParameters.IS_MORE_AVAILABLE, userDataBean.getMore()));

		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] User's Active Plan final response is " + responseList + "\n\n\n");
		return new Response(responseList);
	}

	@GET
	@Path("/getUserTransaction")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to get the user profile which contains user profile
	 * information It first validates all the parameters required for this request
	 * and then check profile of user
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @return response of this request in variable name and value format. This
	 *         method returns the basic information of user like
	 *         msisdn,user_id,password,name etc.
	 */
	public Response handleGetUserTrasaction(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("prevIndex") String prevIndex,
			@QueryParam("nextIndex") String nextIndex, @QueryParam("index") String index) {
		logger.info("\n\n\n\t\t\t >> GET USER ACTIVE PLAN procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "]" + "PrevIndex [ " + prevIndex + " ]NextIndex [ " + nextIndex
				+ " ]\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForGetUserTransaction(msisdn, langId, requestId,
				interfaceUsed, shortCode, prevIndex, nextIndex, index, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			if (interfaceUsed.equalsIgnoreCase("I") || interfaceUsed.equalsIgnoreCase("O")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				// added to show balance in float/double or Integer if true then
				// float or double else Integer

				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00181")
					+ " >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		// UserProfileBean profileBean = new UserProfileBean();
		UserTransactionBean transactionBean = new UserTransactionBean();
		CodeStatus status;

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O"))
			status = new UserManager().getUserLastTransactionIvr(userDataBean);
		else
			status = new UserManager().getUserLastTransaction(userDataBean, transactionBean);

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00324")
					+ "  >> There is some problem while getting user transaction >> MSISDN:[" + userDataBean.getMsisdn()
					+ "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(new VariableAndValue(ResponseParameters.PREV_INDEX, userDataBean.getPrevIndex()));
		responseList.add(new VariableAndValue(ResponseParameters.NEXT_INDEX, userDataBean.getNextIndex()));
		responseList.add(new VariableAndValue(ResponseParameters.IS_MORE_AVAILABLE, userDataBean.getMore()));
		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] User's Last Transaction final response is " + responseList + "\n\n\n");
		return new Response(responseList);
	}

	@GET
	@Path("/checkProfile")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for check profile of user's MSISDN
	 * It first validates all the parameters required for this request and then
	 * check profile of user
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @return response of this request in variable name and value format. This
	 *         method returns result, subscriber type of user (pre-paid or
	 *         post-paid), balance of user, user can continue to user this API or
	 *         not and user is pre-paid or not
	 */
	public Response handleCheckProfile(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode) {
		logger.info("\n\n\n\t\t\t >> CHECK PROFILE procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();
		Date sysDate = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat(MPCommonDataTypes.DATE_FORMAT);
		String sysDateStr = formatter.format(sysDate);
		long handleCheckProfileTime = System.currentTimeMillis();

		boolean validParams = new ParametersValidator().validateForCheckProfile(msisdn, langId, requestId,
				interfaceUsed, shortCode, userDataBean);

		// Method to maintain call log
		userDataBean.setCallStartTime(sysDateStr);
		userDataBean.setCallDuration(-1);
		userDataBean.setLastPackAccessedTime(sysDateStr);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
			// added to show balance in float/double or Integer if true then
			// float or double else Integer
			if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
				responseList.add(
						new VariableAndValue(ResponseParameters.BALANCE, String.valueOf(userDataBean.getBalance())));
			} else {
				responseList.add(new VariableAndValue(ResponseParameters.BALANCE,
						String.valueOf((int) userDataBean.getBalance())));
			}
			responseList.add(new VariableAndValue(ResponseParameters.SUB_TYPE, userDataBean.getSubType()));
			responseList.add(new VariableAndValue(ResponseParameters.IS_CONTINUE, "0"));
			responseList.add(new VariableAndValue(ResponseParameters.IS_PREPAID, "-1"));

			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00181")
					+ " >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		// checking subtype of user
		ChargingManager chargingManager = new ChargingManager();
		CodeStatus status = chargingManager.new HLRHandler().checkSubscriberType(userDataBean);

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00182")
					+ " >> There is some error while checking user subType " + "status [" + status
					+ "] so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
			responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
			// added to show balance in float/double or Integer if true then
			// float or double else Integer
			if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
				responseList.add(
						new VariableAndValue(ResponseParameters.BALANCE, String.valueOf(userDataBean.getBalance())));
			} else {
				responseList.add(new VariableAndValue(ResponseParameters.BALANCE,
						String.valueOf((int) userDataBean.getBalance())));
			}
			responseList.add(new VariableAndValue(ResponseParameters.SUB_TYPE, userDataBean.getSubType()));
			responseList.add(new VariableAndValue(ResponseParameters.IS_CONTINUE, "0"));
			responseList.add(new VariableAndValue(ResponseParameters.IS_PREPAID, "-1"));
			responseList.add(new VariableAndValue(ResponseParameters.USER_POINTS,userDataBean.getUserPoints()+""));
			responseList.add(new VariableAndValue(ResponseParameters.USER_POINTS_INFO,userDataBean.getUserPointsInfo()+""));
		} else if ("O".equalsIgnoreCase(userDataBean.getSubType())) {
			logger.info(userDataBean.getRequestId() + "  >> User subType is checked successfully ["
					+ userDataBean.getSubType() + "] " + " : msisdn [" + userDataBean.getMsisdn() + "]");
			responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
			// added to show balance in float/double or Integer if true then
			// float or double else Integer
			if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
				responseList.add(
						new VariableAndValue(ResponseParameters.BALANCE, String.valueOf(userDataBean.getBalance())));
			} else {
				responseList.add(new VariableAndValue(ResponseParameters.BALANCE,
						String.valueOf((int) userDataBean.getBalance())));
			}
			responseList.add(new VariableAndValue(ResponseParameters.SUB_TYPE, userDataBean.getSubType()));
			responseList.add(new VariableAndValue(ResponseParameters.IS_CONTINUE, "1"));
			responseList.add(new VariableAndValue(ResponseParameters.IS_PREPAID, "0"));
			responseList.add(new VariableAndValue(ResponseParameters.USER_POINTS,userDataBean.getUserPoints()+""));
			responseList.add(new VariableAndValue(ResponseParameters.USER_POINTS_INFO,userDataBean.getUserPointsInfo()+""));
		} else if ("P".equalsIgnoreCase(userDataBean.getSubType())) {
			// MSISDN is prepaid so checking user balance
			status = chargingManager.checkUserBalance(userDataBean);
			if (CodeStatus.SUCCESS != status) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00183")
						+ " >> User subType is [" + userDataBean.getSubType() + "] but "
						+ "there is some error while checking user balance status [" + status
						+ "] so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
				responseList
						.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
				// added to show balance in float/double or Integer if true then
				// float or double else Integer
				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					responseList.add(new VariableAndValue(ResponseParameters.BALANCE,
							String.valueOf(userDataBean.getBalance())));
				} else {
					responseList.add(new VariableAndValue(ResponseParameters.BALANCE,
							String.valueOf((int) userDataBean.getBalance())));
				}
				responseList.add(new VariableAndValue(ResponseParameters.SUB_TYPE, userDataBean.getSubType()));
				responseList.add(new VariableAndValue(ResponseParameters.IS_CONTINUE, "1"));
				responseList.add(new VariableAndValue(ResponseParameters.IS_PREPAID, "1"));
				responseList.add(new VariableAndValue(ResponseParameters.USER_POINTS,userDataBean.getUserPoints()+""));
				responseList.add(new VariableAndValue(ResponseParameters.USER_POINTS_INFO,userDataBean.getUserPointsInfo()+""));
			} else {
				logger.info(userDataBean.getRequestId() + "  >> User subType is [" + userDataBean.getSubType()
						+ "] and " + "balance is [" + userDataBean.getBalance() + "] : msisdn ["
						+ userDataBean.getMsisdn() + "]");
				responseList
						.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
				// added to show balance in float/double or Integer if true then
				// float or double else Integer
				if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
					responseList.add(new VariableAndValue(ResponseParameters.BALANCE,
							String.valueOf(userDataBean.getBalance())));
				} else {
					responseList.add(new VariableAndValue(ResponseParameters.BALANCE,
							String.valueOf((int) userDataBean.getBalance())));
				}
				responseList.add(new VariableAndValue(ResponseParameters.SUB_TYPE, userDataBean.getSubType()));
				responseList.add(new VariableAndValue(ResponseParameters.IS_CONTINUE, "1"));
				responseList.add(new VariableAndValue(ResponseParameters.IS_PREPAID, "1"));
				/**
				 * adding points in response
				 */
				responseList.add(new VariableAndValue(ResponseParameters.USER_POINTS,userDataBean.getUserPoints()+""));
				responseList.add(new VariableAndValue(ResponseParameters.USER_POINTS_INFO,userDataBean.getUserPointsInfo()+""));
			}
		}

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I") || userDataBean.getInterfaceUsed().equalsIgnoreCase("C")) {
			if (!userDataBean.getMsisdn().isEmpty() && !userDataBean.getMsisdn().equalsIgnoreCase("NA")
					&& userDataBean.getMsisdn() != null) {

				if (!TSSJavaUtil.instance().getCallManagerMap().containsKey(userDataBean.getMsisdn())) {
					logger.info("New Entry found. Going to maintain call manager details.");
					TSSJavaUtil.instance().getCallManagerMap().put(userDataBean.getMsisdn(), userDataBean);
				} else {
					logger.info("RequestId[" + userDataBean.getRequestId() + "] MSISDN[" + userDataBean.getMsisdn()
							+ "] Entry already present. Going to maintain call manager details.");
					UserDataBean oldUserData = TSSJavaUtil.instance().getCallManagerMap().get(userDataBean.getMsisdn());
					oldUserData.setCallDuration(ResponseParameters.IMPROPER_HANGUP_CALL_DURATION_RESPONSE_IVR);
					new DBOperations().new LogsManager().maintainCallLogs(oldUserData);
					TSSJavaUtil.instance().getCallManagerMap().put(userDataBean.getMsisdn(), userDataBean);

				}
			} else {
				logger.error("RequestId[" + userDataBean.getRequestId() + "] " + TSSJavaUtil.getLogInitial("00333")
						+ " >> MSISDN:[" + userDataBean.getMsisdn() + "] not found.");
			}
		}

		long currentTime = System.currentTimeMillis();
		// new Date().getTime();
		// maintaining logs
		if (TSSJavaUtil.instance().getCacheParameters().isDbLogOnCheckProfileEnable())
			new DBOperations().new LogsManager().maintainCallLogs(userDataBean);

		logger.info("[" + userDataBean.getRequestId() + "] Time to execute maintainCallLogs method ["
				+ (System.currentTimeMillis() - currentTime) + "]");

		// Maintain User Profile
		currentTime = System.currentTimeMillis();
		new DBOperations().new LogsManager().maintainUserProfile(userDataBean);
		logger.info("[" + userDataBean.getRequestId() + "] Time to execute maintainUserProfile method ["
				+ (System.currentTimeMillis() - currentTime) + "]");
		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] User's check profile final response is " + responseList + "\n\n\n");

		logger.info("CallManagerMap SIZE:[" + TSSJavaUtil.instance().getCallManagerMap().size() + "]");

		logger.info("[" + userDataBean.getRequestId() + "] Time to execute handleCheckProfile method ["
				+ (System.currentTimeMillis() - handleCheckProfileTime) + "]");

		return new Response(responseList);

	}// handleCheckProfile() ends

	@GET
	@Path("/getBalance")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for get balance of user's MSISDN
	 * It first validates all the parameters required for this request and then
	 * checks user main account balance
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @return response of this request in variable name and value format. This
	 *         method returns result, message to be shown and balance of user
	 */
	public Response handleGetBalance(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType) {
		logger.info("\n\n\n\t\t\t >> GET BALANCE procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] " + "requestId [" + requestId + "] interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForGetBalance(msisdn, langId, requestId, interfaceUsed,
				shortCode, subType, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			if (interfaceUsed.equalsIgnoreCase("I") || interfaceUsed.equalsIgnoreCase("O")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}

			// added to show balance in float/double or Integer if true then
			// float or double else Integer
			if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
				responseList.add(
						new VariableAndValue(ResponseParameters.BALANCE, String.valueOf(userDataBean.getBalance())));
			} else {
				responseList.add(new VariableAndValue(ResponseParameters.BALANCE,
						String.valueOf((int) userDataBean.getBalance())));
			}

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00184")
					+ "  >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + "  >> Going to check balance of user : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		// now checking balance from charging server
		CodeStatus status;
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O"))
			status = new ChargingManager().checkUserBalanceIvr(userDataBean);
		else
			status = new ChargingManager().checkUserBalance(userDataBean);

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00185")
					+ "  >> User subType is [" + userDataBean.getSubType() + "] and "
					+ "there is some error while checking user balance status [" + status
					+ "] so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		} else {
			logger.info(userDataBean.getRequestId() + "  >> User subType is [" + userDataBean.getSubType() + "] and "
					+ "balance is [" + userDataBean.getBalance() + "] : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		// added to show balance in float/double or Integer if true then float
		// or double else Integer
		if (TSSJavaUtil.instance().getCacheParameters().isFloatValueEnable()) {
			responseList
					.add(new VariableAndValue(ResponseParameters.BALANCE, String.valueOf(userDataBean.getBalance())));
		} else {
			responseList.add(
					new VariableAndValue(ResponseParameters.BALANCE, String.valueOf((int) userDataBean.getBalance())));
		}
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));

		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] User's check balance final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleGetBalance() ends

	@GET
	@Path("/getPacks")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for getting available packs / Pack
	 * Type for user It first validates all the parameters required for this request
	 * and then get dynamic Pack/Pack Type to show to user
	 * 
	 * @param msisdn
	 * @param langId
	 * @param packTypeId
	 * @param packBrowseList
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param index
	 * @param balance
	 * @param packList
	 * @param isPackType
	 * @param digits
	 * @return response of this request in variable name and value format. This
	 *         method returns result, packs to be shown in message, list of pack IDs
	 *         that user has browsed, and the list of IDs that are shown to user in
	 *         current request
	 */
	public Response handleGetPacks(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("packTypeId") String packTypeId, @QueryParam("packBrowseList") String packBrowseList,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("index") String index, @QueryParam("balance") String balance,
			@QueryParam("packList") String packList, @QueryParam("isPackType") String isPackType,
			@QueryParam("digits") String digits) {
		logger.info("\n\n\n\t\t\t >> GET PACKS procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] packTypeId [" + packTypeId + "] packBrowseList [" + packBrowseList
				+ "] " + "requestId [" + requestId + "] interface [" + interfaceUsed + "] shortCode [" + shortCode
				+ "] subType [" + subType + "] index [" + index + "] " + "balance [" + balance + "] packList ["
				+ packList + "]  isPackType[" + isPackType + "] digits[" + digits + "] \n\n\n");

		UserDataBean userDataBean = new UserDataBean();
		CodeStatus codeStatus = null;
		PackManager packManager = new PackManager();
		Date sysDate = new Date();
		long getPacksTime = System.currentTimeMillis();

		boolean validParams = new ParametersValidator().validateForGetPacks(msisdn, langId, packTypeId, packBrowseList,
				requestId, interfaceUsed, shortCode, subType, index, balance, packList, userDataBean, isPackType,
				digits);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}
			responseList
					.add(new VariableAndValue(ResponseParameters.PACK_BROWSE_LIST, userDataBean.getPackBrowseList()));
			responseList.add(new VariableAndValue(ResponseParameters.PACK_LIST, userDataBean.getPackList()));

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00186")
					+ "  >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + "  >> Going to fetch all available packs of user : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		// now getting all available packs for user

		// For USSD
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
			codeStatus = packManager.fetchAvailablePacks(userDataBean);
		}

		// For IVR
		else if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
			codeStatus = packManager.fetchAvailablePacksForIVR(userDataBean);
		}

		// Maintaining call details
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")) {
			if (TSSJavaUtil.instance().getCallManagerMap().containsKey(userDataBean.getMsisdn())) {
				logger.info("Going to update AccessedPacksRecords");
				UserDataBean callManagerDataBean = TSSJavaUtil.instance().getCallManagerMap()
						.get(userDataBean.getMsisdn());
				SimpleDateFormat formatter = new SimpleDateFormat(MPCommonDataTypes.DATE_FORMAT);
				String sysDateStr = formatter.format(sysDate);

				callManagerDataBean.addAccessedPacksRecords(new AccessedPackRecordBean(userDataBean.getPackTypeId(),
						sysDateStr, callManagerDataBean.getLastPackAccessedTime()));

				callManagerDataBean.setLastPackAccessedTime(sysDateStr);
				TSSJavaUtil.instance().getCallManagerMap().put(userDataBean.getMsisdn(), callManagerDataBean);
				logger.debug("callManagerDataBean:  " + callManagerDataBean.toString());
			} else {
				logger.info(userDataBean.getRequestId() + " >> MISIDN[" + userDataBean.getMsisdn()
						+ "] not found in the map");
			}
		}

		if (CodeStatus.SUCCESS != codeStatus) {
			logger.info(userDataBean.getRequestId() + " >> Unable to fetch packs for user status [" + codeStatus + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_BROWSE_LIST, userDataBean.getPackBrowseList()));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_LIST, userDataBean.getPackList()));
		responseList.add(
				new VariableAndValue(ResponseParameters.CURRENT_PACK, String.valueOf(userDataBean.getPackTypeId())));
		responseList.add(new VariableAndValue(ResponseParameters.IS_PACK_TYPE, userDataBean.getIsPackType()));
		responseList.add(new VariableAndValue(ResponseParameters.BASE_PACK_TYPE, userDataBean.getBasePackType()));

		logger.info(userDataBean.getRequestId() + " Time to execute getPacks method ["
				+ (System.currentTimeMillis() - getPacksTime) + "]");
		logger.info(userDataBean.getRequestId() + " >> msisdn [" + userDataBean.getMsisdn()
				+ "] Fetch all available packs final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleGetPacks() ends

	@GET
	@Path("/getLowBalancePacks")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for get available packs for user
	 * It first validates all the parameters required for this request and then get
	 * packs to show to user
	 * 
	 * @param msisdn
	 * @param langId
	 * @param packTypeId
	 * @param packBrowseList
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param index
	 * @param balance
	 * @param packList
	 * @param isPackType
	 * @param digits
	 * @return response of this request in variable name and value format. This
	 *         method returns result, packs to be shown in message, list of pack IDs
	 *         that user has browsed, and the list of IDs that are shown to user in
	 *         current request
	 */
	public Response handleGetLowBalancePacks(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("packTypeId") String packTypeId, @QueryParam("packBrowseList") String packBrowseList,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("index") String index, @QueryParam("balance") String balance,
			@QueryParam("packList") String packList, @QueryParam("isPackType") String isPackType,
			@QueryParam("digits") String digits) {
		logger.info("\n\n\n\t\t\t >> GET LOW BALANCE PACKS procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] packTypeId [" + packTypeId + "] packBrowseList [" + packBrowseList
				+ "] " + "requestId [" + requestId + "] interface [" + interfaceUsed + "] shortCode [" + shortCode
				+ "] subType [" + subType + "] index [" + index + "] " + "balance [" + balance + "] packList ["
				+ packList + "]  isPackType[" + isPackType + "]  digits[" + digits + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();
		isPackType = "N";
		boolean validParams = new ParametersValidator().validateForGetPacks(msisdn, langId, packTypeId, packBrowseList,
				requestId, interfaceUsed, shortCode, subType, index, balance, packList, userDataBean, isPackType,
				digits);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}
			responseList
					.add(new VariableAndValue(ResponseParameters.PACK_BROWSE_LIST, userDataBean.getPackBrowseList()));
			responseList.add(new VariableAndValue(ResponseParameters.PACK_LIST, userDataBean.getPackList()));

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00186")
					+ "  >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		logger.debug(
				userDataBean.getRequestId() + "  >> Going to fetch all available low balance packs of user : msisdn ["
						+ userDataBean.getMsisdn() + "]");

		// now getting all available low balance packs for user
		CodeStatus status;

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O"))
			status = new PackManager().fetchAvailableIvrLowBalancePacks(userDataBean);
		else
			status = new PackManager().fetchAvailableLowBalancePacks(userDataBean);

		if (CodeStatus.SUCCESS != status) {
			logger.info(userDataBean.getRequestId() + " >> Unable to fetch low balance packs for user status [" + status
					+ "] " + "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_BROWSE_LIST, userDataBean.getPackBrowseList()));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_LIST, userDataBean.getPackList()));
		responseList.add(
				new VariableAndValue(ResponseParameters.CURRENT_PACK_TYPE_LIST, userDataBean.getCurrentPackTypeList()));

		logger.info(userDataBean.getRequestId() + " >> msisdn [" + userDataBean.getMsisdn()
				+ "] Fetch all available low balance packs final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleGetPacks() ends

	@GET
	@Path("/getPackDescription")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for get pack description for user
	 * It first validates all the parameters required for this request and then
	 * fetches the the description of the selected pack
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packList
	 * @param digits
	 * @param packTypeId
	 * @param isLowBalancePack
	 * @param currentPackTypeList
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and description of the pack that is to be
	 *         shown to user and the pack ID selected by user to purchase.
	 */
	public Response handleGetPackDescription(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("packList") String packList, @QueryParam("digits") String digits,
			@QueryParam("packTypeId") String packTypeId, @QueryParam("balance") String balance,
			@QueryParam("isLowBalancePack") String isLowBalancePack,
			@QueryParam("currentPackTypeList") String currentPackTypeList) {
		logger.info("\n\n\n\t\t\t >> GET PACK DESCRIPTION procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "] packList [" + packList + "] " + "digits ["
				+ digits + "] packTypeId [" + packTypeId + "] balance [" + balance + "] isLowBalancePack ["
				+ isLowBalancePack + "] currentPackTypeList [" + currentPackTypeList + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForGetPackDescription(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, packList, digits, packTypeId, balance, userDataBean,
				isLowBalancePack, currentPackTypeList);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O") || userDataBean.getInterfaceUsed().equalsIgnoreCase("C")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}
			responseList
					.add(new VariableAndValue(ResponseParameters.PACK_ID, String.valueOf(userDataBean.getPackId())));

			logger.error(userDataBean.getRequestId()
					+ " handleGetPackDescription() >> One or more parameters are not valid : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + " >> Going to fetch pack description : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		CodeStatus status = null;
		// now fetching pack description

		// Fetching Pack Description for USSD
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
			status = new PackManager().fetchPackDescription(userDataBean);
		}

		// Fetching Pack Description for IVR
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O") || userDataBean.getInterfaceUsed().equalsIgnoreCase("C")) {
			status = new PackManager().fetchPackDescriptionIVR(userDataBean);
		}

		// Modify to remove error due to low balance
		if (CodeStatus.SUCCESS != status && userDataBean.getResult() != ResponseParameters.LOW_BALANCE) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00189")
					+ " >> Unable to fetch pack description status [" + status + "] " + "so returning error : msisdn ["
					+ userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_ID, String.valueOf(userDataBean.getPackId())));
		responseList.add(
				new VariableAndValue(ResponseParameters.CURRENT_PACK, String.valueOf(userDataBean.getPackTypeId())));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_ACTION_TYPE,
				String.valueOf(userDataBean.getPackActionType())));

		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] Fetch pack description final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleGetPackDescription() ends

	@GET
	@Path("/getPackDescriptionById")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for get pack description for user
	 * It first validates all the parameters required for this request and then
	 * fetches description of the selected pack
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packId
	 * @param packTypeId
	 * @param isLowBalancePack
	 * @param currentPackTypeList
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and description of the pack that is to be
	 *         shown to user.
	 */
	public Response handleGetPackDescriptionById(@QueryParam("msisdn") String msisdn,
			@QueryParam("langId") String langId, @QueryParam("requestId") String requestId,
			@QueryParam("interface") String interfaceUsed, @QueryParam("shortCode") String shortCode,
			@QueryParam("subType") String subType, @QueryParam("packId") String packId,
			@QueryParam("packTypeId") String packTypeId, @QueryParam("balance") String balance,
			@QueryParam("isLowBalancePack") String isLowBalancePack,
			@QueryParam("currentPackTypeList") String currentPackTypeList) {
		logger.info("\n\n\n\t\t\t >> GET PACK DESCRIPTION BY ID procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "] packId [" + packId + "] " + "packTypeId ["
				+ packTypeId + "] Balance [" + balance + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForGetPackDescriptionById(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, packId, packTypeId, balance, userDataBean, isLowBalancePack,
				currentPackTypeList);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00190")
					+ "  >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + "  >> Going to fetch pack description : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		CodeStatus status = null;
		// now fetching pack description

		// Fetching Pack Description for USSD
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
			status = new PackManager().fetchPackDescriptionById(userDataBean);
		}

		// Fetching Pack Description for IVR and OBD
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
			status = new PackManager().fetchPackDescriptionByIdIVR(userDataBean);
		}

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00191")
					+ "  >> Unable to fetch pack description status [" + status + "] " + "so returning error : msisdn ["
					+ userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));

		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] Fetch pack description by if id " + "final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleGetPackDescriptionById() ends

	/**
	 * This method is used to receive the request for purchase a pack for user It
	 * first validates all the parameters required for this request and then goes to
	 * purchase the selected pack for user
	 * 
	 * @param msisdn
	 * @param langId
	 * @param packBrowseList
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packId
	 * @param packTypeId
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and the message to be shown for this pack
	 *         purchase request success, fail etc and the pack purchase detail means
	 *         a string containing pack ID purchased by user and result of this pack
	 *         purchase request in this format PACKID;RESULT example 1002;1
	 */
	@GET
	@Path("/purchasePack")
	@Produces(MediaType.APPLICATION_XML)
	public Response handlePurchasePack(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("packBrowseList") String packBrowseList, @QueryParam("requestId") String requestId,
			@QueryParam("interface") String interfaceUsed, @QueryParam("shortCode") String shortCode,
			@QueryParam("subType") String subType, @QueryParam("packId") String packId,
			@QueryParam("packTypeId") String packTypeId) {
		logger.info("\n\n\n\t\t\t >> PURCHASE PACK procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] packBrowseList [" + packBrowseList + "] requestId [" + requestId
				+ "] " + "interface [" + interfaceUsed + "] shortCode [" + shortCode + "] subType [" + subType
				+ "] packId [" + packId + "] packTypeId [" + packTypeId + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();
		long purchasePackTime = System.currentTimeMillis();

		boolean validParams = new ParametersValidator().validateForPurchasePack(msisdn, langId, packBrowseList,
				requestId, interfaceUsed, shortCode, subType, packId, packTypeId, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O") || userDataBean.getInterfaceUsed().equalsIgnoreCase("C")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
				responseList.add(new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL,
						userDataBean.getPackPurchaseDetail()));
			}

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00192")
					+ " >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + "  >> Going to purchase pack for user : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		// now purchasing pack
		CodeStatus status = null;

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
			status = new ChargingManager().purchasePack(userDataBean);
		}

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("C")) {
			status = new ChargingManager().purchasePackIVR(userDataBean);
		}

		if (CodeStatus.LOW_BALANCE == status) {
			logger.info(userDataBean.getRequestId() + " >>> Unable to purchase pack for user, status [" + status + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		} else if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00193")
					+ " Unable to purchase pack for user, status [" + status + "] " + "so returning error : msisdn ["
					+ userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(
				new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL, userDataBean.getPackPurchaseDetail()));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_ACTION_TYPE,
				String.valueOf(userDataBean.getPackActionType())));

		logger.info(userDataBean.getRequestId() + " >> Time to execute PurchasePack ["
				+ (System.currentTimeMillis() - purchasePackTime) + "]");
		logger.info(userDataBean.getRequestId() + " >> msisdn [" + userDataBean.getMsisdn()
				+ "] User's pack purchase final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handlePurchasePack() ends

	@GET
	@Path("/validateFmsisdn")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for validate the friend mobile
	 * number It first validates all the parameters required for this request and
	 * then validates the friend MSISDN entered by user
	 * 
	 * @param msisdn
	 * @param requestId
	 * @param fmsisdn
	 * @param langId
	 * @param interface
	 * @return response of this request in variable name and value format. This
	 *         method returns the result. message to be shown to user if the
	 *         friend's mobile number is not valid and the friend's mobile number
	 *         after converting into international form if it is valid.
	 */
	public Response handleValidateFmsisdn(@QueryParam("msisdn") String msisdn,
			@QueryParam("requestId") String requestId, @QueryParam("fmsisdn") String fmsisdn,
			@QueryParam("langId") String langId, @QueryParam("serviceType") String serviceType,
			@QueryParam("interface") String interfaceUsed) {
		logger.info("\n\n\n\t\t\t >> VALIDATE FMSISDN procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] requestId [" + requestId + "] fmsisdn [" + fmsisdn + "] " + "langId [" + langId
				+ "] serviceType [" + serviceType + "]  interfaceUsed:[" + interfaceUsed + "]  \n\n\n");

		UserDataBean userDataBean = new UserDataBean();
		String filePath = "";
		String ivr_base_file_path = "";

		boolean validParams = new ParametersValidator().validateFMSISDN(msisdn, requestId, fmsisdn, langId, serviceType,
				userDataBean, interfaceUsed);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				if (userDataBean.getResult() == -1) {
					responseList.add(new VariableAndValue(ResponseParameters.RESULT,
							String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
				} else {
					responseList.add(
							new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
					if (userDataBean.getFilePath() == null || userDataBean.getFilePath().equals("")) {
						responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
								TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
										+ File.separator + IvrMenu.UNKNOWN_ERROR_WAV_IVR));
					} else {
						responseList
								.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
					}

				}

			} else {
				responseList
						.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));

				if (userDataBean.getFilePath() == null) {
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
							TSSJavaUtil.instance().getCacheParameters()
									.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
				} else {
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
				}

			}

			responseList.add(new VariableAndValue(ResponseParameters.FMSISDN, fmsisdn));
			logger.info(userDataBean.getRequestId() + " >> One or more parameters are not valid : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		ivr_base_file_path = TSSJavaUtil.instance().getCacheParameters().getIvrBasePath();
		if (ivr_base_file_path.equalsIgnoreCase("NA") || ivr_base_file_path.equalsIgnoreCase("")
				|| ivr_base_file_path == null) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00320")
					+ " >> (IVR)  Base file path is not found for MSISDN[" + userDataBean.getMsisdn() + "].");
			responseList.add(new VariableAndValue(ResponseParameters.RESULT,
					String.valueOf(ResponseParameters.UNKNOWN_ERROR_IVR)));
			responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			responseList.add(new VariableAndValue(ResponseParameters.FMSISDN, fmsisdn));

			return new Response(responseList);

		}

		ChargingManager chargingManager = new ChargingManager();

		msisdn = userDataBean.getMsisdn();
		userDataBean.setMsisdn(userDataBean.getFmsisdn());

		CodeStatus status = chargingManager.new HLRHandler().checkSubscriberType(userDataBean);

		userDataBean.setMsisdn(msisdn);
		// userDataBean.setSubType(subType);

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00194")
					+ " >> There is some error while checking fmsisdn subType " + "status [" + status
					+ "] so returning error : msisdn [" + userDataBean.getMsisdn() + "]");

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.UNKNOWN_ERROR_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				filePath = TSSJavaUtil.instance().getCacheParameters()
						.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId());
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, filePath));
			}

			responseList.add(new VariableAndValue(ResponseParameters.FMSISDN, userDataBean.getFmsisdn()));

		} else if ("O".equalsIgnoreCase(userDataBean.getSubType())) {
			logger.info(userDataBean.getRequestId() + " >> User subType is checked successfully ["
					+ userDataBean.getSubType() + "] " + " : msisdn [" + userDataBean.getMsisdn() + "]");

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.FMSISDN_IS_NOT_PREPAID_IVR)));
			}

			else {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.FMSISDN_IS_NOT_PREPAID)));
			}

			if (ServiceTypes.TALK_TIME_TRANSFER.equals(userDataBean.getServiceType())) {
				if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
						|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
					filePath = TSSJavaUtil.instance().getNumberPrompt(userDataBean.getFmsisdn(),
							userDataBean.getLangId(), ivr_base_file_path) + TSSJavaUtil.FileSeparator
							+ ivr_base_file_path + userDataBean.getLangId() + File.separator
							+ IvrMenu.FMSISDN_IS_NOT_PREPAID_TTT_WAV_IVR;

				} else {
					filePath = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.FMSISDN_IS_NOT_PREPAID_TTT + "_" + userDataBean.getLangId());
				}

			} else if (ServiceTypes.BONUS_TRANSFER.equals(userDataBean.getServiceType())) {
				if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
						|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
					filePath = ivr_base_file_path + userDataBean.getLangId() + File.separator
							+ IvrMenu.FMSISDN_IS_NOT_PREPAID_BT_WAV_IVR;

				} else {

					filePath = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.FMSISDN_IS_NOT_PREPAID_BT + "_" + userDataBean.getLangId());
				}
			} else if (ServiceTypes.DATA_TRANSFER.equals(userDataBean.getServiceType())) {
				if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
						|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
					filePath = ivr_base_file_path + userDataBean.getLangId() + File.separator
							+ IvrMenu.FMSISDN_IS_NOT_PREPAID_DT_WAV_IVR;

				} else {
					filePath = TSSJavaUtil.instance().getCacheParameters().getUssdMenuString(
							UssdMenuNames.FMSISDN_IS_NOT_PREPAID_DT + "_" + userDataBean.getLangId());
				}
			} else {
				if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
						|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
					filePath = TSSJavaUtil.instance().getNumberPrompt(userDataBean.getFmsisdn(),
							userDataBean.getLangId(), ivr_base_file_path) + TSSJavaUtil.FileSeparator
							+ ivr_base_file_path + userDataBean.getLangId() + File.separator
							+ IvrMenu.FMSISDN_IS_NOT_PREPAID_WAV_IVR;

				} else {
					filePath = TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.FMSISDN_IS_NOT_PREPAID + "_" + userDataBean.getLangId());
				}
			}

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
				filePath = filePath.replace("$(fmsisdn)", userDataBean.getFmsisdn());
			}

			responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, filePath));
			responseList.add(new VariableAndValue(ResponseParameters.FMSISDN, userDataBean.getFmsisdn()));

		} else if ("P".equalsIgnoreCase(userDataBean.getSubType())) {
			logger.info(userDataBean.getRequestId() + "  >> User subType is [" + userDataBean.getSubType() + "] "
					+ ": msisdn [" + userDataBean.getMsisdn() + "]");
			responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.SUCCESS)));
			responseList.add(new VariableAndValue(ResponseParameters.FMSISDN, userDataBean.getFmsisdn()));
		}

		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] validate FMSISDN final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleValidateFmsisdn() ends

	@GET
	@Path("/getTTTDescription")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for get talk time transfer
	 * description It first validates all the parameters required for this request
	 * and then generates the confirmation message for talk-time transfer
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param netType
	 * @param volume
	 * @param fmsisdn
	 * @return response of this request in variable name and value format. This
	 *         method returns result and the confirmation message that is to be
	 *         shown to user when user wants to transfer talk-time
	 */
	public Response handleGetTTTDescription(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("netType") String netType, @QueryParam("volume") String volume,
			@QueryParam("fmsisdn") String fmsisdn) {
		logger.info("\n\n\n\t\t\t >> GET TTT DESCRIPTION procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "] netType [" + netType + "] " + "volume ["
				+ volume + "] fmsisdn [" + fmsisdn + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForTTTDescription(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, netType, volume, fmsisdn, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				if (userDataBean.getResult() == -1) {
					responseList.add(new VariableAndValue(ResponseParameters.RESULT,
							String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
				} else {
					responseList.add(
							new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
					if (userDataBean.getFilePath() == null || userDataBean.getFilePath().equals("")) {
						responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
								TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
										+ File.separator + IvrMenu.UNKNOWN_ERROR_WAV_IVR));
					} else {
						responseList
								.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
					}

				}

			} else {

				responseList
						.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));

				if (userDataBean.getFilePath() == null) {
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
							TSSJavaUtil.instance().getCacheParameters()
									.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
				} else {
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
				}

			}
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00195")
					+ "  >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + "  >> Going to fetch talk time transfer description : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		// now fetching talk time transfer description
		CodeStatus status;

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
			status = new PackManager().generateTTTDescriptionIVR(userDataBean);
		} else
			status = new PackManager().generateTTTDescription(userDataBean);

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00196")
					+ " >> Unable to fetch talk time description status [" + status + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));

		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] Fetch talk time description final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleGetTTTDescription() ends

	@GET
	@Path("/talkTimeTransfer")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for get talk time transfer
	 * description It first validates all the parameters required for this request
	 * and then goes to transfer the talk-time entered by user to the friend's
	 * MSISDN
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param netType
	 * @param volume
	 * @param fmsisdn
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and the message to be shown for this
	 *         talk-time transfer request success, fail etc and the pack purchase
	 *         detail means a string containing pack type ID of talk-time transfer
	 *         and result of this request in this format TYPEID;RESULT example 6;1
	 */
	public Response handleTalkTimeTransfer(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("netType") String netType, @QueryParam("volume") String volume,
			@QueryParam("fmsisdn") String fmsisdn) {
		logger.info("\n\n\n\t\t\t >> TALK TIME TRANSFER procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "] netType [" + netType + "] " + "volume ["
				+ volume + "] fmsisdn [" + fmsisdn + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForTTT(msisdn, langId, requestId, interfaceUsed,
				shortCode, subType, netType, volume, fmsisdn, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				if (userDataBean.getResult() == -1) {
					responseList.add(new VariableAndValue(ResponseParameters.RESULT,
							String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
				} else {
					responseList.add(
							new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
					if (userDataBean.getFilePath() == null || userDataBean.getFilePath().equals("")) {
						responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
								TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
										+ File.separator + IvrMenu.UNKNOWN_ERROR_WAV_IVR));
					} else {
						responseList
								.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
					}

				}

			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));

				if (userDataBean.getFilePath() == null) {
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
							TSSJavaUtil.instance().getCacheParameters()
									.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
				} else {
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
				}
			}
			responseList.add(new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL,
					userDataBean.getPackPurchaseDetail()));

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00197")
					+ "  >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + " >> Going to transfer the talk time : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		// now going to transfer talk time
		CodeStatus status;
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O"))
			status = new ChargingManager().talkTimeTransferIVR(userDataBean);

		else
			status = new ChargingManager().talkTimeTransfer(userDataBean);

		if (CodeStatus.LOW_BALANCE == status || CodeStatus.LOW_TTT_BALANCE == status) {
			logger.info(userDataBean.getRequestId() + "  >> Unable to transfer talk time status [" + status + "] "
					+ "so returning failure : msisdn [" + userDataBean.getMsisdn() + "]");
		} else if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00198")
					+ " >> Unable to transfer talk time status [" + status + "] " + "so returning error : msisdn ["
					+ userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(
				new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL, userDataBean.getPackPurchaseDetail()));

		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] transfer talk time final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleTalkTimeTransfer() ends

	@GET
	@Path("/getBonusDescription")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for get bonus transfer description
	 * It first validates all the parameters required for this request and then goes
	 * to generate the bonus transfer (gift) description
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packList
	 * @param digits
	 * @param packTypeId
	 * @param fmsisdn
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and description of the pack that is to be
	 *         shown to user and the pack ID selected by user to purchase.
	 */
	public Response handleGetBonusDescription(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("packList") String packList, @QueryParam("digits") String digits,
			@QueryParam("packTypeId") String packTypeId, @QueryParam("fmsisdn") String fmsisdn,
			@QueryParam("balance") String balance) {
		logger.info("\n\n\n\t\t\t >> GET BONUS DESCRIPTION procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "] packList [" + packList + "] " + "digits ["
				+ digits + "] packTypeId [" + packTypeId + "] fmsisdn [" + fmsisdn + "]" + " User Balance [" + balance
				+ "]\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForBonusTransferDesc(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, packList, digits, packTypeId, fmsisdn, balance, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				if (userDataBean.getResult() == -1) {
					responseList.add(new VariableAndValue(ResponseParameters.RESULT,
							String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
				} else {
					responseList.add(
							new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
					if (userDataBean.getFilePath() == null || userDataBean.getFilePath().equals("")) {
						responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
								TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
										+ File.separator + IvrMenu.UNKNOWN_ERROR_WAV_IVR));
					} else {
						responseList
								.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
					}

				}

			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}
			responseList
					.add(new VariableAndValue(ResponseParameters.PACK_ID, String.valueOf(userDataBean.getPackId())));
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00199")
					+ " handleGetBonusDescription() >> One or more parameters are not valid : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + " >> Going to fetch bonus transfer description : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		// now fetching bonus transfer description
		CodeStatus status;

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O"))
			status = new PackManager().generateBonusTransferDescIVR(userDataBean);

		else
			status = new PackManager().generateBonusTransferDesc(userDataBean);

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00200")
					+ " >> Unable to fetch bonus description status [" + status + "] " + "so returning error : msisdn ["
					+ userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_ID, String.valueOf(userDataBean.getPackId())));

		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] Fetch bonus description final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleGetBonusDescription() ends

	@GET
	@Path("/getDTDescription")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for get data transfer description
	 * It first validates all the parameters required for this request and then
	 * generates confirmation message for data transfer
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packList
	 * @param digits
	 * @param packTypeId
	 * @param fmsisdn
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and description of the pack that is to be
	 *         shown to user and the pack ID selected by user to purchase.
	 */
	public Response handleGetDTDescription(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("packList") String packList, @QueryParam("digits") String digits,
			@QueryParam("packTypeId") String packTypeId, @QueryParam("fmsisdn") String fmsisdn) {
		logger.info("\n\n\n\t\t\t >> GET DATA TRANSFER DESCRIPTION procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "] packList [" + packList + "] " + "digits ["
				+ digits + "] packTypeId [" + packTypeId + "] fmsisdn [" + fmsisdn + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForDataTransferDesc(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, packList, digits, packTypeId, fmsisdn, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				if (userDataBean.getResult() == -1) {
					responseList.add(new VariableAndValue(ResponseParameters.RESULT,
							String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
				} else {
					responseList.add(
							new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
					if (userDataBean.getFilePath() == null || userDataBean.getFilePath().equals("")) {
						responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
								TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
										+ File.separator + IvrMenu.UNKNOWN_ERROR_WAV_IVR));
					} else {
						responseList
								.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
					}

				}

			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}
			responseList
					.add(new VariableAndValue(ResponseParameters.PACK_ID, String.valueOf(userDataBean.getPackId())));
			logger.error(userDataBean.getRequestId() + " >> " + TSSJavaUtil.getLogInitial("00201")
					+ " One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + " >> Going to fetch data transfer description : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		// now fetching data transfer description
		CodeStatus status;

		// Fetching data transfer description for IVR
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O"))
			status = new PackManager().generateDataTransferDescIvr(userDataBean);

		// Fetching data transfer description for USSD
		else
			status = new PackManager().generateDataTransferDesc(userDataBean);

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " >> " + TSSJavaUtil.getLogInitial("00202")
					+ " Unable to fetch data transfer description status [" + status + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_ID, String.valueOf(userDataBean.getPackId())));

		logger.info(userDataBean.getRequestId() + " >> msisdn [" + userDataBean.getMsisdn()
				+ "] Fetch data transfer description final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleGetDTDescription() ends

	@GET
	@Path("/bonusTransfer")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for bonus transfer It first
	 * validates all the parameters required for this request and then goes for
	 * bonus transfer (gift)
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packId
	 * @param packTypeId
	 * @param fmsisdn
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and the message to be shown for this bonus
	 *         transfer (gift) request success, fail etc and the pack gift or say
	 *         bonus transfer detail means a string containing pack ID gifted by
	 *         user and result of this request in this format PACKID;RESULT example
	 *         1002;1
	 */
	public Response handleBonusTransfer(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("packId") String packId, @QueryParam("packTypeId") String packTypeId,
			@QueryParam("fmsisdn") String fmsisdn) {
		logger.info("\n\n\n\t\t\t >> BONUS TRANSFER procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "] packId [" + packId + "] " + "packTypeId ["
				+ packTypeId + "] fmsisdn [" + fmsisdn + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForBonusTransfer(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, packId, packTypeId, fmsisdn, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				if (userDataBean.getResult() == -1) {
					responseList.add(new VariableAndValue(ResponseParameters.RESULT,
							String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
				} else {
					responseList.add(
							new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
					if (userDataBean.getFilePath() == null || userDataBean.getFilePath().equals("")) {
						responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
								TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
										+ File.separator + IvrMenu.UNKNOWN_ERROR_WAV_IVR));
					} else {
						responseList
								.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
					}

				}

			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}
			responseList.add(new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL,
					userDataBean.getPackPurchaseDetail()));

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00203")
					+ " handleBonusTransfer() >> One or more parameters are not valid : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + " >> Going to transfer the bonus : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		// now going to transfer bonus
		CodeStatus status;

		// transfer bonus for IVR
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O"))
			status = new ChargingManager().bonusTransferIvr(userDataBean);

		else
			status = new ChargingManager().bonusTransfer(userDataBean);

		if (CodeStatus.LOW_BALANCE == status) {
			logger.info(userDataBean.getRequestId() + "  >> Unable to transfer bonus status [" + status + "] "
					+ "so returning failure : msisdn [" + userDataBean.getMsisdn() + "]");
		} else if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00204")
					+ " >> Unable to transfer bonus status [" + status + "] " + "so returning error : msisdn ["
					+ userDataBean.getMsisdn() + "]");
		}

		logger.debug(userDataBean.getRequestId() + " >> (IVR) FilePathIvr=[" + userDataBean.getFilePath() + "] MSISDN:["
				+ userDataBean.getMsisdn() + "].");
		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(
				new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL, userDataBean.getPackPurchaseDetail()));

		logger.info(userDataBean.getRequestId() + " >> msisdn [" + userDataBean.getMsisdn()
				+ "] Bonus transfer final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleBonusTransfer() ends

	@GET
	@Path("/checkDTEligibility")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for checking data transfer
	 * eligibility for user It first validates all the parameters required for this
	 * request and then check user eligibility of user for data transfer
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packId
	 * @param packTypeId
	 * @return response of this request in variable name and value format. This
	 *         method returns the result that the user is eligible for data transfer
	 *         or not and the message to be shown to user if not eligible
	 */
	public Response handleCheckDTEligibility(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType) {
		logger.info("\n\n\n\t\t\t>> CHECK DATA TRANSFER ELIGIBILITY procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForCheckDTEligibility(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {

				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00205")
					+ " >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + " >> Going to check data transfer eligibility for user : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		// now going to transfer bonus
		CodeStatus status;
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O"))
			status = new ChargingManager().checkDTEligibilityIvr(userDataBean);

		else
			status = new ChargingManager().checkDTEligibility(userDataBean);

		if (CodeStatus.SUCCESS != status && CodeStatus.NOT_ELIGIBLE_FOR_DT != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00206")
					+ " >> Unable to check data transfer eligibility for user status [" + status + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		if (CodeStatus.SUCCESS != status) {
			responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		}

		logger.info(userDataBean.getRequestId() + " >> msisdn [" + userDataBean.getMsisdn()
				+ "] check data transfer eligibility" + " final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleCheckDTEligibility() ends

	@GET
	@Path("/dataTransfer")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for data transfer It first
	 * validates all the parameters required for this request and then goes for data
	 * transfer
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packId
	 * @param packTypeId
	 * @param fmsisdn
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and the message to be shown for this data
	 *         transfer request success, fail etc and the pack transfered or say
	 *         data transfer detail means a string containing pack ID gifted by user
	 *         and result of this request in this format PACKID;RESULT example
	 *         1002;1
	 */
	public Response handleDataTransfer(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("packId") String packId, @QueryParam("packTypeId") String packTypeId,
			@QueryParam("fmsisdn") String fmsisdn) {
		logger.info("\n\n\n\t\t\t>> DATA TRANSFER procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "] packId [" + packId + "] " + "packTypeId ["
				+ packTypeId + "] fmsisdn [" + fmsisdn + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForDataTransfer(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, packId, packTypeId, fmsisdn, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				if (userDataBean.getResult() == -1) {
					responseList.add(new VariableAndValue(ResponseParameters.RESULT,
							String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
				} else {
					responseList.add(
							new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
					if (userDataBean.getFilePath() == null || userDataBean.getFilePath().equals("")) {
						responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
								TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
										+ File.separator + IvrMenu.UNKNOWN_ERROR_WAV_IVR));
					} else {
						responseList
								.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
					}

				}

			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}
			responseList.add(new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL,
					userDataBean.getPackPurchaseDetail()));

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00207")
					+ " >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + " >> Going to transfer the data : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		// now going to transfer data
		CodeStatus status;

		// for IVR
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
				|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O"))
			status = new ChargingManager().dataTransferIvr(userDataBean);

		else
			status = new ChargingManager().dataTransfer(userDataBean);

		if (CodeStatus.LOW_BALANCE == status) {
			logger.info(userDataBean.getRequestId() + " >> Unable to transfer data status [" + status + "] "
					+ "so returning failure : msisdn [" + userDataBean.getMsisdn() + "]");
		} else if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00208")
					+ " >> Unable to transfer data status [" + status + "] " + "so returning error : msisdn ["
					+ userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(
				new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL, userDataBean.getPackPurchaseDetail()));

		logger.info(userDataBean.getRequestId() + " >> msisdn [" + userDataBean.getMsisdn()
				+ "] Data transfer final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleDataTransfer() ends

	@GET
	@Path("/getUserProfile")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to get the user profile which contains user profile
	 * information It first validates all the parameters required for this request
	 * and then check profile of user
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @return response of this request in variable name and value format. This
	 *         method returns the basic information of user like
	 *         msisdn,user_id,password,name etc.
	 */
	public Response handleGetUserProfile(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode) {
		logger.info("\n\n\n\t\t\t >> GET USER PROFILE procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForCheckProfile(msisdn, langId, requestId,
				interfaceUsed, shortCode, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {

			if (interfaceUsed.equalsIgnoreCase("I") || interfaceUsed.equalsIgnoreCase("O")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00313")
						+ " >> (IVR) One or more parameters are not valid : msisdn [" + msisdn
						+ "], so sending error response " + responseList);
			}

			else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				// added to show balance in float/double or Integer if true then
				// float or double else Integer

				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
				logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00181")
						+ " >> One or more parameters are not valid : msisdn [" + msisdn
						+ "], so sending error response " + responseList);
			}
			return new Response(responseList);
		}

		UserProfileBean profileBean = new UserProfileBean();
		new UserManager().getUserProfile(userDataBean, profileBean);

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));

		return new Response(responseList);
	}

	@GET
	@Path("/callLogs")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for purchase a pack for user It
	 * first validates all the parameters required for this request and then goes
	 * for entry in database for call logs
	 * 
	 * @param msisdn
	 * @param langId
	 * @param packBrowseList
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param digits
	 * @param balance
	 * @param packList
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and the message to be shown (message is not
	 *         shown to end user)
	 */
	public Response handleCallLogs(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("packBrowseList") String packBrowseList, @QueryParam("requestId") String requestId,
			@QueryParam("interface") String interfaceUsed, @QueryParam("shortCode") String shortCode,
			@QueryParam("subType") String subType, @QueryParam("balance") String balance,
			@QueryParam("packPurchaseDetail") String packPurchaseDetail, @QueryParam("fmsisdn") String fmsisdn) {
		logger.info("\n\n\n\t\t\t >> CALL LOGS procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] packBrowseList [" + packBrowseList + "] requestId [" + requestId
				+ "] " + "interface [" + interfaceUsed + "] shortCode [" + shortCode + "] subType [" + subType
				+ "] balance [" + balance + "] " + "packPurchaseDetail [" + packPurchaseDetail + "] fmsisdn [" + fmsisdn
				+ "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();
		Date sysDate, callStartDate = null;

		boolean validParams = new ParametersValidator().validateForCallLogs(msisdn, langId, packBrowseList, requestId,
				interfaceUsed, shortCode, subType, balance, packPurchaseDetail, fmsisdn, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
			responseList
					.add(new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00209")
					+ " >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + "  >> Going to maintain call logs of user : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		sysDate = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat(MPCommonDataTypes.DATE_FORMAT);
		userDataBean.setCallHangUpTime(formatter.format(sysDate));
		// Managing call details
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I") || userDataBean.getInterfaceUsed().equalsIgnoreCase("C")) {
			if (TSSJavaUtil.instance().getCallManagerMap().containsKey(userDataBean.getMsisdn())) {
				UserDataBean callDurationBean = TSSJavaUtil.instance().getCallManagerMap()
						.get(userDataBean.getMsisdn());
				if (!callDurationBean.getCallStartTime().isEmpty() && callDurationBean.getCallStartTime() != null) {
					userDataBean.setCallStartTime(callDurationBean.getCallStartTime());
					try {
						logger.info("CallStartTime:" + userDataBean.getCallStartTime());
						callStartDate = formatter.parse(userDataBean.getCallStartTime());
						logger.info("RequestId[" + userDataBean.getRequestId() + "] " + "Call Duration in Seconds:["
								+ userDataBean.getCallDuration() + "]  userDataBean:" + userDataBean.toString());
					} catch (ParseException e) {
						logger.error("Exception while parsing date in handleCallLogs method");
						e.printStackTrace();
					}

					userDataBean.setCallDuration((int) (((sysDate.getTime() - callStartDate.getTime()) / 1000)));
					userDataBean.addAllAccessedPacksRecords(callDurationBean.getAccessedPacksRecords());

					// Removing requestId from CallManagerMap
					TSSJavaUtil.instance().getCallManagerMap().remove(userDataBean.getMsisdn());
					logger.info("CallHangUpTime:[" + userDataBean.getCallHangUpTime() + "]  CallStartTime:["
							+ userDataBean.getCallStartTime() + "]");
				} else {
					logger.error("RequestId[" + userDataBean.getRequestId() + "] " + TSSJavaUtil.getLogInitial("00334")
							+ " >> callStartTime[" + callDurationBean.getCallStartTime() + "] found null or empty.");
				}
			} else {
				logger.info("RequestId[" + userDataBean.getRequestId() + "]  >> MSISDN[" + userDataBean.getMsisdn()
						+ "] not found in CallManagerMap.");
			}
		}

		logger.info("CallManagerMap SIZE:[" + TSSJavaUtil.instance().getCallManagerMap().size() + "]");

		// now maintaining call logs
		CodeStatus status = new DBOperations().new LogsManager().maintainCallLogs(userDataBean);

		if (status == CodeStatus.SUCCESS) {
			responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.SUCCESS)));
			responseList
					.add(new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.CALL_LOGS_SUCCESS + "_" + userDataBean.getLangId())));

		} else {
			responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
			responseList
					.add(new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
		}

		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] call logs final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleCallLogs() ends

	@GET
	@Path("/directDial")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to handle the request for direct Dial. It first validates
	 * all the parameters required for this request and then goes to purchase the
	 * selected pack for user
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and the message to be shown for this
	 *         request success, fail etc and the pack purchase/transfer/gift detail
	 *         means a string containing pack ID(pack type id in case of TTT)
	 *         purchased/transfered/gifted by user and result of this request in
	 *         this format PACKID/PACK_TYPE_ID;RESULT example 1002;1
	 */
	public Response handleDirectDial(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType) {
		logger.info("\n\n\n\t\t\t >> Handling of Direct Dial short code procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "]\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForDirectDial(msisdn, langId, requestId, interfaceUsed,
				shortCode, subType, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
			if (userDataBean.getFilePath() == null || "".equals(userDataBean.getFilePath())) {
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			} else {
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
			}

			responseList.add(new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL,
					userDataBean.getPackPurchaseDetail()));

			logger.info(userDataBean.getRequestId()
					+ "  >> In case of Direct Dial,One or more parameters are not valid : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId()
				+ "  >> Going to check that which service user want to use in case of Direct Dial: msisdn ["
				+ userDataBean.getMsisdn() + "]");

		// now purchasing pack
		if (ServiceTypes.PACK_PURHCASE.equals(userDataBean.getServiceType())) {
			CodeStatus status = new ChargingManager().purchasePack(userDataBean);

			if (CodeStatus.LOW_BALANCE == status) {
				logger.info(userDataBean.getRequestId() + " Unable to purchase pack for user, status [" + status + "] "
						+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
			} else if (CodeStatus.SUCCESS != status) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00297")
						+ " Unable to purchase pack for user, status [" + status + "] "
						+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
			}

		} // PACK_PURCHASE

		else if (ServiceTypes.BONUS_TRANSFER.equals(userDataBean.getServiceType())) {
			// now going to transfer bonus
			CodeStatus status = new ChargingManager().bonusTransfer(userDataBean);

			if (CodeStatus.LOW_BALANCE == status) {
				logger.info(userDataBean.getRequestId() + "  >> Unable to transfer bonus status [" + status + "] "
						+ "so returning failure : msisdn [" + userDataBean.getMsisdn() + "]");
			} else if (CodeStatus.SUCCESS != status) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00302")
						+ " >> Unable to transfer bonus status [" + status + "] " + "so returning error : msisdn ["
						+ userDataBean.getMsisdn() + "]");
			}
		} else if (ServiceTypes.DATA_TRANSFER.equals(userDataBean.getServiceType())) {
			// now going to transfer data
			CodeStatus status = new ChargingManager().dataTransfer(userDataBean);

			if (CodeStatus.LOW_BALANCE == status) {
				logger.info(userDataBean.getRequestId() + " >> Unable to transfer data status [" + status + "] "
						+ "so returning failure : msisdn [" + userDataBean.getMsisdn() + "]");
			} else if (CodeStatus.SUCCESS != status) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00303")
						+ " >> Unable to transfer data status [" + status + "] " + "so returning error : msisdn ["
						+ userDataBean.getMsisdn() + "]");
			}
		} else if (ServiceTypes.TALK_TIME_TRANSFER_OFFNET.equals(userDataBean.getServiceType())
				|| ServiceTypes.TALK_TIME_TRANSFER_ONNET.equals(userDataBean.getServiceType())) {
			// now going to transfer talk time

			CodeStatus status = new ChargingManager().talkTimeTransfer(userDataBean);

			if (CodeStatus.LOW_BALANCE == status || CodeStatus.LOW_TTT_BALANCE == status) {
				logger.info(userDataBean.getRequestId() + "  >> Unable to transfer talk time status [" + status + "] "
						+ "so returning failure : msisdn [" + userDataBean.getMsisdn() + "]");
			} else if (CodeStatus.SUCCESS != status) {
				logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00304")
						+ " >> Unable to transfer talk time status [" + status + "] " + "so returning error : msisdn ["
						+ userDataBean.getMsisdn() + "]");
			}
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(
				new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL, userDataBean.getPackPurchaseDetail()));

		logger.info(userDataBean.getRequestId() + " >> msisdn [" + userDataBean.getMsisdn() + "] final response is "
				+ responseList + "\n\n\n");
		return new Response(responseList);

	}// handleDirectDial() ends

	@GET
	@Path("/cleanCallManagerMap")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * Used to clean CallManagerMap
	 * 
	 * @return response of this request in variable name and value format
	 */
	public Response cleanCallManagerMap() {
		logger.info("\n\n\n\n\t\t\t >> Goining to clean the CallManagerMap\n");
		logger.info("CallManagerMap SIZE:[" + TSSJavaUtil.instance().getCallManagerMap().size() + "]");
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (TSSJavaUtil.instance().getCallManagerMap().size() < 1) {
			responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
			responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, "UNABLE TO CLEAN CallManagerMap"));
			logger.error("\n\n\t\t " + TSSJavaUtil.getLogInitial("00336") + " >> UNABLE TO CLEAN CallManagerMap\n\n\n");
		} else {

			for (Map.Entry<String, UserDataBean> callManagetMapEntry : TSSJavaUtil.instance().getCallManagerMap()
					.entrySet()) {
				if (callManagetMapEntry.getValue() == null) {
					logger.info("Going to inset values of improper hangups in our system. REQUEST_ID:["
							+ callManagetMapEntry.getValue().getRequestId() + "] MSISDN:["
							+ callManagetMapEntry.getValue().getMsisdn() + "]");
					new DBOperations().new LogsManager().maintainCallLogs(callManagetMapEntry.getValue());
				} else {
					logger.error("Not Going to maintain call log for KEY[" + callManagetMapEntry.getKey() + "] VALUE["
							+ callManagetMapEntry.getValue() + "]");
				}
			}

			TSSJavaUtil.instance().getCallManagerMap().clear();
			logger.info(
					"CallManagerMap SIZE:[" + TSSJavaUtil.instance().getCallManagerMap().size() + "] after cleanup.");
			responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.SUCCESS)));
			responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, "CallManagerMap Cleanup Successful"));
			logger.info("\n\n\t\t >> CallManagerMap Cleanup Successful\n\n\n");
		}
		return new Response(responseList);

	}// handleReloadCache() ends

	/**
	 * This method is used to receive the request for Data Macro Credit Conversion.
	 * It first validates all the parameters required for this request and then goes
	 * for data macro credit service.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param serviceDetail
	 * @param actionType
	 * 
	 * @author SIDDHARTH
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and the message to be shown for this data
	 *         macro credit conversion request.
	 */
	@GET
	@Path("/dmcConversion")
	@Produces(MediaType.APPLICATION_XML)
	public Response handleDMCVolumeBasedConversion(@QueryParam("msisdn") String msisdn,
			@QueryParam("langId") String langId, @QueryParam("requestId") String requestId,
			@QueryParam("interface") String interfaceUsed, @QueryParam("shortCode") String shortCode,
			@QueryParam("subType") String subType, @QueryParam("serviceDetail") String serviceDetail,
			@QueryParam("actionType") String actionType) {
		logger.info("\n\n\n\t\t\t>> (DMC) DATA MACRO CREDIT CONVERSION procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "] serviceDetail [" + serviceDetail
				+ "] actionType [" + actionType + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForDMCConversion(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, serviceDetail, actionType, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));

			if (userDataBean.getFilePath() == null) {
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			} else {
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
			}

			responseList.add(new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL,
					userDataBean.getPackPurchaseDetail()));

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00207")
					+ " >> (DMC) One or more parameters are not valid : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + " >> (DMC) Going for Data Macro Credit Service : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		CodeStatus status = CodeStatus.FAILURE;

		// Now going for Data Macro Conversion
		status = new ChargingManager().dmcConversion(userDataBean);

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00208")
					+ " >> (DMC) Unable to convet data status [" + status + "] " + "so returning error : msisdn ["
					+ userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(
				new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL, userDataBean.getPackPurchaseDetail()));

		logger.info(userDataBean.getRequestId() + " >> (DMC) msisdn [" + userDataBean.getMsisdn()
				+ "] Data Macro Creidt conversion final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// dmcConversion() ends

	/**
	 * This method is used to get Data Macro Credit Service Custom Pack Details. It
	 * first validates all the parameters required for this request and then it will
	 * get all the details of requested pack.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param dataToConvert
	 * @param digits
	 * @param packList
	 * @param actionType
	 * 
	 * @author SIDDHARTH
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and details of requested custom DMC pack.
	 */
	@GET
	@Path("/getDMCPackDetails")
	@Produces(MediaType.APPLICATION_XML)
	public Response handleGetDMCPackDetails(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("dataToConvert") String dataToConvert,
			@QueryParam("digits") String digits, @QueryParam("packList") String packList,
			@QueryParam("actionType") String actionType) {
		logger.info("\n\n\n\t\t\t>> DATA MACRO CREDIT PACK DETAILS procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] dataToConvert [" + dataToConvert + "] digits [" + digits
				+ "] packList [" + packList + "] actionType [" + actionType + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForDMCPackDetails(msisdn, langId, requestId,
				interfaceUsed, shortCode, dataToConvert, digits, packList, actionType, userDataBean);

		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();

		// if parameters are not valid
		if (!validParams) {
			{
				responseList
						.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
				if (userDataBean.getFilePath() == null) {
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
							TSSJavaUtil.instance().getCacheParameters()
									.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
				} else {
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
				}
			}

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00207")
					+ " >> (DMC) One or more parameters are not valid : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId()
				+ " >> Going to get the details of selected custom Data Macro Credit Pack with actionType ["
				+ userDataBean.getPackActionType() + "] : msisdn [" + userDataBean.getMsisdn() + "]");

		CodeStatus status = CodeStatus.FAILURE;

		// Method to get Data Macro Credit Service Pack Details for
		// requested pack (Multiple Configuration)
		status = new ServicesManager().getDmcPackDetails(userDataBean);

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00208")
					+ " >> (DMC) Unable to get the details of selected custom Data Macro Credit Pack status [" + status
					+ "] actionType [" + userDataBean.getPackActionType() + "]so returning error : msisdn ["
					+ userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(new VariableAndValue(ResponseParameters.SERVICE_DETAIL, userDataBean.getServiceDetail()));
		logger.info(userDataBean.getRequestId() + " >> (DMC) msisdn [" + userDataBean.getMsisdn()
				+ "] getDMCPackDetails final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleGetDMCPackDetails method ends

	/**
	 * This method is used to get all available options for Data Macro Credit
	 * Service for requested type and data entered by user. It first validates all
	 * the parameters required for this request and then get all details of
	 * available custom packs according to the provided configurations.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param dataToConvert
	 * @param actionType
	 * @author SIDDHARTH
	 * @return response of this request in variable name and value format. This
	 *         method will returns the result and the available custom packs that
	 *         will be shown to the user for the requested data.
	 */
	@GET
	@Path("/getDMCAvailableOptions")
	@Produces(MediaType.APPLICATION_XML)
	public Response handleGetDMCAvailableOptions(@QueryParam("msisdn") String msisdn,
			@QueryParam("langId") String langId, @QueryParam("requestId") String requestId,
			@QueryParam("interface") String interfaceUsed, @QueryParam("shortCode") String shortCode,
			@QueryParam("subType") String subType, @QueryParam("dataToConvert") String dataToConvert,
			@QueryParam("actionType") String actionType) {
		logger.info("\n\n\n\t\t\t>> (DMC) DATA MACRO CREDIT AVAILABLE OPITONS procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "] dataToConvert [" + dataToConvert
				+ "] actionType [" + actionType + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForDMCAvailableOptions(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, dataToConvert, actionType, userDataBean);

		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();

		// if parameters are not valid
		if (!validParams) {
			responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
			if (userDataBean.getFilePath() == null) {
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			} else {
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
			}

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00207")
					+ " >> (DMC) One or more parameters are not valid : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId()
				+ " >> (DMC) Going to get the available option for requested Data in Data Macro Credit Service : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		CodeStatus status = CodeStatus.FAILURE;

		status = new ServicesManager().getNewDMCAvailableOptions(userDataBean);

		if (CodeStatus.SUCCESS != status) {
			logger.warn(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00208")
					+ " >> (DMC) Unable to get available packs for requested data in DMC status [" + status + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_LIST, userDataBean.getPackList()));
		logger.info(userDataBean.getRequestId() + " >> (DMC) msisdn [" + userDataBean.getMsisdn()
				+ "] Data Macro Credit Service getDMCAvailableOptions final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// getDMCAvailableOptions method ends

	/**
	 * This method is used to receive the request for data macro credit conversion
	 * amount based (DMCA). It first validates all the parameters required for this
	 * request and then goes for data macro credit service.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param balToConvert
	 * @author SIDDHARTH
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and the message to be shown for this data
	 *         macro credit transfer request success, fail etc.
	 */
	@GET
	@Path("/dmcAmountBasedConversion")
	@Produces(MediaType.APPLICATION_XML)
	public Response handleDMCAmountBasedConversion(@QueryParam("msisdn") String msisdn,
			@QueryParam("langId") String langId, @QueryParam("requestId") String requestId,
			@QueryParam("interface") String interfaceUsed, @QueryParam("shortCode") String shortCode,
			@QueryParam("subType") String subType, @QueryParam("balToConvert") String balToConvert) {
		logger.info(
				"\n\n\n\t\t\t>> (DMC-AB) DATA MACRO CREDIT AMOUNT BASE Conversion procedure starts here : app counter ["
						+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] "
						+ "request Parameters received are : msisdn [" + msisdn + "] langId [" + langId
						+ "] requestId [" + requestId + "] " + "interface [" + interfaceUsed + "] shortCode ["
						+ shortCode + "] subType [" + subType + "] balToConvert [" + balToConvert + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForDMCAmountBasedConversion(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, balToConvert, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				if (userDataBean.getResult() == -1) {
					responseList.add(new VariableAndValue(ResponseParameters.RESULT,
							String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
				} else {
					responseList.add(
							new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
					if (userDataBean.getFilePath() == null || userDataBean.getFilePath().equals("")) {
						responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
								TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
										+ File.separator + IvrMenu.UNKNOWN_ERROR_WAV_IVR));
					} else {
						responseList
								.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
					}

				}

			} else {

				responseList
						.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));

				if (userDataBean.getFilePath() == null) {
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
							TSSJavaUtil.instance().getCacheParameters()
									.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
				} else {
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
				}
			}
			responseList.add(new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL,
					userDataBean.getPackPurchaseDetail()));

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00207")
					+ " >> (DMC-AB) One or more parameters are not valid : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + " >> Going to convert the amount into data : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		CodeStatus status = CodeStatus.FAILURE;

		// Now going to convert Data
		status = new ChargingManager().dmcAmountBasedConversion(userDataBean);

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00208")
					+ " >> (DMC-AB) Unable to convet amount into data status [" + status + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(
				new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL, userDataBean.getPackPurchaseDetail()));

		logger.info(userDataBean.getRequestId() + " >> (DMC-AB) msisdn [" + userDataBean.getMsisdn()
				+ "] Amount to Data conversion final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// dmcAmountBasedConversion() ends

	/**
	 * This method is used to get data macro credit amount based details. It first
	 * validates all the parameters required for this request and then get all
	 * details for data macro credit service.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param balance
	 * @param balToConvert
	 * @author SIDDHARTH
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and the message to be shown for this data
	 *         macro credit transfer.
	 */
	@GET
	@Path("/dmcAmountBasedConversionDetails")
	@Produces(MediaType.APPLICATION_XML)
	public Response handleGetDMCAmountBasedConversionDetails(@QueryParam("msisdn") String msisdn,
			@QueryParam("langId") String langId, @QueryParam("requestId") String requestId,
			@QueryParam("interface") String interfaceUsed, @QueryParam("shortCode") String shortCode,
			@QueryParam("subType") String subType, @QueryParam("balToConvert") String balToConvert) {
		logger.info(
				"\n\n\n\t\t\t>> (DMC-AB) DATA MACRO CREDIT AMOUNT BASED CONVESION DETAILS procedure starts here : app counter ["
						+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] "
						+ "request Parameters received are : msisdn [" + msisdn + "] langId [" + langId
						+ "] requestId [" + requestId + "] " + "interface [" + interfaceUsed + "] shortCode ["
						+ shortCode + "] subType [" + subType + "] balToConvert [" + balToConvert + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForDMCAmountBasedConversion(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, balToConvert, userDataBean);

		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();

		// if parameters are not valid
		if (!validParams) {
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				if (userDataBean.getResult() == -1) {
					responseList.add(new VariableAndValue(ResponseParameters.RESULT,
							String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
				} else {
					responseList.add(
							new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
					if (userDataBean.getFilePath() == null || userDataBean.getFilePath().equals("")) {
						responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
								TSSJavaUtil.instance().getCacheParameters().getIvrBasePath() + userDataBean.getLangId()
										+ File.separator + IvrMenu.UNKNOWN_ERROR_WAV_IVR));
					} else {
						responseList
								.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
					}

				}

			} else {

				responseList
						.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));

				if (userDataBean.getFilePath() == null) {
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH,
							TSSJavaUtil.instance().getCacheParameters()
									.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
				} else {
					responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
				}
			}

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00207")
					+ " >> (DMC-AB) One or more parameters are not valid : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + " >> (DMC-AB) Going to get the details of converted data : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		CodeStatus status = CodeStatus.FAILURE;

		status = new ChargingManager().getDMCAccountBasedDetails(userDataBean);

		if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00208")
					+ " >> (DMC-AB) Unable to get DMC converted data details status [" + status + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		logger.info(userDataBean.getRequestId() + " >> (DMC-AB) msisdn [" + userDataBean.getMsisdn()
				+ "] Getting DMC-AB data, final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// dmcAmountBasedConversionDetails() ends

	/**
	 * This method is used to test custom methods
	 * 
	 * @param param
	 * @author SIDDHARTH
	 * @return return response as success or failure
	 */
	@GET
	@Path("/testHit")
	@Produces(MediaType.APPLICATION_XML)
	public Response testHit(@QueryParam("param") String param) {
		logger.info("\n\n\n\t\t\t >> Inside test Hit of MarketplaceApi\n");
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();

		/*
		 * int insertedSeq = 0; UserDataBean userDataBean = new UserDataBean();
		 * userDataBean.setRequestId("12345-Test-54321");
		 * userDataBean.setMsisdn("221723999999");
		 * 
		 * for (int i = 0; i < 1; i++) { insertedSeq = new DBOperations().new
		 * SMSSender().getGeneratedSequenceId(userDataBean);
		 * logger.info("Retrived Inserted Sequence ["+insertedSeq+"]"); }
		 */

		UserDataBean userDataBean = new UserDataBean();
		userDataBean.setRequestId("12345-Test-54321");
		userDataBean.setMsisdn("221723999999");
		// userDataBean.setBalToConvert(Integer.parseInt(param));
		userDataBean.setInterfaceUsed("U");
		userDataBean.setLangId((byte) 1);

		// new ServicesManager().getNewDataMacroCreditAvailableOptions(userDataBean);

		logger.info(
				"Response : FilePath[" + userDataBean.getFilePath() + "] Result [" + userDataBean.getResult() + "]");
		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.SUCCESS)));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		logger.info("\n\n\t\t >> Test Hit Ends << \n\n\n");
		logger.info("Response ===>>>> " + new Response(responseList));
		return new Response(responseList);

	}// testHit() ends

	/**
	 * This method is used to receive the request for getting Promotional Packs. It
	 * first validates all the parameters required for this request and then get the
	 * promotional pack for the user.
	 * 
	 * @author richard
	 * 
	 * @param msisdn
	 * @param langId
	 * @param packTypeId
	 * @param packBrowseList
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param index
	 * @param balance
	 * @param packList
	 * @return response of this request in variable name and value format. This
	 *         method returns result, packs to be shown in message, list of browsed
	 *         packs, and the list of product codes that are shown to user in
	 *         current request.
	 */
	@GET
	@Path("/getWelcomePromotionPacks")
	@Produces(MediaType.APPLICATION_XML)
	public Response handleGetWelcomePromotionPacks(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("packTypeId") String packTypeId, @QueryParam("packBrowseList") String packBrowseList,
			@QueryParam("index") String index, @QueryParam("balance") String balance,
			@QueryParam("packList") String packList) {
		logger.info("\n\n\n\t\t\t >> GET Welcome Promotion Packs procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] packTypeId [" + packTypeId + "] packBrowseList [" + packBrowseList
				+ "] " + "requestId [" + requestId + "] interface [" + interfaceUsed + "] shortCode [" + shortCode
				+ "] subType [" + subType + "] index [" + index + "] " + "balance [" + balance + "] packList ["
				+ packList + "] \n\n\n");

		UserDataBean userDataBean = new UserDataBean();
		CodeStatus codeStatus = CodeStatus.FAILURE;
		PackManager packManager = new PackManager();

		boolean validParams = new ParametersValidator().validateForGetPromotionPacks(msisdn, langId, packTypeId,
				packBrowseList, requestId, interfaceUsed, shortCode, subType, index, balance, packList, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {

			
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O") || userDataBean.getInterfaceUsed().equalsIgnoreCase("C")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {
			
				responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList
					.add(new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}
			responseList
					.add(new VariableAndValue(ResponseParameters.PACK_BROWSE_LIST, userDataBean.getPackBrowseList()));
			responseList.add(new VariableAndValue(ResponseParameters.PACK_LIST, userDataBean.getPackList()));

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00186")
					+ "  >> One or more parameters are not valid for get promotional packs : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(
				userDataBean.getRequestId() + "  >> Going to fetch all available promotion packs of user : msisdn ["
						+ userDataBean.getMsisdn() + "]");

		// now getting all available packs for user

		
		if(userDataBean.getInterfaceUsed().equalsIgnoreCase("C"))
		{
			codeStatus= packManager.fetchAvailableWelcomePromotionPackForIVR(userDataBean);
		}
		else {
			// For Other Interfaces
			logger.error(userDataBean.getRequestId() + " >> Unsupported interface [" + userDataBean.getInterfaceUsed()
					+ "] in get promotion packs where msisdn[" + userDataBean.getMsisdn() + "]");
		}

		if (CodeStatus.SUCCESS != codeStatus) {
			logger.info(userDataBean.getRequestId() + " >> Unable to fetch packs for user status [" + codeStatus + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_BROWSE_LIST, userDataBean.getPackBrowseList()));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_LIST, userDataBean.getPackList()));
		responseList.add(new VariableAndValue(ResponseParameters.IS_MORE_AVAILABLE, userDataBean.getMore()));

		logger.info(userDataBean.getRequestId() + " >> msisdn [" + userDataBean.getMsisdn()
				+ "] Fetch all Promotional Packs final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleGetPromotionPacks() method ends

	
	
	
	/**
	 * This method is used to receive the request for getting Promotional Packs. It
	 * first validates all the parameters required for this request and then get the
	 * promotional pack for the user.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param packTypeId
	 * @param packBrowseList
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param index
	 * @param balance
	 * @param packList
	 * @return response of this request in variable name and value format. This
	 *         method returns result, packs to be shown in message, list of browsed
	 *         packs, and the list of product codes that are shown to user in
	 *         current request.
	 */
	@GET
	@Path("/getPromotionPacks")
	@Produces(MediaType.APPLICATION_XML)
	public Response handleGetPromotionPacks(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("packTypeId") String packTypeId, @QueryParam("packBrowseList") String packBrowseList,
			@QueryParam("index") String index, @QueryParam("balance") String balance,
			@QueryParam("packList") String packList) {
		logger.info("\n\n\n\t\t\t >> GET Promotion Packs procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] packTypeId [" + packTypeId + "] packBrowseList [" + packBrowseList
				+ "] " + "requestId [" + requestId + "] interface [" + interfaceUsed + "] shortCode [" + shortCode
				+ "] subType [" + subType + "] index [" + index + "] " + "balance [" + balance + "] packList ["
				+ packList + "] \n\n\n");

		UserDataBean userDataBean = new UserDataBean();
		CodeStatus codeStatus = CodeStatus.FAILURE;
		PackManager packManager = new PackManager();

		boolean validParams = new ParametersValidator().validateForGetPromotionPacks(msisdn, langId, packTypeId,
				packBrowseList, requestId, interfaceUsed, shortCode, subType, index, balance, packList, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {

			
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O") || userDataBean.getInterfaceUsed().equalsIgnoreCase("C")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {
			
				responseList
					.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList
					.add(new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
							.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}
			responseList
					.add(new VariableAndValue(ResponseParameters.PACK_BROWSE_LIST, userDataBean.getPackBrowseList()));
			responseList.add(new VariableAndValue(ResponseParameters.PACK_LIST, userDataBean.getPackList()));

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00186")
					+ "  >> One or more parameters are not valid for get promotional packs : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(
				userDataBean.getRequestId() + "  >> Going to fetch all available promotion packs of user : msisdn ["
						+ userDataBean.getMsisdn() + "]");

		// now getting all available packs for user

		// For USSD
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
			codeStatus = packManager.fetchAvailablePromotionPack(userDataBean);
		} 
		else if(userDataBean.getInterfaceUsed().equalsIgnoreCase("C"))
		{
			codeStatus= packManager.fetchAvailablePromotionPackForIVR(userDataBean);
		}
		else {
			// For Other Interfaces
			logger.error(userDataBean.getRequestId() + " >> Unsupported interface [" + userDataBean.getInterfaceUsed()
					+ "] in get promotion packs where msisdn[" + userDataBean.getMsisdn() + "]");
		}

		if (CodeStatus.SUCCESS != codeStatus) {
			logger.info(userDataBean.getRequestId() + " >> Unable to fetch packs for user status [" + codeStatus + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_BROWSE_LIST, userDataBean.getPackBrowseList()));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_LIST, userDataBean.getPackList()));
		responseList.add(new VariableAndValue(ResponseParameters.IS_MORE_AVAILABLE, userDataBean.getMore()));

		logger.info(userDataBean.getRequestId() + " >> msisdn [" + userDataBean.getMsisdn()
				+ "] Fetch all Promotional Packs final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleGetPromotionPacks() method ends

	
	/**
	 * This method is used to receive the request for getting customer care flow
	 * promotion pack description. It first validates all the parameters
	 * required for this request and then fetches the the description of the
	 * promotion packs configured for a particular user account.
	 * 
	 * 
	 * @author richard
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packTypeId
	 * @param packBrowseList
	 * @param index
	 * @param balance
	 * @param packList
	 * @return
	 */
	@GET
	@Path("/getCustomerCarePromotionPacks")
	@Produces(MediaType.APPLICATION_XML)
	public Response handleGetCustomerCarePromotionPacks(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("packTypeId") String packTypeId, @QueryParam("packBrowseList") String packBrowseList,
			@QueryParam("index") String index, @QueryParam("balance") String balance,
			@QueryParam("packList") String packList) {

		logger.info("\n\n\n\t\t\t >> GET Promotion Packs procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] packTypeId [" + packTypeId + "] packBrowseList [" + packBrowseList
				+ "] " + "requestId [" + requestId + "] interface [" + interfaceUsed + "] shortCode [" + shortCode
				+ "] subType [" + subType + "] index [" + index + "] " + "balance [" + balance + "] packList ["
				+ packList + "] \n\n\n");

		UserDataBean userDataBean = new UserDataBean();
		CodeStatus codeStatus = CodeStatus.FAILURE;
		PackManager packManager = new PackManager();

		boolean validParams = new ParametersValidator().validateForGetPromotionPacks(msisdn, langId, packTypeId,
				packBrowseList, requestId, interfaceUsed, shortCode, subType, index, balance, packList, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {

			responseList.add(new VariableAndValue(ResponseParameters.RESULT,
					String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
			responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			responseList.add(new VariableAndValue(ResponseParameters.PRODUCT_CODE,
					String.valueOf(userDataBean.getProductCode())));

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00186")
					+ "  >> One or more parameters are not valid for get customer care promotional packs : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(
				userDataBean.getRequestId() + "  >> Going to fetch all available customer care promotion packs of user : msisdn ["
						+ userDataBean.getMsisdn() + "]");

		// now getting all available packs for user

		// For USSD
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("C")) {

			codeStatus = packManager.fetchAvailableCustomerCarePromotionPackForIVR(userDataBean);
		} else {
			// For Other Interfaces
			logger.error(userDataBean.getRequestId() + " >> Unsupported interface [" + userDataBean.getInterfaceUsed()
					+ "] in getting customer care promotion packs where msisdn[" + userDataBean.getMsisdn() + "]");
		}

		// Modify to remove error due to low balance
		if (CodeStatus.SUCCESS != codeStatus && userDataBean.getResult() != ResponseParameters.LOW_BALANCE) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00189")
					+ " >> Unable to fetch customer care promotion pack description status [" + codeStatus + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		logger.info("Product Code : " + String.valueOf(userDataBean.getProductCode()));

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(
				new VariableAndValue(ResponseParameters.PRODUCT_CODE, String.valueOf(userDataBean.getProductCode())));

		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] Fetch customer care promotional pack description final response is " + responseList + "\n\n\n");

		return new Response(responseList);
	}
	
	/**
	 * This method is used to receive the request for get promotion pack
	 * description. It first validates all the parameters required for this request
	 * and then fetches the the description of the selected promotion pack.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param packList
	 * @param digits
	 * @param balance
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and description of the promotional pack
	 *         that is to be shown to user and the product code of the selected
	 *         pack.
	 */
	@GET
	@Path("/getPromoPackDescription")
	@Produces(MediaType.APPLICATION_XML)
	public Response handleGetPromoPackDescription(@QueryParam("msisdn") String msisdn,
			@QueryParam("langId") String langId, @QueryParam("requestId") String requestId,
			@QueryParam("interface") String interfaceUsed, @QueryParam("shortCode") String shortCode,
			@QueryParam("subType") String subType, @QueryParam("packList") String packList,
			@QueryParam("digits") String digits, @QueryParam("balance") String balance) {
		logger.info("\n\n\n\t\t\t >> GET PACK DESCRIPTION procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] requestId [" + requestId + "] " + "interface [" + interfaceUsed
				+ "] shortCode [" + shortCode + "] subType [" + subType + "] packList [" + packList + "] " + "digits ["
				+ digits + "] balance [" + balance + "]\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForGetPromoPackDescription(msisdn, langId, requestId,
				interfaceUsed, shortCode, subType, packList, digits, balance, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("C")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {

				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}
			
			
			responseList.add(new VariableAndValue(ResponseParameters.PRODUCT_CODE,
					String.valueOf(userDataBean.getProductCode())));

			logger.error(userDataBean.getRequestId()
					+ " handleGetPackDescription() >> One or more parameters are not valid in get promotion pack description : msisdn ["
					+ msisdn + "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + " >> Going to fetch promotional pack description : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		CodeStatus status = null;
		// now fetching pack description

		// Fetching Pack Description for USSD
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
			status = new PackManager().fetchPromoPackDescription(userDataBean);
		}
		else if(userDataBean.getInterfaceUsed().equalsIgnoreCase("C"))
		{
			status = new PackManager().fetchPromoPackDescriptionForIVR(userDataBean);
		}
		else {
			// For Other Interfaces
			logger.error(userDataBean.getRequestId() + " >> Unsupported interface [" + userDataBean.getInterfaceUsed()
					+ "] msisdn[" + userDataBean.getMsisdn() + "]");
		}

		// Modify to remove error due to low balance
		if (CodeStatus.SUCCESS != status && userDataBean.getResult() != ResponseParameters.LOW_BALANCE) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00189")
					+ " >> Unable to fetch pack description status [" + status + "] " + "so returning error : msisdn ["
					+ userDataBean.getMsisdn() + "]");
		}

		logger.info("Product Code : " + String.valueOf(userDataBean.getProductCode()));
		
		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(
				new VariableAndValue(ResponseParameters.PRODUCT_CODE, String.valueOf(userDataBean.getProductCode())));

		logger.info(userDataBean.getRequestId() + "  >> msisdn [" + userDataBean.getMsisdn()
				+ "] Fetch promotional pack description final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handleGetPromoPackDescription() method ends

	/**
	 * This method is used to receive the request for purchase a promotional pack
	 * for user. It first validates all the parameters required for this request and
	 * then goes to purchase the selected promotional pack.
	 * 
	 * @param msisdn
	 * @param langId
	 * @param packBrowseList
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param productCode
	 * @param packTypeId
	 * @return response of this request in variable name and value format. This
	 *         method returns the result and the message to be shown for this
	 *         promotional pack purchase request success, fail etc and the pack
	 *         purchase detail means a string containing pack ID purchased by user
	 *         and result of this pack purchase request in this format PACKID;RESULT
	 *         example 1002;1
	 */
	@GET
	@Path("/purchasePromoPack")
	@Produces(MediaType.APPLICATION_XML)
	public Response handlePurchasePromoPack(@QueryParam("msisdn") String msisdn, @QueryParam("langId") String langId,
			@QueryParam("requestId") String requestId, @QueryParam("interface") String interfaceUsed,
			@QueryParam("shortCode") String shortCode, @QueryParam("subType") String subType,
			@QueryParam("productCode") String productCode, @QueryParam("packBrowseList") String packBrowseList,
			@QueryParam("packTypeId") String packTypeId) {
		logger.info("\n\n\n\t\t\t >> PURCHASE PROMOTIONAL PACK procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "] packBrowseList [" + packBrowseList + "] requestId [" + requestId
				+ "] " + "interface [" + interfaceUsed + "] shortCode [" + shortCode + "] subType [" + subType
				+ "] productCode [" + productCode + "] packTypeId [" + packTypeId + "]" + "\n\n\n");

		UserDataBean userDataBean = new UserDataBean();

		boolean validParams = new ParametersValidator().validateForPurchasePromoPack(msisdn, langId, packBrowseList,
				requestId, interfaceUsed, shortCode, subType, productCode, packTypeId, userDataBean);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {
			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("C")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {

				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
				responseList.add(
						new VariableAndValue(ResponseParameters.FILE_PATH, TSSJavaUtil.instance().getCacheParameters()
								.getUssdMenuString(UssdMenuNames.UNKNOWN_ERROR + "_" + userDataBean.getLangId())));
			}
			responseList.add(new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL,
					userDataBean.getPackPurchaseDetail()));

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00192")
					+ " >> One or more parameters are not valid in purchasing promotin pack hit : msisdn [" + msisdn
					+ "], so sending error response " + responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + "  >> Going to purchase pack for user : msisdn ["
				+ userDataBean.getMsisdn() + "]");

		// now purchasing pack
		CodeStatus status = null;

		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
			status = new ChargingManager().purchasePromotionPack(userDataBean);
		} 
		else if(userDataBean.getInterfaceUsed().equalsIgnoreCase("C"))
		{
			status = new ChargingManager().purchasePromotionPackForIVR(userDataBean);
		}
		else {
			// For Other Interfaces
			logger.error(userDataBean.getRequestId() + " >> Unsupported interface [" + userDataBean.getInterfaceUsed()
					+ "] in promo pack purchase hit. msisdn[" + userDataBean.getMsisdn() + "]");
		}

		if (CodeStatus.LOW_BALANCE == status) {
			logger.info(userDataBean.getRequestId() + " >>> Unable to purchase pack for user, status [" + status + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		} else if (CodeStatus.SUCCESS != status) {
			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00193")
					+ " Unable to purchase pack for user, status [" + status + "] " + "so returning error : msisdn ["
					+ userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, userDataBean.getFilePath()));
		responseList.add(
				new VariableAndValue(ResponseParameters.PACK_PURCHASE_DETAIL, userDataBean.getPackPurchaseDetail()));

		logger.info(userDataBean.getRequestId() + " >> msisdn [" + userDataBean.getMsisdn()
				+ "] User's promotional pack purchase final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}// handlePurchasePromotionPack() ends
	
	@GET
	@Path("/updateBrowsingList")
	@Produces(MediaType.APPLICATION_XML)
	public Response handleUpdateBrowsingList(@QueryParam("msisdn") String msisdn, @QueryParam("requestId") String requestId,
										@QueryParam("digits") String digit, @QueryParam("packBrowseList") String packBrowseList) {
		logger.info("\n\n\n\t\t\t >> GET Promotion Packs procedure starts here : app counter ["
				 + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] requestId [" + requestId + "]  packBrowseList [" + packBrowseList );
		System.out.println("##################");
		System.out.println("\n\n\n\t\t\t >> GET Promotion Packs procedure starts here : app counter ["
				 + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] requestId [" + requestId + "]  packBrowseList [" + packBrowseList );
		String packBrowsingData = packBrowseList+","+digit;
		
		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		responseList.add(new VariableAndValue(ResponseParameters.RESULT, digit));
		responseList.add(new VariableAndValue(ResponseParameters.PACK_BROWSE_LIST, packBrowsingData));
		logger.info(  " >> msisdn [" + msisdn
				+ "] Fetch all Promotional Packs final response is " + responseList + "\n\n\n");

		return new Response(responseList);

	}
	
	
	// added by Sanchit Atri on 22/11/21
	@GET
	@Path("/referPack")
	@Produces(MediaType.APPLICATION_XML)
	/**
	 * This method is used to receive the request for getting available packs / Pack
	 * Type for user It first validates all the parameters required for this request
	 * and then get dynamic Pack/Pack Type to show to user
	 * 
	 * @param msisdn
	 * @param langId
	 * @param packTypeId
	 * @param packBrowseList
	 * @param requestId
	 * @param interfaceUsed
	 * @param shortCode
	 * @param subType
	 * @param index
	 * @param balance
	 * @param packList
	 * @param isPackType
	 * @param digits
	 * @return response of this request in variable name and value format. This
	 *         method returns result, packs to be shown in message, list of pack IDs
	 *         that user has browsed, and the list of IDs that are shown to user in
	 *         current request
	 */
	public Response referPack(@QueryParam("msisdn") String msisdn,@QueryParam("digits") String fmsisdn,
			@QueryParam("langId") String langId,@QueryParam("requestId") String requestId,
			@QueryParam("interface") String interfaceUsed,@QueryParam("shortCode") String shortCode, 
			@QueryParam("productCode") String productCode, @QueryParam("packTypeId") String packTypeId)  {
		logger.info("\n\n\n\t\t\t >> referPack procedure starts here : app counter ["
				+ TSSJavaUtil.instance().updateAndGetAppCounter() + "] " + "request Parameters received are : msisdn ["
				+ msisdn + "] langId [" + langId + "]" + "requestId [" + requestId + "] interface [" + interfaceUsed + "] shortCode [" + shortCode
				+"] \n\n\n");

		UserDataBean userDataBean = new UserDataBean();
		CodeStatus codeStatus = null;
		PackManager packManager = new PackManager();
		DBOperations dbOps= new DBOperations();
		Date sysDate = new Date();
		long getPacksTime = System.currentTimeMillis();

		boolean validParams = new ParametersValidator().validateForReferPacks(msisdn, langId, packTypeId,
				requestId, interfaceUsed, shortCode, userDataBean, fmsisdn);

		// if parameters are not valid
		ArrayList<VariableAndValue> responseList = new ArrayList<VariableAndValue>();
		if (!validParams) {

			if (userDataBean.getInterfaceUsed().equalsIgnoreCase("I")
					|| userDataBean.getInterfaceUsed().equalsIgnoreCase("O")) {
				responseList.add(new VariableAndValue(ResponseParameters.RESULT,
						String.valueOf(ResponseParameters.INVALID_PARAM_IVR)));
				responseList.add(new VariableAndValue(ResponseParameters.FILE_PATH, IvrMenu.NO_FILE_PATH_IVR));
			} else {
				responseList.add(
						new VariableAndValue(ResponseParameters.RESULT, String.valueOf(ResponseParameters.FAILURE)));
			}

			logger.error(userDataBean.getRequestId() + " " + TSSJavaUtil.getLogInitial("00186")
					+ "  >> One or more parameters are not valid : msisdn [" + msisdn + "], so sending error response "
					+ responseList);
			return new Response(responseList);
		}

		logger.debug(userDataBean.getRequestId() + "  >> Going to enter details in cdr and refer_member_profile table : msisdn ["
				+ userDataBean.getMsisdn() + "]     fmsisdn = ["+ fmsisdn+"]");

		// now Going to enter details in refer_member_profile table
		
		

		// For USSD
		if (userDataBean.getInterfaceUsed().equalsIgnoreCase("U")) {
			codeStatus = d.manageReferralPacksDetails(userDataBean);
		}


		
		if (CodeStatus.SUCCESS != codeStatus) {
			logger.info(userDataBean.getRequestId() + " >> Unable to refer pack status [" + codeStatus + "] "
					+ "so returning error : msisdn [" + userDataBean.getMsisdn() + "]");
		}

		responseList.add(new VariableAndValue(ResponseParameters.RESULT, String.valueOf(userDataBean.getResult())));
		
		logger.info(userDataBean.getRequestId() + " Time to execute referPack method ["
				+ (System.currentTimeMillis() - getPacksTime) + "]");
		
		return new Response(responseList);

	}// referPack() ends


	
	
	

}