	/**
 * 
 */
package ChargingServer;
import FileBaseLogging.*;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.*;
import java.lang.Math;
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.security.MessageDigest;

public class ChargingServer implements Runnable
{
	static final Logger logger=Logger.getLogger("ChargingServer");
	static int count=0;
        private String query_req="insert into crbt_chg_request(req_date,req_id,msisdn,charging_code,description, account_type) values(sysdate,?,?,?,?,?)";
	private String query_res="insert into crbt_chg_response(req_date,req_id,msisdn,charging_code,description,account_type,resp_code) values(sysdate,?,?,?,?,?,?)";
	private	long chg_reqId=0;
	String subtype="";
	Boolean _DIFFRENTIAL_CHARGING_ENABLE = false;
	Boolean _DIFFRENTIAL_GIFTING_ENABLE = false;
	Boolean _ONE_DAY_CHG_ENABLE=false;
	Boolean _PROFILE_BILLING_ENABLE=false;


	int axis_request_timeout=8000;//default 8 second
	ChargingServer chgserver=null;
	Data_Object data_object=null;
	int[] hybridac=new int[5];

	String vlr = "", scfAddress = "", busyNumber = "", noReplyNumber = "", unreachableNumber = "";
	StringBuffer msrnBuf ;
	StringBuffer imsiBuf ;
	StringBuffer cfuActiveStr;

	int serviceKey=0;
	Boolean isRoaming = true;
	boolean isPrepaid = true;
	Boolean cfuActive = true;
	int msrnError =0;
	FileLogWriter flw=null;
	FileLogWriter flw_balancededuct=null;
	Connection con=null;
	ResultSet rs=null;
	Statement stmt=null;
	int postpaidcheck=0;
	PostCharging postCharging=null;
        int packId=-1;
        int cp_code=-1;
	Thread t= new Thread();

	public ChargingServer(FileLogWriter flw,FileLogWriter flw_balancededuct)
	{
		//this.chgserver=chgserver;
		//this.data_object=data_object;
                System.out.println("Inside ChargingServer Constructor");  
		this.flw=flw;
		this.flw_balancededuct=flw_balancededuct;
	}
	public void stop()
	{
	}

	public void insertLog(double req_id,String msisdn,int chg_code,String desc,int resp_code, int req_for, String acId)
	{
		PreparedStatement pstmt=null; 
		String query_log="";
		if(req_for==1)
			query_log=query_req;
		else
			query_log=query_res;
		logger.info(query_log);
		try{
			this.con=Global.conPool.getConnection();

			pstmt=con.prepareStatement(query_log);
			pstmt.setDouble(1,req_id);
			pstmt.setString(2,msisdn);
			pstmt.setInt(3,chg_code);
			pstmt.setString(4,desc);
			pstmt.setInt(5,Integer.parseInt(acId));
			if(query_log.equalsIgnoreCase(query_res))
				pstmt.setInt(6,resp_code);

			pstmt.executeUpdate();
			pstmt.close();

		}catch(SQLException sqlex)
		{
			if(pstmt!=null)
			{
				try{
					pstmt.close();
				}
				catch(Exception eeee)
				{}
			}
			logger.error("Problem in excute query::",sqlex);
		}
		finally
		{
			try
			{
				con.close();
			}
			catch(Exception e)
			{
				logger.error("Exception",e);
			}
		}
	}
	public void insertfullLog(String msisdn,int tariffid,int action,String interfaceUsed,int service_class,int da_id,String fmsisdn,int rbtcode,double amount,int packId,int chgDays,int cpCode,String transId,int corpId)
	{     
                count++;
		logger.debug("COUNTER IS: "+count);
                PreparedStatement pstmt=null; 
		String query_log="";
		query_log="insert into CRBT_CDRS(cdr_id,msisdn,tariffid,action,interface,service_class,da_id,create_date,fmsisdn,rbt_code,amount,PACK_ID,days,cp_code,TRANS_ID,CORP_ID) values(crbt_cdr_id.nextval,?,?,?,?,?,?,sysdate,?,?,?,?,?,?,?,?)";
		try{
			this.con=Global.conPool.getConnection();
			pstmt=con.prepareStatement(query_log);
			pstmt.setString(1,msisdn);
			pstmt.setInt(2,tariffid);
			pstmt.setInt(3,action);
			pstmt.setString(4,interfaceUsed);
			pstmt.setInt(5,service_class);
			pstmt.setInt(6,da_id);
			pstmt.setString(7,fmsisdn);
			pstmt.setInt(8,rbtcode);
			pstmt.setDouble(9,amount);
			pstmt.setInt(10,packId);
			pstmt.setInt(11,chgDays);
                        pstmt.setInt(12,cpCode);
                        pstmt.setString(13,transId);
			pstmt.setInt(14,corpId);			

			pstmt.executeUpdate();
			logger.info(query_log);
			pstmt.close();
		}catch(SQLException sqlex)
		{
			if(pstmt!=null)
			{
				try{
					pstmt.close();
				}catch(SQLException eeeeeee){}
			}
			logger.error("Problem in excute query::",sqlex);
		}
		finally
		{
			try
			{
				con.close();
			}
			catch(Exception e)
			{
				logger.error("Exception",e);
			}
		}

	}


	public String checkForSubType(String msisdn)
	{
		String subType="";
		PreparedStatement pstmt=null; 
		try
		{
			this.con=Global.conPool.getConnection();
			String query="select SUB_TYPE from crbt_subscriber_master where MSISDN=?";
			pstmt=con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			rs=pstmt.executeQuery();
			if(rs.next())
			{
				subType=rs.getString("SUB_TYPE");
				logger.info("###>> query:"+query+"    "+msisdn+"  ret_val DB SUBTYPE:"+subType);
			}
		}
		catch(Exception e)
		{
			if(pstmt!=null)
			{
				try{
					pstmt.close();
					rs.close();
				}catch(SQLException eeeeeee){}
			}
			logger.error("Problem in excute query::",e);
		}
		finally
		{
			try
			{
				con.close();
			}
			catch(Exception e)
			{
				logger.error("Exception",e);
			}
		}

		return subType;

	}

	public int insertPendingReq(String msisdn)
	{
		int res=-1;



		PreparedStatement pstmt=null;
		try{
			this.con=Global.conPool.getConnection();
			String query="update crbt_pending_request set SUB_TYPE='P' where MSISDN=?";
			pstmt=con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			pstmt.executeUpdate();
			pstmt.close();
			logger.info("###>>   updated subtype in db for :"+msisdn);
			res=1;
		}
		catch(Exception e)
		{
			logger.info("###>> "+msisdn+"  updated subtype in db");
			if(pstmt!=null)
				try {
					pstmt.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

		}
		return res;
	}

	/*This Function check for resouce type to get Subtype and returns String as Subtype 
	  of msisdn and Takes Input as String of msisdn*/
	public boolean checkForSourceType(String msisdn) 
	{
		boolean response=false;
		String subType="P";
		int sourceType=-1;
		int resFM=-1;//Result From Fmsrm
		try
		{

			sourceType=Global.SUB_SOURCE_TYPE;	
			if(sourceType==1)
			{
				/* Check Subtype from HLR*/
				FetchMsrn FM=new FetchMsrn();
				resFM= FM.fetchmsrn(6, msisdn,msrnBuf, vlr, imsiBuf, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber, unreachableNumber, cfuActive, cfuActiveStr );
				if(resFM==1)
				{
					subType="P";
					response=true;
				}
				else if(resFM==2)
				{
					subType="O";
					response=false;
				}
				else
				{
					subType="P";
					response=true;
				}


			}
			else if(sourceType==3)
			{
				/*  Consider All Msisdn As prepaid*/
				subType="P";
				response=true;
			}
			else if(sourceType==4)
			{
				/* Consider All misisdn As Postpaid*/
				subType="O";
				response=false;

			}
			else if(sourceType==5)
			{
				/*Get Subtype From Data Base*/


				PreparedStatement pstmt=null;
				try{
					this.con=Global.conPool.getConnection();
					String query="select SUB_TYPE from "+Global.SUB_TYPE_TABLE+" where MSISDN=?";
					pstmt=con.prepareStatement(query);
					pstmt.setString(1,msisdn);
					rs=pstmt.executeQuery();
					if(rs.next())
					{
						subType=rs.getString("SUB_TYPE");
						logger.info("###>> query:"+query+"    "+msisdn+"  ret_val DB SUBTYPE:"+subType);
					}
					if(subType.equalsIgnoreCase("P"))
					{
						response=true;
					}
					else if(subType.equalsIgnoreCase("O"))
					{
						response=false;
					}
				}
				catch(Exception e)
				{
					logger.error("###>> "+msisdn+"  Error In Check Source From data Base");
					if(pstmt!=null)
						try {
							pstmt.close();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					subType="P";
					response=true;



				}
//sdn,msrnBuf, vlr, imsiBuf, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber, unreachableNumber, cfuActive, cfuActiveStr );
                            



			}
		}
		catch(Exception e)
		{
			logger.error("###>> "+msisdn+"Error checkForSourceType",e);
			response=true;
		}
		return response;
	}
      
    /*This method is used for getting content_provider_code using rbtcode  */
       public int getCpCode(String rbtcode)
        {
                int content_code=-1;
                logger.info("getCpCOde() for rbt :["+rbtcode+"]");
                PreparedStatement pstmt=null;
                ResultSet rs=null;
                String query="";
                query="select content_provider_code from crbt_rbt where rbt_code="+rbtcode;
                try{
                        logger.debug("gettinggg cp codee:::");    
			if( Global.content_Code.get(rbtcode) != null)
				{
 			                content_code=(Integer)Global.content_Code.get(rbtcode);
				}
	
                       if(content_code!=0 && content_code!=-1)
                        {
                           return content_code;  
                        }
                        else
                        {
                        this.con=Global.conPool.getConnection();
                        pstmt=con.prepareStatement(query);
                        rs=pstmt.executeQuery();
                        if(rs.next())
                        {
                         content_code=rs.getInt(1);
                         return content_code;
                        } 
                        logger.info(query);
                        pstmt.close();
                       }  
                }catch(Exception sqlex)
                {
                        if(pstmt!=null)
                        {
                                try{
                                        pstmt.close();
                                }catch(SQLException eeeeeee){}
                        }
                      content_code=-1;  
                      logger.error("Problem in excute query and fetching data from Global.content_code::",sqlex);
                }
                finally
                {
                        try
                        {
                                con.close();
                        }
                        catch(Exception e)
                        {
                                logger.error("Exception",e);
                        }
                }
             return content_code;  
        }//end 
  
      



	public void run()
	{

		int temp_cntr=0;
		while(true)
		{
			try
			{

				if (Global.que.isEmpty())
				{
					try
					{

						t.sleep(1);
						Global.rst(true);
						if(temp_cntr==3000)
							break;
						else
							temp_cntr++;



					}
					catch(Exception se)
					{
						System.out.println("exception in charging server");

					}

				}
				else
				{
					while(Global.cacheThreadAlive)
					{
						t.sleep(1);
						logger.info("ChargingServer Thread is Sleeping---------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
					}

				//	soapRequest=new SoapRequest(Global.chgUserName, Global.chgPassword, Global.chgCurrencyType);
				//	StringBuilder balance= new StringBuilder();
					postCharging = new PostCharging(Global.GATEWAY_URL,Global.chgUserName,Global.chgPassword);	
				        StringBuffer balance= new StringBuffer();
                                    	temp_cntr=0;
					data_object=new Data_Object();
					data_object =(Data_Object) Global.que.poll();
					if(data_object==null) 
					{
						logger.info (" # Request data is null");
						continue;
					}

					logger.info("###>>  "+data_object.o_msisdn+" is started its execution from ChargingServer");
					logger.info("###>>  "+data_object.o_msisdn+" is started its execution from ChargingServer");


					double _MonthlyAmount_pre=0.0;
					double _MonthlyAmount_post=0.0;
					double _3WeekAmount=0.0;
					double _2WeekAmount=0.0;
					double _1WeekAmount=0.0;
					double _1DayAmount=0.0; 
					String msisdn="";
					String accountId="0"; // 0 - main account : 8-DA8 account
					subtype="";
					boolean prepaid=true;
					boolean postpaid_normal=false;
					boolean postpaid_hybrid=false;
					int isprepaid=-1;
					//Double camount=new Double(0.0);
					Long camount=new Long(0);     
					int result=-1;
					try
					{
						accountId="0";
						boolean prepaidStatus=false; //added by rips 10-07-2012
					
						String _msisdn="";
						//double[]  existingBalance=new double[2];
						//int resFrmSoap=-1;
                                                int resFrmMml=-1;

						java.util.Calendar[] expData=new java.util.Calendar[2];
						String chgCode="";
						int chgDays=-1;

						int req_type=-1;
						int requestID=-1;
						String reason="NA";
						String interfaceUsed="NA";	
						int rbt=-1;	
						String fmsisdn="NA";	
						String resdata="";
						int reservestatus=0;
						int status=0;
						int request_type=0;
						int i=-1;
						int da_id=-1;
						int act=-1;
						int service_class=-1;
						int subsrateplan=-1;

						int[] chgCodeDays=new int[2];
						int j=-1;
						String[] s1=new String[20];
						double  TotalBalance=0.0;
						this.axis_request_timeout=Global.axis_request_timeout;
						logger.info("###>> Timeout is:"+axis_request_timeout);
						//_WSE=new wseclient(axis_request_timeout);
						boolean isMatched=true; 
						ArrayList<ChargingCodeAmount> chargingCodeDays=new ArrayList<ChargingCodeAmount>();
						try{
							req_type=data_object.o_reqtype;
							logger.info("###>> "+data_object.o_msisdn+" in request type is "+req_type+" flw_balancededuct:"+flw_balancededuct+" flw:"+flw);

							if(req_type==1)
							{
								requestID = data_object.o_reqid;
								msisdn = data_object.o_msisdn;
								chgCode=data_object.o_tariffid;
								act=data_object.o_action;
								interfaceUsed=data_object.o_interface;
								subtype=data_object.o_subtype;
								rbt=Integer.parseInt(data_object.o_rbtcode);
								fmsisdn=data_object.f_msisdn;
								packId=data_object.o_packId;
								_msisdn=msisdn;
								
								System.out.println("Traffic Id is: "+data_object.o_tariffid);
								StringTokenizer s = new StringTokenizer(data_object.o_tariffid ,";");
								while (s.hasMoreTokens())
								{
									i++;
									s1[i]=s.nextToken();
									System.out.println("Received Tokens.........."+i+" is.. "+s1[i]);
								}

								requestID = data_object.o_reqid;
								msisdn = data_object.o_msisdn;
								_msisdn=msisdn;
								//      chgCode=Integer.parseInt(data_object.o_data);
								//reqdata = data_object.o_data;
								//sock=data_object.sock;
								for(int cntr=0;cntr<19;cntr++)
								{
									if(s1[cntr]!=null)
									{
									ChargingCodeAmount chargingCodeAmount=null;
								        StringTokenizer stParam=new StringTokenizer(s1[cntr],":");

										j=-1;
										while(stParam.hasMoreTokens())
										{
										j++;
										chgCodeDays[j]=Integer.parseInt(stParam.nextToken());											
										}
										chargingCodeAmount=new ChargingCodeAmount();
										chargingCodeAmount.setChargingCode(chgCodeDays[0]);
										chargingCodeAmount.setChargingDays(chgCodeDays[1]);

										chargingCodeDays.add(chargingCodeAmount);
										logger.info("ChargingCode Array Size is: "+chargingCodeDays.size());
									}
								}



							}
							else if(req_type==2)
							{
								requestID = data_object.o_reqid;
								msisdn = data_object.o_msisdn;
								subtype=data_object.o_subtype;
							}
                                                        else if(req_type==3)
                                                        {
                                                                requestID = data_object.o_reqid;
                                                                msisdn = data_object.o_msisdn;
                                                                subtype=data_object.o_subtype;
                                                        }

							else
							{
								resdata=-1+"";
								return;
							}
							logger.info("###>> Reqid "+data_object.o_reqid + " MSISDN "+ data_object.o_msisdn+ "  DATA "+ data_object.o_data+"   SUBTYPE:"+subtype+"   interfaceUsed :"+interfaceUsed);
						}
						catch(Exception exin)
						{
							logger.error("###>> "+msisdn+"  Error... in getting data...",exin);

						}
						logger.info("###>> "+msisdn+"   SUBTYPE:"+subtype);
						//	_msisdn=msisdn.substring(3);
						if(req_type==1)
						{
							int _actDesc=-1;
							try
							{
								if(subtype.equalsIgnoreCase("P"))
								{
									prepaid=true;
									postpaid_normal=false;


									if(Global.TESTCASE!=1 && Global.REQUEST_TO_CHECK_BALANCE == 1)
									{
                                                                          //resquest to interface for checking balance return int value
										logger.debug("##msisdn["+msisdn+"] CheckBalance Enable["+Global.REQUEST_TO_CHECK_BALANCE+"]");
										   resFrmMml=postCharging.checkBalance(_msisdn, balance);      									
                                                                                logger.info("###>>     "+msisdn+" Balance From MMLCommandGen  is: ["+balance.toString() +"]");
										if(balance.toString()!=null && balance.toString().length()!=0)
										{
											TotalBalance=Double.parseDouble(balance.toString());
										}
										else
										{
											TotalBalance=-1;
										}
									}	
									else
									{
									//	resFrmSoap=-1;
										logger.debug("##msisdn["+msisdn+"] CheckBalance Not Enable["+Global.REQUEST_TO_CHECK_BALANCE+"]");
                                                                                resFrmMml = -1;
										TotalBalance = -1;
									}


								}
								else if(subtype.equalsIgnoreCase("O"))	
								{
									postpaid_normal=true;
									prepaid=false;
								}
								else
								{
									if(act==1)
									{
										logger.info("###>>     "+msisdn+"  request to HLR for action:"+act+"    subtype:"+subtype);
										//FetchMsrn FM=new FetchMsrn();
										//isprepaid= FM.fetchmsrn(6, msisdn, msrnBuf, vlr, imsiBuf, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber, unreachableNumber, cfuActive, cfuActiveStr );

										prepaidStatus=this.checkForSourceType(msisdn);

										logger.info("###>>     "+msisdn+"  ret_val HLR of prepaidStatus "+prepaidStatus);
									}
									else
									{
										boolean hlrRequest=false;
										String l_subtype="N";

										try{


											l_subtype=this.checkForSubType(msisdn);
											if(!(StringUtils.isBlank(l_subtype)))
											{
												if(l_subtype.equalsIgnoreCase("P"))
													prepaidStatus=true;
												else if(l_subtype.equalsIgnoreCase("O"))
													prepaidStatus=false;
												else
													hlrRequest=true;
											}
											else
											{
												hlrRequest=true;
											}

											logger.info("###>>   "+msisdn+"  ret_val DB SUBTYPE:"+l_subtype+"  hlrRequest:"+hlrRequest+"   prepaidStatus:"+prepaidStatus);
										}
										catch(Exception exp)
										{
											hlrRequest=true;
											logger.error("###>>   "+msisdn+"  exception in checking data from db  so  hlrRequest :"+hlrRequest,exp);

										}
										if(hlrRequest)
										{
											//FetchMsrn FM=new FetchMsrn();
											//isprepaid = FM.fetchmsrn(6, msisdn, msrnBuf, vlr, imsiBuf, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber, unreachableNumber, cfuActive, cfuActiveStr );
											prepaidStatus=this.checkForSourceType(msisdn);
											logger.info("###>>   hlrRequest:"+hlrRequest+"   "+msisdn+"  ret_val HLR of prepaidStatus "+prepaidStatus);
										}	
									}
									if(prepaidStatus)
									{
										//////////////////////////////////For Testing///////////////////////
										//existingBalance[0]=0.1;//=(_WSE.GetBalance(_msisdn,expData)); //added
										//existingBalance[1]=(-0.1);//=(_WSE.GetBalance(_msisdn,expData)); //added
										//################################################################//
										if(Global.REQUEST_TO_CHECK_BALANCE == 1)
										{
										         logger.debug("##msisdn ["+msisdn+"] CheckBalanceEnable ["+Global.REQUEST_TO_CHECK_BALANCE+"]");				
											resFrmMml=postCharging.checkBalance(_msisdn, balance);
										
											if(balance.toString()!=null && balance.toString().length()!=0)
											{
												TotalBalance=Double.parseDouble(balance.toString());
											}
											else
											{
											TotalBalance=-1;
											}
										}
										else
										{
										logger.debug("##msisdn["+msisdn+"] CheckBalance Not Enable["+Global.REQUEST_TO_CHECK_BALANCE+"]");
										 TotalBalance = -1;
										}

										prepaid=true;
										postpaid_normal=false;
									}
									else
									{
										postpaid_normal=true;
										prepaid=false;
									}
								}

								//logger.info(chgCode + " is charging code");

								result=-2;
								for(int tariffCount=0;tariffCount<chargingCodeDays.size();tariffCount++)

								{
									chgDays=-1;
									chgCode="";
									chgCode=chargingCodeDays.get(tariffCount).getChargingCode()+"";
									chgDays=chargingCodeDays.get(tariffCount).getChargingDays();
									logger.info(msisdn+"#> Charging Code is: ["+chgCode+"] Charging Dys is: ["+chgDays+"]");
									if(act==5)
									{
										_actDesc=act=2;
									}
									else if(act==6)
									{
										_actDesc=act=2;
									}
									else if(act==7)
									{
										_actDesc=act=2;
									}
									else
									{
										_actDesc=act;
									}

									while(Global.cacheThreadAlive)
									{
										t.sleep(1);
										logger.info("ChargingServer Thread is Sleeping---------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
									}
									try
									{
										if(prepaid)	
										{ 
									camount=(long)Math.round((float)Global.charges_prepaid.get(chgCode.trim()));
									logger.info(msisdn+"#> Charging Amount is "+camount);
										}
										else if(postpaid_normal || postpaid_hybrid)
									camount=(long)Math.round((float)Global.charges_postpaid.get(chgCode.trim()));
									}
									catch(NullPointerException ex)
									{
										camount=null;
										insertLog(chg_reqId, msisdn, -1, ex.getMessage(),-4,2,accountId);
										logger.error("###>>   "+msisdn+"   Cannot Get Balance From database");
									}

									//diffenable disable
									java.util.Date cur_date=new java.util.Date();

									logger.info("###>>   "+msisdn+"   amount: "+camount + " is charging amount");
									if(camount!=null )
									{

										if(isMatched)
										{

											logger.info("###>>     "+msisdn+"  Getting Existing Balance of "+TotalBalance);
											if(camount!=0)
											{
												logger.info("###>>     "+msisdn+"  Balance is "+TotalBalance); 
											}
											else
											{
												logger.info("###>>     "+msisdn+"No need to check balance as charging amount is 0");
											}
											da_id=0;
											//if(subtype.equalsIgnoreCase("P")||(subtype.equalsIgnoreCase("O")&&postpaidcheck==1))
											this.postpaidcheck=Global.postpaidcheck;
											logger.info("###>>     "+msisdn+"  postpaidcheck:"+this.postpaidcheck);
											if((prepaid)||((postpaid_normal)&&(postpaidcheck==1)))
											{
												logger.info("###>>     "+msisdn+"Prepaid Case");
												service_class=1;
												if(camount >0)
												{
													if(Global.REQUEST_TO_CHECK_BALANCE == 1)
													{
													if((camount<=TotalBalance) || postpaid_normal)
													{


														if(Global.TESTCASE!=1)
														{
														//	result=soapRequest.debitRequest(_msisdn,camount.longValue(), String.valueOf(chg_reqId));
															     logger.debug("##msisdn["+msisdn+"] checkBalanceEnable And Sending to Debit Balance to Gateway ["+Global.REQUEST_TO_CHECK_BALANCE+"]");	
												                           result=postCharging.debitBalance(_msisdn,String.valueOf(camount) , rbt , data_object.key,data_object);
          											
 
                                                                                                               	}
														else
														{
															result=1;
														}

													}
													else
													{
														logger.info("###>>    "+msisdn+"  Insufficient balance..");
														result=-2;
														//throw new LowBalanceException("Low Balance:"+TotalBalance);
														continue;
													}
													}
													else if(Global.REQUEST_TO_CHECK_BALANCE!=1)
													{

													        if(Global.TESTCASE!=1)
                                                                                                                {
                                                                                                                //      result=soapRequest.debitRequest(_msisdn,camount.longValue(), String.valueOf(chg_reqId));
														    logger.debug("##msisdn["+msisdn+"] checkBalanceNot Enable And Sending to Debit Balance request Gateway ["+Global.REQUEST_TO_CHECK_BALANCE+"] rbt["+rbt+"]");
													            result=postCharging.debitBalance(_msisdn,String.valueOf(camount) , rbt , data_object.key,data_object);
													

                                                                                                                }
                                                                                                                else
                                                                                                                {
															result = 1;
																	
                                                                                                                }


													}
												}
												else if(camount==0)
												{
													logger.info("###>>Charging Amount is  "+ camount+" to "+msisdn);
													result=1;	
													service_class=1;
												}
												else
												{
													logger.info("###>>  "+msisdn+" Insufficient balance..");
													result=-2;
													continue;
													//throw new LowBalanceException("Low Balance:"+TotalBalance);
												}
											}//if prepaid or postpaid true

											else
											{
												logger.info("###>>  "+msisdn+" Case Of Postpaid!!");
												result=1;	
												service_class=2;
											}
										} //isMatched
										else
										{
											result=0;
										}
									}
									else
									{
										result=0;
										camount=(long)-999;
									}

									if(result==1)
									{
										break;
									}
									else
									{
									 logger.debug("##msisdn ["+msisdn+"] RESULT NOT 1 So COntinue With next FallBack");			
									}	


								}
								this.chg_reqId=Global.getChgReqId();
								logger.info("###>>   "+msisdn+"  "+chg_reqId+" "+msisdn+" "+chgCode +" "+reason +" "+result +" "+accountId);
								if(result != -2)
								{
									insertLog(chg_reqId, msisdn, Integer.parseInt(chgCode.trim()), reason, result,2, accountId);
								}
								logger.info("###>>   "+msisdn+" response from MMLCommandGen ::::::"+result);
								if(result==1)
								{								
									resdata="1";
                                                                        logger.info("INSERTING FULL LOGS");
                                                                        cp_code=getCpCode(String.valueOf(rbt));
                                                                        logger.info("RbtCode :["+rbt+" Content_provider_code from getCpCode() is:["+cp_code+"]");                                                             
									insertfullLog(msisdn,Integer.parseInt(chgCode.trim()),_actDesc,interfaceUsed,service_class,da_id,fmsisdn,rbt,camount,packId,chgDays,cp_code,data_object.transId,data_object.o_corpId);
                                                                         
									if(_actDesc==1||_actDesc==4||_actDesc==41||_actDesc==42||_actDesc==43||_actDesc==44)
									{
										logger.info("###>>   "+msisdn+"#>>Action  ["+_actDesc+"]  No file based logging..");
										resdata=chgDays+"";
									} 
									else
									{
										int logDays=1;
										if(_actDesc==8||_actDesc==3)
										{
											logDays=chgDays;
										}
										else
										{

											logDays=chgDays;

										}
										resdata=logDays+"";
										if((camount>0 ) && (!interfaceUsed.equalsIgnoreCase("M")))
										{
											//		synchronized(flw)
											{
												flw.writeLog(msisdn+","+rbt+","+logDays);
												logger.info("Writting File for Interface Not equal M");
											}
										}
										logger.info("###>>   "+msisdn+" Action 3/8 file based logging done for days :"+resdata+"  interfaceUsed :"+interfaceUsed);
									}
									logger.info("###>>  Charging for msisdn ==== "+msisdn+"   is SUCCESSFUL for amount of  ======   "+camount);
									status=1;
								}
								else if(result==-2)
								{
									logger.info("###>>   Charging for msisdn ==== "+msisdn+"   is UNSUCCESSFUL for amount of  ======   "+camount);
									throw new LowBalanceException("Low Balance:"+TotalBalance);
								}
								else
								{
									resdata="-1";
									logger.info("###>>   Charging for msisdn ==== "+msisdn+"   is UNSUCCESSFUL for amount of  ======   "+camount);	
									status=-1;
									//throw new LowBalanceException("Low Balance:"+TotalBalance); 
								}


							}
							catch(LowBalanceException lowbal)
							{
								resdata="-1";
								status=-1;
								Global.rst(true);
								logger.error("###>>   "+msisdn+" Exception::::::::LowBalanceException:",lowbal);
								lowbal.printStackTrace();
								insertLog(chg_reqId, msisdn, -1,lowbal.getMessage(),-4,2,accountId);
							}

							catch(Exception conref)
							{
								resdata="-1";
								status=-1;
								Global.rst(true);
								logger.error( "###>>   "+msisdn+" Exception::::::::Exception:",conref);
								conref.printStackTrace();
								java.lang.Throwable throwable=conref.getCause();
								String errorDesc=((conref.getMessage().length()>90)?conref.getMessage().substring(0,89):conref.getMessage());
								if(throwable!=null)
								{
									logger.error("###>>   "+msisdn+" Exception::::::::Nested Exception is:",throwable);
									if(throwable instanceof java.net.SocketTimeoutException)
										insertLog(chg_reqId, msisdn, -1, errorDesc,-3,2, accountId);
									else if(throwable instanceof java.net.ConnectException)
										insertLog(chg_reqId, msisdn, -1, errorDesc,-5,2, accountId);
									else 
										insertLog(chg_reqId, msisdn, -1, errorDesc,-1,2, accountId);
								}
								else
									insertLog(chg_reqId, msisdn, -1,errorDesc,-8,2, accountId);
							}
							synchronized(flw_balancededuct)
							{
								flw_balancededuct.writeLog(msisdn+","+act+","+rbt+","+interfaceUsed+","+TotalBalance+","+camount+","+status);
							}

							logger.info("ReqType 1:: Charging Done for Days is: "+resdata +"Amount To Be Deduct: ["+camount+"] Charging Code: ["+chgCode+"]");
							data_object.res_data=resdata;
							data_object.o_amount=camount;
							data_object.o_tariffid=chgCode;

						}//req_type==1
						else if(req_type==2)
						{
							//_msisdn=msisdn.substring(3);
							_msisdn=msisdn;
							try{
								logger.info("###>>   Charging req_type :"+req_type+"  subtype :"+subtype+" for MSISDN:"+msisdn);
								//prepaidStatus=false;
								isprepaid=-1;
								int msrnStatus=-1;
								prepaidStatus=false;
								if(subtype.equalsIgnoreCase("N"))
								{
									// Send request to HLR
									logger.info("###>>    Checking subtype for :"+msisdn+"  from  HLR");
									//	FetchMsrn FM=new FetchMsrn();
									//prepaidStatus = FM.fetchmsrn(6,msisdn,msrnBuf, vlr, imsiBuf, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber, unreachableNumber, cfuActive, cfuActiveStr);
									//msrnStatus=FM.fetchmsrn(6,msisdn,msrnBuf, vlr, imsiBuf, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber, unreachableNumber, cfuActive, cfuActiveStr);
									prepaidStatus=this.checkForSourceType(msisdn);

									logger.info("###>>   "+msisdn+" From HLR ret_val of prepaidStatus: "+isprepaid);

									if(prepaidStatus)//prepaid
									{

										reservestatus=1;
										if(Global.TESTCASE!=1)
										{
                                                                                       
										        //	reservestatus=soapRequest.checkBalance(_msisdn, balance);
									          
                                                                                    reservestatus=postCharging.checkBalance(_msisdn,balance);

                                                                               	}
										//resdata=Integer.toString(reservestatus);
										resdata=balance.toString();
										logger.info("###>>   "+msisdn+" Prepaid reservation status :"+reservestatus);

									}//if prepaid if
									else if(!prepaidStatus)
									{
										logger.info("###>>   "+msisdn+" From HLR Case Of Postpaid!!");
										resdata="1";
									}
									else
									{
										logger.info("###>>   "+msisdn+"Unknown Error from HLR!");
									}
								}//end if
								if(subtype.equalsIgnoreCase("O"))
								{
									logger.info("###>>    "+msisdn+" Case Of Postpaid!!");
									resdata="1";
								}
								if(subtype.equalsIgnoreCase("P"))
								{

									reservestatus=-1;
									if(Global.TESTCASE!=1)
									{
										reservestatus=postCharging.checkBalance(_msisdn, balance);
									}
									else
									{

                                                                                balance.delete(0, balance.length());
										balance.append("10.0f");
                                                                               reservestatus=1;

									}
									//resdata=Integer.toString(reservestatus);
									resdata=balance.toString();
									logger.info("###>>    "+msisdn+"  Case Of Prepaid : reservation status is:"+reservestatus);
								}
							}
							catch(Exception conref)
							{
								resdata="-1";
								Global.rst(true);
								logger.error( "###>>   "+msisdn+" check in reservation Exception::::::::Exception:",conref);
								conref.printStackTrace();

								java.lang.Throwable throwable=conref.getCause();
								String errorDesc=((conref.getMessage().length()>90)?conref.getMessage().substring(0,89):conref.getMessage());
								if(throwable!=null)
								{
									logger.error("###>>   "+msisdn+" Exception::::::::Nested Exception is:"+throwable);
									if(throwable instanceof java.net.SocketTimeoutException)
										insertLog(chg_reqId, msisdn, -1, errorDesc,-3,2, accountId);
									else if(throwable instanceof java.net.ConnectException)
										insertLog(chg_reqId, msisdn, -1, errorDesc,-5,2, accountId);
									else
										insertLog(chg_reqId, msisdn, -1, errorDesc,-1,2, accountId);
								}
								else
									insertLog(chg_reqId, msisdn, -1,errorDesc,-6,2, accountId);

							}


							logger.info("ReqType 2:: Response From Check Balance: "+reservestatus +"Balnce From Check Balance  "+resdata);
							data_object.res_data=reservestatus+"";
                                                        // data_object.res_data=resdata+""; 
                                                        

							try
							{
								data_object.o_amount=Long.parseLong(resdata);
                                                            System.out.println(" ---------In try ---------");

							}
							catch(Exception e)
							{

								data_object.o_amount=0;

							}
                                                     logger.info("Amount Tag set is: ["+data_object.o_amount+"]");


						}

                                          //req_type==3
                                             else if(req_type==3)
						{
                                                         
							//_msisdn=msisdn.substring(3);
							_msisdn=msisdn;
							try{
								logger.info("###>>   Charging req_type :"+req_type+"  subtype :"+subtype+" for MSISDN:"+msisdn);
								//prepaidStatus=false;
								isprepaid=-1;
								int msrnStatus=-1;
								prepaidStatus=false;
								if(subtype.equalsIgnoreCase("N"))
								{
									// Send request to HLR
									logger.info("###>>    Checking subtype for :"+msisdn+"  from  HLR");
									//	FetchMsrn FM=new FetchMsrn();
									//prepaidStatus = FM.fetchmsrn(6,msisdn,msrnBuf, vlr, imsiBuf, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber, unreachableNumber, cfuActive, cfuActiveStr);
									//msrnStatus=FM.fetchmsrn(6,msisdn,msrnBuf, vlr, imsiBuf, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber, unreachableNumber, cfuActive, cfuActiveStr);
									prepaidStatus=this.checkForSourceType(msisdn);

									logger.info("###>>   "+msisdn+" From HLR ret_val of prepaidStatus: "+isprepaid);

									if(prepaidStatus)//prepaid
									{

										reservestatus=1;
										if(Global.TESTCASE!=1)
										{
                                                                                       
										        //	reservestatus=soapRequest.checkBalance(_msisdn, balance);
									          
                                                                                    reservestatus=postCharging.checkBalance(_msisdn,balance);

                                                                               	}
										//resdata=Integer.toString(reservestatus);
										resdata=balance.toString();
										logger.info("###>>   "+msisdn+" Prepaid reservation status :"+reservestatus);

									}//if prepaid if
									else if(!prepaidStatus)
									{
										logger.info("###>>   "+msisdn+" From HLR Case Of Postpaid!!");
										resdata="1";
									}
									else
									{
										logger.info("###>>   "+msisdn+"Unknown Error from HLR!");
									}
								}//end if
								if(subtype.equalsIgnoreCase("O"))
								{
									logger.info("###>>    "+msisdn+" Case Of Postpaid!!");
									resdata="1";
								}
								if(subtype.equalsIgnoreCase("P"))
								{

									reservestatus=-1;
									if(Global.TESTCASE!=1)
									{
										reservestatus=postCharging.checkBalance(_msisdn, balance);
									}
									else
									{

                                                                                balance.delete(0, balance.length());
										balance.append("10.0f");
                                                                               reservestatus=1;

									}
									//resdata=Integer.toString(reservestatus);
									resdata=balance.toString();
									logger.info("###>>    "+msisdn+"  Case Of Prepaid : reservation status is:"+reservestatus);
								}
							}
							catch(Exception conref)
							{
								resdata="-1";
								Global.rst(true);
								logger.error( "###>>   "+msisdn+" check in reservation Exception::::::::Exception:",conref);
								conref.printStackTrace();

								java.lang.Throwable throwable=conref.getCause();
								String errorDesc=((conref.getMessage().length()>90)?conref.getMessage().substring(0,89):conref.getMessage());
								if(throwable!=null)
								{
									logger.error("###>>   "+msisdn+" Exception::::::::Nested Exception is:"+throwable);
									if(throwable instanceof java.net.SocketTimeoutException)
										insertLog(chg_reqId, msisdn, -1, errorDesc,-3,2, accountId);
									else if(throwable instanceof java.net.ConnectException)
										insertLog(chg_reqId, msisdn, -1, errorDesc,-5,2, accountId);
									else
										insertLog(chg_reqId, msisdn, -1, errorDesc,-1,2, accountId);
								}
								else
									insertLog(chg_reqId, msisdn, -1,errorDesc,-6,2, accountId);

							}


							logger.info("ReqType 3:: Response From Check Balance: "+reservestatus +"Balnce From Check Balance  "+resdata);
							//data_object.res_data=reservestatus+"";
                                                         data_object.res_data=""+Long.parseLong(resdata);                                                                                   // data_object.res_data=resdata+""; 
                                                        

							try
							{
								data_object.o_amount=Long.parseLong(resdata);
                                                            System.out.println(" ---------In try ---------");

							}
							catch(Exception e)
							{

								data_object.o_amount=0;

							}
                                                     logger.info("Amount Tag set is: ["+data_object.o_amount+"]");


						}//end req_type==3

                                                

						Global.rst(true);
						try
						{
							if (Global.que_send.isEmpty())
							{
								logger.info("###>>Res Que is Empty" );
							}
							else
							{
								logger.info("###>>Res Que is NOT Empty" );
							}
						}catch(Exception e)
						{
							logger.error("Exception in acccessing queue",e);
						}
						postCharging = null;
						Global.que_send.put (data_object); 
						logger.info("###>> "+msisdn+"  Element is inserted in the queue in charging server socket is "+(data_object.sock).toString());

					}
					catch(Exception ee)
					{
						postCharging = null;
						Global.rst(true);
						logger.error("###>>"+msisdn+"   In While Exception::::::::Exception",ee);
						insertLog(chg_reqId, msisdn, -1, ee.getMessage().substring(0,24), -8,2, accountId);
						//	System.exit(1);
						//break;
					}
				}}
				catch(Exception ee)
				{
					logger.fatal("Exception::::::::"+ee.toString());
					ee.printStackTrace();
					System.exit(1);
					break;
				}


		}	

	}//end of run


}
