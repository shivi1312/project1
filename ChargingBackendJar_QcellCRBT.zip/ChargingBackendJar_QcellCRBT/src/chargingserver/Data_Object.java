package chargingserver;

import java.net.*;
import java.util.Arrays;
import java.io.*;

import com.telemune.client.ThirdPartyRequest;
public class Data_Object 
{
	int o_reqid 		= -1;
	int o_reqtype 		= -1;
	public int o_action		= -1; //modified by Avishkar from default to public on 16.10.2018
	public String res_data 	= ""; //modified by Avishkar from default to public on 16.10.2018
	int o_packId 		= -1;
	public String o_msisdn 	= "";
	public String o_subtype 	= ""; //modified by Avishkar from default to public on 16.10.2018
	String f_msisdn 	= "";
	String o_tariffid	= "";
	public String o_interface 	= "NA"; //modified by Avishkar from default to public on 16.10.2018
	public String o_rbtcode 	= "-1"; //modified by Avishkar from default to public on 16.10.2018
	Socket sock 		= null;
	int o_chgcode 		= -1;
	int o_days 		= -1;
	public double o_camount   	= -1; //modified by Avishkar from int to double on 03.09.2019
	int o_dedAccId  	= -1;
	int o_accountType 	= -1;
	int result 		= -1;
	public double camount 			= 0.0f; //modified by Avishkar from default to public on 16.10.2018
    public double balance 		= 0.0f;
    double o_minimum_amount	 	= 0.0f;
    public double advancebalance 	= 0.0f;
	int o_serviceclass 	= -1;
	int o_timerresponse 	= -1;
	String o_data 		= "";
	String o_desc 		= "";
	String o_amount 	= "";
    String o_userValidity 	= "";
	String reason 		= "NA";
	String o_currency = "NA";
	
 // Modification start by Avishkar on 12.10.2018
    
//  SoapRequest soapRequest = null;
//	PostCharging postCharging = null;
//  MobileWebSvc_pkg.PostCharging postCharging = null; // Added by Avishkar on 01.10.2018
//	WSClient _WSE = null; // Modified by Avishkar on 17.09.2018
//	DiameterRequest diameterRequest = null; // Added by Avishkar on 11.10.2018
	ThirdPartyRequest thirdPartyRequest = null; // Added by Avishkar on 18.10.2018
	
    // Modification end by Avishkar on 12.10.2018
	
	//added by Harjinder on 25-7-2016
	double[]  existingBalance=new double[2]; //telecell specific
        java.util.Calendar[] expData=new java.util.Calendar[2]; //telecell specific
//	SendToGateway sendToGateway = null;	

	public int o_cpCode = -1; //added by Avishkar on 16.10.2018
	public String productCode = ""; //Added by Avishkar on 1.11.2018 (Exclusively for NetOneSdp)
	String redirectTagValue = ""; // added by Avishkar on 22.11.2018
	String transId="NA"; // added by Avishkar on 07.01.2020
	int o_corpId = 0; // added by Avishkar on 10.01.2020
	
	
	//addition start by Avishkar on 28.11.2018
	public String getRedirectTagValue() {
		return redirectTagValue;
	}
	public void setRedirectTagValue(String redirectTagValue) {
		this.redirectTagValue = redirectTagValue;
	}
	//addition end by Avishkar on 28.11.2018
	
	//addition start by Avishkar on 1.11.2018
	public int getO_reqid() {
		return o_reqid;
	}
	public void setO_reqid(int o_reqid) {
		this.o_reqid = o_reqid;
	}
	public int getO_chgcode() {
		return o_chgcode;
	}
	public void setO_chgcode(int o_chgcode) {
		this.o_chgcode = o_chgcode;
	}
	public String getO_currency() {
		return o_currency;
	}
	public void setO_currency(String o_currency) {
		this.o_currency = o_currency;
	}
	//addition end by Avishkar on 1.11.2018
	
	// addition start by Avishkar on 20.11.2018
	public String getF_msisdn() {
		return f_msisdn;
	}
	public void setF_msisdn(String f_msisdn) {
		this.f_msisdn = f_msisdn;
	}
	public String getO_tariffid() {
		return o_tariffid;
	}
	public void setO_tariffid(String o_tariffid) {
		this.o_tariffid = o_tariffid;
	}
	public Socket getSock() {
		return sock;
	}
	public void setSock(Socket sock) {
		this.sock = sock;
	}
    public int getO_packId() {
	return o_packId;
	}
	public void setO_packId(int o_packId) {
		this.o_packId = o_packId;
	}
	
	// addition end by Avishkar on 20.11.2018
	
	// addition start by Avishkar on 29.07.2019
		public int getO_accountType() {
			return o_accountType;
		}
		public void setO_accountType(int o_accountType) {
			this.o_accountType = o_accountType;
		}
		
		public double[] getExistingBalance() {
			return existingBalance;
		}
		public void setExistingBalance(double[] existingBalance) {
			this.existingBalance = existingBalance;
		}
		public java.util.Calendar[] getExpData() {
			return expData;
		}
		public void setExpData(java.util.Calendar[] expData) {
			this.expData = expData;
		}
		public int getO_days() {
			return o_days;
		}
		public void setO_days(int o_days) {
			this.o_days = o_days;
		}
	// addition ends by Avishkar on 29.07.2019
		
	// addition start by Avishkar on 07.01.2020
		public String getTransId() {
			return transId;
		}
		public void setTransId(String transId) {
			this.transId = transId;
		}
	// addition ends by Avishkar on 07.01.2020 
		
	// addition start by Avishkar on 10.01.2020
		public int getO_corpId() {
			return o_corpId;
		}
		
		public void setO_corpId(int o_corpId) {
			this.o_corpId = o_corpId;
		}
	// addition ends by Avishkar on 10.01.2020
		
		public String getlog()
        {
                String log = o_reqid + "," +o_msisdn+ "###";
                return log;
        }
		
		// below method is added by Avishkar on 10.01.2020
		@Override
		public String toString() {
			return "Data_Object [o_reqid=" + o_reqid + ", o_reqtype="
					+ o_reqtype + ", o_action=" + o_action + ", res_data="
					+ res_data + ", o_packId=" + o_packId + ", o_msisdn="
					+ o_msisdn + ", o_subtype=" + o_subtype + ", f_msisdn="
					+ f_msisdn + ", o_tariffid=" + o_tariffid
					+ ", o_interface=" + o_interface + ", o_rbtcode="
					+ o_rbtcode + ", sock=" + sock + "]"; 
					/*+ ", o_chgcode=" + o_chgcode
					+ ", o_days=" + o_days + ", o_camount=" + o_camount
					+ ", o_dedAccId=" + o_dedAccId + ", o_accountType="
					+ o_accountType + ", result=" + result + ", camount="
					+ camount + ", balance=" + balance + ", o_minimum_amount="
					+ o_minimum_amount + ", advancebalance=" + advancebalance
					+ ", o_serviceclass=" + o_serviceclass
					+ ", o_timerresponse=" + o_timerresponse + ", o_data="
					+ o_data + ", o_desc=" + o_desc + ", o_amount=" + o_amount
					+ ", o_userValidity=" + o_userValidity + ", reason="
					+ reason + ", o_currency=" + o_currency
					+ ", thirdPartyRequest=" + thirdPartyRequest
					+ ", existingBalance=" + Arrays.toString(existingBalance)
					+ ", expData=" + Arrays.toString(expData)
					+ ", sendToGateway=" + sendToGateway + ", o_cpCode="
					+ o_cpCode + ", productCode=" + productCode
					+ ", redirectTagValue=" + redirectTagValue + ", transId="
					+ transId + ", o_corpId=" + o_corpId + "]";*/
		}
		
		/*public String toString()
		{
			return "o_reqid:[" +o_reqid+ "], o_action:[" +o_action+ "], o_reqtype:[" +o_reqtype+ "], res_data:["+res_data+"], o_packId:[" +o_packId+ "], o_msisdn:[" +o_msisdn+ "], o_tariffid:[" +o_tariffid+ "], o_subtype:[" +o_subtype+ "], o_interface:[" +o_interface+ "], f_msisdn:[" +f_msisdn+ "], o_rbtcode:[" +o_rbtcode+ "], sock:[" +sock+ "]";
		}*/
		
}
