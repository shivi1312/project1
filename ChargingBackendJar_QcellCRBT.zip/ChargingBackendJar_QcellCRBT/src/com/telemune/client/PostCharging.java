package com.telemune.client;

import java.util.*;
import java.text.*;
import java.io.*;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import javax.xml.stream.events.Characters;

import org.apache.commons.httpclient.HttpStatus;
//import org.apache.commons.httpclient.*;
//import org.apache.commons.httpclient.methods.*;
//import org.apache.commons.httpclient.params.HttpParams;
//import org.apache.http.client.params.ClientPNames;
//import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.params.HttpParams;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;

import org.apache.http.util.EntityUtils;
import org.apache.log4j.*;
import chargingserver.Data_Object;
import chargingserver.Global;

class PostCharging
{
	Logger logger = Logger.getLogger("PostCharging");	
	BufferedReader br=null;
	String url,username,passwd;
	int testcase=1;
	public int timeout=10000; // added by Avishkar on 14.10.2019
	
	PostCharging(String url,String username,String passwd)
	{
		this.url = url;
		this.username = username;
		this.passwd = passwd;
		this.timeout = Global.gateway_request_timeout; // added by Avishkar on 14.10.2019
	}
	
	
	/**@author Avishkar Verma on 24-04-2020
	 * This method is added for httpPost hit with modification by implementing CloseableHttpClient to close and release all resources at end.
	 * @param xmlString
	 * @param req
	 * @param dataObject
	 * @return
	 */
	private String sendPost(String xmlString, String req, Data_Object dataObject)
	{
	     StringBuffer responseXml = null;
	     CloseableHttpClient client = null;
	     CloseableHttpResponse response = null;
	     HttpPost post = null;
	     HttpParams httpParams = null;
	     try {
	    	 if (req.equalsIgnoreCase("debit"))
	    	 {
	    		 url = Global.gateway_link1;
	    		 logger.debug(">>>msisdn[" + dataObject.o_msisdn + "] Setting up url :[" + url + "]");
	    	 }
	    	 client = HttpClients.createDefault();
	    	 logger.debug(">>>msisdn[" + dataObject.o_msisdn + "] Client:[" + client + "]");
	 	/*	// added by Avishkar on 24-04-2020 starts
					HttpParams httpParams = (HttpParams) client.getParams();
					httpParams.setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, timeout*1000);
					httpParams.setParameter(CoreConnectionPNames.SO_TIMEOUT, timeout*1000);
					httpParams.setParameter(ClientPNames.CONN_MANAGER_TIMEOUT, new Long(timeout*1000));
			// added by Avishkar on 24-04-2020 ends
		*/	
			httpParams = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParams, this.timeout * 1000);
			HttpConnectionParams.setSoTimeout(httpParams, this.timeout * 1000);
	
	       
	       post = new HttpPost(url);
	       post.setParams(httpParams);
	       logger.debug(">>>msisdn[" + dataObject.o_msisdn + "] post before hit :[" + post + "]");
	       responseXml = new StringBuffer();
	 
	       post.addHeader("Content-Type", "text/xml");
	       post.addHeader("Accept", "text/xml");
	       post.addHeader("Except", "100-continue");
	 
	       
	       System.out.println("XML[" + xmlString + "]");
	       StringEntity entity = new StringEntity(xmlString);
	       post.setEntity(entity);
	 
	       System.out.println("\nSending 'POST' request to URL : " + this.url);
	       logger.info("\n>>>msisdn[" + dataObject.o_msisdn + "]  Sending 'POST' " + req + " request to URL : " + this.url);
	 
	       response = client.execute(post);
	       int returnCode = response.getStatusLine().getStatusCode();
	       String result = EntityUtils.toString(response.getEntity());
	       logger.info(">>>msisdn[" + dataObject.o_msisdn + "] " + req + " post hit returnCode:[" + returnCode + "]");
	       if (returnCode == HttpStatus.SC_NOT_IMPLEMENTED) {
	         System.err.println("The Post post is not implemented by this URI");
	         System.err.println(result);
	       } else {
				/*		br = new BufferedReader(new InputStreamReader(post.getResponseBodyAsStream()));
						String readLine;
						while(((readLine = br.readLine()) != null)) {
							System.err.println(readLine);
							responseXml.append(readLine);
						} */
	         responseXml.append(result);
	       }
	 		
	       //client.close(); // closed in finally block
	
	       logger.debug(">>>msisdn[" + dataObject.o_msisdn + "] post after execute hit :[" + post + "]");
	     } catch (Exception e) {
		       logger.error("Exception in sendPost method of PostCharging : ", e);
		       e.printStackTrace();
		       System.err.println(e);
	     } finally {
		       logger.debug(">>>msisdn[" + dataObject.o_msisdn + "] post in finally block :[" + post + "]");
		 
		       if (post != null) {
		         try {
		           post.releaseConnection();
		           post = null;
		         } catch (Exception e2) {
		           e2.printStackTrace();
		         }
		       }
		 
		       httpParams = null;
		 
		       if (client != null) {
		         try {
		           client.close();
		           client = null;
		         } catch (Exception e3) {
		           e3.printStackTrace();
		         }
		       }
		 
		       if (response != null) {
		         try {
		           response.close();
		           response = null;
		         } catch (Exception e4) {
		           e4.printStackTrace();
		         }
		       }
		 
		       if (this.br != null) try { this.br.close(); } catch (Exception fe) { fe.printStackTrace(); }
		 
	     }
	 
	     return responseXml.toString();
	}

	// below method is commented by Avishkar on 24-04-2020
	/*private String sendPost(String xmlString,String req, Data_Object dataObject) // modified by Avishkar on 27.01.2020
	{
		StringBuffer responseXml = null;//new StringBuffer();
		HttpClient client =null;// new HttpClient(); 
		PostMethod post = null;//new PostMethod(url);
		try{
			if(req.equalsIgnoreCase("debit"))
			{
				//url="http://10.223.2.20:8080/services/BcServices?wsdl";
				url=Global.gateway_link1; // modified by Avishkar on 10.01.2020
				logger.debug(">>>msisdn["+dataObject.o_msisdn+"] Setting up url :["+url+"]");
			}
			client = new HttpClient();
			logger.debug(">>>msisdn["+dataObject.o_msisdn+"] Client:["+client+"]");
			// added by Avishkar on 14.10.2019 starts
			HttpParams httpParams = (HttpParams) client.getParams();
			httpParams.setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, timeout*1000);
			httpParams.setParameter(CoreConnectionPNames.SO_TIMEOUT, timeout*1000);
			httpParams.setParameter(ClientPNames.CONN_MANAGER_TIMEOUT, new Long(timeout*1000));
			// added by Avishkar on 14.10.2019 ends
			
			post = new PostMethod(url);
			logger.debug(">>>msisdn["+dataObject.o_msisdn+"] post before hit :["+post+"]");
			responseXml = new StringBuffer();
			
			post.setRequestHeader("Content-Type","text/xml");
			post.setRequestHeader("Accept","text/xml");
			post.setRequestHeader("Except","100-continue");
			
			System.out.println("XML["+xmlString+"]");
			RequestEntity entity = new StringRequestEntity(xmlString, "text/xml", null);
			post.setRequestEntity(entity);

			System.out.println("\nSending 'POST' request to URL : " + url);
			logger.info("\n>>>msisdn["+dataObject.o_msisdn+"]  Sending 'POST' "+req+" request to URL : " + url); // added by Avishkar on 27.01.2020

			int returnCode = client.executeMethod(post);
			logger.info(">>>msisdn["+dataObject.o_msisdn+"] "+req+" post hit returnCode:["+returnCode+"]"); // added by Avishkar on 27.01.2020
			if(returnCode == HttpStatus.SC_NOT_IMPLEMENTED) {
				System.err.println("The Post post is not implemented by this URI");
				post.getResponseBodyAsString();
			} else {
				br = new BufferedReader(new InputStreamReader(post.getResponseBodyAsStream()));
				String readLine;
				while(((readLine = br.readLine()) != null)) {
					System.err.println(readLine);
					responseXml.append(readLine);
				}
			}
			logger.debug(">>>msisdn["+dataObject.o_msisdn+"] post after execute hit :["+post+"]");
		} catch (Exception e) {
			logger.error("Exception in sendPost method of PostCharging : ",e);
			e.printStackTrace(); 
			System.err.println(e);
		} finally {
			// modification start by Avishkar on 27.01.2020
			logger.debug(">>>msisdn["+dataObject.o_msisdn+"] post in finally block :["+post+"]");
			if (post!=null) {
				try {
					post.releaseConnection();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
			// modification end by Avishkar on 27.01.2020
//			post.releaseConnection();
			if(br != null) try { br.close(); } catch (Exception fe) { fe.printStackTrace();}
		}

		return responseXml.toString();
	}
*/
	
	
	private String getBalanceXML(String msisdn)
	{
		String xmlString="";
		xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+ 
			"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/"+
			"envelope/\" xmlns:ars=\"http://www.huawei.com/bme/cbsinterface/"+
			"arservices\" xmlns:cbs=\"http://www.huawei.com/bme/cbsinterface/"+
			"cbscommon\" xmlns:arc=\"http://cbs.huawei.com/ar/wsservice/arcommon\">"+
			"<soapenv:Header/>"+ 
			"<soapenv:Body><ars:QueryBalanceRequestMsg><RequestHeader>"+
			"<cbs:Version>1</cbs:Version>"+ 
			"<cbs:BusinessCode>1</cbs:BusinessCode>"+
			"<cbs:MessageSeq>1</cbs:MessageSeq>"+ 
			"<cbs:OwnershipInfo>"+ 
			"<cbs:BEID>101</cbs:BEID>"+ 
			"</cbs:OwnershipInfo>"+ 
			"<cbs:AccessSecurity>"+ 
			"<cbs:LoginSystemCode>"+username+"</cbs:LoginSystemCode>"+
			"<cbs:Password>"+passwd+"</cbs:Password>"+
			"</cbs:AccessSecurity>"+ 
			"</RequestHeader>"+ 
			"<QueryBalanceRequest>"+
			"<ars:QueryObj>"+
			"<ars:SubAccessCode>"+ 
			"<arc:PrimaryIdentity>"+msisdn+"</arc:PrimaryIdentity>"+ 
			"</ars:SubAccessCode>"+      
			"</ars:QueryObj>"+ 
			"<ars:BalanceType/>"+
			"</QueryBalanceRequest>"+ 
			"</ars:QueryBalanceRequestMsg>"+ 
			"</soapenv:Body>"+ 
			"</soapenv:Envelope>";		

		return xmlString;	


	}
	//private String getdeductionXML(String msisdn,int amount,int rbt , String key , Data_Object dataObject) // commented by Avishkar on 07.01.2020
	private String getdeductionXML(String msisdn,int amount,int rbt , Data_Object dataObject) // modified by Avishkar on 07.01.2020
	{
		
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyyhhmmss");
		String transId=dateFormat.format(date);
		if(rbt == -1)
		{
		   rbt = 0;
		}
		// Logic to fix rbtCode length to 6 digits created by Harjinder on 12/06/2017  //
		String rbtCodeLength = new String();
		rbtCodeLength = rbt+"";
		String tempRbtCode = "";
			
		if(rbtCodeLength.length() == 5){
		    tempRbtCode = "0";	
			
		}
		else if(rbtCodeLength.length() == 4){
		    tempRbtCode = "00";		
		}
		else if(rbtCodeLength.length() == 3){
		    tempRbtCode = "000";		
		}
		else if(rbtCodeLength.length() == 2){
		    tempRbtCode = "0000";	
		}
		else if(rbtCodeLength.length() == 1){
		    tempRbtCode = "00000";		
		}

		// End by Harjinder  //
		tempRbtCode+=rbtCodeLength;	
			

		String transid = "NA";
		synchronized(this)
		{
		long t = System.nanoTime();
		String t2 =""+t;
		//transid = msisdn+""+rbt+""+ t2.substring(6,t2.length());
		// transaction Id is generated with Msisdn , rbtCode with Six digit fix , nano seconds , date current
		transid = "TeleCrbt";	
		transid+= msisdn+""+tempRbtCode+""+transId+t2.substring(6,t2.length());
		
		}
		
					

		String xml="";
		// commented start by Avishkar on 07.01.2020
//		if(Global.reqIdCache.get(key)!=null){
//			logger.info("###>>msisdn["+msisdn+"] rbt["+rbt+"] tempRbtCode["+tempRbtCode+"] key["+key+"] reqId["+Global.reqIdCache.get(key)+"] alreday under process...");
//		xml = "NA";
//
//		}
//		else{
		      //logger.info("###>>msisdn["+msisdn+"] rbt["+rbt+"] tempRbtCode["+tempRbtCode+"] key["+key+"] transid["+transid+"]");
		// commented end by Avishkar on 07.01.2020
		      logger.info("###>>msisdn["+msisdn+"] rbt["+rbt+"] tempRbtCode["+tempRbtCode+"] transid["+transid+"]");
		     //Global.reqIdCache.put(key , transid);	
		      	
			xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
			"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:bcs=\"http://www.huawei.com/"+
			"bme/cbsinterface/bcservices\" xmlns:cbs=\"http://www.huawei.com/bme/cbsinterface/cbscommon\" xmlns:bcc="+
			"\"http://www.huawei.com/bme/cbsinterface/bccommon\">"+
			"<soapenv:Header/>"+ 
			"<soapenv:Body>"+ 
			"<bcs:FeeDeductionRequestMsg>"+ 
			"<RequestHeader>"+ 
			"<cbs:Version>1</cbs:Version>"+ 
			"<cbs:BusinessCode>FeeDeduction</cbs:BusinessCode>"+ 
			//"<cbs:MessageSeq>TeleCrbt"+transid+"</cbs:MessageSeq>"+ 
			"<cbs:MessageSeq>"+transid+"</cbs:MessageSeq>"+ 
			"<cbs:OwnershipInfo>"+ 
			"<cbs:BEID>101</cbs:BEID>"+                
			"</cbs:OwnershipInfo>"+ 
			"<cbs:AccessSecurity>"+ 
			"<cbs:LoginSystemCode>"+username+"</cbs:LoginSystemCode>"+ 
			"<cbs:Password>"+passwd+"</cbs:Password>"+              
			"</cbs:AccessSecurity>"+ 
			"<cbs:OperatorInfo>"+ 
			//"<cbs:OperatorID>10097</cbs:OperatorID>"+
			"<cbs:OperatorID>326</cbs:OperatorID>"+
			"</cbs:OperatorInfo>"+
			"</RequestHeader>"+
			"<FeeDeductionRequest>"+ 
			"<bcs:DeductSerialNo>"+transid+"</bcs:DeductSerialNo>"+ 
			"<bcs:DeductObj>"+ 
			"<bcs:SubAccessCode>"+ 
			"<bcc:PrimaryIdentity>"+msisdn+"</bcc:PrimaryIdentity>"+ 
			"</bcs:SubAccessCode>"+                             
			"</bcs:DeductObj>"+          
			"<bcs:DeductInfo>"+ 
			"<bcs:ChargeCode>C_FEE_DEDUCTION_CHARGE_CODE</bcs:ChargeCode>"+                
			"<bcs:ChargeAmt>"+amount+"0000</bcs:ChargeAmt>"+                           
			"<bcs:CurrencyID>1049</bcs:CurrencyID>"+               
			"</bcs:DeductInfo>"+            
			"</FeeDeductionRequest>"+ 
			"</bcs:FeeDeductionRequestMsg>"+ 
			"<bcs:AdditionalProperty>"+
			"<bcc:Code>C_REMARKS</bcc:Code>"+
			"<bcc:Value>CRBT</bcc:Value>"+
			"</bcs:AdditionalProperty>"+
			"</soapenv:Body>"+ 
			"</soapenv:Envelope>";
			
		//}
		//dataObject.transId = transid; // commented by Avishkar on 07.01.2020
		dataObject.setTransId(transid); // added by Avishkar on 07.01.2020
		
		//xml = "DO_FURTHER_ACTION"; //For Testing
		return xml;
	}

	private  int  parseXML(String msisdn,String xmlString,String checkList) {
		int result = -1;
		try {
			XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
			byte[] byteArray = xmlString.getBytes("UTF-8");	
			ByteArrayInputStream inputStream = new ByteArrayInputStream(byteArray);
			XMLInputFactory inputFactory = XMLInputFactory.newInstance();
			XMLEventReader xmlEventReader = xmlInputFactory.createXMLEventReader(inputStream);
			int checkForAi=0;
			String resp = null;
			String status = ""; // added by Avishkar on 08.01.2020
			while(xmlEventReader.hasNext()){

				XMLEvent xmlEvent = xmlEventReader.nextEvent();
				XMLEvent  event2 = null;
				if (xmlEvent.isStartElement()){
					StartElement startElement = xmlEvent.asStartElement();
					//      System.out.println("Xml Tag is: "+startElement.getName());
					//      System.out.println("Local Tag is: "+startElement.getName().getLocalPart());

					if(checkList.equalsIgnoreCase("debit") || checkList.equalsIgnoreCase("checkBalance"))
					{

						if(startElement.getName().getLocalPart().equals("ResultCode"))
						{
							event2 = xmlEventReader.nextEvent();
							if (event2 instanceof Characters) {
								resp = event2.asCharacters().getData();

								result = Integer.parseInt(resp);
								if(result != 0)
								{
									status = "FAIL"; // added by Avishkar on 08.01.2020
									// added start by Avishkar on 08.01.2020
									if( Global.RESPONSE_FILE_WRITER == 1 ) /** If it is configured to write response in file.  */
									{
										/**  writing in  logs/ResponseLogs/ResponseLog */
										synchronized(Global.flw_ResponseWriter) 
										{
											Global.flw_ResponseWriter.writeLog(">>>msisdn :["+msisdn+"] "+checkList+" response :["+result+"] status :["+status+"]"); //Global.getCurrentTime()+resultString);
										}
									}
									// added end by Avishkar on 08.01.2020
									
									result = -1;
									
								}
								logger.info("###>msisdn["+msisdn+"] ResultCode Is["+result+"]");
								
								

							}

						}
					}
					if(result == 0 && checkList.equalsIgnoreCase("checkBalance"))
					{
						int responseResult = result; // added by Avishkar on 09.01.2020
						if(startElement.getName().getLocalPart().equals("BalanceType")){
							event2 = xmlEventReader.nextEvent();
							resp = event2.asCharacters().getData();
							if(resp.equalsIgnoreCase("C_MAIN_ACCOUNT"))
							{
								while(xmlEventReader.hasNext())
								{
									event2 = xmlEventReader.nextEvent();
								if (event2 instanceof Characters) {
										resp = event2.asCharacters().getData();

									}
									if(resp.equalsIgnoreCase("PPS_MainAccount"))
									{
										logger.info("##>>msisdn["+msisdn+"] Event PPS_MainAccount Found ...");

										event2 = xmlEventReader.nextEvent();
										if (event2 instanceof Characters) {
											resp = event2.asCharacters().getData();
											logger.info("##>>msisdn["+msisdn+"] Total Balance Is["+resp+"]");
											result = Integer.parseInt(resp);
											status = "SUCCESS"; // added by Avishkar on 09.01.2020
											if(result!=0)
												result=result/10000;
											
											// added start by Avishkar on 08.01.2020
											if( Global.RESPONSE_FILE_WRITER == 1 ) /** If it is configured to write response in file.  */
											{
												/**  writing in  logs/ResponseLogs/ResponseLog */
												synchronized(Global.flw_ResponseWriter) 
												{
													Global.flw_ResponseWriter.writeLog(">>>msisdn :["+msisdn+"] "+checkList+" response :["+responseResult+"] balance :["+result+"] status :["+status+"]"); //Global.getCurrentTime()+resultString);
												}
											}
											// added end by Avishkar on 08.01.2020

										}
									}
								}
							}

						}
					}
					else if(result == 0 && checkList.equalsIgnoreCase("debit"))
					{
						result = 0;
						status="SUCCESS"; // added by Avishkar on 09.01.2020
						logger.info("##>>msisdn["+msisdn+"] debit method found return code ["+result+"] ");
						// added start by Avishkar on 08.01.2020
						if( Global.RESPONSE_FILE_WRITER == 1 ) /** If it is configured to write response in file.  */
						{
							/**  writing in  logs/ResponseLogs/ResponseLog */
							synchronized(Global.flw_ResponseWriter) 
							{
								Global.flw_ResponseWriter.writeLog(">>>msisdn :["+msisdn+"] "+checkList+" response :["+result+"] status :["+status+"]"); //Global.getCurrentTime()+resultString);
							}
						}
						// added end by Avishkar on 08.01.2020
						break;
					}


				}
			}



		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("##>>msisdn["+msisdn+"] Final Return value from parseXML ["+result+"]");
		return result;
	}

	public int checkBalance(String msisdn,StringBuffer balance, Data_Object dataObject) // modified by Avishkar on 27.01.2020
	{
		logger.debug("##>>msisdn["+msisdn+"] Going to Check Balance");	
		int result = -1;	
		String balanceXml = null; 	
		String responseXml = null; 	
		try
		{
			msisdn = msisdn.substring(3);
			balanceXml = getBalanceXML(msisdn);	
			logger .debug("##>>msisdn["+msisdn+"] balanceXml["+balanceXml+"]");	
			responseXml = sendPost(balanceXml,"checkBalance",dataObject); //Xml For check Balance // modified by Avishkar on 27.01.2020
			logger .debug("##>>msisdn["+msisdn+"] responseXml["+responseXml+"]");
			if(responseXml!=null && responseXml.length()>0)
			{
				result = parseXML(msisdn ,responseXml , "checkBalance" );

			}
			else
			{
				result = -1;
			}
			balance.append(result);


		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		logger .info("##>>msisdn["+msisdn+"] response from checkBalance["+result+"]");
		return result;

	}

	//public int debitBalance(String msisdn,String camount , int rbt ,String key,Data_Object dataObject) // commented by Avishkar on 07.01.2020
	public int debitBalance(String msisdn,String camount , int rbt ,Data_Object dataObject) // modified by Avishkar on 07.01.2020
	{
		//logger .debug("##>>msisdn["+msisdn+"] Going to debitBalance for amount["+camount+"] rbt["+rbt+"] key["+key+"]"); // commented by Avishkar on 07.01.2020
		logger .debug("##>>msisdn["+msisdn+"] Going to debitBalance for amount["+camount+"] rbt["+rbt+"]"); // modified by Avishkar on 07.01.2020
		int result = -1;
		String debitXml = null;
		String responseXml = null;
		String _msisdn = "";	
		int amount = -1;	
		try
		{
			_msisdn = msisdn.substring(3);
			//amount = Integer.parseInt(camount); // commented by Avishkar on 23.01.2020
			double amt = Double.parseDouble(camount); // added by Avishkar on 23.01.2020
			amount = (int) amt; // added by Avishkar on 23.01.2020
			
			//debitXml = getdeductionXML(_msisdn,amount,rbt , key,dataObject); // commented by Avishkar on 07.01.2020
			debitXml = getdeductionXML(_msisdn,amount,rbt,dataObject); // modified by Avishkar on 07.01.2020
			if(!debitXml.equalsIgnoreCase("NA")){

			/*if(debitXml.equalsIgnoreCase("DO_FURTHER_ACTION")){
			  logger.info("##>>msisdn["+msisdn+"] DO_FURTHER_ACTION");
			 return 1;
			}*/
			logger .debug("##>>msisdn["+msisdn+"] debitXml["+debitXml+"]"); 
			responseXml = sendPost(debitXml,"debit",dataObject); //Xml For debit Balance // modified by Avishkar on 27.01.2020
			logger .debug("##>>msisdn["+msisdn+"] responseXml["+responseXml+"]");	
			if(responseXml!=null  && responseXml.length()>0)
			{	
				result = parseXML(msisdn ,responseXml , "debit" );
				if(result == 0)
				{
					result=1;
				}
				else 
				{
					result= -1;
				}
			}
			else
				result = -1;
			}
			else
			{
			return -1;
			}
	

		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		logger.info("##>>msisdn["+msisdn+"] response from debitBalance["+result+"]");
		return result;

	}


}

