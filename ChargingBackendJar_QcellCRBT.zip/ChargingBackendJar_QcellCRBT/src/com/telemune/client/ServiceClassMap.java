package com.telemune.client;

class ServiceClassMap
{

    public int  st_class;
    public int  ed_class;
    public int rate_plan;
    public int getstmsisdn()
    {
        return st_class;
    }
    public int getedmsisdn()
    {
        return ed_class;
    }
    public int getrateplan()
    {
        return rate_plan;
    }
}

