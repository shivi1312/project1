/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.telemune.client;

/**
 *
 * @author Ashu
 */
public class TestArea implements Runnable{

    /**
     * @param args the command line arguments
     */
public void run ()
{}

    public static void main(String[] args) {
        // TODO code application logic here
         String strStartFlag="`SC`"; //4 bytes

String strMsgHeader=""; //28 bytes

String  hdVrsnNo="1.00"; //4 bytes
String hdTrmnlId="MD"; //8 bytes
String hdSrvcName="SRVM"; //8 bytes
String hdLangType=""; //8 bytes
String strSsnHeader=""; //18 bytes
String ssnId="1";//8 bytes
String ssnCtrlChar="DLGLGN";//6 bytes
String ssnRsrvdFld="0000";//4 bytes
String strTxnHeader=""; //18 bytes
String txnId="1";//8 bytes
String txnCtrlChar="TXBEG";//6 bytes
//static String txnRsrvdFld="00";//4 bytes
String txnRsrvdFld="0000";//4 bytes
int msgLenth=0;
String strMsgLength=""; //4 bytes
String strOprInfo="LOGIN:USER=telemune,PSWD=savy2288"; //upto 64kb
String strChkSum=""; //8 bytes
String inCommand="";
Thread t=null;
Thread temp=new Thread();
try
{
        MMLCommandGen mmlCm=new MMLCommandGen();
        mmlCm.setHdSrvcName(hdSrvcName);
        mmlCm.setHdVrsnNo(hdVrsnNo);
        mmlCm.setSsnId(ssnId);
        mmlCm.setSsnCtrlChar(ssnCtrlChar);
        mmlCm.setHdTrmnlId(hdTrmnlId);
        mmlCm.setSsnRsrvdFld(txnRsrvdFld);
        mmlCm.setStrMsgHeader(hdSrvcName);
        mmlCm.setHdLangType(hdLangType);
        mmlCm.setTxnId(txnId);
        
        mmlCm.setStrTxnHeader(txnId, txnCtrlChar, txnRsrvdFld);
        mmlCm.setStrSsnHeader(ssnId, ssnCtrlChar);
        mmlCm.setStrOprInfo(strOprInfo);
        mmlCm.setMsgLenth();
        
        mmlCm.setStrChkSum();
        mmlCm.setStrMsgLength();
        mmlCm.setInCommand();
        mmlCm.setSocketConnection();
        
        
/*       	t=new Thread(mmlCm);
	t.start(); 
	temp.sleep(100);
*/
        System.out.println(mmlCm.getMsgLenth());
        System.out.println(mmlCm.getInCommand());
        mmlCm.socketWriter();
      System.out.println(mmlCm.socketReader());
       strOprInfo="DISP PPS ACNTINFO:MSISDN=3023604";
        ssnCtrlChar="DLGCON";
        hdSrvcName="PPS";
        mmlCm.setHdSrvcName(hdSrvcName);
        mmlCm.setHdVrsnNo(hdVrsnNo);
        mmlCm.setSsnId(ssnId);
        mmlCm.setSsnCtrlChar(ssnCtrlChar);
        mmlCm.setHdTrmnlId(hdTrmnlId);
        mmlCm.setSsnRsrvdFld(txnRsrvdFld);
        mmlCm.setStrMsgHeader(hdSrvcName);
        mmlCm.setHdLangType(hdLangType);
        mmlCm.setTxnId(txnId+1);
        
        mmlCm.setStrTxnHeader(txnId, txnCtrlChar, txnRsrvdFld);
        mmlCm.setStrSsnHeader(ssnId, ssnCtrlChar);
        mmlCm.setStrOprInfo(strOprInfo);
        mmlCm.setMsgLenth();
        
        mmlCm.setStrChkSum();
        mmlCm.setStrMsgLength();
        mmlCm.setInCommand();
        
        System.out.println(mmlCm.getMsgLenth()+"===="+mmlCm.getStrMsgLength());
        System.out.println(mmlCm.getInCommand());
        mmlCm.socketWriter();
        System.out.println(mmlCm.socketReader());
        
        
        
        
        strOprInfo="LOGOUT:";
        ssnCtrlChar="DLGCON";
        hdSrvcName="SRVM";
        mmlCm.setHdSrvcName(hdSrvcName);
        mmlCm.setHdVrsnNo(hdVrsnNo);
        mmlCm.setSsnId(ssnId);
        mmlCm.setSsnCtrlChar(ssnCtrlChar);
        mmlCm.setHdTrmnlId(hdTrmnlId);
        mmlCm.setSsnRsrvdFld(txnRsrvdFld);
        mmlCm.setStrMsgHeader(hdSrvcName);
        mmlCm.setHdLangType(hdLangType);
        mmlCm.setTxnId(txnId+1);
        
        mmlCm.setStrTxnHeader(txnId, txnCtrlChar, txnRsrvdFld);
        mmlCm.setStrSsnHeader(ssnId, ssnCtrlChar);
        mmlCm.setStrOprInfo(strOprInfo);
        mmlCm.setMsgLenth();
        
        mmlCm.setStrChkSum();
        mmlCm.setStrMsgLength();
        mmlCm.setInCommand();
        
        System.out.println(mmlCm.getMsgLenth()+"===="+mmlCm.getStrMsgLength());
        System.out.println(mmlCm.getInCommand());
        
        mmlCm.socketWriter();
        System.out.println(mmlCm.socketReader());
        
        //LOGOUT:
        
}
catch(Exception e)
{
    e.printStackTrace();
}
        //`SC`005c1.00MD      SRVM    00000001DLGLGN000000000001TXBEG 0000LOGIN:USER=telemune,PSWD=savy2288   EA96E692
    }
    
}
