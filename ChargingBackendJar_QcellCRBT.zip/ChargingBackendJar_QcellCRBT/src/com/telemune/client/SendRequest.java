package com.telemune.client;

import java.util.Random;

import org.apache.log4j.Logger;


/**
 *  *
 *   * @author Priyanka
 *    */


public class SendRequest {

	String strStartFlag="`SC`"; //4 bytes

	String strMsgHeader=""; //28 bytes

	String  hdVrsnNo="1.00"; //4 bytes
	String hdTrmnlId="MD"; //8 bytes
	String hdSrvcName="SRVM"; //8 bytes
	String hdLangType=""; //8 bytes
	String strSsnHeader=""; //18 bytes
	String ssnId="1";//8 bytes
	String ssnCtrlChar="DLGLGN";//6 bytes
	String ssnRsrvdFld="0000";//4 bytes
	String strTxnHeader=""; //18 bytes
	String txnId="1";//8 bytes
	String txnCtrlChar="TXBEG";//6 bytes
	//static String txnRsrvdFld="00";//4 bytes
	String txnRsrvdFld="0000";//4 bytes
	int msgLenth=0;
	String strMsgLength=""; //4 bytes
	String strOprInfo="LOGIN:USER=telemune,PSWD=savy2288"; //upto 64kb
	String strChkSum=""; //8 bytes
	String inCommand="";
	MMLCommandGen mml =null;
	int txnIdInt=1;
	StringBuilder m_responseString =null;
	Logger logger=Logger.getLogger("SendRequest");
	public SendRequest()
	{
		mml =new MMLCommandGen();

	}

	public synchronized int checkForRequestSuccess(StringBuilder responseString,String msisdn)
	{
		int l_result=-1;
		try
		{
			logger.info("##>>"+msisdn+"Inside checkForRequestSuccess String is: ["+responseString.toString()+"]");
			String responseLogin=responseString.toString();

			if (responseLogin.indexOf("RETN") != -1)
			{
				logger.info("##>>"+msisdn+"Found RETN");
				int res=responseLogin.indexOf("RETN");

				String response=responseLogin.substring((res+5), (res+6));
				res=Integer.parseInt(response);
				logger.info("##>>"+msisdn+"Response "+response);
				l_result=res;
			}
		}catch(Exception e)
		{
			logger.error("##>>"+msisdn+"Exception Inside checkForRequestSuccess",e);

		}

		return l_result;


	}


	public synchronized int getBalance(StringBuilder responseString,String msisdn)
	{
		int l_result=-1;
		try
		{
			logger.info("##>>"+msisdn+"Inside getBalance===============================String is: ["+responseString.toString()+"]");
			String balance=responseString.toString();
			int balanceIndex=-1;
			int indexAtr=responseString.indexOf("ATTR");
			int indexResult=responseString.indexOf("RESULT");
			if(indexAtr!=-1 && indexResult!=-1)
			{
				String[] attrArray=balance.substring(indexAtr+4, indexResult).split("&");
				logger.info("Size of AttrArray "+attrArray.length);
				for(int i=0;i<attrArray.length;i++)
				{
					//logger.info("Attr Array is: "+attrArray[i]);
					if(attrArray[i].equalsIgnoreCase("BALANCE"))
					{
						logger.info("##>>"+msisdn+"Index Matched==========================For Balance"+i);
						balanceIndex=i;
					}
				}

				String[] balanceArray=balance.substring(indexResult+8, balance.length()).split("\\|");
				//for(int i=0;i<balanceArray.length;i++)
				//{
				String balanceInfo=balanceArray[balanceIndex];
				logger.info("##>>"+msisdn+"Balance From gateway is: ["+balanceInfo+"]");
				responseString.delete(0, responseString.length());
				responseString.append(balanceInfo);
				l_result=1;
				//}
			}
		}
		catch(Exception e)
		{
			logger.info("Exception Inside getBalance");
			e.printStackTrace();
		}

		return l_result;
	}



	public  synchronized int  sendReqToLogin(String userName,String password)
	{

		int l_result=-1;
                logger.info("Inside Login Request Username is: ["+userName+"] passowrd is: ["+password+"]");

		try
		{      //LOGIN:USER=telemune,PSWD=savy2288
			strOprInfo="LOGIN:USER="+userName+",PSWD="+password;
			ssnCtrlChar ="DLGLGN";
			hdSrvcName="SRVM";
			mml.setHdSrvcName(hdSrvcName);
			mml.setHdVrsnNo(hdVrsnNo);
			mml.setSsnId(ssnId);
			mml.setSsnCtrlChar(ssnCtrlChar);
			mml.setHdTrmnlId(hdTrmnlId);
			mml.setSsnRsrvdFld(txnRsrvdFld);
			mml.setStrMsgHeader(hdSrvcName);
			mml.setHdLangType(hdLangType);
			mml.setTxnId(txnId);

			mml.setStrTxnHeader(txnId, txnCtrlChar, txnRsrvdFld);
			mml.setStrSsnHeader(ssnId, ssnCtrlChar);
			mml.setStrOprInfo(strOprInfo);
			mml.setMsgLenth();

			mml.setStrChkSum();
			mml.setStrMsgLength();
			mml.setInCommand();

			logger.info("Str is: "+mml.getInCommand());

			mml.setSocketConnection();  //For Test



			logger.debug(mml.getMsgLenth());

			//String commandStr=mml.getInCommand();

			mml.socketWriter(); //For Test
			//logger.info(mml.socketReader());
			String resp=mml.socketReader();
			//String resp="`SC`01141.00      MD  ACKLGN00000001DLGCON000000000001 TXEND0000ACK:LOGIN: RETN=0,";
			m_responseString=new StringBuilder("");
			m_responseString.append(resp);
			l_result=checkForRequestSuccess(m_responseString,"Login");
			if(l_result==0)
			{
				l_result=1;
				logger.info("Login SuccessFul");
			}
			logger.info("Resp Of Login is ==============================: ["+resp+"]");



		}
		catch(Exception e)
		{
			logger.info("Exception Inside sendReqToLogin");
			e.printStackTrace();
		}
		return l_result;
	}


	public synchronized String getTxnId()
	{

		if(txnIdInt>2147483647)
		{
			txnIdInt=1;
		}
		txnIdInt++;


		logger.debug("Txn Id is: "+txnIdInt);
		return txnIdInt+"";

	}


	public synchronized int  checkBalance(String msisdn,StringBuffer setBalance)
	{
		int l_result=-1;
		try
		{
                             msisdn=msisdn.substring(3);
			logger.info("Inside checkBalance ================");	
			strOprInfo="DISP PPS ACNTINFO:MSISDN="+msisdn;
			ssnCtrlChar="DLGCON";
			hdSrvcName="PPS";
			mml.setHdSrvcName(hdSrvcName);
			mml.setHdVrsnNo(hdVrsnNo);
			mml.setSsnId(ssnId);
			mml.setSsnCtrlChar(ssnCtrlChar);
			mml.setHdTrmnlId(hdTrmnlId);
			mml.setSsnRsrvdFld(txnRsrvdFld);
			mml.setStrMsgHeader(hdSrvcName);
			mml.setHdLangType(hdLangType);
			txnId=this.getTxnId();
			mml.setTxnId(txnId);

			mml.setStrTxnHeader(txnId, txnCtrlChar, txnRsrvdFld);
			mml.setStrSsnHeader(ssnId, ssnCtrlChar);
			mml.setStrOprInfo(strOprInfo);
			mml.setMsgLenth();

			mml.setStrChkSum();
			mml.setStrMsgLength();
			mml.setInCommand();

			//logger.info(mml.getMsgLenth()+"===="+mml.getStrMsgLength());
			logger.info("##>>"+msisdn+" MMl Command is: "+mml.getInCommand());
                                /*int res= mml.readDiscardData();
                             if(res==-1)
                                {
                                        return -1;
                                }*/

			boolean sockResp=mml.socketWriter(); //For Test
			while(!sockResp)
			{
				logger.debug("##>>"+msisdn+"Socket Not Closed====");
				this.sendReqToLogin("telemune", "savy2288");
				strOprInfo="DISP PPS ACNTINFO:MSISDN="+msisdn;
				ssnCtrlChar="DLGCON";
				hdSrvcName="PPS";
				mml.setHdSrvcName(hdSrvcName);
				mml.setHdVrsnNo(hdVrsnNo);
				mml.setSsnId(ssnId);
				mml.setSsnCtrlChar(ssnCtrlChar);
				mml.setHdTrmnlId(hdTrmnlId);
				mml.setSsnRsrvdFld(txnRsrvdFld);
				mml.setStrMsgHeader(hdSrvcName);
				mml.setHdLangType(hdLangType);
				txnId=this.getTxnId();
				mml.setTxnId(txnId);

				mml.setStrTxnHeader(txnId, txnCtrlChar, txnRsrvdFld);
				mml.setStrSsnHeader(ssnId, ssnCtrlChar);
				mml.setStrOprInfo(strOprInfo);
				mml.setMsgLenth();

				mml.setStrChkSum();
				mml.setStrMsgLength();
				mml.setInCommand(); 
				 //res= mml.readDiscardData();
				/*if(res==-1)
				{
					return -1;
				}*/


				sockResp=mml.socketWriter(); //For Test
			 }
			//logger.info(mml.socketReader());

			String resp=mml.socketReader(); //For Test

			/*String resp="`SC`05C01.00      MD     ACK00000001DLGCON000000000001 TXEND0000ACK:DISP PPS ACNTINFO: RETN=0, DESC="+"Querying subscriber's"+ 

			"information succeeded.,"+ 

			"ATTR=MSISDN&ACCOUNTSTATE&TIMEENTERACTIVE&FRAUDLOCK&FRAUDTIMES&SERVICESTART&SERVICESTOP&ACTIVESTOP&SUSPENDSTOP&DISABLESTOP&BALANCE&C"+

			"REDITLIMIT&HOMEZONENO&LANGUAGETYPE&SERVICEAREA&CALLINGSCREENFLAG&CALLINGSCREENFLAG1&CALLINGSCREENFLAG2&CALLEDFLAG&MAXCOUNTTOTAL&VOL"+

			"UMEDISCOUNTFLAG&SCORE&SCORESTOPTIME&AGINGPRMFLAG&PRMSCORE&PRMSCORESTOPTIME&PRMPOINT&PRMMONEY&PRMMINUTE&PRMMINUTE2&PRMMINUTE3&PRMSM&"+

			"PRMSM2&PRMSM3&PRMVIDEOMINUTE&PRMVOLUME&PRMMMS&USAGESTOPDATE&SUBCOSID&FREECHANGETIMES&HOMEZONEFLAG&HZFREETIMES&VOICEMAIL&SUBSPID&EFF"+

			"ECTBALANCE&ICFNO&EFFECTCOSID&HZCHGTIMES&PREVIOUSBALANCE&TRANSFFLAG&LOAN&LOANPOUNDAGE&LOANFLAG&TOTALMODISUBTIMES&NEXTBILLDATE1&NEXTB"+

			"ILLDATE2&NEXTBILLDATE3&NEXTBILLDATE4&NEXTBILLDATE5&NEXTBILLDATE6&NEXTBILLDATE7&NEXTBILLDATE8&NEXTBILLDATE9&NEXTBILLDATE10&RENTFLAG&"+

			"RGETIME&UUSSDCMBACKTIMES&USAGESMSTOPDATE&USAGEVOLSTOPDATE&USAGEMMSSTOPDATE&USAGEVIDEOSTOPDATE&USERNAME&USERADDRESS&DISTRIBUTOR&CONT"+

			"RACTNO&LASTNAME&CONTACTPHONE&NEXTBILLDATE&COMMENT, RESULT="+"3023604|02|20140905125553|0|0|20140806|20240806|20150922|20160120|"+

			"20160419|2031|0|-1|1|1001|0|0|1|3|500000|0|162102|20140911|0|162102|20140911|0|5076|0|0|0|0|0|0|0|0|0|20140913|1|0|0|0|1|1|-1||0|"+

			"0|5000|1|0|0||0|||||||||||000000000000000000000000000000000000||0|20140913|20140913|20140913|20140913|username||distributor|12345";*/

			m_responseString=new StringBuilder("");
			m_responseString.append(resp);





			m_responseString=new StringBuilder("");
			m_responseString.append(resp);
			l_result=checkForRequestSuccess(m_responseString,msisdn);
			if(l_result==0)
			{
				l_result=getBalance(m_responseString,msisdn);
				if(l_result==1)
				{
					logger.info("##>>>"+msisdn+"Balance is: "+m_responseString.toString());	 
					System.out.println("##>>>"+msisdn+"Balance is: "+m_responseString.toString());	 
					setBalance.append(m_responseString.toString());
				}
				logger.info("##>>>"+msisdn+"Check Balance Result is: ["+m_responseString.toString()+"]");
				l_result=1;
			}

			logger.info("Response From check Balance is:: --------------------------["+l_result+"]");
			System.out.println("Response From check Balance is:: --------------------------["+l_result+"]");





		}
		catch(Exception e)
		{
			logger.info("Exception inside checkBalance");
			e.printStackTrace();
		}


		return l_result;

	}


	public synchronized int debitBalance(String msisdn,String balance)
	{
		int l_result=-1;
		try
		{
			//3023604
			 msisdn=msisdn.substring(3);
                          int bal=(int)Float.parseFloat(balance);
                            
			strOprInfo="CHANGE PPS BALANCE:MSISDN="+msisdn+",INCRMENT=-"+bal+",COMMENT=\"Amount debited by Telemune\"";//balance deduction
			ssnCtrlChar="DLGCON";
			hdSrvcName="PPS";
			mml.setHdSrvcName(hdSrvcName);
			mml.setHdVrsnNo(hdVrsnNo);
			mml.setSsnId(ssnId);
			mml.setSsnCtrlChar(ssnCtrlChar);
			mml.setHdTrmnlId(hdTrmnlId);
			mml.setSsnRsrvdFld(txnRsrvdFld);
			mml.setStrMsgHeader(hdSrvcName);
			mml.setHdLangType(hdLangType);
			txnId=this.getTxnId();
			mml.setTxnId(txnId);

			mml.setStrTxnHeader(txnId, txnCtrlChar, txnRsrvdFld);
			mml.setStrSsnHeader(ssnId, ssnCtrlChar);
			mml.setStrOprInfo(strOprInfo);
			mml.setMsgLenth();

			mml.setStrChkSum();
			mml.setStrMsgLength();
			mml.setInCommand();

			//logger.info(mml.getMsgLenth()+"===="+mml.getStrMsgLength());
			logger.info("##>>>"+msisdn+ " MML Command For Deduct Balance "+mml.getInCommand());

/*			int res= mml.readDiscardData();
			if(res==-1)
			{
				return -1;
			}
*/


			//mml.socketWriter(); //For Test 
			//	logger.info(mml.socketReader());
			boolean sockResp=mml.socketWriter(); //For Test
			 while(!sockResp)
			 {
				 this.sendReqToLogin("telemune", "savy2288");
				 strOprInfo="CHANGE PPS BALANCE:MSISDN="+msisdn+",INCRMENT=-"+bal+",COMMENT=\"Amount debited by Telemune\"";//balance deduction
				 ssnCtrlChar="DLGCON";
				 hdSrvcName="PPS";
				 mml.setHdSrvcName(hdSrvcName);
				 mml.setHdVrsnNo(hdVrsnNo);
				 mml.setSsnId(ssnId);
				 mml.setSsnCtrlChar(ssnCtrlChar);
				 mml.setHdTrmnlId(hdTrmnlId);
				 mml.setSsnRsrvdFld(txnRsrvdFld);
				 mml.setStrMsgHeader(hdSrvcName);
				 mml.setHdLangType(hdLangType);
				 txnId=this.getTxnId();
				 mml.setTxnId(txnId);

				 mml.setStrTxnHeader(txnId, txnCtrlChar, txnRsrvdFld);
				 mml.setStrSsnHeader(ssnId, ssnCtrlChar);
				 mml.setStrOprInfo(strOprInfo);
				 mml.setMsgLenth();

				 mml.setStrChkSum();
				 mml.setStrMsgLength();
				 mml.setInCommand();
				sockResp=mml.socketWriter(); //For Test
			 }
			String resp=mml.socketReader(); //For Test
			//String resp="`SC`00B01.00      MD     ACK00000001DLGCON000000000001 TXEND0000ACK:CHANGE PPS BALANCE: RETN=0, DESC="+"Modifying subscriber's balance succeeded."+", ORGBALANCE=10000, LASTBALANCE=9990;   E68BFCBC========192";
			
			/*if(resp.equals("ERROR"))
			{
				this.sendReqToLogin("telemune", "savy2288");
				resp=mml.socketWriter(); //For Test
			}*/
			
			
			
			m_responseString=new StringBuilder("");
			m_responseString.append(resp);
			l_result=checkForRequestSuccess(m_responseString,msisdn);
			if(l_result==0)
			{
				l_result=1;
				logger.info("##>>>"+msisdn+"Debit SuccessFul");
			}

			logger.info("##>>>"+msisdn+"Response From Debit Balance is: ["+resp+"]");
		}
		catch(Exception e)
		{
			logger.error("##>>>"+msisdn+"Exception Inside debitBalance",e);

		}
		return l_result;


	}


	public synchronized int logOut()
	{
		int l_result=-1;
		try
		{
			logger.info("Inside LogOut================================= ");

			strOprInfo="LOGOUT:";
			ssnCtrlChar="DLGCON";
			hdSrvcName="SRVM";
			mml.setHdSrvcName(hdSrvcName);
			mml.setHdVrsnNo(hdVrsnNo);
			mml.setSsnId(ssnId);
			mml.setSsnCtrlChar(ssnCtrlChar);
			mml.setHdTrmnlId(hdTrmnlId);
			mml.setSsnRsrvdFld(txnRsrvdFld);
			mml.setStrMsgHeader(hdSrvcName);
			mml.setHdLangType(hdLangType);
			txnId=this.getTxnId();
			mml.setTxnId(txnId);

			mml.setStrTxnHeader(txnId, txnCtrlChar, txnRsrvdFld);
			mml.setStrSsnHeader(ssnId, ssnCtrlChar);
			mml.setStrOprInfo(strOprInfo);
			mml.setMsgLenth();

			mml.setStrChkSum();
			mml.setStrMsgLength();
			mml.setInCommand();


			logger.info(mml.getInCommand());

			mml.socketWriter();
			//logger.info(mml.socketReader());
			String resp=mml.socketReader();
			logger.info("Reading Socket"+resp);
			m_responseString=new StringBuilder("");
			m_responseString.append(resp);
			l_result=checkForRequestSuccess(m_responseString,"Logout");
			if(l_result==0)
			{
				l_result=1;
				logger.info("Logout  SuccessFul");
			}

		}
		catch(Exception e)
		{
			logger.error("Exception Inside logOut",e);

		}
		return l_result;


	}



	public static void main(String args[])
	{
		SendRequest sq=new SendRequest();
		sq.sendReqToLogin("telemune","savy2288");
StringBuffer sqb=new StringBuffer();
		sq.checkBalance(args[0],sqb);
		sq.getTxnId();

	}

}

