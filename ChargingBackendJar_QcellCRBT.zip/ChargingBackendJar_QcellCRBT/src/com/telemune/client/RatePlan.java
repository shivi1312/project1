
package com.telemune.client;
class RatePlan
{

	public int plan_id;
	public int rbt_charge_code;
	public int gift_charge_code;
	public int subscription_charge_code;
	public int monthly_rent_code;
	public int three_week_rent_code;
	public int two_week_rent_code;
	public int one_week_rent_code;
	public int record_charge_code;
	private int oneDayGiftCode;
	private int oneWeekGiftCode;
	private int twoWeekGiftCode;
	private int threeWeekGiftCode;

	public int monthly_rbt_charge_code;
	public int one_week_rbt_charge_code;
	public int two_week_rbt_charge_code;
	public int three_week_rbt_charge_code;
	public int one_day_rbt_charge_code;

	public int getOneDayGiftCode(){return oneDayGiftCode;}
	public int getOneWeekGiftCode(){return oneWeekGiftCode;}
	public int getTwoWeekGiftCode(){return twoWeekGiftCode;}
	public int getThreeWeekGiftCode(){return threeWeekGiftCode;}

 	public void setOneDayGiftCode(int oneDayGiftCode){this.oneDayGiftCode=oneDayGiftCode;}
  public void setOneWeekGiftCode(int oneWeekGiftCode){this.oneWeekGiftCode=oneWeekGiftCode;}
  public void setTwoWeekGiftCode(int twoWeekGiftCode){this.twoWeekGiftCode=twoWeekGiftCode;}
  public void setThreeWeekGiftCode(int threeWeekGiftCode){this.threeWeekGiftCode=threeWeekGiftCode;}
	



	public int get_monthly_rbt_charge_code()
	{
		return monthly_rbt_charge_code;
	}
	public int get_one_week_rbt_charge_code()
	{

		return one_week_rbt_charge_code;
	}
	public int get_two_week_rbt_charge_code()
	{

		return two_week_rbt_charge_code;
	}
	public int get_three_week_rbt_charge_code()
	{

		return three_week_rbt_charge_code;
	}
	public int get_one_day_rbt_charge_code()
	{

		return one_day_rbt_charge_code;
	}
	public int get_planid()
	{
		return plan_id;
	}
	public int get_rbt_charge_code()
	{
		return rbt_charge_code;
	}
	public int get_gift_charge_code()
	{
		return gift_charge_code;
	}
	public int get_subscription_charge_code()
	{
		return subscription_charge_code;
	}
	public int get_monthly_sub_code()
	{
		return monthly_rent_code;
	}
	public int get_three_week_code()
	{
		return three_week_rent_code;
	}
	public int get_two_week_code()
	{
		return two_week_rent_code;
	}
	public int get_one_week_code()
	{
		return one_week_rent_code;
	}
	public int get_record_charge_code()
	{
		return record_charge_code;
	}
}

