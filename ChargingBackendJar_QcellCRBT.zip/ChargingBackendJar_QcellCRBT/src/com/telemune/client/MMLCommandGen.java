

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//package com.telemune;

package com.telemune.client;
import java.net.SocketException;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.Socket;
import java.io.*;
import java.net.UnknownHostException;

public class MMLCommandGen implements Runnable{

	Socket inSocket = null;

	BufferedOutputStream out1 = null;
	BufferedReader in = null;
	String strStartFlag="`SC`"; //4 bytes
	Thread temp=null;
	String strMsgHeader=""; //28 bytes

	String hdVrsnNo=""; //4 bytes
	String hdTrmnlId=""; //8 bytes
	String hdSrvcName=""; //8 bytes
	String hdLangType=""; //8 bytes

	String strSsnHeader=""; //18 bytes

	String ssnId="";//8 bytes
	String ssnCtrlChar="";//6 bytes
	String ssnRsrvdFld="";//4 bytes

	String strTxnHeader=""; //18 bytes

	String txnId="1";//8 bytes
	String txnCtrlChar="";//6 bytes

	String txnRsrvdFld="";//4 bytes

	int msgLenth=0;
	String strMsgLength=""; //4 bytes


	String strOprInfo="DISP PPS ACNTINFO:MSISDN=0000000000"; //upto 64kb

	String strChkSum=""; //8 bytes

	String inCommand="";

	public String getHdLangType() {
		return hdLangType;
	}

	public  void setHdLangType(String LangType) {
		int hdLangTypeLnth=LangType.length();
		for (int i=0;i<8-hdLangTypeLnth; i++){
			LangType=LangType+" ";
		}
		hdLangType = LangType;
	}

	public String getHdSrvcName() {
		return hdSrvcName;
	}

	public void setHdSrvcName(String hdSrvcName) {
		int hdSrvcNameLnth=hdSrvcName.length();
		for (int i=0;i<8-hdSrvcNameLnth; i++){
			hdSrvcName=hdSrvcName+" ";

		}
		this.hdSrvcName = hdSrvcName;
	}

	public String getHdTrmnlId() {
		return hdTrmnlId;
	}

	public void setHdTrmnlId(String hdTmnlId) {
		int hdTrmnlIdLnth=hdTmnlId.length();
		for (int i=0;i<8-hdTrmnlIdLnth; i++){
			hdTmnlId=hdTmnlId+" ";
		}
		this.hdTrmnlId = hdTmnlId;
	}

	public String getHdVrsnNo() {
		return hdVrsnNo;
	}

	public void setHdVrsnNo(String hdVrsnNo) {
		this.hdVrsnNo = hdVrsnNo;
	}

	public String getStrMsgHeader() {
		return strMsgHeader;
	}

	public void setStrMsgHeader(String hdSrvcName) {
		setHdSrvcName(hdSrvcName);
		this.strMsgHeader =hdVrsnNo+hdTrmnlId+this.hdSrvcName;
	}

	public String getSsnCtrlChar() {
		return ssnCtrlChar;
	}

	public void setSsnCtrlChar(String ssnCtrlChar) {
		int ssnCtrlCharLnth=ssnCtrlChar.length();
		for (int i=0;i<6-ssnCtrlCharLnth; i++){
			ssnCtrlChar=ssnCtrlChar+" ";
		}
		this.ssnCtrlChar = ssnCtrlChar;
	}

	public String getSsnId() {
		return ssnId;
	}

	public void setSsnId(String ssnId) {
		int ssnIdLnth=ssnId.length();
		for (int i=0;i<8-ssnIdLnth; i++){//=(8-)
			ssnId="0"+ssnId;
		}
		this.ssnId = ssnId;
	}

	public String getSsnRsrvdFld() {
		return ssnRsrvdFld;
	}

	public void setSsnRsrvdFld(String rsrvdFld) {
		int ssnRsrvdFldLnth=rsrvdFld.length();
		for (int i=0;i<4-ssnRsrvdFldLnth; i++){
			rsrvdFld="0"+rsrvdFld;
		}
		ssnRsrvdFld = rsrvdFld;
	}

	public String getStrSsnHeader() {
		return strSsnHeader;
	}

	public void setStrSsnHeader(String ssnId,String ssnCtrlChar) {
		setSsnId(ssnId);
		setSsnCtrlChar(ssnCtrlChar);
		this.strSsnHeader=this.ssnId+this.ssnCtrlChar+ssnRsrvdFld;
	}

	public String getStrTxnHeader() {
		return strTxnHeader;
	}

	public void setStrTxnHeader(String txnId,String txnCtrlChar,String txnRsrvdFld) {
		setTxnId(txnId);
		setTxnCtrlChar(txnCtrlChar);
		setTxnRsrvdFld(txnRsrvdFld);
		this.strTxnHeader =this.txnId+this.txnCtrlChar+this.txnRsrvdFld;
	}

	public String getTxnCtrlChar() {
		return txnCtrlChar;
	}

	public void setTxnCtrlChar(String txnCtrlChar) {
		int txnCtrlCharLnth=txnCtrlChar.length();
		for (int i=0;i<6-txnCtrlCharLnth; i++){
			txnCtrlChar=txnCtrlChar+" ";
		}
		this.txnCtrlChar = txnCtrlChar;
	}

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		int txnIdLnth=txnId.length();
		for (int i=0;i<8-txnIdLnth; i++){
			txnId="0"+txnId;
		}
		this.txnId = txnId;
	}

	public String getTxnRsrvdFld() {
		return txnRsrvdFld;
	}

	public void setTxnRsrvdFld(String tRsrvdFld) {
		int txnRsrvdFldLnth=tRsrvdFld.length();
		for (int i=0;i<4-txnRsrvdFldLnth; i++){
			tRsrvdFld="0"+tRsrvdFld;
		}
		txnRsrvdFld = tRsrvdFld;
	}

	public int getMsgLenth() {
		return msgLenth;
	}

	public void setMsgLenth(int msgLenth) {
		this.msgLenth = strMsgHeader.length()+strSsnHeader.length()+strTxnHeader.length()+strOprInfo.length();
	}
	public void setMsgLenth() {
		this.msgLenth = strMsgHeader.length()+strSsnHeader.length()+strTxnHeader.length()+strOprInfo.length();
	}
	public String getStrOprInfo() {
		return strOprInfo;
	}

	public void setStrOprInfo(String strOprInfo) {
		int strOprInfoLnth=strOprInfo.length()%4;
		System.out.println("======="+strOprInfoLnth+"==========");
		if(strOprInfoLnth>0)
		{
			for (int i=0;i<4-strOprInfoLnth; i++)
			{
				strOprInfo=strOprInfo+" ";
			}
		}
		this.strOprInfo = strOprInfo;
		System.out.println("======="+strOprInfoLnth+"=========="+strOprInfo+"====");
	}

	public String getStrMsgLength() {
		return strMsgLength;
	}

	public void setStrMsgLength() {
		msgLenth = strMsgHeader.length()+strSsnHeader.length()+strTxnHeader.length()+strOprInfo.length();
		this.strMsgLength = Integer.toHexString(0x10000|msgLenth).substring(1).toUpperCase();
	}

	public String getStrChkSum() {
		return strChkSum;
	}

	public void setStrChkSum() {

		StringBuffer chkSumSb = new StringBuffer(strMsgHeader+strSsnHeader+strTxnHeader+strOprInfo);

		char []res=new char[4];

		for (int j = 0; j < res.length; j++) {
			for (int i = j; i < chkSumSb.length(); i = i + 4) {
				res[j] = (char) (res[j] ^ chkSumSb.charAt(i));
			}
			res[j] = (char) ((~res[j]) & 0x00ff);
		}

		strChkSum="";

		for(int i =0;i<4;i++){
			strChkSum=strChkSum+Integer.toHexString((int)res[i]);
		}
		this.strChkSum=strChkSum.toUpperCase();
	}

	public String getInCommand() {
		return inCommand;
	}

	public void setInCommand() {
		System.out.println("Command==="+strStartFlag+strMsgLength+strMsgHeader+strSsnHeader+strTxnHeader+strOprInfo+strChkSum);
		this.inCommand = strStartFlag+strMsgLength+strMsgHeader+strSsnHeader+strTxnHeader+strOprInfo+strChkSum;
	}

	public void setInCommand(String cmd) {
		this.inCommand = cmd;
	}
	public void setSocketConnection()throws UnknownHostException,IOException{
		System.out.println("Connection ");
              inSocket=null;
		inSocket = new Socket("10.223.4.150",29999);
		System.out.println("Connection Establish on socket "+inSocket);


	}

	public boolean socketWriter(String command)throws IOException{

		boolean l_result=false;		

		if(inSocket.isConnected())
		{
			l_result=true;
			out1 = new BufferedOutputStream(inSocket.getOutputStream());

			OutputStreamWriter out = new OutputStreamWriter(out1, "US-ASCII");
			out.write(getInCommand());

		}
		return l_result;

	}





	public boolean socketWriter()throws IOException{
		System.out.println("Write Dataa==="+inSocket+" Command ===="+getInCommand());
		boolean l_result=false;		
		try{
			if(inSocket.isConnected())
			{

			  System.out.println("Is Connected===================");   
				l_result=true;
				OutputStream outToServer = inSocket.getOutputStream();
				DataOutputStream out =new DataOutputStream(outToServer);
				out.writeUTF(this.getInCommand());
			}}
		catch(SocketException sock)
		{
			System.out.println("Exception Inside socketWriter");
			sock.printStackTrace();
			l_result=false;
		}

		return l_result;

	}
	public void run()
	{
		try
		{
			temp=new Thread();
			while(true)
			{
				socketReader();	
				temp.sleep(10);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}






/*	public int readDiscardData()
	{
		int l_result=-1;
		try
		{

			
			int ascii=-1;
			char b[]=new char[25];


			int s=0;
		         in=null;	
               
			for(int t=0;t<2;t++)
			{
                            System.out.println("Counter ================"+t);
                                        b[]=new char[25];
				in = new BufferedReader(new InputStreamReader(inSocket.getInputStream()));
				int i=in.read(b,0,25);
				s=0;
			for(int j=0;j<b.length;j++)
			{
				ascii=b[j];
				if(ascii<=127 && ascii>0)
				{  
					System.out.println("Index : "+j+" Value in Char"+b[j]+" Ascii"+ascii);
					s++;
				}
				else
				{
					if(t==2 && j==0)
					{
						System.out.println("try for second packet and data found null");
						return 1;
					}
					System.out.println("For First Packet and data not found on index "+j);
					break;
				}
				

			}
			b=null;
			in=null;
			}
			//b=null;
			//in=null;
			System.out.println("index::"+s);
			System.out.println(s-2); 
			l_result=s;

		}
		catch(NullPointerException e)
		{
			System.out.println("Error Inside readDiscardData NullPointerException");
			e.printStackTrace();
			l_result=1;


		}
		catch(Exception exp)
		{
			System.out.println("Error Inside readDiscardData");
			exp.printStackTrace();
		}
		return l_result;
	}
*/




	public String socketReader()
	{

		StringBuffer  resp=new StringBuffer("");


		try
		{
			char b[]=new char[5000];
			System.out.println("Reading data==="+inSocket);



		in = new BufferedReader(new InputStreamReader(inSocket.getInputStream()));

			if(inSocket.isConnected())
			{

				int i=in.read(b,0,8);
				String msgLen="";

				msgLen= String.valueOf(b);
				String msgLen1=msgLen.substring(4,8);
				resp.append(b);
				System.out.println("First 7 byte read : ["+msgLen1+"]"+msgLen1.length());
				int msgLength= Integer.parseInt(msgLen1+"",16);

				System.out.println("Now Message should be of length: "+msgLength);

				while (msgLength==4)
				{
					b=null;
					msgLen=null;
					msgLen1=null;
					b=new char[5000];
					i=in.read(b,0,12);
					System.out.println("Total bytes rwead "+i);
					b=null;
					msgLen=null;
					msgLen1=null;
					resp.delete(0, resp.length());
					b=new char[5000];
					i=in.read(b,0,8);
					msgLen="";
					System.out.println("now Total bytes rwead "+i);

					msgLen= String.valueOf(b);
					msgLen1=msgLen.substring(4,8);
					resp.append(b);
					System.out.println("In Loop First 7 byte read : ["+msgLen1+"]"+msgLen1.length());
					msgLength= Integer.parseInt(msgLen1+"",16);

					System.out.println("In Loop Now Message should be of length: "+msgLength);

				}

				System.out.println("Total Bytes Read : "+i);
				b=null;
				msgLen=null;
				msgLen1=null;
				while(i<msgLength)
				{
					b=new char[5000];
					int k=in.read(b,0,(msgLength+8));
					resp.append(b);
					System.out.println("Total Bytes Read : "+k+" Msg+"+resp);
					i=i+k;
					System.out.println("Total Bytes Read : "+i);
					b=null;
				}
				System.out.println("Inside SocketReader : "+resp.toString().substring(0,msgLength+8)+" Msg Length ========"+msgLength +"Total Byte Read "+i);
			}
			else
			{
				resp.delete(0, resp.length());
				resp.append("ERROR");
			}



		}
		catch(Exception e)
		{

			resp.append("ERROR");
			System.out.println("Exception In socketReader");
			e.printStackTrace();

		}
		return resp.toString();

	}


	public String socketReader1()
	{

		StringBuffer  resp=new StringBuffer("");


		try
		{
			char b[]=new char[5000];
			System.out.println("Reading data==="+inSocket);



		in = new BufferedReader(new InputStreamReader(inSocket.getInputStream()));

			if(inSocket.isConnected())
			{

				int i=in.read(b,0,8);
				String msgLen="";

				msgLen= String.valueOf(b);
				String msgstart=msgLen.substring(0,4);
			
				String msgLen1=msgLen.substring(4,8);
				resp.append(b);
				System.out.println("First 7 byte read : ["+msgLen1+"]"+msgLen1.length());
				int msgLength= Integer.parseInt(msgLen1+"",16);

				System.out.println("Now Message should be of length: "+msgLength);

				while (msgstart.equalsIgnoreCase("`SC`"))
				{
					b=null;
					msgLen=null;
					msgLen1=null;
					b=new char[5000];
					i=in.read(b,0,12);
					System.out.println("Total bytes rwead "+i);
					b=null;
					msgLen=null;
					msgLen1=null;
					b=new char[5000];
					i=in.read(b,0,8);
					msgLen="";
					System.out.println("now Total bytes rwead "+i);

					msgLen= String.valueOf(b);
					msgLen1=msgLen.substring(4,8);
					resp.append(b);
					System.out.println("In Loop First 7 byte read : ["+msgLen1+"]"+msgLen1.length());
					msgLength= Integer.parseInt(msgLen1+"",16);

					System.out.println("In Loop Now Message should be of length: "+msgLength);

				}

				System.out.println("Total Bytes Read : "+i);
				b=null;
				msgLen=null;
				msgLen1=null;
				while(i<msgLength)
				{
					b=new char[5000];
					int k=in.read(b,0,(msgLength+8));
					resp.append(b);
					System.out.println("Total Bytes Read : "+k+" Msg+"+resp);
					i=i+k;
					System.out.println("Total Bytes Read : "+i);
					b=null;
				}
				System.out.println("Inside SocketReader : "+resp.toString().substring(0,msgLength+8)+" Msg Length ========"+msgLength +"Total Byte Read "+i);
			}
			else
			{
				resp.delete(0, resp.length());
				resp.append("ERROR");
			}



		}
		catch(Exception e)
		{

			resp.append("ERROR");
			System.out.println("Exception In socketReader");
			e.printStackTrace();

		}
		return resp.toString();

	}

}

