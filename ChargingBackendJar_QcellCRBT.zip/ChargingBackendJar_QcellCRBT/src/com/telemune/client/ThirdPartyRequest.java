package com.telemune.client;

import java.util.Random;

import org.apache.log4j.Logger;

import chargingserver.Data_Object;
import chargingserver.Global;

/**
 * 
 * @author avishkar
 *	This class is the client base class which vary according to the technology used by client like Soap, Http, Diameter.
 *	This class is used to interact with the Charging Gateway according to technology used by client.
 */

public class ThirdPartyRequest {
	
private static Logger logger = Logger.getLogger("ThirdPartyRequest");
	
	//DiameterRequest diameterRequest;
	//CheckBalance checkBal;
	PostCharging postCharging;
	//SendToSecondCharging sendToSecondCharging;
	private static int chg_reqId=0;
	//private boolean isRedirect=false;
	public int timeout=10000;// 10 sec timeout
	
	public ThirdPartyRequest() {
		//this(10000);
		/*if (Global.DIAMETER_ENABLE==1 && Global.diameterRequest==null) {
			Global.diameterRequest = new DiameterRequest();
			logger.info("Diameter : "+Global.diameterRequest);
		}*/
		//checkBal = new CheckBalance();
		this(Global.gateway_request_timeout);
		postCharging = new PostCharging(Global.gateway_link1, Global.username, Global.password);
		//sendToSecondCharging = new SendToSecondCharging();
	}
	
	public ThirdPartyRequest(int timeout) {
		this.timeout=timeout*1000;
	}
	
	//Below method is added by Avishkar on 24.09.2018
	  public int deductBlnce(Data_Object data_object)
	  {
		  logger.debug(">>>msisdn:["+data_object.o_msisdn+"] Inside deductBlnce method of ThirdPartyRequest...");
//		  int response = -1;
		  int result = -1;
		  int rbt=-1;
//		  int chgcode = -1;
//		  int transactionId = getChgReqId();
//		  String status="";
		  //boolean isRedirect=false;
		  
	    try
	    {	
	    	rbt=Integer.parseInt(data_object.o_rbtcode);
	    	result = postCharging.debitBalance(data_object.o_msisdn, String.valueOf(data_object.o_camount), rbt, data_object);
	    	
	    	if(result==1)
			{
				logger.info(">>>msisdn["+data_object.o_msisdn+"] Response from debitRequest ["+result+"]");
				result=0;
			}
	    	//return 1;
	    }
	    catch(Exception exp)
	    {

	      logger.error(">>>msisdn["+data_object.o_msisdn+"] Exception inside deductBlnce method of ThirdPartyRequest...",exp);
	      System.out.println(">>>msisdn["+data_object.o_msisdn+"] Exception inside deductBlnce method of ThirdPartyRequest..."+exp);
	      exp.printStackTrace();
	      result = -1;
	    }
	    return result;
	  }	
	  
	//Below method is added by Avishkar on 24.09.2018
	    public double checkBalance(Data_Object data_object)
	    {
	    	logger.debug(">>>msisdn["+data_object.o_msisdn+" Inside checkBalance method of ThirdPartyRequest...");
	    	int result = -1;
	    	double available=-1;
	    	String status="";
	    	StringBuffer balance= new StringBuffer();
	    	//boolean isRedirect = false;
	    	try {
	    		result=postCharging.checkBalance(data_object.o_msisdn, balance,data_object);
	    		logger.info(">>>msisdn["+data_object.o_msisdn+" Balance From MMLCommandGen  is: ["+balance.toString() +"] result:["+result+"]");
//	    		String bufferValue = balance.toString(); // added by Avishkar
//	    		available = ( Double.parseDouble(bufferValue) >= 0 ) ? Double.parseDouble(bufferValue) : -1; // added by Avishkar
	    		if(balance.toString()!=null && balance.toString().length()!=0)
				{
					available=Double.parseDouble(balance.toString());
					logger.debug(">>>msisdn["+data_object.o_msisdn+" Balance :["+available+"]"); // added by Avishkar on 09.01.2020
				}
				else
				{
					available=-1;
					logger.debug(">>>msisdn["+data_object.o_msisdn+" Balance :["+available+"]"); // added by Avishkar on 09.01.2020
				}
	    	} catch (Exception e) {
			logger.error(">>>msisdn["+data_object.o_msisdn+" Exception inside checkBalance method of ThirdPartyRequest...");
			System.out.println(">>>msisdn["+data_object.o_msisdn+"] Exception inside checkBalance method of ThirdPartyRequest..."+e);
			e.printStackTrace();
	    	}
	    	
			//logger.debug(">>>msisdn["+data_object.o_msisdn+" return user response from MML is:"+result);
			//data_object.res_data=result+"";
			return available;

	    }
	    
	    public int refundBlnce(Data_Object data_object){
			logger.info(">>>msisdn["+data_object.o_msisdn+"] Inside refundBlnce method...");
			int result = -1;
			
			
			return result;  //not required
		}
	    
		//below method is added to generate requestId for debit request by Avishkar on 24.09.2018
	    public synchronized int getChgReqId()
	    {
	    	if (chg_reqId==999999999) {
	            chg_reqId=0;
	    	}
	                            
	        return ++chg_reqId;
	    }
	    
	    /**
	     * @author avishkar
	     * this method is used to generate Alphanumeric unique transaction Id
	     * @return
	     */
	    protected String gettransactionId() {
	    	String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	        StringBuilder salt = new StringBuilder();
	        Random rnd = new Random();
	        while (salt.length() < 18) { // length of the random string.
	            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
	            salt.append(SALTCHARS.charAt(index));
	        }
	        String saltStr = salt.toString();
	        return saltStr;
	    }
		
		/**
		 * @author avishkar
		 * Below method is added to calculate other charges charged by the client, if any.
		 * @param camount
		 * @param msisdn
		 * @return
		 */
		public double getOtherCharges(double camount, String msisdn) {
			logger.info(">>>msisdn["+msisdn+"] Inside getOtherCharges method...");
			double amount = camount*1000;
			/**
			 * here camount need to be multiply as well as divide with 1000 for Sudan
			 */
			double taxAmount = 0;
			try {
			
				if(Global.TAX_ENABLE == 1)
				{
				 taxAmount =  ((amount * Global.g_TaxAmount/Global.g_divident))/1000;
				}
				else if (Global.FIXED_AMOUNT_ENABLE == 1) {
					taxAmount = Global.FIXED_AMOUNT;
				}
				else
				{
					taxAmount = 0;
				}
			} catch (Exception e) {
				logger.error(">>>msisdn["+msisdn+"] Exception inside getOtherCharges method ",e);
				System.out.println(">>>msisdn["+msisdn+"] Exception inside getOtherCharges method "+e);
				e.printStackTrace();
			}
			
			logger.info("##>>msisdn["+msisdn+"] camount["+camount+"] OtherCharges["+taxAmount+"]");
			
			return taxAmount;
		}
	    
		public int GetReserveStatus(Data_Object data_object)
		{
			return -1; //not required

		}
}
