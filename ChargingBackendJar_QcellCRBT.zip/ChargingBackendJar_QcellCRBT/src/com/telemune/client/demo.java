package com.telemune.client;

public class demo {
	
	public static void main(String args[])
	{
		
		demo d =new demo();
		System.out.println("Hello [" +d.hashCode()+"]");
		demo d1=new demo();
		System.out.println("Hello [" +d1.hashCode()+"]");
		
		System.out.println("Gap days is: "+(15%2));
	}

}
