package programs;

public class substring {

}
