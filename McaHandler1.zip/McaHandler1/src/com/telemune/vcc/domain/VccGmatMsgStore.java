package com.telemune.vcc.domain;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.model.RequestObject;
import com.telemune.vcc.util.AppContext;

public class VccGmatMsgStore {
	final static Logger logger = Logger.getLogger(VccGmatMsgStore.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private DataSource dataSource;
	

	public VccGmatMsgStore() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public boolean insertIntoGmatMsg(RequestObject reqObject) {
		try {
			String query="";
			String gmatMessageType = AppConfig.config.getString("GMAT_MESSAGE_TYPE","1");
			
			if(Integer.parseInt(AppConfig.config.getString("DB_CON_PARAM","1"))==1)
			{			
			 query = "insert into GMAT_MESSAGE_STORE(RESPONSE_ID,ORIGINATING_NUMBER, DESTINATION_NUMBER,MESSAGE_TEXT, SUBMIT_TIME, STATUS,DELIVERY_RECEIPT,PROTOCOL_IDENTIFIER,MESSAGE_TYPE)values (0,?,?,'Text Message',now(),'R',1,64,?)";
			}
			else if(Integer.parseInt(AppConfig.config.getString("DB_CON_PARAM","0"))==0)
			{
				 query = "insert into GMAT_MESSAGE_STORE( REQUEST_ID, RESPONSE_ID,ORIGINATING_NUMBER, DESTINATION_NUMBER,MESSAGE_TEXT, SUBMIT_TIME, STATUS,DELIVERY_RECEIPT,PROTOCOL_IDENTIFIER,MESSAGE_TYPE) values (gmat_request_seq.nextval,?,?,'Text Message',sysdate,'R',1,64,?)";
	
			}
			logger.info(String.format("[%s] [%s] [%s] [%s]  before query [%s]",reqObject.getaParty(),reqObject.getbParty(), query));
			logger.info("#### MESSAGE_TYPE="+gmatMessageType);
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int count = jdbcTemplate.update(query, new Object[] {reqObject.getaParty(),reqObject.getbParty(),gmatMessageType});
			logger.info(String.format("[%s] [%s] [%s] [%s]  after query [%s]",
					reqObject.getaParty(),reqObject.getbParty(), query));
			if (count > 0)
				return true;
			else
				return false;

		} catch (Exception e) {
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString(
							"errorcode_pattern", "VCC-MCA-")
					+ "00018] [Exception while Inserting into GMAT_MESSAGE_STORE table] AParty["
					+ reqObject.getaParty() + "] BParty["
					+ reqObject.getbParty() + "] Error[ "
					+ e.getMessage() + "]");
			/*e.printStackTrace();
			logger.info("Exception while insert into gmat_message_store : " + e.getMessage());*/
			e.printStackTrace();
			return false;
		}

	}

}
