package com.telemune.vcc.util_reqhandler;

public class MessageParam {
	public int req_type;
	public String msisdn="";

	
	
	public int getReq_type() {
		return req_type;
	}
	public void setReq_type(int req_type) {
		this.req_type = req_type;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	

}
