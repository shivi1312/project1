package com.telemune.vcc.util_reqhandler;

public class RequestTag {
	public static int ALERT_SC=1;
	public static int REQ_TYPE=1;
	public static int DEST_MSISDN=1;

}
