package com.telemune.vcc.util_reqhandler;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.model.Global;
import com.telemune.vcc.model.RequestObject;

public class ThreadPoolExtrSeviceHandler implements Runnable {

	Logger logger = Logger.getLogger("ThreadPoolExtrServiceHandler");
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	final static Logger expireReqLogger = Logger.getLogger("expireReqLogger");

	private ThreadPoolExecutor threadPoolExecutor = null;

	public ThreadPoolExtrSeviceHandler(ThreadPoolExecutor threadPoolExecutor) {
		this.threadPoolExecutor = threadPoolExecutor;
	}

	@Override
	public void run() {
		try {
			while (true) {
				if (Global.requestQueue.isEmpty()) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString("errorcode_pattern",
										"VCC-MCA-")
								+ "90013] [InterruptedException in ContentThreadPoolManager while sleeping thread] Error[ "
								+ e.getMessage() + "]");
						logger.error(
								"exception in ThreadPoolExtrServiceHandler while sleeping thread",
								e);
					}
				}
				else if (threadPoolExecutor.getActiveCount() == AppConfig.config.getInt("MAX_POOL_SIZE")) {
					try {
							logger.warn("Maximum Threads open now. Waiting for free Thread. Active["+threadPoolExecutor.getActiveCount()+"] Max Thread["+AppConfig.config.getInt("MAX_POOL_SIZE")+"]");
							Thread.sleep(AppConfig.config.getLong("SLEEP_TIME_AT_MAX_THREAD"));
					}catch (InterruptedException e) {
						logger.error("Exception in ThreadPoolExtrServiceHandler while sleeping thread",e);
					}
				} else {
					RequestObject dataObject = null;
					try {
						logger.info("Now going to process request ["
								+ Global.requestQueue.size() + "]");
						logger.info("URL queue size is"
								+ Global.requestQueue.size()
								+ String.format(
										"[monitor] [%d/%d] Active: %d, Completed: %d, Task: %d, isShutdown: %s, isTerminated: %s",

										threadPoolExecutor.getPoolSize(),

										threadPoolExecutor.getCorePoolSize(),

										threadPoolExecutor.getActiveCount(),

										threadPoolExecutor
												.getCompletedTaskCount(),

										threadPoolExecutor.getTaskCount(),

										threadPoolExecutor.isShutdown(),

										threadPoolExecutor.isTerminated()));
						
						dataObject = Global.requestQueue.poll();
						if (dataObject != null){
							//Thread.sleep(120000);
							boolean status = this.checkExpiration(dataObject);
							if(status==true){
								// modification start by Avishkar on 17/8/2020
								if (Integer.parseInt(AppConfig.config.getString("IS_MISSED_CALL_INTERNAL_HANDLER_ENABLE"))==1) {
									threadPoolExecutor.execute(new MissedCallInternalHandler(dataObject));
								}
								else {
									threadPoolExecutor.execute(new MissedCallerTrigger(dataObject));
								}
//								threadPoolExecutor.execute(new MissedCallerTrigger(dataObject));	
								
								// modification end by Avishkar on 17/8/2020
							}else{
								expireReqLogger.info("Expired Request : "+dataObject.toString());
							}
						}
						else
							logger.info("dataObject not set");
					} catch (Exception e) {
						errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString("errorcode_pattern",
										"VCC-MCA-")
								+ "00008] [Exception in taking request from requestQueue because ContentThreadPoolManager "
								+"request queue is "
								+ "already full ... so No more request "
								+ "can be taken.. discarding this request] Error[ "
								+ e.getMessage() + "]");
						logger.error(
								"ContentThreadPoolManager request queue is "
										+ "already full ... so No more request "
										+ "can be taken.. discarding this request",
								e);
					}
				}
			}
		} catch (Exception e) {
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-MCA-")
					+ "00009] [Exception in ContentThreadPoolManager run] Error[ "
					+ e.getMessage() + "]");
			logger.error("Error In ContentThreadPoolManager run(),", e);
			System.out.println("Error In ContentThreadPoolManager run()");
		}
	}

	public boolean checkExpiration(RequestObject dataObject){
		Date d1 = null;
		Date d2 = null;
		boolean status = false;
		try{
			Date currentTime = new Date();
			String requestTime = dataObject.getCallTime();
			logger.info("Inside checkExpiration: aParty["+dataObject.getaParty()+"] bParty["+dataObject.getbParty()+"] callTime ["+dataObject.getCallTime()+"] currentTime ["+currentTime+"] Expiry Time ["+AppConfig.config.getLong("notify_expiry_time")+" Seconds]");
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			d1 = dateFormat.parse(dateFormat.format(currentTime));
			d2 = dateFormat.parse(requestTime);
			long diff = d1.getTime() - d2.getTime();
			long difference=TimeUnit.MILLISECONDS.toSeconds(diff);
			//long diffMinutes = diff / (60 * 1000);  
			if(difference >=AppConfig.config.getLong("notify_expiry_time",600)){
				status = false;
			}else{
				status = true;
			}
		}catch(Exception e){
			logger.error("Exception while checking Expiration : aParty["+dataObject.getaParty()+"] bParty["+dataObject.getbParty()+"] "+e.getMessage());
		}
		return status;
	}
}
