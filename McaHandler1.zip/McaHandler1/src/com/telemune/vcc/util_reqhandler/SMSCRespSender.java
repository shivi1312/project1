package com.telemune.vcc.util_reqhandler;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.net.Socket;

import org.apache.log4j.Logger;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.model.Global;

import commonutil.TLVAppInterface;

public class SMSCRespSender implements Runnable {

	static Logger logger = null;
	static Logger errorLogger =null;

	static Thread thrd;
	Socket socket_me;
	MessageParam msgParama;
	DataOutputStream stream_send_data;

	public SMSCRespSender(Socket socket) {
		try {
			logger = Logger.getLogger(SMSCRespSender.class);
			errorLogger = Logger.getLogger("errorLogger");

		} catch (Exception eE) {

		}
		thrd = new Thread(this);
		this.socket_me = socket;
		logger.info("started thread to send data: # ");

	}

	public void run() {
		sendtoclient();
	}

	public void stop() {

	}

	public void sendtoclient() {
		logger.info("preparing data from queue to send ......");
		/*
		 * for(int i=0;i<Global.number_of_connection;i++) {
		 */

		try {
			while (true) {

				if (MissedCallInternalHandler.SMSCQueuePool.isEmpty()) {

					try {

						thrd.sleep(10);
						if (socket_me.isClosed()) {
							logger.info("Socket closed");
							thrd.stop();

							return;

						}
					}

					catch (InterruptedException E) {
					}
				} else {
					logger.info("Send Queue is NOT Empty");

					msgParama = new MessageParam();
					// data_element = globalobj.datasendque.dequeue();
					msgParama = (MessageParam) MissedCallInternalHandler.SMSCQueuePool
							.poll();

					logger.info("Messgae getting from Queue "
							+ msgParama.getReq_type());
					logger.info("MSISDN from Queue " + msgParama.getMsisdn());
					TLVAppInterface send_request = new TLVAppInterface();
					ByteArrayOutputStream send_buf = new ByteArrayOutputStream();

					send_request.setData(RequestTag.REQ_TYPE,
							msgParama.getReq_type());
					send_request.setData(RequestTag.DEST_MSISDN,
							msgParama.getMsisdn());

					send_request.encode(send_buf);
					logger.info("packet Socket is===" + socket_me.toString());

					int send_requestLen = send_buf.size();
					try {
						stream_send_data = new DataOutputStream(
								socket_me.getOutputStream());
						logger.info("writing Info buf size=" + send_requestLen);
						byte[] len = new byte[4];
						len[3] = (byte) (send_requestLen);
						len[2] = (byte) ((send_requestLen >> 8));
						len[1] = (byte) ((send_requestLen >> 16));
						len[0] = (byte) ((send_requestLen >> 24));
						stream_send_data.write(len, 0, 4);
						logger.info("Data length sent of  buf size="
								+ send_requestLen);
						stream_send_data.write(send_buf.toByteArray(), 0,
								send_buf.toByteArray().length);
					} catch (Exception eee) {
						try {
							errorLogger
							.error("ErrorCode ["
									+ AppConfig.config.getString("errorcode_pattern",
											"VCC-MCA-")
									+ "90002] [IOException While sending data] Error[ "
									+ eee.getMessage() + "]");
							logger.error("Exception Sending Data:: "
									+ eee.toString());
						} catch (Exception e) {
							logger.error(e);
						}

					}

				}

			}

		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();

			logger.error(" sendtoclient exiting ");
			System.exit(1);
			thrd.stop();
			logger.error(" sendtoclient stopped success ");
		}
	}

	// }

}
