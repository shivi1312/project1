package com.telemune.vcc.util_reqhandler;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.Socket;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.config.FileBasedConfig;
import com.telemune.vcc.model.Global;
import com.telemune.vcc.model.RequestObject;

public class RequestHandler implements Runnable {

	private Socket clientSocket;
	
	final static Logger logger = Logger.getLogger(RequestHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private Gson gson = new Gson();

	public RequestHandler(Socket clientSocket) {
		this.clientSocket = clientSocket;
	}

	@Override
	public void run() {
		this.readWriteRequest();
	}


	private void readWriteRequest() {
		DataOutputStream os = null;
		DataInputStream reader = null;
		RequestObject reqObject = null;
		try {
			reader = new DataInputStream(this.clientSocket.getInputStream());
			os = new DataOutputStream(clientSocket.getOutputStream());
			String data = reader.readUTF();
			logger.info("Request: "+data);
			reqObject = gson.fromJson(data, RequestObject.class);
			
			if(Global.requestQueue.remainingCapacity()>0){
				logger.info("Request Data put in Queue ");
				Global.requestQueue.put(reqObject);	
			}
			else{
				logger.info("Request Cancel ");
				FileBasedConfig.dropReqFlWriter.writeLog(reqObject.toString());
			}
			String response = "HTTP/1.1 200 OK\n\nRequestHandler:"+ System.currentTimeMillis();
			os.writeUTF(response);
			logger.info("200 ok response sent");
			os.flush();
		} 
		catch (EOFException e) {
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-MCA-")
					+ "00006] [End Of File Exception in reading request] Error[ "
					+ e.getMessage() + "]");
		}
		catch (Exception e) {
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-MCA-")
					+ "00007] [Exception while reading request] Error[ "
					+ e.getMessage() + "]");
			logger.error("Exception in reading request " + e);
		} finally {
			try {
				if(reader != null)
					reader.close();
				if(os != null)
					os.close();
			} catch (IOException e) {
				errorLogger
				.error("ErrorCode ["
						+ AppConfig.config.getString("errorcode_pattern",
								"VCC-MCA-")
						+ "90002] [IOException While closing Input/Output Streams] Error[ "
						+ e.getMessage() + "]");
				
			}
		}
	}
}
