package com.telemune.vcc.controller;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.util_reqhandler.RequestHandler;

public class ServerReqAcceptor implements Runnable {
	static final Logger logger = Logger.getLogger(ServerReqAcceptor.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private ServerSocket serverSocket = null;
	private boolean isStopped = false;
	private int serverPort;
	private Socket clientSocket = null;
	protected ExecutorService threadPool = Executors
			.newFixedThreadPool(AppConfig.config.getInt("acceptor.pool", 5));

	public ServerReqAcceptor(int serverPort) {
		this.serverPort = serverPort;
	}

	@Override
	public void run() {
		/*
		 * synchronized (this) { Thread.currentThread(); }
		 */
		this.openServerSocket();
		while (!isStopped()) {
			try {
				clientSocket = serverSocket.accept();
				logger.debug("connection is established with client");
			} catch (SocketTimeoutException se) {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-MCA-")
								+ "90017] [SocketTimeoutException While accepting client socket Connection] Port["
								+ serverPort + "] Error[ " + se.getMessage()
								+ "]");
			} catch (IOException e) {
				if (isStopped()) {
					logger.info("Server Stopped.");
					break;
				}
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-MCA-")
								+ "90002] [IOException While accepting client socket Connection] Port["
								+ serverPort + "] Error[ " + e.getMessage()
								+ "]");
				logger.error("Error accepting client connection ", e);
				throw new RuntimeException("Error accepting client connection",
						e);
			}
			threadPool.execute(new RequestHandler(clientSocket));
		}
		this.threadPool.shutdown();
		logger.info("Now server is going to shutdown!!");
	}

	private synchronized boolean isStopped() {
		return this.isStopped;
	}

	public synchronized void stop() {
		this.isStopped = true;
		try {
			this.serverSocket.close();
		} catch (IOException e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-MCA-")
							+ "90002] [IOException While closing socket connection] Port["
							+ serverPort + "] Error[ " + e.getMessage() + "]");
			logger.error("error closing server: ", e);
			throw new RuntimeException("Error closing server", e);
		}
	}

	private void openServerSocket() {
		try {
			this.serverSocket = new ServerSocket(serverPort);
			logger.info("Server waiting for client on port "
					+ serverSocket.getLocalPort());
		} catch (IOException e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-MCA-")
					+ "90002] [IOException While opening socket port] Port["
					+ serverPort + "] Error[ " + e.getMessage() + "]");
			logger.fatal("cant't open port: " + e.toString());
			throw new RuntimeException("Cannot open port", e);
		}
	}

}
