package com.telemune.vcc.model;

public class McaCallDetailModel {
	
	private String originationNumber;
	private String rowId;
	public String getOriginationNumber() {
		return originationNumber;
	}
	public void setOriginationNumber(String originationNumber) {
		this.originationNumber = originationNumber;
	}
	public String getRowId() {
		return rowId;
	}
	public void setRowId(String rowId) {
		this.rowId = rowId;
	}
	

}
