package com.telemune.vcc.model;

public class RequestObject {
	
	private String aParty;
	private String bParty;
	private String reasonCode;
	private String serviceType;
	private String serviceKey;
	private String callTime;
	private String lang;
	private String type;
	
	
	
	public String getServiceKey() {
		return serviceKey;
	}
	public void setServiceKey(String serviceKey) {
		this.serviceKey = serviceKey;
	}
	public String getaParty() {
		return aParty;
	}
	public void setaParty(String aParty) {
		this.aParty = aParty;
	}
	public String getbParty() {
		return bParty;
	}
	public void setbParty(String bParty) {
		this.bParty = bParty;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getCallTime() {
		return callTime;
	}
	public void setCallTime(String callTime) {
		this.callTime = callTime;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	@Override
	public String toString() {
		return "RequestObject [aPrty=" + aParty + ", bPrty=" + bParty
				+ ", reasonCode=" + reasonCode + ", serviceType=" + serviceType
				+ ", callTime=" + callTime + ", type="
				+ type + "]";
	}

}
