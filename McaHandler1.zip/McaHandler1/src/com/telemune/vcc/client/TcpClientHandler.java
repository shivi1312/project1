package com.telemune.vcc.client;

import org.apache.log4j.Logger;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IoSession;


public class TcpClientHandler extends IoHandlerAdapter {

	private final static Logger logger = Logger.getLogger(TcpClientHandler.class);

	public TcpClientHandler() {

	}

	@Override
	public void sessionOpened(IoSession session) {

	}

	@Override
	public void messageReceived(IoSession session, Object message) {
		logger.info("Messge is: " + message.toString());
	}

	@Override
	public void exceptionCaught(IoSession session, Throwable cause) {
		session.closeNow();
	}
}
