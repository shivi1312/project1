package com.telemune.vcc.client;

public class TcpConfig {
	private String host = "127.0.0.1";
	private int port = 9123;
	private int connectTimeout = 20000;
	private String codec = "UTF-8";
	private int retrySleepTime = 1000;

	public TcpConfig(String host, int port){
		this.host = host;
		this.port = port;
	}
	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public int getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public String getCodec() {
		return codec;
	}

	public void setCodec(String codec) {
		this.codec = codec;
	}

	public int getRetrySleepTime() {
		return retrySleepTime;
	}

	public void setRetrySleepTime(int retrySleepTime) {
		this.retrySleepTime = retrySleepTime;
	}

}
