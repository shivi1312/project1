package com.telemune.vcc.server;

import org.apache.log4j.Logger;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;

import com.google.gson.Gson;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.config.FileBasedConfig;
import com.telemune.vcc.model.Global;
import com.telemune.vcc.model.RequestObject;
import com.vcc.persistent.client.codec.TeleRequest;

public class TcpServerHandler extends IoHandlerAdapter {
	RequestObject reqObject = null;
	private Gson gson = new Gson();

	private final static Logger logger = Logger
			.getLogger(TcpServerHandler.class);
	int numOfElement=0;
	int totalCapacity=0;
	int percentage=0;
	@Override
	public void exceptionCaught(IoSession session, Throwable cause)
			throws Exception {
		cause.printStackTrace();
	}

	@Override
	public void messageReceived(IoSession session, Object message)
			throws Exception {
		TeleRequest teleRequest = (TeleRequest) message;
		if (teleRequest.getRequest().trim().equalsIgnoreCase("quit")) {
			session.closeOnFlush();
			return;
		}
		numOfElement = Global.requestQueue.size();
		totalCapacity = AppConfig.config.getInt("QUEUE_SIZE");
		percentage = (numOfElement*100/totalCapacity);
		reqObject = gson.fromJson(teleRequest.getRequest(), RequestObject.class);
		if (Global.requestQueue.remainingCapacity() > 0) {
			
			logger.info("Request Data put in Queue. AParty["+reqObject.getaParty()+"] BParty["+reqObject.getbParty()+"] " +
					"Request Queue Growth Percentage[ "+percentage+"% ]");
			Global.requestQueue.put(reqObject);

		} else {
			logger.warn("AParty["+reqObject.getaParty()+"] BParty["+reqObject.getbParty()+"] " +
					"Request Queue is FULL. So Request has been canceled and written into file. " +
					"Request Queue Growth Percentage[ "+percentage+"% ]");
			FileBasedConfig.dropReqFlWriter.writeLog(reqObject.toString());
		}
		String response = "HTTP/1.1 200 OK\n\nRequestHandler:"+ System.currentTimeMillis();
		teleRequest.setResponse(response);
		session.write(teleRequest);
	}

	@Override
	public void sessionIdle(IoSession session, IdleStatus status)
			throws Exception {
		
	}

}
