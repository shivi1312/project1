package com.telemune.vcc.server;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.Charset;

import org.apache.log4j.Logger;
import org.apache.mina.core.service.IoAcceptor;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.logging.LoggingFilter;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;

import com.vcc.persistent.client.codec.TeleCodecFactory;

public class TcpServer {

	private final static Logger logger = Logger.getLogger(TcpServer.class);
	private NioSocketAcceptor acceptor = null;
	private int port = 1090;
	private String host = "127.0.0.1";
	private String codec = "UTF-8";
	private int readBufferSize = 1024;
	private int minReadBufferSize = 1024;
	private int maxReadBufferSize = 2048;
	private int idleTime = 10;

	public TcpServer(String host, int port) {
		this.host = host;
		this.port = port;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getCodec() {
		return codec;
	}

	public void setCodec(String codec) {
		this.codec = codec;
	}

	public int getReadBufferSize() {
		return readBufferSize;
	}

	public void setReadBufferSize(int readBufferSize) {
		this.readBufferSize = readBufferSize;
	}

	public int getMinReadBufferSize() {
		return minReadBufferSize;
	}

	public void setMinReadBufferSize(int minReadBufferSize) {
		this.minReadBufferSize = minReadBufferSize;
	}

	public int getMaxReadBufferSize() {
		return maxReadBufferSize;
	}

	public void setMaxReadBufferSize(int maxReadBufferSize) {
		this.maxReadBufferSize = maxReadBufferSize;
	}

	public int getIdleTime() {
		return idleTime;
	}

	public void setIdleTime(int idleTime) {
		this.idleTime = idleTime;
	}

	public void start() {
		acceptor = new NioSocketAcceptor();
		
		
		logger.info("Listening host: " + this.host + " and port: " + this.port);
		logger.info("Buffer size: " + this.readBufferSize + " min: " + this.minReadBufferSize + " max: "
				+ this.maxReadBufferSize);
		logger.info("Codec: " + this.codec + " idle time: " + this.idleTime);
		this.setConfiguration();
		this.bindTcp();
		if (!acceptor.isActive()) {
			logger.error("acceptor is not created: now going to down");
			acceptor.dispose();
			return;
		}
		logger.info("Acceptor is starting successfully ");
	}

	private void setConfiguration() {
		
		acceptor.getFilterChain().addLast("logger", new LoggingFilter());
		acceptor.getFilterChain().addLast("codec",
				new ProtocolCodecFilter(new TeleCodecFactory(Charset.forName(this.codec), false)));
		acceptor.setHandler(new TcpServerHandler());
		acceptor.getSessionConfig().setMinReadBufferSize(this.minReadBufferSize);
		acceptor.getSessionConfig().setMaxReadBufferSize(this.maxReadBufferSize);
		acceptor.getSessionConfig().setReadBufferSize(this.readBufferSize);
		acceptor.getSessionConfig().setIdleTime(IdleStatus.BOTH_IDLE, this.idleTime);
		acceptor.setReuseAddress(true);
	}

	private void bindTcp() {
		try {
			acceptor.bind(new InetSocketAddress(this.port));
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	public static void main(String[] args) throws IOException {
		new TcpServer("10.168.3.65", 1090).start();
	}
}
