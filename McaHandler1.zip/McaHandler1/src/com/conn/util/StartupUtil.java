package com.conn.util;

import org.apache.log4j.Logger;

import FileBaseLogging.FileLogWriter;

public class StartupUtil {
	final static Logger logger = Logger.getLogger(StartupUtil.class);

	public StartupUtil() {

	}

	public int makeDBPool(String driver, String url, String username,
			String passwd, int minpoolsize, int maxpoolsize, int Accomodation) {
		return 0;
	}

	public int initialize(FileLogWriter error_log) {
		return 0;
	}
}
