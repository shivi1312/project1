package com.conn.util;

/**
 * Created by tanujkumar on 02/07/15.
 */
public class ExceptionIgnorer {

    private ExceptionHandler exceptionHandler = null;

    protected ExceptionHandler exceptionHandler(){
        return exceptionHandler;
    }

    protected void exceptionHandler(ExceptionHandler newValue){
        this.exceptionHandler = newValue;
    }

    public ExceptionIgnorer(){
    }

    public ExceptionIgnorer(ExceptionHandler exceptionHandler){
    }

    public ExceptionHandler getExceptionHandler(){
        return this.exceptionHandler;
    }

    public void setExceptionHandler(ExceptionHandler exceptionHandler){
        this.exceptionHandler = exceptionHandler;
    }

    public void exceptionOccurred(Throwable throwable){
        if ( exceptionHandler() != null ){
            exceptionHandler().handleException( throwable );
        }
    }
}
