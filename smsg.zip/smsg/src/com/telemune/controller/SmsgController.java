package com.telemune.controller;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.telemune.handler.JsonHandler;
import com.telemune.handler.SmsgHandler;

import com.telemune.response.ResponseBean;
import com.telemune.response.ResponseData;

@RestController
@RequestMapping("/")
public class SmsgController {
	final static Logger logger = Logger.getLogger(SmsgController.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");	
	private static Gson gson = new Gson();

	@RequestMapping(value = "smsg.request", method = { RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody String reqProcess(@RequestParam Map<String, String> params, ResponseBean reqResponse) {
		String response = "status:fail, msg:Fail";
		SmsgHandler reqHandler = new SmsgHandler();
		boolean status = reqHandler.processReq(params, reqResponse);
		logger.info("status [" + status + "] response:-profile.check  " + gson.toJson(reqResponse));
		response = "status:" + reqResponse.getStatus() + ",msg:" + reqResponse.getMessage();
		return response;
	}

	@RequestMapping(value = "smsg.json", method = RequestMethod.GET, produces = "application/json", consumes = "application/json")
	public @ResponseBody List<ResponseBean> handleJson(@RequestBody String jsonString, ResponseBean reqResponse) {
		logger.info("Received JSON " + jsonString);

		JsonHandler jsonHandler = new JsonHandler();
		List<ResponseBean> respList = jsonHandler.JsonParse(jsonString, reqResponse);
		jsonHandler = null;
		logger.debug("status [" + respList + "] response:-profile.check  " + gson.toJson(reqResponse));

		return respList;
	}

	@RequestMapping(value = "smsg.xml", method = { RequestMethod.POST,
			RequestMethod.GET }, produces = "application/xml; charset=utf-8", consumes = "application/xml; charset=utf-8")
	public @ResponseBody ResponseData handleXml(@RequestBody String xmlString, ResponseBean reqResponse) {
		ResponseData data = null;
		List<ResponseBean> respList = null;
		logger.info("Received JSON " + xmlString);
		try {

			JSONObject xmlJSONObj = XML.toJSONObject(xmlString);

			String jsonString = xmlJSONObj.getJSONObject("root").get("msg").toString();
			if (!jsonString.startsWith("[")) {
				jsonString = "[" + jsonString + "]";
			}
			JsonHandler jsonHandler = new JsonHandler();
			respList = jsonHandler.JsonParse(jsonString, reqResponse);

			data = new ResponseData();
			data.setElement(respList);

			jsonHandler = null;
			logger.debug("status [" + respList + "] response:-profile.check  " + gson.toJson(reqResponse));
		} 
		catch (JSONException jsonException) {
			 errorLogger.error("ErrorCode [SMSGW-SMSGWAR-00001] [JSONException Exception while Converting xml to json] Error[" + jsonException.getMessage()+"]");
            jsonException.printStackTrace();
		}
		catch (Exception e) {
			 errorLogger.error("ErrorCode [SMSGW-SMSGWAR-00002] [Exception while parsing and getting xml from client] Error[" + e.getMessage()+"]");
			e.printStackTrace();
		}

		return data;
	}

}