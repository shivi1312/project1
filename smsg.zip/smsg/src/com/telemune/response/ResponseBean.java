package com.telemune.response;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ResponseBean")
public class ResponseBean {
	
	String message;
	String status;
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "ResponseBean [message=" + message + ", status=" + status + "]";
	}
	
	

}
