package com.telemune.response;


import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "root")
public class ResponseData {
	
	
	private List<ResponseBean>  element =null;

	public List<ResponseBean> getElement() {
		return element;
	}

	public void setElement(List<ResponseBean> element) {
		this.element = element;
	}

}
