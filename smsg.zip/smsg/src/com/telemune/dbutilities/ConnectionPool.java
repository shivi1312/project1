package com.telemune.dbutilities;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mchange.v2.c3p0.ComboPooledDataSource;


public class ConnectionPool {
	private static ConnectionPool datasource;
	private static ComboPooledDataSource cpds;
	static final Logger logger = Logger.getLogger(ConnectionPool.class);

	public ConnectionPool() {

	}

	private ConnectionPool(String productId) throws IOException, SQLException,
			PropertyVetoException {

		logger.info("drive: ["
				+ AppConfig.config.getString("DRIVER",
						"oracle.jdbc.driver.OracleDriver")
				+ "] url ["
				+ AppConfig.config.getString("URL",
						"jdbc:oracle:thin:@10.168.1.23:1521:mastera") + "]");
		logger.info("user [" + AppConfig.config.getString("user", "smsg")
				+ "] password [" + AppConfig.config.getString("PASS", "smsg")
				+ "]");
		cpds = new ComboPooledDataSource();
		cpds.setDriverClass(AppConfig.config.getString("DRIVER",
				"oracle.jdbc.driver.OracleDriver")); // loads the jdbc driver
		cpds.setJdbcUrl(AppConfig.config.getString("URL",
				"jdbc:oracle:thin:@10.168.1.23:1521:mastera"));
		cpds.setUser(AppConfig.config.getString("user", "smsg"));
		cpds.setPassword(AppConfig.config.getString("PASS", "smsg"));
		cpds.setMinPoolSize(AppConfig.config.getInt("min.pool", 5));
		cpds.setAcquireIncrement(AppConfig.config
				.getInt("acquire.increment", 5));
		cpds.setMaxPoolSize(AppConfig.config.getInt("max.pool", 20));
		cpds.setMaxStatements(AppConfig.config.getInt("max.statement", 100));
		cpds.setAcquireRetryAttempts(AppConfig.config.getInt(
				"acquire.retry.attempts", 2));
		
		cpds.setTestConnectionOnCheckin(AppConfig.config.getBoolean("ConnectionChecking",true));
		cpds.setIdleConnectionTestPeriod(AppConfig.config.getInt("IdleConnectionTestPeriod",300));
		cpds.setMaxIdleTimeExcessConnections(AppConfig.config.getInt("ConnectionIdleTime",240));
	}

	public static ConnectionPool getInstance() throws IOException,
			SQLException, PropertyVetoException {
		if (datasource == null) {
			datasource = new ConnectionPool("productId");
		}
		return datasource;
	}

	public void closeDataSource() {
		cpds.close();
	}

	public Connection getConnection() throws IOException, SQLException,
			PropertyVetoException {
		Connection conn = cpds.getConnection();
		logger.info("active connection [" + cpds.getNumBusyConnections()
				+ "] idle: " + cpds.getNumIdleConnections() + " total ["
				+ cpds.getNumConnections() + "]");
		return conn;
	}
}
