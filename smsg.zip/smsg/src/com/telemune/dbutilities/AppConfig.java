package com.telemune.dbutilities;

import java.io.File;

import org.apache.commons.configuration.CombinedConfiguration;
import org.apache.commons.configuration.DefaultConfigurationBuilder;
import org.apache.log4j.Logger;

public class AppConfig {
//	private final static Logger logger = Logger.getLogger(AppConfig.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");	

	
	public static CombinedConfiguration config;
	private AppConfig() {

	}
	static {
		try {
			DefaultConfigurationBuilder builder = new DefaultConfigurationBuilder();
			builder.setFile(new File("config.xml"));
			config = builder.getConfiguration(true);
		} 
		catch(NullPointerException ex)
		{
			errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90003] [NullPointerException while reading and getting config.xml file] ERROR ["+ex.getMessage()+"]");
			ex.printStackTrace();
		}
		catch (Exception e) {
			errorLogger.error("Erroe [SMSGW-SMSGWAR-00003] [Exception in reading config.xml file] ERROR ["+e.getMessage()+"]");
			e.printStackTrace();
		}
	}


}
