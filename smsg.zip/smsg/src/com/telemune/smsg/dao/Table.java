package com.telemune.smsg.dao;

import java.util.ArrayList;

public class Table {
	private ArrayList<FieldBean> field;
	private int msgLength=5;
	
	

	

	public int getMsgLength() {
		return msgLength;
	}



	public void setMsgLength(int msgLength) {
		this.msgLength = msgLength;
	}



	public ArrayList<FieldBean> getField() {
		return field;
	}



	public void setField(ArrayList<FieldBean> field) {
		this.field = field;
	}



	@Override
	public String toString() {
		return "Table [field=" + field + "]";
	}


	
}
