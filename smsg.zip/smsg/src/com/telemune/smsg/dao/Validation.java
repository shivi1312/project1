package com.telemune.smsg.dao;

public class Validation {
	private Checking required;
	private Checking length;
	private Checking number;
	private Checking range;
	private Checking values;
	
	
	public Checking getRange() {
		return range;
	}
	public void setRange(Checking range) {
		this.range = range;
	}
	
	
	
	public Checking getValues() {
		return values;
	}
	public void setValues(Checking values) {
		this.values = values;
	}
	public Checking getRequired() {
		return required;
	}
	public void setRequired(Checking required) {
		this.required = required;
	}
	public Checking getLength() {
		return length;
	}
	public void setLength(Checking length) {
		this.length = length;
	}
	public Checking getNumber() {
		return number;
	}
	public void setNumber(Checking number) {
		this.number = number;
	}
	@Override
	public String toString() {
		return "Validation [required=" + required + ", length=" + length + ", number=" + number + ", range=" + range
				+ ", value=" + values + "]";
	}
	
	
	

}
