package com.telemune.smsg.dao;

public class FieldBean {
	private String param;
	 private String column;
	 private String defaultvalue;
	 private String columnType;
	 private String paramType;
	 
	 private Validation validation;
	 
	public String getParamType() {
		return paramType;
	}
	public void setParamType(String paramType) {
		this.paramType = paramType;
	}
	public String getColumnType() {
		return columnType;
	}
	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}
	public String getParam() {
		return param;
	}
	public void setParam(String param) {
		this.param = param;
	}
	public String getColumn() {
		return column;
	}
	public void setColumn(String column) {
		this.column = column;
	}
	public String getDefaultvalue() {
		return defaultvalue;
	}
	public void setDefaultvalue(String defaultvalue) {
		this.defaultvalue = defaultvalue;
	}
	public Validation getValidation() {
		return validation;
	}
	public void setValidation(Validation validation) {
		this.validation = validation;
	}
	@Override
	public String toString() {
		return "FieldBean [param=" + param + ", column=" + column + ", defaultvalue=" + defaultvalue + ", columnType="
				+ columnType + ", paramType=" + paramType + ", validation=" + validation + "]";
	}
	
	
	 
	
	

}
