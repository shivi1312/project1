package com.telemune.smsg.dao;

public class Checking {
	private boolean check;
	private String msg;
	private int minLength;
	private int maxLength;
	private String value;
	private long minRange;
	private long maxRange;
	
		
	
	
	
	public long getMinRange() {
		return minRange;
	}
	public void setMinRange(long minRange) {
		this.minRange = minRange;
	}
	public long getMaxRange() {
		return maxRange;
	}
	public void setMaxRange(long maxRange) {
		this.maxRange = maxRange;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public int getMinLength() {
		return minLength;
	}
	public void setMinLength(int minLength) {
		this.minLength = minLength;
	}
	public int getMaxLength() {
		return maxLength;
	}
	public void setMaxLength(int maxLength) {
		this.maxLength = maxLength;
	}
	
	public boolean isCheck() {
		return check;
	}
	public void setCheck(boolean check) {
		this.check = check;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	@Override
	public String toString() {
		return "Checking [check=" + check + ", msg=" + msg + ", minLength=" + minLength + ", maxLength=" + maxLength
				+ ", value=" + value + ", minRange=" + minRange + ", maxRange=" + maxRange + "]";
	}
	
	
	
	

}
