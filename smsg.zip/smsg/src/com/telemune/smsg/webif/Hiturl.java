package com.telemune.smsg.webif;

import java.beans.PropertyVetoException;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.AppConfig;
import com.telemune.dbutilities.ConnectionPool;

import com.telemune.endec.MSISDNEnDec;

public class Hiturl {
	static final Logger logger = Logger.getLogger(Hiturl.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private String keyword;
	private String shortcode;
	private String smscId;
	private String msg;
	private String msisdn;
	private static Connection con = null;
	public int size;
	FileInputStream fis = null;

	public Hiturl() {
		try {
			if (con == null) {
				con = ConnectionPool.getInstance().getConnection();
				logger.info("connection is" + con.toString());
			} else {
				logger.info("connection already created");
			}
		} catch (SQLException sqe) {
			errorLogger
					.error("ErrorCode [SMSGW-SMSGWAR-90001] [SQLException Creating connection from data base] ERROR ["
							+ sqe.getMessage() + "]");
			sqe.printStackTrace();
		} catch (IOException e) {
			errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90002] [IOException Creating connection from data base] ERROR ["
					+ e.getMessage() + "]");
			e.printStackTrace();
		} catch (PropertyVetoException ex) {
			errorLogger.error(
					"ErrorCode [SMSGW-SMSGWAR-90014] [PropertyVetoException Creating connection from data base] ERROR ["
							+ ex.getMessage() + "]");
			ex.printStackTrace();
		} catch (Exception e) {
			errorLogger.error(
					"ErrorCode [SMSGW-SMSGWAR-00008] [Exception while creating connection form data base] ERROR ["
							+ e.getMessage() + "]");
			e.printStackTrace();
		}

	}

	/*
	 * public int toHit(String shortcode,String keyword, String msisdn,String
	 * msg,String smscId)
	 */
	public int toHit(HashMap<String, String> paramMap) {
		logger.info("Hash map is " + paramMap.toString());
		if (paramMap.containsKey("shortcode")) {
			this.shortcode = paramMap.get("shortcode");
			paramMap.remove("shortcode");
		}
		if (paramMap.containsKey("keyword")) {
			this.keyword = paramMap.get("keyword");
			paramMap.remove("keyword");
		}
		if (paramMap.containsKey("smscid")) {
			this.smscId = paramMap.get("smscid");
			paramMap.remove("smscid");
		}
		if (paramMap.containsKey("params")) {
			this.msg = paramMap.get("params");
			paramMap.remove("params");
		}
		if (paramMap.containsKey("msisdn")) {
			this.msisdn = paramMap.get("msisdn");
			paramMap.remove("msisdn");
		}
		
		
		if(AppConfig.config.getString("TEST_ENABLE").trim().equalsIgnoreCase("1") &&  AppConfig.config.getString("TEST_MSISDN").trim().equalsIgnoreCase(this.msisdn.trim())) {
			logger.info("This is testing msisdn so going to process with url "+AppConfig.config.getString("TEST_URL").trim());
			int result = urlChecking(AppConfig.config.getString("TEST_URL").trim(), keyword, msisdn, msg, smscId, paramMap, shortcode);
			if (result < 1) {
				logger.info("There is any error in URL by short code and  keyword name");
				return result;
			}
			return 1;
		}
		
		
		Statement pstmt = null, pstmt1 = null;
		PreparedStatement pstmt3 = null;
		ResultSet rs = null;

		
		
		
		logger.info("shortcode=====" + shortcode + "+++++++++keyword=" + keyword + "smscId========" + smscId
				+ "msisdn=====" + msisdn + "message =" + msg);

		int shortCodeEnable = -1;
		int countryCodeEnable = -1;
		shortCodeEnable = AppConfig.config.getInt("EnableshortCode");
		countryCodeEnable = AppConfig.config.getInt("EnablecountryCode");
		if (shortCodeEnable == 1) {
			String query = "select * from smsg_keyword_master where SHORT_CODE=" + shortcode + " and KEYWORD_NAME='"
					+ keyword + "'";
			
			String query1 = "select * from url_mapping where CODE=" + shortcode;
			try {
				pstmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				rs = pstmt.executeQuery(query);
				rs.last();
				size = rs.getRow();
				rs.beforeFirst();
				if (size > 0) {

					logger.info("Number of records found to hit=" + size);
					long tstart = new java.util.Date().getTime();
					while (rs.next()) {
						String dburl = rs.getString("URL");
						logger.info(dburl);
						int result = urlChecking(dburl, keyword, msisdn, msg, smscId, paramMap, shortcode);
						if (result < 1) {
							logger.info("There is any error in URL by short code and  keyword name");
						}

					}

					long tend = new java.util.Date().getTime();
					logger.info("ENDof  exicuting first query=====in milisec========= " + (tend - tstart));
					rs.close();
					pstmt.close();
					try {

						query = "insert into keyword_code_report values(sysdate,?,?,?)";
						if (AppConfig.config.getString("DB_TYPE").trim().equalsIgnoreCase("1")) {
							query = "insert into keyword_code_report values(sysdate,?,?,?)";
						} else {
							query = "insert into keyword_code_report values(sysdate(),?,?,?)";
						}

						pstmt3 = con.prepareStatement(query);
						pstmt3.setString(1, keyword);
						pstmt3.setString(2, shortcode);
						pstmt3.setString(3, msisdn);

						logger.info("row executed " + pstmt3.executeUpdate());
						pstmt3.close();
					} catch (SQLException sqle) {
						errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90001] MSISDN [" + msisdn + "] short code ["
								+ shortcode + "] [SQLException while insert into report_code_report] ERROR ["
								+ sqle.getMessage() + "]");
						sqle.printStackTrace();
						return -3;
					} catch (Exception e) {
						errorLogger.error("ErrorCode [SMSGW-SMSGWAR-00009] MSISDN [" + msisdn + "] short code ["
								+ shortcode + "][Exception while insert into report_code_report] ERROR ["
								+ e.getMessage() + "]");
						e.printStackTrace();
						return -2;
					}

				}

				else {
					pstmt1 = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
					rs = pstmt1.executeQuery(query1);
					rs.last();
					size = rs.getRow();
					rs.beforeFirst();
					logger.info("Number of records found to hit=" + size);
					if (size > 0) {
						long tstart = new java.util.Date().getTime();
						while (rs.next()) {
							int msisdnindex = -1;
							StringBuffer urlquery = null;
							String dburl = rs.getString("URL");
							logger.info(dburl);
							int result = urlChecking(dburl, keyword, msisdn, msg, smscId, paramMap, shortcode);
							if (result < 1) {
								logger.info("There is any error in URL by short code and  keyword name");
							}

						}
						long tend = new java.util.Date().getTime();
						logger.info("ENDof  exicuting second query=====in milisec========= " + (tend - tstart));
						rs.close();
						pstmt.close();
						try {
							query = "insert into keyword_code_report values(sysdate,?,?,?)";

							if (AppConfig.config.getString("DB_TYPE").trim().equalsIgnoreCase("1")) {
								query = "insert into keyword_code_report values(sysdate,?,?,?)";
							} else {
								query = "insert into keyword_code_report values(sysdate(),?,?,?)";
							}

							pstmt3 = con.prepareStatement(query);
							pstmt3.setString(1, keyword);
							pstmt3.setString(2, shortcode);
							pstmt3.setString(3, msisdn);
							logger.info("row executed " + pstmt3.executeUpdate());
							pstmt3.close();
						} catch (SQLException sqle) {
							errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90001] MSISDN [" + msisdn + "] short code ["
									+ shortcode
									+ "] [SQLException while insert into report_code_report when short code is enable] ERROR ["
									+ sqle.getMessage() + "]");
							sqle.printStackTrace();
							return -3;
						} catch (Exception e) {
							errorLogger.error("ErrorCode [SMSGW-SMSGWAR-00009] MSISDN [" + msisdn + "] short code ["
									+ shortcode
									+ "][Exception while insert into report_code_report when short code is enable] ERROR ["
									+ e.getMessage() + "]");
							e.printStackTrace();
							return -2;
						}
					} else {
						int result = insertDB(shortcode, msisdn);
						if (result < 1) {
							logger.info("Data is not insert into data base by first query no hit found");
						}

					}

				}

			} catch (SQLException sqle) {
				errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90001] MSISDN [" + msisdn + "] short code [" + shortcode
						+ "] [SQLException while select data from smsg_keyword_master and url_mapping when short code is enable] ERROR ["
						+ sqle.getMessage() + "]");
				sqle.printStackTrace();
				return -3;
			} catch (Exception e) {
				errorLogger.error("ErrorCode [SMSGW-SMSGWAR-00008] MSISDN [" + msisdn + "] short code [" + shortcode
						+ "][Exception while select data from smsg_keyword_master and url_mapping when short code is enable] ERROR ["
						+ e.getMessage() + "]");
				e.printStackTrace();
				return -2;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (pstmt1 != null)
						pstmt1.close();
					if (pstmt3 != null)
						pstmt3.close();
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		}
		if (countryCodeEnable == 2) {
			String query = "";
			int countryCodeLength = 0;
			countryCodeLength = AppConfig.config.getInt("COUNTRYCODE.LENGTH");

			String countryCode = msisdn.substring(0, countryCodeLength);
			logger.info("Inside condition when country code received country code [" + countryCode + "]");
			query = "select * from url_mapping where COUNTRY_CODE=" + countryCode.trim();
			try {
				pstmt1 = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				rs = pstmt1.executeQuery(query);
				rs.last();
				size = rs.getRow();
				rs.beforeFirst();
				logger.info("Number of records found to hit=" + size);
				if (size > 0) {
					long tstart = new java.util.Date().getTime();
					while (rs.next()) {
						int msisdnindex = -1;
						StringBuffer urlquery = null;
						String dburl = rs.getString("URL");
						logger.info(dburl);
						int result = urlChecking(dburl, keyword, msisdn, msg, smscId, paramMap, shortcode);
						
						if (result < 1) {
							logger.info("There is any error in URL by short code and  keyword name");
						}

					}
					long tend = new java.util.Date().getTime();
					logger.info("ENDof  exicuting second query=====in milisec========= " + (tend - tstart));
					rs.close();
					pstmt1.close();
					try {
						query = "insert into keyword_code_report values(sysdate,?,?,?)";
						if (AppConfig.config.getString("DB_TYPE").trim().equalsIgnoreCase("1")) {
							query = "insert into keyword_code_report values(sysdate,?,?,?)";
						} else {
							query = "insert into keyword_code_report values(sysdate(),?,?,?)";
						}
						pstmt3 = con.prepareStatement(query);
						pstmt3.setString(1, keyword);
						pstmt3.setString(2, shortcode);
						pstmt3.setString(3, msisdn);
						logger.info("row executed " + pstmt3.executeUpdate());
						pstmt3.close();
					} catch (SQLException sqle) {
						errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90001] MSISDN [" + msisdn + "] short code ["
								+ shortcode
								+ "] [SQLException while insert into report_code_report  when country code is enable] ERROR ["
								+ sqle.getMessage() + "]");
						sqle.printStackTrace();
						return -3;
					} catch (Exception e) {
						errorLogger.error("ErrorCode [SMSGW-SMSGWAR-00009] MSISDN [" + msisdn + "] short code ["
								+ shortcode
								+ "][Exception while insert into report_code_report when country code is enable] ERROR ["
								+ e.getMessage() + "]");
						e.printStackTrace();
						return -2;
					}

				} else {
					int result = insertDB(shortcode, msisdn);
					if (result < 1) {
						logger.info("Data is not inser into data base by 2nd query no url hit found");
					}

				}

			} catch (SQLException sqle) {
				errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90001] MSISDN [" + msisdn + "] short code [" + shortcode
						+ "] [SQLException while select data from url_mapping when country code is enable] ERROR ["
						+ sqle.getMessage() + "]");
				sqle.printStackTrace();
				return -3;
			} catch (Exception e) {
				errorLogger.error("ErrorCode [SMSGW-SMSGWAR-00010] MSISDN [" + msisdn + "] short code [" + shortcode
						+ "][Exception while select data from url_mapping when country code is enable] ERROR ["
						+ e.getMessage() + "]");
				e.printStackTrace();
				return -2;
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (pstmt != null)
						pstmt.close();
					if (pstmt1 != null)
						pstmt1.close();
					if (pstmt3 != null)
						pstmt3.close();
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		}

		return 1;
	}

	public int urlChecking(String dburl, String keyword, String msisdn, String msg, String smscId,
			HashMap<String, String> paramMap, String shortCode) {
		logger.info("inside urlChecking() dburl[" + dburl + "] keyword[" + keyword + "] msisdn[" + msisdn + "] msg["
				+ msg + "] smscId[" + smscId + "] shortCode[" + shortCode + "] paramMap[" + paramMap + "]");

		try {
			URL urltemp = new URL(dburl);
			StringBuffer oldurl = new StringBuffer(dburl);
			StringBuffer urlquery = new StringBuffer(urltemp.getQuery());

			logger.info("urlquery [" + urlquery + "]");

			int msisdnindex = urlquery.indexOf("%p");
			if (msisdnindex > 0)
				urlquery.replace(msisdnindex, msisdnindex + 2, msisdn);
			int keyindex = urlquery.indexOf("%k");
			if (keyindex > 0)
				urlquery.replace(keyindex, keyindex + 2, keyword);
			if(AppConfig.config.getString("PARAM_ENCODING_ENABLE").trim().equals("1")){
				msg = msg.substring(msg.indexOf(" ", 0) + 1, msg.length());
			}
			int msgindex = urlquery.indexOf("%r");
			if (msgindex > 0)
				urlquery.replace(msgindex, msgindex + 2, msg);
			int smscIdIndex = urlquery.indexOf("%s");
			if (smscIdIndex > 0) {
				urlquery.replace(smscIdIndex, smscIdIndex + 2, smscId);
			}

			// added by avinash on 24/04/2017 to send encoded value of MSISDN
			int encvIndex = urlquery.indexOf("%e");
			String encodedMSISDN = new MSISDNEnDec().encodeMSISDN(new StringBuilder(msisdn));
			if (encvIndex > 0)
				urlquery.replace(encvIndex, encvIndex + 2, encodedMSISDN);

			// added by avinash on 14/09/2017 to send shortcode
			int shortCodeindex = urlquery.indexOf("%c");
			logger.info("shortCode [" + shortCode + "] shortCodeindex[" + shortCodeindex + "]");
			if (shortCodeindex > 0)
				urlquery.replace(shortCodeindex, shortCodeindex + 2, shortCode);

			logger.info("Values are==" + urlquery);

			String newurl = oldurl.toString();
			if (msisdnindex > 0 || msgindex > 0 || keyindex > 0 || smscIdIndex > 0) {
				newurl = oldurl.replace(oldurl.indexOf("?") + 1, oldurl.length(), urlquery.toString()).toString();
			}
			for (Entry<String, String> entry : paramMap.entrySet()) {
				newurl = newurl + "&" + entry.getKey() + "=" + entry.getValue();
			}
			newurl = newurl.replaceAll("#", "%23");

			newurl = newurl.replaceAll(" ", "+");
			logger.info("New Url become.........." + newurl);

			URL urllink = new URL(newurl);

			HttpURLConnection ucon = (HttpURLConnection) urllink.openConnection();
			ucon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
			ucon.setConnectTimeout(5*1000);
			ucon.setReadTimeout(5*1000);
			ucon.connect();
			logger.info("************************ " + ucon.getContentType());
			ucon.setConnectTimeout(AppConfig.config.getInt("HITURLTIMEOUT"));
			ucon.setReadTimeout(AppConfig.config.getInt("READTIMEOUT"));
			int responseCode = ucon.getResponseCode();
			logger.info("Getting  Response Code :[  " + responseCode + "  ]");

			ucon.disconnect();

		} catch (SocketTimeoutException socExe) {
			errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90011] MSISDN[" + msisdn + "] ShortCode[" + shortcode
					+ "] [SocketTimeOut Exception while Connecting to Other application] Error[" + socExe.getMessage()
					+ "]");
			socExe.printStackTrace();
			return -1;
		} catch (ConnectException conExe) {
			errorLogger.error("ErrorCode [SMSGW-SMSGWAR-00011] MSISDN[" + msisdn + "] ShortCode[" + shortcode
					+ "] [Http connection is not established with other application] Error[" + conExe.getMessage()
					+ "]");
			conExe.printStackTrace();
			return -1;
		}

		catch (Exception e) {
			errorLogger.error("ErrorCode [SMSGW-SMSGWAR-00012] MSISDN[" + msisdn + "] ShortCode[" + shortcode
					+ "] [Exception in Converting OLD URL to new URL] Error[" + e.getMessage() + "]");
			e.printStackTrace();
			return -1;
		}
		return 1;
	}

	public int insertDB(String shortcode, String msisdn) {
		logger.info("Short code is [" + shortcode + "] msisdn [" + msisdn + "]");
		String message = "";
		PreparedStatement pstmt3 = null;
		ResultSet rs = null;
		String query = "";
		try {
			query = "select TEMPLATE_MESSAGE from LBS_TEMPLATES where template_id="
					+ AppConfig.config.getInt("INVALID_CODE_TEMPLATE_ID");
			logger.info(query);
			pstmt3 = con.prepareStatement(query);
			rs = pstmt3.executeQuery();
			if (rs.next()) {
				message = rs.getString("TEMPLATE_MESSAGE");
			}
			pstmt3.close();
			rs.close();
			logger.info("message is " + message);
			query = "INSERT INTO GMAT_MESSAGE_STORE(RESPONSE_ID, REQUEST_ID, ORIGINATING_NUMBER, DESTINATION_NUMBER, MESSAGE_TEXT, SUBMIT_TIME, MESSAGE_TYPE, LANGUAGE, UDH, STATUS_REPORT, DATA_CODING_SCHEME, PROTOCOL_IDENTIFIER, VALIDITY_PERIOD, PRIORITY, CHARGING_CODE, STATUS, MESSAGE_ID,INTERFACE_ID, INTERFACE_TYPE) VALUES (GMAT_RESPONSE_ID_SEQ.nextval,GMAT_REQUEST_ID_SEQ.nextval,?,?,?,SYSDATE,1,1,'1',1,1,1,1,1,1,'R', SMSG_MESSAGE_ID.NEXTVAL,?,1)";
			if (AppConfig.config.getString("DB_TYPE").trim().equalsIgnoreCase("1")) {
				query = "INSERT INTO GMAT_MESSAGE_STORE(RESPONSE_ID, REQUEST_ID, ORIGINATING_NUMBER, DESTINATION_NUMBER, MESSAGE_TEXT, SUBMIT_TIME, MESSAGE_TYPE, LANGUAGE, UDH, STATUS_REPORT, DATA_CODING_SCHEME, PROTOCOL_IDENTIFIER, VALIDITY_PERIOD, PRIORITY, CHARGING_CODE, STATUS, MESSAGE_ID,INTERFACE_ID, INTERFACE_TYPE) VALUES (GMAT_RESPONSE_ID_SEQ.nextval,GMAT_REQUEST_ID_SEQ.nextval,?,?,?,SYSDATE,1,1,'1',1,1,1,1,1,1,'R', SMSG_MESSAGE_ID.NEXTVAL,?,1)";
			} else {
				query = "INSERT INTO GMAT_MESSAGE_STORE(ORIGINATING_NUMBER, DESTINATION_NUMBER, MESSAGE_TEXT, SUBMIT_TIME, MESSAGE_TYPE, LANGUAGE, UDH, STATUS_REPORT, DATA_CODING_SCHEME, PROTOCOL_IDENTIFIER, VALIDITY_PERIOD, PRIORITY, CHARGING_CODE, STATUS, MESSAGE_ID,INTERFACE_ID, INTERFACE_TYPE) VALUES (?,?,?,sysdate(),1,1,'1',1,1,1,1,1,1,'R', default,?,1)";
			}

			pstmt3 = con.prepareStatement(query);
			pstmt3.setString(1, shortcode);
			pstmt3.setString(2, msisdn);
			pstmt3.setString(3, message);
			pstmt3.setString(4, msisdn);
			pstmt3.executeUpdate();
			pstmt3.close();
		} catch (SQLException ex) {
			errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90001] MSISDN [" + msisdn + "] Short Code [" + shortcode
					+ "] [SQLException while insert record into gmat_message_store] ERROR [" + ex.getMessage() + "]");
			ex.printStackTrace();
			return -1;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [SMSGW-SMSGWAR-00012]  Destination Number [" + msisdn + "] Short Code ["
					+ shortcode + "][Exception when insert rcord into gmat_message_store in Hit Url class] ERROR ["
					+ e.getMessage() + "]");
			e.printStackTrace();
			return -1;
		}

		finally {
			try {
				if (pstmt3 != null)
					pstmt3.close();
				if (rs != null)
					rs.close();
				con.commit();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return 1;
	}

}
