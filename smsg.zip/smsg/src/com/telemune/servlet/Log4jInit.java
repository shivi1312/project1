/*
 * Log4jInit.java
 *
 * Created on October 13, 2004, 12:35 PM
 */

package com.telemune.servlet;

import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.xml.DOMConfigurator;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.io.IOException;

public class Log4jInit extends HttpServlet {

  public  void init() {
    String prefix =  getServletContext().getRealPath("/");
    String file = getInitParameter("log4j-init-file");
    // if the log4j-init-file is not set, then no point in trying
    if(file != null) {
        DOMConfigurator.configureAndWatch(prefix+file);
        //PropertyConfigurator.configure(prefix+file);
    }
  }
}