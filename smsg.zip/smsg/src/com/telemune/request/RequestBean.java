package com.telemune.request;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "RequestBean")
public class RequestBean {

	
	private String msisdn;
	
	private String message;

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
	
	
}
