package com.telemune.domain;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.AppConfig;
import com.telemune.dbutilities.ConnectionPool;



public class GmatMessageStore {
	final static Logger logger = Logger.getLogger(GmatMessageStore.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");	

	Connection con=null;
public void inserIntoGmat(Map<String,String> paramMap)
{
	PreparedStatement pstmt=null;
	logger.info("Inside function when insert into gmat message store map size ["+paramMap.size()+"]");
	
	String paramQuery="";
	String valueParam="";
	String query="";
	String key="";
	String value="";
			
                        try
                        {
                        	con=ConnectionPool.getInstance().getConnection();
                        	Set<String> mapValue=paramMap.keySet();
                        	Iterator<String> it=mapValue.iterator();
                        	while(it.hasNext())
                        	{
                        		key=(String)it.next();
                        		value=(String)paramMap.get(key);
                        		paramQuery=paramQuery+key+",";
                        		valueParam=valueParam+value+",";
                        		
                        	}
                        	paramQuery=paramQuery.substring(0,paramQuery.lastIndexOf(","));
                        	valueParam=valueParam.substring(0, valueParam.lastIndexOf(","));
                        	                       
                        query="INSERT INTO "+AppConfig.config.getString("GMAT_MESSAGE_STORE")+" ("+paramQuery+") VALUES ("+valueParam+")";
                        logger.info("query is ["+query+"]");
                        pstmt=con.prepareStatement(query);
                       pstmt.executeUpdate();
                        pstmt.close();
                        con.close();
                        }
                        catch(SQLException ex)
                        {
                			errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90001] Destination Number ["+paramMap.get("DESTINATION_NUMBER")+"] Message Text ["+paramMap.get("MESSAGE_TEXT")+"] [SQLException while insert record into gmat_message_store] ERROR ["+ex.getMessage()+"]");
                			ex.printStackTrace();
                        }
                        catch(Exception e)
                        {
                        	errorLogger.error("ErrorCode [SMSGW-SMSGWAR-00004]  Destination Number ["+paramMap.get("DESTINATION_NUMBER")+"] Message Text ["+paramMap.get("MESSAGE_TEXT")+"][Exception while insert record into gmat_message_store] ERROR ["+e.getMessage()+"]");
                              e.printStackTrace();
                        }
                        finally
                        	{
                        		try
                        			{
                        				if(pstmt!=null)pstmt.close();
                        				if(con!=null)con.close();
                        			}
                        		catch(Exception ex)
                        			{
                        			errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90001] Destination Number ["+paramMap.get("DESTINATION_NUMBER")+"] Message Text ["+paramMap.get("MESSAGE_TEXT")+"] [SQLException while closing connection from data base] ERROR ["+ex.getMessage()+"]");
                                	ex.printStackTrace();
                        			}
                        	}
                       

			}
}
