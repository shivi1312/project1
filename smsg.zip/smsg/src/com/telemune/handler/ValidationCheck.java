package com.telemune.handler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.AppConfig;
import com.telemune.response.ResponseBean;
import com.telemune.smsg.dao.FieldBean;

public class ValidationCheck {
	final static Logger logger = Logger.getLogger(ValidationCheck.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	
	public String validation(String paramValue, FieldBean validateParam,ResponseBean responseBean) {
		logger.info("check parameter is [" + validateParam.getValidation().getRequired().isCheck() + "]");
		try {
			
			if(validateParam.getParamType().equalsIgnoreCase("S"))
			{
				logger.info("Inside condition when set default values of parameters");
				responseBean.setMessage(AppConfig.config.getString("SUCCESS_MESSAGE","success"));
				responseBean.setStatus(AppConfig.config.getString("SUCCESS","success"));
				return "default";
			}
			if (!checkRequiredValidation(paramValue, validateParam)) {
				responseBean.setMessage(validateParam.getValidation().getRequired().getMsg());
				responseBean.setStatus(AppConfig.config.getString("FAIL_STATUS","failure"));
				return "failure";
			}
			if (!checkNumberValidation(paramValue, validateParam)) {
				responseBean.setMessage(validateParam.getValidation().getNumber().getMsg());
				responseBean.setStatus(AppConfig.config.getString("FAIL_STATUS","failure"));
				return "failure";
			}
			if (!checkLengthValidation(paramValue, validateParam)) {
				responseBean.setMessage(validateParam.getValidation().getLength().getMsg());
				responseBean.setStatus(AppConfig.config.getString("FAIL_STATUS","failure"));
				return "failure";
			}
			if (!checkRangeValidation(paramValue, validateParam)) {
				responseBean.setMessage(validateParam.getValidation().getRange().getMsg());
				responseBean.setStatus(AppConfig.config.getString("FAIL_STATUS","failure"));
				return "failure";
			}
			if (!checkValuesValidation(paramValue, validateParam)) {
				responseBean.setMessage(validateParam.getValidation().getValues().getMsg());
				responseBean.setStatus(AppConfig.config.getString("FAIL_STATUS","failure"));
				return "failure";
			}
			
			responseBean.setMessage(AppConfig.config.getString("SUCCESS_MESSAGE", "success"));
			responseBean.setStatus(AppConfig.config.getString("SUCCESS","success"));
		
			if(paramValue.equalsIgnoreCase("")||paramValue==null)
			{
				logger.debug("Inside condition when set default value of received parameter");
				return "default";
			}
/*
			responseBean.setMessage(AppConfig.config.getString("SUCCESS_MESSAGE", "success"));
			responseBean.setStatus("Success");*/
			return "success";

		} catch (Exception e) {
			errorLogger.error("Erroe [SMSGW-SMSGWAR-00008] value ["+paramValue+"[Exception while validate input parameter] ERROR ["+e.getMessage()+"]");
			responseBean.setMessage("Failure");
			responseBean.setStatus(AppConfig.config.getString("FAIL_STATUS","failure"));
			e.printStackTrace();
			return "failure";
		}

	}

	public boolean checkRequiredValidation(String paramValue, FieldBean validateParam) {
		logger.debug("Inside CheckRequired field");
		if (validateParam.getValidation().getRequired().isCheck()) {
			if (paramValue.equalsIgnoreCase("") || paramValue == null) {
				logger.info("Inside condition when param value is null");
				return false;
			} else {
				logger.debug("Inside success condition");
				return true;
			}
		} else {
			logger.debug("Inside condition when Check parameter is false");
			return true;
		}

	}

	public boolean checkLengthValidation(String paramValue, FieldBean validateParam) {
		logger.debug("Inside length validation field");
		if (validateParam.getValidation().getLength().isCheck()) {
			logger.debug("Length of parameter is ["+paramValue.length()+"] min length in xml ["+validateParam.getValidation().getLength().getMinLength()+"] max length ["+validateParam.getValidation().getLength().getMaxLength()+"]");
			if (paramValue.length()<validateParam.getValidation().getLength().getMinLength() || paramValue.length()>validateParam.getValidation().getLength().getMaxLength())
			{
				logger.info("Inside condition when Field length is not valid");
				return false;
			} else {
				logger.debug("Inside success condition");
				return true;
			}
		} else {
			logger.debug("Inside condition when Check parameter is false");
			
			return true;
		}

	}

	public boolean checkNumberValidation(String paramValue, FieldBean validateParam) {
		
		logger.debug("Inside Check number validation field");
		if (validateParam.getValidation().getNumber().isCheck()) {
			if (!paramValue.matches("[0-9]+")) {
				logger.info("Wrong insertion of data");
				return false;
			} else {
				logger.debug("Inside success condition");
				return true;
			}
		} else {
			logger.debug("Inside condition when Check parameter is false");
			return true;
		}

	}
	
	public boolean checkRangeValidation(String paramValue, FieldBean validateParam) {
		logger.debug("Inside CheckRange validation field");
		if (validateParam.getValidation().getRange().isCheck()) {
			logger.debug("Range is ["+paramValue.length()+"] min range in xml ["+validateParam.getValidation().getRange().getMinRange()+"] max range ["+validateParam.getValidation().getRange().getMaxRange()+"]");
			if (Long.parseLong(paramValue)<validateParam.getValidation().getRange().getMinRange() || Long.parseLong(paramValue)>validateParam.getValidation().getRange().getMaxRange())
			{
				logger.info("Inside condition when Range is not valid");
				return false;
			} else {
				logger.debug("Inside success condition");
				return true;
			}
		} else {
			logger.debug("Inside condition when Check parameter is false");
			
			return true;
		}

	}
	public boolean checkValuesValidation(String paramValue, FieldBean validateParam) {
		logger.debug("Inside Checkvalue validation field");
		if (validateParam.getValidation().getValues().isCheck())
		{
			logger.info("Value is ["+paramValue+"] xml values is ["+validateParam.getValidation().getValues().getValue()+"]");
			List<String> listValue=new ArrayList<String>(Arrays.asList(validateParam.getValidation().getValues().getValue().split(",")));
			logger.info("List value is["+listValue+"] size of list is ["+listValue.size()+"]");
			if(listValue.contains(paramValue))
			{
				logger.debug("List contain received value");
				return true; 
			}
			else
			{
				logger.info("Inside condition when values are not defined");
				return false;
			}
		}
		else
		{
			logger.debug("Inside condition when Check parameter is false");
			return true;
		}
	

	}

	
}
