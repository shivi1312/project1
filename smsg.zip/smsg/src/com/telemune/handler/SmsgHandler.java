			package com.telemune.handler;


import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.AppConfig;
import com.telemune.domain.GmatMessageStore;
import com.telemune.response.ResponseBean;

import com.telemune.smsg.dao.Table;

public class SmsgHandler {
	final static Logger logger = Logger.getLogger(SmsgHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");	

	static Table customer = null;
	public ResponseBean responseBean = null;
	public GmatMessageStore gmatMsgStore=null;
	ValidationCheck validate=null;

/**
 * This static block parse configured XML into bean Class
 */
	static {
		try {
				JAXBContext jc = JAXBContext.newInstance(Table.class);
				String catHome = System.getenv("PROPERTY_FILE_PATH");
				if(catHome==null)
				{
					catHome="/home/swati/.config/property/";	
				}
				StreamSource xml = new StreamSource(catHome+"/param_config.xml");
				Unmarshaller unmarshaller = jc.createUnmarshaller();
				JAXBElement<Table> je1 = unmarshaller.unmarshal(xml, Table.class);
				customer = je1.getValue();
			// Fetch particular field
				logger.debug("bean is["+customer.toString()+"]");
			} 
		
		catch(NullPointerException e)
		{
			errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90003] [NullPointerException while reading and getting config.xml file] ERROR ["+e.getMessage()+"]");
			e.printStackTrace();
		}
		
		catch (Exception e) {
			errorLogger.error("Erroe [SMSGW-SMSGWAR-00006] [Exception in reading and getting config.xml file] ERROR ["+e.getMessage()+"]");
			e.printStackTrace();
			}
		}

	/**
	 * 
	 * @param smsgReq : Requested map that will received from Client side
	 * @param responseBean : Response that send to user according 
	 * @return Boolean value true in case of success and false in case of failure
	 */
	public boolean processReq(Map<String, String> smsgReq,ResponseBean responseBean) 
	{
		String columnName = null; 
		String status="";
		Map<String, String> smsgMap = new HashMap<String, String>();
		String columnValue="";
		validate=new ValidationCheck();
			try
				{
					logger.info("Inside processReq() received map is ["+smsgReq+"]");
					for (int i = 0; i < customer.getField().size(); i++) {
					columnName = customer.getField().get(i).getColumn().toString();
					logger.debug("Column name"+columnName);
					
					if (smsgReq.containsKey(customer.getField().get(i).getParam())) 
					{	//Check Received parameter is optional 
						if(customer.getField().get(i).getParamType().equalsIgnoreCase("O"))
							{
								if(smsgReq.get(customer.getField().get(i).getParam())==null || smsgReq.get(customer.getField().get(i).getParam()).equalsIgnoreCase(""))
									{ //put default value into MAP
										logger.info("Default value is set to ["+smsgReq.get(customer.getField().get(i).getParam())+"] Field value");
										smsgReq.put(customer.getField().get(i).getParam(),customer.getField().get(i).getDefaultvalue());
									}
							}
						//Check validation on received request
						status= validate.validation(smsgReq.get(customer.getField().get(i).getParam()),
						customer.getField().get(i),responseBean);
				 
						if(status.equalsIgnoreCase("failure"))
						{
							return false;
						}
						else if(status.equalsIgnoreCase("default"))
							{
								logger.info("param is ["+customer.getField().get(i).getParam()+" default value is"+customer.getField().get(i).getDefaultvalue()+"]");
								smsgReq.remove(customer.getField().get(i).getParam());
								smsgReq.put(customer.getField().get(i).getParam(),customer.getField().get(i).getDefaultvalue());	
								logger.debug("value of updated key is ["+smsgReq.get(customer.getField().get(i).getParam())+"]");
							}
				 
						if(customer.getField().get(i).getColumnType().equalsIgnoreCase("string"))
							{
								columnValue= "'"+smsgReq.get(customer.getField().get(i).getParam())+"'";
							}
						else
							{
								columnValue= smsgReq.get(customer.getField().get(i).getParam());
							}
						smsgMap.put(columnName,columnValue);
				
						logger.info("key [" + columnName + "] value [" + smsgMap.get(columnName) + "]");
					} 
					else 
						{
						//Checking mandatory parameter is received or not
							if(customer.getField().get(i).getParamType().equalsIgnoreCase("M"))
								{
									logger.info("Mandatory field is missing"+customer.getField().get(i).getParam());
									responseBean.setMessage(customer.getField().get(i).getParam()+" is mandatory to Receive");
									responseBean.setStatus(AppConfig.config.getString("FAIL_STATUS","failure"));
									return false;
								}
							else
								{
								//Set Default value of optional and static parameters
									responseBean.setMessage(AppConfig.config.getString("SUCCESS_MESSAGE","success"));
									if(customer.getField().get(i).getColumnType().equalsIgnoreCase("string"))
										{
											columnValue= "'"+customer.getField().get(i).getDefaultvalue()+"'";
										}
									else
										{
											columnValue=customer.getField().get(i).getDefaultvalue();
										}
									smsgMap.put(columnName,columnValue);
									logger.info("key [" + columnName + "] value [" + smsgMap.get(columnName) + "]");
								}
						}
			
			
			
					}
		//Insert into gmat message store
					gmatMsgStore=new GmatMessageStore();
					gmatMsgStore.inserIntoGmat(smsgMap);
					logger.info("Response bean is" +responseBean.toString());
		}
			catch(NullPointerException e)
			{
				errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90003] [NullPointerException while validating received data and stored data into hashmap] ERROR ["+e.getMessage()+"]");
				e.printStackTrace();
			}
			catch (NumberFormatException e) {
				errorLogger.error("ErrorCode [SMSGW-SMSGWAR-90004] [NumberFormatException while storing data into hashMap] ERROR ["+e.getMessage()+"]");
				e.printStackTrace();
			}
		catch(Exception e)
			{
			errorLogger.error("Erroe [SMSGW-SMSGWAR-00007] [Exception in Process request() when processing data getting from user] ERROR ["+e.getMessage()+"]");
			e.printStackTrace();
				return false;
			}
			return true;
		}

	
}
