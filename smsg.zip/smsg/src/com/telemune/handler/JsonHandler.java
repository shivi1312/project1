package com.telemune.handler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONException;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.telemune.dbutilities.AppConfig;
import com.telemune.response.ResponseBean;

public class JsonHandler {
	final static Logger logger = Logger.getLogger(JsonHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	
	private JsonParser parser = new JsonParser();
	private Gson gson = new Gson();
	@SuppressWarnings("unused")
	private ResponseBean responseBean = null;
	private SmsgHandler smsgHandler = null;
	private List<ResponseBean> responseList = new ArrayList<ResponseBean>();

	public List<ResponseBean> JsonParse(String json, ResponseBean responseBean) {
		try {
			smsgHandler = new SmsgHandler();
			JsonArray jsonArr = parser.parse(json).getAsJsonArray();
			
			if (jsonArr.size() > smsgHandler.customer.getMsgLength()) {
				logger.info("Message length is greater than [" + smsgHandler.customer.getMsgLength() + "]");
				responseBean.setMessage(AppConfig.config.getString("MSG_COUNT_MSG","Invalid message count"));
				responseBean.setStatus(AppConfig.config.getString("FAIL_STATUS","failure"));
				responseList.add(responseBean);
				System.out.println("Size of response bean is ["+responseList.size()+"]");
			}
			else
			{
			for (JsonElement el : jsonArr) {
				Map<String, String> jsonMap = gson.fromJson(el.getAsJsonObject().toString(),
						new TypeToken<Map<String, String>>() {
						}.getType());
				responseBean = new ResponseBean();
				System.out.println("Json Map data is [" + jsonMap + "]");
				boolean status = smsgHandler.processReq(jsonMap, responseBean);
				logger.info("status [" + status + "] response:-profile.check  " + gson.toJson(responseBean));
				System.out.println("response bean is" + responseBean);
				responseList.add(responseBean);
				System.out.println("response bean size is" + responseList.size() + "list is " + responseList);
			}
			}

			System.out.println("List is" + responseList);

		} 
		
		catch (Exception e) {
			errorLogger.error("Erroe [SMSGW-SMSGWAR-00005] [Exception in parsing json array] ERROR ["+e.getMessage()+"]");
			e.printStackTrace();
		}

		return responseList;
	}

}
