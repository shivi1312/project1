package com.redhat.springMvc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.redhat.springMvc.model.Alien;

@Controller
public class HomeController {

	
	
	
	
	@RequestMapping("/")
	public String home()
	{
		System.out.println("home page requested.");
		return "index";
	}
	
	// First way to do get parameter from jsp and send parameter to jsp
	@RequestMapping("/add1")
	public String add1(HttpServletRequest req)
	{
		System.out.println("inside add()....");
		int i = Integer.parseInt(req.getParameter("num1"));
		int j = Integer.parseInt(req.getParameter("num2"));
		int num3=i+j;
		HttpSession session=req.getSession();
		session.setAttribute("res", num3);
		return "result.jsp";
	}
	
	// Second way to do get parameter from jsp and send parameter to jsp
	@RequestMapping("/add2")
	public String add2(@RequestParam("num1") int i,@RequestParam("num2") int j, HttpSession session)
	{
		System.out.println("inside add()....");
		
		int num3=i+j;
		session.setAttribute("res", num3);
		return "result.jsp";
	}
	
	
	// Third way to do get parameter from jsp and send parameter to jsp (SPRING Way) recommended
		@RequestMapping("/add3")
		public ModelAndView add3(@RequestParam("num1") int i,@RequestParam("num2") int j, ModelAndView mv)
		{
			System.out.println("inside add()....");
			mv.setViewName("result.jsp");
			int num3=i+j;
			mv.addObject("res", num3);
			return mv;
		}
		
		// Fourth way to do get parameter from jsp and send parameter to jsp (SPRING Way)
				@RequestMapping("/add4")
				public String add4(@RequestParam("num1") int i,@RequestParam("num2") int j, Model m)
				{
					System.out.println("inside add()....");
					
					int num3=i+j;
					m.addAttribute("res", num3);
					return "result.jsp";
				}
		
		// Remove .jsp extention and put all jsp file in view folder.
		@RequestMapping("/add")
		public ModelAndView add(@RequestParam("num1") int i,@RequestParam("num2") int j, ModelAndView mv)
		{
			System.out.println("inside add()....");
			mv.setViewName("result");
			int num3=i+j;
			mv.addObject("res", num3);
			return mv;
		}
		
		
		// First way
		@RequestMapping("/addAlien1")
		public String addAlien1(@RequestParam("aid") int aid,@RequestParam("aname") String aname, Model m)
		{
			Alien a = new Alien();
			a.setAid(aid);
			a.setAname(aname);
			m.addAttribute("alien",a);
			return "result";
		}
		
		
		// Second way (Spring) recommended Here @ModelAttribure set all the jsp parameter 
		// in Alien bean and did the work or @Model also
		@RequestMapping("/addAlien2")
		public String addAlien2(@ModelAttribute Alien alien)
		{
			return "result";
		}
		
		// Here we use different name alien other than al 
		// It can also work if we remove @ModelAttribute we just have to change alien to al in result.jsp
		@RequestMapping("/addAlien")
		public String addAlien(@ModelAttribute("alien") Alien al)
		{
			return "result";
		}
		
		// ModelAttribute at method level
		// this @ModelAttribute is called before the  @RequestMapping and
		// add the attribute in Model
		@ModelAttribute
		public void modelData(Model m)
		{
			m.addAttribute("name","Sanchit");
			System.out.println("inside modelData");
		}
	
}

