package tele.common.filebase;

import org.apache.log4j.Logger;

public class Logging {
	final static Logger logger = Logger.getLogger(Logging.class);
	public void write(String msg){
		logger.info(msg);
	}
}
