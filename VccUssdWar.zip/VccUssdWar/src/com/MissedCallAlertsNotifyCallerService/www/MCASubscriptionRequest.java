/**
 * MCASubscriptionRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.MissedCallAlertsNotifyCallerService.www;

public class MCASubscriptionRequest  implements java.io.Serializable {
    private java.lang.String MSISDN;

    private java.lang.String serviceType;

    private java.lang.String language;

    private com.MissedCallAlertsNotifyCallerService.www.SMSFormat SMSFormat;

    private com.MissedCallAlertsNotifyCallerService.www.Status status;

    private com.MissedCallAlertsNotifyCallerService.www.COS COS;

    public MCASubscriptionRequest() {
    }

    public MCASubscriptionRequest(
           java.lang.String MSISDN,
           java.lang.String serviceType,
           java.lang.String language,
           com.MissedCallAlertsNotifyCallerService.www.SMSFormat SMSFormat,
           com.MissedCallAlertsNotifyCallerService.www.Status status,
           com.MissedCallAlertsNotifyCallerService.www.COS COS) {
           this.MSISDN = MSISDN;
           this.serviceType = serviceType;
           this.language = language;
           this.SMSFormat = SMSFormat;
           this.status = status;
           this.COS = COS;
    }


    /**
     * Gets the MSISDN value for this MCASubscriptionRequest.
     * 
     * @return MSISDN
     */
    public java.lang.String getMSISDN() {
        return MSISDN;
    }


    /**
     * Sets the MSISDN value for this MCASubscriptionRequest.
     * 
     * @param MSISDN
     */
    public void setMSISDN(java.lang.String MSISDN) {
        this.MSISDN = MSISDN;
    }


    /**
     * Gets the serviceType value for this MCASubscriptionRequest.
     * 
     * @return serviceType
     */
    public java.lang.String getServiceType() {
        return serviceType;
    }


    /**
     * Sets the serviceType value for this MCASubscriptionRequest.
     * 
     * @param serviceType
     */
    public void setServiceType(java.lang.String serviceType) {
        this.serviceType = serviceType;
    }


    /**
     * Gets the language value for this MCASubscriptionRequest.
     * 
     * @return language
     */
    public java.lang.String getLanguage() {
        return language;
    }


    /**
     * Sets the language value for this MCASubscriptionRequest.
     * 
     * @param language
     */
    public void setLanguage(java.lang.String language) {
        this.language = language;
    }


    /**
     * Gets the SMSFormat value for this MCASubscriptionRequest.
     * 
     * @return SMSFormat
     */
    public com.MissedCallAlertsNotifyCallerService.www.SMSFormat getSMSFormat() {
        return SMSFormat;
    }


    /**
     * Sets the SMSFormat value for this MCASubscriptionRequest.
     * 
     * @param SMSFormat
     */
    public void setSMSFormat(com.MissedCallAlertsNotifyCallerService.www.SMSFormat SMSFormat) {
        this.SMSFormat = SMSFormat;
    }


    /**
     * Gets the status value for this MCASubscriptionRequest.
     * 
     * @return status
     */
    public com.MissedCallAlertsNotifyCallerService.www.Status getStatus() {
        return status;
    }


    /**
     * Sets the status value for this MCASubscriptionRequest.
     * 
     * @param status
     */
    public void setStatus(com.MissedCallAlertsNotifyCallerService.www.Status status) {
        this.status = status;
    }


    /**
     * Gets the COS value for this MCASubscriptionRequest.
     * 
     * @return COS
     */
    public com.MissedCallAlertsNotifyCallerService.www.COS getCOS() {
        return COS;
    }


    /**
     * Sets the COS value for this MCASubscriptionRequest.
     * 
     * @param COS
     */
    public void setCOS(com.MissedCallAlertsNotifyCallerService.www.COS COS) {
        this.COS = COS;
    }

    private java.lang.Object __equalsCalc = null;
    @Override
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MCASubscriptionRequest)) return false;
        MCASubscriptionRequest other = (MCASubscriptionRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.MSISDN==null && other.getMSISDN()==null) || 
             (this.MSISDN!=null &&
              this.MSISDN.equals(other.getMSISDN()))) &&
            ((this.serviceType==null && other.getServiceType()==null) || 
             (this.serviceType!=null &&
              this.serviceType.equals(other.getServiceType()))) &&
            ((this.language==null && other.getLanguage()==null) || 
             (this.language!=null &&
              this.language.equals(other.getLanguage()))) &&
            ((this.SMSFormat==null && other.getSMSFormat()==null) || 
             (this.SMSFormat!=null &&
              this.SMSFormat.equals(other.getSMSFormat()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.COS==null && other.getCOS()==null) || 
             (this.COS!=null &&
              this.COS.equals(other.getCOS())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    @Override
	public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMSISDN() != null) {
            _hashCode += getMSISDN().hashCode();
        }
        if (getServiceType() != null) {
            _hashCode += getServiceType().hashCode();
        }
        if (getLanguage() != null) {
            _hashCode += getLanguage().hashCode();
        }
        if (getSMSFormat() != null) {
            _hashCode += getSMSFormat().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getCOS() != null) {
            _hashCode += getCOS().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MCASubscriptionRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.MissedCallAlertsNotifyCallerService.com/", ">MCASubscriptionRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSISDN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSISDN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ServiceType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("language");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Language"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SMSFormat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SMSFormat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.MissedCallAlertsNotifyCallerService.com/", "SMSFormat"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.MissedCallAlertsNotifyCallerService.com/", "Status"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("COS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "COS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.MissedCallAlertsNotifyCallerService.com/", "COS"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
