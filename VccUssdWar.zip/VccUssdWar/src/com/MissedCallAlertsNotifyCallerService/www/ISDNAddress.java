/**
 * ISDNAddress.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.MissedCallAlertsNotifyCallerService.www;

public class ISDNAddress  implements java.io.Serializable {
    private byte NAI;

    private byte NPI;

    private byte ES;

    private byte SI;

    private byte APRI;

    private byte NII;

    private byte INNI;

    private byte NQI;

    private java.lang.String digits;

    public ISDNAddress() {
    }

    public ISDNAddress(
           byte NAI,
           byte NPI,
           byte ES,
           byte SI,
           byte APRI,
           byte NII,
           byte INNI,
           byte NQI,
           java.lang.String digits) {
           this.NAI = NAI;
           this.NPI = NPI;
           this.ES = ES;
           this.SI = SI;
           this.APRI = APRI;
           this.NII = NII;
           this.INNI = INNI;
           this.NQI = NQI;
           this.digits = digits;
    }


    /**
     * Gets the NAI value for this ISDNAddress.
     * 
     * @return NAI
     */
    public byte getNAI() {
        return NAI;
    }


    /**
     * Sets the NAI value for this ISDNAddress.
     * 
     * @param NAI
     */
    public void setNAI(byte NAI) {
        this.NAI = NAI;
    }


    /**
     * Gets the NPI value for this ISDNAddress.
     * 
     * @return NPI
     */
    public byte getNPI() {
        return NPI;
    }


    /**
     * Sets the NPI value for this ISDNAddress.
     * 
     * @param NPI
     */
    public void setNPI(byte NPI) {
        this.NPI = NPI;
    }


    /**
     * Gets the ES value for this ISDNAddress.
     * 
     * @return ES
     */
    public byte getES() {
        return ES;
    }


    /**
     * Sets the ES value for this ISDNAddress.
     * 
     * @param ES
     */
    public void setES(byte ES) {
        this.ES = ES;
    }


    /**
     * Gets the SI value for this ISDNAddress.
     * 
     * @return SI
     */
    public byte getSI() {
        return SI;
    }


    /**
     * Sets the SI value for this ISDNAddress.
     * 
     * @param SI
     */
    public void setSI(byte SI) {
        this.SI = SI;
    }


    /**
     * Gets the APRI value for this ISDNAddress.
     * 
     * @return APRI
     */
    public byte getAPRI() {
        return APRI;
    }


    /**
     * Sets the APRI value for this ISDNAddress.
     * 
     * @param APRI
     */
    public void setAPRI(byte APRI) {
        this.APRI = APRI;
    }


    /**
     * Gets the NII value for this ISDNAddress.
     * 
     * @return NII
     */
    public byte getNII() {
        return NII;
    }


    /**
     * Sets the NII value for this ISDNAddress.
     * 
     * @param NII
     */
    public void setNII(byte NII) {
        this.NII = NII;
    }


    /**
     * Gets the INNI value for this ISDNAddress.
     * 
     * @return INNI
     */
    public byte getINNI() {
        return INNI;
    }


    /**
     * Sets the INNI value for this ISDNAddress.
     * 
     * @param INNI
     */
    public void setINNI(byte INNI) {
        this.INNI = INNI;
    }


    /**
     * Gets the NQI value for this ISDNAddress.
     * 
     * @return NQI
     */
    public byte getNQI() {
        return NQI;
    }


    /**
     * Sets the NQI value for this ISDNAddress.
     * 
     * @param NQI
     */
    public void setNQI(byte NQI) {
        this.NQI = NQI;
    }


    /**
     * Gets the digits value for this ISDNAddress.
     * 
     * @return digits
     */
    public java.lang.String getDigits() {
        return digits;
    }


    /**
     * Sets the digits value for this ISDNAddress.
     * 
     * @param digits
     */
    public void setDigits(java.lang.String digits) {
        this.digits = digits;
    }

    private java.lang.Object __equalsCalc = null;
    @Override
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ISDNAddress)) return false;
        ISDNAddress other = (ISDNAddress) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.NAI == other.getNAI() &&
            this.NPI == other.getNPI() &&
            this.ES == other.getES() &&
            this.SI == other.getSI() &&
            this.APRI == other.getAPRI() &&
            this.NII == other.getNII() &&
            this.INNI == other.getINNI() &&
            this.NQI == other.getNQI() &&
            ((this.digits==null && other.getDigits()==null) || 
             (this.digits!=null &&
              this.digits.equals(other.getDigits())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    @Override
	public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getNAI();
        _hashCode += getNPI();
        _hashCode += getES();
        _hashCode += getSI();
        _hashCode += getAPRI();
        _hashCode += getNII();
        _hashCode += getINNI();
        _hashCode += getNQI();
        if (getDigits() != null) {
            _hashCode += getDigits().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ISDNAddress.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.MissedCallAlertsNotifyCallerService.com/", "ISDNAddress"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NAI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "NAI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "byte"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NPI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "NPI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "byte"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ES");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ES"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "byte"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "byte"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("APRI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "APRI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "byte"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NII");
        elemField.setXmlName(new javax.xml.namespace.QName("", "NII"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "byte"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INNI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "INNI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "byte"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NQI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "NQI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "byte"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("digits");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Digits"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
