/**
 * NotifyCallerPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.MissedCallAlertsNotifyCallerService.www;

public interface NotifyCallerPortType extends java.rmi.Remote {
    public com.MissedCallAlertsNotifyCallerService.www.MCASubscriptionResponse MCASubscription(com.MissedCallAlertsNotifyCallerService.www.MCASubscriptionRequest MCASubscriptionRequest) throws java.rmi.RemoteException;
    public com.MissedCallAlertsNotifyCallerService.www.MCAUnsubscriptionResponse MCAUnsubscription(com.MissedCallAlertsNotifyCallerService.www.MCAUnsubscriptionRequest MCAUnsubscriptionRequest) throws java.rmi.RemoteException;
    public com.MissedCallAlertsNotifyCallerService.www.ModifyNotificationLanguageResponse modifyNotificationLanguage(com.MissedCallAlertsNotifyCallerService.www.ModifyNotificationLanguageRequest modifyNotificationLanguageRequest) throws java.rmi.RemoteException;
    public com.MissedCallAlertsNotifyCallerService.www.CallTriggerResponse callTrigger(com.MissedCallAlertsNotifyCallerService.www.CallTriggerRequest callTriggerRequest) throws java.rmi.RemoteException;
}
