package com.MissedCallAlertsNotifyCallerService.www;

public class NotifyCallerPortTypeProxy implements com.MissedCallAlertsNotifyCallerService.www.NotifyCallerPortType {
  private String _endpoint = null;
  private com.MissedCallAlertsNotifyCallerService.www.NotifyCallerPortType notifyCallerPortType = null;
  
  public NotifyCallerPortTypeProxy() {
    _initNotifyCallerPortTypeProxy();
  }
  
  public NotifyCallerPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initNotifyCallerPortTypeProxy();
  }
  
  private void _initNotifyCallerPortTypeProxy() {
    try {
      notifyCallerPortType = (new com.MissedCallAlertsNotifyCallerService.www.MCANotifyCallerServiceLocator()).getNotifyCallerPort();
      if (notifyCallerPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)notifyCallerPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)notifyCallerPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (notifyCallerPortType != null)
      ((javax.xml.rpc.Stub)notifyCallerPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.MissedCallAlertsNotifyCallerService.www.NotifyCallerPortType getNotifyCallerPortType() {
    if (notifyCallerPortType == null)
      _initNotifyCallerPortTypeProxy();
    return notifyCallerPortType;
  }
  
  @Override
public com.MissedCallAlertsNotifyCallerService.www.MCASubscriptionResponse MCASubscription(com.MissedCallAlertsNotifyCallerService.www.MCASubscriptionRequest MCASubscriptionRequest) throws java.rmi.RemoteException{
    if (notifyCallerPortType == null)
      _initNotifyCallerPortTypeProxy();
    return notifyCallerPortType.MCASubscription(MCASubscriptionRequest);
  }
  
  @Override
public com.MissedCallAlertsNotifyCallerService.www.MCAUnsubscriptionResponse MCAUnsubscription(com.MissedCallAlertsNotifyCallerService.www.MCAUnsubscriptionRequest MCAUnsubscriptionRequest) throws java.rmi.RemoteException{
    if (notifyCallerPortType == null)
      _initNotifyCallerPortTypeProxy();
    return notifyCallerPortType.MCAUnsubscription(MCAUnsubscriptionRequest);
  }
  
  @Override
public com.MissedCallAlertsNotifyCallerService.www.ModifyNotificationLanguageResponse modifyNotificationLanguage(com.MissedCallAlertsNotifyCallerService.www.ModifyNotificationLanguageRequest modifyNotificationLanguageRequest) throws java.rmi.RemoteException{
    if (notifyCallerPortType == null)
      _initNotifyCallerPortTypeProxy();
    return notifyCallerPortType.modifyNotificationLanguage(modifyNotificationLanguageRequest);
  }
  
  @Override
public com.MissedCallAlertsNotifyCallerService.www.CallTriggerResponse callTrigger(com.MissedCallAlertsNotifyCallerService.www.CallTriggerRequest callTriggerRequest) throws java.rmi.RemoteException{
    if (notifyCallerPortType == null)
      _initNotifyCallerPortTypeProxy();
    return notifyCallerPortType.callTrigger(callTriggerRequest);
  }
  
  
}