/**
 * CallTriggerRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.MissedCallAlertsNotifyCallerService.www;

public class CallTriggerRequest  implements java.io.Serializable {
    private com.MissedCallAlertsNotifyCallerService.www.ISDNAddress AParty;

    private com.MissedCallAlertsNotifyCallerService.www.ISDNAddress BParty;

    private com.MissedCallAlertsNotifyCallerService.www.ISDNAddress OCN;

    private com.MissedCallAlertsNotifyCallerService.www.ISDNAddress RDN;

    private java.math.BigInteger serviceKey;

    private java.math.BigInteger reasonCode;

    private com.MissedCallAlertsNotifyCallerService.www.CallTriggerRequestServiceType serviceType;

    public CallTriggerRequest() {
    }

    public CallTriggerRequest(
           com.MissedCallAlertsNotifyCallerService.www.ISDNAddress AParty,
           com.MissedCallAlertsNotifyCallerService.www.ISDNAddress BParty,
           com.MissedCallAlertsNotifyCallerService.www.ISDNAddress OCN,
           com.MissedCallAlertsNotifyCallerService.www.ISDNAddress RDN,
           java.math.BigInteger serviceKey,
           java.math.BigInteger reasonCode,
           com.MissedCallAlertsNotifyCallerService.www.CallTriggerRequestServiceType serviceType) {
           this.AParty = AParty;
           this.BParty = BParty;
           this.OCN = OCN;
           this.RDN = RDN;
           this.serviceKey = serviceKey;
           this.reasonCode = reasonCode;
           this.serviceType = serviceType;
    }


    /**
     * Gets the AParty value for this CallTriggerRequest.
     * 
     * @return AParty
     */
    public com.MissedCallAlertsNotifyCallerService.www.ISDNAddress getAParty() {
        return AParty;
    }


    /**
     * Sets the AParty value for this CallTriggerRequest.
     * 
     * @param AParty
     */
    public void setAParty(com.MissedCallAlertsNotifyCallerService.www.ISDNAddress AParty) {
        this.AParty = AParty;
    }


    /**
     * Gets the BParty value for this CallTriggerRequest.
     * 
     * @return BParty
     */
    public com.MissedCallAlertsNotifyCallerService.www.ISDNAddress getBParty() {
        return BParty;
    }


    /**
     * Sets the BParty value for this CallTriggerRequest.
     * 
     * @param BParty
     */
    public void setBParty(com.MissedCallAlertsNotifyCallerService.www.ISDNAddress BParty) {
        this.BParty = BParty;
    }


    /**
     * Gets the OCN value for this CallTriggerRequest.
     * 
     * @return OCN
     */
    public com.MissedCallAlertsNotifyCallerService.www.ISDNAddress getOCN() {
        return OCN;
    }


    /**
     * Sets the OCN value for this CallTriggerRequest.
     * 
     * @param OCN
     */
    public void setOCN(com.MissedCallAlertsNotifyCallerService.www.ISDNAddress OCN) {
        this.OCN = OCN;
    }


    /**
     * Gets the RDN value for this CallTriggerRequest.
     * 
     * @return RDN
     */
    public com.MissedCallAlertsNotifyCallerService.www.ISDNAddress getRDN() {
        return RDN;
    }


    /**
     * Sets the RDN value for this CallTriggerRequest.
     * 
     * @param RDN
     */
    public void setRDN(com.MissedCallAlertsNotifyCallerService.www.ISDNAddress RDN) {
        this.RDN = RDN;
    }


    /**
     * Gets the serviceKey value for this CallTriggerRequest.
     * 
     * @return serviceKey
     */
    public java.math.BigInteger getServiceKey() {
        return serviceKey;
    }


    /**
     * Sets the serviceKey value for this CallTriggerRequest.
     * 
     * @param serviceKey
     */
    public void setServiceKey(java.math.BigInteger serviceKey) {
        this.serviceKey = serviceKey;
    }


    /**
     * Gets the reasonCode value for this CallTriggerRequest.
     * 
     * @return reasonCode
     */
    public java.math.BigInteger getReasonCode() {
        return reasonCode;
    }


    /**
     * Sets the reasonCode value for this CallTriggerRequest.
     * 
     * @param reasonCode
     */
    public void setReasonCode(java.math.BigInteger reasonCode) {
        this.reasonCode = reasonCode;
    }


    /**
     * Gets the serviceType value for this CallTriggerRequest.
     * 
     * @return serviceType
     */
    public com.MissedCallAlertsNotifyCallerService.www.CallTriggerRequestServiceType getServiceType() {
        return serviceType;
    }


    /**
     * Sets the serviceType value for this CallTriggerRequest.
     * 
     * @param serviceType
     */
    public void setServiceType(com.MissedCallAlertsNotifyCallerService.www.CallTriggerRequestServiceType serviceType) {
        this.serviceType = serviceType;
    }

    private java.lang.Object __equalsCalc = null;
    @Override
	public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CallTriggerRequest)) return false;
        CallTriggerRequest other = (CallTriggerRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.AParty==null && other.getAParty()==null) || 
             (this.AParty!=null &&
              this.AParty.equals(other.getAParty()))) &&
            ((this.BParty==null && other.getBParty()==null) || 
             (this.BParty!=null &&
              this.BParty.equals(other.getBParty()))) &&
            ((this.OCN==null && other.getOCN()==null) || 
             (this.OCN!=null &&
              this.OCN.equals(other.getOCN()))) &&
            ((this.RDN==null && other.getRDN()==null) || 
             (this.RDN!=null &&
              this.RDN.equals(other.getRDN()))) &&
            ((this.serviceKey==null && other.getServiceKey()==null) || 
             (this.serviceKey!=null &&
              this.serviceKey.equals(other.getServiceKey()))) &&
            ((this.reasonCode==null && other.getReasonCode()==null) || 
             (this.reasonCode!=null &&
              this.reasonCode.equals(other.getReasonCode()))) &&
            ((this.serviceType==null && other.getServiceType()==null) || 
             (this.serviceType!=null &&
              this.serviceType.equals(other.getServiceType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    @Override
	public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAParty() != null) {
            _hashCode += getAParty().hashCode();
        }
        if (getBParty() != null) {
            _hashCode += getBParty().hashCode();
        }
        if (getOCN() != null) {
            _hashCode += getOCN().hashCode();
        }
        if (getRDN() != null) {
            _hashCode += getRDN().hashCode();
        }
        if (getServiceKey() != null) {
            _hashCode += getServiceKey().hashCode();
        }
        if (getReasonCode() != null) {
            _hashCode += getReasonCode().hashCode();
        }
        if (getServiceType() != null) {
            _hashCode += getServiceType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CallTriggerRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.MissedCallAlertsNotifyCallerService.com/", ">CallTriggerRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AParty");
        elemField.setXmlName(new javax.xml.namespace.QName("", "A-Party"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.MissedCallAlertsNotifyCallerService.com/", "ISDNAddress"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BParty");
        elemField.setXmlName(new javax.xml.namespace.QName("", "B-Party"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.MissedCallAlertsNotifyCallerService.com/", "ISDNAddress"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OCN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "OCN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.MissedCallAlertsNotifyCallerService.com/", "ISDNAddress"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RDN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RDN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.MissedCallAlertsNotifyCallerService.com/", "ISDNAddress"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceKey");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ServiceKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reasonCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ReasonCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ServiceType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.MissedCallAlertsNotifyCallerService.com/", ">>CallTriggerRequest>ServiceType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
