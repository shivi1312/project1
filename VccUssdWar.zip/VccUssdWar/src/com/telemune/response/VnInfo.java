package com.telemune.response;

public class VnInfo implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private boolean bl;
	private boolean optout;
	private int ct;

	public VnInfo(boolean bl, boolean optout, int ct) {
		this.bl = bl;
		this.optout = optout;
		this.ct = ct;
	}

	public boolean getBl() {
		return bl;
	}

	public void setBl(boolean bl) {
		this.bl = bl;
	}

	public boolean getOptout() {
		return optout;
	}

	public void setOptout(boolean optout) {
		this.optout = optout;
	}

	public int getCt() {
		return ct;
	}

	public void setCt(int ct) {
		this.ct = ct;
	}

}
