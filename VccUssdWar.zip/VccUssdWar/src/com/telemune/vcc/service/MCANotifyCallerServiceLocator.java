/**
 * MCANotifyCallerServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.telemune.vcc.service;

public class MCANotifyCallerServiceLocator extends org.apache.axis.client.Service implements com.telemune.vcc.service.MCANotifyCallerService {

    public MCANotifyCallerServiceLocator() {
    }


    public MCANotifyCallerServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public MCANotifyCallerServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for NotifyCallerPort
    private java.lang.String NotifyCallerPort_address = "http://www.MissedCallAlertsNotifyCallerService.com";

    public java.lang.String getNotifyCallerPortAddress() {
        return NotifyCallerPort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String NotifyCallerPortWSDDServiceName = "NotifyCallerPort";

    public java.lang.String getNotifyCallerPortWSDDServiceName() {
        return NotifyCallerPortWSDDServiceName;
    }

    public void setNotifyCallerPortWSDDServiceName(java.lang.String name) {
        NotifyCallerPortWSDDServiceName = name;
    }

    public com.telemune.vcc.service.NotifyCallerPortType getNotifyCallerPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(NotifyCallerPort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getNotifyCallerPort(endpoint);
    }

    public com.telemune.vcc.service.NotifyCallerPortType getNotifyCallerPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.telemune.vcc.service.NotifyCallerSoapBindingStub _stub = new com.telemune.vcc.service.NotifyCallerSoapBindingStub(portAddress, this);
            _stub.setPortName(getNotifyCallerPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setNotifyCallerPortEndpointAddress(java.lang.String address) {
        NotifyCallerPort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.telemune.vcc.service.NotifyCallerPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                com.telemune.vcc.service.NotifyCallerSoapBindingStub _stub = new com.telemune.vcc.service.NotifyCallerSoapBindingStub(new java.net.URL(NotifyCallerPort_address), this);
                _stub.setPortName(getNotifyCallerPortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("NotifyCallerPort".equals(inputPortName)) {
            return getNotifyCallerPort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://www.MissedCallAlertsNotifyCallerService.com/", "MCANotifyCallerService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://www.MissedCallAlertsNotifyCallerService.com/", "NotifyCallerPort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("NotifyCallerPort".equals(portName)) {
            setNotifyCallerPortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
