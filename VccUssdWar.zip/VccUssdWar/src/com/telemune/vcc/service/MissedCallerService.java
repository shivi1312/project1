package com.telemune.vcc.service;

import java.math.BigInteger;
import java.net.URL;

import org.apache.axis.AxisProperties;



public class MissedCallerService {

	NotifyCallerSoapBindingStub soapBindingStub = null;

	public String sendMcaRequest(RequestObject dataObject) {
		String response = null;
		try {
		AxisProperties.setProperty("axis.socketSecureFactory","org.apache.axis.components.net.SunFakeTrustSocketFactory");	
			soapBindingStub = new NotifyCallerSoapBindingStub(new URL("https://115.112.137.229:8443/mca_service/services/NotifyCallerPort"), new org.apache.axis.client.Service());
			CallTriggerRequest callTriggerRequest = new CallTriggerRequest();

			ISDNAddress aPartyIsdnAddress = new ISDNAddress();
			aPartyIsdnAddress.setDigits(dataObject.getaPrty());

			ISDNAddress bPartyIsdnAddress = new ISDNAddress();
			bPartyIsdnAddress.setDigits(dataObject.getbPrty());

			ISDNAddress ocnIsdnAddress = new ISDNAddress();
			ocnIsdnAddress.setDigits(dataObject.getbPrty());

			ISDNAddress rdnIsdnAddress = new ISDNAddress();
			rdnIsdnAddress.setDigits(dataObject.getbPrty());

			callTriggerRequest.setAParty(aPartyIsdnAddress);
			callTriggerRequest.setBParty(bPartyIsdnAddress);
			callTriggerRequest.setOCN(ocnIsdnAddress);
			callTriggerRequest.setRDN(rdnIsdnAddress);
			callTriggerRequest.setReasonCode(new BigInteger(dataObject.getReasonCode()));
			callTriggerRequest.setServiceKey(new BigInteger("1"));
			callTriggerRequest.setServiceType(CallTriggerRequestServiceType
					.fromString(dataObject.getServiceType()));
			System.out.println("soap response 1 ");
			try {
				CallTriggerResponse triggerResponse = soapBindingStub
						.callTrigger(callTriggerRequest);
				response = triggerResponse.getResponseMessage();
				
				System.out.println("soap response "+triggerResponse.getMSISDN());
			} catch (Exception e) {
				e.printStackTrace();
				
			}
			System.out.println("soap response 2");
			
		} catch (Exception e) {
			
		}
		return response;
	}

	public static void main(String[] args){
		String aParty = null;
		String bParty = null;
		if(args.length<2)
		{
		System.out.println("Usage: java McaLang 919820000016 919820000014 ");
                System.exit(0);	
		}else
		{
		aParty =args[0];
		 bParty =args[1];
		RequestObject dataObject = new RequestObject();
		dataObject.setaPrty(aParty);
		dataObject.setbPrty(bParty);
		dataObject.setReasonCode("0");
		dataObject.setServiceType("00001");
		dataObject.setLang("EN");
		MissedCallerService missedCallerService = new MissedCallerService();
		String response  = missedCallerService.sendMcaRequest(dataObject);
		System.out.println("response "+response);
		}
	}
}

