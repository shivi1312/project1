package com.telemune.vcc.service;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.axis.AxisProperties;

public class McaLangChange
{
 NotifyCallerSoapBindingStub stub = null;
public  static void main(String [] args){

                String msisdn  = null;
                String lang =  null;


        if(args.length==0 || args.length==1 )
        {
                System.out.println("Usage: java McaLangChange 919820000016 EN ");
                System.exit(0);

        }
        else
        {
                msisdn=(String)args[0];
                lang = (String)args[1];
                McaLangChange  mcaLang = new McaLangChange();
                mcaLang.mcaUnSub(msisdn,lang);
        }
        }


        public void mcaUnSub(String msisdn,String lang){
	String https_url = "https://115.112.137.229:8443/mca_service/services/NotifyCallerPort";
     	URL url;        
        try{
	 SSLContext ssl_ctx = SSLContext.getInstance("TLS");
            TrustManager[ ] trust_mgr = get_trust_mgr();
	  ssl_ctx.init(null, trust_mgr,new SecureRandom());
	 HttpsURLConnection.setDefaultSSLSocketFactory(ssl_ctx.getSocketFactory());
	 url = new URL(https_url);
	  HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
	
	    con.setHostnameVerifier(new HostnameVerifier() {
                public boolean verify(String host, SSLSession sess) {
                    if (host.equals("115.112.137.229")) return true;
                    else return false;
                }
            });


	AxisProperties.setProperty("axis.socketSecureFactory","org.apache.axis.components.net.SunFakeTrustSocketFactory");
     //stub = new NotifyCallerSoapBindingStub(new URL("https://115.112.137.229:8443/mca_service/services/NotifyCallerPort"), new org.apache.axis.client.Service());
     stub = new NotifyCallerSoapBindingStub(url, new org.apache.axis.client.Service());
			
		ModifyNotificationLanguageRequest langReq = new  ModifyNotificationLanguageRequest();	
                        langReq.setMSISDN(msisdn);
                        langReq.setLanguage(lang);
                        ModifyNotificationLanguageResponse  mcaLangResponse = stub.modifyNotificationLanguage(langReq);
                        String response = mcaLangResponse.getResponseMessage();
                        System.out.println("response "+response);
                }catch(Exception e){
                        e.printStackTrace();
                }
        }

	private TrustManager[ ] get_trust_mgr() {
     TrustManager[ ] certs = new TrustManager[ ] {
        new X509TrustManager() {
           public X509Certificate[ ] getAcceptedIssuers() { return null; }
           public void checkClientTrusted(X509Certificate[ ] certs, String t) { }
           public void checkServerTrusted(X509Certificate[ ] certs, String t) { }
         }
      };
      return certs;
  }	


}

