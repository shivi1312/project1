/**
 * MCANotifyCallerService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.telemune.vcc.service;

public interface MCANotifyCallerService extends javax.xml.rpc.Service {
    public java.lang.String getNotifyCallerPortAddress();

    public com.telemune.vcc.service.NotifyCallerPortType getNotifyCallerPort() throws javax.xml.rpc.ServiceException;

    public com.telemune.vcc.service.NotifyCallerPortType getNotifyCallerPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
