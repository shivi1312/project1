package com.telemune.vcc.service;

import java.net.URL;

import org.apache.axis.AxisFault;
import org.apache.axis.AxisProperties;
import org.apache.axis.MessageContext;
import org.apache.axis.client.Stub;
import org.omg.IOP.ServiceContext;

public class Main {
	NotifyCallerSoapBindingStub stub = null;

	public void test(MCASubRequest mcaSubRequest) {
		try {
			AxisProperties.setProperty("axis.socketSecureFactory",
					"org.apache.axis.components.net.SunFakeTrustSocketFactory");
			stub = new NotifyCallerSoapBindingStub(
					new URL(
							"https://115.112.137.229:8443/mca_service/services/NotifyCallerPort"),
					new org.apache.axis.client.Service());
			MCASubscriptionRequest mcaSubscriptionRequest = new MCASubscriptionRequest();
			mcaSubscriptionRequest
					.setCOS(COS.fromString(mcaSubRequest.getCos()));
			mcaSubscriptionRequest.setLanguage(mcaSubRequest.getLang());
			mcaSubscriptionRequest.setMSISDN(mcaSubRequest.getMsisdn());
			mcaSubscriptionRequest.setServiceType(mcaSubRequest
					.getServiceType());
			mcaSubscriptionRequest.setSMSFormat(SMSFormat
					.fromString(mcaSubRequest.getSmsFormat()));
			mcaSubscriptionRequest.setStatus(Status.fromString(mcaSubRequest
					.getStatus()));
			MCASubscriptionResponse mcaSubscriptionResponse = stub
					.MCASubscription(mcaSubscriptionRequest);
			String response = mcaSubscriptionResponse.getResponseMessage();
			System.out.println("response " + response);
			// new Main().printLog(new Stub());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		// PropertyConfigurator.configure("/home/test/workspace/project/mca/log4j.properties");

		MCASubRequest mcaSubRequest = new MCASubRequest();
		mcaSubRequest.setCos("1");
		mcaSubRequest.setLang("EN");
		mcaSubRequest.setServiceType("00001");
		mcaSubRequest.setSmsFormat("SINGLE");
		mcaSubRequest.setStatus("ACTIVE");
		mcaSubRequest.setMsisdn("919820000014");
		Main mcaSubscription = new Main();
		mcaSubscription.test(mcaSubRequest);
	}

	public void mcaUnSub(MCASubRequest mcaSubRequest) {
		try {
			stub = new NotifyCallerSoapBindingStub(
					new URL(
							"https://115.112.137.229:8443/mca_service/services/NotifyCallerPort"),
					new org.apache.axis.client.Service());
			MCAUnsubscriptionRequest mcaUnSubscriptionRequest = new MCAUnsubscriptionRequest();
			mcaUnSubscriptionRequest.setMSISDN(mcaSubRequest.getMsisdn());
			mcaUnSubscriptionRequest.setServiceType(mcaSubRequest
					.getServiceType());
			MCAUnsubscriptionResponse mcaUnSubscriptionResponse = stub
					.MCAUnsubscription(mcaUnSubscriptionRequest);
			String response = mcaUnSubscriptionResponse.getResponseMessage();
			System.out.println("response " + response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
