package com.telemune.vcc.service;
import java.net.URL;

import org.apache.axis.AxisProperties;

public class McaLang
{
 NotifyCallerSoapBindingStub stub = null;
public  static void main(String [] args){

                String msisdn  = null;
                String lang =  null;


        if(args.length==0 || args.length==1 )
        {
                System.out.println("Usage: java McaLang 919820000016 EN ");
                System.exit(0);

        }
        else
        {
                msisdn=(String)args[0];
                lang = (String)args[1];
                McaLang  mcaLang = new McaLang();
                mcaLang.mcaUnSub(msisdn,lang);
        }
        }


        public void mcaUnSub(String msisdn,String lang){
                try{
 AxisProperties.setProperty("axis.socketSecureFactory","org.apache.axis.components.net.SunFakeTrustSocketFactory");
     stub = new NotifyCallerSoapBindingStub(new URL("https://115.112.137.229:8443/mca_service/services/NotifyCallerPort"), new org.apache.axis.client.Service());
			
		ModifyNotificationLanguageRequest langReq = new  ModifyNotificationLanguageRequest();	
                        langReq.setMSISDN(msisdn);
                        langReq.setLanguage(lang);
                        ModifyNotificationLanguageResponse  mcaLangResponse = stub.modifyNotificationLanguage(langReq);
                        String response = mcaLangResponse.getResponseMessage();
                        System.out.println("response "+response);
                }catch(Exception e){
                        e.printStackTrace();
                }
        }

	


}

