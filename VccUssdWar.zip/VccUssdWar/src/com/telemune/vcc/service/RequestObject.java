package com.telemune.vcc.service;

public class RequestObject {
	
	private String aPrty;
	private String bPrty;
	private String reasonCode;
	private String serviceType;
	private String callTime;
	private String lang;
	private String type;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getaPrty() {
		return aPrty;
	}
	public void setaPrty(String aPrty) {
		this.aPrty = aPrty;
	}
	public String getbPrty() {
		return bPrty;
	}
	public void setbPrty(String bPrty) {
		this.bPrty = bPrty;
	}
	
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getCallTime() {
		return callTime;
	}
	public void setCallTime(String callTime) {
		this.callTime = callTime;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	@Override
	public String toString() {
		return "RequestObject [aPrty=" + aPrty + ", bPrty=" + bPrty
				+ ", reasonCode=" + reasonCode + ", serviceType=" + serviceType
				+ ", callTime=" + callTime + ", lang=" + lang + ", type="
				+ type + "]";
	}

}

