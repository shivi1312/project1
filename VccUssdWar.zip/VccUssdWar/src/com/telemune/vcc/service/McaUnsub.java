package com.telemune.vcc.service;

import java.net.URL;

import org.apache.axis.AxisProperties;

public class McaUnsub
{
 NotifyCallerSoapBindingStub stub = null;
public  static void main(String [] args){
                
		String msisdn  = null;
		String serviceType =  null;


	if(args.length<1)
	{
		System.out.println("Usage: java McaUnsub 919820000016 00001 ");
		System.exit(0);
	
	}
	else
	{	
		msisdn=(String)args[0];
		serviceType = (String)args[1];
                McaUnsub mcaUnSubscription = new McaUnsub();
                mcaUnSubscription.mcaUnSub(msisdn,serviceType);
        }
	}


        public void mcaUnSub(String msisdn,String serviceType){
                try{
AxisProperties.setProperty("axis.socketSecureFactory","org.apache.axis.components.net.SunFakeTrustSocketFactory");
     stub = new NotifyCallerSoapBindingStub(new URL("https://115.112.137.229:8443/mca_service/services/NotifyCallerPort"), new org.apache.axis.client.Service());
                        MCAUnsubscriptionRequest mcaUnSubscriptionRequest = new MCAUnsubscriptionRequest();
                        mcaUnSubscriptionRequest.setMSISDN(msisdn);
                        mcaUnSubscriptionRequest.setServiceType(serviceType);
                        MCAUnsubscriptionResponse mcaUnSubscriptionResponse = stub.MCAUnsubscription(mcaUnSubscriptionRequest);
                        String response = mcaUnSubscriptionResponse.getResponseMessage();
                        System.out.println("response "+response);
                }catch(Exception e){
                        e.printStackTrace();
                }
        }

}
