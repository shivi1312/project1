/**
 * NotifyCallerSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.telemune.vcc.service;

public class NotifyCallerSoapBindingImpl implements com.telemune.vcc.service.NotifyCallerPortType{
    public com.telemune.vcc.service.MCASubscriptionResponse MCASubscription(com.telemune.vcc.service.MCASubscriptionRequest MCASubscriptionRequest) throws java.rmi.RemoteException {
        return null;
    }

    public com.telemune.vcc.service.MCAUnsubscriptionResponse MCAUnsubscription(com.telemune.vcc.service.MCAUnsubscriptionRequest MCAUnsubscriptionRequest) throws java.rmi.RemoteException {
        return null;
    }

    public com.telemune.vcc.service.ModifyNotificationLanguageResponse modifyNotificationLanguage(com.telemune.vcc.service.ModifyNotificationLanguageRequest modifyNotificationLanguageRequest) throws java.rmi.RemoteException {
        return null;
    }

    public com.telemune.vcc.service.CallTriggerResponse callTrigger(com.telemune.vcc.service.CallTriggerRequest callTriggerRequest) throws java.rmi.RemoteException {
        return null;
    }

}
