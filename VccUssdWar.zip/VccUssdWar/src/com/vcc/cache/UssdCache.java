/**
 * The UssdCache class implements cache that read all xml 
 * response file in cache when run a application.    
 * @author Mayank Agrawal
 */

package com.vcc.cache;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.vcc.config.AppConfig;

public class UssdCache {

	final static Logger logger = Logger.getLogger(UssdCache.class);
	public static HashMap<String, String> cache = null;

	static {
		cache = new HashMap<String, String>();
	}

	private UssdCache() {
		readAppConfigProperties();
	}

	/**
	 * This method read xml file by appconfig obect
	 */
	public void readAppConfigProperties() {
		try {
			List<Object> list = AppConfig.config.getList("files");
			for (int i = 0; i < list.size(); i++) {
				readUssdXmlFile(list.get(i).toString());
			}
			logger.info("All response xml file has been set in cache ["
					+ list.size() + "]");
		} catch (Exception e) {
			logger.error("Exception in reading xml file" + e.getMessage());
		}
	}

	/**
	 * This method put xml file in cache
	 */
	public void readUssdXmlFile(String fileName) {
		BufferedReader bufferedReader = null;
		String line;
		StringBuilder stringBuilder = new StringBuilder();
		try {
			String filePath = AppConfig.config.getString("basepath") + fileName;
			bufferedReader = new BufferedReader(new FileReader(new File(
					filePath)));
			while ((line = bufferedReader.readLine()) != null) {
				stringBuilder.append(line);
			}
			cache.put(fileName, stringBuilder.toString());
		} catch (Exception e) {
			logger.error("Exception in reading xml file" + e.getMessage());
		} finally {
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
