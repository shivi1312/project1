package com.vcc.net;

import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;

/**
 * Created by tanujkumar on 02/07/15.
 */
public class SocketConnection extends ExceptionIgnorer {

    private Socket socket          = null;
    private boolean isOpen         = true;
    private volatile boolean inUse = false;

    protected Socket socket(){
        return this.socket;
    }

    protected void socket( Socket newSocket ){
        this.socket = newSocket;
    }

    public boolean isOpen(){
        return this.isOpen;
    }

    public void isOpen( boolean newIsOpen ){
        this.isOpen = newIsOpen;
    }

    protected boolean isClosed(){
        return !isOpen();
    }

    protected synchronized boolean inUse(){
        return this.inUse;
    }

    protected synchronized void inUse( boolean newInUse ){
        this.inUse = newInUse;
    }

    public SocketConnection( Socket openSocket ){
        this( openSocket, null );
    }

    public SocketConnection( Socket openSocket, ExceptionHandler exceptionHandler ){
        super(exceptionHandler);
        socket(openSocket);
    }

    public void close(){
        isOpen( false );
        closeSocket();
    }

    protected synchronized boolean wantToUse(){
        if( inUse() ){
            return false;
        }

        if( isClosed() ){
            return true;
        }

        inUse(true);
        return true;
    }

    protected boolean hasSocket(){
        return socket() != null;
    }

    protected void closeSocket(){
        try{
            if( hasSocket() ){
                socket().close();
                socket(null);
            }
        }catch(IOException ioe){
            exceptionOccurred( ioe );
        }
    }

	public void readTimeout(int timeout) {
		try{
		socket.setSoTimeout(timeout);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
