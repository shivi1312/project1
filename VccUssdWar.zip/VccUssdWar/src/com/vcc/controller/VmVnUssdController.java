/**
 *  The VmVnUssdController class handle request and response of activation 
 *  and deactivation for voice-mail and voice-note service.
 *  @author Mayank Agrawal
 */
package com.vcc.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vcc.cache.UssdCache;
import com.vcc.cdr.FileWriter;
import com.vcc.common.UssdCommonOperation;
import com.vcc.config.AppConfig;
import com.vcc.domain.VccGmatMsgStore;
import com.vcc.handler.VoiceMailServiceHandler;
import com.vcc.handler.VoiceNoteServiceHandler;
import com.vcc.model.VccCdrRequest;
import com.vcc.request.VmVnRequestData;

@RestController
@RequestMapping("/")
public class VmVnUssdController {
	final static Logger logger = Logger.getLogger(VmVnUssdController.class);
	@Autowired
	public VccGmatMsgStore vccGmatMsgStore;

	/**
	 * This method display menu for voice-mail & voice-note service
	 * 
	 * @Param requestData contains url input data
	 * @Param httpHeaders conatains data in header include by url
	 * @return xml response in string format
	 */
	@RequestMapping(value = "vm.vn.menu", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String getVmVnUssdMenu(VmVnRequestData requestData,
			@RequestHeader HttpHeaders httpHeaders) {
		new UssdCommonOperation().getRequestHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("vm.vn.menu");		
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		logger.info(String.format("[%s] main menu request ",
				requestData.getMsisdn()));
		VoiceMailServiceHandler vmServiceHandler = new VoiceMailServiceHandler();
		String response = vmServiceHandler.getVoiceMailVoiceNoteMenu(
				httpHeaders, requestData);
		if (AppConfig.config.getBoolean("whitelist", false)
				&& !AppConfig.config.getList("msisdnlist").contains(
						requestData.getMsisdn())) {
			System.out.println("list " + AppConfig.config.getList("msisdnlist")
					+ " msisdn " + requestData.getMsisdn());
			logger.info(String.format("[%s] whitelist msisdn list [%s]",
					requestData.getMsisdn(),
					AppConfig.config.getList("msisdnlist")));
			return UssdCache.cache.get("error.xml");
		}
		VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("vm.vn.menu");		
		new FileWriter().writeLog(requestData,cdrRequest);
		logger.info(String.format(
				"[%s] voice mail and voice menu response [%s] ",
				requestData.getMsisdn(), response));
		if (response.equalsIgnoreCase("") || response == null)
			return "FAIL";
		return response;

	}

	/**
	 * This method display menu for voice-mail service
	 * 
	 * @Param requestData contains url input data
	 * @Param httpHeaders conatains data in header include by url
	 * @return xml response in string format
	 */
	@RequestMapping(value = "voicemail", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String getVmUssdMenu(VmVnRequestData requestData,
			@RequestHeader HttpHeaders httpHeaders) {
		new UssdCommonOperation().getRequestHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("voicemail");
		new FileWriter().writeLog(requestData,cdrRequest);
		*/
		
		VoiceMailServiceHandler vmServiceHandler = new VoiceMailServiceHandler();
		logger.info(String.format("[%s] voicemail request ",
				requestData.getMsisdn()));
		String response = vmServiceHandler.getVoiceMailMenu(httpHeaders,
				requestData);
		logger.info(String.format("[%s] voice mail response [%s] ",
				requestData.getMsisdn(), response));
		if (response.equalsIgnoreCase("") || response == null)
			return "FAIL";

		return response;
	}

	/**
	 * This method display basic menu of voice-mail service
	 * 
	 * @Param requestData contains url input data
	 * @Param httpHeaders conatains data in header include by url
	 * @return xml response in string format
	 */
	@RequestMapping(value = "vm.basic", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String getVmBasicServiceMEnu(@RequestHeader HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		new UssdCommonOperation().getRequestHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("vm.basic");
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		VoiceMailServiceHandler vmServiceHandler = new VoiceMailServiceHandler();
		logger.info(String.format("[%s] voicemail basic request ",
				requestData.getMsisdn()));
		String response = vmServiceHandler.getBasicVmServices(httpHeaders,
				requestData);
		logger.info(String.format("[%s] voice mail basic response [%s] ",
				requestData.getMsisdn(), response));
		if (response.equalsIgnoreCase("") || response == null)
			return "FAIL";

		return response;
	}

	/**
	 * This method display executive menu of voice-mail service
	 * 
	 * @Param requestData contains url input data
	 * @Param httpHeaders conatains data in header include by url
	 * @return xml response in string format
	 */
	@RequestMapping(value = "vm.executive", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String getVmExecutiveService(@RequestHeader HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		new UssdCommonOperation().getRequestHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("vm.executive");
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		VoiceMailServiceHandler vmServiceHandler = new VoiceMailServiceHandler();
		logger.info(String.format("[%s] voicemail executive request ",
				requestData.getMsisdn()));
		String response = vmServiceHandler.getExecutiveVmServices(httpHeaders,
				requestData);
		logger.info(String.format("[%s] voice mail executive response [%s] ",
				requestData.getMsisdn(), response));
		if (response.equalsIgnoreCase("") || response == null)
			return "FAIL";

		return response;
	}

	/**
	 * This method get activation request for voicemail service
	 * 
	 * @Param requestData contains url input data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	@RequestMapping(value = "vm.activate", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String activateVmService(@RequestHeader HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		new UssdCommonOperation().getRequestHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("vm.activate");
		cdrRequest.setOperation("act");
		new FileWriter().writeLog(requestData,cdrRequest);*/
		VoiceMailServiceHandler vmServiceHandler = new VoiceMailServiceHandler();
		logger.info(String.format("[%s] voicemail activation request ",
				requestData.getMsisdn()));
		String response = vmServiceHandler.subscribeVmService(httpHeaders,
				requestData);
		logger.info(String.format("[%s] voice mail activation response [%s] ",
				requestData.getMsisdn(), response));
		if (response.equalsIgnoreCase("") || response == null)
			return "FAIL";

		return response;
	}

	/**
	 * This method get deactivation request for voicemail service
	 * 
	 * @Param requestData contains url input data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	@RequestMapping(value = "vm.deactivate", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String deactivateVmService(@RequestHeader HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		new UssdCommonOperation().getRequestHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("vm.deactivate");
		cdrRequest.setOperation("deact");
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		VoiceMailServiceHandler vmServiceHandler = new VoiceMailServiceHandler();
		logger.info(String.format("[%s] voicemail deactivation request ",
				requestData.getMsisdn()));
		String response = vmServiceHandler.unSubscribeVmService(httpHeaders,
				requestData);
		logger.info(String.format(
				"[%s] voice mail deactivation response [%s] ",
				requestData.getMsisdn(), response));
		if (response.equalsIgnoreCase("") || response == null)
			return "FAIL";

		return response;
	}

	/**
	 * This method display menu for voice-note service
	 * 
	 * @Param requestData contains url input data
	 * @Param httpHeaders conatains data in header include by url
	 * @return xml response in string format
	 */
	@RequestMapping(value = "voicenote", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String getVnUssdMenu(VmVnRequestData requestData,
			@RequestHeader HttpHeaders httpHeaders) {
		new UssdCommonOperation().getRequestHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("voicenote");
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		VoiceNoteServiceHandler vnServiceHandler = new VoiceNoteServiceHandler();
		logger.info(String.format("[%s] voicenote request ",
				requestData.getMsisdn()));
		String response = vnServiceHandler.getVoiceNoteMenu(httpHeaders,
				requestData);
		logger.info(String.format("[%s] voice note response [%s] ",
				requestData.getMsisdn(), response));
		if (response.equalsIgnoreCase("") || response == null)
			return "FAIL";

		return response;
	}

	/**
	 * This method get activation request for voicenote service
	 * 
	 * @Param requestData contains url input data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	@RequestMapping(value = "vn.activate", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String activateVnService(@RequestHeader HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		new UssdCommonOperation().getRequestHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("vn.activate");
		cdrRequest.setOperation("act");
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		VoiceNoteServiceHandler vnServiceHandler = new VoiceNoteServiceHandler();
		logger.info(String.format("[%s] voicenote activation request ",
				requestData.getMsisdn()));
		String response = vnServiceHandler.subscribeVnService(httpHeaders,
				requestData);
		logger.info(String.format("[%s] voice note activation response [%s] ",
				requestData.getMsisdn(), response));
		if (response.equalsIgnoreCase("") || response == null)
			return "FAIL";

		return response;
	}

	/**
	 * This method get deactivation request for voicenote service
	 * 
	 * @Param requestData contains url input data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	@RequestMapping(value = "vn.deactivate", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String deactivateVnService(@RequestHeader HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		new UssdCommonOperation().getRequestHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("vn.deactivate");
		cdrRequest.setOperation("deact");
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		VoiceNoteServiceHandler vnServiceHandler = new VoiceNoteServiceHandler();
		logger.info(String.format("[%s] voicenote deactivation request ",
				requestData.getMsisdn()));
		String response = vnServiceHandler.unSubscribeVnService(httpHeaders,
				requestData);
		logger.info(String.format(
				"[%s] voice note deactivation response [%s] ",
				requestData.getMsisdn(), response));
		return response;
	}

	@RequestMapping(value = "vn.moreinfo", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String vnMoreInfoService(@RequestHeader HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		new UssdCommonOperation().getRequestHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("vn.moreinfo");		
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		String response = null;
		
		String tempId = AppConfig.config.getString("vn.moreinfo.tempid", "1");
		String key = tempId + "-" + requestData.getLang();

		boolean result = vccGmatMsgStore.insertIntoGmatMsg(
				requestData.getMsisdn(), requestData.getLang(), key, "VN");
		if (!result)
			logger.info("There is any error in message insertion in data base");
		logger.info(String.format("[%s] voicenote moreInfo request ",
				requestData.getMsisdn()));
		if (requestData.getLang() == 1) {
			response = UssdCache.cache.get("ar_moreinfo.xml");
			logger.info(String.format(
					"[%s] voice note more info menu [ar_moreinfo.xml]",
					requestData.getMsisdn()));
		} else {
			response = UssdCache.cache.get("en_moreinfo.xml");
			logger.info(String.format(
					"[%s] voice note more info menu [en_moreinfo.xml]",
					requestData.getMsisdn()));
		}
		return response;
	}

	/**
	 * This method get VM Basic More info request for voicenote service
	 * 
	 * @Param requestData contains url input data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */

	@RequestMapping(value = "vm.basic.moreinfo", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String vmBasicMoreInfoService(@RequestHeader HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		new UssdCommonOperation().getRequestHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("vm.basic.moreinfo");
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		String response = null;
		String tempId = AppConfig.config.getString("vm.basic.moreinfo.tempid",
				"1");
		String key = tempId + "-" + requestData.getLang();

		boolean result = vccGmatMsgStore.insertIntoGmatMsg(
				requestData.getMsisdn(), requestData.getLang(), key, "VM");
		if (!result)
			logger.info("There is any error in message insertion in data base");

		logger.info(String.format("[%s] voicemail moreInfo request ",
				requestData.getMsisdn()));
		if (requestData.getLang() == 1) {
			response = UssdCache.cache.get("ar_vm_basic_moreinfo.xml");
			logger.info(String
					.format("[%s] voice note more info menu [ar_vm_basic_moreinfo.xml]",
							requestData.getMsisdn()));
		} else {
			response = UssdCache.cache.get("en_vm_basic_moreinfo.xml");
			logger.info(String
					.format("[%s] voice note more info menu [en_vm_basic_moreinfo.xml]",
							requestData.getMsisdn()));
		}
		return response;
	}

	/**
	 * This method get VM Executive More info request for voicenote service
	 * 
	 * @Param requestData contains url input data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	@RequestMapping(value = "vm.executive.moreinfo", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String vmExecutiveMoreInfoService(@RequestHeader HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		new UssdCommonOperation().getRequestHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("vm.executive.moreinfo");
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		String response = null;
		String tempId = AppConfig.config.getString(
				"vm.executive.moreinfo.tempid", "1");
		String key = tempId + "-" + requestData.getLang();

		boolean result = vccGmatMsgStore.insertIntoGmatMsg(
				requestData.getMsisdn(), requestData.getLang(), key, "VM");
		if (!result)
			logger.info("There is any error in message insertion in data base");
		logger.info(String.format("[%s] voicenote moreInfo request ",
				requestData.getMsisdn()));
		if (requestData.getLang() == 1) {
			response = UssdCache.cache.get("ar_vm_executive_moreinfo.xml");
			logger.info(String
					.format("[%s] voice note more info menu [ar_vm_executive_moreinfo.xml]",
							requestData.getMsisdn()));
		} else {
			response = UssdCache.cache.get("en_vm_executive_moreinfo.xml");
			logger.info(String
					.format("[%s] voice note more info menu [en_vm_executive_moreInfo.xml]",
							requestData.getMsisdn()));
		}
		return response;
	}

}
