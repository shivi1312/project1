/**
 *  The NotifyMeUssdController class handle request and response of activation 
 *  and deactivation for NotifyMe service.
 *  @author Mayank Agrawal
 */
package com.vcc.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vcc.cache.UssdCache;
import com.vcc.cdr.FileWriter;
import com.vcc.common.UssdCommonOperation;
import com.vcc.config.AppConfig;
import com.vcc.domain.VccGmatMsgStore;
import com.vcc.handler.NotifyMeServiceHandler;
import com.vcc.model.VccCdrRequest;
import com.vcc.request.NotifyMeRequest;

@RestController
@RequestMapping("/")
public class NotifyMeUssdController {
	final static Logger logger = Logger.getLogger(NotifyMeUssdController.class);

	@Autowired
	public VccGmatMsgStore vccGmatMsgStore;

	@RequestMapping(value = "notify.me.menu", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	/**
	 *This method display menu for NotifyMeService
	 *@Param requestData contains url data
	 *@Param httpHeaders conatains data in header include by url
	 *@return xml response in string format	
	 */
	String getNotifyServiceMenu(NotifyMeRequest requestData,
			@RequestHeader HttpHeaders httpHeaders) {
		new UssdCommonOperation().getNotifyMeHeader(httpHeaders, requestData);
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("notify.me.menu");
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		NotifyMeServiceHandler serviceHandler = new NotifyMeServiceHandler();
		logger.info(String.format("[%s] notify.me.menu request",
				requestData.getMsisdn()));
		String response = serviceHandler.getNotifyMeUssdMenu(httpHeaders,
				requestData);
		if (AppConfig.config.getBoolean("whitelist", false)
				&& !AppConfig.config.getList("msisdnlist").contains(
						requestData.getMsisdn())) {
			logger.info(String.format("[%s] whitelist msisdn [%s]",
					requestData.getMsisdn(),
					AppConfig.config.getList("msisdnlist")));
			logger.info(String.format("[%s] notify.me.menu response [%s]",
					requestData.getMsisdn(), response));
			return UssdCache.cache.get("error.xml");
		}
		VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("notify.me.menu");
		new FileWriter().writeLog(requestData,cdrRequest);
		logger.info(String.format("[%s] notify.me.menu reponse [%s]",
				requestData.getMsisdn(), response));
		if (response.equalsIgnoreCase("") || response == null)
			return "FAIL";

		return response;

	}

	/**
	 * This method get activate request for NotifyMeService
	 * 
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	@RequestMapping(value = "notify.me.activate", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String activateNotifyMe(NotifyMeRequest requestData,
			@RequestHeader HttpHeaders httpHeaders) {
		new UssdCommonOperation().getNotifyMeHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("notify.me.activate");
		cdrRequest.setOperation("act");
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		logger.info(String.format("[%s] notify me activate request",
				requestData.getMsisdn()));
		NotifyMeServiceHandler serviceHandler = new NotifyMeServiceHandler();
		String response = serviceHandler.subscribeNotifyMe(httpHeaders,
				requestData, vccGmatMsgStore);
		logger.info("[" + requestData.getMsisdn() + "] repsponse " + response);
		if (response.equalsIgnoreCase("") || response == null)
			return "FAIL";

		return response;
	}

	/**
	 * This method get deactivate request for NotifyMeService
	 * 
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	@RequestMapping(value = "notify.me.deactivate", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String deactivateNotifyMe(NotifyMeRequest requestData,
			@RequestHeader HttpHeaders httpHeaders) {
		new UssdCommonOperation().getNotifyMeHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("notify.me.deactivate");
		cdrRequest.setOperation("deact");
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		
		logger.info(String.format("[%s] notify me deactivate request",
				requestData.getMsisdn()));
		NotifyMeServiceHandler serviceHandler = new NotifyMeServiceHandler();
		String response = serviceHandler.unsubscribeNotifyMe(httpHeaders,
				requestData, vccGmatMsgStore);
		logger.info("[" + requestData.getMsisdn() + "] repsponse " + response);
		if (response.equalsIgnoreCase("") || response == null)
			return "FAIL";

		return response;
	}

	/**
	 * This method get more Info request for NotifyMeService
	 * 
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	@RequestMapping(value = "notify.me.moreinfo", method = RequestMethod.GET, produces = "text/xml; charset=utf-8")
	public @ResponseBody
	String notifyMeMoreInfo(NotifyMeRequest requestData,
			@RequestHeader HttpHeaders httpHeaders) {
		new UssdCommonOperation().getNotifyMeHeader(httpHeaders, requestData);
		
		/*VccCdrRequest cdrRequest = new VccCdrRequest();
		cdrRequest.setMenu("notify.me.moreinfo");
		new FileWriter().writeLog(requestData,cdrRequest);*/
		
		String response = null;
		
		logger.info(String.format("[%s] notify me more Info",
				requestData.getMsisdn()));
		String tempId = AppConfig.config.getString("notifyme.moreinfo.tempid",
				"1");
		String key = tempId + "-" + requestData.getLang();

		boolean result = vccGmatMsgStore.insertIntoGmatMsg(
				requestData.getMsisdn(), requestData.getLang(), key, "NA");
		if (!result)
			logger.info("There is any error in message insertion in data base");

		logger.info(String.format("[%s] voicenote moreInfo request ",
				requestData.getMsisdn()));
		if (requestData.getLang() == 1) {
			response = UssdCache.cache.get("ar_notify_moreinfo.xml");
			logger.info(String.format(
					"[%s] notify me more info menu [ar_notify_moreinfo.xml]",
					requestData.getMsisdn()));
		} else {
			response = UssdCache.cache.get("en_notify_moreinfo.xml");
			logger.info(String.format(
					"[%s] notify me more info menu [en_notify_moreinfo.xml]",
					requestData.getMsisdn()));
		}
		return response;
	}

}
