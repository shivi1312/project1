package com.vcc.domain;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.vcc.config.AppConfig;

public class VccGmatMsgStore {
	final static Logger logger = Logger.getLogger(VccGmatMsgStore.class);
	private final static Logger errorLogger = Logger.getLogger("errorLogger");

	@Autowired
	VccLbsTemplates vccLbsTemp;

	@Autowired
	DataSource dataSource;

	public boolean insertIntoGmatMsg(String msisdn, int lang, String key,
			String serviceType) {
		try {
			String senderId = AppConfig.config.getString(serviceType
					+ "_SMS_SENDER_ID", "NA");
			logger.info("Inside insert into gmat_message_store sender id ["
					+ senderId + "] key [" + key + "]");

			String tempMessage = "Error";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

			logger.info("jdbcTemplate is [" + jdbcTemplate + "]");

			tempMessage = vccLbsTemp.getLbsMessage(key);

			String query = "insert into GMAT_MESSAGE_STORE(ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT,"
					+ "SUBMIT_TIME,STATUS,MESSAGE_TYPE,DESTINATION_PORT,LANGUAGE_ID) values (?,?,?,now(),'R',1,0,?)";
			logger.info(String.format("[%s] [%s]  query [%s]", msisdn,
					tempMessage, query));

			int count = jdbcTemplate.update(query, new Object[] { senderId,
					msisdn, tempMessage, lang });
			if (count > 0)
				return true;
			else
				return false;

		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-USSD-")
							+ "00004] MSISDN["
							+ msisdn
							+ "] [Exception while inserting message in GMAT_MESSAGE_STORE] Error["
							+ e.getMessage() + "]");

			e.printStackTrace();
			logger.info("Exception while save logs: " + e.getMessage());
			return false;
		}

	}

}
