/**
 * The VoiceNoteServiceHandler class process request of 
 * voice-note service that send activation and deactivation 
 * request to rule-engine server   .
 * @author Mayank Agrawal
 */
package com.vcc.handler;

import org.apache.log4j.Logger;
import org.springframework.http.HttpHeaders;

import tele.common.filebase.Logging;

import com.vcc.cache.UssdCache;
import com.vcc.common.UssdCommonOperation;
import com.vcc.config.AppConfig;
import com.vcc.request.VmVnRequestData;
import com.vcc.util.Utility;

public class VoiceNoteServiceHandler {

	final static Logger logger = Logger
			.getLogger(VoiceNoteServiceHandler.class);
	private final static Logger errorLogger = Logger.getLogger("errorLogger");

	private UssdCommonOperation commonOperation = null;
	private String response = null;
	Logging logging = new Logging();

	/**
	 * This method process for voice-note service menu
	 *
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	public String getVoiceNoteMenu(HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		try {
			commonOperation = new UssdCommonOperation();
			commonOperation.getRequestHeader(httpHeaders, requestData);
			if (requestData.getMsisdn() != null && requestData.getLang() != 0
					&& Utility.isValidateMsisdn(requestData.getMsisdn())) {
				if (requestData.getLang() == 2) {
					response = UssdCache.cache.get("en_vn_menu.xml");
					logger.info(String.format(
							"[%s] lang [%s] vn display menu [en_vn_menu.xml]",
							requestData.getMsisdn(), requestData.getLang()));
				} else {
					response = UssdCache.cache.get("ar_vn_menu.xml");
					logger.info(String.format(
							"[%s] lang [%s] vn display menu [ar_vn_menu.xml]",
							requestData.getMsisdn(), requestData.getLang()));
				}
			} else {
				errorLogger
				.error("ErrorCode ["
						+ AppConfig.config.getString(
								"errorcode_pattern", "VCC-USSD-")
						+ "00024] MSISDN["
						+ requestData.getMsisdn()
						+ "] [Some Parameters are Missing in VoiceNote Menu request]");
				response = UssdCache.cache.get("error.xml");
				logger.info(String
						.format("[%s] Mandatory parameter missing lang [%s] display menu [error.xml]",
								requestData.getMsisdn(), requestData.getLang()));
			}
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-USSD-") + "00025] MSISDN["
					+ requestData.getMsisdn()
					+ "] [Exception while displaying Voice Note Menu] Error["
					+ e.getMessage() + "]");
			logger.error(String.format("[%s] Error while display vn menu [%s]",
					requestData.getMsisdn(), e.getMessage()));
			response = UssdCache.cache.get("error.xml");
		}
		return response;
	}

	/**
	 * This method process for voice-note subscribe service
	 *
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	public String subscribeVnService(HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		try {
			commonOperation = new UssdCommonOperation();
			commonOperation.getRequestHeader(httpHeaders, requestData);
			if (requestData.getMsisdn() != null && requestData.getLang() != 0
					&& Utility.isValidateMsisdn(requestData.getMsisdn())) {
				requestData.setServiceType("0100");
				requestData.setActionId(AppConfig.config
						.getString("sub_actionId"));
				String json = commonOperation.getJsonObj(requestData);
				logger.info(String
						.format("[%s] actionId [%s] vn activation request for ruleEngine [%s]",
								requestData.getMsisdn(),
								requestData.getActionId(), json));
				logger.info("voice-note subscribe  json request " + json);
				String ruleEngineResponse = commonOperation
						.sendSubUnscribeRequest(json);
				logger.info(String
						.format("[%s] actionId [%s] vn activation response from ruleEngine [%s]",
								requestData.getMsisdn(),
								requestData.getActionId(), ruleEngineResponse));
				logging.write("voice note subscribe request " + json
						+ " response " + ruleEngineResponse);
				if (requestData.getLang() == 2) {
					response = UssdCache.cache.get("en_final_rpy.xml");
					logger.info(String
							.format("[%s] lang [%s] vn display menu [en_final_rpy.xml]",
									requestData.getMsisdn(),
									requestData.getLang()));
				} else {
					response = UssdCache.cache.get("ar_final_rpy.xml");
					logger.info(String
							.format("[%s] lang [%s] vn display menu [ar_final_rpy.xml]",
									requestData.getMsisdn(),
									requestData.getLang()));
				}
			} else {
				errorLogger
				.error("ErrorCode ["
						+ AppConfig.config.getString(
								"errorcode_pattern", "VCC-USSD-")
						+ "00026] MSISDN["
						+ requestData.getMsisdn()
						+ "] [Some Parameters are Missing in VoiceNote activation request]");
				logger.error(String
						.format("[%s] Mandatory parameter missing lang [%s] vn display menu [error.xml]",
								requestData.getMsisdn(), requestData.getLang()));
				response = UssdCache.cache.get("error.xml");
			}
		} catch (Exception e) {
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString(
							"errorcode_pattern", "VCC-USSD-")
					+ "00002] MSISDN["
					+ requestData.getMsisdn()
					+ "] [Exception while Sending Voice Note Activation request to RuleEngine] Error["
					+ e.getMessage() + "]");
			
			logger.error(String.format("[%s] Error while vn activation [%s]",
					requestData.getMsisdn(), e.getMessage()));
		}
		return response;
	}

	/**
	 * This method process for voice-note unsubscribe service
	 *
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	public String unSubscribeVnService(HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		try {
			commonOperation = new UssdCommonOperation();
			commonOperation.getRequestHeader(httpHeaders, requestData);

			if (requestData.getMsisdn() != null && requestData.getLang() != 0
					&& Utility.isValidateMsisdn(requestData.getMsisdn())) {
				requestData.setServiceType("0100");
				requestData.setActionId(AppConfig.config
						.getString("unsub_actionId"));
				String json = commonOperation.getJsonObj(requestData);
				logger.info("voice-note unsubscribe json request " + json);
				logger.info(String.format(
						"[%s] actionId [%s]vn deactivation request [%s]",
						requestData.getMsisdn(), requestData.getActionId(),
						json));
				String ruleEngineResponse = commonOperation
						.sendSubUnscribeRequest(json);
				logger.info(String.format(
						"[%s] actionId [%s]vn deactivation response [%s]",
						requestData.getMsisdn(), requestData.getActionId(),
						ruleEngineResponse));
				logging.write("voice note unsubscribe request " + json
						+ " response " + ruleEngineResponse);
				if (requestData.getLang() == 2) {
					response = UssdCache.cache.get("en_final_rpy.xml");
					logger.info(String
							.format("[%s] lang [%s] vn display menu [en_final_rpy.xml]",
									requestData.getMsisdn(),
									requestData.getLang()));
				} else {
					response = UssdCache.cache.get("ar_final_rpy.xml");
					logger.info(String
							.format("[%s] lang [%s] vn display menu [ar_final_rpy.xml]",
									requestData.getMsisdn(),
									requestData.getLang()));
				}
			} else {
				errorLogger
				.error("ErrorCode ["
						+ AppConfig.config.getString(
								"errorcode_pattern", "VCC-USSD-")
						+ "00027] MSISDN["
						+ requestData.getMsisdn()
						+ "] [Some Parameters are Missing in VoiceNote deactivation request]");
				response = UssdCache.cache.get("error.xml");
				logger.info(String
						.format("[%s] Missing Mandatory parameters lang [%s] vn display menu [error.xml]",
								requestData.getMsisdn(), requestData.getLang()));
			}
		} catch (Exception e) {
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString(
							"errorcode_pattern", "VCC-USSD-")
					+ "00002] MSISDN["
					+ requestData.getMsisdn()
					+ "] [Exception while Sending Voice Note deactivation request to RuleEngine] Error["
					+ e.getMessage() + "]");
			logger.error(String.format("[%s] Error while vn deativation [%s]",
					requestData.getMsisdn(), e.getMessage()));
		}
		return response;
	}
}
