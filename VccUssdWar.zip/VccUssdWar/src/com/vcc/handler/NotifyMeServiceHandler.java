/**
 * The NotifyMeServiceHandler class process request and
 * response for NotifyService.
 * @author Mayank Agrawal
 */
package com.vcc.handler;

import org.apache.log4j.Logger;
import org.springframework.http.HttpHeaders;

import com.vcc.cache.UssdCache;
import com.vcc.common.UssdCommonOperation;
import com.vcc.config.AppConfig;
import com.vcc.request.NotifyMeRequest;
import com.vcc.domain.VccGmatMsgStore;

public class NotifyMeServiceHandler {

	private UssdCommonOperation commonOperation = null;
	final static Logger logger = Logger.getLogger(NotifyMeServiceHandler.class);
	private final static Logger errorLogger = Logger.getLogger("errorLogger");
	String response = null;

	/**
	 * This method process for notifyMeService menu
	 * 
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	public String getNotifyMeUssdMenu(HttpHeaders httpHeaders,
			NotifyMeRequest notifyMeRequest) {
		commonOperation = new UssdCommonOperation();
		commonOperation.getNotifyMeHeader(httpHeaders, notifyMeRequest);
		try {
			if (notifyMeRequest.getMsisdn() != null
					&& commonOperation.isValidateMsisdn(notifyMeRequest
							.getMsisdn())) {
				response = UssdCache.cache.get("notify_me_menu.xml");
				logger.info(String.format(
						"[%s] notify me menu [notify_me_menu.xml]",
						notifyMeRequest.getMsisdn()));
			} else {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-USSD-")
								+ "00006] MSISDN["
								+ notifyMeRequest.getMsisdn()
								+ "] [Some Parameters are Missing in NotifyMe Menu request]");
				logger.info(String
						.format("[%s] Mandatory parameter missing: notify me menu [error.xml]",
								notifyMeRequest.getMsisdn()));
				response = UssdCache.cache.get("error.xml");
			}
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-USSD-") + "00007] MSISDN["
					+ notifyMeRequest.getMsisdn()
					+ "] [Exception while displaying notify.me.menu] Error["
					+ e.getMessage() + "]");

			response = UssdCache.cache.get("error.xml");
			logger.error(String.format(
					"[%s] Error while display notify.me.menu [error.xml] [%s]",
					notifyMeRequest.getMsisdn()));
		}
		return response;
	}

	/**
	 * This method process for subscribe notifyMeService
	 * 
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	public String subscribeNotifyMe(HttpHeaders httpHeaders,
			NotifyMeRequest notifyMeRequest, VccGmatMsgStore vccGmatMsgStore) {
		commonOperation = new UssdCommonOperation();
		commonOperation.getNotifyMeHeader(httpHeaders, notifyMeRequest);
		SubUnsubNotifyMeHandler notifyMeHandler = new SubUnsubNotifyMeHandler();
		String response = null;
		try {
			if (notifyMeRequest.getMsisdn() != null
					&& notifyMeRequest.getLang() != 0
					&& commonOperation.isValidateMsisdn(notifyMeRequest
							.getMsisdn())) {
				notifyMeHandler.sendActivateNotifyMeReq(notifyMeRequest,
						vccGmatMsgStore);
				if (notifyMeRequest.getLang() == 2) {
					response = UssdCache.cache.get("en_service_status.xml");
					logger.info(String
							.format("[%s] notify me activation menu [ar_service_status.xml]",
									notifyMeRequest.getMsisdn()));
				} else {
					response = UssdCache.cache.get("ar_service_status.xml");
					logger.info(String
							.format("[%s] notify me activation menu [en_service_status.xml]",
									notifyMeRequest.getMsisdn()));
				}
			} else {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-USSD-")
								+ "00008] MSISDN["
								+ notifyMeRequest.getMsisdn()
								+ "] [Some Parameters are Missing in notifyme Activation request]");

				logger.info(String
						.format("[%s] Mandatory parameter missing: notify me activation menu [error.xml]",
								notifyMeRequest.getMsisdn()));
				response = UssdCache.cache.get("error.xml");
			}
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-USSD-") + "00009] MSISDN["
					+ notifyMeRequest.getMsisdn()
					+ "] [Exception while notifyme activation request] Error["
					+ e.getMessage() + "]");

			response = UssdCache.cache.get("error.xml");
			logger.error(String
					.format("[%s] Error while notify me action request [error.xml] [%s]",
							notifyMeRequest.getMsisdn(), e.getMessage()));
		}
		return response;
	}

	/**
	 * This method process for unsubscribe notifyMeService
	 * 
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	public String unsubscribeNotifyMe(HttpHeaders httpHeaders,
			NotifyMeRequest notifyMeRequest, VccGmatMsgStore vccGmatMsgStore) {
		commonOperation = new UssdCommonOperation();
		commonOperation.getNotifyMeHeader(httpHeaders, notifyMeRequest);
		SubUnsubNotifyMeHandler notifyMeHandler = new SubUnsubNotifyMeHandler();
		try {
			if (notifyMeRequest.getMsisdn() != null
					&& notifyMeRequest.getLang() != 0
					&& commonOperation.isValidateMsisdn(notifyMeRequest
							.getMsisdn())) {
				notifyMeHandler.sendDeActivateNotifyMeReq(notifyMeRequest,
						vccGmatMsgStore);
				if (notifyMeRequest.getLang() == 2) {
					response = UssdCache.cache.get("en_service_status.xml");
					logger.info(String
							.format("[%s] notify me deactivation menu [ar_service_status.xml]",
									notifyMeRequest.getMsisdn()));
				} else {
					response = UssdCache.cache.get("ar_service_status.xml");
					logger.info(String
							.format("[%s] notify me deactivation menu [en_service_status.xml]",
									notifyMeRequest.getMsisdn()));
				}
			} else {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-USSD-")
								+ "00010] MSISDN["
								+ notifyMeRequest.getMsisdn()
								+ "] [Some Parameters are Missing in notifyme deactivation request]");

				logger.info(String
						.format("[%s] Mandatory parameter missing: notify me deactivation menu [error.xml]",
								notifyMeRequest.getMsisdn()));
				response = UssdCache.cache.get("error.xml");
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-USSD-")
							+ "00011] MSISDN["
							+ notifyMeRequest.getMsisdn()
							+ "] [Exception while notifyme deactivation request] Error["
							+ e.getMessage() + "]");

			
			response = UssdCache.cache.get("error.xml");
			logger.error(String.format(
					"[%s] Error while notify me deaction request [error.xml]",
					notifyMeRequest.getMsisdn(), e.getMessage()));
		}
		return response;
	}
}
