/**
 * The VoiceMailServiceHandler class process request of 
 * voice-mail service that send activation and deactivation 
 * request to rule-engine server   .
 * @author Mayank Agrawal
 */

package com.vcc.handler;

import org.apache.log4j.Logger;
import org.springframework.http.HttpHeaders;

import tele.common.filebase.Logging;

import com.google.gson.JsonParser;
import com.vcc.cache.UssdCache;
import com.vcc.common.UssdCommonOperation;
import com.vcc.config.AppConfig;
import com.vcc.request.VmVnRequestData;
import com.vcc.util.Utility;

public class VoiceMailServiceHandler {

	final static Logger logger = Logger
			.getLogger(VoiceMailServiceHandler.class);
	private final static Logger errorLogger = Logger.getLogger("errorLogger");
	private UssdCommonOperation commonOperation = null;
	private String response = null;
	private JsonParser parser = new JsonParser();
	Logging logging = new Logging();

	/**
	 * This method process for voice-mail & voice-note service menu
	 * 
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	public String getVoiceMailVoiceNoteMenu(HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		try {
			commonOperation = new UssdCommonOperation();
			commonOperation.getRequestHeader(httpHeaders, requestData);
			if (requestData.getMsisdn() != null
					&& Utility.isValidateMsisdn(requestData.getMsisdn())) {
				response = UssdCache.cache.get("vmVnMenu.xml");
			} else {
				response = UssdCache.cache.get("error.xml");
				logger.trace(String.format("[%s] vm main menu msisdn missing",
						requestData.getMsisdn()));
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-USSD-")
							+ "00014] MSISDN["
							+ requestData.getMsisdn()
							+ "] [Exception while displaying Voice Mail/Voice Note Main Menu] Error["
							+ e.getMessage() + "]");

			
			logger.error(String.format(
					"[%s] voice mail main menu exception [%s]",
					requestData.getMsisdn(), e.getMessage()));
		}
		return response;
	}

	/**
	 * This method process for voice-mail service menu
	 * 
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	public String getVoiceMailMenu(HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		try {
			commonOperation = new UssdCommonOperation();
			commonOperation.getRequestHeader(httpHeaders, requestData);
			try {
				requestData.setServiceType("0010");
				requestData.setActionId(AppConfig.config
						.getString("sub_type_actionId"));
				String subTypeRes = commonOperation
						.sendSubUnscribeRequest(commonOperation
								.getJsonObj(requestData));
				logger.info(String.format(
						"[%s] getting sub type from ruleEngine [%s]",
						requestData.getMsisdn(), subTypeRes));
				requestData.setSubType(AppConfig.config.getString(
						"sub.type."
								+ parser.parse(subTypeRes).getAsJsonObject()
										.get("subType").getAsString(),
						"N"));
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-USSD-")
								+ "00015] MSISDN["
								+ requestData.getMsisdn()
								+ "] [Exception while getting SubType from RuleEngine] Error["
								+ e.getMessage() + "]");
				logger.error(String
						.format("[%s] [%s] Error while getting subtype from ruleEngine [%s]",
								requestData.getMsisdn(), requestData.getLang(),
								e.getMessage()));
			}
			if (requestData.getMsisdn() != null
					&& requestData.getSubType() != null
					&& requestData.getLang() != 0
					&& Utility.isValidateMsisdn(requestData.getMsisdn())
					&& Utility.isValidateSubType(requestData.getSubType())) {
				if (requestData.getSubType().equalsIgnoreCase("P") || requestData.getSubType().equals("N")) {
					if (requestData.getLang() == 1) {
						response = UssdCache.cache.get("ar_bs_vm_menu.xml");
					} else {
						response = UssdCache.cache.get("en_bs_vm_menu.xml");
					}
				} else if (requestData.getSubType()
						.equalsIgnoreCase("O")) {
					if (requestData.getLang() == 1) {
						response = UssdCache.cache.get("ar_postpaid_vm.xml");
					} else {
						response = UssdCache.cache.get("en_postpaid_vm.xml");
					}
				}
				if(response.indexOf("actTrg")!= -1){
					response = response.replaceAll("actTrg=1","actTrg=1&amp;subType="+requestData.getSubType());
					response = response.replaceAll("actTrg=2","actTrg=2&amp;subType="+requestData.getSubType());
					response = response.replaceAll("actTrg=3","actTrg=3&amp;subType="+requestData.getSubType());
					response = response.replaceAll("actTrg=4","actTrg=4&amp;subType="+requestData.getSubType());
				}
			} else {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-USSD-")
								+ "00016] MSISDN["
								+ requestData.getMsisdn()
								+ "] [Some Parameters are Missing in VoiceMail Menu request]");
				logger.info(String
						.format("[%s] one of the mandatery parameter missing subType [%s] lang [%s]",
								requestData.getMsisdn(),
								requestData.getSubType(), requestData.getLang()));
				response = UssdCache.cache.get("error.xml");
			}
		} catch (Exception e) {

			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-USSD-") + "00017] MSISDN["
					+ requestData.getMsisdn()
					+ "] [Exception while displaying Voice Mail Menu] Error["
					+ e.getMessage() + "]");

			
			logger.error(String
					.format("[%s] Error while display voice mail menu subType [%s] [%s]",
							requestData.getMsisdn(), requestData.getSubType(),
							e.getMessage()));
		}
		return response;
	}

	/**
	 * This method process for basic voice-mail service menu
	 * 
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	public String getBasicVmServices(HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		try {
			commonOperation = new UssdCommonOperation();
			commonOperation.getRequestHeader(httpHeaders, requestData);
			try {
				requestData.setServiceType("0010");
				if(requestData.getSubType()==null || (!requestData.getSubType().equalsIgnoreCase("F") && !requestData.getSubType().equalsIgnoreCase("O") && !requestData.getSubType().equalsIgnoreCase("P")))
					{
					requestData.setActionId(AppConfig.config
						.getString("sub_type_actionId"));
				String subTypeRes = commonOperation
						.sendSubUnscribeRequest(commonOperation
								.getJsonObj(requestData));

				logger.info(String.format(
						"[%s] getting sub type from ruleEngine Basic VM Services [%s]",
						requestData.getMsisdn(), subTypeRes));
				requestData.setSubType(AppConfig.config.getString(
						"sub.type."
								+ parser.parse(subTypeRes).getAsJsonObject()
										.get("subType").getAsString(),
						"P"));
			}
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-USSD-")
								+ "00015] MSISDN["
								+ requestData.getMsisdn()
								+ "] [Exception while getting SubType from RuleEngine] Error["
								+ e.getMessage() + "]");

				
				logger.error(String
						.format("[%s] error while getting subtype from ruleEngine [%s]",
								requestData.getMsisdn(), e.getMessage()));
			}
			if (requestData.getMsisdn() != null
					&& requestData.getSubType() != null
					&& requestData.getLang() != 0
					&& requestData.getPlanName() != null
					&& Utility.isValidateMsisdn(requestData.getMsisdn())
					&& Utility.isValidateSubType(requestData.getSubType())) {
				if (requestData.getLang() == 1) {
					response = UssdCache.cache.get("ar_bs_vm_menu.xml");
					logger.info(String.format(
							"[%s] lang [%s] menu [ar_bs_vm_menu.xml]",
							requestData.getMsisdn(), requestData.getLang()));
				} else {
					response = UssdCache.cache.get("en_bs_vm_menu.xml");
					logger.info(String.format(
							"[%s] lang [%s] menu [en_bs_vm_menu.xml]",
							requestData.getMsisdn(), requestData.getLang()));
				}
			} else {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-USSD-")
								+ "00018] MSISDN["
								+ requestData.getMsisdn()
								+ "] [Some Parameters are Missing in VoiceMail Basic Menu request]");
				logger.info(String
						.format("[%s] Mandatory parameter missing subType [%s] lang [%s] plan [%s]",
								requestData.getMsisdn(),
								requestData.getSubType(),
								requestData.getLang(),
								requestData.getPlanName()));
				response = UssdCache.cache.get("error.xml");
			}
			if(response.indexOf("actTrg")!= -1){
				response = response.replaceAll("actTrg=1","actTrg=1&amp;subType="+requestData.getSubType());
				response = response.replaceAll("actTrg=2","actTrg=2&amp;subType="+requestData.getSubType());
				response = response.replaceAll("actTrg=3","actTrg=3&amp;subType="+requestData.getSubType());
				response = response.replaceAll("actTrg=4","actTrg=4&amp;subType="+requestData.getSubType());
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-USSD-")
							+ "00019] MSISDN["
							+ requestData.getMsisdn()
							+ "] [Exception while displaying Voice Mail Basic Menu] Error["
							+ e.getMessage() + "]");

			
			logger.error(String.format(
					"[%s] Error while display basic voice mail [%s]",
					requestData.getMsisdn(), e.getMessage()));
		}
		return response;
	}

	/**
	 * This method process for executive voice-mail service menu
	 * 
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	public String getExecutiveVmServices(HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		try {
			commonOperation = new UssdCommonOperation();
			commonOperation.getRequestHeader(httpHeaders, requestData);
			if (requestData.getMsisdn() != null && requestData.getLang() != 0
					&& requestData.getPlanName() != null
					&& Utility.isValidateMsisdn(requestData.getMsisdn())) {
				if (requestData.getLang() == 1) {
					response = UssdCache.cache.get("ar_ex_vm_menu.xml");
					logger.info(String.format(
							"[%s] lang [%s] display menu [en_ex_vm_menu.xml]",
							requestData.getMsisdn(), requestData.getLang()));
				} else {
					response = UssdCache.cache.get("en_ex_vm_menu.xml");
					logger.info(String.format(
							"[%s] lang [%s] display menu [ar_ex_vm_menu.xml]",
							requestData.getMsisdn(), requestData.getLang()));
				}
			} else {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-USSD-")
								+ "00020] MSISDN["
								+ requestData.getMsisdn()
								+ "] [Some Parameters are Missing in VoiceMail executive Menu request]");
				logger.info(String
						.format("[%s] Mandatory parameter missing lang [%s] subType [%s]",
								requestData.getMsisdn(), requestData.getLang(),
								requestData.getSubType()));
				response = UssdCache.cache.get("error.xml");
			}
			if(response.indexOf("actTrg")!= -1){
				response = response.replaceAll("actTrg=1","actTrg=1&amp;subType=O");
				response = response.replaceAll("actTrg=2","actTrg=2&amp;subType=O");
				response = response.replaceAll("actTrg=3","actTrg=3&amp;subType=O");
				response = response.replaceAll("actTrg=4","actTrg=4&amp;subType=O");
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-USSD-")
							+ "00021] MSISDN["
							+ requestData.getMsisdn()
							+ "] [Exception while displaying Voice Mail Executive Menu] Error["
							+ e.getMessage() + "]");
			
			logger.error(String.format("[%s] Error while display menu [%s]",
					requestData.getMsisdn(), e.getMessage()));
		}
		return response;
	}

	/**
	 * This method process for subscribe voice-mail service
	 * 
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	public String subscribeVmService(HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		try {
			commonOperation = new UssdCommonOperation();
			commonOperation.getRequestHeader(httpHeaders, requestData);

			try {
				requestData.setServiceType("0010");
				if(requestData.getSubType()==null || (!requestData.getSubType().equalsIgnoreCase("F") && !requestData.getSubType().equalsIgnoreCase("O") && !requestData.getSubType().equalsIgnoreCase("P")))
				{
				requestData.setActionId(AppConfig.config
						.getString("sub_type_actionId"));
				String subTypeRes = commonOperation
						.sendSubUnscribeRequest(commonOperation
								.getJsonObj(requestData));

				logger.info(String
						.format("[%s] vm activation getting subtype from ruleEngine [%s]",
								requestData.getMsisdn(), subTypeRes));
				requestData.setSubType(AppConfig.config.getString(
						"sub.type."
								+ parser.parse(subTypeRes).getAsJsonObject()
										.get("subType").getAsString(),
						"P"));
				}
			} catch (Exception e) {

				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-USSD-")
								+ "00015] MSISDN["
								+ requestData.getMsisdn()
								+ "] [Exception while getting SubType from RuleEngine] Error["
								+ e.getMessage() + "]");

				
				logger.error(String
						.format("[%s] vm activation: Error while getting subtype from ruleEngine [%s]",
								requestData.getMsisdn(), e.getMessage()));
			}
			try {
				logger.info(String
						.format("[%s] lang [%s] subtype [%s] plan [%s] active trigger [%s]",
								requestData.getMsisdn(), requestData.getLang(),
								requestData.getSubType(),
								requestData.getPlanName(),
								requestData.getActTrg()));
				if (requestData.getMsisdn() != null
						&& requestData.getLang() != 0
						&& requestData.getSubType() != null
						&& requestData.getPlanName() != null
						&& requestData.getActTrg() != 0
						&& Utility.isValidateMsisdn(requestData.getMsisdn())
						&& Utility.isValidateSubType(requestData.getSubType())) {
					requestData.setServiceType("0010");
					requestData.setActionId(AppConfig.config
							.getString("sub_actionId"));
					String json = commonOperation.getJsonObj(requestData);
					logger.info("Subscribe json request " + json);
					logger.info(String
							.format("[%s] action id [%s] activation request for ruleEngine [%s]",
									requestData.getMsisdn(),
									requestData.getActionId(), json));
					String ruleEngineResponse = commonOperation
							.sendSubUnscribeRequest(json);
					logger.info(String.format("[%s] activation response [%s]",
							requestData.getMsisdn(), ruleEngineResponse));
					logging.write("voice mail subscribe request " + json
							+ " subscribe response " + ruleEngineResponse);
					if (requestData.getLang() == 1) {
						response = UssdCache.cache.get("ar_final_rpy.xml");
						logger.info(String.format(
								"[%s] display menu [ar_final_rpy.xml]",
								requestData.getMsisdn()));
					} else {
						response = UssdCache.cache.get("en_final_rpy.xml");
						logger.info(String.format(
								"[%s] display menu [en_final_rpy.xml]",
								requestData.getMsisdn()));
					}
				} else {
					errorLogger
							.error("ErrorCode ["
									+ AppConfig.config.getString(
											"errorcode_pattern", "VCC-USSD-")
									+ "00022] MSISDN["
									+ requestData.getMsisdn()
									+ "] [Some Parameters are Missing in VoiceMail activation request]");
					logger.info(String
							.format("[%s] Mandatory parameter missing lang [%s] subtype [%s] plan [%s] active triggers [%s]",
									requestData.getMsisdn(),
									requestData.getLang(),
									requestData.getSubType(),
									requestData.getPlanName(),
									requestData.getActTrg()));
					response = UssdCache.cache.get("error.xml");
				}
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-USSD-")
								+ "00002] MSISDN["
								+ requestData.getMsisdn()
								+ "] [Exception while Sending Voice Mail Activation request to RuleEngine] Error["
								+ e.getMessage() + "]");

				
				logger.error(String
						.format("[%s] Error while activation reuqest to ruleEngine [%s]",
								requestData.getMsisdn(), e.getMessage()));
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-USSD-")
							+ "00002] MSISDN["
							+ requestData.getMsisdn()
							+ "] [Exception while Sending Voice Mail Activation request RuleEngine] Error["
							+ e.getMessage() + "]");

			
			logger.error(String.format(
					"[%s] Error while activation reuqest to ruleEngine [%s]",
					requestData.getMsisdn(), e.getMessage()));
		}
		return response;
	}

	/**
	 * This method process for unsubscribe voice-mail service
	 * 
	 * @Param requestData contains url data
	 * @Param httpHeaders conatains msisdn & subtype of user in url header
	 * @return xml response in string format
	 */
	public String unSubscribeVmService(HttpHeaders httpHeaders,
			VmVnRequestData requestData) {
		try {
			commonOperation = new UssdCommonOperation();
			commonOperation.getRequestHeader(httpHeaders, requestData);

			if (requestData.getMsisdn() != null && requestData.getLang() != 0
					&& requestData.getPlanName() != null
					&& Utility.isValidateMsisdn(requestData.getMsisdn())) {
				requestData.setServiceType("0010");
				requestData.setActionId(AppConfig.config
						.getString("unsub_actionId"));
				String json = commonOperation.getJsonObj(requestData);
				logger.info("Unsubscribe json request " + json);
				logger.info(String.format(
						"[%s] deactivation request for ruleEngine [%s]",
						requestData.getMsisdn(), json));
				String ruleEngineResponse = commonOperation
						.sendSubUnscribeRequest(json);

				logger.info(String.format(
						"[%s] deactivate response from ruleEngine [%s]",
						requestData.getMsisdn(), ruleEngineResponse));
				logging.write("voice mail unsubscribe request " + json
						+ " response " + ruleEngineResponse);
				if (requestData.getLang() == 1) {
					response = UssdCache.cache.get("ar_final_rpy.xml");
					logger.info(String.format(
							"[%s] display menu [ar_final_rpy.xml]",
							requestData.getMsisdn()));
				} else {
					response = UssdCache.cache.get("en_final_rpy.xml");
					logger.info(String.format(
							"[%s] display menu [en_final_rpy.xml]",
							requestData.getMsisdn()));
				}
			} else {
				errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-USSD-")
								+ "00023] MSISDN["
								+ requestData.getMsisdn()
								+ "] [Some Parameters are Missing in VoiceMail deactivation request]");
				logger.info(String.format(
						"[%s] Mandatory parameter missing lang [%s]",
						requestData.getMsisdn()));
				response = UssdCache.cache.get("error.xml");
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-USSD-")
							+ "00002] MSISDN["
							+ requestData.getMsisdn()
							+ "] [Exception while Sending Voice Mail Deactivation request RuleEngine] Error["
							+ e.getMessage() + "]");
			logger.error(String.format(
					"[%s] Error while deactivation request [%s]",
					requestData.getMsisdn(), e.getMessage()));
		}
		return response;
	}

}
