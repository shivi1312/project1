/**
 * The SubUnsubNotifyMeHandler class send activation and 
 * deactivation request of NotifyMeService to Mobileum 
 * server by soap based wsdl web service.
 * @author Mayank Agrawal
 */

package com.vcc.handler;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

//import org.apache.axis.AxisProperties;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import tele.common.filebase.Logging;

import com.conn.HttpConnectionPool.HttpConnectionPool;
import com.google.gson.Gson;
import com.missedcallalertsnotifycallerservice.www.MCANotifyCallerServiceStub;
import com.telemune.response.VnResponse;
import com.vcc.config.AppConfig;
import com.vcc.domain.VccGmatMsgStore;
import com.vcc.request.NotifyMeRequest;

@SuppressWarnings("unused")
public class SubUnsubNotifyMeHandler {

	// private NotifyCallerSoapBindingStub stub = null;
	private MCANotifyCallerServiceStub stub = null;
	Logging logging = new Logging();
	final static Logger logger = Logger
			.getLogger(SubUnsubNotifyMeHandler.class);
	private final static Logger errorLogger = Logger.getLogger("errorLogger");
	private final static Logger urlErrorLogger = Logger
			.getLogger("urlErrorLogger");
	int urlTry = 0;

	/**
	 * This method send activation notifyMe service request to mobileum server
	 * via soap based webservice
	 * 
	 * @param notifyMeRequest
	 *            contains user data
	 */
	public void sendActivateNotifyMeReq(NotifyMeRequest notifyMeRequest,
			VccGmatMsgStore vccGmatMsgStore) {

		String url = "";
		if (AppConfig.config.getInt("notify_multiple_url_enable", 0) == 1) {
			url = getUrl(notifyMeRequest.getMsisdn());
		} else {
			url = AppConfig.config
					.getString("notify.me.act.dact.url",
							"https://10.183.126.130:8445/mca_service/services/NotifyCallerPort");
		}
		this.sendActNotifyMeRequest(notifyMeRequest, vccGmatMsgStore, url);
	}

	/**
	 * This method send deactivation notifyMe service request to mobileum server
	 * via soap based webservice
	 * 
	 * @param notifyMeRequest
	 *            contains user data
	 */
	public void sendDeActivateNotifyMeReq(NotifyMeRequest notifyMeRequest,
			VccGmatMsgStore vccGmatMsgStore) {

		String url = "";
		if (AppConfig.config.getInt("notify_multiple_url_enable", 0) == 1) {
			url = getUrl(notifyMeRequest.getMsisdn());
		} else {
			url = AppConfig.config
					.getString("notify.me.act.dact.url",
							"https://10.237.104.141:8445/mca_service/services/NotifyCallerPort");
		}
		this.sendDeActNotifyMeRequest(notifyMeRequest, vccGmatMsgStore, url);

	}

	public String sendNotifyMeUnsubToTibaco(NotifyMeRequest notifyMeRequest) {

		String retVal = "fail";
		HttpGet get = null;
		String url = "";
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		String encodingString = "UTF-8";
		StringBuilder requestUrl = null;
		try {
			url = AppConfig.config.getString("crmclient_url")
					+ "notifyme.deact";
			requestUrl = new StringBuilder(url);
			params.add(new BasicNameValuePair("msisdn", notifyMeRequest
					.getMsisdn()));
			params.add(new BasicNameValuePair("language", notifyMeRequest
					.getLang() + ""));
			params.add(new BasicNameValuePair("serviceType", "0001"));
			params.add(new BasicNameValuePair("transactionId", String
					.valueOf(System.nanoTime())));
			String query = URLEncodedUtils.format(params, encodingString);
			requestUrl.append("?");
			requestUrl.append(query);
			logger.info("MSISDN[" + notifyMeRequest.getMsisdn()
					+ "] URL : VccCrmClient [" + requestUrl.toString() + "]");
			CloseableHttpClient client = HttpConnectionPool.getInstance().httpClient();
			get = new HttpGet(requestUrl.toString());
			HttpResponse response = client.execute(get);
			String responseBody = EntityUtils.toString(response.getEntity());
			int responseCode = response.getStatusLine().getStatusCode();
			VnResponse vnResponse = null;
			if (responseCode == 200) {
				vnResponse = (VnResponse) new Gson().fromJson(
						responseBody.trim().substring(0,
								responseBody.lastIndexOf("}") + 1),
						VnResponse.class);
				retVal = vnResponse.getStatus();
			} else {
				retVal = "fail";
				logger.info("MSISDN[" + notifyMeRequest.getMsisdn()
						+ "] [Getting Fail Response from VccCrmClient]");

			}

		} catch (SocketTimeoutException socExe) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-USSD-")
							+ "00029] MSISDN["
							+ notifyMeRequest.getMsisdn()
							+ "] [SocketTimeOut Exception while Connecting to VccCrmClient] Error["
							+ socExe.getMessage() + "]");
			socExe.printStackTrace();
			retVal = "fail";

		} catch (ConnectException conExe) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-USSD-")
							+ "00030] MSISDN["
							+ notifyMeRequest.getMsisdn()
							+ "]  [Http connection is not established with VccCrmClient] Error["
							+ conExe.getMessage() + "]");
			retVal = "fail";
		} catch (Exception exe) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-USSD-") + "00031] MSISDN["
					+ notifyMeRequest.getMsisdn()
					+ "] [Exception while Connecting to VccCrmClient] Error["
					+ exe.getMessage() + "]");
			logger.info(
					"Getting the exception in side function sendNotifyMeUnsubToTibaco()..... ",
					exe);
			retVal = "fail";
		}
		return retVal;
	}

	public String sendNotifyMeSubToTibaco(NotifyMeRequest notifyMeRequest) {

		String retVal = "fail";
		HttpGet get = null;
		String url = "";
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		String encodingString = "UTF-8";
		StringBuilder requestUrl = null;
		try {
			url = AppConfig.config.getString("crmclient_url") + "notifyme.act";
			requestUrl = new StringBuilder(url);
			params.add(new BasicNameValuePair("msisdn", notifyMeRequest
					.getMsisdn()));
			params.add(new BasicNameValuePair("language", notifyMeRequest
					.getLang() + ""));
			params.add(new BasicNameValuePair("serviceType", "0001"));
			params.add(new BasicNameValuePair("transactionId", String
					.valueOf(System.nanoTime())));
			String query = URLEncodedUtils.format(params, encodingString);
			requestUrl.append("?");
			requestUrl.append(query);
			logger.info("MSISDN[" + notifyMeRequest.getMsisdn()
					+ "] URL : VccCrmClient [" + requestUrl.toString() + "]");
			CloseableHttpClient client = HttpConnectionPool.getInstance().httpClient();
			get = new HttpGet(requestUrl.toString());
			HttpResponse response = client.execute(get);
			String responseBody = EntityUtils.toString(response.getEntity());
			int responseCode = response.getStatusLine().getStatusCode();
			VnResponse vnResponse = null;
			if (responseCode == 200) {
				vnResponse = (VnResponse) new Gson().fromJson(
						responseBody.trim().substring(0,
								responseBody.lastIndexOf("}") + 1),
						VnResponse.class);
				retVal = vnResponse.getStatus();
			} else {
				retVal = "fail";
				logger.info("MSISDN[" + notifyMeRequest.getMsisdn()
						+ "] [Getting Fail Response from VccCrmClient]");

			}

		} catch (SocketTimeoutException socExe) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-USSD-")
							+ "00029] MSISDN["
							+ notifyMeRequest.getMsisdn()
							+ "] [SocketTimeOut Exception while Connecting to VccCrmClient] Error["
							+ socExe.getMessage() + "]");
			socExe.printStackTrace();
			retVal = "fail";

		} catch (ConnectException conExe) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-USSD-")
							+ "00030] MSISDN["
							+ notifyMeRequest.getMsisdn()
							+ "]  [Http connection is not established with VccCrmClient] Error["
							+ conExe.getMessage() + "]");
			retVal = "fail";
		} catch (Exception exe) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-USSD-") + "00031] MSISDN["
					+ notifyMeRequest.getMsisdn()
					+ "] [Exception while Connecting to VccCrmClient] Error["
					+ exe.getMessage() + "]");
			logger.info(
					"Getting the exception in side function sendNotifyMeUnsubToTibaco()..... ",
					exe);
			retVal = "fail";
		}
		return retVal;
	}

	public String getUrl(String msisdn) {
		String url = "";
		if (Integer.parseInt(msisdn.substring(msisdn.length() - 1)) % 2 == 0) {
			url = AppConfig.config
					.getString("notify.me.act.dact.url_even",
							"https://10.183.126.130:8445/mca_service/services/NotifyCallerPort");
			logger.info("Returning even url[" + url + "] msisdn[" + msisdn
					+ "]");
		} else {
			url = AppConfig.config
					.getString("notify.me.act.dact.url_odd",
							"https://10.183.126.131:8445/mca_service/services/NotifyCallerPort");
			logger.info("Returning odd url [" + url + "] msisdn[" + msisdn
					+ "]");
		}
		return url;
	}

	public void sendActNotifyMeRequest(NotifyMeRequest notifyMeRequest,
			VccGmatMsgStore vccGmatMsgStore, String url) {
		urlTry++;
		/*
		 * AxisProperties.setProperty("axis.socketSecureFactory",
		 * "org.apache.axis.components.net.SunFakeTrustSocketFactory");
		 */
		try {

			/*
			 * stub = new NotifyCallerSoapBindingStub(new URL(url), new
			 * org.apache.axis.client.Service());
			 */

			stub = new MCANotifyCallerServiceStub(url);
			MCANotifyCallerServiceStub.MCASubscriptionRequest mCASubscriptionRequest = new MCANotifyCallerServiceStub.MCASubscriptionRequest();
			// MCASubscriptionRequest mcaSubscriptionRequest = new
			// MCASubscriptionRequest();

			MCANotifyCallerServiceStub.MSISDN msisdnBean = new MCANotifyCallerServiceStub.MSISDN();
			msisdnBean.setMSISDN(notifyMeRequest.getMsisdn());
			mCASubscriptionRequest.setMSISDN(msisdnBean);

			MCANotifyCallerServiceStub.ServiceType serviceTypeBean = new MCANotifyCallerServiceStub.ServiceType();
			serviceTypeBean.setServiceType(AppConfig.config.getString(
					"notify.me.service.type", "10000"));
			mCASubscriptionRequest.setServiceType(serviceTypeBean);

			MCANotifyCallerServiceStub.Language languageBean = new MCANotifyCallerServiceStub.Language();
			languageBean.setLanguage(AppConfig.config.getString("lang."
					+ notifyMeRequest.getLang(), "EN"));
			mCASubscriptionRequest.setLanguage(languageBean);

			mCASubscriptionRequest
					.setSMSFormat(MCANotifyCallerServiceStub.SMSFormat.SINGLE);

			mCASubscriptionRequest
					.setStatus(MCANotifyCallerServiceStub.Status.ACTIVE); // active

			mCASubscriptionRequest
					.setCOS(MCANotifyCallerServiceStub.COS.value1); // 0

			/*
			 * mcaSubscriptionRequest.setCOS(COS.fromString(AppConfig.config
			 * .getString("notify.me.cos", "1")));
			 * mcaSubscriptionRequest.setLanguage(AppConfig.config.getString(
			 * "lang." + notifyMeRequest.getLang(), "EN"));
			 * mcaSubscriptionRequest.setMSISDN(notifyMeRequest.getMsisdn());
			 * mcaSubscriptionRequest.setServiceType(AppConfig.config.getString(
			 * "notify.me.service.type", "10000"));
			 * mcaSubscriptionRequest.setSMSFormat(SMSFormat
			 * .fromString(AppConfig.config.getString( "notify.me.sms.format",
			 * "SINGLE")));
			 * mcaSubscriptionRequest.setStatus(Status.fromString("ACTIVE"));
			 */
			logger.info("[Sending Subscription request for notify me] msisdn["
					+ notifyMeRequest.getMsisdn() + "] Url[" + url + "]");
			MCANotifyCallerServiceStub.MCASubscriptionResponse mCASubscriptionResponseBean = stub
					.mCASubscription(mCASubscriptionRequest);
			/*
			 * MCASubscriptionResponse mcaSubscriptionResponse = stub
			 * .MCASubscription(mcaSubscriptionRequest);
			 */
			String response = mCASubscriptionResponseBean.getResponseMessage();
			logger.info("Response is" + response);
			String tempId = null;
			String key = null;
			// String key=tempId+"-"+notifyMeRequest.getLang();
			if (response.indexOf("ADDED") != -1) {
				tempId = AppConfig.config.getString("notifySubTempId", "1");
				key = tempId + "-" + notifyMeRequest.getLang();

				boolean result = vccGmatMsgStore.insertIntoGmatMsg(
						notifyMeRequest.getMsisdn(), notifyMeRequest.getLang(),
						key, "NA");

				// Added by AbhiShek Rana
				if (AppConfig.config.getBoolean("is_crm_enable_for_notifyme",
						false)) {
					String status = this
							.sendNotifyMeSubToTibaco(notifyMeRequest);
					logger.info("MSISDN[" + notifyMeRequest.getMsisdn()
							+ "] Activation Response from VccCrmClient : ["
							+ status + "]");
				}
			} else if (response.indexOf("FAILED") != -1) {
				tempId = AppConfig.config.getString("notifySubFailTempId", "2");
				key = tempId + "-" + notifyMeRequest.getLang();

				boolean result = vccGmatMsgStore.insertIntoGmatMsg(
						notifyMeRequest.getMsisdn(), notifyMeRequest.getLang(),
						key, "NA");
			} else {
				logger.info("Subscription response is invalid");
			}
			logger.info("["
					+ notifyMeRequest.getMsisdn()
					+ "] Service Type ["
					+ AppConfig.config.getString("notify.me.service.type",
							"00001") + "] Response [" + response + "]");
			logging.write(notifyMeRequest.toString() + "," + " response "
					+ response);
		} catch (Exception ex) {
			if (AppConfig.config.getInt("notify_multiple_url_enable", 0) == 1) {
				if (urlTry <= 1) {
					if (ex.getCause() instanceof java.net.ConnectException
							|| ex.getCause() instanceof java.net.SocketTimeoutException
							|| ex.getCause() instanceof org.apache.commons.httpclient.ConnectTimeoutException
							|| ex.getCause() instanceof org.apache.axis2.AxisFault) {
						if (url.equals(AppConfig.config
								.getString("notify.me.act.dact.url_odd",
										"https://10.183.126.131:8445/mca_service/services/NotifyCallerPort"))) {
							logger.error("[Exception while sending Notify Me Subscription request to Mobileum] Msisdn[ "
									+ notifyMeRequest.getMsisdn()
									+ "] Attempt["
									+ urlTry
									+ "]. Now going to hit url[ "
									+ AppConfig.config
											.getString(
													"notify.me.act.dact.url_odd_alternate",
													"https://10.183.126.133:8445/mca_service/services/NotifyCallerPort")
									+ "] Error[" + ex.getMessage() + "]");
							this.sendActNotifyMeRequest(
									notifyMeRequest,
									vccGmatMsgStore,
									AppConfig.config
											.getString(
													"notify.me.act.dact.url_odd_alternate",
													"https://10.183.126.133:8445/mca_service/services/NotifyCallerPort"));
						} else {
							logger.error("[Exception while sending Notify Me Subscription request to Mobileum] Msisdn[ "
									+ notifyMeRequest.getMsisdn()
									+ " ] Attempt["
									+ urlTry
									+ "]. Now going to hit url[ "
									+ AppConfig.config
											.getString(
													"notify.me.act.dact.url_even_alternate",
													"https://10.183.126.132:8445/mca_service/services/NotifyCallerPort")
									+ "] Error[" + ex.getMessage() + "]");
							this.sendActNotifyMeRequest(
									notifyMeRequest,
									vccGmatMsgStore,
									AppConfig.config
											.getString(
													"notify.me.act.dact.url_even_alternate",
													"https://10.183.126.132:8445/mca_service/services/NotifyCallerPort"));
						}
					} else {
						errorLogger
								.error("[Exception while sending Notify Me Subscription request to Mobileum.[ "
										+ notifyMeRequest
										+ " ] Error["
										+ ex.getMessage() + "]");
					}
				} else {
					urlErrorLogger
							.error("[Exception while sending Notify Me Subscription request to Mobileum. All Attempts Failed] "
									+ notifyMeRequest
									+ " ] URL["
									+ url
									+ "] Error[" + ex.getMessage() + "]");
				}
			} else {
				urlErrorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-USSD-")
								+ "00012] MSISDN["
								+ notifyMeRequest.getMsisdn()
								+ "] Language["
								+ notifyMeRequest.getLang()
								+ "] [Exception while sending Notify Me Subscription request to Mobileum] Error["
								+ ex.getMessage() + "]");
			}
		}
	}

	public void sendDeActNotifyMeRequest(NotifyMeRequest notifyMeRequest,
			VccGmatMsgStore vccGmatMsgStore, String url) {
		urlTry++;
		/*
		 * AxisProperties.setProperty("axis.socketSecureFactory",
		 * "org.apache.axis.components.net.SunFakeTrustSocketFactory");
		 */
		try {
			/*
			 * stub = new NotifyCallerSoapBindingStub(new URL(url), new
			 * org.apache.axis.client.Service());
			 */

			stub = new MCANotifyCallerServiceStub(url);

			/*
			 * MCAUnsubscriptionRequest mcaUnSubscriptionRequest = new
			 * MCAUnsubscriptionRequest();
			 */

			/*
			 * mcaUnSubscriptionRequest.setMSISDN(notifyMeRequest.getMsisdn());
			 * mcaUnSubscriptionRequest
			 * .setServiceType(AppConfig.config.getString(
			 * "notify.me.service.type", "0001"));
			 */
			MCANotifyCallerServiceStub.MCAUnsubscriptionRequest mCAUnsubscriptionRequest = new MCANotifyCallerServiceStub.MCAUnsubscriptionRequest();

			MCANotifyCallerServiceStub.MSISDN msisdnBeanUnsub = new MCANotifyCallerServiceStub.MSISDN();
			msisdnBeanUnsub.setMSISDN(notifyMeRequest.getMsisdn());
			mCAUnsubscriptionRequest.setMSISDN(msisdnBeanUnsub);

			MCANotifyCallerServiceStub.ServiceType serviceTypeBeanUnSub = new MCANotifyCallerServiceStub.ServiceType();
			serviceTypeBeanUnSub.setServiceType(AppConfig.config.getString(
					"notify.me.service.type", "0001"));
			mCAUnsubscriptionRequest.setServiceType(serviceTypeBeanUnSub);

			logger.info("[Sending Unsubscription request for notify me] msisdn["
					+ notifyMeRequest.getMsisdn() + "] Url[" + url + "]");
			MCANotifyCallerServiceStub.MCAUnsubscriptionResponse mCAUnsubscriptionResponseBean = stub
					.mCAUnsubscription(mCAUnsubscriptionRequest);

			/*
			 * MCAUnsubscriptionResponse mcaUnSubscriptionResponse = stub
			 * .MCAUnsubscription(mcaUnSubscriptionRequest);
			 */
			String response = mCAUnsubscriptionResponseBean
					.getResponseMessage();
			logger.info("Response is" + response);
			String tempId = null;
			String key = null;
			response = response.substring(response.lastIndexOf(":") + 1);
			if (response.indexOf("DELETED") != -1) {
				tempId = AppConfig.config.getString("notifyUnSubTempId", "1");
				key = tempId + "-" + notifyMeRequest.getLang();
				boolean result = vccGmatMsgStore.insertIntoGmatMsg(
						notifyMeRequest.getMsisdn(), notifyMeRequest.getLang(),
						key, "NA");
				// Added by AbhiShek Rana
				if (AppConfig.config.getBoolean("is_crm_enable_for_notifyme",
						false)) {
					String status = this
							.sendNotifyMeUnsubToTibaco(notifyMeRequest);
					logger.info("MSISDN[" + notifyMeRequest.getMsisdn()
							+ "] Deactivation Response from VccCrmClient : ["
							+ status + "]");
				}

			} else if (response.indexOf("FAILED") != -1) {
				tempId = AppConfig.config.getString("notifyUnSubFailTempId",
						"2");
				key = tempId + "-" + notifyMeRequest.getLang();
				boolean result = vccGmatMsgStore.insertIntoGmatMsg(
						notifyMeRequest.getMsisdn(), notifyMeRequest.getLang(),
						key, "NA");
			} else {
				logger.info("MSISDN[" + notifyMeRequest.getMsisdn()
						+ "] Unsubscription request is fail");
			}
			logger.info("["
					+ notifyMeRequest.getMsisdn()
					+ "] Service Type ["
					+ AppConfig.config.getString("notify.me.service.type",
							"00001") + "] Response [" + response + "]");
			logging.write(notifyMeRequest.toString() + "," + " response "
					+ response);
		} catch (Exception ex) {
			if (AppConfig.config.getInt("notify_multiple_url_enable", 0) == 1) {
				if (urlTry <= 1) {
					if (ex.getCause() instanceof java.net.ConnectException
							|| ex.getCause() instanceof java.net.SocketTimeoutException
							|| ex.getCause() instanceof org.apache.commons.httpclient.ConnectTimeoutException
							|| ex.getCause() instanceof org.apache.axis2.AxisFault) {
						if (url.equals(AppConfig.config
								.getString("notify.me.act.dact.url_odd",
										"https://10.183.126.131:8445/mca_service/services/NotifyCallerPort"))) {
							logger.error("[Exception while sending NotifyMe UnSubscription request to Mobileum] Msisdn["
									+ notifyMeRequest.getMsisdn()
									+ "] Attempt["
									+ urlTry
									+ "]. Now going to hit url["
									+ AppConfig.config
											.getString(
													"notify.me.act.dact.url_odd_alternate",
													"https://10.183.126.133:8445/mca_service/services/NotifyCallerPort")
									+ "] Error[" + ex.getMessage() + "]");
							this.sendDeActNotifyMeRequest(
									notifyMeRequest,
									vccGmatMsgStore,
									AppConfig.config
											.getString(
													"notify.me.act.dact.url_odd_alternate",
													"https://10.183.126.133:8445/mca_service/services/NotifyCallerPort"));
						} else {
							logger.error("[Exception while sending NotifyMe UnSubscription request to Mobileum] Msisdn["
									+ notifyMeRequest.getMsisdn()
									+ "] Attempt["
									+ urlTry
									+ "]. Now going to hit url["
									+ AppConfig.config
											.getString(
													"notify.me.act.dact.url_even_alternate",
													"https://10.183.126.132:8445/mca_service/services/NotifyCallerPort")
									+ "] Error[" + ex.getMessage() + "]");
							this.sendDeActNotifyMeRequest(
									notifyMeRequest,
									vccGmatMsgStore,
									AppConfig.config
											.getString(
													"notify.me.act.dact.url_even_alternate",
													"https://10.183.126.132:8445/mca_service/services/NotifyCallerPort"));
						}
					} else {
						errorLogger
								.error("[Exception while sending Notify Me UnSubscription request to Mobileum.[ "
										+ notifyMeRequest
										+ " ] Error["
										+ ex.getMessage() + "]");
					}
				} else {
					urlErrorLogger
							.error("[Exception while sending NotifyMe UnSubscription request to Mobileum. All Attempts Failed] "
									+ notifyMeRequest
									+ " ] url ["
									+ url
									+ "] Error [" + ex.getMessage() + "]");
				}
			} else {
				urlErrorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-USSD-")
								+ "00012] MSISDN["
								+ notifyMeRequest.getMsisdn()
								+ "] Language["
								+ notifyMeRequest.getLang()
								+ "] [Exception while sending UnSubscription request to Mobileum] Error["
								+ ex.getMessage() + "]");
			}
		}
	}

}
