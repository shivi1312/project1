/**
 * The UssdCommonOperation class implements common operation
 * for whole application like display header of url, send 
 * subscription json obectfor rule engine. 
 * @author Mayank Agrawal
 */

package com.vcc.common;

import org.apache.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.util.MultiValueMap;

import com.google.gson.Gson;
import com.vcc.config.AppConfig;
import com.vcc.model.VccRuleEngineRequest;
import com.vcc.model.VccRuleEngineResponse;
import com.vcc.net.ConnectionPool;
import com.vcc.net.TextSocketConnection;
import com.vcc.request.NotifyMeRequest;
import com.vcc.request.VmVnRequestData;
import com.vcc.util.TcpPool;

public class UssdCommonOperation {

	final static Logger logger = Logger.getLogger(UssdCommonOperation.class);
	private final static Logger errorLogger = Logger.getLogger("errorLogger");

	@SuppressWarnings("unused")
	private VccRuleEngineResponse ruleEngineResponse = null;

	/**
	 * This method display voice-mail & voice-note service url header in log
	 * file
	 * 
	 * @Param vmVnrequestData contains url header data
	 * @Param httpHeaders conatains data in header include by url
	 */
	public void getRequestHeader(HttpHeaders httpHeaders,
			VmVnRequestData vmVnrequestData) {
		StringBuilder stringBuilder = new StringBuilder();
		try {
			MultiValueMap<String, String> map = httpHeaders;
			for (String key : map.keySet()) {
				stringBuilder.append(key + ":" + map.get(key).get(0) + " ");
			}
			if (map.containsKey("User-MSISDN")) {
				vmVnrequestData.setMsisdn(map.get("User-MSISDN").get(0));
			}
			if (map.containsKey("User-Subscription")) {
				vmVnrequestData.setSubType(map.get("User-Subscription").get(0));
			}
		} catch (NullPointerException npe) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-USSD-")+"90003] [NullPointer Exception in getting VM/VN RequestHeaders] Error["+ npe.getMessage() +"]");
		}
		logger.info("Request header: " + stringBuilder.toString());
	}

	/**
	 * This method display notifyMe service url header in log file
	 * 
	 * @Param notifyMeRequest contains url header data
	 * @Param httpHeaders conatains data in header include by url
	 */
	public void getNotifyMeHeader(HttpHeaders httpHeaders,
			NotifyMeRequest notifyMeRequest) {
		MultiValueMap<String, String> map = httpHeaders;
		StringBuilder stringBuilder = new StringBuilder();
		try{
		for (String key : map.keySet()) {
			stringBuilder.append(key + ":" + map.get(key).get(0) + " ");
		}
		if (map.containsKey("User-MSISDN")) {
			notifyMeRequest.setMsisdn(map.get("User-MSISDN").get(0));
			;
		}}catch(NullPointerException npe){
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-USSD-")+"90003] [NullPointer Exception in getting NotifyMe RequestHeaders] Error["+ npe.getMessage() +"]");
		}
		logger.info("NotifyMe Request header: " + stringBuilder.toString());
	}

	public boolean isValidateMsisdn(String msisdn) {
		if (msisdn.length() >= 10) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method send voice-mail, voice-note subscribe & unsubscribe to
	 * rule-engine
	 * 
	 * @json contains reuest data
	 * @return response of rule-engine
	 */
	public String sendSubUnscribeRequest(String json) {
		TextSocketConnection socketConnection = null;
		String response = null;
		try {
			ConnectionPool connectionPool = TcpPool.getRuleEngineConPool();
			socketConnection = connectionPool.getConnection();
			socketConnection.readTimeout(10000);
			logger.info("Server has connected!\n");
			logger.info("Sending string: '" + json + "'\n");
			socketConnection.write(json);
			response = socketConnection.readLine();
			if (response != null) {
				logger.info("rule engine respone " + response);
				this.ruleEngineResponse = new Gson().fromJson(response,
						VccRuleEngineResponse.class);
			} else {
				logger.info("error in rule-engine response " + response);
			}
		} catch (Exception e) {
			errorLogger.error("ErrorCode["+AppConfig.config.getString("errorcode_pattern","VCC-USSD-")+"00002] [Exception While sending sub/unsub Request to Rule Engine] Error["+e.getMessage()+"]");
			logger.error("Error: ", e);
		} finally {
			try {
				socketConnection.close();
			} catch (Exception e) {

			}
		}
		return response;
	}

	/**
	 * This method create json object
	 ** 
	 * @Param requestData contains url header data
	 * @return json string
	 */
	public String getJsonObj(VmVnRequestData requestData) {
		Gson gson = new Gson();
		String jsonObj = "";
		try {
			VccRuleEngineRequest vccSubscribeRequest = new VccRuleEngineRequest();
			vccSubscribeRequest.setMsisdn(requestData.getMsisdn());
			vccSubscribeRequest.setServiceType(requestData.getServiceType());
			vccSubscribeRequest.setInterFace("U");
			vccSubscribeRequest.setChannel("NA");
			vccSubscribeRequest.setTid(String.valueOf(System.nanoTime()));
			vccSubscribeRequest.setActionId(requestData.getActionId());
			vccSubscribeRequest.setReqBy(requestData.getMsisdn());
			vccSubscribeRequest.setPlanName(requestData.getPlanName());
			vccSubscribeRequest.setLang(requestData.getLang());
			vccSubscribeRequest.setAppId("vcc");
			vccSubscribeRequest.setActTrg(requestData.getActTrg());
			vccSubscribeRequest.setSubType(requestData.getSubType());
			jsonObj = gson.toJson(vccSubscribeRequest);
		} catch (Exception e) {
			errorLogger.error("ErrorCode["+AppConfig.config.getString("errorcode_pattern","VCC-USSD-")+"00003] MSISDN["+requestData.getMsisdn()+"] ServiceType["+requestData.getServiceType()+"] [Exception While Creating Json Object] Error["+e.getMessage()+"]");

			logger.error(String.format("Error [%s] [%s]",
					requestData.getMsisdn(), e.getMessage()));
		}
		return jsonObj;
	}
}
