 /**
 *The VmVnRequestData is a bean class that contains url header 
 *data of Voice-mail service and Voice-note servcie    
 * @author Mayank Agrawal
 */

package com.vcc.request;

public class VmVnRequestData {
	
	private int lang;
	private String msisdn;
	private String subType;
	private int actTrg;
	private String serviceType;
	private String planName="NA";
	private String actionId;
	
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public int getLang() {
		return lang;
	}
	public void setLang(int lang) {
		this.lang = lang;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public int getActTrg() {
		return actTrg;
	}
	public void setActTrg(int actTrg) {
		this.actTrg = actTrg;
	}
	public String getActionId() {
		return actionId;
	}
	public void setActionId(String actionId) {
		this.actionId = actionId;
	}
	@Override
	public String toString() {
		return "[lang=" + lang + ", msisdn=" + msisdn
				+ ", subType=" + subType + ", rCode=" + actTrg
				+ ", serviceType=" + serviceType + ", pNme=" + planName + "]";
	}

	
}
