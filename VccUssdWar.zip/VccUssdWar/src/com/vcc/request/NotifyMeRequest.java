/**
 *The NotifyMeRequest is a bean class that contains url header 
 *data of NotifyMe Service    
 * @author Mayank Agrawal
 */

package com.vcc.request;

public class NotifyMeRequest {
	
	private String msisdn;
	private int lang;
	
	public String getMsisdn() {
		return msisdn;
	}
	@Override
	
	public String toString() {
		return "NotifyMeRequest [msisdn=" + msisdn + ", lang=" + lang + "]";
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public int getLang() {
		return lang;
	}
	public void setLang(int lang) {
		this.lang = lang;
	}
	
	

}
