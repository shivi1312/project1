package com.vcc.util;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppContext {
	public static ClassPathXmlApplicationContext context;

	static {
		context = new ClassPathXmlApplicationContext("applicationContext.xml");
	}
}
