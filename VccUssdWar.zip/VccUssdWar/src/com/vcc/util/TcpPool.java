/**
 * The TcpPool is singletion class that provide single object
 * of SocketConnectionPoll
 * @author Mayank Agrawal 
 */

package com.vcc.util;
import com.vcc.config.AppConfig;
import com.vcc.net.ConnectionPool;

public class TcpPool {
	private TcpPool() {

	}

	private static ConnectionPool ruleEngineConPool = new ConnectionPool(
			AppConfig.config.getString("rule_engine_ip"),
			AppConfig.config.getInt("rule_engine_port"));

	/**
	 * This method create connection pool for rule-engine
	 * @return ruleEngineConnection
	 */
	public static ConnectionPool getRuleEngineConPool() {
		return ruleEngineConPool;
	}

}
