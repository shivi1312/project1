package com.vcc.config;

import org.apache.log4j.Logger;

import com.missedcallalertsnotifycallerservice.www.ConnectionManager;

public class StartMonitorThread {
	Logger logger=Logger.getLogger(StartMonitorThread.class);
	public StartMonitorThread()
	{
		logger.info("StartMonitorThread class instantiated");
		if(AppConfig.config.getInt("Config_Context_Flag_Enable",1)==1)
		{
			ConnectionManager.startMonitoring();
		}
	}
}
