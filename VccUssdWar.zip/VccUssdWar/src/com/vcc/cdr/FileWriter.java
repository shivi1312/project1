package com.vcc.cdr;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.log4j.Logger;
import com.google.gson.Gson;
import com.vcc.config.AppConfig;
import com.vcc.model.VccCdrRequest;
import com.vcc.request.NotifyMeRequest;
import com.vcc.request.VmVnRequestData;

public class FileWriter {
	final static Logger logger = Logger.getLogger(FileWriter.class);
	private Gson gson = null;
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = null;
	String formattedDate = null;

	public void writeLog(VmVnRequestData requestData, VccCdrRequest cdrRequest) {

		cdrRequest.setController(AppConfig.config.getString(
				"voice_mail_controller", "vm.vn"));
		cdrRequest.setMsisdn(requestData.getMsisdn());
		cdrRequest.setLang(requestData.getLang());
		cdrRequest.setPlanName(requestData.getPlanName());
		cdrRequest.setActTrg(requestData.getActTrg());
		this.date = new Date();
		this.formattedDate = dateFormat.format(this.date);
		cdrRequest.setTime(this.formattedDate);
		this.gson = new Gson();
		String jsonString = this.gson.toJson(cdrRequest);
		logger.info(jsonString);
	}

	public void writeLog(NotifyMeRequest notifyMeRequest,
			VccCdrRequest cdrRequest) {
		cdrRequest.setController(AppConfig.config.getString(
				"notifyme_controller", "notifyme"));
		cdrRequest.setMsisdn(notifyMeRequest.getMsisdn());
		cdrRequest.setLang(notifyMeRequest.getLang());
		this.date = new Date();
		this.formattedDate = dateFormat.format(this.date);
		cdrRequest.setTime(this.formattedDate);
		this.gson = new Gson();
		String jsonString = this.gson.toJson(cdrRequest);
		logger.info(jsonString);
	}
}
