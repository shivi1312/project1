/**
 * The Info class is a sub class of VccRuleEngineResponse 
 * class that also contains response data of rule engine.
 * @author Mayank Agrawal
 */
package com.vcc.model;

public class Info {
	
	boolean bl;
	boolean optOut;
    int ct;
	public boolean isBl() {
		return bl;
	}
	public void setBl(boolean bl) {
		this.bl = bl;
	}
	public boolean isOptOut() {
		return optOut;
	}
	public void setOptOut(boolean optOut) {
		this.optOut = optOut;
	}
	public int getCt() {
		return ct;
	}
	public void setCt(int ct) {
		this.ct = ct;
	}
    
    

}
