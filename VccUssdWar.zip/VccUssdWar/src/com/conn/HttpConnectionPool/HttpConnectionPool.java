package com.conn.HttpConnectionPool;

import java.util.concurrent.TimeUnit;

import org.apache.http.HeaderElement;
import org.apache.http.HeaderElementIterator;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeaderElementIterator;
import org.apache.http.protocol.HTTP;
import org.apache.http.protocol.HttpContext;
import org.apache.log4j.Logger;

import com.vcc.config.AppConfig;




public class HttpConnectionPool {
	static Logger logger = Logger.getLogger(HttpConnectionPool.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
    private static PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
    private static HttpConnectionPool connectionPool;
    
    
	public static HttpConnectionPool getInstance() {
            if (connectionPool == null) {
                    connectionPool = new HttpConnectionPool();
            }
            return connectionPool;
    }

    
   /*  * Configure common configuration per every root setMaxTotal configure max
     * total connection for connection pool, default is 5 setDefaultMaxPerRoute
     * set max connection per route, default value is 5
     */
    private HttpConnectionPool() {
            try {
                    connManager.setMaxTotal(AppConfig.config.getInt(
                                    "tiboco.max.http.conn", 5));
                    connManager.setDefaultMaxPerRoute(AppConfig.config.getInt(
                                    "tiboco.max.http.per.route.conn", 5));
                  
                    logger.info("default max conn ["
                                    + AppConfig.config.getInt("tiboco.max.http.conn", 5)
                                    + "]");
                    logger.info("default max per route ["
                                    + AppConfig.config.getInt(
                                                    "tiboco.max.http.per.route.conn", 5) + "]");
               
            } catch (Exception e) {
            		errorLogger.error("ErrorCode [VCC-RE-00069] [Exception in HttpConnecionPool]");
                    e.printStackTrace();
            }
    }

    public ConnectionKeepAliveStrategy connectionKeepAliveStrategy() {
        return new ConnectionKeepAliveStrategy() {
            @Override
            public long getKeepAliveDuration(HttpResponse response, HttpContext context) {
                HeaderElementIterator it = new BasicHeaderElementIterator
                        (response.headerIterator(HTTP.CONN_KEEP_ALIVE));
                while (it.hasNext()) {
                    HeaderElement he = it.nextElement();
                    String param = he.getName();
                    String value = he.getValue();
 
                    if (value != null && param.equalsIgnoreCase("timeout")) {
                        return Long.parseLong(value) * 1000;
                    }
                }
                return AppConfig.config.getInt("tiboco.idle.default.keep.alive.time",5000);
            }
        };
    }
    

    public CloseableHttpClient httpClient() {

		logger.info("Configuring HttpClient object for the desired configurations.");

		RequestConfig requestConfig = RequestConfig.custom()
				.setConnectTimeout(AppConfig.config.getInt("tiboco.http.connection.time.out", 5000))
				.setConnectionRequestTimeout(AppConfig.config.getInt("tiboco.http.connection.request.time.out", 100))
				.setSocketTimeout(AppConfig.config.getInt("tiboco.http.read.time.out", 10000)).build();

		return HttpClients.custom().setDefaultRequestConfig(requestConfig)
				.setConnectionManager(connManager).setKeepAliveStrategy(connectionKeepAliveStrategy())
				.build();
	}
    
    public static void startMonitoring() {
		try {
			/*
			 * idle connections is a dedicated monitor thread used to evict
			 * connections that are considered expired due to a long period of
			 * inactivity. The monitor thread can periodically call
			 * ClientConnectionManager#closeExpiredConnections() method to close
			 * all expired connections and evict closed connections from the
			 * pool. It can also optionally call
			 * ClientConnectionManager#closeIdleConnections() method to close
			 * all connections that have been idle over a given period of time 
			 */
			new Thread(
					new Runnable() {
						
						@Override
						public void run() {
							

							logger.info("Idle Monitor Thread Started for Tiboco URL. Conn_Max_Idle_Time["
									+ AppConfig.config.getInt("Connection_Max_Idle_Time", 0) + "]");
							while (true) {
								if (connManager != null) {
									logger.info("Executing closeIdleConnection Method to get rid of the connections residing in CLOSE_WAIT phase for TIBOCO communication...");
									connManager.closeExpiredConnections();
									connManager.closeIdleConnections(AppConfig.config.getInt(
											"Connection_Max_Idle_Time", 0),TimeUnit.SECONDS);
									try {
										logger.info("Idle Monitor Thread for Tiboco communication going to sleep...SleepTime["
												+ AppConfig.config.getInt(
														"Idle_Monitor_Thread_Sleep_Time", 1800000)
												+ "]");
										Thread.sleep(AppConfig.config.getInt(
												"Idle_Monitor_Thread_Sleep_Time", 1800000));
									} catch (InterruptedException e) {
										logger.error("Idle Monitoring Thread for tiboco communication Interrupted : "
												+ e.getMessage());
									}
								}
							}
						
							
							
						}
					}).start();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
}

