package com.telemune.hlr.backend;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

public class ConfigurationLoader {
	static private Logger logger = Logger.getLogger(ConfigurationLoader.class);
   
	static	{
		loadProperties();
	}
	private static void loadProperties() {
		Properties hlrPro = new Properties();
		String prePaid_tplId = "NA";
		String postPaid_tplId = "NA";
		StringTokenizer tokens = null;
		String prePostRanges = "NA"; // added by Avishkar on 10/09/2020
		
		try
		{

			FileInputStream fins=new FileInputStream("properties/TelemuneHlr.properties");
			hlrPro.load(fins);
			fins.close();
		}
		catch(FileNotFoundException fexp)
		{
			fexp.printStackTrace();
			System.exit(1);
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
			System.exit(1);
		}

		try
		{
		Config.TelnetRequestForCS = hlrPro.getProperty("TELNET_REQUEST_FOR_CS");
		Config.TelnetRequestForUF = hlrPro.getProperty("TELNET_REQUEST_FOR_UF");
		Config.TelnetRequestForDF = hlrPro.getProperty("TELNET_REQUEST_FOR_DF");
		
		Config.LOGIN_VALIDATOR = hlrPro.getProperty("LOGIN_VALIDATOR");
		Config.PASSWORDFRMT = hlrPro.getProperty("PASSWORDFRMT");
		Config.LOGINFRMT = hlrPro.getProperty("LOGINFRMT");
		/*Config.TELNET_CONFIGUREDIP = hlrPro.getProperty("TELNET_CONFIGUREDIP");
		Config.PORT =  Integer.parseInt(hlrPro.getProperty("PORT"));
		Config.REMOTEUSER = hlrPro.getProperty("REMOTEUSER");
		Config.REMOTEPASSWD = hlrPro.getProperty("REMOTEPASSWD");*/
		Config.REMOTETERMINATOR = hlrPro.getProperty("REMOTETERMINATOR");
		Config.LOGINCMD = hlrPro.getProperty("LOGINCMD"); 
		Config.CONNECTION_CHECKING_CMD = hlrPro.getProperty("CONNECTION_CHECKING_CMD");
		Config.TESTING = Integer.parseInt(hlrPro.getProperty("TESTING"));
		Config.connectionTimeOut = Integer.parseInt(hlrPro.getProperty("CONN_TIME_OUT"));
		Config.FTN_NUMBER = hlrPro.getProperty("FTN_NUMBER");
		prePaid_tplId = hlrPro.getProperty("PREPAID_TPLIDS");
		postPaid_tplId = hlrPro.getProperty("POSTPAID_TPLIDS");
		// addition by Avishkar on 3-09-2020 start
		Config.TESTING_STRING = hlrPro.getProperty("TESTING_STRING");
		Config.VCC_CFNRY_ENABLE = Integer.parseInt(hlrPro.getProperty("VCC_CFNRY_ENABLE"));
		Config.VCC_CFB_ENABLE = Integer.parseInt(hlrPro.getProperty("VCC_CFB_ENABLE"));
		Config.VCC_CFNRC_ENABLE = Integer.parseInt(hlrPro.getProperty("VCC_CFNRC_ENABLE"));
		Config.VCC_CFU_ENABLE = Integer.parseInt(hlrPro.getProperty("VCC_CFU_ENABLE"));
		Config.TelentRequestFor_CFNRY_UF=hlrPro.getProperty("TELNET_REQUEST_FOR_CFNRY_UF");
		Config.TelentRequestFor_CFB_UF=hlrPro.getProperty("TELNET_REQUEST_FOR_CFB_UF");
		Config.TelentRequestFor_CFNRC_UF=hlrPro.getProperty("TELNET_REQUEST_FOR_CFNRC_UF");
		Config.TelentRequestFor_CFNRY_DF=hlrPro.getProperty("TELNET_REQUEST_FOR_CFNRY_DF");
		Config.TelentRequestFor_CFB_DF=hlrPro.getProperty("TELNET_REQUEST_FOR_CFB_DF");
		Config.TelentRequestFor_CFNRC_DF=hlrPro.getProperty("TELNET_REQUEST_FOR_CFNRC_DF");
		Config.prepaidCheck = Integer.parseInt(hlrPro.getProperty("PREPAID_CHECK"));
		prePostRanges = hlrPro.getProperty("PREPOST_RANGES");
		Config.chk_imsi_start_bit = Integer.parseInt(hlrPro.getProperty("CHEK_IMSI_START_BIT"));
		Config.chk_imsi_no_of_bits = Integer.parseInt(hlrPro.getProperty("CHK_IMSI_NO_OF_BITS"));
		// addition by Avishkar on 3-09-2020 ends
		// added by Avishkar on 22-01-2021 start
		Config.USERNAME = hlrPro.getProperty("USERNAME");
		Config.PASSWORD = hlrPro.getProperty("PASSWORD");
		Config.SERIAL_FORMAT = hlrPro.getProperty("SERIAL_FORMAT");
		Config.HLR_SOAP_URL = hlrPro.getProperty("HLR_SOAP_URL");
		// added by Avishkar on 22-01-2021 ends
		
		tokens = new StringTokenizer(prePaid_tplId , ",");
		while(tokens.hasMoreElements())
		{
			Config.prePaid_tplId.add(tokens.nextToken());
		}
		tokens =  null;
		tokens = new StringTokenizer(postPaid_tplId , ",");
		while(tokens.hasMoreElements())
		{
			Config.postPaid_tplId.add(tokens.nextToken());
		}
		
		// addition start by Avihkar on 10/09/2020
		tokens = null;
		tokens = new StringTokenizer(prePostRanges, ",");
		while(tokens.hasMoreElements())
		{
			Config.prepostranges.add(tokens.nextToken());
		}
		// addition end by Avishkar on 10/09/2020
		
		logger.info("TelnetRequiredForCS["+Config.TelnetRequestForCS+"] LOGIN_VALIDATOR["+Config.LOGIN_VALIDATOR+"]"
				   +"PASSWORDFRMT["+Config.PASSWORDFRMT+"] LOGINFRMT["+Config.LOGINFRMT+"]"
				   +"LOGINCMD["+Config.LOGINCMD+"] CONNECTION_CHECKING_CMD["+Config.CONNECTION_CHECKING_CMD+"]"
				   +"TESTING["+Config.TESTING+"] connectionTimeOut["+Config.connectionTimeOut+"]"
				   +"TelnetRequiredForUF["+Config.TelnetRequestForUF+"] TelnetRequiredForDF["+Config.TelnetRequestForDF+"]"
				   +"prePaid_tplId["+prePaid_tplId+"] postPaid_tplId["+postPaid_tplId+"] Config.prePaid_tplId size["+Config.prePaid_tplId.size()+"]"
				   +"Config.postPaid_tplId["+Config.postPaid_tplId+"] FTN_NUMBER["+Config.FTN_NUMBER+"]");
	    }
		catch(NumberFormatException numexp)
		{
			numexp.printStackTrace();
		}
		catch (NullPointerException nullexp) {
			nullexp.printStackTrace();
		}
		catch (Exception exp) {
			exp.printStackTrace();
		}
	}
}
