import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
public class SimpleSoapClient {
	public static void main(String args[]) throws IOException {
        
	   // String address="Hyderabad";

	    /* place your xml request from soap ui below with necessary changes in parameters*/
	    
	    String xml="<soapenv:Envelope xmlns:soapenv=http://schemas.xmlsoap.org/soap/envelope/ xmlns:cai3=http://schemas.ericsson.com/cai3g1.2/\r\n"
	    		+ "xmlns:mtas=http://schemas.ericsson.com/ema/UserProvisioning/MTAS/>\r\n"
	    		+ "\r\n"
	    		+ "<soapenv:Header>\r\n"
	    		+ "\r\n"
	    		+ "<cai3:SequenceId>${Properties#baseSequenceId}</cai3:SequenceId>\r\n"
	    		+ "\r\n"
	    		+ "<cai3:TransactionId>${Properties#TransactionId}</cai3:TransactionId>\r\n"
	    		+ "\r\n"
	    		+ "<cai3:SessionId>${Properties#SessionID}</cai3:SessionId>\r\n"
	    		+ "\r\n"
	    		+ "</soapenv:Header>\r\n"
	    		+ "\r\n"
	    		+ "<soapenv:Body>\r\n"
	    		+ "\r\n"
	    		+ "<cai3:Set>\r\n"
	    		+ "\r\n"
	    		+ "<cai3:MOType>Subscription@http://schemas.ericsson.com/ema/UserProvisioning/MTAS/</cai3:MOType>\r\n"
	    		+ "\r\n"
	    		+ "<cai3:MOId>\r\n"
	    		+ "\r\n"
	    		+ "<mtas:publicId>sip:+${#MSISDN}@ims.mnc180.mcc338.3gppnetwork.org</mtas:publicId>\r\n"
	    		+ "\r\n"
	    		+ "</cai3:MOId>\r\n"
	    		+ "\r\n"
	    		+ "<cai3:MOAttributes>\r\n"
	    		+ "\r\n"
	    		+ "<mtas:setSubscription publicId=sip:+${#MSISDN}@ims.mnc180.mcc338.3gppnetwork.org>\r\n"
	    		+ "\r\n"
	    		+ "<mtas:services>\r\n"
	    		+ "\r\n"
	    		+ "<mtas:customized-alerting-tone>\r\n"
	    		+ "\r\n"
	    		+ "<mtas:cat-operator-configuration>\r\n"
	    		+ "\r\n"
	    		+ "<mtas:activated>true</mtas:activated>\r\n"
	    		+ "\r\n"
	    		+ "</mtas:cat-operator-configuration>\r\n"
	    		+ "\r\n"
	    		+ "</mtas:customized-alerting-tone>\r\n"
	    		+ "\r\n"
	    		+ "</mtas:services>\r\n"
	    		+ "\r\n"
	    		+ "</mtas:setSubscription>\r\n"
	    		+ "\r\n"
	    		+ "</cai3:MOAttributes>\r\n"
	    		+ "\r\n"
	    		+ "</cai3:Set>\r\n"
	    		+ "\r\n"
	    		+ "</soapenv:Body>\r\n"
	    		+ "\r\n"
	    		+ "</soapenv:Envelope>";
	    String responseF=callSoapService(xml);
        System.out.println(responseF);
}





static String callSoapService(String soapRequest) {
    try {
     String url = "http:// 10.241.11.196"; // replace your URL here
     URL obj = new URL(url);
     HttpURLConnection con = (HttpURLConnection) obj.openConnection();
     
     // change these values as per soapui request on top left of request, click on RAW, you will find all the headers
     con.setRequestMethod("POST");
     con.setRequestProperty("Content-Type","text/xml; charset=utf-8"); 
     con.setDoOutput(true);
     DataOutputStream wr = new DataOutputStream(con.getOutputStream());
     wr.writeBytes(soapRequest);
     wr.flush();
     wr.close();
     String responseStatus = con.getResponseMessage();
     System.out.println(responseStatus);
     BufferedReader in = new BufferedReader(new InputStreamReader(
     con.getInputStream()));
     String inputLine;
     StringBuffer response = new StringBuffer();
     while ((inputLine = in.readLine()) != null) {
         response.append(inputLine);
     }
     in.close();
     
     // You can play with response which is available as string now:
     String finalvalue= response.toString();
     
     // or you can parse/substring the required tag from response as below based your response code
     finalvalue= finalvalue.substring(finalvalue.indexOf("<response>")+10,finalvalue.indexOf("</response>")); 
     return finalvalue;
    } 
   catch (Exception e) {
       return e.getMessage();
   }   
}
}
