package com.telemune;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sppringdb1Application {

	public static void main(String[] args) {
		SpringApplication.run(Sppringdb1Application.class, args);
	}

}
