package com.telemune.demo;

import java.util.*;  
public class Arraylist{  
 public static void main(String args[]){  
  ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
  list.add("Mango");//Adding object in arraylist    
  list.add("Apple");    
  list.add("Banana");    
  list.add("Grapes");
  
  
  //Traversing list through for-each loop
//  for(String fruit:list)    
//    System.out.println(fruit);    
  
 // System.out.println(list)
  
  
  
  // By iterator 
//  Iterator iterator=list.iterator();
//  while(iterator.hasNext()) {
//	  System.out.println(iterator.next());
//  }
  
  // By lamda expresion
  list.forEach((n) -> {
	  System.out.println(n);
  });
  
  
  
  
 }  
}  