package com.telemune.demo;
import java.util.Scanner;
//import org.apache.http.client.methods.CloseableHttpResponse;
//import org.apache.http.client.methods.HttpGet;
//import org.apache.http.impl.client.CloseableHttpClient;
//import org.apache.http.impl.client.HttpClients;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;


public class CloseableHttpClientDemo1 {
	 public static void main(String args[])throws Exception{
		 
	      //Create an HttpClient object
	      CloseableHttpClient httpclient = HttpClients.createDefault();
		// HttpClient client = HttpClientBuilder.create().build();

	      try{
	         //Create an HttpGet object
	         HttpGet httpget = new HttpGet("http://www.google.com/");
	    	 // HttpGet httpget = new HttpGet("https://www.google.com/?q=java");

	         //Execute the Get request
	         CloseableHttpResponse httpresponse = httpclient.execute(httpget);
	    	  //HttpResponse httpresponse = client.execute(httpget);

	         try{
	            Scanner sc = new Scanner(httpresponse.getEntity().getContent());
	            while(sc.hasNext()) {
	               System.out.println(sc.nextLine());
	            }
	         }finally{
	           // httpresponse.close();
	         }
	      }finally{
	       //  httpclient.close();
	      }
	   }
}
