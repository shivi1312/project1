package com.telemune.demo;

public class InheritenceQ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a = new B();
		a.sum(a);
		a.bum();
	//	B b= new A();  // compiletime error
		
	}

}
