package com.telemune.demo;

import java.io.FileOutputStream;

public class FileOutputStreamExample {
	public static void main(String args[]){    
        try{    
          FileOutputStream fout=new FileOutputStream("D:\\avishkar\\jai.txt"); 
          
         String s = "Hii how are u ";
         byte b[] = s.getBytes();
          fout.write(b);    
          fout.close();    
          System.out.println("success...");    
         }catch(Exception e){System.out.println(e);}    
   }    

}
