package com.telemune.demo;

import java.util.ArrayList;

public class Generic {
	
	@SuppressWarnings("finally")
	public int finallyQ()
	{
		try {
			 throw new Exception();
		 }catch(Exception e)
		 {
			 System.out.println("ERROR");
			 throw new Exception();
		 }
		 finally
		 {
			 System.out.println("Finally");
			 return 2;
		 }
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		A a =new A();
		B b=new B();
		C c= new C();
		// here c extends b and b extends a, now If we create an Arraylist of type B then only b and child of b can be add in that arraylist;
		ArrayList<B> al = new ArrayList<>();
		//al.add(a);
		al.add(b);
		al.add(c);
		
		
		System.out.println(new Generic().finallyQ());
	 
	}

}
