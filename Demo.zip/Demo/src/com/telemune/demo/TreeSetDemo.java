 package com.telemune.demo;

import java.util.TreeSet;

public class TreeSetDemo {

	private static char[] ts;

	public static void main(String[] args) {
		try
		{
		TreeSet<Student> ts= new TreeSet<Student>();
		ts.add(new Student(2,"ram"));
		ts.add(new Student(5,"lam"));
		ts.add(new Student(1,"zam"));
		ts.add(new Student(9,"aam"));
		}
		
		
		catch(Exception e) {
			
			System.out.println(ts);
		}
		
		
	}
	}


