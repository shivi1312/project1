package com.telemune.demo;

public class B extends A{
	public void sum(B b)
	{
		System.out.println("child A");
	}
	/*
	 * public void bum() { System.out.println("child bum"); }
	 */
}
