package com.telemune.demo;

public class C extends B{

}
