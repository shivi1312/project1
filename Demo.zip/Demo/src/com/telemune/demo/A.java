package com.telemune.demo;

public class A {

	public void sum(A a)
	{
		System.out.println("parent A");
	}
	public void bum()
	{
		System.out.println("parent bum");
	}
}
