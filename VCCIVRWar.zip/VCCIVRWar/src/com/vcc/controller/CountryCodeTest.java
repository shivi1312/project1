package com.vcc.controller;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;
import com.vcc.common.VccCommonOperation;

public class CountryCodeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String msisdn="043454544";
		
		PhoneNumber number = null;
		String code ="AE";
		PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
		try {
			number = phoneUtil.parse(msisdn, code);
			new VccCommonOperation().convertToInternationalNumber(msisdn, code);
		} catch (NumberParseException e) {

			e.printStackTrace();
			
		}
	}

}
