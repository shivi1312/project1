package com.vcc.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vcc.cache.VccExpiryCache;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.handler.VccMessageHandler;
import com.vcc.handler.VmRecordHandler;
import com.vcc.request.VccMessageRequest;
import com.vcc.response.VccMessageResponse;


/*
 * Have actions for voice mail related informations
 * Save voice mail and Delete voice mail
 * */
@RestController
@RequestMapping("/")
public class VccMessageController {

	final static Logger logger = Logger.getLogger(VccMessageController.class);
	@Autowired
	private VccServices vccServices;
	
	
	
		
	@RequestMapping(value = "message.count", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody VccMessageResponse messageCount(VccMessageRequest messageRequest,
			BindingResult bindingResult, VccMessageResponse messageResponse) {
		logger.debug("request is:  >>>>>>> "+ AppConfig.config.getString("message_count", "count_message"));
		VccMessageHandler vmHandler = new VccMessageHandler();
		vmHandler.processMessage(messageRequest, bindingResult,
				messageResponse, vccServices);
		vmHandler = null;
		return messageResponse;
		
	}
	@RequestMapping(value = "message.retrieve", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody VccMessageResponse messageRetrieve(VccMessageRequest messageRequest,
			BindingResult bindingResult, VccMessageResponse messageResponse) {
		VccMessageHandler vmHandler = new VccMessageHandler();
		logger.debug(" request is:  >>>>>>> "+ AppConfig.config.getString("message_retrieve", "retrieve_message"));
		vmHandler.retrieveMessage(messageRequest, bindingResult,
				messageResponse, vccServices);
		vmHandler =null;
		return messageResponse;
		
	}
	
	@RequestMapping(value = "change.message.status", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody VccMessageResponse changeMessageStatus(VccMessageRequest messageRequest,
			BindingResult bindingResult, VccMessageResponse messageResponse) {
		VccMessageHandler vmHandler = new VccMessageHandler();
		logger.debug(" request is:  >>>>>>> "+ AppConfig.config.getString("change.message.status", "change.message.status"));
		vmHandler.changeMessageStatus(messageRequest, bindingResult,
				messageResponse, vccServices);
		vmHandler =null;
		return messageResponse;
		
	}
	
	@RequestMapping(value = "delete.msg", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody VccMessageResponse deleteMsg(VccMessageRequest messageRequest,
			BindingResult bindingResult,VccMessageResponse messageResponse) {
		VmRecordHandler vmHandler = new VmRecordHandler();
		
		logger.debug("request is: "+ AppConfig.config.getString("delete.msg", "delete.msg"));
		vmHandler.deleteMsgProcess(messageRequest, bindingResult, 
				messageResponse, vccServices);
		vmHandler= null;
		return messageResponse;
	}
	
	

	
	@RequestMapping(value = "cache.check", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody VccMessageResponse cacheCheck(VccMessageRequest messageRequest,
			BindingResult bindingResult, VccMessageResponse messageResponse) {
		
		logger.info("\n request is:  >>>>>>> "+ AppConfig.config.getString("cache.check", "cache.check"));
		
		
		//VccExpiryCache.getSysmap().clear();
		messageResponse.setMsgPath(VccExpiryCache.getSysmap().get("vcc_rate_plan"));
		
		return messageResponse;
		
	}	
}
