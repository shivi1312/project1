package com.vcc.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.handler.ProfileHandler;
import com.vcc.handler.VccRulesRequestHandler;
import com.vcc.handler.VccSubUnScribeHandler;
import com.vcc.handler.VccUserInputHandler;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;

@RestController
@RequestMapping("/")
public class UsersController {

	final static Logger logger = Logger.getLogger(UsersController.class);
	@Autowired
	VccServices vccServices;
	
	private static Gson gson =new Gson();

	@RequestMapping(value = "profile.check", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody ProfileResponse profileCheck(
			ProfileRequest profileRequest, BindingResult bindingResult,
			ProfileResponse profileResponse) {
		logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("profile.check", "profile.check"));
		ProfileHandler profileHandler = new ProfileHandler();
		profileHandler.profileCheck(profileRequest, bindingResult,
				profileResponse, vccServices);
		profileHandler = null;
		logger.debug("response:-profile.check  " + gson.toJson(profileResponse));
		return profileResponse;
	}

	
	@RequestMapping(value = "fs.profile.check", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody ProfileResponse fsProfileCheck(
			ProfileRequest profileRequest, BindingResult bindingResult,
			ProfileResponse profileResponse) {
		logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("profile.check", "profile.check"));
		ProfileHandler profileHandler = new ProfileHandler();
		profileHandler.profileCheck(profileRequest, bindingResult,
				profileResponse, vccServices);
		profileHandler = null;
		logger.debug("response:-profile.check  " + gson.toJson(profileResponse));
		return profileResponse;
	}

	
	@RequestMapping(value = "profile.check.ret", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	ProfileResponse profileCheckRet(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse) {
		ProfileHandler profileHandler = new ProfileHandler();
		logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("profile.check.ret", "profile.check.ret"));
		profileHandler.profileCheckRetrieval(profileRequest, bindingResult,
				profileResponse, vccServices);
	
		logger.debug("response:-profile.check.ret  " +gson.toJson(profileResponse));
		profileHandler = null;
		return profileResponse;
	}
	
	@RequestMapping(value = "profile.check.longCode", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	ProfileResponse profileCheckRetLongShortcode(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse) {
		ProfileHandler profileHandler = new ProfileHandler();
		logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("profile.check.longCode", "profile.check.ret"));
		profileHandler.profileCheckRetrievalLongCode(profileRequest, bindingResult,
				profileResponse, vccServices);
	
		logger.debug("response:-profile.check.longCode  " +gson.toJson(profileResponse));
		profileHandler = null;
		return profileResponse;
	}
	
	
	@RequestMapping(value = "dir.create", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody ProfileResponse recordDirCreate(
			ProfileRequest profileRequest, BindingResult bindingResult,
			ProfileResponse profileResponse) {
		logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("dir.create", "dir.create"));
		ProfileHandler profileHandler = new ProfileHandler();
		profileHandler.dirCreate(profileRequest, bindingResult,
				profileResponse, vccServices);
		profileHandler = null;
		logger.debug("response:-dir.create  " + gson.toJson(profileResponse));
		return profileResponse;
	}
	
	
	@RequestMapping(value = "change.language", method=RequestMethod.GET,produces = "application/xml")
	public @ResponseBody
	ProfileResponse changeLang(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse){
		logger.debug(" request is:  >>>>>>>"+ AppConfig.config.getString("change.language", "change.language"));
		ProfileHandler profileHandler = new ProfileHandler();
		profileHandler.changeLangProcess(profileRequest, bindingResult,
				profileResponse, vccServices);
		logger.debug("response:-change.language " +gson.toJson(profileResponse));
		return profileResponse;
	}
	
	@RequestMapping(value = "change.password", method=RequestMethod.GET,produces = "application/xml")
	public @ResponseBody
	ProfileResponse changePassword(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse){
		logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("change.password", "change.password"));
		ProfileHandler profileHandler = new ProfileHandler();
		profileHandler.changePassWordProcess(profileRequest, bindingResult,
				profileResponse, vccServices);
		profileHandler = null;
		logger.debug("response:-change.password " +gson.toJson(profileResponse));
		return profileResponse;
	}
	
	@RequestMapping(value = "check.password", method=RequestMethod.GET,produces = "application/xml")
	public @ResponseBody
	ProfileResponse checkPassword(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse){
		logger.debug(" request is:  >>>>>>>"+ AppConfig.config.getString("check.password", "check.password"));
		ProfileHandler profileHandler = new ProfileHandler();
		profileHandler.checkPassWordProcess(profileRequest, bindingResult,
				profileResponse, vccServices);
		profileHandler=null;
		logger.debug("response:-check.password " +gson.toJson(profileResponse));
		return profileResponse;
	}
	
	@RequestMapping(value = "check.subType", method=RequestMethod.GET,produces = "application/xml")
	public @ResponseBody
	ProfileResponse checkSubType(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse){
		logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("check.subType", "check.subType"));
		VccRulesRequestHandler rulesRequestHandler = new VccRulesRequestHandler();
		rulesRequestHandler.checkSubtypeProcess(profileRequest,
				profileResponse, vccServices);
		logger.debug("response:-check.subType " +gson.toJson(profileResponse));
		return profileResponse;
	}
	
	
	@RequestMapping(value = "check.subType.ret", method=RequestMethod.GET,produces = "application/xml")
	public @ResponseBody
	ProfileResponse checkSubTypeRet(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse){
		logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("check.subType.ret", "check.subType.ret"));
		VccRulesRequestHandler rulesRequestHandler = new VccRulesRequestHandler();
		profileRequest.setFlowType("ret");
		rulesRequestHandler.checkSubcribertypeProcess(profileRequest,
				profileResponse, vccServices);
		rulesRequestHandler=null;
		logger.debug("response:-check.subType.ret " +gson.toJson(profileResponse));
		return profileResponse;
	}
	@RequestMapping(value = "check.subType.rec", method=RequestMethod.GET,produces = "application/xml")
	public @ResponseBody
	ProfileResponse checkSubTypeRec(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse){
		logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("check.subType.rec", "check.subType.rec"));
		VccRulesRequestHandler rulesRequestHandler = new VccRulesRequestHandler();
		profileRequest.setFlowType("rec");
		rulesRequestHandler.checkSubcribertypeProcess(profileRequest,
				profileResponse, vccServices);
		rulesRequestHandler=null;
		logger.debug("response:-check.subType.rec " +gson.toJson(profileResponse));
		return profileResponse;
	}
	
	@RequestMapping(value = "manage.trigger", method=RequestMethod.GET,produces = "application/xml")
	public @ResponseBody
	ProfileResponse activateTrigger(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse){
		logger.debug(" request is:  >>>>>>>"+ AppConfig.config.getString("activate.trigger", "activate.trigger"));
		VccRulesRequestHandler rulesRequestHandler = new VccRulesRequestHandler();
		rulesRequestHandler.manageTriggerProcess(profileRequest,
				profileResponse, vccServices);
		rulesRequestHandler=null;
		logger.debug("response:-manage.trigger " +gson.toJson(profileResponse));
		return profileResponse;
	}
	
	
	
	@RequestMapping(value = "vm.subscribe", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	ProfileResponse vmSubscribe(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse) {
		logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("vm.subscribe", "vm.subscribe"));
		VccSubUnScribeHandler  subUnScribeHandler = new VccSubUnScribeHandler();
		subUnScribeHandler.subscribeProcess(profileRequest,profileResponse,vccServices);
		subUnScribeHandler = null;
		logger.debug("response:-vm.subscribe " +gson.toJson(profileResponse));
		return profileResponse;
	}
	
	@RequestMapping(value = "do.subscribe", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	ProfileResponse doSubscribe(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse) {
		logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("do.subscribe", "do.subscribe"));
		VccSubUnScribeHandler  subUnScribeHandler = new VccSubUnScribeHandler();
		subUnScribeHandler.subscribeProcess(profileRequest,profileResponse,vccServices);
		subUnScribeHandler = null;
		logger.debug("response:-do.subscribe " +gson.toJson(profileResponse));
		return profileResponse;
	}
	
	@RequestMapping(value = "do.unsubscribe", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	ProfileResponse doUnSubscribe(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse) {
		logger.debug(" request is:  >>>>>>>"+ AppConfig.config.getString("do.unsubscribe", "do.unsubscribe"));
		VccSubUnScribeHandler  subUnScribeHandler = new VccSubUnScribeHandler();
		subUnScribeHandler.unSubscribeProcess(profileRequest,profileResponse,vccServices);
		subUnScribeHandler = null;
		logger.debug("response:-do.unsubscribe " +gson.toJson(profileResponse));
		return profileResponse;
	}
	
	@RequestMapping(value = "user.input", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	ProfileResponse userInput(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse) {
		VccUserInputHandler vccUserInputHandler = new VccUserInputHandler();
		logger.debug("\n request is:  >>>>>>>"+ AppConfig.config.getString("user_input", "user_input"));
		vccUserInputHandler.userInputProcess(profileRequest,bindingResult,profileResponse,vccServices);
		vccUserInputHandler=null;
		logger.debug("response:-user.input " +gson.toJson(profileResponse));
		return profileResponse;
	}
	
	@RequestMapping(value = "check.profile.with.send.a.copy", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody ProfileResponse sendCopy(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse) {
		ProfileHandler profileHandler = new ProfileHandler();
		logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("check.profile.with.send.a.copy", "check.profile.with.send.a.copy"));
		profileHandler.sendCopyProcess(profileRequest,bindingResult,profileResponse,vccServices);
		profileHandler =null;
		logger.debug("response:-check.profile.with.send.a.copy " +gson.toJson(profileResponse));
		return profileResponse;
		
	}
	
	
}
