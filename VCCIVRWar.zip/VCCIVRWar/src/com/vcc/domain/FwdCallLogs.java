package com.vcc.domain;

import org.apache.log4j.Logger;

import com.vcc.chain.VmChain;
import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.model.VccFwdCallLogs;
import com.vcc.request.VmRequest;
import com.vcc.response.VmResponse;

public class FwdCallLogs implements VmChain {
	final static Logger logger = Logger.getLogger(FwdCallLogs.class);
	private VmChain nextInVmChain;
	private VccServices vccServices;
	private int status;

	@Override
	public void setNext(VmChain nextInVmChain, VccServices vccServices) {
		this.nextInVmChain = nextInVmChain;
		this.vccServices = vccServices;

	}

	/**
	 * return void the method is responsible for create logs of call
	 * 
	 * @param vmRequest
	 *            the variable contain bean of VmRequest ,which set by url
	 *            request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param vmResponse
	 *            the variable contain bean of VmResponse , which actually
	 *            return in url response like - isSuccess
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @return void
	 * @see nothing
	 */
	@Override
	public void process(VmRequest vmRequest, VmResponse vmResponse,
			VmError vmError) {
		VccFwdCallLogs fwdCallLogs = new VccFwdCallLogs();

		this.setFwdCallLogs(fwdCallLogs, vmRequest);
		status = vccServices.userService.insertFwdCallLogs(fwdCallLogs);

		if (status == 1)
			vmResponse.setIsSuccess(1);
		else
			vmResponse.setIsSuccess(0);
		logger.info(String
				.format("A-Party [%s] B-Party [%s] call logs saved file in db [%s] any error [%s]",
						vmRequest.getCallingNum(), vmRequest.getCalledNum(),
						status, vmError.getError()));
		if (!vmError.getError()
				&& !vmRequest.getSubType().equalsIgnoreCase("F")) {
			this.nextInVmChain= new VccSendNotification();
			this.nextInVmChain.setNext(this.nextInVmChain, this.vccServices);
			logger.debug("next in chanin instance of ["
					+ nextInVmChain.getClass() + "]");
			nextInVmChain.process(vmRequest, vmResponse, vmError);
			/* new VccSendNotification().process(vmRequest, vmResponse,
			 vmError);*/
		}
	}

	/**
	 * return void the method is responsible for create logs of call
	 * 
	 * @param vmRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param fwdCallLogs
	 *            the variable contain bean of VccFwdCallLogs , which actually
	 *            set data in bean
	 * @return void
	 * @see nothing
	 */
	private void setFwdCallLogs(VccFwdCallLogs fwdCallLogs, VmRequest vmRequest) {

		fwdCallLogs.setServerId(vmRequest.getServerId());
		fwdCallLogs.setCallId(vmRequest.getCallUUID());
		fwdCallLogs.setOriginatingNumber(vmRequest.getCallingNum());
		fwdCallLogs.setDestinationNumber(vmRequest.getCalledNum());
		fwdCallLogs.setCircuitId(vmRequest.getCircuitId());
		fwdCallLogs.setIamCauseCode(vmRequest.getReleaseCode());
		fwdCallLogs.setRelCauseCode(vmRequest.getHangupCause());
		if (vmRequest.getRecordingDuration() < 1 && vmRequest.getAnswerd()==0)
		{
			fwdCallLogs.setMsgLength(0);
			fwdCallLogs.setFileName("NA");
		}else if(vmRequest.getRecordingDuration() < 1 && vmRequest.getAnswerd()==1 && vmRequest.getCallDuration()>1 )
		{
			fwdCallLogs.setMsgLength(vmRequest.getCallDuration()-7);
			fwdCallLogs.setFileName(vmRequest.getRecordFileName());
		}
		else
		{
			fwdCallLogs.setMsgLength(vmRequest.getRecordingDuration() / 1000);
			fwdCallLogs.setFileName(vmRequest.getRecordFileName());
		}
		int vccMsgIndex=0;
		/*if(vmRequest.getAnswerd()==1)
		 vccMsgIndex = vccServices.userService.getVoiceMsgIndex(vmRequest);*/
	
		fwdCallLogs.setVoiceMsgIndex(vccMsgIndex);
		fwdCallLogs.setCallTime(vmRequest.getCallTime());
		fwdCallLogs.setCallDuration(vmRequest.getCallDuration());
		fwdCallLogs.setAnswered(vmRequest.getAnswerd());
		fwdCallLogs.setServiceType(vmRequest.getServiceType());
		fwdCallLogs.setSubType(vmRequest.getSubType());
		fwdCallLogs.setRatePlan(vmRequest.getRatePlan());
		

	}

}
