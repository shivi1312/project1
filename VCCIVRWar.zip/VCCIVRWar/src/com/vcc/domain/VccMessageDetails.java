package com.vcc.domain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.telemune.vcc.expiringmap.ExpiringMap;
import com.vcc.cache.VccExpiryCache;
import com.vcc.chain.VccChain;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.model.MessageAttribute;
import com.vcc.model.MessageReader;
import com.vcc.model.MessageStatus;
import com.vcc.request.VccMessageRequest;
import com.vcc.response.VccMessageResponse;

public class VccMessageDetails implements VccChain {
	final static Logger logger = Logger.getLogger(VccMessageDetails.class);
	private VccChain nextInVmChain;
	@Autowired
	private VccServices vccServices;
	private MessageStatus messageStatus;
	private MessageReader messageReader;
	private List<MessageAttribute> newMsg;
	private List<MessageAttribute> oldMsg;
	private List<MessageAttribute> saveMsg;
	private List<MessageAttribute> tempMsg;
	private List<MessageAttribute> msgList = null;
	private ExpiringMap<String, Object> msgReaderMap = null;
	private int totalNewMsg;
	private int totalOldMsg;
	private int totalSaveMsg;
	private String tempFile = null;
	@SuppressWarnings("unused")
	private String greetingPath = null;
	private VccCommonOperation commonOperation = null;
	private String msgRetKey = null;

	@Override
	public void setNext(VccChain nextInVmChain, VccServices vccServices) {
		this.nextInVmChain = nextInVmChain;
		this.vccServices = vccServices;

	}

	/**
	 * return void the method is responsible for getting voice mail details of
	 * callingNum and set  message path and message details in cache and set message count details to client
	 * 
	 * @param messageRequest
	 *            the variable contain bean of VccMessageRequest ,which set by
	 *            url request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param messageResponse
	 *            the variable contain bean of VccMessageResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	@Override
	public void process(VccMessageRequest messageRequest,
			VccMessageResponse messageResponse, VmError vmError) {
		this.commonOperation = new VccCommonOperation();

		this.msgRetKey = "ret_" + messageRequest.getCallingNum();
		if (messageRequest.getCallingNum() != null
				&& messageRequest.getCallingNum() != "") {
			
			/*
			 * Added by Vivek to reduce query at 27/09/2016
			 * */
			this.msgList = vccServices.messageService.getMessageInfo(messageRequest);
			Map<String,List<MessageAttribute>> map = this.groupByMessages(messageRequest);
			
			// retrieve and create cache for total msg count in mail box of
			// calling Num.
			this.getAndSetMessageCount(messageRequest, map);
			// retrieve and create cache for total msg's.
			this.getAndSetMessage(messageRequest, map);
			
			this.messageStatus = new MessageStatus();
			this.messageReader.setLastVisitTime(new Date());
			this.messageReader.setMessageStatus(this.messageStatus);
			this.msgReaderMap = VccExpiryCache.pxmlmap;
			if (this.msgReaderMap.containsKey(this.msgRetKey)) {
				logger.info("[" + messageRequest.getCallingNum()
						+ "] message retrieval cahce already exists["
						+ this.msgRetKey + "] so its remove from cache");
				this.msgReaderMap.remove(this.msgRetKey);
			}
			this.msgReaderMap.put(this.msgRetKey, this.messageReader, 30, TimeUnit.MINUTES);

		} else {
			vmError.setError(true);
			vmError.setMsg("callingNum is null");
		}
		if (!vmError.getError()) {

			this.nextInVmChain
					.process(messageRequest, messageResponse, vmError);
		} else {
			logger.error("Reason of error [" + vmError.getMsg() + "] ");
			messageResponse.setIsSuccess(-1);
		}

	}

	public Map<String, List<MessageAttribute>> groupByMessages(VccMessageRequest messageRequest){
		Map<String, List<MessageAttribute>> map = new HashMap<String, List<MessageAttribute>>();
		try { 
			for(MessageAttribute msgAttr: this.msgList){
				String key = msgAttr.getMsgStatus();
				logger.debug("map all values=========="+map);
				if(map.containsKey(key)){
					List<MessageAttribute> list = map.get(key);
			        list.add(msgAttr);
				} else {
					List<MessageAttribute> list = new ArrayList<MessageAttribute>();
					list.add(msgAttr);
					map.put(key, list);
				}
				
			}
			logger.debug("group by message: "+map);
		}catch(Exception e){
			e.printStackTrace();
		}
		return map;
	}
	
	/**
	 * return void this method is responsible for set voice mail path and aPrty greet path details in
	 * cache
	 * @param messageRequest
	 *            the variable contain bean of VccMessageRequest ,which set by
	 *            url request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param list the list contain voice message details
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	private void setMessaageAndGreetingPath(VccMessageRequest messageRequest,
			 List<MessageAttribute> list) {

		this.tempMsg = list;
		logger.debug("List ======"+Arrays.toString(list.toArray()));
		for (MessageAttribute msgAtr : this.tempMsg) {
			this.tempFile = msgAtr.getFileName();
			this.tempFile = this.tempFile.substring(0,
					this.tempFile.length() - AppConfig.config.getInt("default_record_digits", 10));
			msgAtr.setMsgPath(this.commonOperation.getCopletePath(
					this.tempFile, messageRequest.getCallingNum(),
					msgAtr.getFileName(),
					AppConfig.config.getString("ivr_record_path")));
			StringBuilder msisdn = new StringBuilder();
			msisdn.append(AppConfig.config.getString("country_code"));
			msisdn.append(msgAtr.getSenderNum());
			logger.debug("MsgPath ================"+msgAtr.getMsgPath());
			/*this.greetingPath = vccServices.messageService
					.getGreetingFile(String.valueOf(msisdn));
			if (this.greetingPath != null && this.greetingPath != "") {
				this.tempFile = this.greetingPath.substring(0,
						this.greetingPath.length() - AppConfig.config.getInt("default_record_digits", 14));

				this.greetingPath = this.commonOperation.getCopletePath(
						tempFile, msgAtr.getSenderNum(), this.greetingPath,
						AppConfig.config.getString("ivr_greeting_path"));
				msgAtr.setGreetingMsg(this.greetingPath);
			} else {
				logger.info("no greeting found");
			}*/
		}

	}
	/**
	 * return void this method is responsible for getting voice mail details in all category (new,old,delete) from database and setting details in global cache 
	 * @param messageRequest
	 *            the variable contain bean of VccMessageRequest ,which set by
	 *            url request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	private List<MessageAttribute> getMessageByGroup(VccMessageRequest messageRequest,
	Map<String,List<MessageAttribute>> map){
		List<MessageAttribute> list = new ArrayList<MessageAttribute>();
		try {
			list = map.get(messageRequest.getCatName());
			if(list == null)
				list = new ArrayList<MessageAttribute>();
		}catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}
	private void getAndSetMessage(VccMessageRequest messageRequest,Map<String,List<MessageAttribute>> map) {
		messageReader = new MessageReader();
		messageStatus = new MessageStatus();
		// new msg list create
		messageRequest.setCatName("N");
		//this.newMsg = vccServices.messageService.getMessageInfo(messageRequest);
		this.newMsg = this.getMessageByGroup(messageRequest, map);
		logger.info(" create cache for CallingNum ["
				+ messageRequest.getCallingNum() + " and new msg list size ["
				+ this.newMsg.size() + "]]"+"    newMsg============"+Arrays.toString(this.newMsg.toArray()));
		this.setMessaageAndGreetingPath(messageRequest,this.newMsg);
		messageReader.setNewmsg(newMsg);
		// old msg list create
		messageRequest.setCatName("R");
		//this.oldMsg = vccServices.messageService.getMessageInfo(messageRequest);
		this.oldMsg = this.getMessageByGroup(messageRequest, map);
		logger.info("create cache for CallingNum ["
				+ messageRequest.getCallingNum() + " and old msg list size ["
				+ this.oldMsg.size() + "]]"+"    oldMsg============"+Arrays.toString(this.oldMsg.toArray())+"      map======"+map);
		this.setMessaageAndGreetingPath(messageRequest,this.oldMsg);
		messageReader.setOldmsg(oldMsg);
		// save msg list create
		messageRequest.setCatName("S");
		//this.saveMsg = vccServices.messageService.getMessageInfo(messageRequest);
		this.saveMsg = this.getMessageByGroup(messageRequest, map);
		logger.info("create cache for CallingNum ["
				+ messageRequest.getCallingNum() + " and save msg list size ["
				+ this.saveMsg.size() + "]]");
		this.setMessaageAndGreetingPath(messageRequest,this.saveMsg);

		messageReader.setSavemsg(saveMsg);
		
		// to add old and new message in same list for airtel_africa
		if(AppConfig.config.getInt("changes_for_airtel_africa")==1) {
			this.newMsg.addAll(this.oldMsg);
		}
		
		
		messageStatus.setMsgCopy(0);
		messageStatus.setMsgDel(0);
		messageStatus.setMsgMove(0);
		messageStatus.setMsgRead(0);
		messageStatus.setMsgSave(0);
	}
	
	/**
	 * return void this method is responsible for getting voice mail message count in all category (new,old,delete) from database and setting details in global cache 
	 * @param messageRequest
	 *            the variable contain bean of VccMessageRequest ,which set by
	 *            url request like - callingNum , calledNum and set catName and total new ,old and save msg 
	 *            ,serviceType,callDuration,callTime etc
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	private void getAndSetMessageCount(VccMessageRequest messageRequest,Map<String,List<MessageAttribute>> map) {
		logger.debug("[" + messageRequest.getCallingNum()
				+ "] Mail Box info....");
		messageRequest.setCatName("N");
		//this.totalNewMsg = this.vccServices.messageService.getMessageCount(messageRequest);
		this.totalNewMsg = this.getMessageByGroup(messageRequest, map).size();
		messageRequest.setTotalNewMsg(this.totalNewMsg);

		messageRequest.setCatName("R");
		//this.totalOldMsg = this.vccServices.messageService.getMessageCount(messageRequest);
		this.totalOldMsg = this.getMessageByGroup(messageRequest, map).size();
		messageRequest.setTotalOldMsg(this.totalOldMsg);

		messageRequest.setCatName("S");
		//this.totalSaveMsg = this.vccServices.messageService.getMessageCount(messageRequest);
		this.totalSaveMsg = this.getMessageByGroup(messageRequest, map).size();
		messageRequest.setTotalSaveMsg(this.totalSaveMsg);
		
		logger.info(" count.message [" + messageRequest.getCallingNum()
				+ "] Mail Box info.[" + messageRequest.getCallingNum() + "]  total new msg ["
				+ this.totalNewMsg + "]  [" + messageRequest.getCallingNum()
				+ " ]  total read msg [" + this.totalOldMsg + "]  [" + messageRequest.getCallingNum()
				+ "] total save  msg [" + this.totalSaveMsg + "]");
	}

}
