package com.vcc.domain;

import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.validation.BindingResult;

import com.google.gson.JsonParser;
import com.vcc.cache.VccExpiryCache;
import com.vcc.chain.Profile;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServiceFlag;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.filter.Filter;
import com.vcc.model.VccAuthUser;
import com.vcc.model.VccServiceProvider;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.repository.ServicingRepository;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.services.Servicing;

public class GetProfileRetrieval implements Profile, Filter {

	final static Logger logger = Logger.getLogger(GetProfileRetrieval.class);

	@SuppressWarnings("unused")
	private List<VccServiceProvider> serviceList;
	@SuppressWarnings("unused")
	private List<VccSubscriptionMaster> activeServiceList;
	@SuppressWarnings("unused")
	private ServicingRepository servicingRepository;
	private VccSubscriptionMaster activeUser = null;
	@SuppressWarnings("unused")
	private Servicing servicing;
	VccCommonOperation commonOperation = null;
	int altFlag = 0;
	int notiFlag = 0;
	int headerFlag = 0;

	public GetProfileRetrieval() {
	}

	public void execute(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {
		this.process(profileRequest, bindingResult, profileResponse, vmError,
				vccServices);
	}

	/**
	 * return void the method check the Profile of particular msisdn
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of profileResponse , which actually
	 *            return in url response like - isSuccess , isCallAllowed,
	 *            isSubscriber
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void process(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {
		// profileRequest.setCalledNum(profileRequest.getCalledNumB());

		this.activeUser = vccServices.userService
				.getActiveUserByServiceType(profileRequest.getCallingNum(),
						profileRequest.getServiceType());
		logger.debug("[" + profileRequest.getCallingNum() + "] is Subscriber ["
				+ this.activeUser + "] for service type ["
				+ profileRequest.getServiceType() + "]");
		VccAuthUser vccAuthUser = vccServices.userService
				.getProfileDetailByCallingNum(profileRequest);
		logger.info("[" + profileRequest.getCallingNum()
				+ "] destination number [" + profileRequest.getCalledNum()
				+ "]  is sub [" + (this.activeUser != null) + "] ");
		if (vccAuthUser != null && this.activeUser != null) {
			commonOperation = new VccCommonOperation();
			profileResponse.setIsSubscriber(1);
			profileResponse.setRatePlan(activeUser.getRatePlan());
			profileResponse.setSubType(vccAuthUser.getSubType());
			profileResponse.setLang(vccAuthUser.getLanguage());
			this.altFlag = commonOperation.getServiceFlag(
					activeUser.getServiceFlag(),
					VccServiceFlag.alternative_msisdn_enable_disable);
			this.notiFlag = commonOperation.getServiceFlag(
					activeUser.getServiceFlag(),
					VccServiceFlag.notification_enable_disable);
			this.headerFlag = commonOperation.getServiceFlag(
					activeUser.getServiceFlag(),
					VccServiceFlag.message_header_enable_disable);

			profileResponse.setAltFlag(this.altFlag);
			profileResponse.setNotiFlag(this.notiFlag);
			profileResponse.setHeaderFlag(this.headerFlag);
			profileResponse.setIsMigrating(vccAuthUser.getIsMigrating());
			profileResponse.setIsNew(vccAuthUser.getIsNew());
			profileResponse.setPassword(vccAuthUser.getPassword());
			profileResponse.setStatus(vccAuthUser.getStatus());
			int ratePlan = profileResponse.getRatePlan();
			
			profileResponse.setMultiLang(AppConfig.config.getInt("multi_lang")); // added by sanchit
			
			String ratePlanJson = VccExpiryCache.getSysmap().get(
					"vcc_rate_plan");

			logger.debug("rate plan json " + ratePlanJson);

			/*
			 * JsonParser jsonParser = new JsonParser(); String planName =
			 * jsonParser.parse(ratePlanJson).getAsJsonObject() .get("" +
			 * ratePlan + "").getAsJsonObject().get("planName") .toString();
			 * profileResponse.setPlanName(planName);
			 */
			String planName = "D";
			JSONObject o;
			try {
				o = new JSONObject(ratePlanJson);
				planName = o.getJSONObject("" + ratePlan + "").get("planName")
						.toString();
				logger.debug("["
						+ profileRequest.getCallingNum()
						+ "]  rate plan is ["
						+ ratePlan
						+ "]   plan name is ["
						+ o.getJSONObject("" + ratePlan + "").get("planName")
								.toString() + "]");
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				logger.error("Error in parsing rate plan json [" + e + "]");
				e.printStackTrace();
			}

			if (planName.equalsIgnoreCase("executive")) {
				profileResponse.setPlanName("E");
			} else if (planName.equalsIgnoreCase("basic")) {
				profileResponse.setPlanName("B");
			} else if (planName.equalsIgnoreCase("default")) {
				profileResponse.setPlanName("D");
			} else {
				profileResponse.setPlanName("B");
			}

		} else {
			profileResponse.setIsSubscriber(0);
			profileResponse.setRatePlan(0);
			profileResponse.setSubType(AppConfig.config.getString(
					"default_sub_type", "N"));
			profileResponse.setAltFlag(this.altFlag);
			profileResponse.setNotiFlag(this.notiFlag);
			profileResponse.setLang(AppConfig.config
					.getInt("vms_default_language"));

			profileResponse.setIsMigrating(0);
			profileResponse.setIsNew(0);
			profileResponse.setPassword("0000");
			profileResponse.setStatus("N");
			profileResponse.setPlanName("D");
			profileResponse.setMultiLang(AppConfig.config.getInt("multi_lang"));  // added by sanchit 
		}

	}
}
