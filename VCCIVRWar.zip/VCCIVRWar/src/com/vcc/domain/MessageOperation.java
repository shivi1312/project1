package com.vcc.domain;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import com.telemune.vcc.expiringmap.ExpiringMap;
import com.vcc.cache.VccExpiryCache;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServiceFlag;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.model.GroupDetail;
import com.vcc.model.MessageStatus;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.model.VccVoiceMessage;
import com.vcc.request.ProfileRequest;
import com.vcc.request.UserConfigRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.VmResponse;

public class MessageOperation {

	final static Logger logger = Logger.getLogger(MessageOperation.class);
	private GroupDetail groupDetail = null;
	private VccCommonOperation commonOperation = null;
	private List<String> frndList = null;
	private String recordFileName = null;
	private String recordFilePath = null;
	private String destFilePath = null;
	private String sourceFilePath = null;
	private String serviceFlag = null;
	private VccUserCompleteDetails userCompleteDetails = null;
	private int result = 0;
	private Boolean alternativeStatus = false;
	private VccVoiceMessage vccVoiceMessage = null;
	private UserConfigRequest userConfigRequest = null;
	private int notiStatus = 0;
	private Boolean isMailBoxFull=false;
	private Boolean isOldVoiceMailDelete=false;
	private List<VccVoiceMessage> vccMsgList = null;
	private List<VccVoiceMessage> vccList =null;
	private int mailBoxLimit=0;
	private String deleteCat="R";
	private String catName ="R";
	/**
	 * return true if status of sending voice mail to any msisdn is success
	 * other return false this method is responsible for sending voice mail to
	 * end user (msisdn)
	 * 
	 * @param vmRequest
	 *            the variable contain bean of vmRequest ,which set by url
	 *            request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param vmResponse
	 *            the variable contain bean of vmResponse , which actually
	 *            return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return status the method return status of sending message
	 * @see status
	 */
	public VccUserCompleteDetails getCompleteAuthDetail(List<VccUserCompleteDetails> master){
		VccUserCompleteDetails vccSub = null;
		try {
			if(master != null){
				for(VccUserCompleteDetails vccMaster: master){
					return vccMaster;
				}
			}
		}catch(Exception e){
			logger.error("Error while convert master to auth user: "+e.getMessage());
		}
		return vccSub;
	}
	public Boolean sendMsgToMsisdn(VmRequest vmRequest, VmResponse vmResponse,
			VccServices vccServices) {
		commonOperation = new VccCommonOperation();

	
		int localMsgIndex = vccServices.userService.getNextIndex(vmRequest
				.getCalledNumB(),vmRequest.getServiceType());
		this.vccVoiceMessage = new VccVoiceMessage();
		this.vccVoiceMessage.setOriginattingNumber(commonOperation
				.msisdnWithCountryCode(vmRequest.getCallingNum()));
		this.vccVoiceMessage.setDesticationNumber(commonOperation
				.msisdnWithCountryCode(vmRequest.getCalledNumB()));
		this.vccVoiceMessage.setOrginalNumber(commonOperation
				.msisdnWithCountryCode(vmRequest.getCalledNumB()));
		this.vccVoiceMessage.setCallTime(vmRequest.getCallTime());
		this.vccVoiceMessage.setFileName(vmRequest.getRecordFileName());
		this.vccVoiceMessage.setLocalMessageIndex(localMsgIndex);
		this.vccVoiceMessage.setMessageStatus("N");
		this.vccVoiceMessage
				.setRecordingTime(vmRequest.getRecordingDuration() / 1000);
		this.vccVoiceMessage.setServiceType(vmRequest.getServiceType());
		this.vccVoiceMessage.setMsgPriority("H");
		this.vccVoiceMessage.setMsgProtect("F");
		this.vccVoiceMessage.setPassProtected("F");
		this.vccVoiceMessage.setPassword("0000");

		
		// get user details
		this.userCompleteDetails = this.getCompleteAuthDetail(vccServices.userService
							.getUserCompleteDetail(this.vccVoiceMessage
									.getOrginalNumber()));
		this.mailBoxLimit = getMailBoxLimit(this.userCompleteDetails.getRatePlan());
		
		 this.checkMailBoxFull(vmRequest.getCalledNumB(),vmRequest.getServiceType(),vccServices);
		
		 if(this.isMailBoxFull && this.isOldVoiceMailDelete){
			 
			this.deleteOldMsg(vmRequest,vccServices); 
			 
		 }
		
		
		// send msg to mail box of calledNumB
		this.result = vccServices.userService
				.insertVoiceMessage(this.vccVoiceMessage);
		if (this.result > 0) {

			logger.info("[" + vmRequest.getCallingNum() + "] msg send to"
					+ this.vccVoiceMessage.getOrginalNumber()
					+ "] msg send status [" + this.result + "] ");
			//get voice_msg_index
			this.vccVoiceMessage.setVoiceMessageIndex(vccServices.userService
					.getVoiceMsgIndex(vmRequest));
			
			
			if(this.userCompleteDetails.getSubType().equalsIgnoreCase("F"))
			{
				logger.info(" [" + vmRequest.getCallingNum()
						+ "] send notify  to  ["
						+ this.vccVoiceMessage.getDesticationNumber()
						+ "] notification not send because subType is ["+this.userCompleteDetails.getSubType()+"] ");
				commonOperation = null;
				vmResponse.setIsSuccess(1);
				return true;
			}else
			{	
			// get service flag details
			this.serviceFlag = vccServices.userConfigService.getServiceFlag(
					this.vccVoiceMessage.getOrginalNumber(),
					this.vccVoiceMessage.getServiceType());
			this.alternativeStatus = false;
			if (this.serviceFlag != null
					&& (this.alternativeStatus = commonOperation
							.checkServiceFlag(
									serviceFlag,
									VccServiceFlag.alternative_msisdn_enable_disable))) {

				this.userConfigRequest = new UserConfigRequest();
				this.userConfigRequest.setCallingNum(vccVoiceMessage
						.getOrginalNumber());
				this.userConfigRequest
						.setServiceFlagIndex(VccServiceFlag.alternative_msisdn_enable_disable);
				this.userConfigRequest.setServiceType(userCompleteDetails
						.getServiceType());
				
				
				String destNumber = vccServices.userConfigService
						.getMsisdnFromAdvancedDetails(this.userConfigRequest);

				if (destNumber != null) {
					logger.info("[" + vmRequest.getCallingNum()
							+ "]   alternative no. found [" + destNumber + "]");
					this.vccVoiceMessage.setDesticationNumber(destNumber);

				} else {

					logger.info("[" + vmRequest.getCallingNum()
							+ "]   alternative no. not found  sent noti to ["
							+ vccVoiceMessage.getOrginalNumber() + "]");
					this.vccVoiceMessage.setDesticationNumber(vccVoiceMessage
							.getOrginalNumber());

				}
			}

			// send notification to calledNumB
			if (userCompleteDetails != null && this.serviceFlag != null
					&& (this.alternativeStatus = 
					commonOperation.checkServiceFlag(serviceFlag,VccServiceFlag.notification_enable_disable))) {
				
				this.notiStatus = vccServices.userService.saveVccNotification(
						this.vccVoiceMessage, this.userCompleteDetails);
				
			}
			vmResponse.setIsSuccess(1);
			if (VccExpiryCache.pxmlmap.containsKey(vmRequest.getCallingNum()
					+ "_status")) {
				MessageStatus messageStatus = (MessageStatus) VccExpiryCache.pxmlmap
						.get(vmRequest.getCallingNum() + "_status");
				messageStatus.setMsgRecord(messageStatus.getMsgRecord() + 1);
			}

			logger.info(" [" + vmRequest.getCallingNum()
					+ "] send notify  to  ["
					+ this.vccVoiceMessage.getDesticationNumber()
					+ "] is send to alternative msisdn ["
					+ this.alternativeStatus + "]  notify send status ["
					+ this.notiStatus + "]");
			commonOperation = null;
			return true;
			}
		} 
		else {
			commonOperation = null;
			logger.info("[" + vmRequest.getCallingNum() + "] msg send to"
					+ this.vccVoiceMessage.getOrginalNumber()
					+ "] msg send status [" + this.result + "] ");
			vmResponse.setIsSuccess(0);
			return false;
		}

	}

	

	

	/**
	 * return true if status of sending voice mail to group of msisdn is success
	 * other return false this method is responsible for sending voice mail to
	 * end user (msisdn)
	 * 
	 * @param vmRequest
	 *            the variable contain bean of vmRequest ,which set by url
	 *            request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param vmResponse
	 *            the variable contain bean of vmResponse , which actually
	 *            return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return status the method return status of sending message
	 * @see status
	 */
	public Boolean sendMsgToGroup(VmRequest vmRequest, VmResponse vmResponse,
			VccServices vccServices) {
		commonOperation = new VccCommonOperation();
		this.groupDetail = new GroupDetail();
		this.groupDetail.setCallingNum(vmRequest.getCallingNum());
		this.groupDetail.setGroupId(vmRequest.getGroupId());
		this.frndList = vccServices.userConfigService
				.getMsisdnList(groupDetail);
		// get source file path
			
		this.sourceFilePath = commonOperation.getCopletePath(
				vmRequest.getRecordFileName().substring(0,
						vmRequest.getRecordFileName().length() - AppConfig.config.getInt("default_record_digits", 10)),
				vmRequest.getCallingNum(), vmRequest.getRecordFileName(),
				AppConfig.config.getString("ivr_record_path"));

		if(this.frndList.size()>0)
			
		{
		for (Iterator<String> msisdnItr = this.frndList.iterator(); msisdnItr
				.hasNext();) {
			String msisdn = (String) msisdnItr.next();
			this.recordFileName = commonOperation.getRecordFileName();
			this.recordFilePath = commonOperation.getRecordFilePath(msisdn,
					this.recordFileName,
					AppConfig.config.getString("ivr_record_path"));
			// get source file path
			this.destFilePath = commonOperation.getCopletePath(
					this.recordFileName.substring(0,
							this.recordFileName.length() - AppConfig.config.getInt("default_record_digits", 10)), msisdn,
					this.recordFileName,
					AppConfig.config.getString("ivr_record_path"));
			// copy source to destination file path
			if (commonOperation.copyRecordFile(this.sourceFilePath,
					this.destFilePath)) {
				int localMsgIndex = vccServices.userService
						.getNextIndex(msisdn,vmRequest.getServiceType());
				this.vccVoiceMessage = new VccVoiceMessage();
				this.vccVoiceMessage.setOriginattingNumber(commonOperation
						.msisdnWithCountryCode(vmRequest.getCallingNum()));
				this.vccVoiceMessage.setDesticationNumber(commonOperation
						.msisdnWithCountryCode(msisdn));
				this.vccVoiceMessage.setOrginalNumber(commonOperation
						.msisdnWithCountryCode(msisdn));
				this.vccVoiceMessage.setCallTime(vmRequest.getCallTime());
				this.vccVoiceMessage.setFileName(this.recordFileName);
				this.vccVoiceMessage.setLocalMessageIndex(localMsgIndex);
				this.vccVoiceMessage.setMessageStatus("N");
				this.vccVoiceMessage.setRecordingTime(vmRequest
						.getRecordingDuration() / 1000);
				this.vccVoiceMessage.setServiceType(vmRequest.getServiceType());
				this.vccVoiceMessage.setMsgPriority("H");
				this.vccVoiceMessage.setMsgProtect("F");
				this.vccVoiceMessage.setPassProtected("F");
				this.vccVoiceMessage.setPassword("0000");
				
				//get user details
				this.userCompleteDetails = this.getCompleteAuthDetail(vccServices.userService
						.getUserCompleteDetail(this.vccVoiceMessage
								.getOrginalNumber()));
				vmRequest.setCalledNumB(this.vccVoiceMessage
						.getOrginalNumber());
				
				this.mailBoxLimit = getMailBoxLimit(this.userCompleteDetails.getRatePlan());
				
				 this.checkMailBoxFull(vmRequest.getCalledNumB(),vmRequest.getServiceType(),vccServices);
				
				 if(this.isMailBoxFull && this.isOldVoiceMailDelete){
					 
					this.deleteOldMsg(vmRequest,vccServices); 
					 
				 }
				
				
				// send msg to mail box of group member
				this.result = vccServices.userService
						.insertVoiceMessage(vccVoiceMessage);
				if (this.result > 0) {
					
					
					
					//get voice_msg_index
					vmRequest.setRecordFileName(this.recordFileName);
					this.vccVoiceMessage.setVoiceMessageIndex(vccServices.userService
							.getVoiceMsgIndex(vmRequest));
					
			
					logger.info("[" + vmRequest.getCallingNum()
							+ "] msg send to	[" + msisdn
							+ "] msg reply status [" + this.result + "]");
					if(this.userCompleteDetails.getSubType().equalsIgnoreCase("F"))
					{
						logger.info(" [" + vmRequest.getCallingNum()
								+ "] send notify  to  ["
								+ this.vccVoiceMessage.getDesticationNumber()
								+ "] notification not send because subType is ["+this.userCompleteDetails.getSubType()+"]");
					}else{
					// check service flag
					this.serviceFlag = vccServices.userConfigService
							.getServiceFlag(
									this.vccVoiceMessage.getOrginalNumber(),
									this.vccVoiceMessage.getServiceType());
					this.alternativeStatus = false;
					if (this.serviceFlag != null
							&& (this.alternativeStatus = commonOperation
									.checkServiceFlag(
											serviceFlag,
											VccServiceFlag.alternative_msisdn_enable_disable))) {

						this.userConfigRequest = new UserConfigRequest();
						this.userConfigRequest.setCallingNum(vccVoiceMessage
								.getOrginalNumber());
						this.userConfigRequest
								.setServiceFlagIndex(VccServiceFlag.alternative_msisdn_enable_disable);
						this.userConfigRequest
								.setServiceType(userCompleteDetails
										.getServiceType());
						String destNumber = vccServices.userConfigService
								.getMsisdnFromAdvancedDetails(userConfigRequest);
						if (destNumber != null) {
							logger.info("[" + vmRequest.getCallingNum()
									+ "]   alternative no. found ["
									+ destNumber + "]");
							this.vccVoiceMessage
									.setDesticationNumber(destNumber);

						} else {

							logger.info("["
									+ vmRequest.getCallingNum()
									+ "]   alternative no. not found  sent noti to ["
									+ vccVoiceMessage.getOrginalNumber() + "]");
							this.vccVoiceMessage
									.setDesticationNumber(vccVoiceMessage
											.getOrginalNumber());

						}

					}

					// send notification to group member
					if (this.userCompleteDetails != null) {
						this.result = vccServices.userService
								.saveVccNotification(this.vccVoiceMessage,
										this.userCompleteDetails);

					}
					logger.info(" [" + vmRequest.getCallingNum()
							+ "] send notify  to  ["
							+ this.vccVoiceMessage.getDesticationNumber()
							+ "] is send to alternative msisdn ["
							+ this.alternativeStatus
							+ "]  notify send status [" + this.result + "]");

					if (VccExpiryCache.pxmlmap.containsKey(vmRequest
							.getCallingNum() + "_status")) {
						MessageStatus messageStatus = (MessageStatus) VccExpiryCache.pxmlmap
								.get(vmRequest.getCallingNum() + "_status");
						messageStatus
								.setMsgRecord(messageStatus.getMsgRecord() + 1);
					}
					}
				}
			} else {
				
				
				result = -1;
				logger.info("[" + vmRequest.getCallingNum()
						+ "] send notification to	[" + msisdn
						+ "] msg reply status [" + result + "]");

			}
		}
		}else
		{
			result=0;
			logger.warn("["+vmRequest.getCallingNum()+"] group id ["+vmRequest.getGroupId()+"] size is ["+this.frndList.size()+"]");
		}
		commonOperation = null;
		vmResponse.setIsSuccess(result);
		if (result != 0)
			return true;
		else
			return false;
	}

	/**
	 * return true if status of sending voice mail to any msisdn is success
	 * other return false this method is responsible for sending voice mail to
	 * end user (msisdn) after some scheduling time
	 * 
	 * @param vmRequest
	 *            the variable contain bean of vmRequest ,which set by url
	 *            request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param vmResponse
	 *            the variable contain bean of vmResponse , which actually
	 *            return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return status the method return status of sending message
	 * @see status
	 */
	public Boolean sendMsgLaterToMsisdn(VmRequest vmRequest,
			VmResponse vmResponse, VccServices vccServices) {

		String scheduleDate = vmRequest.getScheduleDate()
				+ vmRequest.getScheduleTime();
		
		if(scheduleDate.length()==8)
		{
			scheduleDate = scheduleDate  + "00";
		}
			
		commonOperation = new VccCommonOperation();
		if (commonOperation.isValidDate(scheduleDate)
				&& commonOperation.isDateAfterCurrentDate(scheduleDate)) {

			int localMsgIndex = vccServices.userService.getNextIndex(vmRequest
					.getCalledNumB(),vmRequest.getServiceType());
			this.vccVoiceMessage = new VccVoiceMessage();
			this.vccVoiceMessage.setOriginattingNumber(commonOperation
					.msisdnWithCountryCode(vmRequest.getCallingNum()));
			this.vccVoiceMessage.setDesticationNumber(commonOperation
					.msisdnWithCountryCode(vmRequest.getCalledNumB()));
			this.vccVoiceMessage.setOrginalNumber(commonOperation
					.msisdnWithCountryCode(vmRequest.getCalledNumB()));
			this.vccVoiceMessage.setCallTime(vmRequest.getCallTime());
			this.vccVoiceMessage.setFileName(vmRequest.getRecordFileName());
			this.vccVoiceMessage.setLocalMessageIndex(localMsgIndex);
			this.vccVoiceMessage.setMessageStatus("P");
			this.vccVoiceMessage.setRecordingTime(vmRequest
					.getRecordingDuration() / 1000);
			this.vccVoiceMessage.setServiceType(vmRequest.getServiceType());
			this.vccVoiceMessage.setMsgPriority("H");
			this.vccVoiceMessage.setMsgProtect("F");
			this.vccVoiceMessage.setPassProtected("F");
			this.vccVoiceMessage.setPassword("0000");
			this.vccVoiceMessage.setSendingTime(commonOperation
					.parseDate(scheduleDate));

			this.userCompleteDetails = this.getCompleteAuthDetail(vccServices.userService
					.getUserCompleteDetail(this.vccVoiceMessage
							.getOrginalNumber()));

			// insert into msg schedule table
			if (userCompleteDetails != null
					&& vccServices.messageService.insertVoiceMsgWithScheduling(
							vccVoiceMessage, userCompleteDetails)) {
				logger.info(" [" + vmRequest.getCallingNum()
						+ "] send msg later   to  ["
						+ this.vccVoiceMessage.getDesticationNumber()
						+ "]   send msg later status [true]");
				vmResponse.setIsSuccess(1);
				if (VccExpiryCache.pxmlmap.containsKey(vmRequest
						.getCallingNum() + "_status")) {
					MessageStatus messageStatus = (MessageStatus) VccExpiryCache.pxmlmap
							.get(vmRequest.getCallingNum() + "_status");
					messageStatus
							.setMsgRecord(messageStatus.getMsgRecord() + 1);
				}
				return true;
			} else {
				logger.info(" [" + vmRequest.getCallingNum()
						+ "] send msg later   to  ["
						+ this.vccVoiceMessage.getDesticationNumber()
						+ "] failed becoz  userCompleteDetails not found ");
			}

		} else {
			commonOperation = null;
			logger.info(" ["
					+ vmRequest.getCallingNum()
					+ "] send notify  to  ["
					+ vmRequest.getCalledNumB()
					+ "]  notify send status [false] and shedule date is parser[false]");
			vmResponse.setIsSuccess(-1);
			return false;
		}
		vmResponse.setIsSuccess(1);
		return true;
	}

	/**
	 * return true if status of sending voice mail to group of msisdn is success
	 * other return false this method is responsible for sending voice mail to
	 * end user (msisdn) after some scheduling time
	 * 
	 * @param vmRequest
	 *            the variable contain bean of vmRequest ,which set by url
	 *            request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param vmResponse
	 *            the variable contain bean of vmResponse , which actually
	 *            return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return status the method return status of sending message
	 * @see status
	 */
	public Boolean sendMsgLaterToGroup(VmRequest vmRequest,
			VmResponse vmResponse, VccServices vccServices) {

	/*	String scheduleDate = vmRequest.getScheduleDate()
				+ vmRequest.getScheduleTime() + "00";
	*/	
		String scheduleDate = vmRequest.getScheduleDate()
				+ vmRequest.getScheduleTime();
		
		if(scheduleDate.length()==8)
		{
			scheduleDate = scheduleDate  + "00";
		}
			
	
		commonOperation = new VccCommonOperation();
		//
		if (commonOperation.isValidDate(scheduleDate)
				&& commonOperation.isDateAfterCurrentDate(scheduleDate)) {
			this.groupDetail = new GroupDetail();
			this.groupDetail.setCallingNum(vmRequest.getCallingNum());
			this.groupDetail.setGroupId(vmRequest.getGroupId());
			this.frndList = vccServices.userConfigService
					.getMsisdnList(groupDetail);
			// get source file path
			this.sourceFilePath = commonOperation.getCopletePath(
					vmRequest.getRecordFileName().substring(0,
							vmRequest.getRecordFileName().length() - AppConfig.config.getInt("default_record_digits", 10)),
					vmRequest.getCallingNum(), vmRequest.getRecordFileName(),
					AppConfig.config.getString("ivr_record_path"));
			logger.info("frnd list size [" + this.frndList.size() + "]");
			
			if(this.frndList.size()>0)
			{
			for (Iterator<String> msisdnItr = this.frndList.iterator(); msisdnItr
					.hasNext();) {
				String msisdn = (String) msisdnItr.next();
				this.recordFileName = commonOperation.getRecordFileName();
				this.recordFilePath = commonOperation.getRecordFilePath(msisdn,
						this.recordFileName,
						AppConfig.config.getString("ivr_record_path"));
				// get source file path
				this.destFilePath = commonOperation.getCopletePath(
						this.recordFileName.substring(0,
								this.recordFileName.length() - AppConfig.config.getInt("default_record_digits", 10)), msisdn,
						this.recordFileName,
						AppConfig.config.getString("ivr_record_path"));
				// copy source to destination file path
				if (commonOperation.copyRecordFile(this.sourceFilePath,
						this.destFilePath)) {

					int localMsgIndex = vccServices.userService
							.getNextIndex(msisdn,vmRequest.getServiceType());
					this.vccVoiceMessage = new VccVoiceMessage();
					this.vccVoiceMessage.setOriginattingNumber(commonOperation
							.msisdnWithCountryCode(vmRequest.getCallingNum()));
					this.vccVoiceMessage.setDesticationNumber(commonOperation
							.msisdnWithCountryCode(msisdn));
					this.vccVoiceMessage.setOrginalNumber(commonOperation
							.msisdnWithCountryCode(msisdn));
					this.vccVoiceMessage.setCallTime(vmRequest.getCallTime());
					this.vccVoiceMessage.setFileName(this.recordFileName);
					this.vccVoiceMessage.setLocalMessageIndex(localMsgIndex);
					this.vccVoiceMessage.setMessageStatus("P");
					this.vccVoiceMessage.setRecordingTime(vmRequest
							.getRecordingDuration() / 1000);
					this.vccVoiceMessage.setServiceType(vmRequest
							.getServiceType());
					this.vccVoiceMessage.setMsgPriority("H");
					this.vccVoiceMessage.setMsgProtect("F");
					this.vccVoiceMessage.setPassProtected("F");
					this.vccVoiceMessage.setPassword(null);
					this.vccVoiceMessage.setSendingTime(commonOperation
							.parseDate(scheduleDate));
					this.userCompleteDetails = this.getCompleteAuthDetail(vccServices.userService
							.getUserCompleteDetail(this.vccVoiceMessage
									.getOrginalNumber()));

					// insert into msg schedule table
					if (this.userCompleteDetails != null
							&& vccServices.messageService
									.insertVoiceMsgWithScheduling(
											this.vccVoiceMessage,
											this.userCompleteDetails)) {
						vmResponse.setIsSuccess(1);
						logger.info("Message sending later from ["
								+ vmRequest.getCallingNum() + "] to [" + msisdn
								+ "]");
						result = 1;
						if (VccExpiryCache.pxmlmap.containsKey(vmRequest
								.getCallingNum() + "_status")) {
							MessageStatus messageStatus = (MessageStatus) VccExpiryCache.pxmlmap
									.get(vmRequest.getCallingNum() + "_status");
							messageStatus.setMsgRecord(messageStatus
									.getMsgRecord() + 1);
						}

					} else {
						logger.info("Message sending later failed from ["
								+ vmRequest.getCallingNum() + "] to [" + msisdn
								+ "]");
					}

				} else {
					
					result = -1;
					logger.warn("["+vmRequest.getCallingNum()+"] group id ["+vmRequest.getGroupId()+"] file not copy");

				}
				

			}			}
			else
			{
				result=0;
				logger.warn("["+vmRequest.getCallingNum()+"] group id ["+vmRequest.getGroupId()+"] size is ["+this.frndList.size()+"]");
			
			}

			commonOperation = null;
			vmResponse.setIsSuccess(result);
			
		} else {
			commonOperation = null;
			logger.info(" ["
					+ vmRequest.getCallingNum()
					+ "] send notify  to  ["
					+ vmRequest.getCalledNumB()
					+ "]  notify send status [false] and shedule date is parser[false]");
			vmResponse.setIsSuccess(-1);

		}
		if (result == 1)
			return true;
		else
			return false;
	}

	private void  checkMailBoxFull(String msisdn,String serviceType,
			VccServices vccServices) {

		this.vccList=vccServices.userService.getMailboxGroupByCount(msisdn, serviceType);
			
		if(this.vccList!=null && this.mailBoxLimit<=this.vccList.size())
		{
		this.vccMsgList = vccServices.userService
				.getMailboxOrderByCallTime(msisdn,serviceType);
		this.isMailBoxFull=true;
		this.isOldVoiceMailDelete=true;
		
		}else
		{
			this.isMailBoxFull=false;
			this.isOldVoiceMailDelete=false;
		}
		
		
	}

	private Boolean deleteOldMsg(VmRequest vmRequest, VccServices vccServices) {
		
		Boolean status=false;
		
		logger.info("["+vmRequest.getCallingNum()+"] old mail going to deleted ["+this.vccMsgList.get(0).getVoiceMessageIndex()+"]");
		if(this.deleteCat.equalsIgnoreCase("R"))
		{
			logger.debug("find read msg in list cat ["+this.deleteCat+"]");
			this.catName="R";
			status = deleteOldMsgByCategory(this.deleteCat,this.catName,vmRequest,vccServices);
		
		}
		if(this.deleteCat!=null && this.deleteCat.equalsIgnoreCase("N"))
		{
			logger.debug("find new  msg in list cat ["+this.deleteCat+"]");
			this.catName="N";
			status = deleteOldMsgByCategory(this.deleteCat,this.catName,vmRequest,vccServices);
		
		}
		if(this.deleteCat!=null && this.deleteCat.equalsIgnoreCase("S"))
		{
			logger.debug("find save  msg in list cat ["+this.deleteCat+"]");
			this.catName="S";
			status = deleteOldMsgByCategory(this.deleteCat,this.catName,vmRequest,vccServices);
		
		}
		
		return status;
		
	}
	private Boolean deleteOldMsgByCategory(String deleteCat, String catName, VmRequest vmRequest, VccServices vccServices) {
		Boolean status=false,status1=false;
		
		for (VccVoiceMessage msg : this.vccMsgList) {

			if (msg.getMessageStatus().equalsIgnoreCase(this.catName)) {
				status = vccServices.userService.deleteVccVoiceMessage(
						msg.getDesticationNumber(),
						msg.getVoiceMessageIndex());
				commonOperation = new VccCommonOperation();
				// write the logic of delete old voice mail phisically
				status1 = commonOperation
						.deletePhysicalFile(msg.getFileName(),
								msg.getDesticationNumber(),null,AppConfig.config.getString("ivr_record_path"));
				logger.info("delete mail box os ["
						+ vmRequest.getCalledNumB()
						+ "] and voice mail box is ["
						+ msg.getVoiceMessageIndex()
						+ "] and stauts of delete old file[" + status1
						+ "]  delete category is ["+this.catName+"]");
				this.deleteCat=null;
				break;
			} else {
				
				if(this.catName.equalsIgnoreCase("R"))
					this.deleteCat ="N";
				else if(this.catName.equalsIgnoreCase("N"))
					this.deleteCat="S";
				continue;
			}
			

		}
		logger.info("["+vmRequest.getCallingNum()+"] delete mail box os ["
						+ vmRequest.getCalledNumB()
						+ "] and stauts["+status+"] of delete old file[" + status1
						+ "]  delete category is ["+this.catName+"] ");
		return status;
		}
	private int getMailBoxLimit(int ratePlan) {
		int mailBoxId=0,maxMessage=0;
		String ratePlanJson = VccExpiryCache.getSysmap().get("vcc_rate_plan");

		logger.debug("rate plan json " + ratePlanJson);

		JSONObject o;
		try {
			o = new JSONObject(ratePlanJson);
			mailBoxId = Integer.parseInt( o.getJSONObject(
					"" + ratePlan + "").get("mailBoxId").toString());

		} catch (JSONException e) {
			
			e.printStackTrace();
		}

		String mailBoxParam = VccExpiryCache.getSysmap().get(
				"vcc_mailbox_param");

		logger.debug("mailbox  plan json " + mailBoxParam);

		try {
			o = new JSONObject(mailBoxParam);
			maxMessage = Integer.parseInt(o.getJSONObject("" + mailBoxId + "")
					.get("maxMessage").toString());
			

		} catch (JSONException e) {

			e.printStackTrace();
		}
		
		return maxMessage;
	}

	
	
}
