package com.vcc.domain;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.chain.Profile;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.filter.Filter;
import com.vcc.model.VccAuthUser;
import com.vcc.model.VccServiceProvider;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.repository.ServicingRepository;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.services.Servicing;

public class GetProfileReply implements Profile, Filter {

	final static Logger logger = Logger.getLogger(GetProfileReply.class);

	@SuppressWarnings("unused")
	private List<VccServiceProvider> serviceList;
	@SuppressWarnings("unused")
	private List<VccSubscriptionMaster> activeServiceList;
	@SuppressWarnings("unused")
	private ServicingRepository servicingRepository;
	private VccSubscriptionMaster activeUser = null;
	@SuppressWarnings("unused")
	private Servicing servicing;

	public GetProfileReply() {
	}

	public void execute(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {
		this.process(profileRequest, bindingResult, profileResponse, vmError,
				vccServices);
	}
	/**
	 * return void 
	 * the method check the Profile of particular msisdn  for reply
	 * @param profileRequest the variable contain bean of ProfileRequest ,which set by url request like - callingNum , calledNum ,serviceType etc  
	 * @param profileResponse the variable contain bean of  profileResponse , which actually return in url response like - isSuccess , isCallAllowed, isSubscriber 
	 * @param vmError vmError is a bean that is used to define which type of error generate in operation
	 * @param vccServices vccServices is a bean that contain reference of interface(UserService,MessageService,UserConfigService) 
	 * @return void     
	 * @see    nothing
	 */
	public void process(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {
		profileRequest.setCalledNum(profileRequest.getCalledNumB());

		this.activeUser = vccServices.userService
				.getActiveUserByServiceType(profileRequest.getCalledNumB(),
						profileRequest.getServiceType());
		VccAuthUser vccAuthUser = vccServices.userService
				.getProfileDetailByCalledNum(profileRequest);
		logger.info("destination number [" + profileRequest.getCalledNumB()
				+ "]  is sub [" + (this.activeUser != null) + "]");
		if (vccAuthUser != null && this.activeUser != null) {

			profileResponse.setIsSubscriber(1);
			profileResponse.setRatePlan(activeUser.getRatePlan());
			profileResponse.setSubType(vccAuthUser.getSubType());
			profileResponse.setLang(vccAuthUser.getLanguage());
		} else {
			profileResponse.setIsSubscriber(0);
			profileResponse.setRatePlan(0);
			profileResponse.setSubType(AppConfig.config.getString("default_sub_type", "N"));
			profileResponse.setLang(AppConfig.config.getInt("vms_default_language"));
		}
	}
}
