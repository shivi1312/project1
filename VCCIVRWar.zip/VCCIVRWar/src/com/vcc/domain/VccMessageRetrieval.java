package com.vcc.domain;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.telemune.vcc.expiringmap.ExpiringMap;
import com.vcc.cache.VccExpiryCache;
import com.vcc.chain.VccChain;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.model.MessageAttribute;
import com.vcc.model.MessageReader;
import com.vcc.model.MessageStatus;
import com.vcc.request.VccMessageRequest;
import com.vcc.response.VccMessageResponse;

public class VccMessageRetrieval implements VccChain {
	final static Logger logger = Logger.getLogger(VccMessageRetrieval.class);
	private VccChain nextInVmChain;
	@Autowired
	private VccServices vccServices;
	private MessageStatus messageStatus;
	private MessageReader messageReader;
	private MessageAttribute messageAttribute;
	private List<MessageAttribute> newMsg;
	private List<MessageAttribute> oldMsg;
	private List<MessageAttribute> saveMsg;
	private List<MessageAttribute> tempMsg;
	private ExpiringMap<String, Object> msgReaderMap = null;
	private String callingNum;
	private String calledNum;
	private Boolean readMsg = false;
	private int readMsgIndex = 0;
	private String pointer = "N";
	private String catName = "N";
	private String serviceType = "0000";
	private String available = "S";
	private int nextIndex = 0;
	private int prevIndex = 0;
	private String msgRetKey = null;
	private VccCommonOperation commonOperation = null;
	private Boolean default_message_header = true;

	@Override
	public void setNext(VccChain nextInVmChain, VccServices vccServices) {
		this.nextInVmChain = nextInVmChain;
		this.vccServices = vccServices;

	}

	/**
	 * return void this method is responsible for retrieving message from global
	 * cache for callingNum
	 * 
	 * @param messageRequest
	 *            the variable contain bean of vmRequest ,which set by url
	 *            request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param messageResponse
	 *            the variable contain bean of vmResponse , which actually
	 *            return in url response like -
	 *            isSuccess(0,1),msgPath,catName,msgIndex etc
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	@Override
	public void process(VccMessageRequest messageRequest,
			VccMessageResponse messageResponse, VmError vmError) {
		logger.debug("inside process for message retrieval....");
		this.callingNum = messageRequest.getCallingNum();
		this.calledNum = messageRequest.getCalledNum();
		this.catName = messageRequest.getCatName();
		this.available = messageRequest.getAvailable();
		this.nextIndex = messageRequest.getNxtIndex();
		this.prevIndex = messageRequest.getPrvIndex();
		this.pointer = messageRequest.getPointer();
		this.readMsg = messageRequest.getReadMsg();
		this.readMsgIndex = messageRequest.getReadMsgIndex();
		this.msgRetKey = "ret_" + messageRequest.getCallingNum();
		this.default_message_header = AppConfig.config.getBoolean(
				"default_message_header", true);
		this.msgReaderMap = VccExpiryCache.pxmlmap;

		logger.debug("callingNum==="+this.callingNum+"      calledNum===="+this.calledNum+"       catName======"+this.catName+"    "
				+ "  available==="+this.available+"      this.nextIndex===="+this.nextIndex+"       this.prevIndex==="+this.prevIndex+"      "
						+ "this.pointer"+this.pointer+"    this.readMsg===="+this.readMsg+"     readMsgIndex==="+this.readMsgIndex+"   "
								+ "  msgRetKey==="+this.msgRetKey+"    default_message_header===="+this.default_message_header+"  "
										+ "   this.msgReaderMap==="+this.msgReaderMap.toString());
		
		
		if (this.callingNum != null && this.callingNum != ""
				&& this.catName != null && this.catName != ""
				&& this.available != null && this.available != ""
				&& this.pointer != null && this.pointer != ""
				&& this.msgReaderMap.containsKey(this.msgRetKey)) {

			this.messageReader = (MessageReader) this.msgReaderMap
					.get(this.msgRetKey);

			if (catName.equalsIgnoreCase("N")) {
				this.newMsg = this.messageReader.newmsg;

				if (this.readMsg && this.readMsgIndex != 0) {

					// msg status update after read
					if (VccExpiryCache.pxmlmap.containsKey(this.callingNum
							+ "_status")) {
						MessageStatus messageStatus = (MessageStatus) VccExpiryCache.pxmlmap
								.get(this.callingNum + "_status");
						messageStatus
								.setMsgRead(messageStatus.getMsgRead() + 1);
					}
					Boolean status = this.vccServices.messageService
							.updateMsgStatus(this.callingNum, this.readMsgIndex);
					logger.info(String
							.format("A-Party [%s] update msgStatus [%s] of voicemsgindex [%s]  ",
									this.callingNum, status, this.readMsgIndex));
					this.messageStatus = this.messageReader.messageStatus;
					this.messageStatus.setMsgRead(this.messageStatus
							.getMsgRead() + 1);
				}

				if (this.newMsg.size() != 0) {
					this.setMessage(messageRequest, messageResponse,
							this.newMsg, vmError);
				} else {
					vmError.setError(true);
					vmError.setMsg("NO New msg found");
				}

			} else if (catName.equalsIgnoreCase("R")) {
				this.oldMsg = this.messageReader.oldmsg;

				if (this.oldMsg.size() != 0) {
					this.setMessage(messageRequest, messageResponse,
							this.oldMsg, vmError);
				} else {
					vmError.setError(true);
					vmError.setMsg("NO Old msg found");
				}
			} else if (catName.equalsIgnoreCase("S")) {
				this.saveMsg = this.messageReader.savemsg;
				if (this.saveMsg.size() != 0) {
					this.setMessage(messageRequest, messageResponse,
							this.saveMsg, vmError);
				} else {

					vmError.setError(true);
					vmError.setMsg("NO Save msg found");
				}
			} else {
				vmError.setError(true);
				vmError.setMsg("callingNum is [" + this.callingNum
						+ "] invalid cat name [" + this.pointer
						+ "]  pointer [" + this.pointer + "] service Type ["
						+ AppConfig.config.getString(serviceType, "0000") + "]");
			}

		} else {
			vmError.setError(true);
			vmError.setMsg("callingNum is [" + this.callingNum + "] cat name ["
					+ this.catName + "] pointer [" + this.pointer
					+ "] service Type ["
					+ AppConfig.config.getString(serviceType, "0000") + "]");

		}

		if (!vmError.getError()) {
			messageResponse.setIsSuccess(1);
		} else {
			messageResponse.setIsSuccess(-1);
			logger.error(vmError.getMsg());
		}

	}

	/**
	 * return void this method is responsible for set voice mail details of
	 * callingNum in VccMessageResponse bean
	 * 
	 * @param messageRequest
	 *            the variable contain bean of vmRequest ,which set by url
	 *            request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param messageResponse
	 *            the variable contain bean of vmResponse , which actually
	 *            return in url response like -
	 *            isSuccess(0,1),msgPath,catName,msgIndex etc
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	private void setMessage(VccMessageRequest messageRequest,
			VccMessageResponse messageResponse, List<MessageAttribute> msgList,
			VmError vmError) {
		this.tempMsg = msgList;

		if (this.pointer.equalsIgnoreCase("S")) {

			this.messageAttribute = this.tempMsg.get(this.nextIndex);

			if (this.tempMsg.size() == 1) {
				messageResponse.setAvailable("S"); // S for single
			} else if (this.tempMsg.size() - 1 == this.nextIndex) {
				messageResponse.setAvailable("L"); // L for Last
			} else if (this.nextIndex > 0
					&& this.nextIndex < this.tempMsg.size() - 1) {
				messageResponse.setAvailable("P"); // P for Process
				this.nextIndex = this.nextIndex + 1;
			} else if (this.nextIndex == 0 && this.prevIndex == 0) {
				messageResponse.setAvailable("F"); // F for First
				this.nextIndex = this.nextIndex + 1;
			}

			messageResponse.setNxtIndex(this.nextIndex);
			messageResponse.setPrvIndex(this.nextIndex - 1);
			logger.info("pointer [" + this.pointer + "] available ["
					+ messageResponse.getAvailable() + "] nextIndex ["
					+ messageResponse.getNxtIndex() + "] prevIndex ["
					+ messageResponse.getPrvIndex() + "]");

		} else if (this.pointer.equalsIgnoreCase("N")) {

			this.messageAttribute = this.tempMsg.get(this.nextIndex);

			if (this.nextIndex >= 0 && this.nextIndex < this.tempMsg.size() - 1) {
				messageResponse.setAvailable("P"); // P for process
				this.nextIndex = this.nextIndex + 1;
			} else if (this.tempMsg.size() - 1 == this.nextIndex) {
				messageResponse.setAvailable("L"); // L for First
			}

			messageResponse.setNxtIndex(this.nextIndex);
			messageResponse.setPrvIndex(this.nextIndex - 1);
			logger.info("pointer [" + this.pointer + "] available ["
					+ messageResponse.getAvailable() + "] nextIndex ["
					+ messageResponse.getNxtIndex() + "] prevIndex ["
					+ messageResponse.getPrvIndex() + "]");

		} else if (this.pointer.equalsIgnoreCase("P")) {

			this.messageAttribute = this.tempMsg.get(this.prevIndex);
			if (this.prevIndex == 0 || this.prevIndex == -1) {
				messageResponse.setAvailable("F"); // F for First
			} else if (this.tempMsg.size() > 1 && this.prevIndex > 0) {
				messageResponse.setAvailable("P"); // P for process
				this.prevIndex = this.prevIndex - 1;
			}

			messageResponse.setNxtIndex(this.prevIndex + 1);
			messageResponse.setPrvIndex(this.prevIndex);
			logger.info("[" + messageRequest.getCallingNum() + "]  pointer ["
					+ this.pointer + "] available ["
					+ messageResponse.getAvailable() + "] nextIndex ["
					+ messageResponse.getNxtIndex() + "] prevIndex ["
					+ messageResponse.getPrvIndex() + "]");
		} else {
			vmError.setError(true);
			vmError.setMsg("callingNum is [" + this.callingNum
					+ "]  cat name [" + this.pointer + "] invalid pointer ["
					+ this.pointer + "] service Type ["
					+ AppConfig.config.getString(serviceType, "0000") + "]");
		}

		commonOperation = new VccCommonOperation();
		StringBuilder sb = new StringBuilder();
		
		
		logger.info("message header flag is ["+messageRequest.getHeaderFlag()+"]");
		
		// append date time of sending mail
		
		// Condition Commented by AbhiShek Rana for separating voice mail and Voice Note on 05-06-2017
		
		/*if (messageRequest.getHeaderFlag() == 0
				|| (messageRequest.getServiceType()
						.equalsIgnoreCase(AppConfig.config.getString("VN",
								"0100")) && this.default_message_header)) {*/
		if (messageRequest.getHeaderFlag() == 0
				&& messageRequest.getServiceType().equalsIgnoreCase(
						AppConfig.config.getString("VM", "0010"))) {
			logger.info("[" + messageRequest.getCallingNum()
					+ "]  msg header is enable ");
			sb.append(AppConfig.config.getString("ivr_common_path")
					+ File.separator + messageRequest.getLang()
					+ File.separator + "YOU_HAVE.wav");
			sb.append(",");
			sb.append(AppConfig.config.getString("ivr_common_path")
					+ File.separator + messageRequest.getLang()
					+ File.separator + "MESSAGE_FROM.wav");
			sb.append(",");
			sb.append(commonOperation.getMsisdnPath(
					this.messageAttribute.getSenderNum(),
					messageRequest.getLang()));
			sb.append(",");
			sb.append(commonOperation.convertDateToPath(
					this.messageAttribute.getSendingTime(),
					messageRequest.getLang()));
			sb.append(",");
		}else if(messageRequest.getServiceType().equalsIgnoreCase(AppConfig.config.getString("VN",
						"0100"))){
			// Added By Abhishek Rana on 05-06-2017 for removing Date/Time Header.
			logger.info("[" + messageRequest.getCallingNum()
					+ "]  Voice Note Msg Header is enable without date/Time");
			sb.append(AppConfig.config.getString("ivr_common_path")
					+ File.separator + messageRequest.getLang()
					+ File.separator + "YOU_HAVE.wav");
			sb.append(",");
			sb.append(AppConfig.config.getString("ivr_common_path")
					+ File.separator + messageRequest.getLang()
					+ File.separator + "MESSAGE_FROM.wav");
			sb.append(",");
			sb.append(commonOperation.getMsisdnPath(
					this.messageAttribute.getSenderNum(),
					messageRequest.getLang()));
			sb.append(",");
		} 
		else {
			logger.info("[" + messageRequest.getCallingNum()
					+ "]  msg header is not enable ");
		}

		sb.append(this.messageAttribute.getMsgPath());
		logger.info("[" + this.callingNum + "] complete msg path ["
				+ sb.toString() + "]");
		messageResponse.setMsgPath(sb.toString());
		// messageResponse.setGreetingPath(this.messageAttribute.getGreetingMsg());
		messageResponse.setMsgIndex(this.messageAttribute.getVoiceMsgIndex());
		messageResponse.setSenderNum(this.messageAttribute.getSenderNum());
		messageResponse.setMsgDuration(this.messageAttribute
				.getRecordingDuration());

	}

}
