package com.vcc.domain;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.model.VccFwdCallLogs;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.model.VccVoiceMessage;
import com.vcc.request.VmRequest;
import com.vcc.response.VmResponse;

public class FsSaveHandler {
	final static Logger logger = Logger.getLogger(FsSaveHandler.class);

	private VccServices vccServices;
	private int status;
	private int sendVoiceMsgstatus;
	private Boolean sendNotiStatus = false;
	private VccVoiceMessage vmsMessage = null;
	VccCommonOperation commonOperation = null;
	private String recordFileName = null;
	private String recordFilePath = null;
	private String calledNum;
	private String recordTempPath = null;

	public void process(VmRequest vmRequest, VmResponse vmResponse,
			VccServices vccServices) {

		this.calledNum = vmRequest.getCalledNum();
		String tempName = null;
		Date date = new Date();
		String nanoSec = String.valueOf(System.nanoTime());
		nanoSec = (String) nanoSec.subSequence(nanoSec.length() - 6,
				nanoSec.length());
		this.recordFileName = getDateInFormat("yy").format(date)
				+ getDateInFormat("MM").format(date)
				+ getDateInFormat("dd").format(date)
				+ getDateInFormat("HH").format(date)
				+ getDateInFormat("mm").format(date)
				+ getDateInFormat("ss").format(date) + nanoSec;
		tempName = recordFileName.substring(0, recordFileName.length()
				- AppConfig.config.getInt("default_record_digits", 10));
		commonOperation = new VccCommonOperation();
		this.recordFilePath = commonOperation.getCopletePath(
				this.recordFileName.substring(0,
						this.recordFileName.length() - AppConfig.config.getInt("default_record_digits", 10)), this.calledNum,
				null,
				AppConfig.config.getString("ivr_record_path"));
			
		Boolean status = true;
		//status = commonOperation.createDirectory(recordFilePath);

		this.recordFilePath = commonOperation.getCopletePath(
				this.recordFileName.substring(0,
						this.recordFileName.length() - AppConfig.config.getInt("default_record_digits", 10)), this.calledNum,
				this.recordFileName,
				AppConfig.config.getString("ivr_record_path"));
	
		
		logger.info("callingNum [" + vmRequest.getCallingNum()
				+ "] and calledNUm [" + this.calledNum + "] filename ["
				+ this.recordFileName + "] filepath [" + this.recordFilePath
				+ "] tempPath ["+vmRequest.getRecordTempPath()+"] ");
		
		this.recordTempPath = vmRequest.getRecordTempPath();
		Boolean copyStatus=true;
		//Boolean copyStatus=commonOperation.copyRecordFile(this.recordTempPath, this.recordFilePath);
		if(AppConfig.config.getBoolean("delete.file",true))
			try{
				new File(this.recordTempPath).delete();
				}catch(Exception e){}
		/*File file = new File(this.recordTempPath);
		if ((vmRequest.getRecordTempPath() != null
				|| vmRequest.getRecordTempPath() != "") 
				&& file.exists()) {			
			try {				
				file.renameTo(new File(this.recordFilePath));
				this.saveVoiceMail(vmRequest, vmResponse, vccServices);
				this.saveSendNotification(vmRequest, vmResponse,
							vccServices);
			} catch (Exception e) {
				logger.error(
						"Exception while copying temp file to actual File.", e);
			}
		}else{
			logger.info("Record TempFile Path is not exist.."+this.recordTempPath);
		}*/
		if(copyStatus)
		{
			if(AppConfig.config.getBoolean("save.voice.mail",true))
				this.saveVoiceMail(vmRequest, vmResponse, vccServices);
			if(AppConfig.config.getBoolean("save.notification"))
				this.saveSendNotification(vmRequest, vmResponse,vccServices);	
		}else
		{
			logger.info("Record TempFile Path is not exist.."+this.recordTempPath);
		}
		
		
		this.saveCallFwdLog(vmRequest, vmResponse, vccServices);
	}

	private void saveCallFwdLog(VmRequest vmRequest, VmResponse vmResponse,
			VccServices vccServices) {
		VccFwdCallLogs fwdCallLogs = new VccFwdCallLogs();

		this.setFwdCallLogs(fwdCallLogs, vmRequest, vccServices);
		status = vccServices.userService.insertFwdCallLogs(fwdCallLogs);

	}

	private void saveSendNotification(VmRequest vmRequest,
			VmResponse vmResponse, VccServices vccServices) {
		int recordDuration = 0;
		this.commonOperation = new VccCommonOperation();
		VccVoiceMessage vccVoiceMessage = new VccVoiceMessage();
		VccUserCompleteDetails userCompleteDetails = new VccUserCompleteDetails();
		vccVoiceMessage.setOriginattingNumber(vmRequest.getCallingNum());
		vccVoiceMessage.setDesticationNumber(commonOperation
				.msisdnWithCountryCode(vmRequest.getCalledNum()));
		vccVoiceMessage.setCallTime(vmRequest.getCallTime());
		vccVoiceMessage.setFileName(vmRequest.getRecordFileName());
		vccVoiceMessage.setOriginattingNumber(commonOperation
				.msisdnWithCountryCode(vmRequest.getCalledNum()));
		if (vmRequest.getRecordingDuration() != 0) {
			vccVoiceMessage.setRecordingTime(vmRequest.getRecordingDuration());

		} else {
			Date curDate = new Date();
			recordDuration = new VmOperation().getRetSecond(
					vmRequest.getCallTime(), curDate);
			vmRequest.setRecordingDuration(recordDuration);
			vccVoiceMessage.setRecordingTime(recordDuration);
		}
		vccVoiceMessage.setServiceType(vmRequest.getServiceType());
		vccVoiceMessage.setVoiceMessageIndex(vmRequest.getVoiceMsgIndex());
		vccVoiceMessage.setLocalMessageIndex(vccServices.userService
				.getNextIndex(vmRequest.getCalledNum(),vmRequest.getServiceType()));
		vccVoiceMessage.setMsgPriority("H");
		vccVoiceMessage.setPassProtected("F");
		vccVoiceMessage.setPassword("0000");
		userCompleteDetails.setDeliveryInterface(1);
		userCompleteDetails.setClassType(1);
		userCompleteDetails.setSubType(vmRequest.getSubType());
		userCompleteDetails.setRatePlan(vmRequest.getRatePlan());
		userCompleteDetails.setLanguage(vmRequest.getLang());

		vccServices.userService.saveVccNotification(vccVoiceMessage,
				userCompleteDetails);
	}

	private void saveVoiceMail(VmRequest vmRequest, VmResponse vmResponse,
			VccServices vccServices) {

		int recordDuration = 0;
		this.vmsMessage = new VccVoiceMessage();
		this.commonOperation = new VccCommonOperation();
		this.vmsMessage.setMessageStatus("N");
		this.vmsMessage.setOriginattingNumber(commonOperation
				.msisdnWithCountryCode(vmRequest.getCallingNum()));
		this.vmsMessage.setDesticationNumber(commonOperation
				.msisdnWithCountryCode(vmRequest.getCalledNum()));
		this.vmsMessage.setFileName(vmRequest.getRecordFileName());
		this.vmsMessage.setCallTime(vmRequest.getCallTime());
		this.vmsMessage.setOrginalNumber(commonOperation
				.msisdnWithCountryCode(vmRequest.getCalledNum()));

		if (vmRequest.getRecordingDuration() != 0) {
			this.vmsMessage.setRecordingTime(vmRequest.getRecordingDuration());
		} else {
			Date curDate = new Date();
			recordDuration = new VmOperation().getRetSecond(
					vmRequest.getCallTime(), curDate);
			vmRequest.setRecordingDuration(recordDuration);
			this.vmsMessage.setRecordingTime(recordDuration);
		}
		this.vmsMessage.setServiceType(vmRequest.getServiceType());
		this.vmsMessage.setLocalMessageIndex(vccServices.userService
				.getNextIndex(vmRequest.getCalledNum(),vmRequest.getServiceType()));
		this.vmsMessage.setMsgPriority("H");
		this.vmsMessage.setMsgProtect("F");
		this.vmsMessage.setPassProtected("F");
		this.vmsMessage.setPassword("0000");

			this.sendVoiceMsgstatus = vccServices.userService
					.insertVoiceMessage(vmsMessage);


		logger.info(String
				.format("A-Party [%s] B-Party [%s] saved file in db [%s] save notification [%s]",
						vmRequest.getCallingNum(), vmRequest.getCalledNum(),
						this.sendVoiceMsgstatus, this.sendNotiStatus));
	}

	private void setFwdCallLogs(VccFwdCallLogs fwdCallLogs,
			VmRequest vmRequest, VccServices vccServices) {

		fwdCallLogs.setServerId(vmRequest.getServerId());
		fwdCallLogs.setCallId(vmRequest.getCallUUID());
		fwdCallLogs.setOriginatingNumber(vmRequest.getCallingNum());
		fwdCallLogs.setDestinationNumber(vmRequest.getCalledNum());
		fwdCallLogs.setCircuitId(vmRequest.getCircuitId());
		fwdCallLogs.setIamCauseCode(vmRequest.getReleaseCode());
		fwdCallLogs.setRelCauseCode(vmRequest.getHangupCause());
		if (vmRequest.getRecordingDuration() < 1 && vmRequest.getAnswerd() == 0) {
			fwdCallLogs.setMsgLength(0);
			fwdCallLogs.setFileName("NA");
		} else if (vmRequest.getRecordingDuration() < 1
				&& vmRequest.getAnswerd() == 1
				&& vmRequest.getCallDuration() > 1) {
			fwdCallLogs.setMsgLength(vmRequest.getCallDuration() - 7);
			fwdCallLogs.setFileName(vmRequest.getRecordFileName());
		} else {
			fwdCallLogs.setMsgLength(vmRequest.getRecordingDuration() / 1000);
			fwdCallLogs.setFileName(vmRequest.getRecordFileName());
		}
		int vccMsgIndex = vccServices.userService.getVoiceMsgIndex(vmRequest);
		fwdCallLogs.setVoiceMsgIndex(vccMsgIndex);
		fwdCallLogs.setCallTime(vmRequest.getCallTime());
		fwdCallLogs.setCallDuration(vmRequest.getCallDuration());
		fwdCallLogs.setAnswered(vmRequest.getAnswerd());
		fwdCallLogs.setServiceType(vmRequest.getServiceType());
		fwdCallLogs.setSubType(vmRequest.getSubType());
		fwdCallLogs.setRatePlan(vmRequest.getRatePlan());

	}

	private SimpleDateFormat getDateInFormat(String pattern) {

		SimpleDateFormat sdf = new SimpleDateFormat(pattern);

		return sdf;

	}

}
