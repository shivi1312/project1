package com.vcc.domain;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.cache.VccExpiryCache;
import com.vcc.chain.Profile;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.filter.Filter;
import com.vcc.model.MessageAttribute;
import com.vcc.model.MessageReader;
import com.vcc.model.VccAuthUser;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.model.VccVoiceMessage;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.ProfileResponse;

public class VccSendCopyMessage implements Profile, Filter {

	final static Logger logger = Logger.getLogger(VccSendCopyMessage.class);

	private MessageReader messageReader;
	private List<MessageAttribute> tmpList;
	private List<VccVoiceMessage> deleteList;
	private VccAuthUser authUser;
	private String fileName;
	private String msgFilePath;
	private String deleteFilePath;
	private String originalNum;
	private int recordingDuration;
	private String serviceType;
	private String recordFileName;
	private VccCommonOperation commonOperation = null;
	private String msgRetKey = null;

	public VccSendCopyMessage() {

	}
	/**
	 * return void 
	 * this method is responsible for send a copy of voice mail to other msisdn 
	 * @param profileRequest
	 *            the variable contain bean of vmRequest ,which set by
	 *            url request like - callingNum , calledNum
	 *            ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of vmResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	@Override
	public void execute(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {

		this.msgRetKey = "ret_" + profileRequest.getCallingNum();
		logger.info("[" + profileRequest.getCallingNum() + "] cache ["
				+ (VccExpiryCache.pxmlmap.containsKey(this.msgRetKey))
				+ "]   is sub[" + profileResponse.getIsSubscriber() + "]");
		if (VccExpiryCache.pxmlmap.containsKey(this.msgRetKey)
				&& (profileResponse.getIsSubscriber() == 1
						|| profileResponse.getIsCallAllowed() == 1 || profileResponse
						.getIsMailBoxFull() == 1)) {
			logger.debug("[" + profileRequest.getCallingNum()
					+ "] send a copy to [" + profileRequest.getCalledNumB()
					+ "] is mail delete ["
					+ profileResponse.getIsVoiceMailDeleted() + "]");
			this.messageReader = (MessageReader) VccExpiryCache.pxmlmap
					.get(this.msgRetKey);
			this.getMessageAttribute(profileRequest);
			logger.debug("[" + profileRequest.getCallingNum()
					+ "] send a copy to [" + profileRequest.getCalledNumB()
					+ "] is mail delete ["
					+ profileResponse.getIsVoiceMailDeleted() + "]");
			if (profileResponse.getIsVoiceMailDeleted() == 1) {
				// delete old mail logic write here
				logger.debug("[" + profileRequest.getCallingNum()
						+ "] going to delete old msg of ["
						+ profileRequest.getCalledNumB() + "] ");
				this.deleteOldVoiceMail(vccServices, profileRequest,
						profileResponse);

				if (profileResponse.getIsSuccess() == 1) {
					logger.debug("old mail deleted and send copy ");
					this.sendCopyOperation(profileRequest, profileResponse,
							vccServices);
				}
			} else {
				// insert new entry in db
				logger.debug("new mail using send and copy");
				this.sendCopyOperation(profileRequest, profileResponse,
						vccServices);

			}

		} else {
			profileResponse.setIsSuccess(0);

			logger.info("[" + profileRequest.getCalledNum()
					+ "] msg info in Cahce ["
					+ (VccExpiryCache.pxmlmap.containsKey(this.msgRetKey))
					+ "] and calledNumB [" + profileRequest.getCalledNumB()
					+ "] is subscriber [" + profileResponse.getIsSubscriber()
					+ "]");

		}
	}
	/**
	 * return void 
	 * this method is responsible for delete voice mail from mail box of callingNum 
	 * @param profileRequest
	 *            the variable contain bean of vmRequest ,which set by
	 *            url request like - callingNum , calledNum
	 *            
	 * @param profileResponse
	 *            the variable contain bean of vmResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	private void deleteOldVoiceMail(VccServices vccServices,
			ProfileRequest profileRequest, ProfileResponse profileResponse) {
		VmRequest request = new VmRequest();
		request.setCalledNum(profileRequest.getCalledNumB());
		request.setCatName("R");
		this.deleteList = vccServices.userService
				.getMailboxOrderBySendTime(request);

		if (this.deleteList.size() > 0) {
			this.recordFileName = this.deleteList.get(0).getFileName();
			String tempName = recordFileName.substring(0,
					recordFileName.length() - AppConfig.config.getInt("default_record_digits", 10));
			this.deleteFilePath = this.commonOperation.getCopletePath(tempName,
					profileRequest.getCalledNumB(), this.recordFileName,
					AppConfig.config.getString("ivr_record_path"));

			this.commonOperation.deletePhysicalFile(null, null,
					this.deleteFilePath,
					AppConfig.config.getString("ivr_record_path"));
			vccServices.userService.deleteVccVoiceMessage(profileRequest
					.getCalledNumB(), this.deleteList.get(0)
					.getVoiceMessageIndex());
		} else {
			profileResponse.setIsSuccess(0);
			logger.info("NO mesaage Found in ["
					+ profileRequest.getCalledNumB() + "] mail box");
		}
		request = null;
	}
	/**
	 * return void 
	 * this method is responsible for send a copy of voice mail to other msisdn 
	 * @param profileRequest
	 *            the variable contain bean of vmRequest ,which set by
	 *            url request like - callingNum , calledNum
	 *            ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of vmResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	private void sendCopyOperation(ProfileRequest profileRequest,
			ProfileResponse profileResponse, VccServices vccServices) {
		int status=0;
		StringBuilder sb = new StringBuilder();
		sb.append(profileResponse.getRecordFilePath());
		sb.append(File.separator);
		sb.append(profileResponse.getRecordFileName());
		sb.append(".wav");

		commonOperation = new VccCommonOperation();
		Boolean isCopyFile=commonOperation.copyRecordFile(this.msgFilePath, sb.toString());
		// insert into db
		VccVoiceMessage request = new VccVoiceMessage();
		request.setOriginattingNumber(commonOperation
				.msisdnWithCountryCode(profileRequest.getCallingNum()));
		request.setDesticationNumber(commonOperation
				.msisdnWithCountryCode(profileRequest.getCalledNumB()));
		request.setFileName(profileResponse.getRecordFileName());
		request.setRecordingTime(this.recordingDuration);
		request.setMessageStatus("N");
		request.setOrginalNumber(commonOperation
				.msisdnWithCountryCode(profileRequest.getCalledNumB()));
		request.setServiceType(profileRequest.getServiceType());
		request.setLocalMessageIndex(vccServices.userService.getNextIndex(profileRequest.getCalledNumB(),profileRequest.getServiceType()));
		request.setCallTime(profileRequest.getCallTime());
		request.setMsgPriority("H");
		request.setMsgProtect("N");
		request.setPassProtected("N");
		request.setPassword("0000");
		
		if(isCopyFile)
		status = vccServices.messageService.insertVoiceMessage(request); // save
																				// msg
																				// in
																				// mail
																				// box
																				// of
																				// calledNumB

		if (isCopyFile && status > 0) {
			VccUserCompleteDetails userCompleteDetails = this.getCompleteAuthDetail(vccServices.userService
					.getUserCompleteDetail(request.getOrginalNumber())); // save
																		// msg
																		// notification
																		// in db

			//get voice_msg_index
			VmRequest vmRequest = new VmRequest();
			vmRequest.setRecordFileName(request.getFileName());
			request.setVoiceMessageIndex(vccServices.userService
					.getVoiceMsgIndex(vmRequest));
			
			if (userCompleteDetails != null && !userCompleteDetails.getSubType().equalsIgnoreCase("F")) {
				int result =vccServices.userService.saveVccNotification(request,
						userCompleteDetails);
				logger.info("["+profileRequest.getCallingNum()+"] send notification to ["+userCompleteDetails.getMsisdn()+"] status is ["+result+"] voice msg index ["+request.getVoiceMessageIndex()+"] subType ["+userCompleteDetails.getSubType()+"] ");
			}else
			{
				logger.info("["+profileRequest.getCallingNum()+"] send notification to ["+userCompleteDetails.getMsisdn()+"] status is fail due to subType ["+userCompleteDetails.getSubType()+"]  voice msg index ["+request.getVoiceMessageIndex()+"]");
			}
			
			profileResponse.setIsSuccess(1);
			vmRequest=null;
			logger.info("Send and copy file path is [" + sb.toString()
					+ "] and send to mail Box of ["
					+ profileRequest.getCalledNumB() + "] send a copy status ["
					+ status + "]");

		} else {
			profileResponse.setIsSuccess(0);

			logger.info("Send and copy file path is [" + sb.toString()
					+ "] and send to mail Box of ["
					+ profileRequest.getCalledNumB() + "] send a copy status ["
					+ status + "] copy record File ["+isCopyFile+"]");

		}
	}
	/**
	 * return void 
	 * this method is responsible for getting message details from cache 
	 * @param profileRequest
	 *            the variable contain bean of vmRequest ,which set by
	 *            url request like - callingNum , calledNum
	 *            ,catName etc and set message attribute in local class variable 
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void getMessageAttribute(ProfileRequest profileRequest) {

		if (profileRequest.getCatName().equalsIgnoreCase("N")) {
			this.tmpList = this.messageReader.newmsg;

		} else if (profileRequest.getCatName().equalsIgnoreCase("R")) {
			this.tmpList = this.messageReader.oldmsg;

		} else if (profileRequest.getCatName().equalsIgnoreCase("S")) {
			this.tmpList = this.messageReader.savemsg;

		}
		if(this.tmpList.size()>0)
		{
		for (MessageAttribute msAttribute : this.tmpList) {

			if (msAttribute.getVoiceMsgIndex() == profileRequest
					.getVoiceMsgIndex()) {
				this.fileName = msAttribute.getFileName();
				this.msgFilePath = msAttribute.getMsgPath();
				this.originalNum = msAttribute.getOriginalNum();
				this.recordingDuration = msAttribute.getRecordingDuration();
				this.serviceType = msAttribute.getServiceType();

			}

		}
		}else{
			logger.info("["+profileRequest.getCallingNum()+"] no msg found in list for cat ["+profileRequest.getCatName()+"]");
		}

	}
	public VccUserCompleteDetails getCompleteAuthDetail(List<VccUserCompleteDetails> master){
		VccUserCompleteDetails vccSub = null;
		try {
			if(master != null){
				for(VccUserCompleteDetails vccMaster: master){
					return vccMaster;
				}
			}
		}catch(Exception e){
			logger.error("Error while convert master to auth user: "+e.getMessage());
		}
		return vccSub;
	}
}
