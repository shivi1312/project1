package com.vcc.domain;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;

import com.vcc.chain.Profile;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.filter.Filter;
import com.vcc.model.VccAuthUser;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;

public class VccProfileDetails implements Profile, Filter {

	final static Logger logger = Logger.getLogger(VccProfileDetails.class);
	@Autowired
	private VccServices vccServices;

	private VccAuthUser authUser;

	public VccProfileDetails() {

	}
	/**
	 * return void 
	 * the method check the Profile of particular msisdn  
	 * @param profileRequest the variable contain bean of ProfileRequest ,which set by url request like - callingNum , calledNum ,serviceType etc  
	 * @param profileResponse the variable contain bean of  profileResponse , which actually return in url response like - isSuccess , isCallAllowed, isSubscriber 
	 * @param vmError vmError is a bean that is used to define which type of error generate in operation
	 * @param vccServices vccServices is a bean that contain reference of interface(UserService,MessageService,UserConfigService) 
	 * @return void     
	 * @see    nothing
	 */
	@Override
	public void execute(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VmError vmError, VccServices vccServices) {

		if (profileRequest.getCalledNumB() != null
				&& profileRequest.getCalledNumB() != ""
				&& profileRequest.getServiceType() != null
				&& profileRequest.getServiceType() != "") {

			profileRequest.setCalledNum(profileRequest.getCalledNumB());
			this.authUser = vccServices.userService
					.getProfileDetailByCalledNum(profileRequest);

			Boolean isSub = vccServices.userService.isUserSubscribe(
					profileRequest.getCalledNumB(),
					profileRequest.getServiceType());
			
				
			if (isSub && this.authUser != null) {
				VccUserCompleteDetails userCompleteDetails = this.getCompleteAuthDetail(vccServices.userService.getUserCompleteDetail(profileRequest.getCalledNumB()));
				profileResponse.setIsSubscriber(1);
				profileResponse.setIsCallAllowed(1);
				profileResponse.setSubType(this.authUser.getSubType());
				profileResponse.setRatePlan(userCompleteDetails.getRatePlan());
				logger.info("check.profile.with.send.a.copy request >> ["+profileRequest.getCalledNumB()+"] is  a subscriber ");
			} else {
				logger.info("check.profile.with.send.a.copy request >> ["+profileRequest.getCalledNumB()+"] is not a subscriber ");
				profileResponse.setIsSubscriber(0);
				profileResponse.setIsCallAllowed(0);
				profileResponse.setSubType(AppConfig.config.getString("default_sub_type", "N"));
			}
		} else {
			vmError.setError(true);
			vmError.setMsg("check.profile.with.send.a.copy request >> CalledNumB and Service Type are null");
		}
		if (!vmError.getError()) {

		} else {
			logger.error("the error reason is [%s]" + vmError.getMsg());
			vmError.setError(false);
		}

	}
	public VccUserCompleteDetails getCompleteAuthDetail(List<VccUserCompleteDetails> master){
		VccUserCompleteDetails vccSub = null;
		try {
			if(master != null){
				for(VccUserCompleteDetails vccMaster: master){
					return vccMaster;
				}
			}
		}catch(Exception e){
			logger.error("Error while convert master to auth user: "+e.getMessage());
		}
		return vccSub;
	}
}
