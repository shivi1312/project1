package com.vcc.domain;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.google.gson.Gson;
import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.handler.ProfileHandler;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.response.VmResponse;

public class VoiceNoteFilter {
	final static Logger logger = Logger.getLogger(VoiceNoteFilter.class);
	private Gson gson = new Gson();

	public ProfileResponse process(VmRequest vmRequest, VmResponse vmResponse,
			VmError vmError, VccServices vccServices) {
		ProfileHandler profileHandler = new ProfileHandler();
		ProfileResponse profileResponse = new ProfileResponse();
		ProfileRequest profileRequest = new ProfileRequest();
		try {
			logger.debug("calling ["+vmRequest.getCallingNum()+"] called ["+vmRequest.
					getCalledNum()+"] call-uuid ["+vmRequest.getCallUUID()+
					"] server ["+vmRequest.getServerId()+"] profile check during hangup !!..");
			profileRequest.setCallingNum(vmRequest.getCallingNum());
			profileRequest.setCalledNum(vmRequest.getCalledNum());
			profileRequest.setReleaseCode(vmRequest.getReleaseCode());
			profileRequest.setServiceType(vmRequest.getSubType());

			BindingResult bindingResult = null;
			profileHandler.profileCheck(profileRequest, bindingResult,
					profileResponse, vccServices);
			vmRequest.setActiveServiceList(profileRequest.getActiveServiceList());
			logger.debug(gson.toJson(profileResponse));
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("called [" + profileRequest.getCalledNum()
					+ "] calling [" + profileRequest.getCallingNum()
					+ "] Error while maintain profile: " + e.getMessage());
		}
		return profileResponse;
	}
}
