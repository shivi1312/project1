package com.vcc.domain;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.telemune.vcc.expiringmap.ExpiringMap;
import com.vcc.cache.VccExpiryCache;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.model.GroupDetail;
import com.vcc.request.UserConfigRequest;
import com.vcc.response.UserConfigResponse;

public class GroupOperation {

	final static Logger logger = Logger.getLogger(GroupOperation.class);
	private GroupDetail groupDetail = null;
	private ExpiringMap<String, Object> frndDetailMap = null;
	private VccCommonOperation commonOperation = null;
	private String groupPath = null;
	private String groupName = null;
	private String frndKey = null;
	private List<String> frndList = null;
	private String pointer;
	private String avaliable;
	private int nextIndex;
	private int prevIndex;
	private int groupId;
	private int sizeOfGroup;

	/**
	 * return void the method is responsible for find group and if found in
	 * group in database return Status using userConfigResponse
	 * 
	 * @param userConfigRequest
	 *            the variable contain bean of UserConfigRequest ,which set by
	 *            url request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param userConfigResponse
	 *            the variable contain bean of UserConfigResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void findGroup(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse,
			VccServices vccServices) {

		int status = vccServices.userConfigService
				.checkGroupIdExists(userConfigRequest);
		this.frndKey = "list_" + userConfigRequest.getCallingNum()+"_"+userConfigRequest.getGroupId();
		commonOperation = new VccCommonOperation();

		this.frndDetailMap = VccExpiryCache.pxmlmap;
		userConfigResponse.setIsSuccess(status);
		if (this.frndDetailMap.containsKey(this.frndKey) && status > 0) {
			this.groupName = vccServices.userConfigService
					.getGroupName(userConfigRequest);

			this.frndDetailMap = VccExpiryCache.pxmlmap;
		/*	this.frndKey = userConfigRequest.getCallingNum()
					+ userConfigRequest.getGroupId();
		*/	this.groupDetail = (GroupDetail) this.frndDetailMap.get(this.frndKey);
			this.performGroupOperation(userConfigRequest, userConfigResponse,
					vccServices);
			logger.info("[" + userConfigRequest.getCallingNum()
					+ "]  group id [" + userConfigRequest.getGroupId()
					+ "] is exists ");
			userConfigResponse.setInputCount(userConfigRequest.getInputCount()+1);
		} else if (status > 0) {
			logger.info("[" + userConfigRequest.getCallingNum()
					+ "]  group id [" + userConfigRequest.getGroupId()
					+ "] is  exists ");
			this.groupDetail = new GroupDetail();
			this.frndDetailMap.put(this.frndKey, this.groupDetail, 5,
					TimeUnit.MINUTES);

			this.groupDetail.setGroupId(userConfigRequest.getGroupId());
			this.groupDetail.setCallingNum(userConfigRequest.getCallingNum());
			this.groupDetail.setServiceType(userConfigRequest.getServiceType());
			this.groupDetail.setFrndList(vccServices.userConfigService
					.getMsisdnList(groupDetail));

			this.groupName = vccServices.userConfigService
					.getGroupName(userConfigRequest);
			this.groupDetail.setFileName(this.groupName);

			this.performGroupOperation(userConfigRequest, userConfigResponse,
					vccServices);
			userConfigResponse.setInputCount(userConfigRequest.getInputCount()+1);
		} else {
			logger.info("[" + userConfigRequest.getCallingNum()
					+ "]  group id [" + userConfigRequest.getGroupId()
					+ "] is not exists ");
			userConfigResponse.setInputCount(userConfigRequest.getInputCount()+1);
			userConfigResponse.setIsSuccess(0);
			}

	}

	/**
	 * return void the method is responsible for delete group from database
	 * return delete Status using userConfigResponse
	 * 
	 * @param userConfigRequest
	 *            the variable contain bean of UserConfigRequest ,which set by
	 *            url request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param userConfigResponse
	 *            the variable contain bean of UserConfigResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void deleteGroup(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse,
			VccServices vccServices) {

		commonOperation = new VccCommonOperation();

		this.frndDetailMap = VccExpiryCache.pxmlmap;

		this.frndKey = "list_" + userConfigRequest.getCallingNum()+"_"+userConfigRequest.getGroupId();
		if (this.frndDetailMap.containsKey(this.frndKey)) {

			this.groupDetail = (GroupDetail) this.frndDetailMap
					.get(this.frndKey);
			logger.info("group message details calling Num["
					+ this.groupDetail.getCallingNum() + "] file name ["
					+ this.groupDetail.getFileName() + "]");
			if (this.groupDetail.getCallingNum().equalsIgnoreCase(
					userConfigRequest.getCallingNum())
					&& this.groupDetail.getGroupId() == userConfigRequest
							.getGroupId()) {
				this.groupName = this.groupDetail.getFileName();
				if (vccServices.userConfigService.deleteGroup(groupDetail)
						&& vccServices.userConfigService
								.deleteGroupDetails(groupDetail)) {
					logger.info("[" + userConfigRequest.getCallingNum()
							+ "] group id [" + userConfigRequest.getGroupId()
							+ "] is now deleted ");

					commonOperation.deletePhysicalFile(this.groupName,
							userConfigRequest.getCallingNum(), null,
							AppConfig.config.getString("ivr_group_path"));
				}
				this.frndDetailMap.remove(this.frndKey); // remove
															// group
															// details
															// from
															// cache
				userConfigResponse.setIsSuccess(1);
			}

		} else {
			userConfigResponse.setIsSuccess(0);
			logger.warn("group not delete because callingNum["
					+ userConfigRequest.getCallingNum() + "] and groupId["
					+ userConfigRequest.getGroupId() + "] is not in cache");
		}

	}

	/**
	 * return void the method is responsible for update group name in database
	 * and return Status using userConfigResponse
	 * 
	 * @param userConfigRequest
	 *            the variable contain bean of UserConfigRequest ,which set by
	 *            url request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param userConfigResponse
	 *            the variable contain bean of UserConfigResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void updateGroupName(UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, VccServices vccServices) {

		commonOperation = new VccCommonOperation();

		this.frndDetailMap = VccExpiryCache.pxmlmap;

		this.frndKey = "list_" + userConfigRequest.getCallingNum()+"_"+userConfigRequest.getGroupId();
		if (this.frndDetailMap.containsKey(this.frndKey)) {

			this.groupDetail = (GroupDetail) this.frndDetailMap
					.get(this.frndKey);
			logger.info("group message details calling Num["
					+ this.groupDetail.getCallingNum() + "] file name ["
					+ this.groupDetail.getFileName() + "]");
			if (this.groupDetail.getCallingNum().equalsIgnoreCase(
					userConfigRequest.getCallingNum())
					&& this.groupDetail.getGroupId() == userConfigRequest
							.getGroupId()) {
				this.groupName = this.groupDetail.getFileName();
				// delete old file
				commonOperation.deletePhysicalFile(this.groupName,
						userConfigRequest.getCallingNum(), null,
						AppConfig.config.getString("ivr_group_path"));

				// now update the group name by recordFileName
				this.groupName = userConfigRequest.getRecordFileName();
				String tempPath = this.groupName.substring(0,
						this.groupName.length() - AppConfig.config.getInt("default_record_digits", 10));
				this.groupPath = commonOperation.getCopletePath(tempPath,
						userConfigRequest.getCallingNum(), this.groupName,
						AppConfig.config.getString("ivr_group_path"));
				if (commonOperation.checkFileExists(this.groupPath)) {
					groupDetail.setFileName(this.groupName);
					if (vccServices.userConfigService
							.updateGroupName(groupDetail)) {
						this.frndDetailMap.remove(this.frndKey); // remove group
																	// details
																	// from
																	// cache
						logger.info("[" + userConfigRequest.getCallingNum()
								+ "]  group id ["
								+ userConfigRequest.getGroupId()
								+ "] and group name modified successfully ");
						userConfigResponse.setIsSuccess(1);
					} else {
						userConfigResponse.setIsSuccess(-1);
						logger.warn("["
								+ userConfigRequest.getRecordFileName()
								+ "] not save in db");
					}
				} else {
					userConfigResponse.setIsSuccess(-1);
					logger.warn("calligNum ["
							+ userConfigRequest.getCallingNum()
							+ "] there is no file name with ["
							+ userConfigRequest.getRecordFileName() + "]");
				}

			}

		} else {
			userConfigResponse.setIsSuccess(0);
			logger.warn("group not delete because callingNum["
					+ userConfigRequest.getCallingNum() + "] and groupId["
					+ userConfigRequest.getGroupId() + "] is not in cache");
		}

	}

	/**
	 * return void the method is responsible for add msisdn in group and return
	 * Status using userConfigResponse
	 * 
	 * @param userConfigRequest
	 *            the variable contain bean of UserConfigRequest ,which set by
	 *            url request like - callingNum , calledNum
	 *            ,serviceType,callDuration,callTime etc
	 * @param userConfigResponse
	 *            the variable contain bean of UserConfigResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void addFrnd(UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, VccServices vccServices) {

		this.frndDetailMap = VccExpiryCache.pxmlmap;
		this.sizeOfGroup = AppConfig.config.getInt("VM_GROUP_SIZE", 10);
		this.frndKey = "list_" + userConfigRequest.getCallingNum()+"_"+userConfigRequest.getGroupId();
		if (userConfigRequest.getType().equalsIgnoreCase("create")
				&& this.frndDetailMap.containsKey(this.frndKey)
				&& this.sizeOfGroup != userConfigRequest.getFrndCount()) {
			logger.info("[" + userConfigRequest.getCallingNum()
					+ "] Create Group First Time and group Id is ["
					+ userConfigRequest.getGroupId() + "]");
			this.groupDetail = (GroupDetail) this.frndDetailMap
					.get(this.frndKey);
			logger.info("frnd list is ["
					+ this.groupDetail.getFrndList().size() + "]");
			if (!this.groupDetail.getFrndList().contains(
					userConfigRequest.getFrndMsisdn())) {
				this.groupDetail.getFrndList().add(
						userConfigRequest.getFrndMsisdn());
				userConfigResponse.setFrndCnt(this.groupDetail.getFrndList()
						.size());
			}
			userConfigResponse.setIsSuccess(1);
		} else if (userConfigRequest.getType().equalsIgnoreCase("create")
				&& this.sizeOfGroup != userConfigRequest.getFrndCount()) {
			logger.info("[" + userConfigRequest.getCallingNum()
					+ "] Create Group First Time and group Id is ["
					+ userConfigRequest.getGroupId() + "]");
			this.frndList = new ArrayList<String>();
			this.frndList.add(userConfigRequest.getFrndMsisdn());
			this.groupDetail = new GroupDetail();
			this.groupDetail.setCallingNum(userConfigRequest.getCallingNum());
			this.groupDetail.setFileName(userConfigRequest.getRecordFileName());
			this.groupDetail.setGroupId(userConfigRequest.getGroupId());
			this.groupDetail.setFrndList(this.frndList);
			this.frndDetailMap.put(this.frndKey, this.groupDetail, 5,
					TimeUnit.MINUTES);
			userConfigResponse.setIsSuccess(1);
			userConfigResponse.setFrndCnt(this.frndList.size());
		} else if (userConfigRequest.getType().equalsIgnoreCase("modify")
				&& this.frndDetailMap.containsKey(this.frndKey)
				&& this.sizeOfGroup > userConfigRequest.getFrndCount()) {
			
			logger.info("[" + userConfigRequest.getCallingNum()
					+ "] Modify Group  and group Id is ["
					+ userConfigRequest.getGroupId() + "]");
			this.groupDetail = (GroupDetail) this.frndDetailMap
					.get(this.frndKey);
			if(this.groupDetail.getFrndList().size()<this.sizeOfGroup)
			{
			
			if (userConfigRequest.getFrndCount() == 0) {
				userConfigRequest.setFrndCount(this.groupDetail.getFrndList()
						.size());
				this.groupDetail.getFrndList().clear();
			}
			
			if (!this.groupDetail.getFrndList().contains(
					userConfigRequest.getFrndMsisdn())) {
				this.groupDetail.getFrndList().add(
						userConfigRequest.getFrndMsisdn());
				userConfigResponse
						.setFrndCnt(userConfigRequest.getFrndCount() + 1);
			}
			userConfigResponse.setIsSuccess(1);
			}else
			{
				if (userConfigRequest.getFrndCount() == 0) {
					userConfigRequest.setFrndCount(this.groupDetail.getFrndList()
							.size());
					this.groupDetail.getFrndList().clear();
				}
				userConfigResponse.setIsSuccess(2);
				userConfigResponse
				.setFrndCnt(this.groupDetail.getFrndList().size());
			}
		}else
		{
			userConfigResponse.setIsSuccess(2);
			userConfigResponse
			.setFrndCnt(userConfigRequest.getFrndCount() + 1);

		}
	}

	/**
	 * return void the method is responsible for group operation like -
	 * generating file path of Group name and return response using
	 * userConfigResponse
	 * 
	 * @param userConfigRequest
	 *            the variable contain bean of UserConfigRequest ,which set by
	 *            url request like - fileName
	 * @param userConfigResponse
	 *            the variable contain bean of UserConfigResponse , which
	 *            actually return in url response like - isSuccess(0,1),groupid
	 *            ,groupPath
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	private void performGroupOperation(UserConfigRequest userConfigRequest,
			UserConfigResponse userConfigResponse, VccServices vccServices) {
		StringBuilder sb = new StringBuilder();
		this.groupName = this.groupDetail.getFileName();
		String tempName = this.groupName.substring(0,
				this.groupName.length() - AppConfig.config.getInt("default_record_digits", 10));

		
		this.groupPath = commonOperation.getCopletePath(tempName,
				userConfigRequest.getCallingNum(), this.groupName,
				AppConfig.config.getString("ivr_group_path"));

		sb.append(AppConfig.config.getString("ivr_common_path"));
		sb.append(File.separator);
		sb.append(userConfigRequest.getLang());
		sb.append(File.separator);
		sb.append("VMRT_YOUR_LIST_NAME.wav");
		sb.append(",");
		sb.append(this.groupPath);
		
		userConfigResponse.setgroupPath(sb.toString());
		userConfigResponse.setGroupId(this.groupDetail.getGroupId());
		userConfigResponse.setIsSuccess(1);

	}

	/**
	 * return void the method is responsible for giving group details and return
	 * response using userConfigResponse
	 * 
	 * @param userConfigRequest
	 *            the variable contain bean of UserConfigRequest ,which set by
	 *            url request like - fileName
	 * @param userConfigResponse
	 *            the variable contain bean of UserConfigResponse , which
	 *            actually return in url response like - isSuccess(0,1),groupid
	 *            ,groupPath,nxtIndex,prvIndex etc
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void getMsisdnFilePath(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse,
			VccServices vccServices) {

		this.avaliable = userConfigRequest.getAvailable();
		this.pointer = userConfigRequest.getPointer();
		this.nextIndex = userConfigRequest.getNxtIndex();
		this.prevIndex = userConfigRequest.getPrvIndex();
		this.groupId = userConfigRequest.getGroupId();

		if (this.avaliable != null && this.pointer != null) {
			commonOperation = new VccCommonOperation();
			this.frndKey = "list_" + userConfigRequest.getCallingNum()+"_"+userConfigRequest.getGroupId();
			this.frndDetailMap = VccExpiryCache.pxmlmap;

			if (this.frndDetailMap.containsKey(this.frndKey)) {
				this.groupName = vccServices.userConfigService
						.getGroupName(userConfigRequest);

				this.groupDetail = (GroupDetail) this.frndDetailMap
						.get(this.frndKey);

				this.frndList = this.groupDetail.getFrndList();
				logger.info("frnd list size [" + this.frndList.size() + "]");
				if (this.frndList.size() > 0
						&& this.pointer.equalsIgnoreCase("S")) {
					userConfigResponse.setMsisdnFilePath(commonOperation
							.getMsisdnPath(this.frndList.get(this.nextIndex),
									userConfigRequest.getLang()));
					userConfigResponse.setFrndMsisdn(this.frndList
							.get(this.nextIndex));
					userConfigResponse.setIsSuccess(1);
					userConfigResponse
							.setGroupId(this.groupDetail.getGroupId());
					userConfigResponse.setNxtIndex(this.nextIndex + 1);
					userConfigResponse.setPrvIndex(this.nextIndex);
					if (this.frndList.size() == 1) {
						userConfigResponse.setAvailable("S");// S for single
					}else if (this.prevIndex - 1 == -1){
						userConfigResponse.setAvailable("F"); // F for First
					}else if (this.frndList.size() == this.nextIndex + 1) {
						userConfigResponse.setAvailable("L"); // L for Last
					} else if (this.nextIndex + 1 >= 0
							&& this.nextIndex + 1 < this.frndList.size()) {
						userConfigResponse.setAvailable("P"); // P for Process
					}

				} else if (this.frndList.size() > 0
						&& this.pointer.equalsIgnoreCase("N")) {
					userConfigResponse.setMsisdnFilePath(commonOperation
							.getMsisdnPath(this.frndList.get(this.nextIndex),
									userConfigRequest.getLang()));
					userConfigResponse.setFrndMsisdn(this.frndList
							.get(this.nextIndex));
					userConfigResponse.setIsSuccess(1);
					userConfigResponse
							.setGroupId(this.groupDetail.getGroupId());
					userConfigResponse.setNxtIndex(this.nextIndex + 1);
					userConfigResponse.setPrvIndex(this.nextIndex);
					if (this.nextIndex + 1 > 1
							&& this.nextIndex + 1 < this.frndList.size()) {
						userConfigResponse.setAvailable("P"); // P for process
					} else if (this.frndList.size() == this.nextIndex + 1) {
						userConfigResponse.setAvailable("L"); // L for First
					}
					userConfigResponse.setFrndCnt(this.frndList.size());

				} else if (this.frndList.size() > 0
						&& this.pointer.equalsIgnoreCase("P")) {
					userConfigResponse.setMsisdnFilePath(commonOperation
							.getMsisdnPath(this.frndList.get(this.prevIndex - 1),
									userConfigRequest.getLang()));
					userConfigResponse.setFrndMsisdn(this.frndList
							.get(this.prevIndex - 1));
					userConfigResponse.setIsSuccess(1);
					userConfigResponse
							.setGroupId(this.groupDetail.getGroupId());
					userConfigResponse.setNxtIndex(this.prevIndex);
					userConfigResponse.setPrvIndex(this.prevIndex - 1);
					
					if (this.prevIndex - 1  == 0) {
						userConfigResponse.setAvailable("F"); // F for First
					} else if (this.frndList.size() > 1
							&& this.prevIndex - 1 < this.frndList.size()) {
						userConfigResponse.setAvailable("P"); // P for process
					}
					userConfigResponse.setFrndCnt(this.frndList.size());
				} else {
					userConfigResponse.setIsSuccess(0);
					logger.info("[" + userConfigRequest.getCallingNum()
							+ "] group list is empty");
				}
			} else {
				userConfigResponse.setIsSuccess(0);
				logger.info("[" + userConfigRequest.getCallingNum()
						+ "] group details not exist in cache");
			}

		}
	}

	/**
	 * return void the method is responsible for deleting particular msisdn from
	 * group and return delete status using userConfigResponse
	 * 
	 * @param userConfigRequest
	 *            the variable contain bean of UserConfigRequest ,which set by
	 *            url request like - fileName
	 * @param userConfigResponse
	 *            the variable contain bean of UserConfigResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void deleteMsisdnFromGroup(UserConfigRequest userConfigRequest,
			BindingResult bindingResult, UserConfigResponse userConfigResponse,
			VccServices vccServices) {

		this.frndKey = "list_" + userConfigRequest.getCallingNum()+"_"+userConfigRequest.getGroupId();
		this.frndDetailMap = VccExpiryCache.pxmlmap;
		Boolean status = false;
		if (this.frndDetailMap.containsKey(this.frndKey)) {
			this.commonOperation = new VccCommonOperation();
			this.groupDetail = (GroupDetail) this.frndDetailMap
					.get(this.frndKey);

			this.frndList = this.groupDetail.getFrndList();
			
			this.frndList.remove(this.commonOperation
					.msisdnWithCountryCode(userConfigRequest.getFrndMsisdn()));
			
			if(this.frndList.contains(this.commonOperation
					.msisdnWithCountryCode(userConfigRequest.getFrndMsisdn())))
			{
				this.frndList.remove(this.commonOperation
						.msisdnWithCountryCode(userConfigRequest.getFrndMsisdn()));
				
			}
			
			status = vccServices.userConfigService.deleteMsisdnFromGroup(
					userConfigRequest.getCallingNum(),
					userConfigRequest.getGroupId(),
					userConfigRequest.getFrndMsisdn());

			userConfigResponse.setIsSuccess(1);
			/*if(userConfigRequest.getPrvIndex() == 0){
				userConfigResponse.setNxtIndex(userConfigRequest.getNxtIndex() - 1);
				userConfigResponse.setPrvIndex(userConfigRequest.getPrvIndex());
				userConfigResponse.setAvailable("F");
			}
			else*/ if (userConfigRequest.getNxtIndex() == 1
					&& this.frndList.size() > 1) {
				userConfigResponse
						.setNxtIndex(userConfigRequest.getNxtIndex() - 1);
				userConfigResponse
				.setPrvIndex(userConfigRequest.getPrvIndex());
				userConfigResponse.setAvailable("F");
			}else if (userConfigRequest.getNxtIndex() > 1
					&& this.frndList.size() > 1) {
				userConfigResponse
						.setNxtIndex(userConfigRequest.getNxtIndex() - 1);
				userConfigResponse
				.setPrvIndex(userConfigRequest.getPrvIndex() - 1);
				userConfigResponse.setAvailable("P");
			}
			
			else if (this.frndList.size() < 1) {
				userConfigResponse
						.setNxtIndex(0);
				userConfigResponse
						.setPrvIndex(0);
				userConfigResponse.setAvailable("L");
			} else if (this.frndList.size() == 1) {

				userConfigResponse
						.setNxtIndex(userConfigRequest.getNxtIndex() - 1);
				userConfigResponse
						.setPrvIndex(userConfigRequest.getPrvIndex() - 1);
				userConfigResponse.setAvailable("S");
			} else {
				userConfigResponse
						.setNxtIndex(userConfigRequest.getNxtIndex() - 1);
				userConfigResponse.setPrvIndex(userConfigRequest.getPrvIndex());
				userConfigResponse.setAvailable("L");
			}

		} else {
			userConfigResponse.setIsSuccess(0);
			logger.warn("[" + userConfigRequest.getCallingNum()
					+ "] group details not exist in cache");
		}
		logger.info("[" + userConfigRequest.getCallingNum()
				+ "] delete msisdn [" + userConfigRequest.getFrndMsisdn()
				+ "]group [" + userConfigRequest.getGroupId()
				+ "] details status [" + status + "]");
	}

}
