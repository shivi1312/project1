package com.vcc.model;

public class VccMailboxParams implements java.io.Serializable {

	private static final long serialVersionUID = -4965856314783003221L;
	private int mailboxId;
	private String mailboxType;
	private int maxMessage;
	private int msgLifeTime;
	private int msgLifeTimeAfterRet;
	private int msgLifeTimeAfterSave;
	private int maxRecordingTime;

	public int getMailboxId() {
		return mailboxId;
	}

	public void setMailboxId(int mailboxId) {
		this.mailboxId = mailboxId;
	}

	public String getMailboxType() {
		return mailboxType;
	}

	public void setMailboxType(String mailboxType) {
		this.mailboxType = mailboxType;
	}

	public int getMaxMessage() {
		return maxMessage;
	}

	public void setMaxMessage(int maxMessage) {
		this.maxMessage = maxMessage;
	}

	public int getMsgLifeTime() {
		return msgLifeTime;
	}

	public void setMsgLifeTime(int msgLifeTime) {
		this.msgLifeTime = msgLifeTime;
	}

	public int getMsgLifeTimeAfterRet() {
		return msgLifeTimeAfterRet;
	}

	public void setMsgLifeTimeAfterRet(int msgLifeTimeAfterRet) {
		this.msgLifeTimeAfterRet = msgLifeTimeAfterRet;
	}

	public int getMsgLifeTimeAfterSave() {
		return msgLifeTimeAfterSave;
	}

	public void setMsgLifeTimeAfterSave(int msgLifeTimeAfterSave) {
		this.msgLifeTimeAfterSave = msgLifeTimeAfterSave;
	}

	public int getMaxRecordingTime() {
		return maxRecordingTime;
	}

	public void setMaxRecordingTime(int maxRecordingTime) {
		this.maxRecordingTime = maxRecordingTime;
	}

}
