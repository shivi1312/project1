package com.vcc.model;

import java.io.Serializable;
import java.util.Date;

public class VccUserCompleteDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String loginName;
	private String msisdn;
	private String wpin;
	private int language;
	private String serviceType;
	private String email;
	private int deliveryInterface;
	private String password;
	private int greetingType;
	private String subType;
	private String imsi;
	private int classType;
	private String expiryDate;
	private int ratePlan;
	private String dateRegistered;
	private String status;
	private int isNew;
	private int isMigrating;
	private String ServiceFlag;
	
	
	
	public String getServiceFlag() {
		return ServiceFlag;
	}
	public void setServiceFlag(String serviceFlag) {
		ServiceFlag = serviceFlag;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getWpin() {
		return wpin;
	}
	public void setWpin(String wpin) {
		this.wpin = wpin;
	}
	public int getLanguage() {
		return language;
	}
	public void setLanguage(int language) {
		this.language = language;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getDeliveryInterface() {
		return deliveryInterface;
	}
	public void setDeliveryInterface(int deliveryInterface) {
		this.deliveryInterface = deliveryInterface;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getGreetingType() {
		return greetingType;
	}
	public void setGreetingType(int greetingType) {
		this.greetingType = greetingType;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getImsi() {
		return imsi;
	}
	public void setImsi(String imsi) {
		this.imsi = imsi;
	}
	public int getClassType() {
		return classType;
	}
	public void setClassType(int classType) {
		this.classType = classType;
	}
	
	public int getRatePlan() {
		return ratePlan;
	}
	public void setRatePlan(int ratePlan) {
		this.ratePlan = ratePlan;
	}
	
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getDateRegistered() {
		return dateRegistered;
	}
	public void setDateRegistered(String dateRegistered) {
		this.dateRegistered = dateRegistered;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getIsNew() {
		return isNew;
	}
	public void setIsNew(int isNew) {
		this.isNew = isNew;
	}
	public int getIsMigrating() {
		return isMigrating;
	}
	public void setIsMigrating(int isMigrating) {
		this.isMigrating = isMigrating;
	}
	
	

}
