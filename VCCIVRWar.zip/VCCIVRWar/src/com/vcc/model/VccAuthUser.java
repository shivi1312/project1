package com.vcc.model;

/*
 * Use to store and retrive user profile for vcc
 * This model is mapped to the vcc_auth_user table 
 * */
public class VccAuthUser implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	/* By default store msisdn which is used in case of web */
	/* mapped to login_name */
	private String loginName;
	/* store user phone number */
	/* mapped to msisdn */
	private String msisdn;
	/* used to retrive mail box in case other msisdn */
	/* mapped to wpin */
	private String wpin;
	/* store user language */
	/* mapped to language */
	private int language;
	/* service type used by user->0001->voice mail,0011->notify me,voice mail */
	/* mapped to service_type */
	private String serviceType;
	/* user mail id used to send voice mail file by mail id */
	/* mapped to email_addr */
	private String email;
	/* send notification if a-party leave vm or vn ex: sms,mms,email(0,1,2)*/
	/* mapped to delivery_interface */
	private int deliveryInterface;
	/* used when mailbox is accessed by web */
	/* mapped to pass */
	private String password;
	/* greeting type used by user 0->not set,1->signature,2->full */
	/* mapped to greeting_type */
	private int greetingType;
	/* hold user type ex->postpaid,prepaid */
	/* mapped to sub_type */
	private String subType;
	/* hold user imsi used when voice mail service by area wise */
	/* mapped to imsi */
	private String imsi;
	/* categories wise service ex->vip..etc */
	/* mapped to class_type */
	private int classType;
	
	private String status="P";
	
	private int isMigrating;
	
	private int isNew;

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getWpin() {
		return wpin;
	}

	public void setWpin(String wpin) {
		this.wpin = wpin;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public int getLanguage() {
		return language;
	}

	public void setLanguage(int language) {
		this.language = language;
	}

	public int getDeliveryInterface() {
		return deliveryInterface;
	}

	public void setDeliveryInterface(int deliveryInterface) {
		this.deliveryInterface = deliveryInterface;
	}

	public int getGreetingType() {
		return greetingType;
	}

	public void setGreetingType(int greetingType) {
		this.greetingType = greetingType;
	}

	public int getClassType() {
		return classType;
	}

	public void setClassType(int classType) {
		this.classType = classType;
	}

	public int getIsMigrating() {
		return isMigrating;
	}

	public void setIsMigrating(int isMigrating) {
		this.isMigrating = isMigrating;
	}

	public int getIsNew() {
		return isNew;
	}

	public void setIsNew(int isNew) {
		this.isNew = isNew;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
