package com.vcc.handler;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.chain.VmChain;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.domain.FwdCallLogs;
import com.vcc.domain.VccSendNotification;
import com.vcc.domain.VmOperation;
import com.vcc.domain.VoiceNoteFilter;
import com.vcc.error.VmError;
import com.vcc.request.VmRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.response.VmResponse;
import com.vcc.util.DeleteOldVmFile;
import com.vcc.util.ParseAndValidateRecordFile;

public class VmRecordWithHangUpHandler {
	final static Logger logger = Logger
			.getLogger(VmRecordWithHangUpHandler.class);

	private VmError vmError = new VmError();
	private VccCommonOperation commonOperation = null;

	public VmRecordWithHangUpHandler() {

	}

	public void process(VmRequest vmRequest, BindingResult bindingResult,
			VmResponse vmResponse, VccServices vccServices) {
		if (vmRequest.getCallingNum() != null
				&& vmRequest.getCalledNum() != null
				&& vmRequest.getRecordFileName() != null) {
			logger.info("calling ["+vmRequest.getCallingNum()+"] called ["+vmRequest.
					getCalledNum()+"] file ["+vmRequest.getRecordFileName()+"] silence "+
					"["+vmRequest.getIsSilentDetect()+"] call-uuid ["+vmRequest.getCallUUID()+
					"] server ["+vmRequest.getServerId()+"] answered ["+vmRequest.getAnswerd()+
					"] hangup cause ["+vmRequest.getHangupCause()+"] reason ["+vmRequest.getReasonCode()+
					"] service ["+vmRequest.getServiceType()+"] notification ["+vmRequest.getNotificationSend()+
					"] request submitted to handler");
			commonOperation = new VccCommonOperation();
			commonOperation.addAndRemoveCountryCode(vmRequest);

			if (vmRequest.getIsSilentDetect() == 1) {
				VmChain chain = new DeleteOldVmFile();
				VmChain callFwdLog = new FwdCallLogs();
				chain.setNext(callFwdLog, vccServices);
				chain.process(vmRequest, vmResponse, vmError);
				logger.warn("calling ["+vmRequest.getCallingNum()+"] called ["+vmRequest.
						getCalledNum()+"] call-uuid ["+vmRequest.getCallUUID()+
						"] server ["+vmRequest.getServerId()+"] silence detected !!..");
			} else if (AppConfig.config
					.getInt("vcc_fixedline_record_enable", 0) == 0
					&& vmRequest.getSubType().equalsIgnoreCase("F")) {
				VmChain chain = new DeleteOldVmFile();
				VmChain callFwdLog = new FwdCallLogs();
				chain.setNext(callFwdLog, vccServices);
				chain.process(vmRequest, vmResponse, vmError);
				logger.warn("calling ["+vmRequest.getCallingNum()+"] called ["+vmRequest.
						getCalledNum()+"] call-uuid ["+vmRequest.getCallUUID()+
						"] server ["+vmRequest.getServerId()+"] fixed line not allowed for recording !!..");
			} else {
				logger.info("calling ["+vmRequest.getCallingNum()+"] called ["+vmRequest.
						getCalledNum()+"] call-uuid ["+vmRequest.getCallUUID()+
						"] server ["+vmRequest.getServerId()+"] voice mail is recorded !!..");
				/* Added by Vivek to handle profile with hang up */
				/*if(vmRequest.getServiceType().equals("0100") && 
						vmRequest.getReasonCode().equalsIgnoreCase("hangupWithSave")){	
					VoiceNoteFilter voiceNoteFilter = new VoiceNoteFilter();
					ProfileResponse profile = voiceNoteFilter.process(vmRequest, 
						vmResponse, vmError, vccServices);
					vmRequest = this.setProfileDetail(profile, vmRequest);
				}*/
				/* Added by Vivek to handle profile with hang up */
				VmChain chain = new DeleteOldVmFile(); // No Issue
				VmChain parseRecordFile = new ParseAndValidateRecordFile(); //No Issue
				VmChain saveRecord = new VmOperation(); //No Issue
				VmChain callFwdLog = new FwdCallLogs();
				VmChain sendNotification = new VccSendNotification();
				chain.setNext(parseRecordFile, vccServices);
				parseRecordFile.setNext(saveRecord, vccServices);
				saveRecord.setNext(callFwdLog, vccServices);
				callFwdLog.setNext(sendNotification, vccServices);
				chain.process(vmRequest, vmResponse, vmError);
			}
			commonOperation = null;
		} else {
			vmResponse.setIsSuccess(0);
			logger.error("[" + vmRequest.getCallingNum()
					+ "] save.hangup request param are missing calledNum["
					+ vmRequest.getCalledNum() + "] recordfile ["
					+ vmRequest.getRecordFileName() + "]");
		}
	}
	public VmRequest setProfileDetail(ProfileResponse profile, VmRequest vmRequest){
		try {
			logger.debug("called [" + vmRequest.getCalledNum() + "] calling ["
					+ vmRequest.getCallingNum() + "] profile detail set in request");
			vmRequest.setRatePlan(profile.getRatePlan());
			vmRequest.setIsUserIsOptedOut(profile.getIsUserIsOptedOut());
			vmRequest.setIsNotifyMeWithMCM(profile.getIsNotifyMeWithMCM());
			vmRequest.setIsMailBoxFull(profile.getIsMailBoxFull());
			vmRequest.setIsCallAllowed(profile.getIsCallAllowed());//Hard coded need to change later
			vmRequest.setIsVoiceMailDeleted(profile.getIsVoiceMailDeleted());
			vmRequest.setVccList(profile.getVccList());
			if(profile.getRecordFileName()!= null)
				vmRequest.setRecordFileName(profile.getRecordFileName());
		}catch(Exception e){
			logger.error("called [" + vmRequest.getCalledNum()
					+ "] calling [" + vmRequest.getCallingNum()
					+ "] error while set profile detail: "+e.getMessage());
		}
		return vmRequest;
	}
}
