package com.vcc.handler;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.vcc.cache.VccExpiryCache;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.domain.GetProfile;
import com.vcc.domain.GetProfileRetrieval;
import com.vcc.domain.VccProfileDetails;
import com.vcc.domain.VccSendCopyMessage;
import com.vcc.error.VmError;
import com.vcc.filter.ProfileClient;
import com.vcc.filter.ProfileFilterManager;
import com.vcc.model.MessageStatus;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.util.CallAllowanceFilter;
import com.vcc.util.CallRecordPathFilter;
import com.vcc.util.MailboxFilter;
import com.vcc.util.MsisdnFileFilter;
import com.vcc.util.SubTypeFilter;

public class ProfileHandler {

	final static Logger logger = Logger.getLogger(ProfileHandler.class);
	private Gson gson = new Gson();
	private ProfileFilterManager profileFilterManager = null;
	private ProfileClient profileClient = null;
	private VccCommonOperation commonOperation = null;
	private VmError vmError = new VmError();
	private List<VccSubscriptionMaster> activeServiceList;
	private int changeForAirtel =0;  // added by sanchit

	public ProfileHandler() {

	}

	/**
	 * return void the method check the Profile of particular msisdn and filter
	 * the profile of calledNum using ProfileFilterManager
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of profileResponse , which actually
	 *            return in url response like - isSuccess , isCallAllowed,
	 *            isSubscriber
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public static void main(String [] args){
		String json = "[{\"loginName\":\"971560576237\",\"msisdn\":\"971560576237\",\"wpin\":\"0000\","
				+ "\"language\":2,\"serviceType\":\"0100\",\"deliveryInterface\":1,\"password\":\"0000\","
				+ "\"greetingType\":0,\"subType\":\"O\",\"classType\":0,\"expiryDate\":\"2016-09-07 21:50:18\","
				+ "\"ratePlan\":16,\"dateRegistered\":\"2016-09-07 21:50:18\",\"status\":\"A\",\"isNew\":1,\"isMigrating\":0,\"ServiceFlag\":\"1111111100\"}]";
		System.out.println(new Gson().toJson(Arrays.asList(new Gson().fromJson(json,VccSubscriptionMaster[].class))));
	}
	@SuppressWarnings("unused")
	public void profileCheck(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VccServices vccServices) {
		
		logger.debug("calling ["+profileRequest.getCallingNum()+"] called ["+profileRequest.
				getCalledNum()+"]"+"] profile is going to check");
		commonOperation = new VccCommonOperation();
		commonOperation.addAndRemoveCountryCode(profileRequest);
		
		//this.activeServiceList = vccServices.userService.getActiveServiceList(profileRequest); // get subscription details of user
		try {
			List<VccUserCompleteDetails> userDetail = vccServices.userService.getUserCompleteDetail(profileRequest.getCalledNum());
			logger.info("detail: "+gson.toJson(userDetail));
			this.activeServiceList = Arrays.asList(gson.fromJson(gson.toJson(userDetail),VccSubscriptionMaster[].class));
			profileRequest.setActiveServiceList(activeServiceList);
		}catch(Exception e){
			logger.error("calling ["+profileRequest.getCallingNum()+"] called ["+profileRequest.
					getCalledNum()+"]"+"] error while deserialize: "+e.getMessage());
		}
		
		SubTypeFilter subTypeFilter = new SubTypeFilter(); //No Issue
		GetProfile getProfile = new GetProfile(); // See later
		MsisdnFileFilter msisdnFilter = new MsisdnFileFilter(); // No Issue
		CallAllowanceFilter callAllowanceFilter = new CallAllowanceFilter(); // No Issue
		MailboxFilter mailboxFilter = new MailboxFilter(); // No Issue 
		CallRecordPathFilter callRecordPathFilter = new CallRecordPathFilter(); // No Issue
		
		subTypeFilter.setActiveServiceList(activeServiceList);
		getProfile.setActiveServiceList(activeServiceList);
		
		profileClient = new ProfileClient();
		profileFilterManager = new ProfileFilterManager();
		//profileFilterManager.setFilter(new CountryCodeFilter());
		profileFilterManager.setFilter(subTypeFilter);
		profileFilterManager.setFilter(msisdnFilter);
		profileFilterManager.setFilter(callAllowanceFilter);
		profileFilterManager.setFilter(getProfile);
		profileFilterManager.setFilter(mailboxFilter);
		profileFilterManager.setFilter(callRecordPathFilter);
		profileClient.setFilterManager(profileFilterManager);
		profileClient.sendRequest(bindingResult, vccServices, profileRequest,profileResponse, vmError);

		if (profileResponse.getIsCallAllowed() == 1
				|| profileResponse.getIsSubscriber() == 1) {
			int ratePlan = profileResponse.getRatePlan();
			String ratePlanJson = VccExpiryCache.getSysmap().get("vcc_rate_plan");
			logger.debug("rate plan json " + ratePlanJson);
			JsonParser jsonParser = new JsonParser();
			String mailBoxId = jsonParser.parse(ratePlanJson).getAsJsonObject()
					.get("" + ratePlan + "").getAsJsonObject().get("mailBoxId").toString();
			String mailBoxParamJson = VccExpiryCache.getSysmap().get("vcc_mailbox_param");
			int recordingTime = Integer.parseInt(jsonParser
					.parse(mailBoxParamJson).getAsJsonObject().get(mailBoxId)
					.getAsJsonObject().get("maxRecordingTime").toString());
			int recordingTimeOut = AppConfig.config.getInt("record_timeout_" + profileResponse.getServiceType() + "", 15);
			logger.info("aParty [" + profileRequest.getCallingNum()
					+ "] bParty [" + profileRequest.getCalledNum()
					+ "] profile.check request the recordingTimeOut ["
					+ recordingTimeOut + "] recordingTime is [" + recordingTime
					+ "] for  [" + profileRequest.getCalledNum()
					+ "] release code [" + profileRequest.getReleaseCode()+ "] ");
			profileResponse.setRecordLength(recordingTime);
			profileResponse.setRecordTimeout(recordingTimeOut);
		} else {
			logger.info("aParty ["
					+ profileRequest.getCallingNum()
					+ "] bParty ["
					+ profileRequest.getCalledNum()
					+ "] profile.check Request the recordingTime is not set for  ["
					+ profileRequest.getCalledNum() + "] release code ["
					+ profileRequest.getReleaseCode() + "]");
		}

		commonOperation = null;
		profileClient = null;
	}

	/**
	 * return void the method check the Profile of particular msisdn and filter
	 * the profile of calledNum using ProfileFilterManager
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of profileResponse , which actually
	 *            return in url response like - isSuccess , isCallAllowed,
	 *            isSubscriber
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void profileCheckRetrieval(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VccServices vccServices) {

		if (profileRequest.getCallingNum() != null
				&& profileRequest.getServiceType() != null) {
			logger.info(String
					.format(" profile.check.ret request A-Party [%s] B-Party [%s] service type[%s]",
							profileRequest.getCallingNum(),
							profileRequest.getCalledNum(),
							profileRequest.getServiceType()));
			 changeForAirtel = AppConfig.config.getInt("changes_for_airtel_africa"); // added by sanchit
			logger.debug("change for airtel====================="+changeForAirtel);
			// commonOperation = new VccCommonOperation();
			// commonOperation.addAndRemoveCountryCode(profileRequest);
			profileFilterManager = new ProfileFilterManager();
			profileClient = new ProfileClient();
			profileFilterManager.setFilter(new GetProfileRetrieval());
			profileFilterManager.setFilter(new CallAllowanceFilter());
			profileClient.setFilterManager(profileFilterManager);
			
			profileClient.sendRequest(bindingResult, vccServices,
					profileRequest, profileResponse, vmError);
			commonOperation = null;

			if (profileResponse.getIsSubscriber() == 1) {
				profileResponse.setInvalidDigitsSound(AppConfig.config
						.getString("ivr_common_path")
						+ File.separator
						+ profileResponse.getLang()
						+ File.separator
						+ "INVALID_CHOICE.wav");

				Boolean status = vccServices.userService
						.updateLastVisitTime(profileRequest.getCallingNum());

				String key = profileRequest.getCallingNum() + "_status";
				MessageStatus messageStatus = new MessageStatus();
				VccExpiryCache.pxmlmap.put(key, messageStatus, 20,
						TimeUnit.MINUTES);
				logger.info("["
						+ profileRequest.getCallingNum()
						+ "] MessageStatus object created and the Key of Global cache is ["
						+ key + "] and last visit time update status ["
						+ status + "]");

			} else {

				profileResponse.setInvalidDigitsSound(AppConfig.config
						.getString("ivr_common_path")
						+ File.separator
						+ "$lang" + File.separator + "INVALID_CHOICE.wav");
				logger.info("[" + profileRequest.getCallingNum()
						+ "] calling Num is not Subscriber");
			}

		} else {
			logger.error("The profile check parameter are  required callingNum ["
					+ profileRequest.getCallingNum()
					+ "] serviceType ["
					+ profileRequest.getServiceType() + "]");
			profileResponse.setIsSubscriber(-1);

		}
	}

	/**
	 * return void the method check the Profile of particular msisdn and filter
	 * the profile of calledNum using ProfileFilterManager
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of profileResponse , which actually
	 *            return in url response like - isSuccess , isCallAllowed,
	 *            isSubscriber
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void profileCheckRetrievalLongCode(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VccServices vccServices) {

		if (profileRequest.getCallingNum() != null
				&& profileRequest.getServiceType() != null
				&& profileRequest.getCalledNum() != null) {
			logger.info(String
					.format("profile.check.longCode request >> A-Party [%s] B-Party [%s] service type[%s]",
							profileRequest.getCallingNum(),
							profileRequest.getCalledNum(),
							profileRequest.getServiceType()));
			String callingNum;
			if (profileRequest.getCalledNum().startsWith(
					AppConfig.config.getString("longCode"))) {
				callingNum = profileRequest.getCalledNum();
				logger.info("calling from long short code["
						+ AppConfig.config.getString("longCode").length() + "]");

				callingNum = callingNum.substring(
						AppConfig.config.getString("longCode").length(),
						callingNum.length());
				logger.info("called Number: " + callingNum);
				profileRequest.setCallingNum(callingNum);

				profileResponse.setCallingNum(callingNum);
				logger.info("called Number: " + profileRequest.getCalledNum());
			} else if (profileRequest.getCalledNum().startsWith(
					AppConfig.config.getString("pstn_longCode"))) {
				callingNum = profileRequest.getCalledNum();
				logger.info("calling from long short code["
						+ AppConfig.config.getString("pstn_longCode").length()
						+ "]");

				callingNum = callingNum.substring(
						AppConfig.config.getString("pstn_longCode").length(),
						callingNum.length());
				logger.info("called Number: " + callingNum);
				profileRequest.setCallingNum(callingNum);

				profileResponse.setCallingNum(callingNum);
				logger.info("called Number: " + profileRequest.getCalledNum());
			} else {
				logger.info("calling from normal short code");
				callingNum = profileRequest.getCalledNum();

				profileRequest.setCallingNum(callingNum);

				profileResponse.setCallingNum(callingNum);

			}

			// commonOperation = new VccCommonOperation();
			// commonOperation.addAndRemoveCountryCode(profileRequest);
			profileFilterManager = new ProfileFilterManager();
			profileClient = new ProfileClient();
			profileFilterManager.setFilter(new GetProfileRetrieval());
			profileFilterManager.setFilter(new CallAllowanceFilter());
			profileClient.setFilterManager(profileFilterManager);
			profileClient.sendRequest(bindingResult, vccServices,
					profileRequest, profileResponse, vmError);
			commonOperation = null;

			if (profileResponse.getIsSubscriber() == 1) {
				profileResponse.setInvalidDigitsSound(AppConfig.config
						.getString("ivr_common_path")
						+ File.separator
						+ profileResponse.getLang()
						+ File.separator
						+ "INVALID_CHOICE.wav");
				String key = profileRequest.getCallingNum() + "_status";
				MessageStatus messageStatus = new MessageStatus();
				VccExpiryCache.pxmlmap.put(key, messageStatus);
				logger.info("["
						+ profileRequest.getCallingNum()
						+ "] MessageStatus object created and the Key of Global cache is ["
						+ key + "]");

			} else {
				logger.info("[" + profileRequest.getCallingNum()
						+ "] calling Num is not Subscriber");
				profileResponse.setInvalidDigitsSound(AppConfig.config
						.getString("ivr_common_path")
						+ File.separator
						+ "$lang" + File.separator + "INVALID_CHOICE.wav");
			}

		} else {
			logger.error("The profile check parameter are  required callingNum ["
					+ profileRequest.getCallingNum()
					+ "] serviceType ["
					+ profileRequest.getServiceType() + "]");
			profileResponse.setIsSubscriber(-1);

		}
	}

	/**
	 * return void the method is responsible for change the language of
	 * callingNum profile
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of profileResponse , which actually
	 *            return in url response like - isSuccess
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void changeLangProcess(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VccServices vccServices) {

		logger.info(String
				.format(" change.language request >> A-Party [%s] B-Party [%s] Lang[%s]",
						profileRequest.getCallingNum(),
						profileRequest.getCalledNum(), profileRequest.getLang()));

		if (profileRequest.getCallingNum() != null
				&& profileRequest.getLang() != 0
				&& profileRequest.getLang() != -1) {
			int status = vccServices.userService
					.updateUserLanguage(profileRequest);

			if (status > 0) {

				if (VccExpiryCache.pxmlmap.containsKey(profileRequest
						.getCallingNum() + "_status")) {
					MessageStatus messageStatus = (MessageStatus) VccExpiryCache.pxmlmap
							.get(profileRequest.getCallingNum() + "_status");
					messageStatus
							.setLangChange(messageStatus.getLangChange() + 1);

				}
				profileResponse.setIsSuccess(1);
			} else {
				profileResponse.setIsSuccess(0);
			}
		} else {
			logger.error("Change lang param are missing callingNum ["
					+ profileRequest.getCallingNum() + "] and lang ["
					+ profileRequest.getLang() + "]");
			profileResponse.setIsSuccess(-1);
		}
	}

	/**
	 * return void the method is responsible for change the password of
	 * callingNum profile
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of profileResponse , which actually
	 *            return in url response like - isSuccess
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void changePassWordProcess(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VccServices vccServices) {
		if (profileRequest.getCallingNum() != null
				&& profileRequest.getPassword() != null) {
			logger.info(String
					.format("change.password request >> A-Party [%s] B-Party [%s] ServiceType [%s] Lang[%s] Password [%s]",
							profileRequest.getCallingNum(),
							profileRequest.getCalledNum(),
							profileRequest.getServiceType(),
							profileRequest.getLang(),
							profileRequest.getPassword()));
			boolean status = vccServices.userService
					.updateUserPassword(profileRequest);
			if (status) {
				if (VccExpiryCache.pxmlmap.containsKey(profileRequest
						.getCallingNum() + "_status")) {
					MessageStatus messageStatus = (MessageStatus) VccExpiryCache.pxmlmap
							.get(profileRequest.getCallingNum() + "_status");
					messageStatus.setEditPass(messageStatus.getEditPass() + 1);

				}
				profileResponse.setIsSuccess(1);
			} else {
				profileResponse.setIsSuccess(0);
			}

		} else {
			logger.error("change password request param are missing, callingNum ["
					+ profileRequest.getCallingNum()
					+ "] pass ["
					+ profileRequest.getPassword() + "] ");
			profileResponse.setIsSuccess(-1);
		}
	}

	/**
	 * return void the method is responsible for check the profile of
	 * destination MSISDN and if destination MSISDN is voice mail subscriber
	 * than send copy of voice mail this method also responsible for filtering
	 * MSISDN profile with ProfileFilterManager class
	 * 
	 * @param profileRequest
	 *            the variable contain bean of ProfileRequest ,which set by url
	 *            request like - callingNum , calledNum ,serviceType etc
	 * @param profileResponse
	 *            the variable contain bean of profileResponse , which actually
	 *            return in url response like - isSuccess
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void sendCopyProcess(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VccServices vccServices) {

		profileClient = new ProfileClient();
		profileFilterManager = new ProfileFilterManager();
		profileFilterManager.setFilter(new VccProfileDetails());
		profileFilterManager.setFilter(new MailboxFilter());
		profileFilterManager.setFilter(new CallRecordPathFilter());
		profileFilterManager.setFilter(new VccSendCopyMessage());
		profileClient.setFilterManager(profileFilterManager);
		profileClient.sendRequest(bindingResult, vccServices, profileRequest,
				profileResponse, vmError);

		if (profileResponse.getIsSuccess() == 1
				&& VccExpiryCache.pxmlmap.containsKey(profileRequest
						.getCallingNum() + "_status")) {

			MessageStatus messageStatus = (MessageStatus) VccExpiryCache.pxmlmap
					.get(profileRequest.getCallingNum() + "_status");
			messageStatus.setMsgCopy(messageStatus.getMsgCopy() + 1);
		}

	}

	public void checkPassWordProcess(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VccServices vccServices) {
		if (profileRequest.getCallingNum() != null
				&& profileRequest.getPassword() != null
				&& profileRequest.getDigits() != null) {
			logger.info(" check.password request >> ["
					+ profileRequest.getCallingNum()
					+ "] request param are callingNum ["
					+ profileRequest.getCallingNum() + "] password ["
					+ profileRequest.getPassword() + "] user input ["
					+ profileRequest.getDigits() + "]");

			if (profileRequest.getPassword().equalsIgnoreCase(
					profileRequest.getDigits())) {
				logger.info("[" + profileRequest.getCallingNum()
						+ "] paaword match");
				profileResponse.setIsSuccess(1);

			} else {
				profileResponse.setIsSuccess(0);
				logger.info("[" + profileRequest.getCallingNum()
						+ "] paaword not match");

			}

		} else {

			logger.error("check password request param are missing callingNum ["
					+ profileRequest.getCallingNum()
					+ "] password ["
					+ profileRequest.getPassword()
					+ "] user input ["
					+ profileRequest.getDigits() + "]");

			profileResponse.setIsSuccess(-1);
		}

	}

	public void dirCreate(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VccServices vccServices) {
		Boolean status = false;
		if (profileRequest.getCallingNum() != null
				&& profileRequest.getCalledNum() != null
				&& profileRequest.getRecordFilePath() != null
				&& profileRequest.getRecordFilePath() != "") {
			VccCommonOperation commonOperation = new VccCommonOperation();
			if (AppConfig.config.getBoolean("nio_used", false)) {
				status = commonOperation.createNioDirectory(profileRequest
						.getRecordFilePath());
			} else {
				status = commonOperation.createDirectory(profileRequest
						.getRecordFilePath());
			}

			if (status)
				profileResponse.setIsSuccess(1);
			else
				profileResponse.setIsSuccess(0);

		} else {
			logger.error("create directory request param are missing, callingNum ["
					+ profileRequest.getCallingNum()
					+ "] calledNum ["
					+ profileRequest.getCalledNum()
					+ "] recordFilePath ["
					+ profileRequest.getRecordFilePath() + "] ");
			profileResponse.setIsSuccess(0);

		}

	}

}
