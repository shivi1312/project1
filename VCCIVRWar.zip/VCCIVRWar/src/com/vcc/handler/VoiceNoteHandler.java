package com.vcc.handler;

public class VoiceNoteHandler {

}
