package com.vcc.handler;

import org.apache.log4j.Logger;

import com.vcc.cache.VccExpiryCache;
import com.vcc.common.VccServices;
import com.vcc.model.MessageStatus;
import com.vcc.request.RetLogRequest;
import com.vcc.response.ProfileResponse;

public class VccLogHandler {
	
	final static Logger logger = Logger.getLogger(VccLogHandler.class);

	
	public  VccLogHandler(){	
	}
	
	
	/**
	 * return void 
	 * the method is responsible for create voice mail retrieval logs of call and clear cache of callingNum
	 * @param retLogRequest the variable contain bean of RetLogRequest ,which set by url request like - callingNum , calledNum ,serviceType,callDuration,callTime etc  
	 * @param profileResponse the variable contain bean of  ProfileResponse , which actually return in url response like - isSuccess  
	 * @param vccServices vccServices is a bean that contain reference of interface(UserService,MessageService,UserConfigService)
	 * @return void     
	 * @see    nothing
	 */
	public void process(RetLogRequest retLogRequest, ProfileResponse profileResponse, VccServices vccServices){

		
		logger.info("save.retlog request ["+retLogRequest.getCallingNum()+"] Hangup call and save Retrieval log");
		
		if(VccExpiryCache.pxmlmap.containsKey(retLogRequest.getCallingNum()+"_status"))
		{
		logger.info("["+retLogRequest.getCallingNum()+"] get Retrieval info from global cache");
			MessageStatus messageStatus = (MessageStatus) VccExpiryCache.pxmlmap.get(retLogRequest.getCallingNum()+"_status");
			retLogRequest.setCngLngCnt(messageStatus.getLangChange());
			retLogRequest.setDialCnt(messageStatus.getDial());
			retLogRequest.setFrndAd(messageStatus.getFrndAdd());
			retLogRequest.setFrndDel(messageStatus.getFrndDel());
			retLogRequest.setGrtAd(messageStatus.getGrtAdd());
			retLogRequest.setGrtDel(messageStatus.getGrtDel());
			retLogRequest.setmCp(messageStatus.getMsgCopy());
			retLogRequest.setmDel(messageStatus.getMsgDel());
			retLogRequest.setmMv(messageStatus.getMsgMove());
			retLogRequest.setmRd(messageStatus.getMsgRead());
			retLogRequest.setmSv(messageStatus.getMsgSave());
			retLogRequest.setRecCnt(messageStatus.getRecorded());
			
			
			VccExpiryCache.pxmlmap.remove(retLogRequest.getCallingNum()+"_status");
			if(VccExpiryCache.pxmlmap.containsKey("ret_"+retLogRequest.getCallingNum()))
				VccExpiryCache.pxmlmap.remove("ret_"+retLogRequest.getCallingNum());
		
		int status = vccServices.userService.insertRetLog(retLogRequest);
		if(status>0){
			profileResponse.setIsSuccess(1);
			logger.info("["+retLogRequest.getCallingNum()+"] retrieval log saved ");
		}
		else{
			profileResponse.setIsSuccess(0);
			logger.warn("["+retLogRequest.getCallingNum()+"] retrieval log not saved because calllog info. not saved  ");
		}
		}
		else
		{
			logger.warn("["+retLogRequest.getCallingNum()+"] is not subscriber but logs creating in database");
		
			retLogRequest.setCngLngCnt(0);
			retLogRequest.setDialCnt(0);
			retLogRequest.setFrndAd(0);
			retLogRequest.setFrndDel(0);
			retLogRequest.setGrtAd(0);
			retLogRequest.setGrtDel(0);
			retLogRequest.setmCp(0);
			retLogRequest.setmDel(0);
			retLogRequest.setmMv(0);
			retLogRequest.setmRd(0);
			retLogRequest.setmSv(0);
			retLogRequest.setRecCnt(0);
			
			if(VccExpiryCache.pxmlmap.containsKey("ret_"+retLogRequest.getCallingNum()))
				VccExpiryCache.pxmlmap.remove("ret_"+retLogRequest.getCallingNum());
					
		
		int status = vccServices.userService.insertRetLog(retLogRequest);
		if(status>0){
			profileResponse.setIsSuccess(1);
			logger.info("["+retLogRequest.getCallingNum()+"] in not a subscriber but retrieval log saved ");
		}
		else{
			profileResponse.setIsSuccess(0);
			logger.info("["+retLogRequest.getCallingNum()+"] retrieval log not saved because calllog info. not saved  ");
		}
			
			
			
		}
	}
}
