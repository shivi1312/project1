package com.vcc.handler;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.cache.VccExpiryCache;
import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.model.MessageStatus;
import com.vcc.model.VccPersonalGreeting;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VccGreetingRequest;
import com.vcc.response.ProfileResponse;

public class VccGreetingHandler {

	final static Logger logger = Logger.getLogger(VccGreetingHandler.class);
	final static Logger delLogger = Logger.getLogger("deleteLogger");
	private VccCommonOperation commonOperation = null;
	@SuppressWarnings("unused")
	private VmError vmError = new VmError();
	private String greetPath = null;
	private String msisdn = null;
	private String greetFileName = null;
	private int recordingDuration=0;
	public VccGreetingHandler() {

	}

	/**
	 * return void the method is responsible for save the greeting details of callingNum
	 * @param greetingRequest
	 *            the variable contain bean of VccGreetingRequest ,which set by
	 *            url request like - callingNum , serviceType, recordFileName
	 * @param profileResponse
	 *            the variable contain bean of ProfileResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void saveGreetingProcess(VccGreetingRequest greetingRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VccServices vccServices) {
		int response = 0;
		Boolean greetStatus=false;
		if ((greetingRequest.getCallingNum() != null && greetingRequest
				.getRecordFileName() != null)
				&& greetingRequest.getRecordingDuration() != 0) {
			logger.info(String
					.format(" save.greetrequest  >> A-Party [%s] B-Party [%s] ServiceType [%s] Lang[%s] recordFileName [%s] recordingTime [%s]",
							greetingRequest.getCallingNum(),
							greetingRequest.getCalledNum(),
							greetingRequest.getServiceType(),
							greetingRequest.getLang(),
							greetingRequest.getRecordFileName(),
							greetingRequest.getRecordingDuration()/1000));
			int greetingType = AppConfig.config
					.getInt("save_signature_greet_type",1);
			
			
			recordingDuration = greetingRequest.getRecordingDuration();
			
			greetingRequest.setRecordingDuration(recordingDuration/1000);
			
			greetingRequest.setGreetingType(greetingType);
			VccPersonalGreeting personalGreeting = vccServices.userService
					.getUserGreeting(greetingRequest.getCallingNum());
			
			if (personalGreeting != null) {
				if (vccServices.userService
						.updatePersonalGreeting(greetingRequest)) {
					greetStatus =vccServices.userService.updateGreetingType(greetingType,greetingRequest.getCallingNum());
					response = 1;
				}
			} else {
				boolean status = vccServices.userService
						.saveUserGreeting(greetingRequest);
				if (status) {
					greetStatus =vccServices.userService.updateGreetingType(greetingType,greetingRequest.getCallingNum());
					response = 1;
				}
			}
			
			if(response==1 && VccExpiryCache.pxmlmap.containsKey(greetingRequest.getCallingNum()+"_status"))
			{
				MessageStatus messageStatus = (MessageStatus)VccExpiryCache.pxmlmap.get(greetingRequest.getCallingNum()+"_status");
				messageStatus.setGrtAdd(messageStatus.getGrtAdd()+1);
			
			}
			logger.info("[" + greetingRequest.getCallingNum()
					+ "] recordFileName ["
					+ greetingRequest.getRecordFileName() + "] saved status ["
					+ response + "] update Greeting in VCC_AUTH_USER ["+greetStatus+"] for greeting type ["+greetingType+"]");
			profileResponse.setIsSuccess(response);
		} else {
			logger.error("save greeting request param are missing callingNum ["
					+ greetingRequest.getCallingNum() + "] recordFileName ["
					+ greetingRequest.getRecordFileName() + "] recordTime ["
					+ greetingRequest.getRecordingDuration() + "]");
			profileResponse.setIsSuccess(-1);
		}
	}
	/**
	 * return void the method is responsible for delete the greeting details of callingNum
	 * @param greetingRequest
	 *            the variable contain bean of VccGreetingRequest ,which set by
	 *            url request like - callingNum , serviceType, recordFileName
	 * @param profileResponse
	 *            the variable contain bean of ProfileResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void deleteGreetingProcess(VccGreetingRequest greetingRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VccServices vccServices) {
		commonOperation = new VccCommonOperation();
		Boolean greetStatus= false;
		if (greetingRequest.getCallingNum() != null) {
			logger.info(String.format(
					"delete.greet request >> A-Party [%s] B-Party [%s] ServiceType [%s]",
					greetingRequest.getCallingNum(),
					greetingRequest.getCalledNum(),
					greetingRequest.getServiceType()));
			VccPersonalGreeting personalGreeting = vccServices.userService.getUserGreeting(greetingRequest.getCallingNum());
			boolean status = vccServices.userService.deleteUserGreeting(greetingRequest);
			
			if (status) {
				
		    	greetStatus = vccServices.userService.updateGreetingType(AppConfig.config.getInt("default_greeting_type",0), greetingRequest.getCallingNum());
		    	
				profileResponse.setIsSuccess(1);
				if(VccExpiryCache.pxmlmap.containsKey(greetingRequest.getCallingNum()+"_status"))
				{
				MessageStatus messageStatus = (MessageStatus)VccExpiryCache.pxmlmap.get(greetingRequest.getCallingNum()+"_status");
				if(messageStatus!=null){
				messageStatus.setGrtDel(messageStatus.getGrtDel()+1);
				VccExpiryCache.pxmlmap.setExpiration(greetingRequest.getCallingNum()+"_status", 10, TimeUnit.MINUTES);
				}else
				{
					logger.error("["+greetingRequest.getCallingNum()+"] cache is expire");
				}
				}
			} else {
				profileResponse.setIsSuccess(0);
				
				logger.debug("["+greetingRequest.getCallingNum()+"] greet deleted status ["+status+"] because no greeting found ");
			}
			if (personalGreeting != null) {
				msisdn = commonOperation.msisdnWithoutCountryCode(greetingRequest
								.getCallingNum());
				this.greetFileName = personalGreeting.getFilePath();
				this.greetPath = commonOperation.getCopletePath(
						this.greetFileName.substring(0,this.greetFileName.length()
										- AppConfig.config.getInt("default_record_digits", 10)),
						msisdn, this.greetFileName,AppConfig.config.getString("ivr_greeting_path"));
				delLogger.info(this.greetPath);
			}
						
			logger.info("["+greetingRequest.getCallingNum()+"] greet deleted status ["+status+"] update greerting status ["+greetStatus+"]");
		} else {
			logger.error("delete greeting request param are missing callingNum ["
					+ greetingRequest.getCallingNum() + "]");
			profileResponse.setIsSuccess(-1);
		}

	}
	/**
	 * return void the method is responsible for gathering  the greeting details of callingNum from database
	 * @param greetingRequest
	 *            the variable contain bean of VccGreetingRequest ,which set by
	 *            url request like - callingNum , serviceType, recordFileName
	 * @param profileResponse
	 *            the variable contain bean of ProfileResponse , which
	 *            actually return in url response like - isSuccess(0,1)
	 * @param vmError
	 *            vmError is a bean that is used to define which type of error
	 *            generate in operation
	 * @param vccServices
	 *            vccServices is a bean that contain reference of
	 *            interface(UserService,MessageService,UserConfigService)
	 * @return void
	 * @see nothing
	 */
	public void greetingFilePathProcess(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VccServices vccServices) {

		if (profileRequest.getCallingNum() != null
				&& profileRequest.getServiceType() != null
				&& profileRequest.getLang() != 0) {
			logger.info(String.format(
					"greet.file.path request >> A-Party [%s] B-Party [%s] ServiceType [%s] Lang [%s]",
					profileRequest.getCallingNum(),
					profileRequest.getCalledNum(),
					profileRequest.getServiceType(), profileRequest.getLang()));
			commonOperation = new VccCommonOperation();
			String recordFileName = commonOperation.getRecordFileName();
			msisdn = commonOperation.msisdnWithoutCountryCode(profileRequest
					.getCallingNum());
			String recordFilePath = commonOperation.getRecordFilePath(msisdn,
					recordFileName,
					AppConfig.config.getString("ivr_greeting_path"));
			profileResponse.setRecordFileName(recordFileName);
			profileResponse.setRecordFilePath(recordFilePath);

			VccPersonalGreeting personalGreeting = vccServices.userService
					.getUserGreeting(profileRequest.getCallingNum());
			if (personalGreeting != null && recordFileName != null
					&& recordFilePath != null) {

				this.greetFileName = personalGreeting.getFilePath();
				this.greetPath = commonOperation.getCopletePath(
						this.greetFileName.substring(0,
								this.greetFileName.length() - AppConfig.config.getInt("default_record_digits", 10)), msisdn,
						this.greetFileName,
						AppConfig.config.getString("ivr_greeting_path"));
				profileResponse.setGreetPath(this.greetPath);
				profileResponse.setRecordLength(AppConfig.config.getInt("greeting_record_length",15));
				profileResponse.setRecordTimeout(AppConfig.config.getInt("greeting_record_timeout",15));
				profileResponse.setIsSuccess(1);
			} else if (recordFileName != null && recordFilePath != null) {
				profileResponse.setIsSuccess(1);

			} else {
				profileResponse.setIsSuccess(0);
			}
			logger.info("[" + profileRequest.getCallingNum()
					+ "] recordFileName [" + recordFileName
					+ "] recordFilePath [" + recordFilePath + "]");
			commonOperation = null;
		} else {
			logger.error("Greeting file path param are missing callingNum ["
					+ profileRequest.getCallingNum() + "] lang ["
					+ profileRequest.getLang() + "] serviceType ["
					+ profileRequest.getServiceType() + "]");
			profileResponse.setIsSuccess(-1);
		}
	}

}
