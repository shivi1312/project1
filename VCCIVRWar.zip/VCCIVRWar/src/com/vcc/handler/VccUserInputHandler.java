package com.vcc.handler;

import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;

import com.vcc.common.VccCommonOperation;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.error.VmError;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;

public class VccUserInputHandler {
	final static Logger logger = Logger.getLogger(VccUserInputHandler.class);
	private VmError vmError = new VmError();
	private String calledNumB;
	private int lang;
	private String msisdnPath;
	private VccCommonOperation commonOperation = null;

	public VccUserInputHandler() {

	}

	public void userInputProcess(ProfileRequest profileRequest,
			BindingResult bindingResult, ProfileResponse profileResponse,
			VccServices vccServices) {

		if (profileRequest.getCalledNumB() != null
				&& profileRequest.getCalledNumB() != "") {
			commonOperation = new VccCommonOperation();
			this.lang = profileRequest.getLang();
			this.calledNumB = profileRequest.getCalledNumB();
			this.msisdnPath = commonOperation.userInputParse(this.calledNumB,
					this.lang);
			if (profileRequest.getCalledNumB().length() <= 2) {
				logger.info(" user.input request >> ["+profileRequest.getCallingNum()+"] Group["+this.calledNumB+"] id Enter by user ");
				profileResponse.setIsSuccess(1);
				
			} else if (profileRequest.getCalledNumB().length() == AppConfig.config
					.getInt("msisdn_length")) {
				logger.info(" user.input request >> ["+profileRequest.getCallingNum()+"] msisdn ["+this.calledNumB+"]  Enter by user ");
				profileResponse.setIsSuccess(1);
			} else if (profileRequest.getCalledNumB().length() > 9 && profileRequest.getCalledNumB().length() <13) {
				logger.info("user.input request >> ["+profileRequest.getCallingNum()+"] digits ["+this.calledNumB+"]  Enter by user ");
				profileResponse.setIsSuccess(1);
			}else
			{
				logger.info("user.input request >> ["+profileRequest.getCallingNum()+"] digits ["+this.calledNumB+"]  Enter by user not correct ");
				profileResponse.setIsSuccess(0);
			}
			profileResponse.setMsisdnLength(this.calledNumB.length());
			profileResponse.setMsisdnFilePath(this.msisdnPath);
			logger.debug(String.format(
					"A-Party [%s] B-Party [%s] msisdn file list [%s]",
					profileRequest.getCallingNum(),
					profileRequest.getCalledNum(), this.msisdnPath));

		} else {
			vmError.setError(true);
			vmError.setMsg("user.input request >> CalledNumB and lang are null");
		}

		if (vmError.getError()) {
			logger.error("Error in user input [" + vmError.getMsg() + "]");
			vmError.setError(false);
			profileResponse.setIsSuccess(-1);

		}
	}
}
