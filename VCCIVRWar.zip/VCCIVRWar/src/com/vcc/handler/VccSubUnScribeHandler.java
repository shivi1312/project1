package com.vcc.handler;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.List;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.vcc.common.VccServices;
import com.vcc.config.AppConfig;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.net.ConnectionPool;
import com.vcc.net.TextSocketConnection;
import com.vcc.request.ProfileRequest;
import com.vcc.request.VccRuleEngineRequest;
import com.vcc.response.ProfileResponse;
import com.vcc.response.VccRuleEngineResponse;
import com.vcc.util.TcpConnectionPool;
import com.vcc.util.TcpPool;

import edu.emory.mathcs.util.net.Connection;

public class VccSubUnScribeHandler {

	final static Logger logger = Logger.getLogger(VccSubUnScribeHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private Gson gson = null;
	private VccRuleEngineResponse subUnscribeResponse = null;

	public VccSubUnScribeHandler() {
	}
	public VccUserCompleteDetails getCompleteAuthDetail(List<VccUserCompleteDetails> master,String serviceType){
		VccUserCompleteDetails vccSub = null;
		try {
			if(master != null){
				for(VccUserCompleteDetails vccMaster: master){
					if(vccMaster.getServiceType().equalsIgnoreCase(serviceType)){
						logger.debug("[" + vccMaster.getMsisdn()
							+ "] Returning Rate Plan >> "+vccMaster.getRatePlan());
						return vccMaster;
					}
				}
			}
		}catch(Exception e){
			logger.error("Error while convert master to auth user: "+e.getMessage());
		}
		return vccSub;
	}
	public void subscribeProcess(ProfileRequest profileRequest,
			ProfileResponse profileResponse, VccServices vccServices) {
		int isSuccess = 0, ratePlan = 0;
		String subType = AppConfig.config.getString("default_sub_type","N");
		if (profileRequest.getCallingNum() != null
				&& profileRequest.getServiceType() != null
				&& profileRequest.getLang() != 0) {
			String json = getSubscribeJsonObj(profileRequest);
			
			if(profileRequest.getSubType()!=null)
				subType=profileRequest.getSubType();
			
			logger.info("["+profileRequest.getCallingNum()+"] vm.subscribe request >> Subscribe json request subType["+subType+"]: " + json);
			// this.sendSubUnscribeRequest(json);
			this.tcpWithVccRule(json);

			if (subUnscribeResponse != null) {
				if (subUnscribeResponse.getResult().equalsIgnoreCase("success")) {
					logger.info("[" + profileRequest.getCallingNum()
							+ "] success result resopnse from rule engine");
					isSuccess = 1;
					VccUserCompleteDetails userCompleteDetails = this.getCompleteAuthDetail(vccServices.userService
							.getUserCompleteDetail(profileRequest
									.getCallingNum()),profileRequest.getServiceType());
					if (userCompleteDetails != null) {
						ratePlan = userCompleteDetails.getRatePlan();
						subType = userCompleteDetails.getSubType();
					}
				} else if (subUnscribeResponse.getResult().equalsIgnoreCase(
						"fail")) {
					logger.info("[" + profileRequest.getCallingNum()
							+ "] fail result resopnse from rule engine");
					isSuccess = 0;
				}
			} else {
				logger.info("[" + profileRequest.getCallingNum()
						+ "] no resopnse from rule engine");
				isSuccess = -1;
			}
			profileResponse.setIsSuccess(isSuccess);
			profileResponse.setRatePlan(ratePlan);
			profileResponse.setSubType(subType);
		} else {
			logger.error("Do subscribe request param are missing callingNum ["
					+ profileRequest.getCallingNum() + "] lang ["
					+ profileRequest.getLang() + "] serviceType ["
					+ profileRequest.getServiceType() + "]");
			profileResponse.setIsSuccess(-1);
		}
	}

	public void unSubscribeProcess(ProfileRequest profileRequest,
			ProfileResponse profileResponse, VccServices vccServices) {
		int isSucess = 0;
		if (profileRequest.getCallingNum() != null
				&& profileRequest.getServiceType() != null
				&& profileRequest.getLang() != 0) {

			String json = getUnscribeJsonObj(profileRequest);
			logger.info("do.unsubscribe request >> UnSubscribe json request: " + json);
			// this.sendSubUnscribeRequest(json);
			this.tcpWithVccRule(json);
			if (subUnscribeResponse != null) {
				if (subUnscribeResponse.getResult().equalsIgnoreCase("success")) {
					isSucess = 1;
				}
			}
			profileResponse.setIsSuccess(isSucess);
		} else {
			logger.error("Do unsubscribe request param are missing callingNum ["
					+ profileRequest.getCallingNum()
					+ "] lang ["
					+ profileRequest.getLang()
					+ "] serviceType ["
					+ profileRequest.getServiceType() + "]");
			profileResponse.setIsSuccess(-1);
		}
	}

	public String getSubscribeJsonObj(ProfileRequest profileRequest) {
		this.gson = new Gson();
		VccRuleEngineRequest vccSubscribeRequest = new VccRuleEngineRequest();
		vccSubscribeRequest.setMsisdn(profileRequest.getCallingNum());
		vccSubscribeRequest.setServiceType(profileRequest.getServiceType());
		vccSubscribeRequest.setInterFace(AppConfig.config
				.getString("default_ret_interface"));
		vccSubscribeRequest.setChannel(AppConfig.config
				.getString("retrieval_channel"));
		vccSubscribeRequest.setTid(String.valueOf(System.nanoTime()));

		vccSubscribeRequest.setReqBy(profileRequest.getCallingNum());
		if (profileRequest.getServiceType().equals(
				AppConfig.config.getString("VN"))) {

			logger.info("[" + profileRequest.getCallingNum()
					+ "] VN default plan set for subscribe vn request");
			vccSubscribeRequest.setActionId(AppConfig.config
					.getString("vnsub_actionId"));
			vccSubscribeRequest.setPlanName(AppConfig.config
					.getString("VN_DEFAULT_PLAN"));

		} else if (profileRequest.getServiceType().equals(
				AppConfig.config.getString("VM"))
				&& profileRequest.getPlanName() != null
				&& profileRequest.getActTrg() != 0) {

			logger.info("[" + profileRequest.getCallingNum() + "] VM ["
					+ profileRequest.getPlanName()
					+ "] plan set for subscribe vm request and call trigger ["
					+ profileRequest.getActTrg() + "]");
			vccSubscribeRequest.setActionId(AppConfig.config
					.getString("vmsub_actionId"));
			vccSubscribeRequest.setPlanName(profileRequest.getPlanName());
			vccSubscribeRequest.setActTrg(profileRequest.getActTrg());

		} else {
			logger.info("[" + profileRequest.getCallingNum()
					+ "] VM default plan set for subscribe vm request ");
			vccSubscribeRequest.setPlanName(AppConfig.config
					.getString("VM_DEFAULT_PLAN"));
			vccSubscribeRequest.setActionId(AppConfig.config
					.getString("vmsub_actionId"));

		}
		vccSubscribeRequest.setLang(profileRequest.getLang());
		vccSubscribeRequest.setAppId(AppConfig.config.getString("app_id"));
		if(profileRequest.getSubType()!=null)
			vccSubscribeRequest.setSubType(profileRequest.getSubType());
		else
			vccSubscribeRequest.setSubType(AppConfig.config.getString("default_sub_type","N"));
		
		String jsonObj = this.gson.toJson(vccSubscribeRequest);
		return jsonObj;
	}

	public String getUnscribeJsonObj(ProfileRequest profileRequest) {
		this.gson = new Gson();
		VccRuleEngineRequest vccUnSubscribeRequest = new VccRuleEngineRequest();
		vccUnSubscribeRequest.setMsisdn(profileRequest.getCallingNum());
		vccUnSubscribeRequest.setServiceType(profileRequest.getServiceType());
		vccUnSubscribeRequest.setInterFace(AppConfig.config
				.getString("default_ret_interface"));
		vccUnSubscribeRequest.setChannel(AppConfig.config
				.getString("retrieval_channel"));
		vccUnSubscribeRequest.setTid(String.valueOf(System.nanoTime()));
		vccUnSubscribeRequest.setActionId(AppConfig.config
				.getString("unsub_actionId"));
		vccUnSubscribeRequest.setLang(profileRequest.getLang());
		vccUnSubscribeRequest.setAppId(AppConfig.config.getString("app_id"));
		if(profileRequest.getServiceType().equalsIgnoreCase(AppConfig.config.getString("VN","0100")));
			vccUnSubscribeRequest.setPlanName(AppConfig.config.getString("VN_default_plan","default"));
		String jsonObj = this.gson.toJson(vccUnSubscribeRequest);
		return jsonObj;
	}

	public void sendSubUnscribeRequest(String json) {
		TextSocketConnection socketConnection = null;
		String resonse = null;
		ConnectionPool connectionPool = null;
		try {
			connectionPool = TcpPool.getRuleEngineConPool();
			socketConnection = connectionPool.getConnection();
			if (connectionPool != null && socketConnection != null) {

				logger.info("Rule Engine Server has connected!\n");
				logger.info("Rule Engine Sending string: '" + json + "'\n");
				socketConnection.write(json);
				resonse = socketConnection.readLine();
				if (resonse != null) {
					this.subUnscribeResponse = this.gson.fromJson(resonse,
							VccRuleEngineResponse.class);
					logger.info(" Rule Engine response is: " + resonse);
				} else {
					logger.info("Rule engine response is : " + resonse);
				}
			} else {
				logger.error("Rule engine is not connected so can't be perform any operation");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// connectionPool.returnConnection(socketConnection);
				socketConnection.close();
			} catch (Exception e) {
				logger.error("Error in close connection os socket [" + e + "]");
			}
		}

	}

	public void tcpWithVccRule(String json) {
		Connection socketConnection = null;
		String response = null;
		edu.emory.mathcs.util.net.ConnectionPool connectionPool = null;
		Socket client = null;
		OutputStream outToServer = null;
		DataOutputStream out = null;
		InputStream inFromServer = null;
		DataInputStream in = null;

		try {
			connectionPool = TcpConnectionPool.getRuleEngineConPool();
			socketConnection = connectionPool.getConnection();
			if (connectionPool != null && socketConnection != null) {
				logger.info("Rule Engine Server has connected!\n");
				logger.info("Rule Engine Sending string: '" + json + "'\n");
				client = socketConnection.getSocket();
				client.setSoTimeout(AppConfig.config.getInt(
						"rule_engine_socket_timeout", 1000));
				outToServer = client.getOutputStream();
				out = new DataOutputStream(outToServer);
				out.writeUTF(json.toString());
				out.flush();
				inFromServer = client.getInputStream();
				in = new DataInputStream(inFromServer);
				response = in.readUTF();
				out.close();
				in.close();
				socketConnection.returnToPool();

				if (response != null) {
					this.subUnscribeResponse = this.gson.fromJson(response,
							VccRuleEngineResponse.class);
					logger.info(" Rule Engine response is: " + response);
				} else {
					logger.info("Rule engine response is : " + response);
				}
				try {
					logger.info("post delay after subscription/unsubcription for ["+AppConfig.config.getInt("post_delay_after_sub", 0)+"] sec");
					Thread.sleep(AppConfig.config.getInt("post_delay_after_sub", 0));
				} catch (Exception e) {
					logger.error(String.format(
							"wait for  post_delay_after_sub time [%s]  : ",
							AppConfig.config.getInt("post_delay_after_sub", 0)), e);

				}

				
			} else {
				
				logger.info("Rule is not connected so can't be perform any opearation ");
			}

		} catch (SocketTimeoutException e) {
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"90017] [SocketTimeout Exception while connecting to Rule Engine] Error["+ e.getMessage() +"]");

			if (socketConnection != null)
				socketConnection.close();
			try {
				if (out != null) {
					out.flush();
					out.close();
				}
				if (in != null)
					in.close();
				if (inFromServer != null)
					inFromServer.close();
				if (outToServer != null)
					outToServer.close();
			} catch (Exception e2) {

			}

			logger.error("Socket time out [" + e + "]");
		} catch (Exception e) {
			if (socketConnection != null)
				socketConnection.close();
			e.printStackTrace();
			errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00058] [Exception while connecting to Rule Engine] Error["+ e.getMessage() +"]");


		} finally {
			try {
				if (out != null)
					out.close();
				if (in != null)
					in.close();

			} catch (Exception e) {
				errorLogger.error("ErrorCode ["+AppConfig.config.getString("errorcode_pattern","VCC-IVRWAR-")+"00059] [Exception in closing socket connection with Rule Engine] Error["+ e.getMessage() +"]");

				logger.error("Error in closing socket connection [" + e + "]");
			}
		}
	}

}
