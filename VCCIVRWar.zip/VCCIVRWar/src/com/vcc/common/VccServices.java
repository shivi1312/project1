package com.vcc.common;

import org.springframework.beans.factory.annotation.Autowired;

import com.vcc.services.MessageService;
import com.vcc.services.UserConfigService;
import com.vcc.services.UserService;

public class VccServices {

	public UserService userService;
	public MessageService messageService;
	public UserConfigService userConfigService;
	@Autowired
	public VccServices(UserService userService, MessageService messageService,UserConfigService userConfigService) {
		this.userService = userService;
		this.messageService = messageService;
		this.userConfigService = userConfigService;
	}

}
