package com.vcc.net;

import java.io.IOException;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;

import org.apache.log4j.Logger;

import com.vcc.config.AppConfig;
import com.vcc.util.TcpPool;

/**
 * Created by tanujkumar on 02/07/15.
 */

public class ConnectionPool extends ExceptionIgnorer {
	final static Logger logger = Logger.getLogger(ConnectionPool.class);
	private static final int POOLSIZE_MINIMUM = 2;
	private static final int POOLSIZE_DEFAULT = 10;
	private volatile boolean creatingConnection = false;
	private volatile boolean reConnectConnection = false;
	private static final int maxRetryCount = 5;
	private static int retryCount = 0;
	private static final long retrySleepTime = 2000;
	private static final long sleepTimeAfterRetry = 10000;

	private int poolSize = 10;
	private int usedSlots = 0;

	private TextSocketConnection[] pool = null;

	private String hostname = null;
	private int port = 21000;

	protected int poolSize() {
		return this.poolSize;
	}

	protected void poolSize(int newPoolSize) {
		this.poolSize = newPoolSize;
	}

	protected synchronized int usedSlots() {
		return this.usedSlots;
	}

	protected void usedSlots(int newUsedSlots) {
		this.usedSlots = newUsedSlots;
	}

	protected TextSocketConnection[] pool() {
		return this.pool;
	}

	protected void pool(TextSocketConnection[] newPool) {
		this.pool = newPool;
	}

	protected String hostname() {
		return this.hostname;
	}

	protected void hostname(String newHostName) {
		this.hostname = newHostName;
	}

	protected int port() {
		return this.port;
	}

	protected void port(int newPort) {
		this.port = newPort;
	}

	public ConnectionPool(String hostname, int port) {
		this(hostname, port, 10);
	}

	public ConnectionPool(String hostname, int port, int poolLimit) {
		this(hostname, port, poolLimit, null);
	}

	public ConnectionPool(String hostname, int port,
			ExceptionHandler exceptionHandler) {
		this(hostname, port, 2, exceptionHandler);
	}

	public ConnectionPool(String hostname, int port, int poolLimit,
			ExceptionHandler exceptionHandler) {
		super(exceptionHandler);
		hostname(hostname);
		port(port);

		initPool(Math.max(2, poolLimit));
	}

	public TextSocketConnection getConnection() {
		TextSocketConnection conn = null;

		while (conn == null) {
			conn = findUnusedConnectionInPool();
		
			if (conn == null) {
				
				if (wantToCreateNewConnection()) {
					logger.info("***************Now going to create connection*****************");
					conn = newConnection();
					if (conn != null) {
						conn.inUse(true);
						addToPool(conn);
						this.creatingConnection = false;
					}
				}else
				{
					break;
				}
			}
		}
		return conn;
	}

	public void returnConnection(TextSocketConnection connection) {
		connection.inUse(false);
	}

	public void createConnections(int numberOfConnections) {
		int create = Math.min(poolSize(), numberOfConnections);
		for (int i = 1; i <= create; i++) {
			createConnectionInPool();
		}
	}

	public int numberOfPooledConnections() {
		return usedSlots();
	}

	protected TextSocketConnection newConnection() {
		TextSocketConnection conn = null;

		Socket socket = openSocket();
		if (socket != null) {
			conn = new TextSocketConnection(socket, exceptionHandler());
		}

		return conn;
	}

	protected Socket openSocket() {
		Socket socket = null;
		try {
			this.reConnectConnection = false;
			socket = new Socket(hostname(), port());
		} catch (ConnectException con) {
			this.reOpenSocket();
		} catch (UnknownHostException uhe) {
			exceptionOccurred(uhe);
		} catch (IOException ioe) {
			exceptionOccurred(ioe);
		}
		return socket;
	}

	protected void reOpenSocket() {
		retryCount++;
		this.reConnectConnection = true;
		System.out.println("retry enable is"
				+ AppConfig.config.getInt("retry_enable", 0)
				+ "max retry count"
				+ AppConfig.config.getInt("max_retry_count", 2));
		try {
			if (retryCount <= AppConfig.config.getInt("max_retry_count", 2)) {

				if (AppConfig.config.getInt("retry_enable", 0) == 0
						&& retryCount == AppConfig.config.getInt(
								"max_retry_count", 2)) {

					System.out.println("Inside else condition");
					this.reConnectConnection = false;
					Thread.sleep(retryCount);
				} else {
					Thread.sleep(AppConfig.config
							.getInt("retrySleepTime", 1000));
				}
				System.out.println("THread is going to sleep retry count ["
						+ retryCount + "]");
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception inside reOpenSocket()"
					+ e.getMessage());

		}
	}

	protected TextSocketConnection findUnusedConnectionInPool() {
		TextSocketConnection conn = null;
		for (int i = 0; i < this.poolSize; i++) {
			conn = this.pool[i];
			if (conn != null) {
				if (conn.isClosed()) {
					this.pool[i] = null;
					decUsedSlots();
				} else if (conn.wantToUse()) {
					return conn;
				}
			}
		}
		return null;
	}

	protected void addToPool(TextSocketConnection conn) {
		for (int i = 0; i < this.poolSize; i++) {
			if (this.pool[i] == null) {
				this.pool[i] = conn;
				incUsedSlots();
				return;
			}
		}
	}

	protected synchronized boolean wantToCreateNewConnection() {
		if (this.reConnectConnection) {
			return true;
		}
		if (!this.reConnectConnection
				&& AppConfig.config.getInt("retry_enable", 0) == 0
				&& AppConfig.config.getInt("max_retry_count", 2) == maxRetryCount) {
			return false;
		}

		if (this.creatingConnection) {
			return false;
		}

		if (poolIsFull()) {
			return false;
		}
		this.creatingConnection = true;
		return true;
	}

	protected boolean poolIsFull() {
		return usedSlots() == poolSize();
	}

	protected void initPool(int size) {
		poolSize(size);
		pool(new TextSocketConnection[size]);
		usedSlots(0);
	}

	protected void createConnectionInPool() {
		TextSocketConnection conn = newConnection();
		conn.getReader();
		conn.getWriter();
		conn.inUse(false);
		addToPool(conn);
	}

	protected synchronized void incUsedSlots() {
		this.usedSlots += 1;
	}

	protected synchronized void decUsedSlots() {
		this.usedSlots -= 1;
	}
}
