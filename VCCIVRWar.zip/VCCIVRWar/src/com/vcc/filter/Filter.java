package com.vcc.filter;

import org.springframework.validation.BindingResult;

import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;

public interface Filter {
	public void execute(ProfileRequest profileRequest, BindingResult bindingResult,
			ProfileResponse profileResponse, VmError vmError,
			VccServices vccServices);
	
	
}
