package com.vcc.filter;

import org.springframework.validation.BindingResult;

import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.request.ProfileRequest;
import com.vcc.response.ProfileResponse;

public class ProfileFilterManager {

	private static ProfileFilterManager instance = new ProfileFilterManager();
	private ProfileFilterChain profileFilterChain;

	public static ProfileFilterManager getInstance() {
		return instance;
	}

	public ProfileFilterManager() {
		profileFilterChain = new ProfileFilterChain();
	}

	public void setFilter(Filter profileFilter) {
		profileFilterChain.addFilter(profileFilter);
	}

	public void filterRequest(BindingResult bindingResult, VccServices vccServices,
			ProfileRequest profileRequest, ProfileResponse profileResponse, VmError error) {
		profileFilterChain.execute(bindingResult, vccServices, profileRequest,
				profileResponse, error);
	}
}
