package com.vcc.cache;

import com.telemune.vcc.expiringmap.ExpirationListener;

public class VccListener implements ExpirationListener<String, Object> {
	@Override
	public void expired(String key, Object value) {
		System.out.println("Expiring key: "+key+" value "+value);
	}
}
