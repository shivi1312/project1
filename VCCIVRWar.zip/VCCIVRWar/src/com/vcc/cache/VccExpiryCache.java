package com.vcc.cache;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.telemune.vcc.expiringmap.ExpiringMap;
import com.vcc.config.AppConfig;

public class VccExpiryCache {
	final static Logger logger = Logger.getLogger(VccExpiryCache.class);

	@Autowired
	AppConfig appConfig;
	public static ExpiringMap<String, Object> pxmlmap = null;
	public static ExpiringMap<String, String> sysmap = null;
	public static ExpiringMap<String, Object> dbmap = null;
	static {
		pxmlmap = ExpiringMap.builder().expirationListener(new VccListener())
				.variableExpiration().expiration(20, TimeUnit.MINUTES).build();

		sysmap = ExpiringMap.builder().expirationListener(new VccListener())
				.variableExpiration().expiration(24, TimeUnit.HOURS).build();
		
		dbmap = ExpiringMap.builder().expirationListener(new VccListener())
				.variableExpiration().expiration(24, TimeUnit.HOURS).build();
		

	}

	public static ExpiringMap<String, Object> getPxmlmap() {
			
		return pxmlmap;
	}
	
	public static ExpiringMap<String, Object> getGlobalmap() {
		
		if(dbmap.containsKey("vcc_series_range") && dbmap.containsKey("vcc_service_provider"))
		{
			logger.debug("Global cahce is alive");
			
		}else
		{
			logger.debug("Global cahce is not  alive");
			AppConfig.readSeriesRange();
			AppConfig.readServiceProvider();
		}
		return dbmap;
	}
	

	public static ExpiringMap<String, String> getSysmap() {
		if (sysmap.containsKey("vcc_rate_plan")
				&& sysmap.containsKey("vcc_charging_code")
				&& sysmap.containsKey("vcc_mailbox_param")) {
			logger.debug("cahce is alive");

			return sysmap;
		} else {
			logger.debug("cahce is not alive");
			AppConfig.readChargingCode();
			AppConfig.readMailBoxParam();
			AppConfig.readRatePlan();
			AppConfig.readDatabaseConfig();
			return sysmap;
		}
	}

}
