package com.vcc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.vcc.model.VccServiceProvider;


public class VccServiceProviderRowMapper implements RowMapper<VccServiceProvider> {
	@Override
	public VccServiceProvider mapRow(ResultSet rs, int rownumber) throws SQLException {
		VccServiceProvider vcc = new VccServiceProvider();
		vcc.setServiceId(rs.getInt("SERVICE_ID"));
		vcc.setServiceOffer(rs.getString("SERVICE_OFFER"));
		vcc.setSubscription(rs.getString("SUBSCRIPTION"));
		vcc.setPriority(rs.getInt("PRIORITY"));
		vcc.setNotification(rs.getString("NOTIFICATION"));
		vcc.setServiceDefined(rs.getString("SERVICE_DEFINED"));
		return vcc;
	};
}
