package com.vcc.dao;

import java.util.List;

import com.vcc.model.VccAuthUser;
import com.vcc.model.VccClassType;
import com.vcc.model.VccFwdCallLogs;
import com.vcc.model.VccPersonalGreeting;
import com.vcc.model.VccSeriesRange;
import com.vcc.model.VccServiceProvider;
import com.vcc.model.VccSubscriptionMaster;
import com.vcc.model.VccUserCompleteDetails;
import com.vcc.model.VccVoiceMessage;
import com.vcc.request.ProfileRequest;
import com.vcc.request.RetLogRequest;
import com.vcc.request.VccGreetingRequest;
import com.vcc.request.VmRequest;
import com.vcc.response.ProfileResponse;

/*
 * Implement this interface for all provision and deprovision
 * and saved or delete voice mail
 * */
public interface ProfileDao {

	public int getNextIndex(String msisdn,String serviceType);

	
	public int insertVoiceMessage(VccVoiceMessage vmsMessage);

	public List<VccSubscriptionMaster> getActiveServiceList(
			ProfileRequest profileRequest);

	public List<VccServiceProvider> getServiceList(ProfileRequest profileRequest);

	public List<VccSeriesRange> isUserExistWithInRange(
			String msisdn);

	public VccClassType haveAnyClass(ProfileRequest profileRequest);

	public boolean isUserIsOptedOut(ProfileRequest profileRequest,
			ProfileResponse profileResponse);

	public VccAuthUser getProfileDetailByCallingNum(ProfileRequest profileRequest);
	
	
	public VccAuthUser getProfileDetailByCalledNum(ProfileRequest profileRequest);

	public List<VccVoiceMessage> getMailboxGroupByCount(
			String msisdn, String serviceType);

	public int getVoiceMsgIndex(VmRequest vmRequest);

	public List<VccVoiceMessage> getMailboxOrderByCallTime(String msisdn,String serviceType);

	public List<VccVoiceMessage> getMailboxOrderBySendTime(VmRequest request);

	public Boolean deleteVccVoiceMessage(String calledNum, int voiceMsgIndex);

	public int insertFwdCallLogs(VccFwdCallLogs fwdCallLogs);

	public VccSubscriptionMaster getActiveUserByServiceType(
			String msisdn,String serviceType);

	public int updateUserLanguage(ProfileRequest profileRequest);

	public boolean isUserSubscribe(String msisdn ,String serviceType);

	public int saveRetrievalLog(RetLogRequest retLogRequest);

	public int updateVoiceMsgStatus(VmRequest vmRequest, String status);

	public List<VccUserCompleteDetails> getUserCompleteDetail(String msisdn);

	public int saveVccNotification(VccVoiceMessage vccVoiceMessage,
			VccUserCompleteDetails userCompleteDetails);
	
	public boolean updateUserPassword(ProfileRequest profileRequest);
	
	public boolean saveUserGreeting(VccGreetingRequest greetingRequest);
	
	public boolean deleteUserGreeting(VccGreetingRequest greetingRequest);
	
	public VccPersonalGreeting getUserGreeting(String msisdn);
	
	public boolean updatePersonalGreeting(VccGreetingRequest greetingRequest);
	
	public boolean updateGreetingType(int greetingType,String msisdn);
	
	public boolean updateLastVisitTime(String msisdn);
	
}
