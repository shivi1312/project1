package com.vcc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.vcc.model.VccRatePlan;

public class VccRatePlanRowMapper implements RowMapper<VccRatePlan> {
	@Override
	public VccRatePlan mapRow(ResultSet rs, int rownumber) throws SQLException {
		VccRatePlan vcc = new VccRatePlan();
		vcc.setPlanId(rs.getInt("PLAN_ID"));
		vcc.setSubCode(rs.getInt("SUB_CODE"));
		vcc.setSubValidity(rs.getInt("SUB_VALIDITY"));
		vcc.setRenew(rs.getInt("RENEW"));
		vcc.setRenewValidity(rs.getInt("RENEW_VALIDITY"));
		vcc.setRecordCode(rs.getInt("RECORD_CODE"));
		vcc.setGroupRecordCode(rs.getInt("GROUP_RECORD_CODE"));
		vcc.setServiceType(rs.getString("SERVICE_TYPE"));
		vcc.setPullSmsCode(rs.getInt("PULL_SMS_CODE"));
		vcc.setPlanName(rs.getString("PLAN_NAME"));
		vcc.setScope(rs.getString("SCOPE"));
		vcc.setMailBoxId(rs.getInt("MAILBOX_ID"));
		return vcc;
	};

}
