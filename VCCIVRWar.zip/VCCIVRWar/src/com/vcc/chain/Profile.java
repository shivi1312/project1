package com.vcc.chain;


public interface Profile {
	
}
