package com.vcc.chain;

import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.request.VmRequest;
import com.vcc.response.VmResponse;

public interface VmChain {

	public abstract void setNext(VmChain nextInVmChain,
			VccServices vccServices);

	public abstract void process(VmRequest vmRequest, VmResponse vmResponse,
			VmError vmError);



}
