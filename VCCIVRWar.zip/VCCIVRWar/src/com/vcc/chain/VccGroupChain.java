package com.vcc.chain;

import com.vcc.common.VccServices;
import com.vcc.error.VmError;
import com.vcc.request.UserConfigRequest;
import com.vcc.response.UserConfigResponse;

public interface VccGroupChain {

	public abstract void setNext(VccGroupChain nextInVmChain,
		 VccServices vccServices);

	public abstract void process(UserConfigRequest configRequest, UserConfigResponse configResponse,
			VmError vmError);
	
	
}
