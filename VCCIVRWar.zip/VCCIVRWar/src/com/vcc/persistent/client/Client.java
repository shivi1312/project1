package com.vcc.persistent.client;

public abstract interface Client {
	public void write(String value);
	public String writeAsSync(String value);
	public void closeSession();
}
