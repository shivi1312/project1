package com.vcc.error;

public class VmError implements java.io.Serializable {

	private static final long serialVersionUID = -2300493624348029860L;
	private boolean error;
	private String msg;
	
	public boolean getError() {
		return error;
	}
	public void setError(boolean error) {
		this.error = error;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
}
