package com.telemune.client;


import java.io.*;
import java.sql.*;
import java.net.*;
import java.util.*;

import chargingserver.Data_Object;
import chargingserver.Global;

import org.apache.log4j.Logger;

import commonutil.TLVAppInterface;
//import TlvLib;


// **** get data from server........ ******
class USSDCall //implements Runnable 
{
	static final Logger logger=Logger.getLogger("USSDCall");
	static Thread thrd;
	static	Socket socket_me;
	static	DataOutputStream stream_send_data;
	public static int MSISDN_TAG=1;
	public static int DATA_TAG=2;
	public static int DIG_ID_TAG=4;
	public static int OP_CODE_TAG=3;
	public int timeout=10000;// 10 sec timeout


	public USSDCall(int timeout)
	{
		try
		{
			this.timeout=timeout;
			socket_me=new Socket(Global.USSD_HOST,Global.USSD_PORT);
//			socket_me.setSoTimeout(Global.axis_request_timeout);
			socket_me.setSoTimeout(this.timeout);
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}

	}
	
	static DataInputStream reader = null;
	//public static void main(String name[])
	//	public void callUSSD(String name[])
	public String callUSSD(String source_msisdn,int dialog_id,int op_code_id,String command)
	{
		String res="failure";
		logger.info("******************Inside Call USSD ***********");
		try
		{

			System.out.println("Send Que is NOT Empty");




			TLVAppInterface send_request = new TLVAppInterface();
			//	String source_msisdn="";
			ByteArrayOutputStream send_buf = new ByteArrayOutputStream();


			send_request.setData(MSISDN_TAG,source_msisdn);
			send_request.setData(DATA_TAG,command);
			send_request.setData(DIG_ID_TAG,dialog_id);
			send_request.setData(OP_CODE_TAG,op_code_id);

			send_request.encode(send_buf);
			System.out.println("packet Socket is==="+socket_me.toString());

			int send_requestLen = send_buf.size();
			try{

				if (socket_me.isClosed())
				{
					// write data in file
					socket_me=new Socket(Global.USSD_HOST,Global.USSD_PORT);
				}

				stream_send_data = new DataOutputStream(socket_me.getOutputStream());
				System.out.println("writing Info buf size="+send_requestLen);
				byte[] len=new byte[4];
				len[3]=(byte)(send_requestLen );
				len[2]=(byte)((send_requestLen >> 8) );
				len[1]=(byte)((send_requestLen >> 16));
				len[0]=(byte)((send_requestLen >> 24));
				stream_send_data.write(len,0, 4);
				//		stream_send_data.writeInt(send_requestLen);
				System.out.println("Data length sent of  buf size="+send_requestLen);
				stream_send_data.write(send_buf.toByteArray(), 0, send_buf.toByteArray().length);
				send_request=null;
			}
			catch(Exception eee)
			{
				try
				{
					System.out.println("Exception Sending Data:: "+eee.toString());
					socket_me.close();
					return res;
				}
				catch(Exception e)
				{
					System.out.println(e);
				}

				//return;
			}

			//break;  //Uncommented just for compile otherwise no need to be here ....
			//TLVAppInterface tcp_req =new TLVAppInterface();


			try
			{
				if (socket_me.isClosed() || !socket_me.isConnected() || socket_me.isOutputShutdown() || socket_me.isInputShutdown())
				{
					System.out.println("Socket closed");
					socket_me=new Socket(Global.USSD_HOST,Global.USSD_PORT);
					res="failure";
					return res;
				}
				else
				{

					reader = new DataInputStream(socket_me.getInputStream());	
					ByteArrayInputStream inbuf = null;
					System.out.println("reading Info ........");
					System.out.println("Socket==="+socket_me.toString());
					byte dataBuf1[] = new byte[4];
					int dataLen =0;
					try
					{

						if(reader.read(dataBuf1,0,4)==-1)
						{
							System.out.println("reader.read == -1 ...");
							try
							{
								socket_me.close();
								System.out.println("Destroy");
								System.out.println("socket closed");
								thrd.stop();
								res="failure";
								return res;
							}
							catch(Exception e)
							{
								System.out.println(e);
							}

						}
						int test=0;
						dataLen = dataLen | (dataBuf1[0] << 24);
						dataLen = dataLen  | (dataBuf1[1] << 16);
						dataLen = dataLen | (dataBuf1[2] << 8);
						test=(0x000000ff & dataBuf1[3]);
						dataLen = dataLen | test;
						System.out.println("reading Info ......data len.."+dataLen);
					}
					catch (Exception e)
					{
						System.out.println("Getting exception in reading...."+e.toString());
						try
						{
							thrd.sleep(1);
							socket_me.close();

						}
						catch(Exception eee)
						{
							System.out.println("Sleep Exception in main");
						}	
					}
					if (dataLen==0)
					{	try
					{
						System.out.println("Sleeping.....n");
					}
					catch(Exception eee)
					{
						System.out.println("Sleep Exception in main");
					}
					}
					try
					{

						System.out.println("recieved tcp_req size="+dataLen);
						byte dataBuf[] = new byte[dataLen];

						reader.read(dataBuf, 0, dataLen);

						inbuf = new ByteArrayInputStream(dataBuf);
						TLVAppInterface send_request_decode = new TLVAppInterface();
						send_request_decode.decode(inbuf,dataLen);
						/*	System.out.println("Source "+ tcp_req.getData(SRC_TAG));
							System.out.println("Destination "+ tcp_req.getData(DEST_TAG));
							System.out.println("TEXT "+ tcp_req.getData(TEXT_TAG));
							System.out.println("RESPONSE "+ tcp_req.getData(RESPONSE_TAG));
						 */
						System.out.println("MSISDN"+send_request_decode.getData(MSISDN_TAG));
						System.out.println("DATA"+send_request_decode.getData(DATA_TAG));
						System.out.println("DIALOG ID"+send_request_decode.getData(DIG_ID_TAG));
						System.out.println("OP_CODE"+send_request_decode.getData(OP_CODE_TAG));       
						System.out.println("Element is inserted in the queue...");

						String data=send_request_decode.getData(DATA_TAG);
						String[] balArry=null;
						logger.info("Data Return From Gateway is::: "+data);
						if(data.contains(";"))
						{

							balArry=data.split(";");
							logger.info("If Data Got from USSD Gateway ---------->>"+balArry[0]);
							res=balArry[0];
							//return res;
						}
						else if(data.equalsIgnoreCase("-1"))
						{
							return "retry";
						}
						else
						{
							res="failure";
							//return res;
						}
						send_request_decode=null;
					}
					catch(SocketTimeoutException timeOut)
					{
						logger.error("Exception occurr due socket time out inside try1............",timeOut);
						try
						{
							//thrd.sleep(1);
							socket_me.close();

						}
						catch(Exception eee)
						{
							System.out.println("Sleep Exception in main");
						}
						return "failure";


					}

					catch (Exception e)
					{
						res="failure";
						System.out.println("Getting exception in reading...."+e.toString());
						try
						{
							thrd.sleep(1);
							socket_me.close();

						}
						catch(Exception eee)
						{
							System.out.println("Sleep Exception in main");
						}	
					}
				}
				return res;
			}

			catch(Exception e)
			{
				System.out.println("got exception ......"+e.toString());
				e.printStackTrace();
				return res;
			}

		}
		catch(Exception e)
		{
			System.out.println("got exception ......"+e.toString());
			e.printStackTrace();
			return res;
		}

	}



	private void checkConnection()
	{
		try
		{
			logger.error("check for socket "+socket_me);
			if(socket_me!=null)
			{
				if(socket_me.isClosed() || !socket_me.isConnected() || socket_me.isOutputShutdown() || socket_me.isInputShutdown())
				{
					logger.error("socket is closed so reconnecting ");
					socket_me=new Socket(Global.USSD_HOST,Global.USSD_PORT);
//					socket_me.setSoTimeout(Global.axis_request_timeout);
					socket_me.setSoTimeout(this.timeout);
				}
			}
			else
			{
				socket_me=new Socket(Global.USSD_HOST,Global.USSD_PORT);
//				socket_me.setSoTimeout(Global.axis_request_timeout);
				socket_me.setSoTimeout(this.timeout);
			}
		}
		catch(Exception e)
		{
			logger.info("Exception Inside ",e);
		}

	}



//	public int   checkAndDeductBal(String msisdn,int opCode,float amount)
	public int checkAndDeductBal(String msisdn,int opCode,double amount) // modified by Avishkar on 24-02-2022
	{
		logger.info("Inside CheckandDeduct Balance :::: Msisdn is: ["+msisdn +"] OPCode is:: "+opCode);
		int amt=-1;
		String res="failure";
		try
		{
			String source_msisdn="";

			String response_data="";
			int dialog_id=5;
			int op_code_id=opCode;
			//	amt=amount;pri
			String command=""; 
			source_msisdn=msisdn;
			
			logger.info("Dialogue Id iN Deduct Bal: "+dialog_id);
			checkConnection();
			command=Global.deduct_balCommand+"*"+source_msisdn+"*"+amount+"*45TW#";
			logger.info("Command In Deduct  Balance is:: "+command);





			if(Global.TESTCASE!=1)
			{

				for(int count=1;count<=Global.TOTAL_REQ_COUNT;count++)
				{
					logger.info("------ SENDING REQUEST TO USSD CHARGING FOR CHECK BALANCE And Deduct Balance ["+count+"] NUMBER OF TIMES ----------");
					checkConnection();
					dialog_id=Global.getDailogId();
					res=this.callUSSD(source_msisdn, dialog_id, op_code_id,command);
					if(res.equalsIgnoreCase("failure"))
					{
						amt=-1;
						break;	
					}
					else if(res.equalsIgnoreCase("retry"))
					{
						continue;
					}
					else
					{
						logger.info(">>>msisdn["+msisdn+"] Success Return From Gateway In check and deduct Balance ");
						amt=1;
						break;
					}
				}	
			}
			else
			{
				amt=1;					
			}
		}
		catch(Exception e)
		{
			logger.info("Exception Inside checkAndDeductBal ",e);
		}
		return amt;
	}

//	public int checkBal(String msisdn,int opCode,AmountBean amountBean)
	public double checkBal(String msisdn,int opCode) // modified by Avishkar on 24-02-2022
	{
		logger.info("Inside Check Balance Msisdn is: ["+msisdn+"] || OPCode is:: ["+opCode+"]");
//		int amt=-1;
		double amt=-1;
		//int amt=1;//for testing
		String res="failure";
		try
		{
			String source_msisdn="";

			String response_data="";
			int dialog_id=5;
			int op_code_id=opCode;
			int amount=0;
			String command=""; 
			source_msisdn=msisdn;
			dialog_id=Global.getDailogId();;
			logger.info("Dialogue Id iN Check Bal: "+dialog_id);

			checkConnection();
			command=Global.deduct_balCommand+"*"+source_msisdn+"*45TW#";
			logger.info("Command In Check Balance is:: "+command);



			
			
			if(Global.TESTCASE!=1)
			{

				for(int count=1;count<=Global.TOTAL_REQ_COUNT;count++)
				{
					logger.info("------ SENDING REQUEST TO USSD CHARGING FOR CHECK BALANCE And Deduct Balance ["+count+"] NUMBER OF TIMES ----------");
					checkConnection();
					dialog_id=Global.getDailogId();;
					res=this.callUSSD(source_msisdn, dialog_id, op_code_id,command);
					if(res.equalsIgnoreCase("failure"))
					{
						amt=-1;
						break;	
					}
					else if(res.equalsIgnoreCase("retry"))
					{
						continue;
					}
					else
					{
						amt=Double.parseDouble(res);
//						amountBean.setBalance(Float.parseFloat(res));
//						logger.info("Success Return From Gateway In check Balance Amount is: "+Float.parseFloat(res));
						logger.info(">>>msisdn["+msisdn+"] Success Return From Gateway In check Balance Amount is: "+amt);
//						amt=1;
						break;
					}
				}	
			}
			else
			{
				amt=1;					
			}
			
		}
		catch(Exception e)
		{
			logger.info("Exception Inside ",e);
		}
		return amt;

	}

}
