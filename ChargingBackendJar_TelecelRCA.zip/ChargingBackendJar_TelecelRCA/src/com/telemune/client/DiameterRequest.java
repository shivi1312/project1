package com.telemune.client;

import dk.i1.diameter.*;
import dk.i1.diameter.node.*;
import org.apache.log4j.Logger;
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.util.logging.LogManager;
//import java.util.logging.Logger;
//import java.util.logging.ConsoleHandler;
//import java.util.logging.FileHandler;
//import java.util.logging.Handler;
//import java.util.logging.Level;

import chargingserver.Global;
/**
 * A simple client that issues a CCR (credit-control request)
 */
// Diameter not required for this site
public class DiameterRequest {/* // make default to public by Avishkar on 17.10.2018
	static Logger logger = Logger.getLogger("DiameterRequest");
	SimpleSyncClient ssc =null;
	Peer peer[]=null;
	
	//modification start by Avishkar on 23.10.2018
	String host_id = null;
    String realm = null;
    String dest_host = null;
    String dest_realm = null;
    int dest_port = 0;
    int host_port = 0;
    int vendor_id = 0;
    //modification ends by Avishkar on 23.10.2018

	public DiameterRequest()
	{
		
		//Peer peers[]=null;
		
		//Below code is commented by Avishkar on 17.10.2018
		logger = Logger.getLogger("DiameterRequest");      
		try {

			LogManager.getLogManager().readConfiguration(new FileInputStream("properties/mylogging.properties"));

		}
		catch ( IOException e1) {
			e1.printStackTrace();
		}		
		// Comments end by Avishkar on 17.10.2018
		
		
		host_id = Global.ORIGIN_HOST;
		realm = Global.ORIGIN_REALM;
		host_port = Global.HOST_PORT; // added by Avishkar on 23.10.2018
		dest_host = Global.DEST_HOST;
		dest_realm = Global.DEST_REALM; // added by Avishkar on 23.10.2018
		dest_port =Global.DEST_PORT;
		vendor_id = Global.VENDOR_ID; // added by Avishkar on 23.10.2018

		System.out.println("host_id["+host_id+"] realm["+realm+"] host_port["+host_port+"] dest_host["+dest_host+"] dest_realm["+dest_realm+"] dest_port["+dest_port+"] vendor-id["+vendor_id+"]"); // modified by Avishkar on 23.10.2018	
		logger.info("host_id["+host_id+"] realm["+realm+"] host_port["+host_port+"] dest_host["+dest_host+"] dest_realm["+dest_realm+"] dest_port["+dest_port+"] vendor-id["+vendor_id+"]"); // added by Avishkar on 17.10.2018s

		Capability capability = new Capability();
		capability.addAuthApp(ProtocolConstants.DIAMETER_APPLICATION_CREDIT_CONTROL);
		//capability.addAuthApp(ProtocolConstants.DIAMETER_APPLICATION_EAP);
		//capability.addAcctApp(ProtocolConstants.DIAMETER_APPLICATION_CREDIT_CONTROL);

		System.out.println("going to create node Setting....");
		logger.info("going to create node Setting...."); // added by Avishkar on 17.10.2018
		NodeSettings node_settings;
		try {
			node_settings  = new NodeSettings(
					host_id, realm,
					vendor_id, //vendor-id 4646 // modified by Avishkar on 23.10.2018
					capability,
					host_port, //hostPort 20012 // modified by Avishkar on 23.10.2018
					"cc_test_client", 0x01000000);
		} catch (InvalidSettingException e) {
			System.out.println(e.toString());
			logger.error(e.toString()); // added by Avishkar on 17.10.2018
			e.printStackTrace();
			return;
		}

		 System.out.println("node setting created successfully..");
		 logger.info("node setting created successfully.."); // added by Avishkar on 17.10.2018
		try
		{

			Peer peers[]= new Peer[]{new Peer(dest_host,dest_port)};
			 System.out.println("going to create SimpleSyncClient");
			 logger.info("going to create SimpleSyncClient"); // added by Avishkar on 17.10.2018
			ssc = new SimpleSyncClient(node_settings,peers);
			ssc.start();
			 System.out.println("waiting for connection"); // added by Avishkar on 17.10.2018
			 logger.info("waiting for connection");
			ssc.waitForConnection(); //allow connection to be established.


			System.out.println("Now send request for deduct of Amount");
			logger.info("Now send request for deduct of Amount"); // added by Avishkar on 17.10.2018
		}
		catch(Exception e)
		{
			System.out.println("Exception inside DiameterRequest Conc ");
			logger.error("Exception inside DiameterRequest Conc "); // added by Avishkar on 17.10.2018
			e.printStackTrace();
		}

		 System.out.println("SimpleSyncClient created successfully");
		 logger.info("SimpleSyncClient created successfully"); // added by Avishkar on 17.10.2018
	}

	*//**
	 * @author avishkar
	 * Below method is added to get International Number of the msisdn
	 * @param msisdn
	 * @return
	 *//*
	public String  getInternationalNumber(String msisdn){
		logger.info(">> converting msisdn to international number : msisdn ["+msisdn+"]");
		String countryCode =  null;
		String retVal = "";
		try {
			countryCode=Global.country_code.get("COUNTRY_CODE_1").trim();
			//countryCode=Global.COUNTRY_CODE.trim();
			 
		    logger.info("["+msisdn+"] "+"country code :["+countryCode+"]");

		    retVal = msisdn.startsWith("00") || msisdn.startsWith(countryCode) ? msisdn : (msisdn.startsWith("0") ? countryCode + msisdn.substring(1) : countryCode + msisdn);
		    //logger.info("["+uuid+"] "+"International Number :"+retVal);
		    logger.info("International msisdn :  "+retVal);
		} catch (Exception e) {
			logger.error("##>>> msisdn["+msisdn+"] Exception inside getInternationalNumber method : ",e);
			System.out.println("##>>> msisdn["+msisdn+"] Exception inside getInternationalNumber method : "+e);
			e.printStackTrace();
		}
		 
        return retVal;  
	}

	public  synchronized int debitRequest (String msisdn,float Balance,int aVPCode,String rbtCode,String cpId){

		logger.info("##>> msisdn["+msisdn +"] Inside debitRequest method ... Amount ["+Balance/1000+"] AvpCode ["+aVPCode+"] RbtCode ["+rbtCode+"] CP Id ["+cpId+"]"); // modified by Avishkar on 17.10.2018	
		String l_msisdn=msisdn;
		String resultString="NA"; // added by Avishkar on 17.10.2018
		//int currencyCode = Global.CURRENCY_CODE;// added by Avishkar on 23.10.2018 // not required for this site
		
		//modification done by Avishkar on 23.10.2018
			
			if (Global.COUNTRY_CODE_ENABLE==1) { // value 1 means msisdn with countryCode allowed
				l_msisdn=getInternationalNumber(msisdn);
				logger.info(">>>MSISDN with countryCode : "+l_msisdn);
			}
			else {   // CC_CODE_ENABLE value other than 1 means msisdn with countryCode not allowed
				
				if (msisdn.length()>Global.MSISDN_MIN_LENGTH && msisdn.length()==Global.MSISDN_MAX_LENGTH) {
					l_msisdn=msisdn.substring(3);
					logger.info(">>>MSISDN without country code : "+l_msisdn);
				}
			}
		//modification end by Avishkar on 23.10.2018
		
		if(msisdn.length()>10)  // commented by Avishkar on 23.10.2018
		{
			l_msisdn=msisdn.substring(3); }
		
			msisdn=l_msisdn;

			int balance=(int)Balance;
			int l_result=-1;
			//Build Credit-Control Request
			// <Credit-Control-Request> ::= < Diameter Header: 272, REQ, PXY >
			Message ccr = new Message();
			ccr.hdr.command_code = ProtocolConstants.DIAMETER_COMMAND_CC;
			ccr.hdr.application_id = ProtocolConstants.DIAMETER_APPLICATION_CREDIT_CONTROL;
			ccr.hdr.setRequest(true);
			ccr.hdr.setProxiable(true);
			//  < Session-Id >
			ccr.add(new AVP_UTF8String(ProtocolConstants.DI_SESSION_ID,ssc.node().makeNewSessionId()));
			//  { Origin-Host }
			//  { Origin-Realm }
			ssc.node().addOurHostAndRealm(ccr);
			//  { Destination-Realm }
			//ccr.add(new AVP_UTF8String(ProtocolConstants.DI_DESTINATION_REALM,"www.huawei.com"));
			ccr.add(new AVP_UTF8String(ProtocolConstants.DI_DESTINATION_REALM,dest_realm)); //"www.cbpadpt451.com")); // modified by Avishkar on 23.10.2018
			ccr.add(new AVP_UTF8String(ProtocolConstants.DI_DESTINATION_HOST,dest_host)); //Global.DEST_HOST)); //cbpadpt451 // modified by Avishkar on 23.10.2018
			//  { Auth-Application-Id }
			ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_AUTH_APPLICATION_ID,ProtocolConstants.DIAMETER_APPLICATION_CREDIT_CONTROL)); // a lie but a minor one
			//  { Service-Context-Id }
			ccr.add(new AVP_UTF8String(ProtocolConstants.DI_SERVICE_CONTEXT_ID,realm)); //Global.ORIGIN_REALM)); //modified by Avishkar on 23.10.2018
			//  { CC-Request-Type }
			ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_CC_REQUEST_TYPE,ProtocolConstants.DI_CC_REQUEST_TYPE_EVENT_REQUEST));;
			//  { CC-Request-Number }
			ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_CC_REQUEST_NUMBER,0));
			//  [ Destination-Host ]
			//  [ User-Name ]
			ccr.add(new AVP_UTF8String(ProtocolConstants.DI_USER_NAME,realm)); //Global.ORIGIN_REALM)); //modified by Avishkar on 23.10.2018
			//  [ CC-Sub-Session-Id ]
			//  [ Acct-Multi-Session-Id ]
			//  [ Origin-State-Id ]
			ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_ORIGIN_STATE_ID,ssc.node().stateId()));
			//  [ Event-Timestamp ]
			ccr.add(new AVP_Time(ProtocolConstants.DI_EVENT_TIMESTAMP,(int)(System.currentTimeMillis()/1000)));

			//ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_SERVICE_IDENTIFIER,0));
			// *[ Subscription-Id ]
			//  [ Service-Identifier ]
			//  [ Termination-Cause ]
			//  [ Requested-Service-Unit ]
					ccr.add(new AVP_Grouped(ProtocolConstants.DI_REQUESTED_SERVICE_UNIT,
					new AVP[] {new AVP_Unsigned64(ProtocolConstants.DI_CC_SERVICE_SPECIFIC_UNITS,42)}
					)
					);
					
			//  [ Requested-Action ]
			//
			//ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_RATING_GROUP,aVPCode));


			ccr.add(new AVP_Grouped(873,new AVP[] {	
						new AVP_Grouped(20600,new AVP[]
							{new AVP_UTF8String(20601,cpId+"").setM(),new AVP_UTF8String(20640,rbtCode).setM(),new AVP_UTF8String(20639,aVPCode+"").setM()}).setM()}).setM());
							//{new AVP_UTF8String(20639,cpId+"").setM(),new AVP_UTF8String(20640,rbtCode).setM(),new AVP_UTF8String(20601,aVPCode+"").setM()}).setM()}).setM());





			ccr.add(new AVP_Unsigned32(20639,aVPCode));


			  System.out.println("RbtCode is: "+rbtCode+" CpId is: "+cpId);
			  ccr.add(new AVP_Unsigned32(20640,Integer.parseInt(rbtCode))); 
			  ccr.add(new AVP_Unsigned32(20601,Integer.parseInt(cpId)));

			ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_REQUESTED_ACTION,ProtocolConstants.DI_REQUESTED_ACTION_DIRECT_DEBITING));
			// *[ Used-Service-Unit ]
			//  [ Multiple-Services-Indicator ]
			// *[ Multiple-Services-Credit-Control ]
			// *[ Service-Parameter-Info ]
					ccr.add(new AVP_Grouped(ProtocolConstants.DI_SERVICE_PARAMETER_INFO,
					new AVP[] {new AVP_Unsigned32(ProtocolConstants.DI_SERVICE_PARAMETER_TYPE,42),
					new AVP_UTF8String(ProtocolConstants.DI_SERVICE_PARAMETER_VALUE,"Hovercraft")
					}
					)
					);
					
			//  [ CC-Correlation-Id ]
			//  [ User-Equipment-Info ]
			// *[ Proxy-Info ]
			// *[ Route-Record ]
			// *[ AVP ]
			ccr.add(new AVP_Grouped(ProtocolConstants.DI_SUBSCRIPTION_ID,new AVP[] {										                   new AVP_Unsigned32(ProtocolConstants.DI_SUBSCRIPTION_ID_TYPE,0).setM(),                     new AVP_UTF8String(ProtocolConstants.DI_SUBSCRIPTION_ID_DATA,l_msisdn).setM()}).setM());
			ccr.add(
					new AVP_Grouped(ProtocolConstants.DI_REQUESTED_SERVICE_UNIT,
						new AVP[] {new  AVP_Grouped(ProtocolConstants.DI_CC_MONEY,
							new AVP[]{new AVP_Grouped(ProtocolConstants.DI_UNIT_VALUE,
								new AVP[]{  new AVP_Unsigned64(ProtocolConstants.DI_VALUE_DIGITS,balance).setM()}
								).setM()}
							).setM()}
						).setM());


			Utils.setMandatory_RFC3588(ccr);
			Utils.setMandatory_RFC4006(ccr);
			logger.debug("##>>> msisdn["+msisdn+"] All Paramters are set Now send the request"); // modified by Avishkar on 17.10.2018

			//Send it
			Message cca = ssc.sendRequest(ccr);
			logger.info("##>>> msisdn["+msisdn+"] Diameter Debit - Request Sent"); // modified by Avishkar on 17.10.2018

			//Now look at the result
			if(cca==null) {
				resultString="##>>> msisdn["+msisdn+"] Diameter Debit - No response"; // modified by Avishkar on 17.10.2018
				return l_result;
			}
			AVP result_code = cca.find(ProtocolConstants.DI_RESULT_CODE);
			if(result_code==null) {
				resultString="##>>> msisdn["+msisdn+"] Diameter Debit - No result code"; // modified by Avishkar on 17.10.2018
				return l_result;
			}
			try {
				AVP_Unsigned32 result_code_u32 = new AVP_Unsigned32(result_code);
				int rc = result_code_u32.queryValue();
				logger.info("##>>> msisdn["+msisdn+"] Diameter Debit - response from the server ================="+rc); // modified by Avishkar on 17.10.2018
				switch(rc) {
					case ProtocolConstants.DIAMETER_RESULT_SUCCESS:
						resultString="##>>> msisdn["+msisdn+"] Diameter Debit - ResultCode["+rc+"] ResultString[SUCCESS]"; // modified by Avishkar on 17.10.2018
						l_result=1;
						break;
					case ProtocolConstants.DIAMETER_RESULT_END_USER_SERVICE_DENIED:
						resultString="##>>> msisdn["+msisdn+"] Diameter Debit - ResultCode["+rc+"] ResultString[End user service denied]"; // modified by Avishkar on 17.10.2018
						l_result=-1;
						break;
					case ProtocolConstants.DIAMETER_RESULT_CREDIT_CONTROL_NOT_APPLICABLE:
						resultString="##>>> msisdn["+msisdn+"] Diameter Debit - ResultCode["+rc+"] ResultString[Credit-control not applicable]"; // modified by Avishkar on 17.10.2018
						l_result=-1;
						break;
					case ProtocolConstants.DIAMETER_RESULT_CREDIT_LIMIT_REACHED:
						resultString="##>>> msisdn["+msisdn+"] Diameter Debit - ResultCode["+rc+"] ResultString[Credit-limit reached]"; // modified by Avishkar on 17.10.2018
						l_result=-1;
						break;
					case ProtocolConstants.DIAMETER_RESULT_USER_UNKNOWN:
						resultString="##>>> msisdn["+msisdn+"] Diameter Debit - ResultCode["+rc+"] ResultString[User unknown]"; // modified by Avishkar on 17.10.2018
						l_result=-1;
						break;
					case ProtocolConstants.DIAMETER_RESULT_RATING_FAILED:
						resultString="##>>> msisdn["+msisdn+"] Diameter Debit - ResultCode["+rc+"] ResultString[Rating failed]"; // modified by Avishkar on 17.10.2018
						l_result=-1;
						break;
					default:
						//Some other error
						//There are too many to decode them all.
						//We just print the classification
						if(rc>=1000 && rc<1999)
							resultString="##>>> msisdn["+msisdn+"] Diameter Debit - ResultCode["+rc+"] ResultCategory[Informational]"; // modified by Avishkar on 17.10.2018
						else if(rc>=2000 && rc<2999)
							resultString="##>>> msisdn["+msisdn+"] Diameter Debit - ResultCode["+rc+"] ResultCategory[Success]"; // modified by Avishkar on 17.10.2018
						else if(rc>=3000 && rc<3999)
							resultString="##>>> msisdn["+msisdn+"] Diameter Debit - ResultCode["+rc+"] ResultCategory[Protocl error]"; // modified by Avishkar on 17.10.2018
						else if(rc>=4000 && rc<4999)
							resultString="##>>> msisdn["+msisdn+"] Diameter Debit - ResultCode["+rc+"] ResultCategory[Transient failure]"; // modified by Avishkar on 17.10.2018
						else if(rc>=5000 && rc<5999)
							resultString="##>>> msisdn["+msisdn+"] Diameter Debit - ResultCode["+rc+"] ResultCategory[Permanent failure]"; // modified by Avishkar on 17.10.2018
						else
							resultString="##>>> msisdn["+msisdn+"] Diameter Debit - ResultCode["+rc+"] ResultCategory[unknown error class]"; // modified by Avishkar on 17.10.2018
						
						logger.info(resultString); // printing final response from diameter gateway
						
						// Modification start by Avishkar on 18.10.2018
						if( Global.RESPONSE_FILE_WRITER == 1 ) *//** If it is configured to write response in file.  *//*
						{
							*//**  writing in  logs/ResponseLogs/ResponseLog *//*
							synchronized(Global.flw_ResponseWriter) 
							{
								Global.flw_ResponseWriter.writeLog(resultString); //Global.getCurrentTime()+resultString);
							}
						}
						// Modification end by Avishkar on 18.10.2018
						
				}
			} catch(InvalidAVPLengthException ex) {
				//Below code is added by Avishkar on 17.10.2018
				logger.error("##>>> msisdn["+msisdn+"] Exception inside debitRequest method - result-code was illformed, ",ex);
				System.out.println("##>>> msisdn["+msisdn+"] Exception inside debitRequest method - result-code was illformed, "+ex);
				ex.printStackTrace();
				return l_result;
			}
			// below catch and finally block is added by Avishkar on 17.10.2018
			catch (Exception e) {
				logger.error("##>>> msisdn["+msisdn+"] Exception inside debitRequest method : ",e);
				System.out.println("##>>> msisdn["+msisdn+"] Exception inside debitRequest method : "+e);
				e.printStackTrace();
				return l_result;
			}
			finally {
				resultString=null;
			}

			//Stop the stack
			//	ssc.stop();

			return l_result;

	}
	
	public  synchronized int refundRequest (String msisdn,float Balance,int aVPCode){
		logger.info("##>> msisdn["+msisdn +"] Inside refundRequest method ... Amount["+Balance/1000+"] AvpCode ["+aVPCode+"]"); // added by Avishkar on 17.10.2018
		String l_msisdn=msisdn;
		String resultString="NA"; // added by Avishkar on 17.10.2018
		//int currencyCode = Global.CURRENCY_CODE;// added by Avishkar on 23.10.2018 // not required for this site
		
		//modification done by Avishkar on 23.10.2018
			
			if (Global.COUNTRY_CODE_ENABLE==1) { // value 1 means msisdn with countryCode allowed
				l_msisdn=getInternationalNumber(msisdn);
				logger.info(">>>MSISDN with countryCode : "+l_msisdn);
			}
			else {   // CC_CODE_ENABLE value other than 1 means msisdn with countryCode not allowed
				
				if (msisdn.length()>Global.MSISDN_MIN_LENGTH && msisdn.length()==Global.MSISDN_MAX_LENGTH) {
					l_msisdn=msisdn.substring(3);
					logger.info(">>>MSISDN without country code : "+l_msisdn);
				}
			}
		//modification end by Avishkar on 23.10.2018
		
		if(msisdn.length()>10) // commented by Avishkar on 23.10.2018
		{
			l_msisdn=msisdn.substring(3); }
		
			msisdn=l_msisdn;


			int balance=(int)Balance;
			int l_result=-1;
			//Build Credit-Control Request
			// <Credit-Control-Request> ::= < Diameter Header: 272, REQ, PXY >
			Message ccr = new Message();
			ccr.hdr.command_code = ProtocolConstants.DIAMETER_COMMAND_CC;
			ccr.hdr.application_id = ProtocolConstants.DIAMETER_APPLICATION_CREDIT_CONTROL;
			ccr.hdr.setRequest(true);
			ccr.hdr.setProxiable(true);
			//  < Session-Id >
			ccr.add(new AVP_UTF8String(ProtocolConstants.DI_SESSION_ID,ssc.node().makeNewSessionId()));
			//  { Origin-Host }
			//  { Origin-Realm }
			ssc.node().addOurHostAndRealm(ccr);
			//  { Destination-Realm }
			ccr.add(new AVP_UTF8String(ProtocolConstants.DI_DESTINATION_REALM,dest_realm)); //"www.huawei.com")); // modified by Avishkar on 23.10.2018
			ccr.add(new AVP_UTF8String(ProtocolConstants.DI_DESTINATION_HOST,dest_host)); //Global.DEST_HOST)); // modified by Avishkar on 23.10.2018
			//  { Auth-Application-Id }
			ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_AUTH_APPLICATION_ID,ProtocolConstants.DIAMETER_APPLICATION_CREDIT_CONTROL)); // a lie but a minor one
			//  { Service-Context-Id }
			ccr.add(new AVP_UTF8String(ProtocolConstants.DI_SERVICE_CONTEXT_ID,realm)); //Global.ORIGIN_REALM)); // modified by Avishkar on 23.10.2018
			//  { CC-Request-Type }
			ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_CC_REQUEST_TYPE,ProtocolConstants.DI_CC_REQUEST_TYPE_EVENT_REQUEST));;
			//  { CC-Request-Number }
			ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_CC_REQUEST_NUMBER,0));
			//  [ Destination-Host ]
			//  [ User-Name ]
			ccr.add(new AVP_UTF8String(ProtocolConstants.DI_USER_NAME,realm)); //Global.ORIGIN_REALM)); // modified by Avishkar on 23.10.2018
			//  [ CC-Sub-Session-Id ]
			//  [ Acct-Multi-Session-Id ]
			//  [ Origin-State-Id ]
			ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_ORIGIN_STATE_ID,ssc.node().stateId()));
			//  [ Event-Timestamp ]
			ccr.add(new AVP_Time(ProtocolConstants.DI_EVENT_TIMESTAMP,(int)(System.currentTimeMillis()/1000)));

			//ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_SERVICE_IDENTIFIER,0));
			// *[ Subscription-Id ]
			//  [ Service-Identifier ]
			//  [ Termination-Cause ]
			//  [ Requested-Service-Unit ]
					ccr.add(new AVP_Grouped(ProtocolConstants.DI_REQUESTED_SERVICE_UNIT,
					new AVP[] {new AVP_Unsigned64(ProtocolConstants.DI_CC_SERVICE_SPECIFIC_UNITS,42)}
					)
					);
					
			//  [ Requested-Action ]
			//
			ccr.add(new AVP_Unsigned32(20639,aVPCode));

			ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_REQUESTED_ACTION,ProtocolConstants.DI_REQUESTED_ACTION_REFUND_ACCOUNT));
			// *[ Used-Service-Unit ]
			//  [ Multiple-Services-Indicator ]
			// *[ Multiple-Services-Credit-Control ]
			// *[ Service-Parameter-Info ]
					ccr.add(new AVP_Grouped(ProtocolConstants.DI_SERVICE_PARAMETER_INFO,
					new AVP[] {new AVP_Unsigned32(ProtocolConstants.DI_SERVICE_PARAMETER_TYPE,42),
					new AVP_UTF8String(ProtocolConstants.DI_SERVICE_PARAMETER_VALUE,"Hovercraft")
					}
					)
					);
					
			//  [ CC-Correlation-Id ]
			//  [ User-Equipment-Info ]
			// *[ Proxy-Info ]
			// *[ Route-Record ]
			// *[ AVP ]
			ccr.add(new AVP_Grouped(ProtocolConstants.DI_SUBSCRIPTION_ID,new AVP[] {										                   new AVP_Unsigned32(ProtocolConstants.DI_SUBSCRIPTION_ID_TYPE,0).setM(),                     new AVP_UTF8String(ProtocolConstants.DI_SUBSCRIPTION_ID_DATA,l_msisdn).setM()}).setM());
			ccr.add(
					new AVP_Grouped(ProtocolConstants.DI_REQUESTED_SERVICE_UNIT,
						new AVP[] {new  AVP_Grouped(ProtocolConstants.DI_CC_MONEY,
							new AVP[]{new AVP_Grouped(ProtocolConstants.DI_UNIT_VALUE,
								new AVP[]{  new AVP_Unsigned64(ProtocolConstants.DI_VALUE_DIGITS,balance).setM()}
								).setM()}
							).setM()}
						).setM());


			Utils.setMandatory_RFC3588(ccr);
			Utils.setMandatory_RFC4006(ccr);
			logger.debug("##>>> msisdn["+msisdn+"] All Paramters are set Now send the request"); // modified by Avishkar on 17.10.2018

			//Send it
			Message cca = ssc.sendRequest(ccr);
			logger.info("##>>> msisdn["+msisdn+"] Diameter Refund - Request Sent"); // modified by Avishkar on 17.10.2018

			//Now look at the result
			if(cca==null) {
				resultString="##>>> msisdn["+msisdn+"] Diameter Refund - No response"; // modified by Avishkar on 17.10.2018
				return l_result;
			}
			AVP result_code = cca.find(ProtocolConstants.DI_RESULT_CODE);
			if(result_code==null) {
				resultString="##>>> msisdn["+msisdn+"] Diameter Refund - No result code"; // modified by Avishkar on 17.10.2018
				return l_result;
			}
			try {
				AVP_Unsigned32 result_code_u32 = new AVP_Unsigned32(result_code);
				int rc = result_code_u32.queryValue();
				logger.info("##>>> msisdn["+msisdn+"] Diameter Refund - response from the server ================="+rc); // modified by Avishkar on 17.10.2018
				switch(rc) {
					case ProtocolConstants.DIAMETER_RESULT_SUCCESS:
						resultString="##>>> msisdn["+msisdn+"] Diameter Refund - ResultCode["+rc+"] ResultString[SUCCESS]"; // modified by Avishkar on 17.10.2018
						l_result=1;
						break;
					case ProtocolConstants.DIAMETER_RESULT_END_USER_SERVICE_DENIED:
						resultString="##>>> msisdn["+msisdn+"] Diameter Refund - ResultCode["+rc+"] ResultString[End user service denied]"; // modified by Avishkar on 17.10.2018
						l_result=-1;
						break;
					case ProtocolConstants.DIAMETER_RESULT_CREDIT_CONTROL_NOT_APPLICABLE:
						resultString="##>>> msisdn["+msisdn+"] Diameter Refund - ResultCode["+rc+"] ResultString[Credit-control not applicable]"; // modified by Avishkar on 17.10.2018
						l_result=-1;
						break;
					case ProtocolConstants.DIAMETER_RESULT_CREDIT_LIMIT_REACHED:
						resultString="##>>> msisdn["+msisdn+"] Diameter Refund - ResultCode["+rc+"] ResultString[Credit-limit reached]"; // modified by Avishkar on 17.10.2018
						l_result=-1;
						break;
					case ProtocolConstants.DIAMETER_RESULT_USER_UNKNOWN:
						resultString="##>>> msisdn["+msisdn+"] Diameter Refund - ResultCode["+rc+"] ResultString[User unknown]"; // modified by Avishkar on 17.10.2018
						l_result=-1;
						break;
					case ProtocolConstants.DIAMETER_RESULT_RATING_FAILED:
						resultString="##>>> msisdn["+msisdn+"] Diameter Refund - ResultCode["+rc+"] ResultString[Rating failed]"; // modified by Avishkar on 17.10.2018
						l_result=-1;
						break;
					default:
						//Some other error
						//There are too many to decode them all.
						//We just print the classification
						if(rc>=1000 && rc<1999)
							resultString="##>>> msisdn["+msisdn+"] Diameter Refund - ResultCode["+rc+"] ResultCategory[Informational]"; // modified by Avishkar on 17.10.2018
						else if(rc>=2000 && rc<2999)
							resultString="##>>> msisdn["+msisdn+"] Diameter Refund - ResultCode["+rc+"] ResultCategory[Success]"; // modified by Avishkar on 17.10.2018
						else if(rc>=3000 && rc<3999)
							resultString="##>>> msisdn["+msisdn+"] Diameter Refund - ResultCode["+rc+"] ResultCategory[Protocl error]"; // modified by Avishkar on 17.10.2018
						else if(rc>=4000 && rc<4999)
							resultString="##>>> msisdn["+msisdn+"] Diameter Refund - ResultCode["+rc+"] ResultCategory[Transient failure]"; // modified by Avishkar on 17.10.2018
						else if(rc>=5000 && rc<5999)
							resultString="##>>> msisdn["+msisdn+"] Diameter Refund - ResultCode["+rc+"] ResultCategory[Permanent failure]"; // modified by Avishkar on 17.10.2018
						else
							resultString="##>>> msisdn["+msisdn+"] Diameter Refund - ResultCode["+rc+"] ResultCategory[unknown error class]"; // modified by Avishkar on 17.10.2018
						
						logger.info(resultString); // printing final response from diameter gateway
						
						// Modification start by Avishkar on 18.10.2018
						if( Global.RESPONSE_FILE_WRITER == 1 ) *//** If it is configured to write response in file.  *//*
						{
							*//**  writing in  logs/ResponseLogs/ResponseLog *//*
							synchronized(Global.flw_ResponseWriter) 
							{
								Global.flw_ResponseWriter.writeLog(resultString); //(Global.getCurrentTime()+resultString);
							}
						}
						// Modification end by Avishkar on 18.10.2018

				}
			} catch(InvalidAVPLengthException ex) {
				//Below code is added by Avishkar on 17.10.2018
				logger.error("##>>> msisdn["+msisdn+"] Exception inside refundRequest method - result-code was illformed, ",ex);
				System.out.println("##>>> msisdn["+msisdn+"] Exception inside refundRequest method - result-code was illformed, "+ex);
				ex.printStackTrace();
				return l_result;
			}
			// below catch and finally block is added by Avishkar on 17.10.2018
			catch (Exception e) {
				logger.error("##>>> msisdn["+msisdn+"] Exception inside refundRequest method : ",e);
				System.out.println("##>>> msisdn["+msisdn+"] Exception inside refundRequest method : "+e);
				e.printStackTrace();
				return l_result;
			}
			finally {
				resultString=null;
			}
			
			//Stop the stack
			//	ssc.stop();

			return l_result;

	}
	
*/}
