package chargingserver;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.net.*;
import java.util.concurrent.ArrayBlockingQueue;
import org.apache.log4j.*;
import com.telemune.client.DiameterRequest;

import FileBaseLogging.FileLogWriter;

public class Global
{
	private static Logger logger = Logger.getLogger("Global");
	public static int REQID_TAG = 9;
	public static int MSISDN_TAG = 1;
	public static int ACTION_TAG = 2;
	public static int TARIFFID_TAG = 3;
	public static int FMSISDN_TAG = 5;
	public static int RBTCODE_TAG = 4;
	public static int RESPONSE_TAG = 7;
	public static int SUB_TYPE = 8;
	public static int INTERFACE_TAG = 6;
	public static int REQTYPE_TAG = 12;
	public static int numofcontentthreads = 1;
	public static int MAX_LIMIT = 1000;
	public static int PACKID_TAG = 14;
	public static int USER_VALIDITY=15;
	public static int AMOUNT_TAG=11;
	//public static int BALANCE_TAG=71; // added by Avishkar on 21.11.2018
	public static int REDIRECT_TAG=72; // added by Avishkar on 21.11.2018
	public static int THREAD_MONITOR_DELAY = 10;
	public static boolean SEND_ZERO_AMOUNT_CHARGING = false;
	public static int CORPID_TAG=13; // added by Avishkar on 10.01.2020

	
	public static  ArrayBlockingQueue<Data_Object> que=new ArrayBlockingQueue<Data_Object>(100000);
	public static  ArrayBlockingQueue<Data_Object> que_send=new ArrayBlockingQueue<Data_Object>(100000);
	public static Set core_COS_SET = new HashSet();
        public static Set advance_COS_SET = new HashSet();

	public static int cntrcheck= 0;

	public static int BALANCE_FILE_WRITER = 0;
	public static int CDR_FILE_WRITER = 0;
	public static int PER_REQ_FILE_WRITER = 0;
	public static int RESPONSE_FILE_WRITER = 0; // Added by Avishkar on 26.09.2018
	public static FileLogWriter flw_ResponseWriter = null; // Added by Avishkar on 26.09.2018
	
	/*
	public static synchronized void rst( boolean rst)
	{
		if(rst)
			cntrcheck = 0;
		else
			cntrcheck++;
	}*/

//	public static ConnPool conPool = null;
	public static int postpaidcheck = 0;
	public static int _DEFAULT_RATE_PLAN = 1;
	public static int gateway_request_timeout = 10000;

	public static int TESTCASE = -1;
	public static int TESTBALANCE = 0;


	public static int[] prepaidac = new int[5];
	public static int[] postpaidac = new int[5];
	public static int[] hybridac = new int[5];


	public static Hashtable charges_prepaid = new Hashtable();
	public static Hashtable charges_postpaid = new Hashtable();
	public static Hashtable<String, String> product_Code_prepaid = new Hashtable<String, String>(); //Added by Avishkar on 1.11.2018
	public static Hashtable<String, String> product_Code_postpaid = new Hashtable<String, String>(); //Added by Avishkar on 1.11.2018	
	public static Hashtable<String,String> country_code = new Hashtable<String,String>();
	public static Hashtable avp_action = new Hashtable();
	public static Hashtable<String,Integer>  charging_min_balance =  new Hashtable<String,Integer>();
        public static Hashtable<String,Double>  chargescodes_amount = new Hashtable<String,Double>();

	public static Hashtable<Integer,Integer> cpCodeRbtCode=new Hashtable<Integer, Integer>();

	public static int chg_reqId=-1;


	public static String DEFAULT_CURRENCY = "";

	public static String MSRN_FETCH_HOST = "";
	public static short  MSRN_FETCH_PORT = 0;
	public static String MSRN_PROV_FETCH_HOST="";
	public static short MSRN_PROV_FETCH_PORT=0;
	
	//public static int BALANCE_FILE_WRITE = 1; //-1
	//public static Double FIXED_AMOUNT = 0.0;
	public static double FIXED_AMOUNT = 0.0;
	
//	public static FileLogWriter flwBalaceWriter = null;
	public static synchronized int getChgReqId() // method uncommented/ enable by Avishkar on 16.04.2019
	{
		if (chg_reqId==9999999) { // this if condition block is added by Avishkar on 16.04.2019
			chg_reqId=0;
		}
		return ++chg_reqId;
	}


	public static String CHRIP = "NA";
	public static String CHR_USERNAME = "NA";
	public static String CHR_PASSWORD = "NA";	
	public static String username = "crbtblue";
	public static String password = "crbtblue";

	public static String SUB_TYPE_TABLE = "CRBT_SUBSCRIBER_MASTER"; //NA
	public static String gateway_link1 = "NA"; 
	public static String gateway_link2 = "NA";
	public static int gateway_port2 = -1; // Added by Avishkar on 30.11.2018
	public static String gateway_link3 = "NA"; // Added by Avishkar on 30.11.2018
	public static String gateway_link4 = "NA"; // Added by Avsihkar on 07.06.2020
	public static String DELIVERY_URL = "NA"; // Added by Avishakar on 01.10.2018
	public static String DB_TYPE="NA"; // Added by Avishkar on 25.03.2019
	
	public static int g_REQUEST_TO_CHECK_BALANCE = 1; //-1
	public static int g_REQUEST_TO_CREDIT_BALANCE = -1;
	public static int g_REQUEST_TO_DEBIT_BALANCE = 1; //1
	public static int SUB_SOURCE_TYPE = 1; //-1
	public static int MSISDN_MIN_LENGTH = 6; //-1
	public static int MSISDN_MAX_LENGTH = 8; //-1
	static int counter = 0; 

	public static SendToGateway  sendtogateway = null;
	//public static SoapRequest soapRequest = null;
	
	public static void close(Object obj)
	{
		logger.debug("Object no["+counter+"]going to Free["+obj+"]");
		obj = null;
		counter++;       
	}  

	public static int NOT_ENOUGH_BAL = 207;
	public static int BAL_EXPIRED = 208;
	public static int RECORD_NOT_FOUND = 201;
	public static int UNKNOWN_ERROR = 104;
	public static int MAX_AMT_EXCEEDED = 206;
	public static int MAX_OPS_EXCEEDED = 205;  
	public static String rspdesc = "NA";  
	public static final int SUCCESS_CODE = 1;
	public static final int LOW_BALANCE_CODE = 124;   
	public static final int LOW_BALANCE_CODE_PRE = -2;      
	public static final int RESULT_CODE_3 = -3;      
	public static final int RESULT_CODE_4 = -4;      
        public static int DA_ID=-1;
        public static  boolean cacheThreadAlive=false;

    	//modify by Avishkar for HttpUrlTester
    	public static String HTTP_URL_FOR_CHARGING = "NA";
    	public static String DURATION = "NA";
    	
    	public static int MAX_RETRY = 0;
        public static Date startDate = null;
        public static int isStart = 0;
        public static int TOKEN_MINUTE_DIFF = 0;
        
        
        public static String FIND_SUB_ID_URL="";
        public static String CHK_POSSIBILITY_URL_1="";
        public static String CHK_POSSIBILITY_URL_2="";
        public static String DEBIT_FOR_SUBSCRIPTION_URL="";
        public static String DEBIT_FOR_RBT_URL="";
        //public static String LOGIN_URL;
        public static String AUTHTOKEN_URL="";
        //public static String USERNAME="";
        //public static String PASSWORD="";
        public static String SERVICE_ID="";
        public static String SECURITY_TOKEN="";
        public static int DEACT_ENABLE = -1;
        
        //added by Avishkar on 16.10.2018
        public static int g_TaxAmount=-1;
        public static int g_divident = -1;
        public static int TAX_ENABLE=0;
        public static int FIXED_AMOUNT_ENABLE=-1;
        public static String ORIGIN_HOST ="";
    	public static String ORIGIN_REALM ="";
    	public static int HOST_PORT=-1;
    	public static String DEST_HOST= "";
    	public static int DEST_PORT =-1;
    	public static String DEST_REALM="";
    	public static int VENDOR_ID =-1;
    	public static int COUNTRY_CODE_ENABLE=-1;
    	public static int CURRENCY_CODE=-1;
    	//public static String COUNTRY_CODE="";
    	public static String CHECK_BAL_URL="";
    	//public static String ORIGIN_NODE_TYPE="";
    	//public static String ORIGIN_HOST_NAME="";
    	public static String MODULE="";
    	public static String HOST="";
    	
    	public static DiameterRequest diameterRequest=null;
    	public static int REFUND_REQUEST_ENABLE=-1;
    	public static int TESTCASE_DEBIT_SUCCESS=-1;
    	public static int DIAMETER_ENABLE=-1;
    	public static SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
//    	public static String chgUserName="";
//    	public static String chgPassword="";    	
    	
    	// this method is added for print date and time in file base logs by Avishkar on 18.10.2018 
    	public static String getCurrentTime(){
    		//SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
    		Calendar cal = Calendar.getInstance();
    		String time =  dateFormat.format(cal.getTime());
    		cal = null;
    		return time;
    	}
    	
    	//below parameters are added exclusively for NetOne site by Avishkar on 1.11.2018
        public static String operationCode="operationCode";
    	public static String billingText="billingText";
    	public static String msisdn="msisdn";
    	public static String productCode="productCode";
    	public static String cpID="cpID";
    	public static String clientTransID="clientTransId";
    	public static String channelId="channelID";
    	public static String userName="username";
    	public static String language="language";
    	public static String passWord="password";
    	public static String shortCode="shortCode";
    	public static String sourceNode="sourceNode";
    	public static String toneId="toneId";
    	public static String serviceId="serviceId";
    	public static String isContentprovider="isContentprovider";
    	public static String status="status";
    	public static String statusCode="statusCode";
    	public static String chargeAmount="chargeAmount";
    	public static String CP_ID="";
    	
    	//Operation Code
    	//public static String ACTIVATE="ACTIVATE";
    	//public static String DEACTIVATE="DEACTIVATE";
    	public static String DEBIT="DEBIT";
    	//public static String REFUND="REFUND";
    	//public static String END_POINT="";
    	
    	//InterFace Type
    	public final static String USSD="U";
    	public final static String SMS="S";
    	public final static String IVR="I";
    	public final static String GUI="C";
    	public final static String WEB="W";
    	public final static String OBD="O";
    	public final static String RENEWAL="M"; 
    	public final static String MOBILE_APP_OR_WAP="P";
    	public final static String CORPORATE="T";
    	public final static String EXTENDED_API="X";
    	public final static String STAR_COPY="V";
    	public final static String RECORDING="R";
    	
    	//InterFace Tag
    	public static int USSD_TAG=1;
        public static int SMS_TAG=2;
        public static int GUI_TAG=3;
        public static int WEB_TAG=4;
        public static int IVR_TAG=5; // For STAR_COPY AND RECORDING we are using IVR_TAG at client site 
        
        //below InterFace Tag values need to be confirm from client
        public static int OBD_TAG=6;
        public static int RENEWAL_TAG=7;
        public static int APP_OR_WAP_TAG=8;
        public static int CORP_TAG=9;
        public static int EXTENDED_API_TAG=10;
        
        public static int IS_SECOND_CHARGING_ENABLE=-1; // For Jamaica and Barbadose added by Avishkar on 29.11.2018
        public static int TESTCASE_CHKBAL_SUCCESS=-1; // added by Avishkar on 11.12.2018
        public static int FALLBACK_AFTER_DEBIT_FAIL_ENABLE=-1; // added by Avishkar on 11.12.2018
        public static int inter_charging_interaction_timeout = 15; // added by Avishkar on 28.01.2019 
        
        //New parameters for BTC added by Avishkar on 05-06-2020
        public static String LOGIN_URL = "NA";
        public static String APISTR = "SAPI";
        public static String REALM = "SAPI";
        public static String REALM_FOR_SUBID = "CSM";
//        public static String CHKPROFILE_URL = "NA"; // instead of this we are using Global.gateway_link4
        public static String USERID_NAME ="3rd_CRBT";
//        public static String POSTPAID_URL = "NA"; // not required as single url is used for both prepaid and postpaid
        public static int IS_LOGIN_ENABLE = -1;
        public static int CDR_ID_REQUIRED_IN_CHG_REQ = -1;
        public static int NRC_TERM_ID_PREPAID_SUBSCRIPTION=-1;
        public static int NRC_TERM_ID_POSTPAID_SUBSCRIPTION=-1;
        public static int NRC_TERM_ID_PREPAID_RBT_PURCHASE=-1;
        public static int NRC_TERM_ID_POSTPAID_RBT_PURCHASE=-1;
        public static int NRC_TERM_ID_PREPAID_GIFT_RBT=-1;
        public static int NRC_TERM_ID_POSTPAID_GIFT_RBT=-1;
        public static int NRC_TERM_ID_PREPAID_RBT_RENEW=-1;
        public static int NRC_TERM_ID_POSTPAID_RBT_RENEW=-1;
        public static int NRC_TERM_ID_PREPAID_RECORDING_RBT=-1;
        public static int NRC_TERM_ID_POSTPAID_RECORDING_RBT=-1;
        
        // New parameters for Telecel RCA added by Avishkar on 22-02-2022
        public static int dilogId=-1;
    	public static int DLG_START=-1;
    	public static int DLG_STOP=-1;
    	public static int opCode=-1;
        public static int USSD_PORT=-1;
    	public static String USSD_HOST="";
    	public static String Check_balCommand="";
    	public static String deduct_balCommand="";
    	public static int TOTAL_REQ_COUNT=-1;
    	
    	public synchronized static int getDailogId()
    	{
    		if(dilogId==-1)
    		{
    			return dilogId=DLG_START;
    		}else
    		{
    			if(dilogId==DLG_STOP)
    			{
    				return dilogId=DLG_START;
    			}else
    			{
    				return ++dilogId;
    			}
    		}
    	}
    
        
}
