package com.telemune.hlr.backend;

import org.apache.log4j.Logger;

public class SoapRequestHandler implements HlrInterface{

	final private Logger logger = Logger.getLogger(SoapRequestHandler.class);
	SoapClient client = null;
	public long objectNo ;
	
	public SoapRequestHandler(long i) {
		logger.info("Inside SoapRequestHandler Object no "+i+" created");
		client = new SoapClient();
		this.objectNo = objectNo ;
	}
	
	
	public int doProcessing(DataObject dataObject) {
		try
		{
		logger.info("##>isnide doProcessing in SoapRequestHandler request is ["+dataObject+"]");	
		if(dataObject.getReqType() == 1)
		{
			client.getSubType(dataObject);
		}
		else if(dataObject.getReqType() == 3)
		{
			client.upFlag(dataObject);
		}
		else if(dataObject.getReqType() == 4)
		{
			client.downFlag(dataObject);
		}
		logger.info("##>isnide doProcessing in SoapRequestHandler Response is ["+dataObject+"]");	
		return 1;
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		return -1;
	}
	public boolean keepAlive() {
		 
		return false; //not requied in Soap
	}
	public boolean isConnected() {
		return false; //not required in Soap
	}


	public long getObjectNo() {
		// TODO Auto-generated method stub
		return objectNo;
	}
}
