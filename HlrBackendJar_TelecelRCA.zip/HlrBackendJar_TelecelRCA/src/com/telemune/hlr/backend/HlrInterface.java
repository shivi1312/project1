package com.telemune.hlr.backend;

public interface HlrInterface<T> {
	
	public int doProcessing(DataObject dataObject);
	public boolean keepAlive();
    public boolean isConnected();
    public long getObjectNo();
}
