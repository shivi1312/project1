package com.telemune.hlr.backend;

import java.util.ArrayList;

public class Config {

	static String TelnetRequestForCS;
	static String TelnetRequestForUF;
	static String TelnetRequestForDF;
	static String LOGIN_VALIDATOR;
	static String PASSWORDFRMT;
	static String LOGINFRMT;
	/*static String TELNET_CONFIGUREDIP;
	static int PORT;  
	static String REMOTEUSER;
	static String REMOTEPASSWD;*/
	static String REMOTETERMINATOR;
	static String LOGINCMD; 
	static String CONNECTION_CHECKING_CMD;
	public static int TESTING = 0;
	public static int connectionTimeOut = 1;
	public static ArrayList<String> prePaid_tplId = new ArrayList<String>();
	public static ArrayList<String> postPaid_tplId = new ArrayList<String>();
	public static String FTN_NUMBER = "NA";
	public static String TESTING_STRING=""; // added by Avishkar on 23.10.2019
	
	
	
}
