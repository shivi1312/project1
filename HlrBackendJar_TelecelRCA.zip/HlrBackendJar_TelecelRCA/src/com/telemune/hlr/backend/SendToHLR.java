package com.telemune.hlr.backend;
import java.net.HttpURLConnection;
import java.net.URL;
import org.apache.log4j.Logger;

public class SendToHLR {

	final static Logger logger = Logger.getLogger("SendToHLR");

	public String hlrFlagActivity(String msisdn, int reqtype, String hlrUrl, int conTimeout) 
	{
		logger.debug("##>>msisdn["+msisdn+"] Url fetched from HLRInterface ["+hlrUrl+"] conTimeout["+conTimeout+"]");
		hlrUrl = hlrUrl + "?MDN=" + msisdn + "&CRBT=";
		int responseCode = 404;
		String response = "";
		URL url = null;
		try {

			if (reqtype == 3) {
				hlrUrl = hlrUrl + "1";
				logger.info("##>>msisdn["+msisdn+"] HLR Up request url [" + hlrUrl + "]");
			}
			else if (reqtype == 4) {
				hlrUrl = hlrUrl + "0";
				logger.info("##>>msisdn["+msisdn+"] HLR Down request url [" + hlrUrl + "]");
			}
			
			if (Config.TESTING != 1) {
				url = new URL(hlrUrl);
			} else {
				logger.warn("\n\n\t\tTESTING is enable\n\n");
				url = new URL("https://www.google.co.in");
			}
			
			logger.info("\n\n\t\tGoing to hit url [" + url + "]\n");
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			logger.debug("##>>msisdn["+msisdn+"] Connection [" + con + "]");
			con.setRequestMethod("GET");
 
			try {
				
				con.setConnectTimeout(conTimeout*1000); // set timeout to properties
				responseCode = con.getResponseCode();
				logger.info("##>>msisdn["+msisdn+"] In hlrFlagDown.....received responseCode is ["+ responseCode + "]");
			} catch (Exception iae) {
				logger.info("##>>msisdn["+msisdn+"] Illegal Argument Exception \n", iae);
				iae.printStackTrace();
			}

			if (responseCode == 200) 
			{
				response = "0";
				if (reqtype == 3) {
					logger.info("##>>msisdn["+msisdn+"] HLR Up request processed Successfully!!! responseCode ["
							+ responseCode + "] response [" + response + "]");
				}
				if (reqtype == 4) {
					logger.info("##>>msisdn["+msisdn+"] HLR Down request processed Successfully!!! responseCode ["
							+ responseCode + "] response [" + response + "]");
				}
			}
			else 
			{
				response = "-1";
				if (reqtype == 3) {
					logger.info("##>>msisdn["+msisdn+"] There is some problem in processing HLR Up request!!! responseCode ["
							+ responseCode + "] response [" + response + "]");
				}
				if (reqtype == 4) {
					logger.info("##>>msisdn["+msisdn+"] There is some problem in processing HLR Down request!!! responseCode ["
							+ responseCode + "] response [" + response + "]");
				}
			}

		} catch (Exception ekseption) {
			response = "-1";
			logger.error("\n\n\t\tProblem in hlrFlagActivity() method \n", ekseption);
			ekseption.printStackTrace();
		}
		return response;
	}// added by yash on 21.11.2016

}
