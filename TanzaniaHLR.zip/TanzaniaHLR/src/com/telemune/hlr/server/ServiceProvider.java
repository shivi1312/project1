/**
 * ServiceProvider.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.telemune.hlr.server;

public interface ServiceProvider extends javax.xml.rpc.Service {
    public java.lang.String getServiceProviderHttpSoap11EndpointAddress();

    public com.telemune.hlr.server.ServiceProviderPortType getServiceProviderHttpSoap11Endpoint() throws javax.xml.rpc.ServiceException;

    public com.telemune.hlr.server.ServiceProviderPortType getServiceProviderHttpSoap11Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
