package com.telemune.hlr.backend;

import org.apache.log4j.Logger;


public class HttpRequestHandler implements HlrInterface{
	final static Logger logger = Logger.getLogger(HttpRequestHandler.class);
			
	static int counter = 0;
	public long objectNo ;
	public String hlrUrl;
	public HttpRequestHandler(long i,String hlrUrl) {
		logger.info("Inside HttpRequestHandler Object no "+i+" created for hlrUrl["+hlrUrl+"]");
		this.objectNo = i;
		this.hlrUrl = hlrUrl;
	}
	
	
	
	public int doProcessing(DataObject dataObject) {
		
		String response = "";
		SendToHLR sendToHLR =  new SendToHLR();
		int sendNext = -1;
		try 
		{
			logger.info("\n\n\tdata fetched to process with HLR is: \n"+dataObject+"\n\n for objectNO["+objectNo+"]");
			if(Config.TESTING != 1)
			{
			response = sendToHLR.hlrFlagActivity(dataObject.getMsisdn(), dataObject.getReqType(), hlrUrl, Config.connectionTimeOut);
			}
			dataObject.setReqId(1);
			dataObject.setMsrn("NULL");
			dataObject.setMscNo("NULL");
			dataObject.setImsi("NULL");
			dataObject.setScfAddr("NULL");
			dataObject.setServiceKey(0);
			dataObject.setIsPrePaidId("N");
			dataObject.setIsRoaming("N");
			dataObject.setResponse(response);
			dataObject.setBusyNo("NULL");
			dataObject.setNoReachNo("NULL");
			dataObject.setNoReply("NULL");
			dataObject.setIsCFU("N");
			dataObject.setCFU("NULL");
			dataObject.setSendNextHlr(sendNext);
			logger.info("\n After processing request Data is: ["+dataObject+"]\n\n for object no["+objectNo+"]");
			return 1;
		} 
		catch(NullPointerException nullexp)
		{
			logger.fatal("Problem in HttpRequestHandler",nullexp);
			nullexp.printStackTrace();
			return -1;
		}
		catch (Exception e) {
			logger.fatal("Problem in HttpRequestHandler",e);
			e.printStackTrace();
			return -1;
		}
		
	}
	public boolean keepAlive() {
		return false;  //not used for Http
	}
	public boolean isConnected() {
		return false; //not used for Http
	}



	public long getObjectNo() {
		// TODO Auto-generated method stub
		return objectNo;
	}

}
