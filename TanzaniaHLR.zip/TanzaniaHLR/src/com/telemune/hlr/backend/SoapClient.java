package com.telemune.hlr.backend;

import com.telemune.hlr.server.ServiceProviderLocator;
import com.telemune.hlr.server.ServiceProviderPortType;

public class SoapClient {

	ServiceProviderLocator locator = null;
	ServiceProviderPortType port = null;

    public SoapClient() {
    	try
    	{
    	locator = new ServiceProviderLocator();
		port = locator.getServiceProviderHttpSoap11Endpoint();
    	}
    	catch(Exception exp)
    	{
    		exp.printStackTrace();
    	}
	        	
	}
	
    public String getSubType(DataObject dataObject)
    {
    	String subType = "NA";
    	int result = -1;
		try
    	{
			result = port.getSubType(Integer.parseInt(dataObject.getMsisdn()));
			if(result == 1){ subType="P";
			dataObject.setIsPrePaidId("Y");
			dataObject.setResponse("0");
			}
			else { subType="O";
			dataObject.setIsPrePaidId("N");
			dataObject.setResponse("0");
			}
			System.out.println("msisdn["+dataObject.getMsisdn()+"] subType is["+subType+"]");
			return subType;
		
    	}
    	catch(Exception exp)
    	{
    		exp.printStackTrace();
    	}
    	return null;
    }
    
    public String upFlag(DataObject dataObject)
    {
    	String upFlag = "NA";
		int result = -1;
    	try
    	{
    		result = port.upFlag(Integer.parseInt(dataObject.getMsisdn()));
			if(result == 1){ upFlag="UP";
			dataObject.setResponse("0");
			}
			else { upFlag="NOT UP"; 
			dataObject.setResponse("-1");
			
			}
			System.out.println("msisdn["+dataObject.getMsisdn()+"] UpFlag status is["+upFlag+"]");
			return upFlag;
    	}
    	catch(Exception exp)
    	{
    		exp.printStackTrace();
    	}
    	return null;
    }
    
    public String downFlag(DataObject dataObject)
    {
    	String downFlag = "NA";
		int result = -1;
    	try
    	{
    		result = port.downFlag(Integer.parseInt(dataObject.getMsisdn()));
			if(result == 1){ downFlag="DOWN";
			dataObject.setResponse("0");
			}
			else { downFlag="NOT DOWN";
			dataObject.setResponse("-1");
			}
			System.out.println("msisdn["+dataObject.getMsisdn()+"] UpFlag status is["+downFlag+"]");
			return downFlag;
    	}
    	catch(Exception exp)
    	{
    		exp.printStackTrace();
    	}
    	return null;
    }
    
    
    public static void main(String arg[])
    {
    	SoapClient sop = new SoapClient();
    	DataObject dataObject = new DataObject();
    	dataObject.setMsisdn("1");
    	sop.upFlag(dataObject);
    	System.out.println("respose["+dataObject.getResponse()+"]");
    }
}
