package com.telemune.hlr.backend;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.PrintStream;

import org.apache.commons.net.telnet.TelnetClient;
import org.apache.log4j.Logger;

public class TelnetRequestHandler implements HlrInterface{
	private static Logger logger = Logger.getLogger(TelnetRequestHandler.class);
    static int counter = 0;
    private PrintStream telnetOutStream;
	private InputStream telnetInputStream;
    private DataInputStream telnetDataInputStream;
	private boolean isConnected = false;
	long connectionTimeOut = 1;
	TelnetClient telnet = null;
	String strbfr = null;
	String loginCmd4Live = null;
	private String telnetIp = "";
	private int telnetPort;
	private String loginName;
	private String password;
	public long objectNo ;
	public TelnetRequestHandler(long i , String ip,int port,String loginName,String password) {
		logger.info("Inside TelnetRequestHandler Object no "+i+" created");
		try
		{
			telnetIp = ip;
			telnetPort = port;
			this.loginName = loginName;
			this.password = password;
			connectionTimeOut = 1000 * Config.connectionTimeOut;
			telnet = new TelnetClient();
			isConnected = false;
			objectNo = i;
			
			
			loginCmd4Live = Config.LOGINCMD.replace("<login_name>", loginName)
			.replace("<password>", password);
	
			logger.info("\n\t\t loginCommand4Live : \n\n\t\t\t" + loginCmd4Live
							+ "\n\n");
			if(Config.TESTING != 1)
			{
			logger.debug("Going to connect to TelnetHlr inside  TelenetRequestHandler telnetIp["+telnetIp+"] telnetPort["+telnetPort+"]");
			isConnected = telnet.isConnected();
			logger.debug("Going to call keepAlive");
			keepAlive();
			logger.debug("Keep Alive called to make connection");
			}
			
		}
		catch(NullPointerException nullexp)
		{
			nullexp.printStackTrace();
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
	
	
	}
	
	
	
	public synchronized int  doProcessing(DataObject dataObject) {
		logger.info("##>>inside TelnetRequestHandler request is ["+dataObject+"]");
		
		try {
			
			String strBfr = "NA";
			String response = "-1";
			// Addition by Avishkar on 6/09/2020 start
			int responseCFNRY = -1;
			int responseCFB = -1;
			int responseCFNRC = -1;
			StringBuffer imsiBitValueBuf= new StringBuffer();
			// Addition by Avishkar on 6/09/2020 ends
			String str1, str2 = "0";
			String req6CmdStr = null;
			String req3CmdStr = null;
			String req4CmdStr = null;
			String[] tplId = null;
			int sendNext = -1;
			
			dataObject.setReqId(1);
			dataObject.setMsrn("NULL");
			dataObject.setMscNo("NULL");
			dataObject.setImsi("NULL");
			dataObject.setScfAddr("NULL");
			dataObject.setServiceKey(0);
			dataObject.setIsRoaming("N");
			dataObject.setResponse(response);
			dataObject.setBusyNo("NULL");
			dataObject.setNoReachNo("NULL");
			dataObject.setNoReply("NULL");
			dataObject.setIsCFU("N");
			dataObject.setCFU("NULL");
			
			 if (Config.TESTING == 1) {
				logger.info("\n\n\t\t**************Testing is Enabled***************\n\n");
				// Addition start by Avishkar on 3-09-2020
				 if ("SuccessTesting".equalsIgnoreCase(Config.TESTING_STRING)) {
                 logger.info("Yes, TESTING_STRING contains the required String... TESTING_STRING ["+Config.TESTING_STRING+"]");
                 if (dataObject.getReqType()==6) {
                         dataObject.setIsPrePaidId("Y"); // In testing all msisdn is considered as Prepaid
                         response = "0";
                         dataObject.setResponse("0");
                         logger.info(">>>>>"+dataObject.getMsisdn()+" is PrePaid");
                         logger.debug("\n\tIn testing all msisdn considered as Prepaid");
                 }
                 else if (dataObject.getReqType()==3) {
                	 	 response = "0";
                         dataObject.setIsPrePaidId("Y"); // In testing all msisdn is considered as Prepaid
                         dataObject.setResponse("0");
                         logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Up Success");
                 }
                 else if (dataObject.getReqType()==4) {
                	 	 response = "0";
                         dataObject.setIsPrePaidId("Y"); // In testing all msisdn is considered as Prepaid
                         dataObject.setResponse("0");
                         logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Down Success");
                 }
	           } else {
	                   logger.info("No, TESTING_STRING doesn't contain the required String... TESTING_STRING ["+Config.TESTING_STRING+"]");
	                   if (dataObject.getReqType()==6) {
	                  	 	 response = "-1";
	                           dataObject.setResponse("-1");
	                           logger.info(">>>>>"+dataObject.getMsisdn()+" subType NOT FOUND");
	                   }
	                   else if (dataObject.getReqType()==3) {
	                  	 	 response = "-1";
	                           dataObject.setResponse("-1");
	                           logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Up FAILURE");
	                   }
	                   else if (dataObject.getReqType()==4) {
	                  	 	 response = "-1";
	                           dataObject.setResponse("-1");
	                           logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Down FAILURE");
	                   }
	           }
			// Addition end by Avishkar on 3-09-2020
				
			// commented by Avishkar on 3-09-2020 start	
			  /*strBfr = sendCommand("show license" , "LOCAL" , 0);
				logger.info("\n\nResponse of command:\n" + strBfr
						+ "\n*************************\n");
				if (strBfr.toString().contains("permanent")) {
					response = "0";
					logger.info("Yes it contains the required String....");
				} else {
					response = "-1";
					logger.info("No it doesn't contain the required String....");
				}*/
			// commented by Avishkar on 6-09-2020 ends
			} else {
				if(dataObject.getReqType() == 6)
				{
					req6CmdStr = Config.TelnetRequestForCS.replace("<msisdn>",
							dataObject.getMsisdn());
					logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Processing Request 6, Command [" + req6CmdStr + "] ");
				
					strBfr = sendCommand(req6CmdStr.trim() , dataObject.getMsisdn().trim() ,dataObject.getReqType());
					logger.info("\n\nResponse of command:\n" + strBfr
						+ "\n*************************\n");
					if(strBfr.contains("Connection closed by foreign host"))
					{
						telnet.disconnect();
						return -2;
					}
					// addition by Avishkar on 10/09/2020 start
					if (strBfr.contains(":IMSI,")) { 
						response = "0" ; 
						str1 = strBfr.substring(strBfr.lastIndexOf("IMSI,")); 
//						System.out.println("str1 : "+str1);
						str2 = str1.substring(str1.lastIndexOf(",")+1);
						logger.info("the IMSI full number ["+str2+"]"); 
						int bitPosition = Config.chk_imsi_start_bit-1;
						for (int i = 1; i <= Config.chk_imsi_no_of_bits; i++) {
							
							imsiBitValueBuf = imsiBitValueBuf.append(str2.charAt(bitPosition));
							bitPosition ++;
						}
						logger.info("the IMSI digit are ["+imsiBitValueBuf+"]");
					}
					else { 
						response = "-1" ; 
						str2 = str1 = "0" ; 
					}
					
					/*if (strBfr.contains("SUCCESS0001:Operation is successful")) {
						if(strBfr.contains("TPLID"))
						{
						response = "0";
						str1 = strBfr.substring(strBfr.indexOf("TPLID"),strBfr.indexOf("STATE"));
						tplId = str1.split("=");
						logger.info("##>>msisdn["+dataObject.getMsisdn()+"] the TPLID is [" +tplId[1]+ "] ");
						}
						else
						{
							response = "-1";
						}	
					
					} else {
						response = "-1";
					}*/
					
					// addition by Avishkar on 10/09/2020 end
				}
				else if (dataObject.getReqType() == 3) {
					// Addition by Avishkar on 06/09/2020 start
					if (Config.VCC_CFNRY_ENABLE==1) {
						req3CmdStr = Config.TelentRequestFor_CFNRY_UF.replace("<msisdn>",
								dataObject.getMsisdn());
						strBfr = sendCommand(req3CmdStr.trim() ,  dataObject.getMsisdn().trim() ,dataObject.getReqType());
						logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] Response of command:\n" + strBfr
								+ "\n*************************\n");
						
						if(strBfr.contains("Connection closed by foreign host"))
						{
							telnet.disconnect();
							return -2;
						}
						if (strBfr.contains("RESP:0")) {
							responseCFNRY = 1;
							
						} else {
							responseCFNRY = -1;
						}
						
					}
					if (Config.VCC_CFB_ENABLE==1) {
						req3CmdStr = Config.TelentRequestFor_CFB_UF.replace("<msisdn>",
								dataObject.getMsisdn());
						strBfr = sendCommand(req3CmdStr.trim() ,  dataObject.getMsisdn().trim() ,dataObject.getReqType());
						logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] Response of command:\n" + strBfr
								+ "\n*************************\n");
						
						if(strBfr.contains("Connection closed by foreign host"))
						{
							telnet.disconnect();
							return -2;
						}
						if (strBfr.contains("RESP:0")) {
							responseCFB = 1;
							
						} else {
							responseCFB = -1;
						}
						
					}
					if (Config.VCC_CFNRC_ENABLE==1) {
						req3CmdStr = Config.TelentRequestFor_CFNRC_UF.replace("<msisdn>",
								dataObject.getMsisdn());
						strBfr = sendCommand(req3CmdStr.trim() ,  dataObject.getMsisdn().trim() ,dataObject.getReqType());
						logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] Response of command:\n" + strBfr
								+ "\n*************************\n");
						
						if(strBfr.contains("Connection closed by foreign host"))
						{
							telnet.disconnect();
							return -2;
						}
						if (strBfr.contains("RESP:0")) {
							responseCFNRC = 1;
							
						} else {
							responseCFNRC = -1;
						}
					}
					
					logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] "
							+ "VCC_CFNRY_ENABLE["+Config.VCC_CFNRY_ENABLE+"] Flag Up responseCFNRY["+responseCFNRY+"] "
							+ "VCC_CFB_ENABLE["+Config.VCC_CFB_ENABLE+"] Flag Up responseCFB["+responseCFB+"] "
							+ "VCC_CFNRC_ENABLE["+Config.VCC_CFNRC_ENABLE+"] Flag Up responseCFNRC["+responseCFNRC+"]");
					
					if (Config.VCC_CFNRY_ENABLE!=1) {
						responseCFNRY = 1;
					}
					if (Config.VCC_CFB_ENABLE!=1) {
						responseCFB = 1;
					}
					if (Config.VCC_CFNRC_ENABLE!=1) {
						responseCFNRC = 1;
					}
					
					if (responseCFNRY==1 && responseCFB==1 && responseCFNRC==1) {
						response = "0";
					}
					// Addition by Avishkar on 06/09/2020 ends
					
					// Commented by Avishkar on 06/09/2020 start
					/*req3CmdStr = Config.TelnetRequestForUF.replace("<msisdn>",
							dataObject.getMsisdn());
					  
					req3CmdStr = req3CmdStr.replace("<FTN_Number>",Config.FTN_NUMBER);
					strBfr = sendCommand(req3CmdStr.trim() ,  dataObject.getMsisdn().trim() ,dataObject.getReqType());
					logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] Response of command:\n" + strBfr
						+ "\n*************************\n");
					
					if(strBfr.contains("Connection closed by foreign host"))
					{
						telnet.disconnect();
						return -2;
					}
					
					if (strBfr.contains("SUCCESS0001:Operation is successful")) {
						response = "0";
						
					}
					else if (strBfr.contains("SUCCESS0002:Already existed")) {
						response = "0";
						
					}
					else {
						response = "-1";
					}*/
					// Commented by Avishkar on 06/09/2020 ends
				}
				else if (dataObject.getReqType() == 4) {
					// Addition by Avishkar on 06/09/2020 start
					if (Config.VCC_CFNRY_ENABLE==1) {
						req4CmdStr = Config.TelentRequestFor_CFNRY_DF.replace("<msisdn>",
								dataObject.getMsisdn());
						strBfr = sendCommand(req4CmdStr.trim() ,  dataObject.getMsisdn().trim() ,dataObject.getReqType());
						logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] Response of command:\n" + strBfr
								+ "\n*************************\n");
						
						if(strBfr.contains("Connection closed by foreign host"))
						{
							telnet.disconnect();
							return -2;
						}
						if (strBfr.contains("RESP:0")) {
							responseCFNRY = 1;
							
						} else {
							responseCFNRY = -1;
						}
						
					} 
					if (Config.VCC_CFB_ENABLE==1) {
						req4CmdStr = Config.TelentRequestFor_CFB_DF.replace("<msisdn>",
								dataObject.getMsisdn());
						strBfr = sendCommand(req4CmdStr.trim() ,  dataObject.getMsisdn().trim() ,dataObject.getReqType());
						logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] Response of command:\n" + strBfr
								+ "\n*************************\n");
						
						if(strBfr.contains("Connection closed by foreign host"))
						{
							telnet.disconnect();
							return -2;
						}
						if (strBfr.contains("RESP:0")) {
							responseCFB = 1;
							
						} else {
							responseCFB = -1;
						}
						
					}
					if (Config.VCC_CFNRC_ENABLE==1) {
						req4CmdStr = Config.TelentRequestFor_CFNRC_DF.replace("<msisdn>",
								dataObject.getMsisdn());
						strBfr = sendCommand(req4CmdStr.trim() ,  dataObject.getMsisdn().trim() ,dataObject.getReqType());
						logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] Response of command:\n" + strBfr
								+ "\n*************************\n");
						
						if(strBfr.contains("Connection closed by foreign host"))
						{
							telnet.disconnect();
							return -2;
						}
						if (strBfr.contains("RESP:0")) {
							responseCFNRC = 1;
							
						} else {
							responseCFNRC = -1;
						}
					}
					
					logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] "
							+ "VCC_CFNRY_ENABLE["+Config.VCC_CFNRY_ENABLE+"] Flag Down responseCFNRY["+responseCFNRY+"] "
							+ "VCC_CFB_ENABLE["+Config.VCC_CFB_ENABLE+"] Flag Down responseCFB["+responseCFB+"] "
							+ "VCC_CFNRC_ENABLE["+Config.VCC_CFNRC_ENABLE+"] Flag Down responseCFNRC["+responseCFNRC+"]");
					
					if (Config.VCC_CFNRY_ENABLE!=1) {
						responseCFNRY = 1;
					} 
					if (Config.VCC_CFB_ENABLE!=1) {
						responseCFB = 1;
					}
					if (Config.VCC_CFNRC_ENABLE!=1) {
						responseCFNRC = 1;
					}
					
					if (responseCFNRY==1 || responseCFB==1 || responseCFNRC==1) {
						response = "0";
					}
					// Addition by Avishkar on 06/09/2020 ends
					
					// Commented by Avishkar on 06/09/2020 start
					/*req4CmdStr = Config.TelnetRequestForDF.replace("<msisdn>",
							dataObject.getMsisdn());
					strBfr = sendCommand(req4CmdStr.trim() , dataObject.getMsisdn().trim() , dataObject.getReqType());
					logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] Response of command:\n" + strBfr
						+ "\n*************************\n");
					
					if(strBfr.contains("Connection closed by foreign host"))
					{
						telnet.disconnect();
						return -2;
					}
					
					if (strBfr.contains("SUCCESS0001:Operation is successful")) {
						response = "0";
						
					}
					else if (strBfr.contains("SUCCESS0002:Already existed")) {
						response = "0";
						
					}
					else {
						response = "-1";
					}*/
					// Commented by Avishkar on 06/09/2020 start
				}
				
			}

			 if (Config.TESTING!=1) { // this testing condition check is added by Avishkar on 3-09-2020
				 if(dataObject.getReqType() == 6 || dataObject.getReqType() == 7)
					{
					// addition by Avishkar on 10/09/2020 start
					 
					 	if(response.equalsIgnoreCase("0"))
						{
					 		logger.debug("##> msisdn["+dataObject.getMsisdn()+"] while checking prepostranges imsiBitValueBuf:["+imsiBitValueBuf+"]");
							if (Config.prepostranges.contains(imsiBitValueBuf.toString())) {
								if (Config.prepaidCheck==0) { // means if prepostrange contain imsi digit and prepaidcheck=0 then Prepaid
									logger.info("##> msisdn["+dataObject.getMsisdn()+"] prepaidCheck["+Config.prepaidCheck+"]\n\n\t\t***[" + dataObject.getMsisdn()
											+ "] is PrePaid..***\n\n");
									dataObject.setIsPrePaidId("Y");
								} else if (Config.prepaidCheck==1) { // means if prepostrange contain imsi digit and prepaidcheck=1 then Postpaid
									logger.info("##> msisdn["+dataObject.getMsisdn()+"] prepaidCheck["+Config.prepaidCheck+"]\n\n\t\t***[" + dataObject.getMsisdn()
											+ "] is PostPaid..***\n\n");
									dataObject.setIsPrePaidId("N");
								}
								
							} else {
								if (Config.prepaidCheck==0) { // means if prepostrange doesn't contain imsi digit and prepaidcheck=0 then Postpaid
									logger.info("##> msisdn["+dataObject.getMsisdn()+"] prepaidCheck["+Config.prepaidCheck+"] IMSI digit found but does not match with prepostranges \n\n\t\t***[" + dataObject.getMsisdn()
											+ "] is PostPaid..***\n\n");
									dataObject.setIsPrePaidId("N");
								} else if (Config.prepaidCheck==1) { // means if prepostrange doesn't contain imsi digit and prepaidcheck=1 then Prepaid
									logger.info("##> msisdn["+dataObject.getMsisdn()+"] prepaidCheck["+Config.prepaidCheck+"] IMSI digit found but does not match with prepostranges \n\n\t\t***[" + dataObject.getMsisdn()
											+ "] is PrePaid..***\n\n");
									dataObject.setIsPrePaidId("Y");
								}
							}
							imsiBitValueBuf=null;
						} else {
							logger.info("##> msisdn["+dataObject.getMsisdn()+"] \n\n\t\t***[" + dataObject.getMsisdn()
									+ "] fail case ***\n\n");
							dataObject.setIsPrePaidId("N");
							response = "-1";
							imsiBitValueBuf=null;
						}
					 
						/*if(response.equalsIgnoreCase("0"))
						{
							if (Config.prePaid_tplId.contains(tplId[1].trim())) {
								logger.info("##> msisdn["+dataObject.getMsisdn()+"] \n\n\t\t***[" + dataObject.getMsisdn()
								+ "] is PrePaid..***\n\n");
								dataObject.setIsPrePaidId("Y");
							} else if(Config.postPaid_tplId.contains(tplId[1].trim()))  {
								logger.info("##> msisdn["+dataObject.getMsisdn()+"] \n\n\t\t***[" + dataObject.getMsisdn()
								+ "] is PostPaid..***\n\n");
								dataObject.setIsPrePaidId("N");
							}
							else
							{
								logger.info("##> msisdn["+dataObject.getMsisdn()+"] \n\n\t\t***[" + dataObject.getMsisdn()
								+ "] fail case success case***\n\n");
								dataObject.setIsPrePaidId("N");
								response = "-1";
							}
						}
						else {
							dataObject.setIsPrePaidId("N");
						}*/
					
					// addition by Avishkar on 10/09/2020 start
					}
					else
					{
						dataObject.setIsPrePaidId("N");
				}
			}
			 
				//for checking suspended..
			if(dataObject.getReqType() == 7 && !dataObject.getIsPrePaidId().equalsIgnoreCase("Y"))
				{
				   logger.debug("###msisdn["+dataObject.getMsisdn()+"] reqType["+dataObject.getReqType()+"] IsPrepaid["+dataObject.getIsPrePaidId()+"] checking OBO and NAM");	  
				   if(strBfr.contains("OBO,1"))
				   {
					   if(strBfr.contains("NAM,1"))
					   {
						   dataObject.setIsPrePaidId("N"); //as a postpaid and suspended
					   }
					   else {
						   dataObject.setIsPrePaidId("Y"); //not suspended
					}
				   }
				   else {
					   dataObject.setIsPrePaidId("Y"); //not suspended
				   }
			}
			
			imsiBitValueBuf=null;
			dataObject.setResponse(response);
			logger.info("\n After processing request Data is: [\n\n" + dataObject
					+ "\n\n]");
			logger.debug("Processor thread : "
					+ Thread.currentThread().getName());
			return 1;
		}
		catch(NullPointerException nullexp)
		{
			nullexp.printStackTrace();
			dataObject.setResponse("-1");
			logger.info("\n After processing request Data is: [\n\n" + dataObject
					+ "\n\n]");
			return -1;
		}
		catch (Exception e) {
			
			e.printStackTrace();
			dataObject.setResponse("-1");
			logger.info("\n After processing request Data is: [\n\n" + dataObject
					+ "\n\n]");
			return -1;
		}
   }
	public synchronized boolean  keepAlive() {
		
		//connector code
		logger.debug("Inside KeepAlive....objectNo["+objectNo+"] telnet.isConnected();["+telnet.isConnected()+"]");
		try {
			StringBuffer buffer = new StringBuffer();
				if (!isConnected) {
					logger.debug("telnet client isConnected [" + isConnected + "]");
					telnet.setConnectTimeout(Config.connectionTimeOut);
					/*logger.info("\n\n\t\t***connecting to telnet server at  ["
							+ Config.TELNET_CONFIGUREDIP + "] & [" + Config.PORT + "]***\n\n");
					telnet.connect(Config.TELNET_CONFIGUREDIP, Config.PORT);*/
					
					logger.info("\n\n\t\t***connecting to telnet server at  ["
					+ telnetIp + "] & [" + telnetPort + "]***\n\n");
					telnet.connect(telnetIp, telnetPort);
					telnet.setKeepAlive(true);	
					logger.info("checking connect to telnet client ["
							+ telnet.isConnected() + "]");
					// Get input and output stream references
					
					telnetInputStream = telnet.getInputStream();
					telnetDataInputStream = new DataInputStream(telnetInputStream);
					telnetOutStream = new PrintStream(telnet.getOutputStream());
					//telenetReader = new BufferedReader(new InputStreamReader(telnetInputStream));

					// Log the user on
					logger.info("Trying to login.....");
					if (Config.TESTING == 1) {
						logger.info("\n\n\t\t***TESTING is Enabled***LOGINCMD["
								+ Config.LOGINFRMT + ":" + Config.PASSWORDFRMT + "]\n\n");
						strbfr = readUntil(Config.LOGINFRMT , "LOGIN" ,0,buffer,0);
						logger.info("\n" + strbfr + "\n\n");
						//write(Config.REMOTEUSER);
						write(loginName, "LOGIN" ,0);
						strbfr = readUntil(Config.PASSWORDFRMT , "LOGIN" ,0,buffer,0);
						logger.info("\n\n" + strbfr + "\n\n");
						write(password ,"LOGIN" ,0);
						//write(Config.REMOTEPASSWD);
						// Advance to a REMOTETERMINATOR/prompt
						strbfr = readUntil(Config.REMOTETERMINATOR + "" , "LOGIN",0,buffer,0);
						isConnected = true;
					} else {
						logger.debug("\n\n\t\ttelnet server initial pattern to read ["
								+ Config.REMOTETERMINATOR + "]\n\n");
						strbfr = readUntil(Config.REMOTETERMINATOR + "" , "LOGIN",0,buffer,0);
						logger.info("\n\n\t\tresponse of REMOTETERMINATOR cmd ["
								+ strbfr + "]\n\n");
						logger.debug("\n\n\t\tlogging to REMOTE telnet server with ["
								+ loginCmd4Live + "]\n\n");
						write(loginCmd4Live + "\r" ,"LOGIN",0);
						// Advance to a REMOTETERMINATOR/prompt
						strbfr = readUntil(Config.REMOTETERMINATOR + "" ,"LOGIN",0,buffer,0);
						if (strbfr.contains(Config.LOGIN_VALIDATOR)) {
							isConnected = true;
							logger.info("\n\n\t\t***Logged in sucessfully*** isConnected ["
									+ isConnected + "]\n\n");
						} else {
							isConnected = false;
							logger.info("\n\n\t\t***Unable to login***isConnected ["
									+ isConnected + "]\n\n");
						}
					}
					// Advance to a REMOTETERMINATOR/prompt
					logger.info("\n\n" + strbfr + "\n\n");
				} else {
					if(Config.TESTING!=1){
						write(Config.CONNECTION_CHECKING_CMD + "" ,"KEEPALIVE" , 1);
						//Advance to a REMOTETERMINATOR/prompt
						// modified by 
//						strbfr = readUntil(Config.REMOTETERMINATOR + "" ,"KEEPALIVE_CHECK",1,buffer,0);
						strbfr = readUntil(Config.REMOTETERMINATOR + "" ,"KEEPALIVE",1,buffer,0);
						logger.debug("##>>checking connection resp["+strbfr+"]");
//						if (strbfr.contains("END")) {
						if (strbfr.contains("RESP:0")) { // modified by Avishkar on 10/09/2020
							isConnected = true;
							logger.debug("\n\n\t\t isConnected is " + isConnected);
									
						} 
						else if (strbfr.contains("Connection closed by foreign host")) {
							isConnected = false;
							logger.debug("\n\n\t\t isConnected is " + isConnected
									+ " lost going to reconnect agian \n\n");
							telnet.disconnect();
						    keepAlive(); 
						}
						else {
							isConnected = false;
							logger.info("\n\n\t\t isConnected is " + isConnected);
						}
						logger.debug("\n\n\t\t isConnected is " + isConnected);
					}
				}
			
		}
		catch(NullPointerException nullexp)
		{
			logger.error("problem in connecting HLR", nullexp);
			nullexp.printStackTrace();
		}
		catch (Exception e) {
			logger.error("problem in connecting HLR", e);
			e.printStackTrace();
		}
	    return isConnected;
	}
	
	public synchronized String readUntil(String pattern,String action,int reqType , StringBuffer buffer , int reloginCounter) {
		StringBuffer sb = new StringBuffer();
		
		logger.info("readUntil with pattern [" + pattern + "] objectNo["+objectNo+"] action["+action+"] reqType["+reqType+"] reloginCounter["+reloginCounter+"]");
		try {
		//	System.out.println("telnetInputStream["+telnetInputStream+"] ");
			char ch;
			if(action.equalsIgnoreCase("LOGIN") || action.equalsIgnoreCase("KEEPALIVE"))
			{
				synchronized (telnetDataInputStream) {
				ch = (char) telnetDataInputStream.read();
				int i = ch;
			//	System.out.println("ch["+ch+"] intVal["+i+"]");
				
				while (true) {
					sb.append(ch);
					if (sb.toString().contains(pattern)) {
							logger.debug("action["+action+"] reqType["+reqType+"] final response found is ["
									+ sb.toString().trim() + "]\n\n\n\n\n");
							return sb.toString().trim();
						
					}
					ch = (char) telnetInputStream.read();
					i = ch;
				//	System.out.println("ch["+ch+"] intVal["+i+"]");
				}
			   }
			}
			else
			{
			
				logger.debug("##action["+action+"] reqType["+reqType+"] else case ...");
			    synchronized (telnetDataInputStream) {
			    byte[] buf = new byte[2048];
			    telnetDataInputStream.read(buf);
				String bufferData = new String(buf).trim();
						
			    if(!bufferData.equalsIgnoreCase("null"))
				{
			  	
			    	if(reloginCounter == 5)
			    	{
			    		logger.info("##>>action["+action+"] Connection lost ");
						isConnected = false;
						return "Connection closed by foreign host";
			    	}
			    	
			    	buffer.append(bufferData);
			    	logger.info("##>>action ["+action+"] reqType["+reqType+"] bufferData["+bufferData+"] avialble bytes["+telnetInputStream.available()+"] buffer["+buffer+"]");
			    	if(reqType == 3 || reqType == 4)
			    	{
					if(buffer.toString().contains(pattern) || buffer.toString().contains("Connection closed by foreign host"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"]  final response found is ["
							+ buffer.toString() + "]\n\n\n\n\n");
						return buffer.toString();
					}
					/*else if(buffer.toString().contains("RESP:1") || buffer.toString().contains("RESP:6") || buffer.toString().contains("RESP:13") ||  buffer.toString().contains("RESP:14") || buffer.toString().contains("RESP:42") || buffer.toString().contains("RESP:46") || buffer.toString().contains("RESP:52") || buffer.toString().contains("RESP:53") || buffer.toString().contains("RESP:63") || buffer.toString().contains("RESP:64") || buffer.toString().contains("RESP:65") || buffer.toString().contains("RESP:70") || buffer.toString().contains("RESP:73") || buffer.toString().contains("RESP:25") || buffer.toString().contains("RESP:27"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:10534") || buffer.toString().contains("RESP:10535") || buffer.toString().contains("RESP:10541") ||  buffer.toString().contains("RESP:10546") || buffer.toString().contains("RESP:10804") || buffer.toString().contains("RESP:12006"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:1001") || buffer.toString().contains("RESP:1002") || buffer.toString().contains("RESP:1003"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:2002") || buffer.toString().contains("RESP:2003"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:3001") || buffer.toString().contains("RESP:3002") || buffer.toString().contains("RESP:3003") || buffer.toString().contains("RESP:3004") || buffer.toString().contains("RESP:3005") || buffer.toString().contains("RESP:3007") || buffer.toString().contains("RESP:3008") || buffer.toString().contains("RESP:3009") || buffer.toString().contains("RESP:3010") || buffer.toString().contains("RESP:3011") || buffer.toString().contains("RESP:3012"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}*/
					else {
						logger.info("##>>action["+action+"] reqType["+reqType+"] RESP not found reading again...");
						reloginCounter++;
						return readUntil(pattern, action , reqType,buffer,reloginCounter);
					}
				   }
			  else{
					if(buffer.toString().contains(pattern) || buffer.toString().contains("Connection closed by foreign host"))
					{
					logger.debug("action["+action+"] reqType["+reqType+"] final response found is ["
							+ buffer.toString() + "]\n\n\n\n\n");
						return buffer.toString();
					}
					/*else if(buffer.toString().contains("RESP:1") || buffer.toString().contains("RESP:6") || buffer.toString().contains("RESP:13") ||  buffer.toString().contains("RESP:14") || buffer.toString().contains("RESP:42") || buffer.toString().contains("RESP:46") || buffer.toString().contains("RESP:52") || buffer.toString().contains("RESP:53") || buffer.toString().contains("RESP:63") || buffer.toString().contains("RESP:64") || buffer.toString().contains("RESP:65") || buffer.toString().contains("RESP:70") || buffer.toString().contains("RESP:73") || buffer.toString().contains("RESP:25") || buffer.toString().contains("RESP:27") || buffer.toString().contains("OICK,25") || buffer.toString().contains("OICK,27"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:10534") || buffer.toString().contains("RESP:10535") || buffer.toString().contains("RESP:10541") ||  buffer.toString().contains("RESP:10546") || buffer.toString().contains("RESP:10804") || buffer.toString().contains("RESP:12006"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:1001") || buffer.toString().contains("RESP:1002") || buffer.toString().contains("RESP:1003"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:2002") || buffer.toString().contains("RESP:2003"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:3001") || buffer.toString().contains("RESP:3002") || buffer.toString().contains("RESP:3003") || buffer.toString().contains("RESP:3004") || buffer.toString().contains("RESP:3005") || buffer.toString().contains("RESP:3007") || buffer.toString().contains("RESP:3008") || buffer.toString().contains("RESP:3009") || buffer.toString().contains("RESP:3010") || buffer.toString().contains("RESP:3011") || buffer.toString().contains("RESP:3012"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}*/
				else {
						logger.info("##>>action ["+action+"] reqType["+reqType+"] RESP not found so reading again...");
						reloginCounter++;
						return readUntil(pattern, action , reqType,buffer,reloginCounter);
					}
				}
				}
				else {
					logger.debug("action["+action+"] null found..");
					reloginCounter++;
					return readUntil(pattern, action , reqType,buffer,reloginCounter);
				}
			  }
		 	}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("\n\n\tProblem in reading value from server: \n", e);
		}
		System.out.println("String buffer["+sb.toString()+"]");
		return sb.toString() + "...default string";
	} //working live and tested

	
	public synchronized String readUntilUpDown(String pattern,String action,int reqType , StringBuffer buffer , int reloginCounter) {
		StringBuffer sb = new StringBuffer();
		
		logger.info("readUntilUpDown with pattern [" + pattern + "] objectNo["+objectNo+"] action["+action+"] reqType["+reqType+"] reloginCounter["+reloginCounter+"]");
		try {
		//	System.out.println("telnetInputStream["+telnetInputStream+"] ");
			char ch;
			if(action.equalsIgnoreCase("LOGIN") || action.equalsIgnoreCase("KEEPALIVE"))
			{
				synchronized (telnetDataInputStream) {
				ch = (char) telnetDataInputStream.read();
				int i = ch;
			//	System.out.println("ch["+ch+"] intVal["+i+"]");
				
				while (true) {
					sb.append(ch);
					if (sb.toString().contains(pattern)) {
							logger.debug("action["+action+"] reqType["+reqType+"] final response found is ["
									+ sb.toString().trim() + "]\n\n\n\n\n");
							return sb.toString().trim();
						
					}
					ch = (char) telnetInputStream.read();
					i = ch;
				//	System.out.println("ch["+ch+"] intVal["+i+"]");
				}
			   }
			}
			else
			{
			
				logger.debug("##readUntilUpDown action["+action+"] reqType["+reqType+"] else case ...");
			    synchronized (telnetDataInputStream) {
			    byte[] buf = new byte[2048];
			    telnetDataInputStream.read(buf);
				String bufferData = new String(buf).trim();
						
			    if(!bufferData.equalsIgnoreCase("null"))
				{
			    	if(reloginCounter == 5)
			    	{
			    		logger.info("##>>action["+action+"] Connection lost ");
						isConnected = false;
						return "Connection closed by foreign host";
			    	}
			    	
			    	buffer.append(bufferData);
			    	logger.info("##>>action ["+action+"] reqType["+reqType+"] bufferData["+bufferData+"] avialble bytes["+telnetInputStream.available()+"] buffer["+buffer+"]");
			    	if(reqType == 3 || reqType == 4)
			    	{
					if(buffer.toString().contains(pattern) || buffer.toString().contains("Connection closed by foreign host"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"]  final response found is ["
							+ buffer.toString() + "]\n\n\n\n\n");
						return buffer.toString();
					}
					/*else if(buffer.toString().contains("RESP:1") || buffer.toString().contains("RESP:6") || buffer.toString().contains("RESP:13") ||  buffer.toString().contains("RESP:14") || buffer.toString().contains("RESP:42") || buffer.toString().contains("RESP:46") || buffer.toString().contains("RESP:52") || buffer.toString().contains("RESP:53") || buffer.toString().contains("RESP:63") || buffer.toString().contains("RESP:64") || buffer.toString().contains("RESP:65") || buffer.toString().contains("RESP:70") || buffer.toString().contains("RESP:73") || buffer.toString().contains("RESP:25") || buffer.toString().contains("RESP:27"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:10534") || buffer.toString().contains("RESP:10535") || buffer.toString().contains("RESP:10541") ||  buffer.toString().contains("RESP:10546") || buffer.toString().contains("RESP:10804") || buffer.toString().contains("RESP:12006"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:1001") || buffer.toString().contains("RESP:1002") || buffer.toString().contains("RESP:1003"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:2002") || buffer.toString().contains("RESP:2003"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:3001") || buffer.toString().contains("RESP:3002") || buffer.toString().contains("RESP:3003") || buffer.toString().contains("RESP:3004") || buffer.toString().contains("RESP:3005") || buffer.toString().contains("RESP:3007") || buffer.toString().contains("RESP:3008") || buffer.toString().contains("RESP:3009") || buffer.toString().contains("RESP:3010") || buffer.toString().contains("RESP:3011") || buffer.toString().contains("RESP:3012"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}*/
					else {
						logger.info("##>>action["+action+"] reqType["+reqType+"] RESP not found reading agian...");
						reloginCounter++;
						return readUntilUpDown(pattern, action , reqType,buffer,reloginCounter);
					}
				   }
			  else{
					if(buffer.toString().contains(pattern) || buffer.toString().contains("Connection closed by foreign host"))
					{
					logger.debug("action["+action+"] reqType["+reqType+"] final response found is ["
							+ buffer.toString() + "]\n\n\n\n\n");
						return buffer.toString();
					}
					/*else if(buffer.toString().contains("RESP:1") || buffer.toString().contains("RESP:6") || buffer.toString().contains("RESP:13") ||  buffer.toString().contains("RESP:14") || buffer.toString().contains("RESP:42") || buffer.toString().contains("RESP:46") || buffer.toString().contains("RESP:52") || buffer.toString().contains("RESP:53") || buffer.toString().contains("RESP:63") || buffer.toString().contains("RESP:64") || buffer.toString().contains("RESP:65") || buffer.toString().contains("RESP:70") || buffer.toString().contains("RESP:73") || buffer.toString().contains("RESP:25") || buffer.toString().contains("RESP:27") || buffer.toString().contains("OICK,25") || buffer.toString().contains("OICK,27"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:10534") || buffer.toString().contains("RESP:10535") || buffer.toString().contains("RESP:10541") ||  buffer.toString().contains("RESP:10546") || buffer.toString().contains("RESP:10804") || buffer.toString().contains("RESP:12006"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:1001") || buffer.toString().contains("RESP:1002") || buffer.toString().contains("RESP:1003"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:2002") || buffer.toString().contains("RESP:2003"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:3001") || buffer.toString().contains("RESP:3002") || buffer.toString().contains("RESP:3003") || buffer.toString().contains("RESP:3004") || buffer.toString().contains("RESP:3005") || buffer.toString().contains("RESP:3007") || buffer.toString().contains("RESP:3008") || buffer.toString().contains("RESP:3009") || buffer.toString().contains("RESP:3010") || buffer.toString().contains("RESP:3011") || buffer.toString().contains("RESP:3012"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}*/
				else {
						logger.info("##>>action ["+action+"] reqType["+reqType+"] RESP not found so reading again...");
						reloginCounter++;
						return readUntil(pattern, action , reqType,buffer,reloginCounter);
					}
				}
				}
				else {
					logger.debug("readUntilUpDown action["+action+"] null found..");
					reloginCounter++;
					return readUntilUpDown(pattern, action , reqType,buffer,reloginCounter);
				}
			  }
		 	}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("\n\n\tProblem in reading value from server: \n", e);
		}
		System.out.println("String buffer["+sb.toString()+"]");
		return sb.toString() + "...default string";
	} //working live and tested

	public synchronized String readUntilSix(String pattern,String action,int reqType , StringBuffer buffer , int reloginCounter) {
		StringBuffer sb = new StringBuffer();
		
		logger.info("readUntilSix with pattern [" + pattern + "] objectNo["+objectNo+"] action["+action+"] reqType["+reqType+"] reloginCounter["+reloginCounter+"]");
		try {
		//	System.out.println("telnetInputStream["+telnetInputStream+"] ");
			char ch;
			if(action.equalsIgnoreCase("LOGIN") || action.equalsIgnoreCase("KEEPALIVE"))
			{
				synchronized (telnetDataInputStream) {
				ch = (char) telnetDataInputStream.read();
				int i = ch;
			//	System.out.println("ch["+ch+"] intVal["+i+"]");
				
				while (true) {
					sb.append(ch);
					if (sb.toString().contains(pattern)) {
							logger.debug("action["+action+"] reqType["+reqType+"] final response found is ["
									+ sb.toString().trim() + "]\n\n\n\n\n");
							return sb.toString().trim();
						
					}
					ch = (char) telnetInputStream.read();
					i = ch;
				//	System.out.println("ch["+ch+"] intVal["+i+"]");
				}
			   }
			}
			else
			{
			
				logger.debug("##readUntilSix action["+action+"] reqType["+reqType+"] else case ...");
			    synchronized (telnetDataInputStream) {
			    byte[] buf = new byte[2048];
			    telnetDataInputStream.read(buf);
				String bufferData = new String(buf).trim();
						
			    if(!bufferData.equalsIgnoreCase("null"))
				{
			    	if(reloginCounter == 5)
			    	{
			    		logger.info("##>>action["+action+"] Connection lost ");
						isConnected = false;
						return "Connection closed by foreign host";
			    	}
			    	buffer.append(bufferData);
			    	logger.info("##>>action ["+action+"] reqType["+reqType+"] bufferData["+bufferData+"] avialble bytes["+telnetInputStream.available()+"] buffer["+buffer+"]");
			    	if(reqType == 3 || reqType == 4)
			    	{
					if(buffer.toString().contains(pattern) || buffer.toString().contains("Connection closed by foreign host"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"]  final response found is ["
							+ buffer.toString() + "]\n\n\n\n\n");
						return buffer.toString();
					}
					/*else if(buffer.toString().contains("RESP:1") || buffer.toString().contains("RESP:6") || buffer.toString().contains("RESP:13") ||  buffer.toString().contains("RESP:14") || buffer.toString().contains("RESP:42") || buffer.toString().contains("RESP:46") || buffer.toString().contains("RESP:52") || buffer.toString().contains("RESP:53") || buffer.toString().contains("RESP:63") || buffer.toString().contains("RESP:64") || buffer.toString().contains("RESP:65") || buffer.toString().contains("RESP:70") || buffer.toString().contains("RESP:73") || buffer.toString().contains("RESP:25") || buffer.toString().contains("RESP:27"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:10534") || buffer.toString().contains("RESP:10535") || buffer.toString().contains("RESP:10541") ||  buffer.toString().contains("RESP:10546") || buffer.toString().contains("RESP:10804") || buffer.toString().contains("RESP:12006"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:1001") || buffer.toString().contains("RESP:1002") || buffer.toString().contains("RESP:1003"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:2002") || buffer.toString().contains("RESP:2003"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:3001") || buffer.toString().contains("RESP:3002") || buffer.toString().contains("RESP:3003") || buffer.toString().contains("RESP:3004") || buffer.toString().contains("RESP:3005") || buffer.toString().contains("RESP:3007") || buffer.toString().contains("RESP:3008") || buffer.toString().contains("RESP:3009") || buffer.toString().contains("RESP:3010") || buffer.toString().contains("RESP:3011") || buffer.toString().contains("RESP:3012"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}*/
					else {
						logger.info("##>>action["+action+"] reqType["+reqType+"] RESP not found reading agian...");
						reloginCounter++;
						return readUntil(pattern, action , reqType,buffer,reloginCounter);
					}
				   }
			  else{
					if(buffer.toString().contains(pattern) || buffer.toString().contains("Connection closed by foreign host"))
					{
					logger.debug("action["+action+"] reqType["+reqType+"] final response found is ["
							+ buffer.toString() + "]\n\n\n\n\n");
						return buffer.toString();
					}
					/*else if(buffer.toString().contains("RESP:1") || buffer.toString().contains("RESP:6") || buffer.toString().contains("RESP:13") ||  buffer.toString().contains("RESP:14") || buffer.toString().contains("RESP:42") || buffer.toString().contains("RESP:46") || buffer.toString().contains("RESP:52") || buffer.toString().contains("RESP:53") || buffer.toString().contains("RESP:63") || buffer.toString().contains("RESP:64") || buffer.toString().contains("RESP:65") || buffer.toString().contains("RESP:70") || buffer.toString().contains("RESP:73") || buffer.toString().contains("RESP:25") || buffer.toString().contains("RESP:27") || buffer.toString().contains("OICK,25") || buffer.toString().contains("OICK,27"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:10534") || buffer.toString().contains("RESP:10535") || buffer.toString().contains("RESP:10541") ||  buffer.toString().contains("RESP:10546") || buffer.toString().contains("RESP:10804") || buffer.toString().contains("RESP:12006"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:1001") || buffer.toString().contains("RESP:1002") || buffer.toString().contains("RESP:1003"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:2002") || buffer.toString().contains("RESP:2003"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}
					else if(buffer.toString().contains("RESP:3001") || buffer.toString().contains("RESP:3002") || buffer.toString().contains("RESP:3003") || buffer.toString().contains("RESP:3004") || buffer.toString().contains("RESP:3005") || buffer.toString().contains("RESP:3007") || buffer.toString().contains("RESP:3008") || buffer.toString().contains("RESP:3009") || buffer.toString().contains("RESP:3010") || buffer.toString().contains("RESP:3011") || buffer.toString().contains("RESP:3012"))
					{
						logger.debug("action["+action+"] reqType["+reqType+"] Error Code found final response found is ["
								+ buffer.toString() + "]\n\n\n\n\n");
							return buffer.toString();
					}*/
				else {
						logger.info("##>>action ["+action+"] reqType["+reqType+"] RESP not found so reading again...");
						reloginCounter++;
						return readUntilSix(pattern, action , reqType,buffer,reloginCounter);
					}
				}
				}
				else {
					logger.debug("readUntilSix action["+action+"] null found..");
					reloginCounter++;
					return readUntilSix(pattern, action , reqType,buffer,reloginCounter);
				}
			  }
		 	}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("\n\n\tProblem in reading value from server: \n", e);
		}
		System.out.println("String buffer["+sb.toString()+"]");
		return sb.toString() + "...default string";
	} //working live and tested


	public synchronized void write(String value,String action,int reqType) {
		try {
			synchronized (telnetOutStream) {
				logger.debug("action["+action+"] In wirte Synch block value to be written ["
						+ value + "] objectNo["+objectNo+"] reqType["+reqType+"]");
				System.out.println("Going to write to Stream");
				telnetOutStream.println(value);
				telnetOutStream.flush();
				System.out.println("Writeen to Stream");
				
			}
			logger.debug("action["+action+"] Value send to HLR server[" + value + "]");
		} catch (Exception e) {
			e.printStackTrace();
			logger.fatal("\n\n\t\tProblem in writing value\n\n ", e);
		}
	}
    
	public synchronized String sendCommand(String command ,String action , int reqType) {
		logger.info("in sendCommand going to hit command [" + command + "] objectNo["+objectNo+"] reqType["+reqType+"]");
		try {
			StringBuffer buffer = new StringBuffer();
			int reloginCounter = 0;
			write(command+"\r" , action , reqType);
			logger.debug("action["+action+"] in sent Command [" + command + "] ");
			if(reqType == 3 || reqType == 4)
			{
				return readUntilUpDown(Config.REMOTETERMINATOR + "" , action , reqType , buffer,reloginCounter);
			}
			else if(reqType == 6)
			{
				return readUntilSix(Config.REMOTETERMINATOR + "" , action , reqType , buffer,reloginCounter);
			}
			else
			{
				return readUntil(Config.REMOTETERMINATOR + "" , action , reqType , buffer,reloginCounter);
			}
		} catch (Exception e) {
			logger.fatal("\n\n\t\tProblem in Sending command\n\n ");
			e.printStackTrace();
		}
		return null;
	}
	public boolean isConnected() {
		return isConnected;
	}

	public long getObjectNo() {
		return objectNo;
	}
	
	
	
	
}
