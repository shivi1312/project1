
package com.telemune;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SppringdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SppringdbApplication.class, args);
		System.out.println("Hello world");
			}

}
