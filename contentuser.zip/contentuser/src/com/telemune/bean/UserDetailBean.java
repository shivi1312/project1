/* * This class is used for UserDetailBean info for the user management.   */

package com.telemune.bean;

import org.springframework.stereotype.Component;

@Component
public class UserDetailBean
	{
	    private	String userId;
	    private	String userName;
	    private String password;
	    private	String email;	
	    private	String mobileNum;
	    private	String description;
	    private	int roleId;
	    private String address;
	    private String status;
	    private String roleName;
		
	    
		
		public void UserDetailBean ()
	    {
	        userId = "";
	        userName = "";
	        password = "";
	        email = "";
	        mobileNum = "";
	        description = "";
	        roleId = -1 ;
	        address="";
	        status="";
	      
	    }
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public void setUserId (String userId)
	    {
	        this.userId = userId; 
	   }
	    public void setUserName (String userName)
	    {
	        this.userName = userName;
	    }
	    public void setPassword (String password)
	    {
	        this.password = password;
	    }
	    public void setEmail (String email)
	    {
	    	 this.email = email;
	    }
	    public void setMobileNum (String mobileNum)
	    {
	        this.mobileNum = mobileNum;
	    }
	    public void setDescription (String description)
	    {
	        this.description = description;
 	   }
	    public void setRoleId (int roleId)
	    {
	        this.roleId = roleId;
	    }
	    public void setRoleName(String roleName) {
			this.roleName = roleName;
		}
	    public String getUserId ()
	    {
	        return userId;
	    }
	    public String getUserName ()
	    {
	        return userName;
	    }
	    public String getPassword ()
	    {
	        return password;
	    }
	    public String getEmail ()
	    {
	    	
	        return email;
	    }
	    public String getMobileNum ()
	    {	
	        return mobileNum;
	    }
	    public String getDescription ()
	    {
	        return description;
	    }
	    public int getRoleId ()
	    {
	        return roleId;
	    }
	    public String getRoleName() {
			return roleName;
		}
	    @Override
		public String toString() {
			return "UserDetailBean [userId=" + userId + ", userName=" + userName + ", password=" + password + ", email="
					+ email + ", mobileNum=" + mobileNum + ", description=" + description + ", roleId=" + roleId
					+ ", address=" + address + ", status=" + status + ", roleName=" + roleName
					+ "]";
		}
		/* *********    get Values         ******  */
	  
	    
 } // class UserDetailBean
