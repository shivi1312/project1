package com.telemune.bean;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component
@Scope("prototype")
public class AuthBean {
	 private static Logger logger=Logger.getLogger(AuthBean.class);
		private	String userId = "";
		private	int  userType = -1;
		private	String password = "";
		private SessionHistoryBean sessionHistoryBean =  null;
		
		/*private SessionHistory sessionHistory =  null;*/
		 public AuthBean()
		 {
			 
		 }
		 
		 public SessionHistoryBean getSessionHistoryBean() {
			return sessionHistoryBean;
		}

		public void setSessionHistoryBean(SessionHistoryBean sessionHistoryBean) {
			this.sessionHistoryBean = sessionHistoryBean;
		}
/*
		public  SessionHistoryBean getSessionHistory()
			{
				return sessionHistoryBean;
			}*/
		 
		public String getUserId() {
			return userId;
		}
		public void setUserId(String userId) {
			this.userId = userId;
		}
		public int getUserType() {
			return userType;
		}
		public void setUserType(int userType) {
			this.userType = userType;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		

		@Override
		public String toString() {
			return "AuthBean [userId=" + userId + ", userType=" + userType + ", password=" + password
					+ ", sessionHistoryBean=" + sessionHistoryBean + "]";
		}
		 

}
