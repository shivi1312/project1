package com.telemune.bean;

import org.springframework.stereotype.Component;

@Component
public class DownloadBean {
	
	
	String jobId="";
	String filePath="";
	
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	@Override
	public String toString() {
		return "DownloadBean [jobId=" + jobId + ", filePath=" + filePath + "]";
	}
	
	
	
	
}
