package com.telemune.bean;

import java.util.ArrayList;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class ContentUploadBean {

	private ArrayList allfileTypeList=null;
	private MultipartFile uploadFile;
	private MultipartFile uploadZip;
	private String filename;
	private String job_Id;
	private int fileTypeId=-1;
	private String contentTypeName="";
	private String errorTextFilename;
	private String fileCategory;
	
	public MultipartFile getUploadZip() {
		return uploadZip;
	}
	public void setUploadZip(MultipartFile uploadZip) {
		this.uploadZip = uploadZip;
	}
	public ArrayList getAllfileTypeList() {
		return allfileTypeList;
	}
	public void setAllfileTypeList(ArrayList allfileTypeList) {
		this.allfileTypeList = allfileTypeList;
	}
	public MultipartFile getUploadFile() {
		return uploadFile;
	}
	public void setUploadFile(MultipartFile uploadFile) {
		this.uploadFile = uploadFile;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getJob_Id() {
		return job_Id;
	}
	public void setJob_Id(String job_Id) {
		this.job_Id = job_Id;
	}
	public int getFileTypeId() {
		return fileTypeId;
	}
	public void setFileTypeId(int fileTypeId) {
		this.fileTypeId = fileTypeId;
	}
	public String getContentTypeName() {
		return contentTypeName;
	}
	public void setContentTypeName(String contentTypeName) {
		this.contentTypeName = contentTypeName;
	}
	public String getErrorTextFilename() {
		return errorTextFilename;
	}
	public void setErrorTextFilename(String errorTextFilename) {
		this.errorTextFilename = errorTextFilename;
	}
	
	public String getFileCategory() {
		return fileCategory;
	}
	public void setFileCategory(String fileCategory) {
		this.fileCategory = fileCategory;
	}
	@Override
	public String toString() {
		return "ContentUploadBean [allfileTypeList=" + allfileTypeList + ", uploadFile=" + uploadFile + ", uploadZip="
				+ uploadZip + ", filename=" + filename + ", job_Id=" + job_Id + ", fileTypeId=" + fileTypeId
				+ ", contentTypeName=" + contentTypeName + ", errorTextFilename=" + errorTextFilename
				+ ", fileCategory=" + fileCategory + "]";
	} 
	
	
	
}
