package com.telemune.bean;

import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.stereotype.Component;
@Component
public class RoleBean {
	private String check;
	private String[] linkAl;
	private String[] deleteAl;
	private String roleId;
	private String roleName;
	private String desc;
	private ArrayList dataListAl= new ArrayList();
	
	
	public String[] getDeleteAl() {
		return deleteAl;
	}
	public void setDeleteAl(String[] deleteAl) {
		this.deleteAl = deleteAl;
	}
	public String getCheck() {
		return check;
	}
	public void setCheck(String check) {
		this.check = check;
	}
	public String[] getLinkAl() {
		return linkAl;
	}
	public void setLinkAl(String[] deleteAl) {
		this.linkAl = deleteAl;
	}
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public ArrayList getDataListAl() {
		return dataListAl;
	}
	public void setDataListAl(ArrayList dataListAl) {
		this.dataListAl = dataListAl;
	}
	@Override
	public String toString() {
		return "RoleBean [check=" + check + ", linkAl=" + Arrays.toString(linkAl) + ", deleteAl="
				+ Arrays.toString(deleteAl) + ", roleId=" + roleId + ", roleName=" + roleName + ", desc=" + desc
				+ ", dataListAl=" + dataListAl + "]";
	}

	
	

}
