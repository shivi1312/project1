
package com.telemune.bean;

import org.springframework.stereotype.Component;

@Component
public class RoleDetailBean
{

    private String roleName;
    private String roleDesc;
    private int roleId;
    private String linkDesc;
    private int linkId;
	private boolean check;
	
    public boolean isCheck() {
		return check;
	}

	public void setCheck(boolean check) {
		this.check = check;
	}

	public  RoleDetailBean ()
    {
        roleName = "";
				roleDesc =" ";
        roleId = -1;
				linkDesc =" ";
        linkId = -1;
    }
    
    public void setRoleName (String roleName)
    {
        this.roleName = roleName;
    }
    public void setRoleDesc (String roleDesc)
    {
        this.roleDesc = roleDesc;
    }
    public void setRoleId (int roleId)
    {
        this.roleId = roleId;
    }
    public void setLinkDesc (String linkDesc)
    {
        this.linkDesc = linkDesc;
    }
    public void setLinkId (int linkId)
    {
        this.linkId = linkId;
    }
		
   /* ****   get Values  */ 
    public String getRoleName ()
    {
        return roleName;
    }
    public String getRoleDesc ()
    {
        return roleDesc;
    }
public int getRoleId()
    {
        return roleId;
    }
    public String getLinkDesc ()
    {
        return linkDesc;
    }
public int getLinkId()
    {
        return linkId;
    }

@Override
public String toString() {
	return "RoleDetailBean [roleName=" + roleName + ", roleDesc=" + roleDesc + ", roleId=" + roleId + ", linkDesc="
			+ linkDesc + ", linkId=" + linkId + ", check=" + check + "]";
}


}// class RoleType
