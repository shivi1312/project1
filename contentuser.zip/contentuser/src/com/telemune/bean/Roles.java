package com.telemune.bean;

public class Roles {

	private String roleName="";
	private int roleId=-1;
	public Roles() {
		// TODO Auto-generated constructor stub
	}
	
	public Roles(String roleName, int roleId) {
		super();
		this.roleName = roleName;
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	@Override
	public String toString() {
		return "Roles [roleName=" + roleName + ", roleId=" + roleId + "]";
	}
	
	
	
	
	
}
