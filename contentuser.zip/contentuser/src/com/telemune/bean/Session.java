package com.telemune.bean;

import java.io.Serializable;
import java.sql.Connection;
import java.util.ArrayList;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
@Component
@Scope("session")
public class Session implements Serializable {

	private String strUser;
	private ArrayList<Integer> link;
	private int roleId;
	private Connection con;


	public ArrayList<Integer> getLink() {
		return link;
	}


	public void setLink(ArrayList<Integer> link) {
		this.link = link;
	}
	public void SessionHistoryBean()
	{
		this.strUser = "";
	}	
	
	
	public String getStrUser() {
		return strUser;
	}
	public void setStrUser(String strUser) {
		this.strUser = strUser;
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public Connection getCon() {
		return con;
	}


	public void setCon(Connection con) {
		this.con = con;
	}


	@Override
	public String toString() {
		return "SessionHistoryBean [strUser=" + strUser + ", link=" + link + ", roleId=" + roleId + ", con=" + con
				+ "]";
	}
	
	
	

}
