package com.telemune.service;

import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.telemune.bean.ContentUploadBean;
import com.telemune.bean.DownloadBean;
import com.telemune.common.Global;
import com.telemune.common.JavaUtil;
import com.telemune.constant.Constants;
import com.telemune.dao.ContentManagerDao;

@Component

public class DownloadContentService 
{

	@Autowired
	ContentUploadBean contentUploadBean;
	
	@Autowired
	ContentManagerDao contentManagerDao;
	@Autowired
	Global globalMap;
	
	Logger  logger=Logger.getLogger(DownloadContentService.class);
	public ArrayList downloadContent()
	{
		ArrayList jobIdList=new ArrayList();
		logger.info("inside downloadContent............");
		try{
    		   
    		 ArrayList allfileTypeList= contentManagerDao.getAllFileTypes();
    		   jobIdList= contentManagerDao.getJobList(globalMap.sessionMap.get("user").toString());
    		   
    		   logger.info("inside downloadContent ,LIst Size in downloadContent jobIdList ["+jobIdList.size()+"]FileType list ["+allfileTypeList.size()+"]");
	
    		   contentUploadBean.setAllfileTypeList(allfileTypeList);
    		 
    		   return jobIdList;
    		   
			}
			catch(Exception e){
			logger.error(e);
			e.printStackTrace();
		
			}
		return jobIdList;
	}
	
	public int downloadContentExecute(DownloadBean downloadBean)
	{
		
		logger.info("inside downloadContentExecute...........JOBID ["+downloadBean.getJobId()+"]");
				try{
					String jobId =downloadBean.getJobId();
					StringBuffer stringBuffer=new StringBuffer();
						
					stringBuffer=contentManagerDao.getSheetPath(stringBuffer,jobId);
					
					logger.info("Sheet path ["+stringBuffer.toString()+"]");
					 String sheetPath=JavaUtil.instance().getSheetPath();
					 logger.info("Sheet path ["+sheetPath+"]");
					 String returnValue = "";
					 returnValue=   sheetPath + stringBuffer.toString(); 
					 
						logger.info("Return value ["+returnValue+"]"+"jobId======stringBuffer.toString()"+jobId+">>>>"+stringBuffer.toString());
						downloadBean.setFilePath(returnValue);
						globalMap.sessionMap.put("download_path",downloadBean.getFilePath());
						logger.info("filePath===========>>>>>>>>"+downloadBean.getFilePath());
						return Constants.SUCCESS;
				
				}
				catch(Exception ee){
					logger.error("error in downloadContentExecute ",ee);
					ee.printStackTrace();
					return Constants.EXCEPTION_OCCUR;
				}
	}
	

	
}
