/*package com.telemune.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import com.telemune.bean.ContentUploadBean;
import com.telemune.common.Global;
import com.telemune.common.JavaUtil;
import com.telemune.constant.Constants;
import com.telemune.dao.ContentManagerDao;

@Component
public class ContentManagerService {

	@Autowired
	ContentUploadBean contentUploadBean;
	@Autowired
	ContentManagerDao contentManagerDao;
	@Autowired
	Global globalMap;
	
	Logger  logger=Logger.getLogger(ContentManagerService.class);
	String jobId="";
	String message="";
	
	public Map<String, Object> jobIdContType(){

		Map<String, Object> map = new HashMap<String, Object>();
		logger.info("inside jobIdContType()...... ."+"]");
		ArrayList allfileTypeList= contentManagerDao.getAllFileTypes();
		SimpleDateFormat formatter1 = new SimpleDateFormat("dd/MM/yyyy/hhmm");
		String dt1 = formatter1.format(new java.util.Date());
			try{
				
					
					jobId=dt1+"_"+contentManagerDao.getJobIdSeq();
					logger.info("inside uploadContent ,LIst Size FileType list ["+allfileTypeList.size()+"] JOB_ID SEQ ["+jobId+"]");

					contentUploadBean.setAllfileTypeList(allfileTypeList);
					map.put("jobId",jobId);
					map.put("contentList",allfileTypeList);
			}

			catch(Exception e){

				logger.error("error in bulkUploadContent >>>>>>>>> "+e);
				//return -1;
			}
	
			finally
			{
				allfileTypeList=null;
				formatter1=null;
				dt1=null;
			}

			return map;
		}
	
	
	
	public int bulkUploadContent(ContentUploadBean contentUploadBean)
	{
		logger.info("inside bulkUploadContent()...... ."+"]");
		String bulkUploadPath="";
		
		try
		{
			bulkUploadPath = JavaUtil.instance().getAppConfigParam("BULK_CONTENT_UPLOAD_PATH");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		logger.info("bulkUploadPath"+bulkUploadPath);
		MultipartFile file=null;
		String uploadfileName="";
		String path_name="";
		String fileName="";
		boolean proceed=false;
		String fullpath="";
		fullpath=bulkUploadPath;
		File musicFolder=new File(fullpath);

		if(!musicFolder.exists())
		{

			musicFolder.mkdirs();

		}
		String validFileNameChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890_";
		logger.info("addNewContentBean.getUploadFile() ["+contentUploadBean.getUploadFile()+"]");
		logger.info("getUploadFile()......."+contentUploadBean.getUploadFile().toString());
		if(contentUploadBean.getUploadFile()!=null)
		{

			file=contentUploadBean.getUploadFile(); 
			logger.info("getUploadFile====="+file);
			uploadfileName=file.getOriginalFilename();
			logger.info("bulkFileName ["+uploadfileName+"]");
			StringBuffer musicfile_newname = new StringBuffer();
			for (int i=0;i<uploadfileName.length()-5;i++)
			{
				char c = uploadfileName.charAt(i);
				if (validFileNameChars.indexOf(c)== -1)
					musicfile_newname.append("_");
				else
					musicfile_newname.append(c);


			}
			String  fileExt=uploadfileName.trim().substring(uploadfileName.lastIndexOf(".")+1,uploadfileName.length());
			logger.info("FileExt ["+fileExt+"]");
			uploadfileName=musicfile_newname.toString()+"."+fileExt;
			fileName = uploadfileName.replace(' ','_').trim();
			logger.info("inside addNewContentExecute ,MusicPath ["+fullpath+"] sheetFileName ["+uploadfileName+"] ");
			path_name=fullpath;
			fullpath=fullpath+"/"+fileName;
			logger.info("fullpath>>>>>>>>>"+fullpath+" bean<<<<<<<"+contentUploadBean);
			
			try {
				file.transferTo(Paths.get(fullpath).toFile());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			logger.info("Successfully uploaded sheet at path ["+path_name+"]");
			proceed=true;
		
		
		
		}
		if(proceed){
			int res=contentManagerDao.insertIntoDB(jobId,globalMap.sessionMap.get("user").toString(),fullpath, contentUploadBean.getFileCategory());	
			if(res!=Constants.SUCCESS){
				return Constants.SUCCESS;

			}
			String fileType=contentUploadBean.getFileCategory();
			logger.info("JOB ID is ["+jobId+"] file type ["+fileType+"]");
			String scriptPath = "";
			if(fileType.equalsIgnoreCase("1")){
				scriptPath = JavaUtil.instance().getScriptPath();
				logger.info("scriptPath is ["+scriptPath);

			}
			//For Executing the Scrpit
			//1.Execute Script
			//2.Data for Failed RBTS
			//3.After getting Data change Status 
			try {
				Runtime run = Runtime.getRuntime();
				logger.info("scriptPath [" + scriptPath+ "] fileName [" + fullpath + "]  jobId ["+jobId+"] user ["+globalMap.sessionMap.get("user").toString()+"]");
				logger.info(" ==============>>>>>>> "+scriptPath + " "+ fullpath+ " "+ jobId+ " "+ globalMap.sessionMap.get("user").toString());
				Process p_scrpit = run.exec(scriptPath + " "+ fullpath+ " "+ jobId+ " "+ globalMap.sessionMap.get("user").toString());
				p_scrpit.waitFor();
				logger.info("Successfully executed the script");


			} catch (Exception exp) {
				logger.info("Problem in script Running" + exp);
			}



			StringBuffer buffer=new StringBuffer();
			contentManagerDao.getSheetPath(buffer, jobId);
			String returnValue="";
			returnValue=   "CSVReports/" + buffer.toString(); 
			logger.info("Return value ["+returnValue+"]");
			contentUploadBean.setFilename(returnValue);
			contentUploadBean.setErrorTextFilename(returnValue.substring(0,returnValue.lastIndexOf("/")) + ".txt");//Added by Mahesh
			return Constants.SUCCESS; 
		}

		else{
			logger.info("There was some error while uploading");
			return Constants.EXCEPTION_OCCUR;
		}
	}
		
}
*/





/*package com.telemune.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import com.telemune.bean.ContentUploadBean;
import com.telemune.common.Global;
import com.telemune.common.JavaUtil;
import com.telemune.constant.Constants;
import com.telemune.dao.ContentManagerDao;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

@Component
public class ContentManagerService {

	@Autowired
	ContentUploadBean contentUploadBean;
	@Autowired
	ContentManagerDao contentManagerDao;
	@Autowired
	Global globalMap;
	
	Logger  logger=Logger.getLogger(ContentManagerService.class);
	String jobId="";
	String message="";
	
	public Map<String, Object> jobIdContType(){

		Map<String, Object> map = new HashMap<String, Object>();
		logger.info("inside jobIdContType()...... ."+"]");
		ArrayList allfileTypeList= contentManagerDao.getAllFileTypes();
		SimpleDateFormat formatter1 = new SimpleDateFormat("dd/MM/yyyy/hhmm");
		String dt1 = formatter1.format(new java.util.Date());
			try{
				
					
					jobId=dt1+"_"+contentManagerDao.getJobIdSeq();
					logger.info("inside uploadContent ,LIst Size FileType list ["+allfileTypeList.size()+"] JOB_ID SEQ ["+jobId+"]");

					contentUploadBean.setAllfileTypeList(allfileTypeList);
					map.put("jobId",jobId);
					map.put("contentList",allfileTypeList);
			}

			catch(Exception e){

				logger.error("error in bulkUploadContent >>>>>>>>> "+e);
				//return -1;
			}
	
			finally
			{
				allfileTypeList=null;
				formatter1=null;
				dt1=null;
			}

			return map;
		}
	
	
	
	public int bulkUploadContent(ContentUploadBean contentUploadBean) throws IOException
	{
		logger.info("inside bulkUploadContent()...... ."+"]");
		String bulkUploadPath="";
		
		try
		{
			bulkUploadPath = JavaUtil.instance().getAppConfigParam("BULK_CONTENT_UPLOAD_PATH");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		logger.info("bulkUploadPath"+bulkUploadPath);
		MultipartFile file=null;
		String uploadfileName="";
		String path_name="";
		String fileName="";
		boolean proceed=false;
		String fullpath="";
		fullpath=bulkUploadPath;
		File musicFolder=new File(fullpath);

		if(!musicFolder.exists())
		{

			musicFolder.mkdirs();

		}
		String validFileNameChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890_";
		logger.info("addNewContentBean.getUploadFile() ["+contentUploadBean.getUploadFile()+"]");
		logger.info("getUploadFile()......."+contentUploadBean.getUploadFile().toString());
		if(contentUploadBean.getUploadFile()!=null)
		{

			file=contentUploadBean.getUploadFile(); 
			logger.info("getUploadFile====="+file);
			uploadfileName=file.getOriginalFilename();
			logger.info("bulkFileName ["+uploadfileName+"]");
			StringBuffer musicfile_newname = new StringBuffer();
			for (int i=0;i<uploadfileName.length()-5;i++)
			{
				char c = uploadfileName.charAt(i);
				if (validFileNameChars.indexOf(c)== -1)
					musicfile_newname.append("_");
				else
					musicfile_newname.append(c);


			}
			String  fileExt=uploadfileName.trim().substring(uploadfileName.lastIndexOf(".")+1,uploadfileName.length());
			logger.info("FileExt~~~~ ["+fileExt+"]" +"musicFile_newname==========="+musicfile_newname.toString());
			uploadfileName=musicfile_newname.toString()+"."+fileExt;
			fileName = uploadfileName.replace(' ','_').trim();
			logger.info("inside addNewContentExecute ,MusicPath ["+fullpath+"] sheetFileName ["+uploadfileName+"] ");
			path_name=fullpath;
			fullpath=fullpath+"/"+fileName;
			logger.info("fileName>>>>>>>>>"+fileName+"fileExt----"+fileExt);
			logger.info("fullpath>>>>>>>>>"+fullpath+" bean<<<<<<<"+contentUploadBean);
			System.out.println("fileExt");
			
			try {
				file.transferTo(Paths.get(fullpath).toFile());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//String  fileExt=uploadfileName.trim().substring(uploadfileName.lastIndexOf(".")+1,uploadfileName.length());
			if(fileExt.equalsIgnoreCase("zip"))
			{
				System.out.println("0");

			     byte[] buffer = new byte[8024];
			    	
			     try{
			    	System.out.println("1");	//logger("inside ");
			    	//create output directory is not exists
			    	File folder = new File(bulkUploadPath);
			    	if(!folder.exists()){
			    		System.out.println("2");
			    		folder.mkdir();
			    	}
			    		
			    	//get the zip file content
			    	ZipInputStream zis = 
			    		new ZipInputStream(new FileInputStream(fullpath));
			    	//get the zipped file list entry
			    	System.out.println("3");
			    	ZipEntry ze = zis.getNextEntry();
			    		
			    	while(ze!=null){
			    			
			    	   String fileName1 = ze.getName();
			    	   System.out.println(fullpath + File.separator + fileName1);
			           File newFile = new File(bulkUploadPath + File.separator + fileName1);
			           System.out.println("5");
			           System.out.println("file unzip : "+ newFile.getAbsoluteFile());
			                
			            //create all non exists folders
			            //else you will hit FileNotFoundException for compressed folder
			            new File(newFile.getParent()).mkdirs();
			              
			            FileOutputStream fos = new FileOutputStream(newFile);             
			            System.out.println("6");
			            int len;
			            while ((len = zis.read(buffer)) > 0) {
			       		fos.write(buffer, 0, len);
			            }
			            System.out.println("7");
			            fos.close();   
			            System.out.println("8");
			            ze = zis.getNextEntry();
			            System.out.println("9");
			    	}
			    	
			        zis.closeEntry();
			    	zis.close();
			    		
			    	System.out.println("Done");
			    		
			    }catch(IOException ex){
			       ex.printStackTrace(); 
			    }

			}

			logger.info("Successfully uploaded sheet at path ["+path_name+"]");
			proceed=true;
		
		
		
		}
		if(proceed){
			int res=contentManagerDao.insertIntoDB(jobId,globalMap.sessionMap.get("user").toString(),fullpath, contentUploadBean.getFileCategory());	
			if(res!=Constants.SUCCESS){
				return Constants.SUCCESS;

			}
			String fileType=contentUploadBean.getFileCategory();
			logger.info("JOB ID is ["+jobId+"] file type ["+fileType+"]");
			String scriptPath = "";
			if(fileType.equalsIgnoreCase("1")){
				scriptPath = JavaUtil.instance().getScriptPath();
				logger.info("scriptPath is ["+scriptPath);

			}
			//For Executing the Scrpit
			//1.Execute Script
			//2.Data for Failed RBTS
			//3.After getting Data change Status 
			try {
				Runtime run = Runtime.getRuntime();
				logger.info("scriptPath [" + scriptPath+ "] fileName [" + fullpath + "]  jobId ["+jobId+"] user ["+globalMap.sessionMap.get("user").toString()+"]");
				logger.info(" ==============>>>>>>> "+scriptPath + " "+ fullpath+ " "+ jobId+ " "+ globalMap.sessionMap.get("user").toString());
				Process p_scrpit = run.exec(scriptPath + " "+ fullpath+ " "+ jobId+ " "+ globalMap.sessionMap.get("user").toString());
				p_scrpit.waitFor();
				logger.info("Successfully executed the script");


			} catch (Exception exp) {
				logger.info("Problem in script Running" + exp);
			}



			StringBuffer buffer=new StringBuffer();
			contentManagerDao.getSheetPath(buffer, jobId);
			String returnValue="";
			returnValue=   "CSVReports/" + buffer.toString(); 
			logger.info("Return value ["+returnValue+"]");
			contentUploadBean.setFilename(returnValue);
			contentUploadBean.setErrorTextFilename(returnValue.substring(0,returnValue.lastIndexOf("/")) + ".txt");
			
			return Constants.SUCCESS; 
		}

		else{
			logger.info("There was some error while uploading");
			return Constants.EXCEPTION_OCCUR;
		}
	}
		
}
*/









package com.telemune.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
//import java.util.zip.ZipEntry;
//import java.util.zip.ZipInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import com.telemune.bean.ContentUploadBean;
import com.telemune.common.Global;
import com.telemune.common.JavaUtil;
import com.telemune.constant.Constants;
import com.telemune.dao.ContentManagerDao;
import com.telemune.dao.DbQueries;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

@Component
public class ContentManagerService {

	@Autowired
	ContentUploadBean contentUploadBean;
	@Autowired
	ContentManagerDao contentManagerDao;
	@Autowired
	Global globalMap;
	
	Logger  logger=Logger.getLogger(ContentManagerService.class);
	String jobId="";
	String message="";
	
	String downloadSheetName="";
	public Map<String, Object> jobIdContType(){

		Map<String, Object> map = new HashMap<String, Object>();
		logger.info("inside jobIdContType()...... ."+"]");
		ArrayList allfileTypeList= contentManagerDao.getAllFileTypes();
		SimpleDateFormat formatter1 = new SimpleDateFormat("dd/MM/yyyy/hhmm");
		String dt1 = formatter1.format(new java.util.Date());
			try{
				
					
					jobId=dt1+"_"+contentManagerDao.getJobIdSeq();
					logger.info("inside uploadContent ,LIst Size FileType list ["+allfileTypeList.size()+"] JOB_ID SEQ ["+jobId+"]");

					contentUploadBean.setAllfileTypeList(allfileTypeList);
					map.put("jobId",jobId);
					map.put("contentList",allfileTypeList);
			}

			catch(Exception e){

				logger.error("error in bulkUploadContent >>>>>>>>> "+e);
				//return -1;
			}
	
			finally
			{
				allfileTypeList=null;
				formatter1=null;
				dt1=null;
			}

			return map;
		}
	
	
	
	
	// to delete a directory or file
	
	public boolean deleteDirectory(File dir) {
        if (dir.isDirectory()) {
            File[] children = dir.listFiles();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDirectory(children[i]);
                if (!success) {
                    return false;
                }
            }
        }

        // either file or an empty directory
        logger.info("removing file or directory : " + dir.getName());
        return dir.delete();
    }
	
	
	
	
	
	public int bulkUploadContent(ContentUploadBean contentUploadBean)
	{
		logger.info("inside bulkUploadContent()...... ."+"]");
		String bulkUploadPath="";
		String contentUploadPath="";
		try
		{
			bulkUploadPath = JavaUtil.instance().getAppConfigParam("BULK_CONTENT_UPLOAD_PATH");
			contentUploadPath=JavaUtil.instance().getAppConfigParam("CONTENT_UPLOAD_PATH");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		logger.info("bulkUploadPath"+bulkUploadPath);
		MultipartFile file=null;
		MultipartFile zip=null;
		String uploadfileName="";
		String uploadzipName="";		// for zip
		String path_name="";
		String fileName="";
		String zipName="";				// for zip
		boolean proceed=false;
		String fullpath="";
		String zipUploadpath="";
		fullpath=bulkUploadPath;
		zipUploadpath=contentUploadPath;
		logger.info("zipFullpath(contentUplaodPath) - "+zipUploadpath);
		File musicFolder=new File(fullpath);

		if(!musicFolder.exists())
		{

			musicFolder.mkdirs();

		}
		String validFileNameChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890_";
		logger.info("addNewContentBean.getUploadFile() ["+contentUploadBean.getUploadFile()+"]");
		logger.info("getUploadFile()......."+contentUploadBean.getUploadFile().toString());
		if(contentUploadBean.getUploadFile()!=null)
		{

			file=contentUploadBean.getUploadFile(); 
			zip=contentUploadBean.getUploadZip();      // for zip
			logger.info("getUploadZip====="+zip);
			logger.info("getUploadFile====="+file);
			
			uploadfileName=file.getOriginalFilename();
			uploadzipName=zip.getOriginalFilename();    // for zip
			logger.info("uploadzipName ["+uploadzipName+"]");
			logger.info("uploadfileName ["+uploadfileName+"]");
			
			StringBuffer musicfile_newname = new StringBuffer();
			for (int i=0;i<uploadfileName.length()-5;i++)
			{
				char c = uploadfileName.charAt(i);
				if (validFileNameChars.indexOf(c)== -1)
					musicfile_newname.append("_");
				else
					musicfile_newname.append(c);


			}
			String  fileExt=uploadfileName.trim().substring(uploadfileName.lastIndexOf(".")+1,uploadfileName.length());
			logger.info("FileExt ["+fileExt+"]");
			uploadfileName=musicfile_newname.toString()+"."+fileExt;
			fileName = uploadfileName.replace(' ','_').trim();
			
			logger.info("inside addNewContentExecute ,SheetUploadPath ["+fullpath+"] sheetFileName ["+uploadfileName+"] ");
			path_name=fullpath;
			fullpath=fullpath+"/"+fileName;
			
			logger.info("SheetPathWithName>>>>>>>>>"+fullpath+" bean<<<<<<<"+contentUploadBean);
			
			try {
				file.transferTo(Paths.get(fullpath).toFile());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
			
			//for zip
			
			
			if(  !(uploadzipName ==null || "".equals(uploadzipName))   )
			{
				
				logger.info("uploadzipName - "+uploadzipName);
				/*StringBuffer musiczip_newname = new StringBuffer();
				logger.info("uploadzipName.length() - "+musicfile_newname.length());
				for (int i=0;i<uploadzipName.length()-5;i++)
				{
					//logger.info("musicfile_newname.length() - "+musicfile_newname.length());
					char c = uploadzipName.charAt(i);
					if (validFileNameChars.indexOf(c)== -1)
						musiczip_newname.append("_");
					else
						musiczip_newname.append(c);


				}
				String  zipExt=uploadzipName.trim().substring(uploadzipName.lastIndexOf(".")+1,uploadzipName.length());
				logger.info("zipExt ["+zipExt+"]");
				uploadzipName=musiczip_newname.toString()+"."+zipExt;
				zipName=uploadzipName.replace(' ','_').trim();
				zipFullpath=zipFullpath+"/"+zipName;
				logger.info("inside addNewContentExecute ,MusicPath ["+zipFullpath+"] zipFileName ["+zipName+"] ");
				
				
				
				
				
				try {
					zip.transferTo(Paths.get(zipFullpath).toFile());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				

			     byte[] buffer = new byte[8024];
			    	
			     try{
			    	
			    	//create output directory is not exists
			    //	File folder = new File(bulkUploadPath);
			    	 File folder = new File(contentUploadPath);
			    	 if(!folder.exists()){
			    		
			    		folder.mkdir();
			    	}
			    		
			    	//get the zip file content
			    	ZipInputStream zis = 
			    		new ZipInputStream(new FileInputStream(zipFullpath));
			    	//get the zipped file list entry
			    	
			    	ZipEntry ze = zis.getNextEntry();
			    		
			    	while(ze!=null){
			    			
			    	   String fileName1 = ze.getName();
			    	   logger.info(contentUploadPath + File.separator + fileName1);
			      //     File newFile = new File(bulkUploadPath + File.separator + fileName1);
			    	   File newFile = new File(contentUploadPath + File.separator + fileName1);
			           logger.info("file unzip : "+ newFile.getAbsoluteFile());
			                
			            //create all non exists folders
			            //else you will hit FileNotFoundException for compressed folder
			            new File(newFile.getParent()).mkdirs();
			              
			            FileOutputStream fos = new FileOutputStream(newFile);             
			           
			            int len;
			            while ((len = zis.read(buffer)) > 0) {
			       		fos.write(buffer, 0, len);
			            }
			           
			            fos.close();   
			           
			            ze = zis.getNextEntry();

			    	}
			    	 
			    	
			        zis.closeEntry();
			    	zis.close();
			    	 
			    	 
			    	 
			    	 ZipFile zipFile = new ZipFile(zipFullpath);
			    	    zipFile.extractAll(contentUploadPath);
			    		
			    }catch(Exception ex){
			       ex.printStackTrace(); 
			    }

			*/
				
				
				//create output directory is not exists
				File uploadFolder = new File(contentUploadPath);
		    	 if(!uploadFolder.exists()){
		    		
		    		 uploadFolder.mkdir();
		    	}

				String zipPath=zipUploadpath+"/"+uploadzipName; // extracted folder path with name for checking its exist or not.
			    logger.info("folderPath- "+zipPath);
			    File folder = new File(zipPath.substring(0,zipPath.lastIndexOf("."))); // without extention
			    File zipFolder = new File(zipPath);    // use for delete file in method deleteDirectory(zipFolder)
			    logger.info("folder - "+folder);
			    
			    
			    
	            //create all non exists folders
	            //else you will hit FileNotFoundException for compressed folder
	            new File(folder.getParent()).mkdirs();
			    
			    
			    
			    
				
				logger.info("zipUploadpath(contentUploadPath) - "+zipUploadpath);
				logger.info("contentUploadPath - "+contentUploadPath);
				try {
				zip.transferTo(Paths.get(zipPath).toFile());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			
		    	try {
		    	    ZipFile zipFile = new ZipFile(zipPath);
		    	    if (folder.exists()) 
		    	    {
		    	    	deleteDirectory(folder);
		    	    	logger.info(" folder with same name deleted- "+!folder.exists());
		    	    	
		    	    	if(zipFile.isValidZipFile())
		    	    	{
		    	    		logger.info("zipfile is valid");
		    	    		zipFile.extractAll(contentUploadPath+"/");
		    	    		deleteDirectory(zipFolder);
		    	    	}
		    	    	else
		    	    	{
		    	    		logger.info("zipfile is not valid");
		    	    	}
		    	    }
		    	    else
		    	    {
		    	    	if(zipFile.isValidZipFile())
		    	    	{
		    	    		logger.info("zipfile is valid");
		    	    		zipFile.extractAll(contentUploadPath+"/");
		    	    	//	zipFile.removeFile(zipPath);
		    	    		deleteDirectory(zipFolder);
		    	    	}
		    	    	else
		    	    	{
		    	    		logger.info("zipfile is not valid");
		    	    	}
		    	   
		    	    }
		    	} catch (ZipException e) {
		    	    e.printStackTrace();
		    	}
		    	catch(Exception e)
		    	{
		    		e.printStackTrace();
		    	}
			
			}

			
			logger.info("Successfully uploaded sheet at path ["+path_name+"] and zip at path["+contentUploadPath+"]");
			proceed=true;
		
		
		
		}
		if(proceed){
			int res=contentManagerDao.insertIntoDB(jobId,globalMap.sessionMap.get("user").toString(),fullpath, contentUploadBean.getFileCategory());	
			if(res!=Constants.SUCCESS){
				return Constants.SUCCESS;

			}
			String fileType=contentUploadBean.getFileCategory();
			logger.info("JOB ID is ["+jobId+"] file type ["+fileType+"]");
			String scriptPath = "";
			if(fileType.equalsIgnoreCase("1")){
				scriptPath = JavaUtil.instance().getScriptPath();
				logger.info("scriptPath is ["+scriptPath);

			}
			//For Executing the Scrpit
			//1.Execute Script
			//2.Data for Failed RBTS
			//3.After getting Data change Status 
			try {
				Runtime run = Runtime.getRuntime();
				logger.info("scriptPath [" + scriptPath+ "] fileName [" + fullpath + "]  jobId ["+jobId+"] user ["+globalMap.sessionMap.get("user").toString()+"]");
				logger.info(" ==============>>>>>>> "+scriptPath + " "+ fullpath+ " "+ jobId+ " "+ globalMap.sessionMap.get("user").toString());
				logger.info("***********************going to execute script*********************");
				Process p_scrpit = run.exec(scriptPath + " "+ fullpath+ " "+ jobId+ " "+ globalMap.sessionMap.get("user").toString());
				p_scrpit.waitFor();
				
				logger.info("Successfully executed the script");
				
				contentManagerDao.dbToFile(jobId);
				contentManagerDao.updateSheetName(jobId);

			} catch (Exception exp) {
				logger.info("Problem in script Running" + exp);
			}
			
			

			StringBuffer buffer=new StringBuffer();
			contentManagerDao.getSheetPath(buffer, jobId);
			String returnValue="";
			returnValue=   "CSVReports/" + buffer.toString(); 
			logger.info("Return value ["+returnValue+"]");
			contentUploadBean.setFilename(returnValue);
			contentUploadBean.setErrorTextFilename(returnValue.substring(0,returnValue.lastIndexOf("/")) + ".txt");//Added by Mahesh
			return Constants.SUCCESS; 
		}

		else{
			logger.info("There was some error while uploading");
			return Constants.EXCEPTION_OCCUR;
		}
	}
	
	
	
	
	
	
	
		
}