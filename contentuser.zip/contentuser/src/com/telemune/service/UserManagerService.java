package com.telemune.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.telemune.bean.UserDetailBean;
import com.telemune.constant.Constants;
import com.telemune.dao.UserManagerDao;

@Component
public class UserManagerService {
	 static Logger logger=Logger.getLogger(UserManagerService.class);
	 @Autowired
	 UserManagerDao userManagerDao;
	 
	 public int getUserData(ArrayList adminUserAl, UserDetailBean adminUser)
	 {
		 int ret=Constants.FAIL;
		 String userName =adminUser.getUserName().trim().toLowerCase();
		 int roleId =adminUser.getRoleId();
		 /**
			 * Get all user data
			 */
			if( ( userName.equalsIgnoreCase("") || userName == null ) && roleId == 0)
			{
				ret=userManagerDao.getAllUserData(adminUserAl,adminUser);
				logger.info("[ inside 1st if ]");
			}
			/**
			 * Get user data of specific role
			 */
			else if( ( userName.equalsIgnoreCase("") || userName == null ) && roleId != 0)
			{
				ret=userManagerDao.getUserDataByRole(adminUserAl,adminUser);
				logger.info("[ inside 2nd if ]");
			}
			
			/**
			 *  Get user data of specific role and name
			 */
			else if(( !userName.equalsIgnoreCase("") || userName != null ) && roleId != 0 )  
			{
				ret=userManagerDao.getUserDataByNameAndRole(adminUserAl,adminUser);
				logger.info("[ inside 3rd if ]");
			}
			
			/**
			 *  Get user data of specific user name
			 */
			else if(( !userName.equalsIgnoreCase("") || userName != null ) && roleId == 0 )  
			{
				ret=userManagerDao.getUserDataByName(adminUserAl,adminUser);
				logger.info("[ inside 4th if ]");
			}
			return ret;
	 }
	 
	 public int updateUser(UserDetailBean adminUser)
	 {
		 int ret=userManagerDao.updateUser(adminUser);
		 return ret;
	 }
	 
	 public int addUser(UserDetailBean userdetailbean)
	 {
		 int ret=userManagerDao.addUser(userdetailbean);
		 if(ret < 0)
			{
			 if(ret == Constants.RECORD_ALREADY_EXISTS )
			 {
				logger.info("webadmin/UserManage:RECORD ALREADY EXISTS");
				return ret;
			 }
			 else
			 {
				logger.info("webadmin/UserManage: tryLater");
				return ret;
			 }
			}
		 else
		 {
			  logger.info("webadmin/UserManage: User added successfully");
		 }

		 return ret;
	 }
	 
	 public int deleteUser(List adminUserAl)
	 {
		 int ret=userManagerDao.deleteUser(adminUserAl);
		 return ret;
	 }
	 
	 public int getUserDataForViewModify(ArrayList adminUserAl, UserDetailBean adminUser)
	 //public int getUserData(UserDetailBean adminUser)
	 {
		int ret= userManagerDao.getUserDataForViewModify(adminUserAl, adminUser);
		// int ret= userManagerDao.getUserData(adminUser);
		logger.debug("getUserDataForViewModify adminUserAl value= "+adminUserAl.toString());
		return ret;
	 }
}
