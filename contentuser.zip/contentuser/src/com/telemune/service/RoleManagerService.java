package com.telemune.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.telemune.bean.RoleBean;
import com.telemune.bean.RoleDetailBean;
import com.telemune.constant.Constants;
import com.telemune.dao.RoleManagerDao;

@Component
public class RoleManagerService
{
	
	@Autowired
	RoleManagerDao roleManagerDao;
	@Autowired 
	RoleBean roleBean;
	@Autowired
	RoleDetailBean roleDetailBean;
	
		 static Logger logger=Logger.getLogger(RoleManagerService.class);
		 private Connection con = null;
		 
		 
		 
		 
		 public int addRoleData(RoleBean roleBean)
			{
				logger.info ("in function addRoleData of RoleTypeManager");
				int retVal=Constants.FAIL;
				try{
				String roleName = roleBean.getRoleName();
				String roleDesc = roleBean.getDesc();
				HashSet<Integer> linkId= this.linkIds(roleBean);
				roleDetailBean.setRoleName(roleName);
				roleDetailBean.setRoleDesc(roleDesc);

				int i = roleManagerDao.addRoleData(roleDetailBean,linkId); // links may be many, hence these are passed as String arg.

				if(i < 0)
				{
				if(i == Constants.ROLE_NAME_ALREADY_EXIST )
				{
					logger.info("webadmin/RoleManage:RoleName already exist");
					retVal=i;
					return retVal;
				}
				else
				{
					logger.info("webadmin/RoleManage: tryLater");
					return retVal;
				}
				}
				else
				{
				      logger.info("webadmin/RoleManage: Role added successfully");
				}

				retVal=Constants.SUCCESS;
					}catch(Exception e)
					{
					logger.error("Exception inside ",e);
					e.printStackTrace();
					}
					return retVal;
						
			} //addRoleData
		 	
		 public HashSet<Integer> linkIds(RoleBean roleBean)
		 {
			String[] links = roleBean.getLinkAl();
			HashSet<Integer> linkId=new HashSet<Integer>();
			for(int i=0;i<links.length;i++)
			{
				int id=Integer.parseInt(links[i]);
				//****First case when any of children is selected add parent link
				if(id>=Constants.ADD_ROLE_LINK_ID && id<=Constants.DELETE_ROLE_LINK_ID)		// 7 ,10
		    	{
		    	logger.info("linkId for RoleManagement");
		    	logger.info("linkId: Id-Any Child Role  "+id);
		    	linkId.add(id);
		    	int pId=Constants.PARENT_ROLE_LINK_ID;					//6
		    	logger.info("linkId: Any Child Role(pid) "+pId);
		    	linkId.add(pId);
		    	}
		    	
		    	 if(id>=Constants.ADD_USER_LINK_ID && id<=Constants.DELETE_USER_LINK_ID)	// 12 , 15
		    	{
		    		logger.info("linkId for UserManagement");
			    	logger.info("linkId: Id-Any Child User  "+id);
			    	linkId.add(id);
			    	int pId=Constants.PARENT_USER_LINK_ID;		// 11
			    	logger.info("linkId: Any Child User(pid) "+pId);
			    	linkId.add(pId);
		    	}
		    	if(id>=Constants.UPLOAD_CONTENT_LINK_ID && id<=Constants.DOWNLOAD_SHEET_LINK_ID)	// 16, 17
			    {
			    	logger.info("linkId for UserManagement");
			    	logger.info("linkId: Id-Any Child User  "+id);
			    	linkId.add(id);
			   	}
			}
			return linkId;
		 }
		 
		 public int  getHttpLinks (ArrayList roleLinksAl)
			{
				logger.info ("in function getHttpLinks of RoleManagerService");
				int ret = Constants.FAIL;
				ret =roleManagerDao.getHttpLinks(roleLinksAl);
				return Constants.SUCCESS;
			}//getHttpLinks
		 
		 
		 public int handleViewRoleDetails(RoleBean roleBean, ArrayList dataAl)
		 {
		 	logger.info("Inside function handleViewRoleDetails()......");
		 	int retVal=Constants.FAIL;
		 	 try{
		 	    ArrayList roleTypeAl = new ArrayList();
		 	    String roleName = roleBean.getRoleName();
		 	   String roleId = roleBean.getRoleId();
		 	     logger.info("handleViewRoleDetails()>>>>>>>> roleid>>>"+roleBean.getRoleId());
		 	      ArrayList validlinksAl = roleManagerDao.viewLinks(roleId);
		 	      int  links = roleManagerDao.getHttpLinks(roleTypeAl);
		 	 
		 	      boolean check=false;
		 	     
		 	      for(int x = 0; x<roleTypeAl.size(); x++)
		 	      {
		 	    	  RoleDetailBean role=  (RoleDetailBean) roleTypeAl.get(x);
		 	    	  
		 	    	           if( validlinksAl.contains(new Integer ( role.getLinkId() ) ))
		 	                   {
		 	                	   check=true;
		 	                   }else
		 	                   {
		 	                	   check=false;
		 	                   }
		 	    	   role.setCheck(check); 
		 	           dataAl.add(role);
		 	      }
		 	      	roleBean.setDataListAl(dataAl);
		 	     	roleBean.setRoleName(roleName);
		 	    	roleBean.setRoleId(roleId);
		 	    	logger.info(" RoleName:  "+roleBean.getRoleName()+"   roleId:  "+roleBean.getRoleId());
		 	      
		 	     
		 	      retVal=Constants.SUCCESS;
		 	 }catch(Exception e)
		 	 {
		 	 logger.error("Exception inside ",e);
		 	 }	 
		 	 return retVal;
		 		
		 }
		 public int  getRoleTypes (ArrayList roleTypeAl)
			{
				logger.info ("in function getRoleTypes");
				int ret =Constants.FAIL;
				ret = roleManagerDao.getRoleTypes(roleTypeAl);
				return Constants.SUCCESS;

			} //getRoleTypes

		 
		 
		/*
		 * this function is for handle the delete Roles type
		 */
		 public int handleDeleteRoles(RoleBean roleBean)
		 {
		 	logger.info("Inside function handleDeleteRoles().......");
		 int retVal=Constants.FAIL;
		 	 try{

		      String[] RoleArr = roleBean.getDeleteAl();
		      logger.info("in handle delete role >>>>>>>>>>>"+RoleArr.toString());
		      int i = roleManagerDao.deleteRoleData(RoleArr);
		      if(i == Constants.ROLE_NOT_DELETED)
		      {
		              logger.info("webadmin/RoleManager: This RoleType cannot be deleted");
		              
		      }
		      else
		      {
		              logger.info("webadmin/RoleManager: The RoleType deleted successfully");
		              
		      }
		    
		      retVal=Constants.SUCCESS;
		 	 }catch(Exception e)
		 	 {
		 		 e.printStackTrace();
		 	 logger.error("Exception inside ",e);
		 	 }finally
		 	 {
		 	 	if(con!=null)
		 	 		try {
		 	 			con.close();
		 	 		} catch (SQLException e) {
		 	 			// TODO Auto-generated catch block
		 	 			e.printStackTrace();
		 	 		}
		 	 }
		 	return retVal;
		 		
		 }// delete role

			
			
			
			
			// this function is for handle the modify Roles type
			public int modifyRoleDetails(RoleBean roleBean)
			{
			
				logger.info("Inside function modifyRoleDetails(),,,,,,");
				 try{

					 String roleId = roleBean.getRoleId();
			     
			     logger.info("modifyRoleDetails>>>>>>>> roleid>>>"+roleBean.getRoleId());
			     HashSet<Integer> linkId= this.linkIds(roleBean);
			     int i = roleManagerDao.updateRoleData(roleId, linkId);
			     if(i < 0)
			     {
			    	 logger.info("get value less than 1 from roleManagerDao.updateRoleData");
			     }
			     else
			     {
			         logger.info("webadmin/RoleManager: Updation of RoleType "+roleId+" Successfull");
			     }

				
				 }catch(Exception e)
				 {
				 logger.error("Exception inside ",e);
				 }
				return Constants.SUCCESS;
			}
				
			
		 
		 

} //class RoleManagerService
