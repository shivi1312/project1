package com.telemune.service;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.telemune.bean.AuthBean;
import com.telemune.bean.Session;
import com.telemune.bean.SessionHistoryBean;
import com.telemune.common.Global;
import com.telemune.common.JavaUtil;
import com.telemune.constant.Constants;
import com.telemune.dao.AuthDaoImpl;
import org.apache.log4j.Logger; 


@Service
@Scope("prototype")
public class AuthService implements ApplicationContextAware {
	static final Logger logger=Logger.getLogger(AuthService.class);
	@Autowired
	AuthBean authbean;
	@Autowired
	AuthDaoImpl authDaoImpl;
	@Autowired
	SessionHistoryBean sessionHistoryBean;
	@Autowired
	Global globalMap;
	Connection con = null;
		
		
		public int validation(AuthBean authBean,HttpServletRequest request)
		{
			int retval=Constants.FAIL;
			String userName=authBean.getUserId();
			String pass=authBean.getPassword();
			Session session=context.getBean(Session.class);
			retval=authDaoImpl.authenticate(userName, pass,session);
			
			if(retval==Constants.SUCCESS)
			{
				authDaoImpl.setLinks();
				ArrayList<Integer> links = authDaoImpl.getLinks(sessionHistoryBean.getRoleId());
				session.setLink(links);
				logger.info(" sessionHistoryBean.getRoleId() "+sessionHistoryBean.getRoleId());
				globalMap.sessionMap.put("user",sessionHistoryBean.getStrUser());
				logger.info("getstruser====>>"+sessionHistoryBean.getStrUser());
				globalMap.sessionMap.put("Role_Id", sessionHistoryBean.getRoleId());
				
				for(int i=0;i<authDaoImpl.getLinksDetails().size();i++)
				{
					globalMap.sessionMap.put(authDaoImpl.getLinksDetails().get(i).toString(),authDaoImpl.getLinksDetails().get(i));
				}
			}
			return retval;
		}


		@Override
		public void setApplicationContext(ApplicationContext context) throws BeansException {
			this.context=context;
		}
		ApplicationContext context;
		
}
