package com.telemune.common;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.servlet.ModelAndView;

import com.telemune.bean.Session;
import com.telemune.bean.SessionHistoryBean;

@Component
public class Interceptors  extends HandlerInterceptorAdapter implements ApplicationContextAware 
{
	public static Logger logger=Logger.getLogger(Interceptors.class);
	private ApplicationContext context;
	
	public void postHandle(HttpServletRequest request,HttpServletResponse response, Object handler,ModelAndView modelAndView) throws Exception
	{
		
		logger.info("########### POST HANDLER #################" ) ;
		Session session=context.getBean(Session.class);
		try{
			if(session!=null){
			modelAndView.addObject("link", session.getLink());
			modelAndView.addObject("bean", session);
			}
		}
			catch(Exception e){
		}
		logger.info("POST HANDLER IP ====== "+request.getRemoteAddr());
	}
	
	
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		logger.info("########### PRE HANDLER #################");
		logger.info("PRE HANDLER IP ====== "+request.getRemoteAddr()+" "+request.getRequestURL());
		if((request.getRequestURL()+"").contains("logout") || (request.getRequestURL()+"").contains("login") || (request.getRequestURL()+"").contains("resources") || (request.getRequestURL()+"").contains("version")){
			return true;
		}
		logger.info("(SessionHistoryBean)context.getBean(SessionHistoryBean.class)" +((SessionHistoryBean)context.getBean(SessionHistoryBean.class)).toString());
		if((((SessionHistoryBean)context.getBean(SessionHistoryBean.class)).getStrUser()==null)||((SessionHistoryBean)context.getBean(SessionHistoryBean.class)).getStrUser().isEmpty())
		{
			logger.info("########### session Expired ##########");
			response.sendRedirect("logout");
			return false;
			
		}
		logger.info("PRE HANDLER IP ====== "+request.getRemoteAddr()+" "+request.getRequestURL());
		return true;
	}
	
	 @Override
	    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception{
		 logger.info("AFTER COMPLETIOn");
	 	}
	 
	 
	 @Override
	 public void afterConcurrentHandlingStarted(
	            HttpServletRequest request, HttpServletResponse response, Object handler)
	                    throws Exception{
		 logger.info("AFTER concurrent COMPLETIOn started");
	 }
	 
	@Override
	public void setApplicationContext(ApplicationContext context) throws BeansException {
		this.context = context;
	}
}
