 package com.telemune.common;

import java.beans.PropertyVetoException;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.telemune.dao.ConnectionPool;
import com.telemune.dao.DbQueries;



@Component
public class JavaUtil implements ApplicationContextAware{
	
@Autowired
	private ApplicationContext context;
	
	private static Logger logger=Logger.getLogger(JavaUtil.class);
	private static Properties properties = null;
	private static Hashtable  app_params = null;
	private static String dbType=null;
	private static JavaUtil instance_ = null;
	private static long time=0;
	/* @Autowired
	  Environment env;*/
	
	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		// TODO Auto-generated method stub
		
	}
	
	
	
	public ApplicationContext getContext() {
		return context;
	}



	public static synchronized JavaUtil instance()
	{

		long newtime = (new java.util.Date()).getTime();

		if (instance_ == null||((newtime-time)>1000*60*60))
		{
			logger.info("This is the  time || ["+time+"] >1000*60*60 Or when Chache made fist time ");
			instance_ = new JavaUtil();
			time=newtime;
		}
		logger.info("This is the  time || ["+time+"] when not reload ");
		return instance_;
	}
	private JavaUtil()
	{  
		Connection con=null;
		Statement stmt=null;
		ResultSet rs = null;
		String driver = null;
		properties = new Properties();
		try
		{	
	//	FileInputStream fis1 = new FileInputStream(System.getenv("PROPERTY_FILE_PATH")+"/dao.properties");
			FileInputStream fis1 = new FileInputStream(System.getenv("PROPERTY_FILE_PATH")+"/content_user.properties");
		properties.load(fis1);
		fis1.close();

		}
		catch(IOException e)
		{
			e.printStackTrace();
			return;
		}

		
		DbQueries.constructQuery(properties.getProperty("DB_TYPE"));
		
		String strUser = properties.getProperty("USER");
		String strPass = properties.getProperty("PASS");
		String strUrl = properties.getProperty("URL");
		driver =  properties.getProperty("DRIVER");
		dbType=properties.getProperty("DB_TYPE");
		/*dbType=env.getProperty("DB_TYPE");*/
		try
		{
			// Load database driver if not already loaded
			Class.forName(driver);
			// Establish network connection to database
			 con = ConnectionPool.getInstance().getConnection();
		}
		catch(ClassNotFoundException cnfe)
		{
			// Simplify try/catch blocks of people using this by
			// throwing only one exception type.
			return;
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
			return;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try
		{
			 logger.info("App Config Loading Start ");
			stmt = con.createStatement();
			/*"select PARAM_TAG, PARAM_VALUE from CRBT_APP_CONFIG_PARAMS";*/
			String query = DbQueries.getPTag_Val;
			logger.debug(query);
			rs = stmt.executeQuery(query);
			logger.info(query);
			app_params = new Hashtable();
			while (rs.next())
			{
				logger.info("Parameters Tag ["+rs.getString("PARAM_TAG").toUpperCase()+"]");
				app_params.put((rs.getString("PARAM_TAG")).toUpperCase(), rs.getString("PARAM_VALUE"));
			}
			rs.close();
			stmt.close();
			logger.debug("Got config");

			
		}
		catch (SQLException exp)
		{
			exp.printStackTrace();
		}

         finally
         {
				try
				{
					if(rs != null) rs.close();
					stmt.close();
					con.close();
				}
				catch (Exception exp)
				{
					exp.printStackTrace();
				}
       }

	}//JavaUtil()
		
	public String getAppConfigParam(String paramName)
	{
		try
		{
		String retVal = "";
		String param = paramName.toUpperCase();
		retVal = (String) app_params.get(param);
		return retVal;
		}
		catch (Exception e) {
			// TODO: handle exception
		  logger.error("Getting AppConfig Is Null for ["+paramName+"]");
		  return "Null";
		}
	}
	public String getScriptPath()
    {               
            try
            {
                    String scriptPath=properties.getProperty("SCRIPT_PATH");
                    return scriptPath;
            }       
            catch(Exception e)
            {               
                    e.printStackTrace();
                    return "NA";
            }               
                               
	
	
    }
	
	public String getSheetPath()
    {               
            try
            {
                    String scriptPath=properties.getProperty("SHEET_PATH");
                    return scriptPath;
            }       
            catch(Exception e)
            {               
                    e.printStackTrace();
                    return "NA";
            }               
	
    }
	
	public String getMODScriptPath(){
		
		 try
         {
                 String mod_scriptPath=properties.getProperty("MOD_SCRIPT_PATH");
                 return mod_scriptPath;
         }       
         catch(Exception e)
         {               
                 e.printStackTrace();
                 return "NA";
         }          
	}
	
	public Connection getConnection() throws IOException, SQLException, PropertyVetoException
	{
		Connection con=ConnectionPool.getInstance().getConnection();
		return con;
	}
	
	
}
