package com.telemune.common;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
@Component
public class Global{
	
	Logger logger=Logger.getLogger(Global.class);
	public Map<String,Object> sessionMap = new HashMap<String,Object>();
	public void setSession(HashMap<String, Object> arg0) {
		this.sessionMap=arg0;
		
	}
}
