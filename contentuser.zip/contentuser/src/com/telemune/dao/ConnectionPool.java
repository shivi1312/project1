package com.telemune.dao;

import java.beans.PropertyVetoException;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import org.apache.log4j.Logger; 

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class ConnectionPool {
	private static ConnectionPool datasource;
	private static ComboPooledDataSource cpds;
	private static Properties properties=null;
	static final Logger logger = Logger.getLogger(ConnectionPool.class); 
	
	public ConnectionPool() {

	}

	private ConnectionPool(String productId) throws IOException, SQLException,
			PropertyVetoException {
		properties = new Properties();
		String catHome=System.getenv("PROPERTY_FILE_PATH");
		logger.info("Property_File_path Is  || "+catHome+"");
		try
		{
			//properties.load(new FileInputStream(catHome+"dao.properties"));
			properties.load(new FileInputStream(catHome+"content_user.properties"));
		}
		catch(IOException e)
		{
			e.printStackTrace();
			return;
		}
		cpds = new ComboPooledDataSource();
		/*DbQueries.constructQuery(properties.getProperty("DB_TYPE"));*/
		cpds.setDriverClass(properties.getProperty("DRIVER",
				"oracle.jdbc.driver.OracleDriver")); // loads the jdbc driver
		cpds.setJdbcUrl(properties.getProperty("URL"));
		//System.out.println("URL "+properties.getProperty("URL"));
		logger.info("URL "+properties.getProperty("URL"));
		cpds.setUser(properties.getProperty("USER"));
		cpds.setPassword(properties.getProperty("PASS"));
		cpds.setMinPoolSize(Integer.parseInt(properties.getProperty("min.pool")));
		cpds.setAcquireIncrement(Integer.parseInt(properties.getProperty("acquire.increment")));
		cpds.setMaxPoolSize(Integer.parseInt(properties.getProperty("max.pool")));
		cpds.setMaxStatements(Integer.parseInt(properties.getProperty("max.statement")));
		cpds.setAcquireRetryAttempts(Integer.parseInt((properties.getProperty(
				"acquire.retry.attempts"))));
		cpds.setTestConnectionOnCheckin(Boolean.getBoolean(properties.getProperty("ConnectionChecking")));
		cpds.setIdleConnectionTestPeriod(Integer.parseInt(properties.getProperty("IdleConnectionTestPeriod")));
		cpds.setMaxIdleTimeExcessConnections(Integer.parseInt(properties.getProperty("ConnectionIdleTime")));
	}

	public static ConnectionPool getInstance() throws IOException,
			SQLException, PropertyVetoException {
		if (datasource == null) {
			datasource = new ConnectionPool("productId");
		}
		return datasource;
	}

	public void closeDataSource() {
		cpds.close();
	}

	public Connection getConnection() throws IOException, SQLException,
			PropertyVetoException {
		Connection conn = cpds.getConnection();
		logger.info("active connection [" + cpds.getNumBusyConnections()
				+ "] idle: " + cpds.getNumIdleConnections() + " total ["
				+ cpds.getNumConnections() + "]");
		return conn;
	}
}
