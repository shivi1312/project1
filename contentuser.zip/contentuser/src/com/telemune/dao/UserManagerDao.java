package com.telemune.dao;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.telemune.bean.Roles;
import com.telemune.bean.UserDetailBean;
import com.telemune.common.JavaUtil;
import com.telemune.constant.Constants;

@Repository
public class UserManagerDao {
	 static Logger logger=Logger.getLogger(UserManagerDao.class);
	 private ResultSet rs = null;
	 private PreparedStatement pstmt = null;
	 private Connection con = null;
	 private String query = null;
	
	 public int getAllUserData(ArrayList<UserDetailBean> adminUserAl, UserDetailBean adminUser)
	 {
				logger.info("in function getAllUserData ");
				try
				{
					
					con=JavaUtil.instance().getConnection();
					int roleId = adminUser.getRoleId() ;
					String userId = adminUser.getUserId();
					String userName = adminUser.getUserName().trim().toLowerCase();
					logger.info("roleId= "+roleId +" & userName= " +  userName);
					logger.info("userId= "+userId);						
					/*"select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a, ROLE_MASTER b where b.ROLE_ID=a.ROLE_ID  ";*/
					query = DbQueries.getAllUserData;
					pstmt = con.prepareStatement (query);
					logger.info(query);
					rs = pstmt.executeQuery();
					while(rs.next())
					{								
						adminUser = new UserDetailBean ();
						adminUser.setUserId(rs.getString ("USER_ID"));
						adminUser.setUserName(rs.getString ("USER_NAME"));
						adminUser.setPassword(rs.getString ("PASSWORD"));
						adminUser.setEmail(rs.getString ("EMAIL"));
						adminUser.setMobileNum(rs.getString ("MOBILE_NUM"));
						adminUser.setRoleId(rs.getInt ("ROLE_ID"));
						adminUser.setAddress(rs.getString ("ADDRESS"));
						adminUser.setDescription(rs.getString("DESCRIPTION"));
						adminUser.setStatus(rs.getString("STATUS"));
						adminUser.setRoleName(rs.getString("ROLE_NAME"));
						adminUserAl.add(adminUser);
					}
					
				 		rs.close();
					    pstmt.close();
				        con.close();
				   
				} 
				catch (Exception e)
				{
					try
					{
						if(rs != null)rs.close();
						if(pstmt != null)pstmt.close();
						if(con!=null)con.close();
					}catch(SQLException sqle)
					{
						logger.error("Exception in listUser, Exception is : " + sqle.getMessage ());
					}
					e.printStackTrace();
					return -1;
					}
					finally
					{	
						try{
							if(rs != null)rs.close();
							if(pstmt != null)pstmt.close();
							if(con!=null)con.close();
							}
							catch(Exception e){
								
								logger.error("Exception getUserData()",e);
							}
					}

							return 1;

			}//getAllUserData
	 	
	 public int getUserDataByRole(ArrayList<UserDetailBean> adminUserAl, UserDetailBean adminUser)		
	 {
				logger.info("in function getUserDataByRole ");
				try
				{
					
					con=JavaUtil.instance().getConnection();
					int roleId = adminUser.getRoleId() ;
					String userId = adminUser.getUserId();
					String userName = adminUser.getUserName().trim().toLowerCase();
					logger.info("roleId= "+roleId +" & userName= " +  userName);
					/*"select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a, ROLE_MASTER b where a.ROLE_ID = ? AND  b.ROLE_ID=a.ROLE_ID ";*/
					query = DbQueries.getUsrMstrWhRId_RNameFrmRoleM;	
					pstmt = con.prepareStatement (query);
					pstmt.setInt(1, roleId);logger.info("two"+roleId);
					logger.info(query);
					rs = pstmt.executeQuery();
					while(rs.next())
					{		
						adminUser = new UserDetailBean ();
						adminUser.setUserId(rs.getString ("USER_ID"));
						adminUser.setUserName(rs.getString ("USER_NAME"));
						adminUser.setPassword(rs.getString ("PASSWORD"));
						adminUser.setEmail(rs.getString ("EMAIL"));
						adminUser.setMobileNum(rs.getString ("MOBILE_NUM"));
						adminUser.setRoleId(rs.getInt ("ROLE_ID"));
						adminUser.setAddress(rs.getString ("ADDRESS"));
						adminUser.setDescription(rs.getString("DESCRIPTION"));
						adminUser.setStatus(rs.getString("STATUS"));
						adminUser.setRoleName(rs.getString("ROLE_NAME"));
						adminUserAl.add(adminUser);
					}
					
				 		rs.close();
					    pstmt.close();
				        con.close();
				   
				} 
				catch (Exception e)
				{
					try
					{
						if(rs != null)rs.close();
						if(pstmt != null)pstmt.close();
						if(con!=null)con.close();
					}catch(SQLException sqle)
					{
						logger.error("Exception in listUser, Exception is : " + sqle.getMessage ());
					}
					e.printStackTrace();
					return -1;
					}
					finally
					{	
						try{
							if(rs != null)rs.close();
							if(pstmt != null)pstmt.close();
							if(con!=null)con.close();
							}
							catch(Exception e){
								
								logger.error("Exception getUserData()",e);
							}
					}

							return 1;

			}//getUserDataByRole
	 	
	 public int getUserDataByNameAndRole(ArrayList<UserDetailBean> adminUserAl, UserDetailBean adminUser)
	 {
				logger.info("in function getUserDataByNameAndRole ");
				try
				{
					
					con=JavaUtil.instance().getConnection();
					int roleId = adminUser.getRoleId() ;
					String userId = adminUser.getUserId();
					String userName = adminUser.getUserName().trim().toLowerCase();
					logger.info("roleId= "+roleId +" & userName= " +  userName);
					logger.info("userId= "+userId);						
					/*"select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a, ROLE_MASTER b where a.ROLE_ID = ? and a.USER_NAME like  ? AND  b.ROLE_ID=a.ROLE_ID ";*/
					query = DbQueries.getUsrMstrWhRId_UN_RNameFrmRoleM;			 
					pstmt = con.prepareStatement (query);
					pstmt.setInt(1, roleId);
					logger.info("inside 4");
					pstmt.setString(2, "%"+userName+"%" );
					logger.info(query);
					rs = pstmt.executeQuery();
					while(rs.next())
					{		
						adminUser = new UserDetailBean ();
						adminUser.setUserId(rs.getString ("USER_ID"));
						adminUser.setUserName(rs.getString ("USER_NAME"));
						adminUser.setPassword(rs.getString ("PASSWORD"));
						adminUser.setEmail(rs.getString ("EMAIL"));
						adminUser.setMobileNum(rs.getString ("MOBILE_NUM"));
						adminUser.setRoleId(rs.getInt ("ROLE_ID"));
						adminUser.setAddress(rs.getString ("ADDRESS"));
						adminUser.setDescription(rs.getString("DESCRIPTION"));
						adminUser.setStatus(rs.getString("STATUS"));
						adminUser.setRoleName(rs.getString("ROLE_NAME"));
						adminUserAl.add(adminUser);
					}
					
				 		rs.close();
					    pstmt.close();
				        con.close();
				   
				} 
				catch (Exception e)
				{
					try
					{
						if(rs != null)rs.close();
						if(pstmt != null)pstmt.close();
						if(con!=null)con.close();
					}catch(SQLException sqle)
					{
						logger.error("Exception in listUser, Exception is : " + sqle.getMessage ());
					}
					e.printStackTrace();
					return -1;
					}
					finally
					{	
						try{
							if(rs != null)rs.close();
							if(pstmt != null)pstmt.close();
							if(con!=null)con.close();
							}
							catch(Exception e){
								
								logger.error("Exception getUserData()",e);
							}
					}

							return 1;

			}//getUserDataByNameAndRole
	 	
	 public int getUserDataByName(ArrayList<UserDetailBean> adminUserAl, UserDetailBean adminUser)
	 {
				logger.info("in function getUserDataByName ");
				try
				{
					con=JavaUtil.instance().getConnection();
					int roleId = adminUser.getRoleId() ;
					String userId = adminUser.getUserId();
					String userName = adminUser.getUserName().trim().toLowerCase();
					logger.info("roleId= "+roleId +" & userName= " +  userName);
					logger.info("userId= "+userId);						
					/*"select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID, a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS , b.ROLE_NAME from USER_MASTER a, ROLE_MASTER b  where b.ROLE_ID=a.ROLE_ID and a.USER_NAME like ?";*/
					query =DbQueries.getUserDataByName;
					pstmt = con.prepareStatement (query);
					pstmt.setString(1, "%"+userName+"%" );
					logger.info(query);
					rs = pstmt.executeQuery();
					while(rs.next())
					{		
						adminUser = new UserDetailBean ();
						adminUser.setUserId(rs.getString ("USER_ID"));
						adminUser.setUserName(rs.getString ("USER_NAME"));
						adminUser.setPassword(rs.getString ("PASSWORD"));
						adminUser.setEmail(rs.getString ("EMAIL"));
						adminUser.setMobileNum(rs.getString ("MOBILE_NUM"));
						adminUser.setRoleId(rs.getInt ("ROLE_ID"));
						adminUser.setAddress(rs.getString ("ADDRESS"));
						adminUser.setDescription(rs.getString("DESCRIPTION"));
						adminUser.setStatus(rs.getString("STATUS"));
						adminUser.setRoleName(rs.getString("ROLE_NAME"));
						adminUserAl.add(adminUser);
					}
					
				 		rs.close();
					    pstmt.close();
				        con.close();
				   
				} 
				catch (Exception e)
				{
					try
					{
						if(rs != null)rs.close();
						if(pstmt != null)pstmt.close();
						if(con!=null)con.close();
					}catch(SQLException sqle)
					{
						logger.error("Exception in listUser, Exception is : " + sqle.getMessage ());
					}
					e.printStackTrace();
					return Constants.EXCEPTION_OCCUR;
					}
					finally
					{	
						try{
							if(rs != null)rs.close();
							if(pstmt != null)pstmt.close();
							if(con!=null)con.close();
							}
							catch(Exception e){
								
								logger.error("Exception getUserData()",e);
							}
					}

							return Constants.SUCCESS;

			}//getUserDataByName
	 	
	

	 
	 
	 public int getUserDataForViewModify(ArrayList<UserDetailBean> adminUserAl, UserDetailBean adminUser)		
	 {
				logger.info("in function getUserDataForViewModify ");
				try
				{
					
					con=JavaUtil.instance().getConnection();
					int roleId = adminUser.getRoleId() ;
					String userId = adminUser.getUserId();
					String userName = adminUser.getUserName().trim().toLowerCase();
					logger.info("roleId= "+roleId +" & userName= " +  userName);
					logger.info("userId= "+userId);						
					//"select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID, a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS , b.ROLE_NAME from USER_MASTER a, ROLE_MASTER b  where b.ROLE_ID=a.ROLE_ID and a.USER_ID = ?";
					query =DbQueries.getUserDataById;
					pstmt = con.prepareStatement (query);
					logger.info("????????"+userId);
					pstmt.setString(1, userId );
					logger.info(query);
					rs = pstmt.executeQuery();
							  
					while(rs.next())
					{		
						adminUser = new UserDetailBean ();
						adminUser.setUserId(rs.getString ("USER_ID"));
						adminUser.setUserName(rs.getString ("USER_NAME"));
						adminUser.setPassword(rs.getString ("PASSWORD"));
						adminUser.setEmail(rs.getString ("EMAIL"));
						adminUser.setMobileNum(rs.getString ("MOBILE_NUM"));
						adminUser.setRoleId(rs.getInt ("ROLE_ID"));
						adminUser.setAddress(rs.getString ("ADDRESS"));
						adminUser.setDescription(rs.getString("DESCRIPTION"));
						adminUser.setStatus(rs.getString("STATUS"));
						adminUser.setRoleName(rs.getString("ROLE_NAME"));
						adminUserAl.add(adminUser);
					}
					
				 		rs.close();
					    pstmt.close();
				        con.close();
				   
				} 
				catch (Exception e)
				{
					try
					{
						if(rs != null)rs.close();
						if(pstmt != null)pstmt.close();
						if(con!=null)con.close();
					}
					catch(SQLException sqle)
					{
						logger.error("Exception in listUser, Exception is : " + sqle.getMessage ());
					}
					
						e.printStackTrace();
						return Constants.EXCEPTION_OCCUR;
					}
				
					finally
					{	
						try{
							if(rs != null)rs.close();
							if(pstmt != null)pstmt.close();
							if(con!=null)con.close();
							}
							catch(Exception e){
								
								logger.error("Exception getUserData()",e);
							
							}
					}

							return Constants.SUCCESS;

			}//getUserDataForViewModify

	 
	 	
	 	public List<Roles> getRoles()
	 	{
	 		List<Roles> roleList=new ArrayList<Roles>();
	 		
	 		try {
				con=JavaUtil.instance().getConnection();
				/*"Select ROLE_NAME, ROLE_ID from ROLE_MASTER ";*/
				String query=DbQueries.getRN_RId_FrRoleM;
				pstmt=con.prepareStatement(query);
				rs=pstmt.executeQuery();
				while(rs.next())
				{
					
					roleList.add(new Roles(rs.getString("ROLE_NAME"), rs.getInt("ROLE_ID")));
				}
			} catch(IOException | SQLException | PropertyVetoException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 		
	 		return roleList;
	 	}//get users roles
	 	
	 	
	 	
	 	
	 	public int updateUser (UserDetailBean adminUser)
		{
				logger.info("in function updateUser");
				logger.info("updating user type= "+ adminUser.getRoleId()+"& user name= "+ adminUser.getUserName() );
						
			try
			{
					con=JavaUtil.instance().getConnection();
					/*"UPDATE USER_MASTER SET PASSWORD = ?, EMAIL = ?, MOBILE_NUM = ?, ROLE_ID = ?,ADDRESS=?,DESCRIPTION=?, STATUS=? WHERE USER_NAME = ?";*/
					query = DbQueries.upUsrMstr;
					pstmt = con.prepareStatement (query);
					
					pstmt.setString(1, adminUser.getPassword());
					pstmt.setString(2, adminUser.getEmail());
					pstmt.setString(3, adminUser.getMobileNum());
					pstmt.setInt(4, adminUser.getRoleId());
					pstmt.setString(5, adminUser.getAddress());
					pstmt.setString(6, adminUser.getDescription());
					pstmt.setString(7, adminUser.getStatus());
					pstmt.setString(8, adminUser.getUserName());
					pstmt.executeUpdate();
					pstmt.close();
					

			}
			catch (Exception e)
			{
				try
				{
					if(pstmt != null) pstmt.close ();
				}catch(SQLException sqle)
				{
					logger.error("Exception in updateUser, Exception is : " + sqle.getMessage ());
				}
				e.printStackTrace ();
				return -1;
			}
			return 1;
		} // updateUser
	 	
	 	
	 	
	 	public int addUser (UserDetailBean userdetailbean)
		{
			logger.info("User Management: addUser");
			try
			{
				con=JavaUtil.instance().getConnection();
				/*"SELECT USER_NAME FROM USER_MASTER WHERE USER_NAME = ?";*/
				query = DbQueries.getUN_FrUsrMstr;
				pstmt = con.prepareStatement (query);
				pstmt.setString (1, userdetailbean.getUserName ());
				rs = pstmt.executeQuery ();
				while(rs.next ())
				{
					rs.close ();
					pstmt.close ();
					return Constants.RECORD_ALREADY_EXISTS; //-22; //
					
				}
				rs.close ();
				pstmt.close ();
				
				int userId = -1;
				/*"select USER_ID.NEXTVAL from dual";*/
				/*query = DbQueries.nextvalUserId;
				pstmt = con.prepareStatement(query);
				rs = pstmt.executeQuery();
				if (rs.next())
				{
					userId = rs.getInt(1);
					rs.close();
					pstmt.close();
				}
				else
				{
					rs.close();
					pstmt.close();
					logger.info ("UserManager: userId not created");
					return -99;//userId not created
				}*/
				/*"INSERT INTO USER_MASTER (USER_ID,USER_NAME, PASSWORD,CREATE_DATE,MOBILE_NUM, ROLE_ID, ADDRESS, EMAIL, DESCRIPTION,STATUS) VALUES (?,?,?,sysdate,?,?,?,?,?,?)";*/
				String query1 = DbQueries.insertUserDetails;
				pstmt = con.prepareStatement (query1);
				logger.info(query1);
				logger.info("after adduser query"+userdetailbean);
				pstmt.setString(1, userdetailbean.getUserName().trim().toLowerCase());
				pstmt.setString(2, userdetailbean.getPassword ());
				pstmt.setString(3, userdetailbean.getMobileNum ());
				pstmt.setInt(4, userdetailbean.getRoleId ());
				pstmt.setString(5, userdetailbean.getAddress ());
				pstmt.setString(6, userdetailbean.getEmail ());
				pstmt.setString(7, userdetailbean.getDescription ());
				pstmt.setString(8, userdetailbean.getStatus ());

				pstmt.executeUpdate();
				pstmt.close ();
			
				con.close();
			
			}//try
			catch (Exception e)
			{
				logger.error ("User Management: addUser: Exception in addUser, Exception is : ",e);
				try
				{
					if(pstmt != null) pstmt.close ();
					if(rs!=null)rs.close();
					if(con!=null)con.close();
				}catch(SQLException sqle)
				{
					logger.error ("User Management: addUser: Exception in addUser, Exception is : ",sqle);
				}

				e.printStackTrace ();
				return -1;
			}finally
			{	
				try{
					if(rs != null) rs.close ();
					if(pstmt != null) pstmt.close ();
				if(con!=null)con.close();
				}
			catch(Exception e){
				
				logger.error("Exception addUser()",e);
			}
			}

			return 1;

		}// addUser

	 	
	 	
	 	public int deleteUser (List adminUserAl)
		{
			logger.info ("in function deleteUser");
			try
			{
				String userName="";
				con=JavaUtil.instance().getConnection();
				/*" delete from USER_MASTER WHERE USER_ID = ?";*/
				query = DbQueries.delUsrMstrWhUId;
				pstmt = con.prepareStatement (query);
				
				Iterator ite = adminUserAl.iterator ();
				while(ite.hasNext ())
				{
					userName = (String)ite.next ();
					pstmt.setString (1, userName);
					pstmt.executeUpdate();
				}
				pstmt.close ();
				 
			
			}
			catch (Exception e)
			{
				try
				{
					if(pstmt != null) pstmt.close ();
				}catch(SQLException sqle)
				{
					logger.error ("Exception in deleteUser, Exception is : " + sqle.getMessage ());
				}
				e.printStackTrace ();
				return -1;
			}
			
			return 1;
		}//deleteUser

}
