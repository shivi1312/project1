package com.telemune.dao;

import java.util.ArrayList;

public interface SessionHistory {
	public boolean isAllowed(int linkId);
	public ArrayList getLinksDetails();
	public void getLinks(int usertype);
	
}
