package com.telemune.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.telemune.bean.SessionHistoryBean;

@Repository
public class SessionHistoryImpl {
	
	@Autowired
	SessionHistoryBean sessionHistoryBean;
	
	private ArrayList links=null;
	private Connection con;
	
	
	public boolean isAllowed(int linkId)
	{
		return links.contains(new Integer(linkId));
	}
	
	public ArrayList getLinksDetails()
	{
		return links;
	}

	public ArrayList<Integer> getLinks(int usertype)
	{
		links = new ArrayList();
		try
		{
			/*"select LINK_ID from WEB_ACCESS where ROLE_ID = ? and IS_ALLOWED = ?";*/
			String query = DbQueries.getLinkId;
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, usertype);
			pstmt.setString(2, "Y");
			ResultSet rs = pstmt.executeQuery();
			while(rs.next())
			{
				links.add(new Integer(rs.getInt(1)));
			}
			if(rs != null) rs.close();
			pstmt.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return links;
	}
	
}
