package com.telemune.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.telemune.bean.Session;
import com.telemune.bean.SessionHistoryBean;
import com.telemune.common.JavaUtil;
import com.telemune.constant.Constants;


@Repository
public class AuthDaoImpl implements AuthDao{
	@Autowired
	SessionHistoryBean sessionHistoryBean;
	
	
	
	Logger logger=Logger.getLogger(AuthDaoImpl.class);
	private ArrayList links=null;
	private Connection con;
	
	   public int authenticate(String userName,String pass,Session session)
	   {
			logger.info("Inside function authenticate()..where usrename  ["+userName+"] password ["+pass+"]");

			int ret=Constants.FAIL;
			Connection con=null;
			PreparedStatement pstmt=null;
			ResultSet results=null;
			try
			{
				
				con=JavaUtil.instance().getConnection();						
				//String query = "select ROLE_ID from USER_MASTER where USER_NAME = ? and PASSWORD = ?";
				String query =DbQueries.getRoleId;
				pstmt = con.prepareStatement(query);
				logger.info("DB Query::"+query);
				pstmt.setString(1, userName);
				pstmt.setString(2, pass);
				results = pstmt.executeQuery();
				logger.info("authentication .........");
				if (results.next()) 
				{
					
					sessionHistoryBean.setCon(con);
					int roleId = results.getInt("ROLE_ID");
					this.getLinks(roleId);
					
					session.setStrUser(userName);
					session.setRoleId(roleId);
					
					sessionHistoryBean.setStrUser(userName);
					sessionHistoryBean.setRoleId(roleId);
					ret=Constants.SUCCESS;
				}
				else {
					ret=Constants.FAIL;
				}
				results.close();
				pstmt.close();
				con.close();

			}
			catch (Exception e) {
				logger.error("Error in authentricating username and password",e);
			}
		return ret;
	   }

		public boolean isAllowed(int linkId)
		{
			return links.contains(new Integer(linkId));
		}
		
		public ArrayList getLinksDetails()
		{
			return links;
		}
		
		public  SessionHistoryBean getSessionHistoryBean()
		{
			return sessionHistoryBean;
		}
		
		
	   public ArrayList<Integer> getLinks(int roleId)
		{
			links = new ArrayList();
			try
			{
				con=JavaUtil.instance().getConnection();
				/*"select LINK_ID from WEB_ACCESS where ROLE_ID = ? and IS_ALLOWED = ?";*/
				String query = DbQueries.getLinkId;
				PreparedStatement pstmt = con.prepareStatement(query);
				pstmt.setInt(1, roleId);
				pstmt.setString(2, "Y");
				ResultSet rs = pstmt.executeQuery();
				while(rs.next())
				{
					links.add(new Integer(rs.getInt(1)));
				}
				if(rs != null) rs.close();
				pstmt.close();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			return links;
		}
	 
	   public void setLinks()
	   {
		   if(links!=null)
		   {
			   sessionHistoryBean.setLink(links); 
			   logger.info("Links set successfully by setLinks()");
		   }
		   else 
			   logger.info("Links are null");
	   	}

	
	   
}
