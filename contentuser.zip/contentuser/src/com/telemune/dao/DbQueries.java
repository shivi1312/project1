package com.telemune.dao;

public class DbQueries {

	//AuthDaoImpl
	public static String getRoleId="select ROLE_ID from USER_MASTER where USER_NAME = ? and PASSWORD = ?";
	public static String getLinkId="select LINK_ID from WEB_ACCESS where ROLE_ID = ? and IS_ALLOWED = ?";
	
	//ContentManagerDao
	public static String getJobId="select JOB_ID.NEXTVAL from dual";
	public static String getTypeIdName="select TYPE_ID,TYPE_NAME from FILE_TYPES";
	public static String inContentSiteUploadDetail ="insert into CONTENT_SITE_UPLOAD_DETAIL (JOB_ID,USER_NAME,SERVICE_NAME,FOLDER_PATH,CREATE_DATE,STATUS,DESCRIPTION,SHEET_NAME) values (?,?,?,?,sysdate,'I',?,?)";
	public static String jobIdCSUD= "select JOB_ID from CONTENT_SITE_UPLOAD_DETAIL where USER_NAME=? order by ID desc";
	public static String getSheetNameCSUD="select SHEET_NAME from CONTENT_SITE_UPLOAD_DETAIL where JOB_ID=?";
	public static String finalDownloadSheet="select a.reference_id ,a.RBT_NAME ,a.status ,a.file_type , b.DESCRIPTION  from crbt_rbt_bulk_upload a,BULK_UPLOAD_ERR_CODES b where a.ERR_CODE=b.ERR_CODE and job_id=? order by REFERENCE_ID";
	public static String updateSheetName="update CONTENT_SITE_UPLOAD_DETAIL set SHEET_NAME=? , FOLDER_PATH=? where job_id=?";
	
	//RoleManagerDao
	public static String getRoleNameRM="select ROLE_NAME from ROLE_MASTER where ROLE_NAME=?";
	//public static String nextvalRoleId="select ROLE_ID.NEXTVAL from dual";
	public static String insertRoleDetails="insert into ROLE_MASTER (ROLE_ID, ROLE_NAME,CREATE_DATE,DESCRIPTION) values (ROLE_ID.NEXTVAL,?,sysdate,?)";//ch
	public static String inWebAccess="insert into WEB_ACCESS (LINK_ID, ROLE_ID,IS_ALLOWED) values (?,?,?)";
	public static String getHTTP_LINKS="select LINK_ID, DESCRIPTION  from HTTP_LINKS where LINK_ID>5 order by LINK_ID";
	//public static String getLinkIdWB_ACC="select LINK_ID from WEB_ACCESS where ROLE_ID = ? and IS_ALLOWED = ?";
	public static String getRIdNameDescRM="select ROLE_ID,ROLE_NAME,DESCRIPTION  from ROLE_MASTER";
	public static String delWB_Acc_Wh_RId="delete from WEB_ACCESS where ROLE_ID= ?";
	public static String delRoleM_Wh_RId="delete from ROLE_MASTER where ROLE_ID = ?";
	
	//UserManagerDao
/*	public static String getAllUserData="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a, ROLE_MASTER b where b.ROLE_ID=a.ROLE_ID  ";
*/	public static String getAllUserData="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a LEFT OUTER JOIN  ROLE_MASTER b  ON (b.ROLE_ID=a.ROLE_ID)";
	public static String getUsrMstrWhRId_RNameFrmRoleM="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a, ROLE_MASTER b where a.ROLE_ID = ? AND  b.ROLE_ID=a.ROLE_ID ";
	public static String getUsrMstrWhRId_UN_RNameFrmRoleM="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a, ROLE_MASTER b where a.ROLE_ID = ? and a.USER_NAME = ? AND  b.ROLE_ID=a.ROLE_ID ";
	//public static String getUserDataById ="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID, a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS , b.ROLE_NAME from USER_MASTER a, ROLE_MASTER b  where b.ROLE_ID=a.ROLE_ID and a.USER_ID = ?";
	public static String getUserDataById ="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID, a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS , b.ROLE_NAME from USER_MASTER a LEFT OUTER JOIN ROLE_MASTER b ON (b.ROLE_ID=a.ROLE_ID) Where a.USER_ID=?";

	public static String getUserDataByName ="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID, a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS , b.ROLE_NAME from USER_MASTER a, ROLE_MASTER b  where b.ROLE_ID=a.ROLE_ID and a.USER_NAME = ?";
	public static String getRN_RId_FrRoleM="Select ROLE_NAME, ROLE_ID from ROLE_MASTER ";
	public static String upUsrMstr="UPDATE USER_MASTER SET PASSWORD = ?, EMAIL = ?, MOBILE_NUM = ?, ROLE_ID = ?,ADDRESS=?,DESCRIPTION=?, STATUS=? WHERE USER_NAME = ?";
	public static String getUN_FrUsrMstr="SELECT USER_NAME FROM USER_MASTER WHERE USER_NAME = ?";
	//public static String nextvalUserId="select USER_ID.NEXTVAL from dual";
	//public static String inUsrMstr="INSERT INTO USER_MASTER (USER_ID,USER_NAME, PASSWORD,CREATE_DATE,MOBILE_NUM, ROLE_ID, ADDRESS, EMAIL, DESCRIPTION,STATUS) VALUES (?,?,?,sysdate,?,?,?,?,?,?)";
	public static String insertUserDetails="INSERT INTO USER_MASTER (USER_ID,USER_NAME, PASSWORD,CREATE_DATE,MOBILE_NUM, ROLE_ID, ADDRESS, EMAIL, DESCRIPTION,STATUS) VALUES (USER_ID.NEXTVAL,?,?,sysdate,?,?,?,?,?,?)";  //ch
																			
	public static String delUsrMstrWhUId=" delete from USER_MASTER WHERE USER_ID = ?";

	//JavaUtil
	public static String getPTag_Val="select PARAM_TAG, PARAM_VALUE from CRBT_APP_CONFIG_PARAMS";
	
	public static void constructQuery(String dbType)
	{
		
		switch(dbType.toLowerCase()){
		case "oracle":
			getRoleId="select ROLE_ID from USER_MASTER where USER_NAME = ? and PASSWORD = ?";
			getLinkId="select LINK_ID from WEB_ACCESS where ROLE_ID = ? and IS_ALLOWED = ?";
			getJobId="select JOB_ID.NEXTVAL from dual";
			getTypeIdName="select TYPE_ID,TYPE_NAME from FILE_TYPES";
			inContentSiteUploadDetail ="insert into CONTENT_SITE_UPLOAD_DETAIL (JOB_ID,USER_NAME,SERVICE_NAME,FOLDER_PATH,CREATE_DATE,STATUS,DESCRIPTION,SHEET_NAME) values (?,?,?,?,sysdate,'I',?,?)";
			jobIdCSUD= "select JOB_ID from CONTENT_SITE_UPLOAD_DETAIL where USER_NAME=? order by ID desc";
			getSheetNameCSUD="select SHEET_NAME from CONTENT_SITE_UPLOAD_DETAIL where JOB_ID=?";
			getRoleNameRM="select ROLE_NAME from ROLE_MASTER where ROLE_NAME=?";
			/*nextvalRoleId="select ROLE_ID.NEXTVAL from dual";*/
			insertRoleDetails="insert into ROLE_MASTER (ROLE_ID, ROLE_NAME,CREATE_DATE,DESCRIPTION) values (ROLE_ID.NEXTVAL,?,sysdate,?)";
			inWebAccess="insert into WEB_ACCESS (LINK_ID, ROLE_ID,IS_ALLOWED) values (?,?,?)";
			getHTTP_LINKS="select LINK_ID, DESCRIPTION  from HTTP_LINKS where LINK_ID>5 order by LINK_ID";
			//getLinkIdWB_ACC="select LINK_ID from WEB_ACCESS where ROLE_ID = ? and IS_ALLOWED = ?";
			getRIdNameDescRM="select ROLE_ID,ROLE_NAME,DESCRIPTION  from ROLE_MASTER";
			delWB_Acc_Wh_RId="delete from WEB_ACCESS where ROLE_ID= ?";
			delRoleM_Wh_RId="delete from ROLE_MASTER where ROLE_ID = ?";
			/*getAllUserData="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a, ROLE_MASTER b where b.ROLE_ID=a.ROLE_ID  ";*/
			getAllUserData="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a LEFT OUTER JOIN  ROLE_MASTER b  ON (b.ROLE_ID=a.ROLE_ID)";
			getUsrMstrWhRId_RNameFrmRoleM="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a, ROLE_MASTER b where a.ROLE_ID = ? AND  b.ROLE_ID=a.ROLE_ID ";
			getUsrMstrWhRId_UN_RNameFrmRoleM="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a, ROLE_MASTER b where a.ROLE_ID = ? and a.USER_NAME like ? AND  b.ROLE_ID=a.ROLE_ID ";
			//getUserDataById ="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID, a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS , b.ROLE_NAME from USER_MASTER a, ROLE_MASTER b  where b.ROLE_ID=a.ROLE_ID and a.USER_ID = ?";
			getUserDataById ="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID, a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS , b.ROLE_NAME from USER_MASTER a LEFT OUTER JOIN ROLE_MASTER b  ON	(b.ROLE_ID=a.ROLE_ID) Where a.USER_ID=?";
			getUserDataByName ="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID, a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS , b.ROLE_NAME from USER_MASTER a, ROLE_MASTER b  where b.ROLE_ID=a.ROLE_ID and a.USER_NAME like ?";
			getRN_RId_FrRoleM="Select ROLE_NAME, ROLE_ID from ROLE_MASTER ";
			upUsrMstr="UPDATE USER_MASTER SET PASSWORD = ?, EMAIL = ?, MOBILE_NUM = ?, ROLE_ID = ?,ADDRESS=?,DESCRIPTION=?, STATUS=? WHERE USER_NAME = ?";
			getUN_FrUsrMstr="SELECT USER_NAME FROM USER_MASTER WHERE USER_NAME = ?";
			//nextvalUserId="select USER_ID.NEXTVAL from dual";
			insertUserDetails="INSERT INTO USER_MASTER (USER_ID,USER_NAME, PASSWORD,CREATE_DATE,MOBILE_NUM, ROLE_ID, ADDRESS, EMAIL, DESCRIPTION,STATUS) VALUES (USER_ID.NEXTVAL,?,?,sysdate,?,?,?,?,?,?)";
			delUsrMstrWhUId=" delete from USER_MASTER WHERE USER_ID = ?";
			getPTag_Val="select PARAM_TAG, PARAM_VALUE from CRBT_APP_CONFIG_PARAMS";
			finalDownloadSheet="select a.reference_id ,a.RBT_NAME ,a.status ,a.file_type , b.DESCRIPTION  from crbt_rbt_bulk_upload a,BULK_UPLOAD_ERR_CODES b where a.ERR_CODE=b.ERR_CODE and job_id=? order by REFERENCE_ID";
			updateSheetName="update CONTENT_SITE_UPLOAD_DETAIL set SHEET_NAME=?, FOLDER_PATH=? where job_id=?";
			break;
		
		case "mysql":
			getRoleId="select ROLE_ID from USER_MASTER where USER_NAME = ? and PASSWORD = ?";
			getLinkId="select LINK_ID from WEB_ACCESS where ROLE_ID = ? and IS_ALLOWED = ?";
			getJobId="SELECT AUTO_INCREMENT AS NEXTVAL FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'CONTENT' AND TABLE_NAME = 'CONTENT_SITE_UPLOAD_DETAIL'";
			getTypeIdName="select TYPE_ID,TYPE_NAME from FILE_TYPES";
			inContentSiteUploadDetail ="insert into CONTENT_SITE_UPLOAD_DETAIL (JOB_ID,USER_NAME,SERVICE_NAME,FOLDER_PATH,CREATE_DATE,STATUS,DESCRIPTION,SHEET_NAME) values (?,?,?,?,sysdate(),'I',?,?)";
			jobIdCSUD= "select JOB_ID from CONTENT_SITE_UPLOAD_DETAIL where USER_NAME=? order by ID desc";
			getSheetNameCSUD="select SHEET_NAME from CONTENT_SITE_UPLOAD_DETAIL where JOB_ID=?";
			getRoleNameRM="select ROLE_NAME from ROLE_MASTER where ROLE_NAME=?";
			//nextvalRoleId="select ROLE_ID.NEXTVAL from dual";
			//inRoleMaster="insert into ROLE_MASTER (ROLE_ID, ROLE_NAME,CREATE_DATE,DESCRIPTION) values (?,?,sysdate,?)";
			insertRoleDetails="insert into ROLE_MASTER (ROLE_NAME,CREATE_DATE,DESCRIPTION) values (?,now(),?)";
			inWebAccess="insert into WEB_ACCESS (LINK_ID, ROLE_ID,IS_ALLOWED) values (?,?,?)";
			getHTTP_LINKS="select LINK_ID, DESCRIPTION  from HTTP_LINKS where LINK_ID>5 order by LINK_ID";
			//getLinkIdWB_ACC="select LINK_ID from WEB_ACCESS where ROLE_ID = ? and IS_ALLOWED = ?";
			getRIdNameDescRM="select ROLE_ID,ROLE_NAME,DESCRIPTION  from ROLE_MASTER";
			delWB_Acc_Wh_RId="delete from WEB_ACCESS where ROLE_ID= ?";
			delRoleM_Wh_RId="delete from ROLE_MASTER where ROLE_ID = ?";
			//getAllUserData="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a, ROLE_MASTER b where b.ROLE_ID=a.ROLE_ID  ";
			getAllUserData="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a LEFT OUTER JOIN  ROLE_MASTER b  ON (b.ROLE_ID=a.ROLE_ID)";
			getUsrMstrWhRId_RNameFrmRoleM="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a, ROLE_MASTER b where a.ROLE_ID = ? AND  b.ROLE_ID=a.ROLE_ID ";
			getUsrMstrWhRId_UN_RNameFrmRoleM="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID,a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS,b.ROLE_NAME  from USER_MASTER a, ROLE_MASTER b where a.ROLE_ID = ? and a.USER_NAME like ? AND  b.ROLE_ID=a.ROLE_ID ";
			//getUserDataById ="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID, a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS , b.ROLE_NAME from USER_MASTER a, ROLE_MASTER b  where b.ROLE_ID=a.ROLE_ID and a.USER_ID = ?";
			getUserDataById ="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID, a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS , b.ROLE_NAME from USER_MASTER a LEFT OUTER JOIN ROLE_MASTER b  ON	(b.ROLE_ID=a.ROLE_ID) Where a.USER_ID=?";
			getUserDataByName ="select a.USER_ID, a.USER_NAME, a.PASSWORD, a.MOBILE_NUM, a.ROLE_ID, a.ADDRESS, a.EMAIL,a.DESCRIPTION, a.STATUS , b.ROLE_NAME from USER_MASTER a, ROLE_MASTER b  where b.ROLE_ID=a.ROLE_ID and a.USER_NAME like ?";
			getRN_RId_FrRoleM="Select ROLE_NAME, ROLE_ID from ROLE_MASTER ";
			upUsrMstr="UPDATE USER_MASTER SET PASSWORD = ?, EMAIL = ?, MOBILE_NUM = ?, ROLE_ID = ?,ADDRESS=?,DESCRIPTION=?, STATUS=? WHERE USER_NAME = ?";
			getUN_FrUsrMstr="SELECT USER_NAME FROM USER_MASTER WHERE USER_NAME = ?";
			//nextvalUserId="select USER_ID.NEXTVAL from dual";
			insertUserDetails="INSERT INTO USER_MASTER (USER_NAME, PASSWORD,CREATE_DATE,MOBILE_NUM, ROLE_ID, ADDRESS, EMAIL, DESCRIPTION,STATUS) VALUES (?,?,now(),?,?,?,?,?,?)";
			delUsrMstrWhUId=" delete from USER_MASTER WHERE USER_ID = ?";
			getPTag_Val="select PARAM_TAG, PARAM_VALUE from CRBT_APP_CONFIG_PARAMS";
			finalDownloadSheet="select a.reference_id ,a.RBT_NAME ,a.status ,a.file_type , b.DESCRIPTION  from crbt_rbt_bulk_upload a,BULK_UPLOAD_ERR_CODES b where a.ERR_CODE=b.ERR_CODE and job_id=? order by REFERENCE_ID";
			updateSheetName="update CONTENT_SITE_UPLOAD_DETAIL set SHEET_NAME=?,FOLDER_PATH=? where job_id=?";
			break;
			

		}
	}

}
//SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = "SDP" AND TABLE_NAME = "Crbt_Category_master";