package com.telemune.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.telemune.bean.RoleDetailBean;
import com.telemune.common.JavaUtil;
import com.telemune.constant.Constants;

@Repository
public class RoleManagerDao
{
		 static Logger logger=Logger.getLogger(RoleManagerDao.class);
		 private ResultSet rs = null;
		 private PreparedStatement pstmt = null;
		 private Connection con = null;
		 private String query = null;
		 
		 public int addRoleData (RoleDetailBean roleType,HashSet<Integer> linkId)
			{
				logger.info ("in function addRoleData of RoleTypeManager");
				try
				{
					
					con=JavaUtil.instance().getConnection();
					/*"select ROLE_NAME from ROLE_MASTER where ROLE_NAME=?";*/
					query = DbQueries.getRoleNameRM;
					pstmt = con.prepareStatement (query);
					pstmt.setString(1, roleType.getRoleName().trim().toLowerCase() );
					rs = pstmt.executeQuery();
					while(rs.next ())
					{
						rs.close ();
						pstmt.close ();
						return Constants.ROLE_NAME_ALREADY_EXIST;  // this Role Name aleady exists in the System/
					}

					rs.close ();
					pstmt.close ();
					
					int roleId = -1;
					
					/*"select ROLE_ID.NEXTVAL from dual";*/
					/*query = DbQueries.nextvalRoleId;
					pstmt = con.prepareStatement(query);
					rs = pstmt.executeQuery();
					if (rs.next())
					{
						roleId = rs.getInt(1);
						rs.close();
						pstmt.close();
					}
					else
					{
						rs.close();
						pstmt.close();
						logger.info ("RoleTypeManager: roleId not created");
						return -99;
					}*/
					/*"insert into ROLE_MASTER (ROLE_ID, ROLE_NAME,CREATE_DATE,DESCRIPTION) values (?,?,sysdate,?)";*/
					query = DbQueries.insertRoleDetails;
					String columnNames[] = new String[] { "ROLE_ID" };
					pstmt = con.prepareStatement (query,columnNames);

				/*	pstmt.setInt ( 1, roleId);*/
					logger.info("role "+roleType.toString());
					pstmt.setString ( 1, roleType.getRoleName().trim().toLowerCase() );
					pstmt.setString ( 2, roleType.getRoleDesc().trim().toLowerCase() );
					/*pstmt.executeUpdate();*/
					
					roleId=pstmt.executeUpdate();
					if(roleId!=0){
						rs=pstmt.getGeneratedKeys();
						if(rs.next()){
							roleId=(int)rs.getLong(1);
						}
					}
					logger.info("role id - "+roleId);
					rs.close();
					pstmt.close();
					
					/*//added to bean temp test
					roleType.setRoleId(roleId);
					logger.info(">>>>>>>yoyoyoyoy>>>>>>>>"+roleType.getRoleId());*/
					/*query="select ROLE_ID from ROLE_MASTER where ROLE_NAME=?";
					pstmt=con.prepareStatement(query);
					pstmt.setString(1, roleType.getRoleName().trim().toLowerCase());
					logger.info("roleName for roleId?????????????????"+roleType.getRoleName());
					rs=pstmt.executeQuery();
					while(rs.next())
					{
						roleId=rs.getInt(1);
						logger.info("Role-----------------------id"+roleId);
						roleType.setRoleId(roleId);
						
					}
					rs.close();
					pstmt.close();
					*/
					if (linkId.size()>0)
					{			
						/*"insert into WEB_ACCESS (LINK_ID, ROLE_ID,IS_ALLOWED) values (?,?,?)";*/
						query= DbQueries.inWebAccess;
						pstmt = con.prepareStatement (query);
						Iterator itr = linkId.iterator();
						 while(itr.hasNext())
						 {
							 int id=(Integer)itr.next();							 
								
							 	pstmt.setInt (1, id);
								logger.info("role idddddddddddddddddddd"+roleId);
								pstmt.setInt (2, roleId);
								pstmt.setString(3,"Y");
								pstmt.addBatch();
						 }
						 pstmt.executeBatch();
						pstmt.close ();
						
					} //if links
					con.close();
				} //try
				catch (Exception e)
				{//log it
					try
					{
						if(rs != null) rs.close ();
						if(pstmt != null) pstmt.close ();
						if(con!=null)con.close();
					}catch(SQLException sqle)
					{
						logger.error ("Exception in addRoleData, Exception is : " + sqle.getMessage ());
					}
					logger.error ("Exception Received:" + e);
					e.printStackTrace();
					return Constants.EXCEPTION_OCCUR;
				}//catch
				finally
				{	
					try
					{
						if(rs != null) rs.close ();
						if(pstmt != null) pstmt.close ();
						if(con!=null)con.close();
					}catch(Exception e)
					{
						logger.error ("Exception in addRoleData, Exception is : " ,e);
					}
					}
				
				
				return Constants.SUCCESS;

			} //addRoleData

		 
		 
		 public int  getHttpLinks (ArrayList roleLinksAl)
			{
				logger.info ("in function getHttpLinks of RoleManagerService");

				try
				{
					con=JavaUtil.instance().getConnection();
					/*"select LINK_ID, DESCRIPTION  from HTTP_LINKS where LINK_ID>5 order by LINK_ID";*/
					query = DbQueries.getHTTP_LINKS;
					
					pstmt = con.prepareStatement (query);
					rs = pstmt.executeQuery ();
					while(rs.next ())
					{
						RoleDetailBean roleType = new RoleDetailBean();
						roleType.setLinkId( rs.getInt ("LINK_ID") );
						roleType.setLinkDesc( rs.getString ("DESCRIPTION") );
						roleLinksAl.add(roleType);
					}
					rs.close ();
					pstmt.close ();
					con.close();
				}
				catch (Exception e)
				{//log it
					try
					{
						if(rs != null) rs.close ();
						if(pstmt != null) pstmt.close ();
						if(con !=null) con.close();
					}catch(SQLException sqle) {
						logger.error ("Exception in getHttpLinks, Exception is : " + sqle.getMessage ());
					}
					logger.error ("Exception Received:" + e);
					return Constants.EXCEPTION_OCCUR;
				}
				finally
				{	
					try{
						if(rs != null) rs.close ();
						if(pstmt != null) pstmt.close ();
					if(con!=null)con.close();
					}
				catch(Exception e){
					
					logger.error("Exception getHttpLinks()",e);
				}
				}

			
				return Constants.SUCCESS;

			}//getHttpLinks
		 
		 
			public ArrayList viewLinks (String id)
			{
				logger.info ("in function viewLinks of RoleTypeManager id is :  "+id);
				ArrayList ret = new ArrayList ();
				try
				{
					con=JavaUtil.instance().getConnection();
					/*"select LINK_ID from WEB_ACCESS where ROLE_ID = ? and IS_ALLOWED = ?";*/
					query = DbQueries.getLinkId;
					pstmt = con.prepareStatement (query);
					pstmt.setString (1 , id);
					pstmt.setString(2,"Y");
					rs= pstmt.executeQuery ();
					while(rs.next ())
					{
						ret.add(new Integer (rs.getInt ("LINK_ID")));
						
					}
					rs.close ();
					pstmt.close ();
					con.close();
				}
				catch (Exception e)
				{//log it
					try
					{
						if(rs != null) rs.close ();
						if(pstmt != null) pstmt.close ();
						if(con !=null)con.close();
					} catch(SQLException sqle) {
						logger.error ("Exception in getLinks, Exception is : " + sqle.getMessage ());
					}
					logger.error ("Exception Received:" + e);
				}finally
				{	
					try{
						if(rs != null) rs.close ();
						if(pstmt != null) pstmt.close ();
					if(con!=null)con.close();
					}
				catch(Exception e){
					
					logger.error("Exception getLinks()",e);
				}
				}
				return ret;
			} //getLinks/viewLinks
		 
		 
		 public int  getRoleTypes (ArrayList roleTypeAl)
			{
				logger.info ("in function getRoleTypes");
				try
				{
					
					con= JavaUtil.instance().getConnection();
					/*"select ROLE_ID,ROLE_NAME,DESCRIPTION  from ROLE_MASTER";*/
					query = DbQueries.getRIdNameDescRM;
					pstmt = con.prepareStatement (query);
					logger.debug("query ["+query+"]");
					rs = pstmt.executeQuery ();
					while(rs.next ())
					{
						RoleDetailBean roleType = new RoleDetailBean ();
						roleType.setRoleId (rs.getInt ("ROLE_ID") );
						roleType.setRoleName (rs.getString ("ROLE_NAME") );
						roleType.setRoleDesc (rs.getString ("DESCRIPTION") );
						roleTypeAl.add (roleType);
					}
					rs.close ();
					pstmt.close ();
					con.close();
				}
				catch (Exception e)
				{//log it
					try
					{
						if(rs != null) rs.close ();
						if(pstmt != null) pstmt.close ();
						if(con!=null)con.close();
					} catch(SQLException sqle) {
						logger.error ("Exception in getRoleType, Exception is : " + sqle.getMessage ());
					}
					logger.info ("Exception Received:" + e);
					return Constants.EXCEPTION_OCCUR;
				}
				
				finally
				{	
					try{
						if(rs != null) rs.close ();
						if(pstmt != null) pstmt.close ();
					if(con!=null)con.close();
					}
				catch(Exception e){
					
					logger.error("Exception getRoleTypes()",e);
				}
				}
				return Constants.SUCCESS;

			} //getRoleTypes

			public int deleteRoleData (String[] links)
			{
				logger.info ("Here in deleteRoleData of RoleTypeManager");
				try
				{
					con = JavaUtil.instance().getConnection();
					
					// Deleting from WEB_ACCESS table
					/*"delete from WEB_ACCESS where ROLE_ID= ?";*/
					query = DbQueries.delWB_Acc_Wh_RId;
					pstmt = con.prepareStatement (query);
					logger.info("links ki length "+links.length);
					for(int i=0; i<links.length; i++)
					{
						pstmt.setInt (1 , Integer.parseInt(links[i]));
						pstmt.executeUpdate();
					}
					pstmt.close ();

					//deleting from ROLE_MASTER TABLE
					/*"delete from ROLE_MASTER where ROLE_ID = ?";*/
					query = DbQueries.delRoleM_Wh_RId;
					pstmt = con.prepareStatement (query);
					for(int i=0; i<links.length; i++)
					{
						pstmt.setInt (1 , Integer.parseInt(links[i]));
						pstmt.executeUpdate();
					}
					pstmt.close ();
				}
				catch (Exception e)
				{//log it
					try
					{
						if(rs != null) rs.close ();
						if(pstmt != null) pstmt.close ();
					} catch(SQLException sqle) {
						logger.error ("Exception in deleteRoleData, Exception is : " + sqle.getMessage ());
					}
					logger.error ("Exception Received:" + e);
					e.printStackTrace();
					return Constants.ROLE_NOT_DELETED;
				}
				finally
				{		try {
					con.close();
				} catch (Exception e2) {
					// TODO: handle exception
				}	}
				return Constants.SUCCESS;

			} //deleteRoleData

			public int updateRoleData (String roleId,HashSet<Integer> links)
			{
				
				logger.info("Here in updateRoleData of RoleTypeManager  role id --> "+roleId);
				logger.info("No of links  : "+links.size());
				
				try
				{
					con=JavaUtil.instance().getConnection();
					/*"delete from WEB_ACCESS where ROLE_ID= ?";*/
					query = DbQueries.delWB_Acc_Wh_RId;
					pstmt = con.prepareStatement (query);
					pstmt.setString ( 1, roleId);
					pstmt.executeUpdate();
					pstmt.close ();
					if(links != null)
					{
						/*"insert into WEB_ACCESS (LINK_ID, ROLE_ID,IS_ALLOWED) values (?,?,?)";*/
						query = DbQueries.inWebAccess;
						pstmt = con.prepareStatement (query);
						logger.info("links "+links);
						Iterator itr=links.iterator();
						while(itr.hasNext())
						{
							logger.info("roleId " +roleId);
							pstmt.setString (2,roleId);
							pstmt.setString (3,"Y");
							pstmt.setInt (1,(Integer)itr.next());
							pstmt.executeUpdate();
						}
					}

					pstmt.close ();
				}
				catch (Exception e)
				{//log it
					try
					{
						if(pstmt != null) pstmt.close ();
						
					} catch(SQLException sqle) {
						logger.error ("Exception in updateRoleData, Exception is : " + sqle.getMessage ());
					}
					logger.info ("Exception Received:" + e);
					e.printStackTrace();
					return Constants.EXCEPTION_OCCUR;
				}
				return Constants.SUCCESS;

			} //updateRoleData
		 
		 

} //class RoleTypeManager
