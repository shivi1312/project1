package com.telemune.dao;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.telemune.bean.ContentUploadBean;
import com.telemune.common.JavaUtil;
import com.telemune.constant.Constants;



@Repository
public class ContentManagerDao {
	
	@Autowired
	ContentUploadBean contentUploadBean;
	static Logger logger=Logger.getLogger(ContentManagerDao.class);
	private Connection con;
	private PreparedStatement pstmt=null;
	private ResultSet rs=null;
	private static Properties properties = null;
	String downloadSheetName="";
	
	public int getJobIdSeq(){

		try{
			 con = JavaUtil.instance().getConnection();
			 int job_id=Constants.FAIL;
			 /*"select JOB_ID.NEXTVAL from dual";*/
			String query = DbQueries.getJobId;
			logger.info("query - "+query);
			pstmt = con.prepareStatement(query);

			rs = pstmt.executeQuery();
			logger.info(query);

			if (rs.next())
			{
				
				logger.info("Job_ID sequence ["+rs.getInt("NEXTVAL")+"]");
				job_id=rs.getInt("NEXTVAL");
				
							}
			rs.close();
			pstmt.close();
			con.close();
			return job_id;

		}
		catch (Exception exp)
		{//log it 
			logger.error("Exception in getJobIdSeq()",exp);
			try{
				if(rs !=null)rs.close();
				if(pstmt !=null)pstmt.close();
				if(con !=null)con.close();
			}
			catch(Exception ee){
				logger.error("Error in getJobIdSeq()",ee);
			}
			exp.printStackTrace();
			return Constants.EXCEPTION_OCCUR;
		}
		finally
		{
			try{
				if(rs !=null)rs.close();
				if(pstmt !=null)pstmt.close();
				if(con !=null)con.close();
			}
			catch(Exception ee){
				logger.error("Error in getJobIdSeq()",ee);
			}
		}


	}
	
	public ArrayList getAllFileTypes(){
			
		ArrayList arrayList=new ArrayList();
		ContentUploadBean contentUploadBean=null;
		try{
			
			con=JavaUtil.instance().getConnection();
			/*"select TYPE_ID,TYPE_NAME from FILE_TYPES";*/
			String query = DbQueries.getTypeIdName;
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			logger.info(query);

			while (rs.next())
			{
				contentUploadBean=new ContentUploadBean();
				logger.debug("type Name"+rs.getString("TYPE_NAME")+"id "+rs.getInt("TYPE_ID"));
				contentUploadBean.setFileTypeId(rs.getInt("TYPE_ID"));
				contentUploadBean.setContentTypeName(rs.getString("TYPE_NAME"));
				arrayList.add(contentUploadBean);
				
				contentUploadBean=null;
			}
			rs.close();
			pstmt.close();
			con.close();
			query=null;
			
			return arrayList;

		}
		catch (Exception exp)
		{//log it 
			logger.error("Exception in getAllFileTypes()",exp);
			try{
				if(rs !=null)rs.close();
				if(pstmt !=null)pstmt.close();
				if(con !=null)con.close();
			}
			catch(Exception ee){
				logger.error("Error in getAllFileTypes",ee);
			}
			exp.printStackTrace();
			//return arrayList;
		}
		finally
		{
			try{
				
				if(rs !=null)rs.close();
				if(pstmt !=null)pstmt.close();
				if(con !=null)con.close();
			}
			catch(Exception ee){
				logger.error("Error in getAllFileTypes",ee);
			}
		}
		return arrayList;

	}
	
public int insertIntoDB(String jobId, String user, String folderpath, String serviceName){
		
		logger.info("in insertIntoDB user ["+user+"] job Id ["+jobId+"] folderpath ["+folderpath+"]");
		try{
			con=JavaUtil.instance().getConnection();

			/*"insert into CONTENT_SITE_UPLOAD_DETAIL (JOB_ID,USER_NAME,SERVICE_NAME,FOLDER_PATH,CREATE_DATE,STATUS,DESCRIPTION,SHEET_NAME) values (?,?,?,?,sysdate,'I',?,?)";*/
			String query = DbQueries.inContentSiteUploadDetail;
			pstmt = con.prepareStatement(query);
            pstmt.setString(1, jobId);
            pstmt.setString(2, user);
            pstmt.setString(3, serviceName);
            pstmt.setString(4, folderpath);
            pstmt.setString(5, serviceName);
            pstmt.setString(6, "NA");
		 
        	pstmt.executeUpdate();
			logger.info(query);

			
			pstmt.close();
			con.close();
			return Constants.SUCCESS;

		}
		catch (Exception exp)
		{//log it 
			logger.error("Exception in insertIntoDB()",exp);
			try{
				if(rs !=null)rs.close();
				if(pstmt !=null)pstmt.close();
				if(con !=null)con.close();
			}
			catch(Exception ee){
				logger.error("Error in insertIntoDB()",ee);
			}
			exp.printStackTrace();
			return Constants.EXCEPTION_OCCUR;
		}
		finally
		{
			try{
				if(rs !=null)rs.close();
				if(pstmt !=null)pstmt.close();
				if(con !=null)con.close();
			}
			catch(Exception ee){
				logger.error("Error in insertIntoDB()",ee);
			}
		}
		
	}

public ArrayList getJobList(String user){
	
	logger.info("in getJobList user ["+user+"]");
	ArrayList jobIdList=new ArrayList();
	try{
		con=JavaUtil.instance().getConnection();

		/*"select JOB_ID from CONTENT_SITE_UPLOAD_DETAIL where USER_NAME=?";*/
		String query = DbQueries.jobIdCSUD;
		pstmt = con.prepareStatement(query);
        pstmt.setString(1, user);
		rs = pstmt.executeQuery();
		logger.info(query);

	
		
		while (rs.next())
		{
			ContentUploadBean contentUploadBean=new ContentUploadBean();
			
			contentUploadBean.setJob_Id(rs.getString("JOB_ID"));
			jobIdList.add(contentUploadBean);
			
						}
          logger.info("The size of the list is ["+jobIdList.size()+"]");
		
		rs.close();
		pstmt.close();
		con.close();
		return jobIdList;

	}
	catch (Exception exp)
	{//log it 
		logger.error("Exception in getJobIdSeq()",exp);
		try{
			if(rs !=null)rs.close();
			if(pstmt !=null)pstmt.close();
			if(con !=null)con.close();
		}
		catch(Exception ee){
			logger.error("Error in getJobIdSeq()",ee);
		}
		exp.printStackTrace();
		/*return -1;*/
	}
	finally
	{
		try{
			if(rs !=null)rs.close();
			if(pstmt !=null)pstmt.close();
			if(con !=null)con.close();
		}
		catch(Exception ee){
			logger.error("Error in getJobIdSeq()",ee);
		}
	}
	return jobIdList;

	
	
}



public StringBuffer getSheetPath(StringBuffer stringBuffer, String jobId){
	
	logger.info("in getSheetPath jobID ["+jobId+"]");
	try{
		con=JavaUtil.instance().getConnection();

		/*"select SHEET_NAME from CONTENT_SITE_UPLOAD_DETAIL where JOB_ID=?";*/
		String query = DbQueries.getSheetNameCSUD;
		pstmt = con.prepareStatement(query);
        pstmt.setString(1, jobId);
		rs = pstmt.executeQuery();
		logger.info(query+"jobId["+jobId+"]");

		
		
		while (rs.next())
		{
			logger.info("SHEET PATH ["+rs.getString("SHEET_NAME")+"]");
			
			stringBuffer.append((rs.getString("SHEET_NAME")));
			
		}       
		
		logger.info("stringBuffer======-------.>>"+stringBuffer.toString());
		
		rs.close();
		pstmt.close();
		con.close();
		return stringBuffer;

	}
	catch (Exception exp)
	{//log it 
		logger.error("Exception in getSheetPath()",exp);
		try{
			if(rs !=null)rs.close();
			if(pstmt !=null)pstmt.close();
			if(con !=null)con.close();
		}
		catch(Exception ee){
			logger.error("Error in getSheetPath()",ee);
		}
		exp.printStackTrace();
		//return -1;
	}
	finally
	{
		try{
			if(rs !=null)rs.close();
			if(pstmt !=null)pstmt.close();
			if(con !=null)con.close();
		}
		catch(Exception ee){
			logger.error("Error in getSheetPath()",ee);
		}
	}
	return stringBuffer;

  }




public void dbToFile(String jobId)
{
	
	logger.info("inside ContentManagerDao--- dbToFile()... here we create download file");
	String downSheetName=dateTime();
	downloadSheetName=downSheetName;
	properties = new Properties();
	try
	{	
	//FileInputStream fis1 = new FileInputStream(System.getenv("PROPERTY_FILE_PATH")+"/dao.properties");
	FileInputStream fis1 = new FileInputStream(System.getenv("PROPERTY_FILE_PATH")+"/content_user.properties");
	properties.load(fis1);
	fis1.close();

	}
	catch(IOException e)
	{
		e.printStackTrace();
		return;
	}
	String downloadSheetPath =properties.getProperty("SHEET_PATH");
	downloadSheetPath=downloadSheetPath+"/"+downloadSheetName;
	logger.info("downloadSheetPath= "+downloadSheetPath);
	
	String user_Sdp = properties.getProperty("USER_SDP");
	String pass_Sdp = properties.getProperty("PASS_SDP");
	String url_Sdp = properties.getProperty("URL_SDP");
	String driver =  properties.getProperty("DRIVER_SDP");
	
	
    try {
        FileWriter fw = new FileWriter(downloadSheetPath);
        fw.append("REF_ID");
        fw.append("\t");
        fw.append("RBT_NAME");
        fw.append("\t");
        fw.append("STATUS");
        fw.append("\t");
        fw.append("FILE_TYPE");
        fw.append("\t");
        fw.append("REMARKS");
        fw.append("\n");
        Class.forName(driver).newInstance();
        Connection conn = DriverManager.getConnection(url_Sdp, user_Sdp, pass_Sdp);
       // String query = "select a.reference_id ,a.RBT_NAME ,a.status ,a.file_type , b.DESCRIPTION  from crbt_rbt_bulk_upload a,BULK_UPLOAD_ERR_CODES b where a.ERR_CODE=b.ERR_CODE and job_id=?";
        String query=DbQueries.finalDownloadSheet;
        logger.info("query= "+query);
        PreparedStatement pstmt=conn.prepareStatement(query);
        
        pstmt.setString(1, jobId);
		logger.info("jobID = "+jobId);
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()) {
            fw.append(rs.getString("reference_id"));
            fw.append(',');
            fw.append(rs.getString("RBT_NAME"));
            fw.append(',');
            fw.append(rs.getString("status"));
            fw.append(',');
            fw.append(rs.getString("file_type"));
            fw.append(',');
            fw.append(rs.getString("DESCRIPTION"));
            fw.append('\n');
           }
        fw.flush();
        fw.close();
        conn.close();
        System.out.println("CSV File is created successfully.");
    } catch (Exception e) {
        e.printStackTrace();
    }
}



public void updateSheetName(String jobId)
{
	logger.info("inside ContentManagerDao--- updateSheetName()");
	 Connection con=null;
	 PreparedStatement pstmt=null;
	 ResultSet rs=null;
	 
	 String downSheetName=downloadSheetName;
	 String downloadSheetPath=JavaUtil.instance().getSheetPath()+"/"+downSheetName;
	 logger.info("downSheetName= "+downSheetName+"     downloadSheetPath="+downloadSheetPath);
	try{
		con=JavaUtil.instance().getConnection();

		//String query="update CONTENT_SITE_UPLOAD_DETAIL set SHEET_NAME=?, FOLDER_PATH=? where job_id=?";
		String query=DbQueries.updateSheetName;
		pstmt = con.prepareStatement(query);
		pstmt.setString(1, downSheetName);
        pstmt.setString(2, downloadSheetPath);
        pstmt.setString(3, jobId);
   	 
    	pstmt.executeUpdate();
		logger.info(query);

		
		pstmt.close();
		con.close();
		//return Constants.SUCCESS;

	}
	catch (Exception exp)
	{//log it 
		logger.error("Exception in insertIntoDB()",exp);
		try{
			if(rs !=null)rs.close();
			if(pstmt !=null)pstmt.close();
			if(con !=null)con.close();
		}
		catch(Exception ee){
			logger.error("Error in insertIntoDB()",ee);
		}
		exp.printStackTrace();
		//return Constants.EXCEPTION_OCCUR;
	}
	finally
	{
		try{
			if(rs !=null)rs.close();
			if(pstmt !=null)pstmt.close();
			if(con !=null)con.close();
		}
		catch(Exception ee){
			logger.error("Error in insertIntoDB()",ee);
		}
	}
}

public String dateTime()
{
	
	DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss");
	Date date = new Date();
	String downloadSheetName = dateFormat.format(date)+".csv";
	logger.info("inside dateTime() and downloadSheetName= "+downloadSheetName);
	return downloadSheetName;
}


}
