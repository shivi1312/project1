package com.telemune.dao;

import com.telemune.bean.Session;

public interface AuthDao 
{
  int authenticate(String id,String pass,Session session);
}

