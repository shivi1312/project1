package com.telemune.controllers;

import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.telemune.bean.RoleBean;
import com.telemune.bean.RoleDetailBean;
import com.telemune.constant.Constants;
import com.telemune.service.RoleManagerService;

@Controller
public class RoleController {

	@Autowired
	RoleManagerService roleManagerService;
	@Autowired
	RoleDetailBean roleDetailBean;
	@Autowired
	RoleBean roleBean;
	
	private static final Logger logger = Logger.getLogger(RoleController.class);
	
	@RequestMapping(value="/roleManagement", method=RequestMethod.GET)
	public String addViewRole(Model model)
	{
		logger.info("inside req. mapping- roleManagement");
		return ("addViewRole");
	}
	
	@RequestMapping("/addRoleLink")
	public ModelAndView addRoleLink(@ModelAttribute("RoleDetailBean") RoleDetailBean roleDetailBean)
	{
		logger.info("inside req. mapping- addRoleLink");
		ArrayList roleLinksAl=new ArrayList();
		int ret=roleManagerService.getHttpLinks(roleLinksAl);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("addRole","links",roleLinksAl);
		else 
			return new ModelAndView( "error","msg","Something went wrong");
	}
	
	@RequestMapping("/addRole")
	public ModelAndView addRole(@ModelAttribute("RoleBean") RoleBean roleBean)
	{
		logger.info("inside req. mapping- addRole");
		logger.info("Role ["+roleBean.toString()+"]");
		String[] linkAl=(roleBean.getCheck().split(","));
		logger.info("deleteAl>?<><><><><><><>"+ Arrays.toString(linkAl));
		//roleBean.setRoleId(roleId); 
		roleBean.setLinkAl(linkAl);
		logger.info("modifyRoles>>>>>>>> roleid>>>"+roleBean.getCheck().split(","));
		int ret=roleManagerService.addRoleData(roleBean);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("afterLogin","alerts","14");
		else if(ret==Constants.ROLE_NAME_ALREADY_EXIST)
			return new ModelAndView("afterLogin","alerts","-3");
		else 
			return new ModelAndView( "error","msg","Something went wrong");
    }
	
	@RequestMapping(value="/searchRole")
	public ModelAndView searchRole(@ModelAttribute("RoleDetailBean") RoleDetailBean roleDetailBean,HttpServletRequest request,HttpServletResponse response)
	{
		logger.info("inside req. mapping- searchRole");
		ArrayList roleTypeAl=new ArrayList();
		int ret=roleManagerService.getRoleTypes(roleTypeAl);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("searchRole","roleList",roleTypeAl);
		else
			return new ModelAndView("error","msg","Something went wrong");
	}
	
	@RequestMapping(value ="/viewRoleDetail", method = RequestMethod.GET)
    public  ModelAndView viewRoleDetail(@ModelAttribute("RoleBean") RoleBean roleBean,@RequestParam("roleId") String roleId)
	{
		logger.info("inside req. mapping- viewRoleDetail");
		ArrayList dataAl= new ArrayList();
		roleBean.setRoleId(roleId); 
		int ret=roleManagerService.handleViewRoleDetails(roleBean,dataAl);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("viewRoleDetail","roleList",dataAl);
		else 
			return new ModelAndView( "error","msg","Something went wrong");
    }
	
	@RequestMapping(value ="/modifyLink", method = RequestMethod.GET)
    public  ModelAndView modifyLink(@ModelAttribute("RoleBean") RoleBean roleBean,@RequestParam("roleId") String roleId) 
	{
		logger.info("inside req. mapping- modifyLink");
		ArrayList dataAl= new ArrayList();
		roleBean.setRoleId(roleId); 
		logger.info("viewROleDetail>>>>>>>> roleid>>>"+roleBean.getRoleId());
		int ret=roleManagerService.handleViewRoleDetails(roleBean,dataAl);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS){
			ModelAndView model= new ModelAndView("modifyLink","roleList",dataAl);
			model.addObject("roleId",roleId);
			return model;
		}
		else 
			return new ModelAndView( "error","msg","Something went wrong");
    }
	
	@RequestMapping(value ="/modifyRoles", method = RequestMethod.POST)
    public  ModelAndView modifyRoles(@ModelAttribute("RoleBean") RoleBean roleBean,@RequestParam("roleId") String roleId)
	{
		logger.info("inside req. mapping- modifyRoles");
		String[] linkAl=(roleBean.getCheck().split(","));
		roleBean.setRoleId(roleId); 
		roleBean.setLinkAl(linkAl);
		logger.info("modifyRoles>>>>>>>> roleid>>>"+roleBean.getRoleId());
		int ret=roleManagerService.modifyRoleDetails(roleBean);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("afterLogin","alerts","13");
		else 
			return new ModelAndView( "error","msg","Something went wrong");
    }
	
	@RequestMapping(value ="/deleteRole", method = RequestMethod.POST)
		public  ModelAndView deleteRole(@ModelAttribute("RoleBean") RoleBean roleBean,@RequestParam("roleId") String roleId) 
		{
		logger.info("inside req. mapping- deleteRole");
		String[] deleteAl=(roleBean.getRoleId().split(","));
		roleBean.setRoleId(roleId); 
		roleBean.setDeleteAl(deleteAl);
		logger.info("deleteAl's length "+deleteAl.length);
		logger.info("deleteRole>>>>>>>> roleid>>>"+roleBean.getRoleId()+"  "+deleteAl);
		int ret=roleManagerService.handleDeleteRoles(roleBean);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("afterLogin","alerts","15");
		else 
			return new ModelAndView( "error","msg","Something went wrong");
    }
}
