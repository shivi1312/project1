package com.telemune.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.telemune.bean.AuthBean;
import com.telemune.common.Global;
import com.telemune.common.JavaUtil;
import com.telemune.constant.Constants;
import com.telemune.service.AuthService;

@Controller
public class LoginController {
	private static final Logger logger = Logger.getLogger(LoginController.class);
	
	@Autowired
	AuthService authService;
	/*@Autowired
	AuthBean authbean;*/
	@Autowired
	Global globalMap;
	

	@Autowired
	JavaUtil javaUtil;
	
	@RequestMapping(value={"/login","/"})
	public String loginPage(Model model)
	{
		logger.info("Start executing login method.");
		/*model.addAttribute("AuthBean",new AuthBean());*/
		AuthBean authBean = javaUtil.getContext().getBean(AuthBean.class);
		//System.out.println("authBean hashCode "+authBean.hashCode());
		model.addAttribute("AuthBean",authBean);
		return "loginPage";
	}
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView authenticate(@ModelAttribute("AuthBean") AuthBean authBean,HttpServletRequest request,SessionStatus status,Model model)
	{
		logger.info("inside req. mapping- login");
		int ret=authService.validation(authBean, request);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
		{
			HttpSession session = request.getSession();
			session.setAttribute("map", globalMap.sessionMap);
			model.addAttribute("link", globalMap.sessionMap.get("links"));//new
			return new ModelAndView("afterLogin");
		}
		
		else
			return new ModelAndView("loginPage","alerts",Constants.INVALID_PASS);
	}
	
	
	@RequestMapping(value="/logout")
	public ModelAndView logout(Model model,HttpSession session)
	{
		logger.info("inside req. mapping- logout");
		if(session!= null)
		{
			logger.info("before logout "+session.getAttribute("map"));
			session.invalidate();
			globalMap.sessionMap.clear();
		}
		
		AuthBean authBean = javaUtil.getContext().getBean(AuthBean.class);
		//System.out.println("authBean hashCode "+authBean.hashCode());
		model.addAttribute("AuthBean",authBean);
		//model.addAttribute("AuthBean",new AuthBean());
		return new ModelAndView("loginPage");
	}
	
	@RequestMapping("/version")
	public ModelAndView version()
	{
		return new ModelAndView("version");
	}
	
	@RequestMapping("/error")
	public ModelAndView errorPage()
	{
		return new ModelAndView("errorPage");
	}
}
