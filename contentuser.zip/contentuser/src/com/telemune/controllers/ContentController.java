/*package com.telemune.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.telemune.bean.ContentUploadBean;
import com.telemune.bean.DownloadBean;
import com.telemune.common.Global;
import com.telemune.constant.Constants;
import com.telemune.service.ContentManagerService;
import com.telemune.service.DownloadContentService;

@Controller
public class ContentController {
	@Autowired
	ContentManagerService contentManagerService;
	@Autowired
	ContentUploadBean contentUploadBean;
	@Autowired
	DownloadContentService downloadContentService;
	@Autowired
	DownloadBean downloadBean;
	@Autowired
	Global globalMap;
	
	private static final Logger logger = Logger.getLogger(ContentController.class);
	@RequestMapping("/uploadLink")
	public ModelAndView uploadLink(Model model)
	{
			logger.info("inside req. mapping- uploadLink");
			Map<String, Object> map1 = new HashMap<String, Object>();
			map1=contentManagerService.jobIdContType();
			return new ModelAndView("contentUpload","map1",map1);
	}
	
	@RequestMapping("/contentUpload")
	public ModelAndView uploadFile(@ModelAttribute("ContentUploadBean")ContentUploadBean contentUploadBean, @RequestParam("uploadFile") MultipartFile file)
	{
		logger.info("inside req. mapping- contentUpload");
		int ret=contentManagerService.bulkUploadContent(contentUploadBean);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("afterLogin","alerts","16");
		else 
			return new ModelAndView( "error","msg","Something went wrong");
	}
	
	
	@RequestMapping("/downloadLink1")
	public ModelAndView downloadLink(@ModelAttribute("ContentUploadBean")ContentUploadBean contentUploadBean)
	{
		logger.info("inside req. mapping- downloadLink");
		ArrayList jobIdAl= new ArrayList();
		jobIdAl=downloadContentService.downloadContent();
		return new ModelAndView("downloadLink","jobIdAl",jobIdAl);
	}
	
	@RequestMapping("/downloadLink2")
	public ModelAndView downloadLink2(@ModelAttribute("DownloadBean")DownloadBean downloadBean)
	{
		logger.info("inside req. mapping- downloadLink2");
		int ret=downloadContentService.downloadContentExecute(downloadBean);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("downloadMain");
		else 
			return new ModelAndView( "error","msg","Something went wrong");
	}
	
	@RequestMapping("/downloadSheet")
	 public void downloadCsv(HttpServletRequest req,HttpServletResponse resp) throws IOException 
	 {
			        String csvFilePath = "";
		        logger.info("Downloading A .CSV File From The Server ....!"); 
		 
			        csvFilePath = (String) globalMap.sessionMap.get("download_path");
			        logger.info("Absolute Path Of The .CSV File Is?= " + csvFilePath);
		
			        File downloadFile = new File(csvFilePath);
			        if(downloadFile.exists()) {
			        	try{
			        		resp.setContentType("text/csv");
			        		OutputStream outStream = resp.getOutputStream();
			        		FileInputStream inputStream = new FileInputStream(downloadFile);
			        		byte[] buffer = new byte[4096];
			        		int bytesRead = -1;

			        		//**** Write Each Byte Of Data Read From The Input Stream Write Each Byte Of Data  Read From The Input Stream Into The Output Stream ****//*
			        		while ((bytesRead = inputStream.read(buffer)) != -1) {
			        			outStream.write(buffer, 0, bytesRead);
			        		}

			        		inputStream.close();
			        		outStream.close();
			        	}
			        	catch(IOException ioExObj) {
			        		logger.error("Exception While Performing The I/O Operation?= " + ioExObj);
			        	}
			        } else {
			            logger.info("Requested .CSV File Not Found At The Server ....!");
			        }
			        
				}
}
*/













package com.telemune.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.telemune.bean.ContentUploadBean;
import com.telemune.bean.DownloadBean;
import com.telemune.common.Global;
import com.telemune.constant.Constants;
import com.telemune.service.ContentManagerService;
import com.telemune.service.DownloadContentService;

@Controller
public class ContentController {
	@Autowired
	ContentManagerService contentManagerService;
	@Autowired
	ContentUploadBean contentUploadBean;
	@Autowired
	DownloadContentService downloadContentService;
	@Autowired
	DownloadBean downloadBean;
	@Autowired
	Global globalMap;
	/*@Autowired
	ApplicationContext context;*/
	private static final Logger logger = Logger.getLogger(ContentController.class);
	@RequestMapping("/uploadLink")
	public ModelAndView uploadLink(Model model)
	{
			logger.info("inside req. mapping- uploadLink");
			Map<String, Object> map1 = new HashMap<String, Object>();
			map1=contentManagerService.jobIdContType();
			/*ContentUploadBean contentBean=context.getBean(ContentUploadBean.class);*/
			return new ModelAndView("contentUpload","map1",map1);
	}
	
	@RequestMapping("/contentUpload")
	public ModelAndView uploadFile(@ModelAttribute("ContentUploadBean")ContentUploadBean contentUploadBean, @RequestParam("uploadFile") MultipartFile file) throws IOException
	{
		logger.info("inside req. mapping- contentUpload");
		int ret=contentManagerService.bulkUploadContent(contentUploadBean);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("afterLogin","alerts","16");
		else 
			return new ModelAndView( "error","msg","Something went wrong");
	}
	
	
	@RequestMapping("/downloadLink1")
	public ModelAndView downloadLink(@ModelAttribute("ContentUploadBean")ContentUploadBean contentUploadBean)
	{
		logger.info("inside req. mapping- downloadLink");
		ArrayList jobIdAl= new ArrayList();
		jobIdAl=downloadContentService.downloadContent();
		return new ModelAndView("downloadLink","jobIdAl",jobIdAl);
	}
	
	@RequestMapping("/downloadLink2")
	public ModelAndView downloadLink2(@ModelAttribute("DownloadBean")DownloadBean downloadBean)
	{
		logger.info("inside req. mapping- downloadLink2");
		int ret=downloadContentService.downloadContentExecute(downloadBean);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("downloadMain");
		else 
			return new ModelAndView( "error","msg","Something went wrong");
	}
	
	@RequestMapping("/downloadSheet")
	 public void downloadCsv(HttpServletRequest req,HttpServletResponse resp) throws IOException 
	 {
			        String csvFilePath = "";
		        logger.info("Downloading A .CSV File From The Server ....!"); 
		 
			        csvFilePath = (String) globalMap.sessionMap.get("download_path");
			        logger.info("Absolute Path Of The .CSV File Is?= " + csvFilePath);
		
			        File downloadFile = new File(csvFilePath);
			        if(downloadFile.exists()) {
			        	try{
			        		resp.setContentType("text/csv");
			        		OutputStream outStream = resp.getOutputStream();
			        		FileInputStream inputStream = new FileInputStream(downloadFile);
			        		byte[] buffer = new byte[4096];
			        		int bytesRead = -1;

			        		//**** Write Each Byte Of Data  Read From The Input Stream Into The Output Stream ****//*
			        		while ((bytesRead = inputStream.read(buffer)) != -1) {
			        			outStream.write(buffer, 0, bytesRead);
			        		}

			        		inputStream.close();
			        		outStream.close();
			        	}
			        	catch(IOException ioExObj) {
			        		logger.error("Exception While Performing The I/O Operation?= " + ioExObj);
			        	}
			        } else {
			            logger.info("Requested .CSV File Not Found At The Server ....!");
			        }
			        
				}
}
