package com.telemune.controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.telemune.bean.Roles;
import com.telemune.bean.UserDetailBean;
import com.telemune.common.JavaUtil;
import com.telemune.constant.Constants;
import com.telemune.dao.UserManagerDao;
import com.telemune.service.UserManagerService;

@Controller
public class UserController {
	/*@Autowired
	UserDetailBean userDetailBean;*/
	@Autowired
	UserManagerDao userManagerDao;
	@Autowired
	UserManagerService userManagerService;
	@Autowired
	JavaUtil javaUtil;
	
	private static final Logger logger = Logger.getLogger(UserController.class);
	@RequestMapping(value="/userManagement", method=RequestMethod.GET)
	public ModelAndView afterLogin(Model model)
	{
		logger.info("inside req. mapping- userManagement");
		List<Roles> rolesList=userManagerDao.getRoles(); // use to show all roles in select option
		return new ModelAndView("searchUser","rolesList",rolesList);
	}
	
	@RequestMapping(value="/searchUser")
	public ModelAndView searchUser(@ModelAttribute("UserDetailBean") UserDetailBean userDetailBean,HttpServletRequest request,HttpServletResponse response)
	{
		logger.info("inside req. mapping- searchUser");
		if(userDetailBean.getRoleId()==Constants.SELECT_ROLE_TYPE){
			userDetailBean.setRoleId(Constants.ALL_ROLE_TYPE);
		}
		ArrayList adminUserAl=new ArrayList();
		//ArrayList adminUserAl=javaUtil.getContext().getBean(ArrayList.class);
		//System.out.println("adminUserAl hashCode "+adminUserAl.hashCode());
			int ret=userManagerService.getUserData(adminUserAl,userDetailBean);
			logger.info("Status ["+ret+"]");
			if(ret==Constants.SUCCESS)
				return new ModelAndView("searchResult","userList",adminUserAl);
			else
				return new ModelAndView("error","msg","Something went wrong");
	}

	@RequestMapping(value ="/view", method = RequestMethod.GET)
    public  ModelAndView viewDetails(@ModelAttribute("UserDetailBean") UserDetailBean userDetailBean,@RequestParam("userId") String userId,@RequestParam("userName") String userName)
	{
		logger.info("inside req. mapping- view");
		ArrayList adminUserAl=new ArrayList();
		//ArrayList adminUserAl=javaUtil.getContext().getBean(ArrayList.class);
		userDetailBean.setUserId(userId);
		userDetailBean.setUserName(userName);
		int ret=userManagerService.getUserDataForViewModify(adminUserAl,userDetailBean);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("view","userList",adminUserAl);
		else 
			return new ModelAndView( "error","msg","Something went wrong");
    }
	
	@RequestMapping(value ="/modify", method = RequestMethod.GET)
	public ModelAndView modifyDetails(@ModelAttribute("UserDetailBean") UserDetailBean userDetailBean,@RequestParam("userId") String userId,@RequestParam("userName") String userName)
	{
		logger.info("inside req. mapping- modify");
		ArrayList adminUserAl=new ArrayList();
	//	ArrayList adminUserAl=javaUtil.getContext().getBean(ArrayList.class);
		//adminUserAl.add(userDetailBean);
		List<Roles> rolesList=userManagerDao.getRoles();
		Map<String, Object> model = new HashMap<String, Object>();
		//Map<String, Object> model =javaUtil.getContext().getBean(HashMap.class);
		//System.out.println("model hashCode "+model.hashCode());
		//model.put("userList",adminUserAl);
		
		model.put("rolesList",rolesList);
		userDetailBean.setUserId(userId);
		userDetailBean.setUserName(userName); 
		logger.info("map(model) value= "+model.toString());
		int ret=userManagerService.getUserDataForViewModify(adminUserAl,userDetailBean);
		model.put("userList",adminUserAl);
		/*logger.info("#############3userarList"+adminUserAl.toString() +" userBean "+userDetailBean.toString());*/
		//int ret=userManagerService.getUserData(userDetailBean);
		logger.debug("userList value= "+adminUserAl.toString());
		logger.debug("map(model) AFTER  value= "+model.toString());
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("modify","model",model);
		else 
			return new ModelAndView( "error","msg","Something went wrong");
	}
	
	@RequestMapping("/updateUserDetails")
	public ModelAndView updateDetails(@ModelAttribute("UserDetailBean") UserDetailBean userDetailBean)
	{
		logger.info("inside req. mapping- updateUserDetails");
		int ret=userManagerService.updateUser(userDetailBean);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("searchUser","alerts","10");
		else 
			return new ModelAndView( "error","msg","Something went wrong");
	}
	
	@RequestMapping("/addUserLink")
	public ModelAndView addUserLink(Model model)
	{
		logger.info("inside req. mapping- addUserLink");
		List<Roles> rolesList=userManagerDao.getRoles();
		return new ModelAndView("addUser","rolesList",rolesList);
	}
	
	@RequestMapping("/addUserDetails")
	public ModelAndView addUserDetails(@ModelAttribute("UserDetailBean") UserDetailBean userDetailBean)
	{
		logger.info("inside req. mapping- addUserDetails");
		int ret=userManagerService.addUser(userDetailBean);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("afterLogin","alerts","11");
		else if(ret==Constants.RECORD_ALREADY_EXISTS)
			return new ModelAndView("afterLogin","alerts","-22");
		else 
			return new ModelAndView( "error","msg","Something went wrong");
	}
	
	@RequestMapping("/deleteUser")
	public ModelAndView deleteUser(@ModelAttribute("UserDetailBean") UserDetailBean userDetailBean)
	{
		logger.info("inside req. mapping- deleteUser");
		logger.info("userID in deleteUser controller"+userDetailBean.getUserId());
		List adminUserAl=Arrays.asList(userDetailBean.getUserId().split(","));
		int ret=userManagerService.deleteUser(adminUserAl);
		logger.info("Status ["+ret+"]");
		if(ret==Constants.SUCCESS)
			return new ModelAndView("afterLogin","alerts","12");
		else 
			return new ModelAndView( "error","msg","Something went wrong");
	}
	
}
