package com.telemune.vcc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


/**
 * THIS CLASS IS MAIN CLASS WHICH ACTIVATE ALL THE THREADS AND START BINARY
 * 
 * @author swati
 * 
 */

public class DeliveryMain {
	static Logger logger = Logger.getLogger(DeliveryMain.class);
	static Logger errorLogger = Logger.getLogger("errorLogger");

	static Thread threq;
	static Thread thrdRecv;
	static Thread threqProcess;
	static Thread smsthrd;
	static Thread obdthrd;
	static Thread mmsthrd;
	static Thread mailthrd;
	static Thread reqSchldThrd;
	static Thread cacheLoderThrd;

	@SuppressWarnings("unused")
	public static void main(String args[]) {
		/*PropertyConfigurator.configure("properties/delivery_log.properties");*/

		
		
		try {
			String VERSION = "R3.0.0.3";

			String SITE = "VCC Delivery Engine";
			try{
			if(args[0].equalsIgnoreCase("-v"))
			{
				System.out
						.println("\n******************************************************************************************");
				System.out
						.println("\n                          	VCC DELIVERY ENGINE  Version [  "
								+ VERSION + "  ] ");
				System.out
						.println("\n				Copyright @2004-2015Telemune Software Solutions Private Limited. All rights reserved");
				System.out.println("\n				Name of the Licensee : Telemune");
				System.out
						.println("\n				Licence ID: 08981Telemune98Client00909");
				System.out
						.println("\n******************************************************************************************");
				System.out.println("\n");
				System.exit(0);
			}
			}catch(Exception e){
				
			}
			int numofcon = -1;
			int accomodation = -1;
			int minnumofcon = 1;
			String dbuser = "NA";
			String dbpass = "NA";
			String dburl = "NA";
			String driver = "NA";

			Properties chrPro = new Properties();
			try {
				FileInputStream fins = new FileInputStream(
						"properties/deliveryEngine.properties");
				chrPro.load(fins);
				fins.close();
			} catch (FileNotFoundException fnf) {
				errorLogger
						.error("ErrorCode [VCC-MSGDEL-90006] [FileNotFound Exception in loading properties file.] Error[ "
								+ fnf.getMessage() + "]");
				System.exit(1);
			} catch (IOException ioe) {
				errorLogger
						.error("ErrorCode [VCC-MSGDEL-90002] [IOException in loading properties file.] Error[ "
								+ ioe.getMessage() + "]");
				logger.fatal("Error in loading properties file");
				System.exit(1);
			}

			try {
				
				PropertyConfigurator.configureAndWatch(
						"properties/delivery_log.properties", Long
								.parseLong(chrPro.getProperty("LOGGER_FILE_REFRESH_INTERVAL").trim()));
				
				logger.info("Loading Configuration for the Application");
				logger.info("Database Connectivity");

				// LODING MYSQL CONFIGURATION
				// PARAMTERS................................
				dbuser = chrPro.getProperty("DBUSER").trim();
				dbpass = chrPro.getProperty("DBPASSWORD").trim();
				dburl = chrPro.getProperty("DBURL").trim();
				driver = chrPro.getProperty("DRIVER").trim();
				logger.info("Loading Threads Information");
				numofcon = Integer.parseInt(chrPro.getProperty(
						"NUM_OF_CONNECTION").trim());
				minnumofcon = Integer.parseInt(chrPro.getProperty(
						"MIN_NUM_OF_CONNECTION").trim());
				accomodation = Integer.parseInt(chrPro.getProperty(
						"DB_ACCOMODATION").trim());

				// Parameter for MMS Application COnnection
				Global.MMSAPPIP = chrPro.getProperty("MMSAPPIP");
				Global.MMSPORT = Integer
						.parseInt(chrPro.getProperty("MMSPORT"));

				// Parameter for EMAIL APPLication Connection
				Global.EMAILAPPIP = chrPro.getProperty("EMAILAPPIP");
				Global.EMAILPORT = Integer.parseInt(chrPro
						.getProperty("MMSPORT"));

				Global.Time = Integer.parseInt(chrPro.getProperty("TIME")
						.toString());
				Global.RELOADTIME = Integer.parseInt(chrPro.getProperty(
						"RELOAD_TIME").trim());
				Global.ivrRecordBasePath = chrPro
						.getProperty("ivr_record_path").trim();
				Global.defaultRecordDigit = Integer.parseInt(chrPro
						.getProperty("default_record_digits"));

				Global.dbConfigParam = Integer.parseInt(chrPro
						.getProperty("DB_CONFIG_PARAM"));
				Global.vm_count_enable = Integer.parseInt(chrPro
						.getProperty("VM_COUNT_ENABLE"));
				Global.vn_count_enable = Integer.parseInt(chrPro
						.getProperty("VN_COUNT_ENABLE"));

				// Added by AbhiShek Rana
				Global.errorcode_pattern = chrPro.getProperty(
						"errorcode_pattern", "VCC-MSGDEL-");

				logger.info("Property file loded successfully");

			} catch (Exception e) {
				errorLogger
						.error("ErrorCode[VCC-MSGDEL-00001] [Exception while reading properties from properties file] Error["
								+ e.getMessage() + "]");
				e.printStackTrace();
				logger.fatal("ReadExce:" + e.toString());
				System.out.println("ReadExce:" + e.toString());
				System.exit(1);
				// TODO: handle exception
			}
			logger.info("Intializing Database..." + chrPro.toString());

			// MAKE A CONNECTION FROM DATA BASE
			Global.conPool = new ConnPool(driver, dburl, dbuser, dbpass,
					minnumofcon, numofcon, accomodation);
			Global.conPool.MakePool();

			CacheLoader cacheLoadThread = new CacheLoader();
			cacheLoderThrd = new Thread(cacheLoadThread);
			cacheLoderThrd.start();

			RequestReader requestReaderThread = new RequestReader();
			threq = new Thread(requestReaderThread);
			threq.start();

			RequestReceiver reqReceiverThread = new RequestReceiver();
			thrdRecv = new Thread(reqReceiverThread);
			thrdRecv.start();

			RequestProcessor requestProcessing = new RequestProcessor();
			threqProcess = new Thread(requestProcessing);
			threqProcess.start();

			SMSProcessor smsProcessingTh = new SMSProcessor();
			smsthrd = new Thread(smsProcessingTh);
			smsthrd.start();

			OBDProcessor obdProcessingTh = new OBDProcessor();
			obdthrd = new Thread(obdProcessingTh);
			obdthrd.start();

			RequestScheduling requestSchdlTh = new RequestScheduling();
			reqSchldThrd = new Thread(requestSchdlTh);
			reqSchldThrd.start();

			/*
			 * EmailProcessor mailProcessingTh=new EmailProcessor();
			 * mailthrd=new Thread(mailProcessingTh); mailthrd.start();
			 * 
			 * MMSProcessor mmsProcessingTh=new MMSProcessor(); mmsthrd=new
			 * Thread(mmsProcessingTh); mmsthrd.start();
			 */

			if (!cacheLoderThrd.isAlive()) {
				try {
					cacheLoderThrd = new Thread(cacheLoadThread);
					cacheLoderThrd.start();
				} catch (Exception e) {
					errorLogger
							.error("ErrorCode["
									+ Global.errorcode_pattern
									+ "00002] [Exception while restarting cache loader] Error["
									+ e.getMessage() + "]");
					logger.error("Exception inside cache loader Thread restart"
							+ e.getMessage());// TODO: handle exception
				}
			}

			if (!threq.isAlive()) {
				try {

					threq = new Thread(requestReaderThread);
					threq.start();
				} catch (Exception e) {
					errorLogger
							.error("ErrorCode["
									+ Global.errorcode_pattern
									+ "00003] [Exception while restarting Request Thread] Error["
									+ e.getMessage() + "]");
					logger.error("Exception inside Request Thread restart"
							+ e.getMessage());// TODO: handle exception
				}
			}
			if (!thrdRecv.isAlive()) {
				try {

					thrdRecv = new Thread(reqReceiverThread);
					thrdRecv.start();
				} catch (Exception e) {
					errorLogger
							.error("ErrorCode["
									+ Global.errorcode_pattern
									+ "00004] [Exception while restarting Request Receiver Thread] Error["
									+ e.getMessage() + "]");
					logger.error("Exception inside Request Receiver Thread restart"
							+ e.getMessage());// TODO: handle exception
				}
			}

			if (!threqProcess.isAlive()) {
				try {
					threqProcess = new Thread(requestProcessing);
					threqProcess.start();
				} catch (Exception e) {
					errorLogger
							.error("ErrorCode["
									+ Global.errorcode_pattern
									+ "00005] [Exception while restarting RequestProcessing Thread] Error["
									+ e.getMessage() + "]");
					logger.error("Exception inside RequestProcessing thread restart"
							+ e.getMessage()); // TODO: handle exception
				}
			}

			if (!smsthrd.isAlive()) {
				try {
					smsthrd = new Thread(smsProcessingTh);
					smsthrd.start();
				} catch (Exception e) {
					errorLogger
							.error("ErrorCode["
									+ Global.errorcode_pattern
									+ "00006] [Exception while restarting SMSProcessing Thread] Error["
									+ e.getMessage() + "]");
					logger.error("Exception inside SMSProcessing thread restarted"
							+ e.getMessage());// TODO: handle exception
				}
			}

			if (!obdthrd.isAlive()) {
				try {

					obdthrd = new Thread(obdProcessingTh);
					obdthrd.start();
				} catch (Exception e) {
					errorLogger
							.error("ErrorCode["
									+ Global.errorcode_pattern
									+ "00007] [Exception while restarting OBDProcessing Thread] Error["
									+ e.getMessage() + "]");
					logger.error("Exception inside OBDProcessing thread restarted"
							+ e.getMessage()); // TODO: handle exception
				}
			}
			/*
			 * if(!mmsthrd.isAlive()) { try { mmsthrd=new
			 * Thread(mmsProcessingTh); mmsthrd.start(); } catch (Exception e) {
			 * logger
			 * .error("Exception inside MMSProcessing thread restarted"+e.getMessage
			 * ()); // TODO: handle exception } } if(!mailthrd.isAlive()) { try
			 * { mailthrd=new Thread(mailProcessingTh); mailthrd.start(); }
			 * catch (Exception e) {
			 * logger.error("Exception inside SMSProcessing thread restarted"
			 * +e.getMessage()); // TODO: handle exception } }
			 */

		} catch (Exception ex) {
			errorLogger.error("ErrorCode[" + Global.errorcode_pattern
					+ "00008] [Exception inside DeliveryMain Class] Error["
					+ ex.getMessage() + "]");
			logger.error("Exception inside DeliveryMain Class"
					+ ex.getMessage());
			ex.printStackTrace();
		}
	}

}
