package com.telemune.vcc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;

import org.apache.log4j.Logger;

import com.telemune.vcc.history.VccFileDeleteWriter;

/**
 * THIS CLASS IS FOR HANDLING ALL THE DATA BASE TRANSACTIONS AND UPDATION
 * 
 * @author swati
 * @version:- R1_0_0_0
 */
public class DBHandler {
	static Logger logger = Logger.getLogger(DBHandler.class);
	static Logger errorLogger = Logger.getLogger("errorLogger");

	Connection con = null;

	/**
	 * THIS FUNCTION IS FOR UPDATE DELIVERY STATUS ON THE BASIS OF
	 * LOCAL_MESSAGE_INDEX
	 * 
	 * @param localIndex
	 *            :- THIS IS THE UNIQUE ID IN VCC_NOTIFICATION TABLE
	 * @param status
	 *            :- THIS IS THE STATUS OF ENTRY WHICH INDICATE ENTRY IS PROCESS
	 *            OR NOT
	 * @param transactionId
	 *            :-THIS IS REFERS TO SYSTEM ID OR REMOTE ID WHICH RECEIVE IN
	 *            CASE OF MMS
	 * @return 1 FOR SUCCESS
	 */
	public Integer updateDeliveryStatus(Integer localIndex, String status,
			int transactionId) {
		PreparedStatement pstmt = null;
		String query = "";
		int result = -1;

		logger.info("Inside updateDeliveryTimeStatus() function  Voice MSG Index ["
				+ localIndex
				+ "]  TranscationID is ["
				+ transactionId
				+ "] Status is [" + status + "]");

		try {
			con = Global.conPool.getConnection();

			if (con == null) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00012] [Unable to update VCC_NOTIFICATION because connection is NULL]");
				logger.error("Can not update VCC_NOTIFICATION table because connection in NULL So Binary going to RESTART..");
				System.exit(1);
			}

			if (transactionId > 0) {

				if (Global.dbConfigParam == 1) {
					query = "update VCC_NOTIFICATION set STATUS=?,UPDATE_TIME=now(),TRANSACTION_ID=? where VOICE_MSG_INDEX=?";

				} else if (Global.dbConfigParam == 0) {
					query = "update VCC_NOTIFICATION set STATUS=?,UPDATE_TIME=sysdate,TRANSACTION_ID=? where VOICE_MSG_INDEX=?";
				}
				logger.info("Query is [" + query + "]");
				pstmt = con.prepareStatement(query);
				pstmt.setInt(2, transactionId);
				pstmt.setInt(3, localIndex);
			} else {
				if (Global.dbConfigParam == 1) {
					query = "update VCC_NOTIFICATION set STATUS=?,UPDATE_TIME=now() where VOICE_MSG_INDEX=?";
				} else if (Global.dbConfigParam == 0) {
					query = "update VCC_NOTIFICATION set STATUS=?,UPDATE_TIME=sysdate where VOICE_MSG_INDEX=?";

				}

				logger.info("Query is [" + query + "]");
				pstmt = con.prepareStatement(query);
				pstmt.setInt(2, localIndex);
			}

			pstmt.setString(1, status);
			result = pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch (SQLException se) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90001] [SQLException while updating VCC_NOTIFICATION] Error["
							+ se.getMessage() + "]");
			se.printStackTrace();
			result = -2;
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00013] [Exception Inside updateDeliveryTimeStatus() function] Error["
							+ e.getMessage() + "]");
			logger.error(
					"Exception Inside updateDeliveryTimeStatus() function", e);
			e.printStackTrace();
			result = -2;
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in updateDeliveryTimeStatus() function] Error["
								+ ex.getMessage() + "]");
				result = -1;
				logger.error("Error in closing resource", ex);
			}

		}

		return result;
	}// Update Data()

	/**
	 * THIS FUNCTION IS FOR CREATING TEMPLATE ACCORDING TO DYNAMIC VARIABLE
	 * VALUE
	 * 
	 * @param srcTemplate
	 *            :-THIS REFERS TO MESSAGE
	 * @param tagMaps
	 *            :-THIS REFERS TO HASH TABLE WHICH CONTAIN VALUES OF THAT
	 *            DYNAMIC VARIABLE
	 * @return :- THIS RETURN MESSAGE MADE BY REPLACING DYNAMIC VARIABLES
	 */
	public String CreateTemplate(String srcTemplate,
			Hashtable<String, String> tagMaps) {
		String key = "";
		try {
			Enumeration keys = tagMaps.keys();
			while (keys.hasMoreElements()) {
				key = (String) keys.nextElement();

				srcTemplate = srcTemplate.replace(key,
						(String) tagMaps.get(key));
			}
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90003] [NullPointerException Inside createTemplate() function] Error["
							+ npe.getMessage() + "]");

		} catch (Exception ex) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00015] [Exception Inside createTemplate() function] Error["
							+ ex.getMessage() + "]");
			logger.error("Error Inside CreateTemplate() Function ", ex);
		}
		return srcTemplate;
	}

	/**
	 * THIS FUNCTION IF FOR INSERT ENTRY INTO GMAT_MESSAGE_STORE
	 * 
	 * @param dataObjectBean
	 *            :- THIS IS A BEAN OBJECT WHICH HAVE ALL RECEIVGING DATA
	 * @param key
	 *            :-THIS IS KEY VALUE FOR FETCHING TEMPLATE MESSAGE
	 * @return 1 FOR SUCCESS
	 */
	public int insertSMSRequest(DataObjectBean dataObjectBean, String key,
			Hashtable messageMap, String senderId) {
		logger.info("Inside insertSMSRequest() origination number ["
				+ dataObjectBean.getOriginationNumber()
				+ "] destination number is ["
				+ dataObjectBean.getDestinationNumber() + "] key is [" + key
				+ "] senderId [" + senderId + "]");

		PreparedStatement pstmt = null;
		String query = "";
		String TemplateMessage = "ERROR";
		String message = "";
		int retVal = -1;
		try {

			TemplateMessage = VCCConfiguration.getInstance().getTemplate(key);
			if (TemplateMessage == null) {
				logger.error("There is not any template exist");
				retVal = -1;
			}

			if (messageMap.size() != 0) {
				logger.debug("Message Map size is greater than 0");
				message = CreateTemplate(TemplateMessage, messageMap);
			} else {
				logger.info("message Map size is equal to 0");
				message = TemplateMessage;
			}
			logger.debug("Template message is [" + message + "]");
			con = Global.conPool.getConnection();
			logger.info("Inside insertSMSRequest() origination number ["
					+ dataObjectBean.getOriginationNumber()
					+ "] destination number is ["
					+ dataObjectBean.getDestinationNumber()
					+ "] Template message is [" + message + "] key is [" + key
					+ "]");

			if (Global.dbConfigParam == 1) {
				query = "insert into GMAT_MESSAGE_STORE(ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT,SUBMIT_TIME,STATUS,MESSAGE_TYPE,DESTINATION_PORT,LANGUAGE_ID) values (?,?,?,now(),?,1,0,?)";
			} else if (Global.dbConfigParam == 0) {
				query = "insert into GMAT_MESSAGE_STORE(RESPONSE_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT,SUBMIT_TIME,STATUS,MESSAGE_TYPE,DESTINATION_PORT,LANGUAGE_ID) values (gmat_request_seq.nextval,?,?,?,sysdate,?,1,0,?)";

			}
			pstmt = con.prepareStatement(query);
			logger.info("Query [" + query + "]");
			pstmt.setString(1, senderId);
			pstmt.setString(2, dataObjectBean.getDestinationNumber());
			pstmt.setString(3, message);
			pstmt.setString(4, "R");
			pstmt.setInt(5, dataObjectBean.getLang());

			pstmt.executeUpdate();
			retVal = 1;
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90001] Origination Number ["
							+ dataObjectBean.getOriginationNumber()
							+ "] Destination Number["
							+ dataObjectBean.getDestinationNumber()
							+ "] [SQLException while inserting in GMAT_MSG_STORE table] Error["
							+ e.getMessage() + "]");
			logger.error("Inside Exception block of insert into gmat_message_store "
					+ e.getMessage());
			e.printStackTrace();
			retVal = -1;
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00017] Origination Number ["
							+ dataObjectBean.getOriginationNumber()
							+ "] Destination Number["
							+ dataObjectBean.getDestinationNumber()
							+ "] [Exception while inserting in GMAT_MSG_STORE table] Error["
							+ e.getMessage() + "]");
			e.printStackTrace();
			retVal = -1;
		}

		finally {
			try {
				if (pstmt != null) {
					pstmt.close();

				}
				if (con != null)
					con.close();
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in insertSMSRequest() function] Error["
								+ e.getMessage() + "]");
				e.printStackTrace();
				retVal = -1;
			}

		}
		return retVal;
	}

	/**
	 * THIS FUNCTION IS FOR INSERTING AND UPDATING DATA INTO VCC_OUT_DIAL_DATA
	 * TABLE
	 * 
	 * @param dataObjectBean
	 *            :-THIS REFERS TO BEAN OBJECT OF RECEIVING DATA CLASS
	 * @return 1 FOR SUCCESS
	 */
	public int insertOBDRequest(DataObjectBean dataObjectBean) {
		logger.info("Inside insertOBDRequest() data is [" + dataObjectBean
				+ " ]");
		String query = "";
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		int retVal = -1;
		try {
			con = Global.conPool.getConnection();
			query = "select DESTINATION_NUMBER,STATUS,UPDATE_TIME,RETRY_COUNT from VCC_OUT_DIAL_DATA where DESTINATION_NUMBER=?";
			pstmt = con.prepareStatement(query);
			logger.info("Query is [" + query + "]");
			pstmt.setString(1, dataObjectBean.getDestinationNumber());
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if (Global.dbConfigParam == 1)
					query = "update VCC_OUT_DIAL_DATA set STATUS=?,UPDATE_TIME=now() where DESTINATION_NUMBER=?";
				else if (Global.dbConfigParam == 0)
					query = "update VCC_OUT_DIAL_DATA set STATUS=?,UPDATE_TIME=sysdate where DESTINATION_NUMBER=?";

				logger.info("Query is [" + query + "]");
				pstmt1 = con.prepareStatement(query);
				pstmt1.setString(1, "N");
				pstmt1.setString(2, dataObjectBean.getDestinationNumber());
				pstmt1.executeUpdate();
				pstmt1.close();
				pstmt1=null;
			} else {
				if (Global.dbConfigParam == 1)
					query = "insert into VCC_OUT_DIAL_DATA (DESTINATION_NUMBER,STATUS,UPDATE_TIME) values(?,?,now())";
				else if (Global.dbConfigParam == 0)
					query = "insert into VCC_OUT_DIAL_DATA (DESTINATION_NUMBER,STATUS,UPDATE_TIME) values(?,?,sysdate)";

				logger.info("Query is [" + query + "]");
				pstmt1 = con.prepareStatement(query);
				pstmt1.setString(1, dataObjectBean.getDestinationNumber());
				pstmt1.setString(2, "N");
				pstmt1.executeUpdate();
				pstmt1.close();
				pstmt1=null;
			}
			retVal = 1;
			pstmt.close();
			rs.close();
			con.close();
		} catch (SQLException se) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90001] Origination Number ["
							+ dataObjectBean.getOriginationNumber()
							+ "] Destination Number["
							+ dataObjectBean.getDestinationNumber()
							+ "] [SQLException while inserting in VCC_OUT_DIAL_DATA table] Error["
							+ se.getMessage() + "]");
			se.printStackTrace();
			retVal = -1;
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00018] Origination Number ["
							+ dataObjectBean.getOriginationNumber()
							+ "] Destination Number["
							+ dataObjectBean.getDestinationNumber()
							+ "] [Exception while inserting in VCC_OUT_DIAL_DATA table] Error["
							+ e.getMessage() + "]");
			logger.error("Exception inside insertion into VCC_OUT_DIAL_DATA"
					+ e.getMessage());
			e.printStackTrace();
			retVal = -1;// TODO: handle exception
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in insertOBDRequest() function] Error["
								+ e.getMessage() + "]");
				logger.error("Exception inside finally block of closing resources"
						+ e.getMessage());// TODO: handle exception
				retVal = -1;
			}
		}
		return retVal;
	}

	/**
	 * THIS FUNCTION CHECK MAIL BOX CAPACITY AND CHECK STATUS FOR DELETE ENTRY
	 * 
	 * @param dataObjectBean
	 *            :-THIS REFERS TO BEAN OBJECT OF RECEIVING DATA CLASS
	 * @param capacity
	 *            :- THIS REFERS TO TOTAL MAIL BOX CAPACITY
	 * @return TRUE FOR SUCCESS
	 */
	public boolean deleteOldFile(DataObjectBean dataObjectBean, int capacity) {
		logger.info("Inside deleteOldFile() msisdn ["
				+ dataObjectBean.getDestinationNumber() + "] service type ["
				+ dataObjectBean.getServiceType() + "] capacity [" + capacity
				+ "]");
		try {
			boolean status = false;
			ArrayList<DataObjectBean> vccMsgList = new ArrayList<DataObjectBean>();
			String mailBoxReject = VCCConfiguration.getInstance()
					.GetAppConfigParam("vms_mailbox_full_reject");
			getMailBoxByCallTime(vccMsgList,
					dataObjectBean.getDestinationNumber(),
					dataObjectBean.getServiceType());
			if (vccMsgList.size() == 0) {
				logger.debug("vcc_voice_msg not have any message for msisdn ["
						+ dataObjectBean.getDestinationNumber()
						+ "] and service Type ["
						+ dataObjectBean.getServiceType() + "]");
				return true;
			} else if (vccMsgList.size() != 0) {
				logger.info("VCC MSG LIST SIZE IS" + vccMsgList.size());
				if (vccMsgList.size() >= capacity) {
					if (mailBoxReject.equalsIgnoreCase("true")) {
						errorLogger
								.error("ErrorCode["
										+ Global.errorcode_pattern
										+ "00019] MSISDN["
										+ dataObjectBean.getDestinationNumber()
										+ "] ServiceType["
										+ dataObjectBean.getServiceType()
										+ "] [No Message is deleted from VCC_VOICE_MSG because VMS_MAILBOX_FULL_REJECT is set to TRUE]");

						logger.info("No message is deleted from vcc_voice Msg because vms_mailbox_full_reject is set to true");
						return true;
					} else if (mailBoxReject.equalsIgnoreCase("false")) {
						for (int i = 0; i < vccMsgList.size(); i++) {
							logger.info("status is ["
									+ vccMsgList.get(i).getStatus() + "]");
							if (vccMsgList.get(i).getStatus()
									.equalsIgnoreCase("R")) {
								status = deleteOldMsgByStatus(
										vccMsgList.get(i), "R");
								return status;
							} else if (vccMsgList.get(i).getStatus()
									.equalsIgnoreCase("N")) {
								status = deleteOldMsgByStatus(
										vccMsgList.get(i), "N");
								return status;
							} else if (vccMsgList.get(i).getStatus()
									.equalsIgnoreCase("S")) {
								status = deleteOldMsgByStatus(
										vccMsgList.get(i), "S");
								return status;
							}
						}

					}
				}
				status = true;
			}
			return status;
		} catch (Exception e) {
			errorLogger.error("ErrorCode[" + Global.errorcode_pattern
					+ "00020] MSISDN[" + dataObjectBean.getDestinationNumber()
					+ "] ServiceType[" + dataObjectBean.getServiceType()
					+ "] [Exception inside deleteOldFile() Function] Error["
					+ e.getMessage() + "]");

			logger.error("Exception inside deleteOldFile()" + e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * THIS FUNCTION DELETE RECORDS FROM VCC_VOICE_MSG IF MAILBOX IS FULL
	 * 
	 * @param dataObjectBean
	 *            :-THIS REFERS TO BEAN OBJECT OF RECEIVING DATA CLASS
	 * @return BOOLEAN VARIBALE TRUE FOR SUCCESS AND FALSE FOR FAILURE
	 */
	public boolean deleteOldMsgByStatus(DataObjectBean dataObjectBean,
			String messageStatus) {
		VccFileDeleteWriter vccFileDel = new VccFileDeleteWriter();
		logger.info("Inside deleteOldMsgByStatus() msisdn ["
				+ dataObjectBean.getDestinationNumber()
				+ "] and call time is [" + dataObjectBean.getCallTime()
				+ "] Message status [" + messageStatus + "]");
		String query = "";
		PreparedStatement pstmt = null;
		try {
			con = Global.conPool.getConnection();
			query = "delete from VCC_VOICE_MSG where DESTINATION_NUMBER=? and CALL_TIME=? and MESSAGE_STATUS=?";
			pstmt = con.prepareStatement(query);
			logger.info("query is [" + query + "]");
			pstmt.setString(1, dataObjectBean.getDestinationNumber());
			pstmt.setString(2, dataObjectBean.getCallTime());
			pstmt.setString(3, messageStatus);
			pstmt.executeUpdate();

			boolean status = vccFileDel.deletePhysicalFile(
					dataObjectBean.getFileName(),
					dataObjectBean.getDestinationNumber(),
					Global.ivrRecordBasePath);
			if (status) {
				logger.info("Record deleted successfully");
				return true;
			} else
				return false;
			
		} catch (SQLException se) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90001] Origination Number ["
							+ dataObjectBean.getOriginationNumber()
							+ "] Destination Number["
							+ dataObjectBean.getDestinationNumber()
							+ "] [SQLException while deleting from VCC_VOICE_MSG table] Error["
							+ se.getMessage() + "]");
			se.printStackTrace();
			return false;
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00021] Origination Number ["
							+ dataObjectBean.getOriginationNumber()
							+ "] Destination Number["
							+ dataObjectBean.getDestinationNumber()
							+ "] [Exception while deleting from VCC_VOICE_MSG table] Error["
							+ e.getMessage() + "]");
			logger.error("Exception inside deleteOldMsgByStatus()"
					+ e.getMessage());
			e.printStackTrace();
			return false;
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in deleteOldMsgByStatus() function] Error["
								+ e.getMessage() + "]");
				logger.error("Exception inside finally block of closing resources"
						+ e.getMessage());// TODO: handle exception
				return false;
			}
		}
	}

	/**
	 * THIS FUNCTION GET TOTAL NUMBER OF DETAILS ABOUT MAIL BOX FOR MSISDN
	 * 
	 * @param vccMsgList
	 *            :-THIS REFERS TO ARRAY LIST FOR REOED CUSTOMER MAIL BOX DETAIL
	 * @param msisdn
	 *            :- THIS REFERS TO USER's MSISDN
	 * @param serviceType
	 *            :- THIS REFERS TO SERVICE TYPE OF USER
	 */
	public void getMailBoxByCallTime(ArrayList<DataObjectBean> vccMsgList,
			String msisdn, String serviceType) {
		logger.info("Inside getMailBoxByCallTime() MSISDN [" + msisdn
				+ "] service Type [" + serviceType + "]");
		String query = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		DataObjectBean dataObjectBean = null;
		try {
			vccMsgList.clear();
			con = Global.conPool.getConnection();
			query="select MESSAGE_STATUS,ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_TIME,RETRIVAL_TIME,"
                    + "FILENAME,VOICE_MESSAGE_INDEX,RECORDING_DURATION,MSG_PROTECT,MSG_PRIORITY,PASS_PROTECTED,"
                    + "PASSWORD,ORIGINAL_NUMBER,LOCAL_MESSAGE_INDEX,SENDING_TIME,SERVICE_TYPE from VCC_VOICE_MSG "
                    + "where  DESTINATION_NUMBER=? and SERVICE_TYPE =? order by CALL_TIME";
			//query = "select * from VCC_VOICE_MSG where  DESTINATION_NUMBER=? and SERVICE_TYPE =? order by CALL_TIME";
			pstmt = con.prepareStatement(query);
			logger.debug("query is [" + query + "]");
			pstmt.setString(1, msisdn);
			pstmt.setString(2, serviceType);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				dataObjectBean = new DataObjectBean();
				dataObjectBean.setStatus(rs.getString("MESSAGE_STATUS"));
				dataObjectBean.setDestinationNumber(rs
						.getString("DESTINATION_NUMBER"));
				dataObjectBean.setServiceType(rs.getString("SERVICE_TYPE"));
				dataObjectBean.setCallTime(rs.getString("CALL_TIME"));
				dataObjectBean.setFileName(rs.getString("FILENAME"));
				dataObjectBean.setLocalMessageIndex(rs
						.getInt("LOCAL_MESSAGE_INDEX"));
				dataObjectBean.setVoiceMsgIndex(rs
						.getInt("VOICE_MESSAGE_INDEX"));
				dataObjectBean.setRecordDuration(rs
						.getString("RECORDING_DURATION"));
				vccMsgList.add(dataObjectBean);
			}
		} catch (SQLException se) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90001] Destination Number["
							+ msisdn
							+ "] [SQLException while getting data from VCC_VOICE_MSG table] Error["
							+ se.getMessage() + "]");
			se.printStackTrace();
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00022] Destination Number["
							+ msisdn
							+ "] [Exception while getting data from VCC_VOICE_MSG table] Error["
							+ e.getMessage() + "]");
			logger.error("Exception inside getMailBoxByCallTime()"
					+ e.getMessage());
			e.printStackTrace();

		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in getMailBoxByCallTime() function] Error["
								+ e.getMessage() + "]");
				logger.error("Exception inside finally block of closing resources"
						+ e.getMessage());// TODO: handle exception
			}
		}

	}

	public int getNotificationCount(String msisdn, String serviceType) {
		int totalCount = -1;
		logger.info("Inside getNotificationCount MSISDN [" + msisdn
				+ "] service Type [" + serviceType + "]");
		String query = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = Global.conPool.getConnection();
			query = "select count(*) as totalCount from VCC_VOICE_MSG where  DESTINATION_NUMBER=? and SERVICE_TYPE =? and MESSAGE_STATUS='N'";
			pstmt = con.prepareStatement(query);
			logger.debug("query is [" + query + "]");
			pstmt.setString(1, msisdn);
			pstmt.setString(2, serviceType);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				totalCount = rs.getInt("totalCount");
				rs.close();
				pstmt.close();
			}
			if (con != null)
				con.close();
			return totalCount;
		} catch (SQLException se) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90001] Destination Number["
							+ msisdn
							+ "] [SQLException while getting NotificationCount from VCC_VOICE_MSG table] Error["
							+ se.getMessage() + "]");
			se.printStackTrace();
			return totalCount;
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00023] Destination Number["
							+ msisdn
							+ "] [Exception while getting NotificationCount from  VCC_VOICE_MSG table] Error["
							+ e.getMessage() + "]");
			logger.error("Exception inside getNotificationCount()"
					+ e.getMessage());
			e.printStackTrace();
			return totalCount;

		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in getNotificationCount() function] Error["
								+ e.getMessage() + "]");
				logger.error("Exception inside finally block of closing resources"
						+ e.getMessage());// TODO: handle exception
				return -1;
			}
		}

	}

}
