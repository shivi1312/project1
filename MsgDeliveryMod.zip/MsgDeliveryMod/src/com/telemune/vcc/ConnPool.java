package com.telemune.vcc;

import java.sql.Connection;

import org.apache.log4j.Logger;

import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * THIS CLASS IS FOR HANDLING THE CONNECTION POOLING FOR VCC DELIVERY ENGINE
 * 
 * @author swati
 * @version R1_0_0_0
 */

public class ConnPool {
	Logger logger = Logger.getLogger("ConnPol");
	Logger errorLogger = Logger.getLogger("errorLogger");

	private ComboPooledDataSource cpds = new ComboPooledDataSource();

	String driver;
	String url;
	String username;
	String passwd;
	int minpoolsize;
	int maxpoolsize;
	int Accomodation;

	/**
	 * THIS IS THE PARAMETERIZED CONSTRUCTOR FOR CONPOOL CLASS
	 * 
	 * @param driver
	 *            :- REFER TO THE DRIVER OF DB
	 * @param url
	 *            :- REFER TO THE URL OF CONNECTING DB
	 * @param username
	 *            :- REFER TO THE DB USERNAME
	 * @param passwd
	 *            :-REFER TO THE DB PASSWORD
	 * @param minpoolsize
	 *            :- REFER TO THE MINMUM CONNECTION PRESENT IN THE CONNNECTION
	 *            POOL
	 * @param maxpoolsize
	 *            :- REFER TO THE MAXIMUM CONNECTION PRESENT IN THE CONNNECTION
	 *            POOL
	 * @param Accomodation
	 *            :-Determines how many connections at a time c3p0 will try to
	 *            acquire when the pool is exhausted
	 */
	public ConnPool(String driver, String url, String username, String passwd,
			int minpoolsize, int maxpoolsize, int Accomodation) {
		this.driver = driver;
		this.url = url;
		this.username = username;
		this.passwd = passwd;
		this.minpoolsize = minpoolsize;
		this.maxpoolsize = maxpoolsize;
		this.Accomodation = Accomodation;

	}

	/**
	 * THIS FUNCTION IS FOR SETTING UP THE INITAIL CONFIGUARTION OF CONNECTION
	 * POOL IN ComboPooledDataSource
	 */
	public void MakePool() {
		try {
			// cpds=new ComboPooledDataSource();
			cpds.setDriverClass(driver);
			cpds.setJdbcUrl(url);
			cpds.setUser(username);
			cpds.setPassword(passwd);
			cpds.setMaxPoolSize(maxpoolsize);
			cpds.setMinPoolSize(minpoolsize);
			cpds.setAcquireIncrement(Accomodation);
			cpds.setMaxStatements(0);
		
			//cpds.setMaxStatementsPerConnection(25);
			//cpds.setMaxStatementsPerConnection(25);
			
		} catch (Exception ex) {
			errorLogger.error("ErrorCode[" + Global.errorcode_pattern
					+ "00010] [Exception in Making ConnectionPool] Error["
					+ ex.getMessage() + "]");
			// handle exception...not important.....
			logger.error("Exception in MakePool()..........", ex);
		}

	}

	/**
	 * THIS FUNCTION IS FOR GETTING THE CONNECTION FROM THE
	 * ComboPooledDataSource OBJECT
	 * 
	 * @return DATABASE CONNECTION OBJECT
	 */

	public synchronized Connection getConnection() {
		Connection con = null;
		try {
			con = cpds.getConnection();
			con.setReadOnly(false);
			// logger.info("getting the connection con......."+con);
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00011] [Exception in getting database Connection] Error["
							+ e.getMessage() + "]");
			logger.info("Exception in cpds........", e);
			e.printStackTrace();
		}
		return con;
	}
}
