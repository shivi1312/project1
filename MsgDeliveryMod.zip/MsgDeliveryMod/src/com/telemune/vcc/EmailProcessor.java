package com.telemune.vcc;

import org.apache.log4j.Logger;
import commonutil.*;

/**
 * THIS CLASS IS FOR SEND EMAIL INFORMATION TO EMAIL MODULE
 * 
 * @author swati
 * 
 */

public class EmailProcessor implements Runnable {
	static Logger logger = Logger.getLogger(EmailProcessor.class);
	public DataObjectBean dataObjectBean = null;

	public DBHandler dbHandler = null;

	/**
	 * THIS IS THE RUN METHOD OF THIS THREAD
	 */
	public void run() {
		while (true) {
			if (Global.emailProcessorQueue.isEmpty()) {
				try {
					logger.debug("Email Process queue is empty");
					Thread.sleep(1000);
				} catch (Exception e) {
					logger.error("Excption inside emailProcessor class when thread is going to sleep"
							+ e.getMessage()); // TODO: handle exception
				}
			} else {
				dbHandler = new DBHandler();
				try {
					dataObjectBean = Global.emailProcessorQueue.poll();

					int status = sendEmailAPP(dataObjectBean
							.getLocalMessageIndex());
					if (status < 0) {
						logger.info("There is any error when getting response for Email application");
					} else {
						dbHandler.updateDeliveryStatus(
								dataObjectBean.getLocalMessageIndex(), "D", -1);
					}
				} catch (Exception e) {
					logger.error("Exception inside emailprocessor() class"); // TODO:
																				// handle
																				// exception
				}
			}
		}
	}

	/**
	 * THIS FUNCTION IS FOR SENDING REQUEST TO EMAIL MODULE AND GET RESPONSE
	 * FROM THEM
	 * 
	 * @param localIndex
	 *            :- THIS IS THE UNIQUE ID IN VCC_NOTIFICATION TABLE
	 * @return 1 FOR SUCCESS
	 */
	public int sendEmailAPP(int localIndex) {
		TLVAppInterface tlvInterface = null;
		try {
			logger.info("Inside function sendEmailAPP() LOCAL_MESSAGE_INDEX ["
					+ localIndex + "] ip is [" + Global.EMAILAPPIP + "] port ["
					+ Global.EMAILPORT + "]");
			String err = null;
			String serverIp = Global.EMAILAPPIP;
			int serverPort = Global.EMAILPORT;

			tlvInterface = new TLVAppInterface();
			tlvInterface.setData(Global.LOCALINDEX, localIndex);
			tlvInterface.encode();
			tlvInterface.setServerIP(serverIp);
			tlvInterface.setServerPort(serverPort);
			tlvInterface.send();
			int receive = tlvInterface.receive();
			if (receive < 0) {
				logger.info("Error in getting Email request execution");
				return -1;
			}
			err = tlvInterface.getData(Global.RESPONSE_TAG);
			if (Integer.parseInt("err") == 1) {
				logger.info("Response get successfully");
				return 1;
			} else {
				logger.info("Error in getting response");
				return -1;
			}

		}

		catch (Exception e) {
			logger.error("Exception inside sendEmailAPP()" + e.getMessage());
			return -1;// TODO: handle exception
		} finally {
			if (tlvInterface != null)
				tlvInterface.close();
		}
	}

}
