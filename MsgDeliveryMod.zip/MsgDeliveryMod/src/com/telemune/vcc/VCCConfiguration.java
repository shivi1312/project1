package com.telemune.vcc;

import org.apache.log4j.*;

import com.mysql.jdbc.V1toV2StatementInterceptorAdapter;

import java.io.*;
import java.sql.*;
import java.util.*;

/**
 * THIS CLASS IS FOR LOADING ALL CONFIGURATION AND CACHE RELOADING
 * 
 * @author swati
 * 
 */
public class VCCConfiguration {
	static final Logger logger = Logger.getLogger(VCCConfiguration.class);
	static Logger errorLogger = Logger.getLogger("errorLogger");
	private static VCCConfiguration instance_ = null;
	private static Hashtable<String, String> app_config_params = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	Connection con = null;
	private static Hashtable<String, String> TemplateDetails = null;
	private static Map<Integer, Integer> mailBoxDetail = null;
	private static Map<Integer, Integer> ratePlanDetail = null;

	/**
	 * THIS FUNCTION IS FOR GETTING INSTANCE VALUE
	 * 
	 * @return
	 */
	public static synchronized VCCConfiguration getInstance() {
		if (instance_ == null) {
			logger.info("First Time VCC object is created ");
			instance_ = new VCCConfiguration();
		}
		return instance_;
	}

	/**
	 * THIS FUNCTION IS FOR CACHE RELOADING
	 * 
	 * @return 1 FOR SUCCESS
	 */
	public int reLoad() {
		try {
			loadAppConfigParams();
			loadSMSTemplates();
			loadMailBox();
			loadMailBoxId();

		} catch (Exception exp) {
			logger.error("Error during reloading propertyFile ", exp);
			return -1;
		}

		logger.info("Cache Reloaded Successfully ");
		return 1;
	}

	/**
	 * THIS FUNCTION IS FOR LOADING ALL CONFIGURAION
	 */

	private VCCConfiguration() {
		try {
			logger.info("Inside VCCConfiguration()...");
			loadAppConfigParams();
			loadSMSTemplates();
			loadMailBox();
			loadMailBoxId();

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error In VCCConfiguration()" + e.getMessage());
		}

	}

	/**
	 * THIS FUNCTION IS FOR GETTING PARAMETER FROM APP CONFIG TABLE
	 * 
	 * @param paramTag
	 *            :- PARAM TAG
	 * @return PARAM VALUE OF REQUESTED TAG
	 */
	public String GetAppConfigParam(String paramTag) {

		String _pname = paramTag.trim();
		_pname = _pname.toUpperCase();

		if (app_config_params.containsKey(_pname)) {

			return app_config_params.get(_pname);
		} else
			return null;
	}

	/**
	 * THIS FUNCTION IS FOR LOAD ALL APP CONFIG PARAM TAGS AND VALUES
	 * 
	 * @return 1 FOR SUCCESS CASE
	 */
	private int loadAppConfigParams() {
		logger.debug("in LoadAppConfigParams()");
		try {
			con = Global.conPool.getConnection();
			String query = "select PARAM_NAME,PARAM_VALUE from APP_CONFIG_PARAMS";
			logger.info("query is [ " + query + " ]");
			app_config_params = new Hashtable<String, String>();
			app_config_params.clear();
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				try {
					app_config_params.put(rs.getString("PARAM_NAME")
							.toUpperCase().trim(), rs.getString("PARAM_VALUE"));
				} catch (NullPointerException e) {
					errorLogger
							.error("ErrorCode["
									+ Global.errorcode_pattern
									+ "90003] [NullPointerException in loading app_config_params] Error["
									+ e.getMessage() + "]");
				} catch (Exception e) {
					errorLogger
							.error("ErrorCode["
									+ Global.errorcode_pattern
									+ "00037] [Exception in loading app_config_params] Error["
									+ e.getMessage() + "]");
				}

			}
			// rs.close();

		} catch (SQLException exp1) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90001] [SQLException in loading app_config_params] Error["
							+ exp1.getMessage() + "]");
			exp1.printStackTrace();

			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
			} catch (Exception exp2) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in loadAppConfigParams()] Error["
								+ exp2.getMessage() + "]");
				exp2.printStackTrace();
				return -1;
			}
			return -1;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
				if (pstmt != null)
					pstmt.close();
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in loadAppConfigParams()] Error["
								+ e.getMessage() + "]");

				logger.info("Exception inside finally block of closing resources"
						+ e.getMessage());
			}
		}

		return 1;

	}

	/**
	 * THIS FUNCTION IS FOR LOAD ALL TEMPLATES FROM LBS_TEMPLATES TABLE
	 * 
	 * @return 1 FOR SUCCESS
	 */
	private int loadSMSTemplates() {
		logger.info("in LoadSMSTemplates()");
		try {
			String key = "";
			con = Global.conPool.getConnection();
			String query = "select TEMPLATE_ID,TEMPLATE_MESSAGE,LANGUAGE_ID from LBS_TEMPLATES";
			logger.info("query is [ " + query + " ]");
			TemplateDetails = new Hashtable<String, String>();
			TemplateDetails.clear();
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			while (rs.next()) {

				key = rs.getInt("TEMPLATE_ID") + "-" + rs.getInt("LANGUAGE_ID");
				TemplateDetails.put(key, rs.getString("TEMPLATE_MESSAGE"));

			}
			// rs.close();

		} catch (SQLException exp1) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90001] [SQLException in loading data from LBS_TEMPLATES] Error["
							+ exp1.getMessage() + "]");
			exp1.printStackTrace();

			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
				if (pstmt != null)
					pstmt.close();

			} catch (Exception exp2) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in loadSMSTemplates()] Error["
								+ exp2.getMessage() + "]");

				exp2.printStackTrace();
				return -1;
			}
			return -1;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
				if (pstmt != null)
					pstmt.close();
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in loadSMSTemplates()] Error["
								+ e.getMessage() + "]");
				logger.info("Exception inside finally block" + e.getMessage());
			}
		}

		return 1;

	}

	/**
	 * THIS FUNCTION IS FOR GETTING TEMPLATES
	 * 
	 * @param key
	 *            :- THIS IS UNIQUE VALUE
	 * @return TEMPLATE MESSAGE OF THAT KEY
	 */
	public String getTemplate(String key) {
		if (TemplateDetails.containsKey(key)) {

			return TemplateDetails.get(key);
		}

		else {
			return null;
		}

	}

	private int loadMailBox() {
		logger.debug("Inside loadMailBox()");
		try {
			con = Global.conPool.getConnection();
			String query = "select MAILBOX_ID,MAX_MESSAGES from vcc_mailbox_params";
			mailBoxDetail = new HashMap<Integer, Integer>();
			mailBoxDetail.clear();
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			while (rs.next())
				mailBoxDetail.put(rs.getInt("MAILBOX_ID"),
						rs.getInt("MAX_MESSAGES"));

		} catch (SQLException exp1) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90001] [SQLException in loading data from vcc_mailbox_params] Error["
							+ exp1.getMessage() + "]");
			// logger.info("Exception inside loadMailBoxDetail()" +
			// exp1.getMessage());
			exp1.printStackTrace();
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
				if (pstmt != null)
					pstmt.close();
			} catch (Exception exp2) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in loadMailBox()] Error["
								+ exp2.getMessage() + "]");

				exp2.printStackTrace();
				return -1;
			}
			return -1;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
				if (pstmt != null)
					pstmt.close();
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in loadMailBox()] Error["
								+ e.getMessage() + "]");

				// logger.info("Exception inside finally block" +
				// e.getMessage());
			}
		}
		return 1;

	}

	/**
	 * THIS FUNCTION IS FOR GETTING MAX MAIL BOX MESSAGE
	 * 
	 * @param key
	 *            :- THIS IS UNIQUE VALUE
	 * @return MAX MESSAGE OF THAT KEY
	 */
	public int getMaxMessage(int key) {
		if (mailBoxDetail.containsKey(key)) {

			return mailBoxDetail.get(key);
		}

		else {
			return -1;
		}

	}

	private int loadMailBoxId() {
		logger.debug("Inside loadRatePlan()");
		try {
			con = Global.conPool.getConnection();
			String query = "select PLAN_ID,MAILBOX_ID from VCC_RATE_PLAN";
			ratePlanDetail = new HashMap<Integer, Integer>();
			ratePlanDetail.clear();
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			while (rs.next())
				ratePlanDetail.put(rs.getInt("PLAN_ID"),
						rs.getInt("MAILBOX_ID"));

		} catch (SQLException exp1) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90001] [SQLException in loading data from VCC_RATE_PLAN] Error["
							+ exp1.getMessage() + "]");
			logger.info("Exception inside loadRatePlan()" + exp1.getMessage());
			exp1.printStackTrace();
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
				if (pstmt != null)
					pstmt.close();
			} catch (Exception exp2) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in loadMailBoxId()] Error["
								+ exp2.getMessage() + "]");
				exp2.printStackTrace();
				return -1;
			}
			return -1;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
				if (pstmt != null)
					pstmt.close();
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in loadMailBoxId()] Error["
								+ e.getMessage() + "]");

				logger.info("Exception inside finally block" + e.getMessage());
			}
		}
		return 1;

	}

	/**
	 * THIS FUNCTION IS FOR GETTING MailBoxId
	 * 
	 * @param key
	 *            :- THIS IS UNIQUE RATE PLAN ID
	 * @return RATE PLNA NAME OF THAT Key
	 */
	public int getMailBoxId(int key) {
		if (ratePlanDetail.containsKey(key)) {

			return ratePlanDetail.get(key);
		}

		else {
			return -1;
		}

	}

}// class
