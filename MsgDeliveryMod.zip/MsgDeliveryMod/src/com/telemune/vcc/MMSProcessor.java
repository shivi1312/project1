package com.telemune.vcc;

import java.net.Socket;
import java.sql.Connection;

import org.apache.log4j.Logger;
import commonutil.*;

/**
 * THIS CLASS IS FOR HANDLING DATA TO AND FROM MMS MODULE
 * 
 * @author swati
 * 
 */

public class MMSProcessor implements Runnable {
	static Logger logger = Logger.getLogger(MMSProcessor.class);
	public DataObjectBean dataObjectBean = null;
	Connection con = Global.conPool.getConnection();
	public DBHandler dbHandler = null;

	/**
	 * THIS IS THE RUN METHOD OF THIS THREAD
	 */
	public void run() {
		while (true) {
			if (Global.mmsProcessorQueue.isEmpty()) {
				try {
					logger.debug("MMS Process queue is empty");
					Thread.sleep(1000);
				} catch (Exception e) {
					logger.error("Excption inside MMS Process class run()"
							+ e.getMessage()); // TODO: handle exception
				}
			} else {
				dbHandler = new DBHandler();
				try {
					dataObjectBean = Global.mmsProcessorQueue.poll();
					int status = sendMMSAPP(dataObjectBean
							.getLocalMessageIndex());
					// int status=1;
					if (status < 0) {
						logger.info("There is any error when getting response for MMS application");
					} else {
						dbHandler.updateDeliveryStatus(
								dataObjectBean.getLocalMessageIndex(), "D",
								status);
					}
				} catch (Exception e) {
					logger.error("Exception inside MMSProcessor class"
							+ e.getMessage()); // TODO: handle exception
				}
			}
		}
	}

	/**
	 * THIS FUNCTION IS FOR SEND REQUEST TO MMS MODULE AND RECEIVE RESPONSE
	 * 
	 * @param localIndex
	 *            :- THIS IS THE UNIQUE ID IN VCC_NOTIFICATION TABLE
	 * @return TRANASACTION ID RECEIVED FROM MMS MODULE
	 */
	public int sendMMSAPP(int localIndex) {
		TLVAppInterface tlvInterface = null;
		try {
			logger.info("Inside function sendMMSAPP() LOCAL_MESSAGE_INDEX ["
					+ localIndex + "] ip is [" + Global.MMSAPPIP + "] port ["
					+ Global.MMSPORT + "]");
			String err = null;
			int newTransactionID = -1;
			String serverIp = Global.MMSAPPIP;
			int serverPort = Global.MMSPORT;

			tlvInterface = new TLVAppInterface();
			tlvInterface.setServerIP(serverIp);
			tlvInterface.setServerPort(serverPort);

			tlvInterface.setData(Global.LOCALINDEX, localIndex);

			tlvInterface.encode();

			tlvInterface.send();
			int receive = tlvInterface.receive();
			if (receive < 0) {
				logger.info("Error in getting MMS request execution");
				return -1;
			}
			err = tlvInterface.getData(Global.RESPONSE_TAG);
			newTransactionID = Integer.parseInt(tlvInterface
					.getData(Global.TRANACTIONID));
			if (Integer.parseInt("err") == 1) {
				logger.info("TranactionID get successfully");
				return newTransactionID;
			} else {
				logger.info("Error in getting Response");
				return -1;
			}

		}

		catch (Exception e) {
			logger.error("Exception inside sendMMSAPP()" + e.getMessage());
			return -1;// TODO: handle exception
		} finally {
			if (tlvInterface != null)
				tlvInterface.close();
		}
	}

}
