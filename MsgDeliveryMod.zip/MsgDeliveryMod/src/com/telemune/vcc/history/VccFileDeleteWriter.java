package com.telemune.vcc.history;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.telemune.vcc.Global;
import com.telemune.vcc.VCCConfiguration;

public class VccFileDeleteWriter {
	private final static Logger logger = Logger
			.getLogger(VccFileDeleteWriter.class);
	 public Boolean deletePhysicalFile(String recordingFileName, String msisdn,
              String bashPath) {

     msisdn = this.msisdnWithoutCountryCode(msisdn);
     String recordFilePath = null;
     String tempName = null;
     String calledNum = null;

             tempName = recordingFileName.substring(0,
                             recordingFileName.length() - Global.defaultRecordDigit);
             calledNum = msisdn;

             recordFilePath = getCopletePath(tempName, calledNum,
                             recordingFileName, bashPath);
             //logger.info("record file path [" + recordFilePath + "]");
             logger.info(recordFilePath);
             if(recordFilePath==null)
             return false;
             else
            	 return true;
	 }
	 
	 public String getCopletePath(String startEightDigits, String calledNum,
             String recordFileName, String basePath) {
     calledNum = this.msisdnWithoutCountryCode(calledNum);
     StringBuilder filepathBuilder = new StringBuilder();
     filepathBuilder.append(startEightDigits.substring(0,
                     startEightDigits.length() - 6));
     filepathBuilder.append("/");
     filepathBuilder.append(startEightDigits.substring(
                     startEightDigits.length() - 6, startEightDigits.length() - 4));
     filepathBuilder.append("/");
     filepathBuilder.append(startEightDigits.substring(
                     startEightDigits.length() - 4, startEightDigits.length()-2));
     filepathBuilder.append("/");
     filepathBuilder.append(startEightDigits.substring(
                     startEightDigits.length() - 2, startEightDigits.length()));

     //logger.debug("file path ["+filepathBuilder.toString()+"]");
     try {
             DateFormat srcDf = new SimpleDateFormat("yy/MM/dd/HH");
             String myDate = String.valueOf(filepathBuilder);
             Date date = srcDf.parse(myDate);
             DateFormat destDf = new SimpleDateFormat("yyyy/MM/dd/HH");
             myDate = destDf.format(date);
             myDate = myDate.replace("/", File.separator);
             filepathBuilder = new StringBuilder();
             filepathBuilder.append(basePath);
             filepathBuilder.append(File.separator);
             filepathBuilder.append(myDate);
             filepathBuilder.append(File.separator);
             filepathBuilder.append(calledNum.substring(0, 3));
             filepathBuilder.append(File.separator);
             filepathBuilder.append(calledNum.substring(3, 6));
             filepathBuilder.append(File.separator);
             filepathBuilder.append(calledNum.substring(6, 9));
             filepathBuilder.append(File.separator);
             if (recordFileName != null) {
                     filepathBuilder.append(recordFileName);
                     filepathBuilder.append(".wav");
             }
     } catch (Exception e) {
         System.out.println("error in geeting record file path ["+e+"]");

         return null;
 }

 return filepathBuilder.toString();
}
	 public String msisdnWithoutCountryCode(String msisdn) {
		 String countryCode=VCCConfiguration.getInstance().GetAppConfigParam("COUNTRY_CODE");
		 int countryCodeLength=countryCode.length();
		 if(msisdn.startsWith(countryCode))
		 {
			 msisdn=msisdn.substring(countryCodeLength,msisdn.length());
			// logger.info("msisdn is ["+msisdn+"]");
		 }
		 
		 return msisdn;
         
	 }
	 
            
}
