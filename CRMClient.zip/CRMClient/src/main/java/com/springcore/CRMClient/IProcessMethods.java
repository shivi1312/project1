package com.springcore.CRMClient;

public interface IProcessMethods {
	
	public String createProfile()

}
