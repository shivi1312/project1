package com.telemune.hlr;

import java.io.DataInputStream;
import java.io.ObjectInputStream.GetField;
import java.net.Socket;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.hlr.backend.DataObject;

/**
 * This thread read data from particular socket reference by two ways 
 * according to simple read from socket plain text
 * according to json read json 
 * @author Harjinder 
 * */
public class RequestReader implements Runnable{

	static final Logger logger=Logger.getLogger(RequestReader.class);
	String name;
	Thread thrd;
	Socket socket_me;
	DataInputStream reader = null;
	int connectionTimeOut = 10;
	
	/**
	 * It is a parameterized constructor
	 * @param name
	 * @param socket
	 * @param connectionTimeOut
	 * */
	RequestReader(String name,Socket socket,int connectionTimeOut)
	{
		thrd = new Thread(name);
		this.name = name;
		socket_me = socket;
		this.connectionTimeOut = connectionTimeOut;
		logger.info("\nstarted thread to recv data: #" + name );
		//thrd.start();
	}
	
	/**
	 * This is run method provided by Runnnable interface
	 * according to configuration parameter it call reading method 
	 * getNewClient as simple text
	 * getNewClientJson as a JSON
	 * */
	public void run()
	{
		logger.info("##>>RequestReader Thread STARTED...");
		if(Global.REQUEST_JSON_ENABLE == 1)
		{
			getNewClientJson(socket_me , connectionTimeOut);
		}
		else
		{
			getNewClient(socket_me , connectionTimeOut);
		}
		
	}
	public void stop()
	{

	}
	
	/**
	 * This method read data from {@link Socket}  
	 * @param socket
	 * @param connectionTimeOut
	 * @return void
	 * */
	public void getNewClient(Socket socket,int connectionTimeOut) 
	{
		logger.debug("\nPreparing to receive data from client.....");
		try {
			DataObject bean = null;
//			while(true) // commented by Avishkar on 11-11-2020
//			{
			if (socket.isClosed()) {
				logger.debug("Socket is closed");
				return;
			}
			/*
			 * handle the close condition on readInt
			 */
			this.reader = new DataInputStream(socket.getInputStream());
			int dataLen = reader.readInt();
			byte responseBuf[] = new byte[dataLen];
			if(reader.read(responseBuf, 0, dataLen) == -1)
			{
				  try
                  {
                          socket.close();
                          logger.info("Destroy");
                          logger.info("socket closed");
                          return;
                  }
                  catch(Exception e)
                  {
                          logger.info(e);
                  }

			}
			else
			{	

			String response = new String(responseBuf);
			StringTokenizer st = new StringTokenizer(response);
			String[] tokens = new String[st.countTokens()];
			int ctr = 0;
			while (st.hasMoreTokens()) {
				tokens[ctr] = st.nextToken();
				logger.info("Token received [" + tokens[ctr] + "]");
				ctr++;
			}
			if (tokens.length > 2) {
				bean = new DataObject();
				bean.setReqType(Integer.parseInt(tokens[1]));
				bean.setMsisdn(tokens[2]);
				bean.setSock(socket);
				bean.setConTimeout(connectionTimeOut);
				bean.setReqId(1);
				bean.setMsrn("NULL");
				bean.setMscNo("NULL");
				bean.setImsi("NULL");
				bean.setScfAddr("NULL");
				bean.setServiceKey(0);
				bean.setIsPrePaidId("N");
				bean.setIsRoaming("N");
				bean.setResponse("");
				bean.setBusyNo("NULL");
				bean.setNoReachNo("NULL");
				bean.setNoReply("NULL");
				bean.setIsCFU("N");
				bean.setCFU("NULL");
				logger.info("Received DataObject [\n"+bean+"\n]");
				Global.req_queue.put(bean);
				
				
				
			}
			else
			{
				logger.error("Tokens received less than 2, 3 parameters should be received from Rule Engine");
			}
			logger.debug("reading Info......data len.." + dataLen);
			}
//			}
		}catch(java.io.EOFException eofexp)
		{
			
			 try
             {
                     socket.close();
                     logger.info("Destroy");
                     logger.info("socket closed");
                     return;
             }
             catch(Exception e)
             {
                     logger.info(e);
             }
			logger.fatal("Problem while receiving new request",eofexp);
			eofexp.printStackTrace();
			
		}
		catch (Exception e) {
			logger.fatal("Problem while receiving new request",e);
			e.printStackTrace();
		}
	}
	
	/**
	 * This method read data fro {@link Socket} as JSON
	 * @param socket
	 * @param connectionTimeOut
	 * @return void
	 * */
	public void getNewClientJson(Socket socket,int connectionTimeOut) 
	{
		logger.debug("\nPreparing to receive data from client.....");
		try {
			DataObject bean = null;
//			while(true) // commented by Avishkar on 11-11-2020
//			{
			if (socket.isClosed()) {
				logger.debug("Socket is closed");
				return;
			}
			this.reader = new DataInputStream(socket.getInputStream());
			int dataLen = reader.readInt();
			byte responseBuf[] = new byte[dataLen];
			if(reader.read(responseBuf, 0, dataLen) == -1)
			{
				  try
                  {
                          socket.close();
                          logger.info("Destroy");
                          logger.info("socket closed");
                          return;
                  }
                  catch(Exception e)
                  {
                          logger.info(e);
                  }
			}
			else
			{	
			String response = new String(responseBuf);
			if(response.length()>7)
			{
			Gson gson = new Gson();
			bean = gson.fromJson(response,DataObject.class);
			bean.setSock(socket);
			logger.info("Received DataObject [\n"+bean+"\n]");
			Global.req_queue.put(bean);
			}
			else {
				logger.info("##>>> proper data not found ....");
			}
			
			logger.debug("reading Info......data len.." + dataLen);
			}
//			}
		}catch(java.io.EOFException eofexp)
		{
			
			 try
             {
                     socket.close();
                     logger.info("Destroy");
                     logger.info("socket closed");
                     return;
             }
             catch(Exception e)
             {
                     logger.info(e);
             }
			logger.fatal("Problem while receiving new request",eofexp);
			eofexp.printStackTrace();
			
		}
		catch (Exception e) {
			logger.fatal("Problem while receiving new request",e);
			e.printStackTrace();
		}
	}
	
}
