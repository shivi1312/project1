package com.telemune.hlr;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.db.DBQuery;
import com.telemune.hlr.backend.DataObject;

/**
 * This thread read data from CRBT_SUBSCRIBER_MASTER and put into request queue.
 * @author Harjinder 
 * */
public class SetSubType implements Runnable{
	private Logger logger = Logger.getLogger(SetSubType.class);
	private ArrayList<DataObject> pendingList = new ArrayList<DataObject>();
	
	/**
	 * This is run method provided by Runnable interface 
	 * This method provide the logic to read data from CRBT_SUBSCRIBER_MASTER
	 * put data into request queue
	 * Goto  sleep for some time
	 * @return void
	 * */
	public void run() {
		logger.debug("##>>SetSubType Thread STARTED...");
		while(true)
		{
		try
		{
		if(Global.SetSubTypeCounter != 0)
		{
			logger.debug("##>>SetSubType Thread is going to SLEEP...");
			Thread.sleep(1);
		}
		else
		{	
		logger.debug("##>>> Inside SetSubType ...setSubTypeCounter size["+Global.SetSubTypeCounter+"]");
		pendingList.clear();
		getSubTypeData(pendingList); //getting data from CRBT_HLR_INACTIVE
		if(pendingList.size() > 0)
		{
			logger.info("##>> Now going to insert all pending request into req queue...");
			for(DataObject dataObject : pendingList)
			{
				Global.req_queue.put(dataObject); //putting into request queue
			}
		}
		
		logger.debug("##>>SetSubType Thread is going to SLEEP...");
		Thread.sleep(1000*Global.READ_SETSUB_TYPE_SLP_TIME);
		}
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		}
	}
	
	/**
	 * This method read data from CRBT_SUBCRIBER_MASTER 
	 * @param penArrayList
	 * @return void
	 * */
	private void getSubTypeData(ArrayList<DataObject> penArrayList)
	{
		logger.info("##>Inside getSubTypeData .............");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;
		Connection con = null;
		int tempCounter = 0;
		try
		{
			con = Global.conPool.getConnection();
			//query = "select MSISDN from "+Global.READ_SET_SUB_TYPE_TABLE_NAME+" where SUB_TYPE!='P' and SUB_TYPE!='O' and rownum<="+Global.ROW_NUM; // Commented by Avishkar on 22.04.2019
		// addition start by Avishkar on 17/9/2020	
			if (Global.MULTIPLE_TABLE_SUBSCRIPTION_CHECK==1) {
				for (int i = 0; i <= 9; i++) {
					String tableNameSub=Global.READ_SET_SUB_TYPE_TABLE_NAME+"_"+i;
					query = DBQuery.fetchSubTypeData.replace("${Global.READ_SET_SUB_TYPE_TABLE_NAME}", tableNameSub);
					pstmt = con.prepareStatement(query,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					pstmt.setInt(1, Global.ROW_NUM); // Added by Avishkar on 22.04.2019
					rs = pstmt.executeQuery();
					rs.last();
//					Global.SetSubTypeCounter =  rs.getRow();
					tempCounter = tempCounter + rs.getRow();
					rs.beforeFirst();
					while(rs.next())
					{
						DataObject dataObject = new DataObject();
						dataObject.setMsisdn(rs.getString("MSISDN"));
						dataObject.setReqType(6);
						dataObject.setHlrReqId(-22); //setSubType
						penArrayList.add(dataObject);
					}
					logger.info("##>> READ_SET_SUB_TYPE_TABLE_NAME :["+tableNameSub+"] Count_of_total_rows_fetched ["+tempCounter+"]");
				}
			} else {
				query = DBQuery.fetchSubTypeData.replace("${Global.READ_SET_SUB_TYPE_TABLE_NAME}", Global.READ_SET_SUB_TYPE_TABLE_NAME); // Modified by Avishkar on 22.04.2019
				pstmt = con.prepareStatement(query,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				pstmt.setInt(1, Global.ROW_NUM); // Added by Avishkar on 22.04.2019
				rs = pstmt.executeQuery();
				rs.last();
				tempCounter = tempCounter + rs.getRow();
				rs.beforeFirst();
				while(rs.next())
				{
					DataObject dataObject = new DataObject();
					dataObject.setMsisdn(rs.getString("MSISDN"));
					dataObject.setReqType(6);
					dataObject.setHlrReqId(-22); //setSubType
					penArrayList.add(dataObject);
				}
			}
			
//			Global.SetSubTypeCounter =  rs.getRow();
			Global.SetSubTypeCounter = tempCounter;
		// addition end by Avishkar on 17/9/2020
			
		logger.info("##>>Inside getSubTypeData pending list size["+penArrayList.size()+"] setsubTypeCounter size["+Global.SetSubTypeCounter+"]");	
		}
		catch(SQLException sqlexp)
		{
			sqlexp.printStackTrace();
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		finally{
			try
			{
				if(con != null){con.close();}
				if(pstmt != null){pstmt.close();}
				if(rs != null){rs.close();}
			}
			catch(SQLException sqlexp)
			{
				sqlexp.printStackTrace();
			}
		}
	}

	

}
