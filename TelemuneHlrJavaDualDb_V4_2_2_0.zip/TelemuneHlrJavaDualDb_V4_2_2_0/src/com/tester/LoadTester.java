package com.tester;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.telemune.hlr.RejectedWork;

public class LoadTester {
	static String MSRN_FETCH_HOST = "10.168.3.75";
	static short MSRN_FETCH_PORT = 1111;
	final static int SERVICE_NORMAL_MSRN = 1;
	final static int SERVICE_INTERROGATE_MSRN = 15;
	final static int SERVICE_FORWARDING_INFO = 2;
	final static int SERVICE_ACTIVATE_SS = 3;
	final static int SERVICE_DEACTIVATE_SS = 4;
	final static int SERVICE_MSRN_NO_FORWARD = 5;
	final static int SERVICE_SRI = 6;
	final static int SERVICE_DUMMY_LOCUPD = 7;
	final static int SERVICE_DEACTIVATE_IMSI = 12;
	final static int SERVICE_ACTIVATE_IMSI = 13;
	final static int SERVICE_RETRIEVE_IMSI = 9;
	

        private static Logger logger=Logger.getLogger(LoadTester.class);

	public static int fetchmsrn(int service, String msisdn, StringBuffer  msrnBuf, String mscNo, StringBuffer imsiBuf, String scfAddress, Integer serviceKey, Boolean isroaming, Boolean isprepaid, Integer error, String busyNumber, String noReplyNumber, String unreachableNumber, Boolean cfuActive, StringBuffer cfuActiveStr)
	{
                int retVal = -1;
		Properties properties = null;
		FileInputStream fis1 = null;
		logger.info("in fetchmsrn'"+msisdn+"'");
		Socket socket = null;
		DataOutputStream writer = null;
		DataInputStream reader = null;
                int result = -1;
		logger.info("MSRN_FETCH_HOST= "+MSRN_FETCH_HOST+" MSRN_FETCH_PORT= "+MSRN_FETCH_PORT);
		try
		{
			socket = new Socket (MSRN_FETCH_HOST,MSRN_FETCH_PORT);
		}
		catch (SocketException se)
		{
			logger.error("Error in opening socket\n");
			se.printStackTrace();
			return -1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return -1;
		}
		logger.debug("Socket Connection established");

		String requestBuffer = "";
		int requestId = 1;

		requestBuffer = requestBuffer + requestId + "\n" + service;	
		String msrn = "";
		String imsi = "";
		String forwardNumber = "";


		switch(service)
		{
			case SERVICE_NORMAL_MSRN:    // request for normal msrn query...
			case SERVICE_INTERROGATE_MSRN:    // request for normal msrn query...
			case SERVICE_ACTIVATE_SS:		//	request for activate SS
			case SERVICE_DEACTIVATE_SS:		// request for deativate SS
			case SERVICE_RETRIEVE_IMSI:		// request for deativate SS
			case SERVICE_MSRN_NO_FORWARD:		//	request for msrn without forwarded info
			case SERVICE_SRI:		//	request for SRI..( to check prepaid)
				if (msisdn == null)
				{
					msisdn = "";
				}
				requestBuffer = requestBuffer + "\n" + msisdn;
				break;
			case SERVICE_FORWARDING_INFO:		//	request for update location...
			case SERVICE_DEACTIVATE_IMSI:
			case SERVICE_ACTIVATE_IMSI:
				if (msisdn == null)
				{
					msisdn = "";
				}
				if (mscNo == null)
				{
					mscNo = "";
				}
				if (imsi == null)
				{
					imsi = "";
				}
				requestBuffer = requestBuffer + "\n" + msisdn + "\n" + mscNo + "\n" + imsi;
				break;
			default:
				logger.info("Unknown Service Request\n");
		}

		int length = requestBuffer.length(); 

		//    byte[] lengthBuf = new byte[4];
		//    lengthBuf[1] = (byte)((length >> 16) & 0xff);
		//    lengthBuf[0] = (byte)((length >> 24) & 0xff);
		//    lengthBuf[3] = (byte)(length & 0xff);
		//    lengthBuf[2] = (byte)((length >> 8) & 0xff);

		try
		{
			reader = new DataInputStream(socket.getInputStream());
			writer = new DataOutputStream(socket.getOutputStream());
		}
		catch (IOException ioe)
		{
			logger.error("Failed to get input/output stream\n");
			ioe.printStackTrace();
			return -1;
		}
		logger.debug("input/output stream established");

		try
		{
			logger.debug("writing to output stream");
			writer.writeInt (length);
			writer.write(requestBuffer.getBytes(), 0, requestBuffer.length());

			// This can be made a different method.
			//
			logger.debug("reading stream");
			int responseLen = reader.readInt();
			byte responseBuf[] = new byte[responseLen+1];
			reader.read(responseBuf, 0, responseLen);

			responseBuf[responseLen] = '\0';
			socket.close();
			logger.debug("socket closed");

			String response = new String (responseBuf);
			logger.info("response  "+response);
			StringTokenizer st = new StringTokenizer(response);
			//String []tokens = response.split("\\n");
			
			String []tokens = new String[st.countTokens()];
			int ctr = 0;
			while(st.hasMoreTokens())
			{
				tokens[ctr] = st.nextToken();
				System.out.println("TOKEN["+ctr+"] value["+tokens[ctr]+"]");
				ctr++;
			}

			System.out.println("Tokens Length [" + tokens.length + "]" );

			msrn = tokens[1];
			if (msrn.equals("NULL"))
			{
				msrn = "";
			}
			//msrnBuf = msrnBuf.append(msrn);


			mscNo = tokens[2];
			if (mscNo.equals("NULL"))
			{
				mscNo = "";
			}
			imsi = tokens[3];

			if (imsi.equals("NULL"))
			{
				imsi = "";
			}
			imsiBuf.append(imsi);

			scfAddress = tokens[4];
			if (scfAddress.equals("NULL"))
			{
				scfAddress = "";
			}
			try
			{
				serviceKey = new Integer(tokens[5]);
			}
			catch(NumberFormatException nfe)
			{
				serviceKey = new Integer(0);
				nfe.printStackTrace();
			}
                        if (tokens[6].equals("N"))
                        {
		              isprepaid = new Boolean(false);
		              retVal = 1;
		        }
			else
		        {
                              isprepaid = new Boolean(true);
		              retVal = 2;
                        } 
                        		//System.out.println("6.Is  prepaid value  [ "+isprepaid+" ]  Token [6]");
                              logger.info("6.Is  prepaid value  [ "+isprepaid+" ]  Token [6]");
                       if (tokens[7].equals("N"))
		              isroaming = new Boolean(false);
		       else
			     isroaming = new Boolean(true);
                              logger.info("7.Is roaming is [ "+isroaming+" ]");        
                       if (tokens[8].equals("NULL"))
			{
		         error = new Integer (0);
			}
		      else
		       {
			try
			{
			 error = new Integer(tokens[8]);
			}
			catch(NumberFormatException nfe)
			{
			error = new Integer(-1);
			nfe.printStackTrace();
			}
		       }
                      logger.info("8.Error Value [ "+error+" ]");

	busyNumber = tokens[9];
	if (busyNumber.equals("NULL"))
	{
		busyNumber = "";
	}
	logger.info("9.Busy Number [ "+busyNumber+" ]");
	noReplyNumber = tokens[10];
	if (noReplyNumber.equals("NULL"))
	{
		noReplyNumber = "";
	}
	logger.info("10.No Reply  Number [ "+noReplyNumber+" ]");
	unreachableNumber = tokens[11];

	if (unreachableNumber.equals("NULL"))
	{
		unreachableNumber = "";
	}

	logger.info("11.Un Reachable  Number [ "+unreachableNumber+" ]");  
       //    if (tokens[11].equals("N"))

	if (tokens[12].charAt(0)=='N')
	{
		cfuActive = new Boolean(false);
		//cfuActiveStr=cfuActiveStr.append("false");
	}
	else
	{
		cfuActive = new Boolean(true);
		//	cfuActiveStr = cfuActiveStr.append("true");
	}
	logger.info("12.CFU Active [ "+cfuActive+" ]");
	forwardNumber = tokens[13];
	System.out.println("forwardNumber["+forwardNumber+"]");
	if (forwardNumber.equals("NULL"))
	{
		forwardNumber = "";
	}

	//	msrnBuf = msrnBuf.append(forwardNumber);
	logger.info("13.Forword Number [ "+cfuActive+" ]");
	logger.info("Return Value from HLR is [ "+error.intValue()+" ] ");
       // Added by rajendra return 1 for PREPAID 2 for POSTPAID
	if (error.intValue() != 0)
	{
		logger.info(msisdn+"#Error Return From HLR Return Value is [ "+error.intValue()+" ]");
		retVal = -1; // Error Return From HLR
	}
	else
	{
        	logger.info(msisdn+"#Success Return from HLR Return Value is [ "+error.intValue()+" ] Token 6 Value is [ "+tokens[6]+" ]");

		if (tokens[6].equalsIgnoreCase(("N")))
		{
			System.out.println(msisdn+"# is Post Paid Number");
			logger.info(msisdn+"# is Post Paid Number");
			retVal = 2;  // Postpaid Number
			//isprepaid = new Boolean(false);
		}
		else
		{
			System.out.println(msisdn+"# is Prepaid Number");
			logger.info(msisdn+"# is Prepaid Number");
			retVal = 1;  // Prepaid Number
			// isprepaid = new Boolean(true);
	        }
	}
     logger.info("exiting fetchmsrn:with  return value= "+error.intValue()+" retVal["+retVal+"]isPrepaid["+isprepaid+"]");
      }
      catch(Exception e)
      {
	e.printStackTrace();
      }
 return retVal;
   } //fetchmsrn

/*   public static void main(String arg[])
	{
	   Thread executorThread;
	   LoadTestExecutor loadTestExecutor;
	   HlrTesterBean hlrTestBean = new HlrTesterBean();
	   try
	   {
		   		String vlr = "";
                String scfAddress = "";
                String busyNumber = "";
                String noReplyNumber = "";
                String unreachableNumber = "";
                StringBuffer msrnBuf = new StringBuffer();
                StringBuffer imsiBuf = new StringBuffer();
                StringBuffer cfuActiveStr = new StringBuffer();

                Boolean isRoaming = true;
                Boolean isPrepaid = true;
                Boolean cfuActive = true;

                int msrnError = 0;
                int serviceKey = 0;
                int sourceType = -1;
                int serviceType = Integer.parseInt(arg[0]);
                String msisdn = arg[1];
                MSRN_FETCH_HOST = arg[2];
                MSRN_FETCH_PORT = (short) Integer.parseInt(arg[3]);
                int result = -1;
		for(int i =1 ;i<=200000;i++)
		{ //18680000000
			if (i>1) {
				long localmsisdn = Long.parseLong(msisdn);
				localmsisdn = localmsisdn+1;
				
				if (localmsisdn%2==0) {
					msisdn = String.valueOf(localmsisdn);
					serviceType = 3;
				}
				else {
					msisdn = String.valueOf(localmsisdn);
					serviceType = 4;
				}
			}
		result = new LoadTester().fetchmsrn(serviceType,msisdn,msrnBuf, vlr, imsiBuf, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber,unreachableNumber, cfuActive, cfuActiveStr);
		System.out.println("RESPONSE IS["+result+"]");
		Thread.sleep(1000);
		}
	   }
	   catch(Exception exp)
	   {
		   exp.printStackTrace();
	   }
	}*/
   
	public static void main(String arg[])
	{
	   Thread executorThread;
	   LoadTestExecutor loadTestExecutor;
	   HlrTesterBean hlrTestBean = new HlrTesterBean();
	   ThreadPoolExecutor hlrTesterExecutor = null;
	   try {
		   	hlrTestBean.vlr="";
			hlrTestBean.scfAddress="";
			hlrTestBean.busyNumber="";
			hlrTestBean.noReplyNumber="";
			hlrTestBean.unreachableNumber="";
			hlrTestBean.msrnBuf=new StringBuffer();
			hlrTestBean.imsiBuf=new StringBuffer();
			hlrTestBean.cfuActiveStr=new StringBuffer();
			hlrTestBean.isRoaming=true;
			hlrTestBean.isPrepaid=true;
			hlrTestBean.cfuActive=true;
			hlrTestBean.msrnError=0;
			hlrTestBean.serviceKey=0;
			hlrTestBean.sourceType=-1;
			hlrTestBean.serviceType=Integer.parseInt(arg[0]);
			hlrTestBean.msisdn=arg[1];
			MSRN_FETCH_HOST = arg[2];
	        MSRN_FETCH_PORT = (short) Integer.parseInt(arg[3]);
	        int result = -1;
	        for (int j = 1; j <= 1000; j++) {
				if (j<2) {
					result = LoadTester.fetchmsrn(hlrTestBean.getServiceType(),hlrTestBean.getMsisdn(),hlrTestBean.getMsrnBuf(),
							hlrTestBean.getVlr(), hlrTestBean.getImsiBuf(), hlrTestBean.getScfAddress(), 
							hlrTestBean.getServiceKey(), hlrTestBean.getIsRoaming(), hlrTestBean.getIsPrepaid(), 
							hlrTestBean.getMsrnError(), hlrTestBean.getBusyNumber(), hlrTestBean.getNoReplyNumber(),
							hlrTestBean.getUnreachableNumber(), hlrTestBean.getCfuActive(), hlrTestBean.getCfuActiveStr());
					System.out.println("RESPONSE IS["+result+"]");
				}
				else {
					
					hlrTesterExecutor = new ThreadPoolExecutor(1,30,10,TimeUnit.SECONDS,
									new ArrayBlockingQueue<Runnable>(1000));
					hlrTesterExecutor.setRejectedExecutionHandler(new RejectedWork());

					hlrTesterExecutor.execute(new LoadTestExecutor(hlrTestBean));
					
//					loadTestExecutor = new LoadTestExecutor(hlrTestBean);
//					executorThread = new Thread(loadTestExecutor);
//					executorThread.start();
				}
			}
			//System.out.println("RESPONSE IS["+result+"]");
			Thread.sleep(1000);
	} catch (Exception e) {
		e.printStackTrace();
	}
	   
	}
}
