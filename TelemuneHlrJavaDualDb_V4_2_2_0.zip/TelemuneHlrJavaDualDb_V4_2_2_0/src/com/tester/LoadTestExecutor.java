package com.tester;

import org.apache.log4j.Logger;


public class LoadTestExecutor implements Runnable {

	private Logger logger = Logger.getLogger(LoadTestExecutor.class);
	HlrTesterBean hlrTesterBean;
	
	public LoadTestExecutor(HlrTesterBean hlrTesterBean) {
		this.hlrTesterBean=hlrTesterBean;
	}

	@Override
	public void run() {
		int result=-1;
		String msisdn="";
		try {
					long localmsisdn = Long.parseLong(hlrTesterBean.getMsisdn());
					localmsisdn = localmsisdn+1;
					System.out.println("localmsisdn["+localmsisdn+"]" );
					hlrTesterBean.setMsisdn(String.valueOf(localmsisdn));
					if (localmsisdn%2==0) {
						msisdn = String.valueOf(localmsisdn);
						hlrTesterBean.setServiceType(3);//serviceType = 3;
					}
					else {
						msisdn = String.valueOf(localmsisdn);
						hlrTesterBean.setServiceType(4);//serviceType = 4;
					}
			result = LoadTester.fetchmsrn(hlrTesterBean.getServiceType(),hlrTesterBean.getMsisdn(),hlrTesterBean.getMsrnBuf(),
					hlrTesterBean.getVlr(), hlrTesterBean.getImsiBuf(), hlrTesterBean.getScfAddress(), 
					hlrTesterBean.getServiceKey(), hlrTesterBean.getIsRoaming(), hlrTesterBean.getIsPrepaid(), 
					hlrTesterBean.getMsrnError(), hlrTesterBean.getBusyNumber(), hlrTesterBean.getNoReplyNumber(),
					hlrTesterBean.getUnreachableNumber(), hlrTesterBean.getCfuActive(), hlrTesterBean.getCfuActiveStr());
			System.out.println("RESPONSE IS["+result+"]");
			//Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		
}
