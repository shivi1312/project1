package com.tester;

public class HlrTesterBean {
	String vlr;
    String scfAddress;
    String busyNumber;
    String noReplyNumber;
    String unreachableNumber;
    StringBuffer msrnBuf;
    StringBuffer imsiBuf;
    StringBuffer cfuActiveStr;

    Boolean isRoaming;
    Boolean isPrepaid;
    Boolean cfuActive;

    int msrnError;
    int serviceKey;
    int sourceType;
    int serviceType;
    String msisdn;
    
    public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	//    MSRN_FETCH_HOST = arg[2];
//    MSRN_FETCH_PORT = (short) Integer.parseInt(arg[3]);
	public String getVlr() {
		return vlr;
	}
	public void setVlr(String vlr) {
		this.vlr = vlr;
	}
	public String getScfAddress() {
		return scfAddress;
	}
	public void setScfAddress(String scfAddress) {
		this.scfAddress = scfAddress;
	}
	public String getBusyNumber() {
		return busyNumber;
	}
	public void setBusyNumber(String busyNumber) {
		this.busyNumber = busyNumber;
	}
	public String getNoReplyNumber() {
		return noReplyNumber;
	}
	public void setNoReplyNumber(String noReplyNumber) {
		this.noReplyNumber = noReplyNumber;
	}
	public String getUnreachableNumber() {
		return unreachableNumber;
	}
	public void setUnreachableNumber(String unreachableNumber) {
		this.unreachableNumber = unreachableNumber;
	}
	public StringBuffer getMsrnBuf() {
		return msrnBuf;
	}
	public void setMsrnBuf(StringBuffer msrnBuf) {
		this.msrnBuf = msrnBuf;
	}
	public StringBuffer getImsiBuf() {
		return imsiBuf;
	}
	public void setImsiBuf(StringBuffer imsiBuf) {
		this.imsiBuf = imsiBuf;
	}
	public StringBuffer getCfuActiveStr() {
		return cfuActiveStr;
	}
	public void setCfuActiveStr(StringBuffer cfuActiveStr) {
		this.cfuActiveStr = cfuActiveStr;
	}
	public Boolean getIsRoaming() {
		return isRoaming;
	}
	public void setIsRoaming(Boolean isRoaming) {
		this.isRoaming = isRoaming;
	}
	public Boolean getIsPrepaid() {
		return isPrepaid;
	}
	public void setIsPrepaid(Boolean isPrepaid) {
		this.isPrepaid = isPrepaid;
	}
	public Boolean getCfuActive() {
		return cfuActive;
	}
	public void setCfuActive(Boolean cfuActive) {
		this.cfuActive = cfuActive;
	}
	public int getMsrnError() {
		return msrnError;
	}
	public void setMsrnError(int msrnError) {
		this.msrnError = msrnError;
	}
	public int getServiceKey() {
		return serviceKey;
	}
	public void setServiceKey(int serviceKey) {
		this.serviceKey = serviceKey;
	}
	public int getSourceType() {
		return sourceType;
	}
	public void setSourceType(int sourceType) {
		this.sourceType = sourceType;
	}
	public int getServiceType() {
		return serviceType;
	}
	public void setServiceType(int serviceType) {
		this.serviceType = serviceType;
	}
	@Override
	public String toString() {
		return "HlrTesterBean [vlr=" + vlr + ", scfAddress=" + scfAddress
				+ ", busyNumber=" + busyNumber + ", noReplyNumber="
				+ noReplyNumber + ", unreachableNumber=" + unreachableNumber
				+ ", msrnBuf=" + msrnBuf + ", imsiBuf=" + imsiBuf
				+ ", cfuActiveStr=" + cfuActiveStr + ", isRoaming=" + isRoaming
				+ ", isPrepaid=" + isPrepaid + ", cfuActive=" + cfuActive
				+ ", msrnError=" + msrnError + ", serviceKey=" + serviceKey
				+ ", sourceType=" + sourceType + ", serviceType=" + serviceType
				+ ", msisdn=" + msisdn + "]";
	}
	
    
    
}
