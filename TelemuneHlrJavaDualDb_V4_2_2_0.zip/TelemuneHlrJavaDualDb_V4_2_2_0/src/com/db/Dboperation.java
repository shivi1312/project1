package com.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import org.apache.log4j.Logger;
import com.telemune.hlr.Global;
import com.telemune.hlr.HlrBean;
import com.telemune.hlr.ObjectPool;
import com.telemune.hlr.backend.DataObject;
import com.telemune.hlr.backend.HttpRequestHandler;
import com.telemune.hlr.backend.SoapRequestHandler;
import com.telemune.hlr.backend.TelnetRequestHandler;

/**
 * This class provide all utility methods to handle database operations
 * @author Harjinder 
 **/
public class Dboperation {
	private Logger logger = Logger.getLogger("Dboperation");
	private AtomicLong processNo=new AtomicLong(0);
	private AtomicInteger port = new AtomicInteger(0);
	String ip;
	String loginName;
	String password;
	int noOfConnection = 0;
	String hlrType; //added by Avishkar on 19.04.2018
	int hlrId = 0; // added by Avishkar on 25.04.2019
	boolean credentialFlag = false; // added by Avishkar on 25.04.2019
	
	/**
	 * This method used to read data from CRBT_HLR_CONFIG
	 * @return {@link HashMap}
	 * */
	public HashMap<Integer, HlrBean> getAllHlrDetails()
	{
		Connection con = null;
		PreparedStatement pstmt = null;
		String query = null;
		ResultSet rset = null;
		
		try
		{
					
			con = Global.conPool.getConnection();
//			query = DBQuery.fetchHlrConfigDetails; //"select * from CRBT_HLR_CONFIG"; // commented by Avishkar on 11.09.2020
			query = DBQuery.fetchHlrConfigDetails.replace("${Global.READ_HLR_CONFIG_TABLE_NAME}", Global.READ_HLR_CONFIG_TABLE_NAME); // Modified by Avishkar on 11.09.2020
			pstmt = con.prepareStatement(query);
			rset = pstmt.executeQuery();
			HlrBean hlrBean = null;
			if(rset.next())
			{
				port.set(rset.getInt("HLR_PORT"));
				loginName = rset.getString("LOGIN");
				password =  rset.getString("PASSWORD");
				ip = rset.getString("HLR_IP");
				noOfConnection = rset.getInt("CONNECTIONS");
				hlrId = rset.getInt("HLR_ID"); // added by Avishkar on 25.04.2019
				hlrType = rset.getString("HLR_TYPE"); //modified by Avishkar on 19.04.2018
				credentialFlag = true; // added by Avishkar on 25.04.2019
				hlrBean = new HlrBean();
				hlrBean.setRemoteUser(loginName);
				hlrBean.setRemotePassword(password);
				hlrBean.setTelnetConfiguredIp(ip);
				hlrBean.setPort(port);
				//hlrBean.setHlrType("TELNET"); //commented by Avishkar on 19.04.2018
				hlrBean.setHlrType(hlrType); //modified by Avishkar on 19.04.2018
				hlrBean.setNoOfConnection(noOfConnection);
				rset.close();
				pstmt.close();
				con.close();
			} // this block is finish here by Avishkar on 25.04.2019
				//modification start by Avishkar on 20.04.2018
				
				if (credentialFlag) { // this is condition is added by Avishkar on 25.04.2019
					
					if ("TELNET".equals(hlrBean.getHlrType())) {
						//hlrBean.setTelnet_pool(new ObjectPool<TelnetRequestHandler>(rset.getInt("CONNECTIONS")) // commented by Avishkar on 25.04.2019
						hlrBean.setTelnet_pool(new ObjectPool<TelnetRequestHandler>(noOfConnection) // modified by Avishkar on 25.04.2019
						        {  
						            protected TelnetRequestHandler createObject()  
						            {  
						                // create a test object which takes some time for creation  
						                return new TelnetRequestHandler(processNo.incrementAndGet() , ip,port.get() ,loginName,password);  
						            }
						        });
						
						//System.out.println("Object created successfully poolsize["+hlrBean.getTelnet_pool().size()+"] HlrId["+rset.getInt("HLR_ID")+"]"); // commented by Avishkar on 25.04.2019
						System.out.println("Object created successfully poolsize["+hlrBean.getTelnet_pool().size()+"] HlrId["+hlrId+"]"); // modified by Avishkar on 25.04.2019
						logger.info("Object created successfully poolsize["+hlrBean.getTelnet_pool().size()+"] HlrId["+hlrId+"]"); //added by Avishkar on 25.04.2019
						
					} else if ("SOAP".equals(hlrBean.getHlrType())) {
						
						//hlrBean.setSoap_pool(new ObjectPool<SoapRequestHandler>(rset.getInt("CONNECTIONS")) // commented by Avishkar on 25.04.2019
						hlrBean.setSoap_pool(new ObjectPool<SoapRequestHandler>(noOfConnection) // modified by Avishkar on 25.04.2019
						        {  
						            protected SoapRequestHandler createObject()  
						            {  
						                // create a test object which takes some time for creation  
						                return new SoapRequestHandler(processNo.incrementAndGet());  
						            }
						        });
						
						//System.out.println("Object created successfully poolsize["+hlrBean.getSoap_pool().size()+"] HlrId["+rset.getInt("HLR_ID")+"]"); // commented by Avishkar on 25.04.2019
						System.out.println("Object created successfully poolsize["+hlrBean.getSoap_pool().size()+"] HlrId["+hlrId+"]"); // modified by Avishkar on 25.04.2019
						logger.info("Object created successfully poolsize["+hlrBean.getSoap_pool().size()+"] HlrId["+hlrId+"]"); //added by Avishkar on 25.04.2019
						
					} else {
						//hlrBean.setHttp_pool(new ObjectPool<HttpRequestHandler>(rset.getInt("CONNECTIONS")) // commented by Avishkar on 25.04.2019
						hlrBean.setHttp_pool(new ObjectPool<HttpRequestHandler>(noOfConnection) // modified by Avishkar on 25.04.2019
						        {  
						            protected HttpRequestHandler createObject()  
						            {  
						                // create a test object which takes some time for creation  
						                return new HttpRequestHandler(processNo.incrementAndGet(),Global.HTTP_URL);  
						            }
						        });
						
						//System.out.println("Object created successfully poolsize["+hlrBean.getHttp_pool().size()+"] HlrId["+rset.getInt("HLR_ID")+"]"); // commented by Avishkar on 25.04.2019
						System.out.println("Object created successfully poolsize["+hlrBean.getHttp_pool().size()+"] HlrId["+hlrId+"]");
						logger.info("Object created successfully poolsize["+hlrBean.getHttp_pool().size()+"] HlrId["+hlrId+"]"); //added by Avishkar on 25.04.2019
					}
					
			//modification end by Avishkar on 20.04.2018
					
					//comments start by Avishkar on 20.04.2018
					
					/*hlrBean.setTelnet_pool(new ObjectPool<TelnetRequestHandler>(rset.getInt("CONNECTIONS"))  
					        {  
					            protected TelnetRequestHandler createObject()  
					            {  
					                // create a test object which takes some time for creation  
					                return new TelnetRequestHandler(processNo.incrementAndGet() , ip,port.get() ,loginName,password);  
					            }
					        });*/ 
					//comments end by Avishkar on 20.04.2018
					
					//Global.map.put(rset.getInt("HLR_ID"),hlrBean); //commented by Avishkar on 25.04.2019
					Global.map.put(hlrId,hlrBean); // modified by Avishkar on 25.04.2019
					//Global.priority_map.put(1, rset.getInt("HLR_ID")); //commented by Avishkar on 25.04.2019
					Global.priority_map.put(1, hlrId); // modified by Avishkar on 25.04.2019
					 
					 
	//				 System.out.println("Object created successfully poolsize["+hlrBean.getTelnet_pool().size()+"] HlrId["+rset.getInt("HLR_ID")+"]"); 
					 // above line is commented by Avishkar on 20.04.2018
				}
				else { // added by Avishkar on 25.04.2019
					logger.error("Error : Problem in getting credentials of hlr and creating Object pool ");
					System.out.println("Error : Problem in getting credentials of hlr and creating Object pool ");
				}
			 //} // commented by Avishkar on 25.04.2019
		  
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		finally{
			try
			{
				if(con != null){con.close();}
				if(pstmt != null){pstmt.close();}
				if(rset != null){rset.close();}
			}
			catch(SQLException sqlexp)
			{
				sqlexp.printStackTrace();
			}
			
			
		}
		return null;
	}
	
	/**
	 * This method update sub_type inside CRBT_SUBSCRIBER_MASTER
	 * @param dataObject
	 * @return void
	 * */
	public synchronized void updateSubType(DataObject dataObject)
	{
		logger.info("##>msisdn["+dataObject.getMsisdn()+"] isPrepaid["+dataObject.getIsPrePaidId()+"] Inside updateSubType .............");
		PreparedStatement pstmt = null;
		String query = null;
		Connection con = null;
		String subType = "N";
		
		try
		{
			if(dataObject.getIsPrePaidId().equalsIgnoreCase("Y"))
			{
				subType = "P";
			}
			else
			{
				subType = "O";
			}
			con = Global.conPool.getConnection();
			//query = "update "+Global.READ_SET_SUB_TYPE_TABLE_NAME+" set SUB_Type=? where msisdn=?"; // Commented by Avishkar on 22.04.2019
		// addition start by Avishkar on 17/9/2020	
			if (Global.MULTIPLE_TABLE_SUBSCRIPTION_CHECK==1) {
				String lastDigit=dataObject.getMsisdn().substring(dataObject.getMsisdn().length() - 1);
				String tableNameSub=Global.READ_SET_SUB_TYPE_TABLE_NAME+"_"+lastDigit;
				query = DBQuery.updateSubType.replace("${Global.READ_SET_SUB_TYPE_TABLE_NAME}", tableNameSub);
			} else {
				query = DBQuery.updateSubType.replace("${Global.READ_SET_SUB_TYPE_TABLE_NAME}", Global.READ_SET_SUB_TYPE_TABLE_NAME); // Modified by Avishkar on 22.04.2019
			}
//			query = DBQuery.updateSubType.replace("${Global.READ_SET_SUB_TYPE_TABLE_NAME}", Global.READ_SET_SUB_TYPE_TABLE_NAME); // Modified by Avishkar on 22.04.2019
			
		// addition start by Avishkar on 17/9/2020
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, subType);
			pstmt.setString(2, dataObject.getMsisdn());
			pstmt.executeUpdate();
			if(Global.SetSubTypeCounter !=0 )
			{
			Global.SetSubTypeCounter--;
			}
			
		logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Inside updateSubType successfully ...");	
		}
		catch(SQLException sqlexp)
		{
			sqlexp.printStackTrace();
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		finally{
			try
			{
				if(con != null){con.close();}
				if(pstmt != null){pstmt.close();}
			}
			catch(SQLException sqlexp)
			{
				sqlexp.printStackTrace();
			}
		}
	}
	
	public synchronized void decrementCounter()
	{
		Global.SetSubTypeCounter--;
	}
}
