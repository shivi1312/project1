package com.db;

import org.apache.log4j.Logger;

/**
 * 
 * @author avishkar
 * this class is added by Avishkar in reference to the Dual DB support of HLR Module.
 */
public class DBQuery {
	
	private static Logger logger = Logger.getLogger("DBQuery");
	
	public static String fetchRangesFromOperatorSubscriber="select STARTS_AT,ENDS_AT,COUNTRY_CODE,HLR_ID from operator_subscriber";
//	public static String fetchHlrConfigDetails="select * from CRBT_HLR_CONFIG"; // commented by Avishkar on 11/09/2020
	public static String fetchHlrConfigDetails="select * from ${Global.READ_HLR_CONFIG_TABLE_NAME}"; // modified by Avishkar on 11/09/2020
	//public static String fetchHlrInactiveRecords = "select * from "+Global.READ_HLR_INACTIVE_TABLE_NAME+" where rownum<="+Global.ROW_NUM;
	//public static String fetchHlrInactiveRecords="select * from ${Global.READ_HLR_INACTIVE_TABLE_NAME} where rownum<=?"; // commented by Avishkar on 02.09.2019
	public static String fetchHlrInactiveRecords="select * from ${Global.READ_HLR_INACTIVE_TABLE_NAME} where REQUEST_ID in ($(Global.HLR_INACTIVE_REQUEST_ALLOWED)) and rownum<=?"; // modified by Avishkar on 02.09.2019
	//public static String fetchSubTypeData = "select MSISDN from "+Global.READ_SET_SUB_TYPE_TABLE_NAME+" where SUB_TYPE!='P' and SUB_TYPE!='O' and rownum<="+Global.ROW_NUM;
	public static String fetchSubTypeData="select MSISDN from ${Global.READ_SET_SUB_TYPE_TABLE_NAME} where SUB_TYPE!='P' and SUB_TYPE!='O' and rownum<=?";
	//public static String updateSubType = "update "+Global.READ_SET_SUB_TYPE_TABLE_NAME+" set SUB_Type=? where msisdn=?";
	public static String updateSubType="update ${Global.READ_SET_SUB_TYPE_TABLE_NAME} set SUB_Type=? where msisdn=?";
	//public static String deleteHlrInactiveRecords = "delete from "+Global.READ_HLR_INACTIVE_TABLE_NAME+" where msisdn=? and REQUEST_ID=?";
	public static String deleteHlrInactiveRecords="delete from ${Global.READ_HLR_INACTIVE_TABLE_NAME} where msisdn=? and REQUEST_ID=?";
	
	public static void constructQuery(String dbType){
		try {
			switch (dbType.toLowerCase()) {
			case "oracle":
				fetchRangesFromOperatorSubscriber="select STARTS_AT,ENDS_AT,COUNTRY_CODE,HLR_ID from operator_subscriber";
//				fetchHlrConfigDetails="select * from CRBT_HLR_CONFIG"; // commented by Avishkar on 11/09/2020
				fetchHlrConfigDetails="select * from ${Global.READ_HLR_CONFIG_TABLE_NAME}"; // modified by Avishkar on 11/09/2020
				//fetchHlrInactiveRecords="select * from ${Global.READ_HLR_INACTIVE_TABLE_NAME} where rownum<=?"; // commented by Avishkar on 02.09.2019
				fetchHlrInactiveRecords="select * from ${Global.READ_HLR_INACTIVE_TABLE_NAME} where REQUEST_ID in ($(Global.HLR_INACTIVE_REQUEST_ALLOWED)) and rownum<=?"; // modified by Avishkar on 02.09.2019
				fetchSubTypeData="select MSISDN from ${Global.READ_SET_SUB_TYPE_TABLE_NAME} where SUB_TYPE!='P' and SUB_TYPE!='O' and rownum<=?";
				updateSubType="update ${Global.READ_SET_SUB_TYPE_TABLE_NAME} set SUB_Type=? where msisdn=?";
				deleteHlrInactiveRecords="delete from ${Global.READ_HLR_INACTIVE_TABLE_NAME} where msisdn=? and REQUEST_ID=?";
				break;
			case "mysql":
				fetchRangesFromOperatorSubscriber="select STARTS_AT,ENDS_AT,COUNTRY_CODE,HLR_ID from operator_subscriber";
//				fetchHlrConfigDetails="select * from CRBT_HLR_CONFIG"; // commented by Avishkar on 11/09/2020
				fetchHlrConfigDetails="select * from ${Global.READ_HLR_CONFIG_TABLE_NAME}"; // modified by Avishkar on 11/09/2020
				//fetchHlrInactiveRecords="select * from ${Global.READ_HLR_INACTIVE_TABLE_NAME} LIMIT ?"; // commented by Avishkar on 02.09.2019
				fetchHlrInactiveRecords="select * from ${Global.READ_HLR_INACTIVE_TABLE_NAME} where REQUEST_ID in ($(Global.HLR_INACTIVE_REQUEST_ALLOWED)) LIMIT ?"; // modified by Avishkar on 02.09.2019
				fetchSubTypeData="select MSISDN from ${Global.READ_SET_SUB_TYPE_TABLE_NAME} where SUB_TYPE!='P' and SUB_TYPE!='O' LIMIT ?";
				updateSubType = "update ${Global.READ_SET_SUB_TYPE_TABLE_NAME} set SUB_Type=? where msisdn=?";
				deleteHlrInactiveRecords="delete from ${Global.READ_HLR_INACTIVE_TABLE_NAME} where msisdn=? and REQUEST_ID=?";
				break;

			default:
				break;
			}
		} catch (Exception e) {
			logger.error("Exception in constructQuery method for dbType:["+dbType+"], ",e);
			e.printStackTrace();
		}
	}
}
