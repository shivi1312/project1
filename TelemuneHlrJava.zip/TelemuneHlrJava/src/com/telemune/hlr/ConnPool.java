package com.telemune.hlr;
import java.sql.*;
import com.mchange.v2.c3p0.ComboPooledDataSource;
/**
 * This class works as factory of Connection Pool
 * @author Harjinder
 * */
public class ConnPool
{

	private ComboPooledDataSource cpds = null;

	String driver;
	String url;
	String username;
	String passwd;
	int minpoolsize;
	int maxpoolsize;
	int Accomodation;
	
	/**
	 * It is a parameterized constructor 
	 * @param driver 
	 * @param url
	 * @param username
	 * @param passwd
	 * @param minpoolsize
	 * @param maxpoolsize
	 * @param Accomodation
	 * */
	public ConnPool(String driver,String url,String username,String passwd,int minpoolsize,int maxpoolsize,int Accomodation)
	{
		this.driver=driver;
		this.url=url;
		this.username=username;
		this.passwd=passwd;
		this.minpoolsize=minpoolsize;
		this.maxpoolsize=maxpoolsize;
		this.Accomodation=Accomodation;

	}

	/**
	 * This method creates a connection Pool
	 * @return void 
	 **/
	
	public void MakePool()
	{
		try 
		{
			cpds=new ComboPooledDataSource();
			cpds.setDriverClass(driver);
			cpds.setJdbcUrl(url);
			cpds.setUser(username);
			cpds.setPassword(passwd);
			cpds.setMaxPoolSize(maxpoolsize);
			cpds.setMinPoolSize(minpoolsize);
			cpds.setAcquireIncrement(Accomodation);
			cpds.setMaxStatementsPerConnection(25);
			
		} 
		catch (Exception ex) 
		{
			ex.printStackTrace();
		}

	}
	
	/**
	 * This method provides a connection from pool
	 * @return Connection
	 *   
	 * */
	public synchronized Connection getConnection()
	{
		Connection con=null;
		try{

			con= cpds.getConnection();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}
}
