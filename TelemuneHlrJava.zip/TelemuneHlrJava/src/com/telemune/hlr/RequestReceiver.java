package com.telemune.hlr;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.telemune.hlr.Global;
import com.telemune.hlr.backend.DataObject;

/**
 * This thread work as TCP/IP server listen at particular port
 * @author Harjinder 
 * */
class RequestReceiver implements Runnable 
{
	final static Logger logger = Logger.getLogger(RequestReceiver.class);
	DataInputStream reader = null;
	ServerSocket server_socket = null;
	static Thread processor;
	int port;
	Thread threq=null;

	/**
	 * It is parameterized constructor
	 * @param port
	 * */
	public RequestReceiver(int port) 
	{
		this.port = port;
	}

	/**
	 * This is a run method provided by Runnable interface
	 * It accept connection and launch new thread to read data from socket
	 * @return void
	 * */
	public void run() {
		
		try
		{
			server_socket = new ServerSocket(port);
			logger.info("Server waiting for client on port " +server_socket.getLocalPort());
		}
		catch(Exception ee)
		{
			logger.fatal("got SOCKET exception in thread" +ee.toString());
			return;
		}
		
		while (true) {
			try {
				Socket socket = server_socket.accept();
				RequestReader obj_get_data = new RequestReader("ReaderThread"+socket.toString(),socket,Global.connectionTimeOut);
                threq=new Thread(obj_get_data);
                threq.start();
			} catch (Exception e) {
				logger.fatal("Problem while accepting request : ",e);
				e.printStackTrace();
			}
		}
	}
}