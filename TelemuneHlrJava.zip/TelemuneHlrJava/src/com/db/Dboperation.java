package com.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import org.apache.log4j.Logger;
import com.telemune.hlr.Global;
import com.telemune.hlr.HlrBean;
import com.telemune.hlr.ObjectPool;
import com.telemune.hlr.backend.DataObject;
import com.telemune.hlr.backend.TelnetRequestHandler;

/**
 * This class provide all utility methods to handle database operations
 * @author Harjinder 
 **/
public class Dboperation {
	private Logger logger = Logger.getLogger("Dboperation");
	private AtomicLong processNo=new AtomicLong(0);
	private AtomicInteger port = new AtomicInteger(0);
	String ip;
	String loginName;
	String password;
	int noOfConnection = 0;
	
	
	/**
	 * This method used to read data from CRBT_HLR_CONFIG
	 * @return {@link HashMap}
	 * */
	public HashMap<Integer, HlrBean> getAllHlrDetails()
	{
		Connection con = null;
		PreparedStatement pstmt = null;
		String query = null;
		ResultSet rset = null;
		
		try
		{
					
			con = Global.conPool.getConnection();
			query = "select * from CRBT_HLR_CONFIG";
			pstmt = con.prepareStatement(query);
			rset = pstmt.executeQuery();
			HlrBean hlrBean = null;
			if(rset.next())
			{
				port.set(rset.getInt("HLR_PORT"));
				loginName = rset.getString("LOGIN");
				password =  rset.getString("PASSWORD");
				ip = rset.getString("HLR_IP");
				noOfConnection = rset.getInt("CONNECTIONS");
				hlrBean = new HlrBean();
				hlrBean.setRemoteUser(loginName);
				hlrBean.setRemotePassword(password);
				hlrBean.setTelnetConfiguredIp(ip);
				hlrBean.setPort(port);
				hlrBean.setHlrType("TELNET");
				hlrBean.setNoOfConnection(noOfConnection);
				
				hlrBean.setTelnet_pool(new ObjectPool<TelnetRequestHandler>(rset.getInt("CONNECTIONS"))  
				        {  
				            protected TelnetRequestHandler createObject()  
				            {  
				                // create a test object which takes some time for creation  
				                return new TelnetRequestHandler(processNo.incrementAndGet() , ip,port.get() ,loginName,password);  
				            }
				        });
				 Global.map.put(rset.getInt("HLR_ID"),hlrBean); 
				 Global.priority_map.put(1, rset.getInt("HLR_ID"));
				 System.out.println("Object created successfully poolsize["+hlrBean.getTelnet_pool().size()+"] HlrId["+rset.getInt("HLR_ID")+"]");
			 }
		  
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		finally{
			try
			{
				if(con != null){con.close();}
				if(pstmt != null){pstmt.close();}
				if(rset != null){rset.close();}
			}
			catch(SQLException sqlexp)
			{
				sqlexp.printStackTrace();
			}
			
			
		}
		return null;
	}
	
	/**
	 * This method update sub_type inside CRBT_SUBSCRIBER_MASTER
	 * @param dataObject
	 * @return void
	 * */
	public synchronized void updateSubType(DataObject dataObject)
	{
		logger.info("##>msisdn["+dataObject.getMsisdn()+"] isPrepaid["+dataObject.getIsPrePaidId()+"] Inside updateSubType .............");
		PreparedStatement pstmt = null;
		String query = null;
		Connection con = null;
		String subType = "N";
		
		try
		{
			if(dataObject.getIsPrePaidId().equalsIgnoreCase("Y"))
			{
				subType = "P";
			}
			else
			{
				subType = "O";
			}
			con = Global.conPool.getConnection();
			query = "update "+Global.READ_SET_SUB_TYPE_TABLE_NAME+" set SUB_Type=? where msisdn=?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, subType);
			pstmt.setString(2, dataObject.getMsisdn());
			pstmt.executeUpdate();
			if(Global.SetSubTypeCounter !=0 )
			{
			Global.SetSubTypeCounter--;
			}
			
		logger.info("##>>msisdn["+dataObject.getMsisdn()+"] Inside updateSubType successfully ...");	
		}
		catch(SQLException sqlexp)
		{
			sqlexp.printStackTrace();
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		finally{
			try
			{
				if(con != null){con.close();}
				if(pstmt != null){pstmt.close();}
			}
			catch(SQLException sqlexp)
			{
				sqlexp.printStackTrace();
			}
		}
	}
	
	public synchronized void decrementCounter()
	{
		Global.SetSubTypeCounter--;
	}
}
