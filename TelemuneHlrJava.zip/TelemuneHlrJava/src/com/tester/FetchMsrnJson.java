package com.tester;

import java.io.*;
import java.net.*;
import java.util.*; 
import java.lang.String;

import org.apache.log4j.*;

import com.google.gson.Gson;
import com.telemune.hlr.backend.DataObject;

public class FetchMsrnJson
{
	static String MSRN_FETCH_HOST = "10.168.3.75";
	static short MSRN_FETCH_PORT = 1111;
	final static int SERVICE_NORMAL_MSRN = 1;
	final static int SERVICE_INTERROGATE_MSRN = 15;
	final static int SERVICE_FORWARDING_INFO = 2;
	final static int SERVICE_ACTIVATE_SS = 3;
	final static int SERVICE_DEACTIVATE_SS = 4;
	final static int SERVICE_MSRN_NO_FORWARD = 5;
	final static int SERVICE_SRI = 6;
	final static int SERVICE_DUMMY_LOCUPD = 7;
	final static int SERVICE_DEACTIVATE_IMSI = 12;
	final static int SERVICE_ACTIVATE_IMSI = 13;
	final static int SERVICE_RETRIEVE_IMSI = 9;

    private static Logger logger=Logger.getLogger(FetchMsrnJson.class);

	public static int fetchmsrn(int service, String msisdn, StringBuffer  msrnBuf, String mscNo, StringBuffer imsiBuf, String scfAddress, Integer serviceKey, Boolean isroaming, Boolean isprepaid, Integer error, String busyNumber, String noReplyNumber, String unreachableNumber, Boolean cfuActive, StringBuffer cfuActiveStr)
	{
        int retVal = -1;
		Properties properties = null;
		FileInputStream fis1 = null;
		logger.info("in fetchmsrn'"+msisdn+"'");
		Socket socket = null;
		DataOutputStream writer = null;
		DataInputStream reader = null;
        int result = -1;
		logger.info("MSRN_FETCH_HOST= "+MSRN_FETCH_HOST+" MSRN_FETCH_PORT= "+MSRN_FETCH_PORT);
		try
		{
			socket = new Socket (MSRN_FETCH_HOST,MSRN_FETCH_PORT);
		}
		catch (SocketException se)
		{
			logger.error("Error in opening socket\n");
			se.printStackTrace();
			return -1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return -1;
		}
		logger.debug("Socket Connection established");

		String requestBuffer = "";
		int requestId = 1;
		
		DataObject dataObject = new DataObject();
		dataObject.setReqId(requestId);
		dataObject.setReqType(service);
		
		
		//requestBuffer = requestBuffer + requestId + "\n" + service;	
		String msrn = "";
		String imsi = "";
		String forwardNumber = "";


		switch(service)
		{
			case SERVICE_NORMAL_MSRN:    // request for normal msrn query...
			case SERVICE_INTERROGATE_MSRN:    // request for normal msrn query...
			case SERVICE_ACTIVATE_SS:		//	request for activate SS
			case SERVICE_DEACTIVATE_SS:		// request for deativate SS
			case SERVICE_RETRIEVE_IMSI:		// request for deativate SS
			case SERVICE_MSRN_NO_FORWARD:		//	request for msrn without forwarded info
			case SERVICE_SRI:		//	request for SRI..( to check prepaid)
				if (msisdn == null)
				{
					msisdn = "";
				}
				dataObject.setMsisdn(msisdn);
				//requestBuffer = requestBuffer + "\n" + msisdn;
				break;
			case SERVICE_FORWARDING_INFO:		//	request for update location...
			case SERVICE_DEACTIVATE_IMSI:
			case SERVICE_ACTIVATE_IMSI:
				if (msisdn == null)
				{
					msisdn = "";
				}
				if (mscNo == null)
				{
					mscNo = "";
				}
				if (imsi == null)
				{
					imsi = "";
				}
				dataObject.setMsisdn(msisdn);
				dataObject.setMscNo(mscNo);
				dataObject.setImsi(imsi);
				//requestBuffer = requestBuffer + "\n" + msisdn + "\n" + mscNo + "\n" + imsi;
				break;
			default:
				logger.info("Unknown Service Request\n");
		}
		Gson gson = new Gson();
		requestBuffer = gson.toJson(dataObject);
		System.out.println("Reqest Json is["+requestBuffer+"]");
		int length = requestBuffer.length(); 

		try
		{
			reader = new DataInputStream(socket.getInputStream());
			writer = new DataOutputStream(socket.getOutputStream());
		}
		catch (IOException ioe)
		{
			logger.error("Failed to get input/output stream\n");
			ioe.printStackTrace();
			return -1;
		}
		logger.debug("input/output stream established");

		try
		{
			logger.debug("writing to output stream");
			writer.writeInt (length);
			writer.write(requestBuffer.getBytes(), 0, requestBuffer.length());

			// This can be made a different method.
			//
			logger.debug("reading stream");
			int responseLen = reader.readInt();
			byte responseBuf[] = new byte[responseLen+1];
			reader.read(responseBuf, 0, responseLen);

			//responseBuf[responseLen] = '\0';
			socket.close();
			logger.debug("socket closed");

			String response = new String (responseBuf);
			
			dataObject =  gson.fromJson(response.trim(), DataObject.class);
			System.out.println("response JSON "+response);
			
			msrn = dataObject.getMsrn();
			if (msrn.equals("NULL"))
			{
				msrn = "";
			}
			//msrnBuf = msrnBuf.append(msrn);


			mscNo = dataObject.getMscNo();
			if (mscNo.equals("NULL"))
			{
				mscNo = "";
			}
			imsi = dataObject.getImsi();

			if (imsi.equals("NULL"))
			{
				imsi = "";
			}
			imsiBuf.append(imsi);

			scfAddress = dataObject.getScfAddr();
			if (scfAddress.equals("NULL"))
			{
				scfAddress = "";
			}
			try
			{
				serviceKey = new Integer(dataObject.getServiceKey());
			}
			catch(NumberFormatException nfe)
			{
				serviceKey = new Integer(0);
				nfe.printStackTrace();
			}
            if (dataObject.getIsPrePaidId().equals("Y"))
            {
                        	isprepaid = new Boolean(false);
                        	retVal = 1;
            }
			else
		        {
                              isprepaid = new Boolean(true);
                              retVal = 2;
            } 
            logger.info("6.Is  prepaid value  [ "+isprepaid+" ]  Token [6]");
            if (dataObject.getIsRoaming().equals("N"))
		        isroaming = new Boolean(false);
		    else
			    isroaming = new Boolean(true);
            logger.info("7.Is roaming is [ "+isroaming+" ]");        
            if (dataObject.getResponse().equals("NULL"))
			{
		         error = new Integer (0);
			}
		    else
		    {
			try
			{
			 error = new Integer(dataObject.getResponse());
			}
			catch(NumberFormatException nfe)
			{
			error = new Integer(-1);
			nfe.printStackTrace();
			}
		    }
            logger.info("8.Error Value [ "+error+" ]");

	busyNumber = dataObject.getBusyNo();
	if (busyNumber.equals("NULL"))
	{
		busyNumber = "";
	}
	logger.info("9.Busy Number [ "+busyNumber+" ]");
	noReplyNumber = dataObject.getNoReply();
	if (noReplyNumber.equals("NULL"))
	{
		noReplyNumber = "";
	}
	logger.info("10.No Reply  Number [ "+noReplyNumber+" ]");
	unreachableNumber = dataObject.getNoReachNo();

	if (unreachableNumber.equals("NULL"))
	{
		unreachableNumber = "";
	}

	logger.info("11.Un Reachable  Number [ "+unreachableNumber+" ]");  
       //    if (tokens[11].equals("N"))

	if (dataObject.getCFU().charAt(0)=='N')
	{
		cfuActive = new Boolean(false);
		//cfuActiveStr=cfuActiveStr.append("false");
	}
	else
	{
		cfuActive = new Boolean(true);
		//	cfuActiveStr = cfuActiveStr.append("true");
	}
	logger.info("Return Value from HLR is [ "+error.intValue()+" ] ");
       // Added by rajendra return 1 for PREPAID 2 for POSTPAID
	if (error.intValue() != 0)
	{
		logger.info(msisdn+"#Error Return From HLR Return Value is [ "+error.intValue()+" ]");
		retVal = -1; // Error Return From HLR
	}
	else
	{
        	logger.info(msisdn+"#Success Return from HLR Return Value is [ "+error.intValue()+" ]");

		if (dataObject.getIsPrePaidId().equalsIgnoreCase(("N")))
		{
			logger.info(msisdn+"# is Post Paid Number");
			retVal = 2;  // Postpaid Number
			//isprepaid = new Boolean(false);
		}
		else
		{
			logger.info(msisdn+"# is Prepaid Number");
			retVal = 1;  // Prepaid Number
			// isprepaid = new Boolean(true);
	        }
	}
          logger.info("exiting fetchmsrn:with  return value= "+error.intValue()+" retVal["+retVal+"]isPrepaid["+isprepaid+"]");
      }
      catch(Exception e)
      {
	e.printStackTrace();
      }
 return retVal;
   } //fetchmsrn

   public static void main(String arg[])
	{
		String vlr = "";
                String scfAddress = "";
                String busyNumber = "";
                String noReplyNumber = "";
                String unreachableNumber = "";
                StringBuffer msrnBuf = new StringBuffer();
                StringBuffer imsiBuf = new StringBuffer();
                StringBuffer cfuActiveStr = new StringBuffer();

                Boolean isRoaming = true;
                Boolean isPrepaid = true;
                Boolean cfuActive = true;

                int msrnError = 0;
                int serviceKey = 0;
                int sourceType = -1;
                int serviceType = Integer.parseInt(arg[0]);
                String msisdn = arg[1];
                MSRN_FETCH_HOST = arg[2];
                MSRN_FETCH_PORT = (short) Integer.parseInt(arg[3]);
                int result = -1;
	//	for(int i =0 ;i<1;i++)
	//	{
		 result = new FetchMsrnJson().fetchmsrn(serviceType,msisdn,msrnBuf, vlr, imsiBuf, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber,unreachableNumber, cfuActive, cfuActiveStr);		
		System.out.println("RESPONSE IS["+result+"]");
	//	}

	
	}		
}
