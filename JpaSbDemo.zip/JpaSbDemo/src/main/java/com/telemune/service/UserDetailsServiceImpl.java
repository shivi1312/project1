package com.telemune.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.telemune.entity.RoleEntity;
import com.telemune.entity.UserEntity;
import com.telemune.repository.UserRepository;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Service
public class UserDetailsServiceImpl implements UserDetailsService{
	private static final Logger LOG = LogManager.getLogger(UserDetailsServiceImpl.class);
	@Autowired
	private UserRepository userRepository;
	
	@Override
    @Transactional(readOnly = true)
	public UserDetails loadUserByUsername(String userName)
	{
		 LOG.debug("This will be printed on debug");
	        LOG.info("This will be printed on info");
	        LOG.warn("This will be printed on warn");
	        LOG.error("This will be printed on error");
	        LOG.fatal("This will be printed on fatal");
		UserEntity user= userRepository.findByUsername(userName);
		if(user==null) throw new UsernameNotFoundException(userName);
		
		Set<GrantedAuthority> grantedAuthorities= new HashSet<>();
		for(RoleEntity role: user.getRoles())
		{
			grantedAuthorities.add(new SimpleGrantedAuthority(role.getName()));
			
		}
		return new org.springframework.security.core.userdetails.User(user.getUserName(),user.getPassword(),grantedAuthorities);
	}
}
