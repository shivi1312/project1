package com.telemune.service;

import com.telemune.entity.UserEntity;

public interface UserService {
	void save(UserEntity user);

    UserEntity findByUsername(String username);
}
