package com.telemune.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.entity.RoleEntity;

public interface RoleRepository extends JpaRepository<RoleEntity, Long> {
	
}
