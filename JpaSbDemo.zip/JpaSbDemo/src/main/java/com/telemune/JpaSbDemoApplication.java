package com.telemune;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaSbDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaSbDemoApplication.class, args);
	}

}
