package com.telemune;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaSbDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
