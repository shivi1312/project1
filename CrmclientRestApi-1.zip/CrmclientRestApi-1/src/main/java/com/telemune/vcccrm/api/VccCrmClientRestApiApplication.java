package com.telemune.vcccrm.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//import com.telemune.vcccrm.api.config.AppConfig;
//
@SpringBootApplication
public class VccCrmClientRestApiApplication {
//	
//	static {
//		System.setProperty(
//				"javax.net.ssl.trustStore",
//				AppConfig.config
//						.getString(
//								"trust_store",
//								"/home/vccuser/development/apache-tomcat-7.0.30/bin/TibacoCertification/tibaco.jks"));
//		System.setProperty("javax.net.ssl.trustStorePassword",
//				AppConfig.config.getString("trust_password", "password"));
//		System.setProperty(
//				"javax.net.ssl.keyStore",
//				AppConfig.config
//						.getString(
//								"key_store",
//								"/home/vccuser/development/apache-tomcat-7.0.30/bin/TibacoCertification/tibaco.jks"));
//		System.setProperty("javax.net.ssl.keyStorePassword",
//				AppConfig.config.getString("key_store_password", "password"));
//	}
//	
//
	public static void main(String[] args) {
		SpringApplication.run(VccCrmClientRestApiApplication.class, args);
	}

}
