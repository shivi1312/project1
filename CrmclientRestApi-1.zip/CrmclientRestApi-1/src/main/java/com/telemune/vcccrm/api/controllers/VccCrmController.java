package com.telemune.vcccrm.api.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.vcccrm.api.models.ProfileRequest;
import com.telemune.vcccrm.api.models.ProfileResponse;
import com.telemune.vcccrm.api.services.RequestReaderService;

@RestController
@RequestMapping("/api/v1")
public class VccCrmController {
	
	@Autowired
	private RequestReaderService readerService;
	
	
	
	
	@PostMapping("/createOrder")
	public ResponseEntity<ProfileResponse> createOrder(@RequestBody ProfileRequest profileRequest	){
		ProfileResponse profileResponse = this.readerService.createOrder(profileRequest, null);	
		return new ResponseEntity<>(profileResponse,HttpStatus.CREATED);
	}

}
