package com.telemune;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrmclientRestApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(CrmclientRestApi1Application.class, args);
	}

}
