package com.telemune.vcc;

import java.sql.Connection;

import org.apache.log4j.Logger;

/**
 * THIS CLASS IS FOR HANDLING DATA RECEIVED FOR OBD
 * 
 * @author swati
 * 
 */
public class OBDProcessor implements Runnable {
	static Logger logger = Logger.getLogger(RequestProcessor.class);
	public DataObjectBean dataObjectBean = null;
	Connection con = Global.conPool.getConnection();
	public DBHandler dbHandler = null;

	/**
	 * THIS IS THE RUN METHOD OF THIS THREAD
	 */
	public void run() {
		logger.debug("##>> OBDProcessor Thread STARTED...");
		while (true) {
			if (Global.obdProcessorQueue.isEmpty()) {
				try {
					logger.debug("OBD Process queue is empty");
					logger.debug("##>> OBDProcessor Thread going to SLEEP...");
					Thread.sleep(1000);
				} catch (Exception e) {
					logger.error("Excption inside SMSProcessor class when thread is going to sleep"
							+ e.getMessage()); // TODO: handle exception
				}
			} else {
				try {
					dbHandler = new DBHandler();
					dataObjectBean = Global.obdProcessorQueue.poll();
					int result = dbHandler.insertOBDRequest(dataObjectBean);
					if (result < 0) {
						logger.error("Theer is any error when insert record into DataBase for OBD");
					}
				} catch (Exception e) {
					logger.error("Exception inside OBDProcessor class"
							+ e.getMessage()); // TODO: handle exception
				}
			}
		}
	}

}
