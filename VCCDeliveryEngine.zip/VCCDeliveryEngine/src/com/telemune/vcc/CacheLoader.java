package com.telemune.vcc;

import org.apache.log4j.Logger;

public class CacheLoader implements Runnable {
	/**
	 * 
	 * THIS IS THE PARAMETERIZED CONSTRUCTOR OF CACHELOADER CLASS IN WHCIH WE
	 * ARE INITIALIZE THE SLEEP TIME OF THIS THREAD
	 * 
	 * @param sl
	 *            :- REPRESENT THE SLEEP TIME
	 * 
	 */
	int sleeptime = 30;

	Logger logger = Logger.getLogger(CacheLoader.class);
	Logger errorLogger = Logger.getLogger("errorLogger");

	/**
	 * THIS IS THE RUN METHOD OF CACHELOADER THREAD WHICH CALLS RELOAD METHOD OF
	 * VCCCONFIG CLASS
	 */

	public void run() {
		logger.debug("##>> CacheLoader Thread STARTED...");
		while (true) {
			logger.debug("Running Cache Loader Thread........");
			try {
//				Thread.sleep(Global.RELOADTIME * 1000);
				VCCConfiguration.getInstance().reLoad();
				Global.cacheLoadedSuccessfully=true;
				logger.debug("##>> CacheLoader Thread going to SLEEP...");
				Thread.sleep(Global.RELOADTIME * 1000);
			} catch (Exception e) {
				errorLogger.error("ErrorCode[" + Global.errorcode_pattern
						+ "00009] [Exception in CacheLoader] Error["
						+ e.getMessage() + "]");
				logger.error("Exception in cacheloader .........", e);

			}

		}
	}
}
