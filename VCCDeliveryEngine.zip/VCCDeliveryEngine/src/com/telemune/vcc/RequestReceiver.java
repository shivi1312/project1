package com.telemune.vcc;

import java.sql.SQLException;

import org.apache.log4j.Logger;

/**
 * THIS CLASS IS FOR CHECK DELIVERY TYPE AND SEND DATA INTO QUEUE ACCORDING TO
 * DELIVERY TYPE AND SEND DATA TO UPDATION QUEUE
 * 
 * @author swati
 * 
 */

public class RequestReceiver implements Runnable {
	static Logger logger = Logger.getLogger(RequestReceiver.class);
	static Logger errorLogger = Logger.getLogger("errorLogger");

	public DataObjectBean dataObjectBean = null;

	/**
	 * THIS IS THE RUN METHOD OF THIS THREAD
	 */
	public void run() {
		logger.debug("##>> RequestReceiver Thread STARTED...");
		while (true)
			if (Global.request_que.isEmpty()) {
				try {
					logger.debug("Inside condition when request_que is empty and thread is going to sleep for 1 second");
					logger.debug("##>> RequestReceiver Thread going to SLEEP...");
					Thread.sleep(1000);
				} catch (Exception e) {
					errorLogger
							.error("ErrorCode["
									+ Global.errorcode_pattern
									+ "00031] [Exception in RequestReceiver class when Thread is going to sleep] Error["
									+ e.getMessage() + "]");
					/*
					 * logger.error(
					 * "Excption inside RequestReceiver class when thread is going to sleep"
					 * + e.getMessage());
					 */// TODO: handle exception
				}
			} else {
				executeProcess();
			}
	}

	/**
	 * THIS FUNCTION IS FOR CHECKING SUBTYPE AND DELIVERY TYPE OF DATA AND SEND
	 * IT FOR FURTHER PROCESSING
	 */
	public void executeProcess() {
		logger.debug("Inside execute function and request_que size is ["
				+ Global.request_que.size() + "]");
		int vmMMSEnable = 1;
		int vmMailEnable = 1;
		int vnMMSEnable = 1;
		int vnMailEnable = 1;
		int vmDefaultDelivery = 1;
		int vnDefaultDelivery = 1;
		try {
			vmMMSEnable = Integer.parseInt(VCCConfiguration.getInstance()
					.GetAppConfigParam("VM_MMS_ENABLE"));
			vmMailEnable = Integer.parseInt(VCCConfiguration.getInstance()
					.GetAppConfigParam("VM_MAIL_ENABLE"));
			vnMMSEnable = Integer.parseInt(VCCConfiguration.getInstance()
					.GetAppConfigParam("VN_MMS_ENABLE"));
			vnMailEnable = Integer.parseInt(VCCConfiguration.getInstance()
					.GetAppConfigParam("VN_MAIL_ENABLE"));

			vmDefaultDelivery = Integer.parseInt(VCCConfiguration.getInstance()
					.GetAppConfigParam("VM_DEFAULT_DELIVERY"));

			vnDefaultDelivery = Integer.parseInt(VCCConfiguration.getInstance()
					.GetAppConfigParam("VM_DEFAULT_DELIVERY"));

			dataObjectBean = Global.request_que.poll();
			Global.requestProcessque.put(dataObjectBean);
			logger.info("Inside executeProcess() service type is ["
					+ dataObjectBean.getServiceType()
					+ "] and delivery interface is ["
					+ dataObjectBean.getDeliveryInterface()
					+ "] and destination number is ["
					+ dataObjectBean.getDestinationNumber() + "]");
			if (dataObjectBean.getSub_type().equalsIgnoreCase("F")) {
				logger.debug("Inside condition when sub type is F and insert record into OBD queue");
				dataObjectBean.setDeliveryInterface(Global.OBD);
				Global.obdProcessorQueue.put(dataObjectBean);
			} else {

				if (dataObjectBean.getServiceType().equalsIgnoreCase("0010")) {
					if (dataObjectBean.getDeliveryInterface() == Global.SMS) {
						Global.smsProcessorQueue.put(dataObjectBean);
					} else if (dataObjectBean.getDeliveryInterface() == Global.OBD)
						Global.obdProcessorQueue.put(dataObjectBean);

					else if (dataObjectBean.getDeliveryInterface() == Global.MMS) {
						if (vmMMSEnable == 1) {
							Global.mmsProcessorQueue.put(dataObjectBean);
						} else {
							checkDefaultDelivery(vmDefaultDelivery,
									dataObjectBean);
						}
					} else if (dataObjectBean.getDeliveryInterface() == Global.MAIL) {
						if (vmMailEnable == 1) {
							Global.emailProcessorQueue.put(dataObjectBean);
						} else {
							checkDefaultDelivery(vmDefaultDelivery,
									dataObjectBean);
						}
					} else {
						logger.info("Delivery interface is not exist for VM service");
					}
				} else if (dataObjectBean.getServiceType().equalsIgnoreCase(
						"0100")) {
					if (dataObjectBean.getDeliveryInterface() == Global.SMS) {
						Global.smsProcessorQueue.put(dataObjectBean);
					} else if (dataObjectBean.getDeliveryInterface() == Global.OBD)
						Global.obdProcessorQueue.put(dataObjectBean);

					else if (dataObjectBean.getDeliveryInterface() == Global.MMS) {
						if (vnMMSEnable == 1) {
							Global.mmsProcessorQueue.put(dataObjectBean);
						} else {
							checkDefaultDelivery(vnDefaultDelivery,
									dataObjectBean);
						}
					} else if (dataObjectBean.getDeliveryInterface() == Global.MAIL) {
						if (vnMailEnable == 1) {
							Global.emailProcessorQueue.put(dataObjectBean);
						} else {
							checkDefaultDelivery(vnDefaultDelivery,
									dataObjectBean);
						}
					} else {
						logger.info("Delivery interface is not exist for VN Service");
					}
				}
			}
		} catch (NumberFormatException nfe) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90004] [NumberFormatException inside executeProcess() function] Error["
							+ nfe.getMessage() + "]");

		} catch (Exception e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00032] [Exception inside executeProcess() function] Error["
							+ e.getMessage() + "]");
			// logger.error("Exception inside executeProcess()"+e.getMessage());
			e.printStackTrace();// TODO: handle exception
		}
	}

	/**
	 * THIS FUNCTION IF FOR CHECK DEFAULT DELIVERY TYPE
	 * 
	 * @param deliveryType
	 *            :-THIS REFERS TO DELIVERY TYPE OF DATA
	 * @param dataObjectBean
	 *            :- THIS REFERS TO DATA RECEIVING FROM USER
	 */
	public void checkDefaultDelivery(int deliveryType,
			DataObjectBean dataObjectBean) {
		logger.info("Inside checkDefaultDelivery() and delivery type is ["
				+ deliveryType + "]");
		try {

			switch (deliveryType) {
			case 1:
				dataObjectBean.setDeliveryInterface(Global.SMS);
				Global.smsProcessorQueue.put(dataObjectBean);
				break;
			case 2:
				dataObjectBean.setDeliveryInterface(Global.OBD);
				Global.obdProcessorQueue.put(dataObjectBean);
				break;
			case 3:
				dataObjectBean.setDeliveryInterface(Global.MMS);
				Global.mmsProcessorQueue.put(dataObjectBean);
				break;
			case 4:
				dataObjectBean.setDeliveryInterface(Global.MAIL);
				Global.emailProcessorQueue.put(dataObjectBean);
			default:
				logger.info("Inside default condition");
				break;
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00033] [Exception in switch cases while finding Delivery Type] Error["
							+ e.getMessage() + "]");

			// logger.error("Exception inside switch case to find delivery type");//
			// TODO: handle exception

		}
	}

}