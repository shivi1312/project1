package com.telemune.vcc;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;

import oracle.sql.DATE;

import org.apache.log4j.Logger;

/**
 * THIS CLASS IS FOR HANDLING DATA HAVING DELIVERY TYPE SMS
 * 
 * @author swati
 * 
 */
public class SMSProcessor implements Runnable {
	static Logger logger = Logger.getLogger(SMSProcessor.class);
	static Logger errorLogger = Logger.getLogger("errorLogger");
	public DataObjectBean dataObjectBean = null;
	public DBHandler dbHandler = null;
	Hashtable<String, String> replace = new Hashtable<String, String>();

	/**
	 * THIS IS THE RUN METHOD OF THIS THREAD
	 */
	public void run() {
		logger.info("##>> SMSProcessor Thread STARTED...");
		while (true) {
			try {
				if (Global.smsProcessorQueue.isEmpty()) {
					try {
						logger.debug("SMS Process queue is empty");
						logger.debug("##>> SMSProcessor Thread going to SLEEP...");
						Thread.sleep(1000);
					} catch (Exception e) {
						errorLogger
								.error("ErrorCode["
										+ Global.errorcode_pattern
										+ "00034] [Exception in SMSProcessor class when Thread is going to sleep] Error["
										+ e.getMessage() + "]");
						/*
						 * logger.error(
						 * "Excption inside SMSProcessor class when thread is going to sleep"
						 * + e.getMessage());
						 */// TODO:
							// handle
							// exception
					}
				} else {
					String templateId = "-1";
					int totalCount = -1;
					dbHandler = new DBHandler();
					dataObjectBean = Global.smsProcessorQueue.poll();
/*					String lang_id = VCCConfiguration.getInstance()
							.GetAppConfigParam("vms_default_language");
*/					String senderId = "";
					int lang_id = dataObjectBean.getLang();// Added by Abhishek Rana to changing template according to language
					
					if(lang_id==0){
						lang_id = Integer.parseInt(VCCConfiguration.getInstance()
								.GetAppConfigParam("vms_default_language"));
					}
					if (dataObjectBean.getServiceType()
							.equalsIgnoreCase("0010")) {

						int vmcallPartyEnable = Integer
								.parseInt(VCCConfiguration.getInstance()
										.GetAppConfigParam("VM_SMS_SENDER_CPN"));
						if (vmcallPartyEnable == 0) {
							senderId = VCCConfiguration.getInstance()
									.GetAppConfigParam("VM_SMS_NUMBER");
							// dataObjectBean.setOriginationNumber(VCCConfiguration.getInstance().GetAppConfigParam("VM_SMS_NUMBER"));

						} else {
							senderId = dataObjectBean.getOriginationNumber();
						}
						if (Global.vm_count_enable == 1) {
						//	totalCount = dbHandler.getNotificationCount(dataObjectBean.getDestinationNumber(),dataObjectBean.getServiceType());
									
									totalCount=dbHandler.getNotificationCount(dataObjectBean.getOrgNumber(),dataObjectBean.getServiceType());
							templateId = VCCConfiguration.getInstance()
									.GetAppConfigParam("VM_COUNT_TEMP_ID");

						} else {
							templateId = VCCConfiguration.getInstance()
									.GetAppConfigParam("VM_TEMP_ID");
						}
					} else if (dataObjectBean.getServiceType()
							.equalsIgnoreCase("0100")) {

						int vncallPartyEnable = Integer
								.parseInt(VCCConfiguration.getInstance()
										.GetAppConfigParam("VN_SMS_SENDER_CPN"));
						if (vncallPartyEnable == 0) {
							senderId = VCCConfiguration.getInstance()
									.GetAppConfigParam("VN_SMS_NUMBER");

							// dataObjectBean.setOriginationNumber(VCCConfiguration.getInstance().GetAppConfigParam("VN_SMS_NUMBER"));
						} else {
							senderId = dataObjectBean.getOriginationNumber();
						}
						if (Global.vn_count_enable == 1) {
							/*totalCount = dbHandler.getNotificationCount(
									dataObjectBean.getDestinationNumber(),
									dataObjectBean.getServiceType());*/
							totalCount=dbHandler.getNotificationCount(dataObjectBean.getOrgNumber(),dataObjectBean.getServiceType());
							templateId = VCCConfiguration.getInstance()
									.GetAppConfigParam("VN_COUNT_TEMP_ID");
						} else {
							templateId = VCCConfiguration.getInstance()
									.GetAppConfigParam("VN_TEMP_ID");
						}
					}
					//Added by abhishek rana on 06-06-2017
					String formattedDate="";
					try{
						 SimpleDateFormat srcFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						 Date date = srcFormatter.parse(dataObjectBean.getCallTime());
						 SimpleDateFormat destFormatter = new SimpleDateFormat("dd MMM yyyy hh:mm a");
						 formattedDate= destFormatter.format(date);
					}
					catch(Exception e){
						e.printStackTrace();
					}
					replace.clear();
					replace.put("$(Aparty)",
							dataObjectBean.getOriginationNumber());
					replace.put("$(Bparty)",
							dataObjectBean.getDestinationNumber());
					replace.put("$(msgIndex)",
							dataObjectBean.getLocalMessageIndex() + "");
					replace.put("$(duration)",
							dataObjectBean.getRecordDuration() + "");
					//replace.put("$(callTime)", dataObjectBean.getCallTime());
					replace.put("$(callTime)", formattedDate);
					replace.put("$(count)", totalCount + "");

					logger.info("template id " + templateId + "total count "
							+ totalCount + "sender id" + senderId);

					int result = dbHandler.insertSMSRequest(dataObjectBean,
							templateId + "-" + lang_id, replace, senderId);
					if (result < 0) {
						errorLogger
								.error("ErrorCode["
										+ Global.errorcode_pattern
										+ "00036] Originaton Number["
										+ dataObjectBean.getOriginationNumber()
										+ "] Destination Number["
										+ dataObjectBean.getDestinationNumber()
										+ "] [There is some error while inserting record into Database for SMS]");
						logger.info("Theer is any error when insert record into DataBase for SMS");
					}
				}
			} catch (NumberFormatException nfe) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "90004] Originaton Number["
								+ dataObjectBean.getOriginationNumber()
								+ "] Destination Number["
								+ dataObjectBean.getDestinationNumber()
								+ "] [NumberFormat Exception in SMSProcessor Thread] Error["
								+ nfe.getMessage() + "]");
			} catch (Exception ex) {
				errorLogger.error("ErrorCode[" + Global.errorcode_pattern
						+ "00035] Originaton Number["
						+ dataObjectBean.getOriginationNumber()
						+ "] Destination Number["
						+ dataObjectBean.getDestinationNumber()
						+ "] [Exception in SMSProcessor Thread] Error["
						+ ex.getMessage() + "]");
				/*
				 * logger.error("Exception inside SMSProcessor Thread" +
				 * ex.getMessage());
				 */// TODO:
				ex.printStackTrace(); // handle
										// exception
			}
		}
	}

}
