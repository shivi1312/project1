package com.telemune.vcc;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.commons.lang.StringUtils;

/**
 * THIS FUNCTION IS FOR READ REQUESTED DATA FROM DATA BASE AND SEND FRO FURTHER
 * PROCESSING
 * 
 * @author swati
 * 
 */

public class RequestReader implements Runnable {
	static Logger logger = Logger.getLogger(RequestReader.class);
	static Logger errorLogger = Logger.getLogger("errorLogger");
	public DataObjectBean dataObjectBean = null;

	Connection con = null;
	static int maxLocalId = 0;

	/**
	 * THIS IS THE RUN METHOD OF THIS THREAD
	 */

	public void run() {
		logger.debug("##>> RequestReader Thread STARTED...");
		while (true) {
			try {
				loadRequestedData();
				checkProcess();
				logger.debug("##>> RequestReader Thread going to SLEEP...");
				Thread.sleep(10000);
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00026] [Exception in RequestReader class when Thread is going to sleep] Error["
								+ e.getMessage() + "]");
				/*
				 * logger.error("Exception inside RequestReader Thread sleep method"
				 * + e.getMessage());
				 */// TODO: handle exception
			}
		}
	}

	/**
	 * THIS FUNCTION IS FOR LOAD DATA FROM DATABASE WHOSE STATUS IS N
	 */

	public void loadRequestedData() {
		logger.debug("Inside condition loadRequestData()");
		ResultSet rs = null;
		String query = null;
		PreparedStatement pstmt = null;

		try {
			con = Global.conPool.getConnection();
			// query =
			// "select ORIGINATION_NUMBER,DESTINATION_NUMBER,SERVICE_TYPE,CALL_TIME,DELIVERY_INTERFACE,CLASS_TYPE,SUB_TYPE,RATE_PLAN,VOICE_MSG_INDEX,LANGUAGE,LOCAL_MSG_INDEX,RECORD_DURATION from VCC_NOTIFICATION where STATUS='N' and VOICE_MSG_INDEX > ?";
			// // N
			query = "select ORIGINATION_NUMBER,DESTINATION_NUMBER,SERVICE_TYPE,CALL_TIME,DELIVERY_INTERFACE,CLASS_TYPE,SUB_TYPE,RATE_PLAN,VOICE_MSG_INDEX,LANGUAGE,LOCAL_MSG_INDEX,RECORD_DURATION,ORIGINAL_NUMBER from VCC_NOTIFICATION where STATUS='N' and VOICE_MSG_INDEX > ?"; // For
			// New
			// Status....
			pstmt = con.prepareStatement(query);
			logger.info("Max Index id is [" + maxLocalId + "]");
			pstmt.setInt(1, maxLocalId);
			logger.info("Inside loadRequestData() and Query [" + query + " ]");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				if (!StringUtils.isEmpty(rs.getString("ORIGINATION_NUMBER"))
						&& !StringUtils.isEmpty(rs
								.getString("DESTINATION_NUMBER"))
						&& !StringUtils.isEmpty(rs.getString("CALL_TIME"))
						&& (rs.getInt("DELIVERY_INTERFACE") > 0)) {
					dataObjectBean = new DataObjectBean();
					dataObjectBean.setOriginationNumber(rs
							.getString("ORIGINATION_NUMBER"));
					dataObjectBean.setDeliveryInterface(rs
							.getInt("DELIVERY_INTERFACE"));
					dataObjectBean.setDestinationNumber(rs
							.getString("DESTINATION_NUMBER"));
					dataObjectBean.setServiceType(rs.getString("SERVICE_TYPE"));
					dataObjectBean.setCallTime(rs.getString("CALL_TIME"));
					dataObjectBean.setLocalMessageIndex(rs
							.getInt("LOCAL_MSG_INDEX"));
					dataObjectBean.setSub_type(rs.getString("SUB_TYPE"));
					dataObjectBean.setRatePlan(rs.getInt("RATE_PLAN"));
					dataObjectBean.setClassType(rs.getString("CLASS_TYPE"));
					dataObjectBean.setLang(rs.getInt("LANGUAGE"));
					dataObjectBean
							.setOrgNumber(rs.getString("ORIGINAL_NUMBER"));
					dataObjectBean.setVoiceMsgIndex(rs
							.getInt("VOICE_MSG_INDEX"));
					dataObjectBean.setRecordDuration(rs
							.getString("RECORD_DURATION"));

					Global.request_que.put(dataObjectBean);
				} else {
					errorLogger
							.error("ErrorCode["
									+ Global.errorcode_pattern
									+ "00028] [Some parameters are missing in VCC_NOTIFICATION while getting data having status N]");
					logger.info("There is some missing parameters in VCC_NOTIFICATION table when we are getting data having status N");
				}
			}
			pstmt.close();
			rs.close();
			pstmt = null;
			rs = null;
			query = "Select max(VOICE_MSG_INDEX) as MAXID from VCC_NOTIFICATION";
			pstmt = con.prepareStatement(query);
			logger.debug("Query is [ " + query + " ]");
			rs = pstmt.executeQuery();
			if (rs.next()) {
				maxLocalId = rs.getInt("MAXID");
			}

		} catch (SQLException se) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90001] [SQLException while getting data from VCC_NOTIFICATION having Status N] Error["
							+ se.getMessage() + "]");

		} catch (Exception e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00027] [Exception while getting data from VCC_NOTIFICATION having Status N] Error["
							+ e.getMessage() + "]");
			/*
			 * logger.info("Exception inside loadRequestData()" +
			 * e.getMessage());
			 */
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
			} catch (Exception ex) {
				logger.error("Exception inside loadrequestedData()"
						+ ex.getMessage()); // TODO: handle exception
			}
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in loadrequestedData() function] Error["
								+ e.getMessage() + "]");
				/*
				 * logger.error(
				 * "Exception inside loadrequestedData() when resources are closed"
				 * );
				 */// TODO:
					// handle
					// exception
			}
		}
	}

	/**
	 * THIS FUNCTION IS FOR RETRY SENDING DATA WHICH HAVE STATUS S
	 */
	public void checkProcess() {
		logger.info("Inside checkProcess() of class RequestReader");

		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss");
		Date date = null;
		String newTime = null;
		ResultSet rs = null;
		String query = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		int maxRetryCount = 3;
		try {
			con = Global.conPool.getConnection();
			maxRetryCount = Integer.parseInt(VCCConfiguration.getInstance()
					.GetAppConfigParam("RETRY_COUNT"));
			query = "select ORIGINATION_NUMBER,DESTINATION_NUMBER,SERVICE_TYPE,CALL_TIME,DELIVERY_INTERFACE,CLASS_TYPE,SUB_TYPE,RATE_PLAN,VOICE_MSG_INDEX,UPDATE_TIME,RETRY_COUNT,LANGUAGE,LOCAL_MSG_INDEX,RECORD_DURATION from VCC_NOTIFICATION where STATUS='S'";

			pstmt = con.prepareStatement(query);
			logger.debug("Inside CheckProcess() and Query [" + query + " ]");
			rs = pstmt.executeQuery();

			while (rs.next()) {
				int retry_count = 0;
				try {
					if (!StringUtils
							.isEmpty(rs.getString("ORIGINATION_NUMBER"))
							&& !StringUtils.isEmpty(rs
									.getString("DESTINATION_NUMBER"))
							&& !StringUtils.isEmpty(rs.getString("CALL_TIME"))
							&& (rs.getInt("DELIVERY_INTERFACE") > 0)) {
						String updateTime = rs.getString("UPDATE_TIME");
						date = (Date) dateFormat.parse(updateTime);
						Calendar cal = Calendar.getInstance();
						cal.setTime(date);
						cal.add(Calendar.MINUTE, Global.Time);
						newTime = dateFormat.format(cal.getTime());
						if (newTime.compareTo(updateTime) > 0) {
							dataObjectBean = new DataObjectBean();
							dataObjectBean.setOriginationNumber(rs
									.getString("ORIGINATION_NUMBER"));
							dataObjectBean.setDeliveryInterface(rs
									.getInt("DELIVERY_INTERFACE"));
							dataObjectBean.setDestinationNumber(rs
									.getString("DESTINATION_NUMBER"));
							dataObjectBean.setServiceType(rs
									.getString("SERVICE_TYPE"));
							dataObjectBean.setCallTime(rs
									.getString("CALL_TIME"));
							dataObjectBean.setLocalMessageIndex(rs
									.getInt("LOCAL_MSG_INDEX"));
							dataObjectBean
									.setSub_type(rs.getString("SUB_TYPE"));
							dataObjectBean.setRatePlan(rs.getInt("RATE_PLAN"));
							dataObjectBean.setClassType(rs
									.getString("CLASS_TYPE"));
							dataObjectBean.setLang(rs.getInt("LANGUAGE"));
							dataObjectBean.setVoiceMsgIndex(rs
									.getInt("VOICE_MSG_INDEX"));
							dataObjectBean.setRecordDuration(rs
									.getString("RECORD_DURATION"));

							if (rs.getInt("RETRY_COUNT") >= maxRetryCount) {
								logger.info("Inside condition when retry count is equal to configure retry count");
								dataObjectBean.setDeliveryInterface(Global.SMS);
							} else {
								retry_count = rs.getInt("RETRY_COUNT");
								retry_count = retry_count + 1;
								logger.debug("Value of retry count is"
										+ retry_count
										+ "]  local message index is ["
										+ dataObjectBean.getLocalMessageIndex()
										+ "]");
								query = "update VCC_NOTIFICATION set RETRY_COUNT=? where VOICE_MSG_INDEX=?";
								pstmt1 = con.prepareStatement(query);
								pstmt1.setInt(1, retry_count);
								pstmt1.setInt(2,
										dataObjectBean.getLocalMessageIndex());
								pstmt1.executeUpdate();
								pstmt1.close();
							}
							Global.request_que.put(dataObjectBean);
						}
					} else {
						errorLogger
								.error("ErrorCode["
										+ Global.errorcode_pattern
										+ "00029] [Some parameters are missing in VCC_NOTIFICATION while getting data having status S]");
						logger.info("There is some missing parameters in VCC_NOTIFICATION table when we are getting to update status S");
					}
				} catch (SQLException se) {
					errorLogger
							.error("ErrorCode["
									+ Global.errorcode_pattern
									+ "90001] [SQLException while getting data from VCC_NOTIFICATION having Status S] Error["
									+ se.getMessage() + "]");
				} catch (Exception e) {
					errorLogger
							.error("ErrorCode["
									+ Global.errorcode_pattern
									+ "00030] [Exception while getting data from VCC_NOTIFICATION having Status S] Error["
									+ e.getMessage() + "]");

					if (pstmt1 != null)
						pstmt1.close();
					if (rs != null)
						rs.close();
					/*
					 * logger.error("Exception Inside RequestReader class" +
					 * e.getMessage());
					 */// TODO: handle exception
				}
			}
		} catch (SQLException se) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90001] [SQLException whiel getting data from VCC_NOTIFICATION having Status S] Error["
							+ se.getMessage() + "]");

		} catch (Exception e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00030] [Exception while getting data from VCC_NOTIFICATION having Status S] Error["
							+ e.getMessage() + "]");

			/*
			 * logger.error("Exception occur inside loadrequestedData()" +
			 * e.getMessage());
			 */
			e.printStackTrace();// TODO: handle exception
		}

		finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in checkProcess() function] Error["
								+ e.getMessage() + "]");
				/*
				 * logger.error(
				 * "Exception inside Finally block of checkProcess() when resources are closed"
				 * );
				 */// TODO:
					// handle
					// exception
			}
		}
	}

}
