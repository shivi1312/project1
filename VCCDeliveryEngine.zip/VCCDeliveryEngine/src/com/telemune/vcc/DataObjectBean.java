package com.telemune.vcc;

/**
 * THIS CLASS IS POJO CLASS FOR GETTING AND SETTING DATA FROM VCC_NOTIFICATION TABLE
 * @author swati
 *@version:- R1_0_0_0
 */

public class DataObjectBean {
	public String originationNumber;
	public  String destinationNumber;
	public  String serviceType;
	public  String callTime;
	public  int deliveryInterface;
	public String status;
	public int localMessageIndex;
	public int maxlocalId;
	public String sub_type;
	public int ratePlan;
	public String classType;
	public String recordDuration;
	public String msgPriority;
	public String passProtected;
	public String orgNumber;
	public int lang;
	public int voiceMsgIndex;
	public String fileName;
	public String sendTime;
	public String msgProtect;

	
	
	
	
	
	
	
	public String getMsgProtect() {
		return msgProtect;
	}
	public void setMsgProtect(String msgProtect) {
		this.msgProtect = msgProtect;
	}
	public String getSendTime() {
		return sendTime;
	}
	public void setSendTime(String sendTime) {
		this.sendTime = sendTime;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public int getVoiceMsgIndex() {
		return voiceMsgIndex;
	}
	public void setVoiceMsgIndex(int voiceMsgIndex) {
		this.voiceMsgIndex = voiceMsgIndex;
	}
	public String getRecordDuration() {
		return recordDuration;
	}
	public void setRecordDuration(String recordDuration) {
		this.recordDuration = recordDuration;
	}
	public String getMsgPriority() {
		return msgPriority;
	}
	public void setMsgPriority(String msgPriority) {
		this.msgPriority = msgPriority;
	}
	public String getPassProtected() {
		return passProtected;
	}
	public void setPassProtected(String passProtected) {
		this.passProtected = passProtected;
	}
	public String getOrgNumber() {
		return orgNumber;
	}
	public void setOrgNumber(String orgNumber) {
		this.orgNumber = orgNumber;
	}
	public int getLang() {
		return lang;
	}
	public void setLang(int lang) {
		this.lang = lang;
	}
	public String getClassType() {
		return classType;
	}
	public void setClassType(String classType) {
		this.classType = classType;
	}
	public int getRatePlan() {
		return ratePlan;
	}
	public void setRatePlan(int ratePlan) {
		this.ratePlan = ratePlan;
	}
	public String getSub_type() {
		return sub_type;
	}
	public void setSub_type(String sub_type) {
		this.sub_type = sub_type;
	}
	public int getMaxlocalId() {
		return maxlocalId;
	}
	public void setMaxlocalId(int maxlocalId) {
		this.maxlocalId = maxlocalId;
	}
	public int getLocalMessageIndex() {
		return localMessageIndex;
	}
	public void setLocalMessageIndex(int localMessageIndex) {
		this.localMessageIndex = localMessageIndex;
	}
	public String getOriginationNumber() {
		return originationNumber;
	}
	public void setOriginationNumber(String originationNumber) {
		this.originationNumber = originationNumber;
	}
	public String getDestinationNumber() {
		return destinationNumber;
	}
	public void setDestinationNumber(String destinationNumber) {
		this.destinationNumber = destinationNumber;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getCallTime() {
		return callTime;
	}
	public void setCallTime(String callTime) {
		this.callTime = callTime;
	}
	public int getDeliveryInterface() {
		return deliveryInterface;
	}
	public void setDeliveryInterface(int deliveryInterface) {
		this.deliveryInterface = deliveryInterface;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "DataObjectBean [originationNumber=" + originationNumber
				+ ", destinationNumber=" + destinationNumber + ", serviceType="
				+ serviceType + ", callTime=" + callTime
				+ ", deliveryInterface=" + deliveryInterface + ", status="
				+ status + ", localMessageIndex=" + localMessageIndex
				+ ", maxlocalId=" + maxlocalId + ", sub_type=" + sub_type + ", ratePlan="+ratePlan+"]";
	}
	

}
