package com.telemune.vcc;

import java.sql.Connection;

import org.apache.log4j.Logger;

/**
 * THIS CLASS IS FOR SENDING DATA FOR UPDATION INTO UPDATING QUEUE
 * 
 * @author swati
 * 
 */

public class RequestProcessor implements Runnable {
	static Logger logger = Logger.getLogger(RequestProcessor.class);
	static Logger errorLogger = Logger.getLogger("errorLogger");

	public DataObjectBean dataObjectBean = null;
	public DBHandler dbHandler = null;
	Connection con = Global.conPool.getConnection();

	/**
	 * THIS IS THE RUN METHOD OF THIS THREAD
	 */
	public void run() {
		logger.debug("##>> RequestProcessor Thread STARTED...");
		while (true)
			if (Global.requestProcessque.isEmpty()) {
				try {
					logger.debug("Request Process Queue is empty");
					logger.debug("##>> RequestProcessor Thread going to SLEEP...");
					Thread.sleep(1000);
				} catch (Exception e) {
					errorLogger
							.error("ErrorCode["
									+ Global.errorcode_pattern
									+ "00024] [Exception in RequestProcessor class when Thread is going to sleep] Error["
									+ e.getMessage() + "]");
					logger.error("Excption inside RequestProcessing class when thread is going to sleep"
							+ e.getMessage()); // TODO: handle exception
				}
			} else {

				updateRequest();
			}
	}

	/**
	 * THIS FUNCTION IS FOR FETCH DATA FROM PROCESS QUEUE AND SEND REQUEST TO
	 * DATA BASE FOR UPDATION
	 */
	public void updateRequest() {
		try {
			dataObjectBean = Global.requestProcessque.poll();
			logger.info("Inside updateRequest() and updating data is [ "
					+ dataObjectBean.toString() + " ]");
			dbHandler = new DBHandler();

			logger.debug("Inside updateRequest function which will fetch data from queue and update data");

			if (dataObjectBean.getDeliveryInterface() == Global.SMS
					|| dataObjectBean.getDeliveryInterface() == Global.OBD) {
				int i = dbHandler.updateDeliveryStatus(
						dataObjectBean.getVoiceMsgIndex(), "P", -1);
				if (i < 0) {
					logger.info("There is any error when update data into VCC_NOTIFICATION in case of SMS or OBD");
				}
			} else if (dataObjectBean.getDeliveryInterface() == Global.MMS
					|| dataObjectBean.getDeliveryInterface() == Global.MAIL) {
				int j = dbHandler.updateDeliveryStatus(
						dataObjectBean.getVoiceMsgIndex(), "S", -1);
				if (j < 0) {
					logger.info("There is any error when update data into VCC_NOTIFICATION in case of MMS or Email");
				}
			} else
				logger.info("There is no data exist inside VCC_NOTIFICATION table");

		} catch (Exception e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00025] [Exception inside updateRequest() while updating delivery Status] Error["
							+ e.getMessage() + "]");
			logger.error("Exception inside updateRequest()" + e.getMessage());
			e.printStackTrace();
		}
	}
}
