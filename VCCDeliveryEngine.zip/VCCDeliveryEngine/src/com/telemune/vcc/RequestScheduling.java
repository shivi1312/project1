package com.telemune.vcc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

public class RequestScheduling implements Runnable {
	static Logger logger = Logger.getLogger(RequestScheduling.class);
	static Logger errorLogger = Logger.getLogger("errorLogger");

	public DataObjectBean dataObjectBean = null;
	Connection con = null;
	DBHandler dbHandler = new DBHandler();
	/**
	 * THIS IS THE RUN METHOD OF THIS THREAD
	 */
	int retVal = -1;

	public void run() {
		logger.debug("##>> RequestScheduling Thread STARTED...");
		while (true) {
			try {
				retVal = getScheduleData();
				if (retVal < 0) {
					logger.info("There is any error in getRecord from VCC_VOICE_MSG_SCHEDULING");
				}
				logger.debug("##>> RequestScheduling Thread going to SLEEP...");
//				Thread.sleep(3000 / 100);
				Thread.sleep(3000);
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00024] [Exception in RequestScheduler class when Thread is going to sleep] Error["
								+ e.getMessage() + "]");

				/*
				 * logger.error(
				 * "Exception inside RequestScheduler Thread sleep method" +
				 * e.getMessage());
				 */// TODO: handle exception
			}
		}
	}

	/**
	 * THIS Function LOAD DATA FROM DATA BASE ACCORDING TO MESSAGE SCHEDULE
	 * 
	 * @return
	 */
	public int getScheduleData() {
		logger.debug("Inside condition getScheduleData()");
		ResultSet rs = null;
		String query = null;
		PreparedStatement pstmt = null;
		int getVal = -1;
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String currentTime = dateFormat.format(date);
		logger.info("Current time is [" + currentTime + "]");
		try {
			con = Global.conPool.getConnection();
			query = "select ORIGINATION_NUMBER,DESTINATION_NUMBER,SERVICE_TYPE,CALL_TIME,RECORDING_DURATION,MSG_PRIORITY,ORIGINAL_NUMBER,LANGUAGE,DELIVERY_INTERFACE,CLASS_TYPE,SUB_TYPE,RATE_PLAN,FILENAME,SENDING_TIME,MSG_PROTECT,PASS_PROTECTED from VCC_VOICE_MSG_SCHEDULING where SENDING_TIME<='"
					+ currentTime + "'";
			pstmt = con.prepareStatement(query);
			logger.info("Inside getScheduleData() and Query [" + query + " ]");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				dataObjectBean = new DataObjectBean();
				dataObjectBean.setOriginationNumber(rs
						.getString("ORIGINATION_NUMBER"));
				dataObjectBean.setDeliveryInterface(rs
						.getInt("DELIVERY_INTERFACE"));
				dataObjectBean.setDestinationNumber(rs
						.getString("DESTINATION_NUMBER"));
				dataObjectBean.setServiceType(rs.getString("SERVICE_TYPE"));
				dataObjectBean.setCallTime(rs.getString("CALL_TIME"));
				dataObjectBean.setSub_type(rs.getString("SUB_TYPE"));
				dataObjectBean.setRatePlan(rs.getInt("RATE_PLAN"));
				dataObjectBean.setClassType(rs.getString("CLASS_TYPE"));
				dataObjectBean.setRecordDuration(rs
						.getString("RECORDING_DURATION"));
				dataObjectBean.setMsgPriority(rs.getString("MSG_PRIORITY"));

				dataObjectBean.setOrgNumber(rs.getString("ORIGINAL_NUMBER"));
				dataObjectBean.setLang(rs.getInt("LANGUAGE"));
				dataObjectBean.setFileName(rs.getString("FILENAME"));
				dataObjectBean.setSendTime(rs.getString("SENDING_TIME"));
				dataObjectBean.setMsgProtect(rs.getString("MSG_PROTECT"));
				dataObjectBean.setPassProtected(rs.getString("PASS_PROTECTED"));

				Global.requestScheduleque.put(dataObjectBean);
			}

			logger.info("Size of queue is " + Global.requestScheduleque.size());
			pstmt.close();
			rs.close();
			pstmt=null;
			rs=null;
			
			getVal = insertintoVcc(con);
			if (getVal < 1) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00038] Origination Number["
								+ dataObjectBean.getOriginationNumber()
								+ "] Destination Numebr["
								+ dataObjectBean.getDestinationNumber()
								+ "] [Any Error Occured in inserting data into vcc_notification]");
				// logger.info("There is any error in insert entry into vcc_notification table");
				return -1;
			}

			query = "delete from VCC_VOICE_MSG_SCHEDULING where SENDING_TIME<='"
					+ currentTime + "'";
			pstmt = con.prepareStatement(query);
			logger.debug("query is [" + query + "]");
			pstmt.executeUpdate();
			pstmt.close();
			return 1;

		} catch (SQLException se) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "90001] Origination Number["
							+ dataObjectBean.getOriginationNumber()
							+ "] Destination Numebr["
							+ dataObjectBean.getDestinationNumber()
							+ "] [SQLException occured inside getScheduleData()] Error["
							+ se.getMessage() + "]");
			return -1;
		} catch (Exception e) {
			errorLogger.error("ErrorCode[" + Global.errorcode_pattern
					+ "00039] Origination Number["
					+ dataObjectBean.getOriginationNumber()
					+ "] Destination Numebr["
					+ dataObjectBean.getDestinationNumber()
					+ "] [Exception occured inside getScheduleData()] Error["
					+ e.getMessage() + "]");

			// logger.error("Exception inside getScheduleData()" +
			// e.getMessage());
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
			} catch (Exception ex) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in getScheduleData() function] Error["
								+ ex.getMessage() + "]");
				/*
				 * logger.error("Exception inside getScheduleData()" +
				 * ex.getMessage());
				 */// TODO: handle exception
			}
			return -1;
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				errorLogger
						.error("ErrorCode["
								+ Global.errorcode_pattern
								+ "00014] [Exception While closing connection in getScheduleData() function] Error["
								+ e.getMessage() + "]");
				// logger.error("Exception inside getScheduleData() when resources are closed");
				// // TODO:
				// handle // exception
				return -1;
			}
		}
	}

	/**
	 * THIS FUMCTION INSERT DATA INTO VCC VOICE MSG ACCORDING TO TIME SCHEDULE
	 * 
	 * @param con
	 *            :-REFERS TO CONNECTION
	 * @return
	 */
	public int insertintoVcc(Connection con) {
		int localMsgIndex = 0;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		String query = null;
		Integer voiceMsgIndex = 0;
		try {
			logger.debug("Inside function insertintoVCC()");

			if (Global.requestScheduleque.isEmpty()) {
				logger.info("Schedule queue is empty");
				logger.debug("##>> RequestScheduling Thread going to SLEEP...");
				Thread.sleep(1000);
			} else {
				logger.info("Size of queue is "
						+ Global.requestScheduleque.size());
				for (int i = 0; i < Global.requestScheduleque.size(); i++) {
					dataObjectBean = Global.requestScheduleque.poll();
					try {
						int maxCapacity = VCCConfiguration
								.getInstance()
								.getMaxMessage(
										VCCConfiguration.getInstance()
												.getMailBoxId(
														dataObjectBean
																.getRatePlan()));
						logger.info("Max capacity of message box is ["
								+ maxCapacity + " ]");

						boolean status = dbHandler.deleteOldFile(
								dataObjectBean, maxCapacity);
						if (!status)
							return -1;

						logger.info("Inside function insertintoVCC() data is ["
								+ dataObjectBean + "] and size of queue is ["
								+ Global.requestScheduleque.size() + "]");
						//query = "select max(LOCAL_MSG_INDEX) as MAXINDEX from VCC_NOTIFICATION where DESTINATION_NUMBER=?";
						query="select max(LOCAL_MSG_INDEX) as MAXINDEX from VCC_NOTIFICATION where DESTINATION_NUMBER=? and SERVICE_TYPE = ?";
						pstmt = con.prepareStatement(query);
						logger.debug("query [" + query + "]");
						pstmt.setString(1,
								dataObjectBean.getDestinationNumber());
						pstmt.setString(2,dataObjectBean.getServiceType());
						rs = pstmt.executeQuery();
						if (rs.next()) {
							localMsgIndex = rs.getInt("MAXINDEX") + 1;
						}
						pstmt.close();
						rs.close();
						pstmt=null;
						rs=null;
						try {
							if (Global.dbConfigParam == 1) {
								query = "insert into VCC_VOICE_MSG (ORIGINATING_NUMBER,DESTINATION_NUMBER,FILENAME,RECORDING_DURATION,ORIGINAL_NUMBER,LOCAL_MESSAGE_INDEX,SERVICE_TYPE,CALL_TIME,MSG_PROTECT,MSG_PRIORITY,PASS_PROTECTED,SENDING_TIME) values (?,?,?,?,?,?,?,?,?,?,?,?)";
							} else if (Global.dbConfigParam == 0) {
								query = "insert into VCC_VOICE_MSG (ORIGINATING_NUMBER,DESTINATION_NUMBER,FILENAME,RECORDING_DURATION,ORIGINAL_NUMBER,LOCAL_MESSAGE_INDEX,SERVICE_TYPE,CALL_TIME,MSG_PROTECT,MSG_PRIORITY,PASS_PROTECTED,SENDING_TIME,VOICE_MESSAGE_INDEX) values (?,?,?,?,?,?,?,?,?,?,?,?,voice_msg_seq.nextval)";

							}
							logger.info("query [" + query + "]");

							pstmt = con.prepareStatement(query,
									Statement.RETURN_GENERATED_KEYS);
							pstmt.setString(1,
									dataObjectBean.getOriginationNumber());
							pstmt.setString(2,
									dataObjectBean.getDestinationNumber());
							pstmt.setString(3, dataObjectBean.getFileName());
							pstmt.setString(4,
									dataObjectBean.getRecordDuration());
							pstmt.setString(5, dataObjectBean.getOrgNumber());
							pstmt.setInt(6, localMsgIndex);
							pstmt.setString(7, dataObjectBean.getServiceType());
							pstmt.setString(8, dataObjectBean.getCallTime());
							pstmt.setString(9, dataObjectBean.getMsgProtect());
							pstmt.setString(10, dataObjectBean.getMsgPriority());
							pstmt.setString(11,
									dataObjectBean.getPassProtected());
							pstmt.setString(12, dataObjectBean.getSendTime());
							pstmt.executeUpdate();
							rs = pstmt.getGeneratedKeys();
							if (rs != null && rs.next()) {
								voiceMsgIndex = rs.getInt(1);
							}

							logger.debug("Voice msg index is#########################["
									+ voiceMsgIndex + "]");

							pstmt.close();
							rs.close();
							pstmt=null;
							rs=null;
						} catch (SQLException se) {
							errorLogger
									.error("ErrorCode["
											+ Global.errorcode_pattern
											+ "90001] [SQLException while inserting data in VCC_VOICE_MSG] Error["
											+ se.getMessage() + "]");
							se.printStackTrace();
						} catch (Exception e) {
							errorLogger
									.error("ErrorCode["
											+ Global.errorcode_pattern
											+ "00040] [Exception while inserting data in VCC_VOICE_MSG] Error["
											+ e.getMessage() + "]");
							/*
							 * logger.error(
							 * "Exception inside insert into vcc_voice_msg table"
							 * + e.getMessage());
							 */
							e.printStackTrace();// TODO: handle exception
						}
						query = "insert into VCC_NOTIFICATION (ORIGINATION_NUMBER,DESTINATION_NUMBER,SERVICE_TYPE,CALL_TIME,DELIVERY_INTERFACE,CLASS_TYPE,SUB_TYPE,RATE_PLAN,RECORD_DURATION,MSG_PRIORITY,ORIGINAL_NUMBER,LANGUAGE,LOCAL_MSG_INDEX,VOICE_MSG_INDEX,PASS_PROTECTED) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
						pstmt = con.prepareStatement(query);
						logger.info("query is [" + query + "]");
						pstmt.setString(1,
								dataObjectBean.getOriginationNumber());
						pstmt.setString(2,
								dataObjectBean.getDestinationNumber());
						pstmt.setString(3, dataObjectBean.getServiceType());
						pstmt.setString(4, dataObjectBean.getCallTime());
						pstmt.setInt(5, dataObjectBean.getDeliveryInterface());
						pstmt.setString(6, dataObjectBean.getClassType());
						pstmt.setString(7, dataObjectBean.getSub_type());
						pstmt.setInt(8, dataObjectBean.getRatePlan());
						pstmt.setString(9, dataObjectBean.getRecordDuration());
						pstmt.setString(10, dataObjectBean.getMsgPriority());
						pstmt.setString(11, dataObjectBean.getOrgNumber());
						pstmt.setInt(12, dataObjectBean.getLang());
						pstmt.setInt(13, localMsgIndex);
						pstmt.setInt(14, voiceMsgIndex);
						pstmt.setString(15, dataObjectBean.getPassProtected());
						pstmt.executeUpdate();

					} catch (SQLException se) {
						errorLogger
								.error("ErrorCode["
										+ Global.errorcode_pattern
										+ "90001] [SQLException while inserting data in VCC_NOTIFICATION] Error["
										+ se.getMessage() + "]");
						return -1;
					} catch (Exception e) {
						errorLogger
								.error("ErrorCode["
										+ Global.errorcode_pattern
										+ "00041] [Exception while inserting data in VCC_NOTIFICATION] Error["
										+ e.getMessage() + "]");
						/*
						 * logger.error(
						 * "Exception inside insert data into vcc_notification table"
						 * + e.getMessage());
						 */
						return -1;
					} finally {
						try {
							if (pstmt != null) {
								pstmt.close();

							}
						} catch (SQLException e) {
							errorLogger
									.error("ErrorCode["
											+ Global.errorcode_pattern
											+ "00014] [Exception While closing connection in insertintoVcc() function] Error["
											+ e.getMessage() + "]");
							e.printStackTrace();
							return -1;
						}
					}
				}
			}
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode["
							+ Global.errorcode_pattern
							+ "00042] [Exception inside insertintoVcc() function] Error["
							+ e.getMessage() + "]");
			logger.error("Exception inside insertintoVcc()" + e.getMessage());
			return -1;
		}
		return 1;
	}

}