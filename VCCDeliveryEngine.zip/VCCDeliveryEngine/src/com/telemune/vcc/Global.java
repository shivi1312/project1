package com.telemune.vcc;

import java.util.concurrent.ArrayBlockingQueue;

/**
 *THIS CLASS IS FOR DEFINE THE VARIALE STATICALLY AND GLOBALLY
 *@author swati
 *@version: R1_0_0_0
 */
public class Global {
	
	public static ConnPool conPool=null;
	public static int RELOADTIME=10;
	public static final int SMS=1;
	public static final int OBD=2;
	public static final int MAIL=3;
	public static final int MMS=4;
	public static String MMSAPPIP="";
	public static int MMSPORT=-1;
	public static String EMAILAPPIP="";
	public static int EMAILPORT=-1;
	public static int LOCALINDEX=1;
	public static int RESPONSE_TAG=2;
	public static int TRANACTIONID=3;
	public static int Time=-1;//Time is in minutes
	public static  ArrayBlockingQueue<DataObjectBean> smsProcessorQueue=new ArrayBlockingQueue<DataObjectBean>(100000);
	public static  ArrayBlockingQueue<DataObjectBean> obdProcessorQueue=new ArrayBlockingQueue<DataObjectBean>(100000);
	public static  ArrayBlockingQueue<DataObjectBean> mmsProcessorQueue=new ArrayBlockingQueue<DataObjectBean>(100000);
	public static  ArrayBlockingQueue<DataObjectBean> emailProcessorQueue=new ArrayBlockingQueue<DataObjectBean>(100000);
	public static  ArrayBlockingQueue<DataObjectBean> request_que=new ArrayBlockingQueue<DataObjectBean>(100000);
	public static  ArrayBlockingQueue<DataObjectBean>requestProcessque=new ArrayBlockingQueue<DataObjectBean>(100000);
	public static  ArrayBlockingQueue<DataObjectBean>requestScheduleque=new ArrayBlockingQueue<DataObjectBean>(100000);
	
	public static String ivrRecordBasePath="";
	public static int defaultRecordDigit=-1;
	public static int vm_count_enable=0;
	public static int vn_count_enable=0;
	
	
	
	public static int dbConfigParam=-1;
	
	public static String errorcode_pattern="";
	
	// These are the parameters for the HEART BEAT CHECK added by Avishkar

	public static int heartBeatPort = 6666;
	public static String heartBeatIp = "10.168.1.108";
	public static int enableHeartBeat = 0;
	public static int isActive = 0;
	public static boolean isActivateServer = true;
	public static boolean cacheLoadedSuccessfully = false;
	//public static String 0010_1_ENABLE="VM_SMS_ENABLE";
	//public static String 0010_2_ENABLE="VM_OBD_ENABLE";

}
