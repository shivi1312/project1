package com.telemune.vcccrm.api.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.squareup.okhttp.Response;
import com.telemune.vcccrm.api.config.ApiResponse;
import com.telemune.vcccrm.api.models.ProfileBean;
import com.telemune.vcccrm.api.services.VccCrmClientService;
import com.telemune.vcccrm.validator.ParameterValidator;

@RestController
@RequestMapping("/vcc_crm/api/v1")
public class VccCrmController {
	
	@Autowired
	private VccCrmClientService clientService;
	
	@Autowired
	private Environment environment;

	@PostMapping("/createOrder")
	public ResponseEntity<ApiResponse> createOrder(@RequestBody ProfileBean profileBean) {
		System.out.println(profileBean);
		System.out.println(environment.getProperty("url"));
		try {
			
	Boolean isValid = ParameterValidator.isValidForOrder(profileBean);
			
			if(!isValid) {
				return new ResponseEntity<ApiResponse>(new ApiResponse(400, "BAD_REQUEST", false, "All Parameter are required"),
						HttpStatus.BAD_REQUEST);
			}
			else {
					Response response = clientService.createOrder(profileBean);
			String responseData = response.body().string();
				Gson  gson = new Gson();
			    Object object = gson.fromJson(responseData, Object.class);
				return new ResponseEntity<ApiResponse>(new ApiResponse(201, "CREATED", true, "Order Created", profileBean),
						HttpStatus.CREATED);
			}
			
		} catch (Exception e) {
			return new ResponseEntity<ApiResponse>(new ApiResponse(500, "INTERNAL_SERVER_ERROR", false, "Server Error"),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
