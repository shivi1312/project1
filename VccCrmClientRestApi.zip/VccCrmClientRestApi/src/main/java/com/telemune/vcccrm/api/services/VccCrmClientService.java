package com.telemune.vcccrm.api.services;

import java.io.IOException;

import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;
import com.telemune.vcccrm.api.models.ProfileBean;

@Service
public class VccCrmClientService {

	public Response createOrder(ProfileBean profileBean) throws IOException {
		Gson gson = new Gson();
		String profileBeanJsonData = gson.toJson(profileBean);
		OkHttpClient client = new OkHttpClient();
		RequestBody body = RequestBody.create(MediaType.parse("application/json"), profileBeanJsonData);
		Request request = new Request.Builder().url("url").post(body).build();
		Call call = client.newCall(request);
		Response response = call.execute();
		return response;
	}
}
