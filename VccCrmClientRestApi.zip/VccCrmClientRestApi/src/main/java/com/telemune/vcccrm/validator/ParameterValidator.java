package com.telemune.vcccrm.validator;

import com.telemune.vcccrm.api.models.ProfileBean;

public class ParameterValidator {

	public static boolean isValidForOrder(ProfileBean profileBean) {
		return profileBean != null && profileBean.getAccountNo() != null && !profileBean.getAccountNo().equals("")
				&& profileBean.getAccountType() != null && !profileBean.getAccountType().equals("")
				&& profileBean.getAction() != null && !profileBean.getAction().equals("")
				&& profileBean.getOperation() != null && !profileBean.getOperation().equals("")
				&& profileBean.getServiceType() != null && !profileBean.getServiceType().equals("");
	}

}
