package com.telemune.vcccrm.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VccCrmClientRestApiApplication {
	
	
	public static void main(String[] args) {
		SpringApplication.run(VccCrmClientRestApiApplication.class, args);
	}

}
