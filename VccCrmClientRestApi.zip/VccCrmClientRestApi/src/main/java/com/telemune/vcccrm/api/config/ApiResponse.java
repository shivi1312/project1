package com.telemune.vcccrm.api.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ApiResponse {
	private int statusCode;
	private String statusMessage;
	private Boolean isSuccess;
	private String message;
	private Object data;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public Boolean getIsSuccess() {
		return isSuccess;
	}
	public void setIsSuccess(Boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	@Override
	public String toString() {
		return "ApiResponse [statusCode=" + statusCode + ", statusMessage=" + statusMessage + ", isSuccess=" + isSuccess
				+ ", message=" + message + ", data=" + data + "]";
	}
	public ApiResponse(int statusCode, String statusMessage, Boolean isSuccess, String message, Object data) {
		super();
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
		this.isSuccess = isSuccess;
		this.message = message;
		this.data = data;
	}
	public ApiResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ApiResponse(int statusCode, String statusMessage, Boolean isSuccess, String message) {
		super();
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
		this.isSuccess = isSuccess;
		this.message = message;
	}
}
