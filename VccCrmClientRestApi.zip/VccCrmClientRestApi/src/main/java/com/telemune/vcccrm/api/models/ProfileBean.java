package com.telemune.vcccrm.api.models;

public class ProfileBean {

	private String accountNo;

	private String accountType;

	private String ServiceType;

	private String Operation;

	private String Action;

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public ProfileBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProfileBean(String accountNo, String accountType, String serviceType, String operation, String action) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		ServiceType = serviceType;
		Operation = operation;
		Action = action;
	}

	@Override
	public String toString() {
		return "ProfileBean [accountNo=" + accountNo + ", accountType=" + accountType + ", ServiceType=" + ServiceType
				+ ", Operation=" + Operation + ", Action=" + Action + "]";
	}

	public String getServiceType() {
		return ServiceType;
	}

	public void setServiceType(String serviceType) {
		ServiceType = serviceType;
	}

	public String getOperation() {
		return Operation;
	}

	public void setOperation(String operation) {
		Operation = operation;
	}

	public String getAction() {
		return Action;
	}

	public void setAction(String action) {
		Action = action;
	}

}
