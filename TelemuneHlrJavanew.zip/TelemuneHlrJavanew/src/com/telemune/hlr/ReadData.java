package com.telemune.hlr;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.telemune.hlr.backend.DataObject;

/**
 * This thread read data from CRBT_HLR_INACTIVE table and put into req queue
 * @author Harjinder
 * */
public class ReadData implements Runnable{
	private Logger logger = Logger.getLogger(ReadData.class);
	private ArrayList<DataObject> pendingList = new ArrayList<DataObject>();
	
	/**
	 * It is a run method provided by Runnable interface .It define the logic to get data from database and put into
	 * request queue and goto sleep for some time.
	 * @return void
	 * */
	public void run() {
	
		while(true)
		{
		try
		{
		logger.debug("##>>> Inside ReadData");
		pendingList.clear();
		getCrbtHlrInactiveRecords(pendingList); //getting data from CRBT_HLR_INACTIVE
		if(pendingList.size() > 0)
		{
			logger.info("##>> Now going to insert all pending request into req queue...");
			for(DataObject dataObject : pendingList)
			{
				Global.req_queue.put(dataObject); //putting into request queue
			}
			deleteFromCrbtHlrInactive(pendingList); //update status from N to R
		}
		
		Thread.sleep(1000*Global.READ_HLR_PENDING_REQUEST_SLP_TIME);
		
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		}
	}
	
	/**
	 * It provides data from CRBT_HLR_INACTIVE if available 
	 * @param penArrayList
	 * @return void 
	 * */
	private void getCrbtHlrInactiveRecords(ArrayList<DataObject> penArrayList)
	{
		logger.info("##>Inside getCrbtHlrInactiveRecords .............");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;
		Connection con = null;
		
		try
		{
			con = Global.conPool.getConnection();
			query = "select * from "+Global.READ_HLR_INACTIVE_TABLE_NAME+" where rownum<="+Global.ROW_NUM;
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			while(rs.next())
			{
				DataObject dataObject = new DataObject();
				dataObject.setMsisdn(rs.getString("MSISDN"));
				dataObject.setReqType(rs.getInt("REQUEST_ID"));
				dataObject.setInterface(rs.getString("INTERFACE"));
				dataObject.setStatus(rs.getString("STATUS"));
				dataObject.setHlrReqId(rs.getInt("HLR_REQUEST_ID"));
				penArrayList.add(dataObject);
			}
		logger.info("##>>Inside getCrbtHlrInactiveRecords pending list size["+penArrayList.size()+"]");	
		}
		catch(SQLException sqlexp)
		{
			sqlexp.printStackTrace();
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		finally{
			try
			{
				if(con != null){con.close();}
				if(pstmt != null){pstmt.close();}
				if(rs != null){rs.close();}
			}
			catch(SQLException sqlexp)
			{
				sqlexp.printStackTrace();
			}
		}
	}

	/**
	 * This method delete data from CRBT_HLR_INACTIVE
	 * @param penArrayList
	 * @return 1,-1
	 * */
	private int deleteFromCrbtHlrInactive(ArrayList<DataObject> penArrayList)
	{
		logger.info("##>>Inside deleteFromCrbtHlrInactive .....");
		PreparedStatement pstmt = null;
		String query = null;
		Connection con = null;
		int result = -1;
		
		try
		{
			con = Global.conPool.getConnection();
			query = "delete from "+Global.READ_HLR_INACTIVE_TABLE_NAME+" where msisdn=? and REQUEST_ID=?";
			pstmt = con.prepareStatement(query);
			for(DataObject dataObject : penArrayList)
			{
				pstmt.setString(1, dataObject.getMsisdn());
				pstmt.setInt(2,dataObject.getReqType());
				pstmt.addBatch();
			}
			if(penArrayList.size()>0)
			{
				pstmt.executeBatch();
				con.commit();
				logger.info("batch commited successfully...");
			}
			result = 1;
			logger.info("##>>Inside deleteFromcrbtHlrInactive records deleted successfully");
		}
		catch(SQLException sqlexp)
		{
			sqlexp.printStackTrace();
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		finally{
			try
			{
				if(con != null){con.close();}
				if(pstmt != null){pstmt.close();}
			}
			catch(SQLException sqlexp)
			{
				sqlexp.printStackTrace();
			}
		}
		
		return result;
	}

}
