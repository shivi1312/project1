package com.telemune.hlr;

import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import org.apache.log4j.Logger;
import com.google.gson.Gson;
import com.telemune.hlr.backend.DataObject;

/**
 * This thread read data from response queue and sent to receiving socket
 * @author Harjinder
 * 
 * */
class ResponseSender implements Runnable {

	final static Logger logger = Logger.getLogger("ResponseSender");
	String driver = "oracle.jdbc.driver.OracleDriver";
	String url = "jdbc:oracle:thin:@10.168.1.21:1521:mastera";
	String dbname = "";
	String uname = "crbt";
	String pwd = "crbt";
	Socket sock;
	ObjectOutputStream stream_send_object;
	DataOutputStream stream_send_data;

	ResponseSender() 
	{
		
		logger.debug("Response Sender constructor is loaded successfully");
	}

	/**
	 * This is run method provided by Runnable interface 
	 * on the basis of configuration parameter it define which
	 * method to be use for response sent
	 * simple plain text sendtoclient
	 * json response sendtoclientjson
	 * @return void
	 * */
	public void run() {
		logger.debug("ResponseSender running to send data........");
		if(Global.REQUEST_JSON_ENABLE == 1)
		{
			sendtoclientJson();
		}
		else
		{
			sendtoclient();
		}
		
	}


	/**
	 * This method sent Simple text over socket
	 * @return void
	 * */
	public void sendtoclient() {
		logger.debug("send Response to client........");
		try {
			while (true) {
				if (Global.resp_queue.isEmpty()) {
					try {
						//logger.debug("Send que is Empty*****");
						Thread.sleep(Global.RESP_SNDR_THRD_SLP_TIME);
					} catch (InterruptedException e1) {
						logger.fatal("Interrupted Exception occoured in thread",e1);
						e1.printStackTrace();
					}
					continue;
				}

				logger.debug("Send queSend is NOT Empty");
				DataObject dataObject =  Global.resp_queue.poll();
				logger.debug("deleting data from queSend ");
				this.sock = dataObject.getSock();
				logger.debug("packet Socket is===" + this.sock.toString());
				try {
					if (this.sock.isClosed()) {
						try {
							logger.info("Socket is closed ");
						} catch (Exception localException) {
							logger.fatal("Problem Excute Update" + localException.toString());
							localException.printStackTrace();
						}

						logger.debug("Socket is already closed so discarding this packet,Socket value is"
								+ this.sock.toString());

						continue;
					}

					String response = dataObject.getReqId() + "\n" + dataObject.getMsrn()
                                                        + "\n" + dataObject.getMscNo() + "\n" + dataObject.getImsi()
                                                        + "\n" + dataObject.getScfAddr() + "\n" + dataObject.getServiceKey()
                                                        + "\n" + dataObject.getIsPrePaidId() + "\n" + dataObject.getIsRoaming()
                                                        + "\n" + dataObject.getResponse() + "\n" + dataObject.getBusyNo()
                                                        + "\n" + dataObject.getNoReply() + "\n" + dataObject.getNoReachNo()
                                                        + "\n" + dataObject.getIsCFU() + "\n" + dataObject.getCFU();

					logger.debug("Response sending to ["+this.sock+"] for msisdn ["+dataObject.getMsisdn()+"] and reqId ["+dataObject.getReqId()+"]");

					byte[] sendBytes = response.getBytes();
					logger.debug("Response value in bytes ["+sendBytes+"]");
					this.stream_send_data = new DataOutputStream(this.sock.getOutputStream());
					logger.debug("Response length sending is ["+sendBytes.length+"]");
					this.stream_send_data.writeInt(sendBytes.length);
					this.stream_send_data.write(sendBytes);
					this.stream_send_data.flush();

					logger.info("response to be sent to client [" + response + "]");
				} catch (Exception localException4) {
					try {
						logger.info("Exception Sending Data:: "
								+ localException4.toString());
					} catch (Exception localException5) {
						logger.fatal(localException5);
						localException5.printStackTrace();
					}

				}

			}

		} catch (Exception e) {
			logger.fatal("Problem in Response Sending...",e);
			e.printStackTrace();
		} 
	}
	
	/**
	 * This method sent json response over socket
	 * @return void
	 * */
	public void sendtoclientJson() {
		logger.debug("send Response to client........");
		try {
			while (true) {
				if (Global.resp_queue.isEmpty()) {
					try {
						//logger.debug("Send que is Empty*****");
						Thread.sleep(Global.RESP_SNDR_THRD_SLP_TIME);
					} catch (InterruptedException e1) {
						logger.fatal("Interrupted Exception occoured in thread",e1);
						e1.printStackTrace();
					}
					continue;
				}

				logger.debug("Send queSend is NOT Empty");
				DataObject dataObject =  Global.resp_queue.poll();
				logger.debug("deleting data from queSend ");
				this.sock = dataObject.getSock();
				logger.debug("packet Socket is===" + this.sock.toString());
				try {
					if (this.sock.isClosed()) {
						try {
							logger.info("Socket is closed ");
						} catch (Exception localException) {
							logger.fatal("Problem Excute Update" + localException.toString());
							localException.printStackTrace();
						}

						logger.debug("Socket is already closed so discarding this packet,Socket value is"
								+ this.sock.toString());

						continue;
					}

					Gson gson = new Gson();
					System.out.println("End gson dataobject["+dataObject+"]");
					dataObject.setSock(null);
					String response = gson.toJson(dataObject);
					System.out.println("Json Response["+response+"]");
					logger.debug("Response sending to ["+this.sock+"] for msisdn ["+dataObject.getMsisdn()+"] and reqId ["+dataObject.getReqId()+"]");

					byte[] sendBytes = response.getBytes();
					logger.debug("Response value in bytes ["+sendBytes+"]");
					this.stream_send_data = new DataOutputStream(this.sock.getOutputStream());
					logger.debug("Response length sending is ["+sendBytes.length+"]");
					this.stream_send_data.writeInt(sendBytes.length);
					this.stream_send_data.write(sendBytes);
					this.stream_send_data.flush();

					logger.info("response to be sent to client [" + response + "]");
				} catch (Exception localException4) {
					try {
						logger.info("Exception Sending Data:: "
								+ localException4.toString());
					} catch (Exception localException5) {
						logger.fatal(localException5);
						localException5.printStackTrace();
					}

				}

			}

		} catch (Exception e) {
			logger.fatal("Problem in Response Sending...",e);
			e.printStackTrace();
		} 
	}
}
