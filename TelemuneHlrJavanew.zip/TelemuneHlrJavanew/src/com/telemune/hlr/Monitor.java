package com.telemune.hlr;

import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.log4j.Logger;

import com.telemune.hlr.backend.TelnetRequestHandler;

/**
 * This is a monitor thread that monitor TELNET connection and make them alive if not alive then again make connection
 * @author Harjinder
 * */
public class Monitor implements Runnable{
	final private  Logger logger = Logger.getLogger(Monitor.class);
	private AtomicLong processNo=new AtomicLong(0);
	private AtomicInteger port = new AtomicInteger(0);
	String ip;
	String loginName;
	String password;
	int noOfConnection = 0;
	int counter = 0;
	
	
	/**
	 * It is run method provided by Runnable interface define all logic related to keep alive TELNET connection
	 * @return void
	 * */	
	public void run() {
		
		while(true)
		{
			try
			{
				Set<Entry<Integer, HlrBean>> set = Global.map.entrySet();
				Iterator<Entry<Integer, HlrBean>> itr = set.iterator();
				while(itr.hasNext())
				{
					Entry<Integer, HlrBean> entry =  itr.next();
					HlrBean bean = (HlrBean) entry.getValue();
					if(bean.getHlrType().equalsIgnoreCase("TELNET"))
					{
						TelnetRequestHandler reuseablebean = null;
						System.out.println("Telenet pool size["+bean.getTelnet_pool().size()+"] counter["+counter+"]");
						for(int i = 0 ;i<bean.getTelnet_pool().size();i++)	
						{
							
						reuseablebean =(TelnetRequestHandler) bean.getTelnet_pool().borrowObject();
					    System.out.println("Reuseable bean ["+reuseablebean+"]");
						if(reuseablebean != null)
						{
						if(reuseablebean.isConnected())
						{
						logger.debug("##>>Alreday connected so going to call keep Alive");	
						reuseablebean.keepAlive(); 
						}
						else
						{
						logger.debug("##>> Connection lost so going to create again by calling keepAlive");
						reuseablebean.keepAlive();
						}	
					    bean.getTelnet_pool().returnObject(reuseablebean);
						}
						}
						}
					
				}
				Thread.sleep(1000*Global.MONITOR_THRD_SLP_TIME);
			}
			catch(NullPointerException nullexp)
			{
				nullexp.printStackTrace();
			}
			catch(Exception exp)
			{
				exp.printStackTrace();
			}
		}
	}

}
