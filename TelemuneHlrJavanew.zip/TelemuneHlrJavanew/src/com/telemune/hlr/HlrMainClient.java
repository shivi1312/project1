package com.telemune.hlr;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import FileBaseLogging.FileLogWriter;

import com.db.CacheLoader;
import com.db.Dboperation;
import com.telemune.hlr.backend.ConfigurationLoader;
import com.telemune.hlr.backend.DataObject;

/**
 * This is the main class that run application and launch threads
 * @author Harjinder 
 * */
public class HlrMainClient {
	private static Logger logger = Logger.getLogger(HlrMainClient.class);
	Dboperation dbops = null;
	
	public void setUp()
	{
		dbops = new Dboperation();
		dbops.getAllHlrDetails();
		
		System.out.println("Read From Database successfull ");

	}

	/**
	 * This method load property file and initialize all Global parameters
	 * @return void
	 * */
	public void loadingCongiguration()
	{
		String dbuser;
		String dbpass;
		String driver;
		String dburl;
		int port = 10110;
		int numOfConnection;
		int miniNumOfConnection;
		int dbAccomodation;
		int monitorThEnable = -1;
		int hlrInactiveThEnable = -1;
		int setSubStatusThEnable = -1;
		Thread acceptorTh = null;
		Thread respTh = null;
		Thread readerTh = null;
		Thread dataTh = null;
		Thread setSubTypeTh = null;
		Thread monitorTh = null;
		ThreadPoolExecutor hlrexecutor = null;
		Thread cacheLoaderTh = null;
		
		RequestReceiver acceptor = null;
		ResponseSender sender = null;
		QueueReader reader = null;
		ReadData data = null;
		Monitor monitor = null;
		CacheLoader cacheLoader = null;
		SetSubType setSubType = null;
		
		Properties hlrPro = new Properties();
		try
		{
			FileInputStream fins=new FileInputStream("properties/TelemuneHlr.properties");
			hlrPro.load(fins);
			fins.close();
		}
		catch(FileNotFoundException fexp)
		{
			fexp.printStackTrace();
			logger.error(fexp.getMessage());
			System.exit(1);
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
			logger.error(exp.getMessage());
			System.exit(1);
		}

		try
		{
			Global.IsPriorityWiseEnable = Integer.parseInt(hlrPro.getProperty("IS_PRIORITY_WISE_ENABLE"));
			Global.IsRangeWiseEnable = Integer.parseInt(hlrPro.getProperty("IS_RANGE_WISE_ENABLE"));
			Global.SendToSecondHlrEnable = Integer.parseInt(hlrPro.getProperty("SEND_TO_SECOND_HLR_ENABLE"));
			Global.RESP_SNDR_THRD_SLP_TIME = Integer.parseInt(hlrPro.getProperty("RESP_SNDR_THRD_SLP_TIME"));
			Global.MONITOR_THRD_SLP_TIME =  Integer.parseInt(hlrPro.getProperty("MONITOR_THRD_SLP_TIME"));
			Global.REQ_QUEUE_READER_THRD_SLP_TIME = Integer.parseInt(hlrPro.getProperty("REQ_QUEUE_READER_THRD_SLP_TIME"));
			Global.READ_HLR_PENDING_REQUEST_SLP_TIME = Integer.parseInt(hlrPro.getProperty("READ_HLR_PENDING_REQUEST_SLP_TIME"));
			Global.CACHE_LOADER_SLP_TIME= Integer.parseInt(hlrPro.getProperty("CACHE_LOADER_SLP_TIME"));
			Global.ROW_NUM = Integer.parseInt(hlrPro.getProperty("ROW_NUM"));
			Global.REQUEST_JSON_ENABLE = Integer.parseInt(hlrPro.getProperty("REQUEST_JSON_ENABLE"));
			Global.READ_SETSUB_TYPE_SLP_TIME = Integer.parseInt(hlrPro.getProperty("READ_SETSUB_TYPE_SLP_TIME"));
			Global.READ_HLR_INACTIVE_TABLE_NAME = hlrPro.getProperty("READ_HLR_INACTIVE_TABLE_NAME");
			Global.READ_SET_SUB_TYPE_TABLE_NAME = hlrPro.getProperty("READ_SET_SUB_TYPE_TABLE_NAME");
			Global.OBJECT_NOT_FOUND_THEN_SLEEP = Integer.parseInt(hlrPro.getProperty("OBJECT_NOT_FOUND_THEN_SLEEP"));
			
			
			setSubStatusThEnable  = Integer.parseInt(hlrPro.getProperty("SET_SUBCRIBER_STATUS_ENABLE"));
			numOfConnection = Integer.parseInt(hlrPro.getProperty("NUM_OF_CONNECTION"));
			miniNumOfConnection = Integer.parseInt(hlrPro.getProperty("MIN_NUM_OF_CONNECTION"));
			dbAccomodation = Integer.parseInt(hlrPro.getProperty("DB_ACCOMODATION"));
			dbuser = hlrPro.getProperty("DBUSER");
			dbpass = hlrPro.getProperty("DBPASSWORD");
			driver = hlrPro.getProperty("DRIVER");
			dburl = hlrPro.getProperty("DBURL");
			port = Integer.parseInt(hlrPro.getProperty("LOCAL_PORT"));
			monitorThEnable = Integer.parseInt(hlrPro.getProperty("MONITOR_THREAD_ENABLE"));
			hlrInactiveThEnable = Integer.parseInt(hlrPro.getProperty("HLR_INACTIVE_THREAD_ENABLE"));
			
			
			logger.info("IsPriorityWiseEnable["+Global.IsPriorityWiseEnable+"] IsRangeWiseEnable["+Global.IsRangeWiseEnable+"]"
					+"SendToSecondHlrEnable["+Global.SendToSecondHlrEnable+"] RESP_SNDR_THRD_SLP_TIME["+Global.RESP_SNDR_THRD_SLP_TIME+"]"
					+"MONITOR_THRD_SLP_TIME["+Global.MONITOR_THRD_SLP_TIME+"] REQ_QUEUE_READER_THRD_SLP_TIME["+Global.REQ_QUEUE_READER_THRD_SLP_TIME+"]"
					+"READ_HLR_PENDING_REQUEST_SLP_TIME["+Global.READ_HLR_PENDING_REQUEST_SLP_TIME+"] CACHE_LOADER_SLP_TIME["+Global.CACHE_LOADER_SLP_TIME+"]"
					+"MONITOR_THREAD_ENABLE["+monitorThEnable+"] ROW_NUM["+Global.ROW_NUM+"] hlrInactiveThEnable["+hlrInactiveThEnable+"]"
					+"READ_SETSUB_TYPE_SLP_TIME["+Global.READ_SETSUB_TYPE_SLP_TIME+"]"
					+"REQUEST_JSON_ENABLE["+Global.REQUEST_JSON_ENABLE+"] SET_SUBCRIBER_STATUS_ENABLE["+setSubStatusThEnable+"]"
					+"READ_SET_SUB_TYPE_TABLE_NAME["+Global.READ_SET_SUB_TYPE_TABLE_NAME+"] READ_HLR_INACTIVE_TABLE_NAME["+Global.READ_HLR_INACTIVE_TABLE_NAME+"]"
					+"OBJECT_NOT_FOUND_THEN_SLEEP["+Global.OBJECT_NOT_FOUND_THEN_SLEEP+"]");
			
			
			Global.req_queue = new ArrayBlockingQueue<DataObject>(Integer.parseInt(hlrPro.getProperty("REQUEST_QUEUE_CAPACITY")));
			Global.resp_queue = new ArrayBlockingQueue<DataObject>(Integer.parseInt(hlrPro.getProperty("RESPONSE_QUEUE_CAPACITY")));
			ConfigurationLoader loader = new ConfigurationLoader(); //loading jar configuarion

			Global.conPool=new ConnPool(driver,dburl,dbuser,dbpass,miniNumOfConnection,numOfConnection,dbAccomodation);
			Global.conPool.MakePool();


			cacheLoader = new CacheLoader();
			cacheLoaderTh = new Thread(cacheLoader);
			cacheLoaderTh.start();
			logger.info("##>>cacheLoaderThread["+cacheLoaderTh+"]");
			
			acceptor = new RequestReceiver(port);
			acceptorTh = new Thread(acceptor);
			acceptorTh.start();

			sender = new ResponseSender();
			respTh = new Thread(sender);
			respTh.start();

			hlrexecutor = new ThreadPoolExecutor(Integer.parseInt(hlrPro.getProperty("CORE_POOL_SIZE")),
					Integer.parseInt(hlrPro.getProperty("MAX_POOL_SIZE")),
					Integer.parseInt(hlrPro.getProperty("KEEP_ALIVE_TIME")),
					TimeUnit.SECONDS,
					new ArrayBlockingQueue<Runnable>(
						Integer.parseInt(hlrPro.getProperty("PROCESSOR_QUEUE_CAPACITY"))
						));
			hlrexecutor.setRejectedExecutionHandler(new RejectedWork());

		
			setUp(); //making object pool


			if(monitorThEnable == 1)
			{
				monitor = new Monitor();
				monitorTh = new Thread(monitor);
				monitorTh.start();
			}
			reader = new QueueReader(hlrexecutor , Integer.parseInt(hlrPro.getProperty("MAX_POOL_SIZE")), cacheLoader , monitorTh);
			readerTh = new Thread(reader);
			readerTh.start();


			if(hlrInactiveThEnable == 1)
			{
				data = new ReadData();
				dataTh = new Thread(data);
				dataTh.start();
			}
			if(setSubStatusThEnable == 1)
			{
			   setSubType = new SetSubType();
			   setSubTypeTh = new Thread(setSubType);
			   setSubTypeTh.start();
			}
			
		}
		catch(NumberFormatException numexp)
		{
			numexp.printStackTrace();
		}
		catch (NullPointerException nullexp) {
			nullexp.printStackTrace();
		}
		catch (Exception exp) {
			exp.printStackTrace();
		}


		while(true)
		{
			try
			{
				System.out.println("cache loader["+cacheLoaderTh+"]");
				if(!cacheLoaderTh.isAlive())
				{
					cacheLoader = new CacheLoader();
					cacheLoaderTh = new Thread(cacheLoader);
					cacheLoaderTh.start();
				}
				if(!acceptorTh.isAlive())
				{
					acceptor = new RequestReceiver(port);
					acceptorTh = new Thread(acceptor);
					acceptorTh.start();
				}
				if(!respTh.isAlive())
				{
					sender = new ResponseSender();
					respTh = new Thread(sender);
					respTh.start();
				}
				if(!readerTh.isAlive())
				{
					reader = new QueueReader(hlrexecutor ,Integer.parseInt(hlrPro.getProperty("MAX_POOL_SIZE")), cacheLoader,monitorTh);
					readerTh = new Thread(reader);
					readerTh.start();
				}
				if(hlrInactiveThEnable == 1)
				{
					if(!dataTh.isAlive())
					{
						data = new ReadData();
						dataTh = new Thread(data);
						dataTh.start();
					}
				}
				if(setSubStatusThEnable == 1)
				{
					if(!setSubTypeTh.isAlive())
					{
					   setSubType = new SetSubType();
					   setSubTypeTh = new Thread(setSubType);
					   setSubTypeTh.start();
					}
				}
				if(monitorThEnable == 1)
				{
					if(!monitorTh.isAlive())
					{
						monitor = new Monitor();
						monitorTh = new Thread(monitor);
						monitorTh.start();
					}
				}

				Thread.sleep(4*60*1000); //main class sleep time
			}
			catch(NullPointerException nullexp)
			{
				nullexp.printStackTrace();
			}
			catch(Exception exp)
			{
				exp.printStackTrace();
			}
		}
	}

	public static void main(String arg[])
	{
		try
		{
			PropertyConfigurator.configure("properties/TelemuneHlr_log.properties");
			final String VERSION="R4_0_0_0";
			final String SITE="Telemune Hlr";
			logger.info("\n******************************************************************************************");
			logger.info("\n                               Site "+SITE);
			logger.info("\n                               Version "+VERSION);
			logger.info("\n******************************************************************************************");
			logger.info("\n");

			HlrMainClient create = new HlrMainClient();
			create.loadingCongiguration();

		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}


	}
}
