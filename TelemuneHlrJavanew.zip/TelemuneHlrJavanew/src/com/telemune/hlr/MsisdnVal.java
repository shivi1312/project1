package com.telemune.hlr;

/**
 * This class define OPERATOR_SUBSCRIBER table
 * @author Harjinder
 * */
public class MsisdnVal
{

        public String countrycode;
        public String st_msisdn;
        public String ed_msisdn;
        public int hlrId;
        public String getCountrycode() {
			return countrycode;
		}
		public void setCountrycode(String countrycode) {
			this.countrycode = countrycode;
		}
		public String getSt_msisdn() {
			return st_msisdn;
		}
		public void setSt_msisdn(String st_msisdn) {
			this.st_msisdn = st_msisdn;
		}
		public String getEd_msisdn() {
			return ed_msisdn;
		}
		public void setEd_msisdn(String ed_msisdn) {
			this.ed_msisdn = ed_msisdn;
		}
		public int getHlrId() {
			return hlrId;
		}
		public void setHlrId(int hlrId) {
			this.hlrId = hlrId;
		}
		
		@Override
		public String toString() {
			return "MsisdnVal [countrycode=" + countrycode + ", st_msisdn="
					+ st_msisdn + ", ed_msisdn=" + ed_msisdn + ", hlrId="
					+ hlrId + "]";
		}
        
       
        
}

                          