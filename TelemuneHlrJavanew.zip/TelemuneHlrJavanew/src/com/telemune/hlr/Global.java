package com.telemune.hlr;

import java.util.HashMap;
import java.util.concurrent.ArrayBlockingQueue;

import com.telemune.hlr.backend.DataObject;


/**
 * This class provide all data-members required as configuration through out the life cycle of application
 * @author Harjinder 
 * */
public class Global {

	public static ArrayBlockingQueue<DataObject> req_queue = null; 
	public static ArrayBlockingQueue<DataObject> resp_queue = null; 
	public static HashMap<Integer,HlrBean> map = new HashMap<Integer,HlrBean>();
    public static HashMap<Integer,Integer> priority_map = new HashMap<Integer,Integer>();
    public static int IsPriorityWiseEnable = -1;
    public static int IsRangeWiseEnable = -1;
    public static int SendToSecondHlrEnable = -1;
    public static int REQUEST_QUEUE_CAPACITY = 0;
	public static int RESPONSE_QUEUE_CAPACITY = 0;
	public static int port = 2100;
	public static int waiting = 2100;
	public static int connectionTimeOut = -1;
	public static ConnPool conPool = null;
	public static int MONITOR_THRD_SLP_TIME = 5;
	public static int REQ_QUEUE_READER_THRD_SLP_TIME = 1;
	public static int RESP_SNDR_THRD_SLP_TIME = 1;
	public static int READ_HLR_PENDING_REQUEST_SLP_TIME = 1;
	public static int CACHE_LOADER_SLP_TIME = 1;
	public static int ROW_NUM = 1;
	public static int REQUEST_JSON_ENABLE = -1;
	public static int READ_SETSUB_TYPE_SLP_TIME = 1;
	public static String READ_SET_SUB_TYPE_TABLE_NAME = "CRBT_SUBSCRIBER_MASTER";
	public static String READ_HLR_INACTIVE_TABLE_NAME = "CRBT_SUBSCRIBER_MASTER";
	public static int OBJECT_NOT_FOUND_THEN_SLEEP = 1;
	public static int SetSubTypeCounter = 0;
	
	
	
	
}
