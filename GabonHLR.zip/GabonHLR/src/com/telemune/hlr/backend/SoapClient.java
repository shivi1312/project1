package com.telemune.hlr.backend;

import java.io.StringReader;
import java.net.InetAddress;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

//import com.telemune.hlr.server.ServiceProviderLocator;
//import com.telemune.hlr.server.ServiceProviderPortType;

public class SoapClient {
	
	final private Logger logger = Logger.getLogger(SoapClient.class);
//	ServiceProviderLocator locator = null;
//	ServiceProviderPortType port = null;
	private String url;
	private int timeout=10;

    public SoapClient() {
    	try
    	{
//    	locator = new ServiceProviderLocator();
//		port = locator.getServiceProviderHttpSoap11Endpoint();
    		this.url=Config.HLR_SOAP_URL;
    		this.timeout=Config.connectionTimeOut;
    		logger.info("URl <<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>"+url);
    	}
    	catch(Exception exp)
    	{
    		exp.printStackTrace();
    	}
	        	
	}
	
    public String getSubType(DataObject dataObject)
    {
    	String subType = "NA";
    	int result = -1;
		try
    	{
			result=1; // We are considering all msisdn as Prepaid at this site
			logger.info("msisdn["+dataObject.getMsisdn()+"] We are considering all msisdn as Prepaid at this site... subType is["+subType+"]");
			if(result == 1){ subType="P";
			dataObject.setIsPrePaidId("Y");
			dataObject.setResponse("0");
			}
			else { subType="O";
			dataObject.setIsPrePaidId("N");
			dataObject.setResponse("0");
			}
			System.out.println("msisdn["+dataObject.getMsisdn()+"] subType is["+subType+"]");
			return subType;
		
    	}
    	catch(Exception exp)
    	{
    		exp.printStackTrace();
    	}
    	return null;
    }
    
    public int upFlag(DataObject dataObject, String reqFlag)
    {
    	String upFlag = "NA";
		int result = -1;
		String provisioningXml=null;
		String responseXml=null;
		DocumentBuilderFactory dbFactory = null;
		DocumentBuilder dBuilder = null;
		Document doc = null;
		String id=null;
		String returnCode=null;
		String returnDescription=null;
		
    	try
    	{
    		provisioningXml = getProvisioningDeprovisioningXml(dataObject.getMsisdn(),dataObject.getReqType(), reqFlag);
    		if ((!provisioningXml.equalsIgnoreCase("NA")) && (!"".equalsIgnoreCase(provisioningXml))) {
				logger.debug("##>>msisdn["+dataObject.getMsisdn()+"] provisioningXml["+provisioningXml+"]");
				responseXml=sendPost(provisioningXml, "Provisioning", dataObject.getMsisdn());
			}
    		
    		if ((responseXml!=null) && !("".equalsIgnoreCase(responseXml))) {
    			logger.debug("\n\n###>>> msisdn["+dataObject.getMsisdn()+"] Provisioning Response: ["+responseXml+"]\n\n");
    			dbFactory = DocumentBuilderFactory.newInstance();
	    		dBuilder = dbFactory.newDocumentBuilder();
	    		doc = dBuilder.parse(new InputSource(new StringReader(responseXml)));
	    		doc.getDocumentElement().normalize();
	    		logger.info("\n\n###>>> msisdn["+dataObject.getMsisdn()+"] responseXml Root element : ["+ doc.getDocumentElement().getNodeName()+"]");
	    		if (responseXml.contains("ResponseClass") && responseXml.contains("ResponseSubClass")) {
	    			
	        		if (doc.getElementsByTagName("ResponseSubClass").getLength()!=0) {
	    				//id=doc.getElementsByTagName("ID").item(0).getTextContent();
	    				returnCode=doc.getElementsByTagName("ResultCode").item(0).getTextContent();
	    				returnDescription=doc.getElementsByTagName("ResultDescr").item(0).getTextContent();
	    				
	    				// 110140 for niger
	    				if (returnCode.equalsIgnoreCase("0") || returnCode.equalsIgnoreCase("110140") ) {
	    					result=1; // success case
	    					logger.info("\n###>>> msisdn:["+dataObject.getMsisdn()+"] Provisioning Response: RetCode ["+returnCode+"]"
	    							+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] Provisioning Response: RetDesc ["+returnDescription+"]");
						} else {
							result=-1; // fail case
							logger.error("\n###>>> msisdn:["+dataObject.getMsisdn()+"] Provisioning Response: RetCode ["+returnCode+"]"
									+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] Provisioning Response: RetDesc ["+returnDescription+"]");
						}
	        		} else {
	        			result=-1; // fail case
						logger.error("###>>> msisdn["+dataObject.getMsisdn()+"] Provisioning Response: MessageBody is Empty, MessageBody Length["+doc.getElementsByTagName("MessageBody").getLength()+"]");
					}
				} else {
					result=-1; // fail case
					logger.error("###>>> msisdn["+dataObject.getMsisdn()+"] Response does not contain ResultMessage OR MessageBody, Provisioning Response:["+responseXml+"]");
				}
    			
    		}
    		if(result == 1){ upFlag="UP";
//		//	dataObject.setResponse("0");
			}
			else { upFlag="NOT UP"; 
//		//	dataObject.setResponse("-1");
			
			}
    		logger.info("msisdn["+dataObject.getMsisdn()+"] UpFlag status is["+upFlag+"]");
			System.out.println("msisdn["+dataObject.getMsisdn()+"] UpFlag status is["+upFlag+"]");
			return result;
    	}
    	catch(Exception exp)
    	{
    		logger.error(">>>msisdn:["+dataObject.getMsisdn()+"] Exception in upFlag method... ",exp);
			System.err.println(">>>msisdn:["+dataObject.getMsisdn()+"] Exception in upFlag method... "+exp);
		    exp.printStackTrace();
    	} finally {
			if (dbFactory!=null) {dbFactory=null;}
			if (dBuilder!=null) {dBuilder=null;}
			if (doc!=null) {doc=null;}
		}
    	
    	return result;
    }
    
    public int downFlag(DataObject dataObject, String reqFlag)
    {
    	String downFlag = "NA";
		int result = -1;
		String deprovisioningXml=null;
		String responseXml=null;
		DocumentBuilderFactory dbFactory = null;
		DocumentBuilder dBuilder = null;
		Document doc = null;
		String id=null;
		String returnCode=null;
		String returnDescription=null;
		
    	try
    	{
    		deprovisioningXml = getProvisioningDeprovisioningXml(dataObject.getMsisdn(),dataObject.getReqType(),reqFlag);
    		if ((!deprovisioningXml.equalsIgnoreCase("NA")) && (!"".equalsIgnoreCase(deprovisioningXml))) {
				logger.debug("##>>msisdn["+dataObject.getMsisdn()+"] deprovisioningXml["+deprovisioningXml+"]");
				responseXml=sendPost(deprovisioningXml, "Deprovisioning", dataObject.getMsisdn());
			}
    		
    		if ((responseXml!=null) && !("".equalsIgnoreCase(responseXml))) {
    			logger.debug("\n\n###>>> msisdn["+dataObject.getMsisdn()+"] Deprovisioning Response: ["+responseXml+"]\n\n");
    			dbFactory = DocumentBuilderFactory.newInstance();
	    		dBuilder = dbFactory.newDocumentBuilder();
	    		doc = dBuilder.parse(new InputSource(new StringReader(responseXml)));
	    		doc.getDocumentElement().normalize();
	    		logger.info("\n\n###>>> msisdn["+dataObject.getMsisdn()+"] responseXml Root element : ["+ doc.getDocumentElement().getNodeName()+"]");
	    		if (responseXml.contains("ResponseClass") && responseXml.contains("ResponseSubClass")) {
	    			
	        		if (doc.getElementsByTagName("ResponseSubClass").getLength()!=0) {
	    				//id=doc.getElementsByTagName("ID").item(0).getTextContent();
	    				returnCode=doc.getElementsByTagName("ResultCode").item(0).getTextContent();
	    				returnDescription=doc.getElementsByTagName("ResultDescr").item(0).getTextContent();
	    				
	    				if (returnCode.equalsIgnoreCase("0") && returnDescription.contains("success")) {
	    					result=1; // success case
	    					logger.info("\n###>>> msisdn:["+dataObject.getMsisdn()+"] Deprovisioning Response: RetCode ["+returnCode+"]"
	    							+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] Deprovisioning Response: RetDesc ["+returnDescription+"]");
						} else {
							result=-1; // fail case
							logger.error("\n###>>> msisdn:["+dataObject.getMsisdn()+"] Deprovisioning Response: RetCode ["+returnCode+"]"
									+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] Deprovisioning Response: RetDesc ["+returnDescription+"]");
						}
	        		} else {
	        			result=-1; // fail case
						logger.error("###>>> msisdn["+dataObject.getMsisdn()+"] Deprovisioning Response: MessageBody is Empty, MessageBody Length["+doc.getElementsByTagName("MessageBody").getLength()+"]");
					}
				} else {
					result=-1; // fail case
					logger.error("###>>> msisdn["+dataObject.getMsisdn()+"] Response does not contain ResultMessage OR MessageBody, Deprovisioning Response:["+responseXml+"]");
				}
    			
    		}
    		
    		if(result == 1){ downFlag="DOWN";
			//dataObject.setResponse("0");
			}
			else { downFlag="NOT DOWN";
			//dataObject.setResponse("-1");
			}
    		logger.info("msisdn["+dataObject.getMsisdn()+"] downFlag status is["+downFlag+"]");
			System.out.println("msisdn["+dataObject.getMsisdn()+"] downFlag status is["+downFlag+"]");
			return result;
    	}
    	catch(Exception exp)
    	{
    		logger.error(">>>msisdn:["+dataObject.getMsisdn()+"] Exception in downFlag method... ",exp);
			System.err.println(">>>msisdn:["+dataObject.getMsisdn()+"] Exception in downFlag method... "+exp);
		    exp.printStackTrace();
    	} finally {
			if (dbFactory!=null) {dbFactory=null;}
			if (dBuilder!=null) {dBuilder=null;}
			if (doc!=null) {doc=null;}
		}
    	
    	return result;
    }
    
    private String sendPost(String xmlString, String req, String msisdn) {
    	logger.info("inside sendPost    xmlString ====="+xmlString+"     req========"+req+"    msisdn==="+msisdn);
    	StringBuffer responseXml = null;
		CloseableHttpClient client = null;
		CloseableHttpResponse response = null;
		HttpPost post = null;
		HttpParams httpParams = null;
		try {
			//client = HttpClients.createDefault();
			
		RequestConfig config = RequestConfig.custom().setLocalAddress(InetAddress.getByName("172.27.68.171")).build();
			client =  HttpClientBuilder.create().setDefaultRequestConfig(config).build();
			
			httpParams = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParams, this.timeout * 1000);
			HttpConnectionParams.setSoTimeout(httpParams, this.timeout * 1000);
			
			post = new HttpPost(url);
			
			post.setParams(httpParams);
			responseXml = new StringBuffer();
			
			post.addHeader("Content-Type", "text/xml");
			post.addHeader("Accept", "text/xml");
			post.addHeader("Except", "100-continue");
			post.addHeader("IP", InetAddress.getLocalHost().toString());
			
			StringEntity entity = new StringEntity(xmlString);
			post.setEntity(entity);
			
			System.out.println("\n>>>msisdn[" + msisdn + "]  Sending 'POST' " + req + " request to URL :[" + url + "]\n");
			logger.info("\n>>>msisdn[" + msisdn + "]  Sending 'POST' " + req + " request to URL :[" + url + "]\n");
			
			response = client.execute(post);
			int returnCode = response.getStatusLine().getStatusCode();
			String result = EntityUtils.toString(response.getEntity());
			System.out.println(">>>msisdn[" + msisdn + "] " + req + " post hit returnCode:[" + returnCode + "]");
			logger.info(">>>msisdn[" + msisdn + "] " + req + " post hit returnCode:[" + returnCode + "]");
			
			if (returnCode == HttpStatus.SC_NOT_IMPLEMENTED) {
				logger.info(">>>msisdn[" + msisdn + "] The Post post is not implemented by this URI");
				System.err.println(">>>msisdn[" + msisdn + "] The Post post is not implemented by this URI");
				logger.info(">>>msisdn[" + msisdn + "] Post hit result["+result+"]");
		        System.err.println(">>>msisdn[" + msisdn + "] Post hit result["+result+"]");
			} else {
				responseXml.append(result);
			}
			
		} catch (Exception e) {
			logger.error(">>>msisdn["+msisdn+"] Exception in sendPost method at " + req + " request... ",e);
		    System.err.println(">>>msisdn["+msisdn+"] Exception in sendPost method at " + req + " request... "+e);
		    e.printStackTrace();
		} finally {
			if (post != null) {
		         try {
		           post.releaseConnection();
		           post = null;
		         } catch (Exception e2) {
		           e2.printStackTrace();
		         }
		       }
		 
		       httpParams = null;
		 
		       if (client != null) {
		         try {
		           client.close();
		           client = null;
		         } catch (Exception e3) {
		           e3.printStackTrace();
		         }
		       }
		 
		       if (response != null) {
		         try {
		           response.close();
		           response = null;
		         } catch (Exception e4) {
		           e4.printStackTrace();
		         }
		       }
		}
		return responseXml.toString();
    }
    
    private String getProvisioningDeprovisioningXml(String msisdn, int reqType,String reqFlag) {
    	logger.info("###>>> msisdn["+msisdn+"] Inside getProvisioningDeprovisioningXml method...");
    	String xml="";
    	String bizCode="";
    	int timeout=this.timeout*1000;
    	
    	try {
    		String serial = generateSerialNumber(msisdn); // generating unique serial id for each request
    		if (reqType==3) {
				bizCode="1";
				
				logger.info("###>>> msisdn["+msisdn+"] Generating Provisioning Xml, reqType["+reqType+"]");
				xml="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ispp=\"http://ispp.com.cn/ispp_npi/\">\n"
						+ "   <soapenv:Header>\n"
						+ "       <ispp:HLRIN>?</ispp:HLRIN>\n"
						+ "       <ispp:SWITCHNUM>?</ispp:SWITCHNUM>\n"
						+ "       <ispp:MARKID>?</ispp:MARKID>\n"
						+ "       <ispp:HLRNUMBER>?</ispp:HLRNUMBER>\n"
						+ "       <ispp:VHLRID>1</ispp:VHLRID>\n"
						+ "       <ispp:Password>"+Config.PASSWORD+"</ispp:Password>\n"
						+ "       <ispp:Username>"+Config.USERNAME+"</ispp:Username>\n"
						+ "   </soapenv:Header>\n"
						+ "   <soapenv:Body>\n"
						+ "       <ispp:root>\n"
						+ "           <msg_head>\n"
						+ "               <time>?</time>\n"
						+ "               <from>?</from>\n"
						+ "               <to>?</to>\n"
						+ "               <msg_type>?</msg_type>\n"
						+ "               <serial>?</serial>\n"
						+ "           </msg_head>\n"
						+ "           <interface_msg>\n"
						+ "               <directive>\n"
						+ "                   <SubscriberClass Name=\"wSSDataService\">\n"
						+ "                       <SubscriberSubClass Name=\"RegFTNService\">\n"
						+ "                           <Method Name=\"SetMOAttributes\">\n"
						+ "                               <MSISDN>"+msisdn+"</MSISDN>\n"
						+ "                               <SS>"+reqFlag+"</SS>\n"
						+ "                               <Bsg>0</Bsg>\n"
						+ "                               <Register>"+bizCode+"</Register>\n"
						+ "                               <Active>"+bizCode+"</Active>\n"
						+ "                               <FwdNum>"+Config.FTN_NUMBER+"</FwdNum>\n"
						+ "                               <Time>"+Config.connectionTimeOut+"</Time>\n"
						+ "                           </Method>\n"
						+ "                       </SubscriberSubClass>\n"
						+ "                   </SubscriberClass>\n"
						+ "               </directive>\n"
						+ "           </interface_msg>\n"
						+ "       </ispp:root>\n"
						+ "   </soapenv:Body>\n"
						+ "</soapenv:Envelope>\n";
			
			} else if(reqType==4){
				bizCode="0";
				logger.info("###>>> msisdn["+msisdn+"] Generating Deprovisioning Xml, reqType["+reqType+"]");
				
				xml="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ispp=\"http://ispp.com.cn/ispp_npi/\">\n"
				+ "   <soapenv:Header>\n"
				+ "       <ispp:HLRIN>?</ispp:HLRIN>\n"
				+ "       <ispp:SWITCHNUM>?</ispp:SWITCHNUM>\n"
				+ "       <ispp:MARKID>?</ispp:MARKID>\n"
				+ "       <ispp:HLRNUMBER>?</ispp:HLRNUMBER>\n"
				+ "       <ispp:VHLRID>1</ispp:VHLRID>\n"
				+ "       <ispp:Password>"+Config.PASSWORD+"</ispp:Password>\n"
				+ "       <ispp:Username>"+Config.USERNAME+"</ispp:Username>\n"
				+ "   </soapenv:Header>\n"
				+ "   <soapenv:Body>\n"
				+ "       <ispp:root>\n"
				+ "           <msg_head>\n"
				+ "               <time>?</time>\n"
				+ "               <from>?</from>\n"
				+ "               <to>?</to>\n"
				+ "               <msg_type>?</msg_type>\n"
				+ "               <serial>?</serial>\n"
				+ "           </msg_head>\n"
				+ "           <interface_msg>\n"
				+ "               <directive>\n"
				+ "                   <SubscriberClass Name=\"wSSDataService\">\n"
				+ "                       <SubscriberSubClass Name=\"RegFTNService\">\n"
				+ "                           <Method Name=\"SetMOAttributes\">\n"
				+ "                                <MSISDN>"+msisdn+"</MSISDN>\n"
				+ "                               <SS>"+reqFlag+"</SS>\n"
				+ "                               <Bsg>0</Bsg>\n"
				+ "                               <Active>"+bizCode+"</Active>\n"
				+ "                           </Method>\n"
				+ "                       </SubscriberSubClass>\n"
				+ "                   </SubscriberClass>\n"
				+ "               </directive>\n"
				+ "           </interface_msg>\n"
				+ "       </ispp:root>\n"
				+ "   </soapenv:Body>\n"
				+ "</soapenv:Envelope>\n";
				
			
			} else {
				logger.error("###>>> msisdn["+msisdn+"] Wrong ReqType for Generating Deprovisioning Xml, reqType["+reqType+"]");
			}
			
		} catch (Exception e) {
			logger.error(">>>msisdn["+msisdn+"] Exception in getProvisioningXml method... ",e);
			System.err.println(">>>msisdn["+msisdn+"] Exception in getProvisioningXml method... "+e);
		    e.printStackTrace();
		}
    	return xml;
    }
    
    public String generateSerialNumber(String msisdn){
    	String serial="";
    	Date date = null;
    	DateFormat sdf = null;
    	String stringDate = null;
    	try {
    		date =  new Date();
        	sdf = new SimpleDateFormat("yyyyMMdd.HHmmss.SSS");
        	stringDate = sdf.format(date);
        	serial = Config.SERIAL_FORMAT.concat(stringDate);
        	logger.info("###>>> msisdn["+msisdn+"] Serial Id Generated for Request["+serial+"]");
		} catch (Exception e) {
			logger.error(">>>msisdn["+msisdn+"] Exception in generateSerialNumber method... ",e);
			e.printStackTrace();
		}
    	finally {
			if (date!=null) {
				date=null;
			}
			if (sdf!=null) {
				sdf=null;
			}
			if (stringDate!=null) {
				stringDate=null;
			}
		}
    	return serial;
    }
    
    public static void main(String arg[])
    {
    	SoapClient sop = new SoapClient();
    	DataObject dataObject = new DataObject();
    	dataObject.setMsisdn("1");
    	//sop.upFlag(dataObject);
    	System.out.println("respose["+dataObject.getResponse()+"]");
    }
}
