package com.telemune.hlr.backend;

import org.apache.log4j.Logger;

public class SoapRequestHandler implements HlrInterface{

	final private Logger logger = Logger.getLogger(SoapRequestHandler.class);
	SoapClient client = null;
	public long objectNo ;
	
	public SoapRequestHandler(long i) {
		logger.info("Inside SoapRequestHandler Object no "+i+" created");
		client = new SoapClient();
		this.objectNo = i;
	}
	
	
	public int doProcessing(DataObject dataObject) {
		int responseCFNRY = -1;
		int responseCFB = -1;
		int responseCFNRC = -1;
		int responseCFU = -1;
		int result=-1;
		try
		{
		logger.info("##>isnide doProcessing in SoapRequestHandler request is ["+dataObject+"]");	
		if (Config.TESTING==1) {
			logger.info("\n\n\t\t**************Testing is Enabled***************\n\n");
			if ("SuccessTesting".equalsIgnoreCase(Config.TESTING_STRING)) {
				logger.info("Yes, TESTING_STRING contains the required String... TESTING_STRING ["+Config.TESTING_STRING+"]");
				if (dataObject.getReqType()==6) {
					dataObject.setIsPrePaidId("Y"); // In testing all msisdn is considered as Prepaid
					dataObject.setResponse("0");	
					logger.info(">>>>>"+dataObject.getMsisdn()+" is PrePaid");
					logger.debug("\n\tIn testing all msisdn considered as Prepaid");
				}
				else if (dataObject.getReqType()==3) {
					dataObject.setIsPrePaidId("Y"); // In testing all msisdn is considered as Prepaid
					dataObject.setResponse("0");
					logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Up Success");
				}
				else if (dataObject.getReqType()==4) {
					dataObject.setIsPrePaidId("Y"); // In testing all msisdn is considered as Prepaid
					dataObject.setResponse("0");
					logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Down Success");
				}
			} else {
				logger.info("No, TESTING_STRING doesn't contain the required String... TESTING_STRING ["+Config.TESTING_STRING+"]");
				if (dataObject.getReqType()==6) {
					dataObject.setResponse("-1");	
					logger.info(">>>>>"+dataObject.getMsisdn()+" subType NOT FOUND");
				}
				else if (dataObject.getReqType()==3) {
					dataObject.setResponse("-1");
					logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Up FAILURE");
				}
				else if (dataObject.getReqType()==4) {
					dataObject.setResponse("-1");
					logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Down FAILURE");
				}
			}
		}else {
			if(dataObject.getReqType() == 6)
			{
				client.getSubType(dataObject);
			}
			else if(dataObject.getReqType() == 3)
			{
				if (Config.VCC_CFNRC_ENABLE==1) {
					responseCFNRC = client.upFlag(dataObject, "CFNRC");
				}
				
				if (Config.VCC_CFNRY_ENABLE==1) {
					responseCFNRY = client.upFlag(dataObject, "CFNRY");
				}
				
				if (Config.VCC_CFB_ENABLE==1) {
					responseCFB = client.upFlag(dataObject, "CFB");
				}
				
				
				  if (Config.VCC_CFU_ENABLE==1) { responseCFU = client.upFlag(dataObject,
				  "CFU"); }
				
				logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] "
						+ "VCC_CFNRY_ENABLE["+Config.VCC_CFNRY_ENABLE+"] Flag Up responseCFNRY["+responseCFNRY+"] "
						+ "VCC_CFB_ENABLE["+Config.VCC_CFB_ENABLE+"] Flag Up responseCFB["+responseCFB+"] "
						+ "VCC_CFNRC_ENABLE["+Config.VCC_CFNRC_ENABLE+"] Flag Up responseCFNRC["+responseCFNRC+"] "
						+ "VCC_CFU_ENABLE["+Config.VCC_CFU_ENABLE+"] Flag Up responseCFU["+responseCFU+"]");
				
				if (Config.VCC_CFNRY_ENABLE!=1) {
					responseCFNRY = 1;
				}
				if (Config.VCC_CFB_ENABLE!=1) {
					responseCFB = 1;
				}
				if (Config.VCC_CFNRC_ENABLE!=1) {
					responseCFNRC = 1;
				}
				if (Config.VCC_CFU_ENABLE!=1) {
					responseCFU = 1;
				}
				
				if (responseCFNRY==1 && responseCFB==1 && responseCFNRC==1 && responseCFU==1) {
					result = 1;
				}
				
				if(result == 1){ 
				dataObject.setResponse("0");
				}
				else { 
				dataObject.setResponse("-1");
				
				}
			}
			else if(dataObject.getReqType() == 4)
			{
				
				if (Config.VCC_CFNRC_ENABLE==1) {
					responseCFNRC = client.downFlag(dataObject, "CFNRC");
				}
				
				if (Config.VCC_CFNRY_ENABLE==1) {
					responseCFNRY = client.downFlag(dataObject, "CFNRY");
				}
				
				if (Config.VCC_CFB_ENABLE==1) {
					responseCFB = client.downFlag(dataObject, "CFB");
				}
				
				if (Config.VCC_CFU_ENABLE==1) {
					responseCFU = client.downFlag(dataObject, "CFU");
				}
				
				logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] "
						+ "VCC_CFNRY_ENABLE["+Config.VCC_CFNRY_ENABLE+"] Flag Up responseCFNRY["+responseCFNRY+"] "
						+ "VCC_CFB_ENABLE["+Config.VCC_CFB_ENABLE+"] Flag Up responseCFB["+responseCFB+"] "
						+ "VCC_CFNRC_ENABLE["+Config.VCC_CFNRC_ENABLE+"] Flag Up responseCFNRC["+responseCFNRC+"] "
						+ "VCC_CFU_ENABLE["+Config.VCC_CFU_ENABLE+"] Flag Up responseCFU["+responseCFU+"]");
				
				
				if (Config.VCC_CFNRY_ENABLE!=1) {
					responseCFNRY = 1;
				}
				if (Config.VCC_CFB_ENABLE!=1) {
					responseCFB = 1;
				}
				if (Config.VCC_CFNRC_ENABLE!=1) {
					responseCFNRC = 1;
				}
				if (Config.VCC_CFU_ENABLE!=1) {
					responseCFU = 1;
				}
				
				if (responseCFNRY==1 && responseCFB==1 && responseCFNRC==1 && responseCFU==1) {
					result = 1;
				}
				
				if(result == 1){ 
				dataObject.setResponse("0");
				}
				else { 
				dataObject.setResponse("-1");
				
				}
			}
			logger.info("##>inside doProcessing in SoapRequestHandler Response is ["+dataObject+"]");	
			return 1;
		}

		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		return -1;
	}
		
	public boolean keepAlive() {
		 
		return false; //not requied in Soap
	}
	public boolean isConnected() {
		return false; //not required in Soap
	}


	public long getObjectNo() {
		// TODO Auto-generated method stub
		return objectNo;
	}
}
