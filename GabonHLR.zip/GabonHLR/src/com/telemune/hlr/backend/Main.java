package com.telemune.hlr.backend;

import java.io.DataInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.PrintStream;

import javax.imageio.stream.FileImageInputStream;

public class Main {
	
	public static void main(String arg[])
	{
		try
		{
		String str = "RESP:0:MSISDN,50373869410:IMSI,706021008397243:AUTHD,AVAILABLE:PDPCP,1:CSP,10:CAMEL,GPRSTDP,12,GSA,50377600860,SK,10,DEH,0,CCH,3,GPRSTDP,14,GSA,50377600860,SK,10,DEH,0,CCH,3,OCAMEL,GCSO,0,SSLO,1,MCSO,0,GC2SO,0,MC2SO,0,GC3SO,0,MC3SO,0,GC4SO,0,MC4SO,0,GPRSSO,0,OSMSSO,0,MMSO,0,ECAMEL,ETICK,0,ETINCI,0,EOICK,0,EOINCI,0:NAM,0:BAIC,1,0,TS10,0,TS20,0,BS20:BAOC,1,0,TS10,0,TS20,0,BS20:BOIC,1,0,TS10,0,TS20,0,BS20:BICRO,1,0,TS10,0,TS20,0,BS20:BOIEXH,1,0,TS10,0,TS20,0,BS20:CFU,1,0,TS10,0,BS20:CFB,1,0,TS10,0,BS20:CFNRC,1,0,TS10,0,BS20:CFNRY,1,0,TS10,0,BS20:DCF,1,1,50377601180,25,TS10,1,50377601180,25,BS20:CAW,1,1,TS10,1,BS20:BS25,1:BS26,1:CAT,10:CLIP,1:DBSG,1:HOLD,1:MPTY,1:OICK,10:OFA,1:PWD,0000:SOCB,0:SOCFB,0:SOCFRC,0:SOCFRY,0:SOCFU,0:SOCLIP,0:SODCF,0:SOSDCF,7:TS11,1:TS21,1:TS22,1:LOC,4-50377600600,,50377600600,,4-50377600850:VLRID,4-50377600600:GPRCSI,1:REDMCH,1:IMEISV,8669370216962907:GPRSCSIST,1:OCSIST,1:TCSIST,1;";
		System.out.println("Bytes["+str.getBytes().length+"]");
		
			if(str.contains("OICK,"))
		{
			//OICK,331:
			str = str.substring(str.lastIndexOf("OICK,"));
			str = str.substring(5,7);
			System.out.println("value["+str+"]");
			
		}
		else
		{
			System.out.println("Not contains...");
		}	
		
		
		if (Integer.parseInt(str) == 10) {
			
			System.out.println("Prepaid ...");
		} else if(Integer.parseInt(str) == 90)  {
			System.out.println("Postpaid ..");
		}
		
		
		//three digit random number
		/*for(int i=0;i<100;i++)
		{
		long n3 = Math.round(Math.random()*(999 - 100) + 100);
        System.out.println ("Number["+n3+"]");
		}*/
		
		
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		
		String strdata = "GET:HLRSUB:MSISDN,12462142515;";
		String[] val = strdata.split(",");
		String curdata = val[1].substring(0,val[1].length()-1);
		System.out.println("number["+curdata+"]");
		
		StringBuffer buffer = new StringBuffer();
		buffer.append("RESP:0;Enter command:");
		
		if(buffer.toString().contains("Enter command:"))
		{
			System.out.println("Yes");
		}
		else {
			System.out.println("No");
		}
		
		
		String logincommand = "LGI: HLRSN=1,OPNAME='harry', PWD='harry';";
		String[] spiltData = logincommand.split(",");
		for(int i = 0;i < spiltData.length;i++)
			System.out.println("array["+i+"] val["+spiltData[i]+"]");
		
		
	

		}
	
}
