package com.telemune.hlr.backend;

import java.net.Socket;

public class DataObject {
	
	private int reqId = -1; 
	private String msisdn = "";
	private int reqType = -1;
	private String msrn = "";
	private String mscNo = "";
	private String imsi = "";
	private String scfAddr = ""; 
	private int serviceKey = -1; 
	private String isPrePaidId = "";
	private String isRoaming = "";
	private String response = "";
	private String busyNo = "";
	private String noReachNo = "";
	private String isCFU = "";
	private String noReply = "";
	private Socket sock=null;
	private String hlrUrl = null;
	private int conTimeout = -1;
	private String CFU = "";
	private String Interface;
	private String status;
	private long hlrReqId = -1;
	private int sendNextHlr = -1;
	
	private String oldSubType;
	private String newSubType;
	

	public String getCFU(){
		return CFU;
	}
	public void setCFU(String CFU){
		this.CFU=CFU;
	}
	
	public int getConTimeout() {
		return conTimeout;
	}
	public void setConTimeout(int conTimeout) {
		this.conTimeout = conTimeout;
	}
	
	public String getHlrUrl() {
		return hlrUrl;
	}
	public void setHlrUrl(String hlrUrl) {
		this.hlrUrl = hlrUrl;
	}
	public Socket getSock() {
		return sock;
	}
	public void setSock(Socket sock) {
		this.sock = sock;
	}
	public int getReqId() {
		return reqId;
	}
	public void setReqId(int reqId) {
		this.reqId = reqId;
	}

	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public int getReqType() {
		return reqType;
	}
	public void setReqType(int reqType) {
		this.reqType = reqType;
	}

	public String getMsrn() {
		return msrn;
	}
	public void setMsrn(String msrn) {
		this.msrn = msrn;
	}

	public String getMscNo() {
		return mscNo;
	}
	public void setMscNo(String mscNo) {
		this.mscNo = mscNo;
	}

	public String getImsi() {
		return imsi;
	}
	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public String getScfAddr() {
		return scfAddr;
	}
	public void setScfAddr(String scfAddr) {
		this.scfAddr = scfAddr;
	}

	public int getServiceKey() {
		return serviceKey;
	}
	public void setServiceKey(int serviceKey) {
		this.serviceKey = serviceKey;
	}

	public String getIsPrePaidId() {
		return isPrePaidId;
	}
	public void setIsPrePaidId(String isPrePaidId) {
		this.isPrePaidId = isPrePaidId;
	}

	public String getIsRoaming() {
		return isRoaming;
	}
	public void setIsRoaming(String isRoaming) {
		this.isRoaming = isRoaming;
	}

	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}

	public String getBusyNo() {
		return busyNo;
	}
	public void setBusyNo(String busyNo) {
		this.busyNo = busyNo;
	}

	public String getNoReachNo() {
		return noReachNo;
	}
	public void setNoReachNo(String noReachNo) {
		this.noReachNo = noReachNo;
	}

	public String getIsCFU() {
		return isCFU;
	}
	public void setIsCFU(String isCFU) {
		this.isCFU = isCFU;
	}

	public String getNoReply() {
		return noReply;
	}
	public void setNoReply(String noReply) {
		this.noReply = noReply;
	}
	
	public String getInterface() {
		return Interface;
	}
	public void setInterface(String interface1) {
		Interface = interface1;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public long getHlrReqId() {
		return hlrReqId;
	}
	public void setHlrReqId(long hlrReqId) {
		this.hlrReqId = hlrReqId;
	}
	public int getSendNextHlr() {
		return sendNextHlr;
	}
	public void setSendNextHlr(int sendNextHlr) {
		this.sendNextHlr = sendNextHlr;
	}
	public String getOldSubType() {
		return oldSubType;
	}
	public void setOldSubType(String oldSubType) {
		this.oldSubType = oldSubType;
	}
	public String getNewSubType() {
		return newSubType;
	}
	public void setNewSubType(String newSubType) {
		this.newSubType = newSubType;
	}
	@Override
	public String toString() {
		return "DataObject [reqId=" + reqId + ", msisdn=" + msisdn
				+ ", reqType=" + reqType + ", msrn=" + msrn + ", mscNo="
				+ mscNo + ", imsi=" + imsi + ", scfAddr=" + scfAddr
				+ ", serviceKey=" + serviceKey + ", isPrePaidId=" + isPrePaidId
				+ ", isRoaming=" + isRoaming + ", response=" + response
				+ ", busyNo=" + busyNo + ", noReachNo=" + noReachNo
				+ ", isCFU=" + isCFU + ", noReply=" + noReply + ", sock="
				+ sock + ", hlrUrl=" + hlrUrl + ", conTimeout=" + conTimeout
				+ ", CFU=" + CFU + ", Interface=" + Interface + ", status="
				+ status + ", hlrReqId=" + hlrReqId + ", sendNextHlr="
				+ sendNextHlr + ", oldSubType=" + oldSubType + ", newSubType="
				+ newSubType + "]";
	}
    
	
	
}
