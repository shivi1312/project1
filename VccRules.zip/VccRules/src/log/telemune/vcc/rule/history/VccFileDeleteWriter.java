package log.telemune.vcc.rule.history;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.PhoneNumberUtil.PhoneNumberFormat;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;
import com.telemune.vcc.config.AppConfig;

public class VccFileDeleteWriter {
	private final static Logger logger = Logger
			.getLogger(VccFileDeleteWriter.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	public String getRecordFilePath(String msisdn, String recordFileName,
            String bashPath) {
		String recordFilePath = null;
		try {
			
			
			String tempName = null;
			String calledNum = null;
			calledNum = this.msisdnWithoutCountryCode(msisdn);
			
			tempName = recordFileName.substring(0, recordFileName.length()
				- AppConfig.config.getInt("default_record_digits"));
			calledNum = msisdn;

			recordFilePath = getCompletePath(tempName, calledNum,
				recordFileName, bashPath);
			//logger.info("delete path: "+recordFilePath);
			logger.info(recordFilePath);
			return recordFilePath;
		}catch(Exception e){
			logger.debug("number [" + msisdn + "] error while delete physical file: "+e.getMessage());
			return recordFilePath;
		}    
    }
	
	
	public String getCompletePath(String startEightDigits, String calledNum, String recordFileName, String basePath) {
		StringBuilder filepathBuilder = null;
		try
		{
		int msisdnLength = AppConfig.config.getInt("msisdn_length", 10);
		calledNum = this.msisdnWithoutCountryCode(calledNum);
	//	logger.debug(String.format("[%s] length with country code [%s]", calledNum, msisdnLength));
		if (calledNum.length() < msisdnLength) {
		//	logger.info(
					//String.format("Handle fixed line: [%s] length with country code [%s]", calledNum, msisdnLength));
			calledNum = "0" + calledNum;
		//	logger.info(String.format("fixed line msisdn after handling: [%s]", calledNum));
		}
		String dir_format = AppConfig.config.getString("dir_format", "yy/MM/dd/HH/N3/N3");
		String date_dir_format = dir_format.substring(0, dir_format.indexOf("N") - 1);
		String msisdn_dir_format = this.msisdnFormator(dir_format, calledNum);
	//	logger.debug("Date dir [" + date_dir_format + "] msisdn dir [" + msisdn_dir_format + "]");

		 filepathBuilder = new StringBuilder();
		filepathBuilder.append(startEightDigits.substring(0, startEightDigits.length() - 6));
		filepathBuilder.append("/");
		filepathBuilder
			.append(startEightDigits.substring(startEightDigits.length() - 6, startEightDigits.length() - 4));
		filepathBuilder.append("/");
		filepathBuilder
			.append(startEightDigits.substring(startEightDigits.length() - 4, startEightDigits.length() - 2));
		filepathBuilder.append("/");
		filepathBuilder.append(startEightDigits.substring(startEightDigits.length() - 2, startEightDigits.length()));
		//logger.debug("file path [" + filepathBuilder.toString() + "]");

		try {

			DateFormat srcDf = new SimpleDateFormat(date_dir_format);
			String myDate = String.valueOf(filepathBuilder);
			Date date = srcDf.parse(myDate);
			DateFormat destDf = new SimpleDateFormat("yy" + date_dir_format);
			myDate = destDf.format(date);
			myDate = myDate.replace("/", File.separator);

			filepathBuilder = new StringBuilder();
			filepathBuilder.append(basePath);

			filepathBuilder.append(File.separator);
			filepathBuilder.append(myDate);

			filepathBuilder.append(File.separator);
			filepathBuilder.append(msisdn_dir_format.replace("/", File.separator));
			filepathBuilder.append(File.separator);

			if (recordFileName != null) {

				filepathBuilder.append(recordFileName);
				filepathBuilder.append(".wav");
			}

		} catch (Exception e) {
		//	logger.debug("error "+e.getMessage());
			return null;
		}
		}
		catch(Exception ex)
		{
			//logger.debug("error "+ex.getMessage());
			return null;
		}
//logger.debug("file path is "+filepathBuilder.toString());
		return filepathBuilder.toString();
	}
	
	public String msisdnFormator(String format, String msisdn) {
        String[] dir_format_array = format.substring(format.indexOf("N"), format.length()).split("/");
        String msisdn_dir_format = "";
        int start = 0;
        int d = 0;
        try {
            for (String dg : dir_format_array) {
                d = Integer.parseInt(dg.substring(1, dg.length()));
                if (msisdn.length() >= d + start)
                    msisdn_dir_format = msisdn_dir_format + msisdn.substring(start, d + start) + "/";
                else
                    msisdn_dir_format = msisdn_dir_format + msisdn.substring(start, msisdn.length()) + "/";
                start += d;
            }
           // logger.debug("new: " + format.substring(0, format.indexOf("N")) + msisdn_dir_format);
        } catch (ArrayIndexOutOfBoundsException e) {

        } catch (NullPointerException npe) {

        }
        return msisdn_dir_format;
    }


	
	
	public String msisdnWithoutCountryCode(String msisdn) {
		msisdn = this.convertToNationalNumber( msisdn, AppConfig.config.getString("country_special_code","AE"));	
		
		return msisdn;
	}
	public String convertToNationalNumber(String msisdn, String code) {

		PhoneNumber number = null;
		PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
		try {
			number = phoneUtil.parse(msisdn, code);
		} catch (NumberParseException e) {
			e.printStackTrace();
			return msisdn;
		}

		String convertMsisdn = phoneUtil.format(number, PhoneNumberFormat.NATIONAL).toString().replace(" ", "")
			.replace("(", "").replace(")", "").replace("-", "");

		if (convertMsisdn.startsWith("0")) {
			convertMsisdn = convertMsisdn.substring(1, convertMsisdn.length());
		}

	//	logger.debug("number [" + msisdn + "] to national number [" + convertMsisdn + "]");
		return convertMsisdn;
	}
	 

}
