package com.test;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@SuppressWarnings("unused")
public class Client {
	public static void main(String[] args) {
		ExecutorService threadPool = Executors.newFixedThreadPool(10);
		DataOutputStream out;
		DataInputStream reader;
		String actionId = "";
		String serviceType = "";
		
		try {
			actionId = args[0];
			serviceType = args[1];
		} catch (Exception e) {
			actionId = "1";
			serviceType = "0010";
		}
		try {
			System.out.println("start time: "+new Date());
			for(int i = 0; i < 1; i++){
				//long number = (long) Math.floor(Math.random() * 9000000000L) + 1000000000L;
				String number="569963900";
				String json = "{\"msisdn\":\"971"+number+"\",\"reqBy\":\"971"+number+"\",\"serviceType\":\""
						+ serviceType
						+ "\",\"planName\":\"executive\",\"interFace\":\"ivr\",\"actTrg\":1,"
						+ "\"actionId\":\""
						+ actionId
						+ "\",\"tid\":\"1121132444\",\"channel\":\"rec\",\"appId\":\"vcc\",\"action\":1,\"changedMsisdn\":\""+number+"\",\"lang\":1,\"status\":\"success\"}";
				threadPool.execute(new Worker(json));
				//Thread.sleep(1000);
			}
			System.out.println("end time: "+new Date());
			threadPool.shutdown();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

/*
package com.test;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

@SuppressWarnings("unused")
public class Client {
	public static void main(String[] args) {
		DataOutputStream out;
		DataInputStream reader;
		String actionId = "";
		String serviceType = "";
		try {
			actionId = args[0];
			serviceType = args[1];
		} catch (Exception e) {
			actionId = "1";
			serviceType = "0100";
		}
		String json = "{\"msisdn\":\"8800000001\",\"reqBy\":\"8800000001\",\"serviceType\":\""
				+ args[1]
				+ "\",\"interFace\":\"ivr\",\"actTrg\":1,"
				+ "\"planName\":\"default\",\"actionId\":\""
				+ args[0]
				+ "\",\"tid\":\"1121132444\",\"channel\":\"rec\",\"appId\":\"vcc\",\"action\":3,\"changedMsisdn\":\"8800000001\",\"lang\":1}";
		String json = "{\"msisdn\":\"8800000011\",\"reqBy\":\"8800000011\",\"serviceType\":\""
				+ args[1]
				+ "\",\"interFace\":\"ivr\","
				+ "\"actionId\":\""
				+ args[0]
				+ "\",\"tid\":\"1121132444\",\"channel\":\"rec\",\"appId\":\"vcc\"}";
		System.out.println("json: " + json);
		try {
			Socket socket = new Socket("10.168.3.69", 9099);
			out = new DataOutputStream(socket.getOutputStream());
			out.writeUTF(json);
			out.flush();
			reader = new DataInputStream(socket.getInputStream());
			System.out.println("response: " + reader.readUTF());
			out.close();
			reader.close();
			socket.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
*/