package com.test;


public class Main {

	public static void main(String[] args) {
		// System.out.println("plan type: "+AppConfig.config.getString("state(1).transition(0)[@source]"));
		// Iterator it = AppConfig.config.getKeys("state");

		/*
		 * while (it.hasNext()) { System.out.println("key: " + it.next() +
		 * " value: " + AppConfig.config.getString((String) it.next())); }
		 */
		
		 /*UntypedStateMachineBuilder builder = VccStateMachineFactory
		 .getFactory("1");
		 */
		/*UntypedStateMachineBuilder builder = StateMachineBuilderFactory
				.create(VccSubscriptionController.class);
		*/// UntypedStateMachineBuilder builder =
		// VccStateMachineFactory.getFactory("1");
		/*
		 * builder.externalTransition().from("Init").to("CanSubscribe").on("init"
		 * ) .callMethod("canSubscribe");
		 */
		/*builder.externalTransition().from("Init").to("Start").on("init")
				.callMethod("isAlreadySubscriber");
		*//*
		 * builder.externalTransition().from("Start").to("AlreadySubscriber").on(
		 * "exist") .callMethod("alreadySubscriber");
		 *//*builder.externalTransition().from("AlreadySubscriber").to("Finish")
				.on("end").callMethod("doFinish");

		builder.externalTransition().from("CanSubscribe").to("RatePlan")
				.on("pt").callMethod("getValidRatePlan");
		builder.externalTransition().from("RatePlan").to("ChargingCode")
				.on("cc").callMethod("getChargingPriceByChargingCode");
		builder.externalTransition().from("ChargingCode").to("Subscribe")
				.on("sub").callMethod("doSubscribe");
		builder.externalTransition().from("Subscribe").to("SaveDetail")
				.on("save").callMethod("saveSubscriptionDetail");
		
		 * builder.externalTransition().from("Subscribe").to("Finish")
		 * .on("end").callMethod("doFinish");
		 
		builder.externalTransition().from("SaveDetail").to("Finish").on("end")
				.callMethod("doFinish");
*/
		/*
		 * builder.externalTransition().from("Start").to("CanSubscribe").on(
		 * "checkSub") .callMethod("canSubscribe");
		 *//*
		builder.transitions().from("Start").toAmong("AlreadySubscriber")
				.onEach("exist").callMethod("alreadySubscriber");
		builder.transitions().from("Start").toAmong("CanSubscribe")
				.onEach("checkSub").callMethod("canSubscribe");
*/
		/*
		 * builder.externalTransition().from("CanSubscribe").to("SubType").on(
		 * "checkSub") .callMethod("getSubType");
		 * builder.externalTransition().from
		 * ("CanSubscribe").to("ServiceClass").on("checkSub")
		 * .callMethod("getServiceClass");
		 * builder.externalTransition().from("CanSubscribe"
		 * ).to("OperatorRange").on("checkSub") .callMethod("getOperatorRange");
		 */
		/*
		 * builder.onEntry("SubType").callMethod("getSubType");
		 * builder.onEntry("ServiceClass").callMethod("getServiceClass");
		 * builder.onEntry("OperatorRange").callMethod("getOperatorRange");
		 */
		/*
		 * builder.transitions().from("Start") .toAmong("AlreadySubscriber",
		 * "CanSubscribe") .onEach("exist", "checkSub")
		 * .callMethod("alreadySubscriber|canSubscribe|_");
		 */
		/*
		 * builder.transitions().from("Start").toAmong("AlreadySubscriber")
		 * .onEach("exist").callMethod("alreadySubscriber");
		 * builder.transitions().from("Start").toAmong("CanSubscribe")
		 * .onEach("checkSub").callMethod("canSubscribe");
		 */
		/*
		 * builder.transitions().from("CanSubscribe")
		 * .toAmong("AlreadySubscriber", "CanSubscribe") .onEach("exist",
		 * "checkSub") .callMethod("alreadySubscriber|canSubscribe|_");
		 */

		// builder.transitions().fromAmong("Subscribe","SaveDetail","CanSubscribe","AlreadySubscriber").to("Finish").on("end").callMethod("doFinish");

		// String entry = "CanSubscribe,SubType,ServiceClass,OperatorRange";
		// String[] starr = entry.split(",");
		// builder.defineParallelStatesOn(starr);
		// builder.defineParallelStatesOn("CanSubscribe","ServiceClass");
		// builder.defineParallelStatesOn("CanSubscribe","OperatorRange");

		/*UntypedStateMachine fsm = builder.newStateMachine("Init");
		Data data = new Data();
		String json = "{\"msisdn\":\"8800544347\",\"serviceType\":\"0010\",\"actionId\":1,\"planName\":\"default\",\"tid\":\"1121132444\",\"channel\":\"rec\"}";
		VccEvent vccEvent = new VccEvent("init");
		data.setVccEvent(vccEvent);
		data.setData(json);
		data.setMsisdn("8800544347");
		data.setActionId("1");
		data.setTid("1121132444");
		System.out.println(fsm.getAllStates());
		fsm.addDeclarativeListener(new VoiceNoteVccListener(data));
		try {
			fsm.fire("init", data);
			while (data.getVccEvent().getHasNextEvent()) {
				fsm.fire(data.getVccEvent().getNextEvent(), data);
				if (data.getVccEvent().getPreEvent()
						.equals(data.getVccEvent().getCurrentEvent())) {
					data.getVccEvent().setHasNextEvent(false);
					System.out.println("from " + data.getVccState().getFrom()
							+ " to " + data.getVccState().getTo()
							+ " no next state defined");
				}
				data.getVccEvent().setPreEvent(
						data.getVccEvent().getCurrentEvent());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		 * VccRatePlanModel rate = new VccRatePlanModel();
		 * rate.setScope("{\"ST\":\"P,O\"}"); rate.setPlanId(1);
		 * List<VccRatePlanModel> rateModelList = new
		 * ArrayList<VccRatePlanModel>(); rateModelList.add(rate); ScopeModel
		 * scopeModel = new ScopeModel(); scopeModel.setST("P");
		 * scopeModel.setOR("0"); scopeModel.setSC("0"); VnRequest vnRequest =
		 * new Gson().fromJson(json, VnRequest.class);
		 * System.out.println("response: "+data.getVccResponse()); new
		 * ScopeUtil().getTarrifId(rateModelList, scopeModel, vnRequest);
		 */
	}

}
