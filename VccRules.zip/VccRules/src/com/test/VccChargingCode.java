package com.test;

public class VccChargingCode {
	private int chargingCode;
	private String chargingValue;
	public int getChargingCode() {
		return chargingCode;
	}
	public void setChargingCode(int chargingCode) {
		this.chargingCode = chargingCode;
	}
	public String getChargingValue() {
		return chargingValue;
	}
	public void setChargingValue(String chargingValue) {
		this.chargingValue = chargingValue;
	}
	
}
