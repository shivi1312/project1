package com.test;

import com.telemune.vcc.config.AppConfig;

public class Json {
	public static void main(String [] args){
		System.out.println("key: "+AppConfig.config.getString("action.1"));
	}
}
