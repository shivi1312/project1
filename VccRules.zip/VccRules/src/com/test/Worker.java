package com.test;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public class Worker implements Runnable{
	DataOutputStream out;
	DataInputStream reader;
	String json = "";
	Socket socket;
	public Worker(String json){
		this.json = json;
	}
	@Override
	public void run(){
		try{
			socket = new Socket("localhost", 9099);
			out = new DataOutputStream(socket.getOutputStream());
			out.writeUTF(json);
			out.flush();
			reader = new DataInputStream(socket.getInputStream());
			System.out.println("response: " + reader.readUTF());
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(reader != null)
					reader.close();
				if(out != null)
					out.close();
				if(socket != null && !socket.isClosed())
					socket.close();
			}catch(Exception e){
				
			}
		}
	}
	
}
