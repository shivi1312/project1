package com.telemune.vcc.HLR;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.handler.SubscribeHandler;

public class FetchMsrn {
	static String MSRN_FETCH_HOST = "127.0.0.1";
	static short MSRN_FETCH_PORT = 8777;
	final static int SERVICE_NORMAL_MSRN = 1;
	final static int SERVICE_INTERROGATE_MSRN = 15;
	final static int SERVICE_FORWARDING_INFO = 2;
	final static int SERVICE_ACTIVATE_SS = 3;
	final static int SERVICE_DEACTIVATE_SS = 4;
	final static int SERVICE_MSRN_NO_FORWARD = 5;
	final static int SERVICE_SRI = 6;
	final static int SERVICE_DUMMY_LOCUPD = 7;
	final static int SERVICE_DEACTIVATE_IMSI = 12;
	final static int SERVICE_ACTIVATE_IMSI = 13;
	final static int SERVICE_RETRIEVE_IMSI = 9;

	//private static Logger log = Logger.getLogger(FetchMsrn.class);
	final static Logger log = Logger.getLogger(FetchMsrn.class);
	
	
	public static int fetchmsrn(int service, String msisdn,
			StringBuffer msrnBuf, String mscNo, StringBuffer imsiBuf,
			String scfAddress, Integer serviceKey, Boolean isroaming,
			Boolean isprepaid, Integer error, String busyNumber,
			String noReplyNumber, String unreachableNumber, Boolean cfuActive,
			StringBuffer cfuActiveStr) {
		
		System.out.println("Inside Function fetchmsrn");
		int retVal = -1;
		Properties properties = null;
		FileInputStream fis1 = null;
		log.info("in fetchmsrn'" + msisdn + "'");
		Socket socket = null;
		DataOutputStream writer = null;
		DataInputStream reader = null;
		int result = -1;
		log.info("MSRN_FETCH_HOST["
				+ AppConfig.config.getString("MSRN_FETCH_HOST", "10.168.3.57")
				+ "] MSRN_FETCH_PORT["
				+ AppConfig.config.getString("MSRN_FETCH_PORT", "8778") + "]");
		try {
			socket = new Socket(AppConfig.config.getString("MSRN_FETCH_HOST",
					"10.168.3.57"), Integer.parseInt(AppConfig.config
					.getString("MSRN_FETCH_PORT", "8778")));
			socket.setSoTimeout(AppConfig.config.getInt("HLR_SOCKET_TIMEOUT", 3000));
		} catch (SocketException se) {
			log.error("ErrorCode [VCC-RE-90011] MSISDN["+msisdn+"] [Socket Exception in opening socket] Error[ "
					+ se.getMessage()+"]");
			// log.error("Error in opening socket\n");
			se.printStackTrace();
			return -1;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
		log.debug("Socket Connection established");

		String requestBuffer = "";
		int requestId = 1;

		requestBuffer = requestBuffer + requestId + "\n" + service;
		String msrn = "";
		String imsi = "";
		String forwardNumber = "";

		switch (service) {
		case SERVICE_NORMAL_MSRN: // request for normal msrn query...
		case SERVICE_INTERROGATE_MSRN: // request for normal msrn query...
		case SERVICE_ACTIVATE_SS: // request for activate SS
		case SERVICE_DEACTIVATE_SS: // request for deativate SS
		case SERVICE_RETRIEVE_IMSI: // request for deativate SS
		case SERVICE_MSRN_NO_FORWARD: // request for msrn without forwarded info
		case SERVICE_SRI: // request for SRI..( to check prepaid)
			if (msisdn == null) {
				msisdn = "";
			}
			requestBuffer = requestBuffer + "\n" + msisdn;
			break;
		case SERVICE_FORWARDING_INFO: // request for update location...
		case SERVICE_DEACTIVATE_IMSI:
		case SERVICE_ACTIVATE_IMSI:
			if (msisdn == null) {
				msisdn = "";
			}
			if (mscNo == null) {
				mscNo = "";
			}
			if (imsi == null) {
				imsi = "";
			}
			/*requestBuffer = requestBuffer + "\n" + msisdn + "\n" + mscNo + "\n"
					+ imsi;*/
			requestBuffer = (new StringBuilder(String.valueOf(requestBuffer)))
					.append("\n").append(msisdn).append("\n").append(mscNo)
					.append("\n").append(imsi).toString();
			break;
		default:
			log.info("Unknown Service Request\n");
		}

		int length = requestBuffer.length();

		// byte[] lengthBuf = new byte[4];
		// lengthBuf[1] = (byte)((length >> 16) & 0xff);
		// lengthBuf[0] = (byte)((length >> 24) & 0xff);
		// lengthBuf[3] = (byte)(length & 0xff);
		// lengthBuf[2] = (byte)((length >> 8) & 0xff);

		try {
			reader = new DataInputStream(socket.getInputStream());
			writer = new DataOutputStream(socket.getOutputStream());
		} catch (IOException ioe) {

			log.error("ErrorCode [VCC-RE-90002] MSISDN["+msisdn+"] [Input output Exception in fetchMsrn()] Error[ "
					+ ioe.getMessage()+"]");
			ioe.printStackTrace();
			return -1;
		}
		log.debug("input/output stream established");

		try {
			
			log.debug("Writing to output stream. RequestBuffer["+requestBuffer+"]");
			writer.writeInt(length);
			writer.write(requestBuffer.getBytes(), 0, requestBuffer.length());

			// This can be made a different method.
			//
			log.debug("reading stream");
			int responseLen = reader.readInt();
			log.info("Response Length : "+responseLen);
			byte responseBuf[] = new byte[responseLen + 1];
			
			reader.read(responseBuf, 0, responseLen);

			responseBuf[responseLen] = '\0';
			socket.close();
			log.debug("socket closed");

			String response = new String(responseBuf);
			log.info("response  " + response);
			/*StringTokenizer st = new StringTokenizer(response,"\n");*/
			String []tokens = response.split("\\n");
			/*log.info("Count tokens : "+st.countTokens());
			String[] tokens = new String[st.countTokens()];
			int ctr = 0;
			while (st.hasMoreTokens()) {
				tokens[ctr] = st.nextToken();
				log.info("["+ctr+"]----> ["+tokens[ctr]+"]");
				ctr++;
			}*/

			log.info("Tokens Length [" + tokens.length + "]");

			msrn = tokens[1];
			if (msrn.equals("NULL")) {
				msrn = "";
			}
			// msrnBuf = msrnBuf.append(msrn);

			mscNo = tokens[2];
			if (mscNo.equals("NULL")) {
				mscNo = "";
			}
			imsi = tokens[3];

			if (imsi.equals("NULL")) {
				imsi = "";
			}
			imsiBuf.append(imsi);

			scfAddress = tokens[4];
			if (scfAddress.equals("NULL")) {
				scfAddress = "";
			}
			try {
				serviceKey = new Integer(tokens[5]);
			} catch (NumberFormatException nfe) {
				log.error("ErrorCode [VCC-RE-90004] [NumberFormatException in fetchMsrn()] Error["
						+ nfe.getMessage()+"]");
				serviceKey = new Integer(0);
				nfe.printStackTrace();
			}
			if (tokens[6].equals("N")) {
				isprepaid = new Boolean(false);
			} else {
				isprepaid = new Boolean(true);
			}
			log.info("6.Is  prepaid value  [ " + isprepaid + " ]  Token [6]");
			if (tokens[7].equals("N"))
				isroaming = new Boolean(false);
			else
				isroaming = new Boolean(true);
			log.info("7.Is roaming is [ " + isroaming + " ]");
			/* Commented by Richard on 11th June 2019
			 * if (tokens[8].equals("NULL")) { 
			 */
			if (tokens[8].equals("NULL") || tokens[8].equals("")) {
				error = new Integer(0);
			} else {
				try {
					error = new Integer(tokens[8]);
				} catch (NumberFormatException nfe) {
					log.error("ErrorCode [VCC-RE-90004] [NumberFormatException in fetchMsrn()] Error["
							+ nfe.getMessage()+"]");
					error = new Integer(-1);
					nfe.printStackTrace();
				}
			}
			log.info("8.Error Value [ " + error + " ]");

			busyNumber = tokens[9];
			if (busyNumber.equals("NULL")) {
				busyNumber = "";
			}
			log.info("9.Busy Number [ " + busyNumber + " ]");
			noReplyNumber = tokens[10];
			if (noReplyNumber.equals("NULL")) {
				noReplyNumber = "";
			}
			log.info("10.No Reply  Number [ " + noReplyNumber + " ]");
			unreachableNumber = tokens[11];

			if (unreachableNumber.equals("NULL")) {
				unreachableNumber = "";
			}

			log.info("11.Un Reachable  Number [ " + unreachableNumber + " ]");
			// if (tokens[11].equals("N"))

			if (tokens[12].charAt(0) == 'N') {
				cfuActive = new Boolean(false);
				// cfuActiveStr=cfuActiveStr.append("false");
			} else {
				cfuActive = new Boolean(true);
				// cfuActiveStr = cfuActiveStr.append("true");
			}
			log.info("12.CFU Active [ " + cfuActive + " ]");
			forwardNumber = tokens[13];
			if (forwardNumber.equals("NULL")) {
				forwardNumber = "";
			}

			// msrnBuf = msrnBuf.append(forwardNumber);
			log.info("13.Forword Number [ " + cfuActive + " ]");
			log.info("Return Value from HLR is [ " + error.intValue()
					+ " ] ");
			// Added by rajendra return 1 for PREPAID 2 for POSTPAID
			
			if (error.intValue() != 0) {
				log.info(msisdn
						+ "#Error Return From HLR Return Value is [ "
						+ error.intValue() + " ]");
				log.error("ErrorCode [VCC-RE-00018] [Returning error from HLR] ["+error.intValue()+"]");
				retVal = -1; // Error Return From HLR
			} else {
				log.info(msisdn
						+ "#Success Return from HLR Return Value is [ "
						+ error.intValue() + " ] Token 6 Value is [ "
						+ tokens[6] + " ]");

				retVal=1;
				
				if(service==6)
				{
					if (tokens[6].equalsIgnoreCase(("N"))) {
						log.info(msisdn + "# is Post Paid Number");
						retVal=2;
					} else {
						log.info(msisdn + "# is Prepaid Number");
						retVal=1;
					}
				}
				
			}
			log.info("exiting fetchmsrn:with  return value= "
					+ error.intValue() + " retVal[" + retVal + "]isPrepaid["
					+ isprepaid + "]");
		}catch(IOException ioe){
			log.error("ErrorCode [VCC-RE-90002] [Input output Exception in fetchMsrn()] Error[ "
					+ ioe.getMessage()+"]");
		} catch (Exception e) {
			log.error("ErrorCode [VCC-RE-00060] [Exception in fetchMsrn()] Error[ "+e.getMessage()+"]");
			e.printStackTrace();
		}
		return retVal;
	} // fetchmsrn
}
