package com.telemune.vcc.HLR;

public class FetchMs {

}
