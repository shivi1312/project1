package com.telemune.vcc.config;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import org.apache.commons.configuration.CombinedConfiguration;
import org.apache.commons.configuration.DefaultConfigurationBuilder;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.vcc.rule.common.CacheLoader;
import com.telemune.vcc.rule.common.VccCache;
import com.telemune.vcc.util.AppContext;

public class AppConfig {
	public static CombinedConfiguration config;
	static Logger logger = Logger.getLogger(AppConfig.class);
	static Logger errorLogger = Logger.getLogger("errorLogger");
	
	static {
		try {
			DefaultConfigurationBuilder builder = new DefaultConfigurationBuilder();
			builder.setFile(new File("properties/config.xml"));
			config = builder.getConfiguration(true);
			readDatabaseConfig();
						
		}catch(NullPointerException npe){
			errorLogger.error("ErrorCode [VCC-RE-90003] [Null Pointer Exception in reading config File] Error[ "+npe.getMessage()+"]");
		}
		catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00070] [Exception in reading config File] Error[ "+e.getMessage()+"]");
			e.printStackTrace();
		}
	}

	public static void readDatabaseConfig() {
		try {
			DataSource dataSource = (DataSource) AppContext.context
					.getBean("dataSource");
			String query = "SELECT * FROM APP_CONFIG_PARAMS";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			List<AppConfigParam> list = jdbcTemplate.query(query,
					new AppConfigParamRowMapper());

			for (AppConfigParam param : list)
				config.setProperty(param.getParamName(), param.getParamValue());
			
			VccCache.map.put(CacheLoader._acp_prefix, "Reload AppConfigParams",
							AppConfig.config.getInt("app_config_param_cache_time", 2),
							TimeUnit.MINUTES);
		}
		catch (Exception e) {
			e.printStackTrace();
			errorLogger.error("ErrorCode [VCC-RE-00002] [Exception while reading APP_CONFIG_PARAMETER] Error["+e.getMessage()+"]");
		}
	}
}