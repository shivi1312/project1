 package com.telemune.vcc.charging;

import org.apache.log4j.Logger;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.handler.SubscribeHandler;
import com.telemune.vcc.rule.model.VccChargingCodeModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.util.ErrorCodes;
import com.telemune.vcc.rule.util.VccTagsUtil;
import commonutil.TLVAppInterface;

public class DoCharging {

	static Logger logger = Logger.getLogger(SubscribeHandler.class);

	public DoCharging() {

	}

	public int doCharging(VccRequest vnRequest,
			VccChargingCodeModel chargingCode) {
		TLVAppInterface tlvAppInterface = new TLVAppInterface();
		int chargingResult = -1;
		

		int response_code=-100;
		
		
		try {

			logger.info("Sending Charging Request. Msisdn["
					+ vnRequest.getMsisdn() + "] ChargingCode["
					+ chargingCode.getChargingCode() + "]");

			tlvAppInterface.setServerIP(AppConfig.config.getString(
					"CHARGING_HOST_IP", "10.168.3.57"));
			tlvAppInterface.setServerPort(Integer.parseInt(AppConfig.config
					.getString("CHARGING_HOST_PORT", "10101")));

			tlvAppInterface.setData(VccTagsUtil.MSISDN_TAG,vnRequest.getMsisdn());
			tlvAppInterface.setData(VccTagsUtil.REQTYPE_TAG, AppConfig.config.getString("CHARGING_REQUEST_TYPE","2"));
			tlvAppInterface.setData(VccTagsUtil.INTERFACE_TAG,vnRequest.getInterFace());
			tlvAppInterface.setData(VccTagsUtil.TARIFFID_TAG,chargingCode.getChargingCode());
			tlvAppInterface.setData(VccTagsUtil.SUB_TYPE,vnRequest.getSubType());
			tlvAppInterface.setData(VccTagsUtil.SERVICETYPE_TAG,vnRequest.getServiceType());
			tlvAppInterface.setData(VccTagsUtil.ACTION_TAG, AppConfig.config.getString("CHARGING_ACTION_TAG","1"));

			tlvAppInterface.encode();
			tlvAppInterface.setSocketTimeOut(Integer.parseInt(AppConfig.config
					.getString("CHARGING_INTERFACE_SOCKET_TIMEOUT")));
			tlvAppInterface.send();
			logger.info("##>>msisdn[" + vnRequest.getMsisdn()
					+ "] Charging Request sent successfully...");
			tlvAppInterface.receive();

			
			

			if (tlvAppInterface.getData(VccTagsUtil.RESPONSE_CODE) != null) {
				response_code = Integer.parseInt(tlvAppInterface
						.getData(VccTagsUtil.RESPONSE_CODE));
				logger.info("Response from Charging : [" + response_code + "]");
			} else {
				logger.error("Got Exception from Charging so default response : ["
						+ response_code + "]");
			}

			/*
			 * if(AppConfig.config.getBoolean("GB_SE_ENABLED",false)){
			 * response_type=tlvAppInterface.getData(VccTagsUtil.RESPONSE_TYPE);
			 * }
			 * 
			 * logger.info("Charging ResponseCode ["+response_code+
			 * "] ResponseType ["+response_type+"]");
			 */ 
		
			if (response_code ==1) {
				int chgDone = 1;
				int validityDays = response_code;
				int chgCode = Integer.parseInt(tlvAppInterface
						.getData(VccTagsUtil.TARIFF));
				// added for v3.3
				/*
				 * double
				 * amount=Double.parseDouble(tlvAppInterface.getData(VccTagsUtil
				 * .AMOUNT))"Charging successful : ["+response_code+"
				 */logger.info("Charging successful : Response Code["
						+ response_code + "] chargingCode[" + chgCode
						+ "] and validity days[" + validityDays + "]");
				chargingResult=1;
			}
			else if (response_code == -1)// Low balance Exception (Sync)
			{
				chargingResult=ErrorCodes.LOW_BALANCE_ERROR;
				logger.info("User Subscription failed. LowBalanceException received from Charging Interface.");
			}
			else 
			{	
				chargingResult=-1;
			}
		} catch (Exception e) {
			logger.error("Msisdn["
					+ vnRequest.getMsisdn()
					+ "] Error occurred while sending request to Charging. Exception["
					+ e + "]");
			e.printStackTrace();
			chargingResult=-1;
		} finally {
			if (tlvAppInterface != null) {
				tlvAppInterface.close();
				tlvAppInterface = null;
			}
		}
		return chargingResult;
	}

}
