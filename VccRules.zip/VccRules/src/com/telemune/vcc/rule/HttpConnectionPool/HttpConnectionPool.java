package com.telemune.vcc.rule.HttpConnectionPool;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.log4j.Logger;

import com.telemune.vcc.config.AppConfig;

public class HttpConnectionPool {
	static Logger logger = Logger.getLogger(HttpConnectionPool.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	/*
	 * private static PoolingHttpClientConnectionManager connManager = new
	 * PoolingHttpClientConnectionManager();
	 */
	private static PoolingHttpClientConnectionManager connManager = null;
	private static HttpConnectionPool datasource;
	private static RequestConfig requestConfig = null;
	private static CloseableHttpClient client = null;

	public static HttpConnectionPool getInstance() {
		if (datasource == null) {
			datasource = new HttpConnectionPool();
		}
		return datasource;
	}

	/*
	 * * Configure common configuration per every root setMaxTotal configure max
	 * total connection for connection pool, default is 5 setDefaultMaxPerRoute
	 * set max connection per route, default value is 5
	 */
	private HttpConnectionPool() {
		try {
			// added by Harjinder on 12-07-2017 to set connection time out
			requestConfig = RequestConfig
					.custom()
					.setConnectTimeout(
							AppConfig.config.getInt(
									"default.http.conn_timeout", 150000))
					.setSocketTimeout(
							AppConfig.config.getInt(
									"default.http.conn_socket_timeout", 150000))
					.build();
			connManager = new PoolingHttpClientConnectionManager();

			connManager.setMaxTotal(AppConfig.config.getInt(
					"default.max.http.conn", 5));
			connManager.setDefaultMaxPerRoute(AppConfig.config.getInt(
					"default.max.http.per.route.conn", 5));

			// end by Harjinder

			client = HttpClients.custom().setConnectionManager(connManager)
					.setDefaultRequestConfig(requestConfig).build();
			logger.info("CloseableHttpClient build successfully by using PoolingHttpClientConnectionManager. max conn ["
					+ AppConfig.config.getInt("default.max.http.conn", 5)
					+ "] default max per route ["
					+ AppConfig.config.getInt(
							"default.max.http.per.route.conn", 5)
					+ "] Connection Timeout["
					+ AppConfig.config.getInt("default.http.conn_timeout",
							150000)
					+ "] SocketTimeout["
					+ AppConfig.config.getInt(
							"default.http.conn_socket_timeout", 150000) + "]");
			
			// Added By Richard Bux on 22nd Feb 2018, to start the monitoring
			// thread for connection manager
			monitorConnectionManager();
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode [VCC-RE-00069] [Exception in HttpConnecionPool]");
			e.printStackTrace();
		}
	}

	private void monitorConnectionManager() {

		IdleConnectionMonitorThread staleMonitor = new IdleConnectionMonitorThread(
				connManager);
		staleMonitor.start();
	}

	public CloseableHttpClient getHttpConnection() {
		// commented by Harjinder on 12-07-2017 to make changes for connection
		// timeout.
		// return
		// HttpClients.custom().setConnectionManager(connManager).build();
		
		
		/*Commented By Richard Bux on 22nd Feb 2018, since each time we were returning new HttpClient object
		 *  so we were not using characteristics of connection manager in this context
		 *  
		 * return HttpClients.custom().setConnectionManager(connManager)
		.setDefaultRequestConfig(requestConfig).build();*/
		logger.info("Returning CloseableHttpClient object....");
		return client;
	}
}