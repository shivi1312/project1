package com.telemune.vcc.rule.HttpConnectionPool;

import java.util.concurrent.TimeUnit;

import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.log4j.Logger;

import com.telemune.vcc.config.AppConfig;

public class IdleConnectionMonitorThread extends Thread {
	final static Logger logger = Logger
			.getLogger(IdleConnectionMonitorThread.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	private final HttpClientConnectionManager connMgr;

	// private volatile boolean shutdown;

	public IdleConnectionMonitorThread(
			PoolingHttpClientConnectionManager connMgr) {
		super();
		this.connMgr = connMgr;
		logger.info("Conn max ideal timeout ["
				+ AppConfig.config.getInt("ideal.connection.timeout", 30)
				+ "] Idle Monitor Thread Waiting Time [1000 milliseconds]");
	}

	@Override
	public void run() {
		/*
		 * Commented by Richard Bux on 22nd Feb 2018
		 * 
		 * try { while (!shutdown) { synchronized (this) { wait(1000);
		 * connMgr.closeExpiredConnections();
		 * connMgr.closeIdleConnections(AppConfig.config.getInt(
		 * "ideal.connection.timeout", 30), TimeUnit.SECONDS); } } } catch
		 * (InterruptedException ex) { errorLogger.error(
		 * "ErrorCode [VCC-RE-90013] [Interrupted Exception] Error["
		 * +ex.getMessage()+"]"); shutdown(); }
		 */

		while (true) {
			if (connMgr != null) {
				logger.info("Executing closeIdleConnection method...");
				connMgr.closeExpiredConnections();
				connMgr.closeIdleConnections(
						AppConfig.config.getInt("ideal.connection.timeout", 30),
						TimeUnit.SECONDS);
				try {
					// logger.info("Idle Monitor Thread going to sleep...");
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					logger.error("Idle Monitoring Thread Interrupted. ErrorCode [VCC-RE-90013] [Interrupted Exception] Error["
							+ e.getMessage() + "]");
				}

			} else {
				logger.info("Unexpected event occurred. ConnectionManager found null.");
			}
		}
	}

	/*
	 * Commented by Richard Bux on 22nd Feb 2018
	 * 
	 * public void shutdown() { shutdown = true; synchronized (this) {
	 * notifyAll(); } }
	 */
}
