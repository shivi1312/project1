package com.telemune.vcc.rule.HttpConnectionPool;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.response.VnResponse;

public class CRMHttpHit {
	final static Logger logger = Logger.getLogger(CRMHttpHit.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	public static int count = 1;
	private Gson gson = new Gson();
	

	/**
	 * THIS FUNCTION IS FOR HITTING THE HTTP REQUEST BY MAKING THE CONNECTION TO
	 * THE PARTICULAR URL
	 * 
	 * @param bean
	 *            :- REFERS TO THE SMSProcessBean WHICH HOLD THE INFORMATION
	 *            WHICH GOING TO PASS IN THE HTTP HIT
	 * @return :- RETURN STRING WHICH SHOWS WHETHER THE HIT IS SUCCESS OR NOT
	 */
	/*public static void main(String [] args){
		JsonParser par = new JsonParser();
		String json = "{\"subType\":\"P\"}";
		System.out.println("parse: "+par.parse(json).getAsJsonObject().get("subType").getAsString());
	}*/
	public VnResponse sendGet(VccRequest vccRequest, String profile, VnResponse vnResponse) {
		String retVal = "fail";
		HttpGet get = null;
		String url = "";
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		String encodingString = "UTF-8";
		StringBuilder requestUrl = null;
		try {
			logger.info("inside sendGet() nd profile is [" + profile);
			url = AppConfig.config.getString("url") + profile;
			requestUrl = new StringBuilder(url);
			params.add(new BasicNameValuePair("msisdn", vccRequest.getMsisdn()));

			params.add(new BasicNameValuePair("transactionId", vccRequest.getTid()));
			params.add(new BasicNameValuePair("IMSI", "11111"));
			
			params.add(new BasicNameValuePair("interFace",vccRequest.getInterFace()));
			
			if (profile.equalsIgnoreCase(AppConfig.config.getString("create.profile")) || profile.equalsIgnoreCase(AppConfig.config.getString("modify.profile"))) {
				params.add(new BasicNameValuePair("language", vccRequest.getLang() + ""));
				params.add(new BasicNameValuePair("channel", vccRequest.getChannel()));
				
				// params.add(new
				// BasicNameValuePair("subChannel",vccRequest.getSub_channel()));

				if (vccRequest.getServiceType().equalsIgnoreCase("0010"))
					params.add(new BasicNameValuePair("demandValue",
							AppConfig.config.getString(vccRequest.getServiceType() + "." + vccRequest.getPlanName())));
				else
					params.add(new BasicNameValuePair("demandValue",
							AppConfig.config.getString(vccRequest.getServiceType())));
				params.add(new BasicNameValuePair("serviceType", vccRequest.getServiceType()));
				params.add(new BasicNameValuePair("actTrigger", vccRequest.getActTrg() + ""));
				params.add(new BasicNameValuePair("receivedTime", System.currentTimeMillis() + ""));
				params.add(new BasicNameValuePair("actVal", vccRequest.isActVal() + ""));
				params.add(new BasicNameValuePair("actionType", vccRequest.getActionType()));

				params.add(new BasicNameValuePair("methodName", vccRequest.getActionType()));
				try{params.add(new BasicNameValuePair("subType", vnResponse.getSubType()));}catch(Exception e){}
			}

			String query = URLEncodedUtils.format(params, encodingString);// iso-8859-1
			requestUrl.append("?");

			requestUrl.append(query);
			logger.info("url: " + requestUrl.toString());
			CloseableHttpClient client = HttpConnectionPool.getInstance().getHttpConnection();

			get = new HttpGet(requestUrl.toString());
			HttpResponse response = client.execute(get);

			String responseBody = EntityUtils.toString(response.getEntity());
			logger.info("response json: " + responseBody.trim());
			int responseCode = response.getStatusLine().getStatusCode();

			logger.info("status: " + response.getStatusLine() + "status code is "
					+ response.getStatusLine().getStatusCode());
			if (responseCode == 200) {
				//String subTpe = parser.parse(responseBody.trim()).getAsJsonObject().get("subType").getAsString();
				vnResponse = gson.fromJson(responseBody.trim(), VnResponse.class);
				logger.info("status is" + vnResponse.getStatus() +" Error code is ["+vnResponse.getResponseCode()+ "] status is" + vccRequest.getStatus());
				//retVal = vnResponse.getStatus();
				logger.info("sub type is" + vnResponse.getSubType());
			} else {
				retVal = "fail";

			}

		} catch(SocketTimeoutException socExe)
        {
            errorLogger.error("ErrorCode [VCC-RE-90011] TID["+vccRequest.getTid()+"] MSISDN["+vccRequest.getMsisdn()+"] ServiceType["+vccRequest.getServiceType()+"] [SocketTimeOut Exception while Connecting to VccCrmClient] Error[" + socExe.getMessage()+"]");
                    //logger.warn("Socket timeout........" +socExe.getMessage());
                    socExe.printStackTrace();

    }
    catch (ConnectException conExe) {
            errorLogger.error("ErrorCode [VCC-RE-00001] TID["+vccRequest.getTid()+"] MSISDN["+vccRequest.getMsisdn()+"] ServiceType["+vccRequest.getServiceType()+"] [Http connection is not established with VccCrmClient] Error[" + conExe.getMessage()+"]");
            //logger.warn("Connection refused........" +conExe.getMessage()); 
            }
    catch (Exception exe) {
            errorLogger.error("ErrorCode [VCC-RE-00016] TID["+vccRequest.getTid()+"] MSISDN["+vccRequest.getMsisdn()+"] ServiceType["+vccRequest.getServiceType()+"] [Exception while Connecting to VccCrmClient] Error[" + exe.getMessage()+"]");
            logger.info("Getting the exception in side function sendGet()..... ", exe);
    }

		//logger.info("["+vccRequest.getMsisdn()+"]response: "+gson.toJson(vnResponse));
		return vnResponse;
	}

}
