package com.telemune.vcc.rule.controller;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.common.VccRequestCache;
import com.telemune.vcc.rule.domain.VccLicense;
import com.telemune.vcc.rule.handler.BlockProfileHandler;
import com.telemune.vcc.rule.handler.CallBackHandler;
import com.telemune.vcc.rule.handler.ChangeProfileHandler;
import com.telemune.vcc.rule.handler.ModifyTriggerHandler;
import com.telemune.vcc.rule.handler.PasswordHandler;
import com.telemune.vcc.rule.handler.SubTypeHandler;
import com.telemune.vcc.rule.handler.SubscribeHandler;
import com.telemune.vcc.rule.handler.TriggerHandler;
import com.telemune.vcc.rule.handler.UnBlockProfileHandler;
import com.telemune.vcc.rule.handler.UnSubscribeHandler;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.response.VnInfo;
import com.telemune.vcc.rule.response.VnResponse;
import com.telemune.vcc.rule.util.CountryCodeUtil;
import com.telemune.vcc.rule.util.VccTagsUtil;
import commonutil.TLVParameters;

public class VccRuleController {
	final static Logger logger = Logger.getLogger(VccRuleController.class);
	private Gson gson = new Gson();
	private VccRequest vnRequest;
	private VnInfo vnCode = new VnInfo(false, false, 0);
	private VnResponse vnResponse = new VnResponse();
	private CountryCodeUtil countryCode = new CountryCodeUtil();
	private SubscribeHandler subHandler = new SubscribeHandler();
	private UnSubscribeHandler unsubHandler = new UnSubscribeHandler();
	private SubTypeHandler subTypeHandler = new SubTypeHandler();
	private TriggerHandler trgHandler = new TriggerHandler();
	private PasswordHandler passwordHandler = new PasswordHandler();
	private BlockProfileHandler blockHandler = new BlockProfileHandler();
	private UnBlockProfileHandler unBlockprofileHandler = new UnBlockProfileHandler();
	private ChangeProfileHandler unBlockHandler = new ChangeProfileHandler();
	private CallBackHandler callbackHandler = new CallBackHandler();
	
	private ModifyTriggerHandler modifyTriggerHandler=new ModifyTriggerHandler();

	public String subscribe(TLVParameters params) {
		vnRequest = gson.fromJson(params.getData(VccTagsUtil.REQUEST_DATA_JSON), VccRequest.class);
		if(AppConfig.config.getBoolean("VALIDATE_COUNTRY_CODE",false))
		{
			countryCode.validateCountryCode(null, vnRequest);
		}
		logger.info(gson.toJson(vnRequest));
		return VccTagsUtil.SUCCESS;
	}

	public String canSubscribe(TLVParameters params) {
		vnResponse = gson.fromJson(subHandler.canSubscribe(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public String getRatePlan(TLVParameters params) {
		vnResponse = gson.fromJson(subHandler.getRatePlan(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}
	
	public String getChargingCode(TLVParameters params) {
		vnResponse = gson.fromJson(subHandler.getChargingCode(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}
	public String doSubscribe(TLVParameters params) {
		vnResponse = gson.fromJson(subHandler.doSubscribe(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}
	
	public String doSubscriptionCharging(TLVParameters params) {
		vnResponse = gson.fromJson(subHandler.doSubscriptionCharging(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public String saveDetail(TLVParameters params) {
		vnResponse = gson.fromJson(subHandler.saveDetail(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public String saveTransaction(TLVParameters params) {
		vnResponse = gson.fromJson(subHandler.saveTransaction(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	/*
	 * public String updateOrderStatus(TLVParameters params) { return
	 * subHandler.updtateStatus(vnRequest, vnCode, vnResponse); }
	 */

	public String unsubscribe(TLVParameters params) {
		vnRequest = gson.fromJson(params.getData(VccTagsUtil.REQUEST_DATA_JSON), VccRequest.class);
		if(AppConfig.config.getBoolean("VALIDATE_COUNTRY_CODE",false))
		{
			countryCode.validateCountryCode(null, vnRequest);
		}
		logger.info(gson.toJson(vnRequest));
		return VccTagsUtil.SUCCESS;
	}

	public String canUnSubscribe(TLVParameters params) {
		vnResponse = gson.fromJson(unsubHandler.canUnSubscribe(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public String doUnsub(TLVParameters params) {
		vnResponse = gson.fromJson(unsubHandler.doUnsub(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public String removeHistory(TLVParameters params) {
		vnResponse = gson.fromJson(unsubHandler.removeHistory(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public void endUnSub(TLVParameters params) {
		unsubHandler.doFinish(vnRequest, vnCode, vnResponse);
		String response = gson.toJson(vnResponse);
		VccRequestCache.remove("unsub_" + vnRequest.getMsisdn());
		logger.info(String.format("Response: [%s]", response));
		params.setData(VccTagsUtil.RESPONSE_STRING, response);
		// added by sanchit atri on 29-sep-2020
				if(AppConfig.config.getInt("total_sub_license",0)==1)
				{	
					logger.info("vnResponse.getResult() ==="+vnResponse.getResult()+"        vnResponse.getState()====="+vnResponse.getState());

					if(vnResponse.getResult().equalsIgnoreCase("success") && vnResponse.getState().equalsIgnoreCase("END"))
					{
						long msisdn=0;
						try {
						msisdn=Long.parseLong(vnResponse.getMsisdn().trim());
						logger.info("msisdn============="+msisdn);
						}
						catch (NumberFormatException e)
						{
						   logger.info("inside catch",e);
						}
						
						VccLicense.updateCurrSubCount(msisdn,VccLicense.Minus);
					}
				}
		
	}

	public String changeNumber(TLVParameters params) {
		vnRequest = gson.fromJson(params.getData(VccTagsUtil.REQUEST_DATA_JSON), VccRequest.class);
		countryCode.validateCountryCode(null, vnRequest);
		logger.info(gson.toJson(vnRequest));
		return VccTagsUtil.SUCCESS;
	}

	public String updateProfileNumber(TLVParameters params) {
		vnResponse = gson.fromJson(subHandler.updateProfileNumber(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public String doProfileActiveOrInactive(TLVParameters params) {
		vnRequest = gson.fromJson(params.getData(VccTagsUtil.REQUEST_DATA_JSON), VccRequest.class);
		countryCode.validateCountryCode(null, vnRequest);
		return VccTagsUtil.SUCCESS;
	}

	/* ActionId: 4, getting sub type of a number */
	public String subType(TLVParameters params) {
		vnRequest = gson.fromJson(params.getData(VccTagsUtil.REQUEST_DATA_JSON), VccRequest.class);
		countryCode.validateCountryCode(null, vnRequest);
		logger.info(gson.toJson(vnRequest));
		return VccTagsUtil.SUCCESS;
	}

	public String getSubType(TLVParameters params) {
		vnResponse = gson.fromJson(subTypeHandler.getSubType(vnRequest, vnCode, vnResponse), VnResponse.class);
		logger.info("response: " + gson.toJson(vnResponse));
		return vnResponse.getState();
	}

	public void doFinishSubType(TLVParameters params) {
		subTypeHandler.doFinish(vnRequest, vnCode, vnResponse);
		String response = gson.toJson(vnResponse);
		logger.info(String.format("Response: [%s]", response));
		params.setData(VccTagsUtil.RESPONSE_STRING, response);
	}

	public String triggers(TLVParameters params) {
		vnRequest = gson.fromJson(params.getData(VccTagsUtil.REQUEST_DATA_JSON), VccRequest.class);
		countryCode.validateCountryCode(null, vnRequest);
		logger.info(gson.toJson(vnRequest));
		return VccTagsUtil.SUCCESS;
	}

	public String setTriggers(TLVParameters params) {
		vnResponse = gson.fromJson(trgHandler.setTrigger(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public void doFinishTrigger(TLVParameters params) {
		trgHandler.doFinish(vnRequest, vnCode, vnResponse);
		String response = gson.toJson(vnResponse);
		logger.info(String.format("Response: [%s]", response));
		params.setData(VccTagsUtil.RESPONSE_STRING, response);
	}

	public void doFinish(TLVParameters params) {
		subHandler.doFinish(vnRequest, vnCode, vnResponse);
		String response = gson.toJson(vnResponse);
		VccRequestCache.remove("sub_" + vnRequest.getMsisdn());
		logger.info(String.format("Response: [%s]", response));
		params.setData(VccTagsUtil.RESPONSE_STRING, response);
		// added by sanchit atri on 29-sep-2020
		if(AppConfig.config.getInt("total_sub_license",0)==1)
		{	
			logger.info("vnResponse.getResult() ==="+vnResponse.getResult()+"        vnResponse.getState()====="+vnResponse.getState());
			if(vnResponse.getResult().equalsIgnoreCase("success") && vnResponse.getState().equalsIgnoreCase("END"))
			{
				long msisdn=0;
				try {
				msisdn=Long.parseLong(vnResponse.getMsisdn().trim());
				logger.info("msisdn============="+msisdn);
				}
				catch (NumberFormatException e)
				{
				   logger.info("inside catch",e);
				}
				
				VccLicense.updateCurrSubCount(msisdn,VccLicense.Plus);
			}
		}
		
	}

	/* ActionId: 6,password change */
	public String changePassword(TLVParameters params) {
		vnRequest = gson.fromJson(params.getData(VccTagsUtil.REQUEST_DATA_JSON), VccRequest.class);
		countryCode.validateCountryCode(null, vnRequest);
		logger.info(gson.toJson(vnRequest));
		return VccTagsUtil.SUCCESS;
	}

	public String canChangePassword(TLVParameters params) {
		vnResponse = gson.fromJson(passwordHandler.canChangePassword(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public String updatePassword(TLVParameters params) {
		vnResponse = gson.fromJson(passwordHandler.updateVMPassword(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	/*
	 * public String updatePassword(TLVParameters params) { return
	 * passwordHandler.updateVMPassword(vnRequest, vnCode, vnResponse); }
	 */
	public void doFinishPassword(TLVParameters params) {
		passwordHandler.doFinish(vnRequest, vnCode, vnResponse);
		String response = gson.toJson(vnResponse);
		logger.info(String.format("Response: [%s]", response));
		params.setData(VccTagsUtil.RESPONSE_STRING, response);
	}

	/* ActionId: 7,block number */
	public String blockProfile(TLVParameters params) {
		vnRequest = gson.fromJson(params.getData(VccTagsUtil.REQUEST_DATA_JSON), VccRequest.class);
		countryCode.validateCountryCode(null, vnRequest);
		logger.info(gson.toJson(vnRequest));
		return VccTagsUtil.SUCCESS;
	}

	public String canBlock(TLVParameters params) {
		vnResponse = gson.fromJson(blockHandler.canBlock(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public String doBlock(TLVParameters params) {
		vnResponse = gson.fromJson(blockHandler.blockProfile(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public void doFinishBlockProfile(TLVParameters params) {
		blockHandler.doFinish(vnRequest, vnCode, vnResponse);
		String response = gson.toJson(vnResponse);
		logger.info(String.format("Response: [%s]", response));
		params.setData(VccTagsUtil.RESPONSE_STRING, response);
	}

	/* UNBLOCK PROFILE */
	public String unBlockProfile(TLVParameters params) {
		vnRequest = gson.fromJson(params.getData(VccTagsUtil.REQUEST_DATA_JSON), VccRequest.class);
		countryCode.validateCountryCode(null, vnRequest);
		logger.info(gson.toJson(vnRequest));
		return VccTagsUtil.SUCCESS;
	}

	public String canUnBlock(TLVParameters params) {
		vnResponse = gson.fromJson(unBlockprofileHandler.canUnBlock(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public String doUnBlock(TLVParameters params) {
		vnResponse = gson.fromJson(unBlockprofileHandler.unBlockProfile(vnRequest, vnCode, vnResponse),
				VnResponse.class);
		return vnResponse.getState();
	}

	public void doFinishUnBlockProfile(TLVParameters params) {
		unBlockprofileHandler.doFinish(vnRequest, vnCode, vnResponse);
		String response = gson.toJson(vnResponse);
		logger.info(String.format("Response: [%s]", response));
		params.setData(VccTagsUtil.RESPONSE_STRING, response);
	}

	/* ActionId: 8, Change profile */
	public String changeProfile(TLVParameters params) {
		vnRequest = gson.fromJson(params.getData(VccTagsUtil.REQUEST_DATA_JSON), VccRequest.class);
		countryCode.validateCountryCode(null, vnRequest);
		logger.info(gson.toJson(vnRequest));
		return VccTagsUtil.SUCCESS;
	}

	public String canChangeProfile(TLVParameters params) {
		vnResponse = gson.fromJson(unBlockHandler.canChangeProfile(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public String doChangeProfile(TLVParameters params) {
		vnResponse = gson.fromJson(subHandler.doChangeProfile(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public void doFinishChangeProfile(TLVParameters params) {
		unBlockHandler.doFinish(vnRequest, vnCode, vnResponse);
		String response = gson.toJson(vnResponse);
		logger.info(String.format("Response: [%s]", response));
		params.setData(VccTagsUtil.RESPONSE_STRING, response);
	}

	public void endState(TLVParameters params) {
		params.setData(VccTagsUtil.RESPONSE_CODE, 1);
		return;
	}

	/* ActionId: 9,call Back */

	public String callBack(TLVParameters params) {
		vnRequest = gson.fromJson(params.getData(VccTagsUtil.REQUEST_DATA_JSON), VccRequest.class);
		countryCode.validateCountryCode(null, vnRequest);
		logger.info(gson.toJson(vnRequest));
		return VccTagsUtil.SUCCESS;
	}

	public String checkCallback(TLVParameters params) {
		if (vnRequest.getStatus().equalsIgnoreCase("success"))
			return "SUCCESS";
		else if (vnRequest.getStatus().equalsIgnoreCase("fail"))
			return "FAIL";
		return "FAIL";
	}

	public String updateStatus(TLVParameters params) {
		vnResponse = gson.fromJson(callbackHandler.updateStatus(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public String updateFailStatus(TLVParameters params) {
		vnResponse = gson.fromJson(callbackHandler.updateFailStatus(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public void doFinishCallBack(TLVParameters params) {
		callbackHandler.doFinish(vnRequest, vnCode, vnResponse);
		String response = gson.toJson(vnResponse);
		logger.info(String.format("Response: [%s]", response));
		params.setData(VccTagsUtil.RESPONSE_STRING, response);
	}

	/*Modify Trigger Response for send Message*/
	
	
	
	
	
	public String modifyProfile(TLVParameters params) {
		vnRequest = gson.fromJson(params.getData(VccTagsUtil.REQUEST_DATA_JSON), VccRequest.class);
		countryCode.validateCountryCode(null, vnRequest);
		logger.info(gson.toJson(vnRequest));
		return VccTagsUtil.SUCCESS;
	}

	public String checkCallbackModifyProfile(TLVParameters params) {
		if (vnRequest.getStatus().equalsIgnoreCase("success"))
			return "SUCCESS";
		else if (vnRequest.getStatus().equalsIgnoreCase("fail"))
			return "FAIL";
		return "FAIL";
	}

	public String sendModifyProfileMsg(TLVParameters params) {
		vnResponse = gson.fromJson(modifyTriggerHandler.sendModifyProfileMsg(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public String updateFailModifyProfile(TLVParameters params) {
		vnResponse = gson.fromJson(modifyTriggerHandler.sendFailModifyProfileMsg(vnRequest, vnCode, vnResponse), VnResponse.class);
		return vnResponse.getState();
	}

	public void doFinishModify(TLVParameters params) {
		modifyTriggerHandler.doFinish(vnRequest, vnCode, vnResponse);
		String response = gson.toJson(vnResponse);
		logger.info(String.format("Response: [%s]", response));
		params.setData(VccTagsUtil.RESPONSE_STRING, response);
	}


	
}
