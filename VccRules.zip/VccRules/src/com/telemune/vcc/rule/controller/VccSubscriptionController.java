package com.telemune.vcc.rule.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.squirrelframework.foundation.fsm.annotation.StateMachineParameters;
import org.squirrelframework.foundation.fsm.impl.AbstractUntypedStateMachine;

import com.google.gson.Gson;
import com.telemune.vcc.common.Data;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.common.ErrorCode;
import com.telemune.vcc.rule.handler.VccMailboxLogHandler;
import com.telemune.vcc.rule.model.ScopeModel;
import com.telemune.vcc.rule.model.VccChargingCodeModel;
import com.telemune.vcc.rule.model.VccClassTypeModel;
import com.telemune.vcc.rule.model.VccError;
import com.telemune.vcc.rule.model.VccRatePlanModel;
import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.response.VnInfo;
import com.telemune.vcc.rule.response.VnResponse;
import com.telemune.vcc.rule.services.Service;
import com.telemune.vcc.rule.services.VccServices;
import com.telemune.vcc.rule.util.CountryCodeUtil;
import com.telemune.vcc.rule.util.ScopeUtil;

/*
 * Controller for voice note subscription
 * 
 * */
@StateMachineParameters(stateType = String.class, eventType = String.class, contextType = Data.class)
public class VccSubscriptionController extends AbstractUntypedStateMachine {

	private Gson gson = new Gson();
	private VccRequest vnRequest;
	private VnResponse vnResponse = new VnResponse();
	private CountryCodeUtil countryCode = new CountryCodeUtil();
	private ScopeModel scope = new ScopeModel();
	private VnInfo vnCode = new VnInfo(false, false, 0);
	private VccChargingCodeModel chargingCode;
	private VccRatePlanModel rateModel;
	private VccClassTypeModel classType;
	private VccSubscriptionMasterModel vccSub = null;
	private String serviceName;
	private boolean isCtAllow;
	private int isMasterSaved = 0;
	private int isAuthSaved = 0;

	final static Logger logger = Logger
			.getLogger(VccSubscriptionController.class);
	private Service vccService = new VccServices();

	/* State:Start,Event:init :-> check if user already subscribe or not */
	protected void process(String from, String to, String event, Data data) {
		vnRequest = gson.fromJson(data.getData(), VccRequest.class);
		serviceName = AppConfig.config.getString("service."
				+ vnRequest.getServiceType());
		countryCode.validateCountryCode(data, vnRequest);
		logger.info(String.format(
				"[%s] [%s] [%s] [%s] now going to process request",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId()));
		vccSub = vccService
				.getServiceDetailByServiceType(vnRequest);
		if (vccSub != null)
			data.getVccEvent().setNextEvent("lie");
		else
			data.getVccEvent().setNextEvent("checkForAllow");
	}

	/* State:CallAllowed,Event:checkForAllow */
	protected void checkSubAllowedOrNot(String from, String to, String event,
			Data data) {
		logger.info(String
				.format("[%s] [%s] [%s] [%s] Now going to check: blacklist,optout and classtype",
						vnRequest.getMsisdn(), vnRequest.getTid(),
						vnRequest.getServiceType(), vnRequest.getActionId()));
		data.getVccEvent().setNextEvent("check");
	}

	/* State:BlackList,onEntry:CanSubscribe */
	protected void checkForBlackList(String from, String to, String event,
			Data data) {
		if (AppConfig.config
				.getBoolean(serviceName + "_whitelist_enable", true)) {
			vnCode.setBl(vccService.isUserExistWithInRange(vnRequest));
		}
		logger.debug(String.format(
				"[%s] [%s] [%s] [%s] check for blacklist [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				vnCode.getBl()));
	}

	/* State:Optout,onEntry:CanSubscribe */
	protected void checkForOptout(String from, String to, String event,
			Data data) {
		if (vnRequest.getChannel().equals("rec")) {
			vnCode.setOptout(vccService.isUserIsOptedOut(vnRequest));
		}
		logger.debug(String.format("[%s] [%s] [%s] [%s] check for optout [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				vnCode.getOptout()));
	}

	/* State:ClassType,onEntry:CanSubscribe */
	protected void checkForClassType(String from, String to, String event,
			Data data) {
		classType = vccService.haveAnyClass(vnRequest);
		vnCode.setCt(classType.getId());
		logger.debug(String.format(
				"[%s] [%s] [%s] [%s] check for classtype [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				vnCode.getCt()));
	}

	/* State:CanSubscribe,Event:check :-> check user for blacklist or optOut */
	protected void canSubscribe(String from, String to, String event, Data data) {
		logger.info(String.format("[%s] [%s] [%s] [%s] subscription "
				+ "flag: blacklist [%s] classtype [%s] optout [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				vnCode.getBl(), vnCode.getCt(), vnCode.getOptout()));
		if (!vnCode.getBl() && !isCtAllow && !vnCode.getOptout()) {
			data.getVccEvent().setNextEvent("checkValidRatePlan");
		} else {
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(
					AppConfig.config.getString("vn.bl.ct.optout"),
					vnRequest.getMsisdn(), vnRequest.getServiceType()));
			data.getVccEvent().setNextEvent("end");
		}
	}

	/* State:CheckValidRatePlan,Event:checkValidRatePlan */
	protected void checkForValidRatePlan(String from, String to, String event,
			Data data) {
		logger.debug(String.format(
				"[%s] [%s] [%s] [%s] check for valid rate plan",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId()));
		data.getVccEvent().setNextEvent("whitelist");
	}

	/* State:SubType,Event:st(sub type) get sub type */
	protected void getSubType(String from, String to, String event, Data data) {
		if (AppConfig.config
				.getBoolean(serviceName + "_sub_based_on_st", false)) {
			scope.setST("P");
		}
		logger.info(String.format("[%s] [%s] [%s] [%s] getting subtype [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				scope.getST()));
	}

	/* State:ServiceClass,Event:sc(sub type) get service class */
	protected void getServiceClass(String from, String to, String event,
			Data data) {
		if (AppConfig.config
				.getBoolean(serviceName + "_sub_based_on_sc", false)) {
			scope.setSC("1");
		}
		logger.info(String.format(
				"[%s] [%s] [%s] [%s] getting service class [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				scope.getSC()));
	}

	/* State:OperatorRange,Event:or(operator range) get range */
	protected void getOperatorRange(String from, String to, String event,
			Data data) {
		if (AppConfig.config
				.getBoolean(serviceName + "_sub_based_on_or", false)) {
			scope.setOR("1");
		}
		logger.info(String.format("[%s] [%s] [%s] [%s] operator range [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				scope.getOR()));
	}

	/*
	 * State:RatePlan,Event:whitelist() :-> get all rate plan for a plan and
	 * service
	 */
	protected void getValidRatePlan(String from, String to, String event,
			Data data) {
		List<VccRatePlanModel> rateModelList = vccService
				.getRatePlnByServiceType(vnRequest);
		rateModel = new ScopeUtil()
				.getTarrifId(rateModelList, scope, vnRequest);
		logger.info(String.format("[%s] [%s] [%s] [%s] scope "
				+ "flag: sub type [%s] classtype [%s] "
				+ "operator range [%s] planId [%s]", vnRequest.getMsisdn(),
				vnRequest.getTid(), vnRequest.getServiceType(),
				vnRequest.getActionId(), scope.getST(), scope.getSC(),
				scope.getOR(), rateModel.getSubCode()));
		data.getVccEvent().setNextEvent("cc");

	}

	/* State:ChargingCode,Event:cc(charging code) get charging price */
	protected void getChargingPriceByChargingCode(String from, String to,
			String event, Data data) {
		chargingCode = vccService.getChargingCode(vnRequest, rateModel);
		data.getVccEvent().setNextEvent("sub");
	}

	/* State:Subscribe,Event:sub(subscribe) do subscribe for voice note */
	protected void doSubscribe(String from, String to, String event, Data data) {
		logger.info(String.format(
				"[%s] [%s] [%s] [%s] have charging code [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				chargingCode.getHasChargingCode()));
		if (chargingCode.getHasChargingCode()) {
			data.getVccEvent().setNextEvent("save");
		} else {
			vnResponse.setResult("fail");
			vnResponse.setMsg(AppConfig.config.getString(vnRequest.getLang()
					+ "" + ErrorCode._missing_charging_code,
					"Charging code is missing"));
			data.getVccEvent().setNextEvent("end");
		}

	}

	/* State:SaveDetail,Event:save ::do subscribe for voice note */
	protected void saveSubscriptionDetail(String from, String to, String event,
			Data data) {
		data.getVccEvent().setNextEvent("saveOutput");
	}

	/* State:SaveForMaster,onEntry:SaveDetail */
	protected void saveInMaster(String from, String to, String event, Data data) {
		isMasterSaved = vccService.saveUserDetail(vnRequest, rateModel,
				chargingCode,vccSub);
		logger.info(String.format(
				"[%s] [%s] [%s] [%s] save in vcc_subscription_master [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				isMasterSaved));
	}

	/* State:SaveForAuth,onEntry:SaveDetail */
	protected void saveInAuth(String from, String to, String event, Data data) {
		isAuthSaved = vccService.saveAuthUserDetail(vnRequest, rateModel,
				chargingCode, scope,new VccError(),vccSub);
		logger.info(String.format(
				"[%s] [%s] [%s] [%s] save in vcc_auth_user [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				isAuthSaved));
	}

	/* State:OutputForSaveData,Event:saveOutput */
	protected void setOutputForSaveData(String from, String to, String event,
			Data data) {
		if (isMasterSaved > 0 && isAuthSaved > 0) {
			/*
			 * Remove entry from vcc_service_unsub
			 */
			boolean isOptoutRemove = vccService.removeOptoutUser(vnRequest);// vcc_service_unsub
			/*
			 * Save for transaction log in vcc_mailbox_log
			 */
			/*boolean isLogSaved = new VccMailboxLogHandler()
					.updateTransactionLog(vnRequest, chargingCode);*/
			logger.info(String.format(
					"[%s] [%s] [%s] [%s] remove optout [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId(),
					isOptoutRemove));
			vnResponse.setResult("success");
			vnResponse.setMsg(String.format(
					AppConfig.config.getString(vnRequest.getLang()
							+ ErrorCode._subscribe, "Subscribed successfully"),
					vnRequest.getMsisdn(), vnRequest.getServiceType()));
		} else {
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(
					AppConfig.config.getString("vcc.subscribe.fail"),
					vnRequest.getMsisdn(), vnRequest.getServiceType()));
		}
		data.getVccEvent().setNextEvent("end");
	}

	/*
	 * State:AlreadySubscriber,Event:lie, use in case of user already subscriber
	 */
	protected void alreadySubscriber(String from, String to, String event,
			Data data) {
		vnResponse.setResult("success");
		vnResponse.setMsg(String.format(AppConfig.config.getString(
				vnRequest.getLang() + ErrorCode._already_sub,
				"User is already a subscriber"), vnRequest.getMsisdn(),
				vnRequest.getServiceType()));
		data.getVccEvent().setNextEvent("end");
		logger.info(String.format(
				"[%s] [%s] [%s] [%s] planname [%s] User is already subscriber",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				vnRequest.getPlanName()));
	}

	/* State:Finish,Event:end ::finish all operation */
	protected void doFinish(String from, String to, String event, Data data) {
		vnResponse.setMsisdn(vnRequest.getMsisdn());
		vnResponse.setActionId("" + vnRequest.getActionId());
		vnResponse.setTid(vnRequest.getTid());
		if (vnCode == null)
			vnCode = new VnInfo(false, false, 0);
		vnResponse.setInfo(vnCode);
		String response = gson.toJson(vnResponse);
		logger.info(String.format("Response: [%s]", response));
		data.setVccResponse(response);
	}

}