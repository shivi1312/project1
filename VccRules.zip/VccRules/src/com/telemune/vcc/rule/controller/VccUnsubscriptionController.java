package com.telemune.vcc.rule.controller;

import org.apache.log4j.Logger;
import org.squirrelframework.foundation.fsm.annotation.StateMachineParameters;
import org.squirrelframework.foundation.fsm.impl.AbstractUntypedStateMachine;

import com.google.gson.Gson;
import com.telemune.vcc.common.Data;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.common.ErrorCode;
import com.telemune.vcc.rule.handler.VccMailboxLogHandler;
import com.telemune.vcc.rule.model.VccChargingCodeModel;
import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.response.VnResponse;
import com.telemune.vcc.rule.services.Service;
import com.telemune.vcc.rule.services.VccServices;
import com.telemune.vcc.rule.util.CountryCodeUtil;

@StateMachineParameters(stateType = String.class, eventType = String.class, contextType = Data.class)
public class VccUnsubscriptionController extends AbstractUntypedStateMachine {
	final static Logger logger = Logger
			.getLogger(VccUnsubscriptionController.class);
	private Service vccService = new VccServices();
	private CountryCodeUtil countryCode = new CountryCodeUtil();
	private Gson gson = new Gson();
	private VnResponse vnResponse = new VnResponse();
	private VccChargingCodeModel chargingCode = new VccChargingCodeModel();
	private VccRequest vnRequest;
	@SuppressWarnings("unused")
	private String serviceName;
	private int isMasterSaved;
	private int isAuthSaved;

	/* State:Start,Event:init :-> check if user already subscribe or not */
	protected void process(String from, String to, String event, Data data) {
		vnRequest = gson.fromJson(data.getData(), VccRequest.class);
		serviceName = AppConfig.config.getString("service."
				+ vnRequest.getServiceType());
		countryCode.validateCountryCode(data, vnRequest);
		logger.info(String.format(
				"[%s] [%s] [%s] [%s] now going to process request",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId()));
		VccSubscriptionMasterModel vccSub = vccService
				.getServiceDetailByServiceType(vnRequest);
		if (vccSub == null)
			data.getVccEvent().setNextEvent("lie");
		else
			data.getVccEvent().setNextEvent("unsub");
	}

	/*
	 * State:Unsub,Event:unsub, use in case of unsubscriber
	 */
	protected void doUnsub(String from, String to, String event, Data data) {
		try {
			logger.info(String.format("[%s] [%s] [%s] [%s] voice maillist [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId(),
					vccService.getVoiceMailList(vnRequest)));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(String.format("[%s] [%s] [%s] [%s] Exception: [%]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId(), e));
		}
		data.getVccEvent().setNextEvent("history");
	}

	/*
	 * State:DeleteAuth
	 */
	protected void deleteFromAuth(String from, String to, String event,
			Data data) {
		try {
			isAuthSaved = vccService.updateOrDeleteAuthDetail(vnRequest);
		} catch (Exception e) {

		}
	}

	/*
	 * State:DeleteMaster
	 */
	protected void deleteFromMaster(String from, String to, String event,
			Data data) {
		try {
			isMasterSaved = vccService
					.deleteUserDetailByServiceTypeAndMsisdn(vnRequest);
		} catch (Exception e) {

		}
	}

	/*
	 * State:LogAndHistory,Event:history
	 */
	protected void removeHistory(String from, String to, String event, Data data) {
		chargingCode.setDescription("Unsubscribe");
		logger.info(String
				.format("[%s] [%s] [%s] [%s] delete from master [%s] delete from auth [%s]",
						vnRequest.getMsisdn(), vnRequest.getTid(),
						vnRequest.getServiceType(), vnRequest.getActionId(),
						isMasterSaved, isAuthSaved));
		if (isAuthSaved > 0 && isMasterSaved > 0) {
			vccService.getVoiceMailList(vnRequest);
			vccService.deleteVoiceMsgByMsisdnAndServiceType(vnRequest);
			/*boolean isLogSaved = new VccMailboxLogHandler()
					.updateTransactionLog(vnRequest, chargingCode);*/
			logger.info(String.format("[%s] [%s] [%s] [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId()));
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString(
					vnRequest.getLang() + ErrorCode._unsubscribe,
					"User is unsubscribed successfully"),
					vnRequest.getMsisdn(), vnRequest.getServiceType()));
		} else {
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString(
					vnRequest.getLang() + ErrorCode._unknown_err,
					"User is not unsubscribe"), vnRequest.getMsisdn(),
					vnRequest.getServiceType()));
		}
		data.getVccEvent().setNextEvent("end");
	}

	/*
	 * State:AlreadyUnsub,Event:lie, use in case of user already subscriber
	 */
	protected void alreadyUnSubscriber(String from, String to, String event,
			Data data) {
		vnResponse.setResult("success");
		vnResponse.setMsg(String.format(AppConfig.config.getString(
				vnRequest.getLang() + ErrorCode._already_unsub,
				"User is already a unsubscriber"), vnRequest.getMsisdn(),
				vnRequest.getServiceType()));
		data.getVccEvent().setNextEvent("end");
		logger.info(String
				.format("[%s] [%s] [%s] [%s] planname [%s] User is already unsubscriber",
						vnRequest.getMsisdn(), vnRequest.getTid(),
						vnRequest.getServiceType(), vnRequest.getActionId(),
						vnRequest.getPlanName()));
	}

	/* State:Finish,Event:end ::finish all operation */
	protected void doFinish(String from, String to, String event, Data data) {
		vnResponse.setMsisdn(vnRequest.getMsisdn());
		vnResponse.setActionId("" + vnRequest.getActionId());
		vnResponse.setTid(vnRequest.getTid());
		String response = gson.toJson(vnResponse);
		logger.info(String.format("Response: [%s]", response));
		data.setVccResponse(response);
	}

}
