package com.telemune.vcc.rule.common;

import org.apache.log4j.Logger;

import com.telemune.vcc.expiringmap.ExpirationListener;

public class VccReqListener implements ExpirationListener<String, String> {
	static Logger logger = Logger.getLogger(VccReqListener.class);
	@Override
	public void expired(String key, String value) {
		if (key.startsWith(CacheLoader._req_prefix)) {
			logger.debug("key: "+key+" with value: "+value+" is expired after 30 seconds");
		}
	}
}
