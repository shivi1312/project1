package com.telemune.vcc.rule.common;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.expiringmap.ExpirationListener;
import com.telemune.vcc.rule.domain.VccChargingCode;
import com.telemune.vcc.rule.domain.VccRatePlan;
import com.telemune.vcc.rule.domain.VccSeriesRange;

public class VccListener implements ExpirationListener<String, String> {
	@Override
	public void expired(String key, String value) {
		if (key.equals(CacheLoader._sr_prefix)) {
			VccSeriesRange.loadSeriesInCache();
		} else if (key.equals(CacheLoader._cc_prefix)) {
			VccChargingCode.loadChargingCodeCache();
		} else if (key.equals(CacheLoader._rp_prefix)) {
			VccRatePlan.loadRatePlanCache();
		} else if (key.equals(CacheLoader._acp_prefix)) {
			AppConfig.readDatabaseConfig();
		} 
	}
}
