package com.telemune.vcc.rule.common;

public class CacheLoader {
	
	public static final String _mbp_prefix = "mbp";
	public static final String _rp_prefix = "rp";
	public static final String _cc_prefix = "cc";
	public static final String _ec_prefix = "ec";
	public static final String _sr_prefix = "sr_"; //series range
	public static final String _req_prefix = "rp_";
	public static final String _acp_prefix = "acp";  // App_Config_Params 
	
	
	public CacheLoader(){
		
	}
}
