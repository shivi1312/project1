package com.telemune.vcc.rule.common;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.expiringmap.ExpirationPolicy;
import com.telemune.vcc.expiringmap.ExpiringMap;

public class VccRequestCache {
	static Logger logger = Logger.getLogger(VccRequestCache.class);
	public static ExpiringMap<String, String> _reqmap;

	static {
		_reqmap = ExpiringMap.builder().expirationListener(new VccReqListener()).variableExpiration()
				.expiration(AppConfig.config.getInt("req.expiry.cache.time", 20), TimeUnit.SECONDS).build();
		logger.debug("Request cache is running....");
	}

	public static boolean exist(String key) {
		boolean exist = _reqmap.containsKey(CacheLoader._req_prefix + key);
		logger.debug("key: "+CacheLoader._req_prefix + key+" exist: "+exist);
		return exist;
	}

	public static void put(String key, String value, int expiryTime) {
		_reqmap.put(CacheLoader._req_prefix + key, value, ExpirationPolicy.ACCESSED, expiryTime, TimeUnit.SECONDS);
		logger.debug("key: "+CacheLoader._req_prefix + key+" is added successfully for Time ["+expiryTime+"]");
	}

	public static String get(String key) {
		return _reqmap.get(CacheLoader._req_prefix + key);
	}

	public static void remove(String key) {
		_reqmap.remove(CacheLoader._req_prefix + key);
		logger.debug("key: "+CacheLoader._req_prefix + key+" is removed successfully");
	}
}
