package com.telemune.vcc.rule.common;

public class ErrorCode {
	public static final String _unknown_err = "-1";
	public static final String _charging_failed = "-2";
	public static final String _already_sub = "-3";
	public static final String _not_subscriber = "-4";
	public static final String _already_unsub = "-5";
	public static final String _missing_charging_code = "-6";
	public static final String _subscribe = "-7";
	public static final String _unsubscribe = "-8";
	public static final String _blacklist = "-9";
	public static final String _optout = "-10";
	public static final String _change_number_success = "-11";
	public static final String _change_number_fail = "-12";
	public static final String _sub_type_success = "-12";
	public static final String _trigger_success = "-13";
	public static final String _password_success = "1";
	public static final String _password_fail = "-14";
	public static final String _already_block="-15";
	public static final String _profile_not_exist="-16";
	public static final String _block_success="-17";
	public static final String _block_fail="-18";
	public static final String _already_unBlock="-19";
	public static final String _unblock_success="-20";
	public static final String _unblock_fail="-21";
	public static final String _status_change_success="-22";
	public static final String _status_change_fail="-23";
	public static final String _not_unsubscribe="-24";
	public static final String _not_subscribe="-25";
	public static final String _unsubscribe_fail="-26";
	public static final String _already_unblock="-27";
	public static final String _missing_sub_type="-28";
	public static final String _change_number_already_subscribed="-29";
	public static final String _equal_msisdn="-30";
	public static final String _trigger_fail = "-31";
	public static final String _trigger_success_insertMsg="-32";
	
}
