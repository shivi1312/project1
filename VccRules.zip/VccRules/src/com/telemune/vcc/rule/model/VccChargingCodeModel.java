package com.telemune.vcc.rule.model;

public class VccChargingCodeModel implements java.io.Serializable {
	@Override
	public String toString() {
		return "VccChargingCodeModel [chargingCode=" + chargingCode
				+ ", amountPre=" + amountPre + ", amountPost=" + amountPost
				+ ", description=" + description + ", tariffPre=" + tariffPre
				+ ", tariffPost=" + tariffPost + "]";
	}
	private static final long serialVersionUID = 5493297560188661376L;
	private int reqId;
	private int chargingCode;
	private int amountPre;
	private int amountPost;
	private String description = "NA";
	private int tariffPre;
	private int tariffPost;
	private boolean hasChargingCode;
	
	public int getReqId() {
		return reqId;
	}
	public void setReqId(int reqId) {
		this.reqId = reqId;
	}
	public int getChargingCode() {
		return chargingCode;
	}
	public void setChargingCode(int chargingCode) {
		this.chargingCode = chargingCode;
	}
	public int getAmountPre() {
		return amountPre;
	}
	public void setAmountPre(int amountPre) {
		this.amountPre = amountPre;
	}
	public int getAmountPost() {
		return amountPost;
	}
	public void setAmountPost(int amountPost) {
		this.amountPost = amountPost;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getTariffPre() {
		return tariffPre;
	}
	public void setTariffPre(int tariffPre) {
		this.tariffPre = tariffPre;
	}
	public int getTariffPost() {
		return tariffPost;
	}
	public void setTariffPost(int tariffPost) {
		this.tariffPost = tariffPost;
	}
	public boolean getHasChargingCode() {
		return hasChargingCode;
	}
	public void setHasChargingCode(boolean hasChargingCode) {
		this.hasChargingCode = hasChargingCode;
	}
	
}
