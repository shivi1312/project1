package com.telemune.vcc.rule.model;

public class VccTemplatesModel {
	private Integer templateId;
	private Integer languageId;
	private String templateMsg;
	private String key;
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public Integer getTemplateId() {
		return templateId;
	}
	public void setTemplateId(Integer templateId) {
		this.templateId = templateId;
	}
	public Integer getLanguageId() {
		return languageId;
	}
	public void setLanguageId(Integer languageId) {
		this.languageId = languageId;
	}
	public String getTemplateMsg() {
		return templateMsg;
	}
	public void setTemplateMsg(String templateMsg) {
		this.templateMsg = templateMsg;
	}
	

}
