package com.telemune.vcc.rule.model;

public class VccMailboxModel {
	private Integer mailboxId;
	private String mailboxType;
	private Integer maxMessage;
	private Integer msgLifeTime;
	private Integer msgLifeTimeAfterRet;
	
	public Integer getMsgLifeTimeAfterRet() {
		return msgLifeTimeAfterRet;
	}
	public void setMsgLifeTimeAfterRet(Integer msgLifeTimeAfterRet) {
		this.msgLifeTimeAfterRet = msgLifeTimeAfterRet;
	}
	private Integer msgLifeTimeAfterSave;
	private Integer maxRecordingTime;
	
	public Integer getMailboxId() {
		return mailboxId;
	}
	public void setMailboxId(Integer mailboxId) {
		this.mailboxId = mailboxId;
	}
	public String getMailboxType() {
		return mailboxType;
	}
	public void setMailboxType(String mailboxType) {
		this.mailboxType = mailboxType;
	}
	public Integer getMaxMessage() {
		return maxMessage;
	}
	public void setMaxMessage(Integer maxMessage) {
		this.maxMessage = maxMessage;
	}
	public Integer getMsgLifeTime() {
		return msgLifeTime;
	}
	public void setMsgLifeTime(Integer msgLifeTime) {
		this.msgLifeTime = msgLifeTime;
	}
	public Integer getMsgLifeTimeAfterSave() {
		return msgLifeTimeAfterSave;
	}
	public void setMsgLifeTimeAfterSave(Integer msgLifeTimeAfterSave) {
		this.msgLifeTimeAfterSave = msgLifeTimeAfterSave;
	}
	public Integer getMaxRecordingTime() {
		return maxRecordingTime;
	}
	public void setMaxRecordingTime(Integer maxRecordingTime) {
		this.maxRecordingTime = maxRecordingTime;
	}
	
}
