package com.telemune.vcc.rule.model;

public class ScopeModel implements java.io.Serializable {
	private static final long serialVersionUID = -4224689182054133742L;
	private String ST = "0";
	private String OR = "0";
	private String SC = "0";
	
	public String getST() {
		return ST;
	}

	public void setST(String ST) {
		this.ST = ST;
	}

	public String getOR() {
		return OR;
	}

	public void setOR(String OR) {
		this.OR = OR;
	}

	public String getSC() {
		return SC;
	}

	public void setSC(String SC) {
		this.SC = SC;
	}
}
