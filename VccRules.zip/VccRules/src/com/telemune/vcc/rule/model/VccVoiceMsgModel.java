package com.telemune.vcc.rule.model;

public class VccVoiceMsgModel implements java.io.Serializable {
	
	private static final long serialVersionUID = 1724465129650198163L;
	private String msgStatus;
	private String aParty;
	private String bParty;
	private String callTime;
	private String retrivalTime;
	private String fileName;
	private int voiceMsgIndex;
	private int recordingDuration;
	private String msgProtect;
	private String msgPriority;
	private String passProtected;
	private String password;
	private String orgNumber;
	private int localMsgIndex;
	private String sendingTime;
	private String serviceType;

	public String getMsgStatus() {
		return msgStatus;
	}

	public void setMsgStatus(String msgStatus) {
		this.msgStatus = msgStatus;
	}

	public String getaParty() {
		return aParty;
	}

	public void setaParty(String aParty) {
		this.aParty = aParty;
	}

	public String getbParty() {
		return bParty;
	}

	public void setbParty(String bParty) {
		this.bParty = bParty;
	}

	public String getCallTime() {
		return callTime;
	}

	public void setCallTime(String callTime) {
		this.callTime = callTime;
	}

	public String getRetrivalTime() {
		return retrivalTime;
	}

	public void setRetrivalTime(String retrivalTime) {
		this.retrivalTime = retrivalTime;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getVoiceMsgIndex() {
		return voiceMsgIndex;
	}

	public void setVoiceMsgIndex(int voiceMsgIndex) {
		this.voiceMsgIndex = voiceMsgIndex;
	}

	public int getRecordingDuration() {
		return recordingDuration;
	}

	public void setRecordingDuration(int recordingDuration) {
		this.recordingDuration = recordingDuration;
	}

	public String getMsgProtect() {
		return msgProtect;
	}

	public void setMsgProtect(String msgProtect) {
		this.msgProtect = msgProtect;
	}

	public String getMsgPriority() {
		return msgPriority;
	}

	public void setMsgPriority(String msgPriority) {
		this.msgPriority = msgPriority;
	}

	public String getPassProtected() {
		return passProtected;
	}

	public void setPassProtected(String passProtected) {
		this.passProtected = passProtected;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOrgNumber() {
		return orgNumber;
	}

	public void setOrgNumber(String orgNumber) {
		this.orgNumber = orgNumber;
	}

	public int getLocalMsgIndex() {
		return localMsgIndex;
	}

	public void setLocalMsgIndex(int localMsgIndex) {
		this.localMsgIndex = localMsgIndex;
	}

	public String getSendingTime() {
		return sendingTime;
	}

	public void setSendingTime(String sendingTime) {
		this.sendingTime = sendingTime;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

}
