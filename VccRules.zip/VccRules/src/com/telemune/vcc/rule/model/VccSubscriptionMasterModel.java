package com.telemune.vcc.rule.model;

import java.util.Date;

public class VccSubscriptionMasterModel {
	
	private String msisdn;
	private String serviceType;
	private Date expiryDate;
	private int ratePlan;
	private Date dateRegistered;
	private String status;
	private int language;
	
	
	

	public int getLanguage() {
		return language;
	}

	public void setLanguage(int language) {
		this.language = language;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public int getRatePlan() {
		return ratePlan;
	}

	public void setRatePlan(int ratePlan) {
		this.ratePlan = ratePlan;
	}

	public Date getDateRegistered() {
		return dateRegistered;
	}

	public void setDateRegistered(Date dateRegistered) {
		this.dateRegistered = dateRegistered;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "VccSubscriptionMasterModel [msisdn=" + msisdn + ", serviceType=" + serviceType + ", expiryDate="
				+ expiryDate + ", ratePlan=" + ratePlan + ", dateRegistered=" + dateRegistered + ", status=" + status
				+ ", language=" + language + "]";
	}

	
	}


