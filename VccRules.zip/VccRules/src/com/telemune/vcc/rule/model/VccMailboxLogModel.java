package com.telemune.vcc.rule.model;

public class VccMailboxLogModel implements java.io.Serializable {
	private static final long serialVersionUID = 2174737236936588605L;
	private int serverId;
	private String msisdn;
	private String requestDate;
	private String interFace;
	private String mailboxType;
	private String serviceType;
	private String updatedBy;
	private String description;
	private String type;
	private String cdrStatus;
	private String subType;

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public int getServerId() {
		return serverId;
	}

	public void setServerId(int serverId) {
		this.serverId = serverId;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getInterFace() {
		return interFace;
	}

	public void setInterFace(String interFace) {
		this.interFace = interFace;
	}

	public String getMailboxType() {
		return mailboxType;
	}

	public void setMailboxType(String mailboxType) {
		this.mailboxType = mailboxType;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCdrStatus() {
		return cdrStatus;
	}

	public void setCdrStatus(String cdrStatus) {
		this.cdrStatus = cdrStatus;
	}

}
