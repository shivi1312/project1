package com.telemune.vcc.rule.model;

public class VccCallbackModel {
    private String tid;
    private String msisdn;
    private String status = "fail";
    private String serviceType;
    private int callbackCounter = 0;
    private String req_time;
    private String callback_time;
    private String reqInterface;
    private int lang = 1;
    private String callbackStatus;

    public String getCallback_time() {
        return callback_time;
    }

    public void setCallback_time(String callback_time) {
        this.callback_time = callback_time;
    }

    public String getReq_time() {
        return req_time;
    }

    public void setReq_time(String req_time) {
        this.req_time = req_time;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public int getCallbackCounter() {
        return callbackCounter;
    }

    public void setCallbackCounter(int callbackCounter) {
        this.callbackCounter = callbackCounter;
    }

    public String getReqInterface() {
        return reqInterface;
    }

    public void setReqInterface(String reqInterface) {
        this.reqInterface = reqInterface;
    }

    public int getLang() {
        return lang;
    }

    public void setLang(int lang) {
        this.lang = lang;
    }

    public String getCallbackStatus() {
        return callbackStatus;
    }

    public void setCallbackStatus(String callbackStatus) {
        this.callbackStatus = callbackStatus;
    }

}
