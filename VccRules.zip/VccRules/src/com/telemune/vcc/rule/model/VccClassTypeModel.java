package com.telemune.vcc.rule.model;

@SuppressWarnings("serial")
public class VccClassTypeModel implements java.io.Serializable {
	private int id;
	private String classType;
	private String msisdn;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
}
