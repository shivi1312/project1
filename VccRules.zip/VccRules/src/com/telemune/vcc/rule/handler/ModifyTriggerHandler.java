package com.telemune.vcc.rule.handler;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.config.AppConfig;

import com.telemune.vcc.rule.common.ErrorCode;

import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.response.VnInfo;
import com.telemune.vcc.rule.response.VnResponse;


public class ModifyTriggerHandler {
		
		final static Logger logger = Logger.getLogger(ModifyTriggerHandler.class);
		final static Logger errorLogger = Logger.getLogger("errorLogger");

		private SubscribeHandler subscribeHandler=new SubscribeHandler();
		String tempId;
		boolean result=false;
		private Gson gson = new Gson();
		public String sendModifyProfileMsg(VccRequest vnRequest, VnInfo vnCode,
				VnResponse vnResponse) {
			logger.info(String.format(
					"[%s] [%s] [%s] [%s] Success case of call back in modify Trigger response code from CRM",
					vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(),
					vnRequest.getActionId()));
					tempId = AppConfig.config.getString("subModifyTgtTempId","1");
				if(AppConfig.config.getInt("ModifyCallBackActTrgMsgEnable",1)==1)
				{
					result = subscribeHandler.insertIntoGmat(vnRequest, tempId,"");
					if (!result) {
						logger.info(String.format("[%s] [%s] [%s] [%s] Msg inserted fail", vnRequest.getMsisdn(),
								vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId()));
					}
				
				}
				vnResponse.setMsg(String.format(AppConfig.config.getString(
						vnRequest.getLang() + ErrorCode._trigger_success_insertMsg,
						"Message Send Successfully"), vnRequest.getMsisdn(), vnRequest
						.getServiceType()));
				vnResponse.setResult("success");			
				vnResponse.setState("END");
				return gson.toJson(vnResponse);
			}
			public String sendFailModifyProfileMsg(VccRequest vnRequest, VnInfo vnCode,
					VnResponse vnResponse)
			{
				logger.info(String.format(
						"[%s] [%s] [%s] [%s] In case of failure case of call back in modify Trigger response code from CRM",
						vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(),
						vnRequest.getActionId()));
				if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
					tempId = AppConfig.config.getString("vmFailModifySubTempId", "10");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
					tempId = AppConfig.config.getString("vnFailModifySubTempId", "13");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
					tempId = AppConfig.config.getString("mcaFailModifySubTempId", "13");
				}
				if(AppConfig.config.getInt("ModifyCallBackActTrgMsgEnable",1)==1)
				{
					boolean result = subscribeHandler.insertIntoGmat(vnRequest, tempId,"");
					if (!result) {
						logger.info(String.format("[%s] [%s] [%s] [%s] Msg inserted fail", vnRequest.getMsisdn(),
								vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId()));
					}
					
				}
				
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString(
					vnRequest.getLang() + ErrorCode._trigger_fail,
					"Getting fail response in call back modify active trigger case"), vnRequest.getMsisdn(), vnRequest
					.getServiceType()));
			vnResponse.setState("END");
			return gson.toJson(vnResponse);
			}
			
		public String doFinish(VccRequest vnRequest, VnInfo vnCode,
				VnResponse vnResponse) {
			vnResponse.setMsisdn(vnRequest.getMsisdn());
			vnResponse.setActionId("" + vnRequest.getActionId());
			vnResponse.setTid(vnRequest.getTid());
			return null;
		}
	}

