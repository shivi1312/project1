package com.telemune.vcc.rule.handler;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.common.ErrorCode;
import com.telemune.vcc.rule.domain.VccAuthUser;
import com.telemune.vcc.rule.domain.VccRatePlan;
import com.telemune.vcc.rule.domain.VccSubscriptionMaster;
import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.response.VnInfo;
import com.telemune.vcc.rule.response.VnResponse;
import com.telemune.vcc.rule.services.Service;
import com.telemune.vcc.rule.services.VccServices;

public class CallBackHandler {
	final static Logger logger = Logger.getLogger(CallBackHandler.class);
	private Gson gson = new Gson();
	private Service vccService = new VccServices();
	private VccSubscriptionMasterModel vccSub = new VccSubscriptionMasterModel();
	private VccSubscriptionMaster vccSubscription = new VccSubscriptionMaster();
	private VccAuthUser authUser = new VccAuthUser();
	private SubscribeHandler subHandler = null;
	VccRatePlan vccRatePlan = new VccRatePlan();

	public String updateStatus(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {

		String tempId = "";
		logger.debug("request [" + vnRequest.toString());
		vccSub = vccService.getServiceDetailByServiceType(vnRequest);
		

		if (vccSub != null) {
			/*Added by Vivek to send message in selected 
			 * language instead of profiling language
			 * */
			logger.info(String.format("[%s] [%s] [%s] [%s] Send msg in profiling language [%s]", vnRequest.getMsisdn(),
					vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId(),
					AppConfig.config.getBoolean("SND_MSG_ON_PROFILE_LNG",true)));
			if(AppConfig.config.getBoolean("SND_MSG_ON_PROFILE_LNG",true))
                vnRequest.setLang(vccSub.getLanguage());
			/*Message in profiling language or selected language end here*/
			if (vccSub.getStatus().equalsIgnoreCase("P")) {
				int result = vccSubscription.updateSubProfile(vnRequest, "A");
				int status = authUser.updateSubProfile(vnRequest, "A");
				boolean isLogSaved = new VccMailboxLogHandler().updateTransactionLog(vnRequest);
				logger.info(String.format("[%s] mailbox logs saved [%s]", vnRequest.getMsisdn(),isLogSaved));	
				if (result > 0 && status > 0) {
					if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
						tempId = AppConfig.config.getString("vmSubTempId", "1");
					} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
						tempId = AppConfig.config.getString("vnSubTempId", "1");
					}else if (vnRequest.getServiceType().equalsIgnoreCase("000`")) {
						tempId = AppConfig.config.getString("mcaSubTempId", "1");
					}
					subHandler = new SubscribeHandler();
					if(AppConfig.config.getInt("CnfrmMessageEnable",1)==1)
					{
					boolean retVal = subHandler.insertIntoGmat(vnRequest, tempId,"");

					if (!retVal) {
						logger.info("Message not inserted into Gmat Message Store Table");
					}
					}
					vnResponse.setResult("success");
					vnResponse.setMsg(String.format(
							AppConfig.config.getString(vnRequest.getServiceType()+".subscribe_successfully",
									"User is subscribed successfully"),
							vnRequest.getMsisdn(), vnRequest.getServiceType()));
					vnResponse.setState("END");
					return gson.toJson(vnResponse);
					//return "END";
				}
				vnResponse.setResult("fail");
				vnResponse.setMsg(String.format(
						AppConfig.config.getString(vnRequest.getServiceType()+".subscription_fail",
								"User is not subscribed successfully"),
						vnRequest.getMsisdn(), vnRequest.getServiceType()));

			} else if (vccSub.getStatus().equalsIgnoreCase("D")) {
				if (vnRequest.getPlanName() == null)
					vnRequest.setPlanName(vccRatePlan.getRatePlan(vnRequest));
				logger.debug("ratePlan is " + vnRequest.getPlanName());

				int result = vccSubscription.deleteUserDetailByServiceTypeAndMsisdn(vnRequest);
				int status = authUser.updateOrDeleteAuthDetail(vnRequest);
				boolean isLogSaved = new VccMailboxLogHandler().updateTransactionLog(vnRequest);
				logger.info(String.format("[%s] mailbox logs saved [%s]", vnRequest.getMsisdn(),isLogSaved));
				if (result > 0 && status > 0) {
					if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
						tempId = AppConfig.config.getString("vmUnsubTempId", "1");
					} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
						tempId = AppConfig.config.getString("vnUnsubTempId", "1");
					}
					subHandler = new SubscribeHandler();
					if(AppConfig.config.getInt("CnfrmMessageEnable",1)==1)
					{
					boolean retVal = subHandler.insertIntoGmat(vnRequest, tempId,"");

					if (!retVal) {
						logger.info("Message not inserted into Gmat Message Store Table");
					}
					}
					vnResponse.setResult("success");
					vnResponse.setMsg(String.format(
							AppConfig.config.getString(vnRequest.getServiceType()+".unsub_success",
									"User is unsubscribed successfully"),
							vnRequest.getMsisdn(), vnRequest.getServiceType()));
					vnResponse.setState("HISTORY");
					return gson.toJson(vnResponse);
					//return "HISTORY";
				}
				vnResponse.setResult("fail");
				vnResponse.setMsg(String.format(
						AppConfig.config.getString(vnRequest.getServiceType()+".unsub_fail",
								"User is not unsubscribed successfully"),
						vnRequest.getMsisdn(), vnRequest.getServiceType()));

			}
		} else
			logger.info("User is not a subscriber");
		vnResponse.setState("END");
		return gson.toJson(vnResponse);
		//return "END";
	}

	public String updateFailStatus(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {
		String tempId = "";
		vccSub = vccService.getServiceDetailByServiceType(vnRequest);
		vnRequest.setLang(vccSub.getLanguage());
		
		if (vccSub != null) {
			if (vccSub.getStatus().equalsIgnoreCase("D")) {
				int result = vccSubscription.updateSubProfile(vnRequest, "A");
				int status = authUser.updateSubProfile(vnRequest, "A");
				if (result > 0 && status > 0) {
					if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
						tempId = AppConfig.config.getString("vmFailUnSubTempId", "1");
					} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
						tempId = AppConfig.config.getString("vnFailUnSubTempId", "1");
					}else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
						tempId = AppConfig.config.getString("mcaFailUnSubTempId", "1");
					}
					subHandler = new SubscribeHandler();
					if(AppConfig.config.getInt("CnfrmMessageEnable",1)==1)
					{
					boolean retVal = subHandler.insertIntoGmat(vnRequest, tempId,"");

					if (!retVal) {
						logger.info("Message not inserted into Gmat Message Store Table");
					}
					}
					vnResponse.setResult("success");
					vnResponse
							.setMsg(String.format(
									AppConfig.config.getString(vnRequest.getServiceType()+".crm_unsub_fail",
											"We are unable to unsub user"),
									vnRequest.getMsisdn(), vnRequest.getServiceType()));
					vnResponse.setState("END");
					return gson.toJson(vnResponse);
					//return "END";
				}
				vnResponse.setResult("fail");
				vnResponse.setMsg(String.format(
						AppConfig.config.getString(vnRequest.getServiceType()+".crm_not_unsubscribe",
								"There is any error to unsub user from CRM server"),
						vnRequest.getMsisdn(), vnRequest.getServiceType()));

			} else if (vccSub.getStatus().equalsIgnoreCase("P")) {
				int result = vccSubscription.deleteUserDetailByServiceTypeAndMsisdn(vnRequest);
				int status = authUser.updateOrDeleteAuthDetail(vnRequest);
				if (result > 0 && status > 0) {
					if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
						tempId = AppConfig.config.getString("vmClBkSubFailTempId", "1");
					} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
						tempId = AppConfig.config.getString("vnClBkSubFailTempId", "1");
					}
					subHandler = new SubscribeHandler();
					if(AppConfig.config.getInt("CnfrmMessageEnable",1)==1)
					{
					boolean retVal = subHandler.insertIntoGmat(vnRequest, tempId,"");

					if (!retVal) {
						logger.info("Message not inserted into Gmat Message Store Table");
					}
					}
					vnResponse.setResult("success");
					vnResponse.setMsg(String.format(
							AppConfig.config.getString(vnRequest.getServiceType()+".crm_sub_fail",
									"We are unable to subscriber user"),
							vnRequest.getMsisdn(), vnRequest.getServiceType()));
					vnResponse.setState("END");
					return gson.toJson(vnResponse);
					//return "END";
				}
				vnResponse.setResult("fail");
				vnResponse
						.setMsg(String.format(
								AppConfig.config.getString(vnRequest.getServiceType()+".crm_not_subscribe",
										"request is fail to sub user"),
								vnRequest.getMsisdn(), vnRequest.getServiceType()));

			}
		} else
			logger.info("User is not a subscriber");
		vnResponse.setState("END");
		return gson.toJson(vnResponse);
		//	return "END";
	}

	public String doFinish(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {
		vnResponse.setMsisdn(vnRequest.getMsisdn());
		vnResponse.setActionId("" + vnRequest.getActionId());
		vnResponse.setTid(vnRequest.getTid());
		return null;
	}

}
