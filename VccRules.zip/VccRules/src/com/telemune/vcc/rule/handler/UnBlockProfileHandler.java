package com.telemune.vcc.rule.handler;

	import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.config.AppConfig;
	import com.telemune.vcc.rule.common.ErrorCode;

	import com.telemune.vcc.rule.domain.VccSubscriptionMaster;
	import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
	import com.telemune.vcc.rule.request.VccRequest;
	import com.telemune.vcc.rule.response.VnInfo;
	import com.telemune.vcc.rule.response.VnResponse;
	import com.telemune.vcc.rule.services.Service;
	import com.telemune.vcc.rule.services.VccServices;

	public class UnBlockProfileHandler {
		final static Logger logger = Logger.getLogger(UnBlockProfileHandler.class);
		private Gson gson = new Gson();
		private Service vccService = new VccServices();
		private VccSubscriptionMasterModel vccSub = null;
		private VccSubscriptionMaster vccSubMaster=new VccSubscriptionMaster();
		
		public String canUnBlock(VccRequest vnRequest, VnInfo vnCode,
				VnResponse vnResponse) {
		vccSub = vccService.getServiceDetailByServiceType(vnRequest);
		logger.debug("Value of sub is ["+vccSub);
		if (vccSub != null)
			{
			if(vccSub.getStatus().equals("B")) {
				logger.debug("inside block condition");
				vnResponse.setState("ALLOW");
				return gson.toJson(vnResponse);
				//return "ALLOW";
			}

			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString("not_blocked",
					"User Profile is not Blocked"), vnRequest.getMsisdn(),
					vnRequest.getServiceType()));
			logger.info(String
					.format("[%s] [%s] [%s] [%s] User is not "
							+ "Blocked",
							vnRequest.getMsisdn(), vnRequest.getTid(),
							vnRequest.getServiceType(),
							vnRequest.getActionId()));
			vnResponse.setState("DIS_ALLOW");
			return gson.toJson(vnResponse);
			//return "DIS_ALLOW";
		} else {
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString(
					vnRequest.getServiceType()+".not_subscriber",
					"User Profile is Not Exist"), vnRequest.getMsisdn(),
					vnRequest.getServiceType()));
			logger.info(String
					.format("[%s] [%s] [%s] [%s] User Profile not "
							+ "Exist",
							vnRequest.getMsisdn(), vnRequest.getTid(),
							vnRequest.getServiceType(),
							vnRequest.getActionId()));
			
			vnResponse.setState("DIS_ALLOW");
			return gson.toJson(vnResponse);
			//return "DIS_ALLOW";
		}
			
		}
		
		public String unBlockProfile(VccRequest vnRequest, VnInfo vnCode,
				VnResponse vnResponse) {
			logger.info("Inside unblock profile for msisdn [ "+vnRequest.getMsisdn());
			int result=vccSubMaster.updateSubProfile(vnRequest,"A");
			if(result>0)
			{
				vnRequest.setType("BU");
				boolean isLogSaved = new VccMailboxLogHandler().updateTransactionLog(vnRequest);
				logger.info(String.format("[%s] mailbox logs saved for UnBlock user [%s] ", vnRequest.getMsisdn(), isLogSaved));

				vnResponse.setResult("success");
				vnResponse.setMsg(String.format(AppConfig.config.getString(
					"unblock_success",
					"Success unblock Profile"), vnRequest.getMsisdn(), vnRequest
					.getServiceType()));
			}
			
			else
			{
				vnResponse.setResult("fail");
				vnResponse.setMsg(String.format(AppConfig.config.getString(
					"unblock_fail",
					"Fail to unblock Profile"), vnRequest.getMsisdn(), vnRequest
					.getServiceType()));	
			}
			vnResponse.setState("END");
			return gson.toJson(vnResponse);
			//return "END";
		}
		public String doFinish(VccRequest vnRequest, VnInfo vnCode,
				VnResponse vnResponse) {
			vnResponse.setMsisdn(vnRequest.getMsisdn());
			vnResponse.setActionId("" + vnRequest.getActionId());
			vnResponse.setTid(vnRequest.getTid());
			return null;
		}



}
