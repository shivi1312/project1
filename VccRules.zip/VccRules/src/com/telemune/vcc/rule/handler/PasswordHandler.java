package com.telemune.vcc.rule.handler;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.google.gson.Gson;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.common.ErrorCode;
import com.telemune.vcc.rule.domain.VccAuthUser;

import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.response.VnInfo;
import com.telemune.vcc.rule.response.VnResponse;
import com.telemune.vcc.rule.services.Service;
import com.telemune.vcc.rule.services.VccServices;

public class PasswordHandler {
	private static final Log logger = LogFactory.getLog(PasswordHandler.class);
	private VccAuthUser vccAuthUser = new VccAuthUser();
	private Service vccService = new VccServices();
	private VccSubscriptionMasterModel vccSub = null;
	private Gson gson = new Gson();

	public String canChangePassword(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {
		vccSub = vccService.getServiceDetailByServiceType(vnRequest);
		if (vccSub != null) {
			vnResponse.setState("ALLOW");
			return gson.toJson(vnResponse);
			// return "ALLOW";
		} else {
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString(vnRequest.getServiceType() + ".not_subscriber",
					"User Profile is Not Exist"), vnRequest.getMsisdn(), vnRequest.getServiceType()));
			logger.info(String.format("[%s] [%s] [%s] [%s] User profile is not exist", vnRequest.getMsisdn(),
					vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId()));
			vnResponse.setState("DIS_ALLOW");
			return gson.toJson(vnResponse);
			// return "DIS_ALLOW";
		}

	}

	public String updateVMPassword(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {
		int result = vccAuthUser.updatePassword(vnRequest);
		if (result > 0) {
			vnRequest.setType("CP");
			boolean isLogSaved = new VccMailboxLogHandler().updateTransactionLog(vnRequest);
			logger.info(String.format("[%s] mailbox logs saved for change Password [%s] ", vnRequest.getMsisdn(),
					isLogSaved));
			vnResponse.setResult("success");
			vnResponse.setMsg(
					String.format(AppConfig.config.getString("change_password_success", "Success changed Password"),
							vnRequest.getMsisdn(), vnRequest.getServiceType()));
		} else {
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString("password_fail", "Fail to change Password"),
					vnRequest.getMsisdn(), vnRequest.getServiceType()));
		}
		vnResponse.setState("END");
		return gson.toJson(vnResponse);
		// return "END";
	}

	public String doFinish(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {
		vnResponse.setMsisdn(vnRequest.getMsisdn());
		vnResponse.setActionId("" + vnRequest.getActionId());
		vnResponse.setTid(vnRequest.getTid());
		return null;
	}

}
