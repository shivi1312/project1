package com.telemune.vcc.rule.handler;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.common.ErrorCode;

import com.telemune.vcc.rule.domain.VccSubscriptionMaster;
import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.response.VnInfo;
import com.telemune.vcc.rule.response.VnResponse;
import com.telemune.vcc.rule.services.Service;
import com.telemune.vcc.rule.services.VccServices;

public class BlockProfileHandler {
	final static Logger logger = Logger.getLogger(BlockProfileHandler.class);
	private Gson gson = new Gson();
	private Service vccService = new VccServices();
	private VccSubscriptionMasterModel vccSub = null;
	private VccSubscriptionMaster vccSubMaster=new VccSubscriptionMaster();
	
	
	public String canBlock(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
	vccSub = vccService.getServiceDetailByServiceType(vnRequest);
	if (vccSub != null)
		{
		if(!vccSub.getStatus().equals("B")) {
			vnResponse.setState("ALLOW");
			return gson.toJson(vnResponse);
			//return "ALLOW";
		}

		vnResponse.setResult("fail");
		vnResponse.setMsg(String.format(AppConfig.config.getString("already_block",
				"User Profile is already Blocked"), vnRequest.getMsisdn(),
				vnRequest.getServiceType()));
		logger.info(String
				.format("[%s] [%s] [%s] [%s] User is already "
						+ "Blocked",
						vnRequest.getMsisdn(), vnRequest.getTid(),
						vnRequest.getServiceType(),
						vnRequest.getActionId()));
		vnResponse.setState("DIS_ALLOW");
		return gson.toJson(vnResponse);
		//return "DIS_ALLOW";
	} else {
		vnResponse.setResult("fail");
		vnResponse.setMsg(String.format(AppConfig.config.getString(
				vnRequest.getServiceType()+".not_subscriber",
				"User Profile is Not Exist"), vnRequest.getMsisdn(),
				vnRequest.getServiceType()));
		logger.info(String
				.format("[%s] [%s] [%s] [%s] User is not a subscriber ",
						vnRequest.getMsisdn(), vnRequest.getTid(),
						vnRequest.getServiceType(),
						vnRequest.getActionId()));
		vnResponse.setState("DIS_ALLOW");
		return gson.toJson(vnResponse);
		//return "DIS_ALLOW";
	}
		
	}
	
	public String blockProfile(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		int result=vccSubMaster.updateSubProfile(vnRequest,"B");
		if(result>0)
		{
			vnRequest.setType("UB");
			boolean isLogSaved = new VccMailboxLogHandler().updateTransactionLog(vnRequest);
			logger.info(String.format("[%s] mailbox logs saved for block user [%s] ", vnRequest.getMsisdn(), isLogSaved));

			vnResponse.setResult("success");
			vnResponse.setMsg(String.format(AppConfig.config.getString("block_success",
				"Success block Profile"), vnRequest.getMsisdn(), vnRequest
				.getServiceType()));
		}
		
		else
		{
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString("block_fail",
				"Fail to block Profile"), vnRequest.getMsisdn(), vnRequest
				.getServiceType()));	
		}
		vnResponse.setState("END");
		return gson.toJson(vnResponse);
	//	return "END";
	}
	public String doFinish(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		vnResponse.setMsisdn(vnRequest.getMsisdn());
		vnResponse.setActionId("" + vnRequest.getActionId());
		vnResponse.setTid(vnRequest.getTid());
		return null;
	}

}
