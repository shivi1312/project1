package com.telemune.vcc.rule.handler;

	import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.config.AppConfig;
	import com.telemune.vcc.rule.common.ErrorCode;


import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
	import com.telemune.vcc.rule.request.VccRequest;
	import com.telemune.vcc.rule.response.VnInfo;
	import com.telemune.vcc.rule.response.VnResponse;
	import com.telemune.vcc.rule.services.Service;
	import com.telemune.vcc.rule.services.VccServices;

	public class ChangeProfileHandler {
		final static Logger logger = Logger.getLogger(BlockProfileHandler.class);
		private Gson gson = new Gson();
		private Service vccService = new VccServices();
		private VccSubscriptionMasterModel vccSub = null;
		
		public String canChangeProfile(VccRequest vnRequest, VnInfo vnCode,
				VnResponse vnResponse) {
		vccSub = vccService.getServiceDetailByServiceType(vnRequest);
		if (vccSub != null)
			{
			vnResponse.setState("ALLOW");
			return gson.toJson(vnResponse);
				//return "ALLOW";
			}

			else {
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString(
					"not_subscriber",
					"User Profile is Not Exist"), vnRequest.getMsisdn(),
					vnRequest.getServiceType()));
			logger.info(String
					.format("[%s] [%s] [%s] [%s] User Profile not exist",
							vnRequest.getMsisdn(), vnRequest.getTid(),
							vnRequest.getServiceType(),
							vnRequest.getActionId()));
			vnResponse.setState("DIS_ALLOW");
			return gson.toJson(vnResponse);
			//return "DIS_ALLOW";
		}
			
		}
		
		
		public String doFinish(VccRequest vnRequest, VnInfo vnCode,
				VnResponse vnResponse) {
			vnResponse.setMsisdn(vnRequest.getMsisdn());
			vnResponse.setActionId("" + vnRequest.getActionId());
			vnResponse.setTid(vnRequest.getTid());
			return null;
		}

}
