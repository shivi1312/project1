package com.telemune.vcc.rule.handler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.HLR.FetchMsrn;
import com.telemune.vcc.charging.DoCharging;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.HttpConnectionPool.CRMHttpHit;
import com.telemune.vcc.rule.common.VccRequestCache;
import com.telemune.vcc.rule.domain.VccAuthUser;
import com.telemune.vcc.rule.domain.VccCallback;
import com.telemune.vcc.rule.domain.VccGmatMsgStore;
import com.telemune.vcc.rule.domain.VccLicense;
import com.telemune.vcc.rule.domain.VccRatePlan;
import com.telemune.vcc.rule.domain.VccSeriesRange;
import com.telemune.vcc.rule.domain.VccSubscriptionMaster;
import com.telemune.vcc.rule.model.ScopeModel;
import com.telemune.vcc.rule.model.VccChargingCodeModel;
import com.telemune.vcc.rule.model.VccClassTypeModel;
import com.telemune.vcc.rule.model.VccError;
import com.telemune.vcc.rule.model.VccRatePlanModel;
import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.response.VnInfo;
import com.telemune.vcc.rule.response.VnResponse;
import com.telemune.vcc.rule.services.Service;
import com.telemune.vcc.rule.services.VccServices;
import com.telemune.vcc.rule.util.ErrorCodes;
import com.telemune.vcc.rule.util.ScopeUtil;
import commonutil.HLRInt;

import log.telemune.vcc.rule.history.VccFileDeleteWriter;

public class SubscribeHandler {
	public int testcase = 1;
	final static Logger logger = Logger.getLogger(SubscribeHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	private Gson gson = new Gson();
	private Service vccService = new VccServices();
	private ScopeModel scope = new ScopeModel();
	private VccChargingCodeModel chargingCode;
	private VccRatePlanModel rateModel;
	private String serviceName;
	private VccClassTypeModel classType;
	private VccError error = new VccError();
	private boolean isCtAllow;
	private int isMasterSaved = 0;
	private int isAuthSaved = 0;
	private VccGmatMsgStore vccGmatMsgStore = null;
	private VccSubscriptionMasterModel vccSub = null;
	public CRMHttpHit crmHttpHit = null;
	public VccAuthUser vccAuthUser = null;
	public VccSubscriptionMaster vccSubMaster = new VccSubscriptionMaster();
	public UnSubscribeHandler unSubHandler = new UnSubscribeHandler();
	private List<String> fileList = new ArrayList<String>();
	private List<String> greetingFileList = new ArrayList<String>();
	private List<String> groupFileList = new ArrayList<String>();
	private String ivrRecordBasePath;
	private String ivrGreetingBasePath;
	private String ivrGroupBasePath;
	private VccRatePlan ratePlan = null;
	DoCharging doCharging=new DoCharging();
	
	
	
	public String canSubscribe(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		// if license work enable
	if(AppConfig.config.getInt("total_sub_license",0)==1)
		{	
		
		if(VccLicense.li_maxNumSubs>VccLicense.currSubCount)
		{		
			logger.info("inside canSubscribe....if maxValue["+VccLicense.li_maxNumSubs+"] > currSubsriber["+VccLicense.currSubCount+"]");
			
			String tempId = "";
	
			if (!VccRequestCache.exist("sub_" + vnRequest.getMsisdn())) {
				VccRequestCache.put("sub_" + vnRequest.getMsisdn(),
						gson.toJson(vnRequest),
						AppConfig.config.getInt("req.expiry.cache.time", 20));
			} else {
				vnResponse.setResult("fail");
				vnResponse
						.setMsg("Request is already under process for subscription");
				vnResponse.setState("DIS_ALLOW");
				logger.info(String
						.format("[%s] [%s] [%s] [%s] Drop request:: because request is already under process for subscription",
								vnRequest.getMsisdn(), vnRequest.getTid(),
								vnRequest.getServiceType(), vnRequest.getActionId()));
				return gson.toJson(vnResponse);
			}
	
			serviceName = AppConfig.config.getString("service."
					+ vnRequest.getServiceType());
			vccSub = vccService.getServiceDetailByServiceType(vnRequest);
			if (vccSub != null) {
				/*
				 * Added by Vivek to send message in selected language instead of
				 * profiling language
				 */
				logger.info(String.format(
						"[%s] [%s] [%s] [%s] Send msg in profiling language [%s]",
						vnRequest.getMsisdn(), vnRequest.getTid(),
						vnRequest.getServiceType(), vnRequest.getActionId(),
						AppConfig.config.getBoolean("SND_MSG_ON_PROFILE_LNG", true)));
				if (AppConfig.config.getBoolean("SND_MSG_ON_PROFILE_LNG", true))
					vnRequest.setLang(vccSub.getLanguage());
				/* Message in profiling language or selected language end here */
	
				
				
				if (!vccSub.getStatus().equalsIgnoreCase("A")) {
					
					vnResponse.setResult("fail");
					vnResponse.setState("DIS_ALLOW");
					if (AppConfig.config.getString("ASYNC_FLOW_ENABLE", "1").equalsIgnoreCase("1"))
					{
						if(vccSub.getStatus().equalsIgnoreCase("P"))
						{
							
							vnResponse.setMsg(String.format(AppConfig.config.getString(
									vnRequest.getServiceType() + ".sub_underprocess",
									"User subscription request is under process."),
									vnRequest.getMsisdn(), vnRequest.getServiceType()));
							logger.info(String
									.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User subscription request is already under process.",
											vnRequest.getMsisdn(), vnRequest.getTid(),
											vnRequest.getServiceType(),
											vnRequest.getActionId(),
											vnRequest.getPlanName(), vccSub.getStatus()));
							
							tempId = AppConfig.config.getString("subAckTempId", "9");
							logger.info("Ack message enable is "
									+ AppConfig.config.getInt("AckMessageEnable",0));
	
							if (AppConfig.config.getInt("AckMessageEnable", 0) == 1) {
								boolean result = insertIntoGmat(vnRequest, tempId, "");
								if (result)
									logger.info(String.format(
											"[%s] [%s] [%s] [%s] Msg inserted success",
											vnRequest.getMsisdn(), vnRequest.getTid(),
											vnRequest.getServiceType(),
											vnRequest.getActionId()));
							}
						}
						else if(vccSub.getStatus().equalsIgnoreCase("D"))
						{
			
							vnResponse.setMsg(String.format(AppConfig.config.getString(
									vnRequest.getServiceType() + ".unsub_underprocess",
									"User Unsubscription request is under process."),
									vnRequest.getMsisdn(), vnRequest.getServiceType()));
							logger.info(String
									.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User Unsubscription Request is already under process. So can't process the subscription request further.",
											vnRequest.getMsisdn(), vnRequest.getTid(),
											vnRequest.getServiceType(),
											vnRequest.getActionId(),
											vnRequest.getPlanName(), vccSub.getStatus()));
							
							tempId = AppConfig.config.getString("unSubAckTempId", "9");
							logger.info("Ack Message Enable is "
									+ AppConfig.config.getInt("AckMessageEnable",0));
	
							if (AppConfig.config.getInt("AckMessageEnable", 0) == 1) {
								boolean result = insertIntoGmat(vnRequest, tempId, "");
								if (result)
									logger.info(String.format(
											"[%s] [%s] [%s] [%s] Msg inserted success",
											vnRequest.getMsisdn(), vnRequest.getTid(),
											vnRequest.getServiceType(),
											vnRequest.getActionId()));
							}
						}
					}
					if(vccSub.getStatus().equalsIgnoreCase("I"))
					{
						
						vnResponse.setMsg(String.format(AppConfig.config.getString("vcc.inactive.account",
								"User Inactivated")));
						logger.info(String
								.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User profile already exist, so won't be processing the request further.",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId(),
										vnRequest.getPlanName(), vccSub.getStatus()));
				
						if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
							tempId = AppConfig.config.getString("vnAlreadySubTempId",
									"13");
						} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
							tempId = AppConfig.config.getString("mcaAlreadySubTempId",
									"13");
						}
	
						if (AppConfig.config.getInt("CnfrmMessageEnable", 1) == 1) {
							boolean result = insertIntoGmat(vnRequest, tempId, "");
							if (result) {
								logger.info(String.format(
										"[%s] [%s] [%s] [%s] Msg inserted success",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId()));
							}
						}
					}
					else if(vccSub.getStatus().equalsIgnoreCase("B"))
					{
						
						vnResponse.setMsg(String.format(AppConfig.config.getString(
								"vm_user_blocked",
								"User profile is blocked for Voice Mail services."),
								vnRequest.getMsisdn(), vnRequest.getServiceType()));
						logger.info(String
								.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User profile is blocked for Voice Mail services, so can't process the request further.",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId(),
										vnRequest.getPlanName(), vccSub.getStatus()));
				
						tempId = AppConfig.config.getString("userBlockTempId", "36");
						logger.info("User Block Message Enable is "
								+ AppConfig.config.getInt("UserBlockMessageEnable",0));
	
						if (AppConfig.config.getInt("UserBlockMessageEnable", 0) == 1) {
							boolean result = insertIntoGmat(vnRequest, tempId, "");
							if (result)
								logger.info(String.format(
										"[%s] [%s] [%s] [%s] Msg inserted success",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId()));
						}
					}
					else
					{
						
						vnResponse.setMsg(String.format(AppConfig.config.getString(
								vnRequest.getServiceType() + ".unknown_status",
								"User profile status is unknown on the system"),
								vnRequest.getMsisdn(), vnRequest.getServiceType()));
						logger.info(String
								.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User profile status is unknown on the system, so can't process the request further.",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId(),
										vnRequest.getPlanName(), vccSub.getStatus()));
					
						tempId = AppConfig.config.getString("UnknownStatusTempId", "37");
						logger.info("Unknown Message Status Enable is "
								+ AppConfig.config.getInt("UnknownStatusMessageEnable",0));
	
						if (AppConfig.config.getInt("UnknownStatusMessageEnable", 0) == 1) {
							boolean result = insertIntoGmat(vnRequest, tempId, "");
							if (result)
								logger.info(String.format(
										"[%s] [%s] [%s] [%s] Msg inserted success",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId()));
						}
					}
					return gson.toJson(vnResponse);
				}
	
				String planName = vccService.getExistingRatePlanName(vnRequest,
						vccSub);
	
				if ((vnRequest.getAction() == 2 || vnRequest.getAction() == 3)
						&& !planName.equals(vnRequest.getPlanName())) {
					logger.info(String
							.format("[%s] [%s] [%s] [%s] Max total subscriber[%s] total subscriber [%s] [%s] "
									+ "planname [%s] Change Plan [%s]  subtype [%s] whiteList [%s]",
									vnRequest.getMsisdn(),
									vnRequest.getTid(),
									vnRequest.getServiceType(),
									vnRequest.getActionId(),
									vnRequest.getPlanName(),
									AppConfig.config.getString(
											"" + vnRequest.getAction(), ""
													+ vnRequest.getAction()),
									vnRequest.getSubType(), vnCode.getBl()));
					vnRequest.setChangePlan(true);
					vnResponse.setState("ALLOW");
					return gson.toJson(vnResponse);
				}
	
				logger.info(String
						.format("[%s] [%s] [%s] [%s] planname [%s] User is already "
								+ "subscriber Existing plan [%s] Request plan [%s]",
								vnRequest.getMsisdn(), vnRequest.getTid(),
								vnRequest.getServiceType(),
								vnRequest.getActionId(), vnRequest.getPlanName(),
								planName, vnRequest.getPlanName()));
				//if (vnRequest.getServiceType().equalsIgnoreCase("0010")
				//		&& !vnRequest.getInterFace().equalsIgnoreCase("M")) {
					//vnResponse.setState("ALLOW");
					//return gson.toJson(vnResponse);
				//} else {
					if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
						tempId = AppConfig.config.getString("vnAlreadySubTempId",
								"13");
					} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
						tempId = AppConfig.config.getString("mcaAlreadySubTempId",
								"13");
					}
					if (AppConfig.config.getInt("CnfrmMessageEnable", 1) == 1) {
						
						if(!vnRequest.getServiceType().equalsIgnoreCase("0001"))
						{
							boolean result = insertIntoGmat(vnRequest, tempId, "");
							if (result) {
								logger.info(String.format(
										"[%s] [%s] [%s] [%s] Msg inserted success",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId()));
							}
						}
					}
					vnResponse.setResult("fail");
	
					vnResponse.setMsg(String.format(AppConfig.config.getString(
							vnRequest.getServiceType() + ".already.sub",
							"User is already a subscriber"), vnRequest.getMsisdn(),
							vnRequest.getServiceType()));
					logger.info(String
							.format("[%s] [%s] [%s] [%s] planname [%s] User is already "
									+ "subscriber Existing plan [%s] Request plan [%s]",
									vnRequest.getMsisdn(), vnRequest.getTid(),
									vnRequest.getServiceType(),
									vnRequest.getActionId(),
									vnRequest.getPlanName(), planName,
									vnRequest.getPlanName()));
					vnResponse.setState("DIS_ALLOW");
					return gson.toJson(vnResponse);
				//}
			} else {
				return this.checkForBlacklist(vnRequest, vnCode, vnResponse);
			}
		}
		else {
			
			// if max. subscriber limit reached.....
			vnResponse.setResult("fail");
			vnResponse
					.setMsg("You are not eligible for subscription.");
			vnResponse.setState("DIS_ALLOW");
			logger.info(String
					.format("[%s] [%s] [%s] [%s] Drop request:: because Maximum number of subscriber reached!!!",
							vnRequest.getMsisdn(), vnRequest.getTid(),
							vnRequest.getServiceType(), vnRequest.getActionId()));
			return gson.toJson(vnResponse);
		}
	 }
	else
	{
		logger.info("inside canSubscribe....License work is disable from property file");
		// its the orignal one without license 
		
		String tempId = "";

		if (!VccRequestCache.exist("sub_" + vnRequest.getMsisdn())) {
			VccRequestCache.put("sub_" + vnRequest.getMsisdn(),
					gson.toJson(vnRequest),
					AppConfig.config.getInt("req.expiry.cache.time", 20));
		} else {
			vnResponse.setResult("fail");
			vnResponse
					.setMsg("Request is already under process for subscription");
			vnResponse.setState("DIS_ALLOW");
			logger.info(String
					.format("[%s] [%s] [%s] [%s] Drop request:: because request is already under process for subscription",
							vnRequest.getMsisdn(), vnRequest.getTid(),
							vnRequest.getServiceType(), vnRequest.getActionId()));
			return gson.toJson(vnResponse);
		}

		serviceName = AppConfig.config.getString("service."
				+ vnRequest.getServiceType());
		vccSub = vccService.getServiceDetailByServiceType(vnRequest);
		if (vccSub != null) {
			/*
			 * Added by Vivek to send message in selected language instead of
			 * profiling language
			 */
			logger.info(String.format(
					"[%s] [%s] [%s] [%s] Send msg in profiling language [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId(),
					AppConfig.config.getBoolean("SND_MSG_ON_PROFILE_LNG", true)));
			if (AppConfig.config.getBoolean("SND_MSG_ON_PROFILE_LNG", true))
				vnRequest.setLang(vccSub.getLanguage());
			/* Message in profiling language or selected language end here */

			
			
			if (!vccSub.getStatus().equalsIgnoreCase("A")) {
				
				vnResponse.setResult("fail");
				vnResponse.setState("DIS_ALLOW");
				if (AppConfig.config.getString("ASYNC_FLOW_ENABLE", "1").equalsIgnoreCase("1"))
				{
					if(vccSub.getStatus().equalsIgnoreCase("P"))
					{
						
						vnResponse.setMsg(String.format(AppConfig.config.getString(
								vnRequest.getServiceType() + ".sub_underprocess",
								"User subscription request is under process."),
								vnRequest.getMsisdn(), vnRequest.getServiceType()));
						logger.info(String
								.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User subscription request is already under process.",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId(),
										vnRequest.getPlanName(), vccSub.getStatus()));
						
						tempId = AppConfig.config.getString("subAckTempId", "9");
						logger.info("Ack message enable is "
								+ AppConfig.config.getInt("AckMessageEnable",0));

						if (AppConfig.config.getInt("AckMessageEnable", 0) == 1) {
							boolean result = insertIntoGmat(vnRequest, tempId, "");
							if (result)
								logger.info(String.format(
										"[%s] [%s] [%s] [%s] Msg inserted success",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId()));
						}
					}
					else if(vccSub.getStatus().equalsIgnoreCase("D"))
					{
		
						vnResponse.setMsg(String.format(AppConfig.config.getString(
								vnRequest.getServiceType() + ".unsub_underprocess",
								"User Unsubscription request is under process."),
								vnRequest.getMsisdn(), vnRequest.getServiceType()));
						logger.info(String
								.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User Unsubscription Request is already under process. So can't process the subscription request further.",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId(),
										vnRequest.getPlanName(), vccSub.getStatus()));
						
						tempId = AppConfig.config.getString("unSubAckTempId", "9");
						logger.info("Ack Message Enable is "
								+ AppConfig.config.getInt("AckMessageEnable",0));

						if (AppConfig.config.getInt("AckMessageEnable", 0) == 1) {
							boolean result = insertIntoGmat(vnRequest, tempId, "");
							if (result)
								logger.info(String.format(
										"[%s] [%s] [%s] [%s] Msg inserted success",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId()));
						}
					}
				}
				if(vccSub.getStatus().equalsIgnoreCase("I"))
				{
					
					vnResponse.setMsg(String.format(AppConfig.config.getString("vcc.inactive.account",
							"User Inactivated")));
					logger.info(String
							.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User profile already exist, so won't be processing the request further.",
									vnRequest.getMsisdn(), vnRequest.getTid(),
									vnRequest.getServiceType(),
									vnRequest.getActionId(),
									vnRequest.getPlanName(), vccSub.getStatus()));
			
					if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
						tempId = AppConfig.config.getString("vnAlreadySubTempId",
								"13");
					} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
						tempId = AppConfig.config.getString("mcaAlreadySubTempId",
								"13");
					}

					if (AppConfig.config.getInt("CnfrmMessageEnable", 1) == 1) {
						boolean result = insertIntoGmat(vnRequest, tempId, "");
						if (result) {
							logger.info(String.format(
									"[%s] [%s] [%s] [%s] Msg inserted success",
									vnRequest.getMsisdn(), vnRequest.getTid(),
									vnRequest.getServiceType(),
									vnRequest.getActionId()));
						}
					}
				}
				else if(vccSub.getStatus().equalsIgnoreCase("B"))
				{
					
					vnResponse.setMsg(String.format(AppConfig.config.getString(
							"vm_user_blocked",
							"User profile is blocked for Voice Mail services."),
							vnRequest.getMsisdn(), vnRequest.getServiceType()));
					logger.info(String
							.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User profile is blocked for Voice Mail services, so can't process the request further.",
									vnRequest.getMsisdn(), vnRequest.getTid(),
									vnRequest.getServiceType(),
									vnRequest.getActionId(),
									vnRequest.getPlanName(), vccSub.getStatus()));
			
					tempId = AppConfig.config.getString("userBlockTempId", "36");
					logger.info("User Block Message Enable is "
							+ AppConfig.config.getInt("UserBlockMessageEnable",0));

					if (AppConfig.config.getInt("UserBlockMessageEnable", 0) == 1) {
						boolean result = insertIntoGmat(vnRequest, tempId, "");
						if (result)
							logger.info(String.format(
									"[%s] [%s] [%s] [%s] Msg inserted success",
									vnRequest.getMsisdn(), vnRequest.getTid(),
									vnRequest.getServiceType(),
									vnRequest.getActionId()));
					}
				}
				else
				{
					
					vnResponse.setMsg(String.format(AppConfig.config.getString(
							vnRequest.getServiceType() + ".unknown_status",
							"User profile status is unknown on the system"),
							vnRequest.getMsisdn(), vnRequest.getServiceType()));
					logger.info(String
							.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User profile status is unknown on the system, so can't process the request further.",
									vnRequest.getMsisdn(), vnRequest.getTid(),
									vnRequest.getServiceType(),
									vnRequest.getActionId(),
									vnRequest.getPlanName(), vccSub.getStatus()));
				
					tempId = AppConfig.config.getString("UnknownStatusTempId", "37");
					logger.info("Unknown Message Status Enable is "
							+ AppConfig.config.getInt("UnknownStatusMessageEnable",0));

					if (AppConfig.config.getInt("UnknownStatusMessageEnable", 0) == 1) {
						boolean result = insertIntoGmat(vnRequest, tempId, "");
						if (result)
							logger.info(String.format(
									"[%s] [%s] [%s] [%s] Msg inserted success",
									vnRequest.getMsisdn(), vnRequest.getTid(),
									vnRequest.getServiceType(),
									vnRequest.getActionId()));
					}
				}
				return gson.toJson(vnResponse);
			}

			String planName = vccService.getExistingRatePlanName(vnRequest,
					vccSub);

			if ((vnRequest.getAction() == 2 || vnRequest.getAction() == 3)
					&& !planName.equals(vnRequest.getPlanName())) {
				logger.info(String
						.format("[%s] [%s] [%s] [%s] Max total subscriber[%s] total subscriber [%s] [%s] "
								+ "planname [%s] Change Plan [%s]  subtype [%s] whiteList [%s]",
								vnRequest.getMsisdn(),
								vnRequest.getTid(),
								vnRequest.getServiceType(),
								vnRequest.getActionId(),
								vnRequest.getPlanName(),
								AppConfig.config.getString(
										"" + vnRequest.getAction(), ""
												+ vnRequest.getAction()),
								vnRequest.getSubType(), vnCode.getBl()));
				vnRequest.setChangePlan(true);
				vnResponse.setState("ALLOW");
				return gson.toJson(vnResponse);
			}

			logger.info(String
					.format("[%s] [%s] [%s] [%s] planname [%s] User is already "
							+ "subscriber Existing plan [%s] Request plan [%s]",
							vnRequest.getMsisdn(), vnRequest.getTid(),
							vnRequest.getServiceType(),
							vnRequest.getActionId(), vnRequest.getPlanName(),
							planName, vnRequest.getPlanName()));
			if (vnRequest.getServiceType().equalsIgnoreCase("0010")
					&& !vnRequest.getInterFace().equalsIgnoreCase("M")) {
				vnResponse.setState("ALLOW");
				return gson.toJson(vnResponse);
			} else {
				if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
					tempId = AppConfig.config.getString("vnAlreadySubTempId",
							"13");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
					tempId = AppConfig.config.getString("mcaAlreadySubTempId",
							"13");
				}
				if (AppConfig.config.getInt("CnfrmMessageEnable", 1) == 1) {
					
					if(!vnRequest.getServiceType().equalsIgnoreCase("0001"))
					{
						boolean result = insertIntoGmat(vnRequest, tempId, "");
						if (result) {
							logger.info(String.format(
									"[%s] [%s] [%s] [%s] Msg inserted success",
									vnRequest.getMsisdn(), vnRequest.getTid(),
									vnRequest.getServiceType(),
									vnRequest.getActionId()));
						}
					}
				}
				vnResponse.setResult("fail");

				vnResponse.setMsg(String.format(AppConfig.config.getString(
						vnRequest.getServiceType() + ".already.sub",
						"User is already a subscriber"), vnRequest.getMsisdn(),
						vnRequest.getServiceType()));
				logger.info(String
						.format("[%s] [%s] [%s] [%s] planname [%s] User is already "
								+ "subscriber Existing plan [%s] Request plan [%s]",
								vnRequest.getMsisdn(), vnRequest.getTid(),
								vnRequest.getServiceType(),
								vnRequest.getActionId(),
								vnRequest.getPlanName(), planName,
								vnRequest.getPlanName()));
				vnResponse.setState("DIS_ALLOW");
				return gson.toJson(vnResponse);
			}
		} else {
			return this.checkForBlacklist(vnRequest, vnCode, vnResponse);
		}
	
	}
  }

	private String checkForBlacklist(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		
		if(AppConfig.config.getBoolean("BLACK_LIST_CHECK_ENABLE",false))
		{
			vnCode.setBl(vccService.isUserExistWithInRange(vnRequest));
			logger.info(String.format(
					"[%s] [%s] [%s] [%s] check for blacklist [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId(),
					vnCode.getBl()));
			if (vnCode.getBl()) {
				logger.info(String
						.format("[%s] [%s] [%s] [%s] user is blacklist: now return response",
								vnRequest.getMsisdn(), vnRequest.getTid(),
								vnRequest.getServiceType(), vnRequest.getActionId()));
				vnResponse.setResult("fail");
				vnResponse.setMsg(String.format(AppConfig.config.getString(
						"BlackList", "User is blacklist"), vnRequest.getMsisdn(),
						vnRequest.getServiceType()));
				vnResponse.setState("DIS_ALLOW");
				return gson.toJson(vnResponse);
			}
		}
		return this.checkForOptotut(vnRequest, vnCode, vnResponse);
	}

	private String checkForOptotut(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		
		if(AppConfig.config.getBoolean("OPT_OUT_CHECK_ENABLE",false))
		{
			if (vnRequest.getChannel().equals("rec")) {
				vnCode.setOptout(vccService.isUserIsOptedOut(vnRequest));
			}
			logger.debug(String.format("[%s] [%s] [%s] [%s] check for optout [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId(),
					vnCode.getOptout()));
			if (vnCode.getOptout()) {
				vnResponse.setResult("fail");
				vnResponse.setMsg(String.format(
						AppConfig.config.getString("OptOut", "User is opted out"),
						vnRequest.getMsisdn(), vnRequest.getServiceType()));
				vnResponse.setState("DIS_ALLOW");
				return gson.toJson(vnResponse);
			}
		}
		this.checkForClassType(vnRequest, vnCode, vnResponse);
		vnResponse.setState("ALLOW");
		return gson.toJson(vnResponse);
	}

	private String checkForClassType(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		classType = vccService.haveAnyClass(vnRequest);
		vnCode.setCt(classType.getId());
		logger.debug(String.format(
				"[%s] [%s] [%s] [%s] check for classtype [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				vnCode.getCt()));
		if (isCtAllow) {
			vnResponse.setState("DIS_ALLOW");
			return gson.toJson(vnResponse);
		}
		vnResponse.setState("ALLOW");
		return gson.toJson(vnResponse);
	}

	public String getRatePlan(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		vnResponse = this.getSubType(vnRequest, vnCode, vnResponse);
		this.getServiceClass(vnRequest, vnCode, vnResponse);
		List<VccRatePlanModel> rateModelList = vccService
				.getRatePlnByServiceType(vnRequest);
		rateModel = new ScopeUtil()
				.getTarrifId(rateModelList, scope, vnRequest);
		logger.info(String.format("[%s] [%s] [%s] [%s] scope "
				+ "flag: sub type [%s] classtype [%s] "
				+ "operator range [%s] subCode [%s] planId[%s]", vnRequest.getMsisdn(),
				vnRequest.getTid(), vnRequest.getServiceType(),
				vnRequest.getActionId(), scope.getST(), scope.getSC(),
				scope.getOR(), rateModel.getSubCode(), rateModel.getPlanId()));
		
		vnResponse.setState("CHRG_CODE");
		return gson.toJson(vnResponse);
	}

	private VnResponse getSubType(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		
		boolean isFixed = false;
		if(AppConfig.config.getBoolean("CHECK_FOR_FIXED_LINE",false))
		{
			isFixed = new VccSeriesRange().isExistWithinGroup(
					vnRequest.getMsisdn(), "fixedline");
		}
		
		if (isFixed) {
			scope.setST("F");
			vnRequest.setSubType("F");
			logger.debug(String.format(
					"[%s] [%s] [%s] [%s] getting subtype [%s] for fixed",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId(),
					scope.getST()));
		} else {
			if (AppConfig.config.getBoolean(serviceName + "_sub_based_on_st",
					false)) {
				scope.setST("N");
			} else {
				logger.info("Getting subtype in request is [" + vnRequest.getSubType() + "]");
				if (AppConfig.config.getList("avail.sub.types",Arrays.asList("P", "O", "F")).contains(vnRequest.getSubType())) {
					scope.setST(vnRequest.getSubType());
				} else {
					//added by kuldeep on 21 August 2020
					logger.info("multi_service_enable="+AppConfig.config.getBoolean("multi_service_enable", false));
					//if multi_service_enable is true then get subType from other service [VM & MCA] if subscribed for same msisdn
					boolean isGetSubType = true;
					if(AppConfig.config.getBoolean("multi_service_enable", false)) {
						if(vnRequest.getServiceType().equalsIgnoreCase("0001") || vnRequest.getServiceType().equalsIgnoreCase("0010")) {
							String subType =vccService.getSubType(vnRequest);
							logger.debug("Subtype getting from database ["+ subType + "]");
							if(subType != null && AppConfig.config.getList("avail.sub.types",Arrays.asList("P", "O", "F")).contains(subType.trim())) {
								vnRequest.setSubType(subType);
								scope.setST(vnRequest.getSubType());
								isGetSubType = false;
							}
						}
					}
					
					if(isGetSubType) {
						SubTypeHandler subTypeHandler = new SubTypeHandler();
						vnResponse = gson.fromJson(subTypeHandler.getSubType(vnRequest, vnCode, vnResponse), VnResponse.class);
						logger.debug("Subtype getting from CRM server is [" + vnResponse.getSubType() + "]");
						vnRequest.setSubType(vnResponse.getSubType());
						scope.setST(vnResponse.getSubType());
					}
				}
			}
		}
		logger.debug(String.format("[%s] [%s] [%s] [%s] getting subtype [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				scope.getST()));
		return vnResponse;
	}

	private void getServiceClass(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		if (AppConfig.config
				.getBoolean(serviceName + "_sub_based_on_sc", false)) {
			scope.setSC("1");
		}
		logger.debug(String.format(
				"[%s] [%s] [%s] [%s] getting service class [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				scope.getSC()));
	}

	/*
	private void getOperatorRange(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		if (AppConfig.config
				.getBoolean(serviceName + "_sub_based_on_or", false)) {
			scope.setOR("1");
		}
		logger.debug(String.format("[%s] [%s] [%s] [%s] operator range [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				scope.getOR()));
	}
	*/

	public String getChargingCode(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		chargingCode = vccService.getChargingCode(vnRequest, rateModel);

		logger.debug("charging code " + chargingCode);
		if (chargingCode == null) {
			vnResponse.setResult("fail");
			vnResponse.setMsg(AppConfig.config.getString(
					vnRequest.getServiceType() + ".missing_charging_code",
					"Charging code missing"));
			vnResponse.setState("MISS");
			return gson.toJson(vnResponse);
		}

		logger.info(String.format(
				"[%s] [%s] [%s] [%s] have charging code [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				chargingCode.getHasChargingCode()));
		if (chargingCode.getHasChargingCode()) {
			vnResponse.setState("HIT");
			return gson.toJson(vnResponse);
		}
		vnResponse.setResult("fail");
		vnResponse.setMsg(AppConfig.config.getString(vnRequest.getServiceType()
				+ ".missing_charging_code", "Charging code missing"));
		vnResponse.setState("MISS");
		return gson.toJson(vnResponse);
	}

	public String checkWhichCharging(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		if (vnRequest.getCbcmEnable()) {
			vnResponse.setState("CBCM");
		} else {
			vnResponse.setState("INTERNAL");
			logger.info(String.format(
					"[%s] [%s] [%s] [%s] Making profile internally",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId()));
		}
		return gson.toJson(vnResponse);
	}

	public String doSubscribe(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		try {
			String tempId = "";
			if(AppConfig.config.getBoolean("CHECK_FOR_FIXED_LINE",false))
			{
				boolean isFixed = new VccSeriesRange().isExistWithinGroup(
						vnRequest.getMsisdn(), "fixedline");
				if (isFixed) {
					vnRequest.setSubType("F");
					logger.info(String.format(
							"[%s] [%s] [%s] [%s] user is type of fixed [F]",
							vnRequest.getMsisdn(), vnRequest.getTid(),
							vnRequest.getServiceType(), vnRequest.getActionId()));
				}
			}
			logger.debug(String.format("[%s] [%s] [%s] [%s] Do Subscribe",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId()));
			if (vccSub != null) {
				/*
				 * Added by Vivek to send message in selected language instead
				 * of profiling language
				 */
				logger.info(String
						.format("[%s] [%s] [%s] [%s] Send msg in profiling language [%s]",
								vnRequest.getMsisdn(), vnRequest.getTid(),
								vnRequest.getServiceType(), vnRequest
										.getActionId(), AppConfig.config
										.getBoolean("SND_MSG_ON_PROFILE_LNG",
												true)));
				if (AppConfig.config.getBoolean("SND_MSG_ON_PROFILE_LNG", true))
					vnRequest.setLang(vccSub.getLanguage());
				/* Message in profiling language or selected language end here */
			}
			logger.info(String
					.format("[%s] [%s] [%s] [%s] charging interface [%s] cbcm enable [%s]",
							vnRequest.getMsisdn(), vnRequest.getTid(),
							vnRequest.getServiceType(),
							vnRequest.getActionId(),
							AppConfig.config.getString(
									"charging.type.interface", "NA"), vnRequest
									.getCbcmEnable()));
			if (AppConfig.config.getString("charging.type.interface", "NA")
					.equals("crm")
					&& vnRequest.getCbcmEnable()
					&& !vnRequest.getSubType().equals("F")) {
				if (!vnRequest.getInterFace().equalsIgnoreCase("M")) {

					String planName = "NA";	
					crmHttpHit = new CRMHttpHit();
					logger.info("Send request to CRM server for check eligibility");
					vnRequest.setActionType("AddService");
					
					// When already existing user request received for activate
					// new trigger request
					if (vccSub != null) {
						
						//getting planName
						ratePlan = new VccRatePlan();
						planName = ratePlan.getRatePlan(vnRequest);
						ratePlan = null;
						if(planName.equalsIgnoreCase(vnRequest.getPlanName()))
						{
						vnResponse = crmHttpHit.sendGet(vnRequest,
								AppConfig.config.getString("modify.profile"),
								vnResponse);

						if (vnResponse.getStatus().equalsIgnoreCase("success")) {

							logger.info(String
									.format("[%s] [%s] [%s] [%s] In case of modify profile already exist into our data base",
											vnRequest.getMsisdn(),
											vnRequest.getTid(),
											vnRequest.getServiceType(),
											vnRequest.getActionId()));
							vnRequest.setActionType("modify");
							tempId = AppConfig.config.getString(
									"subAckModifyTempId", "1");
							if (AppConfig.config.getInt(
									"ModifyMsgAckInsertionEnable", 1) == 1) {
								boolean result = insertIntoGmat(
										vnRequest,
										tempId,
										AppConfig.config.getString("ActTrg."
												+ vnRequest.getActTrg(), "busy"));
								if (!result) {
									logger.info(String
											.format("[%s] [%s] [%s] [%s] Msg inserted fail",
													vnRequest.getMsisdn(),
													vnRequest.getTid(),
													vnRequest.getServiceType(),
													vnRequest.getActionId()));
								}

							}
							vnResponse.setResult("success");

							vnResponse
									.setMsg(String.format(
											AppConfig.config
													.getString(
															vnRequest
																	.getServiceType()
																	+ ".subscription_under_process",
															"User modify request is under process"),
											vnRequest.getMsisdn(), vnRequest
													.getServiceType()));
							new VccCallback().storeCallback(vnRequest);// Store
																		// callback
							vnResponse.setState("FAIL");
							return gson.toJson(vnResponse);

						} else if (vnResponse.getStatus().equalsIgnoreCase(
								"fail")
								&& vnResponse.getResponseCode()
										.equalsIgnoreCase("E06")) {
							logger.info(String
									.format("[%s] [%s] [%s] [%s] Response fail from VccCrmClient in case of modify trigger and getting E06 error Code",
											vnRequest.getMsisdn(),
											vnRequest.getTid(),
											vnRequest.getServiceType(),
											vnRequest.getActionId()));

							if (vnRequest.getServiceType().equalsIgnoreCase(
									"0010")) {
								tempId = AppConfig.config.getString(
										"vmAlreadySubTempId", "10");
							} else if (vnRequest.getServiceType()
									.equalsIgnoreCase("0100")) {
								tempId = AppConfig.config.getString(
										"vnAlreadySubTempId", "13");
							} else if (vnRequest.getServiceType()
									.equalsIgnoreCase("0001")) {
								tempId = AppConfig.config.getString(
										"mcaAlreadySubTempId", "13");
							}
							if (AppConfig.config.getInt(
									"ModifyMsgInsertionEnable", 1) == 1) {
								boolean result = insertIntoGmat(
										vnRequest,
										tempId,
										AppConfig.config.getString("ActTrg."
												+ vnRequest.getActTrg(), "busy"));
								if (!result) {
									logger.info(String
											.format("[%s] [%s] [%s] [%s] Msg inserted fail",
													vnRequest.getMsisdn(),
													vnRequest.getTid(),
													vnRequest.getServiceType(),
													vnRequest.getActionId()));
								}

							}
							vnResponse.setResult("fail");

							vnResponse.setMsg(String.format(AppConfig.config
									.getString(vnRequest.getServiceType()
											+ ".already.sub",
											"User is already a subscriber"),
									vnRequest.getMsisdn(), vnRequest
											.getServiceType()));
							logger.info(String.format(
									"[%s] [%s] [%s] [%s] planname [%s] User is already "
											+ "subscriber ",
									vnRequest.getMsisdn(), vnRequest.getTid(),
									vnRequest.getServiceType(),
									vnRequest.getActionId(),
									vnRequest.getPlanName()));

							vnResponse.setState("FAIL");
							return gson.toJson(vnResponse);

						}
						///

						else {
							logger.info(String
									.format("[%s] [%s] [%s] [%s] In case of failure case of modify profile already exist into our data base",
											vnRequest.getMsisdn(),
											vnRequest.getTid(),
											vnRequest.getServiceType(),
											vnRequest.getActionId()));
							if (vnRequest.getServiceType().equalsIgnoreCase(
									"0010")) {
								tempId = AppConfig.config.getString(
										"vmFailModifySubTempId", "10");
							} else if (vnRequest.getServiceType()
									.equalsIgnoreCase("0100")) {
								tempId = AppConfig.config.getString(
										"vnFailModifySubTempId", "13");
							} else if (vnRequest.getServiceType()
									.equalsIgnoreCase("0001")) {
								tempId = AppConfig.config.getString(
										"mcaFailModifySubTempId", "13");
							}
							if (AppConfig.config.getInt(
									"ModifyMsgInsertionEnable", 1) == 1) {
								boolean result = insertIntoGmat(vnRequest,
										tempId, "");
								if (!result) {
									logger.info(String
											.format("[%s] [%s] [%s] [%s] Msg inserted fail",
													vnRequest.getMsisdn(),
													vnRequest.getTid(),
													vnRequest.getServiceType(),
													vnRequest.getActionId()));
								}

							}
							vnResponse.setResult("fail");
							vnResponse
									.setMsg(String.format(
											AppConfig.config
													.getString(
															vnRequest
																	.getServiceType()
																	+ ".subscription_trigger_fail",
															"Modify trigger request is failed for subscribe"),
											vnRequest.getMsisdn(), vnRequest
													.getServiceType()));
							vnResponse.setState("FAIL");
							return gson.toJson(vnResponse);
						}
						}
						else{
							//planName not same so can not proceed further
							logger.info(String
									.format("[%s] [%s] [%s] [%s] In case of failue case of modify profile already exist into data base but requested planName and alreday exists planName are not same",
											vnRequest.getMsisdn(),
											vnRequest.getTid(),
											vnRequest.getServiceType(),
											vnRequest.getActionId()));
							if (vnRequest.getServiceType().equalsIgnoreCase(
									"0010")) {
								//vmPlanNotMatchModifySubTempId
								//vnPlanNotMatchModifySubTempId
								//mcaPlanNotMatchModifySubTempId
								tempId = AppConfig.config.getString(
										"vmPlanNotMatchModifySubTempId_"+planName, "10");
							} else if (vnRequest.getServiceType()
									.equalsIgnoreCase("0100")) {
								tempId = AppConfig.config.getString(
										"vnPlanNotMatchModifySubTempId_"+planName, "13");
							} else if (vnRequest.getServiceType()
									.equalsIgnoreCase("0001")) {
								tempId = AppConfig.config.getString(
										"mcaPlanNotMatchModifySubTempId_"+planName, "13");
							}
							if (AppConfig.config.getInt(
									"ModifyMsgInsertionEnable", 1) == 1) {
								boolean result = insertIntoGmat(vnRequest,
										tempId, "");
								if (!result) {
									logger.info(String
											.format("[%s] [%s] [%s] [%s] Msg inserted fail",
													vnRequest.getMsisdn(),
													vnRequest.getTid(),
													vnRequest.getServiceType(),
													vnRequest.getActionId()));
								}

							}
							vnResponse.setResult("fail");
							vnResponse
									.setMsg(String.format(
											AppConfig.config
													.getString(
															vnRequest
																	.getServiceType()
																	+ ".subscription_trigger_fail",
															"Modify trigger request is failed for subscribe"),
											vnRequest.getMsisdn(), vnRequest
													.getServiceType()));
							vnResponse.setState("FAIL");
							return gson.toJson(vnResponse);
							
						}
					}

					// When create order request is receive
					else {
						vnResponse = crmHttpHit.sendGet(vnRequest,
								AppConfig.config.getString("create.profile"),
								vnResponse);
						vnRequest.setActionType("create");
						logger.debug("Response is" + vnResponse.toString());

						if (!vnResponse.getStatus().equalsIgnoreCase("success")) {
							if (vnResponse.getResponseCode() != null
									&& vnResponse.getResponseCode()
											.equalsIgnoreCase("E06")) {
								logger.info(String
										.format("[%s] [%s] [%s] [%s] Response fail from VccCrmClient in case of getting E06 error Code",
												vnRequest.getMsisdn(),
												vnRequest.getTid(),
												vnRequest.getServiceType(),
												vnRequest.getActionId()));
								vnRequest.setStatus("A");
								if (vnRequest.getServiceType()
										.equalsIgnoreCase("0010")) {
									tempId = AppConfig.config.getString(
											"vmSubTempId", "1");
								} else if (vnRequest.getServiceType()
										.equalsIgnoreCase("0100")) {
									tempId = AppConfig.config.getString(
											"vnSubTempId", "1");

								}
								if (AppConfig.config.getInt(
										"CnfrmMessageEnable", 1) == 1) {
									boolean result = insertIntoGmat(vnRequest,
											tempId, "");
									logger.info("insert into gmat_message_store result is "
											+ result);
								}
								boolean isLogSaved = new VccMailboxLogHandler()
										.updateTransactionLog(vnRequest);
								logger.info(String.format(
										"[%s] mailbox logs saved [%s] ",
										vnRequest.getMsisdn(), isLogSaved));
								vnResponse.setResult("success");
								vnResponse
										.setMsg(String.format(
												AppConfig.config
														.getString(
																vnRequest
																		.getServiceType()
																		+ ".E06_subscription_success",
																"Profile created successfully when getting error code E06"),
												vnRequest.getMsisdn(),
												vnRequest.getServiceType()));
								vnResponse.setState("SUCCESS");
								return gson.toJson(vnResponse);

							}

							else {
								if (vnRequest.getServiceType()
										.equalsIgnoreCase("0010")) {
									tempId = AppConfig.config.getString(
											"vmFailSubTempId", "1");
								} else if (vnRequest.getServiceType()
										.equalsIgnoreCase("0100")) {
									tempId = AppConfig.config.getString(
											"vnFailSubTempId", "1");
								} else if (vnRequest.getServiceType()
										.equalsIgnoreCase("0001")) {
									tempId = AppConfig.config.getString(
											"mcaFailSubTempId", "1");
								}
								logger.info(String.format(
										"[%s] [%s] [%s] [%s] Sub fail",
										vnRequest.getMsisdn(),
										vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId()));
								if (AppConfig.config.getInt(
										"CnfrmMessageEnable", 1) == 1) {
									boolean result = insertIntoGmat(vnRequest,
											tempId, "");
									if (!result) {
										logger.info(String
												.format("[%s] [%s] [%s] [%s] Msg inserted fail",
														vnRequest.getMsisdn(),
														vnRequest.getTid(),
														vnRequest
																.getServiceType(),
														vnRequest.getActionId()));
									}
								}
								logger.info(String.format(
										"[%s] [%s] [%s] [%s] Sub fail",
										vnRequest.getMsisdn(),
										vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId()));
								vnResponse.setResult("fail");
								vnResponse.setMsg(String.format(
										AppConfig.config.getString(
												vnRequest.getServiceType()
														+ ".subscription_fail",
												"User is not subscribed"),
										vnRequest.getMsisdn(), vnRequest
												.getServiceType()));
								vnResponse.setState("FAIL");
								return gson.toJson(vnResponse);
							}

						} else {

							vnRequest.setStatus("P");
							logger.info(String
									.format("[%s] [%s] [%s] [%s] status [%s]Response true from VccCrmClient",
											vnRequest.getMsisdn(),
											vnRequest.getTid(),
											vnRequest.getServiceType(),
											vnRequest.getActionId(),
											vnRequest.getStatus()));
							tempId = AppConfig.config.getString("subAckTempId",
									"1");
							logger.info("Ack message is"
									+ AppConfig.config
											.getInt("AckMessageEnable"));
							if (AppConfig.config.getInt("AckMessageEnable", 1) == 1) {
								logger.info("Ack message is"
										+ AppConfig.config
												.getInt("AckMessageEnable"));
								boolean result = insertIntoGmat(vnRequest,
										tempId, "");
								if (!result) {
									logger.info(String
											.format("[%s] [%s] [%s] [%s] Msg inserted fail",
													vnRequest.getMsisdn(),
													vnRequest.getTid(),
													vnRequest.getServiceType(),
													vnRequest.getActionId()));
								}
							}
							new VccCallback().storeCallback(vnRequest);// Store
																		// callback

							vnResponse.setResult("success");
							vnResponse
									.setMsg(String.format(
											AppConfig.config
													.getString(
															vnRequest
																	.getServiceType()
																	+ ".subscription_under_process",
															"Your subscription request is under process waiting for call back"),
											vnRequest.getMsisdn(), vnRequest
													.getServiceType()));
							vnResponse.setState("SUCCESS");
							return gson.toJson(vnResponse);
						}
					}
				}
			}
			if (AppConfig.config.getString("charging.type.interface", "NA")
					.equals("hlr")
					&& vnRequest.getCbcmEnable()
					&& !vnRequest.getSubType().equals("F")) {
				//added by kuldeep on 21 August 2020
				logger.debug("multi_service_enable="+AppConfig.config.getBoolean("multi_service_enable", false));
				//if multi_service_enable is true then get subType from other service [VM & MCA] if subscribed for same msisdn
				boolean isFlagUpRequired = true;
				if(AppConfig.config.getBoolean("multi_service_enable", false)) {
					if(vnRequest.getServiceType().equalsIgnoreCase("0001") || vnRequest.getServiceType().equalsIgnoreCase("0010")) {
						int countMSS =vccService.countForMultiServiceSubscriber(vnRequest);
						logger.debug("countMSS ["+ countMSS + "]");
						if(countMSS > 0) { //1 or greater
							isFlagUpRequired = false;
							logger.info("HLR flag already up in other service VM or MCA for this msisdn ["+vnRequest.getMsisdn()+"]");
						}
					}
				}
				
				if(vnRequest.getServiceType().equalsIgnoreCase("0100") && AppConfig.config.getBoolean("vn_prefix_base_enable", false)) {
					isFlagUpRequired = false;
					logger.info("request NOT send to HLR Server for subscribe user because vn_prefix_base_enable="+AppConfig.config.getBoolean("vn_prefix_base_enable", false));
				}

				//added by sanchit on 12 august 2021
				if(AppConfig.config.getString("NotAllowInterface","abc").equalsIgnoreCase(vnRequest.getInterFace()) && vnRequest.getActionId()==1)
				{
					logger.info("request for subscribe and Interface is IVR so not send request to HLR");
					isFlagUpRequired=false;
				}
				
				
				if(isFlagUpRequired) {
					logger.info("request send to HLR Server for subscribe user");
					String vlr = "", scfAddress = "", busyNumber = "", noReplyNumber = "", unreachableNumber = "";
					StringBuffer msrn = new StringBuffer();
					StringBuffer cfuActiveStr = new StringBuffer();
					Integer serviceKey = new Integer(0);
					Boolean isRoaming = new Boolean(true);
					Boolean isPrepaid = new Boolean(true);
					Boolean cfuActive = new Boolean(true);
					Integer msrnError = new Integer(0);
					StringBuffer imsi = new StringBuffer();
					/*HLRInt hlrInt=new HLRInt(AppConfig.config.getString("MSRN_FETCH_HOST", "10.168.3.57"),Integer.parseInt(AppConfig.config
							.getString("MSRN_FETCH_PORT", "8778")));
					int activateStatus=hlrInt.fetchmsrn(3, vnRequest.getMsisdn(), imsi, isPrepaid, msrnError);*/
					int activateStatus = FetchMsrn.fetchmsrn(3,
							vnRequest.getMsisdn(), msrn, vlr, imsi, scfAddress,
							serviceKey, isRoaming, isPrepaid, msrnError,
							busyNumber, noReplyNumber, unreachableNumber,
							cfuActive, cfuActiveStr);
					logger.info("ActivateStatus= " + activateStatus);

					if (activateStatus < 0) { // Changed from !=0 to <=0
						logger.info("There was some error while sending "
								+ "request to HLR[" + msrnError.intValue() + "]");

						if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
							tempId = AppConfig.config.getString("vmFailSubTempId",
									"1");
						} else if (vnRequest.getServiceType().equalsIgnoreCase(
								"0100")) {
							tempId = AppConfig.config.getString("vnFailSubTempId",
									"1");
						} else if (vnRequest.getServiceType().equalsIgnoreCase(
								"0001")) {
							tempId = AppConfig.config.getString("mcaFailSubTempId",
									"1");
						}
						if (AppConfig.config.getInt("CnfrmMessageEnable", 1) == 1) {
							boolean result = insertIntoGmat(vnRequest, tempId, "");
							if (!result) {
								logger.info("Message not inserted into Gmat Message Store Table");
							}
						}
						vnResponse.setResult("fail");
						vnResponse.setMsg(String.format(AppConfig.config.getString("vcc.server.error",
								"Internal Server Error")));
						if (AppConfig.config.getBoolean(
								"is_testing_enable_for_hlr", false)) {
							vnRequest.setStatus("A");
							/* Commented on 7th June 2019
							 * 
							 * vnResponse.setState("SUCCESS");*/
							vnResponse.setState("HLR_SUCCESS");
							return gson.toJson(vnResponse);
						} else {
							vnResponse.setState("FAIL");
							return gson.toJson(vnResponse);
						}
					}
					else
					{
						logger.info("HLR flag set successfully. Now do charging. Msisdn["+vnRequest.getMsisdn()+"]");
						vnRequest.setStatus("A");
						/* Commented on 7th June 2019
						 * 
						 * vnResponse.setState("SUCCESS");*/
						vnResponse.setState("HLR_SUCCESS");
						return gson.toJson(vnResponse);
					}
				} else {
					vnRequest.setStatus("A");
					vnResponse.setState("HLR_SUCCESS");
					return gson.toJson(vnResponse);
				}
			}
			/*
			 * Default profile If crm/hlr is not set in config file
			 */
			//check that if user alreaday exits then not go further
			if(vccSub!=null)
			{
				logger.info(String.format(
						"[%s] [%s] [%s] [%s] charging interface [%s] cbcm enable [%s] sub typ [%s]"
								+ "subscriber already subscribed ",
						vnRequest.getMsisdn(),
						vnRequest.getTid(),
						vnRequest.getServiceType(),
						vnRequest.getActionId(),
						AppConfig.config.getString("charging.type.interface", "NA"),
						vnRequest.getCbcmEnable(), vnRequest.getSubType()));
						vnRequest.setStatus("A");
						
						logger.debug(String.format(
								"[%s] [%s] [%s] [%s] have charging code [%s]",
								vnRequest.getMsisdn(), vnRequest.getTid(),
								vnRequest.getServiceType(), vnRequest.getActionId(),
								chargingCode.getHasChargingCode()));
								vnResponse.setState("FAIL");
								vnResponse.setMsg(String.format(
										AppConfig.config.getString("vcc.already.sub", "User is already subscribed")));
								
						return gson.toJson(vnResponse);
			}
			else
			{
				if (AppConfig.config.getBoolean("TIBOCO_INTEGRATION")) {
					logger.info(String.format(
							"[%s] [%s] [%s] [%s] charging interface [%s] cbcm enable [%s] sub typ [%s]"
									+ "subscribed internally", vnRequest
									.getMsisdn(), vnRequest.getTid(), vnRequest
									.getServiceType(), vnRequest.getActionId(),
							AppConfig.config.getString(
									"charging.type.interface", "NA"), vnRequest
									.getCbcmEnable(), vnRequest.getSubType()));
					vnRequest.setStatus("A");

					if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
						tempId = AppConfig.config.getString("vmSubTempId", "1");
					} else if (vnRequest.getServiceType().equalsIgnoreCase(
							"0100")) {
						tempId = AppConfig.config.getString("vnSubTempId", "1");
					} else if (vnRequest.getServiceType().equalsIgnoreCase(
							"0001")) {
						tempId = AppConfig.config
								.getString("mcaSubTempId", "1");
					}
					if (AppConfig.config.getInt("CnfrmMessageEnable", 1) == 1) {
						boolean result = insertIntoGmat(vnRequest, tempId, "");
						if (!result) {
							logger.debug("Message not inserted into Gmat Message Store Table");
						}

					}
					boolean isLogSaved = new VccMailboxLogHandler()
							.updateTransactionLog(vnRequest);
					logger.info(String.format("[%s] mailbox logs saved [%s]",
							vnRequest.getMsisdn(), isLogSaved));

					logger.debug(String.format(
							"[%s] [%s] [%s] [%s] have charging code [%s]",
							vnRequest.getMsisdn(), vnRequest.getTid(),
							vnRequest.getServiceType(),
							vnRequest.getActionId(),
							chargingCode.getHasChargingCode()));
					vnResponse.setState("SUCCESS");
					return gson.toJson(vnResponse);
				} else {
					logger.info("Failed to process the request. Please check the sending parameters. Msisdn["
							+ vnRequest.getMsisdn()
							+ "] CBCM Enable Flag["
							+ vnRequest.getCbcmEnable()
							+ "] SubType["
							+ vnRequest.getSubType()
							+ "] charging.type.interface["
							+ AppConfig.config.getString(
									"charging.type.interface", "NA") + "]");
					vnResponse.setState("FAIL");
					vnResponse.setMsg(String.format(AppConfig.config.getString("vcc.server.error",
							"Internal Server Error")));
					return gson.toJson(vnResponse);
				}
			}
			
		} catch (Exception e) {
			logger.error("Exception inside doSubscribe method >> "
					+ e.getMessage());
			vnResponse.setState("FAIL");
			return gson.toJson(vnResponse);
		}
	}

	public String saveDetail(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {

		
		isAuthSaved = vccService.saveAuthUserDetail(vnRequest, rateModel,
				chargingCode, scope, new VccError(), vccSub);

		
		isMasterSaved = vccService.saveUserDetail(vnRequest, rateModel,
				chargingCode, vccSub);
		
		
		logger.debug(String.format(
				"[%s] [%s] [%s] [%s] save in vcc_subscription_master [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				isMasterSaved));
		
		logger.info(String
				.format("[%s] [%s] [%s] [%s] save in vcc_auth_user [%s] save in vcc_subscription_master [%s]",
						vnRequest.getMsisdn(), vnRequest.getTid(),
						vnRequest.getServiceType(), vnRequest.getActionId(),
						isAuthSaved, isMasterSaved));
		
		vnResponse.setState("LOGS");
		return gson.toJson(vnResponse);
	}

	public String saveTransaction(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		logger.debug(String.format("[%s] [%s] [%s] [%s] save transaction",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId()));
		if (isMasterSaved > 0 && isAuthSaved > 0) {
			boolean isOptoutRemove = vccService.removeOptoutUser(vnRequest);// vcc_service_unsub
			
			if (AppConfig.config.getString("ASYNC_FLOW_ENABLE", "1")
					.equalsIgnoreCase("-1")) {
				boolean isLogSaved = new VccMailboxLogHandler()
						.updateTransactionLog(vnRequest);
				logger.info(String.format("[%s] mailbox logs saved [%s]",
						vnRequest.getMsisdn(), isLogSaved));
			}
			// boolean isLogSaved = new
			// VccMailboxLogHandler().updateTransactionLog(vnRequest,
			// chargingCode);
			logger.info(String.format("[%s] [%s] [%s] [%s] remove optout [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId(),
					isOptoutRemove));
			vnResponse.setResult("success");
			vnResponse.setMsg(String.format(AppConfig.config.getString(
					vnRequest.getServiceType() + ".subscribe_successfully",
					"Subscribed successfully"), vnRequest.getMsisdn(),
					vnRequest.getServiceType()));
		} else {
			vnResponse.setResult("fail");

			vnResponse.setMsg(String.format(AppConfig.config.getString("vcc.server.error",
					"Internal Server Error")));
		}
		vnResponse.setState("END");
		return gson.toJson(vnResponse);
		// return "END";
	}
	
	

	public String updateProfileNumber(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		vnCode.setBl(vccService.isUserExistWithInRange(vnRequest));
		serviceName = AppConfig.config.getString("service."
				+ vnRequest.getServiceType());
		VccSubscriptionMasterModel vccSub = vccService
				.getServiceDetailByServiceType(vnRequest);
		boolean status = vccSubMaster.getChangeMsisdnExist(vnRequest);
		if (status) {
			logger.info("Changed MSISDN already subscribed msisdn ["
					+ vnRequest.getMsisdn() + "] change msisdn ["
					+ vnRequest.getChangedMsisdn() + "] service type ["
					+ vnRequest.getServiceType() + "]");
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString(
					"change_number_already_subscribed",
					"Change number is already subscriber"), vnRequest
					.getMsisdn(), vnRequest.getServiceType()));
			vnResponse.setState("END");
			return gson.toJson(vnResponse);
			// return "END";
		}

		if (vccSub == null) {
			logger.info(String.format(
					"[%s] [%s] [%s] [%s] user is not a subscriber",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId()));
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(
					AppConfig.config.getString(vnRequest.getServiceType()
							+ ".not_subscriber", "User is not a subscriber"),
					vnRequest.getMsisdn(), vnRequest.getServiceType()));
			vnResponse.setState("END");
			return gson.toJson(vnResponse);
			// return "END";
		}
		if (vnRequest.getMsisdn().equals(vnRequest.getChangedMsisdn())) {
			logger.info(String.format(
					"[%s] [%s] [%s] [%s] msisdn [%s] and changed "
							+ "msisdn [%s] both are equals",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId(),
					vnRequest.getMsisdn(), vnRequest.getChangedMsisdn()));
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString(
					"equal_msisdn", "MSISDN and New MSISDn are equal"),
					vnRequest.getMsisdn(), vnRequest.getServiceType()));
			vnResponse.setState("END");
			return gson.toJson(vnResponse);
			// return "END";
		}
		if (!vnCode.getBl()
				&& !vnRequest.getMsisdn().equals(vnRequest.getChangedMsisdn())) {
			boolean isNumberUpdate = vccService.changeNumber(vnRequest, error);
			boolean isRemove = vccService
					.deleteVoiceMsgByMsisdnAndServiceType(vnRequest);
			logger.info(String
					.format("[%s] [%s] [%s] [%s] VoiceMsgRemoved [%s] Number Update [%s]",
							vnRequest.getMsisdn(), vnRequest.getTid(),
							vnRequest.getServiceType(),
							vnRequest.getActionId(), isRemove, isNumberUpdate));
			if (!error.getError()) {
				vnRequest.setType("CN");

				String msisdn = vnRequest.getMsisdn();
				vnRequest.setMsisdn(vnRequest.getChangedMsisdn());
				vnRequest.setUpdatedBy(msisdn);
				boolean isLogSaved = new VccMailboxLogHandler()
						.updateTransactionLog(vnRequest);
				logger.info(String
						.format("[%s] mailbox logs saved for Change Number user [%s] Changed number is [%s]",
								msisdn, isLogSaved,
								vnRequest.getChangedMsisdn()));
				vnResponse.setResult("success");
				vnResponse.setMsg(AppConfig.config.getString(
						"change_number_success",
						"Number is changed successfully"));
			} else {
				vnResponse.setResult("fail");
				vnResponse.setMsg(AppConfig.config.getString(
						"change_number_alreday_mainnumber", "Telephone number "
								+ vnRequest.getChangedMsisdn()
								+ "already allocated as main number"));
			}
		} else {
			logger.info(String.format("[%s] [%s] [%s] [%s] Number is not "
					+ "changed due to blacklist [%s]", vnRequest.getMsisdn(),
					vnRequest.getTid(), vnRequest.getServiceType(),
					vnRequest.getActionId(), vnCode.getBl()));
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString(
					"change_number_fail", "Number is not changed"), vnRequest
					.getMsisdn(), vnRequest.getServiceType()));
		}
		vnResponse.setState("END");
		return gson.toJson(vnResponse);
		// return "END";
	}

	public String doFinish(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		vnResponse.setMsisdn(vnRequest.getMsisdn());
		vnResponse.setActionId("" + vnRequest.getActionId());
		vnResponse.setTid(vnRequest.getTid());
		if (vnCode == null)
			vnCode = new VnInfo(false, false, 0);
		if (vnRequest.getActionId() == 1)
			vnResponse.setInfo(vnCode);
		return null;
	}

	public boolean insertIntoGmat(VccRequest vnRequest, String tempId,
			String replaceKey) {
		Boolean result = false;
		vccGmatMsgStore = new VccGmatMsgStore();

		String senderId = "";

		if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {

			senderId = AppConfig.config.getString("VM_SMS_SENDER_ID", "VM");
		} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {

			senderId = AppConfig.config.getString("VN_SMS_SENDER_ID", "VN");
		} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {

			senderId = AppConfig.config.getString("MCA_SMS_SENDER_ID", "MCA");
		}
		String key = tempId + "-" + vnRequest.getLang();
		logger.info("Request data: " + new Gson().toJson(vnRequest) + " key: "
				+ key);
		
		if(vnRequest.getServiceType().equalsIgnoreCase("0100") && AppConfig.config.getBoolean("vn_prefix_base_enable", false)) {
			logger.info("msg not send in case of VN because vn_prefix_base_enable="+AppConfig.config.getBoolean("vn_prefix_base_enable", false));
			return true;
		}
		result = vccGmatMsgStore.insertIntoGmatMsg(senderId, vnRequest, key,
				replaceKey);

		return (result);
	}

	/*
	 * public String updtateStatus(VccRequest vnRequest, VnInfo vnCode,
	 * VnResponse vnResponse) {
	 * 
	 * logger.info("Inside updateStatus"); VccSubscriptionMasterModel vccSub =
	 * vccService .getServiceDetailByServiceType(vnRequest); if (vccSub == null)
	 * { logger.info(String.format(
	 * "[%s] [%s] [%s] [%s] user is not a subscriber", vnRequest.getMsisdn(),
	 * vnRequest.getTid(), vnRequest.getServiceType(),
	 * vnRequest.getActionId())); vnResponse.setResult("fail");
	 * vnResponse.setMsg(String.format(AppConfig.config.getString(
	 * vnRequest.getLang() + ErrorCode._not_subscriber,
	 * "User is not a subscriber"), vnRequest.getMsisdn(),
	 * vnRequest.getServiceType())); return "FAIL"; } else { vccAuthUser=new
	 * VccAuthUser(); logger.info(String.format(
	 * "[%s] [%s] [%s] [%s] Number is not " + "changed due to blacklist [%s]",
	 * vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(),
	 * vnRequest.getActionId())); vnResponse.setResult("success"); int
	 * result=vccAuthUser.updateSubProfile(vnRequest,"A"); if(result>0) {
	 * vnResponse.setResult("success");
	 * vnResponse.setMsg(String.format(AppConfig.config.getString(
	 * vnRequest.getLang() + ErrorCode._status_change_success,
	 * "Success status change"), vnRequest.getMsisdn(), vnRequest
	 * .getServiceType())); }
	 * 
	 * else { vnResponse.setResult("fail");
	 * vnResponse.setMsg(String.format(AppConfig.config.getString(
	 * vnRequest.getLang() + ErrorCode._status_change_fail,
	 * "Fail  status change"), vnRequest.getMsisdn(), vnRequest
	 * .getServiceType())); }
	 * vnResponse.setMsg(String.format(AppConfig.config.getString(
	 * vnRequest.getLang() + ErrorCode._change_number_fail,
	 * "Number is not changed"), vnRequest.getMsisdn(), vnRequest
	 * .getServiceType())); } return "END"; }
	 */

	public String doChangeProfile(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		int result = vccService.updateProfile(vnRequest, rateModel,
				chargingCode);
		String status = removeHistory(vnRequest, vnCode, vnResponse);

		if (status.equalsIgnoreCase("ERROR"))
			logger.info(String
					.format("[%s] Error in logs deleted for profile reset User  user [%s] ",
							vnRequest.getPlanName(), vnRequest.getMsisdn()));
		logger.info(String.format(
				"[%s] Profile reset and logs deleted of profile [%s]",
				vnRequest.getMsisdn(), vnRequest.getPlanName()));

		if (result > 0) {
			if (vnRequest.getPlanName().equalsIgnoreCase("basic"))
				vnRequest.setType("ETB");
			else if (vnRequest.getPlanName().equalsIgnoreCase("executive"))
				vnRequest.setType("BTE");
			boolean isLogSaved = new VccMailboxLogHandler()
					.updateTransactionLog(vnRequest);
			logger.info(String
					.format("[%s] mailbox logs saved for Change Profile user [%s] profile type [%s]",
							vnRequest.getMsisdn(), isLogSaved,
							vnRequest.getPlanName()));

			vnResponse.setResult("success");
			vnResponse.setMsg(String.format(AppConfig.config.getString(
					"profile_change_success", "Successfully change Profile"),
					vnRequest.getMsisdn(), vnRequest.getServiceType()));
		}

		else {
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString(
					"profile_change_fail", "Fail to change Profile"), vnRequest
					.getMsisdn(), vnRequest.getServiceType()));
		}
		vnResponse.setState("END");
		return gson.toJson(vnResponse);
		// return "END";
	}

	public String removeHistory(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		try {
			VccFileDeleteWriter vccFileWriter = new VccFileDeleteWriter();
			fileList = vccService.getVoiceMailList(vnRequest);
			ivrRecordBasePath = AppConfig.config.getString("ivr_record_path");
			boolean relt = vccService
					.deleteVoiceMsgByMsisdnAndServiceType(vnRequest);
			logger.debug("Delete from voice mail is " + relt);
			if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
				greetingFileList = vccService.getGreetingList(vnRequest);
				groupFileList = vccService.getGroupList(vnRequest);
				vccService.deleteFromPersonalizedGreetingByMsisdn(vnRequest);
				vccService.deleteFromAdvanceDetailByMsisdn(vnRequest);
				vccService.deleteFromVoiceMsgScheduleByMsisdn(vnRequest);
				vccService.deleteFromGroupDetailByMsisdn(vnRequest);
				vccService.deleteFromGroupMasterByMsisdn(vnRequest);

				ivrGreetingBasePath = AppConfig.config
						.getString("ivr_greeting_path");
				ivrGroupBasePath = AppConfig.config.getString("ivr_group_path");

				if (greetingFileList.size() > 0) {
					for (int i = 0; i < greetingFileList.size(); i++)
						vccFileWriter.getRecordFilePath(
								vnRequest.getMsisdnWithoutCountryCode(),
								greetingFileList.get(i), ivrGreetingBasePath);

				}
				if (groupFileList.size() > 0) {
					for (int i = 0; i < groupFileList.size(); i++)
						vccFileWriter.getRecordFilePath(
								vnRequest.getMsisdnWithoutCountryCode(),
								groupFileList.get(i), ivrGroupBasePath);

				}

			}
			// boolean isLogSaved = new
			// VccMailboxLogHandler().updateTransactionLog(vnRequest,
			// chargingCode);

			if (fileList.size() > 0) {
				String recordPath = "";
				for (int i = 0; i < fileList.size(); i++)
					recordPath = vccFileWriter.getRecordFilePath(
							vnRequest.getMsisdnWithoutCountryCode(),
							fileList.get(i), ivrRecordBasePath);
				logger.info(" Record File Path is" + recordPath);
			}

			logger.info(String.format("[%s] [%s] [%s] [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId()));
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00058] TID["
					+ vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] Exception in removing History. " + e.getMessage());
			return "ERROR";
		} finally {
			if (fileList != null)
				fileList.clear();
			if (greetingFileList != null)
				greetingFileList.clear();
			if (groupFileList != null)
				groupFileList.clear();
		}
		return "success";
	}
	
	/*
	 * Added By Richard on 7th June 2019
	 */
	public String doSubscriptionCharging(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		
		int chargingResponse=doCharging.doCharging(vnRequest,chargingCode);
		String tempId="";
		
		if(AppConfig.config.getBoolean("SEND_LOW_BALANCE_MESSAGE",false))
		{
			if(chargingResponse==ErrorCodes.LOW_BALANCE_ERROR)
			{
				if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
					tempId = AppConfig.config.getString("vmLowBalFailSubTempId", "1");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
					tempId = AppConfig.config.getString("vnLowBalFailSubTempId", "1");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
					tempId = AppConfig.config.getString("mcaLowBalFailSubTempId", "1");
				}
				vnResponse.setState("FAIL");
				vnResponse.setMsg(String.format(AppConfig.config.getString("vcc.charging.low.balance",
						"User running on low balance.")));
				vnResponse.setResult("FAIL"); // added by sanchit atri 22-09-2020
			}
			else if(chargingResponse==1)
			{
				if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
					tempId = AppConfig.config.getString("vmSubTempId", "1");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
					tempId = AppConfig.config.getString("vnSubTempId", "1");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
					tempId = AppConfig.config.getString("mcaSubTempId", "1");
				}
				vnResponse.setState("SUCCESS");
			}
			else
			{
				if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
					tempId = AppConfig.config.getString("vmFailSubTempId", "1");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
					tempId = AppConfig.config.getString("vnFailSubTempId", "1");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
					tempId = AppConfig.config.getString("mcaFailSubTempId", "1");
				}
				vnResponse.setState("FAIL");
				vnResponse.setMsg(String.format(AppConfig.config.getString("vcc.server.error",
						"Internal server error")));
			}
		}
		else
		{
			if(chargingResponse==1)
			{
				if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
					tempId = AppConfig.config.getString("vmSubTempId", "1");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
					tempId = AppConfig.config.getString("vnSubTempId", "1");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
					tempId = AppConfig.config.getString("mcaSubTempId", "1");
				}
				vnResponse.setState("SUCCESS");
			}
			else if(chargingResponse==ErrorCodes.LOW_BALANCE_ERROR)
			{
				vnResponse.setState("FAIL");
				vnResponse.setMsg(String.format(AppConfig.config.getString("vcc.charging.low.balance",
						"User running on low balance.")));
			}
			else
			{
				vnResponse.setState("FAIL");
				vnResponse.setMsg(String.format(AppConfig.config.getString("vcc.server.error",
						"Internal Server Error")));
			}
			/*
			else
			{
				if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
					tempId = AppConfig.config.getString("vmFailSubTempId", "1");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
					tempId = AppConfig.config.getString("vnFailSubTempId", "1");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
					tempId = AppConfig.config.getString("mcaFailSubTempId", "1");
				}
				vnResponse.setState("FAIL");
			}*/
			
		}
		
		if (AppConfig.config.getInt("CnfrmMessageEnable_WithCharging", 1) == 1) {
			boolean result = insertIntoGmat(vnRequest, tempId, "");
			if (!result) {
				logger.debug("Message not inserted into Gmat Message Store Table");
			}

		}		
		return gson.toJson(vnResponse);
		
	}
	
	
	
}
