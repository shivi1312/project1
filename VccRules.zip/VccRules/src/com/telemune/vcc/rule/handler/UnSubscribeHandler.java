package com.telemune.vcc.rule.handler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.HLR.FetchMsrn;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.HttpConnectionPool.CRMHttpHit;
import com.telemune.vcc.rule.common.VccRequestCache;
import com.telemune.vcc.rule.domain.VccAuthUser;
import com.telemune.vcc.rule.domain.VccCallback;
import com.telemune.vcc.rule.domain.VccGmatMsgStore;
import com.telemune.vcc.rule.domain.VccLicense;
import com.telemune.vcc.rule.domain.VccRatePlan;
import com.telemune.vcc.rule.domain.VccSeriesRange;
import com.telemune.vcc.rule.domain.VccSubscriptionMaster;
import com.telemune.vcc.rule.model.VccChargingCodeModel;
import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.response.VnInfo;
import com.telemune.vcc.rule.response.VnResponse;
import com.telemune.vcc.rule.services.Service;
import com.telemune.vcc.rule.services.VccServices;

import log.telemune.vcc.rule.history.VccFileDeleteWriter;

public class UnSubscribeHandler {
	final static Logger logger = Logger.getLogger(UnSubscribeHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private Gson gson = new Gson();
	private Service vccService = new VccServices();
	private VccFileDeleteWriter vccFileWriter = new VccFileDeleteWriter();
	@SuppressWarnings("unused")
	private VccChargingCodeModel chargingCode = new VccChargingCodeModel();
	private VccRatePlan vccRatePlan = new VccRatePlan();
	@SuppressWarnings("unused")
	private String serviceName;
	private int isMasterSaved = 0;
	private int isAuthSaved = 0;
	private String ivrRecordBasePath;
	private String ivrGreetingBasePath;
	private String ivrGroupBasePath;
	private List<String> fileList = new ArrayList<String>();
	private List<String> greetingFileList = new ArrayList<String>();
	private List<String> groupFileList = new ArrayList<String>();
	private VccGmatMsgStore vccGmatMsgStore = null;
	private VccSubscriptionMasterModel vccSub = null;
	public SubscribeHandler subHandler = null;
	public VccSubscriptionMaster vccSubMaster = null;
	public VccAuthUser vccAuthUser = new VccAuthUser();

	public CRMHttpHit crmHttpHit = null;

	public String canUnSubscribe(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {
		
				serviceName = AppConfig.config.getString("service." + vnRequest.getServiceType());
				vccSub = vccService.getServiceDetailByServiceType(vnRequest);
				String tempId = "";
				
				if (!VccRequestCache.exist("unsub_" + vnRequest.getMsisdn())) {
					VccRequestCache.put("unsub_" + vnRequest.getMsisdn(), gson.toJson(vnRequest),
							AppConfig.config.getInt("req.expiry.cache.time", 20));
				} else {
					vnResponse.setResult("fail");
					vnResponse.setMsg("Request is already under process for unsubscription");
					vnResponse.setState("DIS_ALLOW");
					logger.info(String.format(
							"[%s] [%s] [%s] [%s] Drop request:: because request is already under process for unsubscription",
							vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId()));
					return gson.toJson(vnResponse);
				}
		
				if (vccSub != null) {
					/*
					 * Added by Vivek to send message in selected language instead of
					 * profiling language
					 */
					logger.info(String.format("[%s] [%s] [%s] [%s] Send msg in profiling language [%s]", vnRequest.getMsisdn(),
							vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId(),
							AppConfig.config.getBoolean("SND_MSG_ON_PROFILE_LNG", true)));
					if (AppConfig.config.getBoolean("SND_MSG_ON_PROFILE_LNG", true))
						vnRequest.setLang(vccSub.getLanguage());
					/* Message in profiling language or selected language end here */
				} else {
					logger.info(String.format("[%s] [%s] [%s] [%s] missing profile during unsub", vnRequest.getMsisdn(),
							vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId()));
				}
		
				if (vccSub == null) {
					if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
						tempId = AppConfig.config.getString("vmAlreadyUnSubTempId", "11");
					} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
						tempId = AppConfig.config.getString("vnAlreadyUnSubTempId", "15");
					} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
						tempId = AppConfig.config.getString("mcaFailUnSubTempId", "15");
					}
					if(AppConfig.config.getInt("CnfrmMessageEnable",1)==1)
					{
					boolean result = insertIntoGmat(vnRequest, tempId);
					if (result)
						logger.debug("Message insert into data base successfully");
					}
					vnResponse.setResult("fail");
					vnResponse.setMsg(String.format(AppConfig.config.getString(vnRequest.getServiceType() + ".not_subscriber",
							"User is not a subscriber"), vnRequest.getMsisdn(), vnRequest.getServiceType()));
					logger.info(String.format("[%s] [%s] [%s] [%s] planname [%s] User is not a subscriber",
							vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId(),
							vnRequest.getPlanName()));
					vnResponse.setState("DIS_ALLOW");
					return gson.toJson(vnResponse);
					// return "DIS_ALLOW";
				} else if (!vccSub.getStatus().equalsIgnoreCase("A") && !vccSub.getStatus().equalsIgnoreCase("I")) {
		
					vnResponse.setResult("fail");
					vnResponse.setState("DIS_ALLOW");
		
					if (AppConfig.config.getString("ASYNC_FLOW_ENABLE", "1")
							.equalsIgnoreCase("1")) {
						if (vccSub.getStatus().equalsIgnoreCase("D")) {
							vnResponse.setMsg(String.format(AppConfig.config.getString(
									vnRequest.getServiceType() + ".unsub_underprocess",
									"User Unsubscription request is under process."),
									vnRequest.getMsisdn(), vnRequest.getServiceType()));
							logger.info(String
									.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User Unsubscription Request is already under process.",
											vnRequest.getMsisdn(), vnRequest.getTid(),
											vnRequest.getServiceType(),
											vnRequest.getActionId(),
											vnRequest.getPlanName(), vccSub.getStatus()));
		
							tempId = AppConfig.config.getString("unSubAckTempId", "9");
							logger.info("Ack Message Enable is "
									+ AppConfig.config.getInt("AckMessageEnable", 0));
		
							if (AppConfig.config.getInt("AckMessageEnable", 0) == 1) {
								boolean result = insertIntoGmat(vnRequest, tempId);
								if (result)
									logger.info(String.format(
											"[%s] [%s] [%s] [%s] Msg inserted success",
											vnRequest.getMsisdn(), vnRequest.getTid(),
											vnRequest.getServiceType(),
											vnRequest.getActionId()));
							}
						} else if (vccSub.getStatus().equalsIgnoreCase("P")) {
		
							vnResponse.setMsg(String.format(AppConfig.config.getString(
									vnRequest.getServiceType() + ".sub_underprocess",
									"User subscription request is under process."),
									vnRequest.getMsisdn(), vnRequest.getServiceType()));
							logger.info(String
									.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User subscription request is already under process, so can't process the unsubscription request further.",
											vnRequest.getMsisdn(), vnRequest.getTid(),
											vnRequest.getServiceType(),
											vnRequest.getActionId(),
											vnRequest.getPlanName(), vccSub.getStatus()));
		
							tempId = AppConfig.config.getString("subAckTempId", "9");
							logger.info("Ack message enable is "
									+ AppConfig.config.getInt("AckMessageEnable", 0));
		
							if (AppConfig.config.getInt("AckMessageEnable", 0) == 1) {
								boolean result = insertIntoGmat(vnRequest, tempId);
								if (result)
									logger.info(String.format(
											"[%s] [%s] [%s] [%s] Msg inserted success",
											vnRequest.getMsisdn(), vnRequest.getTid(),
											vnRequest.getServiceType(),
											vnRequest.getActionId()));
							}
						}
					} else if (vccSub.getStatus().equalsIgnoreCase("B")) {
		
						vnResponse.setMsg(String.format(AppConfig.config.getString(
								"vm_user_blocked",
								"User profile is blocked for Voice Mail services."),
								vnRequest.getMsisdn(), vnRequest.getServiceType()));
						logger.info(String
								.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User profile is blocked for Voice Mail services, so can't process the request further.",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId(),
										vnRequest.getPlanName(), vccSub.getStatus()));
		
						tempId = AppConfig.config.getString("userBlockTempId", "36");
						logger.info("User Block Message Enable is "
								+ AppConfig.config.getInt("UserBlockMessageEnable", 0));
		
						if (AppConfig.config.getInt("UserBlockMessageEnable", 0) == 1) {
							boolean result = insertIntoGmat(vnRequest, tempId);
							if (result)
								logger.info(String.format(
										"[%s] [%s] [%s] [%s] Msg inserted success",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId()));
						}
					} else {
						vnResponse.setMsg(String.format(AppConfig.config.getString(
								vnRequest.getServiceType() + ".unknown_status",
								"User profile status is unknown on the system"),
								vnRequest.getMsisdn(), vnRequest.getServiceType()));
						logger.info(String
								.format("[%s] [%s] [%s] [%s] planname [%s] status [%s] User profile status is unknown on the system, so can't process the request further.",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId(),
										vnRequest.getPlanName(), vccSub.getStatus()));
		
						tempId = AppConfig.config
								.getString("UnknownStatusTempId", "37");
						logger.info("Unknown Message Status Enable is "
								+ AppConfig.config.getInt("UnknownStatusMessageEnable",
										0));
		
						if (AppConfig.config.getInt("UnknownStatusMessageEnable", 0) == 1) {
							boolean result = insertIntoGmat(vnRequest, tempId);
							if (result)
								logger.info(String.format(
										"[%s] [%s] [%s] [%s] Msg inserted success",
										vnRequest.getMsisdn(), vnRequest.getTid(),
										vnRequest.getServiceType(),
										vnRequest.getActionId()));
						}
		
					}
					return gson.toJson(vnResponse);
				}
				vnResponse.setState("ALLOW");
				return gson.toJson(vnResponse);
				// return "ALLOW";
	
	}

	public String doUnsub(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {
		String tempId = "";
		// String response = "fail";
		boolean isFixed = new VccSeriesRange().isExistWithinGroup(vnRequest.getMsisdn(), "fixedline");
		if(isFixed){
			vnRequest.setSubType("F");
			logger.info(String.format("[%s] [%s] [%s] [%s] user is type of fixed [F]", vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId()));
		}
		if (vccSub != null) {
			/*
			 * Added by Vivek to send message in selected language instead of
			 * profiling language
			 */
			logger.info(String.format("[%s] [%s] [%s] [%s] Send msg in profiling language [%s]", vnRequest.getMsisdn(),
					vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId(),
					AppConfig.config.getBoolean("SND_MSG_ON_PROFILE_LNG", true)));
			if (AppConfig.config.getBoolean("SND_MSG_ON_PROFILE_LNG", true))
				vnRequest.setLang(vccSub.getLanguage());
			/* Message in profiling language or selected language end here */
		} else {
			logger.info(String.format("[%s] [%s] [%s] [%s] missing profile during unsub", vnRequest.getMsisdn(),
					vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId()));
		}
		logger.info(String.format("[%s] [%s] [%s] [%s] charging interface [%s] cbcm enable [%s]", vnRequest.getMsisdn(),
				vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId(),
				AppConfig.config.getString("charging.type.interface", "NA"), vnRequest.getCbcmEnable()));
		if(vnRequest.getInterFace().equalsIgnoreCase("M")){
			if(vnRequest.getPlanName().equalsIgnoreCase("NA")){
			vnRequest.setPlanName(vccRatePlan.getRatePlan(vnRequest));
			logger.debug("msisdn["+vnRequest.getMsisdn()+"] MML unsubs request PlanName is  "
					+ vnRequest.getPlanName());
			}
		
		}
		
		if (AppConfig.config.getString("charging.type.interface", "NA").equals("crm") && vnRequest.getCbcmEnable() && !vnRequest.getSubType().equals("F")) {
			if (!vnRequest.getInterFace().equalsIgnoreCase("M")) {
				if(vccRatePlan.getRatePlan(vnRequest).equalsIgnoreCase(vnRequest.getPlanName()) || vnRequest.getInterFace().equalsIgnoreCase("W"))
				{
				crmHttpHit = new CRMHttpHit();
				vnRequest.setActionType("DeleteService");
				vnRequest.setPlanName(vccRatePlan.getRatePlan(vnRequest));
				logger.debug("Send request to CRM server for check eligibility for unsubscribe resquest "
						+ vnRequest.getPlanName());
				vnResponse = crmHttpHit.sendGet(vnRequest, AppConfig.config.getString("create.profile"), vnResponse);
				
				if(vnResponse.getStatus().equalsIgnoreCase("fail") && (vnResponse.getResponseCode().equalsIgnoreCase("E04") || vnResponse.getResponseCode().equalsIgnoreCase("E07")))
				{
					logger.info(
							String.format("[%s] [%s] [%s] [%s] Response fail from VccCrmClient in case of getting E04 error Code", vnRequest.getMsisdn(),
									vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId()));
					return handleDefaultProfile(vnRequest, vnCode, vnResponse);
					
				}
				else if (!vnResponse.getStatus().equalsIgnoreCase("success")) {
					if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
						tempId = AppConfig.config.getString("vmFailUnsubFailTibaco", "29");
					} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
						tempId = AppConfig.config.getString("vnFailUnsubFailTibaco", "30");
					}
					if(AppConfig.config.getInt("CnfrmMessageEnable",1)==1)
					{
					boolean result = insertIntoGmat(vnRequest, tempId);
					if (!result) {
						logger.info("Message not inserted into Gmat Message Store Table");
					}
					}
					vnResponse.setResult("fail");
					vnResponse
							.setMsg(String.format(
									AppConfig.config.getString(vnRequest.getServiceType() + ".fail_unsubscribe",
											"User is not unsubscribe"),
									vnRequest.getMsisdn(), vnRequest.getServiceType()));
					vnResponse.setState("END");
					return gson.toJson(vnResponse);
					// return "END";
				}
				else {
					subHandler = new SubscribeHandler();
					logger.debug("getting response true from CRM server in case of unsub request");
					vnRequest.setStatus("D");
					vnRequest.setActionType("create");
					vccSubMaster = new VccSubscriptionMaster();
					int result = vccSubMaster.updateSubProfile(vnRequest, "D");
					int status=1;
					//int status = vccAuthUser.updateSubProfile(vnRequest, "D"); // Commented by Abhishek Rana on 9thMarch2018
					new VccCallback().storeCallback(vnRequest);// Added by vivek
																// for
																// initialize
																// callback
					// boolean isLogSaved = new
					// VccMailboxLogHandler().updateTransactionLog(vnRequest);
					if (result > 0 && status > 0) {
						tempId = AppConfig.config.getString("unSubAckTempId", "1");
						if(AppConfig.config.getInt("AckMessageEnable",1)==1)
						{
						boolean retVal = subHandler.insertIntoGmat(vnRequest, tempId,"");

						if (!retVal) {
							logger.info("Message not inserted into Gmat Message Store Table");
						}
						}
						vnResponse.setResult("success");
						vnResponse.setMsg(String.format(
								AppConfig.config.getString(vnRequest.getServiceType() + ".wait_subscribe",
										"Waiting for call back response from CRM for unsub"),
								vnRequest.getMsisdn(), vnRequest.getServiceType()));
					} else {
						logger.info(
								"There is any error in update status of vcc_auth_user and vcc_subscription_master ");
						vnResponse.setResult("fail");
						vnResponse
								.setMsg(String.format(
										AppConfig.config.getString(vnRequest.getServiceType() + ".fail_unsubscribe",
												"User is not unsubscribe"),
										vnRequest.getMsisdn(), vnRequest.getServiceType()));
					}
					vnResponse.setState("END");
					return gson.toJson(vnResponse);
					// return "END";
				}
			}
			else
			{
				logger.info("msisdn["+vnRequest.getMsisdn()+"] user planName and requested planName both are different so can not continue further processing..");
				if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
					tempId = AppConfig.config.getString("vmFailUnSubTempId", "11");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
					tempId = AppConfig.config.getString("vnFailUnSubTempId", "15");
				} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
					tempId = AppConfig.config.getString("mcaFailUnSubTempId", "15");
				}
				if(AppConfig.config.getInt("CnfrmMessageEnable",1)==1)
				{
				boolean result = insertIntoGmat(vnRequest, tempId);
				if (result)
					logger.debug("Message insert into data base successfully");
				}
				vnResponse.setResult("fail");
				vnResponse.setMsg(String.format(AppConfig.config.getString(vnRequest.getServiceType() + ".not_subscriber",
						"User is not a subscriber"), vnRequest.getMsisdn(), vnRequest.getServiceType()));
				logger.info(String.format("[%s] [%s] [%s] [%s] planname [%s] User is not a subscriber",
						vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId(),
						vnRequest.getPlanName()));
				vnResponse.setState("END");
				return gson.toJson(vnResponse);
		
			}	
		  }
			//not sending request to CRM
			
			
		}
		if (AppConfig.config.getString("charging.type.interface", "NA").equals("hlr") && vnRequest.getCbcmEnable() && !vnRequest.getSubType().equals("F")) {
			//added by kuldeep on 21 August 2020
			logger.debug("multi_service_enable="+AppConfig.config.getBoolean("multi_service_enable", false));
			//if multi_service_enable is true then get subType from other service [VM & MCA] if subscribed for same msisdn
			boolean isFlagDownRequired = true;
			if(AppConfig.config.getBoolean("multi_service_enable", false)) {
				if(vnRequest.getServiceType().equalsIgnoreCase("0001") || vnRequest.getServiceType().equalsIgnoreCase("0010")) {
					int countMSS =vccService.countForMultiServiceSubscriber(vnRequest);
					logger.debug("countMSS ["+ countMSS + "]");
					if(countMSS > 1) { //2 or greater
						isFlagDownRequired = false;
						logger.info("HLR flag not need to down because it is UP for other service VM or MCA for this msisdn ["+vnRequest.getMsisdn()+"]");
					}
				}
			}
			
			if(vnRequest.getServiceType().equalsIgnoreCase("0100") && AppConfig.config.getBoolean("vn_prefix_base_enable", false)) {
				isFlagDownRequired = false;
				logger.info("request NOT send to HLR Server for unsubscribe user because vn_prefix_base_enable="+AppConfig.config.getBoolean("vn_prefix_base_enable", false));
			}
			
			if(isFlagDownRequired) {
				logger.info("request send to HLR Server for unsubscribe user");
				String vlr = "", scfAddress = "", busyNumber = "", noReplyNumber = "", unreachableNumber = "";
				StringBuffer msrn = new StringBuffer();
				StringBuffer cfuActiveStr = new StringBuffer();
				Integer serviceKey = new Integer(0);
				Boolean isRoaming = new Boolean(true);
				Boolean isPrepaid = new Boolean(true);
				Boolean cfuActive = new Boolean(true);
				Integer msrnError = new Integer(0);
				StringBuffer imsi = new StringBuffer();

				int activateStatus = FetchMsrn.fetchmsrn(4, vnRequest.getMsisdn(), msrn, vlr, imsi, scfAddress, serviceKey,
						isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber, unreachableNumber, cfuActive,
						cfuActiveStr);
				logger.info("activateStatus= " + activateStatus);
				
				if (activateStatus < 0) {
					logger.info("\nThere was some error [" + msrnError.intValue() + "] in activate/deactivateSS\n");
					
					if(!AppConfig.config.getBoolean("IGNORE_HLR_STATUS_FOR_UNSUB", true))
					{
						if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
							tempId = AppConfig.config.getString("vmFailUnSubTempId", "1");
						} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
							tempId = AppConfig.config.getString("vnFailUnSubTempId", "1");
						} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
							tempId = AppConfig.config.getString("mcaFailUnSubTempId", "1");
						}
						if(AppConfig.config.getInt("CnfrmMessageEnable",1)==1)
						{
						boolean result = insertIntoGmat(vnRequest, tempId);
						if (!result) {
							logger.info("Message not inserted into Gmat Message Store Table");
						}
						}
						vnResponse.setResult("fail");
						vnResponse.setMsg(
								String.format(AppConfig.config.getString(vnRequest.getServiceType() + ".fail_unsubscribe",
										"User is not unsubscribe"), vnRequest.getMsisdn(), vnRequest.getServiceType()));
						if (!AppConfig.config.getBoolean("is_testing_enable_for_hlr", false)) {
							vnResponse.setState("FAIL");
							return gson.toJson(vnResponse);
							// return "FAIL";
						}
					}
				}
			}
		}
		return handleDefaultProfile(vnRequest, vnCode, vnResponse);
		
		
		
	}
		public String handleDefaultProfile(VccRequest vnRequest,VnInfo vnCode, VnResponse vnResponse)
		{
			String tempId="";
		if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
			tempId = AppConfig.config.getString("vmUnsubTempId", "3");
		} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
			tempId = AppConfig.config.getString("vnUnsubTempId", "4");
		} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
			tempId = AppConfig.config.getString("mcaUnsubTempId", "4");
		}
		if(AppConfig.config.getInt("CnfrmMessageEnable_Unsubscribe",1)==1)
		{
		boolean result = insertIntoGmat(vnRequest, tempId);
		if (!result) {
			logger.debug("Message not inserted into Gmat Message Store Table");
		}
		}
		logger.info(String.format("[%s] [%s] [%s] [%s] charging interface [%s] cbcm enable [%s] "
				+ "unsubscribed internally", vnRequest.getMsisdn(),vnRequest.getTid(), 
				vnRequest.getServiceType(), vnRequest.getActionId(),AppConfig.config.
				getString("charging.type.interface", "NA"), vnRequest.getCbcmEnable()));
		
		if (vnRequest.getPlanName() == null)
			vnRequest.setPlanName(vccRatePlan.getRatePlan(vnRequest));
		logger.debug("ratePlan Name is [" + vnRequest.getPlanName() + "]");
		
		
		this.deleteFromMaster(vnRequest, vnCode, vnResponse);
		this.deleteFromAuth(vnRequest, vnCode, vnResponse);
		
		logger.info(String.format("[%s] [%s] [%s] [%s] is auth delete [%s] is master delete [%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId(),
				isAuthSaved, isMasterSaved));

		if (isAuthSaved > 0 && isMasterSaved > 0) {
			vnResponse.setResult("success");
			boolean isLogSaved = new VccMailboxLogHandler().updateTransactionLog(vnRequest);
			logger.info(String.format("[%s] mailbox logs saved [%s]", vnRequest.getMsisdn(),isLogSaved));
			vnResponse
					.setMsg(String.format(
							AppConfig.config.getString(vnRequest.getServiceType() + ".unsub_success",
									"User is unsubscribed successfully"),
							vnRequest.getMsisdn(), vnRequest.getServiceType()));
			if(vnRequest.getServiceType().equalsIgnoreCase("0001"))
			{
				vnResponse.setState("END");
			}
			else
			{
				vnResponse.setState("HISTORY");
			}
			return gson.toJson(vnResponse);
			// return "HISTORY";
		} else {
			vnResponse.setResult("fail");
			vnResponse.setMsg(String.format(AppConfig.config.getString(vnRequest.getServiceType() + ".fail_unsubscribe",
					"User is not unsubscribe"), vnRequest.getMsisdn(), vnRequest.getServiceType()));
			vnResponse.setState("END");
			return gson.toJson(vnResponse);
			// return "END";
		}
	}

	public String removeHistory(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {
		try {

			fileList = vccService.getVoiceMailList(vnRequest);
			ivrRecordBasePath = AppConfig.config.getString("ivr_record_path");
			boolean relt = vccService.deleteVoiceMsgByMsisdnAndServiceType(vnRequest);
			logger.debug("Delete from voice mail is " + relt);
			if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
				greetingFileList = vccService.getGreetingList(vnRequest);
				groupFileList = vccService.getGroupList(vnRequest);
				vccService.deleteFromPersonalizedGreetingByMsisdn(vnRequest);
				vccService.deleteFromAdvanceDetailByMsisdn(vnRequest);
				vccService.deleteFromVoiceMsgScheduleByMsisdn(vnRequest);
				vccService.deleteFromGroupDetailByMsisdn(vnRequest);
				vccService.deleteFromGroupMasterByMsisdn(vnRequest);

				ivrGreetingBasePath = AppConfig.config.getString("ivr_greeting_path");
				ivrGroupBasePath = AppConfig.config.getString("ivr_group_path");
				
				//logger.info("list size is"+greetingFileList.size());
				if (greetingFileList.size() > 0) {
					for (int i = 0; i < greetingFileList.size(); i++)
						vccFileWriter.getRecordFilePath(vnRequest.getMsisdnWithoutCountryCode(),
								greetingFileList.get(i), ivrGreetingBasePath);

				}
				if (groupFileList.size() > 0) {
					for (int i = 0; i < groupFileList.size(); i++)
						vccFileWriter.getRecordFilePath(vnRequest.getMsisdnWithoutCountryCode(), groupFileList.get(i),
								ivrGroupBasePath);

				}

			}
			// boolean isLogSaved = new
			// VccMailboxLogHandler().updateTransactionLog(vnRequest,
			// chargingCode);
			//logger.info("list size is"+fileList.size());
			if (fileList.size() > 0) {
				String recordPath = "";
				for (int i = 0; i < fileList.size(); i++)
					recordPath = vccFileWriter.getRecordFilePath(vnRequest.getMsisdnWithoutCountryCode(),
							fileList.get(i), ivrRecordBasePath);
				logger.info(" Record File Path is" + recordPath);
			}

			logger.info(String.format("[%s] [%s] [%s] [%s]", vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId()));
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00058] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType() + "] Exception in removing History. "
					+ e.getMessage());
			return "ERROR";
		} finally {
			if (fileList != null)
				fileList.clear();
			if (greetingFileList != null)
				greetingFileList.clear();
			if (groupFileList != null)
				groupFileList.clear();
		}
		vnResponse.setState("END");
		return gson.toJson(vnResponse);
		// return "END";
	}

	protected void deleteFromAuth(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {
		try {
			isAuthSaved = vccService.updateOrDeleteAuthDetail(vnRequest);
		} catch (Exception e) {

		}
	}

	protected void deleteFromMaster(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {
		try {
			isMasterSaved = vccService.deleteUserDetailByServiceTypeAndMsisdn(vnRequest);
		} catch (Exception e) {

		}
	}

	public String doFinish(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {
		vnResponse.setMsisdn(vnRequest.getMsisdn());
		vnResponse.setActionId("" + vnRequest.getActionId());
		vnResponse.setTid(vnRequest.getTid());
		return null;
	}

	public boolean insertIntoGmat(VccRequest vnRequest, String tempId) {
		Boolean result = false;
		vccGmatMsgStore = new VccGmatMsgStore();

		String senderId = "";

		if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {

			senderId = AppConfig.config.getString("VM_SMS_SENDER_ID", "VM");
		} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
			senderId = AppConfig.config.getString("VN_SMS_SENDER_ID", "VN");
		} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
			senderId = AppConfig.config.getString("MCA_SMS_SENDER_ID", "MCA");
		}
		String key = tempId + "-" + vnRequest.getLang();
		logger.info("Request data: " + new Gson().toJson(vnRequest) + " key: " + key);
		if(vnRequest.getServiceType().equalsIgnoreCase("0100") && AppConfig.config.getBoolean("vn_prefix_base_enable", false)) {
			logger.info("msg not send in case of VN because vn_prefix_base_enable="+AppConfig.config.getBoolean("vn_prefix_base_enable", false));
			return true;
		}
		result = vccGmatMsgStore.insertIntoGmatMsg(senderId, vnRequest, key,"");
		return (result);
	}

}
