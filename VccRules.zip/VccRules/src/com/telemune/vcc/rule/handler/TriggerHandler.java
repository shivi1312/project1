package com.telemune.vcc.rule.handler;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.HttpConnectionPool.CRMHttpHit;
import com.telemune.vcc.rule.common.ErrorCode;
import com.telemune.vcc.rule.domain.VccCallback;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.response.VnInfo;
import com.telemune.vcc.rule.response.VnResponse;

public class TriggerHandler {
	
	final static Logger logger = Logger.getLogger(TriggerHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	private CRMHttpHit crmHttpHit=null;
	private SubscribeHandler subscribeHandler=new SubscribeHandler();
	String tempId;
	private Gson gson = new Gson();
	public String setTrigger(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		crmHttpHit = new CRMHttpHit();
		logger.info("Send request to CRM server for modify profile");
		vnRequest.setActionType("AddService");
		if(vnRequest.getType().equalsIgnoreCase("ACT"))
				vnRequest.setActVal(true);
		else if(vnRequest.getType().equalsIgnoreCase("DACT"))
			vnRequest.setActVal(false);
		else
			vnRequest.setActVal(true);
		vnResponse = crmHttpHit.sendGet(vnRequest, AppConfig.config.getString("modify.profile"), vnResponse);
		if(vnResponse.getStatus().equalsIgnoreCase("success"))
		{
			
			logger.info(String.format(
					"[%s] [%s] [%s] [%s] In case of Active Trigger getting success response code from CRM",
					vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(),
					vnRequest.getActionId()));	
			vnRequest.setActionType("modify");
			tempId = AppConfig.config.getString("subActModifyTempId","1");
			if(AppConfig.config.getInt("ModifyActTrgMsgEnable",1)==1)
			{
				boolean result = subscribeHandler.insertIntoGmat(vnRequest, tempId,AppConfig.config.getString("ActTrg."+vnRequest.getActTrg(),"busy"));
				if (!result) {
					logger.info(String.format("[%s] [%s] [%s] [%s] Msg inserted fail", vnRequest.getMsisdn(),
							vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId()));
				}
			}
			new VccCallback().storeCallback(vnRequest);// Store callback
			
			vnResponse.setResult("success");
			vnResponse.setMsg(String.format(AppConfig.config.getString(
					vnRequest.getLang() + ErrorCode._trigger_success,
					"Trigger Active Successfully"), vnRequest.getMsisdn(), vnRequest
					.getServiceType()));
			vnResponse.setState("END");
			return gson.toJson(vnResponse);
			
		}
		else {
			logger.info(String.format(
					"[%s] [%s] [%s] [%s] In case of failure case of Active Trigger response code from CRM",
					vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(),
					vnRequest.getActionId()));
			if (vnRequest.getServiceType().equalsIgnoreCase("0010")) {
				tempId = AppConfig.config.getString("vmFailModifySubTempId", "10");
			} else if (vnRequest.getServiceType().equalsIgnoreCase("0100")) {
				tempId = AppConfig.config.getString("vnFailModifySubTempId", "13");
			} else if (vnRequest.getServiceType().equalsIgnoreCase("0001")) {
				tempId = AppConfig.config.getString("mcaFailModifySubTempId", "13");
			}
			if(AppConfig.config.getInt("ModifyMsgInsertionEnable",1)==1)
			{
				boolean result = subscribeHandler.insertIntoGmat(vnRequest, tempId,"");
				if (!result) {
					logger.info(String.format("[%s] [%s] [%s] [%s] Msg inserted fail", vnRequest.getMsisdn(),
							vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId()));
				}
				
			}
			
		vnResponse.setResult("fail");
		vnResponse.setMsg(String.format(AppConfig.config.getString(
				vnRequest.getLang() + ErrorCode._trigger_fail,
				"Trigger Active fail"), vnRequest.getMsisdn(), vnRequest
				.getServiceType()));
		vnResponse.setState("END");
		return gson.toJson(vnResponse);
		}
		//return "END";
	}
	public String doFinish(VccRequest vnRequest, VnInfo vnCode,
			VnResponse vnResponse) {
		vnResponse.setMsisdn(vnRequest.getMsisdn());
		vnResponse.setActionId("" + vnRequest.getActionId());
		vnResponse.setTid(vnRequest.getTid());
		return null;
	}
}
