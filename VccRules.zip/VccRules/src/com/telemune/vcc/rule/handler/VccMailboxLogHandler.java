package com.telemune.vcc.rule.handler;

import org.apache.log4j.Logger;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.domain.VccVoiceMsg;
import com.telemune.vcc.rule.model.VccChargingCodeModel;
import com.telemune.vcc.rule.model.VccMailboxLogModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.response.VnResponse;
import com.telemune.vcc.rule.services.Transaction;
import com.telemune.vcc.rule.services.UserTransaction;

public class VccMailboxLogHandler {
	private final static Logger logger = Logger.getLogger(VccMailboxLogHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	VccMailboxLogModel vccLog = new VccMailboxLogModel();
	VccVoiceMsg vccMsg = new VccVoiceMsg();
	Transaction transaction = new UserTransaction();

	public boolean updateTransactionLog(VccRequest vccRequest) {
		try {
			if(vccRequest.getActionId()==1)
				vccRequest.setType("S");
			else if(vccRequest.getActionId()==2)
				vccRequest.setType("U");
			if(vccRequest.getServerId()==0)
			{
				vccLog.setServerId(1);
			}
			else 
			{
				vccLog.setServerId(vccRequest.getServerId());
			}			
			vccLog.setMsisdn(vccRequest.getMsisdn());
			vccLog.setInterFace(vccRequest.getInterFace());
			/* if(vccRequest.getPlanName() != null ) */
			vccLog.setMailboxType(vccRequest.getPlanName());
			/*
			 * else { vccLog.setMailboxType(vccMsg.getRatePlan(vccRequest));
			 * logger.info("Rateplan name="+vccMsg.getRatePlan(vccRequest)); }
			 */
			vccLog.setServiceType(vccRequest.getServiceType());
		//	vccLog.setUpdatedBy(vccRequest.getReqBy());
			if(vccRequest.getUpdatedBy()==null || vccRequest.getUpdatedBy().equals(""))
			{
				vccLog.setUpdatedBy(vccRequest.getReqBy());
			}
			else
			{
				vccLog.setUpdatedBy(vccRequest.getUpdatedBy());
			}
			if(vccRequest.getActionId()==1)
			{
				vccLog.setDescription("SUBSCRIBED");
			}
			else if(vccRequest.getActionId()==2)
			{
				vccLog.setDescription("UNSUBSCRIBED");
			}
			vccLog.setType(vccRequest.getType());
			vccLog.setCdrStatus("N");
			vccLog.setSubType(vccRequest.getSubType());
			return transaction.saveTransactionLog(vccLog);
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode [VCC-RE-90003] TID[" + vccRequest.getTid() + "] MSISDN[" + vccRequest.getMsisdn()
							+ "] [Null Pointer Exception in saving transaction log] Error[" + npe.getMessage() + "]");
			return false;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00056] TID[" + vccRequest.getTid() + "] MSISDN["
					+ vccRequest.getMsisdn() + "] [Exception in saving transaction log] Error[" + e.getMessage() + "]");
			logger.error(String.format("[%s] [%s] actionid [%s] Exception: ", vccRequest.getMsisdn(),
					vccRequest.getTid(), vccRequest.getActionId(), e.getMessage()));
			e.printStackTrace();
			return false;
		}

	}
}
