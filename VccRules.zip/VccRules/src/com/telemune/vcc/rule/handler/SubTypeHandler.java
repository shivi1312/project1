package com.telemune.vcc.rule.handler;

import java.util.Arrays;

import org.apache.axis.AxisFault;
import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.HLR.FetchMsrn;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.HttpConnectionPool.CRMHttpHit;
import com.telemune.vcc.rule.domain.VccSeriesRange;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.response.VnInfo;
import com.telemune.vcc.rule.response.VnResponse;

public class SubTypeHandler {
	final static Logger logger = Logger.getLogger(SubTypeHandler.class);
	 final static Logger errorLogger = Logger.getLogger("errorLogger");

	private Integer subTypeInterface;
	public CRMHttpHit crmHttpHit = null;
	private Gson gson = new Gson();

	int result = -1;
	
	public static void main(String [] args){
		VccRequest vnRequest = new VccRequest();
		VnResponse vnResponse = new VnResponse();
		vnRequest.setMsisdn("971568182000");
		vnRequest.setActionId(4);
		vnRequest.setTid("234343545424");
		SubTypeHandler subHan = new SubTypeHandler();
		vnResponse.setSubType("N");
		subHan.setRes(vnResponse);
		System.out.println("resp: "+vnResponse.getSubType());
	}
	public void setRes(VnResponse vnResponse){
		System.out.println("resp: "+vnResponse.getSubType());
		vnResponse.setSubType("P");
	}
	public String getSubType(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {
		try {
			String response = "ERROR";
			// sub.type.interface 1 for Crm, 2 for Hlr, 3 for Prepaid, 4 for
			// Postpaid, 5 for Fixed
			
			if(AppConfig.config.getBoolean("CHECK_FOR_FIXED_LINE",false))
			{
				boolean isFixed = new VccSeriesRange().isExistWithinGroup(vnRequest.getMsisdn(), "fixedline");
				if(isFixed){
					vnResponse.setSubType("F");
					vnResponse.setResult("success");
					vnResponse.setMsg(
							String.format(AppConfig.config.getString(".sub_type_success",
									"Success SubType"), vnRequest.getMsisdn(), vnRequest.getServiceType()));
					vnResponse.setState("END");
					logger.info("response: "+gson.toJson(vnResponse));
					vnRequest.setSubType(vnResponse.getSubType());
					return gson.toJson(vnResponse);
				}
			}
			if (AppConfig.config.getInt("sub.type.interface") == 1) {
				if (!vnRequest.getInterFace().equalsIgnoreCase("M")||(vnRequest.getInterFace().equals("M") 
						&& AppConfig.config.getBoolean("get.sub.type.in.mml",true))) {
					crmHttpHit = new CRMHttpHit();
					logger.debug("Send request to CRM server for get sub type");
					vnResponse = crmHttpHit.sendGet(vnRequest, AppConfig.config.getString("query.hlr"), vnResponse);
					logger.info("["+vnRequest.getMsisdn()+"] Crm res: [" + vnResponse.getStatus() +"] sub type ["+vnResponse.getSubType()+"]");
					logger.info("["+vnRequest.getMsisdn()+"] all sub type ["+AppConfig.config.getList("avail.sub.types")+"]");
					if (AppConfig.config.getList("avail.sub.types", Arrays.asList("P", "O", "F"))
							.contains(vnResponse.getSubType())) {
						logger.info("Inside condition when subtype match ["+vnResponse.getSubType()+"]");
						vnResponse.setSubType(vnResponse.getSubType());
					}else{
						logger.info("["+vnRequest.getMsisdn()+"] inside set subtype N condition");
						vnResponse.setSubType("N");
					}
					vnResponse.setResult("success");
					vnResponse.setMsg(
							String.format(AppConfig.config.getString(".sub_type_success",
									"Success SubType"), vnRequest.getMsisdn(), vnRequest.getServiceType()));
					logger.info("response: "+gson.toJson(vnResponse));
					vnResponse.setState("END");
					vnRequest.setSubType(vnResponse.getSubType());
					return gson.toJson(vnResponse);
				}
			}
			if (AppConfig.config.getInt("sub.type.interface") == 2) {
				String vlr = "";
				String scfAddress = "";
				String busyNumber = "";
				String noReplyNumber = "";
				String unreachableNumber = "";
				StringBuffer msrnBuf = new StringBuffer();
				StringBuffer imsiBuf = new StringBuffer();
				StringBuffer cfuActiveStr = new StringBuffer();

				Boolean isRoaming = true;
				Boolean isPrepaid = true;
				Boolean cfuActive = true;

				int msrnError = 0;
				int serviceKey = 0;

				try {
					subTypeInterface = AppConfig.config.getInt("sub.type.interface", 1);
					if (subTypeInterface == 3) {
						vnResponse.setSubType("P");
					} else if (subTypeInterface == 4) {
						vnResponse.setSubType("O");
					} else {
						result = FetchMsrn.fetchmsrn(6, vnRequest.getMsisdn(), msrnBuf, vlr, imsiBuf, scfAddress,
								serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber,
								unreachableNumber, cfuActive, cfuActiveStr);
						logger.info("After FetchMsrn result :[" + result + "]");

						if (result == 1) // Treat postpaid as prepaid
						{
							vnResponse.setSubType("P"); /** prepaid */
						} else if (result == 2 || result == 3) // Treat Dual and
																// hybrid as
																// postpaid
						{
							vnResponse.setSubType("O"); /** postpaid */
						} else {
							logger.info("Subtype not found. Rresponse from fechMsrn is[" + result + "]");
							vnResponse.setSubType("NA");
						}
					}
					// vnResponse.setSubType("NA");
				} catch (Exception ex) {
                    if (ex instanceof AxisFault) {
                        errorLogger.error("ErrorCode [VCC-RE-00004] TID["
                                        + vnRequest.getTid() + "] MSISDN["
                                        + vnRequest.getMsisdn() + "] ServiceType["
                                        + vnRequest.getServiceType()
                                        + "] [AxisFault Exception] Error[" + ex.getMessage()+"]");
                        // logger.error(" ##>>msisdn["+vnResponse.getMsisdn()+"]Exception inside checkSubType "+((AxisFault)ex).getFaultString());
                        // logger.error("##>>msisdn["+vnResponse.getMsisdn()+"] Exception occured while relogin inside hlrRequest method");
                        vnResponse.setSubType("NA");
                        ex.printStackTrace();
                }

        }

			}
			if (AppConfig.config.getInt("sub.type.interface", 3) == 3) {
				vnResponse.setSubType("P");
			} else if (AppConfig.config.getInt("sub.type.interface", 4) == 4) {
				vnResponse.setSubType("O");
			} else if (AppConfig.config.getInt("sub.type.interface", 5) == 5) {
				vnResponse.setSubType("F");
			}
			//For testing and send N back from CRM client
			else if (AppConfig.config.getInt("sub.type.interface", 5) == 6) {
				vnResponse.setSubType("F");
			}
			vnResponse.setResult("success");
			vnResponse.setMsg(String.format(
					AppConfig.config.getString("sub_type_success", "Success SubType"),
					vnRequest.getMsisdn(), vnRequest.getServiceType()));
		} catch (Exception e) {
            errorLogger.error("ErrorCode [VCC-RE-00059] TID[" + vnRequest.getTid()
            + "] MSISDN[" + vnRequest.getMsisdn() + "] ServiceType["
            + vnRequest.getServiceType()
            + "] [Exception in getSubType method] Error[" + e.getMessage()+"]");
}

		vnRequest.setSubType(vnResponse.getSubType());
		vnResponse.setState("END");
		return gson.toJson(vnResponse);
	}

	public String doFinish(VccRequest vnRequest, VnInfo vnCode, VnResponse vnResponse) {
		vnResponse.setMsisdn(vnRequest.getMsisdn());
		vnResponse.setActionId("" + vnRequest.getActionId());
		vnResponse.setTid(vnRequest.getTid());
		logger.info("response: "+gson.toJson(vnResponse));
		return null;
	}
}
