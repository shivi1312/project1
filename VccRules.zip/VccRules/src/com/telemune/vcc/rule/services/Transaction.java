package com.telemune.vcc.rule.services;

import com.telemune.vcc.rule.model.VccMailboxLogModel;

public interface Transaction {
	public boolean saveTransactionLog(VccMailboxLogModel vccLog);
}
