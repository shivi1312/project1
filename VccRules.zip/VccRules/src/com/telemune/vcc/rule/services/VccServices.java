package com.telemune.vcc.rule.services;

import java.util.List;

import com.telemune.vcc.rule.domain.ChangeNumber;
import com.telemune.vcc.rule.domain.VccAdvancedDetail;
import com.telemune.vcc.rule.domain.VccAuthUser;
import com.telemune.vcc.rule.domain.VccChargingCode;
import com.telemune.vcc.rule.domain.VccClassType;
import com.telemune.vcc.rule.domain.VccGroup;
import com.telemune.vcc.rule.domain.VccMailboxLog;
import com.telemune.vcc.rule.domain.VccMailboxParams;
import com.telemune.vcc.rule.domain.VccPersonalizedGreeting;
import com.telemune.vcc.rule.domain.VccRatePlan;
import com.telemune.vcc.rule.domain.VccSeriesRange;
import com.telemune.vcc.rule.domain.VccServiceUnsub;
import com.telemune.vcc.rule.domain.VccSubscriptionMaster;
import com.telemune.vcc.rule.domain.VccVoiceMsg;
import com.telemune.vcc.rule.model.ScopeModel;
import com.telemune.vcc.rule.model.VccChargingCodeModel;
import com.telemune.vcc.rule.model.VccClassTypeModel;
import com.telemune.vcc.rule.model.VccError;
import com.telemune.vcc.rule.model.VccMailboxLogModel;
import com.telemune.vcc.rule.model.VccRatePlanModel;
import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
import com.telemune.vcc.rule.request.VccRequest;

public class VccServices implements Service {

	@Override
	public VccSubscriptionMasterModel getServiceDetailByServiceType(
			VccRequest vnRequest) {
		return new VccSubscriptionMaster()
				.getServiceDetailByServiceType(vnRequest);
	}

	@Override
	public List<VccRatePlanModel> getRatePlnByServiceType(VccRequest vnRequest) {
		return new VccRatePlan().getRatePlanByServiceTypeAndPlanName(vnRequest);
	}

	@Override
	public boolean isUserExistWithInRange(VccRequest vnRequest) {
		return new VccSeriesRange().isUserExistWithInRange(vnRequest);
	}

	@Override
	public VccClassTypeModel haveAnyClass(VccRequest vnRequest) {
		return new VccClassType().haveAnyClass(vnRequest);
	}

	@Override
	public boolean isUserIsOptedOut(VccRequest vnRequest) {
		return new VccServiceUnsub().isUserIsOptedOut(vnRequest);
	}

	@Override
	public VccChargingCodeModel getChargingCode(VccRequest vnRequest,
			VccRatePlanModel rateModel) {
		return new VccChargingCode().getChargingCode(vnRequest, rateModel);
	}

	@Override
	public int saveAuthUserDetail(VccRequest vnRequest,
			VccRatePlanModel rateModel, VccChargingCodeModel chargingCode,
			ScopeModel scope, VccError error, VccSubscriptionMasterModel vccSub) {
		return new VccAuthUser().saveAuthUserDetail(vnRequest, rateModel,
				chargingCode, scope, error, vccSub);
	}

	public int saveUserDetail(VccRequest vnRequest, VccRatePlanModel rateModel,
			VccChargingCodeModel chargingCode, VccSubscriptionMasterModel vccSub) {
		return new VccSubscriptionMaster().saveUserDetail(vnRequest, rateModel,
				chargingCode, vccSub);
	}

	@Override
	public boolean saveTransactionLog(VccMailboxLogModel vccLog) {
		return new VccMailboxLog().saveTransactionLog(vccLog);
	}

	@Override
	public List<String> getVoiceMailList(VccRequest vnRequest) {
		return new VccVoiceMsg().getVoiceMailList(vnRequest);
	}

	@Override
	public boolean deleteVoiceMsgByMsisdnAndServiceType(VccRequest vnRequest) {
		return new VccVoiceMsg()
				.deleteVoiceMsgByMsisdnAndServiceType(vnRequest);
	}

	@Override
	public boolean removeOptoutUser(VccRequest vnRequest) {
		return new VccServiceUnsub().removeOptoutUser(vnRequest);
	}

	@Override
	public int updateOrDeleteAuthDetail(VccRequest vnRequest) {
		return new VccAuthUser().updateOrDeleteAuthDetail(vnRequest);
	}

	@Override
	public int deleteUserDetailByServiceTypeAndMsisdn(VccRequest vnRequest) {
		return new VccSubscriptionMaster()
				.deleteUserDetailByServiceTypeAndMsisdn(vnRequest);
	}

	@Override
	public void getMailboxParams() {
		new VccMailboxParams().getMailboxParams();
	}

	@Override
	public boolean changeNumber(VccRequest vnRequest, VccError error) {
		return new ChangeNumber().changeNumber(vnRequest, error);
	}

	@Override
	public String getExistingRatePlanName(VccRequest vnRequest,
			VccSubscriptionMasterModel vccSub) {
		return new VccRatePlan().getExistingRatePlanName(vnRequest, vccSub);
	}

	@Override
	public int deleteFromPersonalizedGreetingByMsisdn(VccRequest vnRequest) {
		return new VccPersonalizedGreeting()
				.deleteFromPersonalizedGreetingByMsisdn(vnRequest);
	}

	@Override
	public int deleteFromAdvanceDetailByMsisdn(VccRequest vnRequest) {
		return new VccAdvancedDetail()
				.deleteFromAdvanceDetailByMsisdn(vnRequest);
	}

	@Override
	public int deleteFromVoiceMsgScheduleByMsisdn(VccRequest vnRequest) {
		return new VccVoiceMsg().deleteFromVoiceMsgScheduleByMsisdn(vnRequest);
	}

	@Override
	public int deleteFromGroupDetailByMsisdn(VccRequest vnRequest) {
		return new VccGroup().deleteFromGroupDetailByMsisdn(vnRequest);
	}

	@Override
	public int deleteFromGroupMasterByMsisdn(VccRequest vnRequest) {
		return new VccGroup().deleteFromGroupMasterByMsisdn(vnRequest);
	}

	@Override
	public List<String> getGreetingList(VccRequest vnRequest) {
		return new VccPersonalizedGreeting().getGreetingList(vnRequest);
	}

	@Override
	public List<String> getGroupList(VccRequest vnRequest) {
		return new VccGroup().getGroupList(vnRequest);
	}
	
	@Override
	public int updateProfile(VccRequest vnRequest,VccRatePlanModel rateModel,
			VccChargingCodeModel chargingCode) {
		return new VccSubscriptionMaster().updateProfile(vnRequest, rateModel, chargingCode);
	}
	
	@Override
	public int activeSubscriberNum() {
		return new VccSubscriptionMaster().activeSubscriberNum();
	}
	
	@Override
	public String getSubType(VccRequest vnRequest) {
		return new VccSubscriptionMaster().getSubType(vnRequest);
	}
	
	@Override
	public int countForMultiServiceSubscriber(VccRequest vnRequest) {
		return new VccSubscriptionMaster().countForMultiServiceSubscriber(vnRequest);
	}

}
