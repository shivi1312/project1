package com.telemune.vcc.rule.services;

import java.util.List;

import com.telemune.vcc.rule.model.ScopeModel;
import com.telemune.vcc.rule.model.VccChargingCodeModel;
import com.telemune.vcc.rule.model.VccClassTypeModel;
import com.telemune.vcc.rule.model.VccError;
import com.telemune.vcc.rule.model.VccMailboxLogModel;
import com.telemune.vcc.rule.model.VccRatePlanModel;
import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
import com.telemune.vcc.rule.request.VccRequest;

public interface Service {
	public VccSubscriptionMasterModel getServiceDetailByServiceType(
			VccRequest vnRequest);

	public List<VccRatePlanModel> getRatePlnByServiceType(VccRequest vnRequest);

	public boolean isUserExistWithInRange(VccRequest vnRequest);

	public VccClassTypeModel haveAnyClass(VccRequest vnRequest);

	public boolean isUserIsOptedOut(VccRequest vnRequest);

	public VccChargingCodeModel getChargingCode(VccRequest vnRequest,
			VccRatePlanModel rateModel);

	public int saveAuthUserDetail(VccRequest vnRequest,
			VccRatePlanModel rateModel, VccChargingCodeModel chargingCode,
			ScopeModel scope,VccError error,VccSubscriptionMasterModel vccSub);

	public int saveUserDetail(VccRequest vnRequest, VccRatePlanModel rateModel,
			VccChargingCodeModel chargingCode,VccSubscriptionMasterModel vccSub);

	public boolean saveTransactionLog(VccMailboxLogModel vccLog);

	public List<String> getVoiceMailList(VccRequest vnRequest);

	public boolean deleteVoiceMsgByMsisdnAndServiceType(VccRequest vnRequest);

	public boolean removeOptoutUser(VccRequest vnRequest);
	public int updateOrDeleteAuthDetail(VccRequest vnRequest);
	public int deleteUserDetailByServiceTypeAndMsisdn(VccRequest vnRequest);
	public void getMailboxParams();
	public boolean changeNumber(VccRequest vnRequest,VccError error);
	public String getExistingRatePlanName(VccRequest vnRequest,
			VccSubscriptionMasterModel vccSub);
	public int deleteFromPersonalizedGreetingByMsisdn(VccRequest vnRequest);
	public int deleteFromAdvanceDetailByMsisdn(VccRequest vnRequest);
	public int deleteFromVoiceMsgScheduleByMsisdn(VccRequest vnRequest);
	public int deleteFromGroupDetailByMsisdn(VccRequest vnRequest);
	public int deleteFromGroupMasterByMsisdn(VccRequest vnRequest);
	
	public List<String> getGreetingList(VccRequest vnRequest);
	public List<String> getGroupList(VccRequest vnRequest);
	
	public int updateProfile(VccRequest vnRequest,VccRatePlanModel rateModel,
			VccChargingCodeModel chargingCode);
	public int activeSubscriberNum();
	
	public String getSubType(VccRequest vnRequest);
	public int countForMultiServiceSubscriber(VccRequest vnRequest);
	
}
