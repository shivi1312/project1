package com.telemune.vcc.rule.services;

import com.telemune.vcc.rule.domain.VccMailboxLog;
import com.telemune.vcc.rule.model.VccMailboxLogModel;

public class UserTransaction implements Transaction {
	public boolean saveTransactionLog(VccMailboxLogModel vccLog){
		return new VccMailboxLog().saveTransactionLog(vccLog);
	}
}
