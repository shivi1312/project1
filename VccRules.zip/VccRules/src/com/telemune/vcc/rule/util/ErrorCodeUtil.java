package com.telemune.vcc.rule.util;

public class ErrorCodeUtil {
	
}
