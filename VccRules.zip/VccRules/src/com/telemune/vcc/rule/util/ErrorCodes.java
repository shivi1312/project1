package com.telemune.vcc.rule.util;

public interface ErrorCodes {
	
	int UNKNOWN_ERROR=-1;
	int LOW_BALANCE_ERROR=-2;
	int HLR_ACTIVATION_ERROR=-3;
	int NO_PENDING_REQUEST_EXIST=-20;//entry in db
	int SUBSCRIPTION_NOT_ALLOWED=-22;//(initailly -6)
	int REQUEST_TAKEN=-23;
	int REQ_ALREADY_EXIST=-37;//entry in db (initailly -5)
}
