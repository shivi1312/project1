package com.telemune.vcc.rule.util;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.common.Data;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.request.VccRequest;

public class CountryCodeUtil {
	private static final String defaultCountryCode = "971";
	private final static Logger logger = Logger
			.getLogger(CountryCodeUtil.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	public static void main(String [] args){
		String str = "008800544347";
		System.out.println("msisdn: "+str.substring(2,str.length()));
	}
	public void validateCountryCode(Data data, VccRequest vccRequest) {
		try {
			logger.info(String.format("[%s] [%s] [%s] [%s] country code [%s]",
					vccRequest.getMsisdn(), vccRequest.getTid(), vccRequest
							.getServiceType(), vccRequest.getActionId(),
					AppConfig.config.getString("country_code",
							defaultCountryCode)));
			if (vccRequest.getMsisdn().startsWith(
					AppConfig.config.getString("country_code",
							defaultCountryCode))) {
				vccRequest.setMsisdnWithoutCountryCode(vccRequest.getMsisdn()
						.substring(
								AppConfig.config.getString("country_code",
										defaultCountryCode).length(),
								vccRequest.getMsisdn().length()));
			} else if(vccRequest.getMsisdn().startsWith("00")){
				vccRequest.setMsisdnWithoutCountryCode(vccRequest.getMsisdn().substring(2, vccRequest.getMsisdn().length()));
				vccRequest.setMsisdn(AppConfig.config.getString("country_code",
						defaultCountryCode) + vccRequest.getMsisdn().substring(2, vccRequest.getMsisdn().length()));
				vccRequest.setChangedMsisdn(AppConfig.config.getString("country_code",
						defaultCountryCode) + vccRequest.getChangedMsisdn().substring(2, vccRequest.getMsisdn().length()));
			} else if(vccRequest.getMsisdn().startsWith("0")&& vccRequest.getMsisdn().length() > AppConfig.config.getInt("msisdn_length",9)){
				vccRequest.setMsisdnWithoutCountryCode(vccRequest.getMsisdn().substring(1, vccRequest.getMsisdn().length()));
				vccRequest.setMsisdn(AppConfig.config.getString("country_code",
						defaultCountryCode) + vccRequest.getMsisdn().substring(1, vccRequest.getMsisdn().length()));
				vccRequest.setChangedMsisdn(AppConfig.config.getString("country_code",
						defaultCountryCode) + vccRequest.getChangedMsisdn().substring(1, vccRequest.getMsisdn().length()));
			}else {
				vccRequest.setMsisdnWithoutCountryCode(vccRequest.getMsisdn());
				vccRequest.setMsisdn(AppConfig.config.getString("country_code",
						defaultCountryCode) + vccRequest.getMsisdn());
				vccRequest.setChangedMsisdn(AppConfig.config.getString("country_code",
						defaultCountryCode) + vccRequest.getChangedMsisdn());
			}
			/*
			* Added by Vivek Kumar at 26/07/2016 Handle fixed to make 9 digit
			* number:- Add 0 after country code
			*/
			int msisdnLengthWithCountryCode = AppConfig.config.getInt("msisdn_length",9)
					+ AppConfig.config.getString("country_code").length();
			logger.debug(String.format("[%s] length with country code [%s]", vccRequest.getMsisdn(), msisdnLengthWithCountryCode));
			if (vccRequest.getMsisdn().length() < msisdnLengthWithCountryCode) {
				logger.debug(String.format("Handle fixed line: [%s] length with country code [%s]", vccRequest.getMsisdn(),
						msisdnLengthWithCountryCode));
				vccRequest.setMsisdn(vccRequest.getMsisdn().substring(0, AppConfig.config.getString("country_code").length())
						+ vccRequest.getMsisdn().substring(AppConfig.config.getString("country_code").length(), vccRequest.getMsisdn().length()));
				logger.info(String.format("fixed line msisdn after handling: [%s]", vccRequest.getMsisdn()));
			}
		} 
		catch (NullPointerException npe) {
			errorLogger.error("ErrorCode [VCC-RE-90003] MSISDN["+vccRequest.getMsisdn()+"] [Null pointer Exception in validating country Code] Error[ "+npe.getMessage()+"]");
		}catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00039] MSISDN["+vccRequest.getMsisdn()+"] [Exception in validating country Code] Error["+e.getMessage()+"]");
			e.printStackTrace();
			vccRequest.setMsisdnWithoutCountryCode(vccRequest.getMsisdn());
		}
	}
}
