package com.telemune.vcc.rule.util;

import com.telemune.vcc.rule.model.ServiceType;

public class ServiceTypeUtil {
	public String getCombinedServiceType(String currentServiceType,
			String oldServiceType) {
		String[] current = null;
		String[] old = null;
		int inc = 0;
		String result = new String();
		try {
			current = currentServiceType.split("");
			old = oldServiceType.split("");
			for (String c : current) {
				if (c.equals(old[inc])) {
					result += c;
				} else if (c.equals("1")) {
					result += c;
				} else if (old[inc].equals("1")) {
					result += old[inc];
				}
				inc++;
			}
		} catch (Exception e) {
			return currentServiceType;
		}
		return result;
	}

	public String getRemainServiceType(String currentServiceType,
			String oldServiceType) {
		String[] current = null;
		String[] old = null;
		int inc = 0;
		String result = new String();
		try {
			current = currentServiceType.split("");
			old = oldServiceType.split("");
			for (String o : old) {
				if (!o.equals("")) {
					if (o.equals(current[inc])) {
						result += "0";
					} else if (o.equals("1")) {
						result += o;
					}
				}
				inc++;
			}
		} catch (Exception e) {
			return currentServiceType;
		}
		System.out.println("result " + result);
		return result;
	}

	public ServiceType extractServiceType(String currentServiceType,
			String oldServiceType) {
		ServiceType serviceType = new ServiceType();
		try {
			if (!currentServiceType.equals(oldServiceType)) {
				serviceType.setOperation("update");
				serviceType.setServiceType(this.getRemainServiceType(
						currentServiceType, oldServiceType));
			} else {
				serviceType.setOperation("delete");
				serviceType.setServiceType(currentServiceType);
			}
		} catch (Exception e) {
			serviceType.setOperation("delete");
			serviceType.setServiceType(currentServiceType);
		}
		return serviceType;
	}

	public static void main(String[] args) {
		new ServiceTypeUtil().extractServiceType("0100", "0110");
	}
}
