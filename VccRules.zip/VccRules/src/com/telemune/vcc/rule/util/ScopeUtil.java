package com.telemune.vcc.rule.util;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.domain.VccSeriesRange;
import com.telemune.vcc.rule.model.ScopeModel;
import com.telemune.vcc.rule.model.VccRatePlanModel;
import com.telemune.vcc.rule.model.VccSeries;
import com.telemune.vcc.rule.request.VccRequest;

@SuppressWarnings("unused")
public class ScopeUtil {
	final static Logger logger = Logger.getLogger(ScopeUtil.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	private Gson gson = new Gson();

	public VccRatePlanModel getTarrifId(List<VccRatePlanModel> rateModelList,
			ScopeModel scopeModel, VccRequest vnRequest) {
		VccRatePlanModel tarrifid = this.getMatchTarrifId(rateModelList,
				scopeModel, vnRequest);
		if (tarrifid.getPlanId() == 0) {
			errorLogger.error("ErrorCode [VCC-RE-00068] TID["+vnRequest.getTid()+"] MSISDN["+vnRequest.getMsisdn()+"] [Unable to Find Tarrif Id]");
			logger.info(String.format(
					"[%s] [%s] [%s] tarrifid is not found for [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getActionId(), gson.toJson(scopeModel)));
		}
		return tarrifid;
	}

	private VccRatePlanModel getMatchTarrifId(
			List<VccRatePlanModel> rateModelList, ScopeModel scopeModel,
			VccRequest vnRequest) {
		Scope scope = null;
		String msisdn;
		if (vnRequest.getAction() == 2 || vnRequest.getAction() == 3) {
			msisdn = vnRequest.getChangedMsisdn();
		} else {
			msisdn = vnRequest.getMsisdn();
		}
		try {
			for (VccRatePlanModel vccRate : rateModelList) {
				scope = gson.fromJson(vccRate.getScope(), Scope.class);
				logger.info(String
						.format("[%s] [%s] [%s] [%s] before match: user [%s] system [%s]",
								vnRequest.getMsisdn(), vnRequest.getTid(),
								vnRequest.getServiceType(),
								vnRequest.getActionId(), gson.toJson(scope),
								gson.toJson(scopeModel)));
				if (scope.getST().indexOf(scopeModel.getST()) != -1 && scope.getSC().indexOf(scopeModel.getSC()) != -1) {
					
					logger.info("Operator Range Ids: ["+scope.getOR()+"]");
					//added by kuldeep on 11-jan-2021
					if(scope.getOR().indexOf(scopeModel.getOR()) != -1) {
						logger.info(String.format("[%s] [%s] [%s] [%s] tarrifid [%s] match: user [%s] system [%s]",
								vnRequest.getMsisdn(), vnRequest.getTid(),vnRequest.getServiceType(),vnRequest.getActionId(),vccRate.getSubCode(),gson.toJson(scope), gson.toJson(scopeModel)));
						//if scope.getOR() contains 0 then return this rate plan
						return vccRate;
					} else {
						try {
							boolean wlFlag = false;
							//get OR ids and check whitelisting
							String[] groupIds = scope.getOR().split(",");
							for (int i = 0; i < groupIds.length; i++) {
								if(this.isExistWithinGroup(msisdn, Integer.parseInt(groupIds[i].trim()))) {
									wlFlag = true;
									logger.info("["+msisdn+"] is in Operator Range for group_id ["+groupIds[i]+"]");
								} else {
									wlFlag = false;
									logger.info("["+msisdn+"] is not in Operator Range for group_id ["+groupIds[i]+"]");
									break;
								}
							}
							logger.debug("## whilelisted flag ["+wlFlag+"]");
							if(wlFlag) {
								logger.info(String.format("[%s] [%s] [%s] [%s] tarrifid [%s] match: user [%s] system [%s]",
										vnRequest.getMsisdn(), vnRequest.getTid(),vnRequest.getServiceType(),vnRequest.getActionId(),vccRate.getSubCode(),gson.toJson(scope), gson.toJson(scopeModel)));
								return vccRate;
							}
							
						} catch (Exception e) {
							errorLogger.error("ErrorCode [VCC-RE-00008] MSISDN ["+ msisdn+"]  [Exception in is getMatchTarrifId] Error["+e.getMessage()+"]");
						}
					}
				}
			}
		}catch (NullPointerException npe) {
			errorLogger.error("ErrorCode [VCC-RE-90003] TID["+vnRequest.getTid()+"] MSISDN["+vnRequest.getMsisdn()+"] [Null Pointer Exception while getting TarrifId] Error["+npe.getMessage()+"]");
		}
		
		catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00013] TID["+vnRequest.getTid()+"] MSISDN["+vnRequest.getMsisdn()+"] [Exception while getting TarrifId] Error["+e.getMessage()+"]");
			e.printStackTrace();
			logger.info(String.format(
					"[%s] [%s] [%s] Exception: while getting tarrifid [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getActionId(), e));
		}
		return new VccRatePlanModel();
	}
	
	private boolean isExistWithinGroup(String msisdn1, int groupId) {
		boolean isExist = false;
		int startValue = 0;
		int endValue = 0;
		BigInteger msisdn;
		
		logger.debug("msisdn [" + msisdn1 + "] check for groupId: " + groupId);
		try
			{
			msisdn = new BigInteger(msisdn1);
		for (VccSeries series : VccSeriesRange.vccSeries) {
				startValue = series.getStartRange().compareTo(msisdn);
				endValue = series.getEndRange().compareTo(msisdn);
				if (((startValue == -1 || startValue == 0) && (endValue == 1 || endValue == 0))
						&& series.getGroupId() == groupId) {
					logger.debug("msisdn [" + msisdn + "] exist in group ["+series.getGroupName()+"] groupId: " + groupId);
					if(series.getGroupName().equalsIgnoreCase("blacklist")) {
						return false;
					}
					return true;
				}
			
		}
			}
		 catch (Exception e) {
             errorLogger.error("ErrorCode [VCC-RE-00008]"
                             + " MSISDN ["
                             + msisdn1+"] Group Id ["+groupId
                             + "]  [Exception in is isExistWithinGroup] Error["+e.getMessage()+"]");
             
             isExist = false;
     }

		return isExist;
	}

}
