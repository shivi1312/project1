package com.telemune.vcc.rule.util;

public interface VccTagsUtil {
	
	//Common tags for Charging and CSE
	int MSISDN=1;
	int RBTCODE=4;//ITEM_CODE in case of CSE
	int INTERFACE=6;
	int SUBTYPE=8;
	int PACKID=14;//PACKAGE_TAG in case of CSE
	int LANGUAGE=21;
	//int RESPONSE_CODE=7;
	int PROFILE=113;//REQUEST_DATA in case of CSE
	
	int REQUEST_DATA_JSON=100;//FOR JSON DATA
	
	//Charging specific tags
	int ACTION=2;
	int TARIFF=3; 
	int FMSISDN=5;
	int REQID=9;
	int AMOUNT=11;
	int CHG_REQTYPE=12;
	int CORP_ID=13;
	int RESPONSE_STRING=35;	

	//CSE Specific tags
	int TRANSACTION_ID=101;
	int SE_REQTYPE=102;
	int REPORT=103;
	int SERVICE=104;
	int PMSISDN=105;
	int USERNAME=106;
    int PASSWORD=107;
    int IS_FREE_PACK=108;
    int PSUB_TYPE=109;
    int ITEM_NAME=110;
    int ITEM_TYPE=111;
    int PACK_VARS=112;
    //int RESPONSE_TYPE=201;
	
	//Tags getting in requests from various interface
	int PLANIND=51;
	int UPDATEBY=52;
	int REASON=53;
	int DAYS=54;
	int STARTTIME=55;
	int ENDTIME=56;
	int CHECKRBT=57;
	int GROUPNAME=58;
	int ALBUMNAME=59;
	int ADVOP=60;
	int CONTROLNAME=61;
	int DATE=62;
	int RBTPATH=63;
	int CATID=64;
	int CALLID=65;
	int ALBUMID=66;
	int OCC=67;
	int REFID=68;
	int HLRREQUEST=69;
	int PLANNAME=70;
	
	
	//internal application tags
	int PROC_STATUS=-1;
	

	
	// for internal param storage 1011-1100
	/*public static int PACK_ID=1011;
	public static int ADV_CHG_CODE=1012;
	public static int CHG_CODE=1013;
	public static int CAT_ID=1014;
	public static int CP_ID=1015;
	public static int OPERATION=1016;
	public static int PACK_SETTING=1017;
	public static int PACK_SUB=1018;
	*/

	
	
	
	
	int OP_RBT_PURCHASE=1;
	int OP_RBT_GIFT=2;
	int OP_RBT_RECORD=3;

		
	
	/*
	 * Added By Richard for MCA Charging on 7th June 2019
	 */
	
	public static int MSISDN_TAG=2;
	public static int TARIFFID_TAG=4;
	public static int ACTION_TAG=3;
	public static int SUB_TYPE=7;
	public static int INTERFACE_TAG=8;
	public static int SERVICETYPE_TAG=9;
	public static int REQTYPE_TAG=12;
	
	public int RESPONSE_CODE=6;
	public int RESPONSE_TYPE=201;
	String RESPONSE_ACK_FINAL="FINAL";
	
	/*
	 * 
	 */
	
	
	
	String SUB="Subscribe";
	String RBT="RBT";
	String RBT_RENEW="RBT_RENEW";
	String SUB_RENEW="SUB_RENEW";
	String REC_RENEW="REC_RENEW";
	String RECORD_RBT="REC_FB_CHG_CODE";
	String GIFT_RBT="GIFTRBT";
	String PACKSUB="SUB_CHARGE_CODE";
	String PACK_FREE_RBT_STRING="PackFreeRbt";
	String UNKNOWN="UNKNOWN";
	String SUCCESS="SUCCESS";
	String STATUS_SUCCESS="STATUS_SUCCESS";
	String RP_SUCCESS="RP_SUCCESS";
	String ACCEPT_SUCCESS="ACCEPT_SUCCESS";
	String ERROR="ERROR";
	String SE_SUCCESS="SE_SUCCESS";
	String SE_SUCCESS_UPDATE="SE_SUCCESS_UPDATE";
	String SE_CALLBACK="SE_CALLBACK";
	String HLR_SUCCESS="HLR_SUCCESS";
	String HLR_CALLBACK="HLR_CALLBACK";
	String SUBSCRIBE="SUBSCRIBE";
	String PACK_SUCCESS="PACK_SUCCESS";
	String RENEW_SUB_SUCCESS="RENEW_SUB_SUCCESS";
	String RENEW_RBT_SUCCESS="RENEW_RBT_SUCCESS";
	String INSERT="INSERT";
	String DELETE="DELETE";
	String CHECK="CHECK";
	String exception_error="#ERROR>>";
	
	String SET_SUCCESS="SET_SUCCESS";
	String UNSET_SUCCESS="UNSET_SUCCESS";
	
	String SUBSCRIPTION_ALLOWED="SUBSCRIPTION_ALLOWED";
	String SUBSCRIPTION_NOT_ALLOWED="SUBSCRIPTION_NOT_ALLOWED";
	
	String SUBSCRIBER_INACTIVE="SUBSCRIBER_INACTIVE";
	String SUBSCRIBER_ACTIVE="SUBSCRIBER_ACTIVE";
	String NON_SUBSCRIBER="NON_SUBSCRIBER";
	String A_PARTY_SUCCESS="A_PARTY_SUCCESS";
	String ADDRBT="ADDRBT";
	
	String SE_SUB="SUB";
	String SE_UPDATE="UPDATE";
	String SE_UNSUB="UNSUB";
	String SE_GIFT="GIFT";
	String SE_RECORD="RECORD";
	String SE_RBT="RBT";
	String SE_RECORD_SET="RECORD SET";
	String SE_PURCHASE="PURCHASE";
	String SE_SET="SET";//Purchase and set rbt
	
	//For reponse from CSE in case of async. and sync. both
	String RESPONSE_ACK_OK="ACK_OK";
	String RESPONSE_ACK_ERROR="ACK_ERROR";
	//String RESPONSE_ACK_FINAL="FINAL";
	
	
	int RBT_NOT_IN_WALLET               =-83;
	int RBT_EXISTS_IN_WALLET            =-72;

	// Error Codes

	//Added for RBT_RENEW
	int CRE_PLAYLIST                     =-38;//=-28;
	int CRE_PLAYLIST_DIFF_CHG            =-39;//=-29;
	
	int UNKNOWN_ERROR                     =-1;
	int CHARGING_FAILED                   =-2;
	int NO_DB_CONNECTION                  =-3;
	int OCI_STMT_ERR                      =-4;
	int PROCEDURE_EXECUTION_ERR           =-5;
	int PREPAID_STATUS_ERR                =-6;
	int CRE_RBT_EXIST_IN_ALBUM            =-7;
	int CRE_GIFT_FRIEND_NOT_SUB           =-8;
	int CRE_GIFT_ALREADY_HAS_RBT          =-9;
	int CRE_CAT_ID_NOT_FOUND		        =-10;
	int CRE_CTRL_ID_NOT_FOUND		        =-11;
	int CRE_FRD_NOT_EXIST				    =-12;
	int CRE_GRP_NOT_EXIST			        =-13;
	int CRE_BAD_RBT			            =-14;
	int CRE_RBT_NOT_IN_WLT			    =-15;
	int CRE_ALL_TIME_DEFAULT_CANNOT_DELETE =-16;
	int CRE_WLT_NOT_EXIST					 =-17;
	int CRE_CDR_NOT_GENERATED		   		=-18;
	int CRE_WLT_EXIST						=-19;
	int CRE_SUB_ALREADY_SUBSCRIBED		=-20;
	int CRE_MAX_SUB_LIMIT					=-21;
	int CRE_SUB_NOT_ALLOWED				=-22;
	int REQUEST_TAKEN_INFORM_LATER	    =-23;
	int CRE_ADVERTISEMENT_RBT       		=-24;
	int SUB_STATUS_NOT_EXIST        		=-25;
	int CRE_FREE_RBT                    	=-26;
	int CRE_DIFF_CHG_ENABLED    		    =-27;
	int SUB_ALREADY_SUSPENDED             =-28;
	int SUB_ALREADY_INACTIVE              =-29;
	int USER_NOT_SUBSCRIBED               =-30;
	int CRE_RBT_EXIST_IN_ALBUM_INACTVE    =-31;
	int CRE_PACK_ALREADY_SUB		        =-37;
	int CRBT_PACK_SUB_NOT_ALLOWED	        =-32;
	int CRBT_DIFF_PLAN_ALREADY_SUB	    =-33;
	int CRBT_PLAN_NOT_FOUND               =-34;
	int NO_RBT_TO_ACCEPT                  =-35;
	int SUBSCRIBER_NOT_ACTIVE	            =-36;
	int CRE_SUB_ALREADY_SUBSCRIBED_INACTIVE=-40;
	int CRE_RBT_EXIST_PROFILE_INACTIVE     =-41;
	
// for packs
	
	int RBT_PURCHASE =1;
	int RBT_GIFT =2;
	int RBT_RECORDING =3;
	int DEFAULT_SETTING =1;
	int SEQ_SETTING =2;
	int RANDOM_SETTING= 3;
	int TOP_SETTING =4;

	// CSE TAGS
	//int CSE_RESPONSE_CODE=7;
	
	
	
// Subscriber Profile Status 1000 to 1010	
	int ACTIVE=1000;
	int INACTIVE=1001;
	int NOT_SUBSCRIBED=1002;
	
// for PREPAID/POSTPAID 1101-1105
	int PREPAID=1101;
	int POSTPAID=1102;
	String PREPAID_VAR="P";
	String POSTPAID_VAR="O";
		
// HLR AND CHARGING ACTION TAG
//	int HLR_REQUEST_TAG=2;
//	int HLR_RESPONSE_TAG=3;
	int HLR_FLAG_UP=3;
	int HLR_FLAG_DOWN=4;
	int HLR_SUBTYPE_CHECK=6;
	
			
	}
