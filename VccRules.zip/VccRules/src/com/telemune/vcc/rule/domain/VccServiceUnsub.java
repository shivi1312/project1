package com.telemune.vcc.rule.domain;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.util.AppContext;

public class VccServiceUnsub {

	final static Logger logger = Logger.getLogger(VccServiceUnsub.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	private DataSource dataSource;

	public VccServiceUnsub() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public boolean isUserIsOptedOut(VccRequest vnRequest) {
		boolean isOptout = false;
		try {
			logger.debug(String.format(
					"[%s] [%s] [%s] [%s] valid user interface: [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId(),
					AppConfig.config.getList("vcc_user_interface")));
			if (!AppConfig.config.getList("vcc_user_interface").contains(
					vnRequest.getInterFace())) {
				String query = "select count(*) from vcc_service_unsub "
						+ "where msisdn = ? and service_type = ?";
				logger.debug(String.format(
						"[%s] [%s] [%s] [%s] before query: [%s]",
						vnRequest.getMsisdn(), vnRequest.getTid(),
						vnRequest.getServiceType(), vnRequest.getActionId(),
						query));
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				isOptout = jdbcTemplate.queryForObject(query, new Object[] {
						vnRequest.getMsisdn(), vnRequest.getServiceType() },
						Boolean.class);
				logger.debug(String.format(
						"[%s] [%s] [%s] [%s] after query: [%s]",
						vnRequest.getMsisdn(), vnRequest.getTid(),
						vnRequest.getServiceType(), vnRequest.getActionId(),
						query));
				return isOptout;
			} else {
				return isOptout;
			}
		} catch (Exception e) {
            errorLogger.error("ErrorCode [VCC-RE-00031] TID["
                    + vnRequest.getTid()
                    + "] MSISDN["
                    + vnRequest.getMsisdn()
                    + "] [Exception while checking for OptOut] Error[" + e.getMessage()+"]");
    return false;
}

	}

	public boolean removeOptoutUser(VccRequest vnRequest) {
		try {
			String query = "delete from VCC_SERVICE_UNSUB where "
					+ "msisdn = ? and service_type = ?";
			logger.debug(String.format("[%s] [%s] [%s] [%s] before query: [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int result = jdbcTemplate.update(
					query,
					new Object[] { vnRequest.getMsisdn(),
							vnRequest.getServiceType() });
			logger.debug(String.format("[%s] [%s] [%s] [%s] after query: [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId(), query));
			if (result > 0)
				return true;
			else
				return false;
		}catch (Exception e) {
            errorLogger.error("ErrorCode [VCC-RE-00030] TID["
                    + vnRequest.getTid()
                    + "] MSISDN["
                    + vnRequest.getMsisdn()
                    + "] ServiceType["+vnRequest.getServiceType()+"] [Exception while deleting from VCC_SERVICE_UNSUB for OptOut] Error[" + e.getMessage()+"]");
    logger.info(String.format("[%s] [%s] [%s] [%s] Exception: ",
                    vnRequest.getMsisdn(), vnRequest.getTid(),
                    vnRequest.getServiceType(), vnRequest.getActionId(), e));
    e.printStackTrace();
    return false;
}

	}

}
