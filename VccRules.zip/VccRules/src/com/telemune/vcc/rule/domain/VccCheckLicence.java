package com.telemune.vcc.rule.domain;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.vcc.util.AppContext;

public class VccCheckLicence {

	final static Logger logger = Logger.getLogger(VccCheckLicence.class);
	private DataSource dataSource;
	private static int activeLimit=1;
	public VccCheckLicence() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}
	
	public static int getLiscenseKey()
    {
		String key="";
		
		try
		{
			logger.debug("Inside getLicenceKey()");
			String query="select LICENCE_KEY from APP_TEMP_KEY where KEY_ID = 1";
			DataSource dataSource = (DataSource) AppContext.context
					.getBean("dataSource");
			JdbcTemplate jdbcTemplates=new JdbcTemplate(dataSource);
			key=(String)jdbcTemplates.queryForObject(query,String.class);
			logger.info("key is ["+key+"]");
			/*return key;
		}
		catch(Exception e)
		{
			logger.error("Exception inside VccCheckLiscence()"+e.getMessage());
			e.printStackTrace();
			return key;
		}
    }
	
	
	
	public int getLiscence(String key)
    {
            logger.info(" Inside getLiscence Key is: "+key);
            try
            {*/
                    String temp = key.substring(0, 6);

                    char tmp[] = temp.toCharArray();

                    int n_param = Integer.parseInt(decode(tmp.length, tmp));
                    if (n_param <=0 || n_param > key.length()/8)
                    {
                            return -1;
                    }
                    int loc = 6;

                    for(int i =0; i< n_param; i++)
                    {
                            temp = key.substring(loc);
                            if ((temp == null) || (temp.length() <6))
                            {
                                    return -1;
                            }
                            temp = key.substring(loc,loc+6);
                            tmp = temp.toCharArray();
                            int len = Integer.parseInt(decode(tmp.length, tmp));

                            loc = loc+6;
                            if (len <=0 || (2*len) > key.substring(loc).length())
                            {
                                    return -1;
                            }
                            temp = key.substring(loc, loc+2*len);
                            tmp = temp.toCharArray();
                            String data = decode(tmp.length, tmp);
                            loc = loc+2*len;
                            logger.info("Decoded Liscence is: "+data);
                            if (i==1)
                            {
                                    logger.info(" Inside getLiscence Liscense Number is : "+data);
                                    activeLimit=Integer.parseInt(data);
                                    //  return(Integer.parseInt(data));
                            }
                    }

            }
            catch(Exception e)
            {
                    logger.error("Exception in Get Liscense ",e);
                    activeLimit=-2;

            }
            return activeLimit;
    }
            private static String decode(int len, char data[])
            {
                    logger.info("Inside Decode Function");
                    char l_data[] = new char[(len/2) +1];
                    for (int i=0; i<len; i++)
                    {
                            l_data[i/2] = (char) (data[i] - 0x41);
                            l_data[i/2] += (char) (data[++i] - 0x41)<<4;
                    }
                    String s = new String(l_data);
                    return s.trim();
            } //decode

            
            
            
            
}
