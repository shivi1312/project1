package com.telemune.vcc.rule.domain;

import java.sql.Connection;
import java.util.Timer;
import java.util.TimerTask;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.util.AppContext;

import commonutil.CheckForLicense;


/**
 * This class is used for validate the License which limit the total
 * number of subscribers for this site.
 * 
 * @author Sanchit Atri
 *
 */
public class VccLicense {
	final static Logger logger = Logger.getLogger(VccLicense.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	public static int li_maxNumSubs=-1;
	public static final String Plus="plus";
	public static final String Minus="minus";
	static int multiTableEnable=AppConfig.config.getInt("multi_table_sub_check"); // added by sanchit
	public static int currSubCount=-1;
	public static int msisdnCount=-1;
	static int MINUTES = AppConfig.config.getInt("reload_totalSubCount_time",10); // The delay in minutes
	static {
		if(AppConfig.config.getInt("total_sub_license",0)==1)
		{
			loadLicenseCodeCache();
			//totalUserCount();
			reloadCount();
		}
	}
	
	
	public static void loadLicenseCodeCache(){

		logger.info("Inside loadLicenseCodeCache");
		
		CheckForLicense l_licChk=null;
		String l_key="";
		try{
			DataSource dataSource = (DataSource) AppContext.context
					.getBean("dataSource");
			Connection conn = dataSource.getConnection();
		l_licChk = new CheckForLicense();
		l_key=l_licChk.getLicenseKey(conn);
		li_maxNumSubs=l_licChk.getLicense(l_key);
		if (li_maxNumSubs<0)
		{
			// critical error
			logger.fatal("Critical Error");
		}
		
		logger.info("getting max subs as>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<< ["+li_maxNumSubs+"]");
		}catch (Exception e) {
			logger.fatal("#ERROR>>  in setGlobalVariablesDB ",e);
		}finally{
			l_licChk =null;
		}
		logger.info("loadLicenseCodeCache ended");
		
		

	}
	
	
	public static void totalUserCount()
	{
		logger.info("Inside totalUserCount");
		DataSource dataSource;
		try {
			//logger.info("getting service type from DB");
			dataSource = (DataSource) AppContext.context.getBean("dataSource");
			
			// added by sanchit atri on 28-sep-2020
			String sql="";
			if(multiTableEnable==1)
			{
				sql="SELECT sum(TABLE_ROWS) as count FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME rlike 'vcc_auth_user_[0-9]{1}$'";
				logger.info("Query->>>>>>>>>>>>>>>>>>>>>>>>>>>>"+sql);
			}
			else
			{
				sql="select count(*) from vcc_auth_user";
				logger.info("Query->>"+sql);
			}
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

			currSubCount=jdbcTemplate.queryForObject(sql, Integer.class);
			
			logger.info("Total count->>>>>>>>>>>>>>>>>>>>>>>>>>>>"+currSubCount);
			
		} catch (Exception e) {
			logger.error("error in db operation for count total subscriber  [" + e + "]");
			
		
			}
	}
	
	public static synchronized void updateCurrSubCount(long msisdn, String type)
	{
		logger.info("Inside updateCurrSubCount..");
		DataSource dataSource;
		// updated on 15/07/2021
		long lastDigit=msisdn%10;
		String table="vcc_subscription_master_"+lastDigit;
		
		try {
			//logger.info("getting service type from DB");
			dataSource = (DataSource) AppContext.context.getBean("dataSource");
			
			
			// added by sanchit atri on 29-sep-2020
			String sql="";
			if(multiTableEnable==1)
			{
				sql="select count(*) from "+table+" where msisdn=?";
				logger.info("Query->>>>>>>>>>>>>>>>>>>>>>>>>>>>"+sql+"          msisdn========"+msisdn);
			}
			else
			{
				sql="select count(*) from vcc_vcc_subscription_master where msisdn=?";
				logger.info("Query->>"+sql+"          msisdn========"+msisdn);
			}
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

			msisdnCount=jdbcTemplate.queryForObject(sql,new Object[] { msisdn }, Integer.class);
			
		} catch (Exception e) {
			logger.error("error in db operation for currSubCountIncrement   [" + e + "]");
			}
		
		if(msisdnCount==1 && type.equalsIgnoreCase(Plus))
		{
			currSubCount++;
			logger.info("currSubCount is increment by one>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<< currSubCount=="+currSubCount);
		}
		else if(msisdnCount==0 && type.equalsIgnoreCase(Minus))
		{
			currSubCount--;
			logger.info("currSubCount is decrement by one>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<< currSubCount=="+currSubCount);
		}
		else
		{
			logger.info("currSubCount is neither increment nor decrement because msisdnCount=>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<"+msisdnCount);
		}
		
	}
	
	public static void reloadCount()
	{
		logger.info("<<<<<<<<<<<Inside reloadCount to reload the currSubCount>>>>>>>>>>>");
	Timer timer = new Timer();
	 timer.schedule(new TimerTask() {
	    @Override
	    public void run() { 
	        
	    	totalUserCount(); 
	    }
	 }, 0, 1000 * 60 * MINUTES);
	}
	
}
