package com.telemune.vcc.rule.domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.google.gson.Gson;
import com.telemune.vcc.rule.common.VccCache;
import com.telemune.vcc.rule.common.CacheLoader;
import com.telemune.vcc.rule.model.VccMailboxModel;
import com.telemune.vcc.util.AppContext;

public class VccMailboxParams {
	final static Logger logger = Logger.getLogger(VccMailboxParams.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	private static Gson gson = new Gson();
	private DataSource dataSource;
	final static Map<String, VccMailboxModel> map = new HashMap<String, VccMailboxModel>();

	public VccMailboxParams() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public void getMailboxParams() {
		try {
			String query = "SELECT MAILBOX_ID,MAILBOX_TYPE,MAX_MESSAGES,MSG_LIFETIME,MSG_LIFETIME_AFTER_RET,MSG_LIFETIME_AFTER_SAVE,MAX_RECORDING_TIME FROM VCC_MAILBOX_PARAMS";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			jdbcTemplate.query(
					query,
					new RowMapper<VccMailboxModel>() {
						
						@Override
						public VccMailboxModel mapRow(ResultSet rs, int rownumber)
								throws SQLException {
							VccMailboxModel vcc = new VccMailboxModel();
							vcc.setMailboxId(rs.getInt("MAILBOX_ID"));
							vcc.setMailboxType(rs.getString("MAILBOX_TYPE"));
							vcc.setMaxMessage(rs.getInt("MAX_MESSAGES"));
							vcc.setMsgLifeTime(rs.getInt("MSG_LIFETIME"));
							vcc.setMsgLifeTimeAfterRet(rs
									.getInt("MSG_LIFETIME_AFTER_RET"));
							vcc.setMsgLifeTimeAfterSave(rs
									.getInt("MSG_LIFETIME_AFTER_SAVE"));
							vcc.setMaxRecordingTime(rs.getInt("MAX_RECORDING_TIME"));
							map.put(rs.getString("MAILBOX_ID"), vcc);
							return vcc;
						}
					});
			VccCache.put(CacheLoader._mbp_prefix, gson.toJson(map), 20);
			logger.info("cache: "+ VccCache.get(CacheLoader._mbp_prefix));
		} catch(Exception dae){
            errorLogger.error("ErrorCode [VCC-RE-00065] [Exception while loading mailbox params] Error[" + dae.getMessage()+"]");
            dae.printStackTrace();
    }

	}

	public static void main(String[] args) {
		new VccMailboxParams().getMailboxParams();
	}
}
