package com.telemune.vcc.rule.domain;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.common.CacheLoader;
import com.telemune.vcc.rule.model.ScopeModel;
import com.telemune.vcc.rule.model.ServiceType;
import com.telemune.vcc.rule.model.VccAuthUserModel;
import com.telemune.vcc.rule.model.VccChargingCodeModel;
import com.telemune.vcc.rule.model.VccError;
import com.telemune.vcc.rule.model.VccRatePlanModel;
import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.rule.util.ServiceTypeUtil;
import com.telemune.vcc.util.AppContext;

public class VccAuthUser {

	static Logger logger = Logger.getLogger(VccAuthUser.class);
	static Logger errorLogger = Logger.getLogger("errorLogger");
	int multiTableEnable=AppConfig.config.getInt("multi_table_sub_check"); // added by sanchit

	private DataSource dataSource;

	public VccAuthUser() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	/*
	 * public static void main(String [] args){ VccRequest vnRequest = new
	 * VccRequest(); vnRequest.setMsisdn("918800000010"); VccAuthUserModel
	 * vccModel = new VccAuthUser().getVccAuthUser(vnRequest, null, null);
	 * System.out.println("data: "+vccModel.getServiceType()); }
	 */
	public VccAuthUserModel getVccAuthUser(VccRequest vnRequest, VccRatePlanModel rateModel,
			VccChargingCodeModel chargingCode) {
		VccAuthUserModel authUserModel = null;
		try {
			
			
			// added by sanchit atri on 17-sep-2020
			String query="";
			if(multiTableEnable==1)
			{
				String lastDigit=vnRequest.getMsisdn().substring(vnRequest.getMsisdn().length()-1);
				String tableName="VCC_AUTH_USER_"+lastDigit;
				query = "SELECT SERVICE_TYPE FROM "+tableName+" WHERE MSISDN = ?";
				logger.debug(String.format(">>>>>>>>>>>>>>>>>@@@@@>>>>>>>>>>>>msisdn [%s] service type [%s] before query [%s]", vnRequest.getMsisdn(),
						vnRequest.getServiceType(), query));
			}
			else
			{
				query = "SELECT SERVICE_TYPE FROM VCC_AUTH_USER WHERE MSISDN = ?";
				logger.debug(String.format("msisdn [%s] service type [%s] before query [%s]", vnRequest.getMsisdn(),
						vnRequest.getServiceType(), query));
			}
			
			/*
			 * String query = "SELECT SERVICE_TYPE FROM VCC_AUTH_USER WHERE MSISDN = ?";
			 */		
			/*
			 * logger.debug(String.format("msisdn [%s] service type [%s] before query [%s]",
			 * vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			 */
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			authUserModel = jdbcTemplate.query(query, new Object[] { vnRequest.getMsisdn() },
					new ResultSetExtractor<VccAuthUserModel>() {
						@Override
						public VccAuthUserModel extractData(ResultSet rs) throws SQLException, DataAccessException {
							if (rs.next()) {
								VccAuthUserModel vcc = new VccAuthUserModel();
								vcc.setServiceType(rs.getString("SERVICE_TYPE"));
								return vcc;
							}
							return null;
						}
					});
			logger.debug(String.format("msisdn [%s] service type [%s] after query [%s]", vnRequest.getMsisdn(),
					vnRequest.getServiceType(), query));
			return authUserModel;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00061] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] [Exception while checking user existance in VCC_AUTH_USER] Error[" + e.getMessage() + "]");
			logger.info(String.format("[%s] [%s] [%s] Exception: while check user existence [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(), e));
			return null;
		}

	}

	public int updateOrDeleteAuthDetail(VccRequest vnRequest) {
		int result = 0;
		try {
			VccAuthUserModel authModel = this.getVccAuthUser(vnRequest, null, null);
			ServiceType servType = null;
			if (authModel != null) {
				servType = new ServiceTypeUtil().extractServiceType(vnRequest.getServiceType(),
						authModel.getServiceType());
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				String query = "";
				// added by sanchit atri on 17-sep-2020
				String lastDigit=vnRequest.getMsisdn().substring(vnRequest.getMsisdn().length()-1);
				String tableName="VCC_AUTH_USER_"+lastDigit;
				
				if (servType.getOperation().equals("update")) {
					if (vnRequest.getServiceType().equals("0010")) {
						if(multiTableEnable==1)
						{
							query = "UPDATE "+tableName+" SET SERVICE_TYPE = ?, ISNEW = 1, STATUS='A' WHERE MSISDN = ?";
						}
						else
						{
							query = "UPDATE VCC_AUTH_USER SET SERVICE_TYPE = ?, ISNEW = 1, STATUS='A' WHERE MSISDN = ?";
						}
						/*
						 * query =
						 * "UPDATE VCC_AUTH_USER SET SERVICE_TYPE = ?, ISNEW = 1, STATUS='A' WHERE MSISDN = ?"
						 * ;
						 */
					} else {
						if(multiTableEnable==1)
						{
							query = "UPDATE "+tableName+" SET SERVICE_TYPE = ?, STATUS='A' WHERE MSISDN = ?";
						}
						else
						{
							query = "UPDATE VCC_AUTH_USER SET SERVICE_TYPE = ?, STATUS='A' WHERE MSISDN = ?";
						}
						/*
						 * query =
						 * "UPDATE VCC_AUTH_USER SET SERVICE_TYPE = ?, STATUS='A' WHERE MSISDN = ?";
						 */
					}
				} else if (servType.getOperation().equals("delete")) {
					if(multiTableEnable==1)
					{
						query = "DELETE FROM "+tableName+" WHERE SERVICE_TYPE = ? AND MSISDN = ?";
					}
					else
					{
						query = "DELETE FROM VCC_AUTH_USER WHERE SERVICE_TYPE = ? AND MSISDN = ?";
					}
					/* query = "DELETE FROM VCC_AUTH_USER WHERE SERVICE_TYPE = ? AND MSISDN = ?"; */
				}
				logger.debug(String.format("msisdn [%s] service type [%s] before query [%s]", vnRequest.getMsisdn(),
						vnRequest.getServiceType(), query));
				result = jdbcTemplate.update(query, new Object[] { servType.getServiceType(), vnRequest.getMsisdn() });
				logger.info(String.format("msisdn [%s] service type [%s] after query [%s]", vnRequest.getMsisdn(),
						vnRequest.getServiceType(), query));
			}
			return result;
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode [VCC-RE-90003] [Null Pointer Exception while updating or deleting in VCC_AUTH_USER] Error[ "
							+ npe.getMessage() + "]");
			return 0;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00032] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] [Exception while updating or deleting in VCC_AUTH_USER] Error[ " + e.getMessage() + "]");

			logger.info(String.format("[%s] [%s] [%s] [%s] Exception: while update vcc_auth_user [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId(), e));
			return 0;
		}

	}

	public int saveAuthUserDetail(VccRequest vnRequest, VccRatePlanModel rateModel, VccChargingCodeModel chargingCode,
			ScopeModel scope, VccError error, VccSubscriptionMasterModel vccSub) {
		int result = 0;
		try {
			VccAuthUserModel authModel = this.getVccAuthUser(vnRequest, rateModel, chargingCode);
			String serviceType = vnRequest.getServiceType();
			// added by sanchit atri on 17-sep-2020
			String query="";
			String lastDigit=vnRequest.getMsisdn().substring(vnRequest.getMsisdn().length()-1);
			String tableName="VCC_AUTH_USER_"+lastDigit;
			if (authModel != null) {
				serviceType = new ServiceTypeUtil().getCombinedServiceType(vnRequest.getServiceType(),
						authModel.getServiceType());
				if(multiTableEnable==1)
				{
					 query = "UPDATE "+tableName+" SET SERVICE_TYPE = ?, SUB_TYPE = ? WHERE MSISDN = ?";
				}
				else
				{
					 query = "UPDATE VCC_AUTH_USER SET SERVICE_TYPE = ?, SUB_TYPE = ? WHERE MSISDN = ?";
				}
				/*
				 * String query =
				 * "UPDATE VCC_AUTH_USER SET SERVICE_TYPE = ?, SUB_TYPE = ? WHERE MSISDN = ?";
				 */				
				logger.debug(String.format("msisdn [%s] service type [%s] before query [%s]", vnRequest.getMsisdn(),
						vnRequest.getServiceType(), query));
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				result = jdbcTemplate.update(query,
						new Object[] { serviceType, scope.getST(), vnRequest.getMsisdn() });
				logger.info(String.format("msisdn [%s] service type [%s] after query [%s]", vnRequest.getMsisdn(),
						vnRequest.getServiceType(), query));
				return result;
			} else {
				if(multiTableEnable==1)
				{
					 query = "INSERT INTO "+tableName+"(LOGIN_NAME,MSISDN,"
							+ "LANGUAGE,SERVICE_TYPE,STATUS,SUB_TYPE,CLASS_TYPE,TID)" + " VALUES(?,?,?,?,?,?,?,?)";
					
				}
				else
				{
					 query = "INSERT INTO VCC_AUTH_USER(LOGIN_NAME,MSISDN,"
							+ "LANGUAGE,SERVICE_TYPE,STATUS,SUB_TYPE,CLASS_TYPE,TID)" + " VALUES(?,?,?,?,?,?,?,?)";
					
				}
				/*
				 * String query = "INSERT INTO VCC_AUTH_USER(LOGIN_NAME,MSISDN," +
				 * "LANGUAGE,SERVICE_TYPE,STATUS,SUB_TYPE,CLASS_TYPE,TID)" +
				 * " VALUES(?,?,?,?,?,?,?,?)";
				 */
				logger.debug(String.format("msisdn [%s] service type [%s] before query [%s]", vnRequest.getMsisdn(),
						vnRequest.getServiceType(), query));
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				result = jdbcTemplate.update(query,
						new Object[] { vnRequest.getMsisdn(), vnRequest.getMsisdn(), vnRequest.getLang(),
								vnRequest.getServiceType(), vnRequest.getStatus(), scope.getST(), scope.getSC(),
								vnRequest.getTid() });
				logger.info(String.format("msisdn [%s] service type [%s] after query [%s]", vnRequest.getMsisdn(),
						vnRequest.getServiceType(), query));
				return result;
			}
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode [VCC-RE-90003] [Null Pointer Exception while saving data in VCC_AUTH_USER] Error[ "
							+ npe.getMessage() + "]");
			return 0;
		} catch (org.springframework.dao.DuplicateKeyException dup) {
			errorLogger.error("ErrorCode [VCC-RE-00003] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] [DuplicateKey Exception while saving data in VCC_AUTH_USER] Error[ " + dup.getMessage() + "]");
			return 0;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00033] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] [Exception while saving in VCC_AUTH_USER] Error[" + e.getMessage() + "]");
			logger.error(String.format("[%s] [%s] [%s] Exception: while save user data [%s]", vnRequest.getMsisdn(),
					vnRequest.getTid(), vnRequest.getServiceType(), e));
			return 0;
		}

	}

	public boolean updateVccAuthUserProfileNumber(VccRequest vnRequest, VccError error) {
		try {

			// added by sanchit atri on 17-sep-2020
			String query="";
			if(multiTableEnable==1)
			{
				String lastDigit=vnRequest.getMsisdn().substring(vnRequest.getMsisdn().length()-1);
				String tableName="VCC_AUTH_USER_"+lastDigit;
				 query = "update "+tableName+" SET MSISDN = ?,LOGIN_NAME=? where " + "MSISDN = ?";
			}
			else
			{
				 query = "update VCC_AUTH_USER SET MSISDN = ?,LOGIN_NAME=? where " + "MSISDN = ?";
			}
			/*
			 * String query = "update VCC_AUTH_USER SET MSISDN = ?,LOGIN_NAME=? where " +
			 * "MSISDN = ?";
			 */
			logger.debug(String.format("msisdn [%s] service type [%s] before query [%s]", vnRequest.getMsisdn(),
					vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int result = jdbcTemplate.update(query,
					new Object[] { vnRequest.getChangedMsisdn(), vnRequest.getChangedMsisdn(), vnRequest.getMsisdn() });
			logger.info(String.format("msisdn [%s] service type [%s] after query [%s]", vnRequest.getMsisdn(),
					vnRequest.getServiceType(), query));
			if (result > 0)
				return true;
			else
				return false;
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode [VCC-RE-90003] [Null Pointer Exception while updating user profilenumber in VCC_AUTH_USER] Error[ "
							+ npe.getMessage() + "]");
			return false;
		} catch (org.springframework.dao.DuplicateKeyException dup) {
			errorLogger.error("ErrorCode [VCC-RE-00003] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] [DuplicateKey Exception while updating user profilenumber in VCC_AUTH_USER] Error["
					+ dup.getMessage() + "]");
			error.setError(true);
			error.setMsg("User already exist.");
			return false;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00034] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] [Exception while updating user profilenumber in VCC_AUTH_USER] Error[" + e.getMessage() + "]");
			logger.info(String.format("msisdn [%s] servicetype [%s] exception: [%s]", vnRequest.getMsisdn(),
					vnRequest.getServiceType(), e));
			return false;
		}

	}

	public int updatePassword(VccRequest vmRequest) {
		try {
			// added by sanchit atri on 17-sep-2020
			String query="";
			if(multiTableEnable==1)
			{
				String lastDigit=vmRequest.getMsisdn().substring(vmRequest.getMsisdn().length()-1);
				String tableName="VCC_AUTH_USER_"+lastDigit;
				 query = "update "+tableName+" SET PASS = ? where " + "MSISDN = ? ";
				
			}
			else
			{
				 query = "update VCC_AUTH_USER SET PASS = ? where " + "MSISDN = ? ";
			}
			/*
			 * String query = "update VCC_AUTH_USER SET PASS = ? where " + "MSISDN = ? ";
			 */			logger.debug(String.format("msisdn [%s] service type [%s] before query [%s]", vmRequest.getMsisdn(),
					vmRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int result = jdbcTemplate.update(query, new Object[] { vmRequest.getPassword(), vmRequest.getMsisdn() });
			logger.info(String.format("msisdn [%s] service type [%s] pasword [%s] after query [%s]",
					vmRequest.getMsisdn(), vmRequest.getServiceType(), vmRequest.getPassword(), query));
			if (result > 0) {
				logger.info("Password change successfully into VCC_AUTH_USER");
				return 1;
			} else {
				logger.info("There is any error in change password in VCC_AUTH_USER");
				return -1;
			}
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode [VCC-RE-90003] [Null Pointer Exception while updating user password in VCC_AUTH_USER] Error[ "
							+ npe.getMessage() + "]");
			return -1;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00035] TID[" + vmRequest.getTid() + "] MSISDN[" + vmRequest.getMsisdn()
					+ "] ServiceType[" + vmRequest.getServiceType()
					+ "] [Exception while updating user password in VCC_AUTH_USER] Error[" + e.getMessage() + "]");
			logger.info(String.format("msisdn [%s] servicetype [%s] exception: [%s]", vmRequest.getMsisdn(),
					vmRequest.getServiceType(), e));
			return -1;
		}

	}

	public int updateSubProfile(VccRequest vmRequest, String status) {
		try {
			logger.debug("Inside updateSubProfile bean is " + vmRequest.toString() + "status is " + status);
			
			// added by sanchit atri on 17-sep-2020
			String query="";
			if(multiTableEnable==1)
			{
				String lastDigit=vmRequest.getMsisdn().substring(vmRequest.getMsisdn().length()-1);
				String tableName="VCC_AUTH_USER_"+lastDigit;
				 query = "update "+tableName+" SET STATUS = ? where " + "MSISDN = ?";
			}
			else
			{
				 query = "update VCC_AUTH_USER SET STATUS = ? where " + "MSISDN = ?";
			}
			/*
			 * String query = "update VCC_AUTH_USER SET STATUS = ? where " + "MSISDN = ?";
			 */
			logger.debug(String.format("msisdn [%s] service type [%s] before query [%s]", vmRequest.getMsisdn(),
					vmRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int result = jdbcTemplate.update(query,
					new Object[] { status, vmRequest.getMsisdn() });
			logger.info(String.format("msisdn [%s] service type [%s] after query [%s]", status,
					vmRequest.getServiceType(), vmRequest.getMsisdn(), query));
			if (result > 0) {
				logger.info("Profile updated successfully in VCC_AUTH_USER");
				return 1;
			} else {
				logger.info("There is any error in Profile updation in VCC_AUTH_USER");
				return -1;
			}
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode [VCC-RE-90003] [Null Pointer Exception while updating user Profile in VCC_AUTH_USER] Error[ "
							+ npe.getMessage() + "]");
			return -1;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00037] TID[" + vmRequest.getTid() + "] MSISDN[" + vmRequest.getMsisdn()
					+ "] ServiceType[" + vmRequest.getServiceType()
					+ "] [Exception while updating user Profile in VCC_AUTH_USER] Error[" + e.getMessage() + "]");
			logger.info(String.format("msisdn [%s] servicetype [%s] exception: [%s]", vmRequest.getMsisdn(),
					vmRequest.getServiceType(), e));
			return -1;
		}

	}

}
