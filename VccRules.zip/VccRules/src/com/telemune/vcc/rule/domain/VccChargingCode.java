package com.telemune.vcc.rule.domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.common.CacheLoader;
import com.telemune.vcc.rule.common.VccCache;
import com.telemune.vcc.rule.model.VccChargingCodeModel;
import com.telemune.vcc.rule.model.VccRatePlanModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.util.AppContext;

public class VccChargingCode {
	final static Logger logger = Logger.getLogger(VccChargingCode.class);
	 final static Logger errorLogger = Logger.getLogger("errorLogger");

	@SuppressWarnings("unused")
	private DataSource dataSource;
	private static Map<Integer,VccChargingCodeModel> mapChrg = new HashMap<Integer,VccChargingCodeModel>();

	static {
		loadChargingCodeCache();
	}
	public VccChargingCode() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}
	
	public VccChargingCodeModel getChargingCode(VccRequest vnRequest,
			VccRatePlanModel rateModel) {
		logger.debug("Inside getCharging code()");
		return mapChrg.get(rateModel.getSubCode());
	}
	public static void loadChargingCodeCache(){
		String query = "SELECT * FROM VCC_CHARGING_CODE";
		DataSource dataSource = (DataSource) AppContext.context
				.getBean("dataSource");
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		try {
			jdbcTemplate.query(query, new RowMapper<VccChargingCodeModel>() {
				@Override
				public VccChargingCodeModel mapRow(ResultSet rs, int rownumber)
						throws SQLException {
					VccChargingCodeModel vcc = new VccChargingCodeModel();
					vcc.setChargingCode(rs.getInt("CHARGING_CODE"));
					vcc.setAmountPre(rs.getInt("AMOUNT_PRE"));
					vcc.setAmountPost(rs.getInt("AMOUNT_POST"));
					vcc.setDescription(rs.getString("CHARGING_CODE_NAME"));
					vcc.setTariffPre(rs.getInt("TARIFF_PRE"));
					vcc.setTariffPost(rs.getInt("TARIFF_POST"));
					vcc.setHasChargingCode(true);
					mapChrg.put(rs.getInt("CHARGING_CODE"),vcc);
					return vcc;
				}
			});
			VccCache.map
					.put(CacheLoader._cc_prefix, "Reload charging code cache",
							AppConfig.config.getInt(
									"vcc_chrg_code_cache_time", 12),
							TimeUnit.HOURS);
		} catch (Exception e) {
            errorLogger.error("ErrorCode [VCC-RE-00014] [Exception while loading Charging Code cache] Error["
                    + e.getMessage() + "]");
    e.printStackTrace();
}

	}
}
