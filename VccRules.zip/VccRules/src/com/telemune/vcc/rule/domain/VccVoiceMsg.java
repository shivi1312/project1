package com.telemune.vcc.rule.domain;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.util.AppContext;

public class VccVoiceMsg {

	final static Logger logger = Logger.getLogger(VccVoiceMsg.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	
	private DataSource dataSource;

	public VccVoiceMsg() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public boolean deleteVoiceMsgByMsisdnAndServiceType(VccRequest vnRequest) {
		try {

			logger.info("origination number=[" + vnRequest.getMsisdn()
					+ "]  service type is [" + vnRequest.getServiceType() + "]");
			String query = "delete from VCC_VOICE_MSG where "
					+ "ORIGINAL_NUMBER = ? and SERVICE_TYPE = ?";
			logger.info(String.format("[%s] [%s] [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int result = jdbcTemplate.update(
					query,
					new Object[] { vnRequest.getMsisdn(),
							vnRequest.getServiceType() });
			logger.debug(String.format("[%s] [%s] [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), query));
			if (result > 0) {

				return true;
			} else {

				return false;
			}
		} catch (Exception e) {
            errorLogger.error("ErrorCode [VCC-RE-00040] TID["
                    + vnRequest.getTid()
                    + "] MSISDN["
                    + vnRequest.getMsisdn()
                    + "] ServiceType["+vnRequest.getServiceType()+"] [Exception while deleting data from VCC_VOICE_MSG] Error[ " + e.getMessage()+"]");
  
    return false;
}

	}

	public List<String> getVoiceMailList(VccRequest vnRequest) {
		List<String> list = null;
		try {
			String query = "select FILENAME from VCC_VOICE_MSG where "
					+ "ORIGINAL_NUMBER = ? and SERVICE_TYPE = ?";
			logger.info(String.format("[%s] [%s] [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			list =  jdbcTemplate.queryForList(
					query,
					new Object[] { vnRequest.getMsisdn(),
							vnRequest.getServiceType() }, String.class);
			logger.debug(String.format("[%s] [%s] [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), query));
			return list;
		}  catch (Exception e) {
            errorLogger.error("ErrorCode [VCC-RE-00042] TID["
                    + vnRequest.getTid()
                    + "] MSISDN["
                    + vnRequest.getMsisdn()
                    + "] ServiceType["+vnRequest.getServiceType()+"] [Exception while getting data from VCC_VOICE_MSG] Error[ " + e.getMessage()+"]");

			return new ArrayList<String>();
		}
	}

	public int deleteFromVoiceMsgScheduleByMsisdn(VccRequest vnRequest) {
		int result = 0;
		try {
			String query = "DELETE FROM VCC_VOICE_MSG_SCHEDULING WHERE "
					+ "DESTINATION_NUMBER = ? AND SERVICE_TYPE = ?";
			logger.info(String.format("[%s] [%s] [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			result = jdbcTemplate.update(
					query,
					new Object[] { vnRequest.getMsisdn(),
							vnRequest.getServiceType() });
			logger.debug(String.format("[%s] [%s] [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), query));
			return result;
		} catch (Exception e) {
            errorLogger.error("ErrorCode [VCC-RE-00043] TID["
                    + vnRequest.getTid()
                    + "] MSISDN["
                    + vnRequest.getMsisdn()
                    + "] ServiceType["+vnRequest.getServiceType()+"] [Exception while deleting data from VCC_VOICE_MSG_SCHEDULING] Error[" + e.getMessage()+"]");
    logger.info(String.format("[%s] [%s] [%s] [%s] Exception: while "
                    + "delete user detail [%s]", vnRequest.getMsisdn(),
                    vnRequest.getTid(), vnRequest.getServiceType(),
                    vnRequest.getActionId(), e));
    return 0;
}

	}

}
