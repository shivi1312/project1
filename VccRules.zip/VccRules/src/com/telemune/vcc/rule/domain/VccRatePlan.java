package com.telemune.vcc.rule.domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.common.CacheLoader;
import com.telemune.vcc.rule.common.VccCache;
import com.telemune.vcc.rule.model.VccRatePlanModel;
import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.util.AppContext;

public class VccRatePlan {

	final static Logger logger = Logger.getLogger(VccRatePlan.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	private static Map<Integer, VccRatePlanModel> mapRate = new HashMap<Integer, VccRatePlanModel>();
	private DataSource dataSource;
	int multiTableEnable=AppConfig.config.getInt("multi_table_sub_check"); // added by sanchit

	static {
		loadRatePlanCache();
	}

	public VccRatePlan() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public static void loadRatePlanCache() {
		String query = "SELECT * FROM VCC_RATE_PLAN";
		DataSource dataSource = (DataSource) AppContext.context
				.getBean("dataSource");
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		try {
			jdbcTemplate.query(query, new RowMapper<VccRatePlanModel>() {
				@Override
				public VccRatePlanModel mapRow(ResultSet rs, int rownumber)
						throws SQLException {
					VccRatePlanModel vcc = new VccRatePlanModel();
					vcc.setPlanId(rs.getInt("plan_id"));
					vcc.setSubCode(rs.getInt("sub_code"));
					vcc.setSubValidity(rs.getInt("sub_validity"));
					vcc.setRenew(rs.getInt("renew"));
					vcc.setRenewValidity(rs.getInt("renew_validity"));
					vcc.setRemarks(rs.getString("remarks"));
					vcc.setRetrieveCode(rs.getInt("retrieve_code"));
					vcc.setRecordCode(rs.getInt("record_code"));
					vcc.setGroupRecordCode(rs.getInt("group_record_code"));
					vcc.setServiceType(rs.getString("service_type"));
					vcc.setPullSmsCode(rs.getInt("pull_sms_code"));
					vcc.setPlanName(rs.getString("plan_name"));
					vcc.setScope(rs.getString("scope"));
					vcc.setMailboxId(rs.getInt("mailbox_id"));
					mapRate.put(rs.getInt("plan_id"), vcc);
					return vcc;
				}
			});
			VccCache.map.put(CacheLoader._rp_prefix, "Reload rate plan",
					AppConfig.config.getInt("vcc_rate_plan_cache_time", 12),
					TimeUnit.HOURS);
			
		} catch (Exception dae) {
            errorLogger.error("ErrorCode [VCC-RE-00015] [Exception while Loading RatePlan details] Error[ "
                    + dae.getMessage()+"]");
}

	}

	public List<VccRatePlanModel> getRatePlanByServiceTypeAndPlanName(
			VccRequest vnRequest) {
		List<VccRatePlanModel> list = new ArrayList<VccRatePlanModel>();
		try {
			for(Entry<Integer,VccRatePlanModel> entry: mapRate.entrySet()){
				VccRatePlanModel vccRate = entry.getValue();
				if(vccRate.getServiceType().equals(vnRequest.getServiceType()) &&
						vccRate.getPlanName().equalsIgnoreCase(vnRequest.getPlanName())){
					list.add(vccRate);
				}
			}
			return list;
		}  catch (NullPointerException npe) {
            errorLogger.error("ErrorCode[VCC-RE-90003] TID["
                    + vnRequest.getTid()
                    + "] MSISDN["
                    + vnRequest.getMsisdn()
                    + "] [Null Pointer exception while getting rateplan and planname by servicetype] Error[" + npe.getMessage()+"]");
}
catch (Exception e) {
    errorLogger.error("ErrorCode[VCC-RE-00011] TID["
                    + vnRequest.getTid()
                    + "] MSISDN["
                    + vnRequest.getMsisdn()
                    + "] [Exception while getting rateplan and planname by servicetype] Error[" + e.getMessage()+"]");
    logger.info(String.format("[%s] [%s] [%s] Exception: [%s]",
                    vnRequest.getMsisdn(), vnRequest.getTid(),
                    vnRequest.getActionId(), e));
}

		return list;
	}

	public String getExistingRatePlanName(VccRequest vnRequest,
			VccSubscriptionMasterModel vccSub) {
		String planName = "";
		try {
			String query = "SELECT PLAN_NAME FROM VCC_RATE_PLAN WHERE"
					+ " PLAN_ID = " + vccSub.getRatePlan();
			logger.debug(String.format("[%s] [%s] [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getActionId(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			planName = (String) jdbcTemplate.queryForObject(query,
					new Object[] {}, String.class);
			logger.info(String.format("[%s] [%s] [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getActionId(), query));
		}  catch (Exception e) {
            errorLogger.error("ErrorCode [VCC-RE-00007] TID["
                    + vnRequest.getTid()
                    + "] MSISDN["
                    + vnRequest.getMsisdn()
                    + "] [Exception while getting Existing RatePlan] Error[" + e.getMessage()+"]");
            logger.info(String.format("[%s] [%s] [%s] Exception: [%s]",
                    vnRequest.getMsisdn(), vnRequest.getTid(),
                    vnRequest.getActionId(), e));
}

		return planName;
	}

	public String getRatePlan(VccRequest vnRequest) {
		String ratePlanName = "default";
		String result = "";
		try {

			// added by sanchit atri on 17-sep-2020
			String query="";
			if(multiTableEnable==1)
			{
				String lastDigit=vnRequest.getMsisdn().substring(vnRequest.getMsisdn().length()-1);
				String tableName="VCC_SUBSCRIPTION_MASTER_"+lastDigit;
				
				 query = "Select RATE_PLAN from "+tableName+" WHERE "
						+ "MSISDN = ? AND SERVICE_TYPE = ?";
			}
			else
			{
				 query = "Select RATE_PLAN from VCC_SUBSCRIPTION_MASTER WHERE "
						+ "MSISDN = ? AND SERVICE_TYPE = ?";
			}
			
			//end
			/*
			 * String query = "Select RATE_PLAN from VCC_SUBSCRIPTION_MASTER WHERE " +
			 * "MSISDN = ? AND SERVICE_TYPE = ?";
			 */
			logger.debug(String.format("[%s] [%s] [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getActionId(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int ratePlan = jdbcTemplate.queryForObject(query, new Object[] {
					vnRequest.getMsisdn(), vnRequest.getServiceType() },
					Integer.class);
			logger.info(String.format("[%s] [%s] [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getActionId(), query));
			String query1 = "Select PLAN_NAME from VCC_RATE_PLAN where PLAN_ID=?";
			logger.debug(String.format("[%s] [%s] [%s] beforequery1 [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getActionId(), query));
			JdbcTemplate jdbcTemplate1 = new JdbcTemplate(dataSource);
			result = jdbcTemplate1.queryForObject(query1,
					new Object[] { ratePlan }, String.class);
			logger.info(String.format("[%s] [%s] [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getActionId(), query));
			return result;
		}

		catch (Exception e) {
            errorLogger.error("ErrorCode [VCC-RE-00012] TID["
                            + vnRequest.getTid()
                            + "] MSISDN["
                            + vnRequest.getMsisdn()
                            + "] ServiceType["+vnRequest.getServiceType()+"] [Exception while getting RatePlan] Error[" + e.getMessage()+"]");
            logger.error(String.format(
                            "msisdn [%s] servicetype [%s] exception: [%s]",
                            vnRequest.getMsisdn(), vnRequest.getServiceType(),
                            e.getMessage()));
            return ratePlanName;
    }

	}

}
