package com.telemune.vcc.rule.domain;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.telemune.vcc.rule.model.VccClassTypeModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.util.AppContext;

public class VccClassType {
	final static Logger logger = Logger.getLogger(VccClassType.class);
	private DataSource dataSource;

	public VccClassType() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public VccClassTypeModel haveAnyClass(VccRequest vnRequest) {
		VccClassTypeModel vccClass = null;
		String query = "select a.id id,a.msisdn msisdn,b.class_type "
				+ "class_type from VCC_USER_CLASS a,VCC_CLASS_TYPE b where a.msisdn = ? and a.class_type=b.id";
		logger.debug(String.format(
				"msisdn [%s] service type [%s] before query [%s]",
				vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		vccClass = jdbcTemplate.query(query,
				new Object[] { vnRequest.getMsisdn() },
				new ResultSetExtractor<VccClassTypeModel>() {
					@Override
					public VccClassTypeModel extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						if (rs.next()) {
							VccClassTypeModel vcc = new VccClassTypeModel();
							vcc.setId(rs.getInt("id"));
							vcc.setClassType(rs.getString("class_type"));
							vcc.setMsisdn(rs.getString("msisdn"));
							return vcc;
						}
						return new VccClassTypeModel();
					}
				});
		logger.info(String.format(
				"msisdn [%s] service type [%s] after query [%s]",
				vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
		return vccClass;
	}
}
