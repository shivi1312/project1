package com.telemune.vcc.rule.domain;

import org.apache.log4j.Logger;

import com.telemune.vcc.rule.model.VccError;
import com.telemune.vcc.rule.request.VccRequest;

public class ChangeNumber {
	static Logger logger = Logger.getLogger(ChangeNumber.class);
	public boolean changeNumber(VccRequest vnRequest,VccError error){
		boolean isVccAuthUserUpdate = new VccAuthUser().updateVccAuthUserProfileNumber(vnRequest, error);
		//boolean isvccAuthUserUpdate = new VccAuthUser().updateOrDeleteAuthDetail(vnRequest);
		if(!isVccAuthUserUpdate)
		{
			logger.info("Number ["+vnRequest.getMsisdn()+" is not changed into ["+vnRequest.getChangedMsisdn()+"]");
			return false;
		}
		
		boolean isVccMasterUpdate = new VccSubscriptionMaster().updateVccSubscriptionMasterProfileNumber(vnRequest);
		if(isVccMasterUpdate)
		{
		boolean isGreetingUpdated = new VccPersonalizedGreeting().updateVccSubscriptionMasterProfileNumber(vnRequest);
		boolean isGroupUpdate = new VccGroup().updateGroup(vnRequest);
		boolean isAdvancedDetailUpdate = new VccAdvancedDetail().updateAdvancedDetail(vnRequest);
		logger.info(String.format(
				"[%s] [%s] [%s] [%s] change number isVccAuthUserUpdate [%s] isVccMasterUpdate [%s] and isGreetingUpdated [%s] isGroupUpdate [%s] isAdvancedDetailUpdate[%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				isVccAuthUserUpdate,isVccMasterUpdate,isGreetingUpdated,isGroupUpdate,isAdvancedDetailUpdate));
		logger.debug(String.format(
				"[%s] [%s] [%s] [%s] change number isGreetingUpdated [%s] isGroupUpdate "
				+ "[%s] isAdvancedDetailUpdate[%s]",
				vnRequest.getMsisdn(), vnRequest.getTid(),
				vnRequest.getServiceType(), vnRequest.getActionId(),
				isGreetingUpdated,isGroupUpdate,isAdvancedDetailUpdate));
		//if(isVccAuthUserUpdate && isVccMasterUpdate)
			return true;
		}
		else
			return false;
	}
	
}
