package com.telemune.vcc.rule.domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.telemune.vcc.rule.common.VccCache;
import com.telemune.vcc.rule.model.VccTemplatesModel;
import com.telemune.vcc.util.AppContext;

public class VccLbsTemplates {
	final static Logger logger = Logger.getLogger(VccLbsTemplates.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private DataSource dataSource;
	public static HashMap<String, String> map = new HashMap<String, String>();
	private Gson gson = new Gson();
	private JsonParser parser = new JsonParser();

	public VccLbsTemplates() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public String getLbsMessage(String key) {
		if (VccCache.map.containsKey("lbs_template")) {
			
			return parser.parse(VccCache.map.get("lbs_template"))
					.getAsJsonObject().get(key).getAsString();
		}else{
			
			this.getTemplateList();
			logger.info("key to get: "+key);
			return parser.parse(VccCache.map.get("lbs_template"))
					.getAsJsonObject().get(key).getAsString();
		}
	}

	public void getTemplateList() {
		try {

			String query = "select TEMPLATE_ID,TEMPLATE_MESSAGE,LANGUAGE_ID from LBS_TEMPLATES";
			logger.debug("query for lbs: "+query);
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			jdbcTemplate.query(query, new RowMapper<VccTemplatesModel>() {

				@Override
				public VccTemplatesModel mapRow(ResultSet rs, int rownumber)
						throws SQLException {
					String key = "";
					key = rs.getInt("TEMPLATE_ID") + "-"
							+ rs.getInt("LANGUAGE_ID");
					logger.debug("key to put: "+key);
					map.put(key, rs.getString("TEMPLATE_MESSAGE"));
					return null;
				}
			});
			logger.debug("lbs data: "+gson.toJson(map));
			VccCache.map.put("lbs_template", gson.toJson(map), 10,
					TimeUnit.HOURS);
			

		} catch(Exception e){
            errorLogger.error("ErrorCode [VCC-RE-00064] [Exception while getting Template List] Error[" + e.getMessage()+"]");
            e.printStackTrace();
    }

	}

}
