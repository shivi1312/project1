package com.telemune.vcc.rule.domain;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.util.AppContext;

public class VccGroup {
	final static Logger logger = Logger.getLogger(VccGroup.class);
	 final static Logger errorLogger = Logger.getLogger("errorLogger");

	private DataSource dataSource;

	public VccGroup() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}
	public boolean updateGroup(VccRequest vnRequest){
		boolean isGroupMasterUpdate = this.updateGroupMaster(vnRequest);
		boolean isGroupDetailUpdate = this.updateGroupDetail(vnRequest);
		if(isGroupMasterUpdate && isGroupDetailUpdate)
			return true;
		else
			return false;
	}
	public boolean updateGroupMaster(VccRequest vnRequest) {
		try {
			String query = "UPDATE VCC_GROUP_MASTER SET MSISDN = ? where "
					+ "MSISDN = ?";
			logger.debug(String.format(
					"msisdn [%s] service type [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int result = jdbcTemplate.update(
					query,
					new Object[] { vnRequest.getChangedMsisdn(),
							vnRequest.getMsisdn() });
			logger.debug(String.format(
					"msisdn [%s] service type [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			if(result > 0)
				return true;
			else
				return false;
		}  catch (NullPointerException npe) {
            errorLogger
            .error("ErrorCode [VCC-RE-90003] [Null Pointer Exception while updating VCC_GROUP_MASTER] Error[ "
                            + npe.getMessage() + "]");
return false;
} catch (Exception e) {
errorLogger.error("ErrorCode [VCC-RE-00054] MSISDN["
            + vnRequest.getMsisdn() + "] ServiceType["
            + vnRequest.getServiceType()
            + "] [Exception while updating VCC_GROUP_MASTER] Error["
            + e.getMessage() + "]");
logger.info(String.format(
            "msisdn [%s] servicetype [%s] exception: [%s]",
            vnRequest.getMsisdn(), vnRequest.getServiceType(), e));
return false;
}

	}
	public boolean updateGroupDetail(VccRequest vnRequest) {
		try {
			String query = "UPDATE VCC_GROUP_DETAIL SET OWNER_MSISDN = ? where "
					+ "OWNER_MSISDN = ?";
			logger.debug(String.format(
					"msisdn [%s] service type [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int result = jdbcTemplate.update(
					query,
					new Object[] { vnRequest.getChangedMsisdn(),
							vnRequest.getMsisdn() });
			logger.debug(String.format(
					"msisdn [%s] service type [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			if(result > 0)
				return true;
			else
				return false;
		} catch (NullPointerException npe) {
            errorLogger
            .error("ErrorCode [VCC-RE-90003] [Null Pointer Exception while updating VCC_GROUP_DETAILS] Error[ "
                            + npe.getMessage() + "]");
return false;
} catch (Exception e) {
errorLogger.error("ErrorCode [VCC-RE-00052] MSISDN["
            + vnRequest.getMsisdn() + "] ServiceType["
            + vnRequest.getServiceType()
            + "] [Exception while updating VCC_GROUP_DETAILS] Error[ "
            + e.getMessage() + "]");
logger.info(String.format(
            "msisdn [%s] servicetype [%s] exception: [%s]",
            vnRequest.getMsisdn(), vnRequest.getServiceType(), e));
return false;
}

	}
	
	public int deleteFromGroupDetailByMsisdn(VccRequest vnRequest) {
		int result = 0;
		try {
			String query = "DELETE FROM VCC_GROUP_DETAIL WHERE "
					+ "OWNER_MSISDN = ?";
			logger.debug(String.format(
					"msisdn [%s] service type [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			result = jdbcTemplate.update(
					query,
					new Object[] { vnRequest.getMsisdn()});
			logger.debug(String.format(
					"msisdn [%s] service type [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			return result;
		}  catch (Exception e) {
            errorLogger
            .error("ErrorCode [VCC-RE-00050] TID["
                            + vnRequest.getTid()
                            + "] MSISDN["
                            + vnRequest.getMsisdn()
                            + "] ServiceType["
                            + vnRequest.getServiceType()
                            + "] [Exception while deleting from VCC_GROUP_DETAIL] Error["
                            + e.getMessage() + "]");
logger.info(String.format("[%s] [%s] [%s] [%s] Exception: while "
            + "delete user detail [%s]", vnRequest.getMsisdn(),
            vnRequest.getTid(), vnRequest.getServiceType(),
            vnRequest.getActionId(), e));
return 0;
}

	}
	public int deleteFromGroupMasterByMsisdn(VccRequest vnRequest) {
		int result = 0;
		try {
			String query = "DELETE FROM VCC_GROUP_MASTER WHERE "
					+ "MSISDN = ?";
			logger.debug(String.format(
					"msisdn [%s] service type [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			result = jdbcTemplate.update(
					query,
					new Object[] { vnRequest.getMsisdn()});
			logger.debug(String.format(
					"msisdn [%s] service type [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			return result;
		} catch (Exception e) {
            errorLogger
            .error("ErrorCode [VCC-RE-00051] TID["
                            + vnRequest.getTid()
                            + "] MSISDN["
                            + vnRequest.getMsisdn()
                            + "] [Exception while deleting from VCC_GROUP_MASTER] Error["
                            + e.getMessage() + "]");
logger.info(String.format("[%s] [%s] [%s] [%s] Exception: while "
            + "delete user detail [%s]", vnRequest.getMsisdn(),
            vnRequest.getTid(), vnRequest.getServiceType(),
            vnRequest.getActionId(), e));
return 0;
}

	}
	
	public List<String> getGroupList(VccRequest vnRequest) {
		List<String> list = null;
		try {
			String query = "select FILENAME from VCC_GROUP_MASTER where "
					+ "MSISDN = ?";
			logger.debug(String.format(
					"msisdn [%s] service type [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			list = jdbcTemplate.queryForList(
					query,
					new Object[] { vnRequest.getMsisdn() }, String.class);
			logger.debug(String.format(
					"msisdn [%s] service type [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			return list;
		} catch (DataAccessException dae) {
            errorLogger.error("ErrorCode [VCC-RE-00045] MSISDN["
                    + vnRequest.getMsisdn() + "] ServiceType["
                    + vnRequest.getServiceType()
                    + "] [Exception while getting data from VCC_GROUP_MASTER]"
                    + dae.getMessage() + "]");
    return new ArrayList<String>();
} catch (Exception e) {
    errorLogger
                    .error("ErrorCode [VCC-RE-00045] MSISDN["
                                    + vnRequest.getMsisdn()
                                    + "] ServiceType["
                                    + vnRequest.getServiceType()
                                    + "] [Exception while getting data from VCC_GROUP_MASTER] Error["
                                    + e.getMessage() + "]");

			return new ArrayList<String>();
		}
	}
}
