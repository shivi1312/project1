package com.telemune.vcc.rule.domain;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.util.AppContext;

public class VccPersonalizedGreeting {

	final static Logger logger = Logger
			.getLogger(VccPersonalizedGreeting.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	private DataSource dataSource;

	public VccPersonalizedGreeting() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public boolean updateVccSubscriptionMasterProfileNumber(VccRequest vnRequest) {
		try {
			String query = "UPDATE VCC_PERSONALIZED_GREETING SET MSISDN = ? where "
					+ "MSISDN = ?";
			logger.debug(String.format(
					"msisdn [%s] service type [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int result = jdbcTemplate.update(
					query,
					new Object[] { vnRequest.getChangedMsisdn(),
							vnRequest.getMsisdn() });
			logger.debug(String.format(
					"msisdn [%s] service type [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			if (result > 0)
				return true;
			else {
				errorLogger.error("ErrorCode [VCC-RE-00067] TID["
						+ vnRequest.getTid() + "] MSISDN["
						+ vnRequest.getMsisdn() + "] ServiceType["
						+ vnRequest.getServiceType()
						+ "] [Unable to update VCC_PERSONALIZED_GREETING] ");
				return false;
			}
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode [VCC-RE-90003] [Null Pointer Exception while updating VCC_PERSONALIZED_GREETING] Error[ "
							+ npe.getMessage() + "]");
			return false;
		} catch (Exception dae) {
			errorLogger
					.error("ErrorCode [VCC-RE-00066] TID["
							+ vnRequest.getTid()
							+ "] MSISDN["
							+ vnRequest.getMsisdn()
							+ "] ServiceType["
							+ vnRequest.getServiceType()
							+ "] [Exception while updating VCC_PERSONALIZED_GREETING] Error["
							+ dae.getMessage() + "]");
			return false;
		}
	}

	public int deleteFromPersonalizedGreetingByMsisdn(VccRequest vnRequest) {
		int result = 0;
		try {
			String query = "DELETE FROM VCC_PERSONALIZED_GREETING WHERE "
					+ "MSISDN = ? ";
			logger.debug(String.format(
					"msisdn [%s] service type [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			result = jdbcTemplate.update(query,
					new Object[] { vnRequest.getMsisdn() });
			logger.debug(String.format(
					"msisdn [%s] service type [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			return result;
		} catch (DataAccessException dae) {
			errorLogger
					.error("ErrorCode [VCC-RE-00046] TID["
							+ vnRequest.getTid()
							+ "] MSISDN["
							+ vnRequest.getMsisdn()
							+ "] ServiceType["
							+ vnRequest.getServiceType()
							+ "] [Exception while deleting from VCC_PERSONALIZED_GREETING] Error["
							+ dae.getMessage() + "]");
			return 0;
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode [VCC-RE-00046] TID["
							+ vnRequest.getTid()
							+ "] MSISDN["
							+ vnRequest.getMsisdn()
							+ "] ServiceType["
							+ vnRequest.getServiceType()
							+ "] [Exception while deleting from VCC_PERSONALIZED_GREETING] Error["
							+ e.getMessage() + "]");
			logger.info(String.format("[%s] [%s] [%s] [%s] Exception: while "
					+ "delete user detail [%s]", vnRequest.getMsisdn(),
					vnRequest.getTid(), vnRequest.getServiceType(),
					vnRequest.getActionId(), e));
			return 0;
		}
	}

	public List<String> getGreetingList(VccRequest vnRequest) {
		List<String> list = null;
		try {
			String query = "select FILEPATH from VCC_PERSONALIZED_GREETING where "
					+ "MSISDN = ?";
			logger.debug(String.format(
					"msisdn [%s] service type [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			list = jdbcTemplate.queryForList(query,
					new Object[] { vnRequest.getMsisdn() }, String.class);
			logger.debug(String.format(
					"msisdn [%s] service type [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			return list;
		} catch (DataAccessException dae) {
			errorLogger
					.error("ErrorCode [VCC-RE-00044] TID["
							+ vnRequest.getTid()
							+ "] MSISDN["
							+ vnRequest.getMsisdn()
							+ "] ServiceType["
							+ vnRequest.getServiceType()
							+ "] [Exception while getting data from VCC_PERSONALIZED_GREETING] Error["
							+ dae.getMessage() + "]");
			return new ArrayList<String>();
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode [VCC-RE-00044] TID["
							+ vnRequest.getTid()
							+ "] MSISDN["
							+ vnRequest.getMsisdn()
							+ "] ServiceType["
							+ vnRequest.getServiceType()
							+ "] [Exception while getting data from VCC_PERSONALIZED_GREETING] Error["
							+ e.getMessage() + "]");
			logger.info(String.format(
					"msisdn [%s] servicetype [%s] exception: [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), e));
			return new ArrayList<String>();
		}
	}

}
