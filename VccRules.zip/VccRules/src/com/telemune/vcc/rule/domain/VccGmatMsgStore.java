package com.telemune.vcc.rule.domain;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.util.AppContext;

public class VccGmatMsgStore {
	final static Logger logger = Logger.getLogger(VccGmatMsgStore.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private DataSource dataSource;
	VccLbsTemplates vccLbsTemp = null;

	public VccGmatMsgStore() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public boolean insertIntoGmatMsg(String senderId, VccRequest vnRequest, String key, String replaceKey) {
		try {
			if (vnRequest.getNotification()) {
				String query = "";
				logger.debug("Inside insert into gmat_message_store sender id [" + senderId + "] key [" + key + "]");
				vccLbsTemp = new VccLbsTemplates();
				String tempMessage = "Error";
				tempMessage = vccLbsTemp.getLbsMessage(key);

				tempMessage = CreateTemplate(tempMessage, replaceKey);

				if (AppConfig.config.getInt("DB_CON_PARAM", 1) == 1) {
					query = "insert into GMAT_MESSAGE_STORE(ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT,"
							+ "SUBMIT_TIME,STATUS,MESSAGE_TYPE,DESTINATION_PORT,LANGUAGE) values (?,?,?,now(),'R',1,0,?)";
				} else if (AppConfig.config.getInt("DB_CON_PARAM", 0) == 0) {
					query = "insert into GMAT_MESSAGE_STORE(RESPONSE_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT,"
							+ "SUBMIT_TIME,STATUS,MESSAGE_TYPE,DESTINATION_PORT,LANGUAGE) values (gmat_request_seq.nextval,?,?,?,sysdate,'R',1,0,?)";
				}
				logger.debug(String.format("[%s] [%s] [%s] [%s]  before query [%s]", vnRequest.getMsisdn(),
						vnRequest.getTid(), vnRequest.getActionId(), tempMessage, query));
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				int count = jdbcTemplate.update(query,
						new Object[] { senderId, vnRequest.getMsisdn(), tempMessage, vnRequest.getLang() });
				logger.info(String.format("[%s] [%s] [%s] [%s]  after query [%s]", vnRequest.getMsisdn(),
						vnRequest.getTid(), vnRequest.getActionId(), tempMessage, query));
				if (count > 0)
					return true;
				else
					return false;
			}
			logger.info(String.format("[%s] [%s] [%s] [%s] msg not inserted because notification disabled",
					vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId()));
			return false;
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode [VCC-RE-90003] [Null Pointer Exception in Inserting in GMAT_MESSAGE_STORE] Error[ "
							+ npe.getMessage() + "]");
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			errorLogger.error("ErrorCode [VCC-RE-00063] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] [Exception in Inserting message in GMAT_MESSAGE_STORE] Error[" + e.getMessage() + "]");
			e.printStackTrace();
			return false;
		}

	}

	public String CreateTemplate(String srcTemplate, String replaceKey) {
	
		try {
			srcTemplate = srcTemplate.replace("$(trigger)", replaceKey);
		} catch (NullPointerException npe) {
			errorLogger.error("ErrorCode [VCC-RE-90003] [Null Pointer Exception when replace template key] Error[ "
					+ npe.getMessage() + "]");

		} catch (Exception e) {
			e.printStackTrace();
			errorLogger.error(
					"ErrorCode [VCC-RE-900021] [Exception when replace template key] Error[ " + e.getMessage() + "]");

		}
		return srcTemplate;
	}

}
