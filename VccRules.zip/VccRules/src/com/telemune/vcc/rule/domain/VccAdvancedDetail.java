package com.telemune.vcc.rule.domain;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.util.AppContext;

public class VccAdvancedDetail {
	static Logger logger = Logger.getLogger(VccAdvancedDetail.class);
	static Logger errorLogger = Logger.getLogger("errorLogger");

	private DataSource dataSource;

	public VccAdvancedDetail() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public boolean updateAdvancedDetail(VccRequest vnRequest) {
		try {

			String query = "UPDATE VCC_ADVANCED_DETAILS SET MSISDN = ? where "
					+ "MSISDN = ?";
			logger.debug(String.format(
					"msisdn [%s] service type [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int result = jdbcTemplate.update(
					query,
					new Object[] { vnRequest.getChangedMsisdn(),
							vnRequest.getMsisdn() });
			logger.debug(String.format(
					"msisdn [%s] service type [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			if (result > 0)
				return true;
			else
				return false;
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode [VCC-RE-90003] [Null Pointer Exception in Updating MSISDN in VCC_ADVANCED_DETAILS] Error[ "
							+ npe.getMessage() + "]");
			return false;
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode [VCC-RE-00048] TID["
							+ vnRequest.getTid()
							+ "] MSISDN["
							+ vnRequest.getMsisdn()
							+ "] ServiceType["
							+ vnRequest.getServiceType()
							+ "] [Exception while updating MSISDN in VCC_ADVANCED_DETAILS] Error["
							+ e.getMessage() + "]");
			return false;
		}

	}

	public int deleteFromAdvanceDetailByMsisdn(VccRequest vnRequest) {
		int result = 0;
		try {
			String query = "DELETE FROM VCC_ADVANCED_DETAILS WHERE "
					+ "MSISDN = ? AND SERVICE_TYPE = ?";
			logger.debug(String.format(
					"msisdn [%s] service type [%s] before query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			result = jdbcTemplate.update(
					query,
					new Object[] { vnRequest.getMsisdn(),
							vnRequest.getServiceType() });
			logger.info(String.format(
					"msisdn [%s] service type [%s] after query [%s]",
					vnRequest.getMsisdn(), vnRequest.getServiceType(), query));
			return result;
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode [VCC-RE-90003] [Null Pointer Exception while deleting from VCC_ADVANCED_DETAILS] Error[ "
							+ npe.getMessage() + "]");
			return 0;
		} catch (DataAccessException dae) {
			errorLogger
					.error("ErrorCode [VCC-RE-00047] TID["
							+ vnRequest.getTid()
							+ "] MSISDN["
							+ vnRequest.getMsisdn()
							+ "] ServiceType["
							+ vnRequest.getServiceType()
							+ "] [Exception while deleting from VCC_ADVANCED_DETAILS] Error["
							+ dae.getMessage() + "]");
			return 0;
		} catch (Exception e) {
			errorLogger
					.error("ErrorCode [VCC-RE-00047] TID["
							+ vnRequest.getTid()
							+ "] MSISDN["
							+ vnRequest.getMsisdn()
							+ "] ServiceType["
							+ vnRequest.getServiceType()
							+ "] [Exception while deleting from VCC_ADVANCED_DETAILS] Error["
							+ e.getMessage() + "]");
			logger.info(String.format("[%s] [%s] [%s] [%s] Exception: while "
					+ "delete user detail [%s]", vnRequest.getMsisdn(),
					vnRequest.getTid(), vnRequest.getServiceType(),
					vnRequest.getActionId(), e));
			return 0;

		}
	}

}
