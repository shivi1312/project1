package com.telemune.vcc.rule.domain;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.model.VccChargingCodeModel;
import com.telemune.vcc.rule.model.VccRatePlanModel;
import com.telemune.vcc.rule.model.VccSubscriptionMasterModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.util.AppContext;

public class VccSubscriptionMaster {

	final static Logger logger = Logger.getLogger(VccSubscriptionMaster.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	int multiTableEnable=AppConfig.config.getInt("multi_table_sub_check"); // added by sanchit
	
	private DataSource dataSource;
	// public String service_flag="0000000000";
	public StringBuffer serviceFlag = new StringBuffer();

	/*
	 * public final static String
	 * recording_enable=AppConfig.config.getString("recording_enable","1");
	 * public final static String blacklist_enable_disable =
	 * AppConfig.config.getString("Blacklist_enable","1");//1//2 is position
	 * service flag and flag value are 0 for active 1 for de-active public final
	 * static String time_setting_enable_disable
	 * =(AppConfig.config.getString("Time_setting_enable","1"));//1//3 is
	 * position service flag and flag value are 0 for active 1 for de-active
	 * public final static String friend_limit_enable_disable
	 * =AppConfig.config.getString("Friend_limit_enable","1"));//1//4 is
	 * position service flag and flag value are 0 for active 1 for de-active
	 * public final static String transfer_mail_enable_disable =
	 * AppConfig.config.getString("Transfer_mail_enable","1"));//1//5 is
	 * position service flag and flag value are 0 for active 1 for de-active
	 * public final static int follow_me_enable_disable =
	 * Integer.parseInt(AppConfig.config.getString("Follow_me_enable","1"));
	 * //1//6 is position service flag and flag value are 0 for active 1 for
	 * de-active public final static int auto_sms_enable_disable =
	 * Integer.parseInt(AppConfig.config.getString("Auto_sms_enable","1"));
	 * //1//7 is position service flag and flag value are 0 for active 1 for
	 * de-active public final static int alternative_msisdn_enable_disable
	 * =Integer
	 * .parseInt(AppConfig.config.getString("Alternative_msisdn_enable","1")) ;
	 * //1//8 is position service flag and flag value are 0 for active 1 for
	 * de-active public final static int notification_enable_disable =
	 * Integer.parseInt(AppConfig.config.getString("Notification_enable","0"));
	 * //0//9 is position service flag and flag value are 0 for active 1 for
	 * de-active public final static int message_header_enable_disable =
	 * Integer.
	 * parseInt(AppConfig.config.getString("Message_header_enable","0")); //0//
	 * 10 is position service flag and flag value are 0 for active 1 for
	 * de-active
	 */

	// Service[0]=recording_enable;
	public VccSubscriptionMaster() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public VccSubscriptionMasterModel getServiceDetailByServiceType(VccRequest vnRequest) {
		VccSubscriptionMasterModel subObj = null;
		try {

			String query = "";
			// added by sanchit atri on 17-sep-2020

			String lastDigit=vnRequest.getMsisdn().substring(vnRequest.getMsisdn().length()-1);
			String tableName1="VCC_AUTH_USER_"+lastDigit;
			String tableName2="vcc_subscription_master_"+lastDigit;
				
			if (vnRequest.getActionId() == 1 || vnRequest.getActionId() == 9) {
				if(multiTableEnable==1)
				{
					query = "SELECT  a.MSISDN, a.SERVICE_TYPE,a.EXPIRY_DATE,a.RATE_PLAN,a.DATE_REGISTERED,a.STATUS , b.LANGUAGE as lang FROM "+tableName2+" a inner join "+tableName1+" b  on a.MSISDN=b.MSISDN WHERE a.MSISDN =? AND a.SERVICE_TYPE =?";
				}
				else
				{
					query = "SELECT  vcc_subscription_master.MSISDN, vcc_subscription_master.SERVICE_TYPE,vcc_subscription_master.EXPIRY_DATE,vcc_subscription_master.RATE_PLAN,vcc_subscription_master.DATE_REGISTERED,vcc_subscription_master.STATUS , vcc_auth_user.LANGUAGE as lang FROM vcc_subscription_master inner join vcc_auth_user on "
							+ "vcc_subscription_master.MSISDN=vcc_auth_user.MSISDN WHERE vcc_subscription_master.MSISDN = "
							+ "? AND vcc_subscription_master.SERVICE_TYPE = ? ";
				}
				/*
				 * query =
				 * "SELECT  vcc_subscription_master.MSISDN, vcc_subscription_master.SERVICE_TYPE,vcc_subscription_master.EXPIRY_DATE,vcc_subscription_master.RATE_PLAN,vcc_subscription_master.DATE_REGISTERED,vcc_subscription_master.STATUS , vcc_auth_user.LANGUAGE as lang FROM vcc_subscription_master inner join vcc_auth_user on "
				 * +
				 * "vcc_subscription_master.MSISDN=vcc_auth_user.MSISDN WHERE vcc_subscription_master.MSISDN = "
				 * + "? AND vcc_subscription_master.SERVICE_TYPE = ? ";
				 */
			} else if (vnRequest.getActionId() == 2 || vnRequest.getActionId() == 3 || vnRequest.getActionId() == 6
					|| vnRequest.getActionId() == 7 || vnRequest.getActionId() == 8 || vnRequest.getActionId() == 10) {
				
				if(multiTableEnable==1)
				{
					query = "SELECT  a.MSISDN, a.SERVICE_TYPE,a.EXPIRY_DATE,a.RATE_PLAN,a.DATE_REGISTERED,a.STATUS , b.LANGUAGE as lang FROM "+tableName2+" a inner join "+tableName1+" b  on a.MSISDN=b.MSISDN WHERE a.MSISDN =? AND a.SERVICE_TYPE =?";

				}
				else
				{
					query = "SELECT  vcc_subscription_master.MSISDN, vcc_subscription_master.SERVICE_TYPE,vcc_subscription_master.EXPIRY_DATE,vcc_subscription_master.RATE_PLAN,vcc_subscription_master.DATE_REGISTERED,vcc_subscription_master.STATUS ,  vcc_auth_user.LANGUAGE as lang FROM vcc_subscription_master inner join "
							+ "vcc_auth_user on vcc_subscription_master.MSISDN=vcc_auth_user.MSISDN WHERE vcc_subscription_master.MSISDN = "
							+ "? AND vcc_subscription_master.SERVICE_TYPE = ? ";
				}
				/*
				 * query =
				 * "SELECT  vcc_subscription_master.MSISDN, vcc_subscription_master.SERVICE_TYPE,vcc_subscription_master.EXPIRY_DATE,vcc_subscription_master.RATE_PLAN,vcc_subscription_master.DATE_REGISTERED,vcc_subscription_master.STATUS ,  vcc_auth_user.LANGUAGE as lang FROM vcc_subscription_master inner join "
				 * +
				 * "vcc_auth_user on vcc_subscription_master.MSISDN=vcc_auth_user.MSISDN WHERE vcc_subscription_master.MSISDN = "
				 * + "? AND vcc_subscription_master.SERVICE_TYPE = ? ";
				 */
			}

			logger.info(String.format("[%s] [%s] [%s] [%s] before query: [%s]", vnRequest.getMsisdn(),
					vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			subObj = jdbcTemplate.query(query, new Object[] { vnRequest.getMsisdn(), vnRequest.getServiceType() },
					new ResultSetExtractor<VccSubscriptionMasterModel>() {
						@Override
						public VccSubscriptionMasterModel extractData(ResultSet rs)
								throws SQLException, DataAccessException {
							if (rs.next()) {
								VccSubscriptionMasterModel vcc = new VccSubscriptionMasterModel();
								vcc.setMsisdn(rs.getString("MSISDN"));
								vcc.setServiceType(rs.getString("SERVICE_TYPE"));
								vcc.setExpiryDate(rs.getDate("EXPIRY_DATE"));
								vcc.setRatePlan(rs.getInt("RATE_PLAN"));
								vcc.setDateRegistered(rs.getDate("DATE_REGISTERED"));
								vcc.setStatus(rs.getString("STATUS"));
								vcc.setLanguage(rs.getInt("lang"));
								return vcc;
							}
							return null;
						}
					});
			logger.debug(String.format("[%s] [%s] [%s] [%s] after query: [%s]", vnRequest.getMsisdn(),
					vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId(), query));
			return subObj;
		} catch (Exception e) {
			logger.info(String.format("[%s] [%s] [%s] [%s] Error select query [%s]", vnRequest.getMsisdn(),
					vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId(), e.getMessage()));
			errorLogger.error("ErrorCode [VCC-RE-00029] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] [Exception while getting data from VCC_SuBSCRIPTION_MASTER] Error[" + e.getMessage() + "]");
			return null;
		}

	}

	public boolean getChangeMsisdnExist(VccRequest vnRequest) {

		try {
			boolean isExist = false;
			String query = "";

			// added by sanchit atri on 17-sep-2020
			if(multiTableEnable==1)
			{
				String lastDigit=vnRequest.getMsisdn().substring(vnRequest.getMsisdn().length()-1);
				String tableName1="VCC_AUTH_USER_"+lastDigit;
				String tableName2="vcc_subscription_master_"+lastDigit;
				
				query = "SELECT  count(*) FROM "+tableName2+" a inner join "+tableName1+" b on a.MSISDN=b.MSISDN WHERE a.MSISDN =? AND a.SERVICE_TYPE =?";
			}
			else
			{
				query = "SELECT  count(*) FROM vcc_subscription_master inner join vcc_auth_user on "
						+ "vcc_subscription_master.MSISDN=vcc_auth_user.MSISDN WHERE vcc_subscription_master.MSISDN = "
						+ "? AND vcc_subscription_master.SERVICE_TYPE = ?";
			}
			/*
			 * query =
			 * "SELECT  count(*) FROM vcc_subscription_master inner join vcc_auth_user on "
			 * +
			 * "vcc_subscription_master.MSISDN=vcc_auth_user.MSISDN WHERE vcc_subscription_master.MSISDN = "
			 * + "? AND vcc_subscription_master.SERVICE_TYPE = ?";
			 */
			logger.info(String.format("[%s] [%s] [%s] before query: [%s]", vnRequest.getMsisdn(),
					vnRequest.getChangedMsisdn(), vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

			isExist = jdbcTemplate.queryForObject(query,
					new Object[] { vnRequest.getChangedMsisdn(), vnRequest.getServiceType() }, Boolean.class);

			return isExist;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00029] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] [Exception while when check change MSISDN exist or not] Error[" + e.getMessage() + "]");

			return false;
		}

	}

	public int saveUserDetail(VccRequest vnRequest, VccRatePlanModel rateModel, VccChargingCodeModel chargingCode,
			VccSubscriptionMasterModel vccSub) {
		int result = 0;
		try {
			serviceFlag.append(AppConfig.config.getString("recording_enable", "1"));
			serviceFlag.append(AppConfig.config.getString("Blacklist_enable", "1"));
			// 1//2 is position service flag and flag value are 0 for active 1 for de-active
			serviceFlag.append(AppConfig.config.getString("Time_setting_enable", "1"));
			// 1//3 is position service flag and flag value are 0 for active 1 for de-active
			serviceFlag.append(AppConfig.config.getString("Friend_limit_enable", "1"));
			// 1//4 is position service flag and flag value are 0 for active 1 for de-active
			serviceFlag.append(AppConfig.config.getString("Transfer_mail_enable", "1"));
			// 1//5 is position service flag and flag value are 0 for active 1 for de-active
			serviceFlag.append(AppConfig.config.getString("Follow_me_enable", "1")); 
			// 1//6 is position service flag and flag value are 0 for active 1 for de-active
			serviceFlag.append(AppConfig.config.getString("Auto_sms_enable", "1"));
			// 1//7 is position service flag and flag value are 0 for active 1 for de-active
			serviceFlag.append(AppConfig.config.getString("Alternative_msisdn_enable", "1")); 
			// 1//8 is position service flag and flag value are 0 for active 1 for de-active
			serviceFlag.append(AppConfig.config.getString("Notification_enable", "0")); 
			// 0//9 is position service flag and flag value are 0 for active 1 for de-active
			serviceFlag.append(AppConfig.config.getString("Message_header_enable", "0")); 
			// 0 10 is position service flag and flag value are 0 for active 1 for de-active

			logger.debug(String.format("[%s] [%s] [%s] service flag [%s]", vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), serviceFlag.toString()));
			String query = "";
			
			// added by sanchit atri on 17-sep-2020

			String lastDigit=vnRequest.getMsisdn().substring(vnRequest.getMsisdn().length()-1);
			String tableName="VCC_SUBSCRIPTION_MASTER_"+lastDigit;
			if (vccSub != null) {
				
				
				if (Integer.parseInt(AppConfig.config.getString("DB_CON_PARAM", "0")) == 0) {
					
					if(multiTableEnable==1)
					{
						query = "UPDATE "+tableName+" SET " + "EXPIRY_DATE = sysdate+ INTERVAL '"
								+ rateModel.getSubValidity() + "' DAY" + ",RATE_PLAN = " + rateModel.getPlanId()
								+ ",STATUS ='" + vnRequest.getStatus() + "' WHERE MSISDN = '" + vnRequest.getMsisdn()
								+ "' AND SERVICE_TYPE = '" + vnRequest.getServiceType() + "'";
						
					}
					else
					{
						query = "UPDATE VCC_SUBSCRIPTION_MASTER SET " + "EXPIRY_DATE = sysdate+ INTERVAL '"
								+ rateModel.getSubValidity() + "' DAY" + ",RATE_PLAN = " + rateModel.getPlanId()
								+ ",STATUS ='" + vnRequest.getStatus() + "' WHERE MSISDN = '" + vnRequest.getMsisdn()
								+ "' AND SERVICE_TYPE = '" + vnRequest.getServiceType() + "'";
					}

					/*
					 * query = "UPDATE VCC_SUBSCRIPTION_MASTER SET " +
					 * "EXPIRY_DATE = sysdate+ INTERVAL '" + rateModel.getSubValidity() + "' DAY" +
					 * ",RATE_PLAN = " + rateModel.getPlanId() + ",STATUS ='" +
					 * vnRequest.getStatus() + "' WHERE MSISDN = '" + vnRequest.getMsisdn() +
					 * "' AND SERVICE_TYPE = '" + vnRequest.getServiceType() + "'";
					 */
				} else if (Integer.parseInt(AppConfig.config.getString("DB_CON_PARAM", "1")) == 1) {
					
					if(multiTableEnable==1)
					{
						query = "UPDATE "+tableName+" SET " + "EXPIRY_DATE = NOW()+ INTERVAL "
								+ rateModel.getSubValidity() + " DAY" + ",RATE_PLAN = " + rateModel.getPlanId()
								+ ",STATUS ='" + vnRequest.getStatus() + "' WHERE MSISDN = '" + vnRequest.getMsisdn()
								+ "' AND SERVICE_TYPE = '" + vnRequest.getServiceType() + "'";
					}
					else
					{
						query = "UPDATE VCC_SUBSCRIPTION_MASTER SET " + "EXPIRY_DATE = NOW()+ INTERVAL "
								+ rateModel.getSubValidity() + " DAY" + ",RATE_PLAN = " + rateModel.getPlanId()
								+ ",STATUS ='" + vnRequest.getStatus() + "' WHERE MSISDN = '" + vnRequest.getMsisdn()
								+ "' AND SERVICE_TYPE = '" + vnRequest.getServiceType() + "'";
					}
					/*
					 * query = "UPDATE VCC_SUBSCRIPTION_MASTER SET " +
					 * "EXPIRY_DATE = NOW()+ INTERVAL " + rateModel.getSubValidity() + " DAY" +
					 * ",RATE_PLAN = " + rateModel.getPlanId() + ",STATUS ='" +
					 * vnRequest.getStatus() + "' WHERE MSISDN = '" + vnRequest.getMsisdn() +
					 * "' AND SERVICE_TYPE = '" + vnRequest.getServiceType() + "'";
					 */
				}
				logger.info(String.format("[%s] [%s] [%s] [%s] query [%s]", vnRequest.getMsisdn(), vnRequest.getTid(),
						vnRequest.getServiceType(),vnRequest.getStatus(), query));
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				result = jdbcTemplate.update(query, new Object[] {});
				logger.debug(String.format("[%s] [%s] [%s] query [%s]", vnRequest.getMsisdn(), vnRequest.getTid(),
						vnRequest.getServiceType(), query));
				return result;
			} else {

				if (AppConfig.config.getInt("DB_CON_PARAM", 0) == 0) {
					

					if(multiTableEnable==1)
					{
						query = "INSERT INTO "+tableName+"(MSISDN,"
								+ "SERVICE_TYPE,EXPIRY_DATE,RATE_PLAN,STATUS,DATE_REGISTERED,SERVICE_FLAG) VALUES(?,?,sysdate+"
								+ rateModel.getSubValidity() + ",?,?,sysdate,?)";
					}
					else
					{
						query = "INSERT INTO VCC_SUBSCRIPTION_MASTER(MSISDN,"
								+ "SERVICE_TYPE,EXPIRY_DATE,RATE_PLAN,STATUS,DATE_REGISTERED,SERVICE_FLAG) VALUES(?,?,sysdate+"
								+ rateModel.getSubValidity() + ",?,?,sysdate,?)";
					}
					/*
					 * query = "INSERT INTO VCC_SUBSCRIPTION_MASTER(MSISDN," +
					 * "SERVICE_TYPE,EXPIRY_DATE,RATE_PLAN,STATUS,DATE_REGISTERED,SERVICE_FLAG) VALUES(?,?,sysdate+"
					 * + rateModel.getSubValidity() + ",?,?,sysdate,?)";
					 */
				} else if (AppConfig.config.getInt("DB_CON_PARAM", 1) == 1) {
					if(multiTableEnable==1)
					{
						query = "INSERT INTO "+tableName+"(MSISDN,"
								+ "SERVICE_TYPE,EXPIRY_DATE,RATE_PLAN,STATUS,DATE_REGISTERED,SERVICE_FLAG) VALUES(?,?,NOW()+ INTERVAL "
								+ rateModel.getSubValidity() + " DAY,?,?,NOW(),?)";
					}
					else
					{
						query = "INSERT INTO VCC_SUBSCRIPTION_MASTER(MSISDN,"
								+ "SERVICE_TYPE,EXPIRY_DATE,RATE_PLAN,STATUS,DATE_REGISTERED,SERVICE_FLAG) VALUES(?,?,NOW()+ INTERVAL "
								+ rateModel.getSubValidity() + " DAY,?,?,NOW(),?)";
					}
					/*
					 * query = "INSERT INTO VCC_SUBSCRIPTION_MASTER(MSISDN," +
					 * "SERVICE_TYPE,EXPIRY_DATE,RATE_PLAN,STATUS,DATE_REGISTERED,SERVICE_FLAG) VALUES(?,?,NOW()+ INTERVAL "
					 * + rateModel.getSubValidity() + " DAY,?,?,NOW(),?)";
					 */
				}
				logger.info(String.format("[%s] [%s] [%s] [%s] before query [%s]", vnRequest.getMsisdn(), vnRequest.getTid(),
						vnRequest.getServiceType(),vnRequest.getStatus(), query));
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				result = jdbcTemplate.update(query, new Object[] { vnRequest.getMsisdn(), vnRequest.getServiceType(),
						rateModel.getPlanId(), vnRequest.getStatus(), serviceFlag.toString() });
				logger.debug(String.format("[%s] [%s] [%s] after query [%s]", vnRequest.getMsisdn(), vnRequest.getTid(),
						vnRequest.getServiceType(), query));
				return result;
			}
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode [VCC-RE-90003] [Null Pointer Exception while saving data in VCC_SUBSCRIPTION_MASTER] Error[ "
							+ npe.getMessage() + "]");
			return 0;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00019] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] [Exception while saving data in VCC_SUBSCRIPTION_MASTER] Error[" + e.getMessage() + "]");
			return 0;
		}

	}

	public boolean checkUserExistSubscriptionMaster(VccRequest vnRequest, VccRatePlanModel rateModel,
			VccChargingCodeModel chargingCode) {
		boolean isExist = false;
		try {

			// added by sanchit atri on 17-sep-2020
			String query="";
			if(multiTableEnable==1)
			{
				String lastDigit=vnRequest.getMsisdn().substring(vnRequest.getMsisdn().length()-1);
				String tableName="VCC_SUBSCRIPTION_MASTER_"+lastDigit;
				
				 query = "SELECT COUNT(*) AS CNT FROM "+tableName+" WHERE MSISDN = ? AND SERVICE_TYPE= ?";
						
			}
			else
			{
				 query = "SELECT COUNT(*) AS CNT FROM VCC_SUBSCRIPTION_MASTER"
						+ " WHERE MSISDN = ? AND SERVICE_TYPE= ?";
			}
			
			/*
			 * String query = "SELECT COUNT(*) AS CNT FROM VCC_SUBSCRIPTION_MASTER" +
			 * " WHERE MSISDN = ? AND SERVICE_TYPE= ?";
			 */
			logger.info(String.format("[%s] [%s] [%s] before query [%s]", vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			isExist = jdbcTemplate.queryForObject(query,
					new Object[] { vnRequest.getMsisdn(), vnRequest.getServiceType() }, Boolean.class);
			logger.debug(String.format("[%s] [%s] [%s] after query [%s]", vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), query));
			return isExist;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00020] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] [Exception while checking user existence in VCC_SUBSCRIPTION_MASTER] Error[ " + e.getMessage()
					+ "]");
			return false;
		}

	}

	public int deleteUserDetailByServiceTypeAndMsisdn(VccRequest vnRequest) {
		int result = 0;
		try {
			
			// added by sanchit atri on 17-sep-2020

			String query="";
			if(multiTableEnable==1)
			{
				String lastDigit=vnRequest.getMsisdn().substring(vnRequest.getMsisdn().length()-1);
				String tableName="VCC_SUBSCRIPTION_MASTER_"+lastDigit;
				
				 query = "DELETE FROM "+tableName+" WHERE " + "MSISDN = ? AND SERVICE_TYPE = ?";

			}
			else
			{
				 query = "DELETE FROM VCC_SUBSCRIPTION_MASTER WHERE " + "MSISDN = ? AND SERVICE_TYPE = ?";

			}
			/*
			 * String query = "DELETE FROM VCC_SUBSCRIPTION_MASTER WHERE " +
			 * "MSISDN = ? AND SERVICE_TYPE = ?";
			 */			logger.info(String.format("[%s] [%s] [%s] before query [%s]", vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			result = jdbcTemplate.update(query, new Object[] { vnRequest.getMsisdn(), vnRequest.getServiceType() });
			logger.debug(String.format("[%s] [%s] [%s] after query [%s]", vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), query));
			return result;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00021] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] [Exception while deleting user detail from VCC_SUBSCRIPTION_MASTER] Error[" + e.getMessage()
					+ "]");
			logger.info(String.format("[%s] [%s] [%s] [%s] Exception: while " + "delete user detail [%s]",
					vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId(), e));
			return 0;
		}
	}

	public boolean updateVccSubscriptionMasterProfileNumber(VccRequest vnRequest) {
		try {
			String query="";

			if(multiTableEnable==1)
			{
				String lastDigit=vnRequest.getMsisdn().substring(vnRequest.getMsisdn().length()-1);
				String tableName="VCC_SUBSCRIPTION_MASTER_"+lastDigit;
				 query = "update "+tableName+" SET MSISDN = ? where " + "MSISDN = ?";

			}
			else
			{
				 query = "update VCC_SUBSCRIPTION_MASTER SET MSISDN = ? where " + "MSISDN = ?";
			}
			
			/*
			 * String query = "update VCC_SUBSCRIPTION_MASTER SET MSISDN = ? where " +
			 * "MSISDN = ?";
			 */			logger.info(String.format("[%s] [%s] [%s] before query [%s]", vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int result = jdbcTemplate.update(query,
					new Object[] { vnRequest.getChangedMsisdn(), vnRequest.getMsisdn() });
			logger.debug(String.format("[%s] [%s] [%s] after query [%s]", vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), query));
			if (result > 0)
				return true;
			else
				return false;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00022] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] [Exception while update user's msisdn in VCC_SUBSCRIPTION_MASTER] Error[ " + e.getMessage()
					+ "]");
			logger.info(String.format("msisdn [%s] servicetype [%s] exception: [%s]", vnRequest.getMsisdn(),
					vnRequest.getServiceType(), e));
			return false;
		}

	}

	public int updateSubProfile(VccRequest vmRequest, String status) {
		try {

			String query="";
			if(multiTableEnable==1)
			{
				String lastDigit=vmRequest.getMsisdn().substring(vmRequest.getMsisdn().length()-1);
				String tableName="VCC_SUBSCRIPTION_MASTER_"+lastDigit;
				 query = "update "+tableName+" SET STATUS = ? where " + "MSISDN = ? and SERVICE_TYPE=?";
			}
			else
			{
				 query = "update VCC_SUBSCRIPTION_MASTER SET STATUS = ? where " + "MSISDN = ? and SERVICE_TYPE=?";
			}
			
			/*
			 * String query = "update VCC_SUBSCRIPTION_MASTER SET STATUS = ? where " +
			 * "MSISDN = ? and SERVICE_TYPE=?";
			 */
			logger.info(String.format("msisdn [%s] service type [%s] before query [%s]", vmRequest.getMsisdn(),
					vmRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int result = jdbcTemplate.update(query,
					new Object[] { status, vmRequest.getMsisdn(), vmRequest.getServiceType() });
			logger.debug(String.format("msisdn [%s] service type [%s] after query [%s]", status,
					vmRequest.getServiceType(), vmRequest.getMsisdn(), query));
			if (result > 0) {
				logger.info("Profile updated successfully in VCC_SUBSCRIPTION_MASTER");
				return 1;
			} else {
				logger.info("There is any error in Profile updation in VCC_SUBSCRIPTION_MASTER");
				return -1;
			}
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00024] TID[" + vmRequest.getTid() + "] MSISDN[" + vmRequest.getMsisdn()
					+ "] ServiceType[" + vmRequest.getServiceType()
					+ "] [Exception while updating user profile status] Error[" + e.getMessage() + "]");
			logger.info(String.format("msisdn [%s] servicetype [%s] exception: [%s]", vmRequest.getMsisdn(),
					vmRequest.getServiceType(), e));
			return -1;
		}

	}

	public int updateProfile(VccRequest vmRequest, VccRatePlanModel rateModel, VccChargingCodeModel chargingCode) {
		try {

			String query="";
			if(multiTableEnable==1)
			{
				String lastDigit=vmRequest.getMsisdn().substring(vmRequest.getMsisdn().length()-1);
				String tableName="VCC_SUBSCRIPTION_MASTER_"+lastDigit;
				 query = "update "+tableName+" SET RATE_PLAN= ? where " + "MSISDN = ? and SERVICE_TYPE=?";
			}
			else
			{
				 query = "update VCC_SUBSCRIPTION_MASTER SET RATE_PLAN= ? where " + "MSISDN = ? and SERVICE_TYPE=?";
			}
			
			/*
			 * String query = "update VCC_SUBSCRIPTION_MASTER SET RATE_PLAN= ? where " +
			 * "MSISDN = ? and SERVICE_TYPE=?";
			 */
			logger.info(String.format("msisdn [%s] service type [%s] before query [%s]", rateModel.getPlanId(),
					vmRequest.getMsisdn(), vmRequest.getServiceType(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int result = jdbcTemplate.update(query,
					new Object[] { rateModel.getPlanId(), vmRequest.getMsisdn(), vmRequest.getServiceType() });
			logger.debug(String.format("msisdn [%s] service type [%s] after query [%s]", rateModel,
					vmRequest.getServiceType(), vmRequest.getMsisdn(), query));
			if (result > 0) {
				logger.info("Profile updated successfully in VCC_SUBSCRIPTION_MASTER");
				return 1;
			} else {
				logger.info("There is any error in Profile updation in VCC_SUBSCRIPTION_MASTER");
				return -1;
			}
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00026] TID[" + vmRequest.getTid() + "] MSISDN[" + vmRequest.getMsisdn()
					+ "] ServiceType[" + vmRequest.getServiceType()
					+ "] [Exception while update user's RatePlan] Error[ " + e.getMessage() + "]");
			logger.info(String.format("msisdn [%s] servicetype [%s] exception: [%s]", vmRequest.getMsisdn(),
					vmRequest.getServiceType(), e));
			return -1;
		}

	}

	public int activeSubscriberNum() {
		int activeSubscriber = 0;
		try {

			String query ="";
			if(multiTableEnable==1)
			{
				String tableName="";
				int count=0;
				for(int i=0;i<=9;i++)
				{
					count=0;
					tableName="VCC_SUBSCRIPTION_MASTER_"+i;
					query = "select count(*) as  subcount  from "+tableName+" where status='A'";
					logger.debug("Inside activeSubscriberNum() and query >>>>>>>>>>>>>>>[" + query + "]");
					JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
					count = jdbcTemplate.queryForObject(query, Integer.class);
					activeSubscriber=activeSubscriber+count;
					
				}
			}
			else
			{
				 query = "select count(*) as  subcount  from VCC_SUBSCRIPTION_MASTER where status='A'";
				logger.debug("Inside activeSubscriberNum() and query [" + query + "]");
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				activeSubscriber = jdbcTemplate.queryForObject(query, Integer.class);
			}
			//String query = "select count(*) as  subcount  from VCC_SUBSCRIPTION_MASTER where status='A'";
			//logger.debug("Inside activeSubscriberNum() and query [" + query + "]");
			//JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			//activeSubscriber = jdbcTemplate.queryForObject(query, Integer.class);
			
			logger.info("Total subscriber is [" + activeSubscriber + "]");

		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00028] [Exception while getting Active user Count] Error[ "
					+ e.getMessage() + "]");
			logger.info("exception inside activeSubscriberNum()" + e.getMessage());
			e.printStackTrace();
			activeSubscriber=-1;
		}

		return activeSubscriber;
	}
	
	public String getSubType(VccRequest vnRequest) {
		logger.info(String.format("[%s] [%s] [%s]", vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType()));
		String subType = null;
		try {
			String oST = null;
			if(vnRequest.getServiceType().equalsIgnoreCase("0001")) {
				oST = "0010";
			} else if(vnRequest.getServiceType().equalsIgnoreCase("0010")) {
				oST = "0001";
			} else {
				return null;
			}
			// added by sanchit atri on 17-sep-2020

			String query="";
			if(multiTableEnable==1)
			{
				String lastDigit=vnRequest.getMsisdn().substring(vnRequest.getMsisdn().length()-1);
				String tableName1="VCC_AUTH_USER_"+lastDigit;
				String tableName2="vcc_subscription_master_"+lastDigit;
				
				 query = "SELECT b.SUB_TYPE FROM "+tableName2+" a, "+tableName1+" b WHERE a.MSISDN=b.MSISDN AND a.MSISDN = ? AND a.SERVICE_TYPE = ?";
			}
			else
			{
				 query = "SELECT b.SUB_TYPE FROM vcc_subscription_master a, vcc_auth_user b WHERE a.MSISDN=b.MSISDN AND a.MSISDN = ? AND a.SERVICE_TYPE = ?";
			}
			/*
			 * String query =
			 * "SELECT b.SUB_TYPE FROM vcc_subscription_master a, vcc_auth_user b WHERE a.MSISDN=b.MSISDN AND a.MSISDN = ? AND a.SERVICE_TYPE = ?"
			 * ;
			 */
			logger.info("["+query+"] ["+vnRequest.getMsisdn()+ ","+ oST+"]");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			subType = jdbcTemplate.queryForObject(query, new Object[] { vnRequest.getMsisdn(), oST }, String.class);
			logger.info("######### subType="+subType);
			return subType;
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00020] TID[" + vnRequest.getTid() + "] MSISDN[" + vnRequest.getMsisdn()
					+ "] ServiceType[" + vnRequest.getServiceType()
					+ "] [Exception while getSubType] Error[ " + e.getMessage()
					+ "]");
			return null;
		}
	}
	
	
	public int countForMultiServiceSubscriber(VccRequest vnRequest) {
		int numSubscriber = -1;
		try {

			String query="";
			if(multiTableEnable==1)
			{
				String lastDigit=vnRequest.getMsisdn().substring(vnRequest.getMsisdn().length()-1);
				String tableName="vcc_subscription_master_"+lastDigit;
				
				 query = "select count(*) as  subcount  from "+tableName+" where MSISDN = ? AND SERVICE_TYPE IN('0001', '0010')";
				
			}
			else
			{
				 query = "select count(*) as  subcount  from VCC_SUBSCRIPTION_MASTER where MSISDN = ? AND SERVICE_TYPE IN('0001', '0010')";
			}
			/*
			 * String query =
			 * "select count(*) as  subcount  from VCC_SUBSCRIPTION_MASTER where MSISDN = ? AND SERVICE_TYPE IN('0001', '0010')"
			 * ;
			 */
			logger.debug("Inside countForMultiService() and query [" + query + "]");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			numSubscriber = jdbcTemplate.queryForObject(query, new Object[] { vnRequest.getMsisdn() }, Integer.class);
			logger.info("numSubscriber [" + numSubscriber + "] msisdn ["+vnRequest.getMsisdn()+"]");
		} catch (Exception e) {
			errorLogger.error("ErrorCode [VCC-RE-00028] [Exception while getting countForMultiServiceSubscriber] Error[ "
					+ e.getMessage() + "]");
			logger.info("exception inside countForMultiServiceSubscriber()" + e.getMessage());
			e.printStackTrace();
		}
		return numSubscriber;
	}

}
