package com.telemune.vcc.rule.domain;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.common.CacheLoader;
import com.telemune.vcc.rule.common.VccCache;
import com.telemune.vcc.rule.model.VccSeries;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.util.AppContext;

public class VccSeriesRange {

	private DataSource dataSource;
	final static Logger logger = Logger.getLogger(VccSeriesRange.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	
	public static List<VccSeries> vccSeries = null;

	static {
		loadSeriesInCache();
	}

	public VccSeriesRange() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public boolean isExistWithinGroup(String msisdn1, String groupName) {
		boolean isExist = false;
		int startValue = 0;
		int endValue = 0;
		BigInteger msisdn;
		try
			{
			msisdn = new BigInteger(msisdn1);
		for (VccSeries series : vccSeries) {
			
				
				startValue = series.getStartRange().compareTo(msisdn);
				endValue = series.getEndRange().compareTo(msisdn);
				logger.debug("msisdn [" + msisdn + "] start [" + series.getStartRange() + "] end " + "["
						+ series.getEndRange() + "] startValue: " + startValue + " endValue: " + endValue + " group: "
						+ series.getGroupName() + " check for: " + groupName);
				if (((startValue == -1 || startValue == 0) && (endValue == 1 || endValue == 0))
						&& series.getGroupName().equals(groupName)) {
					return true;
				}
			
		}
			}
		 catch (Exception e) {
             errorLogger.error("ErrorCode [VCC-RE-00008]"
                             + "MSISDN["
                             + msisdn1+"] Group Name ["+groupName
                             + "]  [Exception in is isExistWithinGroup] Error["+e.getMessage()+"]");
             
             isExist = false;
     }

		return isExist;
	}

	public boolean isUserExistWithInRange(VccRequest vnRequest) {
		boolean isExist = false;
		String msisdn;
		boolean isWhitelist = false;
		boolean isBlacklist = false;
		try {
			if (vnRequest.getAction() == 2 || vnRequest.getAction() == 3) {
				msisdn = vnRequest.getChangedMsisdn();
			} else {
				msisdn = vnRequest.getMsisdn();
			}
			isWhitelist = this.isExistWithinGroup(msisdn, "whitelist");
			isBlacklist = this.isExistWithinGroup(msisdn, "blacklist");
			if (!isWhitelist)
				isExist = true;
			else
				isExist = isBlacklist;
			logger.info(
					String.format("[%s] [%s] [%s] whitelist [%s] blacklist [%s] isexist [%s]", vnRequest.getMsisdn(),
							vnRequest.getTid(), vnRequest.getServiceType(), isWhitelist, isBlacklist, isExist));
			return isExist;
		} catch (Exception e) {
            errorLogger.error("ErrorCode [VCC-RE-00008] TID["
                    + vnRequest.getTid()
                    + "] MSISDN["
                    + vnRequest.getMsisdn()
                    + "] [Exception in WhiteList Checking] Error["+e.getMessage()+"]");
    logger.info(String.format(
                    "[%s] [%s] [%s] Exception: while whitelist checking [%s]",
                    vnRequest.getMsisdn(), vnRequest.getTid(),
                    vnRequest.getServiceType(), e));
    isExist = false;
}

		return isExist;
	}

	public boolean checkForBlackList(VccRequest vnRequest) {
		boolean isExist = false;
		String query = "";
		try {
			query = "select count(*) from VCC_SERIES_GROUP A, VCC_SERIES_RANGE B where "
					+ "A.GROUP_NAME = 'blacklist' and A.GROUP_ID=B.GROUP_ID AND  B.START_RANGE <= "
					+ vnRequest.getMsisdn() + " AND B.END_RANGE >=" + vnRequest.getMsisdn();
			logger.info(String.format("[%s] [%s] [%s] [%s] query: [%s]", vnRequest.getMsisdn(), vnRequest.getTid(),
					vnRequest.getServiceType(), vnRequest.getActionId(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			isExist = jdbcTemplate.queryForObject(query, new Object[] {}, Boolean.class);
			logger.debug(String.format("[%s] [%s] [%s] [%s] after query: [%s]", vnRequest.getMsisdn(),
					vnRequest.getTid(), vnRequest.getServiceType(), vnRequest.getActionId(), query));
		}  catch (Exception e) {
            errorLogger.error("ErrorCode [VCC-RE-00009] TID["
                    + vnRequest.getTid()
                    + "] MSISDN["
                    + vnRequest.getMsisdn()
                    + "] ServiceType["+vnRequest.getServiceType()+"] [Exception in BlackList Checking] Error[" + e.getMessage()+"]");
    logger.info(String.format(
                    "[%s] [%s] [%s] Exception: while blacklist checking [%s]",
                    vnRequest.getMsisdn(), vnRequest.getTid(),
                    vnRequest.getServiceType(), e));
    isExist = false;
}

		return isExist;
	}

	public static void loadSeriesInCache() {
		String query = "";

		query = "SELECT A.GROUP_ID AS GROUP_ID,A.GROUP_NAME AS GROUP_NAME,B.TYPE AS TYPE,B.START_RANGE AS START_RANGE,"
				+ "B.END_RANGE END_RANGE FROM vcc_series_group A,vcc_series_range B WHERE A.GROUP_ID=B.GROUP_ID";
		DataSource dataSource = (DataSource) AppContext.context.getBean("dataSource");
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		try {
			vccSeries = jdbcTemplate.query(query, new RowMapper<VccSeries>() {
				@Override
				public VccSeries mapRow(ResultSet rs, int rownumber) throws SQLException {
					VccSeries series = new VccSeries();
					series.setGroupId(rs.getInt("GROUP_ID"));
					series.setGroupName(rs.getString("GROUP_NAME"));
					series.setStartRange(new BigInteger(rs.getString("START_RANGE")));
					series.setEndRange(new BigInteger(rs.getString("END_RANGE")));
					series.setType(rs.getString("TYPE"));
					return series;
				}
			});
			logger.debug("Series Cache load successfully......");
			VccCache.map.put(CacheLoader._sr_prefix, "Reload vcc series cache",
					AppConfig.config.getInt("vcc_series_reange_cache_time", 12), TimeUnit.HOURS);
		} catch (Exception e) {
            errorLogger.error("ErrorCode [VCC-RE-00010] [Exception while loading series range and series group] Error[" + e.getMessage()+"]");
            e.printStackTrace();
    }

	}

	public static void main(String[] args) {
		String msisdn = "911100000000";
		System.out.println("size: " + vccSeries.size() + " exist: "
				+ new VccSeriesRange().isExistWithinGroup(msisdn, "fixedline"));
	}
}
