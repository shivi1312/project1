package com.telemune.vcc.rule.domain;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.google.gson.Gson;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.model.VccCallbackModel;
import com.telemune.vcc.rule.request.VccRequest;
import com.telemune.vcc.util.AppContext;

public class VccCallback {
    
	
	final static Logger logger = Logger.getLogger(VccCallback.class);
    final static Logger errorLogger = Logger.getLogger("errorLogger");
    @SuppressWarnings("unused")
	public static void main(String [] args){
    	Gson gson = new Gson();
        VccCallbackModel callback = new VccCallbackModel();
        callback.setMsisdn("971880054434");
        callback.setLang(1);
        callback.setTid("1312321423423");
        callback.setStatus("success");
        callback.setServiceType("0010");
        callback.setCallbackStatus("I");
        callback.setReqInterface("U");
        callback.setCallback_time("");
       // new VccCallback().storeCallback(gson.fromJson(gson.toJson(callback),VccRequest.class));
    }
    
    private DataSource dataSource;

    public VccCallback() {
        this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
    }
    public int storeCallback(VccRequest vnRequest) {
        String query = "INSERT INTO VCC_CALLBACK(TID,MSISDN,STATUS,SERVICE_TYPE,"
                        + "CALLBACK_COUNTER,REQ_TIME,CALLBACK_TIME,CALLBACK_STATUS,INTERFACE,"
                        + "LANG,MAILBOX_TYPE,TYPE,DESCRIPTION,ACTION,ACT_TRG)VALUES(?,?,"
                        + "'P',?,0,now(),now(),'I',?,?,?,?,?,?,?)";
        int result = 0;
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        try {
        	vnRequest.setType(AppConfig.config.getString("action.id."+vnRequest.getActionId()+".for","NA"));
        	logger.info(new Gson().toJson(vnRequest));
        	
            result = jdbcTemplate.update(query,new Object[] { vnRequest.getTid(),
                    vnRequest.getMsisdn(), vnRequest.getServiceType(),
                    vnRequest.getInterFace(),vnRequest.getLang(),vnRequest.getPlanName(),
                    vnRequest.getType(),vnRequest.getDescription(),vnRequest.getActionType(),vnRequest.getActTrg()});
            logger.info(String.format(query.replaceAll("\\?", "%s"),
                    vnRequest.getTid(),vnRequest.getMsisdn(),'P', vnRequest.getServiceType(),0,'I',
                    vnRequest.getInterFace(),vnRequest.getLang(),vnRequest.getPlanName(),
                    vnRequest.getType(),vnRequest.getDescription(),vnRequest.getActionType(),vnRequest.getActTrg()));
            
           
        }catch(Exception e){
            logger.info(String.format("[%s] [%s] [%s] Exception: while store callback [%s]",
                    vnRequest.getMsisdn(), vnRequest.getTid(), vnRequest.getServiceType(), e));
        }
        return result;
    }
}