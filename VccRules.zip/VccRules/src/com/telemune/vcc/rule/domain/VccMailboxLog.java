package com.telemune.vcc.rule.domain;

import java.util.Arrays;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.model.VccMailboxLogModel;
import com.telemune.vcc.util.AppContext;

public class VccMailboxLog {

	final static Logger logger = Logger.getLogger(VccMailboxLog.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private DataSource dataSource;

	public VccMailboxLog() {
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	}

	public boolean saveTransactionLog(VccMailboxLogModel vccLog) {
		String userInterface = "";
		String type = "";
		List<Object> listInterfaces = AppConfig.config.getList("vcc.interfaces",
				Arrays.asList("ivr", "sms", "custcare", "ussd", "crm", "web"));
		userInterface = vccLog.getInterFace();
		try {
			if (vccLog.getType().equals("sub")) {
				type = "S";
			} else if (vccLog.getType().equals("unsub")) {
				type = "U";
			} else {
				type = vccLog.getType();
			}
			if (listInterfaces.contains(vccLog.getInterFace().toLowerCase())) {
				userInterface = AppConfig.config.getString("interface." + vccLog.getInterFace().toLowerCase(),
						userInterface);
				logger.debug(String.format("msisdn [%s] service type [%s] interface found: [%s] new interface [%s]",
						vccLog.getMsisdn(), vccLog.getServiceType(), vccLog.getInterFace().toLowerCase(),
						userInterface));
			}
			String updatedBy = "";
			if (vccLog.getUpdatedBy() == null)
				updatedBy = vccLog.getMsisdn();
			else
				updatedBy = vccLog.getUpdatedBy();
			String query = "";
			
			String msisdn=vccLog.getMsisdn().trim();
			String lastDigit=msisdn.substring(msisdn.length() - 1);
			String tableName="VCC_MAILBOX_LOG"+"_"+lastDigit;
			
			
			
			if (AppConfig.config.getInt("DB_CON_PARAM", 0) == 0) {
				query = "INSERT INTO "+tableName+"(SERVER_ID,MSISDN,REQUEST_DATE,"
						+ "INTERFACE,MAILBOX_TYPE,SERVICE_TYPE,UPDATED_BY,DESCRIPTION,TYPE,"
						+ "CDR_STATUS,SUB_TYPE)VALUES(?,?,sysdate,?,?,?,?,?,?,?,?)";
			} else if (AppConfig.config.getInt("DB_CON_PARAM", 1) == 1) {
				query = "INSERT INTO "+tableName+"(SERVER_ID,MSISDN,REQUEST_DATE,"
						+ "INTERFACE,MAILBOX_TYPE,SERVICE_TYPE,UPDATED_BY,DESCRIPTION,TYPE,"
						+ "CDR_STATUS,SUB_TYPE)VALUES(?,?,now(),?,?,?,?,?,?,?,?)";
			}
			logger.info(String.format(
					"msisdn [%s] service type [%s] interface found: [%s] new interface [%s] Type [%s] before query [%s]",
					vccLog.getMsisdn(), vccLog.getServiceType(), vccLog.getInterFace().toLowerCase(), userInterface,type,
					query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			int count = jdbcTemplate
					.update(query,
							new Object[] { vccLog.getServerId(), vccLog.getMsisdn(), userInterface,
									vccLog.getMailboxType(), vccLog.getServiceType(), updatedBy,
									vccLog.getDescription(), type, vccLog.getCdrStatus(), vccLog.getSubType() });
			logger.debug(String.format("msisdn [%s] service type [%s] after query [%s]", vccLog.getMsisdn(),
					vccLog.getServiceType(), query));
			if (count > 0)
				return true;
			else
				return false;
		} catch (NullPointerException npe) {
			errorLogger.error("ErrorCode [VCC-RE-90003] [Null Pointer Exception while saving Transaction Logs] Error[ "
					+ npe.getMessage() + "]");
			return false;
		} catch (Exception e) {
			errorLogger.error(
					"ErrorCode [VCC-RE-00056] MSISDN[" + vccLog.getMsisdn() + "] ServiceType[" + vccLog.getServiceType()
							+ "] [Exception while saving Transaction Logs] Error[" + e.getMessage() + "]");
			e.printStackTrace();
			logger.info("Exception while save logs: " + e);
			return false;
		}

	}

}
