package com.telemune.vcc.rule.request;

public class VccRequest implements java.io.Serializable {
	private static final long serialVersionUID = -8861233471459504281L;
	public String msisdn;
	public String msisdnWithoutCountryCode;
	public String changedMsisdn = "";
	public int actionId;
	public String tid;
	private String serviceType;
	private String planName = "NA";
	private String interFace;
	private String channel;
	private int lang;
	private int serverId;
	private String reqBy;
	private Integer action = 0;
	private boolean changePlan = false;
	private Integer actTrg = 4;
	private String password="";
	private String requested_system;
	private String sub_channel;
	private String demand_name;
	private String demand_value;
	private String account_number;
	private String actionType;
	private String parentOrderNumber;
	private String receivedTime;
	private String status;
	private String subType="N";
	private String description = "NA";
	private String type = "NA";
	private boolean notification=true;
	private boolean cbcmEnable = true;
	private String updatedBy="";
	
	private boolean actVal=true;
	
	
	
	
	

	public boolean isActVal() {
		return actVal;
	}

	public void setActVal(boolean actVal) {
		this.actVal = actVal;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public boolean getCbcmEnable() {
		return cbcmEnable;
	}

	public void setCbcmEnable(boolean cbcmEnable) {
		this.cbcmEnable = cbcmEnable;
	}

	public boolean getNotification() {
		return notification;
	}

	public void setNotification(boolean notification) {
		this.notification = notification;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRequested_system() {
		return requested_system;
	}

	public void setRequested_system(String requested_system) {
		this.requested_system = requested_system;
	}

	public String getSub_channel() {
		return sub_channel;
	}

	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}

	public String getDemand_name() {
		return demand_name;
	}

	public void setDemand_name(String demand_name) {
		this.demand_name = demand_name;
	}

	public String getDemand_value() {
		return demand_value;
	}

	public void setDemand_value(String demand_value) {
		this.demand_value = demand_value;
	}

	public String getAccount_number() {
		return account_number;
	}

	public void setAccount_number(String account_number) {
		this.account_number = account_number;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getParentOrderNumber() {
		return parentOrderNumber;
	}

	public void setParentOrderNumber(String parentOrderNumber) {
		this.parentOrderNumber = parentOrderNumber;
	}

	public String getReceivedTime() {
		return receivedTime;
	}

	public void setReceivedTime(String receivedTime) {
		this.receivedTime = receivedTime;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getMsisdnWithoutCountryCode() {
		return msisdnWithoutCountryCode;
	}

	public void setMsisdnWithoutCountryCode(String msisdnWithoutCountryCode) {
		this.msisdnWithoutCountryCode = msisdnWithoutCountryCode;
	}
	
	public String getChangedMsisdn() {
		return changedMsisdn;
	}

	public void setChangedMsisdn(String changedMsisdn) {
		this.changedMsisdn = changedMsisdn;
	}

	public int getActionId() {
		return actionId;
	}

	public void setActionId(int actionId) {
		this.actionId = actionId;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getInterFace() {
		return interFace;
	}

	public void setInterFace(String interFace) {
		this.interFace = interFace;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public int getLang() {
		return lang;
	}

	public void setLang(int lang) {
		this.lang = lang;
	}

	public int getServerId() {
		return serverId;
	}

	public void setServerId(int serverId) {
		this.serverId = serverId;
	}

	public String getReqBy() {
		return reqBy;
	}

	public void setReqBy(String reqBy) {
		this.reqBy = reqBy;
	}

	public Integer getAction() {
		return action;
	}

	public void setAction(Integer action) {
		this.action = action;
	}

	public boolean getChangePlan() {
		return changePlan;
	}

	public void setChangePlan(boolean changePlan) {
		this.changePlan = changePlan;
	}

	public Integer getActTrg() {
		return actTrg;
	}

	public void setActTrg(Integer actTrg) {
		this.actTrg = actTrg;
	}

	@Override
	public String toString() {
		return "VccRequest [msisdn=" + msisdn + ", msisdnWithoutCountryCode=" + msisdnWithoutCountryCode
				+ ", changedMsisdn=" + changedMsisdn + ", actionId=" + actionId + ", tid=" + tid + ", serviceType="
				+ serviceType + ", planName=" + planName + ", interFace=" + interFace + ", channel=" + channel
				+ ", lang=" + lang + ", serverId=" + serverId + ", reqBy=" + reqBy + ", action=" + action
				+ ", changePlan=" + changePlan + ", actTrg=" + actTrg + ", password=" + password + ", requested_system="
				+ requested_system + ", sub_channel=" + sub_channel + ", demand_name=" + demand_name + ", demand_value="
				+ demand_value + ", account_number=" + account_number + ", actionType=" + actionType
				+ ", parentOrderNumber=" + parentOrderNumber + ", receivedTime=" + receivedTime + ", status=" + status
				+ ", subType=" + subType + "]";
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	
	
}
