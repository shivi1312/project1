package com.telemune.vcc.rule.response;

import java.util.HashMap;

public class VnResponse implements java.io.Serializable {
	private static final long serialVersionUID = 4378052788447738920L;
	private String msisdn;
	private String actionId;
	private String tid;
	private String msg;
	private String result;
	private VnInfo info;
	private String subType = "N";
	private String transactionId;
    private String accountNumber;
    private String status;
    private String errorCode;
    private String errorType;
    private String errorDescription;
    private String methodName;
    private String IMSI;

    private String responseCode;
    private String responseDescription;
    private String orderItemNumber;
    private String orderNumber;
    private String demandId;
    private String demandValue;
    private String state;
    private HashMap<String,String> activeTrigger;
    
    
    
    

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorType() {
		return errorType;
	}

	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public String getIMSI() {
		return IMSI;
	}

	public void setIMSI(String iMSI) {
		IMSI = iMSI;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseDescription() {
		return responseDescription;
	}

	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}

	public String getOrderItemNumber() {
		return orderItemNumber;
	}

	public void setOrderItemNumber(String orderItemNumber) {
		this.orderItemNumber = orderItemNumber;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getDemandId() {
		return demandId;
	}

	public void setDemandId(String demandId) {
		this.demandId = demandId;
	}

	public String getDemandValue() {
		return demandValue;
	}

	public void setDemandValue(String demandValue) {
		this.demandValue = demandValue;
	}

	public HashMap<String, String> getActiveTrigger() {
		return activeTrigger;
	}

	public void setActiveTrigger(HashMap<String, String> activeTrigger) {
		this.activeTrigger = activeTrigger;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getActionId() {
		return actionId;
	}

	public void setActionId(String actionId) {
		this.actionId = actionId;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public VnInfo getInfo() {
		return info;
	}

	public void setInfo(VnInfo info) {
		this.info = info;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "VnResponse [msisdn=" + msisdn + ", actionId=" + actionId + ", tid=" + tid + ", msg=" + msg + ", result="
				+ result + ", info=" + info + ", subType=" + subType + ", transactionId=" + transactionId
				+ ", accountNumber=" + accountNumber + ", status=" + status + ", errorCode=" + errorCode
				+ ", errorType=" + errorType + ", errorDescription=" + errorDescription + ", methodName=" + methodName
				+ ", IMSI=" + IMSI + ", responseCode=" + responseCode + ", responseDescription=" + responseDescription
				+ ", orderItemNumber=" + orderItemNumber + ", orderNumber=" + orderNumber + ", demandId=" + demandId
				+ ", demandValue=" + demandValue + ", state=" + state + ", activeTrigger=" + activeTrigger + "]";
	}
	
	
	
	
}
