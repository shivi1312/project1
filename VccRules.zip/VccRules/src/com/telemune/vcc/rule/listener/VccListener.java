package com.telemune.vcc.rule.listener;

import org.squirrelframework.foundation.exception.TransitionException;
import org.squirrelframework.foundation.fsm.Action;

import com.telemune.vcc.common.Data;

public interface VccListener {
	public void transitionBegin(String event);

	public void transitionComplete(String from, String to, String event,
			Data data);

	public void onActionExecException(Action<?, ?, ?, ?> action,
			TransitionException e);
}
