package com.telemune.vcc.rule.listener;

import org.apache.log4j.Logger;
import org.squirrelframework.foundation.exception.TransitionException;
import org.squirrelframework.foundation.fsm.Action;
import org.squirrelframework.foundation.fsm.annotation.OnActionExecException;
import org.squirrelframework.foundation.fsm.annotation.OnBeforeActionExecuted;
import org.squirrelframework.foundation.fsm.annotation.OnTransitionBegin;
import org.squirrelframework.foundation.fsm.annotation.OnTransitionComplete;

import com.google.gson.Gson;
import com.telemune.vcc.common.Data;
import com.telemune.vcc.common.VccState;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.rule.response.VnInfo;
import com.telemune.vcc.rule.response.VnResponse;

public class VoiceNoteVccListener implements VccListener {

	private final static Logger logger = Logger
			.getLogger(VoiceNoteVccListener.class);
	private Data dataObj;
	private VnResponse vnResponse = new VnResponse();
	private VnInfo vnCode = new VnInfo(false, false, 0);
	private Gson gson = new Gson();
	public VoiceNoteVccListener(Data data) {
		this.dataObj = data;
		this.dataObj.setVccState(new VccState());
	}

	@OnBeforeActionExecuted
	public void onBeforeActionExecuted(String from, String to, String event,
			Data data, int[] mOfN, Action<?, ?, ?, ?> action) {
		data.getVccState().setFrom(from);
		data.getVccState().setTo(to);
	}

	@OnTransitionBegin
	public void transitionBegin(String source) {

	}

	@Override
	@OnTransitionComplete
	public void transitionComplete(String from, String to, String event,
			Data data) {
		data.getVccEvent().setCurrentEvent(event);
		if (data.getVccEvent().getCurrentEvent()
				.equals(data.getVccEvent().getNextEvent())) {
			data.getVccEvent().setHasNextEvent(false);
		} else {
			data.getVccEvent().setHasNextEvent(true);
		}
		logger.debug(String.format(
				"Complete! [%s] [%s] [%s] source [%s] target "
						+ "[%s] event [%s] NextEvent [%s] haveNextEvent [%s]",
				data.getMsisdn(), data.getTid(), data.getActionId(), from, to,
				event, data.getVccEvent().getNextEvent(), data.getVccEvent()
						.getHasNextEvent()));
	}

	@Override
	@OnActionExecException
	public void onActionExecException(Action<?, ?, ?, ?> action,
			TransitionException e) {
		logger.info("Exception " + e);
		vnResponse.setResult("fail");
		vnResponse.setMsg(AppConfig.config.getString("unknown_error",
				"Getting unknown error!"));
		vnResponse.setMsisdn(dataObj.getMsisdn());
		vnResponse.setActionId("" + dataObj.getActionId());
		vnResponse.setTid(dataObj.getTid());
		vnResponse.setInfo(vnCode);
		dataObj.setVccResponse(gson.toJson(vnResponse));
	}
}
