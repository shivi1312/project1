package com.telemune.common;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import edu.emory.mathcs.util.net.ConnectionPool;


public class TcpConnectionPool {
	final static Logger logger = Logger.getLogger(TcpConnectionPool.class);

	@Autowired
	static
	Environment environment;
	
	private TcpConnectionPool() {

	}

	/*
	 * private static ConnectionPool mcaConPool = new ConnectionPool(
	 * environment.getProperty("mca_server_ip"),
	 * Integer.parseInt(environment.getProperty("mca_server_port")),
	 * Integer.parseInt(environment.getProperty("mca_socket_timeout")),
	 * Integer.parseInt(environment.getProperty("mca_server_pool_limit")));
	 */
	
	private static ConnectionPool ruleEngineConPool = new ConnectionPool("10.100.1.25",9111,20000,5);
			
	/*
	 * private static ConnectionPool ruleEngineConPool = new ConnectionPool(
	 * environment.getProperty("rule_engine_ip"),
	 * Integer.parseInt(environment.getProperty("rule_engine_port")),
	 * Integer.parseInt(environment.getProperty("rule_engine_socket_timeout")),
	 * Integer.parseInt(environment.getProperty("rule_engine_pool_limit")));
	 */

	public static ConnectionPool getRuleEngineConPool(String ip,int port,int socket_timeout,int poolLimit) {
		/*
		 * logger.debug("the rule engine ip [" +
		 * environment.getProperty("rule_engine_ip") + "] port [" +
		 * environment.getProperty("rule_engine_port") + "] ");
		 */
		
		return new ConnectionPool(ip,port,socket_timeout,poolLimit);
	}

	/*
	 * public static ConnectionPool getMcaConPool() { logger.debug("the mca ip [" +
	 * environment.getProperty("mca_server_ip") + "] port [" +
	 * environment.getProperty("mca_server_port") + "]");
	 * 
	 * return mcaConPool; }
	 */

}
