package com.telemune.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
@PropertySource("file:${PROPERTY_FILE_PATH}/vccApi/setting.properties")
public class MyProperties {
	
	@Value("${country.code}")
	private String countryCode;
	
	@Value("${msisdn_length}")
	private int msisdnLength;
	
	@Value("${multi_table_sub_check}")
	private int multiTableEnable;
	
	@Value("${db_type}")
	private String dbType;
	
	@Value("${default_sub_type}")
	private String defautSubType;
	
	@Value("${rule_engine_socket_timeout}")
	private int ruleSocketTimeOut;
	
	@Value("${rule_engine_ip}")
	private  String ruleEngineIp;
	
	@Value("${rule_engine_port}")
	private int ruleEnginePort;
	
	@Value("${rule_engine_pool_limit}")
	private int ruleEnginePoolLimit;
	
	@Value("${post_delay_after_sub}")
	private int postDelayAfterSub;
	
	@Value("${VM}")
	private String VmCode;
	
	@Value("${VN}")
	private String VnCode;
	
	@Value("${MCA}")
	private String McaCode;
	
	@Value("${retrieval_channel}")
	private String retrievalChannel;
	
	
	@Value("${app_Id}")
	private String appId;
	
	@Value("${default_interface}")
	private String defaultInterface;
	
	@Value("${unsub_actionId}")
	private String unsubActionId;

	@Value("${country_special_code}")
	private String specialCountryCode;
	
	@Value("${msisdn_length_with_CountryCode}")
	private int msisdnLengthWithCountryCode;
	
	@Value("${sub_actionId}")
	private String subActionId;
	
	@Value("${JWT_TOKEN_VALIDITY}")
	private static long jwtTokenValidity;
	
	public String getSubActionId() {
		return subActionId;
	}

	public void setSubActionId(String subActionId) {
		this.subActionId = subActionId;
	}

	public int getMsisdnLengthWithCountryCode() {
		return msisdnLengthWithCountryCode;
	}

	public void setMsisdnLengthWithCountryCode(int msisdnLengthWithCountryCode) {
		this.msisdnLengthWithCountryCode = msisdnLengthWithCountryCode;
	}

	public String getSpecialCountryCode() {
		return specialCountryCode;
	}

	public void setSpecialCountryCode(String specialCountryCode) {
		this.specialCountryCode = specialCountryCode;
	}

	public String getUnsubActionId() {
		return unsubActionId;
	}

	public void setUnsubActionId(String unsubActionId) {
		this.unsubActionId = unsubActionId;
	}

	public String getDefaultInterface() {
		return defaultInterface;
	}

	public void setDefaultInterface(String defaultInterface) {
		this.defaultInterface = defaultInterface;
	}

	public String getVmCode() {
		return VmCode;
	}

	public void setVmCode(String vmCode) {
		VmCode = vmCode;
	}

	public String getVnCode() {
		return VnCode;
	}

	public void setVnCode(String vnCode) {
		VnCode = vnCode;
	}

	public String getMcaCode() {
		return McaCode;
	}

	public void setMcaCode(String mcaCode) {
		McaCode = mcaCode;
	}

	public String getRetrievalChannel() {
		return retrievalChannel;
	}

	public void setRetrievalChannel(String retrievalChannel) {
		this.retrievalChannel = retrievalChannel;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public int getPostDelayAfterSub() {
		return postDelayAfterSub;
	}

	public void setPostDelayAfterSub(int postDelayAfterSub) {
		this.postDelayAfterSub = postDelayAfterSub;
	}

	public int getRuleSocketTimeOut() {
		return ruleSocketTimeOut;
	}

	public void setRuleSocketTimeOut(int ruleSocketTimeOut) {
		this.ruleSocketTimeOut = ruleSocketTimeOut;
	}

	public String getRuleEngineIp() {
		return ruleEngineIp;
	}

	public void setRuleEngineIp(String ruleEngineIp) {
		this.ruleEngineIp = ruleEngineIp;
	}

	public int getRuleEnginePort() {
		return ruleEnginePort;
	}

	public void setRuleEnginePort(int ruleEnginePort) {
		this.ruleEnginePort = ruleEnginePort;
	}

	public int getRuleEnginePoolLimit() {
		return ruleEnginePoolLimit;
	}

	public void setRuleEnginePoolLimit(int ruleEnginePoolLimit) {
		this.ruleEnginePoolLimit = ruleEnginePoolLimit;
	}

	public String getDefautSubType() {
		return defautSubType;
	}

	public void setDefautSubType(String defautSubType) {
		this.defautSubType = defautSubType;
	}

	public String getDbType() {
		return dbType;
	}

	public void setDbType(String dbType) {
		this.dbType = dbType;
	}

	public int getMultiTableEnable() {
		return multiTableEnable;
	}

	public void setMultiTableEnable(int multiTableEnable) {
		this.multiTableEnable = multiTableEnable;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public int getMsisdnLength() {
		return msisdnLength;
	}

	public void setMsisdnLength(int msisdnLength) {
		this.msisdnLength = msisdnLength;
	}

	
	public static long getJwtTokenValidity() {
		return jwtTokenValidity;
	}

	public static void setJwtTokenValidity(long jwtTokenValidity) {
		MyProperties.jwtTokenValidity = jwtTokenValidity;
	}

	@Override
	public String toString() {
		return "MyProperties [countryCode=" + countryCode + ", msisdnLength=" + msisdnLength + ", multiTableEnable="
				+ multiTableEnable + ", dbType=" + dbType + ", defautSubType=" + defautSubType + ", ruleSocketTimeOut="
				+ ruleSocketTimeOut + ", ruleEngineIp=" + ruleEngineIp + ", ruleEnginePort=" + ruleEnginePort
				+ ", ruleEnginePoolLimit=" + ruleEnginePoolLimit + ", postDelayAfterSub=" + postDelayAfterSub
				+ ", VmCode=" + VmCode + ", VnCode=" + VnCode + ", McaCode=" + McaCode + ", retrievalChannel="
				+ retrievalChannel + ", appId=" + appId + ", defaultInterface=" + defaultInterface + ", unsubActionId="
				+ unsubActionId + ", specialCountryCode=" + specialCountryCode + ", msisdnLengthWithCountryCode="
				+ msisdnLengthWithCountryCode + ", subActionId=" + subActionId + "]";
	}

	

	

	
	


	
	

}
