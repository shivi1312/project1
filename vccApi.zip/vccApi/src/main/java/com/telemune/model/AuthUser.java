package com.telemune.model;

import org.springframework.stereotype.Component;

@Component
public class AuthUser {
	
	private String lang;
	private String subType;
	private String serviceType;
	private String isSubscriber;
	private String msisdn;
	private String isSuccess;
	private String status;
	
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getIsSuccess() {
		return isSuccess;
	}
	public void setIsSuccess(String isSuccess) {
		this.isSuccess = isSuccess;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getIsSubscriber() {
		return isSubscriber;
	}
	public void setIsSubscriber(String isSubscriber) {
		this.isSubscriber = isSubscriber;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	@Override
	public String toString() {
		return "UssdApiResponseModel [lang=" + lang + ", subType=" + subType + ", serviceType=" + serviceType
				+ ", isSubscriber=" + isSubscriber + ", msisdn=" + msisdn + ", isSuccess=" + isSuccess + ", status="
				+ status + "]";
	}
	
	
	
	

}
