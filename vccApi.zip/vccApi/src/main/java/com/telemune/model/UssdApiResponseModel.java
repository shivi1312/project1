package com.telemune.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;



@XmlRootElement(name = "response")
@XmlSeeAlso(Var.class)
@XmlAccessorType(XmlAccessType.FIELD)
@Component
public class UssdApiResponseModel implements java.io.Serializable{
	@XmlTransient
	private String lang;
	@XmlTransient
	private String subType;
	@XmlTransient
	private String serviceType;
	@XmlTransient
	private int isSubscriber;
	@XmlTransient
	private String msisdn;
	@XmlTransient
	private int isSuccess;
	@XmlTransient
	private String status;
	
	@XmlTransient
	private int planId;
	@XmlTransient
	private String isValidUser;
	
	@XmlElement(name = "var")
	Var varLang;
	@XmlElement(name = "var")
	Var varSubType;
	@XmlElement(name = "var")
	Var varServiceType;
	@XmlElement(name = "var")
	Var varIsSubscriber;
	@XmlElement(name = "var")
	Var varMsisdn;
	@XmlElement(name = "var")
	Var varIsSuccess;
	@XmlElement(name = "var")
	Var varStatus;
	@XmlElement(name = "var")
	Var varRatePlan;
	@XmlElement(name = "var")
	Var varPlanId;
	@XmlElement(name = "var")
	Var varIsValidUser;
	
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
		varPlanId = new Var("planId", "" + planId);
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
		varStatus = new Var("status", "" + status);
	}
	public int getIsSuccess() {
		return isSuccess;
	}
	public void setIsSuccess(int isSuccess) {
		this.isSuccess = isSuccess;
		varIsSuccess = new Var("isSuccess", "" + isSuccess);
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
		varLang = new Var("lang", "" + lang);
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
		varSubType = new Var("subType", "" + subType);
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
		varServiceType = new Var("serviceType", "" + serviceType);
	}
	public int getIsSubscriber() {
		return isSubscriber;
	}
	public void setIsSubscriber(int isSubscriber) {
		this.isSubscriber = isSubscriber;
		varIsSubscriber = new Var("isSubscriber", "" + isSubscriber);
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
		varMsisdn = new Var("msisdn", "" + msisdn);
	}
	
	public String getIsValidUser() {
		return isValidUser;
	}
	public void setIsValidUser(String isValidUser) {
		this.isValidUser = isValidUser;
		varIsValidUser = new Var("isValidUser", "" + isValidUser);
	}
	@Override
	public String toString() {
		return "UssdApiResponseModel [lang=" + lang + ", subType=" + subType + ", serviceType=" + serviceType
				+ ", isSubscriber=" + isSubscriber + ", msisdn=" + msisdn + ", isSuccess=" + isSuccess + ", status="
				+ status +", planId=" + planId + ", isValidUser=" + isValidUser
				+ ", varLang=" + varLang + ", varSubType=" + varSubType + ", varServiceType=" + varServiceType
				+ ", varIsSubscriber=" + varIsSubscriber + ", varMsisdn=" + varMsisdn + ", varIsSuccess=" + varIsSuccess
				+ ", varStatus=" + varStatus + ", varRatePlan=" + varRatePlan + ", varPlanId=" + varPlanId
				+ ", varIsValidUser=" + varIsValidUser + "]";
	}
	
	
	
	
	

}
