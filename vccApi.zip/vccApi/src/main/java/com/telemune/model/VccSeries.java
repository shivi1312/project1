package com.telemune.model;

import java.math.BigInteger;

import org.springframework.stereotype.Component;

@Component
public class VccSeries {
    private int groupId;
    private String groupName;
    private BigInteger startRange;
    private BigInteger endRange;
    private String type;
    
    public int getGroupId() {
        return groupId;
    }
    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }
    public String getGroupName() {
        return groupName;
    }
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
    public BigInteger getStartRange() {
        return startRange;
    }
    public void setStartRange(BigInteger startRange) {
        this.startRange = startRange;
    }
    public BigInteger getEndRange() {
        return endRange;
    }
    public void setEndRange(BigInteger endRange) {
        this.endRange = endRange;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
}
