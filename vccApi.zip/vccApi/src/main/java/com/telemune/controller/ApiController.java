package com.telemune.controller;

import org.apache.log4j.Logger;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.telemune.common.CacheLoader;
import com.telemune.model.MyProperties;
import com.telemune.model.UssdApiRequestModel;
import com.telemune.model.UssdApiResponseModel;
import com.telemune.service.RequestHandler;
import com.telemune.service.RequestHandlerImpl;

@RestController
public class ApiController {
	final static Logger logger = Logger.getLogger(ApiController.class);
	
	@Autowired
	RequestHandler profileHandler;
	
	@Autowired
	MyProperties myProp;
	
	/*
	 * @Autowired private Gson gson ;
	 */
	
	@Autowired
	CacheLoader cacheLoader;
	
	private static Gson gson =new Gson();
	
	
	
	@GetMapping("/reloadCache")
	public String reloadCache()
	{
		int isSuccess =-1;
		isSuccess=cacheLoader.runAfterStartup();
		if(isSuccess==1)
		{
			return "Cache reload successfully!!!!!!";
		}
		else
		{
			return "Error occured in reload Cache...";
		}
	}
	
	@RequestMapping(value = "profile.check", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UssdApiResponseModel profileCheck(UssdApiRequestModel profileRequest,
			BindingResult bindingResult, UssdApiResponseModel profileResponse) {
		
		
		logger.info("Request:------>>>>"+profileRequest);
		logger.info("Response:------>>>>"+profileResponse);
		//RequestHandlerImpl profileHandler = new RequestHandlerImpl();
		//logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("profile.check", "profile.check"));
		profileResponse=profileHandler.profileCheckUssd(profileRequest, bindingResult,
				profileResponse);

		try {
			logger.info("response:-profile.check  " + gson.toJson(profileResponse));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//profileHandler = null;
		return profileResponse;
	}
	
	@RequestMapping(value = "profile.checkSub", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UssdApiResponseModel profileCheckSub(UssdApiRequestModel profileRequest,
			BindingResult bindingResult, UssdApiResponseModel profileResponse) {
		
		profileResponse=profileHandler.profileCheckSub(profileRequest, bindingResult,
				profileResponse);
		try {
			logger.info("response:-profile.checkSub  " + gson.toJson(profileResponse));
			
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		//profileHandler = null;
		return profileResponse;
	}
	
	
	@RequestMapping(value = "do.subscribe", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UssdApiResponseModel doSubscribe(UssdApiRequestModel profileRequest,
			BindingResult bindingResult, UssdApiResponseModel profileResponse) {
		profileResponse=profileHandler.subscribeProcess(profileRequest,profileResponse);
		
		try {
			logger.info("response:-profile.check  " + gson.toJson(profileResponse));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//profileHandler = null;
		return profileResponse;
	}
	
	@RequestMapping(value = "do.unsubscribe", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	UssdApiResponseModel doUnSubscribe(UssdApiRequestModel profileRequest,
			BindingResult bindingResult, UssdApiResponseModel profileResponse) {
		profileResponse=profileHandler.unSubscribeProcess(profileRequest,profileResponse);
		try {
			logger.info("response:-profile.check  " + gson.toJson(profileResponse));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//profileHandler = null;
		
		return profileResponse;
	}
	
	
	

}
