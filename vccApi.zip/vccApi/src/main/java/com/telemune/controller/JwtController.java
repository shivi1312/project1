package com.telemune.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.model.JwtRequest;
import com.telemune.model.JwtResponse;
import com.telemune.model.User;
import com.telemune.service.UssdApiServiceImpl;
import com.telemune.util.JwtUtil;

@RestController
public class JwtController {
	
	private final static Logger logger = Logger.getLogger(JwtController.class);
	private final static Logger errorLogger = Logger.getLogger("JwtController : errorLogger");
	
	@Autowired
	private UssdApiServiceImpl ussdApiServiceImpl;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private User user;

	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ResponseEntity<?> generateToken(@RequestBody JwtRequest jwtRequest) throws Exception
	{
		String msg="User is not Authenticated!!";
		logger.info("inside JwtController");
		
		user.setPassword(jwtRequest.getPassword());
		user.setUserName(jwtRequest.getUsername());
		try {
			this.authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(jwtRequest.getUsername(), jwtRequest.getPassword()));
			
		}catch(UsernameNotFoundException e)
		{
			errorLogger.error(
					"[Exception while Authenticate user] Error["
							+ e.getMessage() + "]");
			logger.info(" Exception while Authenticate user [" + e + "]");
			throw new Exception("Bad Credentials");
		}catch(BadCredentialsException e)
		{
			errorLogger.error(
					"[Exception while Authenticate user] Error["
							+ e.getMessage() + "]");
			logger.info(" Exception while Authenticate user [" + e + "]");
			throw new Exception("Bad Credentials");
		}
		// fine area
		
		UserDetails userDetails=this.ussdApiServiceImpl.loadUserByUsername(jwtRequest.getUsername());
		String token=this.jwtUtil.generateToken(userDetails);
		return ResponseEntity.ok(new JwtResponse(token));
		
		
	}
	
}
