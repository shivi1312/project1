package com.telemune.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.apache.commons.collections.map.HashedMap;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.telemune.common.AppConfig;
import com.telemune.common.CacheLoader;
import com.telemune.common.VccCommonOperation;
import com.telemune.model.AuthUser;
import com.telemune.model.JwtRequest;
import com.telemune.model.MyProperties;
import com.telemune.model.User;
import com.telemune.model.UssdApiRequestModel;
import com.telemune.model.UssdApiResponseModel;

@Repository
public class UssdApiDaoImpl implements UssdApiDao {
	
	
	@Autowired
	DataSource dataSource;
	
	@Autowired
	VccCommonOperation commonOperation;
	
	@Autowired
	MyProperties myProp;
	
	
	
	final static Logger logger = Logger.getLogger(UssdApiDaoImpl.class);
	private final static Logger errorLogger = Logger.getLogger("UssdApiDaoImpl : errorLogger");
	//int multiTableEnable=AppConfig.config.getInt("multi_table_sub_check",1); // added by sanchit
	

	@SuppressWarnings("deprecation")
	public UssdApiResponseModel getProfileDetailByMsisdn(UssdApiRequestModel profileRequest,UssdApiResponseModel profileResponse) {

		logger.info("inside getProfileDetailByCallingNum");
		
		String msisdn = commonOperation.msisdnWithCountryCode(profileRequest.getMsisdn());
		/*
		 * logger.debug("[" + msisdn +
		 * "] Query is :->>> [select LOGIN_NAME,MSISDN,LANGUAGE,WPIN,EMAIL_ADDR,DELIVERY_INTERFACE,PASS,SERVICE_TYPE,GREETING_TYPE,SUB_TYPE,IMSI,CLASS_TYPE,ISNEW,ISMIGRATING,STATUS  from VCC_AUTH_USER where MSISDN = "
		 * + msisdn + "]");
		 */
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

			// added by sanchit atri on 16-sep-2020
						String query="";
						if(myProp.getMultiTableEnable()==1)
						{
							String lastDigit=msisdn.substring(msisdn.length()-1);
							String tableName="VCC_AUTH_USER_"+lastDigit;
							query = "select LOGIN_NAME,MSISDN,LANGUAGE,WPIN,EMAIL_ADDR,DELIVERY_INTERFACE,PASS,SERVICE_TYPE,GREETING_TYPE,SUB_TYPE,IMSI,CLASS_TYPE,ISNEW,ISMIGRATING,STATUS  from "+tableName+" where MSISDN = ?";
						
							logger.debug("[" + msisdn
									+ "] Query is :- >>>>>>>>>>>>>>>>>>>>>>>>[select LOGIN_NAME,MSISDN,LANGUAGE,WPIN,EMAIL_ADDR,DELIVERY_INTERFACE,PASS,SERVICE_TYPE,GREETING_TYPE,SUB_TYPE,IMSI,CLASS_TYPE,ISNEW,ISMIGRATING,STATUS  from "+tableName+" where MSISDN = "
									+ msisdn + "]");
						}
						else {
							query = "select LOGIN_NAME,MSISDN,LANGUAGE,WPIN,EMAIL_ADDR,DELIVERY_INTERFACE,PASS,SERVICE_TYPE,GREETING_TYPE,SUB_TYPE,IMSI,CLASS_TYPE,ISNEW,ISMIGRATING,STATUS  from VCC_AUTH_USER where MSISDN = ?";
						
							logger.debug("[" + msisdn
									+ "] Query is :- >>[select LOGIN_NAME,MSISDN,LANGUAGE,WPIN,EMAIL_ADDR,DELIVERY_INTERFACE,PASS,SERVICE_TYPE,GREETING_TYPE,SUB_TYPE,IMSI,CLASS_TYPE,ISNEW,ISMIGRATING,STATUS  from VCC_AUTH_USER where MSISDN =  "
									+ msisdn + "]");
						}
						// end
			
						/*
						 * String query =
						 * "select LOGIN_NAME,MSISDN,LANGUAGE,WPIN,EMAIL_ADDR,DELIVERY_INTERFACE,PASS,SERVICE_TYPE,GREETING_TYPE,SUB_TYPE,IMSI,CLASS_TYPE,ISNEW,ISMIGRATING,STATUS  from VCC_AUTH_USER where MSISDN = ?"
						 * ;
						 */
			
			return jdbcTemplate.query(query, new Object[] { msisdn }, new ResultSetExtractor<UssdApiResponseModel>() {
				@Override
				public UssdApiResponseModel extractData(ResultSet rs) throws SQLException, DataAccessException {
					if (rs.next()) {
						profileResponse.setMsisdn(rs.getString("MSISDN"));
						profileResponse.setLang(rs.getString("LANGUAGE"));
						profileResponse.setServiceType(rs.getString("SERVICE_TYPE"));
						profileResponse.setSubType(rs.getString("SUB_TYPE"));
						profileResponse.setStatus(rs.getString("STATUS"));
						logger.info("[" + rs.getString("MSISDN") + "] found in VCC_AUTH_USER ");
						profileResponse.setIsSubscriber(1);
						logger.info("Msisdn=="+profileResponse.getMsisdn()+"   lang=="+profileResponse.getLang()+"   serviceType=="+profileResponse.getServiceType()+"    subType=="+profileResponse.getSubType());
						return profileResponse;
					}
					
						logger.info("No data  found in VCC_AUTH_USER");
						profileResponse.setIsSubscriber(0);
						//profileResponse.setLang(String.valueOf(profileRequest.getLang()));
						
						return profileResponse;
				
					
				}
			});
		} catch (Exception e) {
			errorLogger.error(
					"ErrorCode [00016] MSISDN["
							+ msisdn + "][Exception while getting user profile detail from VCC_AUTH_USER] Error["
							+ e.getMessage() + "]");
			logger.info("[" + msisdn + "] db operation not perform for getProfileDetail [" + e + "]");
			return null;
		} finally {
			//commonOperation = null;
		}
	}
	
	
	@Override
	public boolean updateLastVisitTime(String msisdn) {
		logger.info("inside  updateLastVisitTime  msisdn====="+msisdn);
		msisdn = commonOperation.msisdnWithCountryCode(msisdn);

		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			/*
			 * String query =
			 * "update VCC_SUBSCRIPTION_MASTER set LAST_VISIT_TIME=now() where MSISDN=?"
			 * ;
			 */

			String query = null;
			// added by sanchit atri on 16-sep-2020
			String lastDigit=msisdn.substring(msisdn.length()-1);
			String tableName="VCC_SUBSCRIPTION_MASTER_"+lastDigit;
			
			if (myProp.getDbType().equalsIgnoreCase("mysql")) {
				
				if(myProp.getMultiTableEnable()==1)
				{
					query = "update "+tableName+" set LAST_VISIT_TIME=now() where MSISDN=?";
					
					logger.debug("[" + msisdn
							+ "] Query is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>[update "+tableName+" set LAST_VISIT_TIME=now() where MSISDN=" + msisdn
							+ "]");
				}
				else
				{
					query = "update VCC_SUBSCRIPTION_MASTER set LAST_VISIT_TIME=now() where MSISDN=?";
					
					logger.debug("[" + msisdn
							+ "] Query is [update VCC_SUBSCRIPTION_MASTER set LAST_VISIT_TIME=now() where MSISDN=" + msisdn
							+ "]");
					
				}
				
				/*
				 * query =
				 * "update VCC_SUBSCRIPTION_MASTER set LAST_VISIT_TIME=now() where MSISDN=?";
				 */
			} else if (myProp.getDbType().equalsIgnoreCase("oracle")) {

				if(myProp.getMultiTableEnable()==1)
				{
					query = "update "+tableName+" set LAST_VISIT_TIME=sysdate where MSISDN=?";
					
					logger.debug("[" + msisdn
							+ "] Query is>>>>>>>>>>>>>>>>>>>>>>> [update "+tableName+" set LAST_VISIT_TIME=sysdate where MSISDN="
							+ msisdn + "]");
				}
				else
				{
					query = "update VCC_SUBSCRIPTION_MASTER set LAST_VISIT_TIME=sysdate where MSISDN=?";
					
					logger.debug("[" + msisdn
							+ "] Query is [update VCC_SUBSCRIPTION_MASTER set LAST_VISIT_TIME=sysdate where MSISDN="
							+ msisdn + "]");
				}
				//end

				/*
				 * query =
				 * "update VCC_SUBSCRIPTION_MASTER set LAST_VISIT_TIME=sysdate where MSISDN=?";
				 */
			}

			int result = jdbcTemplate.update(query, new Object[] { msisdn });
			if (result > 0) {
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			errorLogger.error("ErrorCode [00037] MSISDN[" + msisdn
					+ "] [Exception while updating user's last visiting time in VCC_SUBSCRIPTION_MASTER] Error["
					+ e.getMessage() + "]");
			logger.error("[" + msisdn + "] db operation not perform in updateLastVisitTime [" + e + "]");
			return false;
		}

	}
	
	
	@SuppressWarnings("deprecation")
	public UssdApiResponseModel getSubDetailByMsisdn(UssdApiRequestModel profileRequest,UssdApiResponseModel profileResponse) {

		logger.info("inside getSubDetailByMsisdn");
		
		String msisdn = commonOperation.msisdnWithCountryCode(profileRequest.getMsisdn());
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
						String query="";
						if(myProp.getMultiTableEnable()==1)
						{
							String lastDigit=msisdn.substring(msisdn.length()-1);
							String tableName="VCC_SUBSCRIPTION_MASTER_"+lastDigit;
							query = "select MSISDN,SERVICE_TYPE,STATUS  from "+tableName+" where MSISDN = ? and SERVICE_TYPE=?";
						
							logger.debug("[" + msisdn
									+ "] Query is :- >>>>>>>>>>>>>>>>>>>>>>>>[select MSISDN,SERVICE_TYPE,STATUS  from "+tableName+" where MSISDN =? and SERVICE_TYPE=?"
									+ profileRequest.getServiceType() + "]");
						}
						else {
							query = "select MSISDN,SERVICE_TYPE,STATUS  from from VCC_SUBSCRIPTION_MASTER where MSISDN = ? and SERVICE_TYPE=?";
						
							logger.debug("[" + msisdn
									+ "] Query is :- >>[select MSISDN,SERVICE_TYPE,STATUS  from from VCC_SUBSCRIPTION_MASTER where MSISDN = ? and SERVICE_TYPE=?"
									+ msisdn + "]");
						}
						// end
						
			return jdbcTemplate.query(query, new Object[] { msisdn, profileRequest.getServiceType()}, new ResultSetExtractor<UssdApiResponseModel>() {
				@Override
				public UssdApiResponseModel extractData(ResultSet rs) throws SQLException, DataAccessException {
					if (rs.next()) {
						profileResponse.setMsisdn(rs.getString("MSISDN"));
						profileResponse.setServiceType(rs.getString("SERVICE_TYPE"));
						profileResponse.setStatus(rs.getString("STATUS"));
						logger.info("[" + rs.getString("MSISDN") + "] found in VCC_SUBSCRIPTION_MASTER ");
						profileResponse.setIsSubscriber(1);
						profileResponse.setIsSuccess(1);
						//logger.info("Msisdn=="+vcc.getMsisdn()+"   lang=="+vcc.getLang()+"   serviceType=="+vcc.getServiceType()+"    subType=="+vcc.getSubType());
						return profileResponse;
					}
					logger.info("No data  found in VCC_SUBSCRIPTION_MASTER");
					profileResponse.setIsSubscriber(0);
					profileResponse.setIsSuccess(1);
					profileResponse.setStatus("NA");
					return profileResponse;
				}
			});
		} catch (Exception e) {
			errorLogger.error(
					"ErrorCode [00016] MSISDN["
							+ msisdn + "][Exception while getting user profile detail from VCC_SUBSCRIPTION_MASTER] Error["
							+ e.getMessage() + "]");
			logger.info("[" + msisdn + "] db operation not perform for getProfileDetail [" + e + "]");
			e.printStackTrace();
			return null;
		} finally {
			//commonOperation = null;
		}
	}


	@Override
	public int loadAppConfigParams() {
		try {
			logger.info("Inside loadAppConfigParams");
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
						String query="";
						
							query = "select PARAM_NAME,PARAM_VALUE from app_config_params";
						
							logger.debug("["+query+"]");
							
													 
							  jdbcTemplate.query(query, (ResultSet rs) -> {
								    while (rs.next()) {
								        CacheLoader.addToCache(rs.getString("PARAM_NAME"), rs.getString("PARAM_VALUE")); 
									 
								    }
								    
								});
						
							  return 1;
							
		} catch (Exception e) {
			errorLogger.error(
					"ErrorCode [00016][Exception while getting  detail from app_config_params] Error["
							+ e.getMessage() + "]");
			logger.info(" db operation not perform for getProfileDetail [" + e + "]");
			e.printStackTrace();
			return -1;
		} 
		
	}
	
	
	@SuppressWarnings("deprecation")
	public int getUserDetails(User user) {

		logger.info("inside getUserDetails");
		
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

			
						String query="";
													
							query = "select * from api_access where USER_NAME=? and PASSWORD=? ";
						
							logger.debug(" Query is :- >>>>>>>>>>>>>>>>>>>>>>>>[select * from api_access where USER_NAME=? and PASSWORD=? ]");
		
						// end
			
						/*
						 * String query =
						 * "select LOGIN_NAME,MSISDN,LANGUAGE,WPIN,EMAIL_ADDR,DELIVERY_INTERFACE,PASS,SERVICE_TYPE,GREETING_TYPE,SUB_TYPE,IMSI,CLASS_TYPE,ISNEW,ISMIGRATING,STATUS  from VCC_AUTH_USER where MSISDN = ?"
						 * ;
						 */
			
			return jdbcTemplate.query(query, new Object[] { user.getUserName(),user.getPassword() }, new ResultSetExtractor<Integer>() {
				@Override
				public Integer extractData(ResultSet rs) throws SQLException, DataAccessException {
					if (rs.next()) {
						
						return 1;
					}
					logger.info("User is not authenticated!!");
					
					return -99;
				}
			});
		} catch (Exception e) {
			errorLogger.error(
					"ErrorCode [00016] [Exception while getting user details from vcc_admin_user] Error["
							+ e.getMessage() + "]");
			logger.info(" db operation not perform for getUserDetails [" + e + "]");
			return -1;
		} finally {
			//commonOperation = null;
		}
	}
	
	

}
