package com.telemune.dao;

import org.springframework.stereotype.Component;

import com.telemune.model.AuthUser;
import com.telemune.model.JwtRequest;
import com.telemune.model.User;
import com.telemune.model.UssdApiRequestModel;
import com.telemune.model.UssdApiResponseModel;

@Component
public interface UssdApiDao {

	public UssdApiResponseModel getProfileDetailByMsisdn(UssdApiRequestModel profileRequest,UssdApiResponseModel profileResponse) ;
	public boolean updateLastVisitTime(String msisdn);
	public UssdApiResponseModel getSubDetailByMsisdn(UssdApiRequestModel profileRequest,UssdApiResponseModel profileResponse) ;
	public int loadAppConfigParams();
	public int getUserDetails(User user);

}
