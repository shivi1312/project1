package com.telemune.service;

import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;

import com.telemune.model.UssdApiRequestModel;
import com.telemune.model.UssdApiResponseModel;

@Component
public interface RequestHandler {

	public UssdApiResponseModel profileCheckUssd(UssdApiRequestModel profileRequest,
			BindingResult bindingResult, UssdApiResponseModel profileResponse);
	public UssdApiResponseModel profileCheckSub(UssdApiRequestModel profileRequest,
			BindingResult bindingResult, UssdApiResponseModel profileResponse);
	public UssdApiResponseModel subscribeProcess(UssdApiRequestModel profileRequest,
			UssdApiResponseModel profileResponse);
	public UssdApiResponseModel unSubscribeProcess(UssdApiRequestModel profileRequest,
			UssdApiResponseModel profileResponse);
	public String getSubscribeJsonObj(UssdApiRequestModel profileRequest);
	public String getUnscribeJsonObj(UssdApiRequestModel profileRequest);
	public int tcpWithVccRule(String json);
	
}
