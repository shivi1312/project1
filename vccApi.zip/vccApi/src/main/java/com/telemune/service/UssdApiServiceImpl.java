
package com.telemune.service;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.telemune.dao.UssdApiDao;
import com.telemune.model.User;

@Service
public class UssdApiServiceImpl  implements UserDetailsService {
	final static Logger logger = Logger.getLogger(UssdApiServiceImpl.class);
	private final static Logger errorLogger = Logger.getLogger("UssdApiServiceImpl : errorLogger");
	@Autowired
	private User user;
	
	@Autowired
	private UssdApiDao ussdApiDao;
	
	

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException 
	{
		int ret=1;
		
		ret=ussdApiDao.getUserDetails(user);
		//System.out.println("User-"+user.getUserName()+"    pass-"+ user.getPassword());
		if(ret==1)
		{
			logger.info("User is authenticated.");
			
				return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(), new ArrayList<>());
			
		}
		else
		{
			errorLogger.error("User is not Authenticated!!");
			throw new UsernameNotFoundException("User not found!!!");
		}
		
	}
}
