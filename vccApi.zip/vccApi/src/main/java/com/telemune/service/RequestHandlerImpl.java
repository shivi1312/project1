package com.telemune.service;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.google.gson.Gson;
import com.telemune.common.CacheLoader;
import com.telemune.common.TcpConnectionPool;
import com.telemune.dao.UssdApiDao;
import com.telemune.model.AuthUser;
import com.telemune.model.MyProperties;
import com.telemune.model.UssdApiRequestModel;
import com.telemune.model.UssdApiResponseModel;
import com.telemune.model.VccRuleEngineRequest;
import com.telemune.model.VccRuleEngineResponse;
import com.telemune.model.VccUserCompleteDetails;

import edu.emory.mathcs.util.net.Connection;

@Service
public class RequestHandlerImpl implements RequestHandler {

	final static Logger logger = Logger.getLogger(RequestHandler.class);
	private final static Logger errorLogger = Logger.getLogger("RequestHandlerImpl : errorLogger");

	
	@Autowired
	UssdApiDao ussdApiDaoImpl;
	
	@Autowired
	AuthUser authUser;
	
	@Autowired
	MyProperties myProp;
	
	@Autowired
	private Gson gson;
	
	@Autowired
	VccRuleEngineResponse  subUnscribeResponse;
	
	@Autowired
	VccUserCompleteDetails userCompleteDetails;
	
	@Autowired
	VccRuleEngineRequest vccSubscribeRequest;
	
	@Override
	public UssdApiResponseModel profileCheckUssd(UssdApiRequestModel profileRequest, BindingResult bindingResult,
			UssdApiResponseModel profileResponse) {if (profileRequest.getMsisdn() != null) {
				logger.info(String
						.format(" profile.check.ret request Msisdn [%s] service type[%s]",
								profileRequest.getMsisdn(),
								profileRequest.getServiceType()));

				profileResponse=ussdApiDaoImpl.getProfileDetailByMsisdn(profileRequest,profileResponse);
					logger.info("<<<<<<<<<<<<<>>>>>>>>>>>>>>"+profileResponse.toString());

				
				if (profileResponse.getIsSubscriber() == 1) {

					Boolean status = ussdApiDaoImpl.updateLastVisitTime(profileRequest.getMsisdn());

				} else {
					logger.info("[" + profileRequest.getMsisdn()
							+ "] user is not Subscriber");
				}
				return profileResponse;
				
		}
			else {
				logger.error("The profile check parameter are  required msisdn ["
						+ profileRequest.getMsisdn()
						+ "] serviceType ["
						+ profileRequest.getServiceType() + "]");
				profileResponse.setIsSubscriber(-1);
				return profileResponse;

			}}

	
	@Override
	public UssdApiResponseModel profileCheckSub(UssdApiRequestModel profileRequest, BindingResult bindingResult,
			UssdApiResponseModel profileResponse) {
		
		
		if (profileRequest.getMsisdn() != null
				&& profileRequest.getServiceType() != null) {
			logger.info(String
					.format(" profile.checkSub request Msisdn [%s] service type[%s]",
							profileRequest.getMsisdn(),
							profileRequest.getServiceType()));
			//logger.info("<<<<<<<<<<<<<>>>>>>>>>>>>>>"+profileResponse.toString());
			profileResponse=ussdApiDaoImpl.getSubDetailByMsisdn(profileRequest, profileResponse);
			 
			if(profileResponse!=null)
			{
			if ( profileResponse.getIsSubscriber() == 1) {

				Boolean status = ussdApiDaoImpl.updateLastVisitTime(profileRequest.getMsisdn());

			} else {
				logger.info("[" + profileRequest.getMsisdn()
						+ "] user is not Subscriber");
			}
				return profileResponse;
			}
			else
			{
				logger.info("Some error occured in ussdApiDaoImpl.getSubDetailByMsisdn");
				profileResponse.setIsSubscriber(-1);
				return profileResponse;
			}
			
	}
		else {
			logger.error("The profile check parameter are  required msisdn ["
					+ profileRequest.getMsisdn()
					+ "] serviceType ["
					+ profileRequest.getServiceType() + "]");
			profileResponse.setIsSubscriber(-1);

		}
		return profileResponse;
		
		
	}
	
	
	
	public UssdApiResponseModel subscribeProcess(UssdApiRequestModel profileRequest,
			UssdApiResponseModel profileResponse) {
		logger.info("inside subscribeProcess");
		int isSuccess = 0, ratePlan = 0, res=-1;
		String subType = myProp.getDefautSubType();
		if (profileRequest.getMsisdn() != null
				&& profileRequest.getServiceType() != null
				&& profileRequest.getLang() != 0) {
			String json = getSubscribeJsonObj(profileRequest);
			
			if(profileRequest.getSubType()!=null)
				subType=profileRequest.getSubType();
			
			logger.info("["+profileRequest.getMsisdn()+"] subscribe request >> Subscribe json request subType["+subType+"]: " + json);
			// this.sendSubUnscribeRequest(json);
			res=this.tcpWithVccRule(json);
			if (subUnscribeResponse != null && res==1 ) {
				if (subUnscribeResponse.getResult().equalsIgnoreCase("success")) {
					logger.info("[" + profileRequest.getMsisdn()
							+ "] success result resopnse from rule engine");
					isSuccess = 1;
					
					/*
					 * userCompleteDetails = this.getCompleteAuthDetail(vccServices.userService
					 * .getUserCompleteDetail(profileRequest.getMsisdn())); if (userCompleteDetails
					 * != null) { ratePlan = userCompleteDetails.getRatePlan(); subType =
					 * userCompleteDetails.getSubType(); }
					 */
				} else if (subUnscribeResponse.getResult().equalsIgnoreCase(
						"fail")) {
					logger.info("[" + profileRequest.getMsisdn()
							+ "] fail result resopnse from rule engine");
					isSuccess = 0;
					
				}
				
			} else {
				logger.info("[" + profileRequest.getMsisdn()
						+ "] no resopnse from rule engine");
				isSuccess = -1;
				
			}
			profileResponse.setIsSuccess(isSuccess);
			//profileResponse.setRatePlan(ratePlan);
			profileResponse.setSubType(subType);
			profileResponse.setIsSubscriber(1);
			
			return profileResponse;
		} else {
			logger.error("Do subscribe request param are missing callingNum ["
					+ profileRequest.getMsisdn() + "] lang ["
					+ profileRequest.getLang() + "] serviceType ["
					+ profileRequest.getServiceType() + "]");
			profileResponse.setIsSuccess(-1);
			return profileResponse;
		}
	}

	public UssdApiResponseModel unSubscribeProcess(UssdApiRequestModel profileRequest,
			UssdApiResponseModel profileResponse) {
		logger.info("inside unSubscribeProcess");
		int isSucess = 0, res=-1;
		if (profileRequest.getMsisdn() != null
				&& profileRequest.getServiceType() != null
				&& profileRequest.getLang() != 0) {

			String json = getUnscribeJsonObj(profileRequest);
			logger.info("do.unsubscribe request >> UnSubscribe json request: " + json);
			// this.sendSubUnscribeRequest(json);
			res=this.tcpWithVccRule(json);
			if (subUnscribeResponse != null && res==1) {
				if (subUnscribeResponse.getResult().equalsIgnoreCase("success")) {
					isSucess = 1;
				}
			}
			else{
				logger.info("[" + profileRequest.getMsisdn()
				+ "] no resopnse from rule engine");
				isSucess = -1;
		
			}
			profileResponse.setIsSuccess(isSucess);
			return profileResponse;
		
		} else {
			logger.error("Do unsubscribe request param are missing callingNum ["
					+ profileRequest.getMsisdn()
					+ "] lang ["
					+ profileRequest.getLang()
					+ "] serviceType ["
					+ profileRequest.getServiceType() + "]");
			profileResponse.setIsSuccess(-1);
			return profileResponse;
		
		}
	}

	
	public String getSubscribeJsonObj(UssdApiRequestModel profileRequest) {
		logger.info("inside getSubscribeJsonObj");
		this.gson = new Gson();
		vccSubscribeRequest.setMsisdn(profileRequest.getMsisdn());
		vccSubscribeRequest.setServiceType(profileRequest.getServiceType());
		vccSubscribeRequest.setInterFace(myProp.getDefaultInterface());
		vccSubscribeRequest.setChannel(myProp.getRetrievalChannel());
		vccSubscribeRequest.setTid(String.valueOf(System.nanoTime()));
		vccSubscribeRequest.setActionId(myProp.getSubActionId());

		vccSubscribeRequest.setReqBy(profileRequest.getMsisdn());
		if (profileRequest.getServiceType().equals(
				myProp.getVnCode())) {

			logger.info("[" + profileRequest.getMsisdn()
					+ "] VN default plan set for subscribe vn request");
			/*
			 * vccSubscribeRequest.setActionId(AppConfig.config
			 * .getString("vnsub_actionId"));
			 */
			//vccSubscribeRequest.setPlanName(myProp.getVnDefaultPlan());

			vccSubscribeRequest.setPlanName(CacheLoader.getFromCache("VN_DEFAULT_PLAN"));
			
		} else if (profileRequest.getServiceType().equals(
				myProp.getVmCode())
				) {

			/*
			 * vccSubscribeRequest.setActionId(AppConfig.config
			 * .getString("vmsub_actionId"));
			 */
			//vccSubscribeRequest.setPlanName(profileRequest.getPlanName());
			vccSubscribeRequest.setPlanName(CacheLoader.getFromCache("VM_DEFAULT_PLAN"));
			vccSubscribeRequest.setActTrg(profileRequest.getActTrg());
			logger.info("[" + profileRequest.getMsisdn() + "] VM ["
					+ vccSubscribeRequest.getPlanName()
					+ "] plan set for subscribe vm request ");

		} else if(profileRequest.getServiceType().equals(
				myProp.getMcaCode())
				){
			logger.info("[" + profileRequest.getMsisdn()
					+ "] MCA default plan set for subscribe MCA request ");
			//vccSubscribeRequest.setPlanName(myProp.getMcaDefaultPlan());
			vccSubscribeRequest.setPlanName(CacheLoader.getFromCache("MCA_DEFAULT_PLAN"));
		}
		else
		{
			logger.info("serviceType ["+profileRequest.getServiceType()+"] not match with any service!!!!!!");
			
		}
		vccSubscribeRequest.setLang(profileRequest.getLang());
		vccSubscribeRequest.setAppId(myProp.getAppId());
		if(profileRequest.getSubType()!=null)
		vccSubscribeRequest.setSubType(profileRequest.getSubType());
		else
		vccSubscribeRequest.setSubType(myProp.getDefautSubType());
		
		String jsonObj = this.gson.toJson(vccSubscribeRequest);
		return jsonObj;
	}

	public String getUnscribeJsonObj(UssdApiRequestModel profileRequest) {
		logger.info("inside getUnscribeJsonObj");
		this.gson = new Gson();
		VccRuleEngineRequest vccUnSubscribeRequest = new VccRuleEngineRequest();
		vccUnSubscribeRequest.setMsisdn(profileRequest.getMsisdn());
		vccUnSubscribeRequest.setServiceType(profileRequest.getServiceType());
		vccUnSubscribeRequest.setInterFace(myProp.getDefaultInterface());
		vccUnSubscribeRequest.setChannel(myProp.getRetrievalChannel());
		vccUnSubscribeRequest.setTid(String.valueOf(System.nanoTime()));
		vccUnSubscribeRequest.setActionId(myProp.getUnsubActionId());
		vccUnSubscribeRequest.setLang(profileRequest.getLang());
		vccUnSubscribeRequest.setAppId(myProp.getAppId());
		String jsonObj = this.gson.toJson(vccUnSubscribeRequest);
		return jsonObj;
	}

	public int tcpWithVccRule(String json) {
		int res=-1;
		logger.info("inside tcpWithVccRule");
		Connection socketConnection = null;
		String response = null;
		edu.emory.mathcs.util.net.ConnectionPool connectionPool = null;
		Socket client = null;
		OutputStream outToServer = null;
		DataOutputStream out = null;
		InputStream inFromServer = null;
		DataInputStream in = null;

		try {
			connectionPool = TcpConnectionPool.getRuleEngineConPool(myProp.getRuleEngineIp(),myProp.getRuleEnginePort(),myProp.getRuleSocketTimeOut(),myProp.getRuleEnginePoolLimit());
			socketConnection = connectionPool.getConnection();
			if (connectionPool != null && socketConnection != null) {
				logger.info("Rule Engine Server has connected!\n");
				logger.info("Rule Engine Sending string: '" + json + "'\n");
				client = socketConnection.getSocket();
				client.setSoTimeout(myProp.getRuleSocketTimeOut());
				outToServer = client.getOutputStream();
				out = new DataOutputStream(outToServer);
				out.writeUTF(json.toString());
				out.flush();
				inFromServer = client.getInputStream();
				in = new DataInputStream(inFromServer);
				response = in.readUTF();
				out.close();
				in.close();
				socketConnection.returnToPool();

				if (response != null) {
					this.subUnscribeResponse = this.gson.fromJson(response,
							VccRuleEngineResponse.class);
					logger.info(" Rule Engine response is: " + response);
				} else {
					logger.error("Rule engine response is : " + response);
				}
				try {
					logger.info("post delay after subscription/unsubcription for ["+myProp.getPostDelayAfterSub()+"] sec");
					Thread.sleep(myProp.getPostDelayAfterSub());
				} catch (Exception e) {
					logger.error(String.format(
							"wait for  post_delay_after_sub time [%s]  : ",
							myProp.getPostDelayAfterSub()), e);

				}
				res=1;
				
			} else {
				
				logger.info("Rule is not connected so can't be perform any opearation ");
				res=-1;
			}

		} catch (SocketTimeoutException e) {
			errorLogger.error("ErrorCode [90017] [SocketTimeout Exception while connecting to Rule Engine] Error["+ e.getMessage() +"]");
			
			if (socketConnection != null)
				socketConnection.close();
			try {
				if (out != null) {
					out.flush();
					out.close();
				}
				if (in != null)
					in.close();
				if (inFromServer != null)
					inFromServer.close();
				if (outToServer != null)
					outToServer.close();
			} catch (Exception e2) {

			}

			logger.error("Socket time out [" + e + "]");
			res=-1;
		} catch (Exception e) {
			if (socketConnection != null)
				socketConnection.close();
			e.printStackTrace();
			errorLogger.error("ErrorCode [00058] [Exception while connecting to Rule Engine] Error["+ e.getMessage() +"]");
			res=-1;

		} finally {
			try {
				if (out != null)
					out.close();
				if (in != null)
					in.close();

			} catch (Exception e) {
				errorLogger.error("ErrorCode [00059] [Exception in closing socket connection with Rule Engine] Error["+ e.getMessage() +"]");

				logger.error("Error in closing socket connection [" + e + "]");
			}
		}
		return res;
	}

	

	
}
