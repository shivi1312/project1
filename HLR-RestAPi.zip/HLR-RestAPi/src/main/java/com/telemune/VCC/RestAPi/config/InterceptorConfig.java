package com.telemune.VCC.RestAPi.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.telemune.VCC.RestAPi.common.Interceptor;


@Configuration
public class InterceptorConfig implements WebMvcConfigurer{

	@Autowired
	Interceptor intr;
	
	 @Override
	    public void addInterceptors(InterceptorRegistry registry) {
	        registry.addInterceptor(intr);
	    }
	
}
