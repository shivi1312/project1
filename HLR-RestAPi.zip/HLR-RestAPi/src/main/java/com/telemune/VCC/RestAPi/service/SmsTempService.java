package com.telemune.VCC.RestAPi.service;

import java.util.List;

import com.telemune.VCC.RestAPi.bean.SmsTempBean;


public interface SmsTempService {
	//public List<SmsTempBean> findAllTemplate();
	
//	public SmsTempBean updateTemplate(SmsTempBean smsTempBean,SmsTemplateDetail std );
	
	  SmsTempBean createSmsTemp(SmsTempBean UserVO); public SmsTempBean
	  findByTemplateIdAndLanguageId(Integer id, Integer languageId); public
	  SmsTempBean updateTemplate(SmsTempBean lbsTeplateVO); 
	 public boolean templateDeleteById(Integer id);
	 
       //        	public List<SmsTempBean> findByLanguageId(Integer id);
	public List<SmsTempBean> findAllTemplate();
	  List<SmsTempBean> findByTemplateId(Integer id);
	//public int LoadSMSTemplates();
}
