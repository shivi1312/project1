package com.telemune.VCC.RestAPi.common;


import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.telemune.VCC.RestAPi.dao.UssdApiDao;


@Component
public class CacheLoader {
	
	@Autowired
	UssdApiDao ussdApiDao;
	
	final static Logger logger=Logger.getLogger(CacheLoader.class);
	private static Map<String,String> cacheMap = new HashMap<String,String>();
	
	
	public static void addToCache(String key, String value)
	{
		cacheMap.put(key,value);
	}
	
	public static String getFromCache(String key)
	{
		return cacheMap.get(key);
		
	}



	@EventListener(ApplicationReadyEvent.class)
	public int runAfterStartup() {
		int isSucccess=-1;
		 logger.info("<<<<<<<<<<<<<<<<<<<<<Inside runAfterStartup>>>>>>>>>>>>>>>>>>>>>>>>");
		 isSucccess= ussdApiDao.loadAppConfigParams();
		logger.info("map Values================"+cacheMap);
		 return isSucccess;
	}
	
}

