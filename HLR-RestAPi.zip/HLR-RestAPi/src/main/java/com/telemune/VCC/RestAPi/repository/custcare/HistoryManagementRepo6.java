package com.telemune.VCC.RestAPi.repository.custcare;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog6;

public interface HistoryManagementRepo6 extends JpaRepository<MailBoxLog6, Integer> {
	
	List<MailBoxLog6> findByMsisdn(String msisdn);
}
