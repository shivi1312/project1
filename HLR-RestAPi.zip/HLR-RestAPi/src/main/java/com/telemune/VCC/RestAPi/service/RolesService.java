package com.telemune.VCC.RestAPi.service;

import java.util.List;

import com.telemune.VCC.RestAPi.bean.RolesBean;



public interface RolesService {
	
	public RolesBean createRole(RolesBean roleBean);
	public RolesBean updateRole(RolesBean roleVO);

	public List<RolesBean> findAllRole();

	public RolesBean findById(Integer roleId);

	public boolean roleDeleteById(Integer roleId);
	
	
	
	
	
	
	
	
	
	
	
}
