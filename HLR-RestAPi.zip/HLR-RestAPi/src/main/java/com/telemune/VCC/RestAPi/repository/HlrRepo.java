package com.telemune.VCC.RestAPi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.Hlr;



public interface HlrRepo extends JpaRepository<Hlr,Long >
{
	
	
	void deleteByHlrId(Integer hlrId);	
//	Hlr findByHlrIdFromAll(Integer hlrId);
	Optional<Hlr> findByHlrName(String hlrName);
	Optional<Hlr> findByHlrId(Integer hlrId);
}
