package com.telemune.VCC.RestAPi.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="gmat_smsc_config")
public class Smsc {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SMSC_ID")
	  private Integer smscId ;
	@Column(name = "SMSC_PORT")
	  private Integer smscPort; 
	@Column(name = "SMSC_IP")
	  private String smscIp; 
	@Column(name = "SMSC_USER_ID")
	  private String smscUserId; 
	@Column(name = "SMSC_PASSWORD")
	  private String smscPassword;
	@Column(name = "NO_OF_CONNECTIONS", nullable = false)
	  private String conns;
	@Column(name = "SYSTEM_TYPE")
	  private String sysType; 
	@Column(name = "CLIENT_TYPE")
	  private String clientType;

	@Column(name = "STATUS")
	  private String status;
	
	@Column(name = "TON")
	  private Integer ton;
	@Column(name = "NPI")
	  private Integer npi; 
	@Column(name = "ADDRESS_RANGE")
	  private String addressRange; 
	@Column(name = "SPEED")
	  private Integer speed;
	@Column(name = "window_size",columnDefinition = "boolean default true")
	  private Integer windowSize;
	
	public Integer getSmscId() {
		return smscId;
	}
	public void setSmscId(Integer smscId) {
		this.smscId = smscId;
	}
	public Integer getSmscPort() {
		return smscPort;
	}
	public void setSmscPort(Integer smscPort) {
		this.smscPort = smscPort;
	}
	public String getSmscIp() {
		return smscIp;
	}
	public void setSmscIp(String smscIp) {
		this.smscIp = smscIp;
	}
	public String getSmscUserId() {
		return smscUserId;
	}
	public void setSmscUserId(String smscUserId) {
		this.smscUserId = smscUserId;
	}
	public String getSmscPassword() {
		return smscPassword;
	}
	public void setSmscPassword(String smscPassword) {
		this.smscPassword = smscPassword;
	}
	public String getConns() {
		return conns;
	}
	public void setConns(String conns) {
		this.conns = conns;
	}
	public String getSysType() {
		return sysType;
	}
	public void setSysType(String sysType) {
		this.sysType = sysType;
	}
	public String getClientType() {
		return clientType;
	}
	public void setClientType(String clientType) {
		this.clientType = clientType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getTon() {
		return ton;
	}
	public void setTon(Integer ton) {
		this.ton = ton;
	}
	public Integer getNpi() {
		return npi;
	}
	public void setNpi(Integer npi) {
		this.npi = npi;
	}
	public String getAddressRange() {
		return addressRange;
	}
	public void setAddressRange(String addressRange) {
		this.addressRange = addressRange;
	}
	public Integer getSpeed() {
		return speed;
	}
	public void setSpeed(Integer speed) {
		this.speed = speed;
	}
	public Integer getWindowSize() {
		return windowSize;
	}
	public void setWindowSize(Integer windowSize) {
		this.windowSize = windowSize;
	}
	@Override
	public String toString() {
		return "Smsc [smscId=" + smscId + ", smscPort=" + smscPort + ", smscIp=" + smscIp + ", smscUserId=" + smscUserId
				+ ", smscPassword=" + smscPassword + ", conns=" + conns + ", sysType=" + sysType + ", clientType="
				+ clientType + ", status=" + status + ", ton=" + ton + ", npi=" + npi + ", addressRange=" + addressRange
				+ ", speed=" + speed + ", windowSize=" + windowSize + "]";
	}
	
	
	
}
