package com.telemune.VCC.RestAPi.bean;

public class MailBoxBean {
	private int mailBoxId;
	private String mailBoxType;
	private int maxMessage;
	private int msgLifetime;
	private int msgTimeAftrRet;
	private int mgsTimAftrSav;
	private int maxRecordTime;
	public int getMailBoxId() {
		return mailBoxId;
	}
	public void setMailBoxId(int mailBoxId) {
		this.mailBoxId = mailBoxId;
	}
	public String getMailBoxType() {
		return mailBoxType;
	}
	public void setMailBoxType(String mailBoxType) {
		this.mailBoxType = mailBoxType;
	}
	public int getMaxMessage() {
		return maxMessage;
	}
	public void setMaxMessage(int maxMessage) {
		this.maxMessage = maxMessage;
	}
	public int getMsgLifetime() {
		return msgLifetime;
	}
	public void setMsgLifetime(int msgLifetime) {
		this.msgLifetime = msgLifetime;
	}
	public int getMsgTimeAftrRet() {
		return msgTimeAftrRet;
	}
	public void setMsgTimeAftrRet(int msgTimeAftrRet) {
		this.msgTimeAftrRet = msgTimeAftrRet;
	}
	public int getMgsTimAftrSav() {
		return mgsTimAftrSav;
	}
	public void setMgsTimAftrSav(int mgsTimAftrSav) {
		this.mgsTimAftrSav = mgsTimAftrSav;
	}
	public int getMaxRecordTime() {
		return maxRecordTime;
	}
	public void setMaxRecordTime(int maxRecordTime) {
		this.maxRecordTime = maxRecordTime;
	}
	@Override
	public String toString() {
		return "MailBoxBean [mailBoxId=" + mailBoxId + ", mailBoxType=" + mailBoxType + ", maxMessage=" + maxMessage
				+ ", msgLifetime=" + msgLifetime + ", msgTimeAftrRet=" + msgTimeAftrRet + ", mgsTimAftrSav="
				+ mgsTimAftrSav + ", maxRecordTime=" + maxRecordTime + "]";
	}
	
	
	
}
