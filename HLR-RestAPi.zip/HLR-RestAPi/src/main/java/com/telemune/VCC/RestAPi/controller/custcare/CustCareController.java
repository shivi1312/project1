package com.telemune.VCC.RestAPi.controller.custcare;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.VCC.RestAPi.InterfaceVcc.Constants;
import com.telemune.VCC.RestAPi.bean.MailBoxLogBean;
import com.telemune.VCC.RestAPi.bean.VoiceMsgBean;
import com.telemune.VCC.RestAPi.common.Response;
import com.telemune.VCC.RestAPi.service.CustCareService;
@RestController
public class CustCareController {
	private static final Logger logger = Logger.getLogger(CustCareController.class);
	@Autowired
	private CustCareService hisManagementService;


	@GetMapping("/currentMailBox/{destinationNum}/{serviceType}")
	public Response findByMsisdn(@PathVariable String destinationNum,@PathVariable String serviceType ) {

		try {
			logger.info("Inside findByMsisdn() method of HistoryManagementController class");
			logger.info("input msisdn :" + destinationNum);
			MailBoxLogBean hlrBeandb = null;
			List<VoiceMsgBean> hlrBeanlst = new ArrayList<>();
			if (null != destinationNum) {
				hlrBeanlst = hisManagementService.findByDestinationNum(destinationNum,serviceType);
				logger.debug(hlrBeandb);
			//	hlrBeanlst.add(hlrBeandb);
				logger.debug(hlrBeanlst.toString());
			}
			if (null != hlrBeanlst && !hlrBeanlst.isEmpty()) {
				logger.info("Inside findByMsisdn() method of  HistoryManagementController class");
				return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, hlrBeanlst, "subscription history",
						Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

			} else {
				logger.info("Inside findByHlrId() method of HistoryManagementController class");
				return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, hlrBeanlst,
						"Not found value", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}

		} catch (

		Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(), "",
					Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		}

	}

}
