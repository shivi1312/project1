package com.telemune.VCC.RestAPi.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VCC_MAILBOX_PARAMS")
public class MailBox {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "MAILBOX_ID")
	private Integer mailBoxId;
	@Column(name = "MAILBOX_TYPE", nullable = false)
	private String mailBoxType;
	@Column(name = "MAX_MESSAGES")
	private Integer maxMessage;
	@Column(name="MSG_LIFETIME")
	private Integer msgLifetime;
	@Column(name="MSG_LIFETIME_AFTER_RET")
	private Integer msgTimeAftrRet;
	@Column(name="MSG_LIFETIME_AFTER_SAVE")
	private Integer mgsTimAftrSav;
	@Column(name="MAX_RECORDING_TIME")
	private Integer maxRecordTime;
	public Integer getMailBoxId() {
		return mailBoxId;
	}
	public void setMailBoxId(Integer mailBoxId) {
		this.mailBoxId = mailBoxId;
	}
	public String getMailBoxType() {
		return mailBoxType;
	}
	public void setMailBoxType(String mailBoxType) {
		this.mailBoxType = mailBoxType;
	}
	public Integer getMaxMessage() {
		return maxMessage;
	}
	public void setMaxMessage(Integer maxMessage) {
		this.maxMessage = maxMessage;
	}
	public Integer getMsgLifetime() {
		return msgLifetime;
	}
	public void setMsgLifetime(Integer msgLifetime) {
		this.msgLifetime = msgLifetime;
	}
	public Integer getMsgTimeAftrRet() {
		return msgTimeAftrRet;
	}
	public void setMsgTimeAftrRet(Integer msgTimeAftrRet) {
		this.msgTimeAftrRet = msgTimeAftrRet;
	}
	public Integer getMgsTimAftrSav() {
		return mgsTimAftrSav;
	}
	public void setMgsTimAftrSav(Integer mgsTimAftrSav) {
		this.mgsTimAftrSav = mgsTimAftrSav;
	}
	public Integer getMaxRecordTime() {
		return maxRecordTime;
	}
	public void setMaxRecordTime(Integer maxRecordTime) {
		this.maxRecordTime = maxRecordTime;
	}

	
	
	
	
}
