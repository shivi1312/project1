package com.telemune.VCC.RestAPi.service;

import java.util.List;

import com.telemune.VCC.RestAPi.bean.MailBoxLogBean;

public interface HistoryManagementService {
	List<MailBoxLogBean> findByMsisdn(String msisdn);
}
