package com.telemune.VCC.RestAPi.repository.custcare;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog8;

public interface HistoryManagementRepo8 extends JpaRepository<MailBoxLog8, Integer> {
	
	List<MailBoxLog8> findByMsisdn(String msisdn);
}