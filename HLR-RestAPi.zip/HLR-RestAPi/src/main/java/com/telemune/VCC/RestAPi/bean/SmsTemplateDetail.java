package com.telemune.VCC.RestAPi.bean;

public class SmsTemplateDetail {

	
	private Integer tempId;

	private String tempMsg;

	private Integer langId;

	public Integer getTempId() {
		return tempId;
	}

	public void setTempId(Integer tempId) {
		this.tempId = tempId;
	}

	public String getTempMsg() {
		return tempMsg;
	}

	public void setTempMsg(String tempMsg) {
		this.tempMsg = tempMsg;
	}

	public Integer getLangId() {
		return langId;
	}

	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	@Override
	public String toString() {
		return "SmsTemplateDetail [tempId=" + tempId + ", tempMsg=" + tempMsg + ", langId=" + langId + "]";
	}

	
	
	
}
