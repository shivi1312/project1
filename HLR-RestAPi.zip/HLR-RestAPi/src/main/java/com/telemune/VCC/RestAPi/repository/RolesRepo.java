package com.telemune.VCC.RestAPi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.telemune.VCC.RestAPi.entities.Role;

@Repository
public interface RolesRepo extends JpaRepository<Role, Integer> {
	
	
	//Optional<Roles> findByRoles(String roles);
	Role findByRoleId(Integer roleId);
	//Roles findByRoles(String  roles);
	void deleteByRoleId(Integer roleId);	
	
	@Query(value = "SELECT max(r.roleId) FROM Role r")
	public int maxRoleId();
	 
}
