package com.telemune.VCC.RestAPi.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.SmsTemp;
import com.telemune.VCC.RestAPi.entities.embedded.SmsTempEmbedded;



public interface SmsTempRepo extends JpaRepository<SmsTemp,SmsTempEmbedded>
{
	
	Optional<SmsTemp> findBySmsTempEmbedded(SmsTempEmbedded smsTempEmbedded);
	
	
	//@Query(value = "select * from  LBS_TEMPLETES p where p.TEMPLATE_ID=?1", nativeQuery = true)
	List<SmsTemp> findBySmsTempEmbeddedTempId(Integer id);
//	List<SmsTemp> findBySmsTempByRequestKeyword(String reqKeyword);
//	List<SmsTemp> findBySmsTempByRequestKeyword(Integer id);
	/*
	 * @Query(value = "SELECT max(t.SmsTempEmbedded.tempId) FROM SmsTemp t") public
	 * int maxTempId();
	 */
	void deleteAllBySmsTempEmbeddedTempId(Integer id);

//	List<SmsTemp> findByLangId(Integer id);

	
}
