package com.telemune.VCC.RestAPi.service.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.bean.HttpLinkBean;
import com.telemune.VCC.RestAPi.entities.HttpLinks;
import com.telemune.VCC.RestAPi.repository.HttpLinksRepo;
import com.telemune.VCC.RestAPi.service.HttpLinksService;

@Service
public class HttpLinksServiceImpl implements HttpLinksService{

	@Autowired
	HttpLinksRepo httpLinksRepo;
	
	List httplist;
	
	private static final Logger logger = Logger.getLogger(HttpLinksServiceImpl.class);

	@Override
	public HttpLinkBean createHttpLinks(HttpLinkBean httpLinksVO) {
		
        HttpLinks httpLinks = new HttpLinks();
        httplist.add(httpLinksVO.getLinkId());
        httplist.add(httpLinksVO.getDescription());

		/*
		 * Optional.ofNullable(httpLinksVO.getLinkId()).ifPresent(httpLinks::
		 * setHttpLinksEmbedded().setLinkId);
		 * Optional.ofNullable(httpLinksVO.getDescription()).ifPresent(httpLinks::
		 * setDescription);
		 */
		HttpLinks httpLinksdb = httpLinksRepo.save(httpLinks);

		/*
		 * Optional.ofNullable(httpLinksdb.getHttpLinksEmbedded().getLinkId()).ifPresent
		 * (httpLinksVO::setLinkId);
		 * Optional.ofNullable(httpLinksdb.getHttpLinksEmbedded().getDescription()).
		 * ifPresent(httpLinksVO::setDescription);
		 */
		return httpLinksVO;

	}

	@Override
	public HttpLinkBean updateHttpLinks(HttpLinkBean httpLinksVO) {
         
		HttpLinks httpLinks = new HttpLinks();
		
		//Optional.ofNullable(httpLinksVO.getLinkId()).ifPresent(httpLinks::setLinkId);
		//Optional.ofNullable(httpLinksVO.getDescription()).ifPresent(httpLinks::setDescription);

		HttpLinks httpLinksdb = httpLinksRepo.save(httpLinks);

		//Optional.ofNullable(httpLinksdb.getHttpLinksEmbedded().getLinkId()).ifPresent(httpLinksVO::setLinkId);
		//Optional.ofNullable(httpLinksdb.getDescription()).ifPresent(httpLinksVO::setDescription);
		
		return httpLinksVO;
	}

	@Override
	public List<HttpLinks> findAllHttpLinks() {
		
		logger.info("Inside findAllHttpsLinks() method of HttpsController class");
		
		List<HttpLinks>  httpLinksdb= httpLinksRepo.findAll();
		
		logger.info("Exit findAllHttpsLinks() method of HttpsController class");
		
		return httpLinksdb;
	}

	@Override
	public HttpLinks findByHttpLinksId(Integer linkId) {
		
		HttpLinks  httpLinks=httpLinksRepo.findByLinkId(linkId);
		
		return httpLinks;
	}
}
