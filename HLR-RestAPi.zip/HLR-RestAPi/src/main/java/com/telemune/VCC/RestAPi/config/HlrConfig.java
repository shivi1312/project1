package com.telemune.VCC.RestAPi.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.telemune.VCC.RestAPi.entities.Hlr;
@Configuration
public class HlrConfig {
	
	@Bean
	public Hlr hh()
	{
		return new Hlr();
	}
}
