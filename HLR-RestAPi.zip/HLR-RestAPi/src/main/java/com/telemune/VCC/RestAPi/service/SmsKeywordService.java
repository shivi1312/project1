package com.telemune.VCC.RestAPi.service;

import java.util.List;

import com.telemune.VCC.RestAPi.bean.SmsKeywordBean;

public interface SmsKeywordService {
	
//	public SmsKeywordBean updateSmsKeyword(SmsKeywordBean smsKeywordBean);
	SmsKeywordBean findByReqKeyword(String requestkeyword);
	List<SmsKeywordBean> findAllSmsKeywords();
}
