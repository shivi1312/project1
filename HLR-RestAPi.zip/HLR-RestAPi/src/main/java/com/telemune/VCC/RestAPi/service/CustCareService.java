package com.telemune.VCC.RestAPi.service;

import java.util.List;

import com.telemune.VCC.RestAPi.bean.VoiceMsgBean;

public interface CustCareService {
	List<VoiceMsgBean> findByDestinationNum(String destinationNum,String serviceType);
}
