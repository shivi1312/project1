package com.telemune.VCC.RestAPi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.Smsc;

public interface SmscRepo extends JpaRepository<Smsc, Integer>{
	void deleteBySmscId(Integer smscId);	
	Optional<Smsc> findBySmscId(Integer smscId);
}
