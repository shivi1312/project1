package com.telemune.VCC.RestAPi.entities.embedded;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
@Embeddable
public class SubscriptionMasterPriKeys implements Serializable
{

	@Column(name="MSISDN")
	 String msisdn;
	@Column(name = "SERVICE_TYPE")
	 String ServiceType;
	
	public SubscriptionMasterPriKeys() {
		
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getServiceType() {
		return ServiceType;
	}

	public void setServiceType(String serviceType) {
		ServiceType = serviceType;
	}

	
	public SubscriptionMasterPriKeys(String msisdn, String serviceType) {
		super();
		this.msisdn = msisdn;
		ServiceType = serviceType;
	}

	@Override
	public String toString() {
		return "SubscriptionMasterPriKeys [msisdn=" + msisdn + ", ServiceType=" + ServiceType + "]";
	}
	
	

}
