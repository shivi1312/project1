package com.telemune.VCC.RestAPi.repository;

public interface SubscriptionHistoryRepo{

}
