package com.telemune.VCC.RestAPi.repository.custcare;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog5;

public interface HistoryManagementRepo5 extends JpaRepository<MailBoxLog5, Integer> {
	
	List<MailBoxLog5> findByMsisdn(String msisdn);
}
