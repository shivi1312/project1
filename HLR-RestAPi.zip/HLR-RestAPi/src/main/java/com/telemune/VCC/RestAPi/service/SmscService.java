package com.telemune.VCC.RestAPi.service;

import java.util.List;

import com.telemune.VCC.RestAPi.bean.SmscBean;

public interface SmscService {
	public String createSmsc(SmscBean smscBean);
	List<SmscBean> findAllSmsc();
	public String updateSmsc( SmscBean smscBean);
	SmscBean findBySmscId(Integer smscId);
	public boolean DeleteSmscById(Integer smscId);
	
}
