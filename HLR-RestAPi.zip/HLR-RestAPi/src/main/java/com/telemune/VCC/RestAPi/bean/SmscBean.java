package com.telemune.VCC.RestAPi.bean;

public class SmscBean {
	  private Integer smscId ;
		  private Integer smscPort; 
		  private String smscIp; 
		  private String smscUserId; 
		  private String smscPassword;
		  private String conns;
		  private String sysType; 
		  private String clientType;
		  private String status;
		  private Integer ton;
		  private Integer npi; 
		  private String addressRange; 
		  private Integer speed;
		  private Integer windowSize;
		  
		  
		public Integer getSmscId() {
			return smscId;
		}
		public void setSmscId(Integer smscId) {
			this.smscId = smscId;
		}
		public Integer getSmscPort() {
			return smscPort;
		}
		public void setSmscPort(Integer smscPort) {
			this.smscPort = smscPort;
		}
		public String getSmscIp() {
			return smscIp;
		}
		public void setSmscIp(String smscIp) {
			this.smscIp = smscIp;
		}
		public String getSmscUserId() {
			return smscUserId;
		}
		public void setSmscUserId(String smscUserId) {
			this.smscUserId = smscUserId;
		}
		public String getSmscPassword() {
			return smscPassword;
		}
		public void setSmscPassword(String smscPassword) {
			this.smscPassword = smscPassword;
		}
		public String getConns() {
			return conns;
		}
		public void setConns(String conns) {
			this.conns = conns;
		}
		public String getSysType() {
			return sysType;
		}
		public void setSysType(String sysType) {
			this.sysType = sysType;
		}
		public String getClientType() {
			return clientType;
		}
		public void setClientType(String clientType) {
			this.clientType = clientType;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public Integer getTon() {
			return ton;
		}
		public void setTon(Integer ton) {
			this.ton = ton;
		}
		public Integer getNpi() {
			return npi;
		}
		public void setNpi(Integer npi) {
			this.npi = npi;
		}
		public String getAddressRange() {
			return addressRange;
		}
		public void setAddressRange(String addressRange) {
			this.addressRange = addressRange;
		}
		public Integer getSpeed() {
			return speed;
		}
		public void setSpeed(Integer speed) {
			this.speed = speed;
		}
		public Integer getWindowSize() {
			return windowSize;
		}
		public void setWindowSize(Integer windowSize) {
			this.windowSize = windowSize;
		}
	
	  
	  
	  
}
