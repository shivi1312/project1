package com.telemune.VCC.RestAPi.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.telemune.VCC.RestAPi.entities.embedded.SmsTempEmbedded;
@Entity
@Table(name="LBS_TEMPLETES1111")
public class SmsTemp implements Serializable
{

	private static final long serialVersionUID = 1L;
	
//	@Column(name = "TEMPLATE_ID", nullable = false)         
//	private Integer tempId;
	
	@EmbeddedId
	private SmsTempEmbedded smsTempEmbedded; 
	
	 @Column(name = "TEMPLATE_TYPE", nullable = false)
	private Integer tempType;
	 
	 @Column(name = "TEMPLATE_MESSAGE")    
	private String tempMsg;
	 
	 @Column(name = "TOKENS_ALLOWED")  
	private String tokenAllowed;
	 
	 @Column(name = "TEMPLATE_DESCRIPTION")
	private String tempDesc;
	 
//	 @Column(name = "LANGUAGE_ID", nullable = false)       
//	private Integer langId;
	 
	 @Column(name = "SERVICE_TYPE",columnDefinition = "varchar(10) default '0000'")   
	private String serviceType;

	 
	public Integer getTempType() {
		return tempType;
	}
	public void setTempType(Integer tempType) {
		this.tempType = tempType;
	}
	public String getTempMsg() {
		return tempMsg;
	}
	public void setTempMsg(String tempMsg) {
		this.tempMsg = tempMsg;
	}
	public String getTokenAllowed() {
		return tokenAllowed;
	}
	public void setTokenAllowed(String tokenAllowed) {
		this.tokenAllowed = tokenAllowed;
	}
	public String getTempDesc() {
		return tempDesc;
	}
	public void setTempDesc(String tempDesc) {
		this.tempDesc = tempDesc;
	}
	
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	
	
	
	
	public SmsTempEmbedded getSmsTempEmbedded() {
		return smsTempEmbedded;
	}
	public void setSmsTempEmbedded(SmsTempEmbedded smsTempEmbedded) {
		this.smsTempEmbedded = smsTempEmbedded;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "SmsTemp [smsTempEmbedded=" + smsTempEmbedded + ", tempType=" + tempType + ", tempMsg=" + tempMsg
				+ ", tokenAllowed=" + tokenAllowed + ", tempDesc=" + tempDesc + ", serviceType=" + serviceType + "]";
	}
	
	

	
}
