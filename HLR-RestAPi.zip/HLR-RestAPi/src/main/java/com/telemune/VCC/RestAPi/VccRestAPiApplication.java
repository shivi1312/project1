package com.telemune.VCC.RestAPi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.telemune.VCC.RestAPi.entities.UserF;
import com.telemune.VCC.RestAPi.repository.UserRepo;

@SpringBootApplication
@EnableCaching
public class VccRestAPiApplication implements CommandLineRunner {

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private UserRepo userRepo;

	public static void main(String[] args) {
		SpringApplication.run(VccRestAPiApplication.class, args);
		System.out.println("start");
	}

	@Override
	public void run(String... args) throws Exception {

		UserF user = new UserF();
		user.setUsername("admin");
		user.setPassword(passwordEncoder.encode("admin"));
		user.setEmail("admin123@gmail.com");
		userRepo.save(user);

	}

}
