package com.telemune.VCC.RestAPi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.MailBox;

public interface MailBoxRepo extends JpaRepository<MailBox, Integer> {

	Optional<MailBox> findByMailBoxType(String mailBoxType);
	Optional<MailBox> findByMailBoxId(Integer mailBoxId);
	void deleteByMailBoxId(Integer mailBoxId);
}
