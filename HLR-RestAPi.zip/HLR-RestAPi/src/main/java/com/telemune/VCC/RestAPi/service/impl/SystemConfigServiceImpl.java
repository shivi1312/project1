package com.telemune.VCC.RestAPi.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.InterfaceVcc.HistoryEvent;
import com.telemune.VCC.RestAPi.bean.AppConfigBean;
import com.telemune.VCC.RestAPi.entities.AppConfig;
import com.telemune.VCC.RestAPi.entities.HistoryData;
import com.telemune.VCC.RestAPi.model.BeanToEntity;
import com.telemune.VCC.RestAPi.model.EntityToBean;
import com.telemune.VCC.RestAPi.repository.HistoryDataRepo;
import com.telemune.VCC.RestAPi.repository.SystemConfigRepo;
import com.telemune.VCC.RestAPi.service.SystemConfigService;
@Service
public class SystemConfigServiceImpl implements SystemConfigService {
	@Autowired
	private SystemConfigRepo sysConfigRepo;

	@Autowired
	private HistoryDataRepo historyRepo;
	HistoryData hisData = null;

	private static final Logger logger = Logger.getLogger(SystemConfigServiceImpl.class);
	
	
	
	@Override
	@Transactional
	public AppConfigBean updateSysConfig(AppConfigBean appConfigBean) {
	

			logger.info("Inside updateMailBox() method of MailBoxServiceImpl class");
			
				Optional<AppConfig> mailBoxEntity = sysConfigRepo.findByParamName(appConfigBean.getParamName());
				logger.info("MailBox name " + mailBoxEntity);
				if (mailBoxEntity.isPresent()) {
					logger.info("MailBox Already Exist with name===" + mailBoxEntity.get().getParamName());
					hisData = new HistoryData();
					hisData.setRole("Pending");
					hisData.setMsg(HistoryEvent.add);
					hisData.setAction(HistoryEvent.systemconfigmanagement);
					hisData.setEvent(HistoryEvent.alExist);
					hisData.setUser("Pending ");
					historyRepo.save(hisData);
				} 
				else {

					logger.info("going to update ");
					AppConfig mailBoxEntity1 = BeanToEntity.convertAppConfigBeanToAppConfigEntity(appConfigBean);

					AppConfig mailBoxEntitydb = sysConfigRepo.save(mailBoxEntity1);

					logger.info("Exit from updateMailBox() method function of MailBoxServiceImpl class");
					hisData = new HistoryData();
					hisData.setRole("Pending");
					hisData.setMsg(HistoryEvent.add);
					hisData.setAction(HistoryEvent.systemconfigmanagement);
					hisData.setEvent(HistoryEvent.addSuccess);
					hisData.setUser("Pending ");
					historyRepo.save(hisData);
					return EntityToBean.convertAppConfigEntityToAppConfigBean(mailBoxEntitydb);
				}
				//logger.info("Exit from updateMailBox() method function of MailBoxServiceImpl class");
			return new AppConfigBean();
		
				}
	
	
	@Override
	public List<AppConfigBean> findAllSysConfig() {
		logger.info("Inside findAllmailBox() method function of MailBoxServiceImpl class");
		List<AppConfigBean> finalmailBoxBean = new ArrayList<>();
		List<AppConfig> mailboxdbList = sysConfigRepo.findAll();
		for (AppConfig mailBox : mailboxdbList) {
			AppConfigBean mailBoxBean = EntityToBean.convertAppConfigEntityToAppConfigBean(mailBox);
			finalmailBoxBean.add(mailBoxBean);
		}
		logger.info("Exit from  findAllmailBox() method function of MailBoxServiceImpl class");
		return finalmailBoxBean;
	}
	@Override
	public AppConfigBean findByParamName(String paramName) {
		logger.info("Inside findByMailBoxId() method function of MailBoxServiceImpl class");
		Optional<AppConfig> hlrid = sysConfigRepo.findByParamName(paramName);
		logger.info("check by hlrId");

		if (hlrid.isPresent()) {

			logger.info("Exit from findByHlrId() method function of HlrServiceImpl class");

			return EntityToBean.convertAppConfigEntityToAppConfigBean(hlrid.get());

		}
		logger.info("Exit from findByHlrId() method function of HlrServiceImpl class");

		return new AppConfigBean();
	}


	
}
