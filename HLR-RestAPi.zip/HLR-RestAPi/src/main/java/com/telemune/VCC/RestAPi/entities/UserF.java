package com.telemune.VCC.RestAPi.entities;
import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "admin_user")
//@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class UserF implements Serializable{
	
	@Id
	@Column(name = "USER_NAME", nullable = false)
	private String username;

	@Column(name = "PASSWORD", nullable = false)
	private String password;

	@Column(name = "EMAIL", nullable = true)
	private String email;

	@Column(name = "MOBILE_NUM")
	private String mobileNumber;

	@Column(name = "FIRST_LOGIN")
	private String firstLogin;
	
	@Column(name = "STATUS")
	private String status;
	
//	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
//	  @JoinColumn(name = "ROLE")
//	private Role roles;
	 
	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn(name = "ROLE")
	private Role roles;
	
	/*
	 * @OneToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "ROLE") private Role roles;
	 * 
	 */	public Role getRoles() {
		return roles;
	}

	public void setRoles(Role roles) {
		this.roles = roles;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getFirstLogin() {
		return firstLogin;
	}

	public void setFirstLogin(String firstLogin) {
		this.firstLogin = firstLogin;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "UserF [username=" + username + ", password=" + password + ", email=" + email + ", mobileNumber="
				+ mobileNumber + ", firstLogin=" + firstLogin + ", status=" + status + ", roles=" + roles + "]";
	}

	
	 
	
	
}
