package com.telemune.VCC.RestAPi.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Table;

@Embeddable
@Table(name = "web_access")
public class WebAccess {
	
	@Column(name = "HTTP_ID", nullable = false)
	private Integer httpId;
	
	@Column(name = "ROlE_ID", nullable = false)
	private Integer  roleId;
	
	@Column(name = "IS_ALLOWED", nullable = false, columnDefinition = "A")
	private String isAllowed;

	public Integer getHttpId() {
		return httpId;
	}

	public void setHttpId(Integer httpId) {
		this.httpId = httpId;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getIsAllowed() {
		return isAllowed;
	}

	public void setIsAllowed(String isAllowed) {
		this.isAllowed = isAllowed;
	}

	@Override
	public String toString() {
		return "WebAccess [httpId=" + httpId + ", roleId=" + roleId + ", isAllowed=" + isAllowed + "]";
	}

	

}
