package com.telemune.VCC.RestAPi.common;


import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.PhoneNumberUtil.PhoneNumberFormat;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;
import com.telemune.VCC.RestAPi.model.MyProperties;

@Component
public class VccCommonOperation {
	final static Logger logger = Logger.getLogger(VccCommonOperation.class);
	final static Logger delLogger = Logger.getLogger("deleteLogger");
	final static Logger errorLogger = Logger.getLogger("VccCommonOperation : errorLogger");
	@Autowired
	MyProperties myProp;
	
	
	/**
	 * return the msisdn with country code
	 * 
	 * @param msisdn
	 *            the msisdn which does not start with country code
	 * @return msisdnNum the no. with country code
	 * @see country code with msisdn
	 */
	public String msisdnWithCountryCode(String msisdn) {
		logger.info("inside msisdnWithCountryCode   country code=========="+myProp.getCountryCode()+"   msisdn====="+msisdn);
		msisdn=convertToInternationalNumber(msisdn, myProp.getSpecialCountryCode());
		//logger.info(" msisdn=====after convert==="+msisdn);
		return msisdn;

	}
	
	public String convertToInternationalNumber(String msisdn, String code) {
		logger.info("inside convertToInternationalNumber");
		String retMsisdn = "";
		if (msisdn.startsWith(myProp.getCountryCode())) {
			msisdn = msisdn.substring(myProp.getCountryCode().length(), msisdn.length());
		} else if (!msisdn.startsWith(myProp.getCountryCode()) && !msisdn.startsWith("0")
				&& msisdn.length() > myProp.getMsisdnLength()) {
			return msisdn.trim();
		} else if (msisdn.startsWith("00")) {
			return msisdn.trim();
		}

		logger.info("msisdn: inside  convertToInternationalNumber==" + msisdn);
		PhoneNumber number = null;
		PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
		try {
			number = phoneUtil.parse(msisdn, code);
		} catch (NumberParseException e) {
			errorLogger.error("ErrorCode [" +  "90016] [NumberParse Exception while converting MSISDN to International Exception] Error["
					+ e.getMessage() + "]");
			e.printStackTrace();
			return msisdn;
		}
		logger.debug("number [" + msisdn + "] to international number ["
				+ phoneUtil.format(number, PhoneNumberFormat.E164).toString().replace("+", "") + "]");
		retMsisdn = phoneUtil.format(number, PhoneNumberFormat.E164).toString().replace("+", "").trim();
		
		int msisdnLengthWithCountryCode = myProp.getMsisdnLength()
				+ myProp.getCountryCode().length();
		logger.debug(String.format("[%s] length with country code [%s]", retMsisdn, msisdnLengthWithCountryCode));
		if (retMsisdn.length() < msisdnLengthWithCountryCode) {
			logger.debug(String.format("Handle fixed line: [%s] length with country code [%s]", retMsisdn,
					msisdnLengthWithCountryCode));
			retMsisdn = retMsisdn.substring(0, myProp.getCountryCode().length()) + ""
					+ retMsisdn.substring(myProp.getCountryCode().length(), retMsisdn.length());
			logger.debug(String.format("fixed line msisdn after handling: [%s]", retMsisdn));
		}
		return retMsisdn;
	}

	
}
