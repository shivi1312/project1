package com.telemune.VCC.RestAPi.bean;

import java.util.Date;

public class VoiceMsgBean {
private Integer voicemsgIndex;
	
	private String msgStatus;
	
	private String originatingNum;
	
	private String destinationNum;
	
	private Date callTime;
	
	private Date retTime;		
	
	private String fileName;
							
	private Integer recDuration;
	
	private String msgProtect;
	
	private String msgPriority;
	
	private String passProtected;
	
	private String pass;
	
	private String originalNum;
	
	private Integer localMsgIndex;
	
	private Date sendingTime;
	
	private String serviceType;

	public Integer getVoicemsgIndex() {
		return voicemsgIndex;
	}

	public void setVoicemsgIndex(Integer voicemsgIndex) {
		this.voicemsgIndex = voicemsgIndex;
	}

	public String getMsgStatus() {
		return msgStatus;
	}

	public void setMsgStatus(String msgStatus) {
		this.msgStatus = msgStatus;
	}

	public String getOriginatingNum() {
		return originatingNum;
	}

	public void setOriginatingNum(String originatingNum) {
		this.originatingNum = originatingNum;
	}

	public String getDestinationNum() {
		return destinationNum;
	}

	public void setDestinationNum(String destinationNum) {
		this.destinationNum = destinationNum;
	}

	public Date getCallTime() {
		return callTime;
	}

	public void setCallTime(Date callTime) {
		this.callTime = callTime;
	}

	public Date getRetTime() {
		return retTime;
	}

	public void setRetTime(Date retTime) {
		this.retTime = retTime;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Integer getRecDuration() {
		return recDuration;
	}

	public void setRecDuration(Integer recDuration) {
		this.recDuration = recDuration;
	}

	public String getMsgProtect() {
		return msgProtect;
	}

	public void setMsgProtect(String msgProtect) {
		this.msgProtect = msgProtect;
	}

	public String getMsgPriority() {
		return msgPriority;
	}

	public void setMsgPriority(String msgPriority) {
		this.msgPriority = msgPriority;
	}

	public String getPassProtected() {
		return passProtected;
	}

	public void setPassProtected(String passProtected) {
		this.passProtected = passProtected;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getOriginalNum() {
		return originalNum;
	}

	public void setOriginalNum(String originalNum) {
		this.originalNum = originalNum;
	}

	public Integer getLocalMsgIndex() {
		return localMsgIndex;
	}

	public void setLocalMsgIndex(Integer localMsgIndex) {
		this.localMsgIndex = localMsgIndex;
	}

	public Date getSendingTime() {
		return sendingTime;
	}

	public void setSendingTime(Date sendingTime) {
		this.sendingTime = sendingTime;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	@Override
	public String toString() {
		return "VoiceMsgBean [voicemsgIndex=" + voicemsgIndex + ", msgStatus=" + msgStatus + ", originatingNum="
				+ originatingNum + ", destinationNum=" + destinationNum + ", callTime=" + callTime + ", retTime="
				+ retTime + ", fileName=" + fileName + ", recDuration=" + recDuration + ", msgProtect=" + msgProtect
				+ ", msgPriority=" + msgPriority + ", passProtected=" + passProtected + ", pass=" + pass
				+ ", originalNum=" + originalNum + ", localMsgIndex=" + localMsgIndex + ", sendingTime=" + sendingTime
				+ ", serviceType=" + serviceType + "]";
	}

	
}
