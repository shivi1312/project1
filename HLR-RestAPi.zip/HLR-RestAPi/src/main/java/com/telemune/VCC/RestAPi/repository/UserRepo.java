package com.telemune.VCC.RestAPi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.telemune.VCC.RestAPi.entities.UserF;


@Repository
public interface UserRepo extends JpaRepository<UserF, String> {
	  
		Optional<UserF> findByUsername(String username);
		void deleteByUsername(String username);	
		
		
		
//		Hlr findByHlrIdFromAll(Integer hlrId);
		
	/*
	 * @Query(value="SELECT x FROM User x WHERE x.role.roleId = :myRoleId")
	 * List<User> findUserByRoleId (Integer myRoleId);
	 */
	/*
	 * Boolean existsByUsername(String username);
	 * 
	 * Boolean existsByEmail(String email);
	 * 
	 * 
	 * // void deleteByUsername(String username); void deleteByHlrId(Integer hlrId);
	 */

}
