package com.telemune.VCC.RestAPi.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.bean.VoiceMsgBean;
import com.telemune.VCC.RestAPi.common.VccCache;
import com.telemune.VCC.RestAPi.entities.custcare.VoiceMsg;
import com.telemune.VCC.RestAPi.model.custcare.EntityToBeanCust;
import com.telemune.VCC.RestAPi.repository.custcare.VoiceMsgRepo;
import com.telemune.VCC.RestAPi.service.CustCareService;

@Service
public class CustCareServiceImpl implements CustCareService {

	@Autowired
	VoiceMsgRepo voiceMsgRepo;

	private static final Logger logger = Logger.getLogger(CustCareServiceImpl.class);

	@Override
	public List<VoiceMsgBean> findByDestinationNum(String destinationNum,String serviceType) {
		List<VoiceMsgBean> finalHlrBean = new ArrayList<>();
		logger.info("Inside findByMsisdn() method function of HistoryManagementServiceImpl class");
		String num;
		num = VccCache.instance().getInternationalNumber(destinationNum);

		logger.info(num+"====num");
		
		List<VoiceMsg> number = voiceMsgRepo.findByDestinationNum(num);
		for (VoiceMsg hlr : number) {
			VoiceMsgBean hlrBean = EntityToBeanCust.convertVoiceMsgEntityToVoiceMsgBean(hlr);
			finalHlrBean.add(hlrBean);
		}

		logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
		return finalHlrBean;

	}
}
