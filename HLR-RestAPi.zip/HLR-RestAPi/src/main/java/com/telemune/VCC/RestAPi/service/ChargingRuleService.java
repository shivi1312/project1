package com.telemune.VCC.RestAPi.service;

import java.util.List;

import com.telemune.VCC.RestAPi.bean.ChargingRuleBean;


public interface ChargingRuleService {

	public ChargingRuleBean updateChargingCode(ChargingRuleBean chgBean);
	List<ChargingRuleBean> findAllChargingCode();
	ChargingRuleBean findByChargingCode(Integer chargingCode);
	public boolean deleteByChargingCode(Integer chargingCode);

}
