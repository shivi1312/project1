package com.telemune.VCC.RestAPi.bean;

public class ChargingRuleBean {
	
	private Integer chargingCode;
	
	private double amountPre;
	
	private double amountPost;
	
	private String charCodeName;
	
	private Integer tariffPre;
	private Integer tariffPost;
	public Integer getChargingCode() {
		return chargingCode;
	}
	public void setChargingCode(Integer chargingCode) {
		this.chargingCode = chargingCode;
	}
	public double getAmountPre() {
		return amountPre;
	}

	public void setAmountPre(double amountPre) {
		this.amountPre = amountPre;
	}
	
	
	
	public String getCharCodeName() {
		return charCodeName;
	}
	public void setCharCodeName(String charCodeName) {
		this.charCodeName = charCodeName;
	}
	public double getAmountPost() {
		return amountPost;
	}
	public void setAmountPost(double amountPost) {
		this.amountPost = amountPost;
	}
	
	public Integer getTariffPre() {
		return tariffPre;
	}
	public void setTariffPre(Integer tariffPre) {
		this.tariffPre = tariffPre;
	}
	public Integer getTariffPost() {
		return tariffPost;
	}
	public void setTariffPost(Integer tariffPost) {
		this.tariffPost = tariffPost;
	}
	@Override
	public String toString() {
		return "ChargingRuleBean [chargingCode=" + chargingCode + ", amountPre=" + amountPre + ", amountPost="
				+ amountPost + ", charCodeName=" + charCodeName + ", tariffPre=" + tariffPre + ", tariffPost="
				+ tariffPost + "]";
	}
	
}
