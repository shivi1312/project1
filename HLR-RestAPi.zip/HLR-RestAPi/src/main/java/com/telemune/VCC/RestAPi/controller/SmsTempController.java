package com.telemune.VCC.RestAPi.controller;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.VCC.RestAPi.InterfaceVcc.Constants;
import com.telemune.VCC.RestAPi.bean.SmsTempBean;
import com.telemune.VCC.RestAPi.common.Response;
import com.telemune.VCC.RestAPi.service.SmsTempService;


@RestController
public class SmsTempController {

	private static final Logger logger = Logger.getLogger(SmsTempController.class);

	@Autowired
	private SmsTempService smsTempService;
	
	/*
	 * @GetMapping("/courses/{tempId}") public List<SmsTempBean>
	 * getCourses(@PathVariable Integer tempId) {
	 * logger.info("inside createUser() method of UserController class"); return
	 * this.smsTempService.findByTemplateId(tempId); }
	 */


	@SuppressWarnings("unused")
	@PostMapping("/smstemp")
	public Response createSmsTemp(@RequestBody SmsTempBean userVO) {
		try {

			logger.info("inside createUser() method of UserController class");
			logger.info("user input ==> userVO--" + userVO.toString());
			if (null != userVO) {
				SmsTempBean userVOdb = smsTempService.createSmsTemp(userVO);

				logger.debug(userVOdb.toString());
				if (true) {
					logger.info("Exit createUser() method of UserController class");
					return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new ArrayList<>(),
							"User created", Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);
				} else {
					logger.info("Exit createUser() method of UserController class");
					return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
							new ArrayList<>(), "Error while  creating the user", Constants.STATUS_FAILURE,
							Constants.STATUS_FAILURE_MESSAGE);
				}
			}
		} catch (

		Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		}
		logger.info("Exit findAllRole() method of UserController class");
		return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
				"Error while  creating the user", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
	}
	
	
	
	
	@GetMapping("/")
	public Response findByTemplateIdAndLanguageId(@RequestParam("tempId") Integer tempId,
			@RequestParam(name = "langId", required = false) Integer langId) {

		try {

			logger.info("Inside findByTemplateIdAndLanguageId() method of LbsTemplateController class");
			SmsTempBean lbsTemplateVO = null;
			List<SmsTempBean> lbsTemplateVOVOlst = new ArrayList<>();
			if (null != tempId && null != langId) {
				logger.info("Temp id --" + tempId.toString() + "langId --" + langId.toString());
				lbsTemplateVO = smsTempService.findByTemplateIdAndLanguageId(tempId, langId);
				lbsTemplateVOVOlst.add(lbsTemplateVO);
				logger.debug(lbsTemplateVO.toString());
			} else if (null != tempId) {
				logger.info("Temp id --" + tempId.toString());
				lbsTemplateVOVOlst = smsTempService.findByTemplateId(tempId);
				logger.debug(lbsTemplateVOVOlst.toString());
			}

			if (null != lbsTemplateVOVOlst && !lbsTemplateVOVOlst.isEmpty()) {
				logger.info("Exit findByTemplateIdAndLanguageId() method of LbsTemplateController class");
				logger.info(lbsTemplateVOVOlst.toString());
				return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, lbsTemplateVOVOlst, "",
						Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

			} else {
				logger.info("value is null");
				logger.info("Exit findByTemplateIdAndLanguageId() method of LbsTemplateController class");
				return new Response(HttpStatus.NOT_FOUND, Constants.HTTP_STATUS_CODE_NOT_FOUND, new ArrayList<>(),
						"Data not found", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}

		} catch (

		Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.toString(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		}
	}

	@SuppressWarnings("unused")
	@PutMapping("/temp")
	public Response updateTemplate(@RequestBody SmsTempBean lbsTemplateVO) {
		try {

			logger.info("Inside updateTemplate() method of LbsTemplateController class" + lbsTemplateVO.toString());
			if (null != lbsTemplateVO) {
				SmsTempBean lbsTemplate = smsTempService.updateTemplate(lbsTemplateVO);

				logger.debug(lbsTemplate.toString());
				if (null != lbsTemplate && lbsTemplate.getTempId() != null) {
					logger.info(lbsTemplate.toString());
					return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new ArrayList<>(),
							"Template is updated", Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

				} else {
					logger.info("Template not update");
					logger.info("Exit updateTemplate() method of LbsTemplateController class");
					return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
							new ArrayList<>(), "Template is not updated", Constants.STATUS_FAILURE,
							Constants.STATUS_FAILURE_MESSAGE);
				}
			}
			logger.info("Exit updateTemplate() method of LbsTemplateController class");
			return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					"Id is null", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		} catch (

		Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(), "",
					Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		}
	}

	@DeleteMapping("/{tempId}")
	public Response deleteByTempId(@PathVariable(name = "tempId") Integer tempId) {

		try {
			logger.info("Inside deleteByTempId() method of LbsTemplateController class ---tempId---" + tempId);
			if (null != tempId) {
				if (smsTempService.templateDeleteById(tempId)) {
					logger.info("Temp deleted with " + tempId);
					return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new ArrayList<>(),
							"Id is Deleted", Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);
				} else

					return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
							new ArrayList<>(), "Not found value", Constants.STATUS_FAILURE,
							Constants.STATUS_FAILURE_MESSAGE);

			} else {
				logger.info("Temp not deleted");
				logger.info("Exit updateTemplate() method of LbsTemplateController class");
				return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
						"Not found value", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}

		} catch (

		Exception exception) {
			logger.info(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(), "",
					Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		}

	}

		@GetMapping("/alltemps")
	public Response findAllTemp() {

		try {
			logger.info("Inside findAllTemp() method of LbsTemplateController class");
			List<SmsTempBean> lbsTempVOlst = smsTempService.findAllTemplate();
			logger.debug(lbsTempVOlst.toString());
			if (lbsTempVOlst != null && !(lbsTempVOlst.isEmpty())) {
				logger.info("Exit findAllTemp() method of LbsTemplateController class");
				return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, lbsTempVOlst, " ",
						Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);
			}
			logger.info("Exit findAllTemp() method of LbsTemplateController class");
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					"Data not found", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

		} catch (Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.toString(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

		}

	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * @SuppressWarnings("unused")
	 * 
	 * @PutMapping("/smsTemp") public Response updateTemplate(@RequestBody
	 * SmsTempBean lbsTemplateVO,SmsTemplateDetail std1) { try {
	 * 
	 * logger.info("Inside updateTemplate() method of LbsTemplateController class" +
	 * lbsTemplateVO.toString()); if (null != lbsTemplateVO) { SmsTempBean
	 * lbsTemplate = smsTempService.updateTemplate(lbsTemplateVO,std1);
	 * 
	 * logger.debug(lbsTemplate.toString()); if (null != lbsTemplate &&
	 * lbsTemplate.getTempId() != null) { logger.info(lbsTemplate.toString());
	 * return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new
	 * ArrayList<>(), "Template is updated", Constants.STATUS_SUCCESS,
	 * Constants.STATUS_SUCCESS_MESSAGE);
	 * 
	 * } else { logger.info("Template not update");
	 * logger.info("Exit updateTemplate() method of LbsTemplateController class");
	 * return new Response(HttpStatus.BAD_GATEWAY,
	 * Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
	 * "Template is not updated", Constants.STATUS_FAILURE,
	 * Constants.STATUS_FAILURE_MESSAGE); } }
	 * logger.info("Exit updateTemplate() method of LbsTemplateController class");
	 * return new Response(HttpStatus.BAD_GATEWAY,
	 * Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(), "Id is null",
	 * Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE); } catch (
	 * 
	 * Exception exception) { logger.error(exception.toString()); return new
	 * Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new
	 * ArrayList<>(), "", Constants.STATUS_FAILURE,
	 * Constants.STATUS_FAILURE_MESSAGE); } }
	 * 
	 * 
	 * 
	 * @GetMapping("/allTemp") public Response findAllTemp() {
	 * 
	 * try {
	 * logger.info("Inside findAllTemp() method of LbsTemplateController class");
	 * List<SmsTempBean> lbsTempVOlst = smsTempService.findAllTemplate();
	 * logger.debug(lbsTempVOlst.toString()); if (lbsTempVOlst != null &&
	 * !(lbsTempVOlst.isEmpty())) {
	 * logger.info("Exit findAllTemp() method of LbsTemplateController class");
	 * return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS,
	 * lbsTempVOlst, " ", Constants.STATUS_SUCCESS,
	 * Constants.STATUS_SUCCESS_MESSAGE); }
	 * logger.info("Exit findAllTemp() method of LbsTemplateController class");
	 * return new Response(HttpStatus.BAD_REQUEST,
	 * Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(), "Data not found",
	 * Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
	 * 
	 * } catch (Exception exception) { logger.error(exception.toString()); return
	 * new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
	 * new ArrayList<>(), exception.toString(), Constants.STATUS_FAILURE,
	 * Constants.STATUS_FAILURE_MESSAGE);
	 * 
	 * }
	 * 
	 * }
	 */
	 
	

}
