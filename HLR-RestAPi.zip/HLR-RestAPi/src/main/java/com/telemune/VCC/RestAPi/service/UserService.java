package com.telemune.VCC.RestAPi.service;

import java.util.List;

import com.telemune.VCC.RestAPi.entities.UserF;


public interface UserService {
 
	public UserF createUser(UserF userBean);
	
	public UserF updateUser(UserF hlrBean);
	List<UserF> findAllUser();
	UserF findByUserName(String userName);
	public boolean userDeleteByName(String userName);
	
	 
}
