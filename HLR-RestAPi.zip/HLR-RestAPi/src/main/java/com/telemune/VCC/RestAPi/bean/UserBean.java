package com.telemune.VCC.RestAPi.bean;

public class UserBean {


private String username;


private String password;


private String email;


private String mobileNumber;


private String firstLogin;


private String userType;

private String status;

private String createdBy;

private Integer roles;

private Integer roleId;

private String roleName;

private String description;



public Integer getRoles() {
	return roles;
}
public void setRoles(Integer roles) {
	this.roles = roles;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public String getFirstLogin() {
	return firstLogin;
}
public void setFirstLogin(String firstLogin) {
	this.firstLogin = firstLogin;
}
public String getUserType() {
	return userType;
}
public void setUserType(String userType) {
	this.userType = userType;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getCreatedBy() {
	return createdBy;
}
public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
}


public Integer getRoleId() {
	return roleId;
}
public void setRoleId(Integer roleId) {
	this.roleId = roleId;
}

public String getRoleName() {
	return roleName;
}
public void setRoleName(String roleName) {
	this.roleName = roleName;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
@Override
public String toString() {
	return "UserBean [username=" + username + ", password=" + password + ", email=" + email + ", mobileNumber="
			+ mobileNumber + ", firstLogin=" + firstLogin + ", userType=" + userType + ", status=" + status
			+ ", createdBy=" + createdBy + ", roles=" + roles + ", roleId=" + roleId + ", roleName=" + roleName
			+ ", description=" + description + "]";
}

}

