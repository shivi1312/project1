package com.telemune.VCC.RestAPi.repository.custcare;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog3;

public interface HistoryManagementRepo3 extends JpaRepository<MailBoxLog3, Integer> {
	
	List<MailBoxLog3> findByMsisdn(String msisdn);
}
