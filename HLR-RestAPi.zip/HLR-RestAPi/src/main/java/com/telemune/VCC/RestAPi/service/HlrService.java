package com.telemune.VCC.RestAPi.service;

import java.util.List;

import com.telemune.VCC.RestAPi.bean.HlrBean;



public interface HlrService {


	public HlrBean createHlr(HlrBean hlrBean);
	public HlrBean updateHlr(HlrBean hlrBean);
	List<HlrBean> findAllHlr();
	HlrBean findByHlrId(Integer hlrId);
	public boolean hlrDeleteById(Integer hlrId);
	
	//public void deleteHlr(long parseLong);
	}
