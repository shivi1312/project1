package com.telemune.VCC.RestAPi.service;

import java.util.List;

import com.telemune.VCC.RestAPi.bean.HttpLinkBean;
import com.telemune.VCC.RestAPi.entities.HttpLinks;




public interface HttpLinksService {

 public HttpLinkBean createHttpLinks(HttpLinkBean httpLinksVO);
     
     public HttpLinkBean updateHttpLinks(HttpLinkBean httpLinksVO);
     
     public List<HttpLinks> findAllHttpLinks();
     
     public HttpLinks findByHttpLinksId(Integer id);
     
}
