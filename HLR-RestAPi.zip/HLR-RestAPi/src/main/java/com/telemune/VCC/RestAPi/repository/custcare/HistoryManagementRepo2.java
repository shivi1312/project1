package com.telemune.VCC.RestAPi.repository.custcare;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog2;

public interface HistoryManagementRepo2 extends JpaRepository<MailBoxLog2, Integer> {
	
	List<MailBoxLog2> findByMsisdn(String msisdn);
}