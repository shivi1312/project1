package com.telemune.VCC.RestAPi.entities;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.telemune.VCC.RestAPi.entities.embedded.LbsTemplatePriKeys;

@Entity
@Table(name="lbs_templates")
public class LbsTemplates implements Serializable
{
@EmbeddedId
LbsTemplatePriKeys lbsTemplatePriKeys;
int templateType;
String templateMessage;
String tokensAllowed;
String templateDescription;
String serviceType;

public int getTemplateType() {
	return templateType;
}
public void setTemplateType(int templateType) {
	this.templateType = templateType;
}
public String getTemplateMessage() {
	return templateMessage;
}
public void setTemplateMessage(String templateMessage) {
	this.templateMessage = templateMessage;
}
public String getTokensAllowed() {
	return tokensAllowed;
}
public void setTokensAllowed(String tokensAllowed) {
	this.tokensAllowed = tokensAllowed;
}
public String getTemplateDescription() {
	return templateDescription;
}
public void setTemplateDescription(String templateDescription) {
	this.templateDescription = templateDescription;
}

public String getServiceType() {
	return serviceType;
}
public void setServiceType(String serviceType) {
	this.serviceType = serviceType;
}




}
