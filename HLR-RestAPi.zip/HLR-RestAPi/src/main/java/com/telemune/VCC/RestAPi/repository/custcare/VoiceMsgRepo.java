package com.telemune.VCC.RestAPi.repository.custcare;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.telemune.VCC.RestAPi.entities.custcare.VoiceMsg;
@Repository
public interface VoiceMsgRepo extends JpaRepository <VoiceMsg, Integer>{
	
	List<VoiceMsg> findByDestinationNum(String destinationNum);

}
