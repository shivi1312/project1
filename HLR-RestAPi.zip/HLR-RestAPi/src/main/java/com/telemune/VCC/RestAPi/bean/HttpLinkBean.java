package com.telemune.VCC.RestAPi.bean;

public class HttpLinkBean {
	
	
	private Integer linkId;

	private String description;

	public Integer getLinkId() {
		return linkId;
	}

	public void setLinkId(Integer linkId) {
		this.linkId = linkId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "HttpLinkBean [linkId=" + linkId + ", description=" + description + "]";
	}
	
	
	

}
