package com.telemune.VCC.RestAPi.bean;

import java.io.Serializable;


public class SmsTempEmbeddedBean implements Serializable{
	 private static final long serialVersionUID = 1L;

 
	 Integer langId;
	 Integer tempId;
	public SmsTempEmbeddedBean(Integer langId, Integer tempId) {
		super();
		this.langId = langId;
		this.tempId = tempId;
	}
	public Integer getLangId() {
		return langId;
	}
	public void setLangId(Integer langId) {
		this.langId = langId;
	}
	public Integer getTempId() {
		return tempId;
	}
	public void setTempId(Integer tempId) {
		this.tempId = tempId;
	}
	@Override
	public String toString() {
		return "SmsTempEmbeddedBean [langId=" + langId + ", tempId=" + tempId + "]";
	}
	 
	 

	
	
	
}
