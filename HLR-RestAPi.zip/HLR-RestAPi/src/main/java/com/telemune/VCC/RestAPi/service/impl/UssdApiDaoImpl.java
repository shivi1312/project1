package com.telemune.VCC.RestAPi.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.bean.MailBoxLogBean;
import com.telemune.VCC.RestAPi.common.VccCache;
import com.telemune.VCC.RestAPi.dao.UssdApiDao;
import com.telemune.VCC.RestAPi.entities.UserF;
import com.telemune.VCC.RestAPi.entities.custcare.AuthUser0;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog0;
import com.telemune.VCC.RestAPi.model.ApiRequestModel;
import com.telemune.VCC.RestAPi.model.ApiResponseModel;
import com.telemune.VCC.RestAPi.model.EntityToBean;
import com.telemune.VCC.RestAPi.repository.custcare.AuthRepo;

@Service
public class UssdApiDaoImpl implements UssdApiDao{
	
	
	
	@Autowired
	AuthRepo authRepo0;
	
	private static final Logger logger = Logger.getLogger(UssdApiDaoImpl.class);
	@Override
	public ApiResponseModel getProfileDetailByMsisdn(ApiRequestModel profileRequest, ApiResponseModel profileResponse) {

		//	List<MailBoxLogBean> finalHlrBean = new ArrayList<>();
			logger.info("Inside findByMsisdn() method function of HistoryManagementServiceImpl class");
			String num;
			num = VccCache.instance().getInternationalNumber(profileRequest.getMsisdn());
		//	String msisdn = commonOperation.msisdnWithCountryCode(profileRequest.getMsisdn());
			logger.info("num  :" + num);
			String las = num.substring(num.length() - 1);

			logger.info("VCC_MailBox_Log_" + las);

		/*
		 * if (las.equals("0")) { List<AuthUser0> number =
		 * hisManageRepo0.findByMsisdn(msisdn); for (MailBoxLog0 hlr : number) {
		 * MailBoxLogBean hlrBean =
		 * EntityToBean.convertMailBoxLog0EntityToMailBoxLogBean(hlr);
		 * finalHlrBean.add(hlrBean); } logger.
		 * info("Exit from  findAllHlr() method function of IUserServiceImpl class");
		 * return finalHlrBean;}
		 */
return null;
			}
	

	@Override
	public boolean updateLastVisitTime(String msisdn) {

		return false;
	}


	@Override
	public ApiResponseModel getSubDetailByMsisdn(ApiRequestModel profileRequest, ApiResponseModel profileResponse) {

		return null;
	}


	@Override
	public int loadAppConfigParams() {

		return 0;
	}


	@Override
	public int getUserDetails(UserF user) {

		return 0;
	}

}
