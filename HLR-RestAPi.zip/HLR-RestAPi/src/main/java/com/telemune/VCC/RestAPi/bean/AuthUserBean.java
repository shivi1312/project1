package com.telemune.VCC.RestAPi.bean;

public class AuthUserBean {
	
	private String msisdn;

	private String loginName;

	private String wPin;

	private Integer lang;

	private String serviceType;

	private String email;

	private Integer delInterface;

	private String pass;

	private Integer greetingType;

	private String status;
	
	private String subType;
	
	private String imsi;
	
	private Integer classType;

	private Integer isNew;

	private Integer isMigration;

	private String tid;

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getwPin() {
		return wPin;
	}

	public void setwPin(String wPin) {
		this.wPin = wPin;
	}

	public Integer getLang() {
		return lang;
	}

	public void setLang(Integer lang) {
		this.lang = lang;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getDelInterface() {
		return delInterface;
	}

	public void setDelInterface(Integer delInterface) {
		this.delInterface = delInterface;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public Integer getGreetingType() {
		return greetingType;
	}

	public void setGreetingType(Integer greetingType) {
		this.greetingType = greetingType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public Integer getClassType() {
		return classType;
	}

	public void setClassType(Integer classType) {
		this.classType = classType;
	}

	public Integer getIsNew() {
		return isNew;
	}

	public void setIsNew(Integer isNew) {
		this.isNew = isNew;
	}

	public Integer getIsMigration() {
		return isMigration;
	}

	public void setIsMigration(Integer isMigration) {
		this.isMigration = isMigration;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	@Override
	public String toString() {
		return "AuthUserBean [msisdn=" + msisdn + ", loginName=" + loginName + ", wPin=" + wPin + ", lang=" + lang
				+ ", serviceType=" + serviceType + ", email=" + email + ", delInterface=" + delInterface + ", pass="
				+ pass + ", greetingType=" + greetingType + ", status=" + status + ", subType=" + subType + ", imsi="
				+ imsi + ", classType=" + classType + ", isNew=" + isNew + ", isMigration=" + isMigration + ", tid="
				+ tid + "]";
	}

	
}
