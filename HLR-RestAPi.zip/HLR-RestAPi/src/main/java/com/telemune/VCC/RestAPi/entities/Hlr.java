package com.telemune.VCC.RestAPi.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="HLR_config")
public class Hlr {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "HLR_ID")
	private Integer hlrId;
	@Column(name = "HLR_NAME")
	private String hlrName;
	@Column(name = "HLR_IP")
	private String hlrIp;
	@Column(name = "HLR_PORT")
	private int hlrPort;
	@Column(name = "LOGIN")
	private String login;
	@Column(name = "PASSWORD")
	private String password;
	@Column(name = "HLR_TYPE")
	private String hlrType;
	@Column(name = "CONNECTIONS")
	private int conn;
	

	
	public Integer getHlrId() {
		return hlrId;
	}

	public void setHlrId(Integer hlrId) {
		this.hlrId = hlrId;
	}

	public String getHlrName() {
		return hlrName;
	}

	public void setHlrName(String hlrName) {
		this.hlrName = hlrName;
	}

	public String getHlrIp() {
		return hlrIp;
	}

	public void setHlrIp(String hlrIp) {
		this.hlrIp = hlrIp;
	}

	public int getHlrPort() {
		return hlrPort;
	}

	public void setHlrPort(int hlrPort) {
		this.hlrPort = hlrPort;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

	public int getConn() {
		return conn;
	}

	public void setConn(int conn) {
		this.conn = conn;
	}

	
	
	public String getHlrType() {
		return hlrType;
	}

	public void setHlrType(String hlrType) {
		this.hlrType = hlrType;
	}

	@Override
	public String toString() {
		return "Hlr [hlrId=" + hlrId + ", hlrName=" + hlrName + ", hlrIp=" + hlrIp + ", hlrPort=" + hlrPort + ", login="
				+ login + ", password=" + password + ", hlrType=" + hlrType + ", conn=" + conn + "]";
	}

	

	
	
	
	
}
