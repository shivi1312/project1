package com.telemune.VCC.RestAPi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog;

public interface HistoryManagementRepo extends JpaRepository<MailBoxLog, Integer> {
	
	Optional<MailBoxLog> findByMsisdn(String msisdn);
}
