package com.telemune.VCC.RestAPi.service;

import org.springframework.validation.BindingResult;

import com.telemune.VCC.RestAPi.model.ApiRequestModel;
import com.telemune.VCC.RestAPi.model.ApiResponseModel;


public interface ApiRequestHandler {

	public ApiResponseModel profileCheck(ApiRequestModel profileRequest,
			BindingResult bindingResult, ApiResponseModel profileResponse);
	//public ApiResponseModel subscribeProcess(ApiRequestModel profileRequest,ApiResponseModel profileResponse);
	public int tcpWithVccRule(String json);
}
