package com.telemune.VCC.RestAPi.repository;

public interface CacheRepo {

}
