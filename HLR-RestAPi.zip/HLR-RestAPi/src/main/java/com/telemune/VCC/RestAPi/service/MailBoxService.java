package com.telemune.VCC.RestAPi.service;

import java.util.List;

import com.telemune.VCC.RestAPi.bean.MailBoxBean;

public interface MailBoxService {
	
	public MailBoxBean createMailBox(MailBoxBean mailBoxBean);
	List<MailBoxBean> findAllmailBox();
	public MailBoxBean updateMailBox( MailBoxBean mailBoxBean);
	MailBoxBean findByMailBoxId(Integer mailBoxId);

	public boolean DeleteMailBoxById(Integer hlrId);
	
}
