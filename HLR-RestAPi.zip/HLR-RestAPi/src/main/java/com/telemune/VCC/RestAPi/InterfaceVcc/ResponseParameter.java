package com.telemune.VCC.RestAPi.InterfaceVcc;

public interface ResponseParameter {

	
	  String activated="A";
	  String deActivated="D";
	    
	    
	   
}
