package com.telemune.VCC.RestAPi.entities.embedded;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class LbsTemplatePriKeys implements Serializable
{
int templateId;
int languageId;

public LbsTemplatePriKeys() 
{
	
}

public int getTemplateId() {
	return templateId;
}

public void setTemplateId(int templateId) {
	this.templateId = templateId;
}

public int getLanguageId() {
	return languageId;
}

public void setLanguageId(int languageId) {
	this.languageId = languageId;
}

public LbsTemplatePriKeys(int templateId, int languageId) 
{
	this.templateId = templateId;
	this.languageId = languageId;
}

@Override
public String toString() {
	return "LbsTemplatePriKeys [templateId=" + templateId + ", languageId=" + languageId + "]";
}
}
