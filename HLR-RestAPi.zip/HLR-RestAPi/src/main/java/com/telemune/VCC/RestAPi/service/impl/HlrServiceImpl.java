package com.telemune.VCC.RestAPi.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.InterfaceVcc.HistoryEvent;
import com.telemune.VCC.RestAPi.bean.HlrBean;
import com.telemune.VCC.RestAPi.entities.HistoryData;
import com.telemune.VCC.RestAPi.entities.Hlr;
import com.telemune.VCC.RestAPi.model.BeanToEntity;
import com.telemune.VCC.RestAPi.model.EntityToBean;
import com.telemune.VCC.RestAPi.repository.HistoryDataRepo;
import com.telemune.VCC.RestAPi.repository.HlrRepo;
import com.telemune.VCC.RestAPi.service.HlrService;

@Service
public class HlrServiceImpl implements HlrService {

	@Autowired
	private HlrRepo hlrRepo;

	@Autowired
	private HistoryDataRepo historyRepo;

	private static final Logger logger = Logger.getLogger(HlrServiceImpl.class);

	private ArrayList<Hlr> hlrConfigAl;

	public ArrayList<Hlr> getHlrConfigAl() {
		return hlrConfigAl;
	}

	public void setHlrConfigAl(ArrayList<Hlr> hlrConfigAl) {
		this.hlrConfigAl = hlrConfigAl;
	}

	List<Hlr> list;
	HistoryData hisData = null;

	public HlrServiceImpl() {

	}

	/*
	 * @Override public void deleteHlr(long parseLong) { Hlr entity =
	 * hlrRepo.getOne(parseLong); hlrRepo.delete(entity); }
	 */
	@Override
	public HlrBean createHlr(HlrBean hlrBean) {
		try {

			logger.info("Inside createHlr() method function of HlrServiceImpl class");

			Optional<Hlr> hlrEntity = hlrRepo.findByHlrName(hlrBean.getHlrName());

			if (hlrEntity.isPresent()) {
				logger.info("hlr Already Exist with name===" + hlrEntity.get().getHlrName());

				// throw new UserAlreadyExitException("Username Already Exit");
				hisData = new HistoryData();
				hisData.setRole("Pending");
				hisData.setMsg(HistoryEvent.add);
				hisData.setAction(HistoryEvent.hlrmanagement);
				hisData.setEvent(HistoryEvent.alExist);
				hisData.setUser("Pending ");
				historyRepo.save(hisData);
			}

			else {

				Hlr hlr = BeanToEntity.convertHlrBeanToHlrEntity(hlrBean);
				Hlr hlrdb = hlrRepo.save(hlr);
				logger.info("Exit from createHlr() method function of HlrServiceImpl class");
				HlrBean hlrFinal = EntityToBean.convertHlrEntityToHlrBean(hlrdb);
				hisData = new HistoryData();
				hisData.setRole("Pending");
				hisData.setMsg("addSuccess");
				hisData.setAction(HistoryEvent.hlrmanagement);
				hisData.setEvent(HistoryEvent.addSuccess);
				hisData.setUser("Pending");
				historyRepo.save(hisData);

				return hlrFinal;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		logger.info("Exit from createHlr() method function of HlrServiceImpl class");
		return new HlrBean();

	}

	@Override
	@Transactional
	public HlrBean updateHlr(HlrBean hlrBean) {

		logger.info("Inside updateHlr() method of HlrServiceImpl class");
		Optional<Hlr> hlrEntity = hlrRepo.findByHlrId(hlrBean.getHlrId());
		if (hlrEntity.isPresent()) {
			logger.info("id present");
			Optional<Hlr> hlr = hlrRepo.findByHlrName(hlrBean.getHlrName());
			logger.info("hlr name " + hlr);

			if (hlr.isPresent()) {

				logger.info("hlr Already Exist with name===" + hlrEntity.get().getHlrName());
				hisData = new HistoryData();
				hisData.setRole("Pending");
				hisData.setMsg(HistoryEvent.add);
				hisData.setAction(HistoryEvent.hlrmanagement);
				hisData.setEvent(HistoryEvent.alExist);
				hisData.setUser("Pending ");
				historyRepo.save(hisData);
			} 
			else {

				logger.info("going to update ");
				Hlr hlrEntity1 = BeanToEntity.convertHlrBeanToHlrEntity(hlrBean);
				Hlr hlrEntitydb = hlrRepo.save(hlrEntity1);
				logger.info("Exit from updateHlr() method function of HlrServiceImpl class");
				hisData = new HistoryData();
				hisData.setRole("Pending");
				hisData.setMsg("addSuccess");
				hisData.setAction(HistoryEvent.hlrmanagement);
				hisData.setEvent(HistoryEvent.addSuccess);
				hisData.setUser("Pending ");
				historyRepo.save(hisData);
				return EntityToBean.convertHlrEntityToHlrBean(hlrEntitydb);
			}
		} else
			logger.info("Exit from updateHlr() method function of HlrServiceImpl class");
		return new HlrBean();
	}

	@Override
	public List<HlrBean> findAllHlr() {

		logger.info("Inside findAllHlr() method function of HlrServiceImpl class");
		List<HlrBean> finalHlrBean = new ArrayList<>();
		List<Hlr> userdbList = hlrRepo.findAll();

		for (Hlr hlr : userdbList) {
			HlrBean hlrBean = EntityToBean.convertHlrEntityToHlrBean(hlr);
			finalHlrBean.add(hlrBean);
		}
		logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
		return finalHlrBean;
	}

	@Override
	public HlrBean findByHlrId(Integer hlrId) {
		logger.info("Inside findByHlrId() method function of HlrServiceImpl class");

		Optional<Hlr> hlrid = hlrRepo.findByHlrId(hlrId);
		logger.info("check by hlrId");

		if (hlrid.isPresent()) {

			logger.info("Exit from findByHlrId() method function of HlrServiceImpl class");

			return EntityToBean.convertHlrEntityToHlrBean(hlrid.get());

		}
		logger.info("Exit from findByHlrId() method function of HlrServiceImpl class");

		return new HlrBean();
	}

	@Override
	@Transactional
	public boolean hlrDeleteById(Integer hlrId) {

		Optional<Hlr> hlr = hlrRepo.findByHlrId(hlrId);

		logger.info("Inside hlrDeleteById() method of HlrServiceImpl class");

		logger.debug(hlr.toString());

		try {
			if (hlr.isPresent()) {
				hlrRepo.deleteByHlrId(hlrId);
				logger.info("Exit hlrDeleteById() method of HlrServiceImpl class");
				return true;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		logger.info("Exit hlrDeleteById() method of HlrServiceImpl class");
		return false;

	}

}
