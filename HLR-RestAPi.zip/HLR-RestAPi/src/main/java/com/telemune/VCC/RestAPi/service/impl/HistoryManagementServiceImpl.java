package com.telemune.VCC.RestAPi.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.bean.MailBoxLogBean;
import com.telemune.VCC.RestAPi.common.VccCache;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog0;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog1;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog2;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog3;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog4;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog5;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog6;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog7;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog8;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog9;
import com.telemune.VCC.RestAPi.model.EntityToBean;
import com.telemune.VCC.RestAPi.repository.HistoryManagementRepo;
import com.telemune.VCC.RestAPi.repository.custcare.HistoryManagementRepo0;
import com.telemune.VCC.RestAPi.repository.custcare.HistoryManagementRepo1;
import com.telemune.VCC.RestAPi.repository.custcare.HistoryManagementRepo2;
import com.telemune.VCC.RestAPi.repository.custcare.HistoryManagementRepo3;
import com.telemune.VCC.RestAPi.repository.custcare.HistoryManagementRepo4;
import com.telemune.VCC.RestAPi.repository.custcare.HistoryManagementRepo5;
import com.telemune.VCC.RestAPi.repository.custcare.HistoryManagementRepo6;
import com.telemune.VCC.RestAPi.repository.custcare.HistoryManagementRepo7;
import com.telemune.VCC.RestAPi.repository.custcare.HistoryManagementRepo8;
import com.telemune.VCC.RestAPi.repository.custcare.HistoryManagementRepo9;
import com.telemune.VCC.RestAPi.service.HistoryManagementService;

@Service
public class HistoryManagementServiceImpl implements HistoryManagementService {

	@Autowired
	HistoryManagementRepo hisManageRepo;
	@Autowired
	HistoryManagementRepo0 hisManageRepo0;
	@Autowired
	HistoryManagementRepo1 hisManageRepo1;
	@Autowired
	HistoryManagementRepo2 hisManageRepo2;
	@Autowired
	HistoryManagementRepo3 hisManageRepo3;
	@Autowired
	HistoryManagementRepo4 hisManageRepo4;
	@Autowired
	HistoryManagementRepo5 hisManageRepo5;
	@Autowired
	HistoryManagementRepo6 hisManageRepo6;
	@Autowired
	HistoryManagementRepo7 hisManageRepo7;
	@Autowired
	HistoryManagementRepo8 hisManageRepo8;
	@Autowired
	HistoryManagementRepo9 hisManageRepo9;

	private static final Logger logger = Logger.getLogger(HistoryManagementServiceImpl.class);

	@Override
	public List<MailBoxLogBean> findByMsisdn(String msisdn) {
		List<MailBoxLogBean> finalHlrBean = new ArrayList<>();
		logger.info("Inside findByMsisdn() method function of HistoryManagementServiceImpl class");
		String num;
		num = VccCache.instance().getInternationalNumber(msisdn);

		logger.info("num  :" + num);
		String las = num.substring(num.length() - 1);

		logger.info("VCC_MailBox_Log_" + las);

		if (las.equals("0")) {
			List<MailBoxLog0> number = hisManageRepo0.findByMsisdn(msisdn);
			for (MailBoxLog0 hlr : number) {
				MailBoxLogBean hlrBean = EntityToBean.convertMailBoxLog0EntityToMailBoxLogBean(hlr);
				finalHlrBean.add(hlrBean);
			}
			logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
			return finalHlrBean;

		}

		else if (las.equals("1")) {
			List<MailBoxLog1> number = hisManageRepo1.findByMsisdn(msisdn);
			for (MailBoxLog1 hlr : number) {
				MailBoxLogBean hlrBean = EntityToBean.convertMailBoxLog1EntityToMailBoxLogBean(hlr);
				finalHlrBean.add(hlrBean);
			}
			logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
			return finalHlrBean;

		}

		else if (las.equals("2")) {
			List<MailBoxLog2> number = hisManageRepo2.findByMsisdn(msisdn);
			for (MailBoxLog2 hlr : number) {
				MailBoxLogBean hlrBean = EntityToBean.convertMailBoxLog2EntityToMailBoxLogBean(hlr);
				finalHlrBean.add(hlrBean);
			}
			logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
			return finalHlrBean;

		} else if (las.equals("3")) {
			List<MailBoxLog3> number = hisManageRepo3.findByMsisdn(msisdn);
			for (MailBoxLog3 hlr : number) {
				MailBoxLogBean hlrBean = EntityToBean.convertMailBoxLog3EntityToMailBoxLogBean(hlr);
				finalHlrBean.add(hlrBean);
			}
			logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
			return finalHlrBean;

		} else if (las.equals("4")) {
			List<MailBoxLog4> number = hisManageRepo4.findByMsisdn(msisdn);
			for (MailBoxLog4 hlr : number) {
				MailBoxLogBean hlrBean = EntityToBean.convertMailBoxLog4EntityToMailBoxLogBean(hlr);
				finalHlrBean.add(hlrBean);
			}
			logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
			return finalHlrBean;

		} else if (las.equals("5")) {
			List<MailBoxLog5> number = hisManageRepo5.findByMsisdn(msisdn);
			for (MailBoxLog5 hlr : number) {
				MailBoxLogBean hlrBean = EntityToBean.convertMailBoxLog5EntityToMailBoxLogBean(hlr);
				finalHlrBean.add(hlrBean);
			}
			logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
			return finalHlrBean;

		} else if (las.equals("6")) {
			List<MailBoxLog6> number = hisManageRepo6.findByMsisdn(msisdn);
			for (MailBoxLog6 hlr : number) {
				MailBoxLogBean hlrBean = EntityToBean.convertMailBoxLog6EntityToMailBoxLogBean(hlr);
				finalHlrBean.add(hlrBean);
			}
			logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
			return finalHlrBean;

		} else if (las.equals("7")) {
			List<MailBoxLog7> number = hisManageRepo7.findByMsisdn(msisdn);
			for (MailBoxLog7 hlr : number) {
				MailBoxLogBean hlrBean = EntityToBean.convertMailBoxLog7EntityToMailBoxLogBean(hlr);
				finalHlrBean.add(hlrBean);
			}
			logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
			return finalHlrBean;

		} else if (las.equals("8")) {
			List<MailBoxLog8> number = hisManageRepo8.findByMsisdn(msisdn);
			for (MailBoxLog8 hlr : number) {
				MailBoxLogBean hlrBean = EntityToBean.convertMailBoxLog8EntityToMailBoxLogBean(hlr);
				finalHlrBean.add(hlrBean);
			}
			logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
			return finalHlrBean;

		} else if (las.equals("9")) {
			List<MailBoxLog9> number = hisManageRepo9.findByMsisdn(msisdn);
			for (MailBoxLog9 hlr : number) {
				MailBoxLogBean hlrBean = EntityToBean.convertMailBoxLog9EntityToMailBoxLogBean(hlr);
				finalHlrBean.add(hlrBean);
			}
			logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
			return finalHlrBean;

		}

		/*
		 * List<Object> list =null; list.add(number);
		 */

		/*
		 * logger.
		 * info("Exit from findByMsisdn() method function of HistoryManagementServiceImpl class"
		 * ); return new MailBoxLogBean();
		 * 
		 */
//	}
		return finalHlrBean;
	}
}
