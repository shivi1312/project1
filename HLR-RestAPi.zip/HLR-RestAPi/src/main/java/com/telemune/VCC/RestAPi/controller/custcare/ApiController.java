package com.telemune.VCC.RestAPi.controller.custcare;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.telemune.VCC.RestAPi.common.CacheLoader;
import com.telemune.VCC.RestAPi.model.ApiRequestModel;
import com.telemune.VCC.RestAPi.model.ApiResponseModel;
import com.telemune.VCC.RestAPi.model.MyProperties;
import com.telemune.VCC.RestAPi.service.ApiRequestHandler;



@RestController
public class ApiController {
	
	final static Logger logger = Logger.getLogger(ApiController.class);
	
	@Autowired
	ApiRequestHandler profileHandler;
	
	@Autowired
	MyProperties myProp;
	
	@Autowired
	CacheLoader cacheLoader;
	
	private static Gson gson =new Gson();
	
	@GetMapping("/reloadCache")
	public String reloadCache()
	{
		int isSuccess =-1;
		isSuccess=cacheLoader.runAfterStartup();
		if(isSuccess==1)
		{
			return "Cache reload successfully!!!!!!";
		}
		else
		{
			return "Error occured in reload Cache...";
		}
	}
	
	
	@RequestMapping(value = "profile.check", method = RequestMethod.GET, produces = "application/xml")
	public @ResponseBody
	ApiResponseModel profileCheck(ApiRequestModel profileRequest,
			BindingResult bindingResult, ApiResponseModel profileResponse) {
		
		
		logger.info("Request:------>>>>"+profileRequest);
		logger.info("Response:------>>>>"+profileResponse);
		//RequestHandlerImpl profileHandler = new RequestHandlerImpl();
		//logger.debug("request is:  >>>>>>>"+ AppConfig.config.getString("profile.check", "profile.check"));
		profileResponse=profileHandler.profileCheck(profileRequest, bindingResult,
				profileResponse);

		try {
			logger.info("response:-profile.check  " + gson.toJson(profileResponse));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//profileHandler = null;
		return profileResponse;
	}
	
	/*
	 * @RequestMapping(value = "do.subscribe", method = RequestMethod.GET, produces
	 * = "application/xml") public @ResponseBody ApiResponseModel
	 * doSubscribe(ApiRequestModel profileRequest, BindingResult
	 * bindingResult,ApiResponseModel profileResponse) {
	 * profileResponse=profileHandler.subscribeProcess(profileRequest,
	 * profileResponse);
	 * 
	 * try { logger.info("response:-profile.check  " +
	 * gson.toJson(profileResponse)); } catch (Exception e) { // TODO Auto-generated
	 * catch block e.printStackTrace(); } //profileHandler = null; return
	 * profileResponse; }
	 */
}
