package com.telemune.VCC.RestAPi.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.bean.SmscBean;
import com.telemune.VCC.RestAPi.entities.HistoryData;
import com.telemune.VCC.RestAPi.entities.Smsc;
import com.telemune.VCC.RestAPi.model.BeanToEntity;
import com.telemune.VCC.RestAPi.model.EntityToBean;
import com.telemune.VCC.RestAPi.repository.HistoryDataRepo;
import com.telemune.VCC.RestAPi.repository.SmscRepo;
import com.telemune.VCC.RestAPi.service.SmscService;

@Service
//@PropertySource("classpath:webAdmin.properties")
public class SmscServiceImpl implements SmscService {

	@Autowired
	private SmscRepo smscRepo;
	
	@Autowired
	private HistoryDataRepo historyRepo;

	private static final Logger logger = Logger.getLogger(SmscServiceImpl.class);

	ArrayList smscConfigAl;
	Properties properties;
	HistoryData hisData = null;
	String result = "failure";

	public ArrayList getSmscConfigAl() {
		return smscConfigAl;
	}

	public void setSmscConfigAl(ArrayList smscConfigAl) {
		this.smscConfigAl = smscConfigAl;
	}

	
	/*
	 * public SmscServiceImpl() {
	 * 
	 * properties = new Properties(); try { String catHome =
	 * System.getenv("PROPERTY_FILE_PATH"); logger.info("property file path  || " +
	 * catHome + ""); FileInputStream fis = null; if (catHome == null) { fis = new
	 * FileInputStream(
	 * "/home/shivani/.config/property/VccAdminRest/webAdmin.properties");
	 * logger.info("fis ===" + fis); } else { fis = new FileInputStream(catHome +
	 * File.separator + "/VccAdminRest/webAdmin.properties"); logger.info("fis ==="
	 * + fis); } properties.load(fis); fis.close(); } catch (IOException e) {
	 * e.printStackTrace();
	 * 
	 * } }
	 */
	@Override
	public String createSmsc(SmscBean smscBean) {
		try {

			logger.info("Inside createSmsc() method function of SmscServiceImpl class");
			logger.info("smscBean-----" + smscBean.toString());
			smscConfigAl = new ArrayList<SmscBean>();
			//hh = new ArrayList<HistoryData>();
			if (smscBean.getStatus().equals("Activated")) {
				smscBean.setStatus(properties.getProperty("Activated"));
			}
			if (smscBean.getStatus().equals("DeActivated")) {
				smscBean.setStatus(properties.getProperty("DeActivated"));
			}
			Smsc smsc = BeanToEntity.convertSmscBeanToSmscEntity(smscBean);
			Smsc smscdb = smscRepo.save(smsc);

			hisData = new HistoryData();
			hisData.setRole("Pending role add from login hit");
			hisData.setMsg("addSuccess");
			hisData.setAction(properties.getProperty("smscmanagement"));
			hisData.setEvent(properties.getProperty("addSuccess"));
			hisData.setUser("Pending role add from login hit");
		//	hh.add(hisData);
			historyRepo.save(hisData);
			SmscBean ss = EntityToBean.convertSmscEntityToSmscBean(smscdb);
			return "success";
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		return "success";
	}

	@Override
	@Transactional
	public String updateSmsc(SmscBean smscBean) {

		logger.info("Inside updateSmsc() method of SmscServiceImpl class");
		Optional<Smsc> smscEntity = smscRepo.findBySmscId(smscBean.getSmscId());
		if (smscEntity.isPresent()) {
			logger.info("id present");
			logger.info("going to update ");
			Smsc smscEntity1 = BeanToEntity.convertSmscBeanToSmscEntity(smscBean);
			Smsc smscEntitydb = smscRepo.save(smscEntity1);
			smscConfigAl = new ArrayList<SmscBean>();
		//	hh = new ArrayList<HistoryData>();
			hisData = new HistoryData();
			hisData.setRole("Pending role add from login hit");
			hisData.setMsg("Smsc [" + smscEntity1.getSmscUserId() + "] Add [User Already Exist]");
			hisData.setAction(properties.getProperty("smscmanagement"));
			hisData.setEvent(properties.getProperty("addSuccess"));
			hisData.setUser("Pending role add from login hit");
			//hh.add(hisData);
			historyRepo.save(hisData);
			EntityToBean.convertSmscEntityToSmscBean(smscEntitydb);
			return "success";
		} else
			logger.info("Exit from updateSmsc() method function of SmscServiceImpl class");
		return "failure";
	}

	@Override
	public List<SmscBean> findAllSmsc() {

		logger.info("Inside findAllSmsc() method function of SmscServiceImpl class");
		List<SmscBean> finalsmscBean = new ArrayList<>();

		smscConfigAl = new ArrayList<SmscBean>();

		List<Smsc> userdbList = smscRepo.findAll();

		for (Smsc smsc : userdbList) {
			SmscBean hlrBean = EntityToBean.convertSmscEntityToSmscBean(smsc);
			finalsmscBean.add(hlrBean);
		}
		logger.info("Exit from  findAllSmsc() method function of SmscServiceImpl class");
		return finalsmscBean;

	}

	@Override
	public SmscBean findBySmscId(Integer smscId) {
		logger.info("Inside findBySmscId() method function of SmscServiceImpl class");
		Optional<Smsc> smscid = smscRepo.findBySmscId(smscId);

		smscConfigAl = new ArrayList<Smsc>();

		logger.info("check by smscId");

		if (smscid.isPresent()) {

			logger.info("SmscId present in findBySmscId() method function of SmscServiceImpl class");

			return EntityToBean.convertSmscEntityToSmscBean(smscid.get());

		}
		logger.info("Exit from findBySmscId() method function of SmscServiceImpl class");

		return new SmscBean();
	}

	@Override
	@Transactional
	public boolean DeleteSmscById(Integer smscId) {

		Optional<Smsc> smsc = smscRepo.findBySmscId(smscId);

		logger.info("Inside DeleteSmscById() method of SmscServiceImpl class");

		logger.debug(smsc.toString());

		try {
			if (smsc.isPresent()) {
				smscRepo.deleteBySmscId(smscId);
				logger.info("Exit DeleteSmscById() method of SmscServiceImpl class");
				return true;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		logger.info("Exit DeleteSmscById() method of SmscServiceImpl class");
		return false;

	}

}
