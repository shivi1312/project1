package com.telemune.VCC.RestAPi.entities.custcare;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.telemune.VCC.RestAPi.entities.embedded.SubscriptionMasterPriKeys;
@Entity
@Table(name = "vcc_subscription_master_0")
public class SubscriptionMaster0 implements Serializable{
	
	@EmbeddedId
	SubscriptionMasterPriKeys subscriptionMasterPriKeys;
	
	@Column(name = "EXPIRY_DATE", nullable = false)
	private Date expDate;
	
	@Column(name = "RATE_PLAN", columnDefinition = "Integer default 0")
	private Integer ratePlan;
	
	@Column(name = "DATE_REGISTERED")
	private Date regDate;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "SERVICE_FLAG", nullable = false, columnDefinition = "varchar(15) default '0000000000'")
	private String serviceFlag;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_VISIT_TIME", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date lastTimeVisit;
	
	public Date getExpDate() {
		return expDate;
	}
	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}
	public Integer getRatePlan() {
		return ratePlan;
	}
	public void setRatePlan(Integer ratePlan) {
		this.ratePlan = ratePlan;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getServiceFlag() {
		return serviceFlag;
	}
	public void setServiceFlag(String serviceFlag) {
		this.serviceFlag = serviceFlag;
	}
	public Date getLastTimeVisit() {
		return lastTimeVisit;
	}
	public void setLastTimeVisit(Date lastTimeVisit) {
		this.lastTimeVisit = lastTimeVisit;
	}
	@Override
	public String toString() {
		return "SubscriptionMaster0 [expDate=" + expDate + ", ratePlan=" + ratePlan + ", regDate=" + regDate
				+ ", status=" + status + ", serviceFlag=" + serviceFlag + ", lastTimeVisit=" + lastTimeVisit + "]";
	}
	
	
}
