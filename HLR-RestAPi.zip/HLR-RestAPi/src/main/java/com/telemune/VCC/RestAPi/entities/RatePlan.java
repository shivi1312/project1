package com.telemune.VCC.RestAPi.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "VCC_RATE_PLAN")
public class RatePlan {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="PLAN_ID",nullable = false)
	private Integer planId;
	
	
	@Column(name = "SUB_CODE",nullable = false)   
	private Integer subCode;
	
	@Column(name = "SUB_VALIDITY",nullable = false)         
	private Integer subValidity;
	@Column(name = "RENEW",nullable = false) 
	private Integer renew;
	
	@Column(name = "RENEW_VALIDITY",nullable = false)  
	private Integer renewValidity;
	
	@Column(name = "REMARKS")      
	private String remarks;
	@Column(name = "RETRIEVE_CODE",nullable = false) 
	private Integer retCode;
	
	
	
	@Column(name = "RECORD_CODE",nullable = false)   
	private Integer recordCode;
	
	
	@Column(name = "GROUP_RECORD_CODE")  
	private Integer grpRecordCode;
	
	
	@Column(name = "SERVICE_TYPE")           
	private String servicetype;
	
	@Column(name = "PULL_SMS_CODE")
	private Integer pullSmsCode;
	
	@Column(name = "PLAN_NAME",nullable = false)
	private String planName;
	@Column(name = "SCOPE",nullable = false)
	
	private String scope;
	@Column(name = "MAILBOX_ID",nullable = false)
	private Integer mailBoxId;
	@Column(name = "IVR_FLOW")  
	private String ivrFlow;
	public Integer getPlanId() {
		return planId;
	}
	public void setPlanId(Integer planId) {
		this.planId = planId;
	}
	public Integer getSubCode() {
		return subCode;
	}
	public void setSubCode(Integer subCode) {
		this.subCode = subCode;
	}
	public Integer getSubValidity() {
		return subValidity;
	}
	public void setSubValidity(Integer subValidity) {
		this.subValidity = subValidity;
	}
	public Integer getRenew() {
		return renew;
	}
	public void setRenew(Integer renew) {
		this.renew = renew;
	}
	public Integer getRenewValidity() {
		return renewValidity;
	}
	public void setRenewValidity(Integer renewValidity) {
		this.renewValidity = renewValidity;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Integer getRetCode() {
		return retCode;
	}
	public void setRetCode(Integer retCode) {
		this.retCode = retCode;
	}
	public Integer getRecordCode() {
		return recordCode;
	}
	public void setRecordCode(Integer recordCode) {
		this.recordCode = recordCode;
	}
	public Integer getGrpRecordCode() {
		return grpRecordCode;
	}
	public void setGrpRecordCode(Integer grpRecordCode) {
		this.grpRecordCode = grpRecordCode;
	}
	public String getServicetype() {
		return servicetype;
	}
	public void setServicetype(String servicetype) {
		this.servicetype = servicetype;
	}
	public Integer getPullSmsCode() {
		return pullSmsCode;
	}
	public void setPullSmsCode(Integer pullSmsCode) {
		this.pullSmsCode = pullSmsCode;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	public Integer getMailBoxId() {
		return mailBoxId;
	}
	public void setMailBoxId(Integer mailBoxId) {
		this.mailBoxId = mailBoxId;
	}
	public String getIvrFlow() {
		return ivrFlow;
	}
	public void setIvrFlow(String ivrFlow) {
		this.ivrFlow = ivrFlow;
	}
	@Override
	public String toString() {
		return "RatePlan [planId=" + planId + ", subCode=" + subCode + ", subValidity=" + subValidity + ", renew="
				+ renew + ", renewValidity=" + renewValidity + ", remarks=" + remarks + ", retCode=" + retCode
				+ ", recordCode=" + recordCode + ", grpRecordCode=" + grpRecordCode + ", servicetype=" + servicetype
				+ ", pullSmsCode=" + pullSmsCode + ", planName=" + planName + ", scope=" + scope + ", mailBoxId="
				+ mailBoxId + ", ivrFlow=" + ivrFlow + "]";
	}

	
	
}
