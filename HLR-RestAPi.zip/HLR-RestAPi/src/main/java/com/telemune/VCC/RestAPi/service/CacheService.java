package com.telemune.VCC.RestAPi.service;

public class CacheService {

}
