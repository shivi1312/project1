package com.telemune.VCC.RestAPi.model;

import org.springframework.stereotype.Component;

@Component
public class VccRuleEngineRequest {
	
    private String msisdn;

    private String actionId;
    
    private String tid;

    private String channel;
    
    private String interFace;
    
    private String serviceType;

    private String planName;
    
    private int lang;
    
    private String appId;
     
    private String reqBy;
    
    private int actTrg;
    
    private String subType="N";
    
    
    

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getInterFace() {
		return interFace;
	}

	public void setInterFace(String interFace) {
		this.interFace = interFace;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public int getLang() {
		return lang;
	}

	public void setLang(int lang) {
		this.lang = lang;
	}

	public String getPlanName ()
    {
        return planName;
    }

    public void setPlanName (String planName)
    {
        this.planName = planName;
    }

    public String getMsisdn ()
    {
        return msisdn;
    }

    public void setMsisdn (String msisdn)
    {
        this.msisdn = msisdn;
    }

    public String getTid ()
    {
        return tid;
    }

    public void setTid (String tid)
    {
        this.tid = tid;
    }

    public String getActionId ()
    {
        return actionId;
    }

    public void setActionId (String actionId)
    {
        this.actionId = actionId;
    }

    public String getServiceType ()
    {
        return serviceType;
    }

    public void setServiceType (String serviceType)
    {
        this.serviceType = serviceType;
    }

   
    public String getChannel ()
    {
        return channel;
    }

    public void setChannel (String channel)
    {
        this.channel = channel;
    }

    
    public String getReqBy() {
		return reqBy;
	}

	public void setReqBy(String reqBy) {
		this.reqBy = reqBy;
	}

	@Override
    public String toString()
    {
        return "VccSubscribeRequest [planName = "+planName+", msisdn = "+msisdn+", tid = "+tid+", actionId = "+actionId+", serviceType = "+serviceType+", interface = "+interFace+", channel = "+channel+" reqBy="+reqBy+"]";
    }

	public int getActTrg() {
		return actTrg;
	}

	public void setActTrg(int actTrg) {
		this.actTrg = actTrg;
	}

	
	

}
