package com.telemune.VCC.RestAPi.bean;

import java.util.List;

public class RolesBean {


	private Integer roleId;

	
	  private String roleName;

	
	  private String description;
	  
	  private List<HttpLinkBean> httpLinkslst;
	 
	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	
	  public String getRoleName() { return roleName; }
	  
	  public void setRoleName(String roleName) { this.roleName = roleName; }
	  
	
	  public String getDescription() { return description; }
	  
	  public void setDescription(String description) { this.description =
	  description; }
	  
	  
	  
	  
	public List<HttpLinkBean> getHttpLinkslst() {
		return httpLinkslst;
	}

	public void setHttpLinkslst(List<HttpLinkBean> httpLinkslst) {
		this.httpLinkslst = httpLinkslst;
	}

	@Override
	public String toString() {
		return "RolesBean [roleId=" + roleId + ", roleName=" + roleName + ", description=" + description
				+ ", httpLinkslst=" + httpLinkslst + "]";
	}
	
	

}
