package com.telemune.VCC.RestAPi.repository.custcare;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog4;

public interface HistoryManagementRepo4 extends JpaRepository<MailBoxLog4, Integer> {
	
	List<MailBoxLog4> findByMsisdn(String msisdn);
}
