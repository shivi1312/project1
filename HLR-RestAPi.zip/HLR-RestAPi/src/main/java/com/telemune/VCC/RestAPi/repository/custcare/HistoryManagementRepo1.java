package com.telemune.VCC.RestAPi.repository.custcare;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog1;

public interface HistoryManagementRepo1 extends JpaRepository<MailBoxLog1, Integer> {
	
	List<MailBoxLog1> findByMsisdn(String msisdn);
}