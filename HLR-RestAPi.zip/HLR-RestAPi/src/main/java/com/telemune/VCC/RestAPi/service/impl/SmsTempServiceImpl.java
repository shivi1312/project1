package com.telemune.VCC.RestAPi.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.bean.SmsTempBean;
import com.telemune.VCC.RestAPi.bean.SmsTemplateDetail;
import com.telemune.VCC.RestAPi.entities.SmsTemp;
import com.telemune.VCC.RestAPi.entities.embedded.SmsTempEmbedded;
import com.telemune.VCC.RestAPi.model.BeanToEntity;
import com.telemune.VCC.RestAPi.model.EntityToBean;
import com.telemune.VCC.RestAPi.repository.LbsTemplatesRepository;
import com.telemune.VCC.RestAPi.repository.SmsTempRepo;
import com.telemune.VCC.RestAPi.service.SmsTempService;


@Service
public class SmsTempServiceImpl implements SmsTempService {

	@Autowired
	private SmsTempRepo smsTempRepo;
	@Autowired
	 LbsTemplatesRepository lbsTemplatesRepository;
	
private static HashMap<String, String> TemplateDetails = new HashMap<String, String>();


	private static final Logger logger = Logger.getLogger(SmsTempServiceImpl.class);
	ArrayList smsTempConfigAl;

	public ArrayList getSmsTempConfigAl() {
		return smsTempConfigAl;
	}

	public void setSmsTempConfigAl(ArrayList smsTempConfigAl) {
		this.smsTempConfigAl = smsTempConfigAl;
	}
	
	
	

	@Override
	public SmsTempBean  createSmsTemp(SmsTempBean  smscBean) {
		SmsTemp lbsTemplate;
		try {
		
			SmsTemp smsc = BeanToEntity.convertSmsTempBeanToSmsTempEntity(smscBean);
			//lbsTemplate.setSmsTempEmbedded(smsTempEmbedded);
	//		smsc.setSmsTempEmbedded();
			
				logger.info("smscbean data------" + smsc);
				SmsTemp smscdb = smsTempRepo.save(smsc);
				logger.info("smsc data in entity------" + smscdb.toString());
				logger.info("Exit from createSmsc() method function of SmscServiceImpl class");
				return EntityToBean.convertSmsTempEntityToSmsTempBean(smscdb);

			}
		 catch (Exception ex) {
			ex.printStackTrace();
		}
		return new SmsTempBean();
	}

	
	
	
	@Override
	public SmsTempBean findByTemplateIdAndLanguageId(Integer id, Integer languageId) {
		
		logger.info("Inside findByTemplateIdAndLanguageId() method of LbsTemplatelmpl class");
		Optional<SmsTemp> tempdb = smsTempRepo.findBySmsTempEmbedded(new SmsTempEmbedded(id, languageId));
		logger.debug(tempdb);
		if (tempdb.isPresent()) {
			return EntityToBean.convertSmsTempEntityToSmsTempBean(tempdb.get());
		}
		logger.info("Exit findByTemplateIdAndLanguageId() method of LbsTemplatelmpl class");
		return new SmsTempBean();
	}

	/*
	 * @Override public List<SmsTempBean> findByTemplateId(Integer id) {
	 * List<SmsTemp> tempdblst = smsTempRepo.findBySmsTempEmbeddedTempId(id);
	 * 
	 * logger.info("Inside findByTemplateId() method of LbsTemplatelmpl class"); if
	 * (tempdblst != null) {
	 * 
	 * List<SmsTempBean> ltlst = new ArrayList<>();
	 * 
	 * for (SmsTemp lt : tempdblst) {
	 * 
	 * ltlst.add(EntityToBean.convertSmsTempEntityToSmsTempBean(lt)); }
	 * logger.debug(tempdblst.toString());
	 * logger.info("Exit findByTemplateId() method of LbsTemplatelmpl class");
	 * return ltlst; } return new ArrayList<>(); }
	 * 
	 */
	@Override
	public List<SmsTempBean> findByTemplateId(Integer id) {
		logger.info("in LoadSMSTemplates()");
	try {
		String key = "";
		List<Object[]> rows = lbsTemplatesRepository.loadSmsTemplates();
		System.out.println(rows);
		for (Object[] row : rows) {
			try{
				key = row[0] + "-" + row[2];
				TemplateDetails.put(key, (String)row[1]);
				System.out.println(TemplateDetails);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}catch (Exception e) {
		logger.error("Exception insdie Load SMSKeyword()" + e.getMessage());
		e.printStackTrace();// TODO: handle exception
		return new ArrayList<>();	}
	return new ArrayList<>();

}


	
	@Override
	@Transactional
	public boolean templateDeleteById(Integer id) {

		logger.info("Inside templateDeleteById() method of ILbsTemplatelmpl class");

		List<SmsTemp> tempdblst = smsTempRepo.findBySmsTempEmbeddedTempId(id);
		logger.debug(tempdblst);
		if (tempdblst != null && !tempdblst.isEmpty()) {
			smsTempRepo.deleteAllBySmsTempEmbeddedTempId(id);
			logger.info("Exit templateDeleteById() method of LbsTemplatelmpl class");
			return true;
		}
		logger.info("Exit templateDeleteById() method of LbsTemplatelmpl class");
		return false;
	}

	
	/*
	 * @Override public List<SmsTempBean> findByLanguageId(Integer id) {
	 * 
	 * logger.info("Inside findByLanguageId() method of LbsTemplatelmpl class");
	 * 
	 * List<SmsTemp> tempdblst = smsTempRepo.findBySmsTempEmbeddedLangId(id);
	 * 
	 * logger.debug(tempdblst.toString());
	 * 
	 * List<SmsTempBean> ltlst = new ArrayList<>(); for (SmsTemp lt : tempdblst) {
	 * ltlst.add(EntityToBean.convertSmsTempEntityToSmsTempBean(lt)); }
	 * logger.info("Exit findByLanguageId() method of LbsTemplatelmpl class");
	 * return ltlst;
	 * 
	 * }
	 */
	 

	@Override
	public List<SmsTempBean> findAllTemplate() {

		logger.info("Inside findAllTemplate() method of LbsTemplatelmpl class");

		List<SmsTemp> tempdblst = smsTempRepo.findAll();
		
		logger.debug(tempdblst);

		if (tempdblst != null) {

			List<SmsTempBean> ltlst = new ArrayList<>();

			for (SmsTemp lt : tempdblst) {

				ltlst.add(EntityToBean.convertSmsTempEntityToSmsTempBean(lt));
			}
			logger.info("Exit findAllTemplate() method of LbsTemplatelmpl class");
			return ltlst;
		}
		logger.info("Exit findAllTemplate() method of LbsTemplatelmpl class");
		return new ArrayList<>();
	}

	@Override
	public SmsTempBean updateTemplate(SmsTempBean lbsTemplateVO) {

		logger.info("Inside updateTemplate() method of ILbsTemplatelmpl class");

		SmsTemp lbsTemplate=null;
		try {
			for (SmsTemplateDetail std : lbsTemplateVO.getSmsTemplateDetaillst()) {
				Optional<SmsTemp> lbsTempdb = smsTempRepo
						.findBySmsTempEmbedded(new SmsTempEmbedded(std.getTempId(), std.getLangId()));
logger.info("find  ====="+lbsTempdb);
				if (lbsTempdb.isPresent()) {

					lbsTempdb.get().setTempMsg(std.getTempMsg());

					lbsTemplate = smsTempRepo.save(lbsTempdb.get());
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		logger.debug("data saved ==="+lbsTemplate);

		logger.info("Exit updateTemplate() method of LbsTemplatelmpl class");

		return EntityToBean.convertSmsTempEntityToSmsTempBean(lbsTemplate);
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	

	/*
	 * @Override public SmsTempBean updateTemplate(SmsTempBean
	 * smsTempBean,SmsTemplateDetail std1 ) {
	 * 
	 * logger.info("Inside updateTemplate() method of ILbsTemplatelmpl class");
	 * 
	 * SmsTemp lbsTemplate = null;
	 * 
	 * for (SmsTemplateDetail std : smsTempBean.getSmsTemplateDetaillst()) {
	 * logger.info("try ch aagya"); Optional<SmsTemp> lbsTempdb = smsTempRepo
	 * .findBySmsTempEmbedded(new SmsTempEmbedded(std.getTempId(),
	 * std.getLangId())); logger.info("optional toh baadd  ====" + lbsTempdb);
	 * 
	 * if (lbsTempdb.isPresent()) {
	 * 
	 * lbsTempdb.get().setTempMsg(std.getTempMsg());
	 * 
	 * lbsTemplate = smsTempRepo.save(lbsTempdb.get()); }
	 * 
	 * 
	 * }
	 * 
	 * logger.debug(lbsTemplate);
	 * 
	 * logger.info("Exit updateTemplate() method of LbsTemplatelmpl class");
	 * 
	 * return EntityToBean.convertSmsTempEntityToSmsTempBean(lbsTemplate); }
	 * 
	 * @Override public List<SmsTempBean> findAllTemplate() {
	 * 
	 * logger.info("Inside findAllTemplate() method of LbsTemplatelmpl class");
	 * 
	 * List<SmsTemp> tempdblst = smsTempRepo.findAll();
	 * 
	 * logger.debug(tempdblst);
	 * 
	 * if (tempdblst != null) {
	 * 
	 * List<SmsTempBean> ltlst = new ArrayList<>();
	 * 
	 * for (SmsTemp lt : tempdblst) {
	 * 
	 * // SmsTempEmbeddedBean smsBean=new SmsTempEmbeddedBean((Integer)lt[0], //
	 * (Integer)lt[1]); // logger.info("SmsTempEmbeddedBean data ==="+smsBean); //
	 * ltlst.add(smsBean);
	 * 
	 * SmsTempBean smsBean1 = EntityToBean.convertSmsTempEntityToSmsTempBean(lt);
	 * ltlst.add(smsBean1); }
	 * logger.info("Exit findAllTemplate() method of LbsTemplatelmpl class"); return
	 * ltlst; }
	 * logger.info("Exit findAllTemplate() method of LbsTemplatelmpl class"); return
	 * new ArrayList<>(); }
	 */
}
