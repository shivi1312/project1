package com.telemune.VCC.RestAPi.entities.embedded;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class SmsTempEmbedded implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Column(name = "LANGUAGE_ID", nullable = false,columnDefinition = "boolean default false")
	private Integer langId;
	
	
	
	@Column(name = "TEMPLATE_ID", nullable = false,columnDefinition = "boolean default false")
    private Integer tempId;



	public SmsTempEmbedded(){
	}
	
	
	public SmsTempEmbedded(Integer tempId,Integer langId) {
		this.langId = langId;
		this.tempId = tempId;
	}
	public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SmsTempEmbedded that = (SmsTempEmbedded) o;

        if (!tempId.equals(that.tempId)) return false;
        return langId.equals(that.langId);
    }
	
	
	public Integer getLangId() {
		return langId;
	}


	public void setLangId(Integer langId) {
		this.langId = langId;
	}


	public Integer getTempId() {
		return tempId;
	}


	public void setTempId(Integer tempId) {
		this.tempId = tempId;
	}



	@Override
	public String toString() {
		return "SmsTempEmbedded [langId=" + langId + ", tempId=" + tempId + "]";
	}

	
	
	
}
