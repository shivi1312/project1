package com.telemune.VCC.RestAPi.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="ROLE")
public class Role implements Serializable{

	@Id
    @Column(name = "ROLE_ID", updatable = false, nullable = false)
	private Integer roleId;

	//@OneToOne(mappedBy = "admin_user")
	  @Column(name = "ROLE_NAME") 
	  private String roleName;
	
	
	


	@Column(name = "DESCRIPTION") 
	  private String description;
	 
	/*
	 * @ManyToMany(cascade = javax.persistence.CascadeType.PERSIST)
	 * 
	 * @JoinTable(name = "web_access", joinColumns = @JoinColumn(name = "ROLE_ID"),
	 * inverseJoinColumns = @JoinColumn(name = "LINK_ID")) private List<HttpLinks>
	 * httpLinks;
	 * 
	 */
	public Integer getRoleId() {
		return roleId;
	}


	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	
	  public String getRoleName() { return roleName; }
	  
	  public void setRoleName(String roleName) { this.roleName = roleName; }
	  
	  
	  public String getDescription() { return description; }
	  
	  
	  public void setDescription(String description) { this.description =
	  description; }
	  
	 
	
	/*
	 * public List<HttpLinks> getHttpLinks() { return httpLinks; }
	 * 
	 * 
	 * public void setHttpLinks(List<HttpLinks> httpLinks) { this.httpLinks =
	 * httpLinks; }
	 */


	


	@Override
	public String toString() {
		return "Roles [roleId=" + roleId + ", roleName=" + roleName + ", description=" + description + "]";
	}

	
}
