package com.telemune.VCC.RestAPi.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "app_config_params")
public class AppConfig implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "PARAM_NAME",nullable = false)
	private String paramName;  
	
	@Column(name = "PARAM_ID")
	private Integer paramId;
	
	@Column(name = "PARAM_VALUE")
	private String paramValue;
	
	@Column(name = "SERVICE_NAME",nullable = false)
	private String serviceName;
	
	@Column(name = "OWNER",nullable = false)
	private String owner;
	
	@Column(name = "PARAM_TYPE",columnDefinition = "varchar(20) default 'STRING'")
	private String paramType;
 
	@Column(name = "REMARKS") 
	private String remarks;

	public Integer getParamId() {
		return paramId;
	}

	public void setParamId(Integer paramId) {
		this.paramId = paramId;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getParamType() {
		return paramType;
	}

	public void setParamType(String paramType) {
		this.paramType = paramType;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "AppConfig [paramId=" + paramId + ", paramName=" + paramName + ", paramValue=" + paramValue
				+ ", serviceName=" + serviceName + ", owner=" + owner + ", paramType=" + paramType + ", remarks="
				+ remarks + "]";
	}

	
}
