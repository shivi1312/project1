package com.telemune.VCC.RestAPi.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.bean.SmsKeywordBean;
import com.telemune.VCC.RestAPi.entities.SmsKeyword;
import com.telemune.VCC.RestAPi.model.EntityToBean;
import com.telemune.VCC.RestAPi.repository.SmsKeywordRepo;
import com.telemune.VCC.RestAPi.service.SmsKeywordService;

@Service
public class SmsKeywordServiceImpl implements SmsKeywordService {

	private static final Logger logger = Logger.getLogger(SmsKeywordServiceImpl.class);

	@Autowired
	private SmsKeywordRepo smsKeywordRepo;

	@Override
	public List<SmsKeywordBean> findAllSmsKeywords() {

		logger.info("Inside findAllHlr() method function of HlrServiceImpl class");
		List<SmsKeywordBean> finalHlrBean = new ArrayList<>();
		List<SmsKeyword> userdbList = smsKeywordRepo.findAll();

		for (SmsKeyword hlr : userdbList) {
			SmsKeywordBean hlrBean = EntityToBean.convertSmsKeywordEntityToSmsKeywordBean(hlr);
			finalHlrBean.add(hlrBean);
		}
		logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
		return finalHlrBean;
	}

	
	  @Override public SmsKeywordBean findByReqKeyword(String requestkeyword) {
	  logger.info("Inside findByHlrId() method function of HlrServiceImpl class");
	  
	  Optional<SmsKeyword> hlrid =
	  smsKeywordRepo.findByrequestkeyword(requestkeyword);
	  logger.info("check by hlrId");
	  
	  if (hlrid.isPresent()) {
	  
	  logger.info("Exit from findByHlrId() method function of HlrServiceImpl class"
	  );
	  
	  return EntityToBean.convertSmsKeywordEntityToSmsKeywordBean(hlrid.get());
	  
	  }
	  logger.info("Exit from findByHlrId() method function of HlrServiceImpl class"
	  );
	  
	  return new SmsKeywordBean(); }
	 
	/*
	 * @Override
	 * 
	 * @Transactional public SmsKeywordBean updateSmsKeyword(SmsKeywordBean hlrBean)
	 * {
	 * 
	 * logger.info("Inside updateHlr() method of HlrServiceImpl class");
	 * Optional<SmsKeyword> hlrEntity =
	 * smsKeywordRepo.findByrequestkeyword(hlrBean.getRequestkeyword()); if
	 * (hlrEntity.isPresent()) {
	 * 
	 * logger.info("id present");
	 * 
	 * Optional<SmsKeyword> hlr =
	 * smsKeywordRepo.findByHlrName(hlrBean.getRequestkeyword());
	 * logger.info("hlr name " + hlr);
	 * 
	 * if (hlr.isPresent()) { logger.info("hlr Already Exist with name===" +
	 * hlrEntity.get().getProcessname()); } else {
	 * 
	 * logger.info("going to update "); SmsKeyword hlrEntity1 =
	 * BeanToEntity.convertSmsKeywordBeanToSmsKeywordEntity(hlrBean);
	 * 
	 * // adminUser.setPassword(passwordEncoder.encode(userVO.getPassword()));
	 * 
	 * // MarketPlaceRoles marketPlaceRoles = //
	 * marketPlaceRolesRepository.findByRoleId(userVO.getRoleId());
	 * 
	 * // adminUser.setMarketPlaceRoles(marketPlaceRoles);
	 * 
	 * SmsKeyword hlrEntitydb = smsKeywordRepo.save(hlrEntity1);
	 * 
	 * logger.info("Exit from updateHlr() method function of HlrServiceImpl class");
	 * 
	 * return EntityToBean.convertSmsKeywordEntityToSmsKeywordBean(hlrEntitydb); //}
	 * } else
	 * logger.info("Exit from updateHlr() method function of HlrServiceImpl class");
	 * return new SmsKeywordBean(); }
	 */
}
