package com.telemune.VCC.RestAPi.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VCC_SERIES_Range")
public class SeriesRange {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="RANGE_ID",nullable = false)
	private Integer rangeId;	 

	 @Column(name="START_RANGE",nullable = false)
	 private String startRange;
	 
	 @Column(name="END_RANGE",nullable = false)

	 private String endRange;
	 @Column(name="TYPE")
	 private String type;
	 
	 @Column(name="GROUP_ID")
	 private Integer grpId;
	 
	 @Column(name="TIMESTAMP",nullable = false)
	 private Date date;

	public Integer getRangeId() {
		return rangeId;
	}

	public void setRangeId(Integer rangeId) {
		this.rangeId = rangeId;
	}

	public String getStartRange() {
		return startRange;
	}

	public void setStartRange(String startRange) {
		this.startRange = startRange;
	}

	public String getEndRange() {
		return endRange;
	}

	public void setEndRange(String endRange) {
		this.endRange = endRange;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getGrpId() {
		return grpId;
	}

	public void setGrpId(Integer grpId) {
		this.grpId = grpId;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "SeriesRange [rangeId=" + rangeId + ", startRange=" + startRange + ", endRange=" + endRange + ", type="
				+ type + ", grpId=" + grpId + ", date=" + date + "]";
	}
	 
	 
}
