package com.telemune.VCC.RestAPi.bean;

import java.util.List;



public class SmsTempBean {

	private Integer tempId;
	
	private Integer tempType;
	
	private String tempMsg;

	private String tokenAllowed;
	
	private Integer langId;
	
	private String tempDesc;
	
	private String serviceType;
	
	private List<SmsTemplateDetail>  smsTemplateDetaillst;
	
	



	public Integer getTempId() {
		return tempId;
	}

	public void setTempId(Integer tempId) {
		this.tempId = tempId;
	}

	public Integer getTempType() {
		return tempType;
	}

	public void setTempType(Integer tempType) {
		this.tempType = tempType;
	}

	public String getTempMsg() {
		return tempMsg;
	}

	public void setTempMsg(String tempMsg) {
		this.tempMsg = tempMsg;
	}

	public String getTokenAllowed() {
		return tokenAllowed;
	}

	public void setTokenAllowed(String tokenAllowed) {
		this.tokenAllowed = tokenAllowed;
	}

	public Integer getLangId() {
		return langId;
	}

	public void setLangId(Integer langId) {
		this.langId = langId;
	}

	public String getTempDesc() {
		return tempDesc;
	}

	public void setTempDesc(String tempDesc) {
		this.tempDesc = tempDesc;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public List<SmsTemplateDetail> getSmsTemplateDetaillst() {
		return smsTemplateDetaillst;
	}

	public void setSmsTemplateDetaillst(List<SmsTemplateDetail> smsTemplateDetaillst) {
		this.smsTemplateDetaillst = smsTemplateDetaillst;
	}

	@Override
	public String toString() {
		return "SmsTempBean [tempId=" + tempId + ", tempType=" + tempType + ", tempMsg=" + tempMsg + ", tokenAllowed="
				+ tokenAllowed + ", langId=" + langId + ", tempDesc=" + tempDesc + ", serviceType=" + serviceType
				+ ", smsTemplateDetaillst=" + smsTemplateDetaillst + "]";
	}
	
	
	
	
	
}
