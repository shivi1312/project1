package com.telemune.VCC.RestAPi.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VCC_SERIES_GROUP")
public class SeriesGroup {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="GROUP_ID",nullable = false)
	private Integer grpId;
	@Column(name="GROUP_Name")
	private String grpName;
	
	
	public Integer getGrpId() {
		return grpId;
	}
	public void setGrpId(Integer grpId) {
		this.grpId = grpId;
	}
	public String getGrpName() {
		return grpName;
	}
	public void setGrpName(String grpName) {
		this.grpName = grpName;
	}
	@Override
	public String toString() {
		return "SeriesRange [grpId=" + grpId + ", grpName=" + grpName + "]";
	}
	
	

}
