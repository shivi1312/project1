package com.telemune.VCC.RestAPi.entities.custcare;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "vcc_auth_user_3")
public class AuthUser3 {

	@Id
	@Column(name = "MSISDN", nullable = false)
	private String msisdn;

	@Column(name = "LOGIN_NAME")
	private String loginName;

	@Column(name = "WPIN", nullable = false, columnDefinition = "varchar(15) default '0000'")
	private String wPin;

	@Column(name = "LANGUAGE")
	private Integer lang;

	@Column(name = "SERVICE_TYPE")
	private String serviceType;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "DELIVERY_INTERFACE", columnDefinition = "Integer default 1")
	private Integer delInterface;

	@Column(name = "PASS", nullable = false, columnDefinition = "varchar(15) default '0000'")
	private String pass;

	@Column(name = "GREETING_TYPE", columnDefinition = "Integer default 0")
	private Integer greetingType;

	@Column(name = "STATUS", nullable = false, columnDefinition = "varchar(5) default 'A'")
	private String status;
	
	@Column(name = "SUB_TYPE", nullable = false, columnDefinition = "varchar(5) default 'N'")
	private String subType;
	
	@Column(name = "IMSI")
	private String imsi;
	
	@Column(name = "CLASS_TYPE", columnDefinition = "Integer default 1")
	private Integer classType;

	@Column(name = "ISNEW", columnDefinition = "Integer default 1")
	private Integer isNew;

	@Column(name = "ISMIGRATING", columnDefinition = "Integer default 1")
	private Integer isMigration;

	@Column(name = "tid")
	private String tid;

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getwPin() {
		return wPin;
	}

	public void setwPin(String wPin) {
		this.wPin = wPin;
	}

	public Integer getLang() {
		return lang;
	}

	public void setLang(Integer lang) {
		this.lang = lang;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getDelInterface() {
		return delInterface;
	}

	public void setDelInterface(Integer delInterface) {
		this.delInterface = delInterface;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public Integer getGreetingType() {
		return greetingType;
	}

	public void setGreetingType(Integer greetingType) {
		this.greetingType = greetingType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public Integer getClassType() {
		return classType;
	}

	public void setClassType(Integer classType) {
		this.classType = classType;
	}

	public Integer getIsNew() {
		return isNew;
	}

	public void setIsNew(Integer isNew) {
		this.isNew = isNew;
	}

	public Integer getIsMigration() {
		return isMigration;
	}

	public void setIsMigration(Integer isMigration) {
		this.isMigration = isMigration;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	@Override
	public String toString() {
		return "AuthUser [msisdn=" + msisdn + ", loginName=" + loginName + ", wPin=" + wPin + ", lang=" + lang
				+ ", serviceType=" + serviceType + ", email=" + email + ", delInterface=" + delInterface + ", pass="
				+ pass + ", greetingType=" + greetingType + ", status=" + status + ", subType=" + subType + ", imsi="
				+ imsi + ", classType=" + classType + ", isNew=" + isNew + ", isMigration=" + isMigration + ", tid="
				+ tid + "]";
	}

}
