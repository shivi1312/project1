package com.telemune.VCC.RestAPi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.telemune.VCC.RestAPi.entities.LbsTemplates;
import com.telemune.VCC.RestAPi.entities.embedded.LbsTemplatePriKeys;

@Repository
public interface LbsTemplatesRepository extends JpaRepository<LbsTemplates,LbsTemplatePriKeys>
{
	
@Query(value="select lbsTemplatePriKeys.templateId,templateMessage,lbsTemplatePriKeys.languageId from LbsTemplates")
List<Object[]> loadSmsTemplates();


}
