package com.telemune.VCC.RestAPi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.ChargingRule;

public interface ChargingRuleRepo extends JpaRepository<ChargingRule , Integer>{
	
	Optional<ChargingRule> findByChargingCode(Integer chargingCode);
	void deleteByChargingCode(Integer chargingCode);
}
