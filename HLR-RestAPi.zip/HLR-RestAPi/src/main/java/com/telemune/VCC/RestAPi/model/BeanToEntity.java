package com.telemune.VCC.RestAPi.model;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.telemune.VCC.RestAPi.bean.AppConfigBean;
import com.telemune.VCC.RestAPi.bean.ChargingRuleBean;
import com.telemune.VCC.RestAPi.bean.HlrBean;
import com.telemune.VCC.RestAPi.bean.MailBoxBean;
import com.telemune.VCC.RestAPi.bean.RolesBean;
import com.telemune.VCC.RestAPi.bean.SmsKeywordBean;
import com.telemune.VCC.RestAPi.bean.SmsTempBean;
import com.telemune.VCC.RestAPi.bean.SmscBean;
import com.telemune.VCC.RestAPi.bean.UserBean;
import com.telemune.VCC.RestAPi.entities.AppConfig;
import com.telemune.VCC.RestAPi.entities.ChargingRule;
import com.telemune.VCC.RestAPi.entities.Hlr;
import com.telemune.VCC.RestAPi.entities.MailBox;
import com.telemune.VCC.RestAPi.entities.Role;
import com.telemune.VCC.RestAPi.entities.SmsKeyword;
import com.telemune.VCC.RestAPi.entities.SmsTemp;
import com.telemune.VCC.RestAPi.entities.Smsc;
import com.telemune.VCC.RestAPi.entities.UserF;


@Component
public class BeanToEntity {
	
	
	 
public static AppConfig convertAppConfigBeanToAppConfigEntity(AppConfigBean appConfigBean) {
		
	AppConfig appConfigEntity = new AppConfig();
		
		Optional.ofNullable(appConfigBean.getParamName()).ifPresent(appConfigEntity::setParamName);
		Optional.ofNullable(appConfigBean.getOwner()).ifPresent(appConfigEntity::setOwner);
		Optional.ofNullable(appConfigBean.getParamId()).ifPresent(appConfigEntity::setParamId);
		Optional.ofNullable(appConfigBean.getParamType()).ifPresent(appConfigEntity::setParamType);
		Optional.ofNullable(appConfigBean.getParamValue()).ifPresent(appConfigEntity::setParamValue);
		Optional.ofNullable(appConfigBean.getRemarks()).ifPresent(appConfigEntity::setRemarks);
		Optional.ofNullable(appConfigBean.getServiceName()).ifPresent(appConfigEntity::setServiceName);

	
		System.out.println("Role add hoya in Bean to Entity =="+appConfigBean.toString());

		return appConfigEntity;
	}

	public static UserF convertUserBeanToUserEntity(UserBean userBean) {
		
		UserF userEntity = new UserF();
	//	Roles roleEntity=new Roles();
		Optional.ofNullable(userBean.getUsername()).ifPresent(user -> {
			userEntity.setUsername(user);
		});
		Optional.ofNullable(userBean.getEmail()).ifPresent(userEntity::setEmail);
		Optional.ofNullable(userBean.getFirstLogin()).ifPresent(userEntity::setFirstLogin);
		Optional.ofNullable(userBean.getMobileNumber()).ifPresent(userEntity::setMobileNumber);
		Optional.ofNullable(userBean.getPassword()).ifPresent(userEntity::setPassword);
		Optional.ofNullable(userBean.getUsername()).ifPresent(userEntity::setUsername);
		Optional.ofNullable(userBean.getStatus()).ifPresent(userEntity::setStatus);
	//	Optional.ofNullable(userBean.getRoles()).ifPresent(userEntity::setRoles);

	//	Optional.ofNullable(userBean.getRoleId()).ifPresent(userEntity::setRoles);
	//	Optional.ofNullable(userBean.getUserType()).ifPresent(userEntity::setUserType);;
		
		System.out.println("Role add hoya in Bean to Entity =="+userBean.toString());

		return userEntity;
	}

	/*
	 * public static User convertUserBeanToUserEntity(UserBean userBean, User user)
	 * {
	 * 
	 * 
	 * Optional.ofNullable(userBean.getEmail()).ifPresent(user::setEmail);
	 * Optional.ofNullable(userBean.getFirstLogin()).ifPresent(user::setFirstLogin);
	 * Optional.ofNullable(userBean.getMobileNumber()).ifPresent(user::
	 * setMobileNumber);
	 * Optional.ofNullable(userBean.getPassword()).ifPresent(user::setPassword);
	 * Optional.ofNullable(userBean.getUsername()).ifPresent(user::setUsername); //
	 * Optional.ofNullable(userBean.getUserType()).ifPresent(user::setUserType);
	 * 
	 * return user; }
	 */
	
	
	
public static Role convertRolesBeanToRolesEntity(RolesBean rolesBean) {

	Role roles=new Role();
		Optional.ofNullable(rolesBean.getRoleId()).ifPresent(roles::setRoleId);
		Optional.ofNullable(rolesBean.getRoleName()).ifPresent(roles::setRoleName);
		Optional.ofNullable(rolesBean.getDescription()).ifPresent(roles::setDescription);
		
		return roles;
}
		
		
		
	/*
	 * public static HistoryData convertHistoryBeanToHistoryEntity(HistoryDataBean
	 * historyDataBean) {
	 * 
	 * HistoryData historyData= new HistoryData();
	 * Optional.ofNullable(historyDataBean.getMsg()).ifPresent(historyData::setMsg);
	 * Optional.ofNullable(historyDataBean.getRole()).ifPresent(historyData::setRole
	 * );
	 * Optional.ofNullable(historyDataBean.getTime()).ifPresent(historyData::setTime
	 * );
	 * Optional.ofNullable(historyDataBean.getRole()).ifPresent(historyData::setRole
	 * ); Optional.ofNullable(historyDataBean.getEvent()).ifPresent(historyData::
	 * setEvent); //
	 * Optional.ofNullable(userBean.getUserType()).ifPresent(user::setUserType);
	 * 
	 * return historyData; }
	 */
	
public static ChargingRule convertChargingRuleBeanToChargingRuleEntity(ChargingRuleBean chargingRuleBean) {

	ChargingRule chargingRuleEntity = new ChargingRule();
	Optional.ofNullable(chargingRuleBean.getChargingCode()).ifPresent(chargingRuleEntity::setChargingCode);
	Optional.ofNullable(chargingRuleBean.getCharCodeName()).ifPresent(chargingRuleEntity::setCharCodeName);
	Optional.ofNullable(chargingRuleBean.getAmountPost()).ifPresent(chargingRuleEntity::setAmountPost);
	Optional.ofNullable(chargingRuleBean.getAmountPre()).ifPresent(chargingRuleEntity::setAmountPre);
	return chargingRuleEntity;

}
	
	public static Hlr convertHlrBeanToHlrEntity(HlrBean hlrBean) {

		Hlr hlrEntity = new Hlr();
		Optional.ofNullable(hlrBean.getHlrName()).ifPresent(hlrEntity::setHlrName);
		Optional.ofNullable(hlrBean.getHlrId()).ifPresent(hlrEntity::setHlrId);
		Optional.ofNullable(hlrBean.getHlrIp()).ifPresent(hlrEntity::setHlrIp);
		Optional.ofNullable(hlrBean.getHlrPort()).ifPresent(hlrEntity::setHlrPort);
		Optional.ofNullable(hlrBean.getPassword()).ifPresent(hlrEntity::setPassword);
		Optional.ofNullable(hlrBean.getLogin()).ifPresent(hlrEntity::setLogin);
		Optional.ofNullable(hlrBean.getConn()).ifPresent(hlrEntity::setConn);
		Optional.ofNullable(hlrBean.getHlrType()).ifPresent(hlrEntity::setHlrType);
		return hlrEntity;

	}
	
	public static MailBox convertMailBoxBeanToMailBoxEntity(MailBoxBean mailBoxBean) {

		MailBox mailBoxEntity = new MailBox();
		Optional.ofNullable(mailBoxBean.getMailBoxId()).ifPresent(mailBoxEntity::setMailBoxId);
		Optional.ofNullable(mailBoxBean.getMailBoxType()).ifPresent(mailBoxEntity::setMailBoxType);
		Optional.ofNullable(mailBoxBean.getMaxMessage()).ifPresent(mailBoxEntity::setMaxMessage);
		Optional.ofNullable(mailBoxBean.getMaxRecordTime()).ifPresent(mailBoxEntity::setMaxRecordTime);
		Optional.ofNullable(mailBoxBean.getMgsTimAftrSav()).ifPresent(mailBoxEntity::setMgsTimAftrSav);
		Optional.ofNullable(mailBoxBean.getMsgLifetime()).ifPresent(mailBoxEntity::setMsgLifetime);
		Optional.ofNullable(mailBoxBean.getMsgTimeAftrRet()).ifPresent(mailBoxEntity::setMsgTimeAftrRet);
		//Optional.ofNullable(mailBoxBean.getHlrType()).ifPresent(mailBoxEntity::setHlrType);
		return mailBoxEntity;

	}
	
	
	public static Smsc convertSmscBeanToSmscEntity(SmscBean smscBean) {

		Smsc smscEntity = new Smsc();
		Optional.ofNullable(smscBean.getSmscId()).ifPresent(smscEntity::setSmscId);
		Optional.ofNullable(smscBean.getSmscPort()).ifPresent(smscEntity::setSmscPort);
		Optional.ofNullable(smscBean.getSmscIp()).ifPresent(smscEntity::setSmscIp);
		Optional.ofNullable(smscBean.getSysType()).ifPresent(smscEntity::setSysType);
		Optional.ofNullable(smscBean.getClientType()).ifPresent(smscEntity::setClientType);
		Optional.ofNullable(smscBean.getConns()).ifPresent(smscEntity::setConns);
		Optional.ofNullable(smscBean.getNpi()).ifPresent(smscEntity::setNpi);
		Optional.ofNullable(smscBean.getSmscPassword()).ifPresent(smscEntity::setSmscPassword);
		Optional.ofNullable(smscBean.getAddressRange()).ifPresent(smscEntity::setAddressRange);
		Optional.ofNullable(smscBean.getSmscUserId()).ifPresent(smscEntity::setSmscUserId);
		Optional.ofNullable(smscBean.getStatus()).ifPresent(smscEntity::setStatus);
		Optional.ofNullable(smscBean.getTon()).ifPresent(smscEntity::setTon);
		Optional.ofNullable(smscBean.getSpeed()).ifPresent(smscEntity::setSpeed);
		Optional.ofNullable(smscBean.getWindowSize()).ifPresent(smscEntity::setWindowSize);

		return smscEntity;

	}
	
	public static SmsKeyword convertSmsKeywordBeanToSmsKeywordEntity(SmsKeywordBean smsKeywordBean) {

		SmsKeyword smsKeyword =new SmsKeyword();
		
		Optional.ofNullable(smsKeywordBean.getRequestkeyword()).ifPresent(smsKeyword::setRequestkeyword);
		Optional.ofNullable(smsKeywordBean.getProcessname()).ifPresent(smsKeyword::setProcessname);
		Optional.ofNullable(smsKeywordBean.getCreatedby()).ifPresent(smsKeyword::setCreatedby);
		Optional.ofNullable(smsKeywordBean.getCreationdate()).ifPresent(smsKeyword::setCreationdate);
		Optional.ofNullable(smsKeywordBean.getUpdateby()).ifPresent(smsKeyword::setUpdateby);
		Optional.ofNullable(smsKeywordBean.getUpdatedate()).ifPresent(smsKeyword::setUpdatedate);
		Optional.ofNullable(smsKeywordBean.getIsworking()).ifPresent(smsKeyword::setIsworking);
		Optional.ofNullable(smsKeywordBean.getLanguageid()).ifPresent(smsKeyword::setLanguageid);
		Optional.ofNullable(smsKeywordBean.getPackagename()).ifPresent(smsKeyword::setPackagename);
return smsKeyword;
}
	public static SmsTemp convertSmsTempBeanToSmsTempEntity(SmsTempBean smsTempBean) {

		SmsTemp smsTemp =new SmsTemp();
		//Optional.ofNullable(smsTempBean.getLangId()).ifPresent(smsTemp::setServiceType);
		//Optional.ofNullable(smsTempBean.getTempDesc()).ifPresent(smsTemp::setTempDesc);
		Optional.ofNullable(smsTempBean.getServiceType()).ifPresent(smsTemp::setServiceType);
		Optional.ofNullable(smsTempBean.getTempDesc()).ifPresent(smsTemp::setTempDesc);
		Optional.ofNullable(smsTempBean.getTempMsg()).ifPresent(smsTemp::setTempMsg);
		Optional.ofNullable(smsTempBean.getTokenAllowed()).ifPresent(smsTemp::setTokenAllowed);
		Optional.ofNullable(smsTempBean.getTempType()).ifPresent(smsTemp::setTempType);
		
		/*
		 * // SmsTempEmbedded embSmsTemp=new SmsTempEmbedded();
		 * Optional.ofNullable(smsTempBean.getTempId()).ifPresent(smsTemp::
		 * setEmbeddedTempId); //
		 * Optional.ofNullable(smsTempBean.getLangId()).ifPresent(smsTemp::
		 * setProcessname);
		 */
	
return smsTemp;
}
	
}