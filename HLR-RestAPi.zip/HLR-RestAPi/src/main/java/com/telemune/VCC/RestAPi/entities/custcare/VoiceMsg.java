package com.telemune.VCC.RestAPi.entities.custcare;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name = "vcc_voice_msg")
public class VoiceMsg {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "VOICE_MESSAGE_INDEX",nullable = false)
	private Integer voicemsgIndex;
	
	@Column(name = "MESSAGE_STATUS",columnDefinition = "varchar(10) default 'N'")
	private String msgStatus;
	
	@Column(name = "ORIGINATING_NUMBER",columnDefinition = "varchar(10) default '0000000000'")
	private String originatingNum;
	
	@Column(name = "DESTINATION_NUMBER",columnDefinition = "varchar(10) default '0000000000'")
	private String destinationNum;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CALL_TIME", columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date callTime;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="RETRIVAL_TIME", columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date retTime;		
	
	@Column(name = "FILENAME",nullable = false) 
	private String fileName;
							
	@Column(name = "RECORDING_DURATION",columnDefinition = "varchar(10) default '0'") 
	private Integer recDuration;
	
	@Column(name = "MSG_PROTECT",columnDefinition = "varchar(10) default 'N'") 
	private String msgProtect;
	
	@Column(name = "MSG_PRIORITY",columnDefinition = "varchar(10) default 'NN'")
	private String msgPriority;
	
	@Column(name = "PASS_PROTECTED",columnDefinition = "varchar(10) default 'N'") 
	private String passProtected;
	
	@Column(name = "PASSWORD",columnDefinition = "varchar(10) default '0000'") 
	private String pass;
	
	@Column(name = "ORIGINAL_NUMBER",columnDefinition = "varchar(10) default '0000'")    
	private String originalNum;
	
	@Column(name = "LOCAL_MESSAGE_INDEX",columnDefinition = "varchar(10) default '0'")
	private Integer localMsgIndex;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="SENDING_TIME", columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date sendingTime;
	
	@Column(name = "SERVICE_TYPE",columnDefinition = "varchar(10) default '0000'")       
	private String serviceType;

	public Integer getVoicemsgIndex() {
		return voicemsgIndex;
	}

	public void setVoicemsgIndex(Integer voicemsgIndex) {
		this.voicemsgIndex = voicemsgIndex;
	}

	public String getMsgStatus() {
		return msgStatus;
	}

	public void setMsgStatus(String msgStatus) {
		this.msgStatus = msgStatus;
	}

	public String getOriginatingNum() {
		return originatingNum;
	}

	public void setOriginatingNum(String originatingNum) {
		this.originatingNum = originatingNum;
	}

	public String getDestinationNum() {
		return destinationNum;
	}

	public void setDestinationNum(String destinationNum) {
		this.destinationNum = destinationNum;
	}

	public Date getCallTime() {
		return callTime;
	}

	public void setCallTime(Date callTime) {
		this.callTime = callTime;
	}

	public Date getRetTime() {
		return retTime;
	}

	public void setRetTime(Date retTime) {
		this.retTime = retTime;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Integer getRecDuration() {
		return recDuration;
	}

	public void setRecDuration(Integer recDuration) {
		this.recDuration = recDuration;
	}

	public String getMsgProtect() {
		return msgProtect;
	}

	public void setMsgProtect(String msgProtect) {
		this.msgProtect = msgProtect;
	}

	public String getMsgPriority() {
		return msgPriority;
	}

	public void setMsgPriority(String msgPriority) {
		this.msgPriority = msgPriority;
	}

	public String getPassProtected() {
		return passProtected;
	}

	public void setPassProtected(String passProtected) {
		this.passProtected = passProtected;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getOriginalNum() {
		return originalNum;
	}

	public void setOriginalNum(String originalNum) {
		this.originalNum = originalNum;
	}

	public Integer getLocalMsgIndex() {
		return localMsgIndex;
	}

	public void setLocalMsgIndex(Integer localMsgIndex) {
		this.localMsgIndex = localMsgIndex;
	}

	public Date getSendingTime() {
		return sendingTime;
	}

	public void setSendingTime(Date sendingTime) {
		this.sendingTime = sendingTime;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	
	@Override
	public String toString() {
		return "VoiceMsg [voicemsgIndex=" + voicemsgIndex + ", msgStatus=" + msgStatus + ", originatingNum="
				+ originatingNum + ", destinationNum=" + destinationNum + ", callTime=" + callTime + ", retTime="
				+ retTime + ", fileName=" + fileName + ", recDuration=" + recDuration + ", msgProtect=" + msgProtect
				+ ", msgPriority=" + msgPriority + ", passProtected=" + passProtected + ", pass=" + pass
				+ ", originalNum=" + originalNum + ", localMsgIndex=" + localMsgIndex + ", sendingTime=" + sendingTime
				+ ", serviceType=" + serviceType + "]";
	}
}
