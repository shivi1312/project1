package com.telemune.VCC.RestAPi.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.VCC.RestAPi.InterfaceVcc.Constants;
import com.telemune.VCC.RestAPi.bean.AppConfigBean;
import com.telemune.VCC.RestAPi.common.Response;
import com.telemune.VCC.RestAPi.service.SystemConfigService;

@RestController
public class SysConfigController {
	
	@Autowired
	private SystemConfigService sysConfigService;
	
	private static final Logger logger = Logger.getLogger(SysConfigController.class);
	
	@PutMapping("/sysConfig")
	public Response updateSysConfig(@RequestBody AppConfigBean appConfigBean) {
		logger.info("Inside updateHlr() method of HlrController class");
		logger.info("Hlr input ==>" + appConfigBean.toString());

		try {
			logger.info("Inside updateHlr() method of HlrController class");
			logger.info("hlr input ==> hlrBean--" + appConfigBean.toString());
			if (null != appConfigBean && null != appConfigBean.getParamName()) {
				AppConfigBean userVOdb = sysConfigService.updateSysConfig(appConfigBean);
				logger.debug(userVOdb.toString());
				if (null != userVOdb && userVOdb.getParamName() != null) {
					logger.info("Exit updateUser() method of UserController class");
					return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new ArrayList<>(),
							"Hlr created", Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

				} else {
					logger.info("Exit updateUser() method of HlrController class");
					return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
							new ArrayList<>(), "Error while Updating the Hlr", Constants.STATUS_FAILURE,
							Constants.STATUS_FAILURE_MESSAGE);
				}
			}
			return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					"object is null", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		} catch (

		Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

		}

	}

	@GetMapping("/allconfigs")
	public Response findAllSysConfig() {

		try {
			logger.info("inside findAllHlr() method of HlrController class");
			List<AppConfigBean> hlrBeanlst = sysConfigService.findAllSysConfig();
			logger.debug(hlrBeanlst.toString());
			if (null != hlrBeanlst && !hlrBeanlst.isEmpty()) {
				logger.info(hlrBeanlst);
				logger.info("exit findAllUser() method of hlrController class");
				return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, hlrBeanlst, "",
						Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);
			} else {
				logger.info(hlrBeanlst);
				logger.info("exit findAllUser() method of HlrController class");
				return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, hlrBeanlst,
						"data not found", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}
		} catch (Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

		}
	}

	@GetMapping("/param/{paramName}")
	public Response findByParamName(@PathVariable String paramName) {

		try {
			logger.info("Inside findByHlrId() method of HlrController class");
			logger.info("user input ===> roleId" + paramName);
			AppConfigBean hlrBeandb = null;
			List<AppConfigBean> hlrBeanlst = new ArrayList<>();
			if (null != paramName) {
				hlrBeandb = sysConfigService.findByParamName(paramName);
				logger.debug(hlrBeandb);
				hlrBeanlst.add(hlrBeandb);
				logger.debug(hlrBeanlst.toString());
			}
			if (null != hlrBeanlst && !hlrBeanlst.isEmpty()) {
				logger.info("Inside findByHlrId() method of  HlrController class");
				return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, hlrBeanlst, "hlr detail",
						Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

			} else {
				logger.info("Inside findByHlrId() method of HlrController class");
				return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, hlrBeanlst,
						"Not found value", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}

		} catch (

		Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(), "",
					Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		}

	}
		

}
