package com.telemune.VCC.RestAPi.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.VCC.RestAPi.InterfaceVcc.Constants;
import com.telemune.VCC.RestAPi.common.Response;
import com.telemune.VCC.RestAPi.entities.UserF;
import com.telemune.VCC.RestAPi.service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService userService;

	private static final Logger logger = Logger.getLogger(UserController.class);

	@SuppressWarnings("unused")
	@PostMapping("/users")
	public Response createUser(@RequestBody UserF userVO) {
		try {

			logger.info("inside createUser() method of UserController class");
			logger.info("user input ==> userVO--" + userVO.toString());
			if (null != userVO) {
				UserF userVOdb = userService.createUser(userVO);

				logger.debug(userVOdb.toString());
				if (null != userVOdb && null != userVOdb.getUsername()) {
					logger.info("Exit createUser() method of UserController class");
					return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new ArrayList<>(),
							"User created", Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);
				} else {
					logger.info("Exit createUser() method of UserController class");
					return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
							new ArrayList<>(), "Error while  creating the user", Constants.STATUS_FAILURE,
							Constants.STATUS_FAILURE_MESSAGE);
				}
			}
		} catch (

		Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		}
		logger.info("Exit findAllRole() method of UserController class");
		return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
				"Error while  creating the user", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
	}

	
	
	@PutMapping("/users")
	public Response updateUser(@RequestBody UserF hlrBean) {
		logger.info("Inside updateHlr() method of HlrController class");
		logger.info("Hlr input ==>" + hlrBean.toString());

		try {
			logger.info("Inside updateHlr() method of HlrController class");
			logger.info("hlr input ==> hlrBean--" + hlrBean.toString());
			if (null != hlrBean && null != hlrBean.getUsername()) {
				UserF userVOdb = userService.updateUser(hlrBean);
				logger.debug(userVOdb.toString());
				if (null != userVOdb && userVOdb.getUsername() != null) {
					logger.info("Exit updateUser() method of UserController class");
					return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new ArrayList<>(),
							"Hlr created", Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

				} else {
					logger.info("Exit updateUser() method of HlrController class");
					return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
							new ArrayList<>(), "Error while Updating the Hlr", Constants.STATUS_FAILURE,
							Constants.STATUS_FAILURE_MESSAGE);
				}
			}
			return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					"object is null", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		} catch (

		Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

		}

	}

	@GetMapping("/allusers")
	public Response findAllUser() {

		try {
			logger.info("inside findAllHlr() method of HlrController class");
			List<UserF> hlrBeanlst = userService.findAllUser();
			logger.debug(hlrBeanlst.toString());
			if (null != hlrBeanlst && !hlrBeanlst.isEmpty()) {
				logger.info(hlrBeanlst);
				logger.info("exit findAllUser() method of hlrController class");
				return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, hlrBeanlst, "",
						Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);
			} else {
				logger.info(hlrBeanlst);
				logger.info("exit findAllUser() method of HlrController class");
				return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, hlrBeanlst,
						"data not found", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}
		} catch (Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

		}
	}

	@GetMapping("/users/{userName}")
	public Response findByUserName(@PathVariable String userName) {

		try {
			logger.info("Inside findByHlrId() method of HlrController class");
			logger.info("user input ===> roleId" + userName);
			UserF hlrBeandb = null;
			List<UserF> hlrBeanlst = new ArrayList<>();
			if (null != userName) {
				hlrBeandb = userService.findByUserName(userName);
				logger.debug(hlrBeandb);
				hlrBeanlst.add(hlrBeandb);
				logger.debug(hlrBeanlst.toString());
			}
			if (null != hlrBeanlst && !hlrBeanlst.isEmpty()) {
				logger.info("Inside findByHlrId() method of  HlrController class");
				return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, hlrBeanlst, "hlr detail",
						Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

			} else {
				logger.info("Inside findByHlrId() method of HlrController class");
				return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, hlrBeanlst,
						"Not found value", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}

		} catch (

		Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(), "",
					Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		}

	}
	

	@DeleteMapping("users/{userName}")
	public Response deleteByUserName(@PathVariable String userName) {

		try {

			logger.info("inside deleteByHlrId() method of HlrController class");
			logger.info("hlr deleted by id ==" + userName);

			if (null != userName) {
				boolean isHlrDeleted = userService.userDeleteByName(userName);
				logger.debug("Hlr delete status  ---" + isHlrDeleted);
				if (isHlrDeleted) {
					logger.info("exit deleteByPackId() method of HlrController class");
					return new Response(HttpStatus.NO_CONTENT, Constants.HTTP_STATUS_CODE_NO_CONTACT, new ArrayList<>(),
							"Hlr deleted", Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

				} else {
					logger.info("exit deleteByHlrId() method of HlrController class");
					return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
							new ArrayList<>(), "Hlr doesn't exist", Constants.STATUS_FAILURE,
							Constants.STATUS_FAILURE_MESSAGE);
				}

			} else {
				return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
						"Hlr is not deleted", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}

		} catch (

		Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.toString(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	/*
	 * @PutMapping("/users") public Response updateUser(@RequestBody UserBean
	 * userBean) { try {
	 * logger.info("Inside updateUser() method of UserController class");
	 * logger.info("user input ==> userVO--" + userBean.toString()); if (null !=
	 * userBean && null != userBean.getUsername()) { UserBean userVOdb =
	 * userService.updateUser(userBean); logger.debug(userVOdb.toString()); if (null
	 * != userVOdb && userVOdb.getUsername() != null) {
	 * logger.info("Exit updateUser() method of UserController class"); return new
	 * Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new
	 * ArrayList<>(), "user created", Constants.STATUS_SUCCESS,
	 * Constants.STATUS_SUCCESS_MESSAGE);
	 * 
	 * } else { logger.info("Exit updateUser() method of UserController class");
	 * return new Response(HttpStatus.BAD_GATEWAY,
	 * Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
	 * "Error while Updating the user", Constants.STATUS_FAILURE,
	 * Constants.STATUS_FAILURE_MESSAGE); } } return new
	 * Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new
	 * ArrayList<>(), "object is null", Constants.STATUS_FAILURE,
	 * Constants.STATUS_FAILURE_MESSAGE); } catch (
	 * 
	 * Exception exception) { logger.error(exception.toString()); return new
	 * Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new
	 * ArrayList<>(), exception.getMessage(), Constants.STATUS_FAILURE,
	 * Constants.STATUS_FAILURE_MESSAGE); } }
	 */
}
