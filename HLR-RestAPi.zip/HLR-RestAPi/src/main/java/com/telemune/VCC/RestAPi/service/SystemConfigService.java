package com.telemune.VCC.RestAPi.service;

import java.util.List;

import com.telemune.VCC.RestAPi.bean.AppConfigBean;

public interface SystemConfigService {
	
	List<AppConfigBean> findAllSysConfig();
	public AppConfigBean updateSysConfig(AppConfigBean mailBoxBean);
	AppConfigBean findByParamName(String paramName);
	
}
