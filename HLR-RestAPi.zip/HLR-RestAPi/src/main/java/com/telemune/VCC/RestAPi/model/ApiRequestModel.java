package com.telemune.VCC.RestAPi.model;


import org.springframework.stereotype.Component;

@Component
public class ApiRequestModel implements java.io.Serializable{

	private int lang;
	private String subType;
	private String serviceType;
	private String msisdn;
	private String planName;
	private int actTrg;
	private int planId;
	private String userName="";
	private String pass="";
	private String loginToken;
	
	
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public int getActTrg() {
		return actTrg;
	}
	public void setActTrg(int actTrg) {
		this.actTrg = actTrg;
	}
	public int getLang() {
		return lang;
	}
	public void setLang(int lang) {
		this.lang = lang;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getLoginToken() {
		return loginToken;
	}
	public void setLoginToken(String loginToken) {
		this.loginToken = loginToken;
	}
	@Override
	public String toString() {
		return "UssdApiRequestModel [lang=" + lang + ", subType=" + subType + ", serviceType=" + serviceType
				+ ", msisdn=" + msisdn + ", planName=" + planName + ", actTrg=" + actTrg + ", planId=" + planId
				+ ", userName=" + userName + ", pass=" + pass + ", loginToken=" + loginToken + "]";
	}
	
	
	
	
	
}

