package com.telemune.VCC.RestAPi.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.VCC.RestAPi.InterfaceVcc.Constants;
import com.telemune.VCC.RestAPi.bean.HlrBean;
import com.telemune.VCC.RestAPi.common.Response;
import com.telemune.VCC.RestAPi.entities.HistoryData;
import com.telemune.VCC.RestAPi.service.HlrService;


@RestController
public class HlrController {

	private static final Logger logger = Logger.getLogger(HlrController.class);

	@Autowired
	private HlrService hlrService;
	HistoryData history;

	@SuppressWarnings("unused")
	@PostMapping("/hlr")
	public Response createHLR(@RequestBody HlrBean hlrBean) {
		try {

			logger.info("inside createHlr() method of HlrController class");
			logger.info("hlr input ==> hlrBean--" + hlrBean.toString());
			if (null != hlrBean) {
				HlrBean hlrBeandb = hlrService.createHlr(hlrBean);

				logger.debug(hlrBeandb.toString());
				if (null != hlrBeandb && null != hlrBeandb.getHlrName()) {
					logger.info("Exit createHlr() method of HlrController class");
					return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new ArrayList<>(),
							"Hlr created", Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);
					
					
					
				} else {
					logger.info("Exit createHlr() method of HlrController class");
					return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
							new ArrayList<>(), "Error while  creating the hlr", Constants.STATUS_FAILURE,
							Constants.STATUS_FAILURE_MESSAGE);
				}
			}
		} catch (Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		}

		logger.info("Exit  method of HlrController class");
		return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
				"Error while  creating the user", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

	}

	@PutMapping("/hlr")
	public Response updateHlr(@RequestBody HlrBean hlrBean) {
		logger.info("Inside updateHlr() method of HlrController class");
		logger.info("Hlr input ==>" + hlrBean.toString());

		try {
			logger.info("Inside updateHlr() method of HlrController class");
			logger.info("hlr input ==> hlrBean--" + hlrBean.toString());
			if (null != hlrBean && null != hlrBean.getHlrName()) {
				HlrBean userVOdb = hlrService.updateHlr(hlrBean);
				logger.debug(userVOdb.toString());
				if (null != userVOdb && userVOdb.getHlrName() != null) {
					logger.info("Exit updateUser() method of UserController class");
					return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new ArrayList<>(),
							"Hlr created", Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

				} else {
					logger.info("Exit updateUser() method of HlrController class");
					return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
							new ArrayList<>(), "Error while Updating the Hlr", Constants.STATUS_FAILURE,
							Constants.STATUS_FAILURE_MESSAGE);
				}
			}
			return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					"object is null", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		} catch (

		Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

		}

	}

	@GetMapping("/all")
	public Response findAllHlr() {

		try {
			logger.info("inside findAllHlr() method of HlrController class");
			List<HlrBean> hlrBeanlst = hlrService.findAllHlr();
			logger.debug(hlrBeanlst.toString());
			if (null != hlrBeanlst && !hlrBeanlst.isEmpty()) {
				logger.info(hlrBeanlst);
				logger.info("exit findAllUser() method of hlrController class");
				return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, hlrBeanlst, "",
						Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);
			} else {
				logger.info(hlrBeanlst);
				logger.info("exit findAllUser() method of HlrController class");
				return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, hlrBeanlst,
						"data not found", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}
		} catch (Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

		}
	}

	@GetMapping("/hlr/{hlrId}")
	public Response findByHlrId(@PathVariable(name = "hlrId") Integer hlrId) {

		try {
			logger.info("Inside findByHlrId() method of HlrController class");
			logger.info("user input ===> roleId" + hlrId);
			HlrBean hlrBeandb = null;
			List<HlrBean> hlrBeanlst = new ArrayList<>();
			if (null != hlrId) {
				hlrBeandb = hlrService.findByHlrId(hlrId);
				logger.debug(hlrBeandb);
				hlrBeanlst.add(hlrBeandb);
				logger.debug(hlrBeanlst.toString());
			}
			if (null != hlrBeanlst && !hlrBeanlst.isEmpty()) {
				logger.info("Inside findByHlrId() method of  HlrController class");
				return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, hlrBeanlst, "hlr detail",
						Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

			} else {
				logger.info("Inside findByHlrId() method of HlrController class");
				return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, hlrBeanlst,
						"Not found value", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}

		} catch (

		Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(), "",
					Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		}

	}
	

	@DeleteMapping("hlr/{hlrId}")
	public Response deleteByHlrId(@PathVariable Integer hlrId) {

		try {

			logger.info("inside deleteByHlrId() method of HlrController class");
			logger.info("hlr deleted by id ==" + hlrId);

			if (null != hlrId) {
				boolean isHlrDeleted = hlrService.hlrDeleteById(hlrId);
				logger.debug("Hlr delete status  ---" + isHlrDeleted);
				if (isHlrDeleted) {
					logger.info("exit deleteByPackId() method of HlrController class");
					return new Response(HttpStatus.NO_CONTENT, Constants.HTTP_STATUS_CODE_NO_CONTACT, new ArrayList<>(),
							"Hlr deleted", Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

				} else {
					logger.info("exit deleteByHlrId() method of HlrController class");
					return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
							new ArrayList<>(), "Hlr doesn't exist", Constants.STATUS_FAILURE,
							Constants.STATUS_FAILURE_MESSAGE);
				}

			} else {
				return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
						"Hlr is not deleted", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}

		} catch (

		Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.toString(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
		}

	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	/*
	 * @DeleteMapping("/hlr/{hlrId}") public ResponseEntity<HttpStatus>
	 * deleteHlr(@PathVariable String hlrId) { try {
	 * this.hlrService.deleteHlr(Long.parseLong(hlrId)); return new
	 * ResponseEntity<>(HttpStatus.OK); } catch (Exception e) { return new
	 * ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); }
	 * 
	 * }
	 */

}
