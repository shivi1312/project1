package com.telemune.VCC.RestAPi.bean;

import java.time.LocalDateTime;

public class SmsKeywordBean {

	
	private String requestkeyword= null;
	private String processname = null;
	private String packagename= null;
	private String createdby= null;
	private LocalDateTime creationdate= null;
	private String updateby= null;
	private LocalDateTime  updatedate= null;
	private int languageid=0;
	private String isworking=null;
	
	
	
	public String getRequestkeyword() {
		return requestkeyword;
	}
	public void setRequestkeyword(String requestkeyword) {
		this.requestkeyword = requestkeyword;
	}
	public String getProcessname() {
		return processname;
	}
	public void setProcessname(String processname) {
		this.processname = processname;
	}
	public String getPackagename() {
		return packagename;
	}
	public void setPackagename(String packagename) {
		this.packagename = packagename;
	}
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	public LocalDateTime getCreationdate() {
		return creationdate;
	}
	public void setCreationdate(LocalDateTime creationdate) {
		this.creationdate = creationdate;
	}
	public LocalDateTime getUpdatedate() {
		return updatedate;
	}
	public void setUpdatedate(LocalDateTime updatedate) {
		this.updatedate = updatedate;
	}
	public String getUpdateby() {
		return updateby;
	}
	public void setUpdateby(String updateby) {
		this.updateby = updateby;
	}
	
	public int getLanguageid() {
		return languageid;
	}
	public void setLanguageid(int languageid) {
		this.languageid = languageid;
	}
	public String getIsworking() {
		return isworking;
	}
	public void setIsworking(String isworking) {
		this.isworking = isworking;
	}
	@Override
	public String toString() {
		return "SmsKeyword [requestkeyword=" + requestkeyword + ", processname=" + processname + ", packagename="
				+ packagename + ", createdby=" + createdby + ", creationdate=" + creationdate + ", updateby=" + updateby
				+ ", updatedate=" + updatedate + ", languageid=" + languageid + ", isworking=" + isworking + "]";
	}
}
