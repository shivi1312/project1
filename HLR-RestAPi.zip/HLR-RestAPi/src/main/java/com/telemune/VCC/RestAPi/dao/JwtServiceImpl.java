package com.telemune.VCC.RestAPi.dao;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.entities.UserF;
import com.telemune.VCC.RestAPi.repository.UserRepo;

@Service
public class JwtServiceImpl implements UserDetailsService {

	final static Logger logger = Logger.getLogger(JwtServiceImpl.class);
	private final static Logger errorLogger = Logger.getLogger("UssdApiServiceImpl : errorLogger");

	@Autowired
	UserRepo userRepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		UserF user = this.userRepo.findByUsername(username).get();

		if (user != null) {
			logger.info("User is authenticated.");
			return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
					new ArrayList<>());

		} else {
			errorLogger.error("User is not Authenticated!!");
			throw new UsernameNotFoundException("User not found!!!");
		}

	}
}


