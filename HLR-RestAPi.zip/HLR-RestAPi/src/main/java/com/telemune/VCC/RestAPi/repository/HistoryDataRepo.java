package com.telemune.VCC.RestAPi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.HistoryData;

public interface HistoryDataRepo extends JpaRepository<HistoryData, Integer>{
	
}
