package com.telemune.VCC.RestAPi.repository.custcare;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog9;

public interface HistoryManagementRepo9 extends JpaRepository<MailBoxLog9, Integer> {

	List<MailBoxLog9> findByMsisdn(String msisdn);
}