package com.telemune.VCC.RestAPi.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "adminuser_password_check")
public class UserPassCheck {
	@Id
	@Column(name = "USER_NAME", nullable = false)  
	private String userName;
	

	@Column(name = "PASSWORD", nullable = false)
	private String pass;
	
	@Column(name = "ROLE_ID", nullable = false)
	private Integer roles;  
	

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_UPDATE", columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date time;

	
	@Column(name="PASSWORD_NUM")
	private Integer passNum;


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPass() {
		return pass;
	}


	public void setPass(String pass) {
		this.pass = pass;
	}


	public Integer getRoles() {
		return roles;
	}


	public void setRoles(Integer roles) {
		this.roles = roles;
	}


	public Date getTime() {
		return time;
	}


	public void setTime(Date time) {
		this.time = time;
	}


	public Integer getPassNum() {
		return passNum;
	}


	public void setPassNum(Integer passNum) {
		this.passNum = passNum;
	}


	@Override
	public String toString() {
		return "UserPassCheck [userName=" + userName + ", pass=" + pass + ", roles=" + roles + ", time=" + time
				+ ", passNum=" + passNum + "]";
	}
	
	

}
