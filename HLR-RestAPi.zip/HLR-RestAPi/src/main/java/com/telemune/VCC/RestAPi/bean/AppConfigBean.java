package com.telemune.VCC.RestAPi.bean;

public class AppConfigBean {

	private String paramName;

	private Integer paramId;

	private String paramValue;

	private String serviceName;

	private String owner;

	private String paramType;

	private String remarks;

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public Integer getParamId() {
		return paramId;
	}

	public void setParamId(Integer paramId) {
		this.paramId = paramId;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getParamType() {
		return paramType;
	}

	public void setParamType(String paramType) {
		this.paramType = paramType;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "AppConfigBean [paramName=" + paramName + ", paramId=" + paramId + ", paramValue=" + paramValue
				+ ", serviceName=" + serviceName + ", owner=" + owner + ", paramType=" + paramType + ", remarks="
				+ remarks + "]";
	}

}
