package com.telemune.VCC.RestAPi.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="lbs_parser_master")
public class SmsKeyword {


	@Id
	@Column(name = "REQUEST_KEYWORD", nullable = false)
	private String requestkeyword;
	
	@Column(name = "PROCESS_NAME", nullable = false)
	private String processname;
	@Column(name = "PACKAGE_NAME", nullable = false)
	private String packagename;
	
	@Column(name = "CREATED_BY")
	private String createdby;
	
	@Column(name = "CREATION_DATE", nullable = false)
	private	LocalDateTime creationdate;
	
	@Column(name = "UPDATE_BY")
	private String updateby;
	
	@Column(name = "UPDATE_DATE")
	private	LocalDateTime updatedate;
	
	@Column(name = "LANGUAGE_ID", nullable = false)
	private int languageid;
	
	@Column(name = "IS_WORKING")
	private String isworking;
	
	
	
	public LocalDateTime getCreationdate() {
		return creationdate;
	}
	public void setCreationdate(LocalDateTime creationdate) {
		this.creationdate = creationdate;
	}
	public LocalDateTime getUpdatedate() {
		return updatedate;
	}
	public void setUpdatedate(LocalDateTime updatedate) {
		this.updatedate = updatedate;
	}
	public String getRequestkeyword() {
		return requestkeyword;
	}
	public void setRequestkeyword(String requestkeyword) {
		this.requestkeyword = requestkeyword;
	}
	public String getProcessname() {
		return processname;
	}
	public void setProcessname(String processname) {
		this.processname = processname;
	}
	public String getPackagename() {
		return packagename;
	}
	public void setPackagename(String packagename) {
		this.packagename = packagename;
	}
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	
	public String getUpdateby() {
		return updateby;
	}
	public void setUpdateby(String updateby) {
		this.updateby = updateby;
	}
	
	public int getLanguageid() {
		return languageid;
	}
	public void setLanguageid(int languageid) {
		this.languageid = languageid;
	}
	public String getIsworking() {
		return isworking;
	}
	public void setIsworking(String isworking) {
		this.isworking = isworking;
	}
	@Override
	public String toString() {
		return "SmsKeyword [requestkeyword=" + requestkeyword + ", processname=" + processname + ", packagename="
				+ packagename + ", createdby=" + createdby + ", creationdate=" + creationdate + ", updateby=" + updateby
				+ ", updatedate=" + updatedate + ", languageid=" + languageid + ", isworking=" + isworking + "]";
	}

	
}
