package com.telemune.VCC.RestAPi.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "http_links")
public class HttpLinks {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "LINK_ID")
	private Integer linkId;

	@Column(name = "DESCRIPTION", nullable = false)
	private String description;

	public Integer getLinkId() {
		return linkId;
	}

	public void setLinkId(Integer linkId) {
		this.linkId = linkId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "HttpLinks [linkId=" + linkId + ", description=" + description + "]";
	}

	
	
	
	/*
	 * @EmbeddedId private HttpLinksEmbedded httpLinksEmbedded;
	 * 
	 * 
	 * @Column(name = "STATUS") private Integer status;
	 * 
	 * @Column(name = "DESCRIPTION") private String description;
	 * 
	 * @Column(name = "IS_WORKING",columnDefinition = "boolean default false")
	 * private String isWorking;
	 * 
	 * 
	 * 
	 * 
	 * public HttpLinksEmbedded getHttpLinksEmbedded() { return httpLinksEmbedded; }
	 * 
	 * public void setHttpLinksEmbedded(HttpLinksEmbedded httpLinksEmbedded) {
	 * this.httpLinksEmbedded = httpLinksEmbedded; }
	 * 
	 * 
	 * 
	 * @Override public String toString() { return "HttpLinks [httpLinksEmbedded=" +
	 * httpLinksEmbedded + "]"; }
	 */
//	public Integer getStatus() {
//		return status;
//	}
//
//	public void setStatus(Integer status) {
//		this.status = status;
//	}
//
//	public String getIsWorking() {
//		return isWorking;
//	}
//
//	public void setIsWorking(String isWorking) {
//		this.isWorking = isWorking;
//	}
//
//	public String getDescription() {
//		return description;
//	}
//
//	public void setDescription(String description) {
//		this.description = description;
//	}
//
//	@Override
//	public String toString() {
//		return "HttpLinks [httpLinksEmbedded=" + httpLinksEmbedded + ", status=" + status + ", description="
//				+ description + ", isWorking=" + isWorking + "]";
//	}

}
