package com.telemune.VCC.RestAPi.config;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.telemune.VCC.RestAPi.common.VccCache;

@Component
public class VccConfigCache {
	  @Bean
	  @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
	  public VccCache getUnipRestCachetest() {
	  return new VccCache();
	  }
}
