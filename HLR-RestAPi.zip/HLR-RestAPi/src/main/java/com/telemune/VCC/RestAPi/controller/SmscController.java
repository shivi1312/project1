package com.telemune.VCC.RestAPi.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.VCC.RestAPi.InterfaceVcc.Constants;
import com.telemune.VCC.RestAPi.bean.SmscBean;
import com.telemune.VCC.RestAPi.common.Response;
import com.telemune.VCC.RestAPi.service.SmscService;


@RestController
public class SmscController {


		private static final Logger logger = Logger.getLogger(SmscController.class);

		@Autowired
		private SmscService smscService;

		@SuppressWarnings("unused")
		@PostMapping("/smsc")
		public Response createSmsc(@RequestBody SmscBean smscBean) {
			try {

				logger.info("inside createSmsc() method of SmscController class");
				logger.info("smsc input ==> hlrBean--" + smscBean.toString());
				if (null != smscBean) {
					String hlrBeandb = smscService.createSmsc(smscBean);
			
					logger.debug(hlrBeandb.toString());
					if (hlrBeandb.equalsIgnoreCase("success")) {
						logger.info("Exit createSmsc() method of SmscController class");
						return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new ArrayList<>(),
								"Smsc created", Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);
					} else {
						logger.info(" Exit createSmsc() method of SmscController class");
						return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
								new ArrayList<>(), "Error while  creating the Smsc", Constants.STATUS_FAILURE,
								Constants.STATUS_FAILURE_MESSAGE);
					}
				}
			} catch (Exception exception) {
				logger.error(exception.toString());
				return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
						exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}

			logger.info("Exit  method of SmscController class");
			return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					"Error while  creating the Smsc", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

		}
		
		
		@GetMapping("/smsc/{smscId}")
		public Response findBySmscId(@PathVariable(name = "smscId") Integer smscId) {

			try {
				logger.info("Inside findBySmscId() method of SmscController class");
				logger.info("Smsc input ===> roleId" + smscId);
				SmscBean hlrBeandb = null;
				List<SmscBean> hlrBeanlst = new ArrayList<>();
				if (null != smscId) {
					hlrBeandb = smscService.findBySmscId(smscId);
					logger.debug(hlrBeandb);
					hlrBeanlst.add(hlrBeandb);
					logger.debug(hlrBeanlst.toString());
				}
				if (null != hlrBeanlst && !hlrBeanlst.isEmpty()) {
					logger.info("Inside findBySmscId() method of  SmscController class");
					return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, hlrBeanlst, "Smsc detail",
							Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

				} else {
					logger.info("Inside findBySmscId() method of SmscController class");
					return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, hlrBeanlst,
							"Not found value", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
				}

			} catch (

			Exception exception) {
				logger.error(exception.toString());
				return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(), "",
						Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}

		}
		

		@GetMapping("/allsmsc")
		public Response findAllsmsc() {

			try {
				logger.info("inside findAllsmsc() method of SmscController class");
				List<SmscBean> mailBoxBeanlst = smscService.findAllSmsc();
				logger.debug(mailBoxBeanlst.toString());
				if (null != mailBoxBeanlst && !mailBoxBeanlst.isEmpty()) {
					logger.info(mailBoxBeanlst);
					logger.info("exit findAllsmsc() method of SmscController class");
					return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, mailBoxBeanlst, "",
							Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);
				} else {
					logger.info(mailBoxBeanlst);
					logger.info("exit findAllsmsc() method of SmscController class");
					return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, mailBoxBeanlst,
							"data not found", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
				}
			} catch (Exception exception) {
				logger.error(exception.toString());
				return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
						exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

			}
		}

		
		@PutMapping("/smsc")
		public Response updateSmsc(@RequestBody SmscBean mailBoxBean) {
			logger.info("Inside updateMailBox() method of SmscController class");
			logger.info("smsc input ==>" + mailBoxBean.toString());

			try {
				logger.info("Inside updateSmsc() method of SmscController class");
				logger.info("smsc input ==> mailBoxsBean--" + mailBoxBean.toString());
				if (null != mailBoxBean && null != mailBoxBean.getSmscId()) {
					String userVOdb = smscService.updateSmsc(mailBoxBean);
					logger.debug(userVOdb.toString());
					if (userVOdb.equalsIgnoreCase("success")) {
						logger.info("Exit updateSmsc() method of SmscController class");
						return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new ArrayList<>(),
								"smsc created", Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

					} else {
						logger.info("Exit updateMailBox() method of SmscController class");
						return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
								new ArrayList<>(), "Error while Updating the mailBox", Constants.STATUS_FAILURE,
								Constants.STATUS_FAILURE_MESSAGE);
					}
				}
				return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
						"object is null", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			} catch (

			Exception exception) {
				logger.error(exception.toString());
				return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
						exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

			}

		}
		
		@DeleteMapping("/smsc/{smscId}")
		public Response deleteByMailBoxId(@PathVariable Integer smscId) {

			try {

				logger.info("inside deleteByMailBoxId() method of SmscController class");
				logger.info("mailbox deleted by id ==" + smscId);

				if (null != smscId) {
					boolean isHlrDeleted = smscService.DeleteSmscById(smscId);
					logger.debug("mailbox delete status  ---" + isHlrDeleted);
					if (isHlrDeleted) {
						logger.info("exit deleteByMailBoxId() method of SmscController class");
						return new Response(HttpStatus.NO_CONTENT, Constants.HTTP_STATUS_CODE_NO_CONTACT, new ArrayList<>(),
								"mailbox deleted", Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

					} else {
						logger.info("exit deleteByMailBoxId() method of SmscController class");
						return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST,
								new ArrayList<>(), "mailbox doesn't exist", Constants.STATUS_FAILURE,
								Constants.STATUS_FAILURE_MESSAGE);
					}

				} else {
					return new Response(HttpStatus.BAD_GATEWAY, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
							"mailbox is not deleted", Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
				}

			} catch (

			Exception exception) {
				logger.error(exception.toString());
				return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
						exception.toString(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);
			}

		}

		
		
		
		
}
