package com.telemune.VCC.RestAPi.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name="VCC_CHARGING_CODE")
public class ChargingRule {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CHARGING_CODE",nullable = false)
	private Integer chargingCode;
	
	@Column(name = "AMOUNT_PRE",precision=10, scale=2,nullable = false)
	@Type(type = "big_decimal")
	private double amountPre;
	
	@Column(name = "AMOUNT_POST",precision=10, scale=2,nullable = false)
	@Type(type = "big_decimal")
	private double amountPost;
	
	@Column(name = "CHARGING_CODE_NAME")
	private String charCodeName;
	
	@Column(name = "TARIFF_PRE",nullable = false,columnDefinition = "Integer default 1")        
	private Integer tariffPre;
	@Column(name = "TARIFF_POST",nullable = false,columnDefinition = "Integer default 1")
	private Integer tariffPost;
	public Integer getChargingCode() {
		return chargingCode;
	}
	public void setChargingCode(Integer chargingCode) {
		this.chargingCode = chargingCode;
	}
	public double getAmountPre() {
		return amountPre;
	}
	public void setAmountPre(double amountPre) {
		this.amountPre = amountPre;
	}
	public double getAmountPost() {
		return amountPost;
	}
	public void setAmountPost(double amountPost) {
		this.amountPost = amountPost;
	}
	public String getCharCodeName() {
		return charCodeName;
	}
	public void setCharCodeName(String charCodeName) {
		this.charCodeName = charCodeName;
	}
	public Integer getTariffPre() {
		return tariffPre;
	}
	public void setTariffPre(Integer tariffPre) {
		this.tariffPre = tariffPre;
	}
	public Integer getTariffPost() {
		return tariffPost;
	}
	public void setTariffPost(Integer tariffPost) {
		this.tariffPost = tariffPost;
	}
	@Override
	public String toString() {
		return "ChargingCode [chargingCode=" + chargingCode + ", amountPre=" + amountPre + ", amountPost=" + amountPost
				+ ", charCodeName=" + charCodeName + ", tariffPre=" + tariffPre + ", tariffPost=" + tariffPost + "]";
	}
	
	
	

}
