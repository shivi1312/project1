package com.telemune.VCC.RestAPi.repository.custcare;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.custcare.AuthUser0;

public interface AuthRepo extends JpaRepository<AuthUser0, String>{
	List<AuthUser0> findByMsisdn(String msisdn);
}
