package com.telemune.VCC.RestAPi.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.InterfaceVcc.HistoryEvent;
import com.telemune.VCC.RestAPi.bean.ChargingRuleBean;
import com.telemune.VCC.RestAPi.entities.ChargingRule;
import com.telemune.VCC.RestAPi.entities.HistoryData;
import com.telemune.VCC.RestAPi.model.BeanToEntity;
import com.telemune.VCC.RestAPi.model.EntityToBean;
import com.telemune.VCC.RestAPi.repository.ChargingRuleRepo;
import com.telemune.VCC.RestAPi.repository.HistoryDataRepo;
import com.telemune.VCC.RestAPi.service.ChargingRuleService;

@Service
public class ChargingRuleServiceImpl implements ChargingRuleService{
	
	
	@Autowired
	private ChargingRuleRepo chgRepo;

	@Autowired
	private HistoryDataRepo historyRepo;

	HistoryData hisData = null;
	private static final Logger logger = Logger.getLogger(ChargingRuleServiceImpl.class);

	@Override
	@Transactional
	public ChargingRuleBean updateChargingCode(ChargingRuleBean chgBean) {

		logger.info("Inside updateChargingCode() method of ChargingRuleServiceImpl class");
		
			Optional<ChargingRule> hlr = chgRepo.findByChargingCode(chgBean.getChargingCode());
			logger.info("hlr name " + hlr);

			if (hlr.isPresent()) {

				logger.info("hlr Already Exist with name===" +hlr );
				hisData = new HistoryData();
				hisData.setRole("Pending");
				hisData.setMsg(HistoryEvent.add);
				hisData.setAction(HistoryEvent.hlrmanagement);
				hisData.setEvent(HistoryEvent.alExist);
				hisData.setUser("Pending ");
				historyRepo.save(hisData);
			} 
			else {

				logger.info("going to update ");
				ChargingRule hlrEntity1 = BeanToEntity.convertChargingRuleBeanToChargingRuleEntity(chgBean);
				ChargingRule hlrEntitydb = chgRepo.save(hlrEntity1);
				logger.info("Exit from updateChargingCode() method function of ChargingRuleServiceImpl class");
				hisData = new HistoryData();
				hisData.setRole("Pending");
				hisData.setMsg("addSuccess");
				hisData.setAction(HistoryEvent.hlrmanagement);
				hisData.setEvent(HistoryEvent.addSuccess);
				hisData.setUser("Pending ");
				historyRepo.save(hisData);
				return EntityToBean.convertChargingRuleEntityToChargingRuleBean(hlrEntitydb);
			}
		
		//	logger.info("Exit from updateHlr() method function of ChargingRuleServiceImpl class");
		return new ChargingRuleBean();
	}

	@Override
	public List<ChargingRuleBean> findAllChargingCode() {

		logger.info("Inside findAllChargingCode() method function of ChargingRuleServiceImpl class");
		List<ChargingRuleBean> finalHlrBean = new ArrayList<>();
		List<ChargingRule> userdbList = chgRepo.findAll();

		for (ChargingRule hlr : userdbList) {
			ChargingRuleBean hlrBean = EntityToBean.convertChargingRuleEntityToChargingRuleBean(hlr);
			finalHlrBean.add(hlrBean);
		}
		logger.info("Exit from  findAllChargingCode() method function of IUserServiceImpl class");
		return finalHlrBean;
	}

	@Override
	public ChargingRuleBean findByChargingCode(Integer chargingCode)
	{
		
	logger.info("Inside findByChargingCode() method function of ChargingRuleServiceImpl class");

		Optional<ChargingRule> hlrid = chgRepo.findByChargingCode(chargingCode);
		logger.info("check by hlrId");

		if (hlrid.isPresent()) {

			logger.info("Exit from findByChargingCode() method function of ChargingRuleServiceImpl class");

			return EntityToBean.convertChargingRuleEntityToChargingRuleBean(hlrid.get());

		}
		logger.info("Exit from findByChargingCode() method function of ChargingRuleServiceImpl class");

		return new ChargingRuleBean();
	}

	@Override
	@Transactional
	public boolean deleteByChargingCode(Integer chargingCode) {

		Optional<ChargingRule> hlr = chgRepo.findByChargingCode(chargingCode);

		logger.info("Inside deleteByChargingCode() method of ChargingRuleServiceImpl class");

		logger.debug(hlr.toString());

		try {
			if (hlr.isPresent()) {
				chgRepo.deleteByChargingCode(chargingCode);
				logger.info("Exit deleteByChargingCode() method of ChargingRuleServiceImpl class");
				return true;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		logger.info("Exit deleteByChargingCode() method of ChargingRuleServiceImpl class");
		return false;

	}

	
	
}
