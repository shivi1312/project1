package com.telemune.VCC.RestAPi.repository.custcare;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog0;

public interface HistoryManagementRepo0 extends JpaRepository<MailBoxLog0, Integer> {
	
//	Optional<MailBoxLog0> findByMsisdn(String msisdn);
	List<MailBoxLog0> findByMsisdn(String msisdn);
}


