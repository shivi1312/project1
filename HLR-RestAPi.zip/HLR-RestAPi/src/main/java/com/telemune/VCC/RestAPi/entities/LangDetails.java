package com.telemune.VCC.RestAPi.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VCC_LANG_DETAILS")
public class LangDetails {

	@Id
	@Column(name = "ID",nullable = false)
	private Integer id; 
	@Column(name = "LANG_NAME",nullable = false)
	private String langName;
	       
	@Column(name = "INTERFACE",nullable = false)
	private String intrface;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLangName() {
		return langName;
	}

	public void setLangName(String langName) {
		this.langName = langName;
	}

	public String getIntrface() {
		return intrface;
	}

	public void setIntrface(String intrface) {
		this.intrface = intrface;
	}

	@Override
	public String toString() {
		return "LangDetails [id=" + id + ", langName=" + langName + ", intrface=" + intrface + "]";
	}
	

}
