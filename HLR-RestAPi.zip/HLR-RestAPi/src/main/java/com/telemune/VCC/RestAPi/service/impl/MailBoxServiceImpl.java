package com.telemune.VCC.RestAPi.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.InterfaceVcc.HistoryEvent;
import com.telemune.VCC.RestAPi.bean.MailBoxBean;
import com.telemune.VCC.RestAPi.entities.HistoryData;
import com.telemune.VCC.RestAPi.entities.MailBox;
import com.telemune.VCC.RestAPi.model.BeanToEntity;
import com.telemune.VCC.RestAPi.model.EntityToBean;
import com.telemune.VCC.RestAPi.repository.HistoryDataRepo;
import com.telemune.VCC.RestAPi.repository.MailBoxRepo;
import com.telemune.VCC.RestAPi.service.MailBoxService;

@Service
public class MailBoxServiceImpl implements MailBoxService {

	@Autowired
	private MailBoxRepo mailBoxRepo;

	@Autowired
	private HistoryDataRepo historyRepo;

	private static final Logger logger = Logger.getLogger(HlrServiceImpl.class);

	private ArrayList<MailBox> mailboxConfigAl;

	public ArrayList<MailBox> getMailboxConfigAl() {
		return mailboxConfigAl;
	}

	public void setHlrConfigAl(ArrayList<MailBox> mailboxConfigAl) {
		this.mailboxConfigAl = mailboxConfigAl;
	}

	List<MailBox> list;
	HistoryData hisData = null;

	public MailBoxServiceImpl() {
	}

	@Override
	public MailBoxBean createMailBox(MailBoxBean mailBoxBean) {
		try {

			logger.info("Inside createMailBox() method function of MailBoxServiceImpl class");
			Optional<MailBox> mailBoxEntity = mailBoxRepo.findByMailBoxType(mailBoxBean.getMailBoxType());
			if (mailBoxEntity.isPresent()) {
				logger.info("mailbox Already Exist with name===" + mailBoxEntity.get().getMailBoxType());

				// throw new UserAlreadyExitException("Username Already Exit");
				hisData = new HistoryData();
				hisData.setRole("Pending");
				hisData.setMsg(HistoryEvent.add);
				hisData.setAction(HistoryEvent.mailboxmanagement);
				hisData.setEvent(HistoryEvent.alExist);
				hisData.setUser("Pending ");
				historyRepo.save(hisData);
			}

			else {

				MailBox mailbox = BeanToEntity.convertMailBoxBeanToMailBoxEntity(mailBoxBean);
				MailBox mailBoxdb = mailBoxRepo.save(mailbox);
				logger.info("Exit from createMailBox() method function of MailBoxServiceImpl class");
				hisData = new HistoryData();
				hisData.setRole("Pending");
				hisData.setMsg(HistoryEvent.add);
				hisData.setAction(HistoryEvent.mailboxmanagement);
				hisData.setEvent(HistoryEvent.addSuccess);
				hisData.setUser("Pending");
				historyRepo.save(hisData);
				return EntityToBean.convertMailBoxEntityToMailBoxBean(mailBoxdb);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		logger.info("Exit from createMailBox() method function of MailBoxServiceImpl class");
		return new MailBoxBean();

	}
	
	@Override
	public MailBoxBean findByMailBoxId(Integer mailBoxId) {
		logger.info("Inside findByMailBoxId() method function of MailBoxServiceImpl class");
		Optional<MailBox> mailBoxid = mailBoxRepo.findByMailBoxId(mailBoxId);
		logger.info("check by mailBoxId");
		if (mailBoxid.isPresent()) {
			logger.info("Exit from findByMailBoxId() method function of MailBoxServiceImpl class");
			return EntityToBean.convertMailBoxEntityToMailBoxBean(mailBoxid.get());
		}
		logger.info("Exit from findByMailBoxId() method function of MailBoxServiceImpl class");

		return new MailBoxBean();
	}

	@Override
	public List<MailBoxBean> findAllmailBox() {
		logger.info("Inside findAllmailBox() method function of MailBoxServiceImpl class");
		List<MailBoxBean> finalmailBoxBean = new ArrayList<>();
		List<MailBox> mailboxdbList = mailBoxRepo.findAll();
		for (MailBox mailBox : mailboxdbList) {
			MailBoxBean mailBoxBean = EntityToBean.convertMailBoxEntityToMailBoxBean(mailBox);
			finalmailBoxBean.add(mailBoxBean);
		}
		logger.info("Exit from  findAllmailBox() method function of MailBoxServiceImpl class");
		return finalmailBoxBean;
	}

	@Override
	@Transactional
	public MailBoxBean updateMailBox(MailBoxBean mailBoxBean) {
	

			logger.info("Inside updateMailBox() method of MailBoxServiceImpl class");
			Optional<MailBox> mailBoxEntity = mailBoxRepo.findByMailBoxId(mailBoxBean.getMailBoxId());
			if (mailBoxEntity.isPresent()) {
				
				logger.info("id present");
				Optional<MailBox> mailBox = mailBoxRepo.findByMailBoxType(mailBoxBean.getMailBoxType());
				logger.info("MailBox name " + mailBox);
				if (mailBox.isPresent()) {
					logger.info("MailBox Already Exist with name===" + mailBoxEntity.get().getMailBoxType());
					hisData = new HistoryData();
					hisData.setRole("Pending");
					hisData.setMsg(HistoryEvent.add);
					hisData.setAction(HistoryEvent.mailboxmanagement);
					hisData.setEvent(HistoryEvent.alExist);
					hisData.setUser("Pending ");
					historyRepo.save(hisData);
				} 
				else {

					logger.info("going to update ");
					MailBox mailBoxEntity1 = BeanToEntity.convertMailBoxBeanToMailBoxEntity(mailBoxBean);

					MailBox mailBoxEntitydb = mailBoxRepo.save(mailBoxEntity1);

					logger.info("Exit from updateMailBox() method function of MailBoxServiceImpl class");
					hisData = new HistoryData();
					hisData.setRole("Pending");
					hisData.setMsg(HistoryEvent.add);
					hisData.setAction(HistoryEvent.mailboxmanagement);
					hisData.setEvent(HistoryEvent.addSuccess);
					hisData.setUser("Pending ");
					historyRepo.save(hisData);
					return EntityToBean.convertMailBoxEntityToMailBoxBean(mailBoxEntitydb);
				}
			} else
				logger.info("Exit from updateMailBox() method function of MailBoxServiceImpl class");
			return new MailBoxBean();
		}

	@Override
	@Transactional
	public boolean DeleteMailBoxById(Integer mailBoxId) {
		

			Optional<MailBox> mailBox = mailBoxRepo.findByMailBoxId(mailBoxId);
				logger.info("Inside DeleteMailBoxById() method of MailBoxServiceImpl class");
				logger.debug(mailBox.toString());
				try {
					if (mailBox .isPresent()) {
						mailBoxRepo.deleteByMailBoxId(mailBoxId);
						logger.info("Exit DeleteMailBoxById() method of MailBoxServiceImpl class");
						return true;
					}
				} 
				catch (Exception ex) {
					ex.printStackTrace();
				}
				logger.info("Exit DeleteMailBoxById() method of MailBoxServiceImpl class");
				return false;

			}
	}


