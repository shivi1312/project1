package com.telemune.VCC.RestAPi.entities.embedded;

import javax.persistence.Column;
import javax.persistence.Embeddable;
@Embeddable
public class HttpLinksEmbedded {

	
	@Column(name = "LINK_ID",columnDefinition = "boolean default false")
	private Integer linkId;
	
	
	
	@Column(name = "SERVICE_NAME", nullable = false)
    private String serviceName;



	public Integer getLinkId() {
		return linkId;
	}



	public void setLinkId(Integer linkId) {
		this.linkId = linkId;
	}



	public String getServiceName() {
		return serviceName;
	}



	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}



	public HttpLinksEmbedded() {
		
	}

	public HttpLinksEmbedded(Integer linkId,String serviceName) {
		this.serviceName = serviceName;
		this.linkId = linkId;
	}
	public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HttpLinksEmbedded that = (HttpLinksEmbedded) o;

        if (!linkId.equals(that.linkId)) return false;
        return serviceName.equals(that.serviceName);
    }


	
}
