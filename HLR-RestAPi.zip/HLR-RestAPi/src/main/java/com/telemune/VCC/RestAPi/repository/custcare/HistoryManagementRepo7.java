package com.telemune.VCC.RestAPi.repository.custcare;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog7;

public interface HistoryManagementRepo7 extends JpaRepository<MailBoxLog7, Integer> {
	
	List<MailBoxLog7> findByMsisdn(String msisdn);
}