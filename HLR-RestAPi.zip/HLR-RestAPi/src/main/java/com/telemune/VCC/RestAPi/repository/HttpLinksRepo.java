package com.telemune.VCC.RestAPi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.HttpLinks;


public interface HttpLinksRepo extends JpaRepository<HttpLinks, Integer>{
	HttpLinks findByLinkId(Integer linkId);
}
