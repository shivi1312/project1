package com.telemune.VCC.RestAPi.common;

public class ValidateAction {

}
