package com.telemune.VCC.RestAPi.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

//	import com.telemune.VCC.RestAPi.InterfaceVcc.passwordEncoder;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.InterfaceVcc.HistoryEvent;
import com.telemune.VCC.RestAPi.entities.HistoryData;
import com.telemune.VCC.RestAPi.entities.UserF;
import com.telemune.VCC.RestAPi.repository.HistoryDataRepo;
import com.telemune.VCC.RestAPi.repository.UserRepo;
import com.telemune.VCC.RestAPi.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo userRepo;

	@Autowired
	private HistoryDataRepo historyRepo;

	@Autowired
	PasswordEncoder passwordEncoder;

	List<UserF> myRoleId;
	HistoryData hisData = null;
	//String number="7009928910";
	private static final Logger logger = Logger.getLogger(UserServiceImpl.class);

	@Override
	public UserF createUser(UserF userVO) {
		try {
		//	abc=VccCache.instance().getNationalNumber(number);
			
		//	logger.info(abc+"======abc");
			
			logger.info("Inside createUser() method function of IUserServiceImpl class");

			Optional<UserF> marketPlaceAdminUser = userRepo.findByUsername(userVO.getUsername());

			if (marketPlaceAdminUser.isPresent()) {

				logger.info("user Already Exit with name===" + marketPlaceAdminUser.get().getUsername());
				hisData = new HistoryData();
				hisData.setRole("Pending");
				hisData.setMsg(HistoryEvent.add);
				hisData.setAction(HistoryEvent.hlrmanagement);
				hisData.setEvent(HistoryEvent.alExist);
				hisData.setUser("Pending ");
				historyRepo.save(hisData);
			}

			else {
			//	User adminUser = BeanToEntity.convertUserBeanToUserEntity(userVO);
				logger.info("bean to Entity toh baad ===" + userVO);
				userVO.setPassword(passwordEncoder.encode(userVO.getPassword()));
		//		Roles roles = rolesRepo.findByRoles(userVO.getRoleName());
			
				
				
				//Roles roles = rolesRepo.findByRoleId(adminUser.getRoles());
				// logger.info("role----->>>>>>" + marketPlaceRoles);
			//	 adminUser.setRoles(roles);
				// adminUser.setUserType(String.valueOf(userVO.getRoleId()));
				userVO.setFirstLogin("0");

				logger.info("Roles set    =" + userVO);
				UserF adminUserdb = userRepo.save(userVO);

				hisData = new HistoryData();
				hisData.setRole("Pending role add from login hit");
				hisData.setMsg(HistoryEvent.add);
				hisData.setAction(HistoryEvent.usermanagement);
				hisData.setEvent(HistoryEvent.addSuccess);
				hisData.setUser("Pending role add from login hit");
				historyRepo.save(hisData);

				logger.info("Exit from createUser() method function of IUserServiceImpl class" + adminUserdb);

				return adminUserdb;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		logger.info("Exit from createUser() method function of IUserServiceImpl class");
		return new UserF();

	}

	@Override
	@Transactional
	public UserF updateUser(UserF hlrBean) {

		logger.info("Inside updateHlr() method of HlrServiceImpl class");

		Optional<UserF> hlr = userRepo.findByUsername(hlrBean.getUsername());
		logger.info("hlr name " + hlr);

		logger.info("going to update ");
		

		hlrBean.setPassword(passwordEncoder.encode(hlrBean.getPassword()));
		// MarketPlaceRoles marketPlaceRoles =
		// marketPlaceRolesRepository.findByRoleId(userVO.getRoleId());

		// adminUser.setMarketPlaceRoles(marketPlaceRoles);

		UserF hlrEntitydb = userRepo.save(hlrBean);

		logger.info("Exit from updateHlr() method function of HlrServiceImpl class");

		return hlrEntitydb;
	}

	@Override
	public List<UserF> findAllUser() {

		logger.info("Inside findAllHlr() method function of HlrServiceImpl class");
		List<UserF> finalHlrBean = new ArrayList<>();
		List<UserF> userdbList = userRepo.findAll();

		for (UserF hlr : userdbList) {
			//User hlrBean = EntityToBean.convertUserEntityToUserBean(hlr);
			finalHlrBean.add(hlr);
		}
		logger.info("Exit from  findAllHlr() method function of IUserServiceImpl class");
		return finalHlrBean;
	}

	@Override
	public UserF findByUserName(String userName) {
		logger.info("Inside findByHlrId() method function of HlrServiceImpl class");

		Optional<UserF> hlrid = userRepo.findByUsername(userName);
		logger.info("check by hlrId");

		if (hlrid.isPresent()) {

			logger.info("Exit from findByHlrId() method function of HlrServiceImpl class");

			return hlrid.get();

		}
		logger.info("Exit from findByHlrId() method function of HlrServiceImpl class");

		return new UserF();
	}

	@Override
	@Transactional
	public boolean userDeleteByName(String userName) {

		Optional<UserF> hlr = userRepo.findByUsername(userName);

		logger.info("Inside hlrDeleteById() method of HlrServiceImpl class");

		logger.debug(hlr.toString());

		try {
			if (hlr.isPresent()) {
				userRepo.deleteByUsername(userName);
				logger.info("Exit hlrDeleteById() method of HlrServiceImpl class");
				return true;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		logger.info("Exit hlrDeleteById() method of HlrServiceImpl class");
		return false;

	}

}
