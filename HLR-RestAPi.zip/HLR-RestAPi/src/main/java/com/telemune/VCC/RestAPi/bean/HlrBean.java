package com.telemune.VCC.RestAPi.bean;



public class HlrBean {
	private Integer hlrId;
	private String hlrName;
	private String hlrIp;
	private int hlrPort;
	private String login;
	private String password;
	private String hlrType;
	private String description;
	private int conn;
	
	
	
	public String getHlrType() {
		return hlrType;
	}
	public void setHlrType(String hlrType) {
		this.hlrType = hlrType;
	}
	
	
	public Integer getHlrId() {
		return hlrId;
	}
	public void setHlrId(Integer hlrId) {
		this.hlrId = hlrId;
	}
	public String getHlrName() {
		return hlrName;
	}
	public void setHlrName(String hlrName) {
		this.hlrName = hlrName;
	}
	public String getHlrIp() {
		return hlrIp;
	}
	public void setHlrIp(String hlrIp) {
		this.hlrIp = hlrIp;
	}
	public int getHlrPort() {
		return hlrPort;
	}
	public void setHlrPort(int hlrPort) {
		this.hlrPort = hlrPort;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getConn() {
		return conn;
	}
	public void setConn(int conn) {
		this.conn = conn;
	}
	@Override
	public String toString() {
		return "HlrBean [hlrId=" + hlrId + ", hlrName=" + hlrName + ", hlrIp=" + hlrIp + ", hlrPort=" + hlrPort
				+ ", login=" + login + ", password=" + password + ", hlrType=" + hlrType + ", description="
				+ description + ", conn=" + conn + "]";
	}
	
	
	
	
}
