package com.telemune.VCC.RestAPi.entities.custcare;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "vcc_mailbox_log_2")
public class MailBoxLog2{
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private Integer id;
private Integer	server_Id;
	private String 	msisdn;      
	private Date request_Date;
	private	String Interface;   
	private	String mailBox_Type;
	private	String service_Type;
	private	String updated_By ;
	private	String description;
	private	String type;
	private	String cdr_Status;  
	private	String sub_type;

	public MailBoxLog2() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getServer_Id() {
		return server_Id;
	}

	public void setServer_Id(Integer server_Id) {
		this.server_Id = server_Id;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	

	public Date getRequest_Date() {
		return request_Date;
	}

	public void setRequest_Date(Date request_Date) {
		this.request_Date = request_Date;
	}

	public String getInterface() {
		return Interface;
	}

	public void setInterface(String interface1) {
		Interface = interface1;
	}

	public String getMailBox_Type() {
		return mailBox_Type;
	}

	public void setMailBox_Type(String mailBox_Type) {
		this.mailBox_Type = mailBox_Type;
	}

	public String getService_Type() {
		return service_Type;
	}

	public void setService_Type(String service_Type) {
		this.service_Type = service_Type;
	}

	public String getUpdated_By() {
		return updated_By;
	}

	public void setUpdated_By(String updated_By) {
		this.updated_By = updated_By;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCdr_Status() {
		return cdr_Status;
	}

	public void setCdr_Status(String cdr_Status) {
		this.cdr_Status = cdr_Status;
	}

	public String getSub_type() {
		return sub_type;
	}

	public void setSub_type(String sub_type) {
		this.sub_type = sub_type;
	}

	@Override
	public String toString() {
		return "MailBoxLog0 [id=" + id + ", server_Id=" + server_Id + ", msisdn=" + msisdn + ", request_Date="
				+ request_Date + ", Interface=" + Interface + ", mailBox_Type=" + mailBox_Type + ", service_Type="
				+ service_Type + ", updated_By=" + updated_By + ", description=" + description + ", type=" + type
				+ ", cdr_Status=" + cdr_Status + ", sub_type=" + sub_type + "]";
	}
  
	
}
