package com.telemune.VCC.RestAPi.entities.embedded;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class UserRoleId {

	@Column(name = "ROLE_ID")
	private Integer roleId;

	@Column(name = "USER_ID")
	private Integer userId;

	public UserRoleId() {
	}

	public UserRoleId(Integer roleId, Integer userId) {
		
		this.roleId = roleId;
		this.userId = userId;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "UserRoleId [roleId=" + roleId + ", userId=" + userId + "]";
	}

	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		UserRoleId that = (UserRoleId) o;

		if (!userId.equals(that.userId))
			return false;
		return roleId.equals(that.roleId);
	}

}
