package com.telemune.VCC.RestAPi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telemune.VCC.RestAPi.entities.SmsKeyword;

public interface SmsKeywordRepo extends JpaRepository<SmsKeyword , String>{
			Optional<SmsKeyword> findByrequestkeyword(String requestkeyword);

}
