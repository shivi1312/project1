package com.telemune.VCC.RestAPi.model;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.telemune.VCC.RestAPi.bean.AppConfigBean;
import com.telemune.VCC.RestAPi.bean.ChargingRuleBean;
import com.telemune.VCC.RestAPi.bean.HlrBean;
import com.telemune.VCC.RestAPi.bean.MailBoxBean;
import com.telemune.VCC.RestAPi.bean.MailBoxLogBean;
import com.telemune.VCC.RestAPi.bean.RolesBean;
import com.telemune.VCC.RestAPi.bean.SmsKeywordBean;
import com.telemune.VCC.RestAPi.bean.SmsTempBean;
import com.telemune.VCC.RestAPi.bean.SmscBean;
import com.telemune.VCC.RestAPi.bean.UserBean;
import com.telemune.VCC.RestAPi.entities.AppConfig;
import com.telemune.VCC.RestAPi.entities.ChargingRule;
import com.telemune.VCC.RestAPi.entities.Hlr;
import com.telemune.VCC.RestAPi.entities.MailBox;
import com.telemune.VCC.RestAPi.entities.Role;
import com.telemune.VCC.RestAPi.entities.SmsKeyword;
import com.telemune.VCC.RestAPi.entities.SmsTemp;
import com.telemune.VCC.RestAPi.entities.Smsc;
import com.telemune.VCC.RestAPi.entities.UserF;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog0;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog1;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog2;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog3;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog4;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog5;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog6;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog7;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog8;
import com.telemune.VCC.RestAPi.entities.custcare.MailBoxLog9;


@Component
public class EntityToBean {
	public static UserBean convertUserEntityToUserBean(UserF user) {

		UserBean userBean = new UserBean();

		Optional.ofNullable(user.getEmail()).ifPresent(userBean::setEmail);
		Optional.ofNullable(user.getFirstLogin()).ifPresent(userBean::setFirstLogin);
		Optional.ofNullable(user.getMobileNumber()).ifPresent(userBean::setMobileNumber);
		Optional.ofNullable(user.getPassword()).ifPresent(userBean::setPassword);
		Optional.ofNullable(user.getUsername()).ifPresent(userBean::setUsername);
		Optional.ofNullable(user.getStatus()).ifPresent(userBean::setStatus);
	//	Optional.ofNullable(user.getRoles()).ifPresent(userBean::setRoles);

	//	 Optional.ofNullable(user.getUserType()).ifPresent(userBean::setUserType);
//		 Optional.ofNullable(user.getRoles().getRoleId()).ifPresent(userBean::setRoleId);
//			Optional.ofNullable(user.getRoles().getDescription()).ifPresent(userBean::setDescription);
//			Optional.ofNullable(user.getRoles().getRoleName()).ifPresent(userBean::setRoleName);

System.out.println("Role done=="+userBean.toString());
		return userBean;
	}
	public static ChargingRuleBean convertChargingRuleEntityToChargingRuleBean(ChargingRule chargingRule) {

		ChargingRuleBean chargingRuleBean=new ChargingRuleBean();
			Optional.ofNullable(chargingRule.getCharCodeName()).ifPresent(chargingRuleBean::setCharCodeName);
			Optional.ofNullable(chargingRule.getChargingCode()).ifPresent(chargingRuleBean::setChargingCode);
			Optional.ofNullable(chargingRule.getAmountPost()).ifPresent(chargingRuleBean::setAmountPost);
			Optional.ofNullable(chargingRule.getAmountPre()).ifPresent(chargingRuleBean::setAmountPre);

			return chargingRuleBean;
	}
	
	
	public static RolesBean convertRolesEntityToRolesBean(Role roles) {

		RolesBean rolesBean=new RolesBean();
			Optional.ofNullable(roles.getRoleId()).ifPresent(rolesBean::setRoleId);
			Optional.ofNullable(roles.getRoleName()).ifPresent(rolesBean::setRoleName);
			Optional.ofNullable(roles.getDescription()).ifPresent(rolesBean::setDescription);
			
			return rolesBean;
	}
	
	/*
	 * public static HistoryDataBean convertHistoryBeanToHistoryEntity(HistoryData
	 * historyData ){
	 * 
	 * HistoryDataBean historyDataBean= new HistoryDataBean();
	 * Optional.ofNullable(historyData.getMsg()).ifPresent(historyDataBean::setMsg);
	 * Optional.ofNullable(historyData.getRole()).ifPresent(historyDataBean::setRole
	 * );
	 * Optional.ofNullable(historyData.getTime()).ifPresent(historyDataBean::setTime
	 * );
	 * Optional.ofNullable(historyData.getRole()).ifPresent(historyDataBean::setRole
	 * ); Optional.ofNullable(historyData.getEvent()).ifPresent(historyDataBean::
	 * setEvent); //
	 * Optional.ofNullable(userBean.getUserType()).ifPresent(user::setUserType);
	 * 
	 * return historyDataBean; }
	 */
	
	
	
	
	public static HlrBean convertHlrEntityToHlrBean(Hlr hlr) {

		HlrBean hlrBean =new HlrBean();
		Optional.ofNullable(hlr.getHlrName()).ifPresent(hlrBean::setHlrName);

			Optional.ofNullable(hlr.getHlrId()).ifPresent(hlrBean::setHlrId);
			Optional.ofNullable(hlr.getHlrIp()).ifPresent(hlrBean::setHlrIp);
			Optional.ofNullable(hlr.getHlrPort()).ifPresent(hlrBean::setHlrPort);
			Optional.ofNullable(hlr.getPassword()).ifPresent(hlrBean::setPassword);
			Optional.ofNullable(hlr.getLogin()).ifPresent(hlrBean::setLogin);
			Optional.ofNullable(hlr.getConn()).ifPresent(hlrBean::setConn);
		Optional.ofNullable(hlr.getHlrType()).ifPresent(hlrBean::setHlrType);
//		Optional.ofNullable(userBean.getRoleId()).ifPresent(userEntity::setRoles);;
return hlrBean;
}
	
	public static AppConfigBean convertAppConfigEntityToAppConfigBean(AppConfig appConfig) {

		AppConfigBean appConfigBean =new AppConfigBean();
		
		Optional.ofNullable(appConfig.getParamName()).ifPresent(appConfigBean::setParamName);
		Optional.ofNullable(appConfig.getParamId()).ifPresent(appConfigBean::setParamId);
		Optional.ofNullable(appConfig.getParamType()).ifPresent(appConfigBean::setParamType);
		Optional.ofNullable(appConfig.getParamValue()).ifPresent(appConfigBean::setParamValue);
		Optional.ofNullable(appConfig.getOwner()).ifPresent(appConfigBean::setOwner);
		Optional.ofNullable(appConfig.getRemarks()).ifPresent(appConfigBean::setRemarks);
		Optional.ofNullable(appConfig.getServiceName()).ifPresent(appConfigBean::setServiceName);
return appConfigBean;
}
	
	
	public static MailBoxBean convertMailBoxEntityToMailBoxBean(MailBox mailBox) {

		MailBoxBean mailBoxBean =new MailBoxBean();
		
		Optional.ofNullable(mailBox.getMailBoxId()).ifPresent(mailBoxBean::setMailBoxId);
		Optional.ofNullable(mailBox.getMailBoxType()).ifPresent(mailBoxBean::setMailBoxType);
		Optional.ofNullable(mailBox.getMaxMessage()).ifPresent(mailBoxBean::setMaxMessage);
		Optional.ofNullable(mailBox.getMaxRecordTime()).ifPresent(mailBoxBean::setMaxRecordTime);
		Optional.ofNullable(mailBox.getMgsTimAftrSav()).ifPresent(mailBoxBean::setMgsTimAftrSav);
		Optional.ofNullable(mailBox.getMsgLifetime()).ifPresent(mailBoxBean::setMsgLifetime);
		Optional.ofNullable(mailBox.getMsgTimeAftrRet()).ifPresent(mailBoxBean::setMsgTimeAftrRet);
return mailBoxBean;
}
	
	public static SmscBean convertSmscEntityToSmscBean(Smsc smsc) {

		SmscBean smscBean = new SmscBean();
		Optional.ofNullable(smsc.getSmscId()).ifPresent(smscBean::setSmscId);
		Optional.ofNullable(smsc.getSmscPort()).ifPresent(smscBean::setSmscPort);
		Optional.ofNullable(smsc.getSmscIp()).ifPresent(smscBean::setSmscIp);
		Optional.ofNullable(smsc.getSysType()).ifPresent(smscBean::setSysType);
		Optional.ofNullable(smsc.getClientType()).ifPresent(smscBean::setClientType);
		Optional.ofNullable(smsc.getConns()).ifPresent(smscBean::setConns);
		Optional.ofNullable(smsc.getNpi()).ifPresent(smscBean::setNpi);
		Optional.ofNullable(smsc.getSmscPassword()).ifPresent(smscBean::setSmscPassword);
		Optional.ofNullable(smsc.getAddressRange()).ifPresent(smscBean::setAddressRange);
		Optional.ofNullable(smsc.getSmscUserId()).ifPresent(smscBean::setSmscUserId);
		Optional.ofNullable(smsc.getStatus()).ifPresent(smscBean::setStatus);
		Optional.ofNullable(smsc.getTon()).ifPresent(smscBean::setTon);
		Optional.ofNullable(smsc.getSpeed()).ifPresent(smscBean::setSpeed);
		Optional.ofNullable(smsc.getWindowSize()).ifPresent(smscBean::setWindowSize);

		return smscBean;

	}
	
	public static SmsKeywordBean convertSmsKeywordEntityToSmsKeywordBean(SmsKeyword smsKeyword) {

		SmsKeywordBean smsKeywordBean =new SmsKeywordBean();
		
		Optional.ofNullable(smsKeyword.getRequestkeyword()).ifPresent(smsKeywordBean::setRequestkeyword);
		Optional.ofNullable(smsKeyword.getProcessname()).ifPresent(smsKeywordBean::setProcessname);
		Optional.ofNullable(smsKeyword.getCreatedby()).ifPresent(smsKeywordBean::setCreatedby);
		Optional.ofNullable(smsKeyword.getCreationdate()).ifPresent(smsKeywordBean::setCreationdate);
		Optional.ofNullable(smsKeyword.getUpdateby()).ifPresent(smsKeywordBean::setUpdateby);
		Optional.ofNullable(smsKeyword.getUpdatedate()).ifPresent(smsKeywordBean::setUpdatedate);
		Optional.ofNullable(smsKeyword.getIsworking()).ifPresent(smsKeywordBean::setIsworking);
		Optional.ofNullable(smsKeyword.getLanguageid()).ifPresent(smsKeywordBean::setLanguageid);
		Optional.ofNullable(smsKeyword.getPackagename()).ifPresent(smsKeywordBean::setPackagename);
return smsKeywordBean;
}
	
	

	public static SmsTempBean convertSmsTempEntityToSmsTempBean(SmsTemp lbsTemplate) {

		SmsTempBean tempVO = new SmsTempBean();

		Optional.ofNullable(lbsTemplate.getSmsTempEmbedded().getTempId()).ifPresent(tempVO::setTempId);
		Optional.ofNullable(lbsTemplate.getSmsTempEmbedded().getLangId()).ifPresent(tempVO::setLangId);
		Optional.ofNullable(lbsTemplate.getTempType()).ifPresent(tempVO::setTempType);
		Optional.ofNullable(lbsTemplate.getTokenAllowed()).ifPresent(tempVO::setTokenAllowed);
		Optional.ofNullable(lbsTemplate.getTempDesc()).ifPresent(tempVO::setTempDesc);
		Optional.ofNullable(lbsTemplate.getTempMsg()).ifPresent(tempVO::setTempMsg);
		Optional.ofNullable(lbsTemplate.getServiceType()).ifPresent(tempVO::setServiceType);

		return tempVO;
	}
	
	
	public static MailBoxLogBean convertMailBoxLogEntityToMailBoxLogBean(MailBoxLog mailLog) {

		MailBoxLogBean mailLogBean = new MailBoxLogBean();

		Optional.ofNullable(mailLog.getId()).ifPresent(mailLogBean::setId);
		Optional.ofNullable(mailLog.getMailBox_Type()).ifPresent(mailLogBean::setMailBox_Type);
		Optional.ofNullable(mailLog.getInterface()).ifPresent(mailLogBean::setInterface);
		Optional.ofNullable(mailLog.getMsisdn()).ifPresent(mailLogBean::setMsisdn);
		Optional.ofNullable(mailLog.getDescription()).ifPresent(mailLogBean::setDescription);
		Optional.ofNullable(mailLog.getRequest_Date()).ifPresent(mailLogBean::setRequest_Date);
		Optional.ofNullable(mailLog.getServer_Id()).ifPresent(mailLogBean::setServer_Id);
		Optional.ofNullable(mailLog.getUpdated_By()).ifPresent(mailLogBean::setUpdated_By);
		Optional.ofNullable(mailLog.getType()).ifPresent(mailLogBean::setType);
		Optional.ofNullable(mailLog.getSub_type()).ifPresent(mailLogBean::setSub_type);
		Optional.ofNullable(mailLog.getCdr_Status()).ifPresent(mailLogBean::setCdr_Status);
		Optional.ofNullable(mailLog.getService_Type()).ifPresent(mailLogBean::setService_Type);

		return mailLogBean;
	}
	public static MailBoxLogBean convertMailBoxLog0EntityToMailBoxLogBean(MailBoxLog0 mailLog0) {

		MailBoxLogBean mailLogBean = new MailBoxLogBean();

		Optional.ofNullable(mailLog0.getId()).ifPresent(mailLogBean::setId);
		Optional.ofNullable(mailLog0.getMailBox_Type()).ifPresent(mailLogBean::setMailBox_Type);
		Optional.ofNullable(mailLog0.getInterface()).ifPresent(mailLogBean::setInterface);
		Optional.ofNullable(mailLog0.getMsisdn()).ifPresent(mailLogBean::setMsisdn);
		Optional.ofNullable(mailLog0.getDescription()).ifPresent(mailLogBean::setDescription);
		Optional.ofNullable(mailLog0.getRequest_Date()).ifPresent(mailLogBean::setRequest_Date);
		Optional.ofNullable(mailLog0.getServer_Id()).ifPresent(mailLogBean::setServer_Id);
		Optional.ofNullable(mailLog0.getUpdated_By()).ifPresent(mailLogBean::setUpdated_By);
		Optional.ofNullable(mailLog0.getType()).ifPresent(mailLogBean::setType);
		Optional.ofNullable(mailLog0.getSub_type()).ifPresent(mailLogBean::setSub_type);
		Optional.ofNullable(mailLog0.getCdr_Status()).ifPresent(mailLogBean::setCdr_Status);
		Optional.ofNullable(mailLog0.getService_Type()).ifPresent(mailLogBean::setService_Type);

		return mailLogBean;
	}
	public static MailBoxLogBean convertMailBoxLog1EntityToMailBoxLogBean(MailBoxLog1 mailLog1) {

		MailBoxLogBean mailLogBean = new MailBoxLogBean();

		Optional.ofNullable(mailLog1.getId()).ifPresent(mailLogBean::setId);
		Optional.ofNullable(mailLog1.getMailBox_Type()).ifPresent(mailLogBean::setMailBox_Type);
		Optional.ofNullable(mailLog1.getInterface()).ifPresent(mailLogBean::setInterface);
		Optional.ofNullable(mailLog1.getMsisdn()).ifPresent(mailLogBean::setMsisdn);
		Optional.ofNullable(mailLog1.getDescription()).ifPresent(mailLogBean::setDescription);
		Optional.ofNullable(mailLog1.getRequest_Date()).ifPresent(mailLogBean::setRequest_Date);
		Optional.ofNullable(mailLog1.getServer_Id()).ifPresent(mailLogBean::setServer_Id);
		Optional.ofNullable(mailLog1.getUpdated_By()).ifPresent(mailLogBean::setUpdated_By);
		Optional.ofNullable(mailLog1.getType()).ifPresent(mailLogBean::setType);
		Optional.ofNullable(mailLog1.getSub_type()).ifPresent(mailLogBean::setSub_type);
		Optional.ofNullable(mailLog1.getCdr_Status()).ifPresent(mailLogBean::setCdr_Status);
		Optional.ofNullable(mailLog1.getService_Type()).ifPresent(mailLogBean::setService_Type);

		return mailLogBean;
	}
	public static MailBoxLogBean convertMailBoxLog2EntityToMailBoxLogBean(MailBoxLog2 mailLog0) {

		MailBoxLogBean mailLogBean = new MailBoxLogBean();

		Optional.ofNullable(mailLog0.getId()).ifPresent(mailLogBean::setId);
		Optional.ofNullable(mailLog0.getMailBox_Type()).ifPresent(mailLogBean::setMailBox_Type);
		Optional.ofNullable(mailLog0.getInterface()).ifPresent(mailLogBean::setInterface);
		Optional.ofNullable(mailLog0.getMsisdn()).ifPresent(mailLogBean::setMsisdn);
		Optional.ofNullable(mailLog0.getDescription()).ifPresent(mailLogBean::setDescription);
		Optional.ofNullable(mailLog0.getRequest_Date()).ifPresent(mailLogBean::setRequest_Date);
		Optional.ofNullable(mailLog0.getServer_Id()).ifPresent(mailLogBean::setServer_Id);
		Optional.ofNullable(mailLog0.getUpdated_By()).ifPresent(mailLogBean::setUpdated_By);
		Optional.ofNullable(mailLog0.getType()).ifPresent(mailLogBean::setType);
		Optional.ofNullable(mailLog0.getSub_type()).ifPresent(mailLogBean::setSub_type);
		Optional.ofNullable(mailLog0.getCdr_Status()).ifPresent(mailLogBean::setCdr_Status);
		Optional.ofNullable(mailLog0.getService_Type()).ifPresent(mailLogBean::setService_Type);

		return mailLogBean;
	}
	public static MailBoxLogBean convertMailBoxLog3EntityToMailBoxLogBean(MailBoxLog3 mailLog0) {

		MailBoxLogBean mailLogBean = new MailBoxLogBean();

		Optional.ofNullable(mailLog0.getId()).ifPresent(mailLogBean::setId);
		Optional.ofNullable(mailLog0.getMailBox_Type()).ifPresent(mailLogBean::setMailBox_Type);
		Optional.ofNullable(mailLog0.getInterface()).ifPresent(mailLogBean::setInterface);
		Optional.ofNullable(mailLog0.getMsisdn()).ifPresent(mailLogBean::setMsisdn);
		Optional.ofNullable(mailLog0.getDescription()).ifPresent(mailLogBean::setDescription);
		Optional.ofNullable(mailLog0.getRequest_Date()).ifPresent(mailLogBean::setRequest_Date);
		Optional.ofNullable(mailLog0.getServer_Id()).ifPresent(mailLogBean::setServer_Id);
		Optional.ofNullable(mailLog0.getUpdated_By()).ifPresent(mailLogBean::setUpdated_By);
		Optional.ofNullable(mailLog0.getType()).ifPresent(mailLogBean::setType);
		Optional.ofNullable(mailLog0.getSub_type()).ifPresent(mailLogBean::setSub_type);
		Optional.ofNullable(mailLog0.getCdr_Status()).ifPresent(mailLogBean::setCdr_Status);
		Optional.ofNullable(mailLog0.getService_Type()).ifPresent(mailLogBean::setService_Type);

		return mailLogBean;
	}
	
	public static MailBoxLogBean convertMailBoxLog4EntityToMailBoxLogBean(MailBoxLog4 mailLog0) {

		MailBoxLogBean mailLogBean = new MailBoxLogBean();

		Optional.ofNullable(mailLog0.getId()).ifPresent(mailLogBean::setId);
		Optional.ofNullable(mailLog0.getMailBox_Type()).ifPresent(mailLogBean::setMailBox_Type);
		Optional.ofNullable(mailLog0.getInterface()).ifPresent(mailLogBean::setInterface);
		Optional.ofNullable(mailLog0.getMsisdn()).ifPresent(mailLogBean::setMsisdn);
		Optional.ofNullable(mailLog0.getDescription()).ifPresent(mailLogBean::setDescription);
		Optional.ofNullable(mailLog0.getRequest_Date()).ifPresent(mailLogBean::setRequest_Date);
		Optional.ofNullable(mailLog0.getServer_Id()).ifPresent(mailLogBean::setServer_Id);
		Optional.ofNullable(mailLog0.getUpdated_By()).ifPresent(mailLogBean::setUpdated_By);
		Optional.ofNullable(mailLog0.getType()).ifPresent(mailLogBean::setType);
		Optional.ofNullable(mailLog0.getSub_type()).ifPresent(mailLogBean::setSub_type);
		Optional.ofNullable(mailLog0.getCdr_Status()).ifPresent(mailLogBean::setCdr_Status);
		Optional.ofNullable(mailLog0.getService_Type()).ifPresent(mailLogBean::setService_Type);

		return mailLogBean;
	}
	public static MailBoxLogBean convertMailBoxLog5EntityToMailBoxLogBean(MailBoxLog5 mailLog0) {

		MailBoxLogBean mailLogBean = new MailBoxLogBean();

		Optional.ofNullable(mailLog0.getId()).ifPresent(mailLogBean::setId);
		Optional.ofNullable(mailLog0.getMailBox_Type()).ifPresent(mailLogBean::setMailBox_Type);
		Optional.ofNullable(mailLog0.getInterface()).ifPresent(mailLogBean::setInterface);
		Optional.ofNullable(mailLog0.getMsisdn()).ifPresent(mailLogBean::setMsisdn);
		Optional.ofNullable(mailLog0.getDescription()).ifPresent(mailLogBean::setDescription);
		Optional.ofNullable(mailLog0.getRequest_Date()).ifPresent(mailLogBean::setRequest_Date);
		Optional.ofNullable(mailLog0.getServer_Id()).ifPresent(mailLogBean::setServer_Id);
		Optional.ofNullable(mailLog0.getUpdated_By()).ifPresent(mailLogBean::setUpdated_By);
		Optional.ofNullable(mailLog0.getType()).ifPresent(mailLogBean::setType);
		Optional.ofNullable(mailLog0.getSub_type()).ifPresent(mailLogBean::setSub_type);
		Optional.ofNullable(mailLog0.getCdr_Status()).ifPresent(mailLogBean::setCdr_Status);
		Optional.ofNullable(mailLog0.getService_Type()).ifPresent(mailLogBean::setService_Type);

		return mailLogBean;
	}
	public static MailBoxLogBean convertMailBoxLog6EntityToMailBoxLogBean(MailBoxLog6 mailLog0) {

		MailBoxLogBean mailLogBean = new MailBoxLogBean();

		Optional.ofNullable(mailLog0.getId()).ifPresent(mailLogBean::setId);
		Optional.ofNullable(mailLog0.getMailBox_Type()).ifPresent(mailLogBean::setMailBox_Type);
		Optional.ofNullable(mailLog0.getInterface()).ifPresent(mailLogBean::setInterface);
		Optional.ofNullable(mailLog0.getMsisdn()).ifPresent(mailLogBean::setMsisdn);
		Optional.ofNullable(mailLog0.getDescription()).ifPresent(mailLogBean::setDescription);
		Optional.ofNullable(mailLog0.getRequest_Date()).ifPresent(mailLogBean::setRequest_Date);
		Optional.ofNullable(mailLog0.getServer_Id()).ifPresent(mailLogBean::setServer_Id);
		Optional.ofNullable(mailLog0.getUpdated_By()).ifPresent(mailLogBean::setUpdated_By);
		Optional.ofNullable(mailLog0.getType()).ifPresent(mailLogBean::setType);
		Optional.ofNullable(mailLog0.getSub_type()).ifPresent(mailLogBean::setSub_type);
		Optional.ofNullable(mailLog0.getCdr_Status()).ifPresent(mailLogBean::setCdr_Status);
		Optional.ofNullable(mailLog0.getService_Type()).ifPresent(mailLogBean::setService_Type);

		return mailLogBean;
	}
	public static MailBoxLogBean convertMailBoxLog7EntityToMailBoxLogBean(MailBoxLog7 mailLog0) {

		MailBoxLogBean mailLogBean = new MailBoxLogBean();

		Optional.ofNullable(mailLog0.getId()).ifPresent(mailLogBean::setId);
		Optional.ofNullable(mailLog0.getMailBox_Type()).ifPresent(mailLogBean::setMailBox_Type);
		Optional.ofNullable(mailLog0.getInterface()).ifPresent(mailLogBean::setInterface);
		Optional.ofNullable(mailLog0.getMsisdn()).ifPresent(mailLogBean::setMsisdn);
		Optional.ofNullable(mailLog0.getDescription()).ifPresent(mailLogBean::setDescription);
		Optional.ofNullable(mailLog0.getRequest_Date()).ifPresent(mailLogBean::setRequest_Date);
		Optional.ofNullable(mailLog0.getServer_Id()).ifPresent(mailLogBean::setServer_Id);
		Optional.ofNullable(mailLog0.getUpdated_By()).ifPresent(mailLogBean::setUpdated_By);
		Optional.ofNullable(mailLog0.getType()).ifPresent(mailLogBean::setType);
		Optional.ofNullable(mailLog0.getSub_type()).ifPresent(mailLogBean::setSub_type);
		Optional.ofNullable(mailLog0.getCdr_Status()).ifPresent(mailLogBean::setCdr_Status);
		Optional.ofNullable(mailLog0.getService_Type()).ifPresent(mailLogBean::setService_Type);

		return mailLogBean;
	}
	public static MailBoxLogBean convertMailBoxLog8EntityToMailBoxLogBean(MailBoxLog8 mailLog0) {

		MailBoxLogBean mailLogBean = new MailBoxLogBean();

		Optional.ofNullable(mailLog0.getId()).ifPresent(mailLogBean::setId);
		Optional.ofNullable(mailLog0.getMailBox_Type()).ifPresent(mailLogBean::setMailBox_Type);
		Optional.ofNullable(mailLog0.getInterface()).ifPresent(mailLogBean::setInterface);
		Optional.ofNullable(mailLog0.getMsisdn()).ifPresent(mailLogBean::setMsisdn);
		Optional.ofNullable(mailLog0.getDescription()).ifPresent(mailLogBean::setDescription);
		Optional.ofNullable(mailLog0.getRequest_Date()).ifPresent(mailLogBean::setRequest_Date);
		Optional.ofNullable(mailLog0.getServer_Id()).ifPresent(mailLogBean::setServer_Id);
		Optional.ofNullable(mailLog0.getUpdated_By()).ifPresent(mailLogBean::setUpdated_By);
		Optional.ofNullable(mailLog0.getType()).ifPresent(mailLogBean::setType);
		Optional.ofNullable(mailLog0.getSub_type()).ifPresent(mailLogBean::setSub_type);
		Optional.ofNullable(mailLog0.getCdr_Status()).ifPresent(mailLogBean::setCdr_Status);
		Optional.ofNullable(mailLog0.getService_Type()).ifPresent(mailLogBean::setService_Type);

		return mailLogBean;
	}
	public static MailBoxLogBean convertMailBoxLog9EntityToMailBoxLogBean(MailBoxLog9 mailLog0) {

		MailBoxLogBean mailLogBean = new MailBoxLogBean();

		Optional.ofNullable(mailLog0.getId()).ifPresent(mailLogBean::setId);
		Optional.ofNullable(mailLog0.getMailBox_Type()).ifPresent(mailLogBean::setMailBox_Type);
		Optional.ofNullable(mailLog0.getInterface()).ifPresent(mailLogBean::setInterface);
		Optional.ofNullable(mailLog0.getMsisdn()).ifPresent(mailLogBean::setMsisdn);
		Optional.ofNullable(mailLog0.getDescription()).ifPresent(mailLogBean::setDescription);
		Optional.ofNullable(mailLog0.getRequest_Date()).ifPresent(mailLogBean::setRequest_Date);
		Optional.ofNullable(mailLog0.getServer_Id()).ifPresent(mailLogBean::setServer_Id);
		Optional.ofNullable(mailLog0.getUpdated_By()).ifPresent(mailLogBean::setUpdated_By);
		Optional.ofNullable(mailLog0.getType()).ifPresent(mailLogBean::setType);
		Optional.ofNullable(mailLog0.getSub_type()).ifPresent(mailLogBean::setSub_type);
		Optional.ofNullable(mailLog0.getCdr_Status()).ifPresent(mailLogBean::setCdr_Status);
		Optional.ofNullable(mailLog0.getService_Type()).ifPresent(mailLogBean::setService_Type);

		return mailLogBean;
	}
	/*
	 * public static SmsTempBean convertToSmsTempEntityToSmsTempBean(SmsTemp
	 * smsTemp) {
	 * 
	 * SmsTempBean tempBean = new SmsTempBean();
	 * 
	 * Optional.ofNullable(smsTemp.getEmbeddedTempId().getTempId()).ifPresent(
	 * tempBean::setTempId);
	 * Optional.ofNullable(smsTemp.getEmbeddedTempId().getLangId()).ifPresent(
	 * tempBean::setLangId);
	 * Optional.ofNullable(smsTemp.getTempType()).ifPresent(tempBean::setTempType);
	 * Optional.ofNullable(smsTemp.getTempDesc()).ifPresent(tempBean::setTempDesc);
	 * Optional.ofNullable(smsTemp.getTempMsg()).ifPresent(tempBean::setTempMsg);
	 * Optional.ofNullable(smsTemp.getTokenAllowed()).ifPresent(tempBean::
	 * setTokenAllowed);
	 * 
	 * return tempBean; }
	 */
}