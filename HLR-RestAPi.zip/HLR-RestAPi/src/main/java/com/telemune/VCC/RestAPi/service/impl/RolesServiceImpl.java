package com.telemune.VCC.RestAPi.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telemune.VCC.RestAPi.bean.HttpLinkBean;
import com.telemune.VCC.RestAPi.bean.RolesBean;
import com.telemune.VCC.RestAPi.entities.HttpLinks;
import com.telemune.VCC.RestAPi.entities.Role;
import com.telemune.VCC.RestAPi.repository.HttpLinksRepo;
import com.telemune.VCC.RestAPi.repository.RolesRepo;
import com.telemune.VCC.RestAPi.service.RolesService;

@Service
public class RolesServiceImpl implements RolesService {

	@Autowired
	RolesRepo marketPlaceRolesRepository;

	@Autowired
	HttpLinksRepo httpLinkRepo;

	private static final Logger logger = Logger.getLogger(RolesServiceImpl.class);

	@Autowired
	HttpLinksRepo httpLinksRepository;

	@Override
	public RolesBean createRole(RolesBean roleVO) {

		logger.info("Inside createRole() method of RoleServiceImpl class");

		try {
			int newRoleId = 1 + marketPlaceRolesRepository.maxRoleId();

			Role marketPlaceRoles = new Role();

			Optional.ofNullable(roleVO.getDescription()).ifPresent(marketPlaceRoles::setDescription);
			Optional.ofNullable(roleVO.getRoleName()).ifPresent(marketPlaceRoles::setRoleName);
			marketPlaceRoles.setRoleId(newRoleId);

			/*
			 * List<HttpLinks> httplst = new ArrayList<>();
			 * 
			 * for (HttpLinkBean hl : roleVO.getHttpLinkslst()) { HttpLinks httpdb =
			 * httpLinksRepository.findByLinkId(hl.getLinkId()); httplst.add(httpdb); }
			 */
			// marketPlaceRoles.setHttpLinks(httplst);

			Role marketPlaceRolesdb = marketPlaceRolesRepository.save(marketPlaceRoles);

			logger.debug(marketPlaceRolesdb.toString());

			if (marketPlaceRolesdb != null) {
				Optional.ofNullable(marketPlaceRolesdb.getDescription()).ifPresent(roleVO::setDescription);
				Optional.ofNullable(marketPlaceRolesdb.getRoleName()).ifPresent(roleVO::setRoleName);
				roleVO.setRoleId(marketPlaceRolesdb.getRoleId());
			}

		} catch (Exception exp) {
			exp.printStackTrace();
		}

		logger.info("Exit createRole() method of RoleServiceImpl class");
		return roleVO;
	}

	@Override
	@Transactional
	public RolesBean updateRole(RolesBean roleVO) {

		logger.info("Inside updateRole() method of RoleServiceImpl class");

		try {
			Role marketPlaceRoles = marketPlaceRolesRepository.findByRoleId(roleVO.getRoleId());

			if (marketPlaceRoles != null) {

				Optional.ofNullable(roleVO.getDescription()).ifPresent(marketPlaceRoles::setDescription);
				Optional.ofNullable(roleVO.getRoleName()).ifPresent(marketPlaceRoles::setRoleName);

				List<HttpLinks> httplst = new ArrayList<>();
				for (HttpLinkBean hl : roleVO.getHttpLinkslst()) {
					HttpLinks httpdb = httpLinksRepository.findByLinkId(hl.getLinkId());
					httplst.add(httpdb);
				}
			//	marketPlaceRoles.setHttpLinks(httplst);
				Role marketPlaceRolesdb = marketPlaceRolesRepository.save(marketPlaceRoles);

				logger.debug(marketPlaceRolesdb.toString());

				if (marketPlaceRolesdb != null) {
					Optional.ofNullable(marketPlaceRolesdb.getDescription()).ifPresent(roleVO::setDescription);
					Optional.ofNullable(marketPlaceRolesdb.getRoleName()).ifPresent(roleVO::setRoleName);
					roleVO.setRoleId(marketPlaceRolesdb.getRoleId());
				}
				logger.info("Exit updateRole() method of RoleServiceImpl class");
				return roleVO;
			}

			else
				logger.info("Exit updateRole() method of RoleServiceImpl class");
			return new RolesBean();
		} catch (Exception exp) {
			exp.printStackTrace();
		}
		logger.info("Exit updateRole() method of RoleServiceImpl class");
		return new RolesBean();

	}

	@Override
	public List<RolesBean> findAllRole() {
		// TODO Auto-generated method stub

		logger.info("Inside findAllRole() method of RoleServiceImpl class");

		List<RolesBean> roleVOlst = new ArrayList<>();

		List<Role> marketPlaceRoleslst = marketPlaceRolesRepository.findAll();

		for (Role mpr : marketPlaceRoleslst) {
			RolesBean role = new RolesBean();

			role.setRoleId(mpr.getRoleId());
			role.setRoleName(mpr.getRoleName());
			role.setDescription(mpr.getDescription());
			roleVOlst.add(role);

		}
		logger.info("Exit findAllRole() method of RoleServiceImpl class");
		return roleVOlst;
	}

	@Override
	public RolesBean findById(Integer id) {
		// TODO Auto-generated method stub
		logger.info("Inside findById() method of RoleServiceImpl class");

		Role marketPlaceRoles = marketPlaceRolesRepository.findByRoleId(id);

		logger.debug(marketPlaceRoles.toString());

		RolesBean roleVO = new RolesBean();

		if (marketPlaceRoles != null) {

			Optional.ofNullable(marketPlaceRoles.getRoleId()).ifPresent(roleVO::setRoleId);
			Optional.ofNullable(marketPlaceRoles.getDescription()).ifPresent(roleVO::setDescription);
			Optional.ofNullable(marketPlaceRoles.getRoleName()).ifPresent(roleVO::setRoleName);

			/*
			 * List<HttpLinkBean> httplst = new ArrayList<>();
			 * 
			 * for (HttpLinks httpLinks : marketPlaceRoles.getHttpLinks()) { HttpLinkBean
			 * httpLinksVO = new HttpLinkBean();
			 * httpLinksVO.setDescription(httpLinks.getDescription());
			 * httpLinksVO.setLinkId(httpLinks.getLinkId()); httplst.add(httpLinksVO); }
			 */
			logger.info("Exit findById() method of RoleServiceImpl class");
			//roleVO.setHttpLinkslst(httplst);

		}
		return roleVO;
	}

	@Override
	@Transactional
	public boolean roleDeleteById(Integer roleId) {
		// TODO Auto-generated method stub

		Role marketPlaceRoles = marketPlaceRolesRepository.findByRoleId(roleId);

		logger.info("Inside roleDeleteById() method of RoleServiceImpl class");

		logger.debug(marketPlaceRoles.toString());

		try {
			if (marketPlaceRoles != null) {
				marketPlaceRolesRepository.deleteByRoleId(roleId);
				logger.info("Exit roleDeleteById() method of RoleServiceImpl class");
				return true;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		logger.info("Exit roleDeleteById() method of RoleServiceImpl class");
		return false;

	}

}
