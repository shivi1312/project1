package com.telemune.VCC.RestAPi.dao;


import com.telemune.VCC.RestAPi.entities.UserF;
import com.telemune.VCC.RestAPi.model.ApiRequestModel;
import com.telemune.VCC.RestAPi.model.ApiResponseModel;


public interface UssdApiDao {

	public ApiResponseModel getProfileDetailByMsisdn(ApiRequestModel profileRequest,ApiResponseModel profileResponse) ;
	public boolean updateLastVisitTime(String msisdn);
	public ApiResponseModel getSubDetailByMsisdn(ApiRequestModel profileRequest,ApiResponseModel profileResponse) ;
	public int loadAppConfigParams();
	public int getUserDetails(UserF user);

}
