package com.telemune.VCC.RestAPi.repository.custcare;

public interface CustCareRepo{

}
