package com.telemune.VCC.RestAPi.model.custcare;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.telemune.VCC.RestAPi.bean.AuthUserBean;
import com.telemune.VCC.RestAPi.bean.VoiceMsgBean;
import com.telemune.VCC.RestAPi.entities.custcare.AuthUser0;
import com.telemune.VCC.RestAPi.entities.custcare.VoiceMsg;

@Component
public class EntityToBeanCust {

	public static AuthUserBean convertAuthUser0EntityToAuthUSerBean(AuthUser0 authUser0) {

		AuthUserBean authUserBean = new AuthUserBean();

		Optional.ofNullable(authUser0.getClassType()).ifPresent(authUserBean::setClassType);
		Optional.ofNullable(authUser0.getDelInterface()).ifPresent(authUserBean::setDelInterface);
		Optional.ofNullable(authUser0.getEmail()).ifPresent(authUserBean::setEmail);
		Optional.ofNullable(authUser0.getGreetingType()).ifPresent(authUserBean::setGreetingType);
		Optional.ofNullable(authUser0.getImsi()).ifPresent(authUserBean::setImsi);
		Optional.ofNullable(authUser0.getIsMigration()).ifPresent(authUserBean::setIsMigration);
		Optional.ofNullable(authUser0.getIsNew()).ifPresent(authUserBean::setIsNew);
		Optional.ofNullable(authUser0.getLang()).ifPresent(authUserBean::setLang);
		Optional.ofNullable(authUser0.getLoginName()).ifPresent(authUserBean::setLoginName);
		Optional.ofNullable(authUser0.getMsisdn()).ifPresent(authUserBean::setMsisdn);
		Optional.ofNullable(authUser0.getPass()).ifPresent(authUserBean::setPass);
		Optional.ofNullable(authUser0.getServiceType()).ifPresent(authUserBean::setServiceType);
		Optional.ofNullable(authUser0.getStatus()).ifPresent(authUserBean::setStatus);
		Optional.ofNullable(authUser0.getSubType()).ifPresent(authUserBean::setSubType);
		Optional.ofNullable(authUser0.getTid()).ifPresent(authUserBean::setTid);
		Optional.ofNullable(authUser0.getwPin()).ifPresent(authUserBean::setwPin);

		return authUserBean;
	}

	public static VoiceMsgBean convertVoiceMsgEntityToVoiceMsgBean(VoiceMsg voiceMsg) {

		VoiceMsgBean voiceMsgBean = new VoiceMsgBean();

		Optional.ofNullable(voiceMsg.getCallTime()).ifPresent(voiceMsgBean::setCallTime);
		Optional.ofNullable(voiceMsg.getDestinationNum()).ifPresent(voiceMsgBean::setDestinationNum);
		Optional.ofNullable(voiceMsg.getFileName()).ifPresent(voiceMsgBean::setFileName);
		Optional.ofNullable(voiceMsg.getLocalMsgIndex()).ifPresent(voiceMsgBean::setLocalMsgIndex);
		Optional.ofNullable(voiceMsg.getMsgPriority()).ifPresent(voiceMsgBean::setMsgPriority);
		Optional.ofNullable(voiceMsg.getMsgProtect()).ifPresent(voiceMsgBean::setMsgProtect);
		Optional.ofNullable(voiceMsg.getMsgStatus()).ifPresent(voiceMsgBean::setMsgStatus);
		Optional.ofNullable(voiceMsg.getOriginalNum()).ifPresent(voiceMsgBean::setOriginalNum);
		Optional.ofNullable(voiceMsg.getOriginatingNum()).ifPresent(voiceMsgBean::setOriginatingNum);
		Optional.ofNullable(voiceMsg.getPass()).ifPresent(voiceMsgBean::setPass);
		Optional.ofNullable(voiceMsg.getPassProtected()).ifPresent(voiceMsgBean::setPassProtected);
		Optional.ofNullable(voiceMsg.getRecDuration()).ifPresent(voiceMsgBean::setRecDuration);
		Optional.ofNullable(voiceMsg.getRetTime()).ifPresent(voiceMsgBean::setRetTime);
		Optional.ofNullable(voiceMsg.getSendingTime()).ifPresent(voiceMsgBean::setSendingTime);
		Optional.ofNullable(voiceMsg.getServiceType()).ifPresent(voiceMsgBean::setServiceType);
		Optional.ofNullable(voiceMsg.getVoicemsgIndex()).ifPresent(voiceMsgBean::setVoicemsgIndex);

		return voiceMsgBean;
	}
	
}
