package com.telemune.VCC.RestAPi.entities.custcare;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "vcc_fwd_call_logs")
public class FwdCallLogs {
	@Id
	@Column(name = "CALL_ID", columnDefinition = "varchar(50) default '0000000000000000000000000'")
	private String callId;

	@Column(name = "SERVER_ID", columnDefinition = "Integer default 0")
	private Integer serverId;

	@Column(name = "ORIGINATING_NUMBER", columnDefinition = "varchar(20) default '0000000000'")
	private String orgNum;

	@Column(name = "DESTINATION_NUMBER", columnDefinition = "varchar(20) default '0000000000'")
	private String destiNum;

	@Column(name = "CIRCUIT_ID")
	private Integer circuitId;

	@Column(name = "IAM_CAUSE_CODE")
	private String iamCauseCode;

	@Column(name = "REL_CAUSE_CODE")
	private String relCauseCode;

	@Column(name = "MSG_LENGTH", columnDefinition = "Integer default 0")
	private Integer msgLength;

	@Column(name = "VOICE_MSG_INDEX", columnDefinition = "Integer default 0")
	private Integer voiceMsgIndex;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CALL_TIME", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date callTime;

	@Column(name = "CALL_DURATION", columnDefinition = "Integer default 0")
	private Integer callDur;

	@Column(name = "ANSWERED")
	private Integer answered;

	@Column(name = "SERVICE_TYPE", columnDefinition = "varchar(20) default '0000'")
	private String serviceType;

	@Column(name = "SUB_TYPE")
	private String subType;

	@Column(name = "RATE_PLAN")
	private Integer ratePlan;

	@Column(name = "FILENAME")
	private String fileName;

	@Column(name = "ORG_CNT_CODE", columnDefinition = "varchar(20) default 'N'")
	private String orgCntCode;

	public String getCallId() {
		return callId;
	}

	public void setCallId(String callId) {
		this.callId = callId;
	}

	public Integer getServerId() {
		return serverId;
	}

	public void setServerId(Integer serverId) {
		this.serverId = serverId;
	}

	public String getOrgNum() {
		return orgNum;
	}

	public void setOrgNum(String orgNum) {
		this.orgNum = orgNum;
	}

	public String getDestiNum() {
		return destiNum;
	}

	public void setDestiNum(String destiNum) {
		this.destiNum = destiNum;
	}

	public Integer getCircuitId() {
		return circuitId;
	}

	public void setCircuitId(Integer circuitId) {
		this.circuitId = circuitId;
	}

	public String getIamCauseCode() {
		return iamCauseCode;
	}

	public void setIamCauseCode(String iamCauseCode) {
		this.iamCauseCode = iamCauseCode;
	}

	public String getRelCauseCode() {
		return relCauseCode;
	}

	public void setRelCauseCode(String relCauseCode) {
		this.relCauseCode = relCauseCode;
	}

	public Integer getMsgLength() {
		return msgLength;
	}

	public void setMsgLength(Integer msgLength) {
		this.msgLength = msgLength;
	}

	public Integer getVoiceMsgIndex() {
		return voiceMsgIndex;
	}

	public void setVoiceMsgIndex(Integer voiceMsgIndex) {
		this.voiceMsgIndex = voiceMsgIndex;
	}

	public Date getCallTime() {
		return callTime;
	}

	public void setCallTime(Date callTime) {
		this.callTime = callTime;
	}

	public Integer getCallDur() {
		return callDur;
	}

	public void setCallDur(Integer callDur) {
		this.callDur = callDur;
	}

	public Integer getAnswered() {
		return answered;
	}

	public void setAnswered(Integer answered) {
		this.answered = answered;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public Integer getRatePlan() {
		return ratePlan;
	}

	public void setRatePlan(Integer ratePlan) {
		this.ratePlan = ratePlan;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getOrgCntCode() {
		return orgCntCode;
	}

	public void setOrgCntCode(String orgCntCode) {
		this.orgCntCode = orgCntCode;
	}

	
}
