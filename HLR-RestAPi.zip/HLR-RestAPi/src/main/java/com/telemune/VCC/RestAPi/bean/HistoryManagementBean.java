package com.telemune.VCC.RestAPi.bean;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;


public class HistoryManagementBean {
	private String msisdn;
	private String serviceType;
	private int id;
	private String sessionNumber;
	private String title;
	private String[] header;
	private ArrayList dataAl= new ArrayList();
	private String start;
	private String end;
	private String basedOn;
	private ArrayList<Country> countryCodeList= new ArrayList<Country>();
	private int defCountryCode=-1;
	private int countryCode=-1;
	private int planId=-1;
	private int defPlanId=-1;
	private HashMap<Integer, String> ratePlanMap= new HashMap<Integer, String>();
	private int size;
	private String rbtName;
	private String artistName;
	private String albName;
	
	private String subType="";

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSessionNumber() {
		return sessionNumber;
	}

	public void setSessionNumber(String sessionNumber) {
		this.sessionNumber = sessionNumber;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String[] getHeader() {
		return header;
	}

	public void setHeader(String[] header) {
		this.header = header;
	}

	public ArrayList getDataAl() {
		return dataAl;
	}

	public void setDataAl(ArrayList dataAl) {
		this.dataAl = dataAl;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}

	public String getBasedOn() {
		return basedOn;
	}

	public void setBasedOn(String basedOn) {
		this.basedOn = basedOn;
	}

	public ArrayList<Country> getCountryCodeList() {
		return countryCodeList;
	}

	public void setCountryCodeList(ArrayList<Country> countryCodeList) {
		this.countryCodeList = countryCodeList;
	}

	public int getDefCountryCode() {
		return defCountryCode;
	}

	public void setDefCountryCode(int defCountryCode) {
		this.defCountryCode = defCountryCode;
	}

	public int getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(int countryCode) {
		this.countryCode = countryCode;
	}

	public int getPlanId() {
		return planId;
	}

	public void setPlanId(int planId) {
		this.planId = planId;
	}

	public int getDefPlanId() {
		return defPlanId;
	}

	public void setDefPlanId(int defPlanId) {
		this.defPlanId = defPlanId;
	}

	public HashMap<Integer, String> getRatePlanMap() {
		return ratePlanMap;
	}

	public void setRatePlanMap(HashMap<Integer, String> ratePlanMap) {
		this.ratePlanMap = ratePlanMap;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public String getRbtName() {
		return rbtName;
	}

	public void setRbtName(String rbtName) {
		this.rbtName = rbtName;
	}

	public String getArtistName() {
		return artistName;
	}

	public void setArtistName(String artistName) {
		this.artistName = artistName;
	}

	public String getAlbName() {
		return albName;
	}

	public void setAlbName(String albName) {
		this.albName = albName;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	@Override
	public String toString() {
		return "HistoryManagementBean [msisdn=" + msisdn + ", serviceType=" + serviceType + ", id=" + id
				+ ", sessionNumber=" + sessionNumber + ", title=" + title + ", header=" + Arrays.toString(header)
				+ ", dataAl=" + dataAl + ", start=" + start + ", end=" + end + ", basedOn=" + basedOn
				+ ", countryCodeList=" + countryCodeList + ", defCountryCode=" + defCountryCode + ", countryCode="
				+ countryCode + ", planId=" + planId + ", defPlanId=" + defPlanId + ", ratePlanMap=" + ratePlanMap
				+ ", size=" + size + ", rbtName=" + rbtName + ", artistName=" + artistName + ", albName=" + albName
				+ ", subType=" + subType + "]";
	}
	

	
}
