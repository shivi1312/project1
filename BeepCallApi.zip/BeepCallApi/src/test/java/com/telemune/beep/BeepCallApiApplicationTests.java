package com.telemune.beep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeepCallApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
