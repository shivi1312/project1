/**
 * 
 */
package com.telemune.beep.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.DynamicInsert;



/**
 * @author kirti
 *
 */
@Entity
@DynamicInsert
@Table(name = "LIST_DETAIL")
public class ListDetail {

	@Id
	@Size(max = 10)
	@Column(name = "ID")
	private Integer id;
	
	
	@NotNull
	@Size(max = 20)
	@Column(name = "MSISDN")
	private String msisdn;
	
	@NotNull
	@Size(max = 10)
	@Column(name = "CREATE_DATE")
	private Integer create_date;
	
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LIST_ID")
	private ListManager listManager;
	
	
	
	public ListManager getListManager() {
		return listManager;
	}


	public void setListManager(ListManager listManager) {
		this.listManager = listManager;
	}


	public Integer getId() {
		return id;
	}


	


	public String getMsisdn() {
		return msisdn;
	}


	public Integer getCreate_date() {
		return create_date;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}


	public void setCreate_date(Integer create_date) {
		this.create_date = create_date;
	}


	
}
