/**
 * 
 */
package com.telemune.beep.service;

import java.util.List;

import com.telemune.beep.dto.BeepCallDto;
import com.telemune.beep.dto.CallCheckDto;
import com.telemune.beep.entity.LbsTemplate;
import com.telemune.beep.entity.Params;

/**
 * @author kirti
 *
 */
public interface CheckCallService {

	List<Params> getParams();

	/**
	 * 
	 */
	


	public String getParameter(String param_name);

	/**
	 * 
	 */
   int processCheckCall(CallCheckDto callCheckDto);

	/**
	 * @param callCheckDto
	 * @return
	 */
	boolean getWhitelist(CallCheckDto callCheckDto);

	/**
	 * @param callCheckDto
	 * @return
	 */
	 int getCheckLimit(CallCheckDto callCheckDto);
	 
	 int getCheckTimeLimit(CallCheckDto callCheckDto);
	 
	 
	 
	 

	/**
	 * @param callCheckDto
	 * @return
	 */
	boolean getBlacklist(CallCheckDto callCheckDto);
	
	
}
