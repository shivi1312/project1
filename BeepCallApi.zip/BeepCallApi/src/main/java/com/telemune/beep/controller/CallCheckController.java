/**
 * 
 */
package com.telemune.beep.controller;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.beep.common.Constants;
import com.telemune.beep.common.Response;
import com.telemune.beep.dto.BeepCallDto;
import com.telemune.beep.dto.CallCheckDto;
import com.telemune.beep.service.CheckCallService;

/**
 * @author kirti sharma
 *
 */
@RestController
@RequestMapping(produces = "application/xml")
public class CallCheckController {

	private static final Logger logger = LogManager.getLogger(CallCheckController.class);

	@Autowired
	private CheckCallService checkCallService;

	@GetMapping("/callcheck")
	public ResponseEntity<CallCheckDto> callCheck(@RequestParam("callUUID") String callUUID,
			@RequestParam("callingnum") String origination,
			@RequestParam("originalDestination") String originalDestination, @RequestParam("callTime") String callTime,
			@RequestParam("interface") String inter) {
		ResponseEntity<CallCheckDto> callCheck = null;
		try {
			logger.info("### inside callCheck control ###");
			CallCheckDto callCheckDto = new CallCheckDto();

			callCheckDto.setOrigination(origination);
			callCheckDto.setOriginalDestination(originalDestination);
			callCheckDto.setCalltime(callTime);
			callCheckDto.setInter(inter);
           BeepCallDto beepCallDto = new BeepCallDto();
	
			logger.info("### calling process Start for ###" + callCheckDto.toString());
			checkCallService.processCheckCall(callCheckDto);
			logger.info("### After Call Checking process ###" + callCheckDto.toString());
			HttpHeaders headers = new HttpHeaders();
			callCheck = new ResponseEntity<>(callCheckDto, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error(" Error in processing request call controller" + e.getMessage());
			e.printStackTrace();
		}
		return callCheck;

	}
}
