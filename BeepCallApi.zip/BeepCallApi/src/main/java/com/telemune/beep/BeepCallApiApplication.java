package com.telemune.beep;

import java.util.Properties;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.env.Environment;

import com.telemune.beep.config.AsyncConfiguration;
import com.telemune.beep.config.CacheConfig;
import com.telemune.beep.config.GlobalParams;
import com.telemune.beep.service.BeepCallService;
import com.telemune.beep.service.CheckCallService;

@SpringBootApplication
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class BeepCallApiApplication implements CommandLineRunner {

	private static final Logger logger = LogManager.getLogger(BeepCallApiApplication.class);
	@Autowired
	private CacheConfig cacheLoader;

	@Autowired
	private AsyncConfiguration asyncConfiguration;

	@Autowired
	private GlobalParams globalParams;

	@Autowired
	private BeepCallService beepCallService;

	@Autowired
	private Environment environment;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private CheckCallService checkCallService;

//	@Autowired
//	private CacheConfig cacheConfig;

	private static Properties properties = new Properties();

	public static void main(String[] args) {
		
		
		SpringApplication.run(BeepCallApiApplication.class, args);
		
		String VERSION = "v0.0.0.2";
		System.out.println("***********************************************************************************");
		System.out.println("\n              BeepCall  Version [  " + VERSION + "  ]");
		System.out.println("Copyright @2022Telemune Software Solutions Private Limited. All rights reserved");
		System.out.println("\n                Name of the Licensee : Telemune");
		System.out.println("***********************************************************************************");
		System.out.println("\n");
		
		try {
		if (args[0].equalsIgnoreCase("-v")) {
			
			System.exit(1);
		}
		}
		catch(Exception e)
		{
		//	e.printStackTrace();
		}
		
	
	}

	@PostConstruct
	public void init() {

		// add lbs template table in cache and Parameters in cache

		beepCallService.getAllLbsTemplates();
		beepCallService.getAllParams();
		beepCallService.getFailureReasons();

	}

	private void loadFileLogWriterConfiguration() {
		try {
			logger.info("loading BeepCallApi");
			String FileName = this.environment.getProperty("BEEPCALL_LOG_FILE_NAME");
			String FilePath = this.environment.getProperty("BEEPCALL_LOG_FILE_PATH");
			String ArchiveFileName = this.environment.getProperty("BEEPCALL_ARCHIVE_FILE_NAME");
			String ArchiveFilePath = this.environment.getProperty("BEEPCALL_ARCHIVE_FILE_PATH");

			globalParams.getFileLogWriter().setFilename(FileName);
			globalParams.getFileLogWriter().setFilePath(FilePath);
			globalParams.getFileLogWriter().setArchiveFilename(ArchiveFileName);
			globalParams.getFileLogWriter().setArchiveFilePath(ArchiveFilePath);
			globalParams.getFileLogWriter()
					.setNewFileInterval(Integer.parseInt(this.environment.getProperty("BEEPCALL_LOG_FILE_INTERVAL")));
			globalParams.getFileLogWriter().initialize();
		} catch (Exception e) {
			logger.info("Exception", e);
		}
	}

	@Override
	public void run(String... args) throws Exception {
		loadFileLogWriterConfiguration();
	}

}
