/**
 * 
 */
package com.telemune.beep.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.DynamicInsert;

/**
 * @author kirti sharma
 *
 */
@Entity
@DynamicInsert
@Table(name = "daily_call_log")
public class DailyCallLog {

	


	public String getOrigination() {
		return origination;
	}

	public String getDestination() {
		return destination;
	}

	public String getCalltime() {
		return calltime;
	}

	

	public void setOrigination(String origination) {
		this.origination = origination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public void setCalltime(String calltime) {
		this.calltime = calltime;
	}

	@Id
	
    @Column(name = "id")
	private String Id;
	
	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	@NotNull
	@Size(max = 20)
	@Column(name = "ORIGINATING_NUM")
	private String origination;
	
	@NotNull
	@Size(max = 20)
	@Column(name = "DESTINATION_NUM")
	private String destination;
	
	@NotNull
	@Column(name = "CALL_TIME")
	private String calltime;
	
	

	
	
	
}
