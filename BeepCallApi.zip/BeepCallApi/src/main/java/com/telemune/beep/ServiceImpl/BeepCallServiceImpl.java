package com.telemune.beep.ServiceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.telemune.beep.common.Constants;
import com.telemune.beep.config.CacheConfig;
import com.telemune.beep.config.GlobalParams;
import com.telemune.beep.dto.BeepCallDto;
import com.telemune.beep.dto.CallCheckDto;
import com.telemune.beep.dto.CdrDto;
import com.telemune.beep.entity.BeepCall;
import com.telemune.beep.entity.DailyCallLog;
import com.telemune.beep.entity.FailureReason;
import com.telemune.beep.entity.GmatMsg;
import com.telemune.beep.entity.LbsTemplate;
import com.telemune.beep.entity.Params;
import com.telemune.beep.repo.BeepRepository;
import com.telemune.beep.repo.DailyCallLogRepository;
import com.telemune.beep.repo.FailureReasonRepository;
import com.telemune.beep.repo.GmatRepository;
import com.telemune.beep.repo.lbsRepository;
import com.telemune.beep.service.BeepCallService;
import com.telemune.beep.service.CheckCallService;

@Service
public class BeepCallServiceImpl implements BeepCallService {

	private static final Logger logger = LogManager.getLogger(BeepCallServiceImpl.class);

	@Autowired
	private BeepRepository beepCallRepository;

	@Autowired
	private GlobalParams globalParams;

	@Autowired
	private lbsRepository lbsRepository;

	@Autowired
	private FailureReasonRepository failureRepository;

	@Autowired
	private GmatRepository gmatRepository;

	@Autowired
	private CacheConfig cacheConfig;

	@Autowired
	private Environment environment;

	@Autowired
	com.telemune.beep.service.Producer producer;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private DailyCallLogRepository dailyCallLogRepository;

	@Autowired
	private CheckCallService checkCallService;

	String templateMessage;
	String dest;

	@Async("taskExecutor")
	public CompletableFuture<BeepCallDto> processSaveCall(BeepCallDto beepCallDto) {
		logger.info("Inside ProcessSaveCall:" + beepCallDto.toString());
		try {
			if (beepCallDto.getCallAllowed() == 1) {

				// if (beepCallDto.getInter().equals("D")) {
				// isFromOperator(beepCallDto);
				if ((getParameter("OFFNET_BEEPCALL_SMS_ENABLE")).equals("1")) {
					sendSmstoBparty(beepCallDto);
				} else if (beepCallDto.getIsAirtel() == 1) {
						sendSmstoBparty(beepCallDto);
						logger.info("### Message sent to B party ###");
				}

				sendSmstoAparty(beepCallDto);
				logger.info("### Message sent to A party ###");
				convertOriginationWithCountryCode(beepCallDto);
				// }
			}

			if (beepCallDto.getBeepCallSuccess() == 1 && beepCallDto.getBeepCallFailureReasonCode() == 0) {
				convertOriginationWithCountryCode(beepCallDto);
				saveDailyCallLog(beepCallDto);
				logger.info("### Call Log saved into daily_call_log ###");
			}

			convertOriginationWithCountryCode(beepCallDto);
			sendNotificationtoAparty(beepCallDto);
			logger.info("### Notification sent to A Party ###");

			saveCallLog(beepCallDto);
			logger.info("### Call Log saved into ivr_call_log ###");
			makeCallLogs(beepCallDto);
			logger.info("### Call Log saved into file ###");

			CdrDto cdrDto = new CdrDto();
			cdrDto.setOrigination(beepCallDto.getOrigination());
			cdrDto.setDestination(beepCallDto.getDestination());
			cdrDto.setOriginalDestination(beepCallDto.getOriginalDestination());
			cdrDto.setStart_date(beepCallDto.getStart_date());
			cdrDto.setStart_time(beepCallDto.getStart_time());
			cdrDto.setInter(beepCallDto.getInter());
			cdrDto.setaPartyConsent(beepCallDto.getaPartyConsent());
			cdrDto.setBeepCallSuccess(beepCallDto.getBeepCallSuccess());
			cdrDto.setGstn(beepCallDto.getGstn());
			cdrDto.setIsAirtel(beepCallDto.getIsAirtel());
			cdrDto.setSendNotificationtoAParty(beepCallDto.getSendNotificationtoAParty());
			cdrDto.setOperatorCode(beepCallDto.getOperatorCode());
			cdrDto.setSendSMStoBParty(beepCallDto.getSendSMStoBParty());

			ObjectMapper mapper = new ObjectMapper();
			String cdr = "[" + mapper.writeValueAsString(cdrDto) + "]";

			if (this.environment.getProperty("app.kafka.enable").equals("1")) {
				producer.publishToTopic(cdr);
			} else {
				logger.info("Kafka is not enabled");
			}

		} catch (Exception e) {
			logger.info("Exception occurs in processSaveCall" + e);

		}
		return CompletableFuture.completedFuture(beepCallDto);
	}

	public void getAllLbsTemplates() {
		List<LbsTemplate> getAllLbsTemplates = getTemplates();

		if (getAllLbsTemplates != null) {

			for (int i = 0; i < getAllLbsTemplates.size(); i++) {
				cacheConfig.getCacheLoader().put(
						getAllLbsTemplates.get(i).getTemplateId() + "-" + getAllLbsTemplates.get(i).getLangId(),
						getAllLbsTemplates.get(i));

			}
		}
	}

	public void getAllParams() {
		logger.info("Loading App Config Params ");
		List<Params> getAllParams = checkCallService.getParams();

		if (getAllParams != null) {
			for (int i = 0; i < getAllParams.size(); i++) {
				cacheConfig.getloadParams().put(getAllParams.get(i).getParam_name(), getAllParams.get(i));
			}
		}
	}

	public void getFailureReasons() {
		try {
			List<FailureReason> getFailureReasons = getReasons();

			if (getFailureReasons != null) {

				for (int i = 0; i < getFailureReasons.size(); i++) {
					if (getFailureReasons.get(i).getSendSms() == 1) {
						cacheConfig.getFailureReason().put(getFailureReasons.get(i).getReasonCode(),
								getFailureReasons.get(i));
					}

				}
			}
		} catch (Exception e) {
			logger.info("Exception", e);
		}
	}

	public void sendSmstoAparty(BeepCallDto beepCallDto) {

		try {
			logger.info("### inside sendSmstoAparty: ###" + beepCallDto.toString());
			String templateMessage = getTemplate(1, 1);
			Integer sendSmsEnable = beepCallDto.getSms_enable();
			if (sendSmsEnable == 1) {
				templateMessage = buildMessage(beepCallDto, templateMessage);
				String origination = getParameter("MSG_CENTER_ID");
				String destination = beepCallDto.getOrigination();
				sendSMS(beepCallDto, templateMessage, origination, destination);
				logger.info("### Message send to A Party is: ###" + beepCallDto.toString() + "templateMesage :"
						+ templateMessage);
			}
		} catch (Exception e) {
			logger.info("Exception", e);
		}
	}

	public void sendSmstoBparty(BeepCallDto beepCallDto) {

		try {
			logger.info("### inside sendSmstoBparty: ###" + beepCallDto.toString());
			String templateMessage = getTemplate(2, 1);
			String a = beepCallDto.getOrigination();
			templateMessage = buildMessage(beepCallDto, templateMessage);
			Integer sendSMStoBparty = beepCallDto.getSendSMStoBParty();
			if (sendSMStoBparty == 1) {
				String origination = beepCallDto.getOrigination();
				String destination = beepCallDto.getDestination();
				sendSMS(beepCallDto, templateMessage, origination, destination);
				logger.info("### SMS sent to B Party is: ###" + templateMessage);
			}
		} catch (Exception e) {
			logger.info("### Exception ###", e);
		}
	}

	public void sendNotificationtoAparty(BeepCallDto beepCallDto) {
		try {
			String origination = getParameter("MSG_CENTER_ID");
			String destination = beepCallDto.getOrigination();
			if (beepCallDto.getSendNotificationtoAParty() == 1 && beepCallDto.getNotificationInterface().equals("S")) {
				if (beepCallDto.getBeepCallSuccess() == 1 && beepCallDto.getSendNotificationtoAParty() == 1) {
					if (beepCallDto.getCallAllowed() == 1) {
						String templateMessage = getTemplate(3, 1);
						templateMessage = buildMessage(beepCallDto, templateMessage);

						sendSMS(beepCallDto, templateMessage, origination, destination);
						logger.info("### Send notification to A Party is: ###" + templateMessage);
					}
				}

				if (cacheConfig.getFailureReason().get(beepCallDto.getBeepCallFailureReasonCode()) != null) {

					String message = getTemplate(
							cacheConfig.getFailureReason().get(beepCallDto.getBeepCallFailureReasonCode()).getTempId(),
							1);
					logger.debug("### Send notification to A Party is: ###" + message + "======" + cacheConfig
							.getFailureReason().get(beepCallDto.getBeepCallFailureReasonCode()).getReasonCode());

					templateMessage = buildMessage(beepCallDto, message);
					/*
					 * String templateMessage = message .replaceAll("\\$\\(date\\)",
					 * beepCallDto.getCalltime().substring(0, 10)) .replaceAll("\\$\\(bParty\\)",
					 * beepCallDto.getDestination()) .replaceAll("\\$\\(atime\\)",
					 * getParameter("ORIGINATION_NUMBER_TIME_LIMIT")) .replaceAll("\\$\\(btime\\)",
					 * getParameter("DESTINATION_NUMBER_TIME_LIMIT"));
					 */
					logger.info("### Send notification to A Party is: ###" + message);
					sendSMS(beepCallDto, templateMessage, origination, destination);
				}

			}
		} catch (Exception e) {
			logger.info("Exception", e);
		}
	}

	void sendSMS(BeepCallDto beepCallDto, String templateMessage, String origination, String destination) {
		try {

			GmatMsg msg = new GmatMsg();
			msg.setOrigin(origination);
			msg.setDestination(destination);
			msg.setResponseId(1);
			msg.setMessage(templateMessage);
			msg.setLanguage("1");
			gmatRepository.save(msg);
			logger.info("### Inside sendSMS() ###" + msg);
		} catch (Exception e) {
			logger.info("Exception", e);
		}
	}

	String buildMessage(BeepCallDto beepCallDto, String templateMessage) {
		logger.info("### inside buildApartyMessage: ###");
		String message = templateMessage.replaceAll("\\$\\(aParty\\)", beepCallDto.getOrigination())
				.replaceAll("\\$\\(date\\)", beepCallDto.getCalltime().substring(0, 10))
				.replaceAll("\\$\\(bParty\\)", beepCallDto.getDestination())
				.replaceAll("\\$\\(bPartymsisdn\\)", beepCallDto.getDestination().substring(3))
				.replaceAll("\\$\\(atime\\)", getParameter("ORIGINATION_NUMBER_TIME_LIMIT"))
				.replaceAll("\\$\\(btime\\)", getParameter("DESTINATION_NUMBER_TIME_LIMIT"));
		logger.debug(message);
		return message;
	}

	/*
	 * String buildBpartyMessage(BeepCallDto beepCallDto, String templateMessage) {
	 * logger.info("inside buildBpartyMessage:"); //String convertedDestination =
	 * convertToOriginalCallNo(beepCallDto, dest); String message =
	 * templateMessage.replaceAll("\\$\\(bParty\\)",
	 * beepCallDto.getDestination()).replaceAll("\\$\\(date\\)",
	 * beepCallDto.getCalltime().substring(0, 10)) .replaceAll("\\$\\(aParty\\)",
	 * beepCallDto.getOrigination()) .replaceAll("\\$\\(atime\\)",
	 * getParameter("ORIGINATION_NUMBER_TIME_LIMIT")) .replaceAll("\\$\\(btime\\)",
	 * getParameter("DESTINATION_NUMBER_TIME_LIMIT")); return message; }
	 */
	String convertToOriginalCallNo(BeepCallDto beepCallDto, String dest) {
		try {
			String origin = beepCallDto.getDestination();
			logger.debug("### inside convertToOriginalCallNo ###" + origin);
			String countryCode = getParameter("COUNTRY_CODE");
			if (origin.startsWith(countryCode)) {
				dest = origin.trim().substring(3);
			} else {
				dest = origin;
			}

		} catch (Exception e) {
			logger.info("Exception occurs" + e);
		}
		return dest;

	}

	String convertOriginationWithCountryCode(BeepCallDto beepCallDto) {
		try {
			String origin = beepCallDto.getOrigination();
			logger.debug("### inside convertToOriginalCallNoWithCountryCode ###" + origin);
			String countryCode = getParameter("COUNTRY_CODE");

			if (origin.startsWith(countryCode)) {
				beepCallDto.setOrigination(origin);
				logger.debug("Origination number with country code" + origin);
			}

			else if (!origin.startsWith(countryCode)) {
				String original = countryCode + origin;
				beepCallDto.setOrigination(original);

			}

		} catch (Exception e) {
			logger.info("Exception occurs" + e);
		}
		return dest;

	}

//	public void isFromOperator(BeepCallDto beepCallDto) {
//		try {
//
//			String originalDestination = beepCallDto.getOriginalDestination();
//			logger.info("### inside is from operator ###" + originalDestination);
//			if (beepCallDto.getInter().equals("D")) {
//				String prefix = getParameter("PREFIX");
//				String code = getParameter("OPERATOR_CODE");
//
//				int length = prefix.length();
//				String operatorCode = originalDestination.substring(prefix.length(), prefix.length() + code.length());
//				logger.info("### Operator code is ###" + operatorCode);
//				if (operatorCode.equals(code)) {
//					beepCallDto.setIsAirtel("1");
//					beepCallDto.setOperatorCode(code);
//					logger.info("### Original Origination number ###" + beepCallDto.getOperatorCode());
//
//				}
//
//			}
//		}
//
//		catch (Exception e) {
//			logger.info("### Exception occurs ###" + e);
//		}
//	}

	public BeepCallDto saveCallLog(BeepCallDto beepCallDto) {
		try {

			BeepCall beepCall = convertDtoToEntity(beepCallDto);
			// ArrayList<BeepCall> callLog = new ArrayList<BeepCall>();
			// callLog.add(beepCallRepository.save(beepCall));
			beepCallRepository.save(beepCall);
			beepCallDto = convertEntityToDto(beepCall);

		}

		catch (Exception e) {
			logger.info("Exception", e);
		}
		return beepCallDto;
	}

	public BeepCallDto saveDailyCallLog(BeepCallDto beepCallDto) {
		try {

			DailyCallLog dailyCallLog = convertDtoToEntityDaily(beepCallDto);
			dailyCallLogRepository.save(dailyCallLog);
			logger.info("### Daily SaveCallLog is ###" + dailyCallLog.toString());
			beepCallDto = convertEntityToDtoDaily(dailyCallLog);

		}

		catch (Exception e) {
			logger.info("Exception", e);
		}
		return beepCallDto;
	}

	public synchronized void makeCallLogs(BeepCallDto beepCallDto) {
		try {
			globalParams.getFileLogWriter().writeLog(beepCallDto.toString());
		} catch (Exception e) {
			logger.info("Exception", e);
		}
	}

	public List<LbsTemplate> getTemplates() {
		// TODO Auto-generated method stub
		List<LbsTemplate> templateList = lbsRepository.findAll();
		logger.info("### Lbs Template loaded into Cache ###");
		return templateList;
	}

	public List<FailureReason> getReasons() {
		// TODO Auto-generated method stub
		List<FailureReason> reasonList = failureRepository.findAll();
		logger.info("### Failure Reasons loaded into Cache ###");
		logger.debug("### Failure Reasons loaded into Cache ###" + reasonList.toString());
		return reasonList;
	}

	String getTemplate(int templateId, int langId) {

		try {
			LbsTemplate lbsTemplate = cacheConfig.getCacheLoader().get(templateId + "-" + langId);

			if (lbsTemplate != null) {
				templateMessage = lbsTemplate.getTemplateMessage();
			}
		} catch (Exception e) {
			logger.info("Exception", e);
		}
		return templateMessage;
	}

	private BeepCall convertDtoToEntity(BeepCallDto beepCallDto) {
		BeepCall beepCall = modelMapper.map(beepCallDto, BeepCall.class);
		return beepCall;
	}

	private BeepCallDto convertEntityToDto(BeepCall beepCall) {
		BeepCallDto beepCallDto = modelMapper.map(beepCall, BeepCallDto.class);
		return beepCallDto;
	}

	private DailyCallLog convertDtoToEntityDaily(BeepCallDto beepCallDto) {
		DailyCallLog dailyCallLog = modelMapper.map(beepCallDto, DailyCallLog.class);
		return dailyCallLog;
	}

	private BeepCallDto convertEntityToDtoDaily(DailyCallLog dailyCallLog) {
		BeepCallDto beepCallDto = modelMapper.map(dailyCallLog, BeepCallDto.class);
		return beepCallDto;
	}

	public String getParameter(String param_name) {
		String paramValue = "-1";
		try {

			Params params = cacheConfig.getloadParams().get(param_name);

			logger.info(param_name);
			if (params != null) {
				paramValue = params.getParam_value();
			}

		} catch (Exception e) {
			logger.info("Exception", e);
		}
		return paramValue;
	}

}
