package com.telemune.beep.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.telemune.beep.entity.LbsTemplate;

@Repository
public interface lbsRepository extends JpaRepository<LbsTemplate, Integer> {

}
