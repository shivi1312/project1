package com.telemune.beep.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.DynamicInsert;

@Entity
@DynamicInsert
@Table(name = "failure_reason")
public class FailureReason {

	@Id
	@Column(name = "REASON_ID")
	private Integer reasonCode;
	
	@Column(name = "REASON_NAME" , unique=true)
	private String reasonName;
	
	@Column(name = "TEMPLATE_ID" , unique=true)
	private Integer tempId;
	
	
	@Column(name = "sms_send" , unique=true)
	private int sendSms;


	


	public String getReasonName() {
		return reasonName;
	}


	public void setReasonName(String reasonName) {
		this.reasonName = reasonName;
	}


	

	public int getSendSms() {
		return sendSms;
	}


	public void setSendSms(int sendSms) {
		this.sendSms = sendSms;
	}


	public Integer getReasonCode() {
		return reasonCode;
	}


	public void setReasonCode(Integer reasonCode) {
		this.reasonCode = reasonCode;
	}


	public Integer getTempId() {
		return tempId;
	}


	public void setTempId(Integer tempId) {
		this.tempId = tempId;
	}


	@Override
	public String toString() {
		return "FailureReason [reasonCode=" + reasonCode + ", reasonName=" + reasonName + ", tempId=" + tempId
				+ ", sendSms=" + sendSms + "]";
	}
	
	
	
	
}
