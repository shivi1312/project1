package com.telemune.beep.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.telemune.beep.dto.BeepCallDto;
import com.telemune.beep.dto.CallCheckDto;
import com.telemune.beep.entity.BeepCall;
import com.telemune.beep.entity.FailureReason;
import com.telemune.beep.entity.GmatMsg;
import com.telemune.beep.entity.LbsTemplate;


public interface BeepCallService {

//	@Async("taskExecutor")
	public CompletableFuture<BeepCallDto> processSaveCall(BeepCallDto beepCallDto);

	public BeepCallDto saveCallLog(BeepCallDto beepCallDto);

	List<LbsTemplate> getTemplates();
	public void getAllLbsTemplates();
	public void getAllParams();
	List<FailureReason> getReasons();
	
	public void getFailureReasons();
	//public void isFromOperator(BeepCallDto beepCallDto);

	public BeepCallDto saveDailyCallLog(BeepCallDto beepCallDto);
	


}
