package com.telemune.beep.config;

import java.util.HashMap;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.telemune.beep.entity.FailureReason;
import com.telemune.beep.entity.LbsTemplate;
import com.telemune.beep.entity.Params;


@Configuration
public class CacheConfig {

	HashMap<Integer, FailureReason> cacheFailureReasons = new HashMap<Integer, FailureReason>();
	HashMap<String, LbsTemplate> cacheLoader = new HashMap<String, LbsTemplate>();
	HashMap<String, Params> cacheLoadParams = new HashMap<String, Params>();
	@Bean
	public Map<String, LbsTemplate> getCacheLoader() {
		
		return cacheLoader;
	}
	
	@Bean
	public Map<String, Params> getloadParams() {
		
		return cacheLoadParams;
	}


	@Bean
	public HashMap<Integer, FailureReason> getFailureReason() {
		
		return cacheFailureReasons;
	}
	
	
	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}
	
}
