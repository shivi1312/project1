/**
 * 
 */
package com.telemune.beep.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.telemune.beep.entity.Params;



/**
 * @author kirti
 *
 */
@Repository
public interface ParamsRepository extends JpaRepository<Params, String> {

}
