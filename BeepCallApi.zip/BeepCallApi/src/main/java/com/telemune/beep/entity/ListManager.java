/**
 * 
 */
package com.telemune.beep.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.DynamicInsert;


/**
 * @author kirti sharma
 *
 */
@Entity
@DynamicInsert
@Table(name = "LIST_MANAGER")
public class ListManager {

	@Id
	@Size(max = 10)
	@Column(name = "LIST_ID")
	private Integer list_id;
	
	@NotNull
	@Size(max = 50)
	@Column(name = "LIST_NAME")
	private String list_name;
	
	@NotNull
	@Size(max = 50)
	@Column(name = "CREATE_DATE")
	private String date;
	
	@NotNull
	@Size(max = 50)
	@Column(name = "STATUS")
	private String status;
	
	 @OneToOne(mappedBy = "listManager", fetch = FetchType.LAZY)
	    private ListDetail listDetail;
	
	public ListDetail getListDetail() {
		return listDetail;
	}

	public void setListDetail(ListDetail listDetail) {
		this.listDetail = listDetail;
	}

	public Integer getList_id() {
		return list_id;
	}

	public String getList_name() {
		return list_name;
	}

	public String getDate() {
		return date;
	}

	public String getStatus() {
		return status;
	}

	public void setList_id(Integer list_id) {
		this.list_id = list_id;
	}

	public void setList_name(String list_name) {
		this.list_name = list_name;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
}
