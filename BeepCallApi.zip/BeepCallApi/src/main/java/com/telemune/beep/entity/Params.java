/**
 * 
 */
package com.telemune.beep.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.DynamicInsert;

/**
 * @author kirti sharma
 *
 */

@Entity
@DynamicInsert
@Table(name = "app_config_params")
public class Params {
	
	@Id
	@Size(max = 10)
	@Column(name = "PARAM_ID")
	private String param_id;
	
	
	@NotNull
	@Size(max = 50)
	@Column(name = "PARAM_NAME" , unique=true)
	private String param_name;

	@NotNull
	@Size(max = 100)
	@Column(name = "PARAM_VALUE")
	private String param_value;
	
	@Size(max = 100)
	@Column(name = "PARAM_TYPE")
	private String param_type;
	
	@Size(max = 100)
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Size(max = 30)
	@Column(name = "SERVICE_NAME")
	private String service_name;

	

	public String getParam_id() {
		return param_id;
	}

	public void setParam_id(String param_id) {
		this.param_id = param_id;
	}

	
	public String getParam_value() {
		return param_value;
	}

	public String getParam_type() {
		return param_type;
	}

	public String getDescription() {
		return description;
	}

	public String getService_name() {
		return service_name;
	}

	
	
	public String getParam_name() {
		return param_name;
	}

	public void setParam_name(String param_name) {
		this.param_name = param_name;
	}

	public void setParam_value(String param_value) {
		this.param_value = param_value;
	}

	public void setParam_type(String param_type) {
		this.param_type = param_type;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setService_name(String service_name) {
		this.service_name = service_name;
	}
	
	
	
}
