/**
 * 
 */
package com.telemune.beep.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.telemune.beep.dto.CallCheckDto;
import com.telemune.beep.entity.DailyCallLog;
import com.telemune.beep.entity.ListDetail;

/**
 * @author kirti
 *
 */
@Repository
public interface DailyCallLogRepository extends JpaRepository<DailyCallLog, String> {

	/**
	 * @param origin
	 * @return
	 */
	@Query(value="select count(*) from daily_call_log where ORIGINATING_NUM = :origin", nativeQuery = true)
    int findByOriginNumber(String origin);

	/**
	 * @param dest
	 * @return
	 */
	@Query(value="select count(*) from daily_call_log where DESTINATION_NUM = :dest", nativeQuery = true)
	int findByDestNumber(String dest);

	@Query(value="select TIMESTAMPDIFF(MINUTE,IFNULL(MAX(CALL_TIME), now()- interval 1 year),now()) from daily_call_log where ORIGINATING_NUM = :origin", nativeQuery = true)
	int findByOriginTimeLimit(String origin);
	
	@Query(value="select TIMESTAMPDIFF(MINUTE, IFNULL(MAX(CALL_TIME), now()- interval 1 year), now()) from daily_call_log where DESTINATION_NUM = :dest", nativeQuery = true)
	int findByDestTimeLimit(String dest);
}
