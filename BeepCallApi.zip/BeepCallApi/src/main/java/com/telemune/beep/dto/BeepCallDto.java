package com.telemune.beep.dto;

import java.io.Serializable;

import org.springframework.scheduling.annotation.EnableAsync;

import com.fasterxml.jackson.annotation.JsonIgnoreType;
import com.fasterxml.jackson.annotation.JsonView;


public class BeepCallDto implements Serializable{

	
	private String Id;

	private Integer server_id;

	@JsonView
	private String origination;
	@JsonView
	private String destination;
	
	private String calltime;
	@JsonView
	private String start_time;
	@JsonView
	private String start_date;

	private String notificationInterface;
	@JsonView
	private Integer sendNotificationtoAParty;
	@JsonView
	private Integer sendSMStoBParty;

	private Integer sms_enable;
	@JsonView
	private int beepCallSuccess;
	@JsonView
	private String originalDestination;
	@JsonView
	private String inter;
	@JsonView
	private String operatorCode;
	@JsonView
	private Integer isAirtel = 0;
	
	private Integer callAllowed;
	
	@JsonView
	private String aPartyConsent;
	@JsonView
	private String gstn = "NA";
	
	private String origBlackList;
	
	private String destBlackList;
	private String limitOverAParty;
	private String limitOverBParty;
	
	private int beepCallFailureReasonCode = 0;
	
	

	public int getBeepCallFailureReasonCode() {
		return beepCallFailureReasonCode;
	}

	public void setBeepCallFailureReasonCode(int beepCallFailureReasonCode) {
		this.beepCallFailureReasonCode = beepCallFailureReasonCode;
	}

	public String getGstn() {
		return gstn;
	}

	public void setGstn(String gstn) {
		this.gstn = gstn;
	}

	public String getId() {
		return Id;
	}

	public Integer getServer_id() {
		return server_id;
	}

	public String getOrigination() {
		return origination;
	}

	public String getDestination() {
		return destination;
	}

	public String getCalltime() {
		return calltime;
	}

	public String getNotificationInterface() {
		return notificationInterface;
	}

	public Integer getSendNotificationtoAParty() {
		return sendNotificationtoAParty;
	}

	public Integer getSendSMStoBParty() {
		return sendSMStoBParty;
	}

	public Integer getSms_enable() {
		return sms_enable;
	}

	

	public int getBeepCallSuccess() {
		return beepCallSuccess;
	}

	public void setBeepCallSuccess(int beepCallSuccess) {
		this.beepCallSuccess = beepCallSuccess;
	}

	public String getOriginalDestination() {
		return originalDestination;
	}

	public String getInter() {
		return inter;
	}

	public String getOperatorCode() {
		return operatorCode;
	}



	public void setId(String id) {
		Id = id;
	}

	public void setServer_id(Integer server_id) {
		this.server_id = server_id;
	}

	public void setOrigination(String origination) {
		this.origination = origination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public void setCalltime(String calltime) {
		this.calltime = calltime;
	}

	public void setNotificationInterface(String notificationInterface) {
		this.notificationInterface = notificationInterface;
	}

	public void setSendNotificationtoAParty(Integer sendNotificationtoAParty) {
		this.sendNotificationtoAParty = sendNotificationtoAParty;
	}

	public void setSendSMStoBParty(Integer sendSMStoBParty) {
		this.sendSMStoBParty = sendSMStoBParty;
	}

	public void setSms_enable(Integer sms_enable) {
		this.sms_enable = sms_enable;
	}



	public void setOriginalDestination(String originalDestination) {
		this.originalDestination = originalDestination;
	}

	public void setInter(String inter) {
		this.inter = inter;
	}

	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}

	

	public String getStart_time() {
		return start_time;
	}

	public String getStart_date() {
		return start_date;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	
	
	public String getaPartyConsent() {
		return aPartyConsent;
	}

	public void setaPartyConsent(String aPartyConsent) {
		this.aPartyConsent = aPartyConsent;
	}

	public String getOrigBlackList() {
		return origBlackList;
	}

	public String getDestBlackList() {
		return destBlackList;
	}

	public String getLimitOverAParty() {
		return limitOverAParty;
	}

	public String getLimitOverBParty() {
		return limitOverBParty;
	}

	public void setOrigBlackList(String origBlackList) {
		this.origBlackList = origBlackList;
	}

	public void setDestBlackList(String destBlackList) {
		this.destBlackList = destBlackList;
	}

	public void setLimitOverAParty(String limitOverAParty) {
		this.limitOverAParty = limitOverAParty;
	}

	public void setLimitOverBParty(String limitOverBParty) {
		this.limitOverBParty = limitOverBParty;
	}
	

	public Integer getCallAllowed() {
		return callAllowed;
	}

	public void setCallAllowed(Integer callAllowed) {
		this.callAllowed = callAllowed;
	}
	
	public Integer getIsAirtel() {
		return isAirtel;
	}

	public void setIsAirtel(Integer isAirtel) {
		this.isAirtel = isAirtel;
	}

	
	

	public String toCdr() {
		return origination + "," + originalDestination+ ","+ destination + "," + start_date
				+ "," + start_time + "," + inter + "," + operatorCode + ","
				+ isAirtel + "," + beepCallSuccess + "," + sendSMStoBParty
				+"," + sendNotificationtoAParty + "," + aPartyConsent + "," + gstn;
	}

	@Override
	public String toString() {
		return  Id + "," + server_id + "," + origination + ","
				+ destination + "," + calltime + "," + start_time + "," + start_date
				+ "," + notificationInterface + ","
				+ sendNotificationtoAParty + "," + sendSMStoBParty + "," + sms_enable
				+ "," + beepCallSuccess + "," + originalDestination + ","
				+ inter + "," + operatorCode + "," + isAirtel + "," + callAllowed
				+ "," + aPartyConsent + "," + gstn + "," + origBlackList
				+ "," + destBlackList + "," + limitOverAParty + ","
				+ limitOverBParty ;
	}

	
		
}
