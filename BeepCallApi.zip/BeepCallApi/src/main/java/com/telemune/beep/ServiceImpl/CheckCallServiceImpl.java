/**
 * 
 */
package com.telemune.beep.ServiceImpl;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.telemune.beep.common.Constants;
import com.telemune.beep.config.CacheConfig;
import com.telemune.beep.dto.BeepCallDto;
import com.telemune.beep.dto.CallCheckDto;

import com.telemune.beep.entity.DailyCallLog;
import com.telemune.beep.entity.LbsTemplate;
import com.telemune.beep.entity.Params;

import com.telemune.beep.repo.DailyCallLogRepository;
import com.telemune.beep.repo.ListDetailRepository;
import com.telemune.beep.repo.ParamsRepository;
import com.telemune.beep.service.BeepCallService;
import com.telemune.beep.service.CheckCallService;

/**
 * @author kirti
 *
 */
@Service
public class CheckCallServiceImpl implements CheckCallService {

	@Autowired
	private CacheConfig cacheConfig;

	@Autowired
	private ParamsRepository paramsRepository;

	@Autowired
	private DailyCallLogRepository dailyCallLogRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private ListDetailRepository listDetailRepository;

	
	
	String number;
	String origin;

	private static final Logger logger = LogManager.getLogger(CheckCallServiceImpl.class);

	public int processCheckCall(CallCheckDto callCheckDto) {

		try {
			logger.info("INSIDE PROCESS CHECK CALL>>>>>>>>>>>>>");
			if (callCheckDto != null) {
				callCheckDto.setCallAllowed(0);
				if(!parseDestinationToInternationalNo(callCheckDto))
					{
					 return 0;
					}
				
				parseOriginationToInternationalNo(callCheckDto);
				
				if (getParameter("SYSTEM_WHITELIST_ENABLE").equals("1")) {
					logger.info("SYSTEM_WHITELIST_ENABLED>>>>>>>>>>>>>");
					if (getWhitelist(callCheckDto)) {
						return 1;
					} else {
						return 0;
					}
				} else {
					if (getBlacklist(callCheckDto)) {

						
						
						int timeLimitOk = getCheckTimeLimit(callCheckDto);
						
						if (timeLimitOk == -1) {
							callCheckDto.setLimitOverAParty(1);
							callCheckDto.setCallAllowed(0);
							
							return 0;
						}
						if (timeLimitOk == -2) {
							callCheckDto.setLimitOverBParty(1);
							callCheckDto.setCallAllowed(0);
							return 0;
						}
						callCheckDto.setCallAllowed(1);
						
						if (callCheckDto.getCallAllowed()==1)
						{
							int limitOk = getCheckLimit(callCheckDto);
							if (limitOk == -1) {
								callCheckDto.setLimitOverAParty(1);
								callCheckDto.setCallAllowed(0);
								
								return 0;
							}
							if (limitOk == -2) {
								callCheckDto.setLimitOverBParty(1);
								callCheckDto.setCallAllowed(0);
								return 0;
							}
							callCheckDto.setCallAllowed(1);
						}	
						
					} else {
						callCheckDto.setCallAllowed(0);
						return 0;
					}
					
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return 1;

	}

	public List<Params> getParams() {
		// TODO Auto-generated method stub

		List<Params> paramsList = paramsRepository.findAll();

		logger.info("### App Config Params loaded into Cache ###"+ paramsList);
	

		return paramsList;
	}

	public String getParameter(String param_name) {
		String paramValue = "-1";
		try {

			Params params = cacheConfig.getloadParams().get(param_name);

			
			if (params != null) {
				paramValue = params.getParam_value();
			}
			logger.debug(param_name + paramValue);
		} catch (Exception e) {
			logger.info("Exception", e);
		}
		return paramValue;
	}

	public boolean parseDestinationToInternationalNo(CallCheckDto callCheckDto) {
		try {
			logger.debug("Parsing Destination to International"+callCheckDto);
			String originalDestination = callCheckDto.getOriginalDestination();

			String prefix = getParameter("PREFIX");
			String msisdn =originalDestination;
			String	destNumber = "";
			//originalDestination.substring(prefix.length());
			String countryCode = getParameter("COUNTRY_CODE");
			callCheckDto.setOperatorCode("NA");
			if(callCheckDto.getInter().equalsIgnoreCase("I"))
			{
				
				if (originalDestination.startsWith(prefix)) {
					msisdn = originalDestination.substring(prefix.length());
					
					if (msisdn.startsWith("00")) {
						msisdn = countryCode + msisdn.substring(2);
						callCheckDto.setDestination(msisdn);
		            }
					else if (msisdn.startsWith("0") || msisdn.startsWith("+")) {
						msisdn = countryCode + msisdn.substring(1);
		            	callCheckDto.setDestination(msisdn);
		            }
					
					
				}
				else {
					callCheckDto.setBeepCallFailureReasonCode(Constants.destNotValid);
				}
			}
			else
			{
			String code = getParameter("OPERATOR_CODE");
			

			String operatorCode = originalDestination.substring(prefix.length(), prefix.length() + code.length());

			
			if (operatorCode.startsWith(code.substring(0,1)))
			{
			callCheckDto.setOperatorCode(operatorCode);
			
		
			}
			if (originalDestination.startsWith(prefix)) {
				destNumber = originalDestination.substring(prefix.length());	
				
				if (destNumber.startsWith("D") ) {
					msisdn = destNumber.substring(code.length());
			
			    	 if(destNumber.startsWith(code))
			    	 {
			    		 callCheckDto.setIsAirtel(1);
			    	 }
			    	 else
			    	 {
			    		 callCheckDto.setIsAirtel(0);
			    	 }
			     
			   }
				else if (destNumber.startsWith("000") ) {
					msisdn = destNumber.substring(code.length());
			
					 callCheckDto.setIsAirtel(0);
					 callCheckDto.setDestination(msisdn);
					 callCheckDto.setCallAllowed(0);
					 return false;
				}
			}	
		  }
				
			if(msisdn.startsWith(getParameter("COUNTRY_CODE")) && msisdn.length() == Integer.parseInt(getParameter("TOTAL_MSISDN_LENGTH")))
			{

			}
			else if(msisdn.length()==Integer.parseInt(getParameter("TOTAL_MSISDN_LENGTH"))-getParameter("COUNTRY_CODE").length())
					{
						msisdn = getParameter("COUNTRY_CODE") + msisdn;
					
						callCheckDto.setDestination(msisdn);
					}
			else
			{
				callCheckDto.setCallAllowed(0);
				callCheckDto.setDestination(msisdn);
				
		
				callCheckDto.setBeepCallFailureReasonCode(Constants.destNotValid);
				return false;
				
			}
			
			
			callCheckDto.setDestination(msisdn);
		
			
		
		}
		catch (Exception e) {
			logger.info("Exception", e);
			return false;
		}
		return true;
	}

	

	public void parseOriginationToInternationalNo(CallCheckDto callCheckDto) {
		try {
			
			String origination = callCheckDto.getOrigination();
			String countryCode = getParameter("COUNTRY_CODE");
            String original= "NA";
			
			if (origination.startsWith("00")) {
				original = countryCode + origination.substring(2);
				callCheckDto.setOrigination(original);
				
            }
			else if (origination.startsWith("0") || origination.startsWith("+")) {
            	original = countryCode + origination.substring(1);
            	callCheckDto.setOrigination(original);
            }
            
            else if (origination.startsWith(countryCode)) {
				callCheckDto.setOrigination(origination);
			} 
			
			else if(!origination.startsWith(countryCode) || origination.length()==Integer.parseInt(getParameter("TOTAL_MSISDN_LENGTH"))-getParameter("COUNTRY_CODE").length())
			{
				callCheckDto.setOrigination(countryCode + origination);
			}	
			
		} catch (Exception e) {
			logger.info("Exception", e);
		}

	}

	
	@Override
	public boolean getBlacklist(CallCheckDto callCheckDto) {
		try {
			logger.debug("Inside getBlackList"+callCheckDto);

			Optional<String> checkOrigination = listDetailRepository.findByOriginNumberBlacklist(Integer.parseInt(getParameter("SYSTEM_BLACKLIST_ID")),callCheckDto.getOrigination());
			Optional<String> checkDestination = listDetailRepository.findByDestNumberBlacklist(Integer.parseInt(getParameter("SYSTEM_BLACKLIST_ID")),callCheckDto.getDestination());
		
			
			if (checkOrigination.isPresent()) {
				
				callCheckDto.setOrigBlackList(1);
				callCheckDto.setBeepCallFailureReasonCode(Constants.originBlacklist);
				
				return false;
			}
			if (checkDestination.isPresent()) {
				callCheckDto.setDestBlackList(1);
				
				callCheckDto.setBeepCallFailureReasonCode(Constants.destBlacklist);
				return false;
			}
			logger.debug("Exit from getBlackList() method ");
		} catch (Exception e) {
			logger.info("Exception", e);
		}
		return true;
	}

	
	@Override
	public boolean getWhitelist(CallCheckDto callCheckDto) {
		logger.debug("Inside getWhitelist"+callCheckDto.toString());
		try {
			Optional<CallCheckDto> checkOrigination = listDetailRepository.findByOriginNumberWhitelist(Integer.parseInt(getParameter("SYSTEM_WHITELIST_ID")),callCheckDto.getOrigination());
			Optional<CallCheckDto> checkDestination = listDetailRepository.findByDestNumberWhitelist(Integer.parseInt(getParameter("SYSTEM_WHITELIST_ID")),callCheckDto.getDestination());

			if (checkOrigination.isPresent() || checkDestination.isPresent()) {
				callCheckDto.setWhiteList(1);
				callCheckDto.setCallAllowed(1);
			}
			else
			{
				callCheckDto.setWhiteList(0);
				callCheckDto.setCallAllowed(0);
			}
			logger.debug("Exit from getWhitelist() method ");
		}

		catch (Exception e) {
			logger.info("Exception", e);
		}
		return true;
	}
	
	
	@Override
	public int getCheckLimit(CallCheckDto callCheckDto) {
		try {
			logger.info("Inside getCheckLimit"+callCheckDto);
			
			  parseOriginationToInternationalNo(callCheckDto);
			  String origin = callCheckDto.getOrigination();
			  
			  parseDestinationToInternationalNo(callCheckDto);
			  String dest = callCheckDto.getDestination();
			
	
			
			int origincount = dailyCallLogRepository.findByOriginNumber(origin);
			int destcount = dailyCallLogRepository.findByDestNumber(dest);
		
		
		
			if (origincount >= Integer.parseInt(getParameter("ORIGINATION_NUMBER_DAILY_LIMIT"))) {
				callCheckDto.setBeepCallFailureReasonCode(Constants.dailyLimitOverAParty);
				return -1;
				
			}
			if (destcount >= Integer.parseInt(getParameter("DESTINATION_NUMBER_DAILY_LIMIT"))) {
				callCheckDto.setBeepCallFailureReasonCode(Constants.dailyLimitOverBParty);
				return -2;
			}
		} catch (Exception e) {
			logger.info("Exception", e);
		}
		return 1;

	}
	
	
	@Override
	public int getCheckTimeLimit(CallCheckDto callCheckDto) {
		try {
			logger.info("Inside getCheckLimit"+callCheckDto);
			
			  parseOriginationToInternationalNo(callCheckDto);
			  String origin = callCheckDto.getOrigination();
			  
			  parseDestinationToInternationalNo(callCheckDto);
			  String dest = callCheckDto.getDestination();
			
	
			
			int origincount = dailyCallLogRepository.findByOriginTimeLimit(origin);
			int destcount = dailyCallLogRepository.findByDestTimeLimit(dest);
		
		
		
			if (origincount < Integer.parseInt(getParameter("ORIGINATION_NUMBER_TIME_LIMIT"))) {
				callCheckDto.setBeepCallFailureReasonCode(Constants.timeLimitOverAParty);
				return -1;
				
			}
			if (destcount < Integer.parseInt(getParameter("DESTINATION_NUMBER_TIME_LIMIT"))) {
				callCheckDto.setBeepCallFailureReasonCode(Constants.timeLimitOverBParty);
				return -2;
			}
		} catch (Exception e) {
			logger.info("Exception", e);
		}
		return 1;

	}

	

	
	
	
	
	/*
	 * private DailyCallLog convertDtoToEntity(CallCheckDto callCheckDto) {
	 * DailyCallLog dailyCallLog = modelMapper.map(callCheckDto,
	 * DailyCallLog.class); return dailyCallLog; }
	 * 
	 * private CallCheckDto convertEntityToDto(DailyCallLog dailyCallLog) {
	 * CallCheckDto callCheckDto = modelMapper.map(dailyCallLog,
	 * CallCheckDto.class); return callCheckDto; }
	 */
}
