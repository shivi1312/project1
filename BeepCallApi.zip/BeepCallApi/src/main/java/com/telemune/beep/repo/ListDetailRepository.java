/**
 * 
 */
package com.telemune.beep.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.telemune.beep.dto.CallCheckDto;
import com.telemune.beep.entity.ListDetail;

/**
 * @author kirti
 *
 */
@Repository
public interface ListDetailRepository extends JpaRepository<ListDetail, Integer> {

	/**
	 * @param msisdn
	 * @return
	 */
//	@Query(value="select MSISDN from list_detail ld inner join list_manager lm where lm.LIST_ID = ld.LIST_ID and lm.LIST_NAME = 'BLACKLIST' and lm.STATUS = 'A' and ld.msisdn = :origin", nativeQuery = true)
//	//List<Services> findServiceByid(Long id);
//	Optional<CallCheckDto> findByOriginNumberBlacklist(String origin);
//	
//	
//	@Query(value="select MSISDN from list_detail ld inner join list_manager lm where lm.LIST_ID = ld.LIST_ID and lm.LIST_NAME = 'BLACKLIST' and lm.STATUS = 'A' and ld.msisdn = :dest", nativeQuery = true)
//	//List<Services> findServiceByid(Long id);
//	Optional<CallCheckDto> findByDestNumberBlacklist(String dest);
	
	
	@Query(value="select MSISDN from list_detail ld where ld.LIST_ID = :list_id and ld.msisdn = :origin", nativeQuery = true)
	Optional<String> findByOriginNumberBlacklist(int list_id,String origin);
	
	
	@Query(value="select MSISDN from list_detail ld where ld.LIST_ID = :list_id and ld.msisdn = :dest", nativeQuery = true)
	Optional<String> findByDestNumberBlacklist(int list_id,String dest);
	
	@Query(value="select MSISDN from list_detail ld where ld.LIST_ID = :list_id and ld.msisdn = :origin", nativeQuery = true)
	Optional<CallCheckDto> findByOriginNumberWhitelist(int list_id,String origin);
	
	
	@Query(value="select MSISDN from list_detail ld where ld.LIST_ID = :list_id and ld.msisdn = :dest", nativeQuery = true)
	Optional<CallCheckDto> findByDestNumberWhitelist(int list_id,String dest);
	
	
	
}
