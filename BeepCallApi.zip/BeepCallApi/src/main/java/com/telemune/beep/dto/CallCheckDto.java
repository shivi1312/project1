/**
 * 
 */
package com.telemune.beep.dto;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
/**
 * @author kirti
 *
 */

@XmlRootElement(name = "callData")
@XmlAccessorType(XmlAccessType.NONE)
public class CallCheckDto implements Serializable{

	@XmlElement
	private String origination;
	@XmlElement

	private String originalDestination;
	@XmlElement
	private String destination;
	@XmlElement
	private String calltime;
	@XmlElement
	private String inter;
	@XmlElement
	private Integer whiteList = 0;
	@XmlElement
	private Integer origBlackList = -1;
	@XmlElement
	private Integer destBlackList = -1;
	@XmlElement
	private Integer limitOverAParty = -1;
	@XmlElement
	private Integer limitOverBParty = -1;
	@XmlElement
	private Integer callAllowed = 0;
	@XmlElement
	private String operatorCode;
	@XmlElement
	private int isAirtel=-1;
	
	@XmlElement
	private int beepCallFailureReasonCode = 0;
	
	
	
	
	
	
	public int getIsAirtel() {
		return isAirtel;
	}

	public void setIsAirtel(int isAirtel) {
		this.isAirtel = isAirtel;
	}

	public String getOperatorCode() {
		return operatorCode;
	}

	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}

	public Integer getCallAllowed() {
		return callAllowed;
	}

	public void setCallAllowed(Integer callAllowed) {
		this.callAllowed = callAllowed;
	}

	public Integer getWhiteList() {
		return whiteList;
	}
	
	public void setWhiteList(Integer whiteList) {
		this.whiteList = whiteList;
	}
	
	public String getOrigination() {
		return origination;
	}
	public String getOriginalDestination() {
		return originalDestination;
	}
	public String getCalltime() {
		return calltime;
	}
	public String getInter() {
		return inter;
	}
	public void setOrigination(String origination) {
		this.origination = origination;
	}
	public void setOriginalDestination(String originalDestination) {
		this.originalDestination = originalDestination;
	}
	public void setCalltime(String calltime) {
		this.calltime = calltime;
	}
	public void setInter(String inter) {
		this.inter = inter;
	}
	public Integer getLimitOverAParty() {
		return limitOverAParty;
	}
	public Integer getLimitOverBParty() {
		return limitOverBParty;
	}
	public void setLimitOverAParty(Integer limitOverAParty) {
		this.limitOverAParty = limitOverAParty;
	}
	public void setLimitOverBParty(Integer limitOverBParty) {
		this.limitOverBParty = limitOverBParty;
	}


	public Integer getOrigBlackList() {
		return origBlackList;
	}


	public Integer getDestBlackList() {
		return destBlackList;
	}


	public void setOrigBlackList(Integer origBlackList) {
		this.origBlackList = origBlackList;
	}


	public void setDestBlackList(Integer destBlackList) {
		this.destBlackList = destBlackList;
	}
	
	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	
	public int getBeepCallFailureReasonCode() {
		return beepCallFailureReasonCode;
	}

	public void setBeepCallFailureReasonCode(int beepCallFailureReasonCode) {
		this.beepCallFailureReasonCode = beepCallFailureReasonCode;
	}

	@Override
	public String toString() {
		return "CallCheckDto [origination=" + origination + ", originalDestination=" + originalDestination
				+ ", destination=" + destination + ", calltime=" + calltime + ", inter=" + inter + ", whiteList="
				+ whiteList + ", origBlackList=" + origBlackList + ", destBlackList=" + destBlackList
				+ ", limitOverAParty=" + limitOverAParty + ", limitOverBParty=" + limitOverBParty + ", callAllowed="
				+ callAllowed + ", operatorCode=" + operatorCode + ", isAirtel=" + isAirtel
				+ ", beepCallFailureReasonCode=" + beepCallFailureReasonCode + "]";
	}


	
}
