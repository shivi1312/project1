/**
 * 
 */
package com.telemune.beep.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.telemune.beep.entity.ListManager;

/**
 * @author kirti
 *
 */
@Repository
public interface ListManagerRepository extends JpaRepository<ListManager, Integer>{

}
