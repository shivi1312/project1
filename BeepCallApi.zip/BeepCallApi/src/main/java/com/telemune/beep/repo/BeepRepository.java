package com.telemune.beep.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.telemune.beep.entity.BeepCall;
import com.telemune.beep.entity.GmatMsg;


@Repository
public interface BeepRepository extends JpaRepository<BeepCall, Integer> {


}
