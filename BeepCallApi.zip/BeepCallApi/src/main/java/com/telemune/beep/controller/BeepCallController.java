package com.telemune.beep.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.beep.ServiceImpl.BeepCallServiceImpl;
import com.telemune.beep.common.Constants;
import com.telemune.beep.common.Response;
import com.telemune.beep.config.*;
import com.telemune.beep.dto.BeepCallDto;
import com.telemune.beep.dto.CallCheckDto;
import com.telemune.beep.entity.BeepCall;
import com.telemune.beep.entity.LbsTemplate;

import com.telemune.beep.service.BeepCallService;

import org.modelmapper.ModelMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
@RestController
public class BeepCallController {
	
	
	
	
	@Autowired
	private Environment environment;

	@Autowired
	BeepCallService beepCallServiceImpl;

	@Autowired
	private ModelMapper modelMapper;

	private static final Logger logger = LogManager.getLogger(BeepCallController.class);

	@GetMapping("/call")
	public Response getAllCallLog(@RequestParam("callUUID") String callUUID, @RequestParam("callingnum") String origin,
			@RequestParam("callednum") String destination, @RequestParam("callTime") String callTime,
			@RequestParam("notificationInterface") String notificationInterface,
			@RequestParam("sendNotificationtoAParty") Integer sendNotificationtoAParty,
			@RequestParam("sendSMStoBParty") Integer sendSMStoBParty, @RequestParam("sms_enable") Integer sms_enable,
			@RequestParam("beepCallSuccess") Integer beepCallSuccess, @RequestParam("serverId") Integer server_id,
			@RequestParam("originalDestination") String originalDestination, @RequestParam("interface") String inter,@RequestParam("APartyConsent") String aPartyConsent, @RequestParam("gstn") String gstn
			,@RequestParam("origBlackList") String origBlackList,@RequestParam("destBlackList") String destBlackList,
			@RequestParam("limitOverAParty") String limitOverAParty,@RequestParam("limitOverBParty") String limitOverBParty,@RequestParam("callAllowed") Integer callAllowed,@RequestParam("operatorCode") String operatorCode,@RequestParam("isAirtel") Integer isAirtel,@RequestParam("beepCallFailureReasonCode") Integer beepCallFailureReasonCode) 
	{

		try {
			logger.info("### inside getAllCallLog() method of BeepController class ###");
			BeepCallDto beepCallDto = new BeepCallDto();
			beepCallDto.setId(callUUID);
			beepCallDto.setOrigination(origin);
			beepCallDto.setDestination(destination);
			beepCallDto.setCalltime(callTime);
			beepCallDto.setNotificationInterface(notificationInterface);
			beepCallDto.setSendNotificationtoAParty(sendNotificationtoAParty);
			beepCallDto.setSendSMStoBParty(sendSMStoBParty);
			beepCallDto.setSms_enable(sms_enable);
			beepCallDto.setBeepCallSuccess(beepCallSuccess);
			beepCallDto.setServer_id(server_id);
			beepCallDto.setOriginalDestination(originalDestination);
			beepCallDto.setInter(inter);
			beepCallDto.setaPartyConsent(aPartyConsent);
			beepCallDto.setOrigBlackList(origBlackList);
			beepCallDto.setDestBlackList(destBlackList);
			beepCallDto.setLimitOverAParty(limitOverAParty);
			beepCallDto.setLimitOverBParty(limitOverBParty);
			beepCallDto.setGstn(gstn);
			beepCallDto.setCallAllowed(callAllowed);
			beepCallDto.setOperatorCode(operatorCode);
			beepCallDto.setIsAirtel(isAirtel);
			beepCallDto.setBeepCallFailureReasonCode(beepCallFailureReasonCode);
			logger.debug("### inside getAllCallLog() method of BeepController class ###"+beepCallDto.toString());

			String call_time = beepCallDto.getCalltime();
			String startDate = call_time.substring(0, 10);
			String startTime = call_time.substring(11, 16);

			beepCallDto.setStart_time(startDate);
			beepCallDto.setStart_date(startTime);

			logger.debug("### start_date and start_time ###" + startDate);
			logger.debug("### start_date and start_time ###" + startTime);

			beepCallServiceImpl.saveCallLog(beepCallDto);
			
			
			

			return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new ArrayList<>(), " ",
					Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);
		}

		catch (Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

		}

	}

	@GetMapping("save/call")
	public Response saveCall(@RequestParam("callUUID") String callUUID, @RequestParam("callingnum") String origin,
			@RequestParam("callednum") String destination, @RequestParam("callTime") String callTime,
			@RequestParam("notificationInterface") String notificationInterface,
			@RequestParam("sendNotificationtoAParty") Integer sendNotificationtoAParty,
			@RequestParam("sendSMStoBParty") Integer sendSMStoBParty, @RequestParam("sms_enable") Integer sms_enable,
			@RequestParam("beepCallSuccess") Integer beepCallSuccess, @RequestParam("serverId") Integer server_id,
			@RequestParam("originalDestination") String originalDestination, @RequestParam("interface") String inter, @RequestParam("APartyConsent") String aPartyConsent, 
			@RequestParam("gstn") String gstn,@RequestParam("origBlackList") String origBlackList,@RequestParam("destBlackList") String destBlackList,
			@RequestParam("limitOverAParty") String limitOverAParty,@RequestParam("limitOverBParty") String limitOverBParty,@RequestParam("callAllowed") Integer callAllowed,@RequestParam("operatorCode") String operatorCode,@RequestParam("isAirtel") Integer isAirtel,@RequestParam("beepCallFailureReasonCode") Integer beepCallFailureReasonCode)
		{

		try {
			
			BeepCallDto beepCallDto = new BeepCallDto();
			beepCallDto.setId(callUUID);
			beepCallDto.setOrigination(origin);
			beepCallDto.setDestination(destination);
			beepCallDto.setCalltime(callTime);
			beepCallDto.setNotificationInterface(notificationInterface);
			beepCallDto.setSendNotificationtoAParty(sendNotificationtoAParty);
			beepCallDto.setSendSMStoBParty(sendSMStoBParty);
			beepCallDto.setSms_enable(sms_enable);
			beepCallDto.setBeepCallSuccess(beepCallSuccess);
			beepCallDto.setServer_id(server_id);
			beepCallDto.setOriginalDestination(originalDestination);
			beepCallDto.setInter(inter);
			beepCallDto.setaPartyConsent(aPartyConsent);
			beepCallDto.setGstn(gstn);
			beepCallDto.setOrigBlackList(origBlackList);
			beepCallDto.setDestBlackList(destBlackList);
			beepCallDto.setLimitOverAParty(limitOverAParty);
			beepCallDto.setLimitOverBParty(limitOverBParty);
			beepCallDto.setCallAllowed(callAllowed);
			beepCallDto.setOperatorCode(operatorCode);
			beepCallDto.setIsAirtel(isAirtel);
			beepCallDto.setBeepCallFailureReasonCode(beepCallFailureReasonCode);
			
			logger.info("### inside ProcessSaveCall() method of BeepController class ###"+beepCallDto.toString());
			String call_time = beepCallDto.getCalltime();
			String startDate = call_time.substring(0, 10);
			String startTime = call_time.substring(11, 19);

			beepCallDto.setStart_time(startTime);
			beepCallDto.setStart_date(startDate);
         
			logger.debug("### start_date and start_time ###" + startDate);
			logger.debug("### start_date and start_time ###" + startTime);
			
			beepCallServiceImpl.processSaveCall(beepCallDto);
			logger.info("### After ProcessSaveCall() method of BeepController class ###"+beepCallDto.toString());
			
			
			
			

			return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new ArrayList(), "",
					Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);

		} catch (Exception exception) {
			logger.error(exception.toString());
			return new Response(HttpStatus.BAD_REQUEST, Constants.HTTP_STATUS_CODE_BAD_REQUEST, new ArrayList<>(),
					exception.getMessage(), Constants.STATUS_FAILURE, Constants.STATUS_FAILURE_MESSAGE);

		}
	}
}
