package com.telemune.beep.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;

public class CdrDto {
	@JsonProperty("Calling Party")
	@JsonView
	private String origination;
	
	@JsonProperty("Raw Called Party")
	@JsonView
	private String originalDestination;
	
	@JsonProperty("Called Party")
	@JsonView
	private String destination;
	
	@JsonProperty("Call Date")
	@JsonView
	private String start_date;
	
	
	@JsonProperty("Call Time")
	@JsonView
	private String start_time;
	
	@JsonProperty("Call Type")
	@JsonView
	private String inter;
	
	@JsonProperty("Operator Id")
	@JsonView
	private String operatorCode;
	

	@JsonProperty("IsAirtel")
	@JsonView
	private Integer isAirtel = 0;
	
	@JsonProperty("Missed Call Bparty")
	@JsonView
	private Integer beepCallSuccess;
	
	@JsonProperty("Missed CallSms Bparty")
	@JsonView
	private Integer sendSMStoBParty;
	
	@JsonProperty("A Party Notification")
	@JsonView
	private Integer sendNotificationtoAParty;
	

	@JsonProperty("A Party Consent")
	@JsonView
	private String aPartyConsent;
	
	

	@JsonProperty("GSTN")
	@JsonView
	private String gstn = "NA";
	
	public String getOrigination() {
		return origination;
	}
	public void setOrigination(String origination) {
		this.origination = origination;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Integer getSendNotificationtoAParty() {
		return sendNotificationtoAParty;
	}
	public void setSendNotificationtoAParty(Integer sendNotificationtoAParty) {
		this.sendNotificationtoAParty = sendNotificationtoAParty;
	}
	public Integer getSendSMStoBParty() {
		return sendSMStoBParty;
	}
	public void setSendSMStoBParty(Integer sendSMStoBParty) {
		this.sendSMStoBParty = sendSMStoBParty;
	}
	public Integer getBeepCallSuccess() {
		return beepCallSuccess;
	}
	public void setBeepCallSuccess(Integer beepCallSuccess) {
		this.beepCallSuccess = beepCallSuccess;
	}
	public String getOriginalDestination() {
		return originalDestination;
	}
	public void setOriginalDestination(String originalDestination) {
		this.originalDestination = originalDestination;
	}
	
	public String getOperatorCode() {
		return operatorCode;
	}
	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}
	public Integer getIsAirtel() {
		return isAirtel;
	}
	public void setIsAirtel(Integer isAirtel) {
		this.isAirtel = isAirtel;
	}
	public String getaPartyConsent() {
		return aPartyConsent;
	}
	public void setaPartyConsent(String aPartyConsent) {
		this.aPartyConsent = aPartyConsent;
	}
	public String getGstn() {
		return gstn;
	}
	public void setGstn(String gstn) {
		this.gstn = gstn;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getStart_time() {
		return start_time;
	}
	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}
	public String getInter() {
		return inter;
	}
	public void setInter(String inter) {
		this.inter = inter;
	}
	
	
	@Override
	public String toString() {
		return "CdrDto [origination=" + origination + ", originalDestination=" + originalDestination + ", destination="
				+ destination + ", sendNotificationtoAParty=" + sendNotificationtoAParty + ", sendSMStoBParty="
				+ sendSMStoBParty + ", beepCallSuccess=" + beepCallSuccess + ", operatorCode=" + operatorCode
				+ ", isAirtel=" + isAirtel + ", aPartyConsent=" + aPartyConsent + ", gstn=" + gstn + "]";
	}
	
	
	
}
