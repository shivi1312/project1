 package com.telemune.beep.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.annotations.DynamicInsert;



@Entity
@DynamicInsert
@Table(name = "call_log")
public class BeepCall {


	@Id
	@Size(max = 120)
	@Column(name = "CALL_UUID")
	private String Id;

	
	
	@Column(name = "SERVER_ID")
	private Integer server_id;

	@NotBlank
	@Size(max = 120)
	@Column(name = "ORIGINATING_NUM")
	private String origination;
	
	

	@NotBlank
	@Size(max = 120)
	@Column(name = "DESTINATION_NUM")
	private String destination;

	
	
	@Column(name = "CALL_TIME")
	private String calltime;
	
   
	@Column(name = "NotificationInterface")
	private String notificationInterface;
	
	@Column(name = "sendNotificationtoAParty")
	private Integer sendNotificationtoAParty;
	
	@Column(name = "sendSMStoBParty")
	private Integer sendSMStoBParty;
	
	@Column(name = "sms_enable")
	private Integer sms_enable;
	
	@Column(name = "beepCallSuccess")
	private Integer beepCallSuccess;
	
	@Column(name = "originalDestination")
	private String originalDestination;
	
	
	@Column(name ="interface")
	private String inter;
	
	
	
	@Column(name = "operatorCode")
	private String operatorCode;
	
	@Column(name ="isAirtel")
	private String isAirtel; 

	
	
	public Integer getServer_id() {
		return server_id;
	}

	public void setServer_id(Integer server_id) {
		this.server_id = server_id;
	}
	public Integer getBeepCallSuccess() {
		return beepCallSuccess;
	}

	public void setBeepCallSuccess(Integer beepCallSuccess) {
		this.beepCallSuccess = beepCallSuccess;
	}

	public Integer getSms_enable() {
		return sms_enable;
	}

	public void setSms_enable(Integer sms_enable) {
		this.sms_enable = sms_enable;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getOrigination() {
		return origination;
	}

	public void setOrigination(String origination) {
		this.origination = origination;
	}

	

	public String getNotificationInterface() {
		return notificationInterface;
	}

	public void setNotificationInterface(String notificationInterface) {
		this.notificationInterface = notificationInterface;
	}

	public Integer getSendNotificationtoAParty() {
		return sendNotificationtoAParty;
	}

	public void setSendNotificationtoAParty(Integer sendNotificationtoAParty) {
		this.sendNotificationtoAParty = sendNotificationtoAParty;
	}

	public Integer getSendSMStoBParty() {
		return sendSMStoBParty;
	}

	public void setSendSMStoBParty(Integer sendSMStoBParty) {
		this.sendSMStoBParty = sendSMStoBParty;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	

	public String getCalltime() {
		return calltime;
	}

	public void setCalltime(String calltime) {
		this.calltime = calltime;
	}
	
	public String getOriginalDestination() {
		return originalDestination;
	}

	public String getInter() {
		return inter;
	}

	public String getOperatorCode() {
		return operatorCode;
	}

	
	public void setOriginalDestination(String originalDestination) {
		this.originalDestination = originalDestination;
	}

	public void setInter(String inter) {
		this.inter = inter;
	}

	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}

	


	

	public String getIsAirtel() {
		return isAirtel;
	}

	public void setIsAirtel(String isAirtel) {
		this.isAirtel = isAirtel;
	}

	@Override
	public String toString() {
	//	return "BeepCall [Id=" + Id + ", origination=" + origination + ", destination=" + destination + ", calltime="
			//	+ calltime + "]";
		return Id+","+origination+","+destination+","+calltime+","+notificationInterface+","+sendNotificationtoAParty+","+sendSMStoBParty+","+sms_enable+","+beepCallSuccess+','+originalDestination+','+inter+','+operatorCode+','+isAirtel;
	}

	


}
