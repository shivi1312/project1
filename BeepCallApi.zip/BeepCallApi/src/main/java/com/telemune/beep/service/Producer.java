package com.telemune.beep.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.telemune.beep.ServiceImpl.BeepCallServiceImpl;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;



@Service
public class Producer {
	

@Autowired
private Environment environment;

   // String topic = this.environment.getProperty("TOPIC");
   
//public final String topic = Topic;
    @Value("${app.kafka.producer.topic}")
    private String topic;
	@Autowired
	private KafkaTemplate<String,String> kafkaTemp;
	private static final Logger logger = LogManager.getLogger(Producer.class);
	public void publishToTopic(String message)
	{
		
		logger.info("Producer send the message Topic===="+topic+"---"+message);
		
		this.kafkaTemp.send(topic,message);
	}
	
}
