/**
 * 
 */
package com.telemune.beep.controller;

import java.util.ArrayList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.beep.ServiceImpl.BeepCallServiceImpl;
import com.telemune.beep.common.Constants;
import com.telemune.beep.common.Response;

import com.telemune.beep.service.BeepCallService;
import com.telemune.beep.service.CheckCallService;

/**
 * @author kirti
 *
 */
@RestController
public class CacheReloadController {
	private static final Logger logger = LogManager.getLogger(CacheReloadController.class);

	
	@Autowired
	BeepCallService beepCallServiceImpl;
	
	
	@Autowired
	CheckCallService checkCallService;
	
	
	@GetMapping("/cacheReload")
	public Response getAllCacheParameters()
	{
		try {
		beepCallServiceImpl.getAllLbsTemplates();
		beepCallServiceImpl.getAllParams();
		beepCallServiceImpl.getFailureReasons();
	}
		
		catch(Exception e)
		{
			logger.error(" Error in cache Reload controller"+e.getMessage());
			e.printStackTrace();
		}
		
		return new Response(HttpStatus.OK, Constants.HTTP_STATUS_CODE_SCCUESS, new ArrayList<>(), " ",
				Constants.STATUS_SUCCESS, Constants.STATUS_SUCCESS_MESSAGE);
	
}}
