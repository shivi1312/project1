package com.telemune.beep.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.annotations.DynamicInsert;

@Entity
@DynamicInsert
@Table(name = "lbs_templates")
public class LbsTemplate {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TEMPLATE_ID")
	private Integer templateId;

	@NotBlank
	@Size(max = 120)
	@Column(name = "TEMPLATE_TYPE")
	private String templateType;
	
	@NotBlank
	@Size(max = 240)
	@Column(name = "TEMPLATE_MESSAGE")
	private String templateMessage;

	@NotBlank
	@Size(max = 120)
	@Column(name = "TOKENS_ALLOWED")
	private String tokensAllowed;
	
	@NotBlank
	@Size(max = 120)
	@Column(name = "TEMPLATE_DESCRIPTION")
	private String description;
	

	
	@NotBlank
	@Size(max = 120)
	@Column(name = "LANGUAGE_ID")
	private String langId;
	
	@NotBlank
	@Size(max = 120)
	@Column(name = "TEMPLATE_NAME")
	private String templateName;

	public Integer getTemplateId() {
		return templateId;
	}

	public void setTemplateId(Integer templateId) {
		this.templateId = templateId;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public String getTemplateMessage() {
		return templateMessage;
	}

	public void setTemplateMessage(String templateMessage) {
		this.templateMessage = templateMessage;
	}

	public String getTokensAllowed() {
		return tokensAllowed;
	}

	public void setTokensAllowed(String tokensAllowed) {
		this.tokensAllowed = tokensAllowed;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLangId() {
		return langId;
	}

	public void setLangId(String langId) {
		this.langId = langId;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	@Override
	public String toString() {
		return "LbsTemplate [templateId=" + templateId + ", templateType=" + templateType + ", templateMessage="
				+ templateMessage + ", tokensAllowed=" + tokensAllowed + ", description=" + description + ", langId="
				+ langId + ", templateName=" + templateName + "]";
	}

	
		
}

	
	

	

