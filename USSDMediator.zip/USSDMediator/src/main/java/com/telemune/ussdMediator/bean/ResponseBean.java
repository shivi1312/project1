package com.telemune.ussdMediator.bean;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class ResponseBean {

	private String msisdn;
	private String result;
	private String errorCode;
	private String messageSent;
	private String validity;
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getMessageSent() {
		return messageSent;
	}
	public void setMessageSent(String messageSent) {
		this.messageSent = messageSent;
	}
	public String getValidity() {
		return validity;
	}
	public void setValidity(String validity) {
		this.validity = validity;
	}
	
	@Override
	public String toString() {
		return "ResponseBean [msisdn=" + msisdn + ", result=" + result + ", errorCode=" + errorCode + ", messageSent="
				+ messageSent + ", validity=" + validity + "]";
	}
	
}
