package com.telemune.ussdMediator.bean;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class UssdMessageStore {
public String requestId;
public String responseId;
public String originatingNumber;
public String destinationNumber;
public String messageText;
public String submitTime;
public String messageType;
public String language;
public String udh;
public String statusResport;
public String dataEncodingScheme;
public String protocolIdentifier;
public String priority;
public String chargingCode;
public String status;
public String validityPeriod;
public String messageId;
public String interfaceId;
public String interfaceType;
public String destinationPort;
public String campaignId;
public String smscId;
public String format;
public String optionalParam;
public String ussdOpcode;
public String sessionId;
public String validUser;
public String getSessionId() {
	return sessionId;
}
public void setSessionId(String sessionId) {
	this.sessionId = sessionId;
}
public String getValidUser() {
	return validUser;
}
public void setValidUser(String validUser) {
	this.validUser = validUser;
}
public String getRequestId() {
	return requestId;
}
public void setRequestId(String requestId) {
	this.requestId = requestId;
}
public String getResponseId() {
	return responseId;
}
public void setResponseId(String responseId) {
	this.responseId = responseId;
}
public String getOriginatingNumber() {
	return originatingNumber;
}
public void setOriginatingNumber(String originatingNumber) {
	this.originatingNumber = originatingNumber;
}
public String getDestinationNumber() {
	return destinationNumber;
}
public void setDestinationNumber(String destinationNumber) {
	this.destinationNumber = destinationNumber;
}
public String getMessageText() {
	return messageText;
}
public void setMessageText(String messageText) {
	this.messageText = messageText;
}
public String getSubmitTime() {
	return submitTime;
}
public void setSubmitTime(String submitTime) {
	this.submitTime = submitTime;
}
public String getMessageType() {
	return messageType;
}
public void setMessageType(String messageType) {
	this.messageType = messageType;
}
public String getLanguage() {
	return language;
}
public void setLanguage(String language) {
	this.language = language;
}
public String getUdh() {
	return udh;
}
public void setUdh(String udh) {
	this.udh = udh;
}
public String getStatusResport() {
	return statusResport;
}
public void setStatusResport(String statusResport) {
	this.statusResport = statusResport;
}
public String getDataEncodingScheme() {
	return dataEncodingScheme;
}
public void setDataEncodingScheme(String dataEncodingScheme) {
	this.dataEncodingScheme = dataEncodingScheme;
}
public String getProtocolIdentifier() {
	return protocolIdentifier;
}
public void setProtocolIdentifier(String protocolIdentifier) {
	this.protocolIdentifier = protocolIdentifier;
}
public String getPriority() {
	return priority;
}
public void setPriority(String priority) {
	this.priority = priority;
}
public String getChargingCode() {
	return chargingCode;
}
public void setChargingCode(String chargingCode) {
	this.chargingCode = chargingCode;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getValidityPeriod() {
	return validityPeriod;
}
public void setValidityPeriod(String validityPeriod) {
	this.validityPeriod = validityPeriod;
}
public String getMessageId() {
	return messageId;
}
public void setMessageId(String messageId) {
	this.messageId = messageId;
}
public String getInterfaceId() {
	return interfaceId;
}
public void setInterfaceId(String interfaceId) {
	this.interfaceId = interfaceId;
}
public String getInterfaceType() {
	return interfaceType;
}
public void setInterfaceType(String interfaceType) {
	this.interfaceType = interfaceType;
}
public String getDestinationPort() {
	return destinationPort;
}
public void setDestinationPort(String destinationPort) {
	this.destinationPort = destinationPort;
}
public String getCampaignId() {
	return campaignId;
}
public void setCampaignId(String campaignId) {
	this.campaignId = campaignId;
}
public String getSmscId() {
	return smscId;
}
public void setSmscId(String smscId) {
	this.smscId = smscId;
}
public String getFormat() {
	return format;
}
public void setFormat(String format) {
	this.format = format;
}
public String getOptionalParam() {
	return optionalParam;
}
public void setOptionalParam(String optionalParam) {
	this.optionalParam = optionalParam;
}
public String getUssdOpcode() {
	return ussdOpcode;
}
public void setUssdOpcode(String ussdOpcode) {
	this.ussdOpcode = ussdOpcode;
}
@Override
public String toString() {
	return "UssdMessageStore [requestId=" + requestId + ", responseId=" + responseId + ", originatingNumber="
			+ originatingNumber + ", destinationNumber=" + destinationNumber + ", messageText=" + messageText
			+ ", submitTime=" + submitTime + ", messageType=" + messageType + ", language=" + language + ", udh=" + udh
			+ ", statusResport=" + statusResport + ", dataEncodingScheme=" + dataEncodingScheme
			+ ", protocolIdentifier=" + protocolIdentifier + ", priority=" + priority + ", chargingCode=" + chargingCode
			+ ", status=" + status + ", validityPeriod=" + validityPeriod + ", messageId=" + messageId
			+ ", interfaceId=" + interfaceId + ", interfaceType=" + interfaceType + ", destinationPort="
			+ destinationPort + ", campaignId=" + campaignId + ", smscId=" + smscId + ", format=" + format
			+ ", optionalParam=" + optionalParam + ", ussdOpcode=" + ussdOpcode + "]";
}

	
}
