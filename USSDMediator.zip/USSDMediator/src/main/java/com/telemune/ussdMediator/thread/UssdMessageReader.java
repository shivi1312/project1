package com.telemune.ussdMediator.thread;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.telemune.ussdMediator.bean.UssdMessageStore;
import com.telemune.ussdMediator.dao.UssdMediatorDBUtility;

import FileBaseLogging.FileLogWriter;

@Component
public class UssdMessageReader implements Runnable {

	private static Log logger = LogFactory.getLog(UssdMediatorDBUtility.class);
	String operatorUrl;
	@Autowired
	private ApplicationContext context;
	
	FileLogWriter fileWriter;
	
	int dldid;
	@Override
	public void run() {
		try {
			dldid=Integer.parseInt(context.getEnvironment().getProperty("DLID"));
			timeout=Integer.parseInt(context.getEnvironment().getProperty("ussd.request.timeout"));
			UssdMediatorDBUtility ussdMediatorDBUtility=context.getBean(UssdMediatorDBUtility.class);
			long startTime=System.currentTimeMillis();
			operatorUrl=context.getEnvironment().getProperty("ussd.request.send.mt.url");
			fileWriter=(FileLogWriter)context.getBean("errorFileWriter");
			while(true) {
				
				logger.info("Inside UssdMessageReader going to collect data from USSD_MESSAGE_STORE");
				List<UssdMessageStore> listUssdDbUtility = ussdMediatorDBUtility.getUssdMessageStore();
				
				/**
				 * 
				 * Found No message from USSD_MESSAGE_STORE
				 * continue the while loop from begining
				 * 
				 */
				if(listUssdDbUtility==null || listUssdDbUtility.isEmpty()) {
					logger.info(" Found there is no entry for ussd so going to sleep from  "+context.getEnvironment().getProperty("ussd.main.sleep")+ " seconds");
					Thread.sleep(Integer.parseInt(context.getEnvironment().getProperty("ussd.main.sleep"))*1000);
					continue;
				}
				
				if((System.currentTimeMillis()-startTime)<=1000) {
					logger.info("To maintain tps going to sleep for ["+(1000-(System.currentTimeMillis()-startTime))+"] seconds");
					Thread.sleep(1000-(System.currentTimeMillis()-startTime));
				}
				
				startTime=System.currentTimeMillis();
				
				listUssdDbUtility.forEach(bean -> {
					
					if(dldid>=9999) {
						dldid=Integer.parseInt(context.getEnvironment().getProperty("DLID"));
					}
					
					logger.info("Going to send request for msisdn ["+bean.getDestinationNumber()+"]");
					this.hitRequestToServer(bean);
					if(bean.getSessionId()!=null) {
						logger.info("Going to maintain session for msisdn ["+bean.getDestinationNumber()+"]");
						ussdMediatorDBUtility.storeUssdMessageStoreSession(bean);
						logger.info("Going to delete msisdn ["+bean.getDestinationNumber()+"] from ussd_message_store" );
						ussdMediatorDBUtility.deletefromUssdMessageStore(bean);
					}else {
						logger.info(" get null sessionId so we try it after some time for msisdn ["+bean.getDestinationNumber()+"] so going to delete from  ussd_message_store and maintain error_log");
						ussdMediatorDBUtility.deletefromUssdMessageStore(bean);
						this.maintainErrorLog(bean);
					}
				});
			}
		}catch(Exception e) {
			logger.error("Exception while ussdMessageReader ["+e+"]");
			e.printStackTrace();
		}
	}
	
	
	private void maintainErrorLog(UssdMessageStore ussdMessageStore) {
		try {
			fileWriter.writeLog(context.getBean(Gson.class).toJson(ussdMessageStore));
		} catch (Exception e) {
			logger.error("Exception while write error file for msisdn ["+ussdMessageStore.getDestinationNumber()+"] "+ussdMessageStore.toString() +" "+e);
			e.printStackTrace();
		}
	}
	
	private void hitRequestToServer(UssdMessageStore ussdMessageStore) {
		try {
			RestTemplate restTemplate = context.getBean(RestTemplate.class);
			HttpHeaders headers = context.getBean(HttpHeaders.class); /*new HttpHeaders();*/
			headers.setContentType(MediaType.TEXT_PLAIN);
			List <MediaType> mediaTypeList = new ArrayList<MediaType>();
			headers.setAccept(mediaTypeList);
			headers.add("USERNAME", context.getEnvironment().getProperty("USER_NAME"));
			headers.add("PASSWORD", context.getEnvironment().getProperty("PASSWORD"));
			headers.add("DLID", ((dldid++)+""));
			headers.add("DATA", ussdMessageStore.getMessageText());
			headers.add("MSISDN", ussdMessageStore.getDestinationNumber());
			headers.add("SHORTCODE", ussdMessageStore.getOriginatingNumber());
			headers.add("OPCODE", context.getEnvironment().getProperty("OPCODE_MT"));

			HttpEntity<String> requestXml = new HttpEntity<String>("{}", headers);
			this.setTimeout(restTemplate);
			logger.info("Send Post request to "+operatorUrl+" for msisdn "+ussdMessageStore.getDestinationNumber() +" with header data ["+headers.toString()+"] ");
			ResponseEntity<String> response = restTemplate.postForEntity(operatorUrl,
					requestXml, String.class);
			HttpHeaders responseHeader=response.getHeaders();
			ussdMessageStore.setValidUser(responseHeader.get("VALIDUSER").get(0));
			ussdMessageStore.setSessionId(responseHeader.get("SESIONID").get(0));
			logger.info(" response for msisdn ["+ussdMessageStore.getDestinationNumber() +"] with headers validUser ["+responseHeader.get("VALIDUSER")+"] and sessionid ["+responseHeader.get("SESIONID")+"]");
		}catch(Exception e) {
			logger.error("Exception while send  ussd request for msisdn ["+ussdMessageStore.getDestinationNumber()+"] "+e);
			e.printStackTrace();	
		}
	}
	
	int timeout;
	private void setTimeout(RestTemplate restTemplate) {
        restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
        SimpleClientHttpRequestFactory rf = (SimpleClientHttpRequestFactory) restTemplate
                .getRequestFactory();
        rf.setReadTimeout(timeout*1000);
        rf.setConnectTimeout(timeout*1000);
    }

}
