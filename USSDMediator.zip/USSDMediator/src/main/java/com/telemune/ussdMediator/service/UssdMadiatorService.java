package com.telemune.ussdMediator.service;


import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.telemune.ussdMediator.bean.ResponseBean;
import com.telemune.ussdMediator.dao.UssdMediatorDBUtility;
import  org.springframework.http.*;
import FileBaseLogging.FileLogWriter;

@Component
@Scope("prototype")
public class UssdMadiatorService {
	private static Log logger = LogFactory.getLog(UssdMadiatorService.class);
	private String apiUrl;
	public void sendRequestForSub(String sessionId, String msisdn) {
		if(context.getEnvironment().getProperty("RESPONSE_ENABLE").trim().equals("1")){
			logger.info("Inside sendRequestForSub() for msisdn ["+msisdn+"] session ["+sessionId+"] give response t user ");
			hitRequestToServer(msisdn);
		}
		logger.info("Inside sendRequestForSub() for msisdn ["+msisdn+"] session ["+sessionId+"] going to send request to api");
		sendToPortalApi(msisdn);
		logger.info("Inside sendRequestForSub() for msisdn ["+msisdn+"] session ["+sessionId+"] after send request to api and maintain log now we delete from ussd_session");
		context.getBean(UssdMediatorDBUtility.class).deleteFromUssdSession(msisdn,sessionId);
		logger.info("Delete from ussd session end of the service class msisdn ["+msisdn+"]");
		}
	
	@Autowired
	ApplicationContext context;
	
	private void sendToPortalApi(String msisdn) {
		ResponseBean responseBean=null;
		ResponseEntity<String> response = null;
		try {
			
			RestTemplate restTemplate = context.getBean(RestTemplate.class);
			this.setTimeout(restTemplate);
			String requestType=context.getEnvironment().getProperty("REQUEST_TYPE");
			logger.info("Send Post request to " + apiUrl + " for msisdn " + msisdn);
			HttpHeaders headers = context.getBean(HttpHeaders.class);
			headers.setContentType(MediaType.APPLICATION_JSON);
			
			if(requestType.equalsIgnoreCase("POST"))
			{
				apiUrl=context.getEnvironment().getProperty("API_URL");
				logger.info("Post request is "+context.getEnvironment().getProperty("API_URL_DATA").replace("%m", msisdn));
				response = restTemplate.postForEntity(apiUrl, context.getEnvironment().getProperty("API_URL_DATA").replace("%m", msisdn) , String.class);
			}
			else
			{
				apiUrl=context.getEnvironment().getProperty("GET_API_URL").replace("%m", msisdn);
				logger.info("Get request is "+apiUrl);
				response = restTemplate.getForEntity(apiUrl , String.class);
			}
			
		//	responseBean = context.getBean(Gson.class).fromJson(response.getBody(), ResponseBean.class);
			logger.info("Response msisdn is  "+msisdn + " response body "+ response.getBody());
			
		} catch (Exception e) {
			logger.error("Exception while send  ussd request for msisdn [" + msisdn + "] " + e);
			e.printStackTrace();
		}finally {
			//if(responseBean==null) {
		//		responseBean=context.getBean(ResponseBean.class);
		//	}
		//	responseBean.setMsisdn(msisdn);
			if(response!=null)
				this.maintainlog(response.getBody(),msisdn);
			else
				this.maintainlog("Error while send to portal API ",msisdn);
		}
	}

	int timeout;
	
	private void setTimeout(RestTemplate restTemplate) {
		timeout=Integer.parseInt(context.getEnvironment().getProperty("API_URL_TIMEOUT"));
		restTemplate.setRequestFactory(new SimpleClientHttpRequestFactory());
		SimpleClientHttpRequestFactory rf = (SimpleClientHttpRequestFactory) restTemplate.getRequestFactory();
		rf.setReadTimeout(timeout * 1000);
		rf.setConnectTimeout(timeout * 1000);
	}
	
	private void maintainlog(ResponseBean response) {
		//		responseFileWriter
		try {
		FileLogWriter fileWriter=(FileLogWriter)context.getBean("responseFileWriter");
		fileWriter.writeLog(context.getBean(Gson.class).toJson(response));
		logger.info("Successfully maintain log for msisdn ["+response.toString()+"]");
		}catch (Exception e) {
			logger.error("Exception while make response of the api for bean ["+response.toString()+"]" +e);
			e.printStackTrace();
		}
		
	}
	
	private void maintainlog(String response,String msisdn) {
		//		responseFileWriter
		try {
		FileLogWriter fileWriter=(FileLogWriter)context.getBean("responseFileWriter");
		fileWriter.writeLog(msisdn +" #,# "+response);
		logger.info("Successfully maintain log for msisdn ["+response.toString()+"]");
		}catch (Exception e) {
			logger.error("Exception while make response of the api for bean ["+response.toString()+"]" +e);
			e.printStackTrace();
		}
		
	}

	private void hitRequestToServer(String msisdn) {
                try {
			String operatorUrl=context.getEnvironment().getProperty("ussd.response.send.mt.url");
                        RestTemplate restTemplate = context.getBean(RestTemplate.class);
                        HttpHeaders headers = context.getBean(HttpHeaders.class); /*new HttpHeaders();*/
                        headers.setContentType(MediaType.TEXT_PLAIN);
                        List <MediaType> mediaTypeList = new ArrayList<MediaType>();
                        headers.setAccept(mediaTypeList);
                        headers.add("USERNAME", context.getEnvironment().getProperty("USER_NAME"));
                        headers.add("PASSWORD", context.getEnvironment().getProperty("PASSWORD"));
                        headers.add("DLID", "1000");
                        headers.add("DATA", context.getEnvironment().getProperty("DEFAULT_RESPONSE_MESSAGE"));
                        headers.add("MSISDN", msisdn);
                        headers.add("SHORTCODE", context.getEnvironment().getProperty("ORIG_NO"));
                        headers.add("OPCODE", context.getEnvironment().getProperty("OPCODE_MT_RES"));

                        HttpEntity<String> requestXml = new HttpEntity<String>("{}", headers);
                        this.setTimeout(restTemplate);
                        logger.info("Send Post request to "+operatorUrl+" for msisdn "+ msisdn +" with header data ["+headers.toString()+"] ");
                        ResponseEntity<String> response = restTemplate.postForEntity(operatorUrl,
                                        requestXml, String.class);
                        HttpHeaders responseHeader=response.getHeaders();
//                        ussdMessageStore.setValidUser(responseHeader.get("VALIDUSER").get(0));
  //                      ussdMessageStore.setSessionId(responseHeader.get("SESIONID").get(0));
                        logger.info(" response for msisdn ["+msisdn +"] with headers validUser ["+responseHeader.get("VALIDUSER")+"] and sessionid ["+responseHeader.get("SESIONID")+"]");
                }catch(Exception e) {
                        logger.error("Exception while send  ussd request for msisdn ["+msisdn+"] "+e);
                        e.printStackTrace();
                }
        }

}
