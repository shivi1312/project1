package com.telemune.ussdMediator.restController;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.ussdMediator.dao.UssdMediatorDBUtility;
import com.telemune.ussdMediator.service.UssdMadiatorService;

@RestController
@RequestMapping("/UssdMadiator")
public class UssdMadiatoryRestController {
	private static Log logger = LogFactory.getLog(UssdMediatorDBUtility.class);
	
	@Autowired
	ApplicationContext context;
	
	@PostMapping("/response")
	private ResponseEntity ussdMadiatorResponse(@RequestHeader("REQUESTTYPE") String requestType,
			@RequestHeader("DIALOGID") String dialogId,
			@RequestHeader("MSISDN") String msisdn,
			@RequestHeader("REQDATA") String reqData,
			@RequestHeader("SESSIONID") String sessionId
			) {
		logger.info("Get request with DIALOGID ["+dialogId+"] MSISDN ["+msisdn+"] REQDATA ["+reqData+"] SESSIONID ["+sessionId+"] ");
		//@RequestHeader("Connection") String connection
		String response=null;
		UssdMadiatorService ussdMadiatorService=context.getBean(UssdMadiatorService.class);
		if(reqData.trim().equalsIgnoreCase("1")) {
			ussdMadiatorService.sendRequestForSub(sessionId,msisdn);
//			
		}else{
		
				logger.info("Get Invalid response from msisdn ["+msisdn+"] REQDATA ["+reqData+"] DIALOGID ["+dialogId+"]");
				//context.getEnvironment().getProperty
				//response=context.getEnvironment().getProperty("INVALID_DIGIT_MSISDN");
		}
	//	if(response==null){
		response=context.getEnvironment().getProperty("DEFAULT_RESPONSE_MESSAGE");
	//	}
		
		HttpHeaders headers=new HttpHeaders();
		headers.add("RESPDATA", response );
		//headers.add("DATA", response );
		headers.add("REQTYPE", context.getEnvironment().getProperty("OPCODE_MT_RES").trim());
		headers.add("DIALOGID", dialogId);
		headers.add("DLID", dialogId);
		logger.info("request complete for msisdn ["+msisdn+"]");
		return new ResponseEntity<>(headers,HttpStatus.OK);
	}
}
