package com.telemune.ussdMediator.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.telemune.ussdMediator.bean.UssdMessageStore;

@Component
@Scope("prototype")
public class UssdMediatorDBUtility {

	private static Log logger = LogFactory.getLog(UssdMediatorDBUtility.class);
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	ApplicationContext context;
	
	public List<UssdMessageStore> getUssdMessageStore() {
		try {
			String query="select * from ussd_message_store limit "+context.getEnvironment().getProperty("ussd.message.limit").trim();
			if(context.getEnvironment().getProperty("ussd.dbType").trim().equalsIgnoreCase("1")) {
				query="select * from ussd_message_store where rownum <= "+context.getEnvironment().getProperty("ussd.message.limit").trim()+"";
			}
			logger.info("Going to select the data from getUssdMessageStore() method with query ["+query+"]");
			return	jdbcTemplate.query(query, new BeanPropertyRowMapper(UssdMessageStore.class,false));
		}catch(Exception e) {
			logger.error("Exception while select from ussd_message_store in getUssdMessageStore() method "+e); 
			e.printStackTrace();
		}
		return null;
	}
	
/**
 * create table USSD_MESSAGE_SESSION(
 	MSISDN varchar(15) not null,
 	SESSION_DATA text not null,
 	SESSION_ID varchar(50) not null,
 	CREATE_DATE datetime
 	);
 * 
 * @param bean
 * @return
 */
	public void storeUssdMessageStoreSession(UssdMessageStore bean) {
		try {
			String query="insert into USSD_MESSAGE_SESSION(MSISDN,SESSION_DATA,SESSION_ID,CREATE_DATE) values(?,?,?,now())" ;
			if(context.getEnvironment().getProperty("ussd.dbType").trim().equalsIgnoreCase("1")) {
				query="insert into USSD_MESSAGE_SESSION(MSISDN,SESSION_DATA,SESSION_ID,CREATE_DATE) values(?,?,?,sysdate)" ;
			}
			logger.info("Going to insert data from storeUssdMessageStoreSession() method with query ["+query+"] "+jdbcTemplate.update(query,bean.getDestinationNumber(),context.getBean(Gson.class).toJson(bean),bean.getSessionId()));
		}catch(Exception e) {
			logger.error("Exception while select from ussd_message_session in storeUssdMessageStoreSession() method "+e);
			e.printStackTrace();
		}
	}
	
	
	public void deletefromUssdMessageStore(UssdMessageStore bean) {
		try {
			String query="delete from ussd_message_store where request_id=? and response_id=?";
			logger.info("Going to delete data from deletefromUssdMessageStore() method with query ["+query+"] "+jdbcTemplate.update(query,bean.getRequestId(),bean.getResponseId()));
		}catch(Exception e) {
			logger.error("Exception while delete from ussd_message_store in deletefromUssdMessageStore() method "+e); 
			e.printStackTrace();
		}
	}

	public void deleteFromUssdSession(String msisdn,String sessionId) {
		try {
			String query="delete from USSD_MESSAGE_SESSION where msisdn=? ";
			logger.info("Going to delete data from deleteFromUssdSession() method with query ["+query+"] "+jdbcTemplate.update(query,msisdn));
		}catch(Exception e) {
			logger.error("Exception while delete from ussd_message_store in deletefromUssdMessageStore() method "+e); 
			e.printStackTrace();
		}
	}
	
	
}
