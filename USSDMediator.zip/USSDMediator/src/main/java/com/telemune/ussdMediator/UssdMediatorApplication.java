package com.telemune.ussdMediator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.omg.PortableInterceptor.LOCATION_FORWARD;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

import com.telemune.ussdMediator.thread.UssdMessageReader;

@SpringBootApplication
public class UssdMediatorApplication {
	private final static Log logger = LogFactory.getLog(UssdMediatorApplication.class);

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new SpringApplicationBuilder(UssdMediatorApplication.class)
				.properties("spring.config.name:UssdMediator", "spring.config.location:config/").build().run(args);
		Thread th = null;
		Runnable ussdMessageReader = null;
		try {
			logger.info("Going to start the application First going to run thread of USSD_MESSAGE_READER");
			ussdMessageReader = context.getBean(UssdMessageReader.class);
			th = context.getBean(Thread.class, ussdMessageReader, "USSD_MESSAGE_READER");
			th.start();
			logger.info("successfully start the thread of USSD_MESSAGE_READER");
			logger.info("All thread start successfully now while loop to check all the thread run continously ");
		} catch (Exception e) {
			logger.error("Exception in while start thread " + e);
			e.printStackTrace();
		}
		while (true) {
			try {
				if (th == null || !th.isAlive()) {
					if (ussdMessageReader == null) {
						ussdMessageReader = context.getBean(UssdMessageReader.class);
					}
					th = context.getBean(Thread.class, ussdMessageReader, "USSD_MESSAGE_READER");
					th.start();
				}
				try {
					Thread.sleep(20 * 1000);
				} catch (Exception e) {
					logger.error("Exception in while loop while sleep for 20 sec " + e);
					e.printStackTrace();
				}
			} catch (Exception e) {
				logger.error("Exception in while loop to check all thread run continously " + e);
				e.printStackTrace();

			}
		}

	}

}
