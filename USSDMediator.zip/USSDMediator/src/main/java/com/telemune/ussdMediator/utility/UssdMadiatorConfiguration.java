package com.telemune.ussdMediator.utility;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;

import FileBaseLogging.FileLogWriter;

@Configuration
public class UssdMadiatorConfiguration {
	
	
	@Bean
	@Scope("prototype")
	public HttpHeaders httpHeaders(){
		return new HttpHeaders();
	}
	
	@Bean
	@Scope("prototype")
	public RestTemplate restTemplate(){
		return new RestTemplate();
	}
	
	@Bean
	@Scope("prototype")
	public Gson gson(){
		return new Gson();
	}

	@Autowired
	Environment env;
	
	@Bean("errorFileWriter")
	public FileLogWriter errorFileReport() {
			FileLogWriter fileLogWriter = new FileLogWriter();
			fileLogWriter.setNewFileInterval(Integer.parseInt(env.getProperty("ERROR_FILE_INTERVAL")));
			fileLogWriter.setFilename(env.getProperty("ERROR_FILENAME"));
			fileLogWriter.setFilePath(env.getProperty("ERROR_FILEPATH"));
			fileLogWriter.setArchiveFilePath(env.getProperty("ERROR_FILEPATH_ARCH"));
			fileLogWriter.setArchiveFilename(env.getProperty("ERROR_FILENAME_ARCH"));
			fileLogWriter.setArchiveFileExtension(".d");
			fileLogWriter.setIncludeTime(false);
			fileLogWriter.initialize();
			return fileLogWriter;
		}
	
	
	@Bean("responseFileWriter")
	public FileLogWriter responseFileReport() {
			FileLogWriter fileLogWriter = new FileLogWriter();
			fileLogWriter.setNewFileInterval(Integer.parseInt(env.getProperty("RESPONSE_FILE_INTERVAL")));
			fileLogWriter.setFilename(env.getProperty("RESPONSE_FILENAME"));
			fileLogWriter.setFilePath(env.getProperty("RESPONSE_FILEPATH"));
			fileLogWriter.setArchiveFilePath(env.getProperty("RESPONSE_FILEPATH_ARCH"));
			fileLogWriter.setArchiveFilename(env.getProperty("RESPONSE_FILENAME_ARCH"));
			fileLogWriter.setArchiveFileExtension(".d");
			fileLogWriter.setIncludeTime(false);
			fileLogWriter.initialize();
			return fileLogWriter;
		}
	
	@Bean
	@Lazy
	@Scope("prototype")
	public Thread thread(Runnable runnable,String name) {
		return new Thread(runnable, name);
	}
	
}
