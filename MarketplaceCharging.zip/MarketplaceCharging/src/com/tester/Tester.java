package com.tester;

import com.charging.client.ThirdParty.Data_Object;
import com.charging.client.ThirdParty.TransferManager;

public class Tester {

	public static void main(String arg[])
	{
		//Global.loadConfiguration(); //loading configuration
		TransferManager request = new TransferManager();
		Data_Object data_object = null;
		int resp = -1;
		
		if(arg[0].equalsIgnoreCase("CB"))
		{
			System.out.println("arg[0] = "+arg[0]+" arg[1]"+arg[1]);
			data_object = new Data_Object();
			data_object.serviceType = "CHECK_BALANCE";
			data_object.msisdn = arg[1];
			data_object.serviceAmount = 300;
			data_object.currAcctChgAmt = 22;
			resp = request.doCharging(data_object);
			System.out.println("Resposne from checkBalance is["+resp+"] result bean is ["+data_object+"]");
		}
		else if(arg[0].equalsIgnoreCase("PA"))
		{
			data_object = new Data_Object();
			data_object.serviceType = "PACK_PURCHASE";
			data_object.msisdn = arg[1];
			data_object.productCode = arg[2];
			resp = request.doCharging(data_object);
			System.out.println("Resposne from packActivation is["+resp+"] result bean is ["+data_object+"]");
		}
		else if(arg[0].equalsIgnoreCase("DB"))
		{
			data_object = new Data_Object();
			data_object.serviceType = "DEDUCT_BALANCE";
			data_object.msisdn = arg[1];
			data_object.deductAmount = Integer.parseInt(arg[2]);
			data_object.desc = arg[3];
			resp = request.doCharging(data_object);
			System.out.println("Resposne from deductBalance is["+resp+"] result bean is ["+data_object+"]");
		}
		else if(arg[0].equalsIgnoreCase("TT"))
		{
			data_object = new Data_Object();
			data_object.serviceType = "TALK_TIME_TRANSFER";
			data_object.msisdn = arg[1];
			data_object.fmsisdn = arg[2];
			data_object.currAcctChgAmt = Integer.parseInt(arg[3]);
			data_object.accType = arg[4];
			data_object.nb_day = Integer.parseInt(arg[5]);
			data_object.desc = arg[6];
			data_object.serviceAmount = Integer.parseInt(arg[7]);
			resp = request.doCharging(data_object);
			System.out.println("Resposne from TalkTimeTransfer is["+resp+"] result bean is ["+data_object+"]");
		}
		else if(arg[0].equalsIgnoreCase("DT"))
		{
			data_object = new Data_Object();
			data_object.serviceType = "DATA_TRANSFER";
			data_object.msisdn = arg[1];
			data_object.fmsisdn = arg[2];
			data_object.currAcctChgAmt = Integer.parseInt(arg[3]);
			data_object.accType = arg[4];
			data_object.nb_day = Integer.parseInt(arg[5]);
			data_object.desc = arg[6];
			data_object.serviceAmount = Integer.parseInt(arg[7]);
			resp = request.doCharging(data_object);
			System.out.println("Resposne from DataTransfer is["+resp+"] result bean is ["+data_object+"]");
		}
		else if(arg[0].equalsIgnoreCase("BT"))
		{
			data_object = new Data_Object();
			data_object.serviceType = "BOUNS_TRANSFER";
			data_object.msisdn = arg[1];
			data_object.fmsisdn = arg[2];
			data_object.currAcctChgAmt = Integer.parseInt(arg[3]);
			data_object.accType = arg[4];
			data_object.nb_day = Integer.parseInt(arg[5]);
			data_object.desc = arg[6];
			data_object.serviceAmount = Integer.parseInt(arg[7]);
			resp = request.doCharging(data_object);
			System.out.println("Resposne from BounsTransfer is["+resp+"] result bean is ["+data_object+"]");
		}
	}
}
