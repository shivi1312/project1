package com.tester;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.TreeSet;

import com.charging.client.ThirdParty.ThirdPartyRequest;

public class Test {

	public static void main(String arg[])
	{
		 //TreeSet<BalanceInfoBean> set = new TreeSet<BalanceInfoBean>(new ExpiryDateComparator());
		 /*ArrayList<BalanceInfoBean> set = new ArrayList<BalanceInfoBean>(); 
		 BalanceInfoBean info = new BalanceInfoBean();
		 info.id = 22;
		 info.expiryTime ="20370101000000000000";
		 
		 BalanceInfoBean info1 = new BalanceInfoBean();
		 info1.id = 23;
		 info1.expiryTime ="20170313000000000000";
		 
		 BalanceInfoBean info2 = new BalanceInfoBean();
		 info2.id = 24;
		 info2.expiryTime ="20170313000000000000";
		 
		 BalanceInfoBean info3 = new BalanceInfoBean();
		 info3.id = 25;
		 info3.expiryTime ="20170313000000000000";
		 
		 BalanceInfoBean info4 = new BalanceInfoBean();
		 info4.id = 26;
		 info4.expiryTime ="20170313000000000000";
		 
		 set.add(info);
		 set.add(info1);
		 set.add(info2);
		 set.add(info3);
		 set.add(info4);
		 
		 Collections.sort(set, new ExpiryDateComparator());
		 
		 Iterator<BalanceInfoBean> itr = set.iterator();
		 while(itr.hasNext())
		 {
			 System.out.println("Data["+itr.next()+"]");
		 }
			*/ 
		 
		 
		//Added By Siddharth For Test
		//new ThirdPartyRequest().getBalancePost(msisdn);
		 
		 }
		 
		 
		 
		 
		
	     
	}
	
	

