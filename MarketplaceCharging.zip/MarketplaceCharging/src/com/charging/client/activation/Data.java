package com.charging.client.activation;

public class Data
{
private Trade Trade;

public Trade getTrade ()
{
return Trade;
}

public void setTrade (Trade Trade)
{
this.Trade = Trade;
}

@Override
public String toString()
{
return "ClassPojo [Trade = "+Trade+"]";
}
}
