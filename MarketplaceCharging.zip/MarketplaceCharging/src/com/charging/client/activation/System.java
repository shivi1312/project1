package com.charging.client.activation;

public class System
{
private String SN;

private String messageType;

private String cmdCode;

public String getSN ()
{
return SN;
}

public void setSN (String SN)
{
this.SN = SN;
}

public String getMessageType ()
{
return messageType;
}

public void setMessageType (String messageType)
{
this.messageType = messageType;
}

public String getCmdCode ()
{
return cmdCode;
}

public void setCmdCode (String cmdCode)
{
this.cmdCode = cmdCode;
}

@Override
public String toString()
{
return "ClassPojo [SN = "+SN+", messageType = "+messageType+", cmdCode = "+cmdCode+"]";
}
}