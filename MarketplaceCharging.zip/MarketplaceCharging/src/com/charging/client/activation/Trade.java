package com.charging.client.activation;
                 

public class Trade
{
private ParamList ParamList;

private System System;

public ParamList getParamList ()
{
return ParamList;
}

public void setParamList (ParamList ParamList)
{
this.ParamList = ParamList;
}

public System getSystem ()
{
return System;
}

public void setSystem (System System)
{
this.System = System;
}

@Override
public String toString()
{
return "ClassPojo [ParamList = "+ParamList+", System = "+System+"]";
}
}

