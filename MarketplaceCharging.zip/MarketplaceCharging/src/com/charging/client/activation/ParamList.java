package com.charging.client.activation;
public class ParamList
{
    private Param[] Param;

    private String desc;

    private String retCode;

    private String operationID;

    public Param[] getParam ()
    {
        return Param;
    }

    public void setParam (Param[] Param)
    {
        this.Param = Param;
    }

    public String getDesc ()
    {
        return desc;
    }

    public void setDesc (String desc)
    {
        this.desc = desc;
    }

    public String getRetCode ()
    {
        return retCode;
    }

    public void setRetCode (String retCode)
    {
        this.retCode = retCode;
    }

    public String getOperationID ()
    {
        return operationID;
    }

    public void setOperationID (String operationID)
    {
        this.operationID = operationID;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Param = "+Param+", desc = "+desc+", retCode = "+retCode+", operationID = "+operationID+"]";
    }
}
			
	