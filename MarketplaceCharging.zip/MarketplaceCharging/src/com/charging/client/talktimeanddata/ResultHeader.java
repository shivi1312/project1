package com.charging.client.talktimeanddata;
public class ResultHeader
{
	 private String TransactionId;

	    private String ResultDesc;

	    private String SequenceId;

	    private String ResultCode;

	    private String CommandId;

	    private String Version;

	    public String getTransactionId ()
	    {
	        return TransactionId;
	    }

	    public void setTransactionId (String TransactionId)
	    {
	        this.TransactionId = TransactionId;
	    }

	    public String getResultDesc ()
	    {
	        return ResultDesc;
	    }

	    public void setResultDesc (String ResultDesc)
	    {
	        this.ResultDesc = ResultDesc;
	    }

	    public String getSequenceId ()
	    {
	        return SequenceId;
	    }

	    public void setSequenceId (String SequenceId)
	    {
	        this.SequenceId = SequenceId;
	    }

	    public String getResultCode ()
	    {
	        return ResultCode;
	    }

	    public void setResultCode (String ResultCode)
	    {
	        this.ResultCode = ResultCode;
	    }

	    public String getCommandId ()
	    {
	        return CommandId;
	    }

	    public void setCommandId (String CommandId)
	    {
	        this.CommandId = CommandId;
	    }

	    public String getVersion ()
	    {
	        return Version;
	    }

	    public void setVersion (String Version)
	    {
	        this.Version = Version;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [TransactionId = "+TransactionId+", ResultDesc = "+ResultDesc+", SequenceId = "+SequenceId+", ResultCode = "+ResultCode+", CommandId = "+CommandId+", Version = "+Version+"]";
	    }
}
			
			