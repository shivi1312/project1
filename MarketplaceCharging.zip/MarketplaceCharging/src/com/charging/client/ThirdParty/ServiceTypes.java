package com.charging.client.ThirdParty;

/**
 * This is a Interface that define all constant related to different
 * serviceTypes.
 * 
 * @author Siddharth Singh Rawat
 */
public interface ServiceTypes {
	String CHECK_BALANCE = "CHECK_BALANCE";
	String DEDUCT_BALANCE = "DEDUCT_BALANCE";
	String PACK_PURHCASE = "PACK_PURCHASE";
	String DATA_TRANSFER = "DATA_TRANSFER";
	String BONUS_TRANSFER = "BONUS_TRANSFER";
	String TALK_TIME_TRANSFER = "TALK_TIME_TRANSFER";
	String CHECK_TRANSFER_BALANCE = "CHECK_TRANSFER_BALANCE";
	String OFF_NET = "OFF_NET";
	String ON_NET = "ON_NET";
	String EURO_OFF_NET = "EURO_OFF_NET";
	String DATA = "DATA";
	String GIFT = "GIFT";
	String CHECK_DT_ELIGIBILITY = "CHECK_DT_ELIGIBILITY";
	String SERVICE_TYPE_GIFT = "GIFT";
	String SERVICE_TYPE_PACK_PURCHASE = "PP";
	String DATA_MACRO_CREDIT = "DATA_MACRO_CREDIT";
}