package com.charging.client.ThirdParty;

import java.util.Arrays;
import java.util.Hashtable;

/**
 * This class provide all data-members used for all type of operations regarding
 * charging. Modified by SIDDHARTH
 * 
 * @author Harjinder
 */
public class Data_Object {

	public String transId;
	public String msisdn;
	public String fmsisdn = "NA";
	public long balance;
	public long acc_2000_balance;
	public long acc_2001_balance;
	public long acc_5018_balance;
	public long acc_5017_balance;
	public long acc_5016_balance;
	public int offNetCreditAcc;
	public int onNetCreditAcc;
	public int offNetDebitAcc;
	public int onNetDebitAcc;
	public int bounsCreditAcc;
	public int bounsDebitAcc;
	public String productCode;
	public int deductAmount;
	public long currAcctChgAmt = 0l;
	public String accType;
	public String accId;
	public String desc;
	public int nb_day;
	public String serviceType;
	public double serviceAmount = 0;
	public long creditcurrAcctamount;
	public int index;
	public String[] responseArray = new String[10];
	public long volumeBalance;
/*
 * adding HashTable for balance Mapping information, which can used any where.
 * Changes by Ashu Mittal 
 * 19-Oct-2021
 * #8335 _ pms feature number
 */
	
	public Hashtable <Integer,BalanceInfoBean> accountDetailInfoTable=null;
	
	public long getCreditcurrAcctamount() {
		return creditcurrAcctamount;
	}

	public void setCreditcurrAcctamount(long creditcurrAcctamount) {
		this.creditcurrAcctamount = creditcurrAcctamount;
	}

	public long getCurrAcctChgAmt() {
		return currAcctChgAmt;
	}

	public void setCurrAcctChgAmt(long currAcctChgAmt) {
		this.currAcctChgAmt = currAcctChgAmt;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public String getFmsisdn() {
		return fmsisdn;
	}

	public void setFmsisdn(String fmsisdn) {
		this.fmsisdn = fmsisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public long getAcc_2000_balance() {
		return acc_2000_balance;
	}

	public void setAcc_2000_balance(int acc_2000_balance) {
		this.acc_2000_balance = acc_2000_balance;
	}

	public long getAcc_2001_balance() {
		return acc_2001_balance;
	}

	public void setAcc_2001_balance(int acc_2001_balance) {
		this.acc_2001_balance = acc_2001_balance;
	}

	public long getAcc_5018_balance() {
		return acc_5018_balance;
	}

	public void setAcc_5018_balance(int acc_5018_balance) {
		this.acc_5018_balance = acc_5018_balance;
	}

	public long getAcc_5017_balance() {
		return acc_5017_balance;
	}

	public void setAcc_5017_balance(int acc_5017_balance) {
		this.acc_5017_balance = acc_5017_balance;
	}

	public long getAcc_5016_balance() {
		return acc_5016_balance;
	}

	public void setAcc_5016_balance(int acc_5016_balance) {
		this.acc_5016_balance = acc_5016_balance;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public int getDeductAmount() {
		return deductAmount;
	}

	public void setDeductAmount(int deductAmount) {
		this.deductAmount = deductAmount;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public int getNb_day() {
		return nb_day;
	}

	public void setNb_day(int nb_day) {
		this.nb_day = nb_day;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public double getServiceAmount() {
		return serviceAmount;
	}

	public void setServiceAmount(double serviceAmount) {
		this.serviceAmount = serviceAmount;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String[] getResponseArray() {
		return responseArray;
	}

	public void setResponseArray(String[] responseArray) {
		this.responseArray = responseArray;
	}

	public long getVolumeBalance() {
		return volumeBalance;
	}

	public void setVolumeBalance(long volumeBalance) {
		this.volumeBalance = volumeBalance;
	}

	@Override
	public String toString() {
		return "Data_Object [transId=" + transId + ", msisdn=" + msisdn + ", fmsisdn=" + fmsisdn + ", balance="
				+ balance + ", acc_2000_balance=" + acc_2000_balance + ", acc_2001_balance=" + acc_2001_balance
				+ ", acc_5018_balance=" + acc_5018_balance + ", acc_5017_balance=" + acc_5017_balance
				+ ", acc_5016_balance=" + acc_5016_balance + ", offNetCreditAcc=" + offNetCreditAcc
				+ ", onNetCreditAcc=" + onNetCreditAcc + ", offNetDebitAcc=" + offNetDebitAcc + ", onNetDebitAcc="
				+ onNetDebitAcc + ", bounsCreditAcc=" + bounsCreditAcc + ", bounsDebitAcc=" + bounsDebitAcc
				+ ", productCode=" + productCode + ", deductAmount=" + deductAmount + ", currAcctChgAmt="
				+ currAcctChgAmt + ", accType=" + accType + ", accId=" + accId + ", desc=" + desc + ", nb_day=" + nb_day
				+ ", serviceType=" + serviceType + ", serviceAmount=" + serviceAmount + ", creditcurrAcctamount="
				+ creditcurrAcctamount + ", index=" + index + ", responseArray=" + Arrays.toString(responseArray)
				+ ", volumeBalance=" + volumeBalance + "]";
	}
}
