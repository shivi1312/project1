package com.charging.client.ThirdParty;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import org.apache.log4j.Logger;

/**
 * This class is a wrapper class that take request from MarketPlaceApi , then
 * sent for further processing according to serviceType. Modified by SIDDHARTH.
 * 
 * @author Harjinder
 * 
 */
public class TransferManager {

	private static Logger logger = Logger.getLogger("TransferManager");

	/**
	 * This method is common method for all requests from MarketPlaceApi.
	 * 
	 * @param data_Object
	 * @return 1,-1,-2
	 */
	public int doCharging(Data_Object data_Object) {
		int resp = -1;
		StringBuffer respDesc = new StringBuffer("NA");
		int debitAcctExists = -1;
		try {
			ThirdPartyRequest request = new ThirdPartyRequest();
			logger.info("###>>msisdn[" + data_Object.msisdn + "] inside doCharging() with bean[" + data_Object + "]");
			//System.out.println("###>>msisdn[" + data_Object.msisdn + "] inside doCharging() with bean[" + data_Object + "]");
			data_Object.msisdn = data_Object.msisdn.substring(Global.countryCodeLength);
			if (!data_Object.fmsisdn.equalsIgnoreCase("NA")) {
				data_Object.fmsisdn = data_Object.fmsisdn.substring(Global.countryCodeLength);
			}
			data_Object.deductAmount = (int) data_Object.serviceAmount;
			data_Object.creditcurrAcctamount = data_Object.currAcctChgAmt;
			if (data_Object.getServiceType().equalsIgnoreCase(ServiceTypes.TALK_TIME_TRANSFER)) {
				data_Object.desc = "TTT";
				logger.info("###>>msisdn[" + data_Object.msisdn + "] going for Talk Time Transfer, ServiceType["
						+ data_Object.getServiceType() + "] desc[" + data_Object.desc + "]");
				ArrayList<BalanceInfoBean> balanceList = new ArrayList<BalanceInfoBean>();
				ArrayList<BalanceInfoBean> debitArrayList = new ArrayList<BalanceInfoBean>();
				// going to call check balance
				data_Object.index = 0;
				resp = -1;
				debitAcctExists = -1;
				// resp = request.checkBalance(data_Object, balanceList);
				resp = request.checkBalanceDiameter(data_Object, balanceList);
				if (resp == 1) {
					// to check debit account in balanceList exists or not
					respDesc.append("CHECK BALANCE SUCCESS");
					debitAcctExists = toCheckTranferBalance(data_Object, balanceList, debitArrayList);
					logger.debug("##>>msisdn[" + data_Object.msisdn + "] response from toCheckTranferBalance["
							+ debitAcctExists + "]");
					if (debitAcctExists != -1) {
						// to check user have enough balance for this transaction
						respDesc.append(",TALKTIME TRANSFER DEBIT ACCOUNT EXISTS");
						resp = -1;
						if (data_Object.acc_2000_balance >= data_Object.serviceAmount) {
							// going to deduct service amount from main account
							data_Object.deductAmount = (int) data_Object.serviceAmount;
							resp = request.deductBlnce(data_Object);
							logger.info(
									"##>>msisdn[" + data_Object.msisdn + "] response from  deductBlnce [" + resp + "]");
							if (resp != 1) {
								respDesc.append(",DEDUCTION FROM MAIN ACCOUNT FAIL");
								resp = -1;
							}

						} else {
							respDesc.append(",USER HAS LOW MAIN BALANCE");
							resp = -2;
						}
					} else {
						respDesc.append(",TALKTIME TRANSFER DEBIT ACCOUNT NOT EXITS");
						resp = -3;
					}
				} else {
					respDesc.append("CHECK BALANCE NOT SUCCESS");

				}

				if (resp == 1) {
					// debit from main account successfully
					respDesc.append(",DEDUCTION FROM MAIN ACCOUNT SUCCESS");
					resp = -1;
					for (int i = 0; i < debitArrayList.size(); i++) {
						BalanceInfoBean balInfoBean = debitArrayList.get(i);
						data_Object.currAcctChgAmt = (int) balInfoBean.amountToDeduct;
						negativeConverter(data_Object); // convert into negative value
						logger.info("##>>msisdn[" + data_Object.msisdn + "] Balancebean[" + balInfoBean + "]");
						data_Object.accId = balInfoBean.getAccId();
						// debit transfer amount from A party msisdn
						resp = request.debitAccount(data_Object, "DEBIT");
						if (resp != 1) {
							respDesc.append(",TALKTIME TRANSFER DEBIT TRANSFER AMOUNT NOT SUCCESS");
							logger.info("##>>msisdn[" + data_Object.msisdn + "] accId[" + data_Object.accId
									+ "] response from talkTimeAccount debit not success [" + resp + "] for amount["
									+ data_Object.currAcctChgAmt + "]");
						} else if (resp == 1) {
							respDesc.append(",TALKTIME TRANSFER DEBIT TRANSFER AMOUNT SUCCESS");
							logger.info("##>>msisdn[" + data_Object.msisdn + "] accId[" + data_Object.accId
									+ "] response from talkTimeAccount debit success [" + resp + "] for amount["
									+ data_Object.currAcctChgAmt + "]");
						}
					} // end for loop

					if (resp == 1) {
						resp = -1;
						// debit transfer amount from A party msisdn successfully
						data_Object.currAcctChgAmt = data_Object.creditcurrAcctamount;
						// positiveConverter(data_Object); //no need to convert into positive already in
						// positive
						if (data_Object.getAccType().equalsIgnoreCase(ServiceTypes.OFF_NET)) {
							data_Object.accId = Global.OffNetCreditAccount;
						} else if (data_Object.getAccType().equalsIgnoreCase(ServiceTypes.ON_NET)) {
							data_Object.accId = Global.onNetCreditAccount;
						} else if (data_Object.getAccType().equalsIgnoreCase(ServiceTypes.EURO_OFF_NET)) {
							data_Object.accId = Global.euroOffNetCreditAccount;
						}
						// credit into B party msisdn account
						resp = request.creditAccount(data_Object, "CREDIT");
						if (resp != 1) {
							respDesc.append(",TALKTIME TRANSFER CREDIT TRANSFER AMOUNT NOT SUCCESS");
							logger.info("##>>msisdn[" + data_Object.msisdn + "] accId[" + data_Object.accId
									+ "]  fmsisdn[" + data_Object.fmsisdn
									+ "] response from talkTimeAccount credit not success [" + resp + "]");
						} else if (resp == 1) {
							respDesc.append(",TALKTIME TRANSFER CREDIT TRANSFER AMOUNT SUCCESS");
							logger.info("##>>msisdn[" + data_Object.msisdn + "] accId[" + data_Object.accId
									+ "]  fmsisdn[" + data_Object.fmsisdn
									+ "] response from talkTimeAccount debit success [" + resp + "]");
						}
					} else {
						resp = -1;
					}
				}
			} else if (data_Object.getServiceType().equalsIgnoreCase(ServiceTypes.DATA_TRANSFER)) {
				data_Object.desc = "DATA";
				logger.info("###>>msisdn[" + data_Object.msisdn + "] going for Data Transfer, ServiceType["
						+ data_Object.getServiceType() + "] desc[" + data_Object.desc + "]");
				ArrayList<BalanceInfoBean> balanceList = new ArrayList<BalanceInfoBean>();
				ArrayList<BalanceInfoBean> debiList = new ArrayList<BalanceInfoBean>();
				data_Object.index = 0;
				// going to call check balance
				resp = -1;
				debitAcctExists = -1;
				// resp = request.checkBalance(data_Object, balanceList);
				resp = request.checkBalanceDiameter(data_Object, balanceList);
				if (resp == 1) {
					respDesc.append("CHECK BALANCE SUCCESS");
					resp = -1;
					// check that user eligible or not for transfer
					resp = checkEligibilty(data_Object, balanceList);
					logger.info("##>>msisdn[" + data_Object.msisdn + "] response from checkEligibilty[" + resp + "]");
					if (resp == 1) {
						// check debit account exists in balanceList or not
						respDesc.append(",UESR IS ELIGIBLE FOR TRANSFER");

						debitAcctExists = toCheckTranferBalance(data_Object, balanceList, debiList);
						logger.info("##>>msisdn[" + data_Object.msisdn + "] response from toCheckTranferBalance["
								+ debitAcctExists + "]");
						if (debitAcctExists != -1) {
							respDesc.append(",DATA TRANSFER DEBIT ACCOUNT EXISTS");
							resp = -1;
							if (data_Object.acc_2000_balance >= data_Object.serviceAmount) {
								data_Object.deductAmount = (int) data_Object.serviceAmount;
								// debit tarnsfer service amount from main account
								resp = request.deductBlnce(data_Object);
								logger.info("##>>msisdn[" + data_Object.msisdn + "] response from  deductBlnce [" + resp
										+ "]");
								if (resp != 1) {
									respDesc.append(",DEDUCTION FROM MAIN ACCOUNT FAIL");
									resp = -1;
								}
							} else {
								respDesc.append(",USER HAS LOW MAIN BALANCE");
								resp = -2;
							}
						} else {
							respDesc.append(",DATA TRANSFER DEBIT ACCOUNT NOT EXISTS");
							resp = -3;
						}
					} else {
						respDesc.append(",USER IS NOT ELIGIBLE FOR TRANSFER");

					}
				} else {
					respDesc.append("CHECK BALANCE NOT SUCCESS");
				}

				if (resp == 1) {
					// debit from main account successfully
					respDesc.append(",DEDUCTION FROM MAIN ACCOUNT SUCCESS");
					resp = -1;
					for (int i = 0; i < debiList.size(); i++) {
						BalanceInfoBean balanceInfoBean = debiList.get(i);
						logger.info("##>>msisdn[" + data_Object.msisdn + "] Balancebean[" + balanceInfoBean + "]");
						data_Object.currAcctChgAmt = (int) balanceInfoBean.amountToDeduct;
						negativeConverter(data_Object); // convert into negative value
						data_Object.accId = balanceInfoBean.getAccId();
						// debit transfer amount from A party msisdn
						resp = request.debitAccount(data_Object, "DEBIT");
						if (resp != 1) {
							respDesc.append(",DATA TRANSFER DEBIT TRANSFER AMOUNT NOT SUCCESS");
							logger.info("##>>msisdn[" + data_Object.msisdn + "] accId[" + data_Object.accId
									+ "] response from data transfer debit not success[" + resp + "] for amount["
									+ data_Object.currAcctChgAmt + "]");
						} else if (resp == 1) {
							respDesc.append(",DATA TRANSFER DEBIT TRANSFER AMOUNT SUCCESS");
							logger.info("##>>msisdn[" + data_Object.msisdn + "] accId[" + data_Object.accId
									+ "] response from data transfer debit success[" + resp + "] for amount["
									+ data_Object.currAcctChgAmt + "]");
						}
					}

					if (resp == 1) {
						resp = -1;
						resp = request.packPurchaseForGift(data_Object);
						if (resp != 1) {
							respDesc.append(",PACK NOT PURCHASED SUCCESSFULLY");
						} else if (resp == 1) {
							respDesc.append(",PACK PURCHASED SUCCESSFULLY");
						}
						logger.info("##>>msisdn[" + data_Object.msisdn + "] fmsisdn[" + data_Object.fmsisdn
								+ "] response from  packPurchaseForGift[" + resp + "]");

					} else {
						resp = -1;
					}
				}

			} else if (data_Object.getServiceType().equalsIgnoreCase(ServiceTypes.BONUS_TRANSFER)) {
				data_Object.desc = "GIFT";
				logger.info("###>>msisdn[" + data_Object.msisdn + "] Going for Gift, ServiceType["
						+ data_Object.getServiceType() + "] desc[" + data_Object.desc + "]");
				ArrayList<BalanceInfoBean> balanceList = new ArrayList<BalanceInfoBean>();
				data_Object.index = 0;
				resp = -1;
				debitAcctExists = -1;
				// going to call check balance
				// resp = request.checkBalance(data_Object, balanceList);
				resp = request.checkBalanceDiameter(data_Object, balanceList);

				logger.info("##>>msisdn[" + data_Object.msisdn + "] response from checkBalance[" + resp + "]");
				if (resp == 1) {
					respDesc.append("CHECK BALANCE SUCCESS");
					resp = -1;
					if (data_Object.acc_2000_balance >= (data_Object.serviceAmount + data_Object.currAcctChgAmt)) {
						data_Object.deductAmount = (int) (data_Object.serviceAmount + data_Object.currAcctChgAmt);
						// debit service amount from A party msisdn
						resp = request.deductBlnce(data_Object);
						logger.info("##>>msisdn[" + data_Object.msisdn + "] response from  deductBlnce [" + resp + "]");
						if (resp != 1) {
							respDesc.append(",DEDUCTION FROM MAIN ACCOUNT FAIL");
							// write log into file
							resp = -1;
						}

					} else {
						respDesc.append(",USER HAS LOW MAIN BALANCE");
						resp = -2;
					}

				} else {
					respDesc.append("CHECK BALANCE NOT SUCCESS");

				}

				if (resp == 1) {
					resp = -1;
					respDesc.append(",DEDUCTION FROM MAIN ACCOUNT SUCCESS");
					resp = request.packPurchaseForGift(data_Object);
					if (resp != 1) {
						respDesc.append(",PACK NOT PURCHASED SUCCESSFULLY");
					} else if (resp == 1) {
						respDesc.append(",PACK PURCHASED SUCCESSFULLY");
					}
					logger.info("msisdn[" + data_Object.msisdn + "] fmsisdn[" + data_Object.fmsisdn
							+ "] response from packPurchaseForGift[" + resp + "]");
				}

			} // end of bonus Transfer
			else if (data_Object.getServiceType().equalsIgnoreCase(ServiceTypes.CHECK_BALANCE)) {
				ArrayList<BalanceInfoBean> balaList = new ArrayList<BalanceInfoBean>();
				data_Object.index = 0;
				logger.info("###>>msisdn[" + data_Object.msisdn + "] going for CheckBalance, ServiceType["
						+ data_Object.getServiceType() + "]");
				//System.out.println("###>>msisdn[" + data_Object.msisdn + "] going for CheckBalance, ServiceType["
						//+ data_Object.getServiceType() + "]");
				// resp = request.checkBalance(data_Object, balaList);
				resp = request.checkBalanceDiameter(data_Object, balaList);
				for (int i = 0; i < balaList.size(); i++) {
					BalanceInfoBean bean = balaList.get(i);
					logger.info("##msisdn[" + data_Object.msisdn + "] BalanceBeans[" + bean + "]");

				}
			} else if (data_Object.getServiceType().equalsIgnoreCase(ServiceTypes.DEDUCT_BALANCE)) {
				data_Object.index = 0;
				logger.info("###>>msisdn[" + data_Object.msisdn + "] Going for Deduct Balance, ServiceType["
						+ data_Object.getServiceType() + "]");
				resp = request.deductBlnce(data_Object);
			} else if (data_Object.getServiceType().equalsIgnoreCase(ServiceTypes.PACK_PURHCASE)) {
				data_Object.index = 0;
				logger.info("###>>msisdn[" + data_Object.msisdn + "] Going for Purchase Pack, ServiceType["
						+ data_Object.getServiceType() + "]");
				if (Global.checkBalanceForPackEnable == 1) {
					ArrayList<BalanceInfoBean> balance = new ArrayList<BalanceInfoBean>();
					logger.debug("##msisdn[" + data_Object.msisdn + "] Going to check balance");
					 //resp = request.checkBalance(data_Object, balance);
					resp = request.checkBalanceDiameter(data_Object, balance);
					if (resp == 1) {
						respDesc.append("CHECK BALANCE SUCCESS");
						resp = -1;
						if (data_Object.acc_2000_balance >= data_Object.deductAmount) {
							resp = request.packPurchase(data_Object);
							if (resp != 1) {
								respDesc.append(",PACK NOT PURCHASED SUCCESSFULLY");
							} else if (resp == 1) {
								respDesc.append(",PACK PURCHASED SUCCESSFULLY");
							}

						} else {
							respDesc.append(",USER HAS LOW MAIN BALANCE");
							resp = -2;
						}
					} else {
						respDesc.append("CHECK BALANCE NOT SUCCESS");
						//resp = -1;
						resp = 99;
					}
				} else {
					logger.debug("##msisdn[" + data_Object.msisdn + "] check balance not enable for pack");
					resp = request.packPurchase(data_Object);
				}
			} else if (data_Object.getServiceType().equalsIgnoreCase(ServiceTypes.CHECK_TRANSFER_BALANCE)) {

				logger.info("###>>msisdn[" + data_Object.msisdn + "] going to Check Transfer Balance ServiceType["
						+ data_Object.getServiceType() + "]");
				ArrayList<BalanceInfoBean> balanceList = new ArrayList<BalanceInfoBean>();
				ArrayList<BalanceInfoBean> debitArrayList = new ArrayList<BalanceInfoBean>();
				// going to call check balance
				data_Object.index = 0;
				resp = -1;
				debitAcctExists = -1;
				// resp = request.checkBalance(data_Object, balanceList);
				resp = request.checkBalanceDiameter(data_Object, balanceList);
				if (resp == 1) {
					respDesc.append("CHECK TRANSFER BALANCE SUCCESS");

					// to check debit account in balanceList exists or not
					if (data_Object.getAcc_2000_balance() >= data_Object.serviceAmount) {
						debitAcctExists = checkTranferBalance(data_Object, balanceList, debitArrayList);
						logger.info("##>>msisdn[" + data_Object.msisdn + "] response from checkTranferBalance["
								+ debitAcctExists + "]");
						if (debitAcctExists != -1) {
							respDesc.append(",DEBIT ACCOUNT EXISTS");
							resp = 1;
						} else {
							respDesc.append(",DEBIT ACCOUNT NOT EXISTS");
							resp = -3;
						}
					} else {
						respDesc.append(",USER HAS LOW MAIN BALANCE");
						resp = -2;
					}
				} else {
					respDesc.append("CHECK BALANCE NOT SUCCESS");
					resp = -1;
				}
			} else if (data_Object.getServiceType().equalsIgnoreCase(ServiceTypes.CHECK_DT_ELIGIBILITY)) {
				ArrayList<BalanceInfoBean> balanceList = new ArrayList<BalanceInfoBean>();

				logger.info(
						"###>>msisdn[" + data_Object.msisdn + "] going to Check Data Transfer Eligibility, ServiceType["
								+ data_Object.getServiceType() + "]");
				// going to call check balance
				data_Object.index = 0;
				resp = -1;
				// resp = request.checkBalance(data_Object, balanceList);
				resp = request.checkBalanceDiameter(data_Object, balanceList);
				logger.info("##>msisdn[" + data_Object.msisdn + "] response from checkBalance[" + resp + "]");

				if (resp == 1) {
					respDesc.append("CHECK BALANCE SUCCESS");
					resp = -1;
					resp = checkEligibilty(data_Object, balanceList);
					if (resp != 1) {
						respDesc.append(",USER IS NOT ELIGIBILE FOR TRANSFER");
						logger.info(
								"##>msisdn[" + data_Object.msisdn + "] response from checkEligibilty[" + resp + "]");
					} else {
						respDesc.append(",USER IS ELIGIBILE FOR TRANSFER");
						logger.info(
								"##>msisdn[" + data_Object.msisdn + "] response from checkEligibilty[" + resp + "]");
					}

				} else {
					respDesc.append("CHECK BALANCE NOT SUCCESS");
					resp = -1;
				}

			} else if (data_Object.getServiceType().equalsIgnoreCase(ServiceTypes.DATA_MACRO_CREDIT)) {
				// Added By SIDDHARTH for Data Macro Credit Service
				data_Object.desc = "DMC";

				logger.info("###>>msisdn[" + data_Object.msisdn + "] going for Data Macro Creidt Service, ServiceType["
						+ data_Object.getServiceType() + "] desc[" + data_Object.desc + "]");
				ArrayList<BalanceInfoBean> balanceList = new ArrayList<BalanceInfoBean>();

				data_Object.index = 0;

				resp = -1;

				// going to call check balance
				// resp = request.checkBalance(data_Object, balanceList);
				resp = request.checkBalanceDiameter(data_Object, balanceList);
				if (resp == 1) {
					respDesc.append("CHECK BALANCE SUCCESS");
					resp = -1;
					if (data_Object.acc_2000_balance >= data_Object.serviceAmount) {
						data_Object.deductAmount = (int) data_Object.serviceAmount;
						// debit tarnsfer service amount from main account
						resp = request.deductBlnce(data_Object);
						logger.info("##>>msisdn[" + data_Object.msisdn + "] response from  deductBlnce [" + resp + "]");
						if (resp != 1) {
							logger.info("##>>msisdn[" + data_Object.msisdn + "] DEDUCTION FROM MAIN ACCOUNT FAIL.");
							respDesc.append(",DEDUCTION FROM MAIN ACCOUNT FAIL");
							resp = -1;
						}
					} else {
						logger.info("##>>msisdn[" + data_Object.msisdn + "] user has LOW MAIN BALANCE.");
						respDesc.append(",USER HAS LOW MAIN BALANCE");
						resp = -2;
					}
				} else {
					logger.info("##>>msisdn[" + data_Object.msisdn + "] CHECK BALANCE NOT SUCCESS.");
					respDesc.append("CHECK BALANCE NOT SUCCESS");
				}

				if (resp == 1) {
					// debit from main account successfully
					respDesc.append(",DEDUCTION FROM MAIN ACCOUNT SUCCESS");
					resp = -1;

					// Setting DMC account Id
					data_Object.accId = Global.dataMacroCreditAccount;

					// credit into A party msisdn account
					resp = request.creditAccount(data_Object, "CREDIT");
					if (resp != 1) {
						respDesc.append(",DATA MACRO CREDIT NOT SUCCESS");
						logger.info("##>>msisdn[" + data_Object.msisdn + "] accId[" + data_Object.accId + "] response ["
								+ resp + "] from creditAccount not success");

					} else if (resp == 1) {
						respDesc.append(",DATA MACRO CREDIT SUCCESS");
						logger.info("##>>msisdn[" + data_Object.msisdn + "] accId[" + data_Object.accId + "] response ["
								+ resp + "] from creditAccount success");
					}
				}
			} else {
				logger.error("##>>msisdn[" + data_Object.msisdn + "] Service Type [" + data_Object.getServiceType()
						+ "] found is not configured in Charging.");
			}

			// writing log into FileBase Logging
			synchronized (this) {
				Global.activity_flw.writeLog("MSISDN[" + data_Object.msisdn + "], TRANSACTION ID[" + data_Object.transId
						+ "],JSON[" + Arrays.toString(data_Object.responseArray) + "],FINAL RESPONSE["
						+ respDesc.toString() + "]");
			}
		} catch (Exception exp) {
			logger.error("Exception occur in doCharging() method. Exception:" + exp.getMessage());
			exp.printStackTrace();
			return -1;
		}
		logger.info("##>>method doCharging End here databean[" + data_Object + "]");
		return resp;
	}

	/**
	 * This method convert positive number into negative
	 * 
	 * @param data_Object
	 * @return void
	 */
	public void negativeConverter(Data_Object data_Object) {
		data_Object.currAcctChgAmt = (~(data_Object.currAcctChgAmt - 1));
		logger.info(
				"##>>msisdn[" + data_Object.msisdn + "] For Debit currAcctChgAmt[" + data_Object.currAcctChgAmt + "]");
	}

	/**
	 * This method convert negative number into positive number.
	 * 
	 * @param data_Object
	 * @return void
	 */
	public void positiveConverter(Data_Object data_Object) {

		data_Object.currAcctChgAmt = ~(data_Object.currAcctChgAmt - 1);
		logger.info(
				"##>>msisdn[" + data_Object.msisdn + "] For Credit currAcctChgAmt[" + data_Object.currAcctChgAmt + "]");
	}

	/**
	 * This method check that user have enough balance for current transition or
	 * not.
	 * 
	 * @param balArrayList
	 * @param deductionArr
	 * @return 1,-1
	 */
	public int toCheckTranferBalance(Data_Object data_Object, ArrayList<BalanceInfoBean> balArrayList,
			ArrayList<BalanceInfoBean> deductionArr) {
		long amountToBeDeduct = data_Object.currAcctChgAmt;
		long volumeBalance = 0;
		for (int i = 0; i < balArrayList.size(); i++) {
			BalanceInfoBean balInfoBean = balArrayList.get(i);
			if (data_Object.getServiceType().equalsIgnoreCase(ServiceTypes.TALK_TIME_TRANSFER)) {
				if (data_Object.getAccType().equalsIgnoreCase(ServiceTypes.OFF_NET)) {
					if (Global.offNetDebitList.contains(balInfoBean.getAccId().trim())) {
						logger.info("##>>msisdn[" + data_Object.msisdn + "] AccExits inside Global.offNetDebitList["
								+ balInfoBean.getAccId() + "]");
						if (balInfoBean.getBalance() > 0) {
							if (amountToBeDeduct > balInfoBean.getBalance()) {
								amountToBeDeduct = amountToBeDeduct - balInfoBean.getBalance();
								balInfoBean.amountToDeduct = balInfoBean.getBalance();
								volumeBalance += balInfoBean.getBalance();
							} else {
								balInfoBean.amountToDeduct = amountToBeDeduct;
								amountToBeDeduct = 0;
								volumeBalance += balInfoBean.getBalance();
							}

							logger.info("##>>msisdn[" + data_Object.msisdn
									+ "] can use as debit for OFF_NET account because balance is["
									+ balInfoBean.getBalance() + "] and transfer amount is["
									+ data_Object.getCurrAcctChgAmt() + "]");
							data_Object.setVolumeBalance(volumeBalance);
							deductionArr.add(balInfoBean);
							if (amountToBeDeduct <= 0) {
								Collections.sort(deductionArr, new ExpiryDateComparator());
								return 1;
							}
						} else {
							logger.info("##>>msisdn[" + data_Object.msisdn
									+ "] cannot use as debit for OFF_NET  account because balance is["
									+ balInfoBean.getBalance() + "] and transfer amount is["
									+ data_Object.getCurrAcctChgAmt() + "]");
							continue;
						}
					} else {
						logger.info(
								"##>>msisdn[" + data_Object.msisdn + "]  Acc Not Exists inside Global.offNetDebitList["
										+ balInfoBean.getAccId() + "] so continue");
						continue;
					}
				} else if (data_Object.getAccType().equalsIgnoreCase(ServiceTypes.ON_NET)) {
					if (Global.onNetDebitList.contains(balInfoBean.getAccId().trim())) {
						logger.info("##>>msisdn[" + data_Object.msisdn + "] AccExits inside Global.onNetDebitList["
								+ balInfoBean.getAccId() + "]");
						if (balInfoBean.getBalance() > 0) {
							logger.info("##>>msisdn[" + data_Object.msisdn
									+ "] can use as debit  for ON_NET  account because balance is["
									+ balInfoBean.getBalance() + "] and transfer amount is["
									+ data_Object.getCurrAcctChgAmt() + "]");

							if (amountToBeDeduct > balInfoBean.getBalance()) {
								amountToBeDeduct = amountToBeDeduct - balInfoBean.getBalance();
								balInfoBean.amountToDeduct = balInfoBean.getBalance();
								volumeBalance += balInfoBean.getBalance();
							} else {
								balInfoBean.amountToDeduct = amountToBeDeduct;
								amountToBeDeduct = 0;
								volumeBalance += balInfoBean.getBalance();
							}

							logger.debug("##>>msisdn[" + data_Object.msisdn
									+ "] can use as debit for ON_NET account because balance is["
									+ balInfoBean.getBalance() + "] and transfer amount is["
									+ data_Object.getCurrAcctChgAmt() + "]");
							deductionArr.add(balInfoBean);
							data_Object.setVolumeBalance(volumeBalance);
							if (amountToBeDeduct <= 0) {
								Collections.sort(deductionArr, new ExpiryDateComparator());
								return 1;
							}
						} else {
							logger.info("##>>msisdn[" + data_Object.msisdn
									+ "] cannot use as debit for ON_NET  account because balance is["
									+ balInfoBean.getBalance() + "] and transfer amount is["
									+ data_Object.getCurrAcctChgAmt() + "]");
							continue;
						}
					} else {
						logger.info(
								"##>>msisdn[" + data_Object.msisdn + "] Acc not Exits  inside Global.onNetDebitList["
										+ balInfoBean.getAccId() + "] so continue");
						continue;
					}
				} else if (data_Object.getAccType().equalsIgnoreCase(ServiceTypes.EURO_OFF_NET)) {
					if (Global.euroOffNetDebitAccounts.contains(balInfoBean.getAccId().trim())) {
						logger.info("##>>msisdn[" + data_Object.msisdn + "] AccExits inside Global.onNetDebitList["
								+ balInfoBean.getAccId() + "]");
						if (balInfoBean.getBalance() > 0) {
							logger.info("##>>msisdn[" + data_Object.msisdn
									+ "] can use as debit  for ON_NET  account because balance is["
									+ balInfoBean.getBalance() + "] and transfer amount is["
									+ data_Object.getCurrAcctChgAmt() + "]");

							if (amountToBeDeduct > balInfoBean.getBalance()) {
								amountToBeDeduct = amountToBeDeduct - balInfoBean.getBalance();
								balInfoBean.amountToDeduct = balInfoBean.getBalance();
								volumeBalance += balInfoBean.getBalance();
							} else {
								balInfoBean.amountToDeduct = amountToBeDeduct;
								amountToBeDeduct = 0;
								volumeBalance += balInfoBean.getBalance();
							}

							logger.debug("##>>msisdn[" + data_Object.msisdn
									+ "] can use as debit for OFF_NET account because balance is["
									+ balInfoBean.getBalance() + "] and transfer amount is["
									+ data_Object.getCurrAcctChgAmt() + "]");
							data_Object.setVolumeBalance(volumeBalance);
							deductionArr.add(balInfoBean);
							if (amountToBeDeduct <= 0) {
								Collections.sort(deductionArr, new ExpiryDateComparator());
								return 1;
							}
						} else {
							logger.info("##>>msisdn[" + data_Object.msisdn
									+ "] cannot use as debit for ON_NET  account because balance is["
									+ balInfoBean.getBalance() + "] and transfer amount is["
									+ data_Object.getCurrAcctChgAmt() + "]");
							continue;
						}
					} else {
						logger.info(
								"##>>msisdn[" + data_Object.msisdn + "] Acc not Exits  inside Global.onNetDebitList["
										+ balInfoBean.getAccId() + "] so continue");
						continue;
					}
				}
			} else if (data_Object.getServiceType().equalsIgnoreCase(ServiceTypes.DATA_TRANSFER)) {
				if (Global.dataDebitList.contains(balInfoBean.getAccId().trim())) {
					logger.info("##>>msisdn[" + data_Object.msisdn
							+ "] AccExists inside Global.bounsDebitList for debit[" + balInfoBean.getAccId() + "]");
					if (balInfoBean.getBalance() > 0) {
						logger.info("##>>msisdn[" + data_Object.msisdn
								+ "] can use as debit  for data Transfer account because balance is["
								+ balInfoBean.getBalance() + "] and transfer amount is["
								+ data_Object.getCurrAcctChgAmt() + "]");
						if (amountToBeDeduct > balInfoBean.getBalance()) {
							amountToBeDeduct = amountToBeDeduct - balInfoBean.getBalance();
							balInfoBean.amountToDeduct = balInfoBean.getBalance();
							volumeBalance += balInfoBean.getBalance();
						} else {
							balInfoBean.amountToDeduct = amountToBeDeduct;
							amountToBeDeduct = 0;
							volumeBalance += balInfoBean.getBalance();
						}

						logger.debug("##>>msisdn[" + data_Object.msisdn
								+ "] can use as debit for data transfer account because balance is["
								+ balInfoBean.getBalance() + "] and transfer amount is["
								+ data_Object.getCurrAcctChgAmt() + "]");
						data_Object.setVolumeBalance(volumeBalance);
						deductionArr.add(balInfoBean);
						if (amountToBeDeduct <= 0) {
							Collections.sort(deductionArr, new ExpiryDateComparator());
							return 1;
						} else {
							logger.info("##>>msisdn[" + data_Object.msisdn
									+ "] cannot use as debit for data transfer account because balance is["
									+ balInfoBean.getBalance() + "] and transfer amount is["
									+ data_Object.getCurrAcctChgAmt() + "]");
							continue;
						}
					} else {
						continue;
					}

				}
			} else if (data_Object.getServiceType().equalsIgnoreCase(ServiceTypes.BONUS_TRANSFER)) {
				if (Global.bounsDebitList.contains(balInfoBean.getAccId().trim())) {
					logger.info("##>>msisdn[" + data_Object.msisdn
							+ "] AccExists inside Global.bounsDebitList for debit[" + balInfoBean.getAccId() + "]");
					if (balInfoBean.getBalance() > 0) {
						logger.info("##>>msisdn[" + data_Object.msisdn
								+ "] can use as debit  for bouns account because balance is[" + balInfoBean.getBalance()
								+ "] and transfer amount is[" + data_Object.getCurrAcctChgAmt() + "]");
						if (amountToBeDeduct > balInfoBean.getBalance()) {
							amountToBeDeduct = amountToBeDeduct - balInfoBean.getBalance();
							balInfoBean.amountToDeduct = balInfoBean.getBalance();
							volumeBalance += balInfoBean.getBalance();
						} else {
							balInfoBean.amountToDeduct = amountToBeDeduct;
							amountToBeDeduct = 0;
							volumeBalance += balInfoBean.getBalance();
						}

						logger.debug("##>>msisdn[" + data_Object.msisdn
								+ "] can use as debit for bonus account because balance is[" + balInfoBean.getBalance()
								+ "] and transfer amount is[" + data_Object.getCurrAcctChgAmt() + "]");
						deductionArr.add(balInfoBean);
						data_Object.setVolumeBalance(volumeBalance);
						if (amountToBeDeduct <= 0) {
							Collections.sort(deductionArr, new ExpiryDateComparator());
							return 1;
						}
					} else {
						logger.info("##>>msisdn[" + data_Object.msisdn
								+ "] cannot use as debit for bouns account because balance is["
								+ balInfoBean.getBalance() + "] and transfer amount is["
								+ data_Object.getCurrAcctChgAmt() + "]");
						continue;
					}
				} else {
					continue;
				}

			}

		}
		return -1;
	}

	/**
	 * This method also provide information regarding user have enough balance for
	 * transfer or not.
	 * 
	 * @param balArrayList
	 * @param deductionArr
	 * @return 1,-1
	 */
	//// CHECK_TRANSFER_BALANCE
	public int checkTranferBalance(Data_Object data_Object, ArrayList<BalanceInfoBean> balArrayList,
			ArrayList<BalanceInfoBean> deductionArr) {
		long amountToBeDeduct = data_Object.currAcctChgAmt;
		long volumeBalance = 0;
		for (int i = 0; i < balArrayList.size(); i++) {
			BalanceInfoBean balInfoBean = balArrayList.get(i);
			if (data_Object.getAccType().equalsIgnoreCase(ServiceTypes.OFF_NET)) {
				if (Global.offNetDebitList.contains(balInfoBean.getAccId().trim())) {
					logger.info("##>>msisdn[" + data_Object.msisdn + "] AccExits inside Global.offNetDebitList["
							+ balInfoBean.getAccId() + "]");
					if (balInfoBean.getBalance() > 0) {
						if (amountToBeDeduct > balInfoBean.getBalance()) {
							amountToBeDeduct = amountToBeDeduct - balInfoBean.getBalance();
							balInfoBean.amountToDeduct = balInfoBean.getBalance();
							volumeBalance += balInfoBean.getBalance();
						} else {
							balInfoBean.amountToDeduct = amountToBeDeduct;
							amountToBeDeduct = 0;
							volumeBalance += balInfoBean.getBalance();
						}

						logger.info("##>>msisdn[" + data_Object.msisdn
								+ "] can use as debit for OFF_NET account because balance is["
								+ balInfoBean.getBalance() + "] and transfer amount is["
								+ data_Object.getCurrAcctChgAmt() + "]");
						deductionArr.add(balInfoBean);
						data_Object.setVolumeBalance(volumeBalance);
						if (amountToBeDeduct <= 0) {
							Collections.sort(deductionArr, new ExpiryDateComparator());
							return 1;
						}
					} else {
						logger.info("##>>msisdn[" + data_Object.msisdn
								+ "] cannot use as debit for OFF_NET  account because balance is["
								+ balInfoBean.getBalance() + "] and transfer amount is["
								+ data_Object.getCurrAcctChgAmt() + "]");
						continue;
					}
				} else {
					logger.info("##>>msisdn[" + data_Object.msisdn + "]  Acc Not Exists inside Global.offNetDebitList["
							+ balInfoBean.getAccId() + "] so continue");
					continue;
				}
			} else if (data_Object.getAccType().equalsIgnoreCase(ServiceTypes.ON_NET)) {
				if (Global.onNetDebitList.contains(balInfoBean.getAccId().trim())) {
					logger.info("##>>msisdn[" + data_Object.msisdn + "] AccExits inside Global.onNetDebitList["
							+ balInfoBean.getAccId() + "]");
					if (balInfoBean.getBalance() > 0) {
						logger.info("##>>msisdn[" + data_Object.msisdn
								+ "] can use as debit  for ON_NET  account because balance is["
								+ balInfoBean.getBalance() + "] and transfer amount is["
								+ data_Object.getCurrAcctChgAmt() + "]");

						if (amountToBeDeduct > balInfoBean.getBalance()) {
							amountToBeDeduct = amountToBeDeduct - balInfoBean.getBalance();
							balInfoBean.amountToDeduct = balInfoBean.getBalance();
							volumeBalance += balInfoBean.getBalance();
						} else {
							balInfoBean.amountToDeduct = amountToBeDeduct;
							amountToBeDeduct = 0;
							volumeBalance += balInfoBean.getBalance();
						}

						logger.debug("##>>msisdn[" + data_Object.msisdn
								+ "] can use as debit for ON_NET account because balance is[" + balInfoBean.getBalance()
								+ "] and transfer amount is[" + data_Object.getCurrAcctChgAmt() + "]");
						deductionArr.add(balInfoBean);
						data_Object.setVolumeBalance(volumeBalance);
						if (amountToBeDeduct <= 0) {
							Collections.sort(deductionArr, new ExpiryDateComparator());
							return 1;
						}
					} else {
						logger.info("##>>msisdn[" + data_Object.msisdn
								+ "] cannot use as debit for ON_NET  account because balance is["
								+ balInfoBean.getBalance() + "] and transfer amount is["
								+ data_Object.getCurrAcctChgAmt() + "]");
						continue;
					}
				} else {
					logger.info("##>>msisdn[" + data_Object.msisdn + "] Acc not Exits  inside Global.onNetDebitList["
							+ balInfoBean.getAccId() + "] so continue");
					continue;
				}
			} else if (data_Object.getAccType().equalsIgnoreCase(ServiceTypes.EURO_OFF_NET)) {
				if (Global.euroOffNetDebitAccounts.contains(balInfoBean.getAccId().trim())) {
					logger.info("##>>msisdn[" + data_Object.msisdn + "] AccExits inside Global.onNetDebitList["
							+ balInfoBean.getAccId() + "]");
					if (balInfoBean.getBalance() > 0) {
						logger.info("##>>msisdn[" + data_Object.msisdn
								+ "] can use as debit  for ON_NET  account because balance is["
								+ balInfoBean.getBalance() + "] and transfer amount is["
								+ data_Object.getCurrAcctChgAmt() + "]");

						if (amountToBeDeduct > balInfoBean.getBalance()) {
							amountToBeDeduct = amountToBeDeduct - balInfoBean.getBalance();
							balInfoBean.amountToDeduct = balInfoBean.getBalance();
							volumeBalance += balInfoBean.getBalance();
						} else {
							balInfoBean.amountToDeduct = amountToBeDeduct;
							amountToBeDeduct = 0;
							volumeBalance += balInfoBean.getBalance();
						}

						logger.debug("##>>msisdn[" + data_Object.msisdn
								+ "] can use as debit for OFF_NET account because balance is["
								+ balInfoBean.getBalance() + "] and transfer amount is["
								+ data_Object.getCurrAcctChgAmt() + "]");
						deductionArr.add(balInfoBean);
						data_Object.setVolumeBalance(volumeBalance);
						if (amountToBeDeduct <= 0) {
							Collections.sort(deductionArr, new ExpiryDateComparator());
							return 1;
						}
					} else {
						logger.info("##>>msisdn[" + data_Object.msisdn
								+ "] cannot use as debit for ON_NET  account because balance is["
								+ balInfoBean.getBalance() + "] and transfer amount is["
								+ data_Object.getCurrAcctChgAmt() + "]");
						continue;
					}
				} else {
					logger.info("##>>msisdn[" + data_Object.msisdn + "] Acc not Exits  inside Global.onNetDebitList["
							+ balInfoBean.getAccId() + "] so continue");
					continue;
				}
			} else if (data_Object.getAccType().equalsIgnoreCase(ServiceTypes.DATA)) {
				if (Global.dataDebitList.contains(balInfoBean.getAccId().trim())) {
					logger.info("##>>msisdn[" + data_Object.msisdn
							+ "] AccExists inside Global.bounsDebitList for debit[" + balInfoBean.getAccId() + "]");
					if (balInfoBean.getBalance() > 0) {
						logger.info("##>>msisdn[" + data_Object.msisdn
								+ "] can use as debit  for data Transfer account because balance is["
								+ balInfoBean.getBalance() + "] and transfer amount is["
								+ data_Object.getCurrAcctChgAmt() + "]");
						if (amountToBeDeduct > balInfoBean.getBalance()) {
							amountToBeDeduct = amountToBeDeduct - balInfoBean.getBalance();
							balInfoBean.amountToDeduct = balInfoBean.getBalance();
							volumeBalance += balInfoBean.getBalance();
						} else {
							balInfoBean.amountToDeduct = amountToBeDeduct;
							amountToBeDeduct = 0;
							volumeBalance += balInfoBean.getBalance();
						}

						logger.debug("##>>msisdn[" + data_Object.msisdn
								+ "] can use as debit for data transfer account because balance is["
								+ balInfoBean.getBalance() + "] and transfer amount is["
								+ data_Object.getCurrAcctChgAmt() + "]");
						deductionArr.add(balInfoBean);
						data_Object.setVolumeBalance(volumeBalance);
						if (amountToBeDeduct <= 0) {
							Collections.sort(deductionArr, new ExpiryDateComparator());
							return 1;
						} else {
							logger.info("##>>msisdn[" + data_Object.msisdn
									+ "] cannot use as debit for data transfer account because balance is["
									+ balInfoBean.getBalance() + "] and transfer amount is["
									+ data_Object.getCurrAcctChgAmt() + "]");
							continue;
						}
					} else {
						continue;
					}

				}
			} else if (data_Object.getAccType().equalsIgnoreCase(ServiceTypes.GIFT)) {
				if (Global.bounsDebitList.contains(balInfoBean.getAccId().trim())) {
					logger.info("##>>msisdn[" + data_Object.msisdn
							+ "] AccExists inside Global.bounsDebitList for debit[" + balInfoBean.getAccId() + "]");
					if (balInfoBean.getBalance() > 0) {
						logger.info("##>>msisdn[" + data_Object.msisdn
								+ "] can use as debit  for bouns account because balance is[" + balInfoBean.getBalance()
								+ "] and transfer amount is[" + data_Object.getCurrAcctChgAmt() + "]");
						if (amountToBeDeduct > balInfoBean.getBalance()) {
							amountToBeDeduct = amountToBeDeduct - balInfoBean.getBalance();
							balInfoBean.amountToDeduct = balInfoBean.getBalance();
							volumeBalance += balInfoBean.getBalance();
						} else {
							balInfoBean.amountToDeduct = amountToBeDeduct;
							amountToBeDeduct = 0;
							volumeBalance += balInfoBean.getBalance();
						}

						logger.debug("##>>msisdn[" + data_Object.msisdn
								+ "] can use as debit for bonus account because balance is[" + balInfoBean.getBalance()
								+ "] and transfer amount is[" + data_Object.getCurrAcctChgAmt() + "]");
						deductionArr.add(balInfoBean);
						data_Object.setVolumeBalance(volumeBalance);
						if (amountToBeDeduct <= 0) {
							Collections.sort(deductionArr, new ExpiryDateComparator());
							return 1;
						}
					} else {
						logger.info("##>>msisdn[" + data_Object.msisdn
								+ "] cannot use as debit for bouns account because balance is["
								+ balInfoBean.getBalance() + "] and transfer amount is["
								+ data_Object.getCurrAcctChgAmt() + "]");
						continue;
					}
				} else {
					continue;
				}

			}

		}
		return -1;
	}

	public int checkEligibilty(Data_Object data_Object, ArrayList<BalanceInfoBean> baArrayList) {
		logger.debug("##>>msisdn[" + data_Object.msisdn + "] inside checkEligibilty for Data Transfer...");
		try {
			for (int i = 0; i < baArrayList.size(); i++) {
				BalanceInfoBean balInfoBean = baArrayList.get(i);
				if (data_Object.getAccType().equalsIgnoreCase(ServiceTypes.DATA)) {
					if (Global.dataDebitList.contains(balInfoBean.getAccId().trim())) {
						logger.info("##>>msisdn[" + data_Object.msisdn + "] Account  exits in data debit list["
								+ balInfoBean.getAccId() + "] so can continue ..");
						return 1;
					} else {
						logger.info("##>>msisdn[" + data_Object.msisdn + "] Account not exits data debit list["
								+ balInfoBean.getAccId() + "]");
					}
				}
			}
		} catch (Exception exp) {
			exp.printStackTrace();
			return -9;
		}
		return -9;
	}
}
