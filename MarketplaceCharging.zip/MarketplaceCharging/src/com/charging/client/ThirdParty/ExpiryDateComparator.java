package com.charging.client.ThirdParty;

import java.util.Comparator;

/**
 * This class provide the functionality of comparator provide all expiry date in
 * decreasing order.
 * 
 * @author SIDDHARTH SINGH RAWAT
 *
 */
public class ExpiryDateComparator implements Comparator<BalanceInfoBean> {

	/**
	 * This method is used to compare and used in sorting of BalanceInfoBean
	 * according to the expiry data.
	 */
	public int compare(BalanceInfoBean bean1, BalanceInfoBean bean2) {
		return -(bean1.expiryTime.compareTo(bean2.expiryTime));
	}

}
