package com.charging.client.ThirdParty;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import org.apache.log4j.Logger;

import com.charging.client.DiameterRequest;
import com.charging.client.activation.PackageActivation;
import com.charging.client.activation.Param;
import com.charging.client.activation.ParamList;
import com.charging.client.activation.Trade;
import com.charging.client.bouns.AdjustAccountResult;
import com.charging.client.bouns.Bouns;
import com.charging.client.bouns.ResultHeader;
import com.charging.client.deduct.AcctChgRec;
import com.charging.client.deduct.Deduct;
import com.charging.client.reqbal.BalanceRecord;
import com.charging.client.reqbal.RequestBean;
import com.charging.client.talktimeanddata.TalkTimeAndDataTransfer;
import com.google.gson.Gson;

/**
 * This class provide methods to hit gateway API and got response in JSON
 * format.
 * 
 * @author SIDDHARTH
 */
public class ThirdPartyRequest {
	static private Logger logger = Logger.getLogger("ThirdPartyRequest");

	public ThirdPartyRequest() {
	}

	/**
	 * This method is used to get all the balance details of requested msisdn and
	 * fill that details in provided ArrayList. This method also set the main
	 * account balance for requested msisdn.
	 * 
	 * @param data_object
	 * @param balList
	 * @author SIDDHARTH
	 * @return 1,-1
	 **/
	@Deprecated
	public int checkBalance(Data_Object data_object, ArrayList<BalanceInfoBean> balList) {
		String msisdn = data_object.msisdn;
		int checkBalance = -1;

		String output = null;
		try {
			output = getBalance(msisdn);
			if (output.equalsIgnoreCase("Error")) {
				return -1; // Error occurred
			}
		} catch (Exception e) {
			e.printStackTrace();
			return -1; // Error occurred
		}

		if (data_object.index > 0) {
			data_object.responseArray[++data_object.index] = "CHECK_BALANCE";
			data_object.responseArray[++data_object.index] = output;
		} else {
			data_object.responseArray[data_object.index] = "CHECK_BALANCE";
			data_object.responseArray[++data_object.index] = output;
		}

		Gson gson = new Gson();

		logger.info("##>>msisdn[" + data_object.msisdn + "] CheckBalance JSON[" + output + "]");
		RequestBean data = gson.fromJson(output, RequestBean.class);
		logger.info("##>>msisdn[" + data_object.msisdn + "] Response contains Code:[" + data.getResult().getCode()
				+ "] Status :[" + data.getResult().getStatus() + "] for check balance.");

		int accountType = -1;
		long accountType_2000_Balance = 0;
		boolean isMainAcountAvailable = false;
		data_object.accountDetailInfoTable=new Hashtable<Integer,BalanceInfoBean>();
		long bal = 0;
		for (BalanceRecord record : data.getResult().getData().getBalanceRecord()) {
			accountType = Integer.parseInt(record.getAccountType());
			logger.info("##>>msisdn[" + data_object.msisdn + "] AccountType :[" + accountType + "] Balance :["
					+ record.getBalance() + "]");
			bal = Long.parseLong(record.getBalance());
			BalanceInfoBean balInfoBean = new BalanceInfoBean();
			balInfoBean.setAccId(accountType + "");
			balInfoBean.setBalance(bal);
			balInfoBean.setExpiryTime(record.getExpireTime());
			balList.add(balInfoBean);
			
			
			/*
			 * changes by Ashu 
			 * 19-oct-2021 #8335
			 */
			
			data_object.accountDetailInfoTable.put(accountType, balInfoBean);
			/*
			  */
			if (bal < 0) {
				bal = 0;
			}

			if (accountType == 2000) {
				accountType_2000_Balance = bal;
				isMainAcountAvailable = true;
			} else if (accountType == 2001) {
				data_object.acc_2001_balance = bal;
			} else if (accountType == 5018) {
				data_object.acc_5018_balance = bal;
			} else if (accountType == 5017) {
				data_object.acc_5017_balance = bal;
			} else if (accountType == 5016) {
				data_object.acc_5016_balance = bal;
			}
			checkBalance = 1;
		}
		// Sorting BalanceInfoBean according to the ExpiryData
		Collections.sort(balList, new ExpiryDateComparator());
		if (isMainAcountAvailable) {
			data_object.balance = accountType_2000_Balance;
			data_object.acc_2000_balance = accountType_2000_Balance;
			checkBalance = 1;
		}

		return checkBalance;
	}

	/**
	 * This method is used to get all the balance details of requested msisdn and
	 * fill that details in provided ArrayList. This method also set the main
	 * account balance for requested msisdn using diameter.
	 * 
	 * @param data_object
	 * @param balList
	 * @author SIDDHARTH
	 * @return 1(for success)/-1(for failure)
	 */
	public int checkBalanceDiameter(Data_Object data_object, ArrayList<BalanceInfoBean> balList) {
		String msisdn = data_object.getMsisdn();
		int checkBalance = -1;
		int output = -1;
		try {
			logger.info("##>>msisdn [" + data_object.getMsisdn() + "] Going to fetch user balance details.");
			// System.out.println("##>>msisdn [" + data_object.getMsisdn() + "] Going to
			// fetch user balance details.");
			output = DiameterRequest.getDiameterInstance().checkBalanceRequest(msisdn, checkBalance, data_object, -1,
					"-1", "-1", balList);

			// Sorting BalanceInfoBean according to the ExpiryData
			Collections.sort(balList, new ExpiryDateComparator());

			if (data_object.index > 0) {
				data_object.responseArray[++data_object.index] = "CHECK_BALANCE";
				data_object.responseArray[++data_object.index] = balList.toString();
			} else {
				data_object.responseArray[data_object.index] = "CHECK_BALANCE";
				data_object.responseArray[++data_object.index] = balList.toString();
			}

			// System.out.println("##>>msisdn" + msisdn + "Result of checkBalanceDiameter["
			// + output
			// + "] and balance info list size [" + balList.size() + "]");
			logger.info("##>>msisdn" + msisdn + "Result of checkBalanceDiameter[" + output + "] and balance info list ["
					+ balList + "]");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}

	/**
	 * This method used to deduct user main balance.
	 * 
	 * @param data_object
	 * @return 1,-1
	 */
	public int deductBlnce(Data_Object data_object) {
		int result = -1;
		logger.info("Going to deduct balance ##>>msisdn[" + data_object.msisdn + "] deductAmount["
				+ data_object.deductAmount + "] desc[" + data_object.desc + "]");
		String output = deductBalance(data_object.msisdn, data_object.deductAmount, data_object.desc);
		if (output.equalsIgnoreCase("Exception")) {
			return -1; // Error occurred
		}

		if (data_object.index > 0) {
			data_object.responseArray[++data_object.index] = "DEDUCT_BALANCE";
			data_object.responseArray[++data_object.index] = output;

		} else {
			data_object.responseArray[data_object.index] = "DEDUCT_BALANCE";
			data_object.responseArray[++data_object.index] = output;

		}

		Bouns resultData = null;
		ResultHeader header = null;
		Gson gson = new Gson();
		logger.info("##>>msisdn[" + data_object.msisdn + "] deduct main balance Json[" + output + "]");
		Deduct data = gson.fromJson(output, Deduct.class);

		resultData = gson.fromJson(output, Bouns.class);

		if (resultData != null) {
			header = resultData.getResult().getData().getResultHeader();
		} else {
			result = -1;
			logger.error("##>>msisdn[" + data_object.msisdn
					+ "] result header found null in deduct balance hit so returning result [" + result + "].");
			return result;
		}

		logger.info("##>>msisdn[" + data_object.msisdn + "] Response contains Code:[" + data.getResult().getCode()
				+ "] Status :[" + data.getResult().getStatus() + "] for deduct main balance hit.");
		if (data.getResult().getStatus().equalsIgnoreCase("Success")) {

			logger.info("##>>msisdn[" + data_object.msisdn + "] Deduct Main Balance Response contains Code:["
					+ data.getResult().getCode() + "] Status :[" + data.getResult().getStatus()
					+ "] header :  ResultCode[" + header.getResultCode() + "] ResultDesc[" + header.getResultDesc()
					+ "] from deductBlnce method.");

			if (header.getResultDesc().equalsIgnoreCase("Operation is successful.")) {
				logger.info("##>>msisdn[" + data_object.msisdn + "]Dedut Main Balance is successful");
				result = 1;
			} else {
				logger.info("##>>msisdn[" + data_object.msisdn + "]Dedut Main Balance failure with Result Description ["
						+ header.getResultDesc() + "]");
				result = -1;

			}

			// result = 1;
		}
		AcctChgRec acctChgRec = data.getResult().getData().getAcctChgRec();
		if (acctChgRec != null) {
			showAcctChgResult(acctChgRec, data_object.msisdn, data_object.fmsisdn);
		} else {
			logger.info("##>>msisdn[" + data_object.msisdn + "] acctChgRec Found Null");
		}
		return result;
	}

	/**
	 * This is the method used to purchase requested pack
	 * 
	 * @param data_object
	 * @return 1,-1
	 */
	public int packPurchase(Data_Object data_object) {
		int result = -1;
		String serviceType = ServiceTypes.SERVICE_TYPE_PACK_PURCHASE;
		logger.info("Going to activate package ##>>msisdn[" + data_object.msisdn + "] productCode["
				+ data_object.productCode + "]");

		String output = activatePackage(data_object.msisdn, data_object.fmsisdn, data_object.productCode, serviceType);
		if (output.equalsIgnoreCase("Exception")) {
			return -1;
		}

		if (data_object.index > 0) {
			data_object.responseArray[++data_object.index] = "PACK_PURCHASE";
			data_object.responseArray[++data_object.index] = output;

		} else {
			data_object.responseArray[data_object.index] = "PACK_PURCHASE";
			data_object.responseArray[++data_object.index] = output;

		}
		Gson gson = new Gson();
		logger.info("##>>msisdn[" + data_object.msisdn + "] PackPurchase Json[" + output + "]");
		PackageActivation data = gson.fromJson(output, PackageActivation.class);
		logger.info("##>>msisdn[" + data_object.msisdn + "] Response contains Code:[" + data.getResult().getCode()
				+ "] Status :[" + data.getResult().getStatus() + "] for purchas pack.");
		if (data.getResult().getStatus().equalsIgnoreCase("Success")) {
			result = 1;
		}
		Trade trade = data.getResult().getData().getTrade();
		if (trade != null) {
			result = showActivatePackageResponse(trade, data_object);
		}
		return result;
	}

	/**
	 * This method used to purchase pack as gift for B party. Modified by SIDDHARTH
	 * 
	 * @param data_object
	 * @return 1,-1
	 */
	public int packPurchaseForGift(Data_Object data_object) {
		int result = -1;
		String serviceType = ServiceTypes.SERVICE_TYPE_GIFT;
		logger.info("Going to activate package for Gift ##>>msisdn[" + data_object.msisdn + "]  fmsisdn["
				+ data_object.fmsisdn + "] productCode[" + data_object.productCode + "] serviceType[" + serviceType
				+ "]");
		String output = activatePackage(data_object.msisdn, data_object.fmsisdn, data_object.productCode, serviceType);

		if (output.equalsIgnoreCase("Exception")) {
			return -1;
		}

		if (data_object.index > 0) {
			data_object.responseArray[++data_object.index] = "PACK_PURCHASE_FOR_GIFT";
			data_object.responseArray[++data_object.index] = output;

		} else {
			data_object.responseArray[data_object.index] = "PACK_PURCHASE_FOR_GIFT";
			data_object.responseArray[++data_object.index] = output;

		}
		Gson gson = new Gson();
		logger.info("##>>msisdn[" + data_object.msisdn + "] fmsisdn[" + data_object.fmsisdn
				+ "] PackPurchase For Gift Json[" + output + "]");
		PackageActivation data = gson.fromJson(output, PackageActivation.class);
		logger.info("##>>msisdn[" + data_object.msisdn + "] fmsisdn[" + data_object.fmsisdn
				+ "] Response contains Code:[" + data.getResult().getCode() + "] Status :["
				+ data.getResult().getStatus() + "] for purchase pack");
		if (data.getResult().getStatus().equalsIgnoreCase("Success")) {
			result = 1;
		}
		Trade trade = data.getResult().getData().getTrade();
		if (trade != null) {
			result = showActivatePackageResponse(trade, data_object);
		}
		return result;
	}

	/**
	 * This method used to debit transfer amount from A party accounts. Modified by
	 * SIDDHARTH
	 * 
	 * @param data_object
	 * @param action
	 * @return 1,-1
	 */
	public int debitAccount(Data_Object data_object, String action) {
		int result = -1;

		// long to support large data (SID)
		long deductAmount = -1;

		String output = null;
		if (data_object.getServiceType().equalsIgnoreCase(ServiceTypes.DATA_TRANSFER)) {
			deductAmount = (data_object.currAcctChgAmt / 100);
		} else {
			deductAmount = data_object.currAcctChgAmt;
		}
		logger.info("Going to bonus deduct ##>>msisdn[" + data_object.msisdn + "] action[" + action + "] accId["
				+ data_object.accId + "] transferAmount[" + data_object.currAcctChgAmt + "] debuctAmount/100 ["
				+ deductAmount + "] desc [" + data_object.desc + "]");
		if (action.equalsIgnoreCase("DEBIT")) {
			output = bonusAndDataTransfer(data_object.msisdn, deductAmount, data_object.accId, data_object.desc);
		}

		if (output.equalsIgnoreCase("Exception")) {
			return -1;
		}

		if (data_object.index > 0) {
			data_object.responseArray[++data_object.index] = "VOLUME_DEBIT";
			data_object.responseArray[++data_object.index] = output;

		} else {
			data_object.responseArray[data_object.index] = "VOLUME_DEBIT";
			data_object.responseArray[++data_object.index] = output;

		}

		Gson gson = new Gson();
		logger.info("##>>msisdn[" + data_object.msisdn + "] Bouns Json[" + output + "] from debitAccount() method.");
		Bouns data = null;
		ResultHeader header = null;
		com.charging.client.bounsArray.Bouns daBouns = null;
		com.charging.client.bounsArray.ResultHeader daheader = null;

		try {
			daBouns = null;
			data = gson.fromJson(output, Bouns.class);
			header = data.getResult().getData().getResultHeader();
		} catch (Exception exp) {
			data = null;
			daBouns = gson.fromJson(output, com.charging.client.bounsArray.Bouns.class);
			daheader = daBouns.getResult().getData().getResultHeader();
		}
		if (data != null) {

			logger.info("##>>msisdn[" + data_object.msisdn + "] Response contains Code:[" + data.getResult().getCode()
					+ "] Status :[" + data.getResult().getStatus() + "] header : ResultCode[" + header.getResultCode()
					+ "] ResultDesc[" + header.getResultDesc() + "] from debitAccount() method.");
			if (data.getResult().getStatus().equalsIgnoreCase("Success")) {

				if (header.getResultDesc().equalsIgnoreCase("Operation is successful.")) {
					result = 1;
					AdjustAccountResult adjustment = data.getResult().getData().getAdjustAccountResult();
					if (adjustment != null) {
						result = showAdjustMentResult(adjustment, data_object.msisdn, data_object.fmsisdn);
					}
				} else {
					result = -1;
					logger.info("#.#>>msisdn[" + data_object.msisdn + "] Response contains Code:["
							+ data.getResult().getCode() + "] Status :[" + data.getResult().getStatus()
							+ "] header :  ResultCode[" + header.getResultCode() + "] ResultDesc["
							+ header.getResultDesc() + "] from debitAccount() method.");
				}
			}
		} else if (daBouns != null) {

			logger.info("##>>msisdn[" + data_object.msisdn + "] Response contains Code:["
					+ daBouns.getResult().getCode() + "] Status :[" + daBouns.getResult().getStatus()
					+ "] header : ResultCode[" + daheader.getResultCode() + "] ResultDesc[" + daheader.getResultDesc()
					+ "] from debitAccount() method.");
			if (daBouns.getResult().getStatus().equalsIgnoreCase("Success")) {

				if (daheader.getResultDesc().equalsIgnoreCase("Operation is successful.")) {
					result = 1;
					com.charging.client.bounsArray.AdjustAccountResult adjustment = daBouns.getResult().getData()
							.getAdjustAccountResult();
					if (adjustment != null) {
						result = showAdjustMentResultArray(adjustment, data_object.msisdn, data_object.fmsisdn);
					}
				} else {
					result = -1;
					logger.info("#.#>>msisdn[" + data_object.msisdn + "] Response contains Code:["
							+ daBouns.getResult().getCode() + "] Status :[" + daBouns.getResult().getStatus()
							+ "] header :  ResultCode[" + daheader.getResultCode() + "] ResultDesc["
							+ daheader.getResultDesc() + "] from debitAccount() method.");
				}
			}

		}
		return result;
	}

	/**
	 * This method used to credit the user account data and account expiry date.
	 * Modified by SIDDHARTH.
	 * 
	 * @param data_object
	 * @param action
	 * @return 1,-1
	 */
	public int creditAccount(Data_Object data_object, String action) {
		int result = -1;
		logger.info("Going for Credit account ##>>msisdn[" + data_object.msisdn + "] fmsisdn[" + data_object.fmsisdn
				+ "] serviceType[" + data_object.getServiceType() + "] action[" + action + "] accId["
				+ data_object.accId + "] TransferAmount[" + data_object.currAcctChgAmt + "] nb_day["
				+ data_object.nb_day + "] desc [" + data_object.desc + "]");
		String output = null;
		long accCreditChargingAmount = 0l;
		String respArrActionType = "VOLUME_CREDIT";
		if (action.equalsIgnoreCase("CREDIT")) {

			if (data_object.getServiceType().equalsIgnoreCase(ServiceTypes.DATA_MACRO_CREDIT)) {
				respArrActionType = "DATA_CREDIT";
				String desc = Global.additionalInfoInChargingForMacroData;
				// Setting account credit charging amount
				accCreditChargingAmount = (data_object.currAcctChgAmt / 100);
				output = adjustAccountDest(data_object.msisdn, data_object.msisdn, accCreditChargingAmount,
						data_object.accId, data_object.nb_day, desc);
			} else {
				accCreditChargingAmount = data_object.currAcctChgAmt;
				output = talkTimeTransfer(data_object.msisdn, data_object.fmsisdn, accCreditChargingAmount,
						data_object.accId, data_object.nb_day, data_object.desc);
			}

		}

		if (output.equalsIgnoreCase("Exception")) {
			return -1;
		}

		if (data_object.index > 0) {
			data_object.responseArray[++data_object.index] = respArrActionType;
			data_object.responseArray[++data_object.index] = output;
		} else {
			data_object.responseArray[data_object.index] = respArrActionType;
			data_object.responseArray[++data_object.index] = output;
		}

		Gson gson = new Gson();
		logger.info("##>>msisdn[" + data_object.msisdn + "] SERVICE_TYPE[" + data_object.serviceType + "] Json["
				+ output + "] for credit account hit.");
		TalkTimeAndDataTransfer data = null;
		com.charging.client.talktimeanddata.ResultHeader header = null;
		com.charging.client.bounsArray.Bouns daBouns = null;
		com.charging.client.bounsArray.ResultHeader daheader = null;

		try {
			daBouns = null;
			data = gson.fromJson(output, TalkTimeAndDataTransfer.class);
			header = data.getResult().getData().getResultHeader();
		} catch (Exception exp) {
			data = null;
			daBouns = gson.fromJson(output, com.charging.client.bounsArray.Bouns.class);
			daheader = daBouns.getResult().getData().getResultHeader();
		}
		if (data != null) {
			logger.info("##>>msisdn[" + data_object.msisdn + "] Response contains Code:[" + data.getResult().getCode()
					+ "] Status :[" + data.getResult().getStatus() + "] ResultCode[" + header.getResultCode()
					+ "] ResultDesc[" + header.getResultDesc() + "] for creditAccount where ServiceType["
					+ data_object.getServiceType() + "]");
			if (data.getResult().getStatus().equalsIgnoreCase("Success")) {
				if (header.getResultDesc().equalsIgnoreCase("Operation is successful.")) {
					result = 1;
					com.charging.client.talktimeanddata.AdjustAccountResult adjustment = data.getResult().getData()
							.getAdjustAccountResult();
					if (adjustment != null) {
						result = showAdjustMentTalkTimeResults(adjustment, data_object.msisdn, data_object.fmsisdn);
					}
				} else {
					result = -1;
					logger.info("##>>msisdn[" + data_object.msisdn + "] Response contains Code:["
							+ data.getResult().getCode() + "] Status :[" + data.getResult().getStatus()
							+ "] header : ResultCode[" + header.getResultCode() + "] ResultDesc["
							+ header.getResultDesc() + "] for creditAccount where ServiceType["
							+ data_object.getServiceType() + "]");

				}
			}
		} else if (daBouns != null) {

			logger.info("##>>msisdn[" + data_object.msisdn + "] Response contains Code:["
					+ daBouns.getResult().getCode() + "] Status :[" + daBouns.getResult().getStatus()
					+ "] header : ResultCode[" + daheader.getResultCode() + "] ResultDesc[" + daheader.getResultDesc()
					+ "] for creditAccount where ServiceType[" + data_object.getServiceType() + "]");
			if (daBouns.getResult().getStatus().equalsIgnoreCase("Success")) {

				if (daheader.getResultDesc().equalsIgnoreCase("Operation is successful.")) {
					result = 1;
					com.charging.client.bounsArray.AdjustAccountResult adjustment = daBouns.getResult().getData()
							.getAdjustAccountResult();
					if (adjustment != null) {
						result = showAdjustMentResultArray(adjustment, data_object.msisdn, data_object.fmsisdn);
					}
				} else {
					result = -1;
					logger.info("#.#>>msisdn[" + data_object.msisdn + "] Response contains Code:["
							+ daBouns.getResult().getCode() + "] Status :[" + daBouns.getResult().getStatus()
							+ "] header :  ResultCode[" + daheader.getResultCode() + "] ResultDesc["
							+ daheader.getResultDesc() + "] for creditAccount where ServiceType["
							+ data_object.getServiceType() + "]");
				}
			}
		}

		return result;
	}

	/**
	 * This method is used to credit or debit from the user existing account. It
	 * interact with the gateway API by HTTP (POST request) and provide a JSON
	 * response for requested msisdn.
	 * 
	 * @param msisdn
	 * @param adjustAccountMsisdn
	 * @param currAcctChgAmt
	 * @param accType
	 * @param noOfdays
	 * 
	 * @author SIDDHARTH
	 * @return JSONString
	 */
	private String adjustAccountDest(String msisdn, String adjustAccountMsisdn, long currAcctChgAmt, String accType,
			int noOfdays, String desc) {
		logger.info("###>>msisdn[" + msisdn
				+ "] inside adjustAccountDest() method for adjusting account with adjustAccountMsisdn["
				+ adjustAccountMsisdn + "] currAcctChgAmt[" + currAcctChgAmt + "] accType[" + accType + "] desc[" + desc
				+ "]");
		StringBuffer response = new StringBuffer();
		try {
			String packageURL = Global.adjustAccountUrl;
			URL url = new URL(packageURL);
			HttpURLConnection httpcon = (HttpURLConnection) url.openConnection();

			httpcon.setReadTimeout(Global.conn_read_timeout);
			httpcon.setConnectTimeout(Global.gateway_request_timeout);
			httpcon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			httpcon.setRequestProperty("Accept", "application/json");
			httpcon.setRequestMethod("POST");
			httpcon.setDoInput(true);
			httpcon.setDoOutput(true);

			HashMap<String, String> postParams = new HashMap<String, String>();
			postParams.put(HttpUrlConnectionParam.MSISDN, adjustAccountMsisdn);
			postParams.put(HttpUrlConnectionParam.SIGNATURE, Global.signature);
			// currAcctChgAmt : positive for credit, negative for debit
			postParams.put(HttpUrlConnectionParam.CURR_ACC_CHARGING_AMOUNT, currAcctChgAmt + "");
			postParams.put(HttpUrlConnectionParam.ACCOUNT_TYPE, accType);
			postParams.put(HttpUrlConnectionParam.NB_DAY, noOfdays + "");
			postParams.put(HttpUrlConnectionParam.ADDITIONAL_INFO, desc);

			OutputStream os = httpcon.getOutputStream();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
			writer.write(getURLEncodedDataString(postParams));
			writer.flush();
			writer.close();
			os.close();

			int responseCode = httpcon.getResponseCode();
			logger.info(
					"##>>msisdn[" + msisdn + "] responseCode :[" + responseCode + "] form adjustAccountDest() method.");
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line;
				BufferedReader br = new BufferedReader(new InputStreamReader(httpcon.getInputStream()));
				while ((line = br.readLine()) != null) {
					response.append(line);
				}
			} else {
				response.append("Exception");
			}
			logger.info("##>>msisdn[" + msisdn + "] adjustAccountMsisdn[" + adjustAccountMsisdn + "] response ::: ["
					+ response + "] form adjustAccountDest() method.");
		} catch (Exception e) {
			return "Exception";
		}
		return response.toString();
	}

	/**
	 * This method used to make GET hit url for each request , with encoding.
	 * 
	 * @param params
	 * @return {@link String}
	 */
	private static String getURLEncodedDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
		StringBuilder result = new StringBuilder();
		boolean first = true;
		for (Map.Entry<String, String> entry : params.entrySet()) {
			if (first)
				first = false;
			else
				result.append("&");

			result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
			result.append("=");
			result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
		}
		return result.toString();
	}

	/**
	 * This method show activate package response.
	 * 
	 * @param trade
	 * @param data_Object
	 * @return 1,-1
	 */
	private int showActivatePackageResponse(Trade trade, Data_Object data_Object) {
		int result = -1;
		try {
			ParamList paramList = trade.getParamList();
			logger.info("##>>msisdn[" + data_Object.msisdn + "] fmsisdn[" + data_Object.fmsisdn + "] SN :["
					+ trade.getSystem().getSN() + "] , messageType :[" + trade.getSystem().getMessageType()
					+ "], cmdCode:[" + trade.getSystem().getCmdCode() + "], operationID :[" + paramList.getOperationID()
					+ "], retCode :[" + paramList.getRetCode() + "], desc :[" + paramList.getDesc() + "]");
						
			if(trade.getParamList().getRetCode().equalsIgnoreCase("0"))
			{
				result=1;
			}
			else
			{
				try
				{
					result=Integer.parseInt(trade.getParamList().getRetCode());
				}
				catch(Exception e)
				{
					logger.error(">>>Msisdn[" + data_Object.getMsisdn()
							+ "] Exception occurred while getting ret Code while pack purchasing..." + e);
				}
				
			}
			
			
		} catch (Exception exp) {
			exp.printStackTrace();
			result = 99;
		}
		return result;
	}

	/**
	 * This method show debit transfer amount response
	 * 
	 * @param adjustment
	 * @param msisdn
	 * @param fmsisdn
	 * @return 1,-1
	 */
	private int showAdjustMentResult(com.charging.client.bouns.AdjustAccountResult adjustment, String msisdn,
			String fmsisdn) {
		int result = -1;
		try {
			com.charging.client.bouns.AcctChgRec acctrec = adjustment.getAcctChgRec();

			logger.info("##>>debit from transfer account msisdn[" + msisdn + "] fmsisdn[" + fmsisdn + "] AccountID :["
					+ acctrec.getAccountID() + "] AccountType :[" + acctrec.getAccountType() + "] ChgAcctBal :["
					+ acctrec.getChgAcctBal() + "]" + "ChgExpTime :[" + acctrec.getChgExpTime() + "] CurrAcctBal :["
					+ acctrec.getCurrAcctBal() + "]" + "CurrExpTime :[" + acctrec.getCurrExpTime() + "] MinMeasureId :["
					+ acctrec.getMinMeasureId() + "]");

			result = 1;
		} catch (Exception exp) {
			exp.printStackTrace();
			result = -1;
		}
		return result;
	}

	/**
	 * This method show debit transfer amount response
	 * 
	 * @param adjustment
	 * @param msisdn
	 * @param fmsisdn
	 * @return 1,-1
	 */
	private int showAdjustMentResultArray(com.charging.client.bounsArray.AdjustAccountResult adjustment, String msisdn,
			String fmsisdn) {
		int result = -1;
		try {
			com.charging.client.bounsArray.AcctChgRec[] acctrecList = adjustment.getAcctChgRec();
			for (com.charging.client.bounsArray.AcctChgRec acctrec : acctrecList) {

				logger.info("##>>debit from transfer account msisdn[" + msisdn + "] fmsisdn[" + fmsisdn
						+ "] AccountID :[" + acctrec.getAccountID() + "] AccountType :[" + acctrec.getAccountType()
						+ "] ChgAcctBal :[" + acctrec.getChgAcctBal() + "]" + "ChgExpTime :[" + acctrec.getChgExpTime()
						+ "] CurrAcctBal :[" + acctrec.getCurrAcctBal() + "]" + "CurrExpTime :["
						+ acctrec.getCurrExpTime() + "] MinMeasureId :[" + acctrec.getMinMeasureId() + "]");
			}

			result = 1;
		} catch (Exception exp) {
			exp.printStackTrace();
			result = -1;
		}
		return result;
	}

	/**
	 * This method show debit transfer amount response
	 * 
	 * @param adjustment
	 * @param msisdn
	 * @param fmsisdn
	 * @return 1,-1
	 */
	private int showAdjustMentTalkTimeResults(com.charging.client.talktimeanddata.AdjustAccountResult adjustment,
			String msisdn, String fmsisdn) {
		int result = -1;
		try {
			com.charging.client.talktimeanddata.AcctChgRec acctrecList = adjustment.getAcctChgRec();
			logger.info("##>>credit TTT Result msisdn[" + msisdn + "] fmsisdn[" + fmsisdn + "] AccountID :["
					+ acctrecList.getAccountID() + "] AccountType :[" + acctrecList.getAccountType() + "] ChgAcctBal :["
					+ acctrecList.getChgAcctBal() + "]" + "ChgExpTime :[" + acctrecList.getChgExpTime()
					+ "] CurrAcctBal :[" + acctrecList.getCurrAcctBal() + "]" + "CurrExpTime :["
					+ acctrecList.getCurrExpTime() + "] MinMeasureId :[" + acctrecList.getMinMeasureId() + "]");

			result = 1;
		} catch (Exception exp) {
			exp.printStackTrace();
			result = -1;
		}
		return result;
	}

	/**
	 * This method is used to show the response of debit main account hit.
	 * 
	 * @param acctChgRec
	 * @param msisdn
	 * @param fmsisdn
	 * @return 1,-1
	 */
	private int showAcctChgResult(AcctChgRec acctChgRec, String msisdn, String fmsisdn) {
		int result = -1;
		try {

			logger.info("##>>debit from Main account msisdn[" + msisdn + "]  fmsisdn[" + fmsisdn + "] AccountID :["
					+ acctChgRec.getAccountID() + "] AccountType :[" + acctChgRec.getAccountType() + "] ChgAcctBal :["
					+ acctChgRec.getChgAcctBal() + "]" + "ChgExpTime :[" + acctChgRec.getChgExpTime()
					+ "] CurrAcctBal :[" + acctChgRec.getCurrAcctBal() + "]" + "CurrExpTime :["
					+ acctChgRec.getCurrExpTime() + "] MinMeasureId :[" + acctChgRec.getMinMeasureId() + "]");
			result = 1;
		} catch (Exception exp) {
			exp.printStackTrace();
			result = -1;
		}
		return result;
	}

	/**
	 * This method is used to interact with the gateway API by HTTP (POST request)
	 * and provide a JSON response of all the balance details of requested msisdn.
	 * 
	 * @param msisdn
	 * 
	 * @author SIDDHARTH
	 * @return JSONString
	 * 
	 */
	public String getBalance(String msisdn) {
		logger.info("###>>msisdn[" + msisdn + "] inside getBalance() method Going to all user balances.");
		StringBuffer response = new StringBuffer();
		try {

			String reqBalURL = Global.getBalanceUrl;

			URL url = new URL(reqBalURL);

			HashMap<String, String> postParam = new HashMap<String, String>();
			postParam.put(HttpUrlConnectionParam.MSISDN, msisdn);
			postParam.put(HttpUrlConnectionParam.SIGNATURE, Global.signature);

			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setReadTimeout(Global.conn_read_timeout);
			conn.setConnectTimeout(Global.gateway_request_timeout);
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestMethod("POST");
			conn.setDoInput(true);
			conn.setDoOutput(true);

			OutputStream os = conn.getOutputStream();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
			writer.write(getURLEncodedDataString(postParam));
			writer.flush();
			writer.close();
			os.close();

			int responseCode = conn.getResponseCode();
			logger.info("##>>msisdn[" + msisdn + "]  responseCode:[" + responseCode + "] for getBalance.");
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line;
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				while ((line = br.readLine()) != null) {
					response.append(line);
				}
			} else {
				logger.error("##>>msisdn[" + msisdn + "] Failed : HTTP error code " + conn.getResponseCode());
				throw new RuntimeException("Failed : HTTP error code " + conn.getResponseCode());
			}

		} catch (MalformedURLException e) {
			e.printStackTrace();
			response.append("Error");

		} catch (IOException e) {
			e.printStackTrace();
			response.append("Error");
		} catch (Exception exp) {
			exp.printStackTrace();
			response.append("Error");
		}
		return response.toString();
	}

	/**
	 * This method is used to deduct main balance of requested msisndn. This method
	 * interact with the gateway API by HTTP (POST request) and provide a JSON
	 * response.
	 * 
	 * @param msisdn
	 * @param deductAmount
	 * @param desc
	 * 
	 * @author SIDDHARTH
	 * @return JSONString
	 */
	private String deductBalance(String msisdn, int deductAmount, String desc) {
		logger.info("###>>msisdn[" + msisdn
				+ "] Inside deductBalance() method Going to deduct the main balance of requested msisdn with deductAmount ["
				+ deductAmount + "].");
		StringBuffer response = new StringBuffer();
		try {
			String packageURL = Global.deductBalanceUrl;
			URL url = new URL(packageURL);

			HashMap<String, String> postParam = new HashMap<String, String>();
			postParam.put(HttpUrlConnectionParam.MSISDN, msisdn);
			postParam.put(HttpUrlConnectionParam.SIGNATURE, Global.signature);
			postParam.put(HttpUrlConnectionParam.DEDUCT_AMOUNT, deductAmount + "");
			postParam.put(HttpUrlConnectionParam.ADDITIONAL_INFO, desc);

			HttpURLConnection httpcon = (HttpURLConnection) url.openConnection();

			httpcon.setReadTimeout(Global.conn_read_timeout);
			httpcon.setConnectTimeout(Global.gateway_request_timeout);
			httpcon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			httpcon.setRequestProperty("Accept", "application/json");
			httpcon.setRequestMethod("POST");
			httpcon.setDoInput(true);
			httpcon.setDoOutput(true);

			OutputStream os = httpcon.getOutputStream();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
			writer.write(getURLEncodedDataString(postParam));
			writer.flush();
			writer.close();
			os.close();

			int responseCode = httpcon.getResponseCode();
			logger.info("##>>msisdn[" + msisdn + "] responseCode :[" + responseCode + "] for main account deduction.");
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line;
				BufferedReader br = new BufferedReader(new InputStreamReader(httpcon.getInputStream()));
				while ((line = br.readLine()) != null) {
					response.append(line);
				}
			} else {
				response.append("Exception");
			}
			logger.info("##>>msisdn[" + msisdn + "] response ::: [" + response + "] for main account deduction.");
		} catch (Exception e) {
			return "Exception";
		}
		return response.toString();

	}

	/**
	 * This method is used to credit the Talk time Transfer Account. This method
	 * interact with the gateway API by HTTP (POST request) and provide a JSON
	 * response.
	 * 
	 * @param msisdn
	 * @param fmsisdn
	 * @param currAcctChgAmt
	 * @param accType
	 * @param noOfdays
	 * 
	 * @author SIDDHARTH
	 * @return jsonString
	 */
	private String talkTimeTransfer(String msisdn, String fmsisdn, long currAcctChgAmt, String accType, int noOfdays,
			String desc) {
		logger.info("###>>msisdn[" + msisdn + "] inside talkTimeTransfer() method for adjusting account with ["
				+ currAcctChgAmt + "] accType[" + accType + "] noOfdays[" + noOfdays + "] desc[" + desc + "]");

		StringBuffer response = new StringBuffer();
		try {
			String packageURL = Global.talkTimeDebitCreditUrl;
			URL url = new URL(packageURL);
			HttpURLConnection httpcon = (HttpURLConnection) url.openConnection();

			httpcon.setReadTimeout(Global.conn_read_timeout);
			httpcon.setConnectTimeout(Global.gateway_request_timeout);
			httpcon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			httpcon.setRequestProperty("Accept", "application/json");
			httpcon.setRequestMethod("POST");
			httpcon.setDoInput(true);
			httpcon.setDoOutput(true);

			HashMap<String, String> postParams = new HashMap<String, String>();
			postParams.put(HttpUrlConnectionParam.MSISDN, fmsisdn);
			postParams.put(HttpUrlConnectionParam.SIGNATURE, Global.signature);
			// currAcctChgAmt : positive for credit, negative for debit
			postParams.put(HttpUrlConnectionParam.CURR_ACC_CHARGING_AMOUNT, currAcctChgAmt + "");
			postParams.put(HttpUrlConnectionParam.ACCOUNT_TYPE, accType);
			postParams.put(HttpUrlConnectionParam.NB_DAY, noOfdays + "");
			postParams.put(HttpUrlConnectionParam.ADDITIONAL_INFO, desc);

			OutputStream os = httpcon.getOutputStream();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
			writer.write(getURLEncodedDataString(postParams));
			writer.flush();
			writer.close();
			os.close();

			int responseCode = httpcon.getResponseCode();
			logger.info(
					"##>>msisdn[" + msisdn + "] responseCode :[" + responseCode + "] form talkTimeTransfer() method.");
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line;
				BufferedReader br = new BufferedReader(new InputStreamReader(httpcon.getInputStream()));
				while ((line = br.readLine()) != null) {
					response.append(line);
				}
			} else {
				response.append("Exception");
			}
			logger.info("##>>msisdn[" + msisdn + "] fmsisdn[" + fmsisdn + "] response ::: [" + response
					+ "] form talkTimeTransfer() method.");
		} catch (Exception e) {
			return "Exception";
		}
		return response.toString();
	}

	/**
	 * This method is used to activate the requested pack to the provided msisdn.
	 * This method interact with the gateway API by HTTP (POST request) and provide
	 * a JSON response.
	 * 
	 * @param msisdn
	 * @param fmsisdn
	 * @param productCode
	 * @param packUrl
	 * 
	 * @author SIDDHARTH
	 * @return jsonString
	 */
	private String activatePackage(String msisdn, String fmsisdn, String productCode, String serviceType) {
		logger.info("###>>msisdn[" + msisdn + "] inside activatePackage() method to purchase pack with fmsisdn ["
				+ fmsisdn + "] and serviceType [" + serviceType + "].");
		StringBuffer response = new StringBuffer();
		try {
			String packageURL = Global.packActivationUrl;
			URL url = new URL(packageURL);
			HttpURLConnection httpcon = (HttpURLConnection) url.openConnection();

			httpcon.setReadTimeout(Global.conn_read_timeout);
			httpcon.setConnectTimeout(Global.gateway_request_timeout);
			httpcon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			httpcon.setRequestProperty("Accept", "application/json");
			httpcon.setRequestMethod("POST");
			httpcon.setDoInput(true);
			httpcon.setDoOutput(true);

			HashMap<String, String> postParam = new HashMap<String, String>();
			if (serviceType.equalsIgnoreCase(ServiceTypes.SERVICE_TYPE_GIFT)) {
				postParam.put(HttpUrlConnectionParam.MSISDN, fmsisdn);
			}

			else if (serviceType.equalsIgnoreCase(ServiceTypes.SERVICE_TYPE_PACK_PURCHASE)) {
				postParam.put(HttpUrlConnectionParam.MSISDN, msisdn);
			}

			else {
				logger.error("###MSISDN:[" + msisdn + "] ServieType[" + serviceType
						+ "] is not as expected. Expected ServiceType are [" + ServiceTypes.SERVICE_TYPE_GIFT + ","
						+ ServiceTypes.SERVICE_TYPE_PACK_PURCHASE + "]");
				return "Exception";
			}
			postParam.put(HttpUrlConnectionParam.SIGNATURE, Global.signature);
			postParam.put(HttpUrlConnectionParam.PRODUCT_CODE, productCode);

			OutputStream os = httpcon.getOutputStream();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
			writer.write(getURLEncodedDataString(postParam));
			writer.flush();
			writer.close();
			os.close();

			int responseCode = httpcon.getResponseCode();
			logger.info("##>>msisdn[" + msisdn + "] fmsisdn[" + fmsisdn + "] responseCode :[" + responseCode
					+ "] serviceType [" + serviceType + "] for activatePackage() method.");
			if (responseCode == HttpURLConnection.HTTP_OK) {

				String line;
				BufferedReader br = new BufferedReader(new InputStreamReader(httpcon.getInputStream()));
				while ((line = br.readLine()) != null) {
					response.append(line);
				}
			} else {
				response.append("Exception");
			}
			logger.info("##>>msisdn[" + msisdn + "] fmsisdn[" + fmsisdn + "]  response ::: [" + response
					+ "] serviceType [" + serviceType + "] for activatePackage() method.");
		} catch (Exception e) {
			return "Exception";
		}
		return response.toString();

	}

	/**
	 * This method is used to deduct account balance of requested msisdn. This
	 * method interact with the gateway API by HTTP (POST request) and provide a
	 * JSON response.
	 * 
	 * @param msisdn
	 * @param currAcctChgAmt
	 * @param accType
	 * 
	 * @author SIDDHARTH
	 * @return jsonString
	 */
	private String bonusAndDataTransfer(String msisdn, long currAcctChgAmt, String accType, String desc) {
		logger.info("###>>msisdn[" + msisdn
				+ "] inside bonusAndDataTransferPost() method to deduct transfer amount from A praty where currAcctChgAmt["
				+ currAcctChgAmt + "] accType[" + accType + "] desc[" + desc + "]");
		StringBuffer response = new StringBuffer();
		try {
			String packageURL = Global.bounsDebitCreditUrl;
			URL url = new URL(packageURL);
			HttpURLConnection httpcon = (HttpURLConnection) url.openConnection();

			httpcon.setReadTimeout(Global.conn_read_timeout);
			httpcon.setConnectTimeout(Global.gateway_request_timeout);
			httpcon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			httpcon.setRequestProperty("Accept", "application/json");
			httpcon.setRequestMethod("POST");
			httpcon.setDoInput(true);
			httpcon.setDoOutput(true);

			HashMap<String, String> postParams = new HashMap<String, String>();
			postParams.put(HttpUrlConnectionParam.MSISDN, msisdn);
			postParams.put(HttpUrlConnectionParam.SIGNATURE, Global.signature);
			postParams.put(HttpUrlConnectionParam.ACCOUNT_TYPE, accType);
			// positive for credit, negative for debit
			postParams.put(HttpUrlConnectionParam.CURR_ACC_CHARGING_AMOUNT, currAcctChgAmt + "");
			postParams.put(HttpUrlConnectionParam.ADDITIONAL_INFO, desc);

			OutputStream os = httpcon.getOutputStream();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
			writer.write(getURLEncodedDataString(postParams));
			writer.flush();
			writer.close();
			os.close();

			int responseCode = httpcon.getResponseCode();
			logger.info("##>>msisdn[" + msisdn + "] responseCode [" + responseCode + "] from bonusAndDataTransfer.");
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line;
				BufferedReader br = new BufferedReader(new InputStreamReader(httpcon.getInputStream()));
				while ((line = br.readLine()) != null) {
					response.append(line);
				}
			} else {
				response.append("Exception");
			}
			logger.info("##>>msisdn[" + msisdn + "]   response ::: [" + response + "] from bonusAndDataTransfer.");
		} catch (Exception e) {
			return "Exception";
		}
		return response.toString();
	}

	/**
	 * This method is used to get the fully initialized bean of mobile money having
	 * information about the mobile money.
	 * 
	 * @param data_object
	 * @return MobileMoneyBean
	 */
	public MobileMoneyBean getMobleMoneyInfo(Data_Object data_object) {
		MobileMoneyBean mobileMoneyBean = null;
		String jsonResponse = "";

		logger.info("##>>msisdn[" + data_object.msisdn
				+ "] inside getMobleMoneyInfo() method to get the information about mobile money.");

		try {
			jsonResponse = getMobileMoneyResponse(data_object);
			Gson gson = new Gson();
			logger.debug("##>>msisdn[" + data_object.msisdn + "] Mobile Money JsonResponse [" + jsonResponse
					+ "] from getMobileMoneyResponse() method.");

			mobileMoneyBean = gson.fromJson(jsonResponse, MobileMoneyBean.class);

			logger.debug("##>>msisdn[" + data_object.msisdn + "]  mobileMoneyBean: " + mobileMoneyBean);
		} catch (Exception e) {
			logger.error("Exception in getMobleMoneyInfo() method. Exception:" + e.getMessage());
			e.printStackTrace();
		}

		return mobileMoneyBean;
	}

	/**
	 * This method is used to get the mobile money details of the requested MSISDN.
	 * This method interact with the Mobile Money API by HTTP (POST request) and
	 * provide a JSON response.
	 * 
	 * @param data_Object
	 * @return jsonString
	 */
	private String getMobileMoneyResponse(Data_Object data_Object) {
		logger.info("###>>msisdn[" + data_Object.msisdn + "] inside getMobileMoneyResponse() method.");
		StringBuffer response = new StringBuffer();
		try {

			String dateInRequiredFormat = getDateForMobileMoney();
			String packageURL = Global.mobileMoneyUrl;
			URL url = new URL(packageURL);
			HttpURLConnection httpcon = (HttpURLConnection) url.openConnection();

			logger.info("###>>msisdn[" + data_Object.msisdn
					+ "] going to interact with Mobile Money API with required date format ["
					+ Global.mobileMoneyRequiredDateFormat + "] Timestamp [" + dateInRequiredFormat + "] OperatorID ["
					+ Global.mobileMoneyOperatorID + "] Token [" + Global.mobileMoneyToken + "] Authorization ["
					+ Global.mobileMoneyAuthorization + "]");

			httpcon.setReadTimeout(Global.conn_read_timeout);
			httpcon.setConnectTimeout(Global.gateway_request_timeout);
			httpcon.setRequestProperty("Content-Type", "application/json");
			httpcon.setRequestProperty("OperatorID", Global.mobileMoneyOperatorID);
			httpcon.setRequestProperty("Timestamp", dateInRequiredFormat);
			httpcon.setRequestProperty("Token", Global.mobileMoneyToken);
			httpcon.setRequestProperty("Authorization", Global.mobileMoneyAuthorization);

			httpcon.setRequestMethod("POST");
			httpcon.setDoInput(true);
			httpcon.setDoOutput(true);

			HashMap<String, String> postParams = new HashMap<String, String>();
			postParams.put(HttpUrlConnectionParam.MSISDN, data_Object.msisdn);
			postParams.put(HttpUrlConnectionParam.Moble_Money_Amount, "");
			postParams.put(HttpUrlConnectionParam.TRANSACTION_ID, data_Object.getTransId());

			OutputStream os = httpcon.getOutputStream();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
			writer.write(getURLEncodedDataString(postParams));
			writer.flush();
			writer.close();
			os.close();

			int responseCode = httpcon.getResponseCode();
			logger.info(
					"##>>msisdn[" + data_Object.msisdn + "] responseCode [" + responseCode + "] from mobileMoney API.");
			if (responseCode == HttpURLConnection.HTTP_OK) {
				String line;
				BufferedReader br = new BufferedReader(new InputStreamReader(httpcon.getInputStream()));
				while ((line = br.readLine()) != null) {
					response.append(line);
				}
			} else {
				response.append("Exception");
			}
			logger.info(
					"##>>msisdn[" + data_Object.msisdn + "]   response ::: [" + response + "] from mobileMoney API.");
		} catch (Exception e) {
			logger.error("Exception in getMobileMoneyResponse() method. Exception:" + e.getMessage());
			e.printStackTrace();
			return "Exception";
		}
		return response.toString();
	}

	/**
	 * This method is used to convert the current date time format into required
	 * date time format for mobile money.
	 * 
	 * @return Mobile Money TimeStamp.
	 */
	private String getDateForMobileMoney() {
		Date date = new Date();
		String dateInRequiredFomat = "";
		try {
			SimpleDateFormat fomatter = new SimpleDateFormat(Global.mobileMoneyRequiredDateFormat);
			dateInRequiredFomat = fomatter.format(date);
		} catch (Exception e) {
			logger.error("Exception while converting date into required date fomat ["
					+ Global.mobileMoneyRequiredDateFormat + "] form mobile money. Exception:" + e.getMessage());
			e.printStackTrace();
		}

		logger.debug(
				"Inside getDateForMobileMoney() method to convert date time into required format for mobile money ["
						+ Global.mobileMoneyRequiredDateFormat + "] TimeStamp [" + dateInRequiredFomat + "]");
		return dateInRequiredFomat;
	}

}
