package com.charging.client.ThirdParty;

import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

import FileBaseLogging.FileLogWriter;
import org.apache.log4j.Logger;

/**
 * This class define all data-members that are used as configuration ,
 * Throughout the application life cycle.
 * 
 * @author SIDDHARTH
 */
public class Global {

	private static Logger logger = Logger.getLogger("Global");

	public static String getBalanceUrl = "http://10.71.128.187/selfcare/expresso-services.php/esn-query-balance";
	public static String deductBalanceUrl = "http://10.71.128.187/selfcare/expresso-services-deduct.php/MainAccountDeduction";
	public static String packActivationUrl = "http://10.71.128.187/selfcare/expresso-services.php/esn-package-activation";
	public static String bounsDebitCreditUrl = "http://10.71.128.187/selfcare/expresso-services-deduct.php/adjustAccount_source/";
	public static String talkTimeDebitCreditUrl = "http://10.71.128.187/selfcare/expresso-services-deduct.php/adjustAccount_dest/";
	public static String adjustAccountUrl = "http://10.71.128.187/selfcare/expresso-services-deduct.php/adjustAccount/";
	public static int gateway_request_timeout = 1000;
	public static int conn_read_timeout = 10000;

	public static String offNetDebitAccounts = "2001 , 2501 , 2508 , 5011 , 5070 , 2500 , 2502 , 2503 , 2504 , 2505 , 2509 , 2514 , 2515 , 2517 , 2519 , 2520 , 2535 , 2543 , 2547 , 5046 , 2507 , 2510 , 2518 , 2522 , 5039 , 5069 , 2522 , 2522 , 2522 , 5010 , 5099 , 5010 , 5016 , 5023  , 5027  , 5049  , 5058   , 5067";
	public static String OffNetCreditAccount = "OffNet";

	public static String onNetDebitAccounts = "2001 , 2501 , 2508 , 5011 , 5070 , 2500 , 2502 , 2503 , 2504 , 2505 , 2509 , 2514 , 2515 , 2517 , 2519 , 2520 , 2535 , 2543 , 2547 , 5046 , 2507 , 2510 , 2518 , 2522 , 5039 , 5069 , 2522 , 2522 , 2522 , 5010 , 5099 , 5010 , 5016 , 5023  , 5027  , 5049  , 5058   , 5067";
	public static String onNetCreditAccount = "OnNet";

	public static String bounsDebitAccounts = "2001 , 2501 , 2508 , 5011 , 5070 , 2500 , 2502 , 2503 , 2504 , 2505 , 2509 , 2514 , 2515 , 2517 , 2519 , 2520 , 2535 , 2543 , 2547 , 5046 , 2507 , 2510 , 2518 , 2522 , 5039 , 5069 , 2522 , 2522 , 2522 , 5010 , 5099 , 5010 , 5016 , 5023  , 5027  , 5049  , 5058   , 5067";
	public static String bounsCreditAccount = "DATA";

	public static String dataDebitAccounts = "2001 , 2501 , 2508 , 5011 , 5070 , 2500 , 2502 , 2503 , 2504 , 2505 , 2509 , 2514 , 2515 , 2517 , 2519 , 2520 , 2535 , 2543 , 2547 , 5046 , 2507 , 2510 , 2518 , 2522 , 5039 , 5069 , 2522 , 2522 , 2522 , 5010 , 5099 , 5010 , 5016 , 5023  , 5027  , 5049  , 5058   , 5067";
	public static String dataCreditAccount = "DATA";

	public static String euroOffNetDebitAccounts = "2001 , 2501 , 2508 , 5011 , 5070 , 2500 , 2502 , 2503 , 2504 , 2505 , 2509 , 2514 , 2515 , 2517 , 2519 , 2520 , 2535 , 2543 , 2547 , 5046 , 2507 , 2510 , 2518 , 2522 , 5039 , 5069 , 2522 , 2522 , 2522 , 5010 , 5099 , 5010 , 5016 , 5023  , 5027  , 5049  , 5058   , 5067";
	public static String euroOffNetCreditAccount = "EuroOffnet";

	public static String dataMacroCreditAccount = "5248";
	public static String signature = "8b85407d65a1f8985de7e860ffb11ee4";
	public static String additionalInfoInChargingForMacroData = "MACRO";
	public static int chargingJarTestEnable = 0;
	public static int chargingJarTTPayBackeEnableResp = 0;
	public static int chargingJarDMCPayBackeEnableResp = 0;

	public static int countryCodeLength = 3;
	public static int checkBalanceForPackEnable = -1;
	public static ArrayList<String> offNetDebitList = new ArrayList<String>();
	public static ArrayList<String> onNetDebitList = new ArrayList<String>();
	public static ArrayList<String> euroOffNetDebitList = new ArrayList<String>();
	public static ArrayList<String> dataDebitList = new ArrayList<String>();
	public static ArrayList<String> bounsDebitList = new ArrayList<String>();
	public static FileLogWriter activity_flw = new FileLogWriter();

	// Diameter
	public static String host_id = "";
	public static String realm = "";
	public static String dest_host = "";
	public static String dest_realm = "";
	public static int dest_port = 0;
	public static int host_port = 0;
	public static int vendor_id = 0;

	// For Mobile money
	public static String mobileMoneyUrl = "https://192.168.180.199/ExpressoSenVoucherApi/voucher/";
	public static String mobileMoneyOperatorID = "365";
	public static String mobileMoneyRequiredDateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	public static String mobileMoneyToken = "d6448e9eb8affd7bbc7532ad59a64e0c";
	public static String mobileMoneyAuthorization = "RVNORVhQUkTVU086ZXhwcmVzc29AMjAxOQ**";

	/**
	 * This method read configuration from property file .
	 * 
	 * @param pro
	 * @return void
	 */
	public static void loadConfiguration(Properties pro) {

		try {
			if (pro != null) {

				Global.offNetDebitList.clear();
				Global.onNetDebitList.clear();
				Global.euroOffNetDebitList.clear();
				Global.dataDebitList.clear();
				Global.bounsDebitList.clear();

				Global.packActivationUrl = pro.getProperty("PACK_URL");
				Global.getBalanceUrl = pro.getProperty("CHECK_BALANCE_URL");
				Global.deductBalanceUrl = pro.getProperty("DEDUCT_BAL_URL");
				Global.bounsDebitCreditUrl = pro.getProperty("BONUS_DEBIT_CREDIT_URL");
				Global.talkTimeDebitCreditUrl = pro.getProperty("TALKTIME_DEBIT_CREDIT_URL");
				Global.adjustAccountUrl = pro.getProperty("ADJUST_ACCOUNT_URL");
				Global.gateway_request_timeout = Integer.parseInt(pro.getProperty("REQUEST_TIME_OUT"));
				Global.conn_read_timeout = Integer
						.parseInt(pro.getProperty("CONNECTION_READ_TIMEOUT", String.valueOf(conn_read_timeout)));

				Global.offNetDebitAccounts = pro.getProperty("OFFNET_DEBIT_ACCOUNTS");
				Global.OffNetCreditAccount = pro.getProperty("OFFNET_CREDIT_ACCOUNT");

				Global.onNetDebitAccounts = pro.getProperty("ONNET_DEBIT_ACCOUNTS");
				Global.onNetCreditAccount = pro.getProperty("ONNET_CREDIT_ACCOUNT");

				Global.euroOffNetDebitAccounts = pro.getProperty("EURO_OFF_NET_DEBIT_ACCOUNTS");
				Global.euroOffNetCreditAccount = pro.getProperty("EURO_OFF_NET_CREDIT_ACCOUNT");

				Global.bounsDebitAccounts = pro.getProperty("BOUNS_DEBIT_ACCOUNTS");
				Global.bounsCreditAccount = pro.getProperty("BOUNS_CREDIT_ACCOUNT");

				Global.dataDebitAccounts = pro.getProperty("DATA_DEBIT_ACCOUNTS");
				Global.dataCreditAccount = pro.getProperty("DATA_CREDIT_ACCOUNT");

				Global.dataMacroCreditAccount = pro.getProperty("DATA_MACRO_CREDIT_ACCOUNTS").trim();
				Global.signature = pro.getProperty("CHARGING_SIGNATURE");
				Global.additionalInfoInChargingForMacroData = pro.getProperty("ADDITIONAL_INFO_MACRO_DATA_CHARGING");

				Global.countryCodeLength = Integer.parseInt(pro.getProperty("COUNTRY_CODE_LENGTH"));
				Global.checkBalanceForPackEnable = Integer.parseInt(pro.getProperty("CHECK_BALANCE_FOR_PACK_ENABLE"));

				Global.chargingJarTestEnable = Integer.parseInt(pro.getProperty("CHARGING_JAR_TEST_ENABLE"));
				Global.chargingJarTTPayBackeEnableResp = Integer
						.parseInt(pro.getProperty("CHARGING_JAR_TTT_PAYBACK_ENABLE_RESP"));
				Global.chargingJarDMCPayBackeEnableResp = Integer
						.parseInt(pro.getProperty("CHARGING_JAR_DMC_PAYBACK_ENABLE_RESP"));

				int activity_file_interval = -1;
				String activity_filename = "";
				String activity_filepath = "";
				String activity_filepath_arch = "";
				String activity_filename_arch = "";

				logger.info("Loading Logging Information");

				activity_file_interval = Integer.parseInt(pro.getProperty("ACTIVITY_ARCHIVE_FILE_INTERVAL"));
				activity_filename = pro.getProperty("ACTIVITY_LOG_FILE_NAME");
				activity_filepath = pro.getProperty("ACTIVITY_LOG_FILE_PATH");
				activity_filepath_arch = pro.getProperty("ACTIVITY_ARCHIVE_FILE_PATH");
				activity_filename_arch = pro.getProperty("ACTIVITY_ARCHIVE_FILE_NAME");

				logger.info("Intializing Loggings...");
				Global.activity_flw.setNewFileInterval(activity_file_interval);
				Global.activity_flw.setFilename(activity_filename);
				Global.activity_flw.setFilePath(activity_filepath);
				Global.activity_flw.setArchiveFilePath(activity_filepath_arch);
				Global.activity_flw.setArchiveFilename(activity_filename_arch);
				Global.activity_flw.setArchiveFileExtension("");
				Global.activity_flw.initialize();

				// Setting values for diameter parameter
				Global.host_id = pro.getProperty("ORIGIN_HOST").trim();
				Global.realm = pro.getProperty("ORIGIN_REALM").trim();
				Global.dest_host = pro.getProperty("DEST_HOST");
				Global.dest_realm = pro.getProperty("DEST_REALM");
				Global.dest_port = Integer.parseInt(pro.getProperty("DEST_PORT"));
				Global.host_port = Integer.parseInt(pro.getProperty("HOST_PORT"));
				Global.vendor_id = Integer.parseInt(pro.getProperty("VENDOR_ID"));

				// Setting for mobile money
				Global.mobileMoneyOperatorID = pro.getProperty("MobileMoneyOperatorID");
				Global.mobileMoneyRequiredDateFormat = pro.getProperty("MobileMoneyRequiredDateFormat");
				Global.mobileMoneyToken = pro.getProperty("MobileMoneyToken");
				Global.mobileMoneyAuthorization = pro.getProperty("MobileMoneyAuthorization");
				Global.mobileMoneyUrl = pro.getProperty("MobileMoneyUrl");

				StringTokenizer tokens = new StringTokenizer(Global.offNetDebitAccounts, ",");
				while (tokens.hasMoreElements()) {
					Global.offNetDebitList.add(tokens.nextToken().trim());
				}

				tokens = new StringTokenizer(Global.onNetDebitAccounts, ",");
				while (tokens.hasMoreElements()) {
					Global.onNetDebitList.add(tokens.nextToken().trim());
				}

				tokens = new StringTokenizer(Global.bounsDebitAccounts, ",");
				while (tokens.hasMoreElements()) {
					Global.bounsDebitList.add(tokens.nextToken().trim());
				}

				tokens = new StringTokenizer(Global.dataDebitAccounts, ",");
				while (tokens.hasMoreElements()) {
					Global.dataDebitList.add(tokens.nextToken().trim());
				}

				tokens = new StringTokenizer(Global.euroOffNetDebitAccounts, ",");
				while (tokens.hasMoreElements()) {
					Global.euroOffNetDebitList.add(tokens.nextToken().trim());
				}

				logger.info("Charging Jar (Global) ==>  packActivationUrl[" + Global.packActivationUrl
						+ "] getBalanceUrl[" + Global.getBalanceUrl + "] deductBalanceUrl[" + Global.deductBalanceUrl
						+ "]" + "bounsDebitCreditYrl[" + Global.bounsDebitCreditUrl + "] talkTimeDebitCreditUrl["
						+ Global.talkTimeDebitCreditUrl + "] adjustAccountUrl[" + Global.adjustAccountUrl + "]"
						+ "gateway_request_timeout[" + Global.gateway_request_timeout + "] conn_read_timeout["
						+ Global.conn_read_timeout + "] offNetDebitAccounts[" + Global.offNetDebitAccounts + "]"
						+ "OffNetCreditAccount[" + Global.OffNetCreditAccount + "] onNetDebitAccounts["
						+ Global.onNetDebitAccounts + "]" + "onNetCreditAccount[" + Global.onNetCreditAccount
						+ "] offNetDebitList[" + Global.offNetDebitList.size() + "] onNetDebitList["
						+ Global.onNetDebitList.size() + "]" + "bounsDebitList[" + Global.bounsDebitList.size() + "]"
						+ "countryCodeLength[" + Global.countryCodeLength + "] checkBalanceForPackEnable["
						+ Global.checkBalanceForPackEnable + "] dataDebitAccounts[" + Global.dataDebitAccounts + "]"
						+ "dataCreditAccount[" + Global.dataCreditAccount + "] dataDebitList["
						+ Global.dataDebitList.size() + "] euroOffNetCreditAccount[" + Global.euroOffNetCreditAccount
						+ "]" + "euroOffNetDebitAccounts[" + Global.euroOffNetDebitAccounts + "] euroOffNetDebitList["
						+ Global.euroOffNetDebitList.size() + "] bounsDebitList[" + Global.bounsDebitList + "]"
						+ "bounsCreditAccount[" + Global.bounsCreditAccount + "] signature[" + Global.signature
						+ "] dataMacroCreditAccount[" + Global.dataMacroCreditAccount
						+ "] additionalInfoInChargingForMacroData[" + Global.additionalInfoInChargingForMacroData
						+ "] chargingJarTestEnable [" + Global.chargingJarTestEnable
						+ "] chargingJarTTPayBackeEnableResp [" + Global.chargingJarTTPayBackeEnableResp
						+ "] chargingJarDMCPayBackeEnableResp [" + Global.chargingJarDMCPayBackeEnableResp
						+ "] host_id [" + Global.host_id + "] realm [" + Global.realm + "] dest_host ["
						+ Global.dest_host + "] dest_realm [" + Global.dest_realm + "] dest_port [" + Global.dest_port
						+ "] host_port [" + Global.host_port + "] vendor_id [" + Global.vendor_id + "] mobileMoneyUrl ["
						+ Global.mobileMoneyUrl + "] mobileMoneyOperatorID [" + Global.mobileMoneyOperatorID
						+ "] mobileMoneyRequiredDateFormat [" + Global.mobileMoneyRequiredDateFormat + "] mobileMoneyToken ["
						+ Global.mobileMoneyToken + "] mobileMoneyAuthorization [" + Global.mobileMoneyAuthorization
						+ "]");
			} else {
				logger.warn("Property object null[" + pro + "]");
			}
		} catch (Exception exp) {
			exp.printStackTrace();
		}
	}
}
