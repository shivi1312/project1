package com.charging.client.ThirdParty;

/**
 * This class provide getter setter to define all balance accounts and their details.
 * @author Harjinder
 * */
public class BalanceInfoBean {
	
	public String accId;
	public String expiryTime;
	public long balance;
	public long amountToDeduct;
	public String getAccId() {
		return accId;
	}
	public void setAccId(String accId) {
		this.accId = accId;
	}
	public String getExpiryTime() {
		return expiryTime;
	}
	public void setExpiryTime(String expiryTime) {
		this.expiryTime = expiryTime;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	
	public long getAmountToDeduct() {
		return amountToDeduct;
	}
	public void setAmountToDeduct(long amountToDeduct) {
		this.amountToDeduct = amountToDeduct;
	}
	@Override
	public String toString() {
		return "BalanceInfoBean [accId=" + accId + ", expiryTime=" + expiryTime
				+ ", balance=" + balance + ", amountToDeduct=" + amountToDeduct
				+ "]";
	}
	
	

}
