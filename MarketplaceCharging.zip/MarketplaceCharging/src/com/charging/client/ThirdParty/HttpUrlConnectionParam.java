package com.charging.client.ThirdParty;

/**
 * This Interface defines all constant related to HttpUrlConnection
 * 
 * @author Siddharth Singh Rawat
 */
public interface HttpUrlConnectionParam {

	String MSISDN = "mdn";
	String SIGNATURE = "signature";
	String DEDUCT_AMOUNT = "deductAmt";
	String ADDITIONAL_INFO = "additionalInfo";
	String CURR_ACC_CHARGING_AMOUNT = "CurrAcctChgAmt";
	String ACCOUNT_TYPE = "AccountType";
	String NB_DAY = "nb_day";
	String PRODUCT_CODE = "productcode";
	String Moble_Money_Amount = "amount";
	String TRANSACTION_ID = "transactionID";
}
