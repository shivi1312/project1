package com.charging.client.ThirdParty;

public class MobileMoneyBean {

	int status = 0;
	String voucherCode = "";
	String message = "";

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getVoucherCode() {
		return voucherCode;
	}

	public void setVoucherCode(String voucherCode) {
		this.voucherCode = voucherCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "MobileMoneyBean [status=" + status + ", voucherCode=" + voucherCode + ", message=" + message + "]";
	}
}
