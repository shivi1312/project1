package com.charging.client;

import dk.i1.diameter.*;
import dk.i1.diameter.node.*;

import java.util.ArrayList;
import java.util.Hashtable;

import org.apache.log4j.Logger;

import com.charging.client.ThirdParty.BalanceInfoBean;
import com.charging.client.ThirdParty.Data_Object;
import com.charging.client.ThirdParty.Global;

/**
 * This class is used to initialize all the required parameter for Diameter
 * based charging and provides method to used diameter hits for performing
 * operation on user accounts. CCR (credit-control request)
 * 
 * @author SIDDHARTH SINGH RAWAT
 *
 */
public class DiameterRequest {
	public static DiameterRequest diameterInstance = null;
	private static Logger logger = Logger.getLogger(DiameterRequest.class);

	SimpleSyncClient ssc = null;
	Peer peer[] = null;

	private DiameterRequest() {

		logger.info("Going to initialize all the required parameter for Diameter based charging with host_id["
				+ Global.host_id + "] realm[" + Global.realm + "] host_port[" + Global.host_port + "] dest_host["
				+ Global.dest_host + "] dest_realm[" + Global.dest_realm + "] dest_port[" + Global.dest_port
				+ "] vendor-id[" + Global.vendor_id + "]");

		Capability capability = new Capability();
		capability.addAuthApp(ProtocolConstants.DIAMETER_APPLICATION_CREDIT_CONTROL);
		// capability.addAuthApp(ProtocolConstants.DIAMETER_APPLICATION_EAP);
		// capability.addAcctApp(ProtocolConstants.DIAMETER_APPLICATION_CREDIT_CONTROL);

		// System.out.println("going to create node Setting....");
		logger.info("going to create node Setting....");
		NodeSettings node_settings;
		try {
			node_settings = new NodeSettings(Global.host_id, Global.realm, Global.vendor_id, capability,
					Global.host_port, "cc_test_client", 0x01000000);
		} catch (InvalidSettingException e) {
			logger.error("Exception while Setting Node. Exception:" + e.toString());
			e.printStackTrace();
			return;
		}

		// System.out.println("node setting created successfully..");
		logger.info("node setting created successfully..");
		try {

			Peer peers[] = new Peer[] { new Peer(Global.dest_host, Global.dest_port) };
//			System.out.println("going to create SimpleSyncClient");
			logger.info("going to create SimpleSyncClient");
			ssc = new SimpleSyncClient(node_settings, peers);
			ssc.start();
//			System.out.println("waiting for connection");
			logger.info("waiting for connection");
			ssc.waitForConnection(); // allow connection to be established.
		} catch (Exception e) {
//			System.out.println("Exception inside DiameterRequest Conc ");
			logger.error("Exception inside DiameterRequest Conc. Exception:" + e.getMessage());
			e.printStackTrace();
		}

//		System.out.println("SimpleSyncClient created successfully");
		logger.info("SimpleSyncClient created successfully");
	}

	public static DiameterRequest getDiameterInstance() {

		// logger.info("Inside getDiameterInstance with diameterInstance [" +
		// diameterInstance + "]");
		// System.out.println("Inside getDiameterInstance with diameterInstance [" +
		// diameterInstance + "]");
		if (diameterInstance == null) {
//			System.out.println("DiameterRequest instance found [" + instance + "] so going to create a new object");
			logger.info("DiameterRequest instance found [" + diameterInstance + "] so going to create a new object");
			diameterInstance = new DiameterRequest();
		}

		logger.debug("Found object of DiameterRequest, So returning old already created object.");
		return diameterInstance;
	}

	public synchronized int checkBalanceRequest(String msisdn, double Balance, Data_Object data_Object, int aVPCode,
			String rbtCode, String cpId, ArrayList<BalanceInfoBean> balList) {

		logger.debug("##>> msisdn[" + msisdn
				+ "] Inside checkBalanceRequest method for fetching user accounts balance information using Diameter with AvpCode ["
				+ aVPCode + "] RbtCode [" + rbtCode + "] CP Id [" + cpId + "]");
		String l_msisdn = msisdn;
		String resultString = "NA";
		data_Object.accountDetailInfoTable=new Hashtable<Integer,BalanceInfoBean>();
		int balance = (int) Balance;
		int l_result = -1;
		// Build Credit-Control Request
		// <Credit-Control-Request> ::= < Diameter Header: 272, REQ, PXY >
		Message ccr = new Message();
		ccr.hdr.command_code = ProtocolConstants.DIAMETER_COMMAND_CC;
		ccr.hdr.application_id = ProtocolConstants.DIAMETER_APPLICATION_CREDIT_CONTROL;
		ccr.hdr.setRequest(true);
		ccr.hdr.setProxiable(true);
		// < Session-Id >
		ccr.add(new AVP_UTF8String(ProtocolConstants.DI_SESSION_ID, ssc.node().makeNewSessionId()));
		// { Origin-Host }
		// { Origin-Realm }
		ssc.node().addOurHostAndRealm(ccr);
		// { Destination-Realm }
		// ccr.add(new
		// AVP_UTF8String(ProtocolConstants.DI_DESTINATION_REALM,"www.huawei.com"));
		ccr.add(new AVP_UTF8String(ProtocolConstants.DI_DESTINATION_REALM, Global.dest_realm));
		ccr.add(new AVP_UTF8String(ProtocolConstants.DI_DESTINATION_HOST, Global.dest_host));
		// { Auth-Application-Id }
		ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_AUTH_APPLICATION_ID,
				ProtocolConstants.DIAMETER_APPLICATION_CREDIT_CONTROL));
		// { Service-Context-Id }
		ccr.add(new AVP_UTF8String(ProtocolConstants.DI_SERVICE_CONTEXT_ID, "QueryBalance@huawei.com"));
		// { CC-Request-Type }
		ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_CC_REQUEST_TYPE,
				ProtocolConstants.DI_CC_REQUEST_TYPE_EVENT_REQUEST));
		;
		// { CC-Request-Number }
		ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_CC_REQUEST_NUMBER, 0));
		// [ Destination-Host ]
		// [ User-Name ]
		ccr.add(new AVP_UTF8String(ProtocolConstants.DI_USER_NAME, Global.realm));
		// [ CC-Sub-Session-Id ]
		// [ Acct-Multi-Session-Id ]
		// [ Origin-State-Id ]
		ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_ORIGIN_STATE_ID, ssc.node().stateId()));
		// [ Event-Timestamp ]
		ccr.add(new AVP_Time(ProtocolConstants.DI_EVENT_TIMESTAMP, (int) (System.currentTimeMillis() / 1000)));
		// *[ Subscription-Id ]
		ccr.add(new AVP_Grouped(ProtocolConstants.DI_SUBSCRIPTION_ID,
				new AVP[] { new AVP_Unsigned32(ProtocolConstants.DI_SUBSCRIPTION_ID_TYPE, 0).setM(),
						new AVP_UTF8String(ProtocolConstants.DI_SUBSCRIPTION_ID_DATA, l_msisdn).setM() }).setM());
		// [ Service-Identifier ]
		ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_SERVICE_IDENTIFIER, 3));
		ccr.add(new AVP_Grouped(873,
				new AVP[] { new AVP_Grouped(20600, new AVP[] { new AVP_UTF8String(20601, cpId + "").setM(),
						new AVP_UTF8String(20640, rbtCode).setM(), new AVP_UTF8String(20639, aVPCode + "").setM() })
								.setM() }).setM());
		ccr.add(new AVP_Unsigned32(ProtocolConstants.DI_REQUESTED_ACTION,
				ProtocolConstants.DI_REQUESTED_ACTION_CHECK_BALANCE));

		// [Service-Information]
		ccr.add(new AVP_Grouped(873, // Service-Information
				new AVP[] { new AVP_Grouped(20300, // IN-Information
						new AVP[] { new AVP_Unsigned32(20346, 2).setM(), // Account-Query-Method
								new AVP_Grouped(20349).setM() } // Account-Change-Info
				).setM() }).setM());
		// [ CC-Correlation-Id ]
		// [ User-Equipment-Info ]
		// *[ Proxy-Info ]
		// *[ Route-Record ]
		ccr.add(new AVP_UTF8String(ProtocolConstants.DI_ROUTE_RECORD, Global.host_id));
		// *[ AVP ]
		ccr.add(new AVP_Grouped(ProtocolConstants.DI_SUBSCRIPTION_ID,
				new AVP[] { new AVP_Unsigned32(ProtocolConstants.DI_SUBSCRIPTION_ID_TYPE, 0).setM(),
						new AVP_UTF8String(ProtocolConstants.DI_SUBSCRIPTION_ID_DATA, l_msisdn).setM() }).setM());
		ccr.add(new AVP_Grouped(ProtocolConstants.DI_REQUESTED_SERVICE_UNIT, new AVP[] { new AVP_Grouped(
				ProtocolConstants.DI_CC_MONEY,
				new AVP[] { new AVP_Grouped(ProtocolConstants.DI_UNIT_VALUE,
						new AVP[] { new AVP_Unsigned64(ProtocolConstants.DI_VALUE_DIGITS, balance).setM() }).setM() })
								.setM() }).setM());

		Utils.setMandatory_RFC3588(ccr);
		Utils.setMandatory_RFC4006(ccr);
		logger.debug("##>>> msisdn[" + msisdn + "] All Paramters are set Now send the request");

		// Send it
		Message cca = ssc.sendRequest(ccr);
		// System.out.println("##>>> msisdn["+msisdn+"] Diameter Check Balance - Request
		// Sent");
		logger.info("##>>> msisdn[" + msisdn + "] Diameter Check Balance - Request Sent");

		// Now look at the result
		if (cca == null) {
			resultString = "##>>> msisdn[" + msisdn + "] Diameter CheckBalance - No response";
			return l_result;
		}
		AVP result_code = cca.find(ProtocolConstants.DI_RESULT_CODE);
		if (result_code == null) {
			resultString = "##>>> msisdn[" + msisdn + "] Diameter CheckBalance - No result code";
			return l_result;
		}

		AVP service_Information = cca.find(873);
		if (service_Information == null) {
			resultString = "##>>> msisdn[" + msisdn + "] Diameter CheckBalance - No Service-Information[873] Found";
			logger.info(resultString);
		} else {
			try {
				AVP_Grouped serviceAvp_Grouped = new AVP_Grouped(service_Information);
				AVP[] avps = serviceAvp_Grouped.queryAVPs();

				for (int i = 0; i < avps.length; i++) {
					// System.out.println(">> avps.codes == " + avps[i].code);
					logger.debug(">> avps.codes == " + avps[i].code);
				}

				AVP_Grouped balance_Information = new AVP_Grouped(avps[1]);
				AVP[] bal_Info = balance_Information.queryAVPs();
				for (int j = 0; j < bal_Info.length; j++) {
					// System.out.println(" >> bal_info CODE array ==> "+bal_Info[j].code);
					logger.debug("##>>msisdn[" + msisdn + "] going to process for Code[" + bal_Info[j].code + "]");

					if (bal_Info[j].code == 30841) {
						AVP_Integer64 balance_code_Int64 = new AVP_Integer64(bal_Info[j]);
						double res_balance = balance_code_Int64.queryValue() / 100;
						// System.out.println("##>>> msisdn[" + msisdn
						// + "] Diameter Check Balance - balance response from the server =============
						// balance:["
						// + res_balance + "]");

						logger.info("##>>> msisdn[" + msisdn + "] main balance:[" + res_balance + "]");

						data_Object.balance = (int) res_balance;
						// balInfoBean.setBalance(data_Object.balance);
						// dataObject.setBalnceDetailData(res_balance + "");

					}
					if (bal_Info[j].code == 20349) {
						logger.debug("##>>msisdn[" + msisdn + "] going to process for code 20349");
						AVP account_change_Information = bal_Info[j];
						if (account_change_Information == null) {
							resultString = "##>>> msisdn[" + msisdn
									+ "] Diameter CheckBalance - No Service-Information[20349] Found";
							logger.warn(resultString);
						} else {

							// BalanceInfoBean balInfoBean = new BalanceInfoBean();
							AVP_Grouped accountAvp_Grouped = new AVP_Grouped(account_change_Information);
							AVP[] avps1 = accountAvp_Grouped.queryAVPs();
							int accountType = 0;
							long res_balance = 0l;
							String expiryTime = "";

							for (int i = 0; i < avps1.length; i++) {

								logger.debug("##>>msisdn[" + msisdn + "] going to process for avps1 code ["
										+ avps1[i].code + "]");

								if (avps1[i].code == 20372) {
									AVP_Integer32 accountType_avp = new AVP_Integer32(avps1[i]);
									// AVP_UTF8String accountType_avp=new AVP_UTF8String(avps1[i]);
									accountType = accountType_avp.queryValue();
									logger.debug("##>>> msisdn[" + msisdn
											+ "] Diameter Check Balance - at AVP CODE 20372 Account type :["
											+ accountType + "]");
								}

								if (avps1[i].code == 20350) {
									AVP_Integer64 balance_code_Int64 = new AVP_Integer64(avps1[i]);
									res_balance = balance_code_Int64.queryValue();
									logger.debug("##>>> msisdn[" + msisdn
											+ "] Diameter Check Balance - at AVP CODE  20350 balance:[ " + res_balance
											+ "]");
								}

								if (avps1[i].code == 20359) {
									AVP_UTF8String time_avp = new AVP_UTF8String(avps1[i]);
									expiryTime = time_avp.queryValue().toString();
									// System.out.println("##>>> msisdn[" + msisdn
									// + "] Diameter check Balnace - at AVP CODE 20359 Expiry :[" + expiryTime
									// + "]");
									logger.debug("##>>> msisdn[" + msisdn
											+ "] Diameter check Balnace - at AVP CODE 20359 Expiry :[" + expiryTime
											+ "]");

								}

							}

							if (accountType == 2000) {
								res_balance = res_balance / 100;
								data_Object.acc_2000_balance = (int) res_balance;
							} else if (accountType == 2001) {
								data_Object.acc_2001_balance = res_balance;
							} else if (accountType == 5018) {
								data_Object.acc_5018_balance = res_balance;
							} else if (accountType == 5017) {
								data_Object.acc_5017_balance = res_balance;
							} else if (accountType == 5016) {
								data_Object.acc_5016_balance = res_balance;
							}

							// Setting the values in BalanceInfoBean
							BalanceInfoBean balInfoBean = new BalanceInfoBean();
							balInfoBean.setAccId(accountType + "");
							balInfoBean.setBalance(res_balance);
							balInfoBean.setExpiryTime(expiryTime);
							balList.add(balInfoBean);
							/*
							 * changes by Ashu 
							 * 19-oct-2021 #8335
							 */
							
							data_Object.accountDetailInfoTable.put(accountType, balInfoBean);
							/*
							  */
						}

					}

				}

				// System.out.println(data_Object.getMsisdn() + " >> balanceInfoList [" +
				// balList + "]");
				logger.info("##>>msisdn[" + msisdn + "] total balanceInfoList found [" + balList.size() + "]."+" Balances"+data_Object.accountDetailInfoTable);
			} catch (InvalidAVPLengthException ex) {
				logger.error(
						"##>>> msisdn[" + msisdn
								+ "] Exception inside checkBalanceRequest method - balance result-code was illformed, ",
						ex);
				// System.out.println("##>>> msisdn[" + msisdn
				// + "] Exception inside checkBalanceRequest method - balance result-code was
				// illformed, " + ex);
				ex.printStackTrace();
				return l_result;
			}
		}

		try {
			AVP_Unsigned32 result_code_u32 = new AVP_Unsigned32(result_code);
			int rc = result_code_u32.queryValue();
			// System.out.println("##>>> msisdn[" + msisdn
			// + "] Diameter Check Balance - response from the server =================" +
			// rc);
			logger.info("##>>> msisdn[" + msisdn
					+ "] Diameter Check Balance - response from the server =================" + rc); // modified by
																										// Avishkar on
																										// 17.10.2018
			switch (rc) {
			case ProtocolConstants.DIAMETER_RESULT_SUCCESS:
				resultString = "##>>> msisdn[" + msisdn + "] Diameter Check Balance - ResultCode[" + rc
						+ "] ResultString[SUCCESS]"; // modified by Avishkar on 17.10.2018
				l_result = 1;
				break;
			case ProtocolConstants.DIAMETER_RESULT_END_USER_SERVICE_DENIED:
				resultString = "##>>> msisdn[" + msisdn + "] Diameter Check Balance - ResultCode[" + rc
						+ "] ResultString[End user service denied]"; // modified by Avishkar on 17.10.2018
				l_result = -1;
				break;
			case ProtocolConstants.DIAMETER_RESULT_CREDIT_CONTROL_NOT_APPLICABLE:
				resultString = "##>>> msisdn[" + msisdn + "] Diameter Check Balance - ResultCode[" + rc
						+ "] ResultString[Credit-control not applicable]"; // modified by Avishkar on 17.10.2018
				l_result = -1;
				break;
			case ProtocolConstants.DIAMETER_RESULT_CREDIT_LIMIT_REACHED:
				resultString = "##>>> msisdn[" + msisdn + "] Diameter Check Balance - ResultCode[" + rc
						+ "] ResultString[Credit-limit reached]"; // modified by Avishkar on 17.10.2018
				l_result = -1;
				break;
			case ProtocolConstants.DIAMETER_RESULT_USER_UNKNOWN:
				resultString = "##>>> msisdn[" + msisdn + "] Diameter Check Balance - ResultCode[" + rc
						+ "] ResultString[User unknown]"; // modified by Avishkar on 17.10.2018
				l_result = -1;
				break;
			case ProtocolConstants.DIAMETER_RESULT_RATING_FAILED:
				resultString = "##>>> msisdn[" + msisdn + "] Diameter Check Balance - ResultCode[" + rc
						+ "] ResultString[Rating failed]"; // modified by Avishkar on 17.10.2018
				l_result = -1;
				break;
			default:
				// Some other error
				// There are too many to decode them all.
				// We just print the classification
				if (rc >= 1000 && rc < 1999)
					resultString = "##>>> msisdn[" + msisdn + "] Diameter Check Balance - ResultCode[" + rc
							+ "] ResultCategory[Informational]"; // modified by Avishkar on 17.10.2018
				else if (rc >= 2000 && rc < 2999)
					resultString = "##>>> msisdn[" + msisdn + "] Diameter Check Balance - ResultCode[" + rc
							+ "] ResultCategory[Success]"; // modified by Avishkar on 17.10.2018
				else if (rc >= 3000 && rc < 3999)
					resultString = "##>>> msisdn[" + msisdn + "] Diameter Check Balance - ResultCode[" + rc
							+ "] ResultCategory[Protocl error]"; // modified by Avishkar on 17.10.2018
				else if (rc >= 4000 && rc < 4999)
					resultString = "##>>> msisdn[" + msisdn + "] Diameter Check Balance - ResultCode[" + rc
							+ "] ResultCategory[Transient failure]"; // modified by Avishkar on 17.10.2018
				else if (rc >= 5000 && rc < 5999)
					resultString = "##>>> msisdn[" + msisdn + "] Diameter Check Balance - ResultCode[" + rc
							+ "] ResultCategory[Permanent failure]"; // modified by Avishkar on 17.10.2018
				else
					resultString = "##>>> msisdn[" + msisdn + "] Diameter Check Balance - ResultCode[" + rc
							+ "] ResultCategory[unknown error class]"; // modified by Avishkar on 17.10.2018
			}
			// System.out.println(
			// resultString + " and Balance is [" + data_Object.getBalance() + "] and
			// Response[" + l_result + "]");
			logger.info(
					resultString + " and Balance is [" + data_Object.getBalance() + "] and Response[" + l_result + "]");

		} catch (InvalidAVPLengthException ex) {
			logger.error("##>>> msisdn[" + msisdn
					+ "] Exception inside checkBalanceRequest method - result-code was illformed, ", ex);
			// System.out.println("##>>> msisdn[" + msisdn
			// + "] Exception inside checkBalanceRequest method - result-code was illformed,
			// " + ex);
			ex.printStackTrace();
			return l_result;
		} catch (Exception e) {
			logger.error("##>>> msisdn[" + msisdn + "] Exception inside checkBalanceRequest method : ", e);
			// System.out.println("##>>> msisdn[" + msisdn + "] Exception inside
			// checkBalanceRequest method : " + e);
			e.printStackTrace();
			return l_result;
		} finally {
			resultString = null;
		}
		return l_result;

	}

}
