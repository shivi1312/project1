package com.charging.client.deduct;
                 
public class AcctChgRec
{
    private String CurrAcctBal;

    private String AccountID;

    private String CurrExpTime;

    private String MinMeasureId;

    private String ChgExpTime;

    private String ChgAcctBal;

    private String AccountType;

    public String getCurrAcctBal ()
    {
        return CurrAcctBal;
    }

    public void setCurrAcctBal (String CurrAcctBal)
    {
        this.CurrAcctBal = CurrAcctBal;
    }

    public String getAccountID ()
    {
        return AccountID;
    }

    public void setAccountID (String AccountID)
    {
        this.AccountID = AccountID;
    }

    public String getCurrExpTime ()
    {
        return CurrExpTime;
    }

    public void setCurrExpTime (String CurrExpTime)
    {
        this.CurrExpTime = CurrExpTime;
    }

    public String getMinMeasureId ()
    {
        return MinMeasureId;
    }

    public void setMinMeasureId (String MinMeasureId)
    {
        this.MinMeasureId = MinMeasureId;
    }

    public String getChgExpTime ()
    {
        return ChgExpTime;
    }

    public void setChgExpTime (String ChgExpTime)
    {
        this.ChgExpTime = ChgExpTime;
    }

    public String getChgAcctBal ()
    {
        return ChgAcctBal;
    }

    public void setChgAcctBal (String ChgAcctBal)
    {
        this.ChgAcctBal = ChgAcctBal;
    }

    public String getAccountType ()
    {
        return AccountType;
    }

    public void setAccountType (String AccountType)
    {
        this.AccountType = AccountType;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [CurrAcctBal = "+CurrAcctBal+", AccountID = "+AccountID+", CurrExpTime = "+CurrExpTime+", MinMeasureId = "+MinMeasureId+", ChgExpTime = "+ChgExpTime+", ChgAcctBal = "+ChgAcctBal+", AccountType = "+AccountType+"]";
    }
}
			
			