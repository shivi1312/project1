package com.charging.client.deduct;
public class Data
{
    private AcctChgRec AcctChgRec;

    public AcctChgRec getAcctChgRec ()
    {
        return AcctChgRec;
    }

    public void setAcctChgRec (AcctChgRec AcctChgRec)
    {
        this.AcctChgRec = AcctChgRec;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [AcctChgRec = "+AcctChgRec+"]";
    }
}
			