package com.charging.client.bouns;
                 
public class Data
{
    private AdjustAccountResult AdjustAccountResult;

    private ResultHeader ResultHeader;

    public AdjustAccountResult getAdjustAccountResult ()
    {
        return AdjustAccountResult;
    }

    public void setAdjustAccountResult (AdjustAccountResult AdjustAccountResult)
    {
        this.AdjustAccountResult = AdjustAccountResult;
    }

    public ResultHeader getResultHeader ()
    {
        return ResultHeader;
    }

    public void setResultHeader (ResultHeader ResultHeader)
    {
        this.ResultHeader = ResultHeader;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [AdjustAccountResult = "+AdjustAccountResult+", ResultHeader = "+ResultHeader+"]";
    }
}
			
			