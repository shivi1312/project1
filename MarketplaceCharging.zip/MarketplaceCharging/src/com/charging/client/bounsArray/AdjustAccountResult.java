package com.charging.client.bounsArray;

import java.util.Arrays;
                 
public class AdjustAccountResult
{
    private AcctChgRec[] AcctChgRec;

    public AcctChgRec[] getAcctChgRec ()
    {
        return AcctChgRec;
    }

    public void setAcctChgRec (AcctChgRec[] AcctChgRec)
    {
        this.AcctChgRec = AcctChgRec;
    }

	@Override
	public String toString() {
		return "AdjustAccountResult [AcctChgRec=" + Arrays.toString(AcctChgRec)
				+ "]";
	}

   
}
			
			