package com.charging.client.reqbal;
                 
public class BalanceRecord
{
    private String AccountKey;

    private String BalanceDescTrans;

    private String BalanceDesc;

    private String ExpireTime;

    private String MinMeasureId;

    private String Balance;

    private String UnitType;

    private String AccountType;

    public String getAccountKey ()
    {
        return AccountKey;
    }

    public void setAccountKey (String AccountKey)
    {
        this.AccountKey = AccountKey;
    }

    public String getBalanceDescTrans ()
    {
        return BalanceDescTrans;
    }

    public void setBalanceDescTrans (String BalanceDescTrans)
    {
        this.BalanceDescTrans = BalanceDescTrans;
    }

    public String getBalanceDesc ()
    {
        return BalanceDesc;
    }

    public void setBalanceDesc (String BalanceDesc)
    {
        this.BalanceDesc = BalanceDesc;
    }

    public String getExpireTime ()
    {
        return ExpireTime;
    }

    public void setExpireTime (String ExpireTime)
    {
        this.ExpireTime = ExpireTime;
    }

    public String getMinMeasureId ()
    {
        return MinMeasureId;
    }

    public void setMinMeasureId (String MinMeasureId)
    {
        this.MinMeasureId = MinMeasureId;
    }

    public String getBalance ()
    {
        return Balance;
    }

    public void setBalance (String Balance)
    {
        this.Balance = Balance;
    }

    public String getUnitType ()
    {
        return UnitType;
    }

    public void setUnitType (String UnitType)
    {
        this.UnitType = UnitType;
    }

    public String getAccountType ()
    {
        return AccountType;
    }

    public void setAccountType (String AccountType)
    {
        this.AccountType = AccountType;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [AccountKey = "+AccountKey+", BalanceDescTrans = "+BalanceDescTrans+", BalanceDesc = "+BalanceDesc+", ExpireTime = "+ExpireTime+", MinMeasureId = "+MinMeasureId+", Balance = "+Balance+", UnitType = "+UnitType+", AccountType = "+AccountType+"]";
    }
}