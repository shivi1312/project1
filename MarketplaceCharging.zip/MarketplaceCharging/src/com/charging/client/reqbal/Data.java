package com.charging.client.reqbal;
               
public class Data
{
    private BalanceRecord[] BalanceRecord;

    public BalanceRecord[] getBalanceRecord ()
    {
        return BalanceRecord;
    }

    public void setBalanceRecord (BalanceRecord[] BalanceRecord)
    {
        this.BalanceRecord = BalanceRecord;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [BalanceRecord = "+BalanceRecord+"]";
    }
}
			
		