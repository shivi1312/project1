package com.telemune.main;

import com.telemune.api.ApiAccess;
import com.telemune.bean.ApiResponse;
import com.telemune.bean.LoginRequest;
import com.telemune.bean.LoginResponse;
import com.telemune.filereader.ProprtyFileRederValue;
import com.telemune.request.RequestData;

public class CwcApplication {
	public static void main(String[] args) {
       //1. Login Request
		String loginRequest = RequestData.loginData(new LoginRequest(ProprtyFileRederValue.USER_ID,ProprtyFileRederValue.PASSWORD));
		System.out.println(loginRequest);
		//2. Login Api Call
		LoginResponse loginResponse = ApiAccess.loginApiCall(loginRequest);
		System.out.println(loginResponse);
		
		if(loginResponse.getStatusCode()==200) {
			//3. Flag Up Request
			String flagUpRequest = RequestData.flagUpData(loginResponse.getSessionId()); 
			
			ApiResponse apiResponse	=ApiAccess.flagUpApiCall(flagUpRequest);
		
			
			//4. Flag Down Request
			
			if (apiResponse.getStatusCode() == 200) {
			
			String flagDownRequest = RequestData.flagDownData(loginResponse.getSessionId());
			ApiAccess.flagDownApiCall(flagDownRequest);
		}
		}
				else {
					
					//5. Logout Request
				
			String logoutRequest = RequestData.logoutData(loginResponse.getSessionId());
			ApiAccess.loginApiCall(logoutRequest);
			
			
		}
	}
}

