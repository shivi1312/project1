package com.telemune.bean;

public class ApiResponse {
	
	private int statusCode;
	private String statusMessage;
    private String message;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "ApiResponse [statusCode=" + statusCode + ", statusMessage=" + statusMessage + ", message=" + message
				+ "]";
	}
	public ApiResponse(int statusCode, String statusMessage, String message) {
		super();
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
		this.message = message;
	}
	public ApiResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
