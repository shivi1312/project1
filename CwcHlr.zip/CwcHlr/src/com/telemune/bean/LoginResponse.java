package com.telemune.bean;

public class LoginResponse {

	private String sessionId;

	private String baseSequenceId;

	private int statusCode;

	public String getSessionId() {
		return sessionId;
	}

	public LoginResponse() {
		super();
	}
	
	public LoginResponse(String sessionId, String baseSequenceId, int statusCode) {
		super();
		this.sessionId = sessionId;
		this.baseSequenceId = baseSequenceId;
		this.statusCode = statusCode;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getBaseSequenceId() {
		return baseSequenceId;
	}

	public void setBaseSequenceId(String baseSequenceId) {
		this.baseSequenceId = baseSequenceId;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	@Override
	public String toString() {
		return "LoginResponse [sessionId=" + sessionId + ", baseSequenceId=" + baseSequenceId + ", statusCode="
				+ statusCode + "]";
	}

}
