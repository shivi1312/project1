package com.telemune.request;

import com.telemune.bean.LoginRequest;

public class RequestData {

	public static String loginData(LoginRequest loginRequest) {
		String loginData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cai3=\"http://schemas.ericsson.com/cai3g1.2/\"><soapenv:Header/><soapenv:Body><cai3:Login><cai3:userId>"+loginRequest.getUserId() +"</cai3:userId><cai3:pwd>"+loginRequest.getPwd()+"</cai3:pwd></cai3:Login></soapenv:Body></soapenv:Envelope>\r\n";
		return loginData;
	}

	public static String flagUpData(String sessionId) {

		String flagUpData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cai3=\"http://schemas.ericsson.com/cai3g1.2/\" xmlns:mtas=\"http://schemas.ericsson.com/ema/UserProvisioning/MTAS/\">\r\n"
				+ "<soapenv:Header>\r\n" + "<cai3:SequenceId>865517758</cai3:SequenceId>\r\n"
				+ "<cai3:TransactionId>1087</cai3:TransactionId>\r\n"
				+ "<cai3:SessionId>"+sessionId+"</cai3:SessionId>\r\n" + "</soapenv:Header>\r\n"
				+ "<soapenv:Body>\r\n" + "<cai3:Set>\r\n"
				+ "<cai3:MOType>Subscription@http://schemas.ericsson.com/ema/UserProvisioning/MTAS/</cai3:MOType>\r\n"
				+ "<cai3:MOId>\r\n"
				+ "<mtas:publicId>sip:+18769907318@ims.mnc180.mcc338.3gppnetwork.org</mtas:publicId>\r\n"
				+ "</cai3:MOId>\r\n" + "<cai3:MOAttributes>\r\n"
				+ "<mtas:setSubscription publicId=\"sip:+18769907318@ims.mnc180.mcc338.3gppnetwork.org\">\r\n"
				+ "<mtas:services>\r\n" + "<mtas:customized-alerting-tone>\r\n"
				+ "<mtas:cat-operator-configuration>\r\n" + "<mtas:activated>true</mtas:activated>\r\n"
				+ "</mtas:cat-operator-configuration>\r\n" + "</mtas:customized-alerting-tone>\r\n"
				+ "</mtas:services>\r\n" + "</mtas:setSubscription>\r\n" + "</cai3:MOAttributes>\r\n"
				+ "</cai3:Set>\r\n" + "</soapenv:Body>\r\n" + "</soapenv:Envelope>\r\n" + "";

		return flagUpData;
	}

	public static String flagDownData(String sessionId) {

		String flagDownData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cai3=\"http://schemas.ericsson.com/cai3g1.2/\" xmlns:mtas=\"http://schemas.ericsson.com/ema/UserProvisioning/MTAS/\">\r\n"
				+ "<soapenv:Header>\r\n" + "<cai3:SessionId>"+sessionId+"</cai3:SessionId>\r\n"
				+ "</soapenv:Header>\r\n" + "<soapenv:Body>\r\n" + "<cai3:Set>\r\n"
				+ "<cai3:MOType>Subscription@http://schemas.ericsson.com/ema/UserProvisioning/MTAS/</cai3:MOType>\r\n"
				+ "<cai3:MOId>\r\n"
				+ "<mtas:publicId>sip:+18769907318@ims.mnc180.mcc338.3gppnetwork.org</mtas:publicId>\r\n"
				+ "</cai3:MOId>\r\n" + "<cai3:MOAttributes>\r\n"
				+ "<mtas:setSubscription publicId=\"sip:+18769907318@ims.mnc180.mcc338.3gppnetwork.org\">\r\n"
				+ "<mtas:services>\r\n" + "<mtas:customized-alerting-tone>\r\n"
				+ "<mtas:cat-operator-configuration>\r\n" + "<mtas:activated>false</mtas:activated>\r\n"
				+ "</mtas:cat-operator-configuration>\r\n" + "</mtas:customized-alerting-tone>\r\n"
				+ "</mtas:services>\r\n" + "</mtas:setSubscription>\r\n" + "</cai3:MOAttributes>\r\n"
				+ "</cai3:Set>\r\n" + "</soapenv:Body>\r\n" + "</soapenv:Envelope>\r\n" + "";

		return flagDownData;
	}

	public static String logoutData(String sessionId) {
		String logoutData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:cai3=\"http://schemas.ericsson.com/cai3g1.2/\">\r\n"
				+ "   <soapenv:Header>\r\n"
				+ "      <cai3:SessionId>"+sessionId+"</cai3:SessionId>\r\n"
				+ "   </soapenv:Header>\r\n" + "   <soapenv:Body>\r\n" + "      <cai3:Logout>\r\n"
				+ "         <cai3:sessionId>a909bc0c6927400cb1a325e91877ab81</cai3:sessionId>\r\n"
				+ "      </cai3:Logout>\r\n" + "   </soapenv:Body>\r\n" + "</soapenv:Envelope>\r\n" + "";
		return logoutData;
	}

}
