package com.telemune.filereader;

public interface ProprtyFileRederValue {
	public static final String USER_ID = ProperyFileReader.getPropertyValue("UserId");
	public static final String PASSWORD = ProperyFileReader.getPropertyValue("Pwd");
}
