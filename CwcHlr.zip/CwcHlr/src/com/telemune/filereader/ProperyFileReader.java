package com.telemune.filereader;

import java.io.InputStream;
import java.util.Properties;

public class ProperyFileReader {
	
	public static String getPropertyValue(String key) {
		Properties properties = new Properties();
		try {
			InputStream in = ProperyFileReader.class.getClassLoader().getResourceAsStream("application.properties");
			properties.load(in);
			return properties.getProperty(key);
		} catch (Exception e) {
		
		}
		return properties.getProperty(key);
	}

}
