package com.telemune.assembler;

import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.telemune.bean.LoginResponse;

public class Assembler {

	public static LoginResponse addResponseXmlToBean(String xmlData,int statusCode) {
		LoginResponse loginResponse = new LoginResponse();
		try {
			//String xmlData = "<?xml version='1.0' encoding='UTF-8'?><S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\"><S:Body><LoginResponse xmlns=\"http://schemas.ericsson.com/cai3g1.2/\"><sessionId>392fa4d7e2854066814e4c2658d67b49</sessionId><baseSequenceId>1816513353</baseSequenceId></LoginResponse></S:Body></S:Envelope>";
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = null;
			
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(xmlData)));

			loginResponse.setSessionId(doc.getElementsByTagName("sessionId").item(0).getTextContent());
			loginResponse.setBaseSequenceId(doc.getElementsByTagName("baseSequenceId").item(0).getTextContent());
			loginResponse.setStatusCode(statusCode);

			return loginResponse;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return loginResponse;
	}



}