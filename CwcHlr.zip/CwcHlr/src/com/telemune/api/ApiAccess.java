package com.telemune.api;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import com.telemune.assembler.Assembler;
import com.telemune.bean.ApiResponse;
import com.telemune.bean.LoginResponse;

public class ApiAccess {

	public static LoginResponse loginApiCall(String requestBody) {
		LoginResponse loginResponse = null;
		StringBuilder response = new StringBuilder();
		try {
			URL url = new URL("http://10.236.112.10:8080/CAI3G1.2/services/CAI3G1.2");

			HttpURLConnection http = (HttpURLConnection) url.openConnection();

			http.setRequestMethod("POST");
			http.setDoOutput(true);
			http.setRequestProperty("Content-Type", "text/xml");

			byte[] out = requestBody.getBytes(StandardCharsets.UTF_8);

			OutputStream stream = http.getOutputStream();
			stream.write(out);

			System.out.println(http.getResponseCode() + " " + http.getResponseMessage());
			
				InputStream inputStream = http.getInputStream();
				byte[] res = new byte[2048];
				int i = 0;

				while ((i = inputStream.read(res)) != -1) {
					response.append(new String(res, 0, i));
				}
				
				System.out.println("Response= " + response.toString());

				inputStream.close();
				http.disconnect();
				
				loginResponse = Assembler.addResponseXmlToBean(response.toString(),http.getResponseCode());
				
				if(loginResponse!=null) {
					return loginResponse;
				}
				else {
					throw new Exception("Response Not Found!!! ");
				}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return loginResponse;
	}
	
	public static ApiResponse flagUpApiCall(String requestBody) {
		ApiResponse apiResponse = null;
		StringBuilder response = new StringBuilder();
		try {
			URL url = new URL("http://10.236.112.10:8080/CAI3G1.2/services/CAI3G1.2");

			HttpURLConnection http = (HttpURLConnection) url.openConnection();

			http.setRequestMethod("POST");
			http.setDoOutput(true);
			http.setRequestProperty("Content-Type", "text/xml");

			byte[] out = requestBody.getBytes(StandardCharsets.UTF_8);

			OutputStream stream = http.getOutputStream();
			stream.write(out);

			System.out.println(http.getResponseCode() + " " + http.getResponseMessage());
			
				InputStream inputStream = http.getInputStream();
				byte[] res = new byte[2048];
				int i = 0;

				while ((i = inputStream.read(res)) != -1) {
					response.append(new String(res, 0, i));
				}
				
				System.out.println("Response= " + response.toString());

				inputStream.close();
				http.disconnect();
				apiResponse = new ApiResponse(http.getResponseCode(),http.getResponseMessage(), "Flagup Success" );
				
				if(apiResponse!=null) {
				return apiResponse;
				}
				else {
		         	throw new Exception("Response Not Found!!! ");
				}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return apiResponse;
	}

	
	
	
	public static ApiResponse flagDownApiCall(String requestBody) {
		ApiResponse apiResponse = null;
		StringBuilder response = new StringBuilder();
		try {
			URL url = new URL("http://10.236.112.10:8080/CAI3G1.2/services/CAI3G1.2");

			HttpURLConnection http = (HttpURLConnection) url.openConnection();

			http.setRequestMethod("POST");
			http.setDoOutput(true);
			http.setRequestProperty("Content-Type", "text/xml");

			byte[] out = requestBody.getBytes(StandardCharsets.UTF_8);

			OutputStream stream = http.getOutputStream();
			stream.write(out);

			System.out.println(http.getResponseCode() + " " + http.getResponseMessage());
			
				InputStream inputStream = http.getInputStream();
				byte[] res = new byte[2048];
				int i = 0;

				while ((i = inputStream.read(res)) != -1) {
					response.append(new String(res, 0, i));
				}
				
				System.out.println("Response= " + response.toString());

				inputStream.close();
				http.disconnect();
				apiResponse = new ApiResponse(http.getResponseCode(),http.getResponseMessage(), "Flagdown Success" );
				
				if(apiResponse!=null) {
				return apiResponse;
				}
				else {
		         	throw new Exception("Response Not Found!!! ");
				}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return apiResponse;
	}

	
	public static ApiResponse logoutApiCall(String requestBody) {
		ApiResponse apiResponse = null;
		StringBuilder response = new StringBuilder();
		try {
			URL url = new URL("http://10.236.112.10:8080/CAI3G1.2/services/CAI3G1.2");

			HttpURLConnection http = (HttpURLConnection) url.openConnection();

			http.setRequestMethod("POST");
			http.setDoOutput(true);
			http.setRequestProperty("Content-Type", "text/xml");

			byte[] out = requestBody.getBytes(StandardCharsets.UTF_8);

			OutputStream stream = http.getOutputStream();
			stream.write(out);

			System.out.println(http.getResponseCode() + " " + http.getResponseMessage());
			
				InputStream inputStream = http.getInputStream();
				byte[] res = new byte[2048];
				int i = 0;

				while ((i = inputStream.read(res)) != -1) {
					response.append(new String(res, 0, i));
				}
				
				System.out.println("Response= " + response.toString());

				inputStream.close();
				http.disconnect();
				apiResponse = new ApiResponse(http.getResponseCode(),http.getResponseMessage(), "Logout Success" );
				
				if(apiResponse!=null) {
				return apiResponse;
				}
				else {
		         	throw new Exception("Response Not Found!!! ");
				}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return apiResponse;
	}

	
	
	
	
	
	
}


