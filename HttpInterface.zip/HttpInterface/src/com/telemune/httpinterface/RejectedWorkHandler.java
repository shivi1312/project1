package com.telemune.httpinterface;

import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import org.apache.log4j.Logger;

public class RejectedWorkHandler implements RejectedExecutionHandler{

    Logger logger = Logger.getLogger(RejectedWorkHandler.class);

	@Override
   	public void rejectedExecution(Runnable r, ThreadPoolExecutor executor)  {
		try {
                	   Thread.sleep(1);
 		}catch (InterruptedException e) {
    			e.printStackTrace();
       		}
        	try{
			logger.info("Task is Rejected. Again Submitting to ThreadPool");
        		executor.execute(r);
        	}catch(RejectedExecutionException re){
	        	logger.error("Problem In  Submitting task because Its too late processing, Please check your Processing time of Server(Good Option) or increase thread pool queue size(Bad Option) ",re);
        	}
   	}
}

