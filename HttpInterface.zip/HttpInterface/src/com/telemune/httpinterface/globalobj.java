
/*
 * globalobj.java
 *
 * Created on June 9, 2010, 3:52 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.telemune.httpinterface;

/**
 *
 * @author ashu
 */
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
public class globalobj
{
    
    /** Creates a new instance of globalobj */
 	public static ArrayBlockingQueue datarecvque=new ArrayBlockingQueue(100000);
 	public static ArrayBlockingQueue datasendque = new ArrayBlockingQueue(100000);
//		public static ArrayList clientList=new ArrayList();
		public static HashMap clientList=new HashMap();
		public static HashMap actionList=new HashMap();
		public static HashMap<String,String> errorList =new HashMap<String,String>();
		public static HashMap<String,req_class> pushReq =new HashMap<String,req_class>();
		public static Map<String,req_class> mp=new HashMap<String,req_class>();
		public static int TIMEOUT=-1;
		public static int MSGLENGTH=0;
		public static int HTTP_READ_TIMEOUT=-1;
		public static int RELOADTIME=25000;
		public static int lang=-1;
		public static int push_header_enable=0;
		public static int pull_header_enable=0;
		public static int encript_decript_flag=0;
		
}
