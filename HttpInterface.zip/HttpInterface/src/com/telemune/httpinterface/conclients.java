

/*
 * conclients.java
 *
 * Created on June 9, 2010, 5:09 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.telemune.httpinterface;

/**
 *
 * @author ashu
 */
public class conclients {

				/** Creates a new instance of conclients */
				public conclients() {
				}
				public String url="";
				public String shortcode="";
				public String service_type="";
				public String service_name="";
				public String error_resp="";
				public String user_name="";
				public String password="";
				public int http_read_timeout=-1;

}
