

/*
 * AppResources.java
 *
 * Created on June 9, 2010, 6:10 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.telemune.httpinterface;

/**
 *
 * @author ashu
 */
//import dbutility.*;
import java.io.*;
import java.lang.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import org.apache.log4j.*;

public class AppResources implements Runnable
{

	/** Creates a new instance of AppResources */
	Connection con=null;
	ResultSet rs=null;
	Statement stmt=null;
	String  query=null;
	Socket sock=null;
	String dbname="";
	String uname="crbt";
	String pwd="crbt";
	String driver="";
	String url="";
	Logger logger=null;


	boolean alreadyadd=false;
	Thread thrd=new Thread();
	public AppResources() 
	{
		try
		{
			logger=Logger.getLogger(AppResources.class.getName());

		}catch(Exception eE)
		{


		}

		Properties chrPro = new Properties();
		try
		{
			FileInputStream fins=new FileInputStream("property/ussdgw.properties");
			chrPro.load(fins);
			fins.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
			logger.error(ioe.getMessage());
			System.exit(1);
		}
		try
		{
			uname=chrPro.getProperty("DBUSER");
			pwd=chrPro.getProperty("DBPASSWORD");
			url=chrPro.getProperty("DBURL");
			driver=chrPro.getProperty("DRIVER");

		}
		catch (Exception sqle)
		{
			logger.error("Exception Connection Creating" +sqle.toString());
		}
		try
		{
			Class.forName(driver);
		}catch(ClassNotFoundException  E)
		{
			logger.error("Driver class not found "+ E.getMessage());
			System.exit(1);
		}	catch(Exception e)
		{
			logger.error("Cant load driver "+e.toString());
			System.exit(1);
		}
		try
		{
			con=DriverManager.getConnection(url,uname,pwd);
			logger.info("Connection Success ");

		}catch(Exception eE)
		{
			logger.error("Cant connect to DB "+eE.getMessage());
			System.exit(1);
		}
	}
	public void run()
	{
		try
		{
			while(true)
			{
				stmt=con.createStatement();
				query="select USER_NAME,PASSWORD,SERVICE_TYPE,URL,HTTP_READ_TIMEOUT,CODE,SERVICE_NAME,ERROR_RESP from USSD_USERS a,USSD_SERVICE_CODE b where a.INTERFACE_TYPE='HTTP' and a.USER_ID=b.USER_ID";
				logger.info("query==="+query);
				rs=stmt.executeQuery(query);
				while(rs.next())
				{
					try
					{
						conclients cnc =new conclients();
						cnc.url=rs.getString("URL");
						cnc.user_name=rs.getString("USER_NAME");
						cnc.shortcode=rs.getString("CODE");
						cnc.service_type=rs.getString("SERVICE_TYPE");
						cnc.service_name=rs.getString("SERVICE_NAME");
						cnc.error_resp=rs.getString("ERROR_RESP");
						cnc.password=rs.getString("PASSWORD");
						if(rs.getString("HTTP_READ_TIMEOUT").equals("-1"))
						{
							cnc.http_read_timeout=globalobj.HTTP_READ_TIMEOUT;
						}
						else
						{
							cnc.http_read_timeout=rs.getInt("HTTP_READ_TIMEOUT");
						}
						globalobj.clientList.put(cnc.shortcode,cnc);
						/*alreadyadd=false;
						  for(int i=0;i<globalobj.clientList.size();i++)
						  {
						  conclients cnccheck =(conclients)globalobj.clientList.get(i);
						  if(cnc.code==cnccheck.code)
						  {
						  alreadyadd=true;
						  break;
						  }
						  }
						  if(!alreadyadd)
						  {
						  globalobj.clientList.add(cnc);
						  }*/
					}
					catch(Exception see)
					{
						logger.error("Can't insert into HashTable1 "+see.toString());
					}
				}
				rs.close();
				stmt.close();

				stmt=con.createStatement();
				query="select ACTION_ID,ACTION_NAME, USER_NAME ,USER_PASSWORD ,CONNECTION_STRING from USSD_LEAF_ACTION_DETAIL where INTERFACE_TYPE='HTTP'";
				logger.info("query==="+query);
				rs=stmt.executeQuery(query);
				while(rs.next())
				{
					try
					{
						Action action =new Action();
						action.url=rs.getString("CONNECTION_STRING");
						action.user_name=rs.getString("USER_NAME");
						action.action_id=rs.getInt("ACTION_ID");
						action.action_name=rs.getString("ACTION_NAME");
						action.password=rs.getString("USER_PASSWORD");
						globalobj.actionList.put(action.action_id,action);
					}
					catch(Exception see)
					{
						logger.error("Can't insert into HashTable2 "+see.toString());
					}
				}
				rs.close();
				stmt.close();

				stmt=con.createStatement();
				query="select ERR_CODE, ERR_STR, LANG_ID from USSD_ERROR_CODE";
				logger.info("query==="+query);
				rs=stmt.executeQuery(query);
				while(rs.next())
				{
					try
					{
						ErrorCode errorCode =new ErrorCode();
						errorCode.code=rs.getInt("ERR_CODE");
						errorCode.lang=rs.getInt("LANG_ID");
						errorCode.errorString=rs.getString("ERR_STR");
						globalobj.errorList.put(errorCode.code+"_"+errorCode.lang,errorCode.errorString);
					}
					catch(Exception see)
					{
						logger.error("Can't insert into Hashtable3 "+see.toString());
					}
				}
				rs.close();
				stmt.close();

				try
				{
					logger.info("cache reload");
					thrd.sleep(globalobj.RELOADTIME);
				}
				catch(Exception exp)
				{
					exp.printStackTrace();
				}
			}

		}
		catch(Exception appresexp)
		{
			appresexp.printStackTrace();

		}
	}
}
