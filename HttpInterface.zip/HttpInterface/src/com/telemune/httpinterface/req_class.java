
/*
 * req_class.java
 *
 * Created on June 9, 2010, 12:58 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package com.telemune.httpinterface;



import java.net.*;
import java.io.*;
class req_class
{
    String user_msisdn="";
    long dialog_id=-1;
				String cnccode="";
				String url="";
				String sessionId="";
				String short_code="";
				int http_read_timeout=-1;
				boolean isPush=false;
}

