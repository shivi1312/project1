

/*
 * ProcessServer.java
 *
 * Created on June 22, 2010, 2:01 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.telemune.httpinterface;

/**
 *
 * @author ashu
 */

import TlvLib.*;
import java.io.*;
import java.net.InetSocketAddress;
import java.util.*;
import java.sql.*;
import java.net.*;

import com.google.gson.Gson;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import com.telemune.httpinterface.bean.PushRequestBody;
import com.telemune.httpinterface.bean.PushResponseBody;

import org.apache.log4j.*;

public class ProcessServer implements Runnable 
{
static Logger logger=Logger.getLogger(ProcessServer.class.getName());
//	  Map<String,req_class> pushReq =new HashMap<String,req_class>();

	/** Creates a new instance of ProcessServer */
	Connection con=null;
	ResultSet rs=null;
	PreparedStatement pstmt=null;
	String userName="",password="",data="",dlId="",msisdn="",shortCode="",opCode="";
	Headers responseHeaders=null;
	boolean validEntry=true,authFlag=true,isPush=false;
	OutputStream responseBody=null;
	HttpExchange exchange=null;
	String uname=null,pwd=null,url=null,driver=null;
	String sessionId=null;
	String validUser=null;

	public ProcessServer(PushRequestBody requestBody,HttpExchange exchange)
	{

		this.userName=requestBody.getUserName();
		this.password=requestBody.getPassword();
		this.dlId=requestBody.getDlId();
		this.data=requestBody.getData();
		this.msisdn=requestBody.getMsisdn();
		this.shortCode=requestBody.getShortCode();
		this.opCode=requestBody.getOpCode();
		this.exchange=exchange;
	}
	
	public ProcessServer(String userName,String password,String dlId,String data,String msisdn,String shortCode,String opCode,Headers responseHeaders,HttpExchange exchange)
	{

		this.userName=userName;
		this.password=password;
		this.dlId=dlId;
		this.data=data;
		this.msisdn=msisdn;
		this.shortCode=shortCode;
		this.opCode=opCode;
		this.responseHeaders=responseHeaders;
		this.exchange=exchange;
	}
	
	public void run()
	{
		logger.info("Inside Run method of Process Server");
		try
		{
			validEntry=true;
			authFlag=false;
			isPush=false;
		
			if(userName.length()==0)
			{
				validEntry=false;
				logger.info("User Name is not Valid");
			}
			if(password.length()==0)
			{
				validEntry=false;
				logger.info("Password is not Valid");
			}

			if(validEntry)
			{
				logger.info("For Check Authentication Function");
				authFlag=checkAuthentication();
				logger.info("Authentication Function Return Flag || "+authFlag);

			}

			if(dlId.length()==0)
			{
				validEntry=false;
				logger.info("DialogId is not Valid ");
			}

			if(data.length()==0)
			{
				validEntry=false;
				logger.info("Data is not Valid");
			}
			if(msisdn.length()==0)
			{
				validEntry=false;
				logger.info("Msisdn is not Valid");
			}
			if(shortCode.length()==0)
			{
				validEntry=false;
				logger.info("Short Codes  is not Valid");
			}
			if(opCode.length()==0)
			{
				validEntry=false;
				logger.info("OpCode is not Valid");
			}

			

			if(authFlag&&validEntry)
			{
				validUser="0";
				req_class req=new req_class();
				logger.info("Success:: User Is authenticate ");
				//responseHeaders.set("Content-Type", "text/plain");
				//responseHeaders.set("VALIDUSER", "0");
				isPush=true;
				logger.info("User Is authenticate  VALIDUSER ");
				sessionId=System.currentTimeMillis()+"";	
				user_data data_obj =new user_data();
				data_obj.op_code=Integer.parseInt(opCode);
				data_obj.user_data=data;
				data_obj.user_msisdn=msisdn;
				data_obj.dialog_id=Integer.parseInt(dlId);
				data_obj.short_code=shortCode;
				data_obj.isPush=isPush;
				sessionId=sessionId.concat(msisdn.substring(msisdn.length()-5,msisdn.length()-1));
				
				logger.info("session ID is [  "+sessionId+"]");
				data_obj.sessionId=sessionId;
				req.user_msisdn=data_obj.user_msisdn;
                                req.dialog_id=data_obj.dialog_id;
				req.sessionId=data_obj.sessionId;
				req.isPush=isPush;
				req.short_code=data_obj.short_code;
				logger.info("session id from req is"+req.sessionId);
				globalobj.pushReq.put(data_obj.sessionId,req);
				//globalobj.datasendque.enqueue(data_obj);
				globalobj.datasendque.put(data_obj);
			}
			else if(!authFlag)
			{
				logger.info("Error:: User Is  not authenticate  INVALIDUSER ");
				validUser="-2";
				sessionId="-1";

			}
			else if(!validEntry)
			{
				logger.info("Error:: Some Argument Missing  INVALIDARGUMENT ");
				validUser="-2";
				sessionId="-1";
			}
			
			if(globalobj.push_header_enable==1)
			{
				logger.info("====Sending Response Through Headers=====");
				sendResponseThroughResponseHeaders(validUser,sessionId,exchange);
			}
			else
			{
				logger.info("===Sending Response through Response Body===");
				sendResponseThroughResponseBody(validUser,sessionId,exchange);
			}
			
			

		}
		catch(Exception exprocess)
		{
			exprocess.printStackTrace();
		}
	}


	public boolean checkAuthentication()
	{

		Properties chrPro = new Properties();
		try
		{
			FileInputStream fins=new FileInputStream("property/ussdgw.properties");
			chrPro.load(fins);
			fins.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
			logger.error(ioe.getMessage());
			System.exit(1);
		}
		try
		{
			uname=chrPro.getProperty("DBUSER");
			pwd=chrPro.getProperty("DBPASSWORD");
			url=chrPro.getProperty("DBURL");
			driver=chrPro.getProperty("DRIVER");


			logger.info("Connection to DataBase DBUSER [ "+uname+"] DBPASSWORD ["+pwd+"] DBURL ["+url +"] DRIVER ["+driver+" ]");

		}
		catch(Exception expset)
		{
			logger.error("ReadExce:"+expset.toString());
		}
		try
		{
			Class.forName(driver);
		}catch(ClassNotFoundException  E)
		{
			logger.error("Driver class not found "+ E.getMessage());
			System.exit(1);
		}       catch(Exception e)
		{
			logger.error("Cant load driver "+e.toString());
			System.exit(1);
		}
		try
		{
			con=DriverManager.getConnection(url,uname,pwd);
			logger.info("Connection Success ");

		}catch(Exception eE)
		{
			logger.error("Cant connect to DB "+eE.getMessage());
			System.exit(1);

		}




			boolean flag=false;

			PreparedStatement pstmt=null;
			try
			{

				logger.info("CHeck Authentication for USER_NAME || "+userName+" PASSWORD ||"+password);

				String query="select USER_NAME,PASSWORD from USSD_USERS where USER_NAME=?and PASSWORD=?";
				pstmt=con.prepareStatement(query);

				pstmt.setString(1,userName);
				pstmt.setString(2,password);
				rs=pstmt.executeQuery();


				if(rs.next())
				{
					logger.info("UserName And Password is valid");
					flag=true;

				}
				else
				{

					flag=false;

					logger.info("NO record fetch from USSD_USERS table ["+userName+"] Password ["+password+"]");

				}


				rs.close();
				pstmt.close();
			}
			catch(Exception sqlE)
			{

				try
				{
					pstmt.close();
				}
				catch(SQLException sqe){}

				sqlE.printStackTrace();	

				logger.error("Error in SQL:::"+sqlE.toString());
				flag=false;
			}

			finally
			{
				try
				{
					if(con!=null)
					{con.close();}
				}catch(Exception e){}
			}

		
			return flag;

		}
	public void sendResponseThroughResponseHeaders(String validUser,String sessionId,HttpExchange exchange)
	{
		logger.info("===Response : ValidUser["+validUser+"],SessionId["+sessionId+"],ContentType[text/plain]");
		responseHeaders.set("SESIONID",sessionId);
		responseHeaders.set("Content-Type", "text/plain");
		responseHeaders.set("VALIDUSER",validUser);
		try
		{
			exchange.sendResponseHeaders(200, -1);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void sendResponseThroughResponseBody(String validUser,String sessionId,HttpExchange exchange)
	{
		PushResponseBody responseBody=new PushResponseBody();
		responseBody.setContentType("application/json");
		responseBody.setValidUser(validUser);
		responseBody.setSessionId(sessionId);
		responseBody.setStatusCode("200");
		Gson gson=new Gson();
		String stringJson=gson.toJson(responseBody);
		logger.info("==Response : "+stringJson);
		try
		{
			exchange.sendResponseHeaders(200, 0);
		
			OutputStream outputStream=exchange.getResponseBody();
			outputStream.write(stringJson.getBytes());
			outputStream.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
		/*

		   public void sendTCPData()
		   {
		   try
		   {

		   logger.info("Send data into TCP Socket");
		   DataOutputStream stream_send_data=null;

		   Socket socket=new Socket("10.168.1.21",10109);
		   stream_send_data = new DataOutputStream(socket.getOutputStream());


		   TLVAppInterface send_request = new TLVAppInterface();
		   ByteArrayOutputStream send_buf = new ByteArrayOutputStream();
		   send_request.setData(1,msisdn);
		   send_request.setData(2,opCode);
		   send_request.encode(send_buf);
		   int send_requestLen = send_buf.size();
		   byte[] len=new byte[4];
		   len[3]=(byte)(send_requestLen );
		   len[2]=(byte)((send_requestLen >> 8) );
		   len[1]=(byte)((send_requestLen >> 16));
		   len[0]=(byte)((send_requestLen >> 24));

		   stream_send_data.write(len,0, 4);

		   logger.info("Data length sent of buf size="+send_requestLen);
		   stream_send_data.write(send_buf.toByteArray(), 0, send_buf.toByteArray().length);

		   }
		   catch(Exception e)
		   {
		   logger.info("exception "+e.toString());
		   }


		   }

		 */


}
