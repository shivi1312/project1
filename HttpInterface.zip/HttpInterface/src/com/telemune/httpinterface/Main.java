
/*
 * Main.java
 *
 * Created on June 9, 2010, 12:58 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.telemune.httpinterface;


/**
 *
 * @author ashu
 */

import java.io.*;
import java.lang.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import org.apache.log4j.*;

import TlvLib.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executors;
import com.sun.net.httpserver.*;

public class Main implements Runnable
{

	/** Creates a new instance of Main */
	public Main() {
	}
	static int sce_port=-1; 
	static int server_port=-1;
	static int server_port_enable=-1;
	static String sce_ip=""; 
	static int conpoolsize=-1; 
	static String driver = "oracle.jdbc.driver.OracleDriver";
	//String url="jdbc:oracle:thin:@192.168.57.2:1521:vtnora";
	static String url="jdbc:oracle:thin:@192.168.1.110:1521:mastera";
	static  String uname="crbt";
	static	 String pwd="crbt";
	static Logger logger;
	static Thread thrdsendRes;
	static Thread thrdprocess;
	static Thread thrdappres;
	static ThreadPoolExtrProcessHandler processHandle;
	static Socket socket;
	static Thread thrd;
	static Connection con;
	static sendResp sendRes;
	static ProcessRequest processreq;
	static AppResources appclients;
	static Thread thrdserver;
	static MyHandler myHandler;
	static InetSocketAddress addr;
	static HttpServer server;
	static HttpContext context;
	static ThreadPoolExecutor thExecute;


	static int count=0;
		/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		// TODO code application logic here								logger = Logger.getLogger(this.getName());
		
		try
		{
			try
			{
			if(args[0].equalsIgnoreCase("-v"))
				{
					String VERSION="R3_1_1_2";
					String SITE="USSD HTTP MODULE";
					System.out.println("\n******************************************************************************************");
					System.out.println("\n                          	USSD HTTP MODULE  Version [  "+VERSION+"  ]");
					System.out.println("\n				Name of the Licensee : Telemune");
					System.out.println("\n				Licence ID: 08981Telemune98Client00909");	
					System.out.println("\n******************************************************************************************");
					System.out.println("\n");

					System.exit(1);
				}
				}
				catch(Exception Arrayoutex)
				{
					//logger.error("Starts...."+Arrayoutex.toString());
				}
				PropertyConfigurator.configure("property/log4j.properties");
				logger=Logger.getLogger(Main.class.getName());
				thrd=new Thread();
				logger.info("Strating...");
				DataOutputStream stream_send_data=null;
				Properties chrPro = new Properties();
				try
				{
					FileInputStream fins=new FileInputStream("property/ussdgw.properties");
					chrPro.load(fins);
					fins.close();
				}
				catch(IOException ioe)
				{
					ioe.printStackTrace();
					logger.error(ioe.getMessage());
					System.exit(1);
				}
				try
				{

					sce_port=Integer.parseInt(chrPro.getProperty("ROUTER_PORT"));
					server_port=Integer.parseInt(chrPro.getProperty("SERVER_PORT"));
					server_port_enable=Integer.parseInt(chrPro.getProperty("SERVER_PORT_ENABLE"));
					sce_ip=chrPro.getProperty("ROUTER_IP");
					uname=chrPro.getProperty("DBUSER");
					pwd=chrPro.getProperty("DBPASSWORD");
					url=chrPro.getProperty("DBURL");
					driver=chrPro.getProperty("DRIVER");
					globalobj.TIMEOUT=Integer.parseInt(chrPro.getProperty("CONNECTION_TIMEOUT"));
					globalobj.HTTP_READ_TIMEOUT=Integer.parseInt(chrPro.getProperty("HTTP_READ_TIMEOUT"));
					globalobj.MSGLENGTH=Integer.parseInt(chrPro.getProperty("MSGLENGTH"));
					globalobj.RELOADTIME=Integer.parseInt(chrPro.getProperty("CACHE_RELOAD_TIME"));
					globalobj.lang=Integer.parseInt(chrPro.getProperty("language_id"));
					globalobj.pull_header_enable=Integer.parseInt(chrPro.getProperty("pull_header_enable"));
					globalobj.push_header_enable=Integer.parseInt(chrPro.getProperty("push_header_enable"));
					globalobj.encript_decript_flag=Integer.parseInt(chrPro.getProperty("encript_decript_flag"));
					ProcessThread.minThreadSize=Integer.parseInt(chrPro.getProperty("minThread"));
					ProcessThread.maxThreadSize=Integer.parseInt(chrPro.getProperty("maxThread"));
					ProcessThread.waitQueueSize=Integer.parseInt(chrPro.getProperty("waitQueue"));
					logger.info("min Thread ["+ProcessThread.minThreadSize+"] max Thread ["+ProcessThread.maxThreadSize+"] wait queue size ["+ProcessThread.waitQueueSize+"]");
					
				}
				catch(Exception expset)
				{
					logger.error("ReadExce:"+expset.toString());
				}
				try
				{

					//server_socket = new ServerSocket(port);
					//logger.debug("Server waiting for client on port " +server_socket.getLocalPort());


				}
				catch(Exception ee)
				{
					logger.error("got SOCKET exception in thread" +ee.toString());
					logger.error("Strating..."+ee.toString());                                
					System.exit(1);

				}
				try
				{
					uname=chrPro.getProperty("DBUSER");
					pwd=chrPro.getProperty("DBPASSWORD");
					url=chrPro.getProperty("DBURL");
					driver=chrPro.getProperty("DRIVER");


				}
				catch (Exception sqle)
				{
					logger.error("Exception Connection Creating" +sqle.toString());
				}
				try
				{
					Class.forName(driver);
				}catch(ClassNotFoundException  E)
				{
					logger.error("Driver class not found "+ E.getMessage());
					System.exit(1);
				}	catch(Exception e)
				{
					logger.error("Cant load driver "+e.toString());
					System.exit(1);
				}
				try
				{
					con=DriverManager.getConnection(url,uname,pwd);
					logger.info("Connection Success ");

				}catch(Exception eE)
				{
					logger.error("Cant connect to DB "+eE.getMessage());
					System.exit(1);
				}
				try
				{
					try
					{
						socket=new Socket(sce_ip,sce_port);	
						logger.info("Connection accepted response" +
								socket.getInetAddress() +
								":" + socket.getPort());
						logger.info("Connection accepted response" +
								socket.toString());

						stream_send_data = new DataOutputStream(socket.getOutputStream());
						TLVAppInterface tlvdata=new TLVAppInterface();
						tlvdata.setData(5,"HTTP");
						tlvdata.encode();	
						tlvdata.send(socket);

					}
					catch(Exception exa)
					{
						logger.error("Shown the "+exa.toString());
					}
					AppResources appclients=null;
			//		ProcessRequest processreq=null;

			//		thServcHandle.start();
					getReq obj_get_data =null;
					Thread threq=null;
					sendResp sendRes=null;
					MyHandler myHandler=null;


					if(socket==null)
					{

					}
					else
					{
						appclients=new	AppResources();
						thrdappres=new Thread(appclients);
						thrdappres.start();
						//logger.info("Shown the 1");
					         thExecute = new ThreadPoolExecutor(ProcessThread.minThreadSize,ProcessThread.maxThreadSize,ProcessThread.waitQueueSize, TimeUnit.SECONDS,new ArrayBlockingQueue<Runnable>(100),new RejectedWorkHandler());
                                        	processHandle= new ThreadPoolExtrProcessHandler(thExecute);
                                        	thrdprocess= new Thread(processHandle);
                                        	thrdprocess.start();

					//	processreq=new ProcessRequest();
					//	thrdprocess=new Thread(processreq);
					//	thrdprocess.start();
						//logger.info("Shown the 2");
						obj_get_data = new getReq("threadCheckRequest"+socket.toString(),socket);
						threq=new Thread(obj_get_data);
						threq.start();
					//	logger.info("Shown the 3");

						sendRes=new sendResp(socket);
						thrdsendRes=new Thread(sendRes);
						thrdsendRes.start();
					//	logger.info("Shown the 4");
						if(server_port_enable==1)
						{
						myHandler=new MyHandler();


						InetSocketAddress addr = new InetSocketAddress(server_port);
						HttpServer server = HttpServer.create(addr, 0);
						HttpContext context=server.createContext("/", myHandler);
						server.setExecutor(Executors.newCachedThreadPool());
						server.start();


						logger.info("Server is listening on port "+server_port );
						}

					}
					while(true)
					{
						while(!socket.isConnected() || socket.isInputShutdown() || socket.isOutputShutdown() || !socket.isBound() || socket.isClosed())
						{
							try
							{
								socket=new Socket(sce_ip,sce_port);	
								logger.info("Connection accepted response" +
										socket.getInetAddress() +
										":" + socket.getPort());
								logger.info("Connection accepted response" +
										socket.toString());
								stream_send_data = new DataOutputStream(socket.getOutputStream());
								TLVAppInterface tlvdata=new TLVAppInterface();
								tlvdata.setData(5,"HTTP");
								tlvdata.encode();	
								tlvdata.send(socket);

							}	catch(Exception ee)
							{
								logger.error("got SOCKET exception in thread  Process1" +ee.toString());
								thrd.sleep(1000);
								//System.exit(1);
							}
						}

						try
						{
							if(!threq.isAlive())
							{
								logger.info("Shown the 5");
								obj_get_data = new getReq("threadCheckRequest"+socket.toString(),socket);
								threq=new Thread(obj_get_data);
								threq.start();
							}

							if (!thrdappres.isAlive())
							{

								logger.info("Shown the 9");
								appclients=new	AppResources();
								thrdappres=new Thread(appclients);
								thrdappres.start();
							}
							if (!thrdprocess.isAlive())
							{
								logger.info("Shown the 6");
								processHandle= new ThreadPoolExtrProcessHandler(thExecute);
		                                                thrdprocess= new Thread(processHandle);
                		                                thrdprocess.start();


							}
							if (!thrdsendRes.isAlive())
							{
								logger.info("Shown the 7");
								sendRes=new sendResp(socket);
								thrdsendRes=new Thread(sendRes);
								thrdsendRes.start();

							}



						}
						catch(Exception e)
						{
							logger.error("got exception in  thread" +e);
							System.exit(1);
						}
						try
						{
							thrd.sleep(1000);
							count++;
							if(count==10)
							{
							logger.info("Size of globalobj.mp is ["+globalobj.mp.size()+"]");
							count=0;	
							}
						}		
						catch(Exception eee)
						{
							logger.error("Sleep Exception in main");
						}
					}

				}
				catch(Exception mainEx)
				{
					mainEx.printStackTrace();

				}

			}
			catch(Exception e)
			{
				e.printStackTrace();

			}
		}
		public void run()
		{

		}

	}
