package com.telemune.httpinterface.bean;

public class HttpsPullRequestBody {

	private String requestType;
	private String dialogId;
	private String msisdn;
	private String requestData;
	private String sessionId;
	private String connection;
	
	public HttpsPullRequestBody()
	{
		
	}
	
	public String getRequestType()
	{
		return requestType;
	}
	public String getDialogId()
	{
		return dialogId;
	}
	public String getMsisdn()
	{
		return msisdn;
	}
	public String getRequestData()
	{
		return requestData;
	}
	public String getSessionId()
	{
		return sessionId;
	}
	
	public void setRequestType(String requestType)
	{
		this.requestType=requestType;
	}
	public void setDialogId(String dialogId)
	{
		this.dialogId=dialogId;
	}
	public void setMsisdn(String msisdn)
	{
		this.msisdn=msisdn;
	}
	public void setRequestData(String requestData)
	{
		this.requestData=requestData;
	}
	public void setSessionId(String sessionId)
	{
		this.sessionId=sessionId;
	}
}
