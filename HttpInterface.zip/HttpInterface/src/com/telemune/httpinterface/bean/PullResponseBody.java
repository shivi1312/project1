package com.telemune.httpinterface.bean;

public class PullResponseBody {

	private String responseData;
	private String requestType;
	
	public String getResponseData()
	{
		return responseData;
	}
	public void setResponseData(String responseData)
	{
		this.responseData=responseData;
	}
	
	public String getRequestType()
	{
		return requestType;
	}
	public void setRequestType(String requestType)
	{
		this.requestType=requestType;
	}
}
