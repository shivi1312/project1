package com.telemune.httpinterface.bean;

public class PushResponseBody {

	private String contentType;
	private String validUser;
	private String sessionId;
	private String statusCode;
	
	public String getContentType()
	{
		return contentType;
	}
	public String getValidUser()
	{
		return validUser;
	}
	public String getSessionId()
	{
		return sessionId;
	}
	public String getStatusCode()
	{
		return statusCode;
	}
	
	public void setContentType(String contentType)
	{
		this.contentType=contentType;
	}
	public void setValidUser(String validUser)
	{
		this.validUser=validUser;
	}
	public void setSessionId(String sessionId)
	{
		this.sessionId=sessionId;
	}
	public void setStatusCode(String statusCode)
	{
		this.statusCode=statusCode;
	}
}
