package com.telemune.httpinterface.bean;

public class PushRequestBody 
{
	
	private String userName="";
	private String password="";
	private String data="";
	private String dlId="";
	private String msisdn="";
	private String shortCode="";
	private String opCode="";
	
	public PushRequestBody()
	{
		
	}
	
	public String getUserName()
	{
		return userName;
	}
	public String getPassword()
	{
		return password;
	}
	public String getData()
	{
		return data;
	}
	public String getDlId()
	{
		return dlId;
	}
	public String getMsisdn()
	{
		return msisdn;
	}
	public String getShortCode()
	{
		return shortCode;
	}
	public String getOpCode()
	{
		return opCode;
	}
	
	public void setUserName(String userName)
	{
		this.userName=userName;
	}
	public void setPassword(String password)
	{
		this.password=password;
	}
	public void setData(String data)
	{
		this.data=data;
	}
	public void setDlId(String dlId)
	{
		this.dlId=dlId;
	}
	public void setMsisdn(String msisdn)
	{
		this.msisdn=msisdn;
	}
	public void setShortCode(String shortCode)
	{
		this.shortCode=shortCode;
	}
	public void setOpCode(String opCode)
	{
		this.opCode=opCode;
	}
}
