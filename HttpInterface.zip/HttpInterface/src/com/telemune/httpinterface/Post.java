

/*
 * Post.java
 *
 * Created on June 9, 2010, 12:58 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.telemune.httpinterface;


import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;

import java.net.SocketTimeoutException;
import java.net.ConnectException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import org.apache.log4j.*;

import com.google.gson.Gson;
import com.telemune.httpinterface.bean.HttpsPullRequestBody;
import com.telemune.httpinterface.bean.HttpPullRequestBody;
import com.telemune.httpinterface.bean.PullResponseBody;

import java.net.URLDecoder;
import java.util.Date;


import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.net.HttpURLConnection;
import java.security.cert.X509Certificate;


public class Post //implements Runnable
{
	static Logger logger=Logger.getLogger(Post.class.getName());
	private  String url ="https://10.168.3.57:8443/HTTPInterfaceTestingSpring/test";
	int req_type=0;
	user_data data_obj;
	Date sendingTime=null;
	Date responseTime=null;
	int http_read_timeout=-1;
	int encript_decript_flag=globalobj.encript_decript_flag;
	
	/*public Post(user_data data_obj,String url,boolean isPush)
	{
		System.out.println("Inside Post Constructor");
		this.url=url;
		this.data_obj=data_obj;
		
		if(url.contains("https"))
		{
			disableAllCertificates();
			httpsRequest();
		}
		else
		{
			httpRequest();
		}
	}
*/
	public Post(user_data data_obj,String url,int http_read_timeout,boolean isPush)
	{
		logger.info("Inside Post Constructor");
		this.url=url;
		this.http_read_timeout=http_read_timeout;
		this.data_obj=data_obj;
		
		if(url.contains("https"))
		{
			disableAllCertificates();
			httpsRequest();
		}
		else
		{
			httpRequest();
		}
	}
	
	public void httpRequest()
	{
		if(globalobj.pull_header_enable==1)
		{
			getHttpRequestByRequestHeaders();
		}
		else 
		{
			getHttpRequestByRequestBody();
		}
	}

	public void httpsRequest()
	{
		if(globalobj.pull_header_enable==1)
		{
			getHttpsRequestByRequestHeaders();
		}
		else 
		{
			getHttpsRequestByRequestBody();
		}
	}

	public void setErrorResponse(String msg,int opcode,int errCode){
		try{
			if(globalobj.mp.get(data_obj.user_msisdn)!=null)
			{
				logger.debug("Remove entry from Hash Map when set error response in Post request");
				globalobj.mp.remove(data_obj.user_msisdn);
			}

			if(data_obj.op_code==6 || data_obj.op_code==10)
			{
				logger.info("Session aborted");
			}
			else
			{
				data_obj.user_data=msg;
				data_obj.op_code=opcode;
				data_obj.errCode=errCode;
				globalobj.datasendque.put(data_obj);
			}
		}catch(Exception ex)
		{
			logger.error("Exception while setting Error Code : "+ex.getMessage());
			ex.printStackTrace();
		}


	}
	public long getTimeDifference(Date start, Date end){
		long difference=-1;
		try{

			long difference1 = end.getTime() - start.getTime();
			difference= difference1 / 1000 % 60;
		}catch(Exception e){
			logger.error("Exception while getting time difference :"+e.getMessage());
		}

		return difference;
	}
	
	public String XMLEncode(String value)
	{
		return value.replaceAll("&", "&amp;").replaceAll("\n","&#13;").replaceAll("'", "&apos;").replaceAll("\"", "&quot;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
	}

	public String XMLDecode(String value)
	{
		return value.replaceAll("&amp;", "&").replaceAll("&#13;","\n").replaceAll("&apos;", "'").replaceAll("&lt;", "<").replaceAll("&gt;", ">");
	}
	
	public void disableAllCertificates()
	{
		try
		{
			/*Create a trust manager that does not validate certificate chains*/
			TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}
				public void checkClientTrusted(X509Certificate[] certs, String authType) {
				}
				public void checkServerTrusted(X509Certificate[] certs, String authType) {
				}
			}
			};
			/* Install the all-trusting trust manager*/
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

			/* Create all-trusting host name verifier*/
			HostnameVerifier allHostsValid = new HostnameVerifier() {
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			};

			/* Install the all-trusting host verifier*/
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
	}
	
	public String getStringFromInputStream(InputStream inputStream)
	{
		BufferedReader reader=null;
		StringBuilder stringBuilder=new StringBuilder();
		String line=null;
		
		try
		{
			reader=new BufferedReader(new InputStreamReader(inputStream));
			while((line=reader.readLine()) !=null)
			{
				stringBuilder.append(line);
			}
		}
		catch(IOException e)
		{
			logger.error(e);
		}
		catch(Exception e)
		{
			logger.error(e);
		}
		finally
		{
			if(reader!=null)
			{
				try
				{
					reader.close();
				}
				catch(IOException e)
				{
					logger.error(e);
				}
				catch(Exception e)
				{
					logger.error(e);
				}
			}
		}
		return stringBuilder.toString();
	}
	
	public void getHttpRequestByRequestBody()
	{
		CloseableHttpClient client = null;
		try
		{
			logger.info("URL is going to hit >>> [ "+this.url+" ]");
			RequestConfig config = RequestConfig.custom()
					  .setConnectTimeout(globalobj.TIMEOUT)
					  .setConnectionRequestTimeout(globalobj.TIMEOUT).setSocketTimeout(http_read_timeout).build();
			client = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
			 
			HttpPost postRequest = new HttpPost(url);
			
			HttpPullRequestBody requestBody=new HttpPullRequestBody();
			requestBody.setRequestType(data_obj.op_code+"");
			requestBody.setDialogId(data_obj.dialog_id+"");
			requestBody.setMsisdn(data_obj.user_msisdn+"");
			requestBody.setRequestData(data_obj.user_data+"");
	/*		if(encript_decript_flag==1)
			{
				requestBody.setRequestData(EncriptDecript.encript(data_obj.user_data));
				logger.info("Request Data After Encription : "+requestBody.getRequestData());
			}
			else
			{
				requestBody.setRequestData(data_obj.user_data+"");
			}*/
			requestBody.setSessionId(data_obj.sessionId+"");
			requestBody.setConnection("close");
			
			Gson gson = new Gson();
			String requestJson=gson.toJson(requestBody);
			logger.info("Request Json : "+requestJson);
			
			StringEntity input = new StringEntity(requestJson);
			
			
			
			postRequest.setEntity(input);
			
			/*
			StringRequestEntity requestEntity = new StringRequestEntity(
				    requestJson,
				    "application/json",
				    "UTF-8");
				   postMethod.setRequestEntity(requestEntity);
			*/
			
			
			sendingTime = new Date();
			HttpResponse response = client.execute(postRequest);
			responseTime = new Date();
			
			int statusCode1=response.getStatusLine().getStatusCode();
			if(statusCode1 == 200){
				long difference = this.getTimeDifference(sendingTime,responseTime);
				logger.info("HTTP Status is ["+statusCode1+"] Response Time["+difference+" Seconds]");
							
				String responseJson=getStringFromInputStream((response.getEntity().getContent()));
				
				logger.info("Response Json String : "+responseJson);
				
				PullResponseBody responseBody = gson.fromJson(responseJson,PullResponseBody.class);
				String s=XMLDecode(responseBody.getResponseData());
				s=URLDecoder.decode(s,"UTF-8");
				/*if(encript_decript_flag==1)
				{
					logger.debug("Encripted Response Data : "+s);
					s=EncriptDecript.decript(s);
				}*/
				data_obj.user_data=s;
				int opcode=0;
				if(data_obj.user_data.getBytes().length>=globalobj.MSGLENGTH)
				{
					int temp_len=data_obj.user_data.getBytes().length-data_obj.user_data.length();
					logger.debug("Message length is greater then 180 characters So decrease :"+globalobj.MSGLENGTH+" and temp:"+temp_len);
					data_obj.user_data=data_obj.user_data.substring(0,globalobj.MSGLENGTH-temp_len-1);
				}
				logger.debug("String is :["+ data_obj.user_data+"]");

				try
				{
					req_type=Integer.parseInt(responseBody.getRequestType());
					
				}
				catch(Exception uwe)
				{
					uwe.printStackTrace();
					this.setErrorResponse("UnKnown Error",4,32);
					return;
				}

				if(req_type!=2 && req_type!=4 && req_type!=11)
				{
					logger.info("REQTYPE is INVALID SESSION STOP");
					this.setErrorResponse("UnKnown Error",4,32);
					return;
				}
				if(data_obj.op_code==6 || data_obj.op_code==10)
				{
					logger.info("Session is abort from router");
					if(globalobj.mp.get(data_obj.user_msisdn)!=null)
					{
						logger.debug("Remove entry from Hash Map when session abort from router");
						globalobj.mp.remove(data_obj.user_msisdn);
					}
				}	
				else 
				{
					if(data_obj.op_code==9)
					{
						opcode=4;
					}
					else
					{

						if(req_type==2)
							opcode=2;
						else if(req_type==4)
							opcode=4;
						else if(req_type==11)
							opcode=11;
					}
					if(opcode==4 || opcode==11)
					{
						if(globalobj.mp.get(data_obj.user_msisdn)!=null)
						{
							logger.debug("Remove entry from Hash Map when user send opcode 4 for termination");
							globalobj.mp.remove(data_obj.user_msisdn);
						}
					}
					data_obj.op_code=opcode;
					data_obj.errCode=0;
					logger.info("statusLine>>>" + response.getStatusLine());
					globalobj.datasendque.put(data_obj);
				}
			}
			else{
				logger.info("HTTP Status is ["+statusCode1+"] So returning Error !!!" );		
				this.setErrorResponse("UnKnown Error",4,31);	
			}	
		}
		catch(ConnectException exe)
		{
			logger.error("Exception in connection......"+exe.getMessage());
			this.setErrorResponse("Unknown Error",4,31);

		}catch(SocketTimeoutException sockexe)
		{
			logger.error("Socket timeout........"+sockexe.getMessage());
			this.setErrorResponse("Please try later",4,31);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			this.setErrorResponse("UnKnown Error",4,32);	
		}
	}
	public void getHttpRequestByRequestHeaders()
	{
		HttpClient client = null;
		PostMethod postMethod = null;
		try
		{
			logger.info("URL is going to hit >>> [ "+this.url+" ]");
			client = new HttpClient();
			postMethod = new PostMethod(url);
			client.setTimeout(globalobj.TIMEOUT);
			client.setConnectionTimeout(globalobj.TIMEOUT); // Connection Timeout for connecting server
			postMethod.getParams().setParameter("http.socket.timeout", http_read_timeout);  // Timeout wait for response after connecting
			postMethod.setRequestHeader("REQUESTTYPE",data_obj.op_code+"");
			postMethod.setRequestHeader("DIALOGID",data_obj.dialog_id+"");
			postMethod.setRequestHeader("MSISDN",data_obj.user_msisdn+"");
			postMethod.setRequestHeader("REQDATA",data_obj.user_data+"");
	/*		if(encript_decript_flag==1)
			{
				postMethod.setRequestHeader("REQDATA",EncriptDecript.encript(data_obj.user_data+""));
				logger.info("Request Data After Encryption : "+EncriptDecript.encript(data_obj.user_data+""));
			}
			else
			{
				postMethod.setRequestHeader("REQDATA",data_obj.user_data+"");
			}*/
			postMethod.setRequestHeader("SESSIONID",data_obj.sessionId+"");
			postMethod.setRequestHeader("Connection", "close");
		
			sendingTime = new Date();
			int statusCode1 =    client.executeMethod(postMethod);
			responseTime = new Date();
			Header hdr_req[] = postMethod.getRequestHeaders();
			int n = hdr_req.length;
			logger.info("Value of n------------------>>"+n);
			
			for (int i=0;i<n;i++)
			{
				String headerHead = hdr_req[i].toExternalForm();
				headerHead = headerHead.substring(0,headerHead.indexOf(": "));
				logger.info(hdr_req[i].toExternalForm());
				if (! hdr_req[i].isAutogenerated())
					postMethod.removeRequestHeader(headerHead);
			}	
			if(statusCode1 == 200){
				long difference = this.getTimeDifference(sendingTime,responseTime);
				logger.info("HTTP Status is ["+statusCode1+"] Response Time["+difference+" Seconds]");
				Header hdr_resp[] = postMethod.getResponseHeaders();
				n = hdr_resp.length;
				logger.debug("RESPONSE HEADERS");
				for (int i=0;i<n;i++)
				{
					logger.info(hdr_resp[i].toExternalForm());
				}
				logger.info("Got RESPONSE HEADERS");


				NameValuePair nameval;
				nameval=postMethod.getResponseHeader("RESPDATA");
				String s=nameval.getValue();
				s=XMLDecode(s);
				s=URLDecoder.decode(s,"UTF-8");
				logger.info("Response String "+s);
				/*if(encript_decript_flag==1)
				{	
					s=EncriptDecript.decript(s);
				}*/
				data_obj.user_data=s;
				int opcode=0;
				if(data_obj.user_data.getBytes().length>=globalobj.MSGLENGTH)
				{
					int temp_len=data_obj.user_data.getBytes().length-data_obj.user_data.length();
					logger.debug("Message length is greater then 180 characters So decrease :"+globalobj.MSGLENGTH+" and temp:"+temp_len);
					data_obj.user_data=data_obj.user_data.substring(0,globalobj.MSGLENGTH-temp_len-1);
				}
				logger.debug("String is :["+ data_obj.user_data+"]");

				try
				{
					nameval=postMethod.getResponseHeader("REQTYPE");
					req_type=Integer.parseInt(nameval.getValue());
				}
				catch(Exception uwe)
				{

					uwe.printStackTrace();
					this.setErrorResponse("UnKnown Error",4,32);
					return;
				}

				if(req_type!=2 && req_type!=4 && req_type!=11)
				{
					logger.info("REQTYPE is INVALID SESSION STOP");
					this.setErrorResponse("UnKnown Error",4,32);
					return;
				}
				if(data_obj.op_code==6 || data_obj.op_code==10)
				{
					logger.info("Session is abort from router");
					if(globalobj.mp.get(data_obj.user_msisdn)!=null)
					{
						logger.debug("Remove entry from Hash Map when session abort from router");
						globalobj.mp.remove(data_obj.user_msisdn);
					}

				}	
				else 
				{
					if(data_obj.op_code==9)
					{
						opcode=4;
					}
					else
					{

						if(req_type==2)
							opcode=2;
						else if(req_type==4)
							opcode=4;
						else if(req_type==11)
							opcode=11;

					}
					if(opcode==4 || opcode==11)
					{
						if(globalobj.mp.get(data_obj.user_msisdn)!=null)
						{
							logger.debug("Remove entry from Hash Map when user send opcode 4 for termination");
							globalobj.mp.remove(data_obj.user_msisdn);
						}
					}
					data_obj.op_code=opcode;
					data_obj.errCode=0;
					logger.info("RESPONSE HEADERS");
					logger.info("statusLine>>>" + postMethod.getStatusLine());
					globalobj.datasendque.put(data_obj);
				}
			}
			else
			{
				logger.info("HTTP Status is ["+statusCode1+"] So returning Error !!!" );		
				this.setErrorResponse("UnKnown Error",4,31);	
			}	
		}
		catch(ConnectException exe)
		{
			logger.error("Exception in connection......"+exe.getMessage());
			this.setErrorResponse("Unknown Error",4,31);

		}catch(SocketTimeoutException sockexe)
		{
			logger.error("Socket timeout........"+sockexe.getMessage());
			this.setErrorResponse("Please try later",4,31);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			this.setErrorResponse("UnKnown Error",4,32);	

		}
		finally
		{	
			postMethod.releaseConnection();	
		}
	}
	public void getHttpsRequestByRequestBody()
	{
		try
		{
			logger.info("URL is going to hit >>> [ "+this.url+" ]");
			URL u = new URL(url);
			URLConnection con = u.openConnection();
			HttpURLConnection httpurlcon = (HttpURLConnection)con;
			httpurlcon.setConnectTimeout(globalobj.TIMEOUT);
			httpurlcon.setReadTimeout(globalobj.TIMEOUT);
			httpurlcon.setDoOutput(true);
			httpurlcon.setDoInput(true);
			httpurlcon.setRequestProperty("Content-Type", "application/json");
			httpurlcon.setRequestProperty("Accept", "application/json");
			httpurlcon.setRequestMethod("POST");
			
			HttpsPullRequestBody requestBody=new HttpsPullRequestBody();
			requestBody.setRequestType(data_obj.op_code+"");
			requestBody.setDialogId(data_obj.dialog_id+"");
			requestBody.setMsisdn(data_obj.user_msisdn+"");
			requestBody.setRequestData(data_obj.user_data+"");
/*			if(encript_decript_flag==1)
			{
				requestBody.setRequestData(EncriptDecript.encript(data_obj.user_data+""));
				logger.info("Request Data After Encription : "+requestBody.getRequestData());
			}
			else
			{
				requestBody.setRequestData(data_obj.user_data+"");
			}*/
			requestBody.setSessionId(data_obj.sessionId+"");
			
			Gson gson = new Gson();
			String requestJson=gson.toJson(requestBody);
			
			logger.info("Request Json : "+requestJson);
			
			sendingTime = new Date();
			
			OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream());
			writer.write(requestJson);
			try
			{
				writer.flush();
				writer.close();
			}
			catch(IOException e)
			{
				logger.error(e);
			}
			catch(Exception e)
			{
				logger.error(e);
			}
			
			int statusCode1 = HttpURLConnection.HTTP_OK;
			responseTime = new Date();
			if(statusCode1 == 200){
				long difference = this.getTimeDifference(sendingTime,responseTime);
				logger.info("HTTP Status is ["+statusCode1+"] Response Time["+difference+" Seconds]");

				String responseJson=getStringFromInputStream(con.getInputStream());
				PullResponseBody responseBody = gson.fromJson(responseJson,PullResponseBody.class);
				
				logger.info("Response Json String : "+responseJson);
				String s=URLDecoder.decode(responseBody.getResponseData(),"UTF-8");
				s=XMLDecode(s);
				/*if(encript_decript_flag==1)
				{
					logger.info("Encripted Response Data : "+s);
					s=EncriptDecript.decript(s);
				}*/
				data_obj.user_data=s;
				int opcode=0;
				if(data_obj.user_data.getBytes().length>=globalobj.MSGLENGTH)
				{
					int temp_len=data_obj.user_data.getBytes().length-data_obj.user_data.length();
					logger.info("Message length is greater then 180 characters So decrease :"+globalobj.MSGLENGTH+" and temp:"+temp_len);
					data_obj.user_data=data_obj.user_data.substring(0,globalobj.MSGLENGTH-temp_len-1);
				}
				logger.info("String is :["+ data_obj.user_data+"]");
				try
				{
					String req=URLDecoder.decode(responseBody.getRequestType());
					req_type=Integer.parseInt(req);
				}
				catch(Exception uwe)
				{

					uwe.printStackTrace();
					this.setErrorResponse("UnKnown Error",4,32);
					return;
				}

				if(req_type!=2 && req_type!=4 && req_type!=11)
				{
					logger.info("REQTYPE is INVALID SESSION STOP");
					this.setErrorResponse("UnKnown Error",4,32);
					return;
				}
				if(data_obj.op_code==6 || data_obj.op_code==10)
				{
					logger.info("Session is abort from router");
					if(globalobj.mp.get(data_obj.user_msisdn)!=null)
					{
						logger.debug("Remove entry from Hash Map when session abort from router");
						globalobj.mp.remove(data_obj.user_msisdn);
					}

				}	
				else 
				{
					if(data_obj.op_code==9)
					{
						opcode=4;
					}
					else
					{

						if(req_type==2)
							opcode=2;
						else if(req_type==4)
							opcode=4;
						else if(req_type==11)
							opcode=11;

					}
					if(opcode==4 || opcode==11)
					{
						if(globalobj.mp.get(data_obj.user_msisdn)!=null)
						{
							logger.debug("Remove entry from Hash Map when user send opcode 4 for termination");
							globalobj.mp.remove(data_obj.user_msisdn);
						}
					}
					data_obj.op_code=opcode;
					data_obj.errCode=0;
					logger.info("RESPONSE HEADERS");
					globalobj.datasendque.put(data_obj);
				}
			}
			else{
				logger.info("HTTP Status is ["+statusCode1+"] So returning Error !!!" );		
				this.setErrorResponse("UnKnown Error",4,31);	
			}	
		}
		catch(ConnectException exe)
		{
			logger.error("Exception in connection......"+exe.getMessage());
			this.setErrorResponse("Unknown Error",4,31);

		}catch(SocketTimeoutException sockexe)
		{
			logger.error("Socket timeout........"+sockexe.getMessage());
			this.setErrorResponse("Please try later",4,31);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			this.setErrorResponse("UnKnown Error",4,32);	
		}
	}
	public void getHttpsRequestByRequestHeaders()
	{
		try
		{
			logger.info("URL is going to hit >>> [ "+this.url+" ]");
			URL u = new URL(url);
			URLConnection con = u.openConnection();
			HttpURLConnection httpurlcon = (HttpURLConnection)con;
			httpurlcon.setConnectTimeout(globalobj.TIMEOUT);
			httpurlcon.setReadTimeout(globalobj.TIMEOUT);
			sendingTime = new Date();
			httpurlcon.setRequestProperty("REQUESTTYPE",data_obj.op_code+"");
			httpurlcon.setRequestProperty("DIALOGID",data_obj.dialog_id+"");
			httpurlcon.setRequestProperty("MSISDN",data_obj.user_msisdn+"");
			httpurlcon.setRequestProperty("REQDATA",data_obj.user_data+"");
/*			if(encript_decript_flag==1)
			{
				httpurlcon.setRequestProperty("REQDATA",EncriptDecript.encript(data_obj.user_data+""));
				logger.info("Encripted Request Data : "+EncriptDecript.encript(data_obj.user_data+""));
			}
			else
			{
				httpurlcon.setRequestProperty("REQDATA",data_obj.user_data+"");
			}*/
			
			httpurlcon.setRequestProperty("SESSIONID",data_obj.sessionId+"");
			httpurlcon.setRequestMethod("POST");

			int statusCode1 =    HttpURLConnection.HTTP_OK;
			responseTime = new Date();


			if(statusCode1 == 200){
				long difference = this.getTimeDifference(sendingTime,responseTime);
				logger.info("HTTP Status is ["+statusCode1+"] Response Time["+difference+" Seconds]");
				logger.info("RESPONSE HEADERS");
				logger.info("Got RESPONSE HEADERS");
				String s=URLDecoder.decode(httpurlcon.getHeaderField("RESPDATA"),"UTF-8");
				s=XMLDecode(s);
				logger.info("Response String before Decription : "+s);
				/*if(encript_decript_flag==1)
				{
					s=EncriptDecript.decript(s);
				}*/
				data_obj.user_data=s;
				int opcode=0;
				if(data_obj.user_data.getBytes().length>=globalobj.MSGLENGTH)
				{
					int temp_len=data_obj.user_data.getBytes().length-data_obj.user_data.length();
					logger.info("Message length is greater then 180 characters So decrease :"+globalobj.MSGLENGTH+" and temp:"+temp_len);
					data_obj.user_data=data_obj.user_data.substring(0,globalobj.MSGLENGTH-temp_len-1);
				         
				}
				logger.info("String is :["+ data_obj.user_data+"]");

				try
				{
					String req=URLDecoder.decode(httpurlcon.getHeaderField("REQTYPE"));
					req_type=Integer.parseInt(req);
				}
				catch(Exception uwe)
				{

					uwe.printStackTrace();
					this.setErrorResponse("UnKnown Error",4,32);
					return;
				}

				if(req_type!=2 && req_type!=4 && req_type!=11)
				{
					logger.info("REQTYPE is INVALID SESSION STOP");
					this.setErrorResponse("UnKnown Error",4,32);
					return;
				}
				if(data_obj.op_code==6 || data_obj.op_code==10)
				{
					logger.info("Session is abort from router");
					if(globalobj.mp.get(data_obj.user_msisdn)!=null)
					{
						logger.debug("Remove entry from Hash Map when session abort from router");
						globalobj.mp.remove(data_obj.user_msisdn);
					}

				}	
				else 
				{
					if(data_obj.op_code==9)
					{
						opcode=4;
					}
					else
					{

						if(req_type==2)
							opcode=2;
						else if(req_type==4)
							opcode=4;
						else if(req_type==11)
							opcode=11;

					}
					if(opcode==4 || opcode==11)
					{
						if(globalobj.mp.get(data_obj.user_msisdn)!=null)
						{
							logger.debug("Remove entry from Hash Map when user send opcode 4 for termination");
							globalobj.mp.remove(data_obj.user_msisdn);
						}
					}
					data_obj.op_code=opcode;
					data_obj.errCode=0;
					logger.info("RESPONSE HEADERS");
					globalobj.datasendque.put(data_obj);
				}
			}
			else{
				logger.info("HTTP Status is ["+statusCode1+"] So returning Error !!!" );		
				this.setErrorResponse("UnKnown Error",4,31);	
			}	
		}
		catch(ConnectException exe)
		{
			logger.error("Exception in connection......"+exe.getMessage());
			this.setErrorResponse("Unknown Error",4,31);
		}
		catch(SocketTimeoutException sockexe)
		{
			logger.error("Socket timeout........"+sockexe.getMessage());
			this.setErrorResponse("Please try later",4,31);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			this.setErrorResponse("UnKnown Error",4,32);	

		}		
	}

}

