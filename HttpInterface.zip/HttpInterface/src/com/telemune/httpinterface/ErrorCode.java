

/*
 * ErrorCode.java
 *
 * Created on Feb 14, 2017, 1:56 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.telemune.httpinterface;

/**
 *
 * @author ashu
 */
public class ErrorCode {

				/** Creates a new instance of conclients */
				public ErrorCode() {
				}
				public int code=-1;
				public int lang=-1;
				public String errorString="";
}
