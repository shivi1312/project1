
/*
 * ProcessRequest.java
 *
 * Created on June 10, 2010, 6:24 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.telemune.httpinterface;

/**
 *
 * @author ashu
 */
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import TlvLib.*;
//import dbutility.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import java.io.*;

import org.apache.log4j.*;

public class ProcessRequest implements Runnable {

	/** Creates a new instance of ProcessRequest */
	boolean val_found = false;
	// Map<String,req_class> mp=new HashMap<String,req_class>();
	Logger logger = Logger.getLogger(ProcessRequest.class);
	Thread thrd = new Thread();
	PreparedStatement stmt = null;
	Connection con = null;
	String dbname = "";
	String uname = "crbt";
	String pwd = "crbt";
	String driver = "";
	String url = "";
	int lang = globalobj.lang;
	user_data data_object = null;

	public ProcessRequest() {
		Properties chrPro = new Properties();
		try {
			FileInputStream fins = new FileInputStream("ussdgw.properties");
			chrPro.load(fins);

			fins.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
			logger.error(ioe.getMessage());
			System.exit(1);
		}
		try {
		} catch (Exception expset) {
			logger.error("ReadExce:" + expset.toString());
		}
		try {
			uname = chrPro.getProperty("DBUSER");
			pwd = chrPro.getProperty("DBPASSWORD");
			url = chrPro.getProperty("DBURL");
			driver = chrPro.getProperty("DRIVER");

			logger.info(" user name [" + uname + "]  password   [" + pwd + "]   url  [ " + url + "  ] driver  ["
					+ driver + "]");
		} catch (Exception sqle) {
			logger.error("Exception Connection Creating" + sqle.toString());
		}
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException E) {
			logger.error("Driver class not found " + E.getMessage());
			System.exit(1);
		} catch (Exception e) {
			logger.error("Cant load driver " + e.toString());
			System.exit(1);
		}
		try {
			con = DriverManager.getConnection(url, uname, pwd);
			logger.info("Connection Success ");

		} catch (Exception eE) {
			logger.error("Cant connect to DB " + eE.getMessage());
			System.exit(1);
		}
		try {
			logger.debug("Connecting to database...");
			logger.debug("Connection Success ");

		} catch (Exception eE) {
			logger.error("Cant connect to DB " + eE.getMessage());
			System.exit(1);
		}

	}

	public ProcessRequest(user_data data_object) {
		this.data_object = data_object;
	}

	public void run() {
		try {
			/*
			 * while(true) { try {
			 * 
			 * 
			 * if (globalobj.datarecvque.isEmpty()) { logger.
			 * debug("############data receiving queue is empty##################"
			 * ); try {
			 * 
			 * logger.info("############Thread is sleep for 1 second");
			 * thrd.sleep(1000); } catch(Exception se) {
			 * logger.error("exception in charging server"); }
			 * 
			 * } else {
			 */
			// logger.info("Que is NOT Empty Receive Queue");
			int result = -1;
			String msisdn = "";
			String req_data = "";
			int requestID = -1;
			String reason = "NA";
			String interfaceUsed = "NA";
			int rbt = -1;
			String fmsisdn = "NA";
			String resdata = "";
			int i = -1;
			int da_id = -1;
			int act = -1;
			int service_class = -1;
			val_found = false;

			/*
			 * user_data data_object = new user_data(); //data_object =
			 * globalobj.datarecvque.dequeue(); data_object =
			 * (user_data)globalobj.datarecvque.poll();
			 */
			logger.info("data object bean is" + data_object);
			req_data = data_object.user_data;
			if (data_object.op_code == 1) {
				// logger.debug("###############Inside condition when request is
				// come first Time################");
				logger.info("Inside condition when First time request come");
				if (globalobj.mp.get(data_object.user_msisdn) != null) {
					logger.info("Remove entry from hash map in case of opcode 1");
					globalobj.mp.remove(data_object.user_msisdn);
				}
				String t = req_data;

				logger.info(t);
				conclients cnc = (conclients) globalobj.clientList.get(t);
				// here we are checking if shortcode present as it is.
				// if not present then following condition will work
				if (cnc == null) {
					String t1;
					int test = t.indexOf("*", 1);
					if (test > 1) {
						t1 = t.substring(0, test);
						t1 = t1 + "#";
						logger.info(t1);
						 cnc = (conclients) globalobj.clientList.get(t1);
					}
					/*
					 * else { t1=t; logger.info(t1); }
					 */

				}

				if (cnc == null) {
					logger.info("please enter correct service code");
					// data_object.user_data="Please Enter correct service
					// code";
					data_object.user_data = globalobj.errorList.get("5" + "_" + lang);
					data_object.op_code = 4;
					data_object.errCode = 2;
					globalobj.datasendque.put(data_object);

				} else {
					logger.info("Correct Short Code IS" + cnc.shortcode);
					req_class req = new req_class();
					req.user_msisdn = data_object.user_msisdn;
					req.dialog_id = data_object.dialog_id;
					req.cnccode = cnc.shortcode;
					req.url = cnc.url;
					req.http_read_timeout = cnc.http_read_timeout;
					logger.info("Putting data into Map" + cnc.shortcode);
					globalobj.mp.put(req.user_msisdn, req);
					Post post = new Post(data_object, cnc.url, cnc.http_read_timeout, false);
				}
			} else if (data_object.op_code == 2) {
				// logger.debug("Inside ");
				req_class req = (req_class) globalobj.mp.get(data_object.user_msisdn);
				if (req == null) {
					logger.info("please try later");
					// data_object.user_data="Please Try Later";
					data_object.user_data = globalobj.errorList.get("2" + "_" + lang);
					data_object.op_code = 4;
					data_object.errCode = 3;
					globalobj.datasendque.put(data_object);
				} else {
					Post post = new Post(data_object, req.url, req.http_read_timeout, req.isPush);
				}
			} else if (data_object.op_code == 9) {
				Action action = (Action) globalobj.actionList.get(data_object.action_id);
				if (action == null) {
					logger.info("please enter correct service code");
					// data_object.user_data="Please Enter correct service
					// code";
					data_object.user_data = globalobj.errorList.get("5" + "_" + lang);
					data_object.op_code = 4;
					data_object.errCode = 7;
					globalobj.datasendque.put(data_object);

				} else {
					Post post = new Post(data_object, action.url, globalobj.HTTP_READ_TIMEOUT, false);
				}

			}
			// updated by swati
			else if (data_object.op_code == 6 || data_object.op_code == 10) {
				logger.info("Abort session");
				req_class req = (req_class) globalobj.mp.get(data_object.user_msisdn);
				if (req == null) {
					logger.info("please try later");
					// data_object.user_data="Please Try Later";
					data_object.user_data = globalobj.errorList.get("2" + "_" + lang);

				} else if (req.url == null || req.url == "") {
					logger.info("Inside abort session and url is null");
				} else {
					logger.info("Abort session from router");
					Post post = new Post(data_object, req.url, req.http_read_timeout, false);
				}

			}
			// updated for PUSH request
			else if (data_object.op_code == 7) {
				try {
					logger.info("Inside PUSH request");
					String shortCode = "";
					logger.info("session id is" + data_object.sessionId);
					logger.info("session ID is" + globalobj.pushReq.get(data_object.sessionId));
					req_class req = (req_class) globalobj.pushReq.get(data_object.sessionId);
					if (req == null) {
						logger.info("User Data is null please try later");
					} else {
						{
							logger.info("Remove entry from pushReq map in case of opcode 7");
							globalobj.pushReq.remove(data_object.sessionId);
						}
						conclients cnc = (conclients) globalobj.clientList.get(req.short_code);
						if (cnc == null) {
							logger.info("please enter correct service code");

						} else {
							if (globalobj.mp.get(req.user_msisdn) != null) {
								logger.info("Remove entry from hash map in case of opcode 7");
								globalobj.mp.remove(req.user_msisdn);
							}
							logger.info("enter correct code" + cnc.shortcode);
							req.url = cnc.url;
							req.http_read_timeout = cnc.http_read_timeout;
							globalobj.mp.put(req.user_msisdn, req);

							if (data_object.dialog_id == -1) {
								data_object.user_data = globalobj.errorList.get(data_object.user_data + "_" + lang);
								data_object.op_code = 12;
								Post post = new Post(data_object, cnc.url, req.http_read_timeout, req.isPush);
							}
						}
					}
				} catch (Exception e) {
					System.out.println("Exception inside push request" + e.getMessage());
					e.printStackTrace();
				}
			} else {
				logger.info("please enter correct service code");
				// data_object.user_data="Please Enter correct service code";
				data_object.user_data = globalobj.errorList.get("5" + "_" + lang);
				data_object.op_code = 4;
				globalobj.datasendque.put(data_object);
			}
			/*
			 * for(int k = 0; k < globalobj.clientList.size(); k++) { conclients
			 * cnc=(conclients) globalobj.clientList.get(k);
			 * if(req_data.equalsIgnoreCase(cnc.shortcode)) { req_class req=new
			 * req_class(); req.user_msisdn=data_object.user_msisdn;
			 * req.dialog_id=data_object.dialog_id; req.cnccode=cnc.code;
			 * mp.put(req.user_msisdn,req); Post post =new
			 * Post(data_object,cnc.ip); val_found=true; break; } if(!val_found)
			 * { req_class req=(req_class)mp.get(data_object.user_msisdn);
			 * if(req==null) { val_found=false; } else {
			 * req.user_msisdn=data_object.user_msisdn;
			 * req.dialog_id=data_object.dialog_id; req.cnccode=cnc.code;
			 * mp.put(req.user_msisdn,req); Post post =new
			 * Post(data_object,cnc.ip); val_found=true; }
			 * 
			 * }
			 * 
			 * }
			 */

			// }
			/*
			 * } catch(Exception inte) {
			 * logger.error("Exception::::::::"+inte.toString());
			 * 
			 * }
			 */
			// }
		} catch (Exception ee) {
			logger.error("Exception::::::::" + ee.toString());
			System.exit(1);

		}
	}
}
