

/*
 * sendResp.java
 *
 * Created on June 24, 2008, 12:07 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.telemune.httpinterface;

import java.io.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import TlvLib.*;
//import dbutility.*;
import org.apache.log4j.*;
/**
 *
 * @author ashu
 */
class sendResp implements Runnable
{
	String driver = "oracle.jdbc.driver.OracleDriver";
	String url="jdbc:oracle:thin:@192.168.57.200:1521:mastera";
	String dbname="";
	String uname="crbt";
	String pwd="crbt";

	Connection con=null;
	ResultSet rs=null;
	PreparedStatement stmt=null;
	String name;
	static Thread thrd;
	Socket socket_me;
	DataOutputStream stream_send_data;
	Logger logger=null;

	sendResp(Socket socket)				
	{
		try
		{
			logger=Logger.getLogger(sendResp.class.getName());

		}catch(Exception eE)
		{


		}
		logger.error("========sending data thread==========");
		Properties chrPro = new Properties();
		try
		{
			FileInputStream fins=new FileInputStream("property/ussdgw.properties");
			chrPro.load(fins);
			fins.close();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
			logger.error(ioe.getMessage());
			System.exit(1);
		}
		try
		{
			uname=chrPro.getProperty("DBUSER");
			pwd=chrPro.getProperty("DBPASSWORD");
			url=chrPro.getProperty("DBURL");
			driver=chrPro.getProperty("DRIVER");


		}
		catch (Exception sqle)
		{
			logger.error("Exception Connection Creating" +sqle.toString());
		}
		try
		{
			Class.forName(driver);
		}catch(ClassNotFoundException  E)
		{
			logger.error("Driver class not found "+ E.getMessage());
			System.exit(1);
		}	catch(Exception e)
		{
			logger.error("Cant load driver "+e.toString());
			System.exit(1);
		}
		try
		{
			con=DriverManager.getConnection(url,uname,pwd);
			logger.info("Connection Success ");

		}catch(Exception eE)
		{
			logger.error("Cant connect to DB "+eE.getMessage());
			System.exit(1);
		}


		thrd = new Thread(this);
		this.name = name;
		socket_me=socket;
		logger.info("started thread to send data: # "  );
	}
	public void run()
	{
		sendtoclient(name);
	}
	public void stop()
	{

	}
	public void sendtoclient(String name)
	{
		logger.info("preparing data from queue to send ......");

		try
		{
			while(true)
			{

				if (globalobj.datasendque.isEmpty())
				{
					//		logger.debug("Send Que is Empty" );
					try
					{
			//			logger.debug("###########inside condition when datasender queue is empty#############");
						thrd.sleep(10);
						if (socket_me.isClosed())
						{
							logger.info("Socket closed");
							thrd.stop();

							return;

						}
					}
					catch(InterruptedException E)
					{
					}
				}
				else
				{
					logger.info("Send Que is NOT Empty");

					user_data data_element = null;//new user_data();
					//data_element = globalobj.datasendque.dequeue();
					data_element = (user_data)globalobj.datasendque.poll();

					String ls_msisdn = "";
					int ls_reqdata = -1;
					String ls_resdata = "";
					int ls_requestID = -1;

					logger.info("Got OPCODE from Queue " + data_element.op_code);
					logger.info("Got MSISDN from Queue " + data_element.user_msisdn);
					logger.info("Got DATA from Queue " + data_element.user_data);
					logger.info("Got UNIQUE DIALOG ID from queue "+data_element.dialog_id);
					logger.info("Got Response code from queue "+data_element.errCode);
					logger.info("Got push request parameter "+data_element.isPush);
					logger.info("Got sessionID from Queue "+data_element.sessionId);
					TLVAppInterface send_request = new TLVAppInterface();
					ByteArrayOutputStream send_buf = new ByteArrayOutputStream();


					send_request.setData(1,data_element.user_msisdn);
					if(globalobj.encript_decript_flag==1)
					{
						send_request.setData(2,EncriptDecript.encript(data_element.user_data));
					}
					else
					{
						send_request.setData(2,data_element.user_data);
					}
					send_request.setData(3,data_element.op_code);
					send_request.setData(4,data_element.dialog_id);
					send_request.setData(8,data_element.short_code);
					send_request.setData(10,data_element.sessionId);
					send_request.setData(14,data_element.errCode);
					if(data_element.isPush)
					send_request.setData(11,1);
					else 
					send_request.setData(11,0);

					send_request.encode(send_buf);
					logger.info("packet Socket is==="+socket_me.toString());

					int send_requestLen = send_buf.size();
					try
					{
						stream_send_data = new DataOutputStream(socket_me.getOutputStream());
						logger.info("writing Info buf size="+send_requestLen);
						byte[] len=new byte[4];
						len[3]=(byte)(send_requestLen );
						len[2]=(byte)((send_requestLen >> 8) );
						len[1]=(byte)((send_requestLen >> 16));
						len[0]=(byte)((send_requestLen >> 24));
						stream_send_data.write(len,0, 4);
						logger.info("Data length sent of  buf size="+send_requestLen);
						stream_send_data.write(send_buf.toByteArray(), 0, send_buf.toByteArray().length);
					}
					catch(Exception eee)
					{
						try
						{
							logger.error("Exception Sending Data:: "+eee.toString());
						}
						catch(Exception e)
						{
							logger.error(e);
						}

						//return;
					}

					//break;  //Uncommented just for compile otherwise no need to be here ....
				}
			}

		}catch(Exception e)
		{logger.error(e);
			logger.error(" sendtoclient exiting ");
			System.exit(1);
			thrd.stop();
			logger.error(" sendtoclient stopped success ");
		}
		finally
		{
			try{
				con.close();	
			}
			catch(Exception econ1){  logger.info("Caught Exception :" +econ1.toString());}
		}
	}
}
