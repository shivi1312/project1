/*
 * ListQueue.java
 *
 * Created on June 9, 2010, 3:59 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.telemune.httpinterface;

/**
 *
 * @author ashu
 */
import java.net.*;
import java.io.*;

public class ListQueue  implements Queue {
    
    /** Creates a new instance of ListQueue */
    public ListQueue() {
		front = back = null;
    }
   	public boolean isEmpty( ) {
		return front == null;
	}
 	public void enqueue( user_data x ) {
		if( isEmpty( ) )    // Make queue of one element
			back = front = new ListNode( x );
		else                // Regular case
			back = back.next = new ListNode( x );
	}

public user_data dequeue( ) 
	{
		if( isEmpty( ) )
			throw new UnderflowException( "ListQueue dequeue" );

		user_data returnValue = front.element;
		front = front.next;
		return returnValue;
	}
public user_data getFront( ) {
		if( isEmpty( ) )
			throw new UnderflowException( "ListQueue getFront" );
		return front.element;
	}

	/**
	 * Make the queue logically empty.
	 */
	public void makeEmpty( ) {
		front = null;
		back = null;
	}

	private ListNode front;
	private ListNode back;
}

class UnderflowException extends RuntimeException {
	/**
	 * Construct this exception object.
	 * @param message the error message.
	 */
	public UnderflowException( String message ) {
		super( message );
	}
}
class ListNode {
	// Constructors
	public ListNode( user_data theElement ) {
		this( theElement, null );
	}

	public ListNode( user_data theElement, ListNode n ) {
		element = theElement;
		next    = n;
	}

	public user_data  element;
	public ListNode next;
}


interface Queue 
{
	/**
	 * Insert a new item into the queue.
	 * @param x the item to insert.
	 */
	void  enqueue( user_data x );

	/**
	 * Get the least recently inserted item in the queue.
	 * Does not alter the queue.
	 * @return the least recently inserted item in the queue.
	 * @exception UnderflowException if the queue is empty.
	 */
	user_data getFront( );

	/**
	 * Return and remove the least recently inserted item
	 * from the queue.
	 * @return the least recently inserted item in the queue.
	 * @exception UnderflowException if the queue is empty.
	 */
	user_data dequeue( );

	/**
	 * Test if the queue is logically empty.
	 * @return true if empty, false otherwise.
	 */
	boolean isEmpty( );

	/**
	 * Make the queue logically empty.
	 */
	void makeEmpty( );
}

