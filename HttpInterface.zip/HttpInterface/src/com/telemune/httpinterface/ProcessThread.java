package com.telemune.httpinterface;

import java.util.concurrent.ArrayBlockingQueue;

public class ProcessThread{
    public static int minThreadSize = 5;
    public static int maxThreadSize = 10;
    public static int waitQueueSize = 100;

}
