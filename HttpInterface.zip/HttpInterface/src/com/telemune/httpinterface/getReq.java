
/*
 * class_get_data_client.java
 *
 * Created on June 24, 2010, 12:12 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package com.telemune.httpinterface;


import java.io.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import TlvLib.*;
//import dbutility.*;
import org.apache.log4j.*;



/**
 *
 * @author ashu
 */

class getReq implements Runnable
{

	static Logger logger=Logger.getLogger(getReq.class.getName());

	String name;
	Thread thrd;
	Socket socket_me;
	DataInputStream reader = null;
	getReq(String name,Socket socket)
	{
		thrd = new Thread(this,name);
		this.name = name;
		socket_me = socket;
		logger.info("\nstarted thread to recv data: #" + name );
		//thrd.start();
	}
	public void run()
	{
		getfromclient(name,socket_me);
	}
	public void stop()
	{

	}
	public void getfromclient(String name,Socket socket_me)
	{
		try{
			reader = new DataInputStream(socket_me.getInputStream());}
		catch(Exception E1)
		{	
			E1.printStackTrace();
		}
		logger.info("\nPreparing to recv  data thread# "+ name);
		try
		{
			TLVAppInterface tcp_req ;
			tcp_req = new TLVAppInterface();
			while(true)
			{

				//	logger.debug("###############inside while true condition#################");
				if (socket_me.isClosed())
				{
					logger.info("Socket closed");
					thrd.stop();

					return;

				}
				else
				{	
					ByteArrayInputStream inbuf = null;

					logger.info("reading Info ....");
					logger.info("reading Info ........");
					logger.info("Socket==="+socket_me.toString());
					byte dataBuf1[] = new byte[4];

					int dataLen =0;
					try
					{

						if(reader.read(dataBuf1,0,4)==-1)
						{
							logger.info("reader.read == -1 ...");

							try
							{
								socket_me.close();
								logger.info("Destroy");
								logger.info("socket closed");
								thrd.stop();
								return;
							}
							catch(Exception e)
							{
								logger.info(e);
							}

						}
						int test=0;
						dataLen = dataLen | (dataBuf1[0] << 24);
						dataLen = dataLen  | (dataBuf1[1] << 16);
						dataLen = dataLen | (dataBuf1[2] << 8);
						test=(0x000000ff & dataBuf1[3]);
						dataLen = dataLen | test;

						logger.info("reading Info ......data len.."+dataLen);
					}
					catch (Exception e)
					{
						logger.error("Getting exception in reading...."+e.toString());
						try
						{
							thrd.sleep(1000);
							socket_me.close();

						}
						catch(Exception eee)
						{
							logger.error("Sleep Exception in main");
						}	
						//															continue;
					}
					if (dataLen==0)
					{	try
						{
							logger.info("Sleeping.....n");
							thrd.sleep(10);
						}
						catch(Exception eee)
						{
							logger.error("Sleep Exception in main");
						}
					}

					logger.info("recieved tcp_req size="+dataLen);
					byte dataBuf[] = new byte[dataLen];

					reader.read(dataBuf, 0, dataLen);

					inbuf = new ByteArrayInputStream(dataBuf);

					logger.info("Readed data is ["+dataBuf+"] decode buffer data is ["+inbuf+"]");
					//		logger.info("going to decode buffer data"+inbuf);
					tcp_req.decode(inbuf,dataLen);

					String l_msisdn = "";
					String l_data = "";
					int l_requestID = 0;


					{

						user_data data_object = new user_data();
						logger.info("req "+ tcp_req.getData (1)+ "  "+tcp_req.getData (2)+ "  "+tcp_req.getData (3)+ "  "+tcp_req.getData (4));

						data_object.user_msisdn = tcp_req.getData (1);
						if(globalobj.encript_decript_flag==1)
						{
							data_object.user_data = EncriptDecript.decript(tcp_req.getData(2));
						}
						else
						{
							data_object.user_data = tcp_req.getData(2);
						}
						
						data_object.dialog_id = Integer.parseInt(tcp_req.getData(4));
						data_object.op_code = Integer.parseInt(tcp_req.getData(3));
						if(data_object.op_code==9)
						{
							data_object.action_id= Integer.parseInt(tcp_req.getData(6));
						}
						logger.info("##msisdn["+data_object.user_msisdn+"] userData["+data_object.user_data+"] dialogId["+data_object.dialog_id+"] op_code["+data_object.op_code+"]");
						///////Update for Push Request//////////////
						if(data_object.op_code==7 || data_object.op_code==1)
						{
							data_object.sessionId=tcp_req.getData(10);//need to set 	
							logger.info("## sessionId["+data_object.sessionId+"]  sessionID in TCP["+tcp_req.getData(10)+"]");
						}
						//data_object.sock=socket_me;

						if (globalobj.datarecvque.isEmpty())
						{
							logger.info("Req Que is Empty" );
						}
						else
						{
							//	logger.info("Req Que is NOT Empty" );
						}
						logger.debug("Size of datarecvque is "+globalobj.datarecvque.size());
						//globalobj.datarecvque.enqueue (data_object);
						globalobj.datarecvque.put(data_object);
						//logger.info("Element is inserted in the queue...");
						if (globalobj.datarecvque.isEmpty())
						{
							logger.info("Req Que is still Empty" );
						}
					}
				}
			}
		}
		catch(IOException e)
		{
			logger.error(e);
			logger.error("got exception ......");
		}
		catch(Exception exe)
		{
			logger.error("Exception inside try block of getdata...",exe);
		}
	}
}
