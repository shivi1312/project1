/*
 * user_data.java
 *
 * Created on June 9, 2010, 12:58 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.telemune.httpinterface;


public class user_data
{
        int req_id=-1;
        int op_code=-1; // op_code will define the value of req.// while sending req_continue=1; req_close=0; 
        // while coming req continue=1 requet new=0;
        String user_data="";
        //user data will contain the values comes from user and send back the response;
        String user_msisdn="";
        int dialog_id=-1;
        int action_id=-1;
        String short_code="";
        String sessionId="";
        boolean isPush=false;
        int errCode=-1;
}