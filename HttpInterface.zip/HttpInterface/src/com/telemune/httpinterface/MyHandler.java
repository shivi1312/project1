

/*
 * MyHandler.java
 *
 * Created on June 18, 2010, 11:02 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package com.telemune.httpinterface;


import java.io.*;
import java.net.InetSocketAddress;
import java.util.*;
import java.sql.*;
import java.net.*;

import com.google.gson.Gson;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import com.telemune.httpinterface.bean.PushRequestBody;

import org.apache.log4j.*;

/**
 *
 * @author ashu
 */


public class MyHandler extends Thread implements HttpHandler 
{
		  static Logger logger=Logger.getLogger(MyHandler.class.getName());
	/** Creates a new instance of MyHandler */



	public MyHandler()
	{

	}
		
	public void handle(HttpExchange exchange) throws IOException 
	{
		if(globalobj.push_header_enable==1)
		{
			logger.info("====Getting Request through Headers==== ");
			getRequestByRequestHeaders(exchange);
		}
		else
		{
			logger.info("====Getting Request through Body==== ");
			getRequestByRequestBody(exchange);
		}
	}
	
/*

	public int insertintoDB(String userName,String password,int optionVal,int status_code)
	{
		int ref_id=-1;
		try
		{
			Statement stmt=con.createStatement();
			String query="select cbs_req_id.nextval from dual";
			rs=stmt.executeQuery(query);
			while(rs.next())
			{
				ref_id=rs.getInt(1);
			}
			rs.close();
			stmt.close();
		}
		catch(Exception sqlE)
		{
			logger.info("Error in SQL:::"+sqlE.toString());
		}
		PreparedStatement pstmt=null; 
		String query_log="";

		query_log="insert into cbs_requests_detail(req_id,userName,password,request_type,request_status,request_time) values(?,?,?,?,?,sysdate)";
		try{
			pstmt=con.prepareStatement(query_log);
			pstmt.setInt(1,ref_id);
			pstmt.setString(2,userName);
			pstmt.setString(3,password);
			pstmt.setInt(4,optionVal);
			pstmt.setInt(5,status_code);

			pstmt.executeUpdate();
			logger.info(query_log);
			pstmt.close();
		}catch(SQLException sqlex)
		{
			try
			{
				pstmt.close();
			}
			catch(SQLException sqe){}
			logger.info("Problem in excute query::"+sqlex.toString());
		}
		return ref_id;
	}
*/
	public void getRequestByRequestBody(HttpExchange exchange)
	{
		String requestMethod = exchange.getRequestMethod();

		logger.info("Request Type || "+requestMethod);

		if (requestMethod.equalsIgnoreCase("POST") || requestMethod.equalsIgnoreCase("GET")) 
		{
			InputStream inputStream=exchange.getRequestBody();
			String jsonString=getStringFromInputStream(inputStream);
			
			Gson gson=new Gson();
			PushRequestBody requestBody=gson.fromJson(jsonString,PushRequestBody.class);
		/*	if(globalobj.encript_decript_flag==1)
			{
				logger.info("Request Data After Decription : "+requestBody.getData());
				requestBody.setData(EncriptDecript.decript(requestBody.getData()));
			}*/
			
			logger.info("Request Body is || "+jsonString);
			/*String s1=null;
			
					s1 = requestBody.getUserName().substring(1);
					s1 = s1.substring(0,s1.indexOf(']'));
					requestBody.setUserName(s1);	
					logger.info("=======UserName=================== || "+requestBody.getUserName());
					
					s1 = requestBody.getPassword().substring(1);
					s1 = s1.substring(0,s1.indexOf(']'));
					requestBody.setPassword(s1);	
					logger.info("=======Password=================== || "+requestBody.getPassword());
					
					s1 = requestBody.getDlId().substring(1);
					s1 = s1.substring(0,s1.indexOf(']'));
					requestBody.setDlId(s1);	
					logger.info("=======DlId=================== || "+requestBody.getDlId());
					
					s1 = requestBody.getData().substring(1);
					s1 = s1.substring(0,s1.indexOf(']'));
					requestBody.setData(s1);	
					logger.info("=======Data=================== || "+requestBody.getData());
					
					s1 = requestBody.getMsisdn().substring(1);
					s1 = s1.substring(0,s1.indexOf(']'));
					requestBody.setMsisdn(s1);	
					logger.info("=======Msisdn=================== || "+requestBody.getMsisdn());
					
					s1 = requestBody.getShortCode().substring(1);
					s1 = s1.substring(0,s1.indexOf(']'));
					requestBody.setShortCode(s1);	
					logger.info("=======ShortCode=================== || "+requestBody.getShortCode());
					
					s1 = requestBody.getOpCode().substring(1);
					s1 = s1.substring(0,s1.indexOf(']'));
					requestBody.setOpCode(s1);	
					logger.info("=======OpCode=================== || "+requestBody.getOpCode());
					
				logger.info("Parameter Lists UserName ["+requestBody.getUserName()+"] Password ["+requestBody.getPassword()+"] DLID ["+requestBody.getDlId()+" ] DATA ["+requestBody.getData()+"] MSISDN ["+requestBody.getMsisdn()+"] SHORTCODE ["+requestBody.getShortCode()+"] OPCODE ["+requestBody.getOpCode()+"]");

*/

			if(!(requestBody.getUserName().length()==0)&&!(requestBody.getPassword().length()==0))
			{
				logger.info("Inside Check Authentication Response");
				ProcessServer process=new ProcessServer(requestBody,exchange);
				Thread processthrd=new Thread(process);
				processthrd.start();
			}
			else
			{

				logger.info("Invalid User Name Password UserNmae ["+requestBody.getUserName()+"] Password ["+requestBody.getPassword()+"]");
			
			}

		}
		else
		{
			logger.info("Invalid Request Type ||");
		}
	
		
	}
	public void getRequestByRequestHeaders(HttpExchange exchange)
	{
		String userName="",password="",data="",dlId="",msisdn="",shortCode="",opCode="";
		String requestMethod = exchange.getRequestMethod();

		logger.info("Request Type || "+requestMethod);

		if (requestMethod.equalsIgnoreCase("POST") ||requestMethod.equalsIgnoreCase("GET")) 
		{		
			Headers responseHeaders = exchange.getResponseHeaders();

			logger.info("Response header is || "+responseHeaders);

			Headers requestHeaders = exchange.getRequestHeaders();
			logger.info("Request header is || "+requestHeaders);

			Set<String> keySet = requestHeaders.keySet();
			Iterator<String> iter = keySet.iterator();
			logger.info("Request header keySet || "+keySet);

			while (iter.hasNext()) 
			{
				String key = (String) iter.next();
				List <String> values = requestHeaders.get(key);

				logger.info("Getting requestHeaders Key  [  "+key+"] Value ["+values.toString()+"]");

				String s1=null;
				
				if(key.equalsIgnoreCase("USERNAME"))
				{
					 s1 = ((values.toString()).substring(1));
					 s1 = s1.substring(0,s1.indexOf(']'));
					userName=s1;	
					logger.info("=======UserName=================== || "+userName);
				}
				if(key.equalsIgnoreCase("PASSWORD"))
				{
					s1 = ((values.toString()).substring(1));
					s1 = s1.substring(0,s1.indexOf(']'));
					password=s1;	
					logger.info("=======Password=================== || "+password);
				}
				if(key.equalsIgnoreCase("DLID"))
				{
					s1 = ((values.toString()).substring(1));
					s1 = s1.substring(0,s1.indexOf(']'));
					dlId=s1;	
					logger.info("=======DlID=================== || " +dlId);
				}
				if(key.equalsIgnoreCase("DATA"))
				{
			/*		if(globalobj.encript_decript_flag==1)
					{
						s1 = ((EncriptDecript.decript(values.toString())).substring(1));
					}
					else
					{
						s1 = ((values.toString()).substring(1));
					}*/
					s1 = ((values.toString()).substring(1));
					s1 = s1.substring(0,s1.indexOf(']'));
					data=s1;
					logger.info("=======Data=================== || "+data);
				}

				if(key.equalsIgnoreCase("MSISDN"))
                {
                    s1 = ((values.toString()).substring(1));
                    s1 = s1.substring(0,s1.indexOf(']'));
                    msisdn=s1;
                    logger.info("=======Msisdn=================== || "+msisdn);
                }
				if(key.equalsIgnoreCase("SHORTCODE"))
				{
					s1 = ((values.toString()).substring(1));
					s1 = s1.substring(0,s1.indexOf(']'));
					shortCode=s1;
					logger.info("=======SHORTCODE=================== || "+shortCode);
                }

				if(key.equalsIgnoreCase("OPCODE"))
                {
                    s1 = ((values.toString()).substring(1));
                    s1 = s1.substring(0,s1.indexOf(']'));
                    opCode=s1;
                    logger.info("=======OPCODE=================== || "+opCode);
                }
			}

			logger.info("Parameter Lists UserNmae ["+userName+"] Password ["+password+"] DLID ["+dlId+" ] DATA ["+data+"] MSISDN ["+msisdn+"] SHORTCODE ["+shortCode+"] OPCODE ["+opCode+"]");

			if(!(userName.length()==0)&&!(password.length()==0))
			{
				logger.info("Inside Check Authentication Response");
				ProcessServer process=new ProcessServer(userName,password,dlId,data,msisdn,shortCode,opCode,responseHeaders,exchange);
				Thread processthrd=new Thread(process);
				processthrd.start();
			}
			else
			{

				logger.info("Invalid User Name Password UserNmae ["+userName+"] Password ["+password+"]");
			
			}

		}
		else
		{
			logger.info("Invalid Request Type ||");
		}
	
	}
	public String getStringFromInputStream(InputStream inputStream)
	{
		BufferedReader reader=null;
		StringBuilder stringBuilder=new StringBuilder();
		String line=null;
		
		try
		{
			reader=new BufferedReader(new InputStreamReader(inputStream));
			while((line=reader.readLine()) !=null)
			{
				stringBuilder.append(line);
			}
		}
		catch(IOException e)
		{
			logger.error(e);
		}
		catch(Exception e)
		{
			logger.error(e);
		}
		finally
		{
			if(reader!=null)
			{
				try
				{
					reader.close();
				}
				catch(IOException e)
				{
					logger.error(e);
				}
				catch(Exception e)
				{
					logger.error(e);
				}
			}
		}
		return stringBuilder.toString();
	}
		
}
