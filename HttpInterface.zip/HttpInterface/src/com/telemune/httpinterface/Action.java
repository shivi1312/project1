
/*
 * conclients.java
 *
 * Created on June 9, 2010, 5:09 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.telemune.httpinterface;

/**
 *
 * @author ashu
 */
public class Action {

				/** Creates a new instance of conclients */
				public Action() {
				}
				public String url="";
				public int action_id=-1;
				public String action_name="";
				public String user_name="";
				public String password="";
}
