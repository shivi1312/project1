package com.telemune.httpinterface;


import java.util.concurrent.ThreadPoolExecutor;
import org.apache.log4j.Logger;

public class ThreadPoolExtrProcessHandler implements Runnable {
	
	  Logger logger = Logger.getLogger("ThreadPoolExtrServiceHandler");

	  ThreadPoolExecutor contentexecutorPool = null;
	   static int count=0;

	
	 public ThreadPoolExtrProcessHandler(ThreadPoolExecutor contentexecutorPool) {
		
		this.contentexecutorPool = contentexecutorPool;
	}


	public void run() {

	       try
		{
	        while (true) {
	      			if (globalobj.datarecvque.isEmpty())
                                 {   
	      								try
                                        {
                                            //logger.debug("################Thread is sleep for 1 second############");
                                            Thread.sleep(10);
                                        }
                                        catch(Exception se)
                                        {
                                            logger.error("exception in charging server");
                                        }
                               	}
                      else
                      {
	                    
                    	  try
                    	  {
                    		  	logger.debug("THREAD POOL FOUND REQUEST TO PROCESS ");
                    		  	user_data data_object = new user_data();
	
                    		  	data_object=(user_data)globalobj.datarecvque.poll();
                                                        count++;
                                                        if(count==10000)
                                                        {
                                                        logger.info("Size of globalobj.mp is ["+globalobj.mp.size()+"]");
                                                        count=0;
                                                        }

                                                        contentexecutorPool.execute(new ProcessRequest(data_object));
                    	  }

                    	  	catch(Exception e){
                    	  		logger.error("ContentThreadPoolManager request queue is already full ... so No more request can be taken.. discarding this request",e);
                    	  		System.exit(1);
                    	  		break;
                    	  	}

	            }



	        }//while(true)
		}
catch(Exception e){

	         logger.error("Error In ContentThreadPoolManager run(),",e);
	        }

	    }//run()
}
