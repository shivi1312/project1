package com.telemune.smsc.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.telemune.smsc.bean.SmsgBean;
import com.telemune.smsc.config.GlobalParams;
import com.telemune.smsc.entity.GmatMsg;
import com.telemune.smsc.repo.GmatRepository;
import com.telemune.smsc.service.SmsgService;




@Service
public class SmscServiceImpl implements  SmsgService  {
	@Autowired
    GmatRepository gmatRepository;
	
	@Autowired(required = true)
	private GlobalParams globalParams;


	public void sendSMS(SmsgBean smsgbean, String Origination, String destination, String message) {
		try {
            makeCallLogs(smsgbean);
			GmatMsg msg = new GmatMsg();
			msg.setOrigin(Origination);
			msg.setDestination(destination);
			msg.setMessage(message);

			gmatRepository.save(msg);
		} catch (Exception e) {
		}
	}
	
	public synchronized void makeCallLogs(SmsgBean smsgbean) {
		try {
			globalParams.getFileLogWriter().writeLog(smsgbean.toString());
		} catch (Exception e) {
			
		}
	}

}
