package com.telemune.smsc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.smsc.bean.SmsgBean;
import com.telemune.smsc.service.SmsgService;


@RestController
public class SmscController {
	@Autowired
 private  SmsgService smscserviceimpl;
//	@Autowired(required=true)
//	private GlobalParams globalParams;


	
	@GetMapping("/recieve")
	public ResponseEntity saveSms(@RequestParam("Origination_number") String Origination, @RequestParam("destination_number") String destination,
	@RequestParam("message") String message)
	{


			SmsgBean smsgbean = new SmsgBean();
			smsgbean.setOrigination_number(Origination);
			smsgbean.setDestination_number(destination);
			smsgbean.setMessage(message);
			smscserviceimpl.sendSMS(smsgbean, Origination, destination ,message);
			
			
			


			return ResponseEntity.status(HttpStatus.OK).body("OK");




}

}