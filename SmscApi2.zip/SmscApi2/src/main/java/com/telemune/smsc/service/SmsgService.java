package com.telemune.smsc.service;

import com.telemune.smsc.bean.SmsgBean;

public interface SmsgService {

	public void sendSMS(SmsgBean smsgbean, String Origination, String destination, String message);
}
