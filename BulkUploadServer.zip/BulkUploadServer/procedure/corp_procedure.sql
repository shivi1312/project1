 
/*
 * In property File PROC_PACKAGE value is 1 then use CRBTCORPBULKUPLOAD package and compile this procedure.sql file
 * if in property file PROC_PACKAGE value is 0 or not Found then don't compile this procedure.sql file
 * add CheckForCorpSubscription, CorpSubscribe and CorpUnsubscribe procedures in procedure.sql file in Rule Engine in CRBTNEW Package.
 * Then compile Rule Engine procedure.sql file   
 * 
 */

CREATE OR REPLACE PACKAGE CRBTCORPBULKUPLOAD as
	 
	Procedure CheckForCorpSubscription(p_msisdn in varchar2,p_maxsub in number,p_plan in number,p_corpid in number,p_maxsubcorp in number,p_status out number);
	Procedure CorpSubscribe (p_msisdn in varchar2,p_plan in number,p_lang in number,p_updatedby in varchar2,p_subtype in varchar2,p_pin in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_isPackSubscriber in number,p_corpId in long,p_corpName in varchar2,p_imsi in varchar2,p_rbtCode in number,p_passwd in varchar2,p_day in number,p_startTime in number,p_endTime in number, p_status out number,p_id out number);	 
	Procedure CorpUnsubscribe (p_msisdn in varchar2, p_updatedby in varchar2, p_corpId in long, p_corpName in varchar2, p_status out number,p_response out number,p_id out number);
	
End CRBTCORPBULKUPLOAD;
/
show errors;

CREATE OR REPLACE PACKAGE BODY CRBTCORPBULKUPLOAD as


Procedure CheckForCorpSubscription(p_msisdn in varchar2,p_maxsub in number,p_plan in number,p_corpid in number,p_maxsubcorp in number,p_status out number) is
l_temp          number ;
l_totsub 	number;
Begin
        p_status:=1;
        l_temp:=0;
	l_totsub:=0;
	
	if p_maxsubcorp!=-99 then 
		select count(msisdn) into l_totsub from crbt_subscriber_master where corp_id = p_corpid;
		if l_totsub >=p_maxsubcorp then 
			p_status:=-26;
			return;
		end if;
	end if;

        select to_number(param_value) into l_temp from crbt_app_config_params where param_tag='WHITELIST_ENABLE';
        if l_temp = 1 then
                select count(*) into l_temp from crbt_whitelist where to_number(STARTS_AT) <=to_number(p_msisdn) and to_number(ENDS_AT) >=to_number(p_msisdn);
                if l_temp = 0 then
                        p_status:=-25;
                        return;
                end if;
        end if;

        select count(msisdn) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and status != 'D';
        if l_temp!=0
        then
		select plan_indicator into l_temp from  crbt_subscriber_master where msisdn=p_msisdn ;

                if l_temp != p_plan  and p_plan!=-1 then
                        p_status:=-33;                  -- person is already subscribe with different plan
                else
                p_status:=-20;
                end if;
                RETURN;
        end if;
        l_temp:=0;
        select count(msisdn) into l_temp from crbt_subscriber_master where status='A';
        if l_temp > p_maxsub
        then
                p_status:=-21;
                RETURN;
        end if;

        l_temp:=0;

        select count(range_id) into l_temp from OPERATOR_SUBSCRIBER where (to_number(STARTS_AT) <=to_number(p_msisdn) and to_number(ENDS_AT) >=to_number(p_msisdn) and p_msisdn not in (select EXCLUDE_NUM from OPERATOR_SUBSCRIBER_EXCLUDE)) or p_msisdn in ( select INCLUDE_NUM from OPERATOR_SUBSCRIBER_INCLUDE);
        dbms_output.put_line( 'in procedure subscriber msisdn===' || p_msisdn);
        dbms_output.put_line( 'in procedure subscriber l_temp===' || l_temp);

        if l_temp=0
        then
                p_status:=-22;
                RETURN;
        end if;

        exception
                when others then
                        p_status:=-1;
End CheckForCorpSubscription;


Procedure CorpSubscribe (p_msisdn in varchar2,p_plan in number,p_lang in number,p_updatedby in varchar2,p_subtype in varchar2,p_pin in varchar2,p_refid in varchar2,p_chgcode in number,p_validityDays in number,p_isPackSubscriber in number,p_corpId in long,p_corpName in varchar2,p_imsi in varchar2,p_rbtCode in number,p_passwd in varchar2,p_day in number,p_startTime in number,p_endTime in number, p_status out number,p_id out number) is 
l_wltid	number;
l_temp number;
l_pre_amount  number;
l_post_amount  number;
l_final_amount number;
l_isSystemRbtBased number;
l_paramValue number;
l_packId number;
l_isSub number;
Begin
	p_status:=1;
	p_id:=-1;
	select AMOUNT_POST,AMOUNT_PRE into l_post_amount,l_pre_amount from crbt_charging_code where CHARGING_CODE=p_chgcode;
        if p_subtype = 'O' then
           	l_final_amount:=l_post_amount;
        else
	        l_final_amount:=l_pre_amount;
        end if;
        p_status:=2;

	select SCDR_ID.nextval into p_id from dual;
	insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount) values (p_id,p_msisdn,'T',sysdate,'S',p_plan,'N',p_subtype,p_refid,p_chgcode,l_final_amount);
	p_status:=3;
	commit;

    	insert into crbt_subscriber_master (msisdn,status,plan_indicator,rbt_code,password,tpin,language,sub_type,last_charged,expiry_date,IMSI, CORP_ID,IS_MONTHLY_CHARGEABLE,CORP_EXPIRY) values (p_msisdn,'A',p_plan,p_rbtCode,p_passwd,p_pin,p_lang,p_subtype,sysdate-30+p_validityDays,sysdate+p_validityDays,p_imsi,p_corpId,'Y',sysdate+p_validityDays);
	p_status:=4;
	commit;

	select wallet_id_seq.nextval into l_wltid from dual;
	insert into crbt_wallet_master (msisdn,wallet_id,create_date,wallet_name,ivr_name)	values (p_msisdn,l_wltid,sysdate,'DEFAULT',0);
	p_status:=5;
	commit;

	insert into crbt_wallet_content (wallet_id,rbt_code,create_date,is_rbt_gifted,msisdn) values (l_wltid,p_rbtCode,sysdate,2,p_msisdn);
	p_status:=6;
	commit;

	insert into crbt_default_detail (msisdn,day,start_at,ends_at,rbt_code,update_time) values (p_msisdn,p_day,p_startTime,p_endTime,p_rbtCode,sysdate);
	p_status:=7;
	commit;

	insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id) values (p_msisdn,p_subtype,sysdate,'S','T','Y',p_updatedby,p_id);
	p_status:=8;
	commit;

	insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'SUBSCRIBED TO CORP:'||p_corpName,p_subtype,'T',p_updatedby);
	p_status:=9;
	commit;

	exception
		when others then
		if p_status > 1 then
			delete from crbt_event_cdr where cdr_id=p_id;
			commit;
			delete from crbt_subscriber_master where msisdn=p_msisdn;
			commit;
			delete from crbt_subscription_log where msisdn=p_msisdn and call_id=p_id;
			commit;
		end if;
		p_status:=(p_status*(-1));
End CorpSubscribe;

 
Procedure CorpUnsubscribe (p_msisdn in varchar2, p_updatedby in varchar2, p_corpId in long, p_corpName in varchar2, p_status out number,p_response out number, p_id out number) is
l_temp          number;
l_status        varchar(2);
l_planId        number;
l_subtype       varchar(1);
Begin
        l_temp:=0;
        p_status:=-1;
        l_planId:=-1;
        l_subtype:='N';
        p_id:=-1;
	p_response:=-1;

        select count(*) into l_temp from crbt_subscriber_master where msisdn=p_msisdn and CORP_ID=p_corpId;
        if l_temp = 0 then
                p_response:=-24;
                RETURN;
        end if;
        p_status:=1;
	p_response:=1;

        select PLAN_INDICATOR,SUB_TYPE into l_planId,l_subtype from CRBT_SUBSCRIBER_MASTER where MSISDN =p_msisdn  and CORP_ID=p_corpId;
        p_status:=2;
	p_response:=2;

        select SCDR_ID.nextval into p_id from dual;
        insert into crbt_event_cdr (cdr_id,msisdn,interface_used,update_time,action,plan_indicator,status,sub_type,reference_id,TARIFF_ID,amount) values (p_id,p_msisdn,'T',sysdate,'U',1,'N',l_subtype,'00000000000',-1,0);
        dbms_output.put_line( 'subscriber is postpaid ..scdr id ' || p_id);
        p_status:=3;
	p_response:=3;
        dbms_output.put_line('CRBT EVENT CDR');

        dbms_output.put_line( 'after cdr');
        insert into crbt_subscriber_master_old (select * from crbt_subscriber_master where msisdn=p_msisdn);
        commit;
        delete from crbt_subscriber_master where msisdn=p_msisdn;
        dbms_output.put_line( 'after deletion');
        p_status:=4;
	p_response:=4;
        commit;
        dbms_output.put_line('CRBT SUBSCRIBER MASTER');

        insert into crbt_cdrs ( msisdn,TARIFFID,ACTION,INTERFACE,SERVICE_CLASS,DA_ID,CREATE_DATE,FMSISDN,RBT_CODE,AMOUNT,STATUS,CDR_ID) values (p_msisdn,-1,9,'T',-1,0,sysdate,'NA',-1,0,'N',crbt_cdr_id.nextval);
        p_status:=5;
	p_response:=5;
        commit;
        dbms_output.put_line('CRBT CDRS');

        if l_subtype='P' then
                insert into CRBT_PREPAID_SUBSCRIPTION_CDR (PRE_SCDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, ACTION, PLAN_INDICATOR, STATUS) values (PRE_SCDR_ID.nextval, p_msisdn, 'T', sysdate, 'U',l_planId, 'N');
          else
                insert into CRBT_SUBSCRIPTION_CDR (SCDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, ACTION, PLAN_INDICATOR, STATUS) values (SCDR_ID.nextval,p_msisdn , 'T', sysdate, 'U',l_planId, 'N');
	end if;
        p_status:=6;
	p_response:=6;
        commit;
        dbms_output.put_line('SUBSCRITION CDR log');

        insert into crbt_subscription_log (msisdn,subscriber_type,activity_date,activity,interface_type,was_charged,updated_by,call_id,unsub_reason) values (p_msisdn,l_subtype,sysdate,'U','T','N',p_updatedby,0,-1);
        p_status:=7;
	p_response:=7;
        commit;
        dbms_output.put_line( 'subscription log');

        insert into crbt_activity_detail_log (msisdn,start_time,request_type,request_data,subscriber_type,request_from,updated_by) values (p_msisdn,sysdate,1,'UNSUBSCRIBED FROM CORP:'||p_corpName,l_subtype,'T',p_updatedby);
        p_status:=8;
	p_response:=8;
        commit;
        dbms_output.put_line( 'activity log');

        p_status:=9;
	p_response:=9;
        exception
                when others then
		if p_response>=4 and p_response<=9 then 
				p_response:=-23;
		else 			
	                p_response:=(p_response*(-1));
		end if;

End CorpUnsubscribe;

--//////////////////////////////;
End CRBTCORPBULKUPLOAD;			
/
show errors;
quit;
