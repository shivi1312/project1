package com.telemune.bulkupload.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import com.telemune.bulkupload.db.DBQueries;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.telemune.bulkupload.beans.ListDataBean;
import com.telemune.bulkupload.db.ConnPool;
import com.telemune.bulkupload.threads.CacheLoader;
import com.telemune.bulkupload.threads.CorpQueueReader;
import com.telemune.bulkupload.threads.ReadCorp;
import com.telemune.bulkupload.threads.ResponseQueueReader;

import FileBaseLogging.FileLogWriter;

public class BulkUploadServer {
	
	private static final Logger logger=Logger.getLogger("BulkUploadServer.class");	
	private static FileLogWriter flwFailupdation = null;
	public static int DBTYPE=0; //added by Tannu Bajpai
	public static BulkUploadServer instance=null;
	
	public static void main(String[] args)
	{	
		
	
		
		File log4jfile = null;
		try
		{		
				log4jfile = new File("properties/bulkUploadServer_log.properties");				
				if(!log4jfile.exists())
				{
					System.out.println("bulkUploadServer_log.properties file not found");					
					System.exit(1);
				}
				System.out.println("Logger file bulkUploadServer_log.properties file Path:"+log4jfile.getAbsolutePath());
				PropertyConfigurator.configure(log4jfile.getAbsolutePath());			
			
			//Using -v or -V command line argument for checking the version of the binary
			if(args.length>0 && "-v".equalsIgnoreCase(args[0]))
			{
				printVersion();
				System.exit(1);
			}
			
		}		
		catch(NullPointerException npe)
		{
			logger.fatal("[CRBT-BU-90003] error some value may be null in main() of class BulkUploadServer ",npe);
			System.exit(1);
		}		
		catch(Exception e) 
		{
			logger.fatal("[CRBT-BU-00001] Exception in Main Method while loading bulkUploadServer_log.properties file of class BulkUploadServer ",e); 
			System.exit(1);
		}
		
		try 
		{
			loadPropertiesFile();
			startThreads();
		}
		catch (Exception e) 
		{
			logger.error("[CRBT-BU-00002] Exception in Main() of class BulkUploadServer ",e); //added by Ashish on 09-11-2016 
		}
		finally
		{	
				logger.fatal("All Threads stopped ");
				System.exit(1);
		}
	}//main() ends here
	
	private static void loadPropertiesFile()
	{
		String VERSION="R2_0_1_4";
		String SITE="BTC Bulk Upload System";
		logger.info("\n******************************************************************************************");
		logger.info("\n                               Site: "+SITE);
		logger.info("\n                               Version: "+VERSION);
		logger.info("\n******************************************************************************************");
		logger.info("\n");
	
		Properties bulkProperties = new Properties();
		String dbuser=null;
		String dbpass=null;
		String dburl=null;
		String driver=null;
         
		int numofcon=-1;
		int accomodation=-1;
		int minnumofcon=1;
		short conIdleTimeOut=60;
		
		try
		{
			FileInputStream fins=new FileInputStream("properties/bulkUploadServer.properties");
			bulkProperties.load(fins);
			fins.close();
		}
		catch(IOException ioe)
		{
			logger.fatal("[CRBT-BU-90002] bulkUploadServer.properties file not found ",ioe);
			System.out.println("bulkUploadServer.properties file not found");
			System.exit(1);
		}
		
		catch(NullPointerException npe)
		{
			logger.fatal("[CRBT-BU-90003] NullPointer Exception while reading bulkUploadServer.properties file ",npe);
			System.exit(1);
		}
		catch(Exception e)
		{
			logger.fatal("[CRBT-BU-00003] Exception while loading bulkUploadServer.properties file ",e);
			System.exit(1);
		}
		
		
		try
		{
			logger.info("Loading Configuration for the Application");
			dbuser=bulkProperties.getProperty("DBUSER").trim();
			dbpass=bulkProperties.getProperty("DBPASSWORD").trim();
			dburl=bulkProperties.getProperty("DBURL").trim();
			driver=bulkProperties.getProperty("DRIVER").trim();
			logger.info("Loading Threads Information");
			numofcon=Integer.parseInt(bulkProperties.getProperty("NUM_OF_CONNECTION").trim());
			minnumofcon=Integer.parseInt(bulkProperties.getProperty("MIN_NUM_OF_CONNECTION").trim());
			accomodation=Integer.parseInt(bulkProperties.getProperty("DB_ACCOMODATION").trim());
			Global.MIN_CONTENT_THREAD = Integer.parseInt(bulkProperties.getProperty("MIN_NUM_OF_CONTENT_THREADS").trim());
			Global.MAX_CONTENT_THREAD = Integer.parseInt(bulkProperties.getProperty("NUM_OF_CONTENT_THREADS").trim());
			Global.CACHE_RELOAD_TIME=Integer.parseInt(bulkProperties.getProperty("RELOAD_TIME").trim());
		
			Global.ROWNUM = Integer.parseInt(bulkProperties.getProperty("ROW_NUM").trim());
		
			Global.THREAD_INTERNAL_QUEUE_SIZE = Integer.parseInt(bulkProperties.getProperty("THREAD_INTERNAL_QUEUE_SIZE").trim());			
			Global.SSF_SERVER_HOST=bulkProperties.getProperty("SSF_SERVER_HOST").trim();//CHARGING IP
			Global.SSF_SERVER_PORT=Short.parseShort(bulkProperties.getProperty("SSF_SERVER_PORT").trim());//CHARGING PORT			
			Global.MSRN_FETCH_HOST=bulkProperties.getProperty("MSRN_FETCH_HOST").trim(); //HLR IP
			Global.MSRN_FETCH_PORT=Short.parseShort(bulkProperties.getProperty("MSRN_FETCH_PORT").trim());//HLR PORT			
			Global.SOURCE_TYPE = Byte.parseByte(bulkProperties.getProperty("SOURCE_TYPE").trim());			
			if(Integer.parseInt(bulkProperties.getProperty("BIGTLV_ENABLE").trim())==1) 
			{
				//true means enable false means disable
				Global.BIGTLV_ENABLE=true;
			}
			else
			{
				Global.BIGTLV_ENABLE=false;
			}
			
			if(Integer.parseInt(bulkProperties.getProperty("SEND_TO_HLR").trim())==1) 
			{
				//true means enable false means disable
				Global.SEND_TO_HLR=true;
			}
			else
			{
				Global.SEND_TO_HLR=false;
			}			
			
			if(Integer.parseInt(bulkProperties.getProperty("TLVBASE_ENABLE").trim())==1) 
			{
				//true means enable false means disable
				Global.TLVBASE_ENABLE=true;
			}
			else
			{
				Global.TLVBASE_ENABLE=false;
			}			
			
			Global.MESSAGE = bulkProperties.getProperty("MESSAGE").trim();	//SMS TEMPLATE MESSAGE		
			
			if(Integer.parseInt(bulkProperties.getProperty("DOACTDEACT").trim())==1) 
			{
				//true means enable false means disable
				Global.DOACTDEACT=true;
			}
			else
			{
				Global.DOACTDEACT=false;
			}
			
			if(Integer.parseInt(bulkProperties.getProperty("CHARGING_SCOPE").trim())==1) 
			{
				//true means enable false means disable
				Global.CHARGING_SCOPE=true;
			}
			else
			{
				Global.CHARGING_SCOPE=false;
			}
			Global.DEFAULT_LANGUAGE = Byte.parseByte(bulkProperties.getProperty("DEFAULT_LANGUAGE").trim());
			Global.SOCKET_TIME_OUT = Byte.parseByte(bulkProperties.getProperty("SOCKET_TIME_OUT").trim()); //added on 11-11-2016
			Global.CON_TIME_OUT=Short.parseShort(bulkProperties.getProperty("CON_TIME_OUT").trim()); //added on 22-11-2016
			conIdleTimeOut=Short.parseShort(bulkProperties.getProperty("CON_IDLE_TIME_OUT").trim()); //added on 24-11-2016
			
			
			if(Integer.parseInt(bulkProperties.getProperty("UNSUB_HLR_CONFIG").trim())==1) 
			{
				//true means Request goes to HLR enable false means insert into CRBT_HLR_INACTIVE
				Global.UNSUB_HLR_CONFIG=true;
			}
			else
			{
				Global.UNSUB_HLR_CONFIG=false;
			}
			
			Global.READER_QUEUE_SLEEP_TIME=Byte.parseByte(bulkProperties.getProperty("READER_QUEUE_SLEEP_TIME").trim());
			Global.RESPONSE_QUEUE_SLEEP_TIME=Byte.parseByte(bulkProperties.getProperty("RESPONSE_QUEUE_SLEEP_TIME").trim() );
			Global.APP_CONFIG_PARAMS=bulkProperties.getProperty("APP_CONFIG_PARAMS").trim();
			Global.READ_CORP_SLEEP_TIME=Short.parseShort(bulkProperties.getProperty("READ_CORP_SLEEP_TIME").trim());//ReadCorp Thread sleep time
			
			Global.readerQueue = new ArrayBlockingQueue<ListDataBean>(Integer.parseInt(bulkProperties.getProperty("ARRAY_BLOCKING_QUEUE").trim()));
			Global.responseQueue = new ArrayBlockingQueue<ListDataBean>(Integer.parseInt(bulkProperties.getProperty("ARRAY_BLOCKING_QUEUE").trim()));
			
			Global.HLR_TEST_CASE = Short.parseShort(bulkProperties.getProperty("HLR_TEST_CASE").trim());
			Global.MAX_RESPONSE_POOL_THREAD = Integer.parseInt(bulkProperties.getProperty("MAX_RESPONSE_POOL_THREAD").trim());
			Global.MIN_RESPONSE_POOL_THREAD = Integer.parseInt(bulkProperties.getProperty("MIN_RESPONSE_POOL_THREAD").trim());			
			Global.RESPONSE_POOL_THREAD_QUEUE_SIZE = Integer.parseInt(bulkProperties.getProperty("RESPONSE_POOL_THREAD_QUEUE_SIZE").trim());
			Global.HLR_CONNECTION_TRIES=Short.parseShort(bulkProperties.getProperty("HLR_CONNECTION_TRIES").trim());//Application tries to connect to HLR
			if(Global.HLR_CONNECTION_TRIES<1)
			{
				Global.HLR_CONNECTION_TRIES=1;
			}
			
			//added by Ashish on 28-Nov-2017 starts
			if(Integer.parseInt(bulkProperties.getProperty("LICENSE_ENABLE").trim())==1) 
			{
				Global.isLicenseFeatureEnable = true;
			}
			else
			{
				Global.isLicenseFeatureEnable = false;
			}
			//added by Ashish on 28-Nov-2017 ends

			//added by Ashish on 21-03-2018 starts
			String procPackage = bulkProperties.getProperty("PROC_PACKAGE");
			if(procPackage!=null)
				Global.PROC_PACKAGE = Integer.parseInt(procPackage)==1?1:0;
			//added by Ashish on 21-03-2018 ends
			//added by Avishkar on 07.01.2019 starts
			if(Integer.parseInt(bulkProperties.getProperty("IS_SET_DEFAULT_RBT").trim())==1) 
			{
				Global.IS_SET_DEFAULT_RBT = true;
			}
			else
			{
				Global.IS_SET_DEFAULT_RBT = false;
			}
			
			
			//added by Avishkar on 07.01.2019 ends
			
			flwFailupdation = new FileLogWriter();
            flwFailupdation.setNewFileInterval(Integer.parseInt(bulkProperties.getProperty("FAILED_UPDATION_FILE_INTERVAL").trim()));
            flwFailupdation.setFilename(bulkProperties.getProperty("FAILED_UPDATION_LOG_FILE_NAME").trim());
            flwFailupdation.setFilePath(bulkProperties.getProperty("FAILED_UPDATION_LOG_FILE_PATH").trim());
            flwFailupdation.setArchiveFilePath(bulkProperties.getProperty("FAILED_UPDATION_ARCHIVE_FILE_PATH").trim());
            flwFailupdation.setArchiveFilename(bulkProperties.getProperty("FAILED_UPDATION_ARCHIVE_FILE_NAME").trim());
            flwFailupdation.setArchiveFileExtension("");
            flwFailupdation.initialize();
            logger.info("ldbuser["+dbuser+"] l_dbpass["+dbpass+"] l_dburl["+dburl+"] l_driver["+driver+"] l_numofcon["+numofcon+"]  l_minnumofcon["+minnumofcon+"] l_numofcon["+numofcon+"]  ROW_NUM["+Global.ROWNUM+"] cacheReloadTime["+Global.CACHE_RELOAD_TIME+"] minThread["+Global.MIN_CONTENT_THREAD+"] NO_OF_CONTENT_THREAD:["+Global.MAX_CONTENT_THREAD+"] THREAD_INTERNAL_QUEUE_SIZE["+Global.THREAD_INTERNAL_QUEUE_SIZE+"]  socketTimeOut:["+Global.SOCKET_TIME_OUT+"] conTimeOut:["+Global.CON_TIME_OUT+"] conIdleTimeOut:["+conIdleTimeOut+"] unsubHlrConfig:["+Global.UNSUB_HLR_CONFIG+"] ReaderQueueEmptySleepTime:["+Global.READER_QUEUE_SLEEP_TIME+"] ResponseQueueEmptySleepTime:["+Global.RESPONSE_QUEUE_SLEEP_TIME+"] ReadCorpThreadSleepTime:["+Global.READ_CORP_SLEEP_TIME+"] CRBT_APP_CONFIG_PARAMS:["+Global.APP_CONFIG_PARAMS+"] hlrTestCase:["+Global.HLR_TEST_CASE+"] MAX_RESPONSE_POOL_THREAD:["+Global.MAX_RESPONSE_POOL_THREAD+"] MIN_RESPONSE_POOL_THREAD:["+Global.MIN_RESPONSE_POOL_THREAD+"] RESPONSE_POOL_THREAD_QUEUE_SIZE:["+Global.RESPONSE_POOL_THREAD_QUEUE_SIZE+"] hlrConnectionTries:["+Global.HLR_CONNECTION_TRIES+"] isLicenseFeatureEnable["+Global.isLicenseFeatureEnable+"] PROC_PACKAGE["+Global.PROC_PACKAGE+"]");
            
            logger.debug("Intializing Database... DBUser Name: ["+dbuser+"] DB Passowrd: ["+dbpass+"] DB Driver ["+driver+"] Minimum No Connection ["+minnumofcon+"] DB Accomodation ["+accomodation+"]");
    		Global.conPool=new ConnPool(driver,dburl,dbuser,dbpass,minnumofcon,numofcon,accomodation,conIdleTimeOut);
    		Global.conPool.MakePool();
    		logger.info("Starting Threads");
    		Global.dbType=bulkProperties.getProperty("dbType").trim(); //added by Tannu Bajpai
    		Global.DBTYPE=Integer.parseInt(bulkProperties.getProperty("DBTYPE").trim()); //added by Tannu Bajpai
    		logger.info("Loading the Dbtype parameter:"+Global.DBTYPE); //added by Tannu Bajpai
    		//DBQueries queries=new DBQueries(); 
    		DBQueries.loadAllQueries();
		}
		catch(NullPointerException npe)
		{
			logger.fatal("[CRBT-BU-90003] NullPointerException while reading property file parameters ",npe);
			System.exit(1);				
		}
		catch(NumberFormatException nfe)
		{
			logger.fatal("[CRBT-BU-90004] NumberFormatException while parsing property file parameters ",nfe);
			System.exit(1);
		}
	
		catch(Exception exp)
		{
		
			logger.fatal("ReadExce:"+exp.toString());
			logger.fatal("[CRBT-BU-00004] Exception while reading property file parameters ",exp); //added by Ashish on 09-11-2016 
			System.exit(1);
		}
	}//loadPropertiesFile()
	
	private static void printVersion()
	{
				String VERSION="R2_0_1_4";
				String SITE="BTC Bulk Upload Server Module";
				System.out.println("\n******************************************************************************************");
				System.out.println("\n                               Site: "+SITE);
				System.out.println("\n                               Version: "+VERSION);
				System.out.println("\n******************************************************************************************");
				System.out.println("\n");
				
				VERSION=null;
				SITE=null;
	}//printVersion() ends
	
	
	private static void startThreads()
	{		
		Thread threadCorpReader = null; //reader thread put data in reader queue from db
		Thread threadCorpQueueReader =null;//Queue Reader thread
		Thread threadResponseQueueReader=null; //ResponseQueueReader
		Thread threadCacheLoader=null; //cacahe Loader Thread
		
		try
		{
			ThreadPoolExecutor bulkexecutorPool = new ThreadPoolExecutor(Global.MIN_CONTENT_THREAD, Global.MAX_CONTENT_THREAD, 10, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(Global.THREAD_INTERNAL_QUEUE_SIZE, true));
	        bulkexecutorPool.setRejectedExecutionHandler(new RejectedWork());
	        
	        //added on 11-01-2017 starts
	        ThreadPoolExecutor responseBulkexecutorPool = new ThreadPoolExecutor(Global.MIN_RESPONSE_POOL_THREAD, Global.MAX_RESPONSE_POOL_THREAD, 10, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(Global.RESPONSE_POOL_THREAD_QUEUE_SIZE, true));
	        responseBulkexecutorPool.setRejectedExecutionHandler(new RejectedWork());
	        //added on 11-01-2017 ends
	        
	        threadCacheLoader = new Thread( new CacheLoader(Global.CACHE_RELOAD_TIME));	        
	 		threadCacheLoader.start();
	 		threadCacheLoader.join(2000); //
	 		
	 		threadCorpReader = new Thread( new ReadCorp(flwFailupdation));
	 		threadCorpReader.start();
	 		
	 		threadCorpQueueReader=new Thread( new CorpQueueReader(bulkexecutorPool) );
	 		threadCorpQueueReader.start();

	 		/*threadResponseQueueReader=new Thread( new ResponseQueueReader(flwFailupdation) );
	 		threadResponseQueueReader.start();*/ //commented on 11-01-2017 
	 		
	 		threadResponseQueueReader=new Thread( new ResponseQueueReader(responseBulkexecutorPool,flwFailupdation) );
	 		threadResponseQueueReader.start();
	 		
	 		 while(true)
				{

						logger.info("AtiveCount["+bulkexecutorPool.getActiveCount()+"] CompletedTask["+bulkexecutorPool.getCompletedTaskCount()+"] QueueSzie["+bulkexecutorPool.getQueue().size()+"]");

							if(!threadCorpQueueReader.isAlive())
							{
								logger.info("Reader Thread is Not Alive So going to restart thread...");								
								threadCorpQueueReader=new Thread( new CorpQueueReader(bulkexecutorPool) ); 
								threadCorpQueueReader.start();
							}
						
							/*if (!threadResponseQueueReader.isAlive())
							{
								logger.info("ResponseQueueReader Thread is Not Alive So going to restart thread...");							
								threadResponseQueueReader=new Thread( new ResponseQueueReader(flwFailupdation) );
								threadResponseQueueReader.start();
							}*/ //commented on 11-01-2017 
							
							if (!threadResponseQueueReader.isAlive())
							{
								logger.info("ResponseQueueReader Thread is Not Alive So going to restart thread...");							
								threadResponseQueueReader=new Thread( new ResponseQueueReader(responseBulkexecutorPool,flwFailupdation) );
								threadResponseQueueReader.start();
							}
												
							if (!threadCorpReader.isAlive())
							{
								logger.info("Reader Thread is Not Alive So going to restart thread...");								
								threadCorpReader = new Thread( new ReadCorp(flwFailupdation));
								threadCorpReader.start();
							}
	                                   
	                     if(!threadCacheLoader.isAlive())
							{								
								logger.info("CacheLoader Thread is Not Alive So going to restart thread...");
								threadCacheLoader = new Thread( new CacheLoader(Global.CACHE_RELOAD_TIME));
								threadCacheLoader.start();
							}			
					
							Thread.sleep(10000);
				}//while(true) ends
		}
		catch(Exception e)
		{
			logger.fatal("[CRBT-BU-00005] Exception in Thread while check Thread is Alive",e); 
			System.exit(1);
		}
		
	}//startThreads() ends
	
	
	/***
	 * 
	 * added by Tannu bajpai for procedure used
	 * 
	 */
	
	/*public String getProcedurePackage(){
		String proc_package="";
		try 
		{
		  if ("oracle".equalsIgnoreCase(Global.dbType) && (!(Global.procedure_package==null || "".equalsIgnoreCase(Global.procedure_package)) || ("NA".equalsIgnoreCase(Global.procedure_package))) )
		  {
		   proc_package=Global.procedure_package+".";
		  }
		  else if ("mysql".equalsIgnoreCase(Global.dbType)) 
		  {
		   proc_package=""; // In case of mysql there is no package name to call the procedure.
		  }
	    } 
	  catch (Exception e) 
		{
		
		}
		return proc_package;
	}
*/	

}//class ends
