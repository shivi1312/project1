package com.telemune.bulkupload.common;

import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.*; 
import java.lang.Short;
import java.lang.String;
import org.apache.log4j.*;

import com.telemune.bulkupload.beans.FetchMsrnBean;
public class FetchMsrn
{
	static String MSRN_FETCH_HOST = "127.0.0.1";
	static short MSRN_FETCH_PORT = 8777;

	final static byte SERVICE_NORMAL_MSRN = 1;
	final static byte SERVICE_INTERROGATE_MSRN = 15;
	final static byte SERVICE_FORWARDING_INFO = 2;
	final static byte SERVICE_ACTIVATE_SS = 3;
	final static byte SERVICE_DEACTIVATE_SS = 4;
	final static byte SERVICE_MSRN_NO_FORWARD = 5;
	final static byte SERVICE_SRI = 6;
	final static byte SERVICE_DUMMY_LOCUPD = 7;
	final static byte SERVICE_DEACTIVATE_IMSI = 12;
	final static byte SERVICE_ACTIVATE_IMSI = 13;
	final static byte SERVICE_RETRIEVE_IMSI = 9;
    
	private static final Logger logger=Logger.getLogger(FetchMsrn.class);

	public static byte fetchmsrn(FetchMsrnBean fetchMsrnBean)
	{
		byte retVal = -1;
		Socket socket = null;
		DataOutputStream writer = null;
		DataInputStream reader = null;
		MSRN_FETCH_HOST = Global.MSRN_FETCH_HOST;
		MSRN_FETCH_PORT  = Global.MSRN_FETCH_PORT;
		logger.info("in fetchmsrn() MSRN_FETCH_HOST= "+MSRN_FETCH_HOST+" MSRN_FETCH_PORT= "+MSRN_FETCH_PORT+" Msisdn:["+fetchMsrnBean.getMsisdn()+"]");
		//application tries to connect with HLR in configured no times if socket connection not established
		for(int i=1;i<=Global.HLR_CONNECTION_TRIES;i++)
		{
			try
			{
				socket = new Socket (MSRN_FETCH_HOST, MSRN_FETCH_PORT);
				socket.setSoTimeout(Global.SOCKET_TIME_OUT*1000);
				break;
			}
			catch (SocketException se)
			{
				logger.error("[CRBT-BU-90011] getting error in opening socket in fetchmsrn() of class FetchMsrn  ", se);
				if(i==Global.HLR_CONNECTION_TRIES)
				{
					return -1;
				}			
			}
			catch (Exception e)
			{
				logger.error("[CRBT-BU-00045] getting error while opening socket in fetchmsrn() of class FetchMsrn ", e);
				if(i==Global.HLR_CONNECTION_TRIES)
				{
					return -1;
				}	
			}			
		}
		/*try
		{
			socket = new Socket (MSRN_FETCH_HOST, MSRN_FETCH_PORT);
			socket.setSoTimeout(Global.SOCKET_TIME_OUT*1000);
		}
		catch (SocketException se)
		{
			logger.error("[CRBT-BU-90011] getting error in opening socket in fetchmsrn() of class FetchMsrn  ", se);
			return -1;
		}
		catch (Exception e)
		{
			logger.error("[CRBT-BU-00045] getting error while opening socket in fetchmsrn() of class FetchMsrn ", e);
			return -1;
		}*/
		logger.debug("Socket Connection established");
		String requestBuffer = "";
		int requestId = 1;

		requestBuffer = requestBuffer + requestId + "\n" + fetchMsrnBean.getService();	
		String msrn = "";
		String imsi = "";
		String forwardNumber = "";
		switch(fetchMsrnBean.getService())
		{
			case SERVICE_NORMAL_MSRN:    // request for normal msrn query...
			case SERVICE_INTERROGATE_MSRN:    // request for normal msrn query...
			case SERVICE_ACTIVATE_SS:		//	request for activate SS
			case SERVICE_DEACTIVATE_SS:		// request for deativate SS
			case SERVICE_RETRIEVE_IMSI:		// request for deativate SS
			case SERVICE_MSRN_NO_FORWARD:		//	request for msrn without forwarded info
			case SERVICE_SRI:		//	request for SRI..( to check prepaid)
				if (fetchMsrnBean.getMsisdn() == null)
				{
					//msisdn = ""; 
					fetchMsrnBean.setMsisdn("");
				}
				requestBuffer = requestBuffer + "\n" + fetchMsrnBean.getMsisdn();
				break;
			case SERVICE_FORWARDING_INFO:		//	request for update location...
			case SERVICE_DEACTIVATE_IMSI:
			case SERVICE_ACTIVATE_IMSI:
				if (fetchMsrnBean.getMsisdn() == null)
				{
					fetchMsrnBean.setMsisdn("");
				}
				if (fetchMsrnBean.getVlr() == null)
				{
					fetchMsrnBean.setVlr("") ;
				}
				if (imsi == null)
				{
					imsi = "";
				}
				requestBuffer = requestBuffer + "\n" + fetchMsrnBean.getMsisdn() + "\n" + fetchMsrnBean.getVlr() + "\n" + imsi;
				break;
			default:
				logger.info("Msisdn:["+fetchMsrnBean.getMsisdn()+"] Unknown Service Request\n");
		}

		int length = requestBuffer.length(); 

		
		try
		{
			reader = new DataInputStream(socket.getInputStream());
			writer = new DataOutputStream(socket.getOutputStream());
		}
		catch (IOException ioe)
		{
			logger.error("[CRBT-BU-90002] getting failed  to get input/output stream in fetchmsrn() of class FetchMsrn ", ioe);
			return -1;
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00046] getting failed  to get input/output stream in fetchmsrn() of class FetchMsrn ", e);
			return -1;
		}
		logger.debug(" Msisdn:["+fetchMsrnBean.getMsisdn()+"] input/output stream established");

		try
		{
			logger.debug("Msisdn:["+fetchMsrnBean.getMsisdn()+"] writing to output stream");
			writer.writeInt (length);
			writer.write(requestBuffer.getBytes(), 0, requestBuffer.length());

			// This can be made a different method.
			//
			logger.debug("Msisdn:["+fetchMsrnBean.getMsisdn()+"] reading stream");
			int responseLen = reader.readInt();
			byte responseBuf[] = new byte[responseLen+1];
			reader.read(responseBuf, 0, responseLen);

			responseBuf[responseLen] = '\0';

			//socket.close(); //commented by Ashish on 11-11-2016 
			logger.debug("Msisdn:["+fetchMsrnBean.getMsisdn()+"] socket closed");

			String response = new String (responseBuf);
			logger.debug("Msisdn:["+fetchMsrnBean.getMsisdn()+"] response:["+response+"]");
			
			StringTokenizer st = new StringTokenizer(response);
			//String []tokens = response.split("\\n");
			String []tokens = new String[st.countTokens()];
			int ctr = 0;
			while(st.hasMoreTokens())
			{
				tokens[ctr]= st.nextToken();
				
				ctr++;
			}
			logger.info("Msisdn:["+fetchMsrnBean.getMsisdn()+"] Tokens Length [" + tokens.length + "]" );
			msrn = tokens[1];
			if (msrn.equals("NULL"))
			{
				msrn = "";
			}
			//msrnBuf = msrnBuf.append(msrn);
			fetchMsrnBean.setVlr(tokens[2]);
			if (fetchMsrnBean.getVlr().equals("NULL"))
			{
				fetchMsrnBean.setVlr("");
			}
			imsi = tokens[3];

			if (imsi.equals("NULL"))
			{
				imsi = "";
			}
			//imsiBuf.append(imsi); //should be remove
			fetchMsrnBean.setImsiBuf(fetchMsrnBean.getImsiBuf().append(imsi));

			//scfAddress = tokens[4]; //should be remove
			fetchMsrnBean.setScfAddress(tokens[4]);
			if (fetchMsrnBean.getScfAddress().equals("NULL"))
			{
				//scfAddress = "";
				fetchMsrnBean.setScfAddress("");
			}
			try
			{
				//serviceKey = new Integer(tokens[5]);
				fetchMsrnBean.setServiceKey(new Integer(tokens[5]));
			}
			catch(NumberFormatException nfe)
			{
				//serviceKey = new Integer(0);
				fetchMsrnBean.setServiceKey(new Integer(0));
				//nfe.printStackTrace();
				logger.error("[CRBT-BU-90004] getting error while parsing serviceKey token into Integer in fetchmsrn() of class FetchMsrn ", nfe);
			}
			if (tokens[6].equals("N"))
			{
				//isprepaid = new Boolean(false);
				fetchMsrnBean.setPrepaid(new Boolean(false));
				retVal=2;
			}
			else
			{
				//isprepaid = new Boolean(true);
				fetchMsrnBean.setPrepaid(new Boolean(true));
				retVal=1;
			}
			//logger.debug("6.Is  prepaid value  [ "+isprepaid+" ]  Token [6]");
			logger.debug("6. Msisdn:["+fetchMsrnBean.getMsisdn()+"] Is  prepaid value  [ "+fetchMsrnBean.isPrepaid()+" ]  Token [6]");
			if (tokens[7].equals("N"))
			{
				//isroaming = new Boolean(false);
				fetchMsrnBean.setRoaming(new Boolean(false));				
			}
			else
			{
			     //isroaming = new Boolean(true);
			     fetchMsrnBean.setRoaming(new Boolean(true));
			}
				//logger.debug("7.Is roaming is [ "+isroaming+" ]");
			logger.debug("7. Msisdn:["+fetchMsrnBean.getMsisdn()+"]  Is roaming is [ "+fetchMsrnBean.isRoaming()+" ]");  
			if (tokens[8].equals("NULL"))
			{
		         //error = new Integer (0);
				fetchMsrnBean.setMsrnError(new Integer (0));
			}
			else
			{
				try
				{
					//error = new Integer(tokens[8]);
					fetchMsrnBean.setMsrnError(new Integer (tokens[8]));
				}
				catch(NumberFormatException nfe)
				{
					//error = new Integer(-1);
					fetchMsrnBean.setMsrnError(new Integer (-1));
					//nfe.printStackTrace();
					logger.error("[CRBT-BU-90004] getting error while parsing error token into Integer in fetchmsrn() of class FetchMsrn ", nfe);
				}
		    }
			//logger.debug("8.Error Value [ "+error+" ]");
			logger.debug("8.Error Value [ "+fetchMsrnBean.getMsrnError()+" ]");

	//busyNumber = tokens[9];
	fetchMsrnBean.setBusyNumber(tokens[9]);
	if (fetchMsrnBean.getBusyNumber().equals("NULL"))
	{
		//busyNumber = "";
		fetchMsrnBean.setBusyNumber("");
	}

	//logger.debug("9.Busy Number [ "+busyNumber+" ]");
	logger.debug("9. Msisdn:["+fetchMsrnBean.getMsisdn()+"] Busy Number [ "+fetchMsrnBean.getBusyNumber()+" ]");

	//noReplyNumber = tokens[10];
	fetchMsrnBean.setNoReplyNumber(tokens[10]);
	if (fetchMsrnBean.getNoReplyNumber().equals("NULL"))
	{
		//noReplyNumber = "";
		fetchMsrnBean.setNoReplyNumber("");
	}

	//logger.debug("10.No Reply  Number [ "+noReplyNumber+" ]");
	logger.debug("10. Msisdn:["+fetchMsrnBean.getMsisdn()+"] No Reply  Number [ "+fetchMsrnBean.getNoReplyNumber()+" ]");

	//unreachableNumber = tokens[11];
	fetchMsrnBean.setUnreachableNumber(tokens[11]);
	if (fetchMsrnBean.getUnreachableNumber().equals("NULL"))
	{
		//unreachableNumber = "";
		fetchMsrnBean.setUnreachableNumber("");
	}

	//logger.debug("11.Un Reachable  Number [ "+unreachableNumber+" ]");
	logger.debug("11. Msisdn:["+fetchMsrnBean.getMsisdn()+"] Un Reachable  Number [ "+fetchMsrnBean.getUnreachableNumber()+" ]");
       //    if (tokens[11].equals("N"))

	if (tokens[12].charAt(0)=='N')
	{
		//cfuActive = new Boolean(false);		
		fetchMsrnBean.setCfuActive(new Boolean(false));
		//cfuActiveStr=cfuActiveStr.append("false");
	}
	else
	{
		//cfuActive = new Boolean(true);
		fetchMsrnBean.setCfuActive(new Boolean(true));
		//	cfuActiveStr = cfuActiveStr.append("true");
	}


	//logger.debug("12.CFU Active [ "+cfuActive+" ]");
	logger.debug("12. Msisdn:["+fetchMsrnBean.getMsisdn()+"] CFU Active [ "+fetchMsrnBean.isCfuActive()+" ]");

	forwardNumber = tokens[13];
	if (forwardNumber.equals("NULL"))
	{
		forwardNumber = "";
	}	
	logger.debug("13. Msisdn:["+fetchMsrnBean.getMsisdn()+"] Forword Number [ "+fetchMsrnBean.isCfuActive()+" ]");
	//logger.debug("Return Value from HLR is [ "+error.intValue()+" ] ");
	logger.debug("Return Value from HLR is [ "+fetchMsrnBean.getMsrnError().intValue()+" ] Msisdn:["+fetchMsrnBean.getMsisdn()+"] ");
	// Added by rajendra return 1 for PREPAID 2 for POSTPAID
	if (fetchMsrnBean.getMsrnError().intValue() != 0)
	{
		logger.debug(fetchMsrnBean.getMsisdn()+"#Error Return From HLR Return Value is [ "+fetchMsrnBean.getMsrnError().intValue()+" ]");
		retVal= -1; // Error Return From HLR
	}
	else
	{
		logger.info(fetchMsrnBean.getMsisdn()+"#Success Return from HLR Return Value is [ "+fetchMsrnBean.getMsrnError().intValue()+" ] Token 6 Value is [ "+tokens[6]+" ]");

		if (tokens[6].equalsIgnoreCase(("N")))
		{
			logger.info("Msisdn:["+fetchMsrnBean.getMsisdn()+"] # is Post Paid Number");
			retVal= 2;  // Postpaid Number
			//isprepaid = new Boolean(false);
		}
		else
		{
			logger.info("Msisdn:["+fetchMsrnBean.getMsisdn()+"]# is Prepaid Number");
			retVal=1;  // Prepaid Number
			// isprepaid = new Boolean(true);
		}
	}
          logger.info("Msisdn:["+fetchMsrnBean.getMsisdn()+"] exiting fetchmsrn:with  HLR Return Value is:["+fetchMsrnBean.getMsrnError().intValue()+"]  retValue:["+retVal+"] retValue 1 for Prepaid and 2 Postpaid");
           //logger.info("exiting fetchmsrn:with  return value= "+retVal+" isPrepaid["+isprepaid+"]");
          st=null;
          response=null;
      }
      catch(SocketException se)
      {
               logger.error("[CRBT-BU-90011] getting error in closing socket in fetchmsrn() of class FetchMsrn ", se);
      }
      catch(Exception e)
      {
    	  //e.printStackTrace();
		logger.error("[CRBT-BU-00047] getting error in fetchmsrn() of class FetchMsrn ", e);
      }
	finally
	{
		try
		{
			socket.close();	
			reader=null;
			writer=null;
			requestBuffer=null;
			msrn=null;
			imsi=null;
			forwardNumber=null;
			socket=null;
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00048] Exception while closing the socket connection in fetchmsrn() of class FetchMsrn ",e);
		}
	}	
		return retVal;
   } //fetchmsrn(fetchMsrnBean)
}
