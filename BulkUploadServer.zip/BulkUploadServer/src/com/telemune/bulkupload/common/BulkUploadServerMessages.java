package com.telemune.bulkupload.common;

public interface BulkUploadServerMessages 
{
	public String ALREADY_SUBSCRIBED = "Already subscribed";
	public String INVALID_RANGE = "Msisdn Not in specified range";
	public String LICENSE_EXPIRE = "Corporate License key Expire";
	public String CALL_FORWARDING_ERROR = "Call forwarding not done";
	public String SUB_TYPE_ERROR = "Msisdn Subscriber Type not found";
	public String CHARGING_ERROR = "Msisdn could not be Charged may be Insufficent Balance";
	public String SEND_SMS_ERROR = "Subscribed Successfully but Error while sending message";
	public String STATUS_INACTIVE = "User Status Not Active";
	public String MSISDN_INVALID_RANGE = "Msisdn Not in Range";
	public String CHARGING_DONE_NOT_SUBSCRIBED = "Charging done but Msisdn not subscribed";
	public String MSISDN_NOT_WHITELISTED = "Msisdn must be whitelisted";
	public String TOTAL_CAPACITY_FULL = "Total Capacity Full";
	public String UNKNOWN_ERROR = "Error Occured Please Try Later";
	public String SUCCESSFULLY_SUBSCRIBED = "Successfully Subscribed";
	public String NOT_SUBSCRIBED = "Msisdn not a subscriber";
	public String UNSUB_SUCCESS_LOG_ERROR ="unsubscribed successfully but log not maintained";
	public String UNSUB_SUCCESS = "unsubscribed successfully";
	public String UNSUB_SUCCES_LOG_HLR_ERROR = "unsubscribed successfully but log not maintained and CFU couldnot be deactivated";
	public String UNSUB_SUCCESS_HLR_ERROR="unsubscribed successfully but CFU couldnot be deactivated";
	public String DB_ERROR="DB Error occured please try later";
	
	public String CHARGING_SOCKET_ERROR = "Connection to Charging is not established";
	public String CHARGING_TIMEOUT_ERROR="Socket Timeout to connect to Charging";
	public String CHARGING_READ_TIMEOUT="Socket Input output stream breaks before request completes";
	
}
