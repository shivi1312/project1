package com.telemune.bulkupload.common;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;

import org.apache.log4j.Logger;

import com.telemune.bulkupload.beans.ListDataBean;
import com.telemune.bulkupload.db.ConnPool;





/**
 * 
 * @author Ashish
 * This class contain static parameter
 *
 */

public class Global {

	private static Logger logger=Logger.getLogger(Global.class);
	public static  ConnPool conPool=null;
	public static  ArrayBlockingQueue<ListDataBean> readerQueue;
	public static  ArrayBlockingQueue<ListDataBean> responseQueue;
	public static  int MAX_CONTENT_THREAD=40;
	public static  int MIN_CONTENT_THREAD=10;
	public static  int THREAD_INTERNAL_QUEUE_SIZE=500;
   	
    public static int ROWNUM;
    public static int LIMIT;
    public static int TOTAL_REQ_COUNT=-1; 
	
	public static int LICENSE_KEY;
	public static String SSF_SERVER_HOST;
	public static short SSF_SERVER_PORT;
	
	public static String MSRN_FETCH_HOST; 
	public static short MSRN_FETCH_PORT;
	public static byte SOURCE_TYPE; 
	public static boolean BIGTLV_ENABLE;
	public static boolean SEND_TO_HLR; 
	public static boolean TLVBASE_ENABLE;	
	public static String MESSAGE;
	public static boolean DOACTDEACT;
	public static boolean CHARGING_SCOPE;  
	public static byte DEFAULT_LANGUAGE;
	
	public static Hashtable appConfigParams;
	public static Hashtable<Integer, String> smstemplates ;
	
	public static byte SOCKET_TIME_OUT; 
	public static short CON_TIME_OUT;
	public static boolean UNSUB_HLR_CONFIG; //Added on 15-12-2016 to make HLR request configurale for UNSUB request //boolean
	
	public  static int CACHE_RELOAD_TIME;
	public static byte READER_QUEUE_SLEEP_TIME;
	public static byte RESPONSE_QUEUE_SLEEP_TIME;
	public static String APP_CONFIG_PARAMS;
	public static short READ_CORP_SLEEP_TIME;

	public static short HLR_TEST_CASE; //FOR testing	
	public static Hashtable corpIdScope; //For scope in CRBT_CORP_DETAIL
	public static Hashtable<String, String> corpRbtCode; //For rbt_code in CRBT_CORP_DETAIL //added by Avishkar on 08.01.2019
	
	public static  int MAX_RESPONSE_POOL_THREAD=5;
	public static  int MIN_RESPONSE_POOL_THREAD=1;
	public static  int RESPONSE_POOL_THREAD_QUEUE_SIZE=500;
	public static  short HLR_CONNECTION_TRIES=3;
	
	//added on 28-Nov-2017 starts
	public static boolean isLicenseFeatureEnable;
	
	//added on 28-Nov-2017 ends

	public static int PROC_PACKAGE = 0; //added by Ashish on 12-03-2018 
	
	public static boolean IS_SET_DEFAULT_RBT; // added by Avishkar on 07.01.2019 
	/*public static boolean*/
	public static int DBTYPE=1;//added by Tannu Bajpai
	public static String procedure_package=null;//added by Tannu Bajpai
	public  static String dbType=null; //added by Tannu Bajpai
	public static String getAppConfigParam(String paramName)
	{
		String retVal = "";		
		try
		{
			retVal = (String) Global.appConfigParams.get(paramName.trim());
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] null value found in getAppConfigParam() of class Global ",npe);
			retVal=null;
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00006] Exception in getAppConfigParam() of class Global ",e);
			retVal=null;
		}
		
		return retVal;
	}//getAppConfigParam() ends
	
	public static String getSmsTemplates(String paramName)
	{
		String retVal = "";		
		try
		{
			retVal = (String) Global.smstemplates.get(Integer.parseInt(paramName.trim()));
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] null value found in getSmsTemplates() of class Global ",npe);
			retVal=null;
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00007] Exception in getSmsTemplates() of class Global ",e);
			retVal=null;
		}
		
		return retVal;
	}// getSmsTemplates() ends

	
	
	
	
	
 }
