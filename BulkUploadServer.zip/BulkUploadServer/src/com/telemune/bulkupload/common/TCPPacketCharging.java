package com.telemune.bulkupload.common;


import java.io.*;
import java.net.*;
import TlvLib.*;
import commonutil.*;
import org.apache.log4j.*;
import org.w3c.dom.css.Counter;

import com.telemune.bulkupload.beans.RequestResponseBean;
public class TCPPacketCharging
{
		private static final Logger logger=Logger.getLogger(TCPPacketCharging.class);
        final static String SSF_SERVER_HOST = Global.SSF_SERVER_HOST;//"stp"; //TODO, take from configuration
        final static int SSF_SERVER_PORT = Global.SSF_SERVER_PORT;//10101;
        public static final int MSISDN_TAG=1;
        public static final int REQTYPE_TAG=12;

        public static final int ACTION_TAG=2;
		public static final int TARIFFID_TAG=3;
		
		public static final int FMSISDN_TAG=5;
		public static final int RBTCODE_TAG=4;
		public static final int CORPID_TAG=13;
		public static final int INTERFACE_TAG=6;
		public static final int RESPONSE_TAG=7;
		public static final int SUB_TYPE=8;
		public static final int BALANCE_TAG=11;	
		public static final int PACKID_TAG=14;
		
		DataOutputStream stream_send_data;
        private int resp;
		public void TCPPacketCharging()
		{
			resp=0;
		}
		Socket socket = null;

		public int subscribeCharging(RequestResponseBean req,String name)
        {				
				String fmsisdn = req.getfMsisdn();
                String msisdn = req.getMsisdn();         
                //int reqType = req.getRequestType();
                //char subType = req.getSubType();
                short action = req.getAction();
                int rbtcode= req.getRbtcode();              
                String tariffID = req.getStarrifId();                
                char interfaceType = req.getInterfaceType();
                
                logger.info("subscribeCharging() msisdn:["+msisdn+"] fmsisdn:["+fmsisdn+"] action:["+action+"] interfaceType:["+interfaceType+"] Name["+name+"]");
                DataOutputStream writer = null;
                DataInputStream reader = null;
                String packetData="";
                //StringBuffer chStatus=null;
                try
                {
                        logger.debug("opening socket to..="+SSF_SERVER_HOST+" Port="+SSF_SERVER_PORT);
                        socket = new Socket (SSF_SERVER_HOST, SSF_SERVER_PORT);
                        //              socket.setSoTimeout(100); //100ms
                        socket.setSoTimeout(Global.SOCKET_TIME_OUT*1000); 
                        
                }
                catch (SocketException se)
                {
                	logger.error("[CRBT-BU-90011] getting error in opening socket in subscribeCharging(RequestResponseBean, String) of class TCPPacketCharging  ", se);
                	//return -1;
                	return -101; //socket connection not established 
                }
                catch (Exception e)
                {
                	logger.error("[CRBT-BU-00049] getting error in opening socket in subscribeCharging(RequestResponseBean, String) of class TCPPacketCharging ", e);
                	//return -1;
                	return -100; //UNKNOWN_ERROR
                }

                try
                {
                        logger.debug("opening read/write stream");
                        reader = new DataInputStream(socket.getInputStream());
                        writer = new DataOutputStream(socket.getOutputStream());
                }
		

                catch (IOException ioe)
                {
                	logger.error("[CRBT-BU-90002] getting failed  to get input/output stream in subscribeCharging(RequestResponseBean, String) of class TCPPacketCharging ", ioe);
                	//return -1; 
                	return -97;
                }

                try
                {
                        //      socket.setSoTimeout(100); //100ms
                        switch(action)
                        {
                                case 1: //Subscription 
                                        packetData="ACT:"+action+";TAR:"+tariffID+";INT:"+interfaceType+";FMSISDN:"+fmsisdn;
                                        break;
                                case 2: //Subscription renew
                                        break;
                                case 3: //RBT purchase
                                        packetData="ACT:"+action+";TAR:"+tariffID+";RBT:"+rbtcode+";INT:"+interfaceType;
                                        break;
                                case 4: //RBT Gift
                                        packetData="ACT:"+action+";TAR:"+tariffID+";RBT:"+rbtcode+";FMSISDN:"+fmsisdn+";INT:"+interfaceType;
                                        break;
                                default:
                                        break;
                        }
                        logger.info("msisdn:["+msisdn+"] fmsisdn:["+fmsisdn+"]  packet:["+packetData+"]");
                        TCPRequest request = new TCPRequest();
                //      TCPRequest response= new TCPRequest();
                        ByteArrayOutputStream buf = new ByteArrayOutputStream();
                        ByteArrayInputStream inbuf = null;
                        request.setMsisdn(msisdn);
                        //request.setTariffID(tariffID);
                        request.setData(packetData);

                        request.encode(buf);
                        int requestLen = buf.size();
                        logger.debug("request:packetData info buf size="+requestLen+" .... sending" );
                        byte len[]=new byte[4];
                        len[3] = (byte)(requestLen & 0xff);
                        len[2] = (byte)((requestLen >> 8) & 0xff);
                        len[1] = (byte)((requestLen >> 16) & 0xff);
                        len[0] = (byte)((requestLen >> 24) & 0xff);
                        writer.write(len,0,4);
                        writer.write(buf.toByteArray(), 0, buf.toByteArray().length);

                        //logger.debug("reading Info from SSFResponse");
                        logger.debug("response: reading info ....");
                        int responseLen = reader.readInt();
                        logger.info("msisdn:["+msisdn+"] fmsisdn:["+fmsisdn+"] recieved response size:["+responseLen+"]");
                        byte responseBuf[] = new byte[responseLen];
                        reader.read(responseBuf, 0, responseLen);

                        inbuf = new ByteArrayInputStream(responseBuf);
                        request.decode(inbuf);
                        resp = request.getResponseId();
                        logger.info("msisdn:["+msisdn+"] fmsisdn:["+fmsisdn+"] TCPPacketCharging: response:["+resp+"]");
                        //socket.close(); //commented by Ashish on 11-11-2016
                        //request=null;
                        return resp;
                }
		

                catch(InterruptedIOException ioEx)
                {                        
                        //ioEx.printStackTrace();
                        logger.error("[CRBT-BU-90015] getting error while Socket TimeOut occurred in subscribeCharging(RequestResponseBean, String) of class TCPPacketCharging ", ioEx);
                        return -5;
                }
                catch (IOException ioe)
                {
                        //ioe.printStackTrace();
                        logger.error("[CRBT-BU-90002] getting Failed to read / write in subscribeCharging(RequestResponseBean, String) of class TCPPacketCharging ", ioe);
                        return -6;
                }
                //added by Ashish on 11-11-2016 starts
                finally
                {
                	try 
                	{
						if(socket!=null)
						{
	                		socket.close();
							socket=null; 
						}
						//reader=null;
						//writer=null;
						//packetData=null;
						//msisdn=null;
						//fmsisdn=null;
						//tariffID=null;
					} 
                	catch (Exception e)
                	{
						logger.error("[CRBT-BU-00050] Exception while closing socket connection in subscribeCharging(RequestResponseBean, String) of class TCPPacketCharging ",e);
						//e.printStackTrace();
					}
                }
                //added by Ashish on 11-11-2016 ends
        }//subscribeCharging(RequestResponseBean req,String name)

        public int subscribeCharging(RequestResponseBean req)	
        {
        	
        	int response=0;
        	try
            {			
                        logger.debug("opening socket to..="+SSF_SERVER_HOST+" Port="+SSF_SERVER_PORT+" Using BigTlv");                       
                        logger.info("recieved bean: ["+req.getRequestType()+"]["+req.getSubType()+"] MSISDN:["+req.getMsisdn()+"] FMSISDN:["+req.getfMsisdn()+"] ["+req.getAction()+"]["+req.getStarrifId()+"]["+req.getRbtcode()+"]["+req.getInterfaceType()+"]");
                        socket = new Socket (SSF_SERVER_HOST,SSF_SERVER_PORT);//to be un-commented later                        
                        commonutil.TLVAppInterface send_request=new commonutil.TLVAppInterface();
                        ByteArrayOutputStream send_buf=new ByteArrayOutputStream();
                                send_request.setData(REQTYPE_TAG,req.getRequestType());
                                send_request.setData(FMSISDN_TAG,req.getfMsisdn());
                                send_request.setData(SUB_TYPE,req.getSubType());
                                send_request.setData(MSISDN_TAG,req.getMsisdn());
                                send_request.setData(ACTION_TAG,req.getAction());
                               	send_request.setData(TARIFFID_TAG,req.getStarrifId());
                                send_request.setData(RBTCODE_TAG,req.getRbtcode());
                                send_request.setData(INTERFACE_TAG,String.valueOf(req.getInterfaceType()));
                                send_request.setData(PACKID_TAG,"-1");
                                send_request.encode(send_buf);	                       
                        logger.info("MSISDN:["+req.getMsisdn()+"] FMSISDN:["+req.getfMsisdn()+"] packet Socket is==="+socket.toString());
                        int send_requestLen = send_buf.size();
                        socket.setSoTimeout(30000);
                        stream_send_data = new DataOutputStream(socket.getOutputStream());
                        logger.info("MSISDN:["+req.getMsisdn()+"] FMSISDN:["+req.getfMsisdn()+"] writing Info buf size="+send_requestLen);
                        byte[] len=new byte[4];
                        len[3]=(byte)(send_requestLen );
                        len[2]=(byte)((send_requestLen >> 8) );
                        len[1]=(byte)((send_requestLen >> 16));
                        len[0]=(byte)((send_requestLen >> 24));
		
                        stream_send_data.write(len,0, 4);
                        stream_send_data.write(send_buf.toByteArray(), 0, send_buf.toByteArray().length);
                        logger.info("MSISDN:["+req.getMsisdn()+"] FMSISDN:["+req.getfMsisdn()+"] Sending data length: "+len.length);
			
                        commonutil.TLVAppInterface rec_data = new commonutil.TLVAppInterface();
                        DataInputStream dis=new DataInputStream(socket.getInputStream());
                        byte dataBuf1[] = new byte[4];
                        int dataLen =0;
                        int test=0;
                        ByteArrayInputStream inbuf=null;
                                if(dis.read(dataBuf1,0,4)==-1)
                                {
                                 logger.debug("reader.read == -1 ...");
                                 logger.debug("  .............................");
                                }
                                else
                                {
                                  dataLen = dataLen | (dataBuf1[0] << 24);
                                  dataLen = dataLen  | (dataBuf1[1] << 16);
                                  dataLen = dataLen | (dataBuf1[2] << 8);
                                  test=(0x000000ff & dataBuf1[3]);
                                  dataLen = dataLen | test;
                                  logger.info("MSISDN:["+req.getMsisdn()+"] FMSISDN:["+req.getfMsisdn()+"]length:"+dataLen);
                                  byte dataBuf[] = new byte[dataLen];
					
                                  logger.info("Reading Data");
                                        dis.read(dataBuf, 0, dataLen);

                                        inbuf = new ByteArrayInputStream(dataBuf);
                                        rec_data.decode(inbuf,dataLen);
                                        //logger.info("MSISDN:["+req.getMsisdn()+"] FMSISDN:["+req.getfMsisdn()+"] RESPONSE_TAG:["+rec_data.getData(RESPONSE_TAG)+"] "); //commented by Ashish on 1-DEC-2017
                                        //logger.info("MSISDN:["+req.getMsisdn()+"] FMSISDN:["+req.getfMsisdn()+"] SUB_TYPE:"+rec_data.getData(SUB_TYPE));  //commented by Ashish on 1-DEC-2017
                                       response=Integer.parseInt(rec_data.getData(RESPONSE_TAG));
                                       //added by Ashish on 1-Dec-2017 starts
                				       int chgCode = Integer.parseInt(rec_data.getData(TARIFFID_TAG)); 
                				       req.setTarrifId(chgCode);
                				       //added by Ashish on 1-Dec-2017 ends
                                       //logger.info("MSISDN:["+req.getMsisdn()+"] FMSISDN:["+req.getfMsisdn()+"] chgCode:["+chgCode+"] Response to Send Back: "+response);//commented by Ashish on 1-DEC-2017
                                       logger.info("MSISDN:["+req.getMsisdn()+"] FMSISDN:["+req.getfMsisdn()+"] RESPONSE_TAG:["+response+"] chgCode:["+chgCode+"] SUB_TYPE:["+rec_data.getData(SUB_TYPE)+"]"); //added by Ashish on 1-DEC-2017
                                    
                                 }
                                
                           
                                
                          return response;

            }
        	catch (SocketException se)
        	{          
        		logger.error("[CRBT-BU-90011] getting error in opening socket in subscribeCharging method(RequestResponseBean) of class TCPPacketCharging  ", se);
        		//return -1;
        		return -101; //socket connection not established        		
        	}
        	catch(InterruptedIOException ioEx)
        	{
        		logger.error("[CRBT-BU-90015] getting error while Socket TimeOut occurred in subscribeCharging method(RequestResponseBean) of class TCPPacketCharging  ", ioEx);
        		//return -1;
        		return -98; //socket time out error
        	}

        	catch(IOException ioe)
        	{
        		logger.error("[CRBT-BU-90002] getting failed  to get input/output stream in subscribeCharging method(RequestResponseBean) of class TCPPacketCharging  ", ioe);
        		//return -1;
        		return -97; //input/output stream break error before request complete
        	}
        	catch(Exception exp)
        	{        		
        		//exp.printStackTrace();
        		logger.error("[CRBT-BU-00051] getting failed  to get input/output stream in subscribeCharging method(RequestResponseBean) of class TCPPacketCharging  ", exp);
        		//return -1;
        		return -100;//UNKNOWN_ERROR
        	}
        	finally
        	{
        		try{
        			if(socket!=null)
        			{
        				socket.close();
            			socket=null;
        			}
        			
        		}
        		catch(Exception exp)
        		{
        			//exp.printStackTrace();
        			logger.error("[CRBT-BU-00052] getting error while closing socket connection in subscribeCharging method(RequestResponseBean) of class TCPPacketCharging  ", exp);
        		}
        	}

        }//subscribeCharging() 


      public int subscribeCharging(RequestResponseBean req,int param)   //by  harjinder simple TlvLib used..
      {
        int response=0;
        try
            {           
                        logger.debug("opening socket to..="+SSF_SERVER_HOST+" Port="+SSF_SERVER_PORT+" SimpeTlv param="+param);
                        socket = new Socket (SSF_SERVER_HOST,SSF_SERVER_PORT);//to be un-commented later                        
                        logger.info("recieved bean: ["+req.getRequestType()+"]["+req.getSubType()+"] MSISDN:["+req.getMsisdn()+"]FMSISDN:["+req.getfMsisdn()+"]["+req.getAction()+"]["+req.getStarrifId()+"]["+req.getRbtcode()+"]["+req.getInterfaceType()+"]");
                        TlvLib.TLVAppInterface send_request=new TlvLib.TLVAppInterface();
                        ByteArrayOutputStream send_buf=new ByteArrayOutputStream();
                                send_request.setData(REQTYPE_TAG,req.getRequestType());
                                send_request.setData(FMSISDN_TAG,req.getfMsisdn());
                                send_request.setData(SUB_TYPE,req.getSubType());
                                send_request.setData(MSISDN_TAG,req.getMsisdn());
                                send_request.setData(ACTION_TAG,req.getAction());
                                send_request.setData(TARIFFID_TAG,req.getStarrifId());
                                send_request.setData(RBTCODE_TAG,req.getRbtcode());//must be -1
                                send_request.setData(INTERFACE_TAG,String.valueOf(req.getInterfaceType()));
                                send_request.setData(PACKID_TAG,"-1");

                                send_request.encode(send_buf);
                        //logger.info("recieved bean: ["+req.getRequest_type()+"]["+req.getSub_Type()+"]["+req.getMsisdn()+"]["+req.getAction()+"]["+req.getStarrif_id()+"]["+req.getRbtcode()+"]["+req.getInterface_type()+"]");
                        logger.info("MSISDN:["+req.getMsisdn()+"]FMSISDN:["+req.getfMsisdn()+"] packet Socket is==="+socket.toString());
                        int send_requestLen = send_buf.size();
                        socket.setSoTimeout(30000);
                        stream_send_data = new DataOutputStream(socket.getOutputStream());
                        logger.info("MSISDN:["+req.getMsisdn()+"] FMSISDN:["+req.getfMsisdn()+"] writing Info buf size="+send_requestLen);
                        byte[] len=new byte[4];
                        len[3]=(byte)(send_requestLen );
                        len[2]=(byte)((send_requestLen >> 8) );
                        len[1]=(byte)((send_requestLen >> 16));
                        len[0]=(byte)((send_requestLen >> 24));

                        stream_send_data.write(len,0, 4);
                        stream_send_data.write(send_buf.toByteArray(), 0, send_buf.toByteArray().length);
                        logger.info("MSISDN:["+req.getMsisdn()+"]FMSISDN:["+req.getfMsisdn()+"] Sending data length: "+len.length);

                        TlvLib.TLVAppInterface rec_data = new TlvLib.TLVAppInterface();
                        DataInputStream dis=new DataInputStream(socket.getInputStream());
                        byte dataBuf1[] = new byte[4];
                        int dataLen =0;
                        int test=0;
                        ByteArrayInputStream inbuf=null;
                          if(dis.read(dataBuf1,0,4)==-1)
                                {
                                 logger.debug("MSISDN:["+req.getMsisdn()+"]FMSISDN:["+req.getfMsisdn()+"] reader.read == -1 ...");
                                 logger.debug("Msisdn:["+req.getMsisdn()+"]FMSISDN:["+req.getfMsisdn()+"]  .............................");
                                }
                                else
                                {
                                  dataLen = dataLen | (dataBuf1[0] << 24);
                                  dataLen = dataLen  | (dataBuf1[1] << 16);
                                  dataLen = dataLen | (dataBuf1[2] << 8);
                                  test=(0x000000ff & dataBuf1[3]);
                                  dataLen = dataLen | test;
                                logger.info("Msisdn["+req.getMsisdn()+"]FMsisdn["+req.getfMsisdn()+"] length:"+dataLen);
                                  byte dataBuf[] = new byte[dataLen];

                                        logger.info("Msisdn["+req.getMsisdn()+"]FMsisdn["+req.getfMsisdn()+"] Reading Data");
                                        dis.read(dataBuf, 0, dataLen);

                                        inbuf = new ByteArrayInputStream(dataBuf);
                                        rec_data.decode(inbuf,dataLen);
                                        //logger.info("Msisdn["+req.getMsisdn()+"]FMsisdn["+req.getfMsisdn()+"]  RESPONSE_TAG:"+rec_data.getData(RESPONSE_TAG)); //commented by Ashish on 1-DEC-2017
                                        //logger.info("Msisdn["+req.getMsisdn()+"]FMsisdn["+req.getfMsisdn()+"] SUB_TYPE:"+rec_data.getData(SUB_TYPE));//commented by Ashish on 1-DEC-2017
                                       response=Integer.parseInt(rec_data.getData(RESPONSE_TAG));
                                       //added by Ashish on 1-Dec-2017 starts
                				       int chgCode = Integer.parseInt(rec_data.getData(TARIFFID_TAG)); 
                				       req.setTarrifId(chgCode);
                				       //added by Ashish on 1-Dec-2017 ends
                                        logger.info("Msisdn:["+req.getMsisdn()+"] Fmsisdn:["+req.getfMsisdn()+"] SUB_TYPE:"+rec_data.getData(SUB_TYPE)+"] chgCode:["+chgCode+"]  Response to Send Back: ["+response+"]");
                                 }
                          return response;

                  }
		
		catch(SocketException se)
		{
			logger.error("[CRBT-BU-90011] getting error in opening socket in subscribeCharging method(RequestResponseBean, int) of class TCPPacketCharging ", se);
			//return -1;
			return -101;
		}
		catch(InterruptedIOException ioEx)
		{
			
			logger.error("[CRBT-BU-90015] getting error while Socket TimeOut occurred in subscribeCharging method(RequestResponseBean, int) of class TCPPacketCharging ", ioEx);
			//return -1;
			return -98;
		}
        
        catch(IOException ioe)
        {
        	logger.error("[CRBT-BU-90002] getting failed  to get input/output stream in subscribeCharging method(RequestResponseBean, int) of class TCPPacketCharging ", ioe);
        	//return -1;
        	return -97;
        }
        catch(Exception exp)
        {	          
        	//exp.printStackTrace();
        	logger.error("[CRBT-BU-00053] getting error in subscribeCharging method(RequestResponseBean, int) of class TCPPacketCharging ", exp);
        	//return -1;
        	return -100;
        }
        finally
        {
        	try{
        		if(socket!=null)
        		{
        			socket.close();
            		socket=null;
        		}        		
        	}
        	catch(Exception exp)
        	{	
				logger.error("[CRBT-BU-00054] getting error while closing socket connection in subscribeCharging method(RequestResponseBean, int) of class TCPPacketCharging ", exp);
				//exp.printStackTrace();
        	}
        }
    }//subscribeCharging() by harjinder ends


         public char sendRequestToChargingHLR(RequestResponseBean reqbean)
         {         	
        	 		//ByteArrayOutputStream buf=null;
                   commonutil.TLVAppInterface tlvAppInterface=null;
                   char retval='N';
                   try{
                        int sourcetype=Global.SOURCE_TYPE;
                        int responseCode=-1;
                        logger.info("##>>Msisdn["+reqbean.getMsisdn()+"] reqType:["+reqbean.getRequestType()+"] sending Request to Charging to get sub type ["+Global.SSF_SERVER_HOST+":"+Global.SSF_SERVER_PORT+"] Using BigTlv");
                        logger.debug("sending request to Charging to get subtype through TLV >> msisdn["+reqbean.getMsisdn()+"] sourceType["+sourcetype+"]");
                        tlvAppInterface=new commonutil.TLVAppInterface();
                        tlvAppInterface.setServerIP(Global.SSF_SERVER_HOST);
                        tlvAppInterface.setServerPort(Global.SSF_SERVER_PORT);
                        tlvAppInterface.setData(MSISDN_TAG,reqbean.getMsisdn());                       
                        tlvAppInterface.setData(REQTYPE_TAG,reqbean.getRequestType());// 6->subtype check
                        tlvAppInterface.encode();
                        tlvAppInterface.setSocketTimeOut(30000);
                        tlvAppInterface.send();
                        tlvAppInterface.receive();                      
                         if(tlvAppInterface.getData(RESPONSE_TAG)!=null){
                                responseCode=Integer.parseInt(tlvAppInterface.getData(RESPONSE_TAG));
                                logger.info("msisdn["+reqbean.getMsisdn()+"] subtype response from Charging : ["+responseCode+"] ");
                                if(responseCode>=0 && (tlvAppInterface.getData(SUB_TYPE)!=null && (!tlvAppInterface.getData(SUB_TYPE).equalsIgnoreCase(""))))
                                  {
                                      retval=tlvAppInterface.getData(SUB_TYPE).charAt(0);
                                  }
                               else
                                  {
                                     retval='N';
                                  }

                        }
                        else{
                                retval='N';
                                logger.error("msisdn["+reqbean.getMsisdn()+"] got exception from Charging so default response : ["+responseCode+"]");
                        }


                      }                

                   catch(Exception socexp)
                   {
                	   retval='N';                	   
                	   logger.error("[CRBT-BU-00055]  getting error in sendRequestToChargingHLR(RequestResponseBean) of class TCPPacketCharging ", socexp);
                   }                   
                   finally
                   {
                	   try
                	   {
                		   tlvAppInterface.close();
                		   tlvAppInterface=null;
                	   }
                	   catch(Exception e)
                	   {
                		   logger.error("[CRBT-BU-00056] Exception while closing of tlvAppInterface connection in sendRequestToChargingHLR(RequestResponseBean) of class TCPPacketCharging ",e);
                	   }
                	   
                   }	                   
                   logger.debug("msisdn["+reqbean.getMsisdn()+"] Sending subtype Response subtype["+retval+"]");
                   
              return retval;
         }//sendRequestToChargingHLR(RequestResponseBean reqbean) ends

          public char sendRequestToChargingHLR(RequestResponseBean reqbean,String param)
          {

                   ByteArrayOutputStream buf=null;
                   TlvLib.TLVAppInterface tlvAppInterface=null;
                   char retval='N';
                   try{
                        int sourcetype=Global.SOURCE_TYPE;
                        int responseCode=-1;
                        logger.info("##>>Msisdn["+reqbean.getMsisdn()+"]sending Request to Charging to get subtype ["+Global.SSF_SERVER_HOST+":"+Global.SSF_SERVER_PORT+"] simple TlvLib");
                        logger.debug("sending request to Charging to get sub type through TLV >> msisdn["+reqbean.getMsisdn()+"] source type["+sourcetype+"]");
                        ByteArrayOutputStream send_buf=new ByteArrayOutputStream();
                        socket = new Socket(Global.SSF_SERVER_HOST,Global.SSF_SERVER_PORT);	
                        tlvAppInterface=new TlvLib.TLVAppInterface();
                        //tlvAppInterface.setServerIP(TSSJavaUtil.instance().getSSFServer());
                        //tlvAppInterface.setServerPort(TSSJavaUtil.instance().getSSFPort());
                        tlvAppInterface.setData(MSISDN_TAG,reqbean.getMsisdn());
                        //tlvAppInterface.setData(REQTYPE_TAG,reqbean.getRequest_type());// 6->subtype check //should be remove 
                        tlvAppInterface.setData(REQTYPE_TAG,reqbean.getRequestType());// 6->subtype check 
                        //tlvAppInterface.encode();
                       // tlvAppInterface.setSocketTimeOut(30000);
                       // tlvAppInterface.send();
                       //tlvAppInterface.receive();
                        tlvAppInterface.encode(send_buf);
                        logger.info("packet Socket is==="+socket.toString());
                        int send_requestLen = send_buf.size();
                        socket.setSoTimeout(30000);
                        stream_send_data = new DataOutputStream(socket.getOutputStream());
                        logger.info("writing Info buf size="+send_requestLen);
                        byte[] len=new byte[4];
                        len[3]=(byte)(send_requestLen );
                        len[2]=(byte)((send_requestLen >> 8) );
                        len[1]=(byte)((send_requestLen >> 16));
                        len[0]=(byte)((send_requestLen >> 24));
                        stream_send_data.write(len,0, 4);
                        stream_send_data.write(send_buf.toByteArray(), 0, send_buf.toByteArray().length);


                        TlvLib.TLVAppInterface rec_data ;
                        rec_data = new TlvLib.TLVAppInterface();
                        DataInputStream dis=new DataInputStream(socket.getInputStream());
                        byte dataBuf1[] = new byte[4];
                        int dataLen =0;
                        int test=0;
                        ByteArrayInputStream inbuf=null;
                         if(dis.read(dataBuf1,0,4)==-1)
                                {
                                 logger.debug("reader.read == -1 ...");
                                 logger.debug("  .............................");
                                }
                                else
                                {
                                  dataLen = dataLen | (dataBuf1[0] << 24);
                                  dataLen = dataLen  | (dataBuf1[1] << 16);
                                  dataLen = dataLen | (dataBuf1[2] << 8);
                                  test=(0x000000ff & dataBuf1[3]);
                                  dataLen = dataLen | test;
                                logger.info("msisdn["+reqbean.getMsisdn()+"]  length:"+dataLen);
                                  byte dataBuf[] = new byte[dataLen];

                                        dis.read(dataBuf, 0, dataLen);

                                        inbuf = new ByteArrayInputStream(dataBuf);
                                        rec_data.decode(inbuf,dataLen);
 
                    
                        //System.out.println("------------------> ["+tlvAppInterface.getData(CrbtTags.RESPONSE_CODE)+"]");
                         if(rec_data.getData(RESPONSE_TAG)!=null)
                         {
                                responseCode=Integer.parseInt(rec_data.getData(RESPONSE_TAG));
                                logger.info("msisdn["+reqbean.getMsisdn()+"] sub type response from Charging : ["+responseCode+"]");
                                if(responseCode>=0 && (rec_data.getData(SUB_TYPE)!=null && (!rec_data.getData(SUB_TYPE).equalsIgnoreCase(""))))
                                  {
                                      retval=rec_data.getData(SUB_TYPE).charAt(0);
                                  }
                               else
                                  {
                                     retval='N';
                                  }

                        }
                        else{
                                retval='N';
                                logger.error("msisdn["+reqbean.getMsisdn()+"] got exception from Charging so default response : ["+responseCode+"]");
                        }
                      }
                     }
		
		catch(SocketException se)
		{
			logger.error("[CRBT-BU-90011] getting error in opening socket in sendRequestToChargingHLR(RequestResponseBean, String) of class TCPPacketCharging ", se);
			retval='N';
		}
		catch(InterruptedIOException ioEx)
		{
			
			logger.error("[CRBT-BU-90015] getting error while Socket TimeOut occurred in sendRequestToChargingHLR(RequestResponseBean, String) of class TCPPacketCharging ", ioEx);
			retval='N';
		}

        catch(IOException ioe)
        {
        	logger.error("[CRBT-BU-90002] getting failed  to get input/output stream in sendRequestToChargingHLR(RequestResponseBean, String) of class TCPPacketCharging ", ioe);
        	retval='N';
        }
        catch(Exception socexp)
        {
        	retval='N';
        	//socexp.printStackTrace();
        	logger.error("[CRBT-BU-00057] getting error  in sendRequestToChargingHLR(RequestResponseBean, String) ", socexp);
        }        
        finally
        {
        	try
        	{
				socket.close();
				tlvAppInterface=null;
			}
        	catch (Exception e) 
        	{	
        		logger.error("[CRBT-BU-00058] Error while closing socket connection in sendRequestToChargingHLR(RequestResponseBean, String) ",e);
				//e.printStackTrace();
			}
        }
                   logger.debug("msisdn["+reqbean.getMsisdn()+"]  Sending Response subtype["+retval+"]");
                   return retval;

    }//sendRequestToChargingHLR(RequestResponseBean reqbean,String param) ends

	
}//class
