package com.telemune.bulkupload.db;


import java.sql.BatchUpdateException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;

import com.telemune.bulkupload.beans.CorpDetailBean;
import com.telemune.bulkupload.beans.FetchMsrnBean;
import com.telemune.bulkupload.beans.ListDataBean;
import com.telemune.bulkupload.beans.ListIdBean;
import com.telemune.bulkupload.beans.RequestResponseBean;
import com.telemune.bulkupload.beans.ToneSetting;
import com.telemune.bulkupload.common.BulkUploadServer;
import com.telemune.bulkupload.common.BulkUploadServerMessages;
import com.telemune.bulkupload.common.FetchMsrn;
import com.telemune.bulkupload.common.Global;
import com.telemune.bulkupload.common.TCPPacketCharging;
import com.telemune.bulkupload.threads.CacheLoader;


import RatePlan.RatePlanParser;

public class CorpManager 
{
	private static final Logger logger=Logger.getLogger(CorpManager.class);
	RequestResponseBean reqbean=new RequestResponseBean();	
	RatePlanParser crbtRatePlanParser=new RatePlanParser();
	private static char interfaceType='T';
	final static byte SERVICE_ACTIVATE_SS = 3;
	final static byte SERVICE_DEACTIVATE_SS = 4;
	BulkUploadServer uploadServer=null;
	/**
	 * This Function get request type (CORP SUB/UNSUB Action) request from Database and put it into the queue
	 *It takes out many parameters from database used to process the request
	 */
	
	public void getListInfo(ArrayList listInfo)
	{
		logger.info("Inside getListInfo() Method to get array list of ListId's  which are not completed");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ListIdBean listIdBean = null;
		CorpDetailBean corpBean = null; 
		boolean resp = false;
		
		String query=null; 
		query=DBQueries.SELECT_USER_ID__JOB_LIST_DETAILS;
		
		try
		{  
			logger.info("query in getListInfo: "+query);
		    con = Global.conPool.getConnection();
			if(con==null)
			{
				con=ConnPool.cpds.getConnection();
			}
			logger.info("The Value of Connection is:"+con);
			
			//con=Global.conPool.getConnection();
			logger.info("query in getListInfo: after connectionPool ");
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			logger.info("Query in getListInfo: "+query);
			while(rs.next())
			{
				listIdBean = new ListIdBean();				
				listIdBean.setListId(rs.getString("LIST_ID"));				
				listIdBean.setUserId(rs.getString("USER_ID"));
				listIdBean.setAction(rs.getString("ACTION"));
				listIdBean.setScope(rs.getString("SCOPE"));
				listIdBean.setCreateDate(rs.getString("CREATE_DATE"));				
				listIdBean.setLidStatus(rs.getString("STATUS").charAt(0));	
				listIdBean.setTotalReqCount(rs.getInt("TOTAL_REQ_COUNT"));
				listIdBean.setRequestType(rs.getString("REQUEST_TYPE"));
				listIdBean.setSuccessCount(rs.getInt("TOTAL_SUCC_COUNT"));
				listIdBean.setFailCount(rs.getInt("TOTAL_FAIL_COUNT"));
				listIdBean.setLang(Global.DEFAULT_LANGUAGE);
				
				corpBean = new CorpDetailBean();
				listIdBean.setCorpDetailBean(corpBean);
				resp=parseActionData(listIdBean);
				if(resp==true)
				{
					resp=getCorpIdDetail(listIdBean);
				}
				
				if(resp==true)
				{
					logger.debug("listIdBean:["+listIdBean+"]");
					listInfo.add(listIdBean);
				}
				else
				{					
					logger.info("list_id["+listIdBean.getListId()+"] Response from parseActionData() or getCorpIdDetail() data is not success..");
				}
			}//while loop ends
			if(listInfo.size()==0)
			{
				logger.info("No Pending or Running ListId found");
			}
			corpBean= null;
			listIdBean=null;
		}		
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] NullPointerException in getListInfo() of class CorpManager ",npe);
		}
		catch(ClassCastException cce)
		{
			logger.error("[CRBT-BU-90009] ClassCastException in getListInfo() of class CorpManager ",cce);
		}
		catch(SQLException sqle)
		{
			logger.error("[CRBT-BU-90001] SQLException in getListInfo() of class CorpManager ",sqle);
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00018] Exception in getListInfo() of class CorpManager ",e);
		}
		finally
		{
			try
			{
				if(con!=null)
				{					
					con.close();										
				}
				if(pstmt!=null)
				{
					pstmt.close();					
				}
				if(rs!=null)
				{
					rs.close();					
				}
				query=null;
				con=null;
				pstmt=null;
				rs=null;
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00019] Exception while Closing of DB Resources in getListInfo() of class CorpManager ",e);
			}
		}
		
	}//getListInfo() ends
	
	public void getMsisdnList(ListIdBean listIdBean,ArrayList listMsisdn,ArrayList runningList)
	{
		logger.info("Inside getMsisdnList() to get Msisdn to process of ListId:["+listIdBean.getListId()+"]");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;		
		ListDataBean listDataBean = null;
		
		String query=null; 
		query=DBQueries.SELECT_LIST_ID_JOB_LIST_DETAILS;
		try
		{
			con = Global.conPool.getConnection();
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,listIdBean.getListId());
			rs = pstmt.executeQuery();
			logger.debug("query1 inside getMsisdnList: "+query);
			while(rs.next())
			{
				listDataBean = new ListDataBean();
				listDataBean.setListId(rs.getString("LIST_ID")); 
				listDataBean.setMsisdn(rs.getString("MSISDN"));
				listDataBean.setMsisdnStatus(rs.getString("STATUS").charAt(0));
				listDataBean.setInterface(interfaceType);		
				listDataBean.setListbean(listIdBean);
				
				listMsisdn.add(listDataBean);
				
			}//while loop ends
			rs.close();
			pstmt.close();
			query=DBQueries.SELECT_RUNNING_STATUS_JOB_LIST_DETAILS;
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,listIdBean.getListId());
			rs = pstmt.executeQuery();
			logger.debug("query2 inside getMsisdnList:  "+query);
			if(rs.next())
			{
				logger.info("runningList count in getMsisdnList:["+rs.getString("RUNNING_STATUS")+"] ListId:["+listIdBean.getListId()+"]");
				if(Integer.parseInt(rs.getString("RUNNING_STATUS"))!=0)
				runningList.add(rs.getString("RUNNING_STATUS"));
			}
			rs.close();
			pstmt.close();
			
			//added on 11-01-2017 starts
			getListInfoForCount(listIdBean);
			updateListInfo(listIdBean,'R');
			//added on 11-01-2017 ends
			listDataBean=null;
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] NullPointerException in getMsisdnList() of class CorpManager ",npe);
		}
		catch(SQLException sqle)
		{
			logger.error("[CRBT-BU-90001] SQLException during DB operation in getMsisdnList() of class CorpManager ",sqle);
		}
		catch(ClassCastException cce)
		{
			logger.error("[CRBT-BU-90009] ClassCastException during DB operation in getMsisdnList() of class CorpManager ",cce);
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00020] Exception in getMsisdnList() of class CorpManager ",e);
		}
		finally
		{
			try
			{
				if(con!=null)
				{					
					con.close();					
				}
				if(pstmt!=null)
					pstmt.close();
				if(rs!=null)
					rs.close();
				query=null;
				con=null;
				pstmt=null;
				rs=null;
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00021] Exception while Closing of DB Resources in getMsisdnList() of class CorpManager ",e);
			}
		}//finally ends
		
	}//getMsisdnList() ends
	
	
	public void updateListInfo(ListIdBean listIdBean,char status)
	{
		logger.info("inside updateListInfo() of class CorpManager ListId:["+listIdBean.getListId()+"] status:["+listIdBean.getLidStatus()+"] Success Count:["+listIdBean.getSuccessCount()+"] Failure Count:["+listIdBean.getFailCount()+"] status to be update:["+status+"]");		
		Connection con=null;
		PreparedStatement pstmt=null;
		String query=null; 
		query=DBQueries.UPDATE_STATUS_JOB_DETAILS;
       
		try
		{
			
			con = Global.conPool.getConnection();			
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,String.valueOf(status));
			pstmt.setInt(2,listIdBean.getSuccessCount());
			pstmt.setInt(3,listIdBean.getFailCount());			
			pstmt.setString(4,listIdBean.getListId().trim());
			logger.debug("Query inside updateListInfo: "+query);
			int result = pstmt.executeUpdate();			
			if(result>0)
			{				
				logger.info("Successfully  Update List Id:["+listIdBean.getListId()+"] status to:["+status+"] from ["+listIdBean.getLidStatus()+"] No of rows Updated:["+result+"]");
			}
			else
			{
				logger.info("Error while  Update List Id:["+listIdBean.getListId()+"] status to:["+status+"] from ["+listIdBean.getLidStatus()+"] No of rows Updated:["+result+"]");
			}
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] NullPointerException in updateListInfo() of class CorpManager ",npe);
		}
		catch(SQLException sqle)
		{
			logger.error("[CRBT-BU-90001] SQLException in updateListInfo() of class CorpManager ",sqle);
		}		
		catch(Exception exp)
		{
			logger.error("[CRBT-BU-00022] Exception in updateListInfo() of class CorpManager ",exp);
		}
		finally
		{
			try 
			{
				if(con!=null)
				{					
					con.close();
				}
				if(pstmt!=null)
					pstmt.close();
				query=null;
				con=null;
				pstmt=null;
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00023] Exception while Closing of DB Resources in updateListInfo() of class CorpManager ",e);
			}
		}//finnaly ends		
	}//updateListInfo() ends
	
	public void getListInfoForCount(ListIdBean listIdBean)
	{
		logger.info("Inside getListInfoForCount() to get Success and Failure count ListId:["+listIdBean.getListId()+"] ");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query=null; 
		query=DBQueries.SELECT_COUNT_JOB_LIST_DETAILS;
		try
		{
			con = Global.conPool.getConnection();
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,listIdBean.getListId());
			rs = pstmt.executeQuery();
			logger.debug("Query inside getListInfoForCount: "+query);
			while(rs.next())
			{
				logger.debug("STAUS_INSIDE["+rs.getString("STATUS")+"] COUNT["+rs.getString("TOTAL_COUNT")+"]");
				if(rs.getString("STATUS").equalsIgnoreCase("S"))
				{				
					listIdBean.setSuccessCount(Integer.parseInt(rs.getString("TOTAL_COUNT")));
				}
				else if(rs.getString("STATUS").equalsIgnoreCase("F"))
				{				
					listIdBean.setFailCount(Integer.parseInt(rs.getString("TOTAL_COUNT")));
				}
			}//while loop ends
			logger.info("ListId:["+listIdBean.getListId()+"] Total SuccessCount:["+listIdBean.getSuccessCount()+"] FailCount:["+listIdBean.getFailCount()+"]");
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] NullPointerException in getListInfoForCount() of class CorpManager ",npe);
		}
		catch(SQLException sqle)
		{
			logger.error("[CRBT-BU-90001] SQLException in getListInfoForCount() of class CorpManager ",sqle);
		}
		catch(NumberFormatException nfe)
		{
			logger.error("[CRBT-BU-90004] NumberFormatException in getListInfoForCount() of class CorpManager ",nfe);
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00024] Exception in getListInfoForCount() of class CorpManager ",e);
		}finally
		{
			try
			{
				if(con!=null)
				{					
					con.close();					
				}
				if(pstmt!=null)
					pstmt.close();
				if(rs!=null)
					rs.close();
				query=null;
				con=null;
				pstmt=null;
				rs=null;
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00025] Exception while Closing of DB Resources in getListInfoForCount() of class CorpManager ",e);
			}
		}
	}//getListInfoForCount() ends
	
	public void updateMsisdnStatus(ArrayList listMsisdn)
	{
		logger.info("Inside updateMsisdnStatus() Method to update Msisdn status from P to R"); 
		Connection con = null;
		PreparedStatement pstmt= null;
		String query=null;
		query=DBQueries.UPDATE_JOB_LIST_DETAILS;
		ListDataBean listDataBean = null;
		
		try
		{			
				con = Global.conPool.getConnection();
				pstmt=con.prepareStatement(query);
				logger.debug("update query in updateMsisdnStatus() status update to R: ["+query + "]  "); //debug
				Iterator itr = listMsisdn.iterator();
				while(itr.hasNext())
				{
					listDataBean = (ListDataBean)itr.next();					
					pstmt.setString(1,"R");
					pstmt.setString(2,listDataBean.getMsisdn());
					pstmt.setString(3,listDataBean.getListbean().getListId());
					pstmt.addBatch();
				}			
				int[] updatedMsisdn = pstmt.executeBatch();
				logger.debug("No of Msisdn status update in updateMsisdnStatus() "+updatedMsisdn.length);
				listDataBean=null;
		}
		catch(BatchUpdateException bue)
		{
			logger.error("[CRBT-BU-90024] BatchUpdateException in updateMsisdnStatus() of class CorpManager ",bue);
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] NullPointerException in updateMsisdnStatus() of class CorpManager ",npe);
		}
		catch(SQLException sqle)
		{
			logger.error("[CRBT-BU-90001] SQLException in updateMsisdnStatus() of class CorpManager ",sqle);
		}
		catch(ClassCastException cce)
		{
			logger.error("[CRBT-BU-90009] ClassCastException in updateMsisdnStatus() of class CorpManager ",cce);
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00026] Exception in updateMsisdnStatus() while updating status to Processing Msisdn:["+listDataBean.getMsisdn()+"] ListId:["+listDataBean.getListbean().getListId()+"]",e);
		}
		finally
		{
			try
			{
				if(con!=null)
				{					
					con.close();
				}
				if(pstmt!=null)
					pstmt.close();	
				con=null;
				pstmt=null;
			}
			catch(Exception e)
			{
				logger.info("[CRBT-BU-00027] Exception while closing DB resources in updateMsisdnStatus() of class CorpManager ",e);
			}
		}
		logger.info(" Msisdn status from P to R updated successfully");
	}//updateMsisdnStatus
	
	
	public boolean getCorpIdDetail(ListIdBean listbean)
	{		
		logger.info("CorpId:["+listbean.getCorpDetailBean().getCorpId()+"] ListId:["+listbean.getListId()+"] ReqId:["+listbean.getReqId()+"]" );
		Connection con = null;
		PreparedStatement pstmt= null;
		ResultSet rs = null;
		String query = "";		
		int maxSub=0;		
		//String scope_temp="NA";		
        //String scope[];
        boolean result = false;
        int corpId = listbean.getCorpDetailBean().getCorpId();        
        char subType = 'N';
		try{
			if(con==null)
			{
				con = Global.conPool.getConnection();
			}			
			//query = "SELECT MAX_SUB,CHARGING_MSISDN,CORP_NAME,SCOPE from CRBT_CORP_DETAIL where corp_id = ?";
			
			//added by Ashish on 28-Nov-2017 starts
			if(Global.isLicenseFeatureEnable==true)
			{
				query=DBQueries.SELECT_MAX_SUB;
			}
			else
			{  
				query=DBQueries.SELECT_CHARGING_MSISDN;
			}
		//	logger.info("The DataBase used is :"+TSSJavaUtil.getInstance().getKeyValue("DB_QUERY")+":"+query);
			//added by Ashish on 28-Nov-2017 ends
			//query = "SELECT MAX_SUB,CHARGING_MSISDN,CORP_NAME from CRBT_CORP_DETAIL where corp_id = ?";//commented by Ashish on 28-NOV-2017
			pstmt =con.prepareStatement(query);
			pstmt.setInt(1,corpId);
			
			rs=pstmt.executeQuery();			 
			logger.debug("Query1 in getCorpIdDetail: "+query);
			if(rs.next())
			{
				//Added by Ashish on 28-NOV-2017 starts
				if(Global.isLicenseFeatureEnable==true)
				{
					maxSub = rs.getInt("MAX_SUB");
					listbean.getCorpDetailBean().setTotcap(maxSub);
					logger.debug(" ListId:["+listbean.getListId()+"] maxSub["+maxSub+"] setting maxSub for License Feature Enable");		
				}
				else
				{
					maxSub=-99;
					listbean.getCorpDetailBean().setTotcap(maxSub);
					logger.debug(" ListId:["+listbean.getListId()+"] maxSub["+maxSub+"] setting maxSub to -99 for License Feature not enable for corp");
				}
				//added by Ashish on 28-NOV-2017 ends
				//maxSub = rs.getInt("MAX_SUB"); //commented by Ashish on 28-NOV-2017
				//listbean.getCorpDetailBean().setTotcap(maxSub);//commented by Ashish on 28-NOV-2017
				//logger.debug(" ListId:["+listbean.getListId()+"] maxSub "+maxSub);//commented by Ashish on 28-NOV-2017				
				listbean.getCorpDetailBean().setChargingMsisdn(rs.getString("CHARGING_MSISDN"));
				listbean.getCorpDetailBean().setCorpName(rs.getString("CORP_NAME"));
				//added by Ashish on 28-NOV-2017 Starts
				String scopeSubValue = null; 
				if(Global.CHARGING_SCOPE==true)
				{
					scopeSubValue = (String)Global.corpIdScope.get(String.valueOf(corpId));
					logger.info("ListId:["+listbean.getListId()+"] scope value:["+scopeSubValue+"]");
					if(scopeSubValue==null)
					{
						CacheLoader reloadCache = new CacheLoader();
						reloadCache.reloadCache();
						scopeSubValue = (String) Global.corpIdScope.get(corpId);
						reloadCache=null;
					}
					if(scopeSubValue==null )
					{
						listbean.getCorpDetailBean().setScopeCorp(scopeSubValue); 
					}
					listbean.getCorpDetailBean().setScopeCorp(scopeSubValue);
					logger.info("Corporate Sub Scope value:["+scopeSubValue+"] ListId:["+listbean.getListId()+"]");
				}
				//added by Ashish on 28-NOV-2017 ends
				
				//Below code is commented by Ashish on 28-NOV-2017 
				/*scopeSubValue = (String)Global.corpIdScope.get(String.valueOf(corpId));
				logger.info("ListId:["+listbean.getListId()+"] scope value:["+scopeSubValue+"]");
				if(scopeSubValue==null)
				{
					CacheLoader reloadCache = new CacheLoader();
					reloadCache.reloadCache();
					scopeSubValue = (String) Global.corpIdScope.get(corpId);
					reloadCache=null;
				}
				if(scopeSubValue==null )
				{
					listbean.getCorpDetailBean().setScopeCorp(scopeSubValue); 
				}
				listbean.getCorpDetailBean().setScopeCorp(scopeSubValue); */
				/*if(rs.getString("SCOPE")!=null && (!rs.getString("SCOPE").equalsIgnoreCase("NA")))
                {
				   StringTokenizer st= new StringTokenizer(rs.getString("SCOPE"),",");
				   while(st.hasMoreTokens())
					{
					   scope_temp=st.nextToken();
					   scope=scope_temp.split(":");
				       scope_temp=scope[1];				         
				       listbean.getCorpDetailBean().setScopeCorp(scope_temp);
				       break; //only getting SUB:I/M scope
					}
					
                }
				else
				{
					listbean.getCorpDetailBean().setScopeCorp(rs.getString("SCOPE")); 
				}*///commented on 12-01-2017
				//logger.info("Corporate Sub Scope value:["+scopeSubValue+"] ListId:["+listbean.getListId()+"]"); //Commented by Ashish on 28-NOV-2017 
			}
			
				//logger.info("scopeSubValue:["+scopeSubValue+"] ListId:["+listbean.getListId()+"]");
				//getting SUB TYPE OF CHARGING MSISDN				
				if((listbean.getReqId()!=2) && (listbean.getCorpDetailBean().getCorpSubType()==0 || listbean.getCorpDetailBean().getCorpSubType()=='N' || listbean.getCorpDetailBean().getCorpSubType()=='n' || listbean.getCorpDetailBean().getCorpSubType()==32  ))
			    {
			    	subType =  getSubType(listbean.getCorpDetailBean().getChargingMsisdn()); 			    	
					//subType='n'; //should be commented later for testing only
			    	logger.info("Corporate Billing Msisdn SubType:["+subType+"] ListId:["+listbean.getListId()+"] ");
			    	listbean.getCorpDetailBean().setCorpSubType(subType);			    	
			    	if(subType!='N' && subType!='n' && subType!=0 && subType!=32)
			    	{
			    		updateScope(listbean);			    		
			    	}	
			    }
				
				if(listbean.getCorpDetailBean().getCorpSubType()=='N' || listbean.getCorpDetailBean().getCorpSubType()=='n' || listbean.getCorpDetailBean().getCorpSubType()==0 || listbean.getCorpDetailBean().getCorpSubType()==32 ) 
			    {			    
			    	subType='N';
			    	listbean.getCorpDetailBean().setCorpSubType(subType);
			    }			  
			
				//get Fall Back  Charging Code
				String schargeCode="N/A";
				String fnlchargeCode="N/A";
				
				if(listbean.getReqId()!=2)
				{
					short planId = listbean.getCorpDetailBean().getPlan();				
					query=DBQueries.SELECT_SUB_FB_CHG_CODE;
					pstmt = con.prepareStatement(query);
					pstmt.setShort(1,planId);					
					logger.debug("query of find charge_code: "+query);
					rs = pstmt.executeQuery();
					if (rs.next())
					{
						schargeCode =rs.getString("SUB_CHARGE");
						logger.info("ListId:["+listbean.getListId()+"] CorpId:["+corpId+"] PlanIndicator:["+planId+"] chargeCode:["+schargeCode+"] ");
						crbtRatePlanParser.ParsrChargingCode(schargeCode,planId+"","SUB_FB_RENEW");
						fnlchargeCode=crbtRatePlanParser.getParamValues(planId+"","SUB_FB_RENEW","CC:DAYS");
						listbean.getCorpDetailBean().setChargingCode(fnlchargeCode);
						logger.info("ListId:["+listbean.getListId()+"]  CorpId:["+corpId+"] PlanIndicator:["+planId+"] parsed chargeCode:["+fnlchargeCode+"] ");
					}					
					rs.close();
					pstmt.close();
				}				
			result = true;
		}		
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] NullPointerException in getCorpIdDetail() of class CorpManager ",npe);
			result = false;
		}
		catch(NumberFormatException nfe)
		{
			logger.error("[CRBT-BU-90004] NumberFormatException in getCorpIdDetail() of class CorpManager ",nfe);
			result = false;
		}
		catch(SQLException sqle)
		{
			logger.error("[CRBT-BU-90001] Exception during DB operation in getCorpIdDetail() of class CorpManager ",sqle);
			result = false;
		}
		catch(ArrayIndexOutOfBoundsException aiobe)
		{
			logger.error("[CRBT-BU-90007] Exception while access corporate scope in getCorpIdDetail() of class CorpManager ",aiobe);
			result = false;
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00028] Exception in getCorpIdDetail() of class CorpManager  ",e);			
			result = false;			
		}finally
		{
				try 
				{
					if(con!=null)
					{						
						con.close();						
					}
					if(pstmt!=null)
						pstmt.close();
					if(rs!=null)
						rs.close();
					query = null;
					con=null;
					pstmt=null;
					rs=null;
				}
				catch (Exception e) {
					logger.error("[CRBT-BU-00029] Exception while closing DB Connection in getCorpIdDetail() ",e);
				}
		}
		return result;
	}//getCorpIdDetail
	
	public boolean updateScope(ListIdBean listIdBean)
	{		
		logger.info("inside updateScope() ListId:["+listIdBean.getListId()+"] Scope:["+listIdBean.getScope()+"]");
		boolean retVal = false;
		Connection con = null; 
		PreparedStatement pstmt = null;
		String query=null; 
		query=DBQueries.UPDATE_JOB_DETAILS;
		String scope = listIdBean.getScope()+",CORPSUBTYPE:"+listIdBean.getCorpDetailBean().getCorpSubType();		
		logger.info("ListId:["+listIdBean.getListId()+"] updated scope:["+scope+"]");
		try
		{
			con = Global.conPool.getConnection();
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,scope);
			pstmt.setString(2,listIdBean.getListId());
			logger.debug("Query in updateScope: UPDATE JOB_DETAILS SET SCOPE ='"+scope+"' WHERE LIST_ID='"+listIdBean.getListId()+"'");
			int resp =  pstmt.executeUpdate();
			if(resp>0)
			{
				retVal = true;
			}
			
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] some value may be null in updateScope() of class CorpManager ",npe);
		}
		catch(SQLException sqle)
		{
			logger.error("[CRBT-BU-90001] getting error while update in DB query in updateScope() of class CorpManager ",sqle);
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00072] Exception in updateScope() of class CorpManager ",e);
		}
		finally
		{
			try
			{
				if(pstmt!=null)
				{
					pstmt.close();
				}
				if(con!=null)
				{
					con.close();					
				}
				query= null;
				con=null;
				pstmt=null;
				scope=null;
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00073] Exception while closing of DB resources in updateScope() of class CorpManager ",e);
			}
		}//finally block ends
		logger.info("ListId:["+listIdBean.getListId()+"] return value from updateScope:["+retVal+"]");
		return retVal;
	}
	
	private boolean parseActionData(ListIdBean listbean)
	{
		logger.info("inside parseActionData() to parse SCOPE from JOB_DETAILS of ListId:["+listbean.getListId()+"]");
		boolean result = false;	
		StringTokenizer str = null;
		String token = "";
		String value = "";
		StringTokenizer token_value = null;	
		try
		{	
			if(listbean.getScope().trim()!=null)	
			{
				str = new StringTokenizer(listbean.getScope().trim(),",");
			}			
			while(str.hasMoreElements())
			{
				token=str.nextToken();				
				token_value=new StringTokenizer(token.trim(),":");				
				while(token_value.hasMoreElements())
				{
					value = token_value.nextToken();
					logger.debug("scope values["+value+"]");
					if(value.equals("ACT"))
					{
						byte act=0;
						String action = token_value.nextToken();
						if(action.equalsIgnoreCase("SUB"))
						{
							act=1;
						}else if(action.equalsIgnoreCase("UNSUB"))
						{
							act=2;
						}						
						listbean.setReqId(act);
					}
					else if(value.equals("CORPID"))
					{
						listbean.getCorpDetailBean().setCorpId((Integer.parseInt(token_value.nextToken())));
					}
					else if(value.equals("SMS"))
					{
						char sms = 'N';
						String sendSms = token_value.nextToken();
						if(sendSms.equalsIgnoreCase("Y"))
						{
							sms='Y';
						}
						listbean.setSendSms(sms);						
					}
					else if(value.equals("PLANID"))
					{
						listbean.getCorpDetailBean().setPlan(Short.parseShort(token_value.nextToken()));						
					}
					//added for CORP SUB TYPE
					else if(value.equals("CORPSUBTYPE"))
					{
						listbean.getCorpDetailBean().setCorpSubType(token_value.nextToken().charAt(0));
					}
				}
				result = true;
			}
							str = null;
							token_value = null;
                             token = null;
                             value = null;
		}
		catch(NumberFormatException nfe)
		{
			result = false;
			str = null;
			token_value = null;
			token = null;
			value = null;
			logger.error("[CRBT-BU-90004] NumberFormatException in parseActionData() of class CorpManager ",nfe);
		}
		catch(NullPointerException npe)
		{
			result = false;
			str = null;
			token_value = null;
			token = null;
			value = null;
			logger.error("[CRBT-BU-90003] NullPointerException in parseActionData() of class CorpManager ",npe);
		}	
		catch(Exception exp)
		{
			result = false;
			str = null;
			token_value = null;
			token = null;
			value = null;
			logger.error("[CRBT-BU-00030] Exception in parseActionData() of class CorpManager ",exp);			
		}
		logger.info("Response from parseActionData: ["+result+"] ListId:["+listbean.getListId()+"]");
		return result;
	}//parseActionData ends
 
	public String addSubscriberGroup(ListDataBean msisdnDataBean) 
	{
		logger.debug("inside addSubscriberGroup() msisdnDataBean: "+msisdnDataBean);		
		short retrn=0;		
		//added by Ashish on 28-NOV-2017 Starts
		String scope= null;
		if(Global.CHARGING_SCOPE==true)
		{			
			scope=msisdnDataBean.getListbean().getCorpDetailBean().getScopeCorp();
		}
		
		//added by Ashish on 28-NOV-2017 ends		
		String msisdn=msisdnDataBean.getMsisdn();
		String chargingMsisdn=msisdnDataBean.getListbean().getCorpDetailBean().getChargingMsisdn();
		String reason="Not found";
		String status = "failure"; 
		byte corpMsisdnenable = -1; //not enable
		String corpmsisdn="";
		String temp="";	
		try
		{
            if(Global.CHARGING_SCOPE==true && (!scope.equalsIgnoreCase("NA")))
            {                        
            	if(scope.equalsIgnoreCase("I")) //charging from individual account corporate scope
            	{
            		corpMsisdnenable=-1;  
            	}
            	else if(scope.equalsIgnoreCase("M")) //charging from main account corpoarte scope
            	{
            		corpMsisdnenable=1; 
            	}
            	logger.debug("Checking for CHARGING_SCOPE corporate Msisdn enable["+corpMsisdnenable+"] Msisdn:["+msisdn+"]");
            }
            else
            {
            	corpMsisdnenable=Byte.parseByte(Global.getAppConfigParam("CHARGING_FROM_CORP_MSISDN_ENABLE"));
            	logger.debug("Cheking from APP Config Param from corporate Msisdn enable["+corpMsisdnenable+"] Msisdn:["+msisdn+"]");
            }  
            logger.debug("Charging from corporate Msisdn enable["+corpMsisdnenable+"] Msisdn:["+msisdn+"]");   
	        if(corpMsisdnenable==1)
            {
            	logger.debug("chargingMsisdn["+chargingMsisdn+"] msisdn["+msisdn+"]");            
            	retrn = addSubscriber(msisdnDataBean,corpMsisdnenable,corpmsisdn,chargingMsisdn); //from corporate account
            }
            else
            {
            	temp = chargingMsisdn;
            	corpmsisdn = chargingMsisdn;
            	chargingMsisdn = msisdn;  
            	logger.debug(" inside else ..charging Msisdn["+chargingMsisdn+"] msisdn["+msisdn+"] corpmsisdn["+corpmsisdn+"]");            	           	
            	retrn = addSubscriber(msisdnDataBean,corpMsisdnenable,corpmsisdn,chargingMsisdn); //from individual accounts
            	chargingMsisdn=temp; 
            }                   
            logger.info("addsubscriber returing response :["+retrn + "] Msisdn:["+msisdn+"]"); 
            if(retrn == -1 || retrn == -2 || retrn == -5 || retrn == -12 || retrn == -15 || retrn == -13 ||retrn == -3 || retrn == -10||retrn==-99 || retrn == -16 || retrn == -22 || retrn==-25 || retrn==-23  || retrn==-26 || retrn==-101 || retrn==-6 || retrn==-7 )///Error
            {		
					/*if(retrn == -1 || retrn==-99 ) reason="Already subscribed";
					else if(retrn == -2 ) reason="Not in specified range";
					else if(retrn == -3) reason="Corporate License key Expire";
					else if(retrn == -5 ) reason="Call forwarding not done";
					else if(retrn == -12 ) reason="Subscriber Type not found";					
					else if(retrn == -15 ) reason="could not be Charged may be Insufficent Balance";
					else if(retrn == -16 ) reason="Subscribed Successfully but Error while sending message";
					else if(retrn == -13) reason="User Status Not Active";
					else if(retrn == -22) reason="Msisdn Not in Range";
					else if(retrn == -23) reason="Charging done but Msisdn not subscribed";
					else if(retrn == -25) reason="Msisdn must be whitelisted";
					else if(retrn == -26) reason="Total Capacity Full";
					else if(retrn == -10 ) reason="Error Occured";*/            
            	if(retrn == -1 || retrn==-99 ) reason=BulkUploadServerMessages.ALREADY_SUBSCRIBED;
				else if(retrn == -2 ) reason=BulkUploadServerMessages.INVALID_RANGE;
				else if(retrn == -3) reason=BulkUploadServerMessages.LICENSE_EXPIRE;
				else if(retrn == -5 ) reason=BulkUploadServerMessages.CALL_FORWARDING_ERROR;
				else if(retrn == -12 ) reason=BulkUploadServerMessages.SUB_TYPE_ERROR;					
				else if(retrn == -15 ) reason=BulkUploadServerMessages.CHARGING_ERROR;
				else if(retrn == -16 ) reason=BulkUploadServerMessages.SEND_SMS_ERROR;
				else if(retrn == -13) reason=BulkUploadServerMessages.STATUS_INACTIVE;
				else if(retrn == -22) reason=BulkUploadServerMessages.MSISDN_INVALID_RANGE;
				else if(retrn == -23) reason=BulkUploadServerMessages.CHARGING_DONE_NOT_SUBSCRIBED;
				else if(retrn == -25) reason=BulkUploadServerMessages.MSISDN_NOT_WHITELISTED;
				else if(retrn == -26) reason=BulkUploadServerMessages.TOTAL_CAPACITY_FULL;
				//added on 06-02-2017 starts
				else if(retrn == -101) reason=BulkUploadServerMessages.CHARGING_SOCKET_ERROR;
				else if(retrn == -6) reason=BulkUploadServerMessages.CHARGING_READ_TIMEOUT;
				else if(retrn == -7) reason=BulkUploadServerMessages.CHARGING_TIMEOUT_ERROR;
            	//added on 06-02-2017 ends
				else if(retrn == -10 ) reason=BulkUploadServerMessages.UNKNOWN_ERROR;
					msisdnDataBean.setDescription(reason);
					status="failure";
				}
            	else if(retrn>=0)
		   	    {	
            		/*msisdnDataBean.setDescription("Successfully Subscribed");*/
            		msisdnDataBean.setDescription(BulkUploadServerMessages.SUCCESSFULLY_SUBSCRIBED);
            		status="success";
		   	    }
            	else
		   	    {
		   	    	/*msisdnDataBean.setDescription("Error Occured please Try Later");*/
            		msisdnDataBean.setDescription(BulkUploadServerMessages.UNKNOWN_ERROR);            	
            		status="failure";
		   	    }
            scope=null;
            msisdn=null;
            chargingMsisdn=null;
            reason=null;
            corpmsisdn=null;
            temp=null;
		}//try
		catch(NullPointerException npe)
		{
			/*msisdnDataBean.setDescription("Error Occured ");*/
			msisdnDataBean.setDescription(BulkUploadServerMessages.UNKNOWN_ERROR);
			logger.error("[CRBT-BU-90003]  getting null value in addSubscriberGroup() of class CorpManager ", npe);			
			return "failure";
		}
		catch(NumberFormatException nfe)
		{
			/*msisdnDataBean.setDescription("Error Occured ");*/
			msisdnDataBean.setDescription(BulkUploadServerMessages.UNKNOWN_ERROR);
			logger.error("[CRBT-BU-90004] getting error while parsing(CHARGING_FROM_CORP_MSISDN_ENABLE) from String to Number Format in addSubscriberGroup() of class CorpManager ", nfe);			
			return "failure";
		}
		catch(Exception e)
		{
			/*msisdnDataBean.setDescription("Error Occured ");*/
			msisdnDataBean.setDescription(BulkUploadServerMessages.UNKNOWN_ERROR);
			logger.error("[CRBT-BU-00033]  getting error  in addSubscriberGroup() of class CorpManager ", e);			
			return "failure";
		}
		return status;
	} //addSubscriberGroup()
	
	public short addSubscriber(ListDataBean msisdnDataBean,int corpMsisdnenable,String corpMsisdn,String chargingMsisdn) //added on 16-12-2016
	{	
		logger.info("inside addSubscriber:["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"]");	
	 	Connection con = null;
        char listIntermsisdnSubType='N';  //changed from P to NA
		String imsi = "123456781011121";   
		char subscriberType='N' ; // all are same -postpaid or prepaid  //changed from P to NA		
		StringBuffer imsiBuf = new StringBuffer();	
		String msisdn = msisdnDataBean.getMsisdn();
		String fnlchargeCode= msisdnDataBean.getListbean().getCorpDetailBean().getChargingCode();
		logger.info("The fnlchargeCode is : "+fnlchargeCode);
		char corpSubType= msisdnDataBean.getListbean().getCorpDetailBean().getCorpSubType();
		logger.info("The corpSubtype is :"+corpSubType);
		if(con==null)
		{

			con = Global.conPool.getConnection();
		}
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CallableStatement cstmt = null;
		logger.info("The DataBase used is :"+Global.dbType.equalsIgnoreCase("ORACLE"));
		try 
		{	
			String checkCorpSubSql = null;
			if(Global.PROC_PACKAGE==0)
     		     if(Global.dbType.equalsIgnoreCase("ORACLE"))
     		          {
     		    	   logger.info("========================    The procedure used is oracle   ====>>> ==================");
     		    	    checkCorpSubSql = "{call CRBTNEW.CheckForCorpSubscription(?,?,?,?,?,?)}";
     		          }
     		     else 
     		     {
     		    	 logger.info("========================    The procedure used is MYSQl ====>     ==================");
     		    	 checkCorpSubSql="{call CheckForCorpSubscription(?,?,?,?,?,?)}";
     		     }
			else				
				  if(Global.dbType.equalsIgnoreCase("ORACLE"))
			        {
					  logger.info("========================    The procedure used is oracle   ====>>> ");
				     checkCorpSubSql = "{call CRBTCORPBULKUPLOAD.CheckForCorpSubscription(?,?,?,?,?,?)}";
				    }
				  else
				    {
					  logger.info("========================    The procedure used is MYSQL   ==<<<<=");
					 checkCorpSubSql="{call CheckForCorpSubscription(?,?,?,?,?,?) }";
				    }
			cstmt = con.prepareCall(checkCorpSubSql);
			cstmt.setString(1,msisdn);
			cstmt.setInt(2,Global.LICENSE_KEY); //check for max_sub of CRBT system
			cstmt.setInt(3,msisdnDataBean.getListbean().getCorpDetailBean().getPlan());
			cstmt.setInt(4,msisdnDataBean.getListbean().getCorpDetailBean().getCorpId());
			cstmt.setInt(5,msisdnDataBean.getListbean().getCorpDetailBean().getTotcap());
			cstmt.registerOutParameter(6,java.sql.Types.INTEGER);			
			cstmt.execute();
			int retStatus = cstmt.getInt(6);
			if(retStatus==-26)
			{	
				logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Total capacity Full ");
				return -26;
			}
			else if(retStatus==-25)
			{				
				logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Msisdn must be whitelisted ");
				return -25;
			}
			else if(retStatus==-33 || retStatus==-20)
			{
				logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] already subscribed ");
				return -1;
			}
			else if(retStatus==-21)
			{
				logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] License key Expire ");
				return -3;
			}
			else if(retStatus==-22)
			{
				logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Number Not in range ");
				return -22;
			}
			else if(retStatus<0)
			{
				logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Error occured ");
				return -10; //Error occured while fetch data 
			}
			checkCorpSubSql=null;
			
			listIntermsisdnSubType=getSubType(msisdn); //commented for testing only must be uncommented later		
			logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] SubType:["+listIntermsisdnSubType+"]");
			if(listIntermsisdnSubType=='N' || listIntermsisdnSubType=='n' || listIntermsisdnSubType==0)
			{
				return -12;
			}
			
			//added by Avishkar on 08.01.2019 starts
			int rbtCode=0;
			int corpId = msisdnDataBean.getListbean().getCorpDetailBean().getCorpId();
			if (Global.IS_SET_DEFAULT_RBT==true) {
				rbtCode = Integer.parseInt(Global.getAppConfigParam("DEFAULT_RBT")); //rbt for all new subscribers
			} else {
				if (corpId>=0) {
					rbtCode = Integer.parseInt(Global.corpRbtCode.get(String.valueOf(corpId)));
					logger.info(">>>msisdn:["+chargingMsisdn+"] Corp_Id:["+corpId+"] rbtCode:["+rbtCode+"]" );
				} else {
					logger.info(">>>msisdn:["+chargingMsisdn+"] Problem in getting rbt_code because CorpId not found. Corp_Id:["+corpId+"] rbtCode:["+rbtCode+"]");
				}
			}
			//added by Avishkar on 08.01.2019 ends
			
			Random noGenerator = new Random();
			String passwd = "" + (noGenerator.nextInt(8999) + 1000);		
			ToneSetting ts = new ToneSetting();
			TCPPacketCharging tcpCharge = new TCPPacketCharging();
			short retVal=-1;
			interfaceType='T';
			char subType='N';
			if(corpMsisdnenable==1)                    	 
			{				
				subType= corpSubType; //corpSubType is set in ListIdBean at time of getListInfo
			}
			else
			{
				subType=listIntermsisdnSubType;  
				logger.debug("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] chargingMsisdn ["+chargingMsisdn+"] SubType["+subType+"]"); 
			}             
                    	  if(subType=='N' || subType=='n' || subType==0 || subType==32)
                    	  {
                    		  retVal=-8;
                    	  }
                    	  else
                    	  {
                    		  //this change is to Make HLR Flag Up before request to charging
                    		  if (cfuProcess(msisdn, imsiBuf, SERVICE_ACTIVATE_SS) != 1)
                    		  {
                    			  logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] CFU Could not be activated for subscribing it ");
                    			  return -5;
                    		  }                    		  
                    		  subscriberType=subType;
                    		  if(corpMsisdnenable==1)
                    		  {	                    			
                    			  reqbean.setfMsisdn(msisdn);
                    		  }
                    		  else
                    		  {                    			
                    			  reqbean.setfMsisdn(corpMsisdn);
                    		  }
                    		  reqbean.setMsisdn(chargingMsisdn);                    		 
                    		  reqbean.setRequestType((byte) 1);                    		  
                    		  reqbean.setSubType(subscriberType);
                    		  reqbean.setAction((byte) 1);                            
                    		  reqbean.setRbtcode(rbtCode);
                    		  reqbean.setStarrifId(fnlchargeCode);                    		  
                    		  reqbean.setInterfaceType(interfaceType);//interfaceType changed to "T" for this
                    		  logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ChargingMsisdn ["+chargingMsisdn+"] FMsisdn ["+msisdn+"] Request_type[1] Sub_Type ["+subType+"] Action [1] Rbtcode ["+rbtCode+"] TarrifId(fnlchargeCode) ["+fnlchargeCode+"] InterfaceType ["+interfaceType+"] planId ["+msisdnDataBean.getListbean().getCorpDetailBean().getPlan()+"] tlvbasedenable["+Global.TLVBASE_ENABLE+"]");
                    		  
                    		  if(Global.TLVBASE_ENABLE==false)
                    		  {
                    			  retVal=(short) tcpCharge.subscribeCharging(reqbean,"DIGI"); 
                    		  }
                    		  else
                    		  { 
                    			  if(Global.BIGTLV_ENABLE==true)
                    			  { 
                    				  retVal=(short) tcpCharge.subscribeCharging(reqbean);  //using bigTlv commented for testing must be uncomment later
                    				  ////retVal = 30; // must be commented later for testing only
                    			  }
                    			  else
                    			  {
                    				  retVal=(short) tcpCharge.subscribeCharging(reqbean,-1); //using simple Tlv
                    			  } 
                    		  }
                    		  /////retVal=-1 ; //For LOcal testing to fail charging 
                    	  }
                    	  logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Getting response from charging ["+retVal + "] chargingCode ["+reqbean.getTarrifId()+"]");   
                     
			       if(retVal >=0)//success
			       {
				       logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] ChargingMsisdn:["+chargingMsisdn+ "] Charged successfully ");
				       //call subscribe procedure after hlr up and charging successfull
					String corpSubSql = null;
					if(Global.PROC_PACKAGE==0) {
						  if(Global.dbType.equalsIgnoreCase("ORACLE"))
					        {
							  logger.info("====================== call CRBTNEW.CorpSubscribe Charged successfully ");
						     corpSubSql = "{call CRBTNEW.CorpSubscribe(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
						    }
						  else
						  {
							  logger.info("====================== call MYSQL CorpSubscribe Charged successfully ");
							  corpSubSql ="{call CorpSubscribe(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
						  }  
					}
					else {
						if(Global.dbType.equalsIgnoreCase("ORACLE"))
						     {
							logger.info("====================== call CRBTCORPBULKUPLOAD.CorpSubscribe Charged successfully ");
						      corpSubSql = "{call CRBTCORPBULKUPLOAD.CorpSubscribe(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
						     }
						else 
						     {
							logger.info("====================== call XXXXXXXXXXXXX CorpSubscribe Charged successfully ");
							corpSubSql ="{call CorpSubscribe(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
						     }
						}	
						logger.info("going to call procedure "+corpSubSql+ " msisnd ["+msisdn+"] plan ["+msisdnDataBean.getListbean().getCorpDetailBean().getPlan()+"] lang ["+msisdnDataBean.getListbean().getLang()+"] userid ["+msisdnDataBean.getListbean().getUserId()+"] subscriber type ["+subscriberType+"] passwd ["+passwd+"]");
						logger.info("going to call procedure "+corpSubSql+ " -1  ["+reqbean.getTarrifId()+"] charging ret val ["+retVal+"] refId ["+-1+"] corpId ["+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"] corpName ["+msisdnDataBean.getListbean().getCorpDetailBean().getCorpName()+"] imsi ["+imsi+"] rbtcode ["+rbtCode+"] +Day+]" +ts.getDay()+"[StartTime]"+ts.getStartTime()+"[EndTime]"+ts.getEndTime());
						
						
						cstmt = con.prepareCall(corpSubSql);
						cstmt.setString(1,msisdn);
						cstmt.setInt(2,msisdnDataBean.getListbean().getCorpDetailBean().getPlan());
						cstmt.setInt(3,msisdnDataBean.getListbean().getLang());
						cstmt.setString(4,msisdnDataBean.getListbean().getUserId()); //updatedBy
						cstmt.setString(5,String.valueOf(subscriberType)); //sub_type
						cstmt.setString(6,passwd); //tpin is same as passwd so using passwd 
						cstmt.setString(7,"-1"); //refId ?						
						cstmt.setInt(8,reqbean.getTarrifId()); //chgCode as returned by Charging
						cstmt.setInt(9,retVal); //validityDays - returned by charging
						cstmt.setInt(10,-1); // isPackSubscriber -1					
						cstmt.setInt(11,msisdnDataBean.getListbean().getCorpDetailBean().getCorpId());
						cstmt.setString(12,msisdnDataBean.getListbean().getCorpDetailBean().getCorpName());
						cstmt.setString(13,imsi);
						cstmt.setInt(14,rbtCode);
						cstmt.setString(15,passwd);						
						cstmt.setInt(16,ts.getDay());
						cstmt.setInt(17,ts.getStartTime());
						cstmt.setInt(18,ts.getEndTime());
						cstmt.registerOutParameter(19,java.sql.Types.INTEGER);
						cstmt.registerOutParameter(20,java.sql.Types.INTEGER);
						cstmt.execute();
						int retStatusSub = cstmt.getInt(19);
						logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] status returned from CorpSubscribe procedure: ["+retStatusSub+"]");
						if(retStatusSub<0)
						{				
							//Charging done but not subscribed Error code =-23
							logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] charging done but not subscribed retStatusSub:["+retStatusSub+"]");
							return -23;
						}	
						corpSubSql=null;
			       }
			       else if(retVal ==-1 || retVal ==-2)//charging failure
			       {
			    	   logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+ "] could not be Charged, may be insufficient balance");
			    	   return -15;
			       }
			       else if(retVal ==-5)//timeout
			       {
			    	   logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] TCP/IP conection timeout occured");
			    	   return -7;
			       }
			       else if(retVal ==-6)//network read/write error
			       {
			    	   logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Read/Write error");
			    	   return -6;
			       }
			       else if(retVal ==-8)
			       {
			    	   logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Subtype Not found error");
			    	   return -12;
			       }
			       // added on 06-02-2017 starts
			       else if(retVal ==-97)
			       {	//input/output stream break error before request complete
			    	   logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"]input/output stream break error before request complete");
			    	   return -6;
			       }
			       else if(retVal == -98)
			       {	/////socket time out error
			    	   logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Socket Timeout Error!!");
			    	   return -7;
			       }
			       else if(retVal == -101)
			       {	////socket connection not established 
			    	   logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] socket connection to Charging is not established");
			    	   return -101;
			       }
			       else if(retVal ==-100)
			       {	//UNKNOWN_ERROR
			    	   logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Unknown Error!! Try later, Msisdn");
			    	   return -10;
			       }
			       //added on 06-02-2017 ends
			       else //
			       {
			    	   logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Try later, Msisdn");
			    	   //return -7;
			    	   return -10; //added on 06-02-2017
			       }
			       
			   logger.debug("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] sendsms:["+msisdnDataBean.getListbean().getSendSms()+"]");
		       if(msisdnDataBean.getListbean().getSendSms() == 'Y')
		       {
		    	   if (this.regeneratePass(msisdn,1,msisdnDataBean.getListbean().getLang()) != 1)
		    	   {		    		   
		    		   logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Error in sending sms");
		    		   return -16;
		    	   }
		       }
		       fnlchargeCode=null;
		       imsi=null;  
		       msisdn=null;
		       imsiBuf=null;
		       tcpCharge=null;
		       ts=null;
		       noGenerator=null;
		       passwd=null;
		       
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] value of MSISDN:["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] NullPointerException in addsubscriber() of class CorpManager ", npe);
			return -10;
		}
		catch(NumberFormatException nfe)
		{
			logger.error("[CRBT-BU-90004] value of MSISDN:["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] getting error while parsing String to Number Format in addsubscriber() of class CorpManager ", nfe);
			return -10;
		}
		catch(SQLException sqle)
		{
			logger.error("[CRBT-BU-90001] value of MSISDN:["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] getting error while DB operation in addsubscriber() of class CorpManager ", sqle);
			return -10;
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00034] value of MSISDN:["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"]  getting error in addsubscriber() of class CorpManager ", e);
			return -10;
		}			
		finally 
		{
			try
			{
				if(con!=null)
				{					
					con.close();					
				}
				if(pstmt!=null)
					pstmt.close();
				if(rs!=null)
					rs.close();
				con=null;
				pstmt=null;
				rs=null;
			}
			catch(Exception e) 
			{
					logger.info("[CRBT-BU-00035] value of MSISDN:["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Exception while closing DB resources in addsubscriber() of class CorpManager ",e);
			}
		}
		return 1;
	} //addsubscriber
	
	public char getSubType(String chargingMsisdn)
	{
			char retVal='N';			
			byte hlrReturn;
			//String msisdn="N/A";
			boolean sendtohlr = Global.SEND_TO_HLR;
			byte sourcetype= Global.SOURCE_TYPE; 
			try
			{
				if(sendtohlr==true && sourcetype==1)
				{	            
							   FetchMsrnBean fetchMsrnBean = new FetchMsrnBean();
                               fetchMsrnBean.setMsisdn(chargingMsisdn);
                               fetchMsrnBean.setService(6);
                               fetchMsrnBean.setVlr("");
                               fetchMsrnBean.setScfAddress("");
                               fetchMsrnBean.setBusyNumber("");
                               fetchMsrnBean.setNoReplyNumber("");
                               fetchMsrnBean.setUnreachableNumber("");
                               fetchMsrnBean.setMsrnBuf(new StringBuffer());
                               fetchMsrnBean.setImsiBuf(new StringBuffer());
                               fetchMsrnBean.setCfuActiveStr(new StringBuffer());
                               fetchMsrnBean.setServiceKey(0);
                               fetchMsrnBean.setMsrnError(0);
                               fetchMsrnBean.setRoaming(new Boolean(true));
                               fetchMsrnBean.setPrepaid(new Boolean(true));
                               fetchMsrnBean.setCfuActive(new Boolean(true));
                               logger.debug("MSISDN: "+fetchMsrnBean.getMsisdn()+"  chargingMsisdn:["+chargingMsisdn+"]");                              
                               hlrReturn = FetchMsrn.fetchmsrn(fetchMsrnBean);
                               logger.info("inside getSubType() MSISDN [" + fetchMsrnBean.getMsisdn() + "]  reponse from  HLR is Prepaid [P] Postpaid [O] || " + hlrReturn);
                               if(hlrReturn==1) //prepaid
                               {
                                  logger.info("##>>msisdn["+fetchMsrnBean.getMsisdn()+"] isPrepaid flag["+fetchMsrnBean.isPrepaid()+"]");                           
                                  retVal='P';
                                }
                                else if (hlrReturn == 2) //PostPaid
                                {                                	
                                	retVal='O';
                                }
                                else
                                {
                                	logger.info(fetchMsrnBean.getMsisdn()+"## Error return from HLR is " + hlrReturn);                                	
                                	retVal='N';  //chnaged from P to NA
                                }	
                               fetchMsrnBean=null;
				}				
				else if(sendtohlr==true && sourcetype==2)
				{
					TCPPacketCharging tcpCharge = new TCPPacketCharging();					
					interfaceType='T';
					reqbean.setMsisdn(chargingMsisdn);					
					reqbean.setRequestType((byte) 6);					
					reqbean.setInterfaceType(interfaceType);//interfaceType changed to "T" for this
					logger.info("inside getSubType() ChargingMsisdn ["+chargingMsisdn+"]  Request_type[6]");					
					if(Global.BIGTLV_ENABLE==true)
					{
						retVal= tcpCharge.sendRequestToChargingHLR(reqbean); //BigTlv 
					}
					else
					{
						retVal= tcpCharge.sendRequestToChargingHLR(reqbean,"TLvLib"); //simle TlvLib
					}
					tcpCharge=null;
				} //checking from charging
				else if(sourcetype==3)
				{
					retVal='P';
				}
				else if(sourcetype==4)
				{
					retVal='O';
				}
			    else
			    {
			    	//msisdn=chargingMsisdn;
			    	retVal= checkForSubType(chargingMsisdn);			    	
			    	if(retVal=='N' || retVal=='n' || retVal==0 )
			    	{
			    		logger.info(chargingMsisdn+" SubType not found from crbt_subscriber_master");
			    		retVal='N'; //changed from P to NA
			    	}
			    }	
			}
			catch(NullPointerException npe)
			{
				logger.error("[CRBT-BU-90003] NullPointerException in getSubType() of class CorpManager ",npe);
				retVal='N';
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00031] Exception in getSubType() of class CorpManager ",e);
				retVal='N';
			}
				return retVal;

	}//getSubType Ends
	
	public char checkForSubType(String msisdn)
    {
			logger.info("inside checkForSubType() MSISDN["+msisdn+"]");
            char subType='N';
			Connection con = null;
            PreparedStatement pstmt=null;
            ResultSet rs = null;
            String query = "";
            try
            {
            	if(con==null)
            	{
            		con =Global.conPool.getConnection();
            	}
            	query=DBQueries.SELECT_SUBTYPE_CRBT_SUBSCRIBER_MASTER;
                pstmt=con.prepareStatement(query);
                pstmt.setString(1,msisdn);
                pstmt.setQueryTimeout(Global.CON_TIME_OUT);
                rs=pstmt.executeQuery();
                if(rs.next())
                {
                	subType=rs.getString("SUB_TYPE").charAt(0);
                    logger.debug("###>> query:"+query+"    "+msisdn+"  ret_val DB SUBTYPE:"+subType);
                }
            }
            catch(SQLException sqle)
            {
            	logger.error("[CRBT-BU-90001] getting error during DB operation in checkForSubType() of class CorpManager ",sqle);
            }
            catch(NullPointerException npe)
            {
            	logger.error("[CRBT-BU-90003] getting error some value may be null in checkForSubType() of class CorpManager ",npe);
            }
            catch(Exception e)
            {
            	logger.error("[CRBT-BU-00036] value of MSISDN:[" + msisdn + "]  getting error in checkForSubType() of class CorpManager ", e);
            }
            finally
            {	
            	try
            	{
            		if(con!=null)
            		{            			
							con.close();
            		}
            		if(pstmt!=null)
            			pstmt.close();
            		if(rs!=null)
            			rs.close();
            		query=null;
            		con=null;
            		pstmt=null;
            		rs=null;
            	} 
            	catch (Exception e1) 
            	{	
            		logger.error("[CRBT-BU-00037] Exception while Closing DB resources in checkForSubType() of class CorpManager ",e1);
				}
            }
            return subType;
    }// checkForSubType Ends
		
	public byte regeneratePass(String msisdn, int act,byte lang)
	{
		logger.info("inside regeneratePass(): Msisdn:["+msisdn+"] act:["+act+"] lang:["+lang+"] ");
		String passwd="";
		String query="";	
		boolean conflag = false;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		try 
		{
			if(con==null)
			{
				con = Global.conPool.getConnection();
			}
				conflag = true;
				con.setAutoCommit(false);
			query=DBQueries.SELECT_MSISDN_CRBT_SUBSCRIBER_MASTER;
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, msisdn);
			pstmt.setQueryTimeout(Global.CON_TIME_OUT);
			rs = pstmt.executeQuery();
			logger.debug("Query in regeneratePass(Msisdn,action,lang): "+query);
			if (!rs.next())
			{
				rs.close();
				pstmt.close();
				return -1;
			}
			else 
			{
				Random noGenerator = new Random();
				passwd = "" + (noGenerator.nextInt(8999) + 1000);
				noGenerator=null;
			}
			rs.close();
			pstmt.close();
			String messageText= "You have been subscribed to the 'Digicel Intune's Service, your IVR password is " + passwd ;
			messageText=Global.MESSAGE;
			messageText=messageText+ passwd;
						
			if(Global.getSmsTemplates("300")!=null) 
			{			
				String messageString = Global.getSmsTemplates("300");
				int tempPos =0;
				tempPos = messageString.indexOf("$(password)");
				if(tempPos !=-1) 
				{
					messageText = messageString.substring(0,tempPos);
					messageText = messageText +passwd+messageString.substring(tempPos+11,messageString.length());
					//logger.info("1. "+messageText);
				}
				int tempPos2 = messageString.indexOf("$(tpin)");
				if(tempPos2 !=-1) 
				{
					messageText = messageText + messageString.substring(tempPos+11, tempPos2);				
					messageText = messageText + passwd;
					messageText = messageText + messageString.substring(tempPos2+7, messageString.length());
					//logger.info("2. "+messageText);
				}
				messageString=null;
			}
						
			String smsOriginNumber="132";
		
			smsOriginNumber = Global.getAppConfigParam("SMS_ORIGINATION_NUMBER"); //rbt for all new subscribers
			//logger.info("SmsOriginNumber:["+smsOriginNumber+"]");
			query=DBQueries.INSERT_GMAT_MESSAGE_STORE;
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, smsOriginNumber);
			pstmt.setString(2, msisdn);
			pstmt.setString(3, messageText);
			pstmt.setString(4, "R");
			logger.debug("Insert query GMAT_MESSAGE_STORE: Msisdn:["+msisdn+"] ");
			pstmt.setQueryTimeout(Global.CON_TIME_OUT);
			pstmt.executeUpdate();
			pstmt.close();
			query=DBQueries.UPDATE_CRBT_SUBSCRIBER_MASTER;
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, passwd);			
			pstmt.setString(2, passwd);
			pstmt.setString(3, msisdn);
			logger.debug("update query CRBT_SUBSCRIBER_MASTER: Msisdn:["+msisdn+"] ");
			pstmt.setQueryTimeout(Global.CON_TIME_OUT);
			pstmt.executeUpdate();
			pstmt.close();
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
			if (conflag) con.commit();
			passwd=null;
			messageText=null;
			smsOriginNumber=null;
			msisdn=null;
			return 1;
		}
		catch(NullPointerException npe)
        {	
			try
			{
				con.rollback();				
			} catch (Exception exp) 
			{
				logger.error("[CRBT-BU-00038] value of MSISDN:["+ msisdn +"]  getting error while rollback in regeneratePass(arg1,arg2,arg3) of class CorpManager ", exp);
				return 0;
			}
				logger.error("[CRBT-BU-90003] value of MSISDN:["+ msisdn +"] NullPointerException in regeneratePass(arg1,arg2,arg3) of class CorpManager ", npe);
				return 0;
        }
		catch(SQLException sqle)
        {	
			try
			{
				con.rollback();				
			} 
			catch (Exception exp) 
			{
				logger.error("[CRBT-BU-00039] value of MSISDN:["+ msisdn +"]  getting error while rollback in regeneratePass(arg1,arg2,arg3) of class CorpManager ", exp);
				return 0;
			}
				logger.error("[CRBT-BU-90001] value of MSISDN:["+ msisdn +"] getting error while DB operation in regeneratePass(arg1,arg2,arg3) of class CorpManager ", sqle);
				return 0;
        }
		catch(StringIndexOutOfBoundsException siobe)
        {	
			try
			{
				con.rollback();				
			} 
			catch (Exception exp) 
			{
				logger.error("[CRBT-BU-00040] value of MSISDN:["+ msisdn +"]  getting error while rollback in regeneratePass(arg1,arg2,arg3) of class CorpManager ", exp);
				return 0;
			}
				logger.error("[CRBT-BU-90010] value of MSISDN:["+ msisdn +"] getting error while String operation(index/substring) in regeneratePass(arg1,arg2,arg3) of class CorpManager ", siobe);
				return 0;
        }		
		catch(Exception e)
        {	
			try
			{
				con.rollback();
			} catch (Exception exp) 
			{
				logger.error("[CRBT-BU-00041] value of MSISDN:["+ msisdn +"]  getting error while rollback in regeneratePass(arg1,arg2,arg3) of class CorpManager ", exp);
				return 0;
			}
				logger.error("[CRBT-BU-00042] value of MSISDN:["+ msisdn +"] getting error in regeneratePass(arg1,arg2,arg3) of class CorpManager ", e);
				return 0;
        }
		finally
		{
				try {
					if (conflag){
						if(con!=null)
						{
							con.close();
						}
					}	
					con=null;
				} catch (Exception e) {		
					logger.error("[CRBT-BU-00043] value of MSISDN:["+ msisdn +"] getting error while closing of DB resources in regeneratePass(arg1,arg2,arg3) of class CorpManager ", e);					
				}
		}
	} //regeneratePass() ENDS
	
	private int cfuProcess(String interMsisdn, StringBuffer imsi, int service)
	{
		//added for testing starts 
 		if(Global.HLR_TEST_CASE==1)
 		{
 			return 1;
 		}
 		//added for testing ends
 		
					logger.debug(" In function cfuProcess() ");					
					if(Global.DOACTDEACT == true) 
					{									
									FetchMsrnBean fetchMsrnBean = new FetchMsrnBean();
									fetchMsrnBean.setService(service);
									fetchMsrnBean.setMsisdn(interMsisdn);
									fetchMsrnBean.setMsrnBuf(new StringBuffer());
									fetchMsrnBean.setVlr("");
									fetchMsrnBean.setImsiBuf(imsi);
									fetchMsrnBean.setScfAddress("");
									fetchMsrnBean.setServiceKey(new Integer(0));
									fetchMsrnBean.setRoaming(new Boolean(true));
									fetchMsrnBean.setPrepaid(new Boolean(true));
									fetchMsrnBean.setMsrnError(new Integer(0));
									fetchMsrnBean.setBusyNumber("");
									fetchMsrnBean.setNoReplyNumber("");
									fetchMsrnBean.setUnreachableNumber("");
									fetchMsrnBean.setCfuActive(new Boolean(true));
									fetchMsrnBean.setCfuActiveStr(new StringBuffer());
								
									int activateStatus = FetchMsrn.fetchmsrn(fetchMsrnBean);								
									if(activateStatus <0)  
									{
													logger.info("\nThere was some error [" + fetchMsrnBean.getMsrnError().intValue() +"] in activate/deactivateSS\n");
													fetchMsrnBean=null;
													return 0;
									}
									fetchMsrnBean=null;
									return 1;
					}
					else
					{
									logger.info(interMsisdn+" DOACTDEACT is disable from property file");									
									return -10;
					}
	}//cfuProcess
	
	public String unsubscribe(ListDataBean msisdnDataBean)
	{ 
		logger.debug("in unsubscribe()"+msisdnDataBean);
		String msisdn=msisdnDataBean.getMsisdn();
		String userId=msisdnDataBean.getListbean().getUserId();
		int corpid=msisdnDataBean.getListbean().getCorpDetailBean().getCorpId();
		String corpName=msisdnDataBean.getListbean().getCorpDetailBean().getCorpName();
		StringBuffer imsiBuf = new StringBuffer();
		String status = "failure";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CallableStatement cstmt = null;
		int retResponse = -1;
		int retStatus=-1;
		String corpUnsubSql = null;
		logger.info("["+msisdn+"_"+corpid+"_"+msisdnDataBean.getListbean().getReqId()+"] in unsubscribe() ");
		try 
		{
			if(con==null)
			{
				con = Global.conPool.getConnection();
			}
		/*	String corpUnsubSql = null;*/
			if(Global.PROC_PACKAGE==0)
			{	
				if(Global.dbType.equalsIgnoreCase("ORACLE"))
				{
				corpUnsubSql = "{call CRBTNEW.CorpUnsubscribe (?,?,?,?,?,?,?)}";
				}
				else
				{
					logger.info("The unsubscribe procedure call =================");
				    corpUnsubSql = "{ call CorpUnsubscribe (?,?,?,?,?,?,?)}";
				}
			}
			else
			{
				if(Global.dbType.equalsIgnoreCase("ORACLE"))
			
			      {
				   corpUnsubSql = "{call CRBTCORPBULKUPLOAD.CorpUnsubscribe (?,?,?,?,?,?,?)}";
				  }
				else
				  {
				   corpUnsubSql ="{call CorpUnsubscribe(?,?,?,?,?,?,?) }";
				  }
			}	
			cstmt = con.prepareCall(corpUnsubSql);
			cstmt.setString(1,msisdn);
			cstmt.setString(2,userId); //updatedBy
			cstmt.setInt(3,corpid);
			cstmt.setString(4,corpName);
			cstmt.registerOutParameter(5,java.sql.Types.INTEGER);
			cstmt.registerOutParameter(6,java.sql.Types.INTEGER);
			cstmt.registerOutParameter(7,java.sql.Types.INTEGER);
			cstmt.execute();
			retResponse = cstmt.getInt(6); //getting p_response from procedure
			retStatus = cstmt.getInt(5);
			//retResponse = -24 means Msisdn is already subscribed
			if(retResponse==-24)
			{
				logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Not corp subscriber, response returned from unsubscribe procedure:["+retResponse+"] status:["+retStatus+"]");				
				/*msisdnDataBean.setDescription("not a subscriber");	*/
				msisdnDataBean.setDescription(BulkUploadServerMessages.NOT_SUBSCRIBED);	
				return "failure";
			}			
			else if(retResponse==-23)
			{
				logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Unsubscribed but log not maintained, response returned from unsubscribe procedure:["+retResponse+"] status:["+retStatus+"]");	
			}
			else if(retResponse<0)
			{
				logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Error occured while unsubscribe,  response returned from unsubscribe procedure:["+retResponse+"] status:["+retStatus+"]");
				/*msisdnDataBean.setDescription("Error occured");	*/
				msisdnDataBean.setDescription(BulkUploadServerMessages.UNKNOWN_ERROR);	
				return "failure";
			}
			corpUnsubSql =null;
			logger.info("["+msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+"] ListId:["+msisdnDataBean.getListId()+"] Unsubscribed successfully from procedure, response returned from unsubscribe procedure:["+retResponse+"] status:["+retStatus+"]");
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] value of MSISDN:["+msisdn+"] some value may be null, getting error in unsubscribe() of class CorpManager ", npe);
			status = "failure";
			/*msisdnDataBean.setDescription("Error Occured");*/
			msisdnDataBean.setDescription(BulkUploadServerMessages.UNKNOWN_ERROR);
			return status;
		}
		catch(SQLException sqle)
		{
			logger.error("[CRBT-BU-90001] value of MSISDN:["+msisdn+"]  getting error while DB operation in unsubscribe() of class CorpManager ", sqle);
			status = "failure";			
			/*msisdnDataBean.setDescription("DB Error Occured");*/
			msisdnDataBean.setDescription(BulkUploadServerMessages.DB_ERROR);
			return status;
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00032] value of MSISDN:["+msisdn+"] getting error in unsubscribe() of class CorpManager ", e);
			status = "failure";
			/*msisdnDataBean.setDescription("Error Occured");*/
			msisdnDataBean.setDescription(BulkUploadServerMessages.UNKNOWN_ERROR);
			return status;
		}
		finally 
		{
			try
			{				
				if(rs!=null)
					rs.close();
				if(pstmt!=null)
					pstmt.close();
				if(con!=null)
				{
					con.close();					
				}
				rs=null;
				pstmt=null;
				con=null;			
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00044] Exception while closing of DB resources in unsubscribe() of class CorpManager ",e);
			}
		}
		if(Global.UNSUB_HLR_CONFIG==false)
		{
				int hlrRet = insertIntoCrbtHlrInactive(msisdn,interfaceType,4);
				logger.info(msisdnDataBean.getMsisdn()+"_"+msisdnDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+msisdnDataBean.getListbean().getReqId()+ " ListId:["+msisdnDataBean.getListId()+"] retVal from InsertIntoCrbtHlrInactive():["+hlrRet+"] ");
				if(hlrRet==1)
				{
					status = "success";
					if(retResponse==-23)
						/*msisdnDataBean.setDescription("unsubscribed successfully but log not maintained");*/
						msisdnDataBean.setDescription(BulkUploadServerMessages.UNSUB_SUCCESS_LOG_ERROR);
					else if(retResponse>0)
						/*msisdnDataBean.setDescription("unsubscribed successfully");*/
						msisdnDataBean.setDescription(BulkUploadServerMessages.UNSUB_SUCCESS);
				}
				else
				{
					status = "success";
					if(retResponse==-23)
						/*msisdnDataBean.setDescription("unsubscribed successfully but logCheckForCorpSubscription.sql not maintained and CFU couldnot be deactivated");*/
						msisdnDataBean.setDescription(BulkUploadServerMessages.UNSUB_SUCCES_LOG_HLR_ERROR);
					else if(retResponse>0)
						/*msisdnDataBean.setDescription("unsubscribed successfully but CFU couldnot be deactivated");*/
						msisdnDataBean.setDescription(BulkUploadServerMessages.UNSUB_SUCCESS_HLR_ERROR);
				}	
		}		
		else
		{
		   if (cfuProcess(msisdn, imsiBuf, SERVICE_DEACTIVATE_SS) != 1)
		   {
			   	status = "success";
			   	if(retResponse==-23)
					/*msisdnDataBean.setDescription("unsubscribed successfully but log not maintained and CFU couldnot be deactivated");*/
			   		msisdnDataBean.setDescription(BulkUploadServerMessages.UNSUB_SUCCES_LOG_HLR_ERROR);
				else if(retResponse>0)
					/*msisdnDataBean.setDescription("unsubscribed successfully but CFU couldnot be deactivated");*/
					msisdnDataBean.setDescription(BulkUploadServerMessages.UNSUB_SUCCESS_HLR_ERROR);
				return status;
		   }
		   status = "success";
		   if(retResponse==-23)
				/*msisdnDataBean.setDescription("unsubscribed successfully but log not maintained");*/
			   msisdnDataBean.setDescription(BulkUploadServerMessages.UNSUB_SUCCESS_LOG_ERROR);
			else if(retResponse>0)
				/*msisdnDataBean.setDescription("unsubscribed successfully");*/
				msisdnDataBean.setDescription(BulkUploadServerMessages.UNSUB_SUCCESS);
		} 
		msisdn=null;
		userId=null;
		corpName=null;
		imsiBuf=null;
		corpName=null; 
		   return status;
		} //unsubscribe
	
	public int insertIntoCrbtHlrInactive(String msisdn,char byInterface,int reqId)
	{
		logger.info("inside InsertIntoCrbtHlrInactive() Interface:["+byInterface+"] Msisdn:["+msisdn+"] reqId:["+reqId+"]");
		Connection con = null;
		PreparedStatement pstmt=null;		
		String query=null; 
	
		
		query=DBQueries.INSERT_INTO_CRBT_HLR_INACTIVE;
		try
		{
			con = Global.conPool.getConnection();
			pstmt=con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			pstmt.setInt(2,reqId);			
			pstmt.setString(3,String.valueOf(interfaceType));
			pstmt.executeUpdate();						
		}
		catch(SQLException sqle)
		{
			logger.error("SQLException in insertIntoCrbtHlrInactive() of class CorpManager: "+sqle.getErrorCode() + " State:["+sqle.getMessage()+"]");
			int errorCode = sqle.getErrorCode();
			if(errorCode==1)
			{
				logger.error("SQLException due to unique constraint on MSISDN and REQ_ID column in CRBT_HLR_INACTIVE as 1 record is already there ");
				return 1;
			}
			logger.error("[CRBT-BU-90001] SQLException in insertIntoCrbtHlrInactive() of class CorpManager: ",sqle);
			return -1;
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00074] Exception in insertIntoCrbtHlrInactive() of class CorpManager ",e);			
			return -1;
		}
		finally
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(con!=null)
					con.close();
				query=null;
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00075] Exception while closing of DB Resources in InsertIntoCrbtHlrInactive() of class CorpManager ",e);
				e.printStackTrace();
			}
		}
		
		return 1;
	}//InsertIntoCrbtHlrInactive() ends
	
}
