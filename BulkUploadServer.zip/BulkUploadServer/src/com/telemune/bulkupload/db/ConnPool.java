package com.telemune.bulkupload.db;

import FileBaseLogging.*;
import java.io.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import org.apache.log4j.*;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class ConnPool
{
	private static final Logger logger=Logger.getLogger(ConnPool.class);
	static ComboPooledDataSource cpds = null;//new ComboPooledDataSource();

	String driver;
	String url;
	String username;
	String passwd;
	int minpoolsize;
	int maxpoolsize;
	int Accomodation;
	int conIdleTimeOut;
        
	public ConnPool(String driver,String url,String username,String passwd,int minpoolsize,int maxpoolsize,int Accomodation,int conIdleTimeOut)
	{
		this.driver=driver;
		this.url=url;
		this.username=username;
		this.passwd=passwd;
		this.minpoolsize=minpoolsize;
		this.maxpoolsize=maxpoolsize;
		this.Accomodation=Accomodation;
		this.conIdleTimeOut=conIdleTimeOut;
	}


	public void MakePool()
	{
		try 
		{
			cpds=new ComboPooledDataSource();
			cpds.setDriverClass(driver);
			cpds.setJdbcUrl(url);
			cpds.setUser(username);
			cpds.setPassword(passwd);
			cpds.setMaxPoolSize(maxpoolsize);
			cpds.setMinPoolSize(minpoolsize);			
			cpds.setAcquireIncrement(Accomodation);
			cpds.setMaxStatementsPerConnection(25);
			cpds.setMaxIdleTime(conIdleTimeOut);
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] NullPointerException cpds:["+cpds+"] may be null in MakePool() of class ConnPool ",npe);
		}
		catch (Exception ex) 
		{
			logger.error("[CRBT-BU-00015] Exception in MakePool() of class ConnPool ",ex);
		}
	}
	public synchronized Connection getConnection()
	{
		Connection con=null;
		try{
			//System.out.println("Number Of Busy Connection["+cpds.getNumBusyConnections()+"] NumberofUnclosedConnection["+cpds.getNumUnclosedOrphanedConnectionsDefaultUser()+"] ");
		
			con= cpds.getConnection();
		}		
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] NullPointerException cpds:["+cpds+"] may be null in getConnection() of class ConnPool ",npe);
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00016] Exception in getConnection() of class ConnPool ",e);
		}
		return con;
	}

       public synchronized Connection getConnection(String name)
       {
                Connection con=null;
                try{
                	//System.out.println("Number Of Busy Connection["+cpds.getNumBusyConnections()+"] name["+name+"]");
                        con= cpds.getConnection();
                }
        		catch(NullPointerException npe)
        		{
        			logger.error("[CRBT-BU-90003] NullPointerException cpds:["+cpds+"] may be null in getConnection(args) of class ConnPool ",npe);
        		}
                catch(Exception e)
                {
                		logger.error("[CRBT-BU-00017] Exception in getConnection(args) of class ConnPool ",e);
                }
                return con;
        }
}
