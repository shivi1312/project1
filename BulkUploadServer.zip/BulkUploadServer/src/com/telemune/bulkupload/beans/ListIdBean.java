package com.telemune.bulkupload.beans;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class ListIdBean 
{	
	private String listId;
	private String userId;
	private String action;
	private String scope;
	private String createDate;
	private String requestType;
	private char lidStatus;
	private int totalReqCount;
	private byte reqId;	
	private byte lang;
	private char sendSms;
	private int successCount;
	private int failCount;
	
	private CorpDetailBean corpDetailBean;
			
	public String getListId() {
		return listId;
	}
	public void setListId(String listId) {
		this.listId = listId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
		
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public char getLidStatus() {
		return lidStatus;
	}
	public void setLidStatus(char lidStatus) {
		this.lidStatus = lidStatus;
	}
	public int getTotalReqCount() {
		return totalReqCount;
	}
	public void setTotalReqCount(int totalReqCount) {
		this.totalReqCount = totalReqCount;
	}
	public byte getReqId() {
		return reqId;
	}
	public void setReqId(byte reqId) {
		this.reqId = reqId;
	}
	
	
	public byte getLang() {
		return lang;
	}
	public void setLang(byte lang) {
		this.lang = lang;
	}
	public char getSendSms() {
		return sendSms;
	}
	public void setSendSms(char sendSms) {
		this.sendSms = sendSms;
	}
	
	public int getSuccessCount() {
		return successCount;
	}
	public void setSuccessCount(int successCount) {
		this.successCount = successCount;
	}
	public int getFailCount() {
		return failCount;
	}
	public void setFailCount(int failCount) {
		this.failCount = failCount;
	}
	
	
		
	public CorpDetailBean getCorpDetailBean() {
		return corpDetailBean;
	}
	public void setCorpDetailBean(CorpDetailBean corpDetailBean) {
		this.corpDetailBean = corpDetailBean;
	}
	@Override
	public String toString() {		
		return "listId["+listId+"] userId["+userId+"] action["+action+"]   scope["+scope+"] createDate:["+createDate+"] requestType:["+requestType+"]  lidStatus:["+lidStatus+"] totalReqCount:["+totalReqCount+"] reqId:["+reqId+"] CorpDetailBean:["+corpDetailBean+"] language:["+lang+"] sendSms:["+sendSms+"] successCount:["+successCount+"] failCount:["+failCount+"]" ;
	}
	

}
