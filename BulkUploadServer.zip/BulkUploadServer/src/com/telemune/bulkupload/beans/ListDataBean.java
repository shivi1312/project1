package com.telemune.bulkupload.beans;


public class ListDataBean {
	
	private String listId;
	private String msisdn;	
	private char msisdnStatus;
	private char Interface;
	private ListIdBean listbean;
	private char subtype;
    private String description = "";

    public String getListId() {
		return listId;
	}
	public void setListId(String listId) {
		this.listId = listId;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	
	public char getMsisdnStatus() {
		return msisdnStatus;
	}
	public void setMsisdnStatus(char msisdnStatus) {
		this.msisdnStatus = msisdnStatus;
	}
	public char getInterface() {
		return Interface;
	}
	public void setInterface(char interface1) {
		Interface = interface1;
	}
	public ListIdBean getListbean() {
		return listbean;
	}
	public void setListbean(ListIdBean listbean) {
		this.listbean = listbean;
	}
	
	public char getSubtype() {
		return subtype;
	}
	public void setSubtype(char subtype) {
		this.subtype = subtype;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
    
   
	@Override
	public String toString() {
		return "listId["+listId+"] msisdn["+msisdn+"] msisdnstatus["+msisdnStatus+"]   Interface["+Interface+"] Corp Name["+listbean.getCorpDetailBean().getCorpName()+"] corpId["+listbean.getCorpDetailBean().getCorpId()+"] description:["+description+"] subtype:["+subtype+"]";
	}

	
}
