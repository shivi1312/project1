/*
 * This class is used for user authentication for the web interface for CRBT. 
 *
 *
 *
 */

package com.telemune.bulkupload.beans;

public class ToneSetting {
	
	private int rbtCode=0;
	private byte day=8;
	private short startTime=2500;
	private short endTime=2500;
	
	public int getRbtCode() {
		return rbtCode;
	}
	public void setRbtCode(int rbtCode) {
		this.rbtCode = rbtCode;
	}
	public byte getDay() {
		return day;
	}
	public void setDay(byte day) {
		this.day = day;
	}
	public short getStartTime() {
		return startTime;
	}
	public void setStartTime(short startTime) {
		this.startTime = startTime;
	}
	public short getEndTime() {
		return endTime;
	}
	public void setEndTime(short endTime) {
		this.endTime = endTime;
	}

	 
	@Override
	public String toString() {
		return "rbtCode:["+rbtCode+"] day:["+day+"] startTime:["+startTime+"] endTime:["+endTime+"] " ;
	}
}
