package com.telemune.bulkupload.beans;

public class FetchMsrnBean 
{
	private int service;
	private String msisdn ;	
	private String vlr="";
	private String scfAddress="";
	private String busyNumber="";
	private String noReplyNumber="";
	private String unreachableNumber="";
	private StringBuffer msrnBuf;
	private StringBuffer imsiBuf;
	private StringBuffer cfuActiveStr;	
	private int serviceKey=0;	
	private Integer msrnError=0;	
	private Boolean cfuActive=true;
	private Boolean isRoaming=true;
	private Boolean isPrepaid=true;
	
	public int getService() {
		return service;
	}
	public void setService(int service) {
		this.service = service;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getVlr() {
		return vlr;
	}
	public void setVlr(String vlr) {
		this.vlr = vlr;
	}
	public String getScfAddress() {
		return scfAddress;
	}
	public void setScfAddress(String scfAddress) {
		this.scfAddress = scfAddress;
	}
	public String getBusyNumber() {
		return busyNumber;
	}
	public void setBusyNumber(String busyNumber) {
		this.busyNumber = busyNumber;
	}
	public String getNoReplyNumber() {
		return noReplyNumber;
	}
	public void setNoReplyNumber(String noReplyNumber) {
		this.noReplyNumber = noReplyNumber;
	}
	public String getUnreachableNumber() {
		return unreachableNumber;
	}
	public void setUnreachableNumber(String unreachableNumber) {
		this.unreachableNumber = unreachableNumber;
	}
	public StringBuffer getMsrnBuf() {
		return msrnBuf;
	}
	public void setMsrnBuf(StringBuffer msrnBuf) {
		this.msrnBuf = msrnBuf;
	}
	public StringBuffer getImsiBuf() {
		return imsiBuf;
	}
	public void setImsiBuf(StringBuffer imsiBuf) {
		this.imsiBuf = imsiBuf;
	}
	public StringBuffer getCfuActiveStr() {
		return cfuActiveStr;
	}
	public void setCfuActiveStr(StringBuffer cfuActiveStr) {
		this.cfuActiveStr = cfuActiveStr;
	}
	public int getServiceKey() {
		return serviceKey;
	}
	public void setServiceKey(int serviceKey) {
		this.serviceKey = serviceKey;
	}
	public Integer getMsrnError() {
		return msrnError;
	}
	public void setMsrnError(Integer msrnError) {
		this.msrnError = msrnError;
	}
	public Boolean isCfuActive() {
		return cfuActive;
	}
	public void setCfuActive(Boolean cfuActive) {
		this.cfuActive = cfuActive;
	}
	public Boolean isRoaming() {
		return isRoaming;
	}
	public void setRoaming(Boolean isRoaming) {
		this.isRoaming = isRoaming;
	}
	public Boolean isPrepaid() {
		return isPrepaid;
	}
	public void setPrepaid(Boolean isPrepaid) {
		this.isPrepaid = isPrepaid;
	}
	
	@Override
	public String toString() {	
		return "msisdn:[" +msisdn+"] vlr:["+vlr+"] scfAddress:["+scfAddress+"] busyNumber:["+busyNumber+"] noReplyNumber:["+noReplyNumber+"] unreachableNumber:["+unreachableNumber+"] msrnBuf:["+msrnBuf+"] imsiBuf:["+imsiBuf+"] cfuActiveStr:["+cfuActiveStr+"] serviceKey:["+serviceKey+"] msrnError:["+msrnError+"] cfuActive:["+cfuActive+"] isRoaming:["+isRoaming+"] isPrepaid:["+isPrepaid+"] ";
	}
	
	

}
