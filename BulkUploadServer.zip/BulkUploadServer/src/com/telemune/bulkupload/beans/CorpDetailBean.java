package com.telemune.bulkupload.beans;

/*
 * Bean containing Corporate Information 
 */

public class CorpDetailBean 
{
	private int corpId=-1;
	private String corpName;
	private short plan;
	private char corpSubType;	
	private String chargingMsisdn;
	private String chargingCode;
	private int totcap;
	private String corpScope;
		
	public int getCorpId() {
		return corpId;
	}
	
	public void setCorpId(int corpId) {
		this.corpId = corpId;
	}
	
	public String getCorpName() {
		return corpName;
	}

	public void setCorpName(String corpName) {
		this.corpName = corpName;
	}

	public short getPlan() {
		return plan;
	}

	public void setPlan(short plan) {
		this.plan = plan;
	}

	public char getCorpSubType() {
		return corpSubType;
	}

	public void setCorpSubType(char corpSubType) {
		this.corpSubType = corpSubType;
	}

	public String getChargingMsisdn() {
		return chargingMsisdn;
	}

	public void setChargingMsisdn(String chargingMsisdn) {
		this.chargingMsisdn = chargingMsisdn;
	}

	public String getChargingCode() {
		return chargingCode;
	}

	public void setChargingCode(String chargingCode) {
		this.chargingCode = chargingCode;
	}

	public int getTotcap() {
		return totcap;
	}

	public void setTotcap(int totcap) {
		this.totcap = totcap;
	}

	public String getScopeCorp() {
		return corpScope;
	}

	public void setScopeCorp(String scopeCorp) {
		this.corpScope = scopeCorp;
	}

	@Override
	public String toString() 
	{	
		return "plan:["+plan+"] corpSubType:["+corpSubType+"] chargingMsisdn:["+chargingMsisdn+"] chargingCode:["+chargingCode+"] totcap:["+totcap+"] scopeCorp:["+corpScope+"] corpId:["+corpId+"] corpName:["+corpName+"]";
	}
	
}
