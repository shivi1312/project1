package com.telemune.bulkupload.beans;

public class RequestResponseBean
{
	private String msisdn;
	private byte requestType;
	private byte action;
	private int corpId;
	private int rbtcode;
	private int tarrifId;
	private String starrifId;
	private String fMsisdn;
	private char interfaceType;
	private short response;
	private char subType;

	public String getMsisdn() 
	{
		return msisdn;
	}
	public void setMsisdn(String msisdn)
	{
		this.msisdn = msisdn;
	}
	public byte getRequestType() {
		return requestType;
	}
	public void setRequestType(byte requestType) {
		this.requestType = requestType;
	}
	public byte getAction() 
	{
		return action;
	}
	public void setAction(byte action) 
	{
		this.action = action;
	}
	public int getCorpId() {
		return corpId;
	}
	public void setCorpId(int corpId) {
		this.corpId = corpId;
	}
	public int getRbtcode() 
	{
		return rbtcode;
	}
	public void setRbtcode(int rbtcode) 
	{
		this.rbtcode = rbtcode;
	}
	public int getTarrifId() {
		return tarrifId;
	}
	public void setTarrifId(int tarrifId) {
		this.tarrifId = tarrifId;
	}
	public String getStarrifId() {
		return starrifId;
	}
	public void setStarrifId(String starrifId) {
		this.starrifId = starrifId;
	}
	public String getfMsisdn() {
		return fMsisdn;
	}
	public void setfMsisdn(String fMsisdn) {
		this.fMsisdn = fMsisdn;
	}
	public char getInterfaceType() {
		return interfaceType;
	}
	public void setInterfaceType(char interfaceType) {
		this.interfaceType = interfaceType;
	}
	public char getSubType() {
		return subType;
	}
	public void setSubType(char subType) {
		this.subType = subType;
	}
	public short getResponse() 
	{
		return response;
	}
	public void setResponse(short response) 
	{
		this.response = response;
	}
	
	@Override
	public String toString()
	{
		return "msisdn:["+msisdn+"] requestType:["+requestType+"] action:["+action+"] corpId:["+corpId+"] rbtcode:["+rbtcode+"] tarrifId:["+tarrifId+"] starrifId:["+starrifId+"] fMsisdn:["+fMsisdn+"] interfaceType:["+interfaceType+"] response:["+response+"] subType:["+subType+"] " ;
	}

}
