package com.telemune.bulkupload.threads;

import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import com.telemune.bulkupload.beans.ListDataBean;
import com.telemune.bulkupload.common.Global;

/**
 * 
 * @author Ashish This class Read data from queue and opens new thread to
 *         process that request
 * 
 */

public class CorpQueueReader implements Runnable 
{
	private static final Logger logger = Logger.getLogger(CorpQueueReader.class);
	ThreadPoolExecutor bulkexecutorPool = null;
	ListDataBean dataBean = null;
	public CorpQueueReader(ThreadPoolExecutor bulkexecutorPool) 
	{
		this.bulkexecutorPool = bulkexecutorPool;		
	}

	/**
	 * this function check for queue is empty or not and then opens new thared
	 * to peocess the request
	 */
	public void readQueueData() 
	{
		while (true) {
			try {
				if (Global.readerQueue.isEmpty()) {
					try 
					{
						logger.debug("reqderQueue is Empty");
						Thread.sleep(Global.READER_QUEUE_SLEEP_TIME*1000); //readerQueueEmpty is configurable in property file in seconds
					}
					catch (Exception e) 
					{
						logger.error("[CRBT-BU-00061] Error while intrupt thread in readQueueData() of class CorpQueueReader ",e);
					}
				} else 
				{								
					while(this.bulkexecutorPool.getActiveCount()==Global.MAX_CONTENT_THREAD)
					{
						Thread.sleep(1);
					}
					this.dataBean = Global.readerQueue.poll();					
					this.bulkexecutorPool.execute(new CorpRequestProcessor(this.dataBean));	
					
				}

			}
			catch (Exception e)
			{
				logger.error("[CRBT-BU-00062] Error in Reading data from Queue in readQueueData() of class CorpQueueReader ", e);
			}
		}//while loop ends
	}

	public void run() 
	{
		readQueueData();
	}

}
