package com.telemune.bulkupload.threads;

//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
import java.util.concurrent.ThreadPoolExecutor;


import org.apache.log4j.Logger;

import com.telemune.bulkupload.beans.ListDataBean;
import com.telemune.bulkupload.common.Global;

import FileBaseLogging.FileLogWriter;

public class ResponseQueueReader implements Runnable 
{	
	private static final Logger logger = Logger.getLogger(ResponseQueueReader.class);
	FileLogWriter flwUpdationfail = null;
	ThreadPoolExecutor responseBulkexecutorPool = null; //added on 11-01-2017
	
	public ResponseQueueReader(ThreadPoolExecutor responseBulkexecutorPool,FileLogWriter flwUpdationfail)
	{
		this.responseBulkexecutorPool=responseBulkexecutorPool;
		this.flwUpdationfail = flwUpdationfail;
	}
	
	public void run() 
	{
		readQueueData();
	}//run() ends
	
	public void readQueueData()
	{
		logger.info("Inside readQueueData() of class ResponseQueueReader ");		
		ListDataBean listDataBean = null;
		
		try
		{	
			while(true)
			{
				if (Global.responseQueue.isEmpty())
				{
					try
					{		
						logger.debug("responseQueue is Empty");
						logger.info("responseQueue is Empty");
						Thread.sleep(Global.RESPONSE_QUEUE_SLEEP_TIME*1000); //responseQueueEmpty is configurable in property file in seconds
					}
					catch(Exception e)
					{
						logger.error("[CRBT-BU-00068] Error while Intruption of thread inside readQueueData() check weather it is empty or not  ",e);												
					}
				}
				else
				{					
					/*listDataBean = Global.responseQueue.poll();					
					updateJobListStatus(listDataBean);*/ //commented on 11-01-2017
					
					while(this.responseBulkexecutorPool.getActiveCount()==Global.MAX_RESPONSE_POOL_THREAD)
					{
						Thread.sleep(1);
					}
					listDataBean = Global.responseQueue.poll();					
					this.responseBulkexecutorPool.execute(new ResponseQueueProcessor(listDataBean,flwUpdationfail));
					
				}
				
			}//while(true)
			
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00069] Exception in readQueueData() of class ResponseQueueReader ",e);			
		}		
	}//readQueueData() 
		
	/*private void updateJobListStatus(ListDataBean listDataBean)  
	{
		logger.info("["+listDataBean.getMsisdn()+"_"+listDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+listDataBean.getListbean().getReqId()+"] inside updateJobListStatus() of class ResponseQueueReader Msisdn Status:["+listDataBean.getMsisdnStatus()+"] Description:["+listDataBean.getDescription()+"]");
		Connection con = null;
		PreparedStatement pstmt= null;
		//String query = "update JOB_LIST_DETAILS set STATUS=? ,RESPONSE_STRING=?,UPDATE_DATE=sysdate where MSISDN=? and LIST_ID=?";
		String query = "update JOB_LIST_DETAILS set STATUS=? ,RESPONSE_STRING=?,UPDATE_DATE=sysdate where LIST_ID=? AND MSISDN=?";
		try
		{
			logger.debug("["+listDataBean.getMsisdn()+"_"+listDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+listDataBean.getListbean().getReqId()+"] ListId:["+listDataBean.getListbean().getListId()+"] Status:["+listDataBean.getMsisdnStatus()+"] Description:["+listDataBean.getDescription()+"]");		
			con = Global.conPool.getConnection();
			pstmt = con.prepareStatement(query);
			//added on 11-01-2017 starts
			if(listDataBean.getMsisdnStatus()=='F' || listDataBean.getMsisdnStatus()=='f')
			{		
				synchronized (flw_updationfail) 
				{
					flw_updationfail.writeLog(listDataBean.getListbean().getListId()+","+listDataBean.getMsisdn()+","+listDataBean.getMsisdnStatus()+","+listDataBean.getDescription());
				}				
			}
			//added on 11-01-2017 ends 
			
			pstmt.setString(1,String.valueOf(listDataBean.getMsisdnStatus()));
			pstmt.setString(2,listDataBean.getDescription());
			pstmt.setString(3,listDataBean.getListbean().getListId());
			pstmt.setString(4,listDataBean.getMsisdn());		
			
			logger.debug("Query in updateJobListStatus() of class ResponseQueueReader: "+query);
			pstmt.executeUpdate();
			pstmt.close();
			
			if(listDataBean.getMsisdnStatus()=='S' || listDataBean.getMsisdnStatus()=='s')
			{			
				query= "UPDATE JOB_DETAILS SET TOTAL_SUCC_COUNT=TOTAL_SUCC_COUNT+1 WHERE LIST_ID=?";
			}			
			else if(listDataBean.getMsisdnStatus()=='F' || listDataBean.getMsisdnStatus()=='f')
			{
				query="UPDATE JOB_DETAILS SET TOTAL_FAIL_COUNT=TOTAL_FAIL_COUNT+1 WHERE LIST_ID=?";
				flw_updationfail.writeLog(listDataBean.getListbean().getListId()+","+listDataBean.getMsisdn()+","+listDataBean.getMsisdnStatus()+","+listDataBean.getDescription());
			}			
			pstmt = con.prepareStatement(query);			
			logger.debug("query update:  "+query);		
			pstmt.setString(1,listDataBean.getListbean().getListId());
			pstmt.executeUpdate(); //commented on 11-01-2017
			logger.info("["+listDataBean.getMsisdn()+"_"+listDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+listDataBean.getListbean().getReqId()+"] successfully update status in updateJobListStatus() of class ResponseQueueReader ");			
		}
		catch(SQLException sqle)
		{		
			synchronized (flw_updationfail) 
			{
				flw_updationfail.writeLog(listDataBean.getListbean().getListId()+","+listDataBean.getMsisdn()+","+listDataBean.getMsisdnStatus()+",DB Updation Error");
			}
			logger.error("[CRBT-BU-90001] Exception while DB operation in updateJobListStatus() of class ResponseQueueReader ",sqle);
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] Exception some value may be null in updateJobListStatus() of class ResponseQueueReader ",npe);
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00070] Exception in updateJobListStatus() of class ResponseQueueReader ",e);
		}
		finally
		{
			try
			{
				if(con!=null)
				{
					con.close();	
				}
				if(pstmt!=null)
				{
					pstmt.close();					
				}
				query=null;
				pstmt=null;
				con=null;
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00071] Exception while closing of DB resources in updateJobListStatus() of class ResponseQueueReader ",e);
			}
		}
		//logger.info("["+listDataBean.getMsisdn()+"_"+listDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+listDataBean.getListbean().getReqId()+"] successfully update status in updateJobListStatus() of class ResponseQueueReader ");
	}//updateJobListStatus() 
*/  //commented on 11-01-2017
	
}
