package com.telemune.bulkupload.threads;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.telemune.bulkupload.beans.ListDataBean;
import com.telemune.bulkupload.beans.ListIdBean;
import com.telemune.bulkupload.common.Global;
import com.telemune.bulkupload.db.CorpManager;
import com.telemune.bulkupload.db.DBQueries;

import FileBaseLogging.FileLogWriter;


/**
 * 
 * @author Ashish
 * class implements runnable
 * This class reads Copr SUB/UNSUB request
 *
 */
public class ReadCorp implements Runnable 
{
	private static final Logger logger=Logger.getLogger(ReadCorp.class);
	CorpManager corpManager = null;	
	ListIdBean listIdBean = null;
	FileLogWriter flwFailupdation = null;
	
	public ReadCorp(FileLogWriter flwFailupdation)
	{
		 this.flwFailupdation= flwFailupdation;		 	
	}

	
	/**
	 * Execution of thread starts here
	 */
	
	public void run()
	{
		
		logger.info("Inside run() of ReadCorp ");
		ArrayList listInfo=null; 
		ArrayList listMsisdn=null;
		ArrayList runningList=null;
		logger.info("It is going to call the getListInfo() ++++++++");
		corpManager = new CorpManager();
		logger.info("It is going to call the getListInfo() ++++++++ after  corpManager");
		
    	while(true)
	 {
		  runningList = new ArrayList();
		 listInfo=new ArrayList();
		 listInfo.clear(); //to clear listinfo
		 logger.info("It is going to call the getListInfo()");
		 corpManager.getListInfo(listInfo);
		 logger.debug("ListSize["+listInfo.size()+"]"); //for testing
		 logger.info("ListSize["+listInfo.size()+"]");
		if((listInfo!=null || listInfo.size()>0) )
		{			
			for(int i=0;i<listInfo.size();i++)
			{				
				listIdBean=(ListIdBean)listInfo.get(i); 
				listMsisdn=new ArrayList();
				
				if(listIdBean.getLidStatus()=='P' || listIdBean.getLidStatus()=='p' )
				{					
					corpManager.updateListInfo(listIdBean,'R');
				}
				
				corpManager.getMsisdnList(listIdBean,listMsisdn,runningList);
				//changed on 09-01-2017 starts
				if(listMsisdn.size()>0)
				{
					corpManager.updateMsisdnStatus(listMsisdn);
				}
				//changed on 09-01-2017 ends
				logger.info("Running List size: "+runningList.size()+" ListMsisdnSize: "+listMsisdn.size()+" ListId: "+listIdBean.getListId()+" ");
				/*logger.info("The message used to be added is :" listIdBean.getCorpDetailBean().getCorpSubType()=='N');*/
				if(Global.CHARGING_SCOPE==true && ((listIdBean.getCorpDetailBean().getCorpSubType()=='N' || listIdBean.getCorpDetailBean().getCorpSubType()=='n' || listIdBean.getCorpDetailBean().getCorpSubType()==32 || listIdBean.getCorpDetailBean().getCorpSubType()==0 ) && listIdBean.getReqId()==1))
				{					
					logger.info("inside Corporate charging and corp subtype not found ListId:["+listIdBean.getListId()+"]");				
					updateListForCorpSubType(listMsisdn);
					if(listMsisdn.size()==0 && runningList.size()==0)
                    {
							logger.info("inside Corp subtype not found  to update ListId status to C ListId:["+listIdBean.getListId()+"]");
                            corpManager.getListInfoForCount(listIdBean);
                            corpManager.updateListInfo(listIdBean,'C');
                    }

				}
				else
				{
					if(listMsisdn.size()==0 && runningList.size()==0)
					{
						logger.info("inside if to update ListId status to C ListId:["+listIdBean.getListId()+"]");
						corpManager.getListInfoForCount(listIdBean);
						corpManager.updateListInfo(listIdBean,'C');
					}
					else
					{
						logger.info("inside else listMsisdn size "+listMsisdn.size()+ " runningList size: "+runningList.size()+" ListId:["+listIdBean.getListId()+"]");
						for(int j=0;j<listMsisdn.size();j++)
						{
							try 
							{	
								Global.readerQueue.put((ListDataBean)listMsisdn.get(j));
							} 
							catch (Exception e) 
							{
								logger.error("[CRBT-BU-00064] Exception while insert records in readerQueue of run() of Class ReadCorp ",e);
								//e.printStackTrace();
								try 
								{
									
									Thread.sleep(50);
									continue; //continue is used to put data in reader queue if exception occur for first time
								} catch (InterruptedException e1)
								{
									logger.error("[CRBT-BU-90013] Error while intruppting Thread during putting data in reader queue ",e1);
								} //if exception point 11.6
								
							}
							
						}//inner for loop ends
						
						try 
						{
							Thread.sleep(20);
						} catch (Exception e) 
						{	
							logger.error("[CRBT-BU-00065] Error while intruption of Thread in run() of class ReadCorp ",e);
						}
						
					}//inner else
				}//else subtype
				
				runningList.clear();// to clear running list
				listMsisdn.clear();// to clear listMsisdn list
				
			}//outer for loop
		
			
		}
		
		
			try 
			{
				//Thread.sleep(1000);
				Thread.sleep(Global.READ_CORP_SLEEP_TIME*1000);
			} 
			catch (InterruptedException e) 
			{
				logger.error("[CRBT-BU-90013] Error while intruppting Thread in run() of class ReadCorp ",e);				
			}
			logger.debug("Size of que :"+Global.readerQueue.size());
			while(!Global.readerQueue.isEmpty())
			{
				try 
				{
					Thread.sleep(10);
				} 
				catch (InterruptedException e) 
				{
					logger.error("[CRBT-BU-90013] Error while intruppting Thread during Reader Queue empty check in run() of class ReadCorp ",e);					
				}
			}
			//list object should be null here 
			listInfo = null;
			runningList=null;
			listMsisdn=null;
			
	     }//while(true)
		
	}//run() 
	
		
	private void updateListForCorpSubType(ArrayList listMsisdn)
	{
		logger.info("inside updateListForCorpSubType() of class ReadCorp to update Msisdn's status to F as Corp Subtype not found. ListId:["+listIdBean.getListId()+"] listMsisdn size:["+listMsisdn.size()+"]");
		
		Connection con = null;
		PreparedStatement pstmt = null;	
		String query=null; 
	    query=DBQueries.UPDATE_JOB_LIST_DETAILS_RESPONSE_STRING;	
     
		
		try
		{
			String description= "Corporate Msisdn Subscriber type not found";
			con = Global.conPool.getConnection();
			pstmt = con.prepareStatement(query);
			logger.debug("Query in updateListForCorpSubType() status to be update to F: "+query);
			ListDataBean listDataBean = null;
			Iterator itr = listMsisdn.iterator();
			while(itr.hasNext())
			{
				listDataBean = (ListDataBean)itr.next();
				pstmt.setString(1,"F");
				pstmt.setString(2,description);
				pstmt.setString(3,listDataBean.getListId());
				pstmt.setString(4,listDataBean.getMsisdn());
				pstmt.addBatch();			 
				synchronized (flwFailupdation) 
				{					
					flwFailupdation.writeLog(listDataBean.getListbean().getListId()+","+listDataBean.getMsisdn()+",F,"+description);
				}
			}
				
			int[] updatedMsisdn = pstmt.executeBatch();
			logger.info("No of Msisdn status update in updateMsisdnStatus() "+updatedMsisdn.length);
			
			pstmt.close();
			description=null;
			listDataBean=null;
		}
		catch(BatchUpdateException bue)
		{
			logger.error("[CRBT-BU-90024] BatchUpdateException while updating Msisdn status to F when corp subtype not found in updateListForCorpSubType() of class CorpReader ",bue);
		}
		catch(SQLException sqle)
		{
			logger.error("[CRBT-BU-90001] getting error while updating Msisdn status to F when corp subtype not found in updateListForCorpSubType() of class CorpReader ",sqle);
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] getting error some value may be null while updating Msisdn status to F when corp subtype not found in updateListForCorpSubType() of class CorpReader ",npe);
		}		
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00066] Exception while update in updateListForCorpSubType() of class ReadCorp ",e);
		}
		finally
		{
			try{
				if(pstmt!=null)
				{
					pstmt.close();					
				}
				if(con!=null)
				{					
					con.close();					
				}
				query=null;
				pstmt=null;
				con=null;
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00067] Exception while closing DB resources in updateListForCorpSubType() of class ReadCorp ",e);
			}
		}
		
	}//updateListForCorpSubType(ArrayList) ends

}
