package com.telemune.bulkupload.threads;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import FileBaseLogging.FileLogWriter;

import com.telemune.bulkupload.beans.ListDataBean;
import com.telemune.bulkupload.common.Global;
import com.telemune.bulkupload.db.CorpManager;
import com.telemune.bulkupload.db.DBQueries;

import com.telemune.bulkupload.*;
/*
 *  This Thread Process the Response Queue and Update their status in JOB_LIST_DETAILS Table
 */
public class ResponseQueueProcessor implements Runnable
{
	private static final Logger logger = Logger.getLogger(CorpRequestProcessor.class);
	ListDataBean mDataBean = null ;	
	FileLogWriter flwUpdationfail = null;
	/*ListIdBean listbean=null;*/
	
	
	//CorpManager corpManager = null;
	 
	
	public ResponseQueueProcessor(ListDataBean dataBean,FileLogWriter flwUpdationfail)
	{		
		this.mDataBean=dataBean;
		this.flwUpdationfail=flwUpdationfail;
	}


	@Override
	public void run() 
	{
		logger.debug("inside run method() of ResponseQueueProcessor ");
		try
		{
			updateJobListStatus(this.mDataBean);
			mDataBean=null;
			flwUpdationfail=null;
		}catch(Exception e)
		{
			logger.error("Exception in run() of ResponseQueueProcessor",e);
		}
		
	}
	
	private void updateJobListStatus(ListDataBean listDataBean)  
	{
		logger.info("["+listDataBean.getMsisdn()+"_"+listDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+listDataBean.getListbean().getReqId()+"] inside updateJobListStatus() of class ResponseQueueReader Msisdn Status:["+listDataBean.getMsisdnStatus()+"] Description:["+listDataBean.getDescription()+"]");
		String query =null;
		Connection con = null;
		PreparedStatement pstmt= null;
		//String query = "update JOB_LIST_DETAILS set STATUS=? ,RESPONSE_STRING=?,UPDATE_DATE=sysdate where MSISDN=? and LIST_ID=?";
		
		query=DBQueries.UPDATE_RESPONSE_STRING_JOB_LIST_DETAILS;
		try
		{
			logger.debug("["+listDataBean.getMsisdn()+"_"+listDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+listDataBean.getListbean().getReqId()+"] ListId:["+listDataBean.getListbean().getListId()+"] Status:["+listDataBean.getMsisdnStatus()+"] Description:["+listDataBean.getDescription()+"]");		
			con = Global.conPool.getConnection();
			pstmt = con.prepareStatement(query);
			//added on 11-01-2017 starts
			if(listDataBean.getMsisdnStatus()=='F' || listDataBean.getMsisdnStatus()=='f')
			{		
				synchronized (flwUpdationfail) 
				{
					flwUpdationfail.writeLog(listDataBean.getListbean().getListId()+","+listDataBean.getMsisdn()+","+listDataBean.getMsisdnStatus()+","+listDataBean.getDescription());
				}				
			}
			//added on 11-01-2017 ends 
			
			pstmt.setString(1,String.valueOf(listDataBean.getMsisdnStatus()));
			pstmt.setString(2,listDataBean.getDescription());
			pstmt.setString(3,listDataBean.getListbean().getListId());
			pstmt.setString(4,listDataBean.getMsisdn());		
			
			logger.debug("Query in updateJobListStatus() of class ResponseQueueReader: "+query);
			pstmt.executeUpdate();
			pstmt.close();
			
			/*if(listDataBean.getMsisdnStatus()=='S' || listDataBean.getMsisdnStatus()=='s')
			{			
				query= "UPDATE JOB_DETAILS SET TOTAL_SUCC_COUNT=TOTAL_SUCC_COUNT+1 WHERE LIST_ID=?";
			}			
			else if(listDataBean.getMsisdnStatus()=='F' || listDataBean.getMsisdnStatus()=='f')
			{
				query="UPDATE JOB_DETAILS SET TOTAL_FAIL_COUNT=TOTAL_FAIL_COUNT+1 WHERE LIST_ID=?";
				flwUpdationfail.writeLog(listDataBean.getListbean().getListId()+","+listDataBean.getMsisdn()+","+listDataBean.getMsisdnStatus()+","+listDataBean.getDescription());
			}			
			pstmt = con.prepareStatement(query);			
			logger.debug("query update:  "+query);		
			pstmt.setString(1,listDataBean.getListbean().getListId());
			pstmt.executeUpdate(); 			
*/  //commented on 11-01-2017
			logger.info("["+listDataBean.getMsisdn()+"_"+listDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+listDataBean.getListbean().getReqId()+"] successfully update status in updateJobListStatus() of class ResponseQueueReader ");
		}
		catch(SQLException sqle)
		{		
			synchronized (flwUpdationfail) 
			{
				flwUpdationfail.writeLog(listDataBean.getListbean().getListId()+","+listDataBean.getMsisdn()+","+listDataBean.getMsisdnStatus()+",DB Updation Error");
			}
			logger.error("[CRBT-BU-90001] Exception while DB operation in updateJobListStatus() of class ResponseQueueReader ",sqle);
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] Exception some value may be null in updateJobListStatus() of class ResponseQueueReader ",npe);
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00070] Exception in updateJobListStatus() of class ResponseQueueReader ",e);
		}
		finally
		{
			try
			{
				if(con!=null)
				{
					con.close();	
				}
				if(pstmt!=null)
				{
					pstmt.close();					
				}
				query=null;
				pstmt=null;
				con=null;
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00071] Exception while closing of DB resources in updateJobListStatus() of class ResponseQueueReader ",e);
			}
		}		
	}//updateJobListStatus() 

}
