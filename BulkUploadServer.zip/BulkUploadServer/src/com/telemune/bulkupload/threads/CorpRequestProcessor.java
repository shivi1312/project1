package com.telemune.bulkupload.threads;

import org.apache.log4j.Logger;

import com.telemune.bulkupload.beans.ListDataBean;
import com.telemune.bulkupload.beans.ListIdBean;
import com.telemune.bulkupload.common.Global;
import com.telemune.bulkupload.db.CorpManager;

public class CorpRequestProcessor implements Runnable
{
	private static final Logger logger = Logger.getLogger(CorpRequestProcessor.class);
	ListDataBean mDataBean = null ;	
	/*ListIdBean listbean=null;*/
	
	String respstr ="NA";	
	CorpManager corpManager = null;
	 
	
	public CorpRequestProcessor(ListDataBean dataBean)
	{		
		this.mDataBean=dataBean;
	}


	@Override
	public void run() {
		
		try
		{			
			logger.info("inside run() of CorpRequestProcessor: ["+mDataBean.getMsisdn()+"_"+mDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+mDataBean.getListbean().getReqId()+"] ListId:["+mDataBean.getListId()+"]");
			corpManager = new CorpManager();
			
			if(mDataBean != null)
			{				
				//listbean = mDataBean.getListbean();				
				String userId=mDataBean.getListbean().getUserId();								
				mDataBean.getListbean().setUserId(userId.substring(userId.indexOf('_')+1, userId.length()));
               
				switch( mDataBean.getListbean().getReqId())
				{
                                  
				 case 1: //Add subscriber
				 {					 					 	
					 		respstr = corpManager.addSubscriberGroup(this.mDataBean);				 					  
					 		break;			
				 }	
                 case 2: //UnSubscribe
				 {
					 		respstr = corpManager.unsubscribe(this.mDataBean );					 
					 		break;					
				 }
                 default :
				 {				
					 logger.info("["+mDataBean.getMsisdn()+"_"+mDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+mDataBean.getListbean().getReqId()+"] ListId:["+mDataBean.getListId()+"] reqId["+mDataBean.getListbean().getReqId()+"] requested Id not found");
					 respstr = "NA";
				 }
				}
				logger.debug("["+mDataBean.getMsisdn()+"_"+mDataBean.getListbean().getCorpDetailBean().getCorpId()+"_"+mDataBean.getListbean().getReqId()+"] ListId:["+mDataBean.getListId()+"] Response returned after Processing request is ["+respstr+"]");
				
				if(respstr.equalsIgnoreCase("success"))
				{
					logger.debug("SUCCESSS");
					this.mDataBean.setMsisdnStatus('S');	
					Global.responseQueue.put(this.mDataBean);
					respstr = null;
				}
				
				else 
				{ 
					logger.debug("FAILURE");			
					this.mDataBean.setMsisdnStatus('F');
					Global.responseQueue.put(this.mDataBean);
					respstr = null;
				}
				userId=null; //added on 11-01-2017
				corpManager=null;
				//mDataBean=null;
			}
			else
			{
				logger.error("dataBean is null");
			}
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] null value found while process request in run() of class CorpRequestProcessor ",npe);
		}
		catch(Exception exp)
		{
			logger.error("[CRBT-BU-00063] Error while process request in run() of class CorpRequestProcessor ",exp);
		}
	}//run method ends
	
} //class ends
