package com.telemune.bulkupload.threads;

/*
CacheLoader Class Basically Used for Loading Data From Database into HashTable for Making Cache So 
That Every Time we don't Need to get Data from Database.  

[m] before every variable defines class member and [l] defines local variable of any method

*/
import org.apache.log4j.*;

import RatePlan.RatePlanParser;

import com.telemune.bulkupload.common.Global;
import com.telemune.bulkupload.db.DBQueries;


import java.sql.*;
import java.util.*;


public class CacheLoader implements Runnable
{
	private static final Logger logger=Logger.getLogger(CacheLoader.class);
	int sleeptime=30;
	private static Hashtable<String, String> appConfigParams = null;
	Hashtable<Integer,String>  smstemplates = null;
	private static Hashtable corpIdScope = null; //Corp scope from crbt_corp_detail
	private static Hashtable<String, String> corpRbtCode = null; //Corp rbt_code from crbt_corp_detail // added by Avishkar on 08.01.2019
	private static RatePlanParser crbtRatePlanParser=new RatePlanParser();
	
	public void stop()
	{

	}

	public CacheLoader(int s1)
	{		
		sleeptime=s1;
	}
	public CacheLoader()
	{		
		
	}

	public void run()
	{
		/*ResultSet rs=null;
		Connection con=null;
		PreparedStatement pstmt=null;
		String query="";*/		
		while(true)
		{
			/*try
			{	
				if(con==null)
					con=Global.conPool.getConnection();
		
				query="select TEMPLATE_ID,TEMPLATE_MESSAGE from LBS_TEMPLATES where TEMPLATE_ID = 300 and TEMPLATE_TYPE = 10 and language_id = ?";
				logger.debug("query["+query+"]");
				
				pstmt = con.prepareStatement(query);
				pstmt.setInt(1,Global.DEFAULT_LANGUAGE);
				rs=pstmt.executeQuery();			
				smstemplates = new Hashtable<Integer, String>();
				while(rs.next())
				{
					logger.debug(" TEMPLATE_ID ==="+rs.getInt("TEMPLATE_ID")+" TEMPLATE_MESSAGE ==="+rs.getString("TEMPLATE_MESSAGE"));
					try
					{
						smstemplates.put(rs.getInt("TEMPLATE_ID"),rs.getString("TEMPLATE_MESSAGE"));
					}
					catch(ClassCastException cce)
					{
						logger.error("[CRBT-BU-90009] ClassCastException while loading templates in class CacheLoader ",cce);
					}
					catch(NullPointerException npe)
					{
						logger.error("[CRBT-BU-90003] NullPointerException while loading templates in class CacheLoader ",npe);
					}
					catch(Exception see)
					{						
						logger.error("[CRBT-BU-00009] Exception while loading templates in class CacheLoader ",see);
					}
				}	
					rs.close();
					pstmt.close();
					Global.smstemplates= smstemplates;
					
					logger.debug("GOING TO CLOSE CONNECTION AND STATEMENT FOR CACHELOADER BEFORE FINALLY");
					Global.LICENSE_KEY = getMaxSubs();
					logger.info("Global licence key "+Global.LICENSE_KEY);				
					
					query = "select PARAM_TAG, PARAM_VALUE from CRBT_APP_CONFIG_PARAMS WHERE PARAM_TAG IN ("+Global.APP_CONFIG_PARAMS+" )";				
					pstmt = con.prepareStatement(query);
					logger.info("query to load data from crbt_app_config_params:["+query+"]");
					rs = pstmt.executeQuery(query);
					appConfigParams = new Hashtable();
					while (rs.next())
					{
						try
						{
							appConfigParams.put((rs.getString("PARAM_TAG")).toUpperCase(), rs.getString("PARAM_VALUE"));
						}
						catch(ClassCastException cce)
						{
							logger.error("[CRBT-BU-90009] ClassCastException while loading app config params in class CacheLoader ",cce);
						}
						catch(NullPointerException npe)
						{
							logger.error("[CRBT-BU-90003] NullPointerException while loading app config params in class CacheLoader ",npe);
						}
						catch(Exception e)
						{
							logger.error("[CRBT-BU-00008] Exception while loading app config params in class CacheLoader ",e);
						}						
					}				
					rs.close();
					pstmt.close();
					
					Global.appConfigParams= appConfigParams;
					Thread.sleep(sleeptime*1000);
					
					smstemplates = null;
					appConfigParams=null;
			}
			catch(SQLException sqle)
			{
				logger.error("[CRBT-BU-90001] SQLException in run() of class CacheLoader ",sqle);
			}
			catch(NullPointerException npe)
			{
				logger.error("[CRBT-BU-90003] NullPointerException in run() of class CacheLoader ",npe);
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00010] Exception in run() of class CacheLoader ",e);
			}
			finally{
				
				try
				{					
					if(con!=null)
					{						
						con.close();												
					}
					if(pstmt!=null)
					{
						pstmt.close();
					}
					if(rs!=null)
					{
						rs.close();
					}
					query=null;
					rs=null;
					pstmt=null;
					con=null;
				}
				catch(Exception e1)
				{
					logger.error("[CRBT-BU-00011] Exception while closing of DB resources in class CacheLoader ",e1);
				}				
			}*/
			try
			{
				reloadCache();
				logger.debug("sleepTime:["+sleeptime+"]");
				Thread.sleep(sleeptime*1000);
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00076] Exception in run() of CacheLoader ",e);
			}
			
		}//while(true) ends  
	}//RUN
	
	
	
	private int getMaxSubs()
	{
		logger.info("Inside getMaxSubs() of class CacheLoader ");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String key = "";
		String query =null;
		try
		{
			if(con==null)
			{
				con = Global.conPool.getConnection();
			}
			query=DBQueries.SELECT_LICENCE_KEY_CRBT_APP_TEMP_KEY;
			//logger.info("The DataBase Used is :"+TSSJavaUtil.getInstance().getKeyValue("DB_QUERY")+":"+query);
			pstmt = con.prepareStatement(query);
			logger.debug("Query in getMaxSubs(): "+query);
			rs = pstmt.executeQuery();		
			if(rs.next())
			{
				key = rs.getString(1);				
			}
		}
		catch(SQLException sqle)
		{
			logger.error("[CRBT-BU-90001] SQLException in getMaxSubs() of class CacheLoader ",sqle);
		}
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] NullPointerException in getMaxSubs() of class CacheLoader ",npe);
		}
		catch (Exception exp)
		{
			logger.error("[CRBT-BU-00012] Exception in getMaxSubs() of class CacheLoader ",exp);
		}finally{
			
				try
				{
					if(con!=null)
					{						
						con.close();												
					}
					if(rs != null)
					{
						rs.close();
					}
					if(pstmt!=null)
					{
						pstmt.close();
					}
					query=null;
					rs=null;
					pstmt=null;
					con=null;
				}
				catch(Exception e)
				{
					logger.error("[CRBT-BU-00013] Exception while closing the DB resources in getMaxSubs() of class CacheLoader ",e);					
				}
		}
	
	try{
		String temp = key.substring(0, 6);

		char tmp[] = temp.toCharArray();

		int nParam = Integer.parseInt(decode(tmp.length, tmp));
		if (nParam <=0 || nParam > key.length()/8)
		{
			return -1;
		}
		int loc = 6;

			for(int i =0; i< nParam; i++)
			{
				temp = key.substring(loc);
				if ((temp == null) || (temp.length() <6))
				{
					return -1;
				}
				temp = key.substring(loc,loc+6);
				tmp = temp.toCharArray();
				int len = Integer.parseInt(decode(tmp.length, tmp));
	
				loc = loc+6;
				if (len <=0 || (2*len) > key.substring(loc).length())
				{
					return -1;
				}
				temp = key.substring(loc, loc+2*len);
				tmp = temp.toCharArray();
				String data = decode(tmp.length, tmp);
				loc = loc+2*len;
				logger.info("hhh["+data+"] i"+i);
				if (i==1)
				{
					return(Integer.parseInt(data));
				}
			}
			temp=null;
			tmp=null;
		}	
		catch(NullPointerException npe)
		{
			logger.error("[CRBT-BU-90003] NullPointerException while decoding in getMaxSubs() of class CacheLoader ",npe);
		}
		catch(NumberFormatException nfe)
		{
			logger.error("[CRBT-BU-90004] NumberFormatException while decoding in getMaxSubs() of class CacheLoader ",nfe);
		}
		catch(StringIndexOutOfBoundsException siobe)
		{
			logger.error("[CRBT-BU-90010] StringIndexOutOfBoundsException while decoding in getMaxSubs() of class CacheLoader ",siobe);
		}
		catch(ArrayIndexOutOfBoundsException aiobe)
		{
			logger.error("[CRBT-BU-90007] ArrayIndexOutOfBoundsException while decoding in getMaxSubs() of class CacheLoader ",aiobe);
		}
		catch(Exception e)
		{
			logger.error("[CRBT-BU-00014] Exception in getMaxSubs() of class CacheLoader ", e);
		}
		key=null;
		return -1;	
	}//getMaxSubs
	
	public static String decode(int len, char data[])
	{
		//logger.debug("DECODE: starts "+data);
		char lData[] = new char[(len/2) +1];
		for (int i=0; i<len; i++)
		{
			lData[i/2] = (char) (data[i] - 0x41);
			lData[i/2] += (char) (data[++i] - 0x41)<<4;
		}
		String s = new String(lData);
		//logger.debug("DECODE: ends");
		return s.trim();
	} //decode
	
	public void reloadCache()
	{

		ResultSet rs=null;
		Connection con=null;
		PreparedStatement pstmt=null;
		String query="";		
		appConfigParams=new Hashtable<String, String>();
			try
			{	
				if(con==null)
					con=Global.conPool.getConnection();
				query=DBQueries.SELECT_TEMPLATE_ID_LBS_TEMPLATES;
				
				logger.debug("query["+query+"]");
				
				pstmt = con.prepareStatement(query);
				pstmt.setInt(1,Global.DEFAULT_LANGUAGE);
				rs=pstmt.executeQuery();			
				smstemplates = new Hashtable<Integer, String>();
				while(rs.next())
				{
					logger.debug(" TEMPLATE_ID ==="+rs.getInt("TEMPLATE_ID")+" TEMPLATE_MESSAGE ==="+rs.getString("TEMPLATE_MESSAGE"));
					try
					{
						smstemplates.put(rs.getInt("TEMPLATE_ID"),rs.getString("TEMPLATE_MESSAGE"));
					}
					catch(ClassCastException cce)
					{
						logger.error("[CRBT-BU-90009] ClassCastException while loading templates in class CacheLoader ",cce);
					}
					catch(NullPointerException npe)
					{
						logger.error("[CRBT-BU-90003] NullPointerException while loading templates in class CacheLoader ",npe);
					}
					catch(Exception see)
					{						
						logger.error("[CRBT-BU-00009] Exception while loading templates in class CacheLoader ",see);
					}
				}	
					rs.close();
					pstmt.close();
					Global.smstemplates= smstemplates;
					
					logger.debug("GOING TO CLOSE CONNECTION AND STATEMENT FOR CACHELOADER BEFORE FINALLY");
					logger.info("GOING TO CLOSE CONNECTION AND STATEMENT FOR CACHELOADER BEFORE FINALLY");
					Global.LICENSE_KEY = getMaxSubs();
					logger.info("Global licence key :"+Global.LICENSE_KEY);				
					query=DBQueries.SELECT_PARAM_TAG_CRBT_APP_CONFIG_PARAMS;
					//logger.info("The DataBase Used is :"+TSSJavaUtil.getInstance().getKeyValue("DB_QUERY")+":"+query);
					pstmt = con.prepareStatement(query);
					logger.info("query to load data from crbt_app_config_params:["+query+"]");
					rs = pstmt.executeQuery(query);
					logger.info("The value is after execution :"+rs);
					while (rs.next())
					{
						try
						{
							appConfigParams.put((rs.getString("PARAM_TAG")).toUpperCase(), rs.getString("PARAM_VALUE"));
						}
						catch(ClassCastException cce)
						{
							logger.error("[CRBT-BU-90009] ClassCastException while loading app config params in class CacheLoader ",cce);
						}
						catch(NullPointerException npe)
						{
							logger.error("[CRBT-BU-90003] NullPointerException while loading app config params in class CacheLoader ",npe);
						}
						catch(Exception e)
						{
							logger.error("[CRBT-BU-00008] Exception while loading app config params in class CacheLoader ",e);
						}						
					}				
					rs.close();
					pstmt.close();
					
					Global.appConfigParams= appConfigParams;
					//Thread.sleep(sleeptime*1000);
					
					//added on 12-01-2016 starts
					//This if condition is added by Ashish on 28-NOV-2017
					if(Global.CHARGING_SCOPE==true)
					{
						query=DBQueries.SELECT_SCOPE_FROM_CRBT_CORP_DETAIL;
					//	logger.info("The DataBase used is :"+TSSJavaUtil.getInstance().getKeyValue("DB_QUERY")+":"+query);
						pstmt = con.prepareStatement(query);
						logger.debug("query to load scope of corp id from CRBT_CORP_DETAIL:["+query+"]");
						logger.info("query to load scope of corp id from CRBT_CORP_DETAIL:["+query+"]");
						rs = pstmt.executeQuery(query);
						corpIdScope = new Hashtable();					
						String scopeValue= null;
						while (rs.next())
						{
							try
							{
								if( rs.getString("SCOPE")!=null && !rs.getString("SCOPE").equalsIgnoreCase("NA"))
								{
									crbtRatePlanParser.ParsrChargingCode(rs.getString("SCOPE"),rs.getString("CORP_ID"),"CORP");
									scopeValue = crbtRatePlanParser.getParamValues(rs.getString("CORP_ID"),"CORP","SUB");
									corpIdScope.put((rs.getString("CORP_ID")),scopeValue);
									logger.info("CorpId:["+rs.getString("CORP_ID")+"] scopeValue:["+scopeValue+"]");
								}							
								
							}
							catch(ClassCastException cce)
							{
								logger.error("[CRBT-BU-90009] ClassCastException while loading scope of corp id from CRBT_CORP_DETAIL in class CacheLoader ",cce);
							}
							catch(NullPointerException npe)
							{
								logger.error("[CRBT-BU-90003] NullPointerException while loading scope of corp id from CRBT_CORP_DETAIL in class CacheLoader ",npe);
							}
							catch(Exception e)
							{
								logger.error("[CRBT-BU-00077] Exception while loading scope of corp id from CRBT_CORP_DETAIL in class CacheLoader ",e);
							}						
						}				
						rs.close();
						pstmt.close();
						Global.corpIdScope= corpIdScope;
						corpIdScope=null;
						scopeValue=null;
					}
					
					
					
					//added on 12-01-2016 ends
					
					//added by Avishkar on 08.01.2019 starts
					if (Global.IS_SET_DEFAULT_RBT==false) 
					{
						query=DBQueries.SELECT_CORP_ID_CRBT_CORP_DETAIL;
						pstmt = con.prepareStatement(query);
						logger.info("The Default value for Global.IS_SET_DEFAULT_RBT is :"+Global.IS_SET_DEFAULT_RBT);
						logger.debug("query to load rbt_code of corp id from CRBT_CORP_DETAIL:["+query+"]");
						logger.info("query to load rbt_code of corp id from CRBT_CORP_DETAIL:["+query+"]");
						rs = pstmt.executeQuery(query);
						corpRbtCode = new Hashtable<String,String>();
						while (rs.next()) 
						{
							try {
								 if (rs.getString("RBT_CODE")!=null && !rs.getString("RBT_CODE").equalsIgnoreCase("NA")) 
								   {
									corpRbtCode.put((rs.getString("CORP_ID")),(rs.getString("RBT_CODE")));
									logger.info("CorpId:["+rs.getString("CORP_ID")+"] Rbt_Code:["+rs.getString("RBT_CODE")+"]");
								   }
							    } 
							catch(ClassCastException cce)
							{
								logger.error("[CRBT-BU-90009] ClassCastException while loading rbt_code of corp id from CRBT_CORP_DETAIL in class CacheLoader ",cce);
							}
							catch(NullPointerException npe)
							{
								logger.error("[CRBT-BU-90003] NullPointerException while loading rbt_code of corp id from CRBT_CORP_DETAIL in class CacheLoader ",npe);
							}
							catch(Exception e)
							{
								logger.error("[CRBT-BU-00078] Exception while loading rbt_code of corp id from CRBT_CORP_DETAIL in class CacheLoader ",e);
							}						
						}
						rs.close();
						pstmt.close();
						Global.corpRbtCode= corpRbtCode;
						corpRbtCode=null;
					}
					//added by Avishkar on 08.01.2019 ends
					
					smstemplates = null;
					appConfigParams=null;
					
			}
			catch(SQLException sqle)
			{
				logger.error("[CRBT-BU-90001] SQLException in run() of class CacheLoader ",sqle);
			}
			catch(NullPointerException npe)
			{
				logger.error("[CRBT-BU-90003] NullPointerException in run() of class CacheLoader ",npe);
			}
			catch(Exception e)
			{
				logger.error("[CRBT-BU-00010] Exception in run() of class CacheLoader ",e);
			}
			finally{
				
				try
				{					
					if(con!=null)
					{						
						con.close();												
					}
					if(pstmt!=null)
					{
						pstmt.close();
					}
					if(rs!=null)
					{
						rs.close();
					}
					query=null;
					rs=null;
					pstmt=null;
					con=null;
				}
				catch(Exception e1)
				{
					logger.error("[CRBT-BU-00011] Exception while closing of DB resources in class CacheLoader ",e1);
				}				
			}
		  
	
	}//reloadCache() ends
	
	

}//class ends