package com.telemune.listener;

import org.apache.log4j.Logger;
import com.telemune.ivr.util.VoiceXmlReader;
import com.telemune.vcc.expiringmap.ExpirationListener;
public class LoaderListener implements ExpirationListener<String, VoiceXmlReader> 
{
    Logger logger = Logger.getLogger(LoaderListener.class);
	
    public void expired(String key, VoiceXmlReader value) 
    {
    	logger.info("Expiring Map for "+key+" value "+value);
    	value = null;
            
    }
}


