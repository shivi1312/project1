package com.telemune.listener;

import org.apache.log4j.Logger;

import com.telemune.ivr.bean.RequestBean;
import com.telemune.vcc.expiringmap.ExpirationListener;


public class ParserListener implements ExpirationListener<String, RequestBean> {
    Logger logger = Logger.getLogger(ParserListener.class);
	@Override
	public void expired(String key, RequestBean value) {
		logger.info("Expiring key: "+key+" value "+value);
                value.getActionMap().clear();
                value.getLangMap().clear();
                value.getVarMap().clear();
                value.getLinkMap().clear();
                value = null;
                
	}
}