package com.telemune.ivr.db;

import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;


import org.apache.log4j.Logger;



public class JavaScriptMenuText {

	Logger logger = Logger.getLogger(JavaScriptMenuText.class);
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	public ConcurrentHashMap<String, String> getJavaScriptText(
			ConcurrentHashMap<String, String> jsTextMap) {
		logger.info("##> inside the load javascript text");
		String query = "select scriptName,scriptText,appName from JAVASCRIPT_MENU";
		
		String catName = "";
		String scriptName = "";
		String scriptText = "";
		
	try{
	con = DbConnection.getConnection();
	pstmt = con.prepareStatement(query);
	rs = pstmt.executeQuery();
	while(rs.next())
	{
	scriptName = rs.getString("scriptName");
	scriptText = rs.getString("scriptText");
	catName = rs.getString("appName");
	String key = catName+"/"+scriptName;
	jsTextMap.put(key, scriptText);	
	
	logger.info("In javascript catname :["+catName+"] scriptName :["+scriptName+"]");
	
		
	}
	
	}catch(Exception e)
	{
		logger.error("an sql error occurs in  "+e.getMessage());
	}
	
	logger.info("End of get JavaScript Text");
	return jsTextMap;
	}
	
	
	
}
