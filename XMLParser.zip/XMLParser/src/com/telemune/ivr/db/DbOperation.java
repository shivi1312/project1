package com.telemune.ivr.db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.telemune.ivr.bean.DbParamBean;
import com.telemune.ivr.bean.DbSelectBean;

/**
 * This class is used to perform all operation of database like select,insert,update,delete
 * 
 * @author jeevan
 */
public class DbOperation {
	Logger logger = Logger.getLogger(DbOperation.class);
	Connection con = null;
	PreparedStatement pstmt = null;
	Statement stmt = null;
	ResultSet rs = null;
	DbParamBean dbBean = null;
	DbSelectBean dbSBean = null;
    //insertOperation method Start Here 
	public int insertOperation(String dbDriver, String dbUrl, String dbUser,
			String dbPass, String ip, String queryString,
			HashMap<String, String> varMap,
			HashMap<String, Object> paramMap) throws SQLException {
		logger.info("###> inside the  insertOperation");
		ArrayList<DbParamBean> dblist = new ArrayList<DbParamBean>();

		int status = 0;
		int i = 0;
		
		
		
		try {
			Class.forName(dbDriver);
			try {
				con = DriverManager.getConnection(dbUrl, dbUser, dbPass);
				if(queryString.contains("&lt"))
				{
					queryString.replaceAll("&lt;", ">");
				}else if(queryString.contains("&gt;"))
				{
					queryString.replaceAll("&gt;", "<");
				}
				
				pstmt = con.prepareStatement(queryString);
				dblist = (ArrayList<DbParamBean>) paramMap.get("dbdata");
				logger.info("dblist =[" + dblist + "]");
				Iterator itr = dblist.iterator();
				while (itr.hasNext()) {
					i++;
					dbBean = (DbParamBean) itr.next();
					String data = dbBean.getData();
					String name = dbBean.getName();
					String type = dbBean.getType();
					int paramIndex = Integer.parseInt(dbBean.getParamIndex());

					if (paramIndex == i) {
						if (type.equalsIgnoreCase("int")) {
							logger.debug("# inside the set parameter of query and parameter is["
									+ name + "] ");
							if (varMap.containsKey(data)) // Incase of
															// parametrer values
															// fetch from
															// globalvalue
															// (varMap)
							{
								data = varMap.get(data);
							}
							pstmt.setInt(paramIndex, Integer.parseInt(data));
						} else if (type.equalsIgnoreCase("String")) {
							logger.debug("# inside the set parameter of query and parameter is["
									+ name + "] ");
							if (varMap.containsKey(data)) {
								data = varMap.get(data);
							}
							pstmt.setString(paramIndex, data);
						} else if (type.equalsIgnoreCase("Date")) {
							logger.debug("# inside the set parameter of query and parameter is["
									+ name + "] ");
							if (varMap.containsKey(data)) {
								data = varMap.get(data);
							}
							pstmt.setDate(paramIndex, Date.valueOf(data));
						}
					}

				}
				pstmt.executeUpdate();
				status = 1;

			} catch (SQLException ex) {
				logger.fatal("# Error Connection not form in ServiceInfo ", ex);

			}
		} catch (ClassNotFoundException ex) {
			logger.fatal("# Error Driver Not Found in Service Info ", ex);
			status = -1;

		} finally {
			 if (con != null || pstmt !=null)try{
					con.close();
					pstmt.close();}catch (Exception e) {
						logger.fatal("# Error con close Service Info ", e);
					}
		}
		logger.info("###> end  of the  insertOperation and status of insert operation is ["+status+"]");
		return status;
	}//insertOperation method End Here 

	//deleteOperation method Start Here 
	public int deleteOperation(String dbDriver, String dbUrl, String dbUser,
			String dbPass, String ip, String queryString,
			HashMap<String, String> varMap,
			HashMap<String, Object> paramMap) throws SQLException {
		ArrayList<DbParamBean> dblist = new ArrayList<DbParamBean>();
		dbBean = new DbParamBean();
		logger.info("###> inside the  deleteOperation");
		int status = 0;
		int i = 0;
		try {
			Class.forName(dbDriver);
			try {
				con = DriverManager.getConnection(dbUrl, dbUser, dbPass);
				if(queryString.contains("&lt"))
				{
					queryString.replaceAll("&lt;", ">");
				}else if(queryString.contains("&gt;"))
				{
					queryString.replaceAll("&gt;", "<");
				}
				pstmt = con.prepareStatement(queryString);
				dblist = (ArrayList<DbParamBean>) paramMap.get("dbdata");

				Iterator itr = dblist.iterator();
				while (itr.hasNext()) {
					i++;
					dbBean = (DbParamBean) itr.next();
					String data = dbBean.getData();
					String name = dbBean.getName();
					String type = dbBean.getType();
					int paramIndex = Integer.parseInt(dbBean.getParamIndex());

					if (paramIndex == i) {
						if (type.equalsIgnoreCase("int")) {
							logger.debug("# inside the set parameter of query and parameter is["
									+ name + "] ");
							if (varMap.containsKey(data)) // Incase of
															// parametrer values
															// fetch from
															// globalvalue
															// (varMap)
							{
								data = varMap.get(data);
							}
							pstmt.setInt(paramIndex, Integer.parseInt(data));
						} else if (type.equalsIgnoreCase("String")) {
							logger.debug("# inside the set parameter of query and parameter is["
									+ name + "] ");
							if (varMap.containsKey(data)) {
								data = varMap.get(data);
							}
							pstmt.setString(paramIndex, data);
						} else if (type.equalsIgnoreCase("Date")) {
							logger.debug("# inside the set parameter of query and parameter is["
									+ name + "] ");
							if (varMap.containsKey(data)) {
								data = varMap.get(data);
							}
							pstmt.setDate(paramIndex, Date.valueOf(data));
						}
					}

				}
				pstmt.executeUpdate();
				status = 1;

			} catch (SQLException ex) {
				logger.fatal("# Error Connection not form in ServiceInfo ", ex);

			}
		} catch (ClassNotFoundException ex) {
			logger.fatal("# Error Driver Not Found in Service Info ", ex);
			status = -1;

		} finally {
			 if (con != null)try{
			con.close();
			pstmt.close();}catch (Exception e) {
				logger.fatal("# Error con close Service Info ", e);
			}
		}
		logger.info("###> end of  the  deleteOperation and status of status is ["+status+"]");
		return status;
	}//deleteOperation method End Here
	
	//updateOperation method Start Here
	public int updateOperation(String dbDriver, String dbUrl, String dbUser,
			String dbPass, String ip, String queryString,
			HashMap<String, String> varMap,
			HashMap<String, Object> paramMap) throws SQLException {
		ArrayList<DbParamBean> dblist = new ArrayList<DbParamBean>();
		dbBean = new DbParamBean();

		logger.info("###> inside the  updateOperation");
		int status = 0;
		int i = 0;
		try {
			Class.forName(dbDriver);
			try {
				con = DriverManager.getConnection(dbUrl, dbUser, dbPass);
				if(queryString.contains("&lt"))
				{
					queryString.replaceAll("&lt;", ">");
				}else if(queryString.contains("&gt;"))
				{
					queryString.replaceAll("&gt;", "<");
				}
				pstmt = con.prepareStatement(queryString);
				dblist = (ArrayList<DbParamBean>) paramMap.get("dbdata");

				logger.info("###> inside the  dblist [" + dblist + "]");

				Iterator itr = dblist.iterator();
				while (itr.hasNext()) {
					i++;

					dbBean = (DbParamBean) itr.next();
					String data = dbBean.getData();
					String name = dbBean.getName();
					String type = dbBean.getType();
					int paramIndex = Integer.parseInt(dbBean.getParamIndex());

					if (paramIndex == i) {

						if (type.equalsIgnoreCase("int")) {

							if (varMap.containsKey(data)) // Incase of
															// parametrer values
															// fetch from
															// globalvalue
															// (varMap)
							{
								data = varMap.get(data);
							}
							pstmt.setInt(paramIndex, Integer.parseInt(data));
						} else if (type.equalsIgnoreCase("String")) {

							if (varMap.containsKey(data)) {
								data = varMap.get(data);
							}
							pstmt.setString(paramIndex, data);
						} else if (type.equalsIgnoreCase("Date")) {

							if (varMap.containsKey(data)) {
								data = varMap.get(data);
							}
							pstmt.setDate(paramIndex, Date.valueOf(data));
						}
					}

				}

				logger.info("# inside the query String[" + queryString + "] ");
				pstmt.executeUpdate();
				status = 1;

			} catch (SQLException ex) {
				logger.fatal("# Error Connection not form in ServiceInfo ", ex);

			}
		} catch (ClassNotFoundException ex) {
			logger.fatal("# Error Driver Not Found in Service Info ", ex);
			status = -1;

		} finally {
			 if (con != null)try{
					con.close();
					pstmt.close();}catch (Exception e) {
						logger.fatal("# Error con close Service Info ", e);
					}
		}
		logger.info("###> end of  the  updateOperation[" + status + "]");
		return status;
	}//updateOperation method End Here

	//selectOperation method Start Here
	public int selectOperation(String dbDriver, String dbUrl, String dbUser,
			String dbPass, String ip, String queryString,
			HashMap<String, String> varMap,
			HashMap<String, Object> paramMap) throws SQLException {
		logger.info("###> inside the  select Operation");
		dbBean = new DbParamBean();
		dbSBean = new DbSelectBean();
		ArrayList<DbParamBean> dblist = new ArrayList<DbParamBean>();
		ArrayList<DbSelectBean> dbSlist = new ArrayList<DbSelectBean>();
		int status = 0;
		int count = 0;
		int i = 0;
		int j = 0;
		try {
			Class.forName(dbDriver);
			try {
				con = DriverManager.getConnection(dbUrl, dbUser, dbPass);
				if(queryString.contains("&lt"))
				{
					queryString.replaceAll("&lt;", ">");
				}else if(queryString.contains("&gt;"))
				{
					queryString.replaceAll("&gt;", "<");
				}
				pstmt = con.prepareStatement(queryString);
				dblist = (ArrayList<DbParamBean>) paramMap.get("dbdata");

				Iterator itr = dblist.iterator();
				while (itr.hasNext()) {
					i++;
					dbBean = (DbParamBean) itr.next();
					String data = dbBean.getData();
					String name = dbBean.getName();
					String type = dbBean.getType();
					int paramIndex = Integer.parseInt(dbBean.getParamIndex());

					if (paramIndex == i) {
						if (type.equalsIgnoreCase("int")) {
							logger.info("# inside the set parameter of query and parameter is["
									+ name
									+ "] and data is ["
									+ varMap.get(data) + "] ");
							if (varMap.containsKey(data)) // Incase of
															// parametrer values
															// fetch from
															// globalvalue
															// (varMap)
							{
								data = varMap.get(data);
							}
							pstmt.setInt(paramIndex, Integer.parseInt(data));
						} else if (type.equalsIgnoreCase("String")) {
							logger.info("# inside the set parameter of query and parameter is["
									+ name + "] and data is ["
									+ data + "] ");
							if (varMap.containsKey(data)) {
								data = varMap.get(data);
							}
							pstmt.setString(paramIndex, data);
						} else if (type.equalsIgnoreCase("Date")) {
							logger.info("# inside the set parameter of query and parameter is["
									+ name + "] ");
							if (varMap.containsKey(data)) {
								data = varMap.get(data);
							}
							pstmt.setDate(paramIndex, Date.valueOf(data));
						
						}
					}

				}
				logger.info("query is"+pstmt);
				rs = pstmt.executeQuery();
				// getting data from anonymous database
				dbSlist = (ArrayList<DbSelectBean>) paramMap.get("dbsdata");
				Iterator itr2 = dbSlist.iterator();
				
			
				while (rs.next()) {
					j = 0;
					count++;
					while (itr2.hasNext()) {
						j++;
						logger.info("inside the rs.next");
						dbSBean = (DbSelectBean) itr2.next();
						// String data = dbBean.getData();
						String name = dbSBean.getName();

						String type = dbSBean.getType();
						// logger.info("name["+name+"] type =["+type+"]");
						int selectIndex = Integer.parseInt(dbSBean
								.getSelectIndex());

						if (selectIndex == j) {
							if (type.equalsIgnoreCase("String")) {
								varMap.put(name, rs.getString(name));
								logger.info("select Varible is [" + name
										+ "] and value is [" + varMap.get(name)
										+ "]");
							} else if (type.equalsIgnoreCase("int")) {
								String temp = Integer.toString(rs.getInt(name));
								varMap.put(name, temp);
								logger.info("select Varible is [" + name
										+ "] and value is [" + varMap.get(name)
										+ "]");
							}
						}

					}

				}
				if(count>=1)
				{
					status = 1;
					logger.warn(" row select For this for"+queryString);
					
				}else
				{
					status = 0;
					logger.warn("No row select For this for"+queryString);
				}
				
				
				

			} catch (SQLException ex) {
				logger.fatal("# Error Connection not form in ServiceInfo ", ex);

			}
		} catch (ClassNotFoundException ex) {
			logger.fatal("# Error Driver Not Found in Service Info ", ex);
			status = -1;

		} finally {
			 if (con != null ||pstmt!=null )try{
					con.close();
					pstmt.close();}catch (Exception e) {
						logger.fatal("# Error con close Service Info ", e);
					}
		}
		logger.info("###> end of the  select Operation and status of select is ["+status+"]");
		return status;
	}//selectOperation method end Here

}
