package com.telemune.ivr.db;

import java.sql.*;

import org.apache.log4j.Logger;

import com.telemune.ivr.bean.ShortCodeConfig;
import com.telemune.ivr.util.ServiceInfo;

/**
 * This class is used to get Application list of IVR from the databases on the bases of IsActive(Active or InActive).
 * 
 * @author jeevan
 */

public class ApplicationList {

	Logger logger = Logger.getLogger(ApplicationList.class);
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	//getApplicationList Method Start here
	public void getApplicationList(Connection con, ShortCodeConfig shortCodeConfig) {
		String query = "select App_Id,ShortCode,Mode,App_Name,AdditionalDigits from Application_List where isActive=?";
		try {
		//	Class.forName(dbDriver);
			try {
				// con = DriverManager.getConnection(dbUrl, dbUser, dbPass);
				//con = DbConnection.getConnection();
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, "Active");
				rs = pstmt.executeQuery();
				while (rs.next()) {

					shortCodeConfig = new ShortCodeConfig(
							rs.getString("App_Id"), rs.getString("ShortCode"),
							rs.getString("Mode"),
							rs.getString("AdditionalDigits")
							);
					if (rs.getString("AdditionalDigits").equals("NA")
							|| rs.getString("AdditionalDigits").equals("DF")) {
						logger.debug("App Id put is [" + rs.getString("App_Id")
								+ "#" + rs.getString("AdditionalDigits")
								+ "] App Name [" + rs.getString("App_Name")
								+ "]");
						ServiceInfo.appShort.put(rs.getString("App_Id") + "#"
								+ rs.getString("AdditionalDigits"),
								shortCodeConfig);
					} else {
						logger.debug("App Id put is [" + rs.getString("App_Id")
								+ "#] App Name [" + rs.getString("App_Name")
								+ "]");
						ServiceInfo.appShort.put(rs.getString("App_Id") + "#",
								shortCodeConfig);
					}

					logger.info("App_ID [" + rs.getString("App_Id")
							+ "] ShortCode [" + rs.getString("ShortCode")
							+ "] App Name [" + rs.getString("App_Name")
							+ "] Mode [" + rs.getString("Mode")
							+ "] AdditionalDigits ["
							+ rs.getString("AdditionalDigits") + "]");
				}
				pstmt.close();
				rs.close();

			} catch (SQLException ex) {
				logger.fatal("# Error Connection not form in ServiceInfo ", ex);

			}
		} catch (Exception ex) {
			logger.fatal("# Error Driver Not Found in Service Info ", ex);
		}
		finally
		{
			//logger.info("Inside Finally");
			
			//logger.info("Finally Ends");
		}

	}////getApplicationList Method End here

}
