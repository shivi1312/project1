package com.telemune.ivr.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.telemune.ivr.servlet.PlivoControlServlet;

/**
 * This class is used to create connection with database
 * 
 * @author jeevan
 */
public class DbConnection {
	
	
	static Connection con = null;
//getConnection method Start here 
	public static Connection getConnection() {
		try {
			Class.forName(PlivoControlServlet.dbDriver);
			try{
			con = DriverManager.getConnection(PlivoControlServlet.dbUrl,
					PlivoControlServlet.dbUser, PlivoControlServlet.dbPass);
			}catch(SQLException ex)
			{
				
			}
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}
		return con;
	}//getConnection method End here
}
