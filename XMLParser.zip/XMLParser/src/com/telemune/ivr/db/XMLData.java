package com.telemune.ivr.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

/**
 * This class is used to get XMLData from the database on the basis of applicationId(Serv_Id=?)
 *   
 * @author jeevan
 */
public class XMLData {
	Logger logger = Logger.getLogger(XMLData.class);
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	//getXmlData method Start here
	public String getXmlData(String servId,Connection con) {
		logger.debug("##> xml for this application id ["+servId+"]");
		String query = "select XML_Data from IVR_Services_Data where Serv_Id=?";
		String xmlData = "";

		//con = DbConnection.getConnection();

		try {
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, Integer.parseInt(servId));
			rs = pstmt.executeQuery();
			while (rs.next()) {
				xmlData = rs.getString("XML_Data");
			}
		} catch (SQLException e) {
			logger.fatal("# Error in VoiceXmlReader Constructor ", e);
			e.printStackTrace();
		}

		try {
			pstmt.close();
			rs.close();
		} catch (SQLException ex) {
			logger.fatal("# Error in VoiceXmlReader Constructor ", ex);

		}finally{
			 
		}

		return xmlData;
	}//getXmlData method End here

}
