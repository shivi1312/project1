package com.telemune.ivr.bean;

public class OutputDataBean {

	public OutputDataBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	String name,data,type;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getData() {
		return data;
	}

	public OutputDataBean(String name, String data, String type) {
		super();
		this.name = name;
		this.data = data;
		this.type = type;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	
}
