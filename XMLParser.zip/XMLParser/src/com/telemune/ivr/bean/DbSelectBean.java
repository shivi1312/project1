package com.telemune.ivr.bean;

import java.util.concurrent.*;

;

/**
 * This class is used to select parameters of query in database operation 
 * 
 * @author jeevan
 */
public class DbSelectBean {
	String data;
	String name;
	String type;
	String selectIndex;

	public void setSelectIndex(String selectIndex) {
		this.selectIndex = selectIndex;
	}

	public String getSelectIndex() {
		return selectIndex;
	}

	public DbSelectBean(String data, String name, String type,
			String selectIndex) {
		this.data = data;
		this.name = name;
		this.type = type;

		this.selectIndex = selectIndex;
	}

	public DbSelectBean() {
		super();
	}

	public void setData(String data) {
		this.data = data;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getData() {
		return data;
	}

	public String getName() {
		return name;
	}

	public String getType() {
		return type;
	}

	private ConcurrentHashMap<String, DbSelectBean> dbmap;

	public void setDbmap(ConcurrentHashMap<String, DbSelectBean> dbmap) {
		this.dbmap = dbmap;
	}

	public ConcurrentHashMap<String, DbSelectBean> getDbmap() {
		return dbmap;
	}

}
