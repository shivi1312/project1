package com.telemune.ivr.bean;
/**
 * This class is used to keep track of record of call on the basis of short code
 * 
 * @author jeevan
 */


public class ShortCodeConfig {
	private String appID;
	private String shortCode;
	private String direction;
	private String addCode;

	public ShortCodeConfig(String appID, String shortCode, String direction,
			String addCode) {
		super();
		this.appID = appID;
		this.shortCode = shortCode;
		this.direction = direction;
		this.addCode = addCode;
	}

	public String getAppID() {
		return appID;
	}

	public void setAppID(String appID) {
		this.appID = appID;
	}

	public String getShortCode() {
		return shortCode;
	}

	public void setShortCode(String shortCode) {
		this.shortCode = shortCode;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getAddCode() {
		return addCode;
	}

	public void setAddCode(String addCode) {
		this.addCode = addCode;
	}

}
