package com.telemune.ivr.bean;

import java.util.HashMap;

/**
 * This class is used to help processing of call 
 * 
 * @author jeevan
 */
public class RequestBean {
	private String callUUID;
	private String calledNum;
	private String itemId;
	private String callingNum;
	private StringBuffer callDigInfo;
	private String callSequence;
	private String callStatus;
	private String serviceId;
	private byte actionSequence;
	private byte changeShortcode;
	private HashMap<String, String> varMap;
	private HashMap<String, String> linkMap;
	private HashMap<String, String> langMap;
	private HashMap<String, String> actionMap;
	private HashMap<String, String> dbVarMap;// add by jeevan for the dbpool variable
	private HashMap<String, DbPool> conPoolMap;

	public HashMap<String, String> getDbVarMap() {
		return dbVarMap;
	}

	public void setDbVarMap(HashMap<String, String> dbVarMap) {
		this.dbVarMap = dbVarMap;
	}

	/**
	 * 
	 * @return the map contains action of particular item id
	 */
	public HashMap<String, String> getActionMap() {
		return actionMap;
	}

	/**
	 * 
	 * @param actionMap
	 *            set that action in bean
	 */
	public void setActionMap(HashMap<String, String> actionMap) {
		this.actionMap = actionMap;
	}

	/**
	 * 
	 * @return give the sequence how many actions are processed
	 */
	public byte getActionSequence() {
		return actionSequence;
	}

	/**
	 * 
	 * @param actionSequence
	 *            tell how many action are processed
	 */
	public void setActionSequence(byte actionSequence) {
		this.actionSequence = actionSequence;
	}

	/**
	 * 
	 * @return give the info regarding digits pressed by user during IVR call
	 */
	public StringBuffer getCallDigInfo() {
		return callDigInfo;
	}

	/**
	 * 
	 * @param callDigInfo
	 *            set on every digits press by user
	 */
	public void setCallDigInfo(StringBuffer callDigInfo) {
		this.callDigInfo = callDigInfo;
	}

	/**
	 * 
	 * @return is used to track the recording state of complete IVR call
	 */
	public String getCallSequence() {
		return callSequence;
	}

	/**
	 * 
	 * @param callSequence
	 *            used to track if recording start or not for IVR call
	 */
	public void setCallSequence(String callSequence) {
		this.callSequence = callSequence;
	}

	/**
	 * 
	 * @return tell call status stage ( ringing , in-progress,complete)
	 */
	public String getCallStatus() {
		return callStatus;
	}

	/**
	 * 
	 * @param callStatus
	 *            set stage of IVR call
	 */
	public void setCallStatus(String callStatus) {
		this.callStatus = callStatus;
	}

	/**
	 * 
	 * @return return call UUID
	 */
	public String getCallUUID() {
		return callUUID;
	}

	/**
	 * 
	 * @param callUUID
	 *            set Call UNIQUE ID
	 */
	public void setCallUUID(String callUUID) {
		this.callUUID = callUUID;
	}

	/**
	 * 
	 * @return shortcode
	 */
	public String getCalledNum() {
		return calledNum;
	}

	/**
	 * 
	 * @param calledNum
	 *            shortcode on which call originates or dialed
	 */
	public void setCalledNum(String calledNum) {
		this.calledNum = calledNum;
	}

	/**
	 * 
	 * @return give MSISDN
	 */
	public String getCallingNum() {
		return callingNum;
	}

	/**
	 * 
	 * @param callingNum
	 *            set MSISDN
	 */
	public void setCallingNum(String callingNum) {
		this.callingNum = callingNum;
	}

	/**
	 * 
	 * @return ITEM ID
	 */
	public String getItemId() {
		return itemId;
	}

	/**
	 * 
	 * @param itemId
	 *            set ITEM ID
	 */
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	/**
	 * 
	 * @return return the langMap
	 */
	public HashMap<String, String> getLangMap() {
		return langMap;
	}

	/**
	 * 
	 * @param langMap
	 *            set langMap contains paths of prompt directory
	 */
	public void setLangMap(HashMap<String, String> langMap) {
		this.langMap = langMap;
	}

	/**
	 * 
	 * @return contains link Information for particular ID
	 */
	public HashMap<String, String> getLinkMap() {
		return linkMap;
	}

	/**
	 * 
	 * @param linkMap
	 *            set link information of particular item Id
	 */
	public void setLinkMap(HashMap<String, String> linkMap) {
		this.linkMap = linkMap;
	}

	/**
	 * 
	 * @return appId of Call
	 */
	public String getServiceId() {
		return serviceId;
	}

	/**
	 * 
	 * @param serviceId
	 *            set appId of call
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	/**
	 * 
	 * @return contains info applications variables
	 */
	public HashMap<String, String> getVarMap() {
		return varMap;
	}

	/**
	 * 
	 * @param varMap
	 *            set application variables
	 */
	public void setVarMap(HashMap<String, String> varMap) {
		this.varMap = varMap;
	}

	/**
	 * clear varMap
	 */
	public void clearMap() {
		this.varMap.clear();
	}

	public byte getChangeShortcode() {
		return changeShortcode;
	}

	public void setChangeShortcode(byte changeShortcode) {
		this.changeShortcode = changeShortcode;
	}

	public HashMap<String, DbPool> getConPoolMap() {
		return conPoolMap;
	}

	public void setConPoolMap(HashMap<String, DbPool> conPoolMap) {
		this.conPoolMap = conPoolMap;
	}

}
