package com.telemune.ivr.bean;

import java.util.concurrent.*;

/**
 * This class is used to set parameter value of query(insert,delete,update) in database  operation
 * 
 * @author jeevan
 */
public class DbParamBean {
	String data;
	String name;
	String type;
	String paramIndex;

	public void setParamIndex(String paramIndex) {
		this.paramIndex = paramIndex;
	}

	public String getParamIndex() {
		return paramIndex;
	}

	public DbParamBean(String data, String name, String type, String paramIndex) {
		this.data = data;
		this.name = name;
		this.type = type;
		this.paramIndex = paramIndex;
	}

	public DbParamBean() {
		super();
	}

	public void setData(String data) {
		this.data = data;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getData() {
		return data;
	}

	public String getName() {
		return name;
	}

	public String getType() {
		return type;
	}

	private ConcurrentHashMap<String, DbParamBean> dbmap;

	public void setDbmap(ConcurrentHashMap<String, DbParamBean> dbmap) {
		this.dbmap = dbmap;
	}

	public ConcurrentHashMap<String, DbParamBean> getDbmap() {
		return dbmap;
	}

}
