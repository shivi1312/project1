package com.telemune.ivr.bean;

public class DbPool {

	String username ="";
	String password ="";
	String ip="";
	String port="";
	String databaseType="";
	String databasename="";
	
	public DbPool() {
		super();
		
	}
	public DbPool(String username, String password, String ip, String port,
			String databaseType,String databasename) {
		super();
		this.username = username;
		this.password = password;
		this.ip = ip;
		this.port = port;
		this.databaseType = databaseType;
		this.databasename = databasename;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getDatabaseType() {
		return databaseType;
	}
	public void setDatabaseType(String databaseType) {
		this.databaseType = databaseType;
	}
	public String getDatabasename() {
		return databasename;
	}
	public void setDatabasename(String databasename) {
		this.databasename = databasename;
	}
	
	
}
