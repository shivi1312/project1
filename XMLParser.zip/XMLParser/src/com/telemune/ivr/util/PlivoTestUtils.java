package com.telemune.ivr.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import org.apache.log4j.Logger;

/**
 * This class is used to track the state of a particular Call
 * 
 * @author jeevan
 */
class PlivoTestUtils {
	public static Logger logger = Logger.getLogger(PlivoTestUtils.class);

	private static final Properties testProp = new Properties();
	private static volatile boolean initialized = false;

	public static final String GATEWAYS = "user/,user/";
	public static final String GATEWAY_RETRIES = "1,1";
	public static final String EXTRA_DIAL_STRING = "bridge_early_media=true,hangup_after_bridge=true";
	public static final String GATEWAY_TIMEOUTS = "60,60";
	public static final String GATEWAY_CODECS = "'PCMA,PCMU'";

	public static Map<String, String> mapToSingleValue(
			Map<String, String[]> seed) {
		Map<String, String> result = new HashMap<String, String>();
		Iterator<String> iterator = seed.keySet().iterator();
		String key = null;
		String[] value = null;
		StringBuilder sb = new StringBuilder();
		while (iterator.hasNext()) {
			key = iterator.next();
			value = seed.get(key);
			// logger.info("Key ["+key+"] Value is ["+value+"]");
			if (value.length == 1) {
				result.put(key, String.valueOf(value[0]));
			} else {
				for (String v : value) {
					v = String.valueOf(v);
					// logger.info("=======value====== "+v);
					if (sb.length() > 0)
						sb.append(",");
					sb.append(v);
				}
				result.put(key, value[0]);
			}
		}
		// logger.info("=========Returning result======== "+result);
		return result;
	}

	public static String get(String name) {
		initProperties();

		return testProp.getProperty(name);
	}

	public static String getAccountId() {
		return get("accountId");
	}

	public static String getAuthToken() {
		return get("authToken");
	}

	public static String getPlivoUrl() {
		return get("plivoUrl");
	}

	public static String getCallbackUrl() {
		return get("callbackUrl");
	}

	private static void initProperties() {
		if (initialized)
			return;
		synchronized (PlivoTestUtils.class) {
			if (initialized)
				return;

			try {
				testProp.load(PlivoTestUtils.class
						.getResourceAsStream("/test.properties"));
				logger.info("Data is in plivotestutils ["
						+ PlivoTestUtils.class
								.getResourceAsStream("/test.properties") + "]");

				initialized = true;
			} catch (IOException e) {
				logger.error(e);
				throw new RuntimeException(e);
			}
		}
	}

}
