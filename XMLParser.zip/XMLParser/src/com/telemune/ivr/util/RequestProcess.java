package com.telemune.ivr.util;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.plivo.bridge.client.PlivoClient;
import org.plivo.bridge.exception.PlivoClientException;
import org.plivo.bridge.to.response.TransfCallResponse;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.telemune.ivr.bean.DbPool;
import com.telemune.ivr.bean.InputDataBean;
import com.telemune.ivr.bean.OutputDataBean;
import com.telemune.ivr.bean.RequestBean;
import com.telemune.ivr.db.DbOperation;
import com.telemune.ivr.servlet.PlivoControlServlet;

/**
 * This class is used to perform action on the basis of actionType( play ,record
 * ,playandcontinue etc)
 * 
 * @author jeevan
 */
public class RequestProcess {

	Logger logger = Logger.getLogger(RequestProcess.class);

	/**
	 * This method find the action and links for a IVR call
	 * 
	 * @param request
	 *            HttpRequest
	 * @param response
	 *            HttpResponse
	 * @param callUUID
	 *            Unique Id of IVR call
	 * @param itemId
	 *            Item ID in XML whom actions and links are to be found
	 * @param actionSequence
	 *            maintain the sequence how many actions are processed
	 * @param reqbean
	 *            contains whole information about particular IVR call
	 * @param vxReader
	 *            is the object contains XML for particular shortcode
	 * @param httpClient
	 *            httpclient
	 * @param pxGenerator
	 *            Object of PlivoXMlGenerator which contains all voice actions
	 * @param separator
	 *            is used to separate the multiple voice file
	 */

	// doActionEvent method Start here
	public void doActionEvent(HttpServletRequest request,
			HttpServletResponse response, String callUUID, String itemId,
			byte actionSequence, RequestBean reqbean, VoiceXmlReader vxReader,
			HttpClient httpClient, PlivoXmlGenerator pxGenerator,
			String separator) {
		logger.debug("[" + callUUID
				+ "] #Inside doActionEvent() of RequestProcess vxReader is ["
				+ vxReader + "]");
		try {

			HashMap<String, Object> paramMap = new HashMap<String, Object>();

			while (true) {
				try {
					if (reqbean.getLinkMap() != null) {
						logger.debug("[" + callUUID + "] #Link is Available ["
								+ reqbean.getLinkMap().get("itemId") + "]");
						if (reqbean.getLinkMap().get("itemId") != null) {
							reqbean.setItemId(reqbean.getLinkMap()
									.get("itemId"));
							logger.debug("[" + callUUID
									+ "] #item id is set in bean is ["
									+ reqbean.getLinkMap().get("itemId") + "]");
							if (itemId.equals(reqbean.getItemId())) {

							} else {
								actionSequence = Byte.parseByte(reqbean
										.getLinkMap().get("actionSequence")
										.toString());
							}
						}
					} else {
						logger.debug("[" + callUUID
								+ "] # link is not available");
					}
				} catch (Exception ex) {
					logger.fatal(
							"["
									+ callUUID
									+ "] #Error in while loop of doActionEvent() RequestProcess ",
							ex);
					break;
				}
				try {
					logger.debug("[" + callUUID
							+ "] # Now getting action details for itemId ["
							+ reqbean.getItemId() + "]");

					reqbean.setActionMap(vxReader.getActionDetail(
							reqbean.getItemId(), actionSequence,
							reqbean.getVarMap()));
					logger.debug("[" + callUUID + "] ActionMap is Now ["
							+ reqbean.getActionMap() + "]");
					if (reqbean.getActionMap() != null) { // process action for
															// item id
						logger.debug("[" + callUUID + "] # action type ["
								+ reqbean.getActionMap().get("actionType")
								+ "]");
						logger.debug("[" + callUUID
								+ "] #  action details found for itemId ["
								+ reqbean.getItemId() + "]");
						if (reqbean.getActionMap().get("actionType")
								.equals("voice")) {
							logger.debug("[" + callUUID
									+ "] # voice action is under process");
							paramMap = vxReader.getParamMap(reqbean
									.getActionMap().get("action"), reqbean
									.getActionMap().get("actionType"), reqbean
									.getItemId(), reqbean.getLangMap(), reqbean
									.getVarMap()); // getting param tag data
													// using action & actionType
							logger.debug("[" + callUUID
									+ "] Param Map for Item Id ["
									+ reqbean.getItemId() + "] is [" + paramMap
									+ "]");
							pxGenerator.doMyAction(request, response,
									reqbean.getActionMap(), paramMap,
									reqbean.getVarMap(), reqbean.getLangMap(),
									separator);
							actionSequence++;
							if (!(reqbean.getItemId()
									.equalsIgnoreCase("#hangup"))) {
								reqbean.getLinkMap().put("actionSequence",
										Byte.toString(actionSequence));
								logger.info("["
										+ callUUID
										+ "] # Now item id set in bean from Link Map is ["
										+ reqbean.getLinkMap().get("itemId")
										+ "]");
								reqbean.setItemId(reqbean.getLinkMap().get(
										"itemId"));
							}
							reqbean.setActionSequence(actionSequence);
							if (reqbean.getActionMap().get("action")
									.equalsIgnoreCase("playandcontinue")) {
								continue;
							} else {
								break;
							}

						}
						if (reqbean.getActionMap().get("actionType")
								.equalsIgnoreCase("dbop")) {
							logger.debug("[" + callUUID
									+ "] # DBOP action is under process");
							paramMap = vxReader.getParamMap(reqbean
									.getActionMap().get("action"), reqbean
									.getActionMap().get("actionType"), reqbean
									.getItemId(), reqbean.getLangMap(), reqbean
									.getVarMap()); // getting param tag data
													// using action & actionType
							logger.debug("[" + callUUID
									+ "] Param Map for Item Id ["
									+ reqbean.getItemId() + "] is [" + paramMap
									+ "]");
							// pxGenerator.doMyAction(request, response,
							// reqbean.getActionMap(),paramMap,reqbean.getVarMap(),reqbean.getLangMap(),separator);
							performDbOperation(reqbean.getActionMap(),
									paramMap, reqbean.getVarMap(),
									reqbean.getLangMap(),
									reqbean.getDbVarMap(),
									reqbean.getConPoolMap(), separator);
							logger.debug("##> action sequence before increment "
									+ actionSequence + "");
							++actionSequence;
							logger.info("##> action sequence after increment "
									+ actionSequence + "");
							if (actionSequence < Byte.parseByte(reqbean
									.getActionMap().get("actionSequence"))) {

								reqbean.getLinkMap().put("actionSequence",
										Byte.toString(actionSequence));
								logger.info("[" + callUUID
										+ "] more action left to process");
								continue;
							} else {
								actionSequence = 0;
								reqbean.getLinkMap().put("actionSequence",
										Byte.toString(actionSequence));
								logger.info("[" + callUUID
										+ "] No more action left to process");
								reqbean.setLinkMap(vxReader.getNextActionLink(
										reqbean.getItemId(),
										reqbean.getVarMap()));
							}

							logger.info("[" + callUUID
									+ "] # db action ends here");

						} else if (reqbean.getActionMap().get("actionType")
								.equals("javascript")) {

							logger.info("[" + callUUID
									+ "] # jsMenu action is under process");
							paramMap = vxReader.getParamMap(reqbean
									.getActionMap().get("action"), reqbean
									.getActionMap().get("actionType"), reqbean
									.getItemId(), reqbean.getLangMap(), reqbean
									.getVarMap()); // getting param tag data
													// using action & actionType
							logger.debug("[" + callUUID
									+ "] Param Map for Item Id ["
									+ reqbean.getItemId() + "] is [" + paramMap
									+ "]");
							performJsOperation(reqbean.getActionMap(),
									paramMap, reqbean.getVarMap(),
									reqbean.getLangMap(),
									reqbean.getConPoolMap(),
									ServiceInfo.jsTextMap, separator);
							logger.debug("##> action sequence before increment "
									+ actionSequence + "");
							++actionSequence;
							logger.debug("##> action sequence after increment "
									+ actionSequence
									+ "action sequence in reuest ["
									+ Byte.parseByte(reqbean.getActionMap()
											.get("actionSequence")) + "]");
							if (actionSequence < Byte.parseByte(reqbean
									.getActionMap().get("actionSequence"))) {

								reqbean.getLinkMap().put("actionSequence",
										Byte.toString(actionSequence));
								logger.info("[" + callUUID
										+ "] more action left to process");
								continue;
							} else {
								actionSequence = 0;
								reqbean.getLinkMap().put("actionSequence",
										Byte.toString(actionSequence));
								logger.info("[" + callUUID
										+ "] No more action left to process");
								reqbean.setLinkMap(vxReader.getNextActionLink(
										reqbean.getItemId(),
										reqbean.getVarMap()));
							}

							logger.info("[" + callUUID
									+ "] # jsMenu action ends here");

						}

						else if (reqbean.getActionMap().get("actionType")
								.equals("INTERNAL")) {
							logger.debug("[" + callUUID
									+ "] # internal action is under process");
							paramMap = vxReader.getParamMap(reqbean
									.getActionMap().get("action"), reqbean
									.getActionMap().get("actionType"), reqbean
									.getItemId(), reqbean.getLangMap(), reqbean
									.getVarMap());
							for (Iterator iter = paramMap.entrySet().iterator(); iter
									.hasNext();) {
								Map.Entry entry = (Map.Entry) iter.next();

								String key = (String) entry.getKey();
								String keyvalue = (String) entry.getValue();
								logger.debug("[" + callUUID
										+ "] In Internal key [" + key
										+ "] value [" + keyvalue + "]");
								if (reqbean.getVarMap().containsKey(key)
										&& reqbean.getVarMap().containsKey(
												keyvalue)) {
									String interChangeKey = keyvalue;// paramMap.get(key).toString();
									String newKeyVal = reqbean.getVarMap().get(
											interChangeKey);
									reqbean.getVarMap().put(key, newKeyVal);
								} else if (reqbean.getVarMap().containsKey(key)
										&& keyvalue
												.equalsIgnoreCase("_sysdate")) {
									logger.debug("CallUUID["
											+ callUUID
											+ "] the current date going set in ["
											+ key + "]");

									String currentTime = this.getTime(callUUID);
									reqbean.getVarMap().put(key, currentTime);
								}

								else if (reqbean.getVarMap().containsKey(key)) {
									reqbean.getVarMap().put(key, keyvalue);
								}

							}
							++actionSequence;
							if (actionSequence < Byte.parseByte(reqbean
									.getActionMap().get("actionSequence"))) {

								reqbean.getLinkMap().put("actionSequence",
										Byte.toString(actionSequence));
								logger.info("[" + callUUID
										+ "] more action left to process");
								continue;
							} else {
								actionSequence = 0;
								reqbean.getLinkMap().put("actionSequence",
										Byte.toString(actionSequence));
								logger.debug("[" + callUUID
										+ "] No more action left to process");
								reqbean.setLinkMap(vxReader.getNextActionLink(
										reqbean.getItemId(),
										reqbean.getVarMap()));
							}

							logger.debug("[" + callUUID
									+ "] # internal action ends here");
						} else if (reqbean.getActionMap().get("actionType")
								.equals("HTTP")) {
							logger.debug("[" + callUUID
									+ "] # http action is under process");
							String url = "";
							paramMap = vxReader.getParamMap(reqbean
									.getActionMap().get("action"), reqbean
									.getActionMap().get("actionType"), reqbean
									.getItemId(), reqbean.getLangMap(), reqbean
									.getVarMap());
							ArrayList<String> paramList = null;
							ArrayList<String> setList = null;
							Set<String> paramKey = paramMap.keySet();

							for (Iterator<String> param = paramKey.iterator(); param
									.hasNext();) {
								String key = param.next();
								if (key.equals("URL")) {
									url = paramMap.get(key).toString();
								} else if (key.equals("parameter")) {
									paramList = (ArrayList) paramMap.get(key);

								} else if (key.equals("set")) {
									setList = (ArrayList) paramMap.get(key);
								}
							}
							logger.debug("callUUID" + "[" + callUUID
									+ "] parameter passed to hit http :["
									+ paramList + "]");

							String responseBody = sendRequestAndGetResponsePersistnace(
									url, paramList, request, callUUID, reqbean,
									httpClient);
							String xpathQuery = "/response/var";

							HashMap<String, String> responseMap = getResponseMap(
									callUUID, xpathQuery, responseBody);
							String key = "";
							if (setList != null && (!setList.isEmpty())) {
								for (Iterator<String> setItr = setList
										.iterator(); setItr.hasNext();) {
									key = setItr.next();
									if (reqbean.getVarMap().containsKey(key)
											&& responseMap.containsKey(key)) {
										reqbean.getVarMap().put(key,
												responseMap.get(key));
									}
								}
							}
							++actionSequence;
							logger.debug("action seq : [" + actionSequence
									+ "]");

							if (!(reqbean.getItemId()
									.equalsIgnoreCase("#hangup"))) { // changes
																		// done
																		// by
																		// alkesh

								reqbean.getLinkMap().put("actionSequence",
										Byte.toString(actionSequence));
							}
							reqbean.setActionSequence(actionSequence);
							if (actionSequence < Byte.parseByte(reqbean
									.getActionMap().get("actionSequence"))) {
								logger.debug("[" + callUUID
										+ "] more action left to process");
								continue;
							} else {
								logger.debug("["
										+ callUUID
										+ "] No more action left to process reading links in http");
								actionSequence = 0;
								reqbean.getLinkMap().put("actionSequence",
										Byte.toString(actionSequence));

								reqbean.setLinkMap(vxReader.getNextActionLink(
										reqbean.getItemId(),
										reqbean.getVarMap()));
							}
						} else if (reqbean.getActionMap().get("actionType")
								.equals("CALL")) {
							String forwardNumber = null;
							logger.info("[" + callUUID
									+ "] # call action is under process");
							paramMap = vxReader.getParamMap(reqbean
									.getActionMap().get("action"), reqbean
									.getActionMap().get("actionType"), reqbean
									.getItemId(), reqbean.getLangMap(), reqbean
									.getVarMap());
							for (Iterator iter = paramMap.entrySet().iterator(); iter
									.hasNext();) {
								Map.Entry entry = (Map.Entry) iter.next();

								String key = (String) entry.getKey();
								String keyvalue = (String) entry.getValue();
								logger.info("[" + callUUID + "] In Call key ["
										+ key + "] call num value [" + keyvalue
										+ "]");
								if (reqbean.getVarMap().containsKey(key)
										&& reqbean.getVarMap().containsKey(
												keyvalue)) {
									String interChangeKey = keyvalue;
									String newKeyVal = reqbean.getVarMap().get(
											interChangeKey);
									reqbean.getVarMap().put(key, newKeyVal);

									forwardNumber = newKeyVal;

								} else if (reqbean.getVarMap().containsKey(key)) {

									reqbean.getVarMap().put(key, keyvalue);
									forwardNumber = keyvalue;
								}

								callForwarding(request, response, reqbean,
										forwardNumber, callUUID);

							}
							actionSequence++;
							if (!(reqbean.getItemId()
									.equalsIgnoreCase("#hangup"))) {
								reqbean.getLinkMap().put("actionSequence",
										Byte.toString(actionSequence));
								logger.info("["
										+ callUUID
										+ "] # Now item id set in bean from Link Map is ["
										+ reqbean.getLinkMap().get("itemId")
										+ "]");
								reqbean.setItemId(reqbean.getLinkMap().get(
										"itemId"));
							}
							reqbean.setActionSequence(actionSequence);
							if (reqbean.getActionMap().get("action")
									.equalsIgnoreCase("playandcontinue")) {
								logger.debug("[" + callUUID
										+ "] # call action ends here");
								continue;
							} else {
								logger.debug("[" + callUUID
										+ "] # call action ends here");
								break;
							}

							/*
							 * ++actionSequence; if (actionSequence <
							 * Byte.parseByte(reqbean
							 * .getActionMap().get("actionSequence"))) {
							 * 
							 * reqbean.getLinkMap().put("actionSequence",
							 * Byte.toString(actionSequence)); logger.info("[" +
							 * callUUID + "] more action left to process");
							 * continue; } else { actionSequence = 0;
							 * reqbean.getLinkMap().put("actionSequence",
							 * Byte.toString(actionSequence)); logger.info("[" +
							 * callUUID + "] No more action left to process");
							 * reqbean.setLinkMap(vxReader.getNextActionLink(
							 * reqbean.getItemId(), reqbean.getVarMap())); }
							 */

						}

					} else { // No Action founds reading links
						logger.debug("[" + callUUID
								+ "] No Action is found Now going to read Lnks");

						reqbean.setLinkMap(vxReader.getNextActionLink(
								reqbean.getItemId(), reqbean.getVarMap()));
						actionSequence = 0;
						reqbean.getLinkMap().put("actionSequence",
								Byte.toString(actionSequence));
					}
					if ((reqbean.getLinkMap().get("itemId") == null || reqbean
							.getLinkMap().get("itemId").equals(""))
							|| reqbean.getLinkMap().get("itemId")
									.equals("#hangup")) {
						break;
					}

				} catch (Exception ex) {
					logger.fatal("[" + callUUID
							+ "] # Error in getting Action details ", ex);
					break;
				}
			}
		} catch (Exception ex) {
			logger.fatal("[" + callUUID
					+ "] #Error in doActionEvent() of RequestProcess ", ex);
		}
	}// doActionEvent method End here

	private void callForwarding(HttpServletRequest request,
			HttpServletResponse response, RequestBean reqbean,
			String forwardNumber, String callUUID) {

		logger.debug("[" + callUUID + "] # Call forwaring Request Comes ####");
		String sip_ip = null;
		String sip_port = null;

		if (reqbean.getVarMap().containsKey("sip_ip"))
			sip_ip = reqbean.getVarMap().get("sip_ip");
		else
			sip_ip = PlivoControlServlet.ip.trim();

		if (reqbean.getVarMap().containsKey("sip_port"))
			sip_port = reqbean.getVarMap().get("sip_port");
		else
			sip_port = PlivoControlServlet.port.trim();

		String auth_id = PlivoControlServlet.authId;
		String auth_token = PlivoControlServlet.authToken;
		String plivo_url = PlivoControlServlet.plivoUrl;
		PlivoClient newClient = new PlivoClient("v0.1", auth_id, auth_token,
				plivo_url, true);
		String forwardingUrl = "http://" + PlivoControlServlet.ip.trim() + ":"
				+ PlivoControlServlet.port.trim() + "/"
				+ request.getContextPath().replace("/", "") + "/dialservlet"
				+ "?forwardingTo=" + forwardNumber + "&alegid=" + callUUID
				+ "&sip_ip=" + sip_ip + "&sip_port=" + sip_port + " ";
		logger.info("[" + callUUID + "] forwarding params forwardingNumber ["
				+ forwardNumber + "] forwardingUrl [" + forwardingUrl + "]");

		LinkedHashMap<String, String> callParamsTransfer = new LinkedHashMap<String, String>();
		callParamsTransfer.put("CallUUID", reqbean.getVarMap().get("callUUID"));
		callParamsTransfer.put("Url", forwardingUrl);

		TransfCallResponse callResponse = null;
		try {
			callResponse = newClient.call().transfer(callParamsTransfer);

		} catch (PlivoClientException e) {

			e.printStackTrace();
		}

		if (callResponse.isSuccess() == true) {
			reqbean.getVarMap().put("forwardingSuccess", "1");
		} else {
			reqbean.getVarMap().put("forwardingSuccess", "0");
		}

		logger.info("[" + reqbean.getVarMap().get("callUUID")
				+ "] call response [" + callResponse.getMessage() + "]");

		try {
			PrintWriter writer = response.getWriter();
			writer.append("200 ok");
			writer.append("" + callResponse);
			writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void performJsOperation(HashMap<String, String> actionMap,
			HashMap<String, Object> paramMap, HashMap<String, String> varMap,
			HashMap<String, String> langMap,
			HashMap<String, DbPool> conPoolMap,
			ConcurrentHashMap<String, String> jsTextMap, String separator) {
		logger.debug("[" + varMap.get("callUUID")
				+ "] # jsMenu Request Comes ####");

		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine engine = manager.getEngineByName("javascript");
		InputDataBean inputBean = new InputDataBean();
		OutputDataBean outputBean = new OutputDataBean();
		ArrayList<String> textData = new ArrayList<String>();
		ArrayList<InputDataBean> inputData = new ArrayList<InputDataBean>();
		ArrayList<OutputDataBean> outputData = new ArrayList<OutputDataBean>();
		if (jsTextMap != null) {

			inputData = (ArrayList<InputDataBean>) paramMap.get("inputData");
			outputData = (ArrayList<OutputDataBean>) paramMap.get("outputData");

			logger.debug("[" + varMap.get("callUUID")
					+ "] # jsMenu perform for menu  ####");

			textData = (ArrayList<String>) paramMap.get("textData");
			String textPath = null;
			String conditionvar = (String) paramMap.get("conditionVariable");
			logger.info("[" + varMap.get("callUUID")
					+ "] # jsMenu perform for menu condition [" + conditionvar
					+ "] ####");
			Iterator<String> iteratorText = textData.iterator();
			while (iteratorText.hasNext()) {
				textPath = iteratorText.next();
				break;
			}
			logger.info("[" + varMap.get("callUUID")
					+ "] # jsMenu perform for menu [" + textPath
					+ "] js contain [" + jsTextMap.containsKey(textPath)
					+ "]  ####");

			if (jsTextMap.containsKey(textPath)) {

				String jsQuery = jsTextMap.get(textPath);

				logger.info("[" + varMap.get("callUUID") + "]  jsQuery ["
						+ jsQuery + "]####");
				Iterator<InputDataBean> iteratorInput = inputData.iterator();
				while (iteratorInput.hasNext()) // /input value are set in
												// javascript
				{
					/* inputBean = new InputDataBean(); */
					inputBean = iteratorInput.next();
					String varName = inputBean.getName(); // /variable name of
															// javascript
					String varValue = inputBean.getData(); // / value of
															// variable
					if (varMap.containsKey(varValue)) {
						varValue = varMap.get(varValue);
					}
					logger.info("[" + varMap.get("callUUID") + "] varName ["
							+ varName + "] varValue[" + varValue + "] ####");
					engine.put(varName, varValue);
				}
				try {
					engine.eval(jsQuery);

				} catch (ScriptException e) {

					varMap.put(conditionvar, "error");
					logger.info("[" + varMap.get("callUUID")
							+ "] # Error in javascript ####");
					e.printStackTrace();
				}

				Iterator<OutputDataBean> iteratorOutput = outputData.iterator();
				while (iteratorOutput.hasNext()) // / output variable get for
													// set output of javascript
				{
					/* outputBean = new OutputDataBean(); */
					outputBean = iteratorOutput.next();
					String outputSetVar = outputBean.getName(); // variable used
																// for setting
																// the value of
																// output
					String outputGetVar = outputBean.getData(); // variable is
																// used for
																// getting the
																// value from
																// javascript

					String result = engine.get(outputGetVar).toString(); // /getting
																			// output
																			// from
																			// javascript

					/*
					 * if(result.contains(".0") &&
					 * result.indexOf(".")+2==result.length()) //remove '.0'
					 * from the string { result =
					 * result.substring(0,result.indexOf(".")); }
					 */
					varMap.put(outputSetVar, result); // putting result value in
														// varMap
					if (conditionvar.equalsIgnoreCase(outputSetVar)) {
						varMap.put(conditionvar, result);
						logger.info("[" + varMap.get("callUUID")
								+ "]condition variable outputSetVar ["
								+ outputSetVar + "] outputGetVar["
								+ varMap.get("result") + "] ####");
					}
					logger.info("[" + varMap.get("callUUID")
							+ "] outputSetVar [" + outputSetVar
							+ "] outputGetVar[" + varMap.get(outputSetVar)
							+ "] ####");
				}

			} else {
				logger.error("[" + varMap.get("callUUID")
						+ "] # Excetion in getting scriptText ####");
			}

		} else {
			logger.error("[" + varMap.get("callUUID")
					+ "] # jsTextMap is empty####");
		}
		textData = null;
		inputData = null;
		outputData = null;
		inputBean = null;
		outputBean = null;
		manager = null;
		engine = null;

		logger.info("[" + varMap.get("callUUID")
				+ "] # jsMenu Request End ####");

	}

	/**
	 * This method is used to hit the url and get the response
	 * 
	 * @param url
	 *            This is URL on which hit goes
	 * @param paramList
	 *            This contains the list of parameters which are hit with URL
	 * @param request
	 *            HttpRequest
	 * @param callUUID
	 *            Unique ID of Call
	 * @param reqbean
	 *            Bean which contains all information about a call
	 * @param httpClient
	 *            httpclient 1.1 object use to hit the url
	 * @return response on hitting
	 */
	// sendRequestAndGetResponsePersistnace method Start here
	public String sendRequestAndGetResponsePersistnace(String url,
			ArrayList<String> paramList, HttpServletRequest request,
			String callUUID, RequestBean reqbean, HttpClient httpClient) {

		logger.debug("[" + callUUID + "] Inside sendRequestGetResponse() ");
		url = url + "?";
		String paramKey = "";
		for (Iterator<String> itr = paramList.iterator(); itr.hasNext();) {
			paramKey = itr.next();

			if (reqbean.getVarMap().containsKey(paramKey)) {
				logger.debug("[" + callUUID + "] key  [" + paramKey
						+ "] value [" + reqbean.getVarMap().get(paramKey) + "]");

				if (reqbean.getVarMap().get(paramKey).contains(" "))
					url = url
							+ paramKey
							+ "="
							+ reqbean.getVarMap().get(paramKey)
									.replace(" ", "%20");
				else
					url = url
							+ paramKey
							+ "="
							+ URLEncoder.encode(reqbean.getVarMap().get(
									paramKey));

			}
			if (itr.hasNext()) {
				url = url + "&";
			}
		}
		logger.info("[" + callUUID + "] ## URL IS GOING TO HIT IS : [" + url
				+ "]");
		HttpGet httpget = null;

		httpget = new HttpGet(url);

		HttpContext context = new BasicHttpContext();

		HttpEntity entity = null;
		HttpResponse response = null;
		String responseBody = "";
		try {

			response = httpClient.execute(httpget);
			entity = response.getEntity();
			int code = response.getStatusLine().getStatusCode();
			if (code == 200) {
				responseBody = EntityUtils.toString(entity);

				responseBody = responseBody.trim();
				logger.info("[" + callUUID
						+ "] The  response of http request  is ["
						+ responseBody + "]");
			} else {
				logger.fatal("[" + callUUID
						+ "] Unable to get response , and the error code is["
						+ code + "]");
			}

		} catch (ConnectTimeoutException cnr) {
			logger.error("[" + callUUID + "]  connection time out  ", cnr);
		} catch (IOException ex) {
			logger.error("[" + callUUID
					+ "] Error in sendRequestAndgetResponse() ", ex);
		} finally {
			httpget.releaseConnection();
			httpget = null;
			context = null;
			entity = null;
			response = null;
			url = null;
			paramList = null;
			paramKey = null;
		}
		logger.debug("[" + callUUID
				+ "] ## End of sendRequestAndgetResponse() ");
		return responseBody;
	} // sendRequestAndGetResponsePersistnace method End here

	/**
	 * This function will parse the XML which comes from another war file hit
	 * using HTTP hit
	 * 
	 * 
	 * @param callUUID
	 *            This is the unique IVR call ID
	 * @param xpathQuery
	 *            This variable is used to get the value of particular node from
	 *            xml
	 * @param responseBody
	 *            Is the XML in String format . Which is going to parse here
	 * @return This return the Map with updated value of parameters
	 */
	// getResponseMap method Start here
	public HashMap<String, String> getResponseMap(String callUUID,
			String xpathQuery, String responseBody) {
		logger.debug("[" + callUUID
				+ "] # Inside getResponseMap() of RequestProcess");
		HashMap<String, String> responseMap = new HashMap<String, String>();
		Node mainNode = null;
		NamedNodeMap nnMap = null;
		Node node1 = null;
		Node node2 = null;
		XPathExpression expr = null;
		Document doc = null;
		doc = loadXmlFromString(callUUID, responseBody);
		XPathFactory xFactory = null;
		XPath xPath = null;
		Object result = null;
		NodeList ndList = null;
		try {
			xFactory = XPathFactory.newInstance();
			xPath = xFactory.newXPath();
			expr = xPath.compile(xpathQuery);
			result = expr.evaluate(doc, XPathConstants.NODESET);
			ndList = (NodeList) result;
			for (int i = 0; i < ndList.getLength(); i++) {
				mainNode = ndList.item(i);
				nnMap = mainNode.getAttributes();
				node1 = nnMap.getNamedItem("name");
				node2 = nnMap.getNamedItem("value");
				responseMap.put(node1.getNodeValue(), node2.getNodeValue());
			}
			return responseMap;
		} catch (XPathExpressionException ex) {
			logger.fatal("[" + callUUID
					+ "] XPathExpressionError in getResponseMap() ", ex);
			return null;
		} finally {
			mainNode = null;
			nnMap = null;
			node1 = null;
			node2 = null;
			expr = null;
			xFactory = null;
			xPath = null;
			result = null;
			ndList = null;
			doc = null;
			logger.debug("[" + callUUID
					+ "] # End of getResponseMap() of RequestProcess");
		}

	}// getResponseMap method End here

	/**
	 * This function is used to make the document of input string
	 * 
	 * @param callUUID
	 *            This is the unique IVR call ID
	 * @param responseBody
	 *            Is the XML in String format
	 * @return this will return the document object
	 */
	// loadXmlFromString method Start here
	public Document loadXmlFromString(String callUUID, String responseBody) {
		logger.debug("[" + callUUID + "] Inside loadXmlFromString()");
		DocumentBuilderFactory factory = null;
		DocumentBuilder db = null;
		InputSource ins = null;
		Document doc = null;
		try {
			factory = DocumentBuilderFactory.newInstance();
			db = factory.newDocumentBuilder();
			ins = new InputSource(new StringReader(responseBody));
			try {
				doc = db.parse(ins);
				return doc;
			} catch (SAXException ex) {
				logger.error("[" + callUUID
						+ "] Error in loadXmlFromString() SAXException ", ex);
				return null;
			} catch (IOException ex) {
				logger.error("[" + callUUID
						+ "] Error in loadXmlFromString() IOException ", ex);
				return null;
			}
		} catch (ParserConfigurationException ex) {
			logger.error("[" + callUUID + "] Error in loadXmlFromString() ", ex);
			return null;

		} finally {
			ins = null;
			db = null;
			factory = null;
			logger.debug("[" + callUUID + "] End of loadXmlFromString()");
		}

	}

	public void performDbOperation(HashMap<String, String> actionMap,
			HashMap<String, Object> paramMap, HashMap<String, String> varMap,
			HashMap<String, String> langMap, HashMap<String, String> dbVarMap,
			HashMap<String, DbPool> conPoolMap, String separator)
			throws SQLException {
		logger.debug("[" + varMap.get("callUUID")
				+ "] # DbOp Request Comes ####");
		int result = 0;
		DbPool dbPool = null;
		String databaseType = "";
		String username = "";
		String password = "";
		String dbip = "";
		String dbport = "";
		// RequestBean reqbean = new RequestBean();
		String conVar = (String) paramMap.get("conditionVariable");
		String queryType = (String) paramMap.get("queryType");
		String queryString = (String) paramMap.get("queryString");
		String dbname = (String) paramMap.get("dbName");
		logger.info("dbname" + dbname);

		if (conPoolMap.containsKey(dbname)) {
			logger.debug("[" + varMap.get("callUUID") + "] #database name is["
					+ dbname + "] ####");
			dbPool = conPoolMap.get(dbname);

			databaseType = dbPool.getDatabaseType();// 1
			username = dbPool.getUsername();// 2
			password = dbPool.getPassword();// 3
			dbip = dbPool.getIp();// 5
			dbport = dbPool.getPort();// 6
		} else {
			logger.debug("[" + varMap.get("callUUID") + "] #database name is["
					+ dbname + "]  not exists####");
		}

		/*
		 * String databaseType = (String) paramMap.get("databaseType");//1
		 * String username = (String) paramMap.get("username");//2 String
		 * password = (String) paramMap.get("password");//3 String dbip =
		 * (String) paramMap.get("dbip");//5 String dbport = (String)
		 * paramMap.get("dbport");//6
		 */

		DbOperation dbOperation = new DbOperation();
		String key = conVar;
		String responseResult = null;
		String dbDriver = null;
		String dbUrl = null;
		// logger.info("["+varMap.get("callUUID")+"] # DbOp Request Comes ####");
		if (databaseType.equalsIgnoreCase("mysql")) {
			// logger.info("["+varMap.get("callUUID")+"] # DbOp Request Comes ####");
			dbDriver = "com.mysql.jdbc.Driver";
			dbUrl = "jdbc:mysql://" + dbip + ":" + dbport + "/" + dbname + "";
			logger.info("[" + varMap.get("callUUID") + "] [" + dbDriver
					+ "]# [" + dbUrl + "]DbOp Request Comes ####");
		} else if (databaseType.equalsIgnoreCase("oracle")) {
			dbDriver = "oracle.jdbc.driver.OracleDriver";
			dbUrl = "jdbc:oracle:thin:" + username + "/" + password + "@"
					+ dbip + ":" + dbport + ":" + dbname + "";
		} else {
			dbDriver = "com.mysql.jdbc.Driver";
			dbUrl = "jdbc:mysql://" + dbip + ":" + dbport + "/" + dbname + "";
		}

		// logger.info("["+varMap.get("callUUID")+"] # DbOp 333 Request Comes ####  ["+queryType.equalsIgnoreCase("update")+"]+");
		if (queryType.equalsIgnoreCase("select")
				|| queryString.contains("select")) {
			logger.info("[" + varMap.get("callUUID")
					+ "] # DbOp select Comes ####");
			result = dbOperation.selectOperation(dbDriver, dbUrl, username,
					password, dbip, queryString, varMap, paramMap);
		} else if (queryType.equalsIgnoreCase("insert")
				|| queryString.contains("insert")) {
			logger.info("[" + varMap.get("callUUID")
					+ "] # DbOp insert Comes ####");
			result = dbOperation.insertOperation(dbDriver, dbUrl, username,
					password, dbip, queryString, varMap, paramMap);
		} else if (queryType.equalsIgnoreCase("update")
				|| queryString.contains("update")) {
			logger.info("[" + varMap.get("callUUID")
					+ "] # DbOp update Comes ####");
			result = dbOperation.updateOperation(dbDriver, dbUrl, username,
					password, dbip, queryString, varMap, paramMap);
			logger.info("[" + varMap.get("callUUID")
					+ "] # DbOp update End ####[" + result + "]");
		} else if (queryType.equalsIgnoreCase("delete")
				|| queryString.contains("delete")) {
			logger.info("[" + varMap.get("callUUID")
					+ "] # DbOp delete Comes ####");
			result = dbOperation.deleteOperation(dbDriver, dbUrl, username,
					password, dbip, queryString, varMap, paramMap);
		} else {
			logger.warn("NO DBOperation perform!");
			result = -1;
		}
		responseResult = Integer.toString(result); // return action result

		varMap.put(key, responseResult);
		dbPool = null;
		logger.info("[" + varMap.get("callUUID") + "] # DbOp Request ends["
				+ varMap.get(key) + "]####");
	}// loadXmlFromString method End here

	public String getTime(String callUUID) {
		logger.debug("[" + callUUID + "] #Inside getTime() ");
		String timeInfo = "";

		SimpleDateFormat sdf = null;
		if (PlivoControlServlet.db_type != null) {
			if (PlivoControlServlet.db_type.equalsIgnoreCase("mysql")) {
				sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			} else if (PlivoControlServlet.db_type.equalsIgnoreCase("oracle")) {
				sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			} else {
				sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			}
		} else {
			sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		}
		// sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		timeInfo = sdf.format(new java.util.Date());
		return timeInfo;
	}

}