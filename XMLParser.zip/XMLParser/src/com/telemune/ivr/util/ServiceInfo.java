package com.telemune.ivr.util;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.HttpParams;
import org.apache.log4j.Logger;

import com.telemune.ivr.bean.RequestBean;
import com.telemune.ivr.bean.ShortCodeConfig;
import com.telemune.ivr.db.ApplicationList;
import com.telemune.ivr.db.DbConnection;
import com.telemune.ivr.db.JavaScriptMenuText;
import com.telemune.ivr.servlet.PlivoControlServlet;
import com.telemune.listener.LoaderListener;
import com.telemune.listener.ParserListener;
import com.telemune.vcc.expiringmap.ExpiringMap;

/**
 * This class is used to track the state of a particular Call
 * 
 * @author jeevan
 */
public class ServiceInfo {

	static Logger logger = Logger.getLogger(ServiceInfo.class);
	/**
	 * Static Map Contains all the shortecode information
	 */
	public static ConcurrentHashMap<String, ShortCodeConfig> appShort = null;
	/**
	 * Static Hashtable contains XML object to each shortcode
	 */
	public static ConcurrentHashMap<String, VoiceXmlReader> voiceReaderMap = null;
	/**
	 * Map contains the HttpClient object
	 */
	public ConcurrentHashMap<String, HttpClient> httpReaderMap = null;
	/**
	 * Map contains the call state
	 */
	//public ConcurrentHashMap<String, RequestBean> beanMap = null;
	  public static ExpiringMap<String, RequestBean> beanMap = null;
	  
	  public static ExpiringMap<String,VoiceXmlReader > oldBeanMap = null;
      
      static {
          beanMap = ExpiringMap.builder().expirationListener(new ParserListener())
				.variableExpiration().expiration(PlivoControlServlet.cacheExpireTime, TimeUnit.MINUTES).build();
          
          
          
          oldBeanMap = ExpiringMap.builder().expirationListener(new LoaderListener())
  				.variableExpiration().expiration(PlivoControlServlet.cacheExpireTime, TimeUnit.MINUTES).build();
          
      }
      
	
	
	public static ConcurrentHashMap<String , String> jsTextMap = null;
	
	ShortCodeConfig shortCodeConfig = null;
	PlivoXmlGenerator pxGenerator = null;
	static JavaScriptMenuText scriptMenuText = null;
	/**
	 * Boolean object to create PlivoXmlGenerator object one time for a call
	 */
	public boolean first = false;
	/**
	 * Ip on which Plivo Hits
	 */
	public String ip;
	/**
	 * Port on which plivo hits
	 */
	public String port;

	/**
	 * This method is used to load the xml to active shortcode
	 * 
	 * @param dbDriver
	 *            MySql Driver
	 * @param dbUrl
	 *            Database URL
	 * @param dbUser
	 *            Database Name
	 * @param dbPass
	 *            Database password
	 * @param ip
	 *            Ip on which Plivo hit
	 * @param port
	 *            Port on which XMLIVR run
	 * @return PlivoXMlGenerator class object
	 */
	ApplicationList applicationList = null;
	Connection con = null;
	//loadXmlData method Start here
	public PlivoXmlGenerator loadXmlData(String dbDriver,
			String dbUrl, String dbUser, String dbPass, String ip, String port) {
		logger.info("# Inside loadXmlData() dbDriver [" + dbDriver
				+ "] dbUrl [" + dbUrl + "] dbUser [" + dbUser + "] IP [" + ip
				+ "] port [" + port + "]");
		try {

			if (appShort == null) {
				appShort = new ConcurrentHashMap<String, ShortCodeConfig>();

			} else {
				appShort.clear();

			}

			this.ip = ip;
			this.port = port;
			con = DbConnection.getConnection();
			applicationList = new ApplicationList();
			applicationList.getApplicationList(con,shortCodeConfig);

			voiceReaderMap = new ConcurrentHashMap<String, VoiceXmlReader>();
			httpReaderMap = new ConcurrentHashMap<String, HttpClient>();
		//	beanMap = new ConcurrentHashMap<String, RequestBean>();
			for (Map.Entry<String, ShortCodeConfig> entry : appShort.entrySet())
			{
				//logger.info("going to Create VxReader Instance");
				Boolean result = createVxReaderInstance(entry.getKey(),this.ip, this.port,con);
				//logger.info("instance Created");
				if (!result) 
				{
					logger.error(" Error: in create Instance of VoiceXmlReader!");
				}
			}
		} catch (Exception ex) {
			logger.fatal("# Exception in loadXMlData() ", ex);
		}
		finally
		{
			try
			{
				if(con!=null)
					con.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing connection"+e);
			}
		}
		logger.debug("# End of loadXmlData()");
		return this.pxGenerator;

	}//loadXmlData method End here

	//createVxReaderInstance method Start here
	private boolean createVxReaderInstance(String appId, String ip,String port,Connection con)
	{
		logger.debug("# Inside createVxReaderInstance()");
		String servId = appId.split("#")[0];
		// logger.info("# Create VxReader Instance for Id ["+servId+"]");
		if (!voiceReaderMap.containsKey(servId)) {
			logger.debug("# Now going to load XML for Id [" + servId + "]");
			VoiceXmlReader vxReader = new VoiceXmlReader(servId,con);
			if (vxReader.parsingSuccess) 
			{ // checking if parsing is success
				voiceReaderMap.put(servId, vxReader);
			}
			else 
			{
				return false;
			}
		}

		if (!first) 
		{
			first = true;
			this.pxGenerator = new PlivoXmlGenerator(ip, port);
		}
		this.ip = null;
		this.port = null;
		logger.debug("# End of createVxReaderInstance()");
		return true;

	}//createVxReaderInstance method End here

	//getDefaultShortCodeId method Start here
	public String getDefaultShortCodeId(String callUUID, String destSC,
			String direct) {
		logger.debug("[" + callUUID
				+ "] Inside getDefaultShortCodeId() calledNum [" + destSC
				+ "] Direction [" + direct + "]");
		String shortCodeId = null;
		for (Map.Entry<String, ShortCodeConfig> entry3 : appShort.entrySet()) {
			ShortCodeConfig codeBean1 = entry3.getValue();
			if (destSC.startsWith(codeBean1.getShortCode())
					&& direct.equalsIgnoreCase(codeBean1.getDirection())
					&& codeBean1.getAddCode().equalsIgnoreCase("DF")) {

				logger.debug("Direct Case of Short Code= " + destSC);
				shortCodeId = entry3.getKey().split("#")[0];
			}
			if (shortCodeId != null) {
				break;
			}
		}
		logger.debug("####### Default Shortcode is [" + shortCodeId + "]");
		logger.info("#getDefaultShortCodeId() ends here ####");

		return shortCodeId;
	}//getDefaultShortCodeId method End here

	//createHttpClient method Start here
	public void createHttpClient(String callUUID, String servId,
			HashMap<String, String> varMap, String ip,
			String port, String soTimeout, String conTimeout,
			String conManTimeout) {
		logger.debug("[" + callUUID
				+ "] #Inside createHttpClientObject() of appId [" + servId
				+ "]");
		String httpIp = "";
		int httpPort = 0;
		try {
			if (varMap.containsKey("hit_ip")) {
				httpIp = varMap.get("hit_ip");
				logger.debug("[" + callUUID + "] #Xml Contains hit_ip ["
						+ varMap.get("hit_ip") + "]");
				if (httpIp == null || httpIp == "") {
					httpIp = ip;
				}
			} else {
				logger.debug("ip is ::-----------"+ip);
				httpIp = ip;
			}
			if (varMap.containsKey("hit_port")) {

				logger.debug("[" + callUUID + "] #Xml Contains hit_ip ["
						+ varMap.get("hit_ip") + "]");
				if (varMap.get("hit_port") == null
						|| varMap.get("hit_port") == "") {
					httpPort = Integer.parseInt(port);
				} else {
					httpPort = Integer.parseInt(varMap.get("hit_port"));
				}
			} else {
				
				httpPort = Integer.parseInt(port);
			}
			logger.info("[" + callUUID + "] HttpIp is [" + httpIp
					+ "] HttpPort is [" + httpPort + "]");
			SchemeRegistry schemeRegistry = new SchemeRegistry();
			schemeRegistry.register(new Scheme("http", httpPort,
					PlainSocketFactory.getSocketFactory())); // create
																// http://10.168.1.71:1000/
																// schemes

			PoolingClientConnectionManager cm = new PoolingClientConnectionManager(
					schemeRegistry);

			cm.setMaxTotal(300);
			cm.setDefaultMaxPerRoute(20);
			HttpHost localhost = new HttpHost(httpIp, httpPort);
			cm.setMaxPerRoute(new HttpRoute(localhost), 250);

			HttpClient _httpClient = new DefaultHttpClient(cm);
			HttpParams _httpPramas = _httpClient.getParams();
			_httpPramas.setIntParameter(CoreConnectionPNames.SO_TIMEOUT,
					Integer.parseInt(soTimeout));
			_httpPramas.setIntParameter(
					CoreConnectionPNames.CONNECTION_TIMEOUT,
					Integer.parseInt(conTimeout));
			_httpPramas.setLongParameter(ClientPNames.CONN_MANAGER_TIMEOUT,
					Long.parseLong(conManTimeout));
			logger.debug("[" + callUUID
					+ "] HttClient is now in createHttpClient is ["
					+ _httpClient + "]");
			logger.debug("[" + callUUID
					+ "] Size of Map before in createHttpClient is ["
					+ httpReaderMap.size() + "]");
			httpReaderMap.put(servId, _httpClient);
			logger.debug("[" + callUUID
					+ "] Size of Map after in createHttpClient is ["
					+ httpReaderMap.size() + "]");
		} catch (Exception ex) {
			logger.fatal(
					"["
							+ callUUID
							+ "] # Error in creating Http Client from createHttpClient() of appId ["
							+ servId + "] with error ", ex);
		}
		logger.debug("[" + callUUID + "] #End of createHttpClient() method ###");

	}//createHttpClient method End here

	//getAppIdForCall method Start here
	public String getAppIdForCall(String destSC, String direct) {
		logger.debug("#getAppIdForCall() starts here ####");
		String initSc = "";
		int initScLen = 0;
		String defautlAppID = null;
		String finalAppID = null;
		String keyIs = "";
	
		for (Map.Entry<String, ShortCodeConfig> entry : appShort.entrySet()) {
			ShortCodeConfig codeBean = entry.getValue();
			logger.debug("App_id 1" + codeBean.getAppID() + "Direction "+codeBean.getDirection()+"short code"+codeBean.getShortCode());
			if (destSC.equalsIgnoreCase(codeBean.getShortCode())
					&& direct.equalsIgnoreCase(codeBean.getDirection())
					&& (codeBean.getAddCode().equalsIgnoreCase("DF") || codeBean
							.getAddCode().equalsIgnoreCase("NA"))) {

				logger.debug("Direct Case of Short Code= " + destSC);
				finalAppID = entry.getKey().split("#")[0];
				logger.debug("finalAppId"+entry.getKey().split("#")[0]);
				keyIs = entry.getKey();
			}
			if (finalAppID != null) {
				break;
			}
		}
		ShortCodeConfig testBean1 = null;
		ShortCodeConfig testBean2 = null;
		if (finalAppID == null) {
									/// calledNum contain additional digit than that condition is execute  
			String bkSc = "";
			logger.info("InDirect Case of Short Code= " + destSC);

			for (Map.Entry<String, ShortCodeConfig> entry : appShort.entrySet()) {

				testBean1 = null;
				testBean2 = null;
				ShortCodeConfig codeBean = entry.getValue();
				logger.debug("App_id " + codeBean.getAppID() + "Direction "+codeBean.getDirection()+"short code"+codeBean.getShortCode());
				if (destSC.startsWith(codeBean.getShortCode())
						&& direct.equalsIgnoreCase(codeBean.getDirection())
						&& (!codeBean.getAddCode().equalsIgnoreCase("NA"))) {
					bkSc = destSC;
					initScLen = codeBean.getShortCode().length();
					initSc = bkSc.substring(initScLen, bkSc.length());
					bkSc = bkSc.substring(0, initScLen);

					logger.debug("New Dest ID=" + bkSc
							+ "\n Entering into Default ID section!!");
					for (Map.Entry<String, ShortCodeConfig> entry1 : appShort
							.entrySet()) {
						testBean1 = entry1.getValue();
						if (bkSc.equalsIgnoreCase(testBean1.getShortCode())
								&& direct.equalsIgnoreCase(testBean1
										.getDirection())) {
							testBean2 = appShort.get(codeBean.getAppID()
									+ "#DF");
							if (testBean2 != null) {
								logger.info(" Detected Default App ID "
										+ testBean2.getAppID());
								defautlAppID = testBean2.getAppID().split("#")[0];
								keyIs = entry.getKey();
								logger.info(" Default APP ID ASSIGNED="
										+ defautlAppID);
								break;
							}
						}
					}
					if (bkSc.equalsIgnoreCase(codeBean.getShortCode())
							&& direct.equalsIgnoreCase(codeBean.getDirection())) {   // check length of additional digits == length of additional digits of shortcode 
						if (initSc.length() == codeBean.getAddCode().length()) {
							finalAppID = entry.getKey().split("#")[0];
							keyIs = entry.getKey();
							logger.info(" Addition Code Matched  APP ID taken="
									+ keyIs);
						}
					}
				}
				if (finalAppID != null) {
					break;
				}
			}
			if (finalAppID == null) {
				finalAppID = (defautlAppID != null) ? defautlAppID : null;
			}
		}

		logger.debug("AppId for this short["+direct+"] is ["+finalAppID+"] ");
		logger.debug("#getAppIdForCall() ends here ####");
		return finalAppID;

	}//getAppIdForCall method End here

	public static void loadJavaScriptText(){
		logger.info("# Inside loadJavaScriptText() ");
		if(jsTextMap == null)
		{
			jsTextMap = new  ConcurrentHashMap<String,String>();
		}else
		{
			jsTextMap.clear();
		}
		
		scriptMenuText = new JavaScriptMenuText();
		
		jsTextMap = scriptMenuText.getJavaScriptText(jsTextMap);
		
		logger.info("# end of loadJavaScriptText() ");
	}

}
