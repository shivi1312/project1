package com.telemune.ivr.util;

import java.io.IOException;
import java.io.StringReader;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.telemune.ivr.bean.DbParamBean;
import com.telemune.ivr.bean.DbSelectBean;
import com.telemune.ivr.bean.InputDataBean;
import com.telemune.ivr.bean.OutputDataBean;
import com.telemune.ivr.db.XMLData;
/**
 * This class is used to parse xml 
 * 
 * @author jeevan
 */
public class VoiceXmlReader {

	Logger logger = Logger.getLogger(VoiceXmlReader.class);

	public boolean parsingSuccess = false;
	XPath xpath = null;
	/**
	 * xPath object used for parsing
	 */
	public String varXmlQuery = "/menus/var";
	/**
	 * to find var node values and attributes from xml
	 */
	public String dbVarXmlQuery = "/menus/dbpool";
	/**
	 * to find var node values and attributes from xml
	 */
	
	public String varAttrib = "name";
	/**
	 * to find name node value
	 */
	public String varAttribVal = "value";
	/**
	 * to find value node value
	 */
	public String langXmlQuery = "/menus/lang";
	/**
	 * to find lang node values and attributes from xml
	 */
	public String langAttrib = "id";
	/**
	 * to find id node value
	 */
	public String langAttribVal = "filepath";
	Document doc = null;
	//XMLData xmlData = new XMLData();

	
	//VoiceXmlReader constructor Start here
	public VoiceXmlReader(String servId,Connection con) 
	{
		XMLData xmlData = new XMLData();
		logger.debug("# Inside VoiceXmlReader constructor");
		String xmlDataDb = xmlData.getXmlData(servId,con);

		if (xmlDataDb != null) {
			InputSource inSrc = new InputSource(new StringReader(xmlDataDb)); // A
																				// single
																				// input
																				// source
																				// for
																				// an
																				// XML
																				// entity.
			DocumentBuilderFactory factory = DocumentBuilderFactory
					.newInstance();
			try {
				DocumentBuilder builder = factory.newDocumentBuilder();
				try {
					this.doc = builder.parse(inSrc);
					XPathFactory xFactory = XPathFactory.newInstance();
					this.xpath = xFactory.newXPath();
					parsingSuccess = true;
				} catch (SAXException ex) {
					logger.fatal("# Unable to Parse the XML of Id [" + servId
							+ "] with error ", ex);
					parsingSuccess = false;
				} catch (IOException ex) {
					logger.fatal("# Input Source not found for Id [" + servId
							+ "] with error ", ex);
					parsingSuccess = false;
				}
			} catch (ParserConfigurationException ex) {
				logger.fatal(
						"# Unable to confihure Parser in VoiceXmlReader Construvtor ",
						ex);
				parsingSuccess = false;
			}
		} else {
			logger.info("# Xml not loaded for appId [" + servId + "]");
			parsingSuccess = false;
		}

		logger.debug("# VoiceXmlReader Ends Here");
	} // VoiceXmlReader Constructor Ends here

	/**
	 * 
	 * this method is used to load the global variables of xml
	 * 
	 * @param callUUID
	 *            unique id of call
	 * @param varXmlQuery
	 *            string to be search in xml
	 * @param varAttrib
	 *            string to be search in xml
	 * @param varAttribVal
	 *            string to be search in xml
	 * @return return map with updated parameters
	 */
	
	//getXmlLangOrVarData method Start here
	public HashMap<String, String> getXmlLangOrVarData(
			String callUUID, String varXmlQuery, String varAttrib,
			String varAttribVal) {
		logger.debug("[" + callUUID + "] # Inside getXmlLangOrVarData() ### langXmlQuery ["+varXmlQuery+"=]langAttrib["+varAttrib+"] langAttribVal["+varAttribVal+"]");

		HashMap<String, String> langOrVarMap = new HashMap<String, String>();
		Node mainNode = null;
		NamedNodeMap nnMap = null;
		Node node1 = null;
		Node node2 = null;
		XPathExpression expr = null;
		Object result = null;
		NodeList ndList = null;
		try {
			expr = (XPathExpression) this.xpath.compile(varXmlQuery);
			
			synchronized (this) 
			{
				result = expr.evaluate(this.doc, XPathConstants.NODESET);	
			}
			
			logger.debug("##> XML global variable result is ["+result+"] ");
			ndList = (NodeList) result;
			for (int i = 0; i < ndList.getLength(); i++) {
				mainNode = ndList.item(i);
				nnMap = mainNode.getAttributes();
				node1 = nnMap.getNamedItem(varAttrib);
				node2 = nnMap.getNamedItem(varAttribVal);

				langOrVarMap.put(node1.getNodeValue(), node2.getNodeValue());
				//logger.info("[" + callUUID + "]node1 ["+node1.getNodeValue()+"],node2["+node2.getNodeValue()+"] ");
			}
		} catch (XPathExpressionException ex) {
			logger.error("[" + callUUID
					+ "] Error in parsing in getXmlLangorVarData ", ex);

		} finally {
			mainNode = null;
			nnMap = null;
			node1 = null;
			node2 = null;
			expr = null;
			ndList = null;
			result = null;
		}
		logger.debug("[" + callUUID
				+ "] #getXmlLangOrVarData() process complete #### Map is ["
				+ langOrVarMap + "]");
		
		logger.debug("##>end of getXmlLangOrVarData langmap"+langOrVarMap +"filepath"+langOrVarMap.get("1"));
		return langOrVarMap;
	}//getXmlLangOrVarData method End here

	/**
	 * This method return the action detail of particular itemId
	 * 
	 * @param itemId
	 *            item id whose action to be find
	 * @param actionSequence
	 *            total number of action contains at particular itemId
	 * @param varMap
	 *            map contains the xml parameters ingo
	 * @return Map with item action details
	 */
	
	//getActionDetail method Start here
	HashMap<String, String> getActionDetail(String itemId,
			byte actionSequence, HashMap<String, String> varMap) {
		logger.info("["
				+ varMap.get("callUUID")
				+ "] # Inside getActionDetail() of VoiceXmlReader itemId for this=["
				+ itemId + "] and action sequence [" + actionSequence + "]");
		HashMap<String, String> actionMap = new HashMap<String, String>();
		Node mainNode = null;
		NamedNodeMap nnMap = null;
		Node node1 = null;
		Node node2 = null;
		XPathExpression expr = null;
		Object result = null;
		NodeList ndList = null;
		try {
			expr = xpath.compile("/menus/item[@id='" + itemId + "']/action");
			
			synchronized (this) 
			{
				result = expr.evaluate(this.doc, XPathConstants.NODESET);	
			}
			
			ndList = (NodeList) result;
			logger.debug("[" + varMap.get("callUUID")
					+ "] Total Action Found: [" + ndList.getLength()
					+ "] Action Squence: [" + actionSequence + "]");

			if (ndList.getLength() > actionSequence && ndList.getLength() != 0) {
				mainNode = ndList.item(actionSequence);
				nnMap = mainNode.getAttributes();
				node1 = nnMap.getNamedItem("type");
				actionMap.put("actionType", node1.getNodeValue());

				node2 = nnMap.getNamedItem("action");
				actionMap.put("action", node2.getNodeValue());
				actionMap.put("actionSequence",
						Integer.toString(ndList.getLength()));
				logger.info("[" + varMap.get("callUUID") + "]  ACTION : "
						+ node2.getNodeValue() + "action sequence ["
						+ Integer.toString(ndList.getLength()) + "]");

				logger.debug("[" + varMap.get("callUUID") + "]  ACTION MAP: "
						+ actionMap);
				return actionMap;
			} else {
				logger.warn("[" + varMap.get("callUUID") + "]  ACTION MAP: "
						+ actionMap.get("action"));
				return null;
			}

		} catch (XPathExpressionException ex) {
			logger.fatal(
					"["
							+ varMap.get("callUUID")
							+ "] Error in XPath Parsing of getActionDetail() VoiceXmlReader ",
					ex);
			return null;

		} finally {
			mainNode = null;
			nnMap = null;
			node1 = null;
			node2 = null;
			expr = null;
			ndList = null;
			result = null;
			logger.debug("[" + varMap.get("callUUID")
					+ "] # End of getActionDetail() of VoiceXmlReader");
		}

	}//getActionDetail method End here

	/**
	 * This method is used to get the parameter of particular action
	 * 
	 * @param action
	 *            action to which parameter are to find
	 * @param actionType
	 *            type of action
	 * @param itemId
	 *            action item id
	 * @param langMap
	 *            map contains language info
	 * @param varMap
	 *            map contains xml parameters info
	 * @return map with parameter of action
	 */
	
	//getParamMap method Start here
	HashMap<String, Object> getParamMap(String action,
			String actionType, String itemId,
			HashMap<String, String> langMap,
			HashMap<String, String> varMap) {
		logger.debug("[" + varMap.get("callUUID")
				+ "] # Inside getParamMap() of VoiceXmlReader");
		Node mainNode = null;
		NamedNodeMap nnMap = null;
		Node node1 = null;
		Node node2 = null;
		Node node3 = null;
		Node node4 = null;
		XPathExpression expr = null;
		String attribute1 = null;
		String attribute2 = null;
		String attribute3 = null;
		String attribute4 = null;
		HashMap<String, Object> paramMap = new HashMap<String, Object>();
		ArrayList<String> promptData = new ArrayList<String>();
		ArrayList<String> paramData = new ArrayList<String>();
		ArrayList<String> textData = new ArrayList<String>();
		ArrayList<String> setData = new ArrayList<String>();
		ArrayList<InputDataBean> inputData = new ArrayList<InputDataBean>();
		ArrayList<OutputDataBean> outputData = new ArrayList<OutputDataBean>();
		
		ArrayList<DbParamBean> dbData = new ArrayList<DbParamBean>();
		ArrayList<DbSelectBean> dbSData = new ArrayList<DbSelectBean>();
		DbParamBean dbBean = null;
		DbSelectBean dbSBean = null;
		
		InputDataBean inputDataBean = null;
		OutputDataBean outputDataBean = null;
		
		Object result = null;
		NodeList ndList = null;
		try {
			expr = xpath.compile("/menus/item[@id='" + itemId
					+ "']/action[@action='" + action + "'][@type='"
					+ actionType + "']/param");
			synchronized (this) 
			{
				result = expr.evaluate(this.doc, XPathConstants.NODESET);	
			}
			
			ndList = (NodeList) result;
			for (int i = 0; i < ndList.getLength(); i++) {
				//dbBean = new DbParamBean();
				//dbSBean = new DbSelectBean();
				mainNode = ndList.item(i);
				nnMap = mainNode.getAttributes();
				node1 = nnMap.getNamedItem("name");
				node2 = nnMap.getNamedItem("data");
				node3 = nnMap.getNamedItem("type");
				if (node3 != null) { ////// if database operation perform and getting database parameters Data
					if (node3.getNodeValue().contains("Select")) {
						node4 = nnMap.getNamedItem("selectIndex");
					} else {
						node4 = nnMap.getNamedItem("paramIndex");
					}
				}
				
				
				if (node3 != null && node4 != null) {
					logger.debug("[" + varMap.get("callUUID")
							+ "] PARAM 3: Node Name is Found :"
							+ node3.getNodeValue());
					logger.debug("[" + varMap.get("callUUID")
							+ "] PARAM 4: Node Name is Found :"
							+ node4.getNodeValue());
					attribute3 = node3.getNodeValue();
					attribute4 = node4.getNodeValue();
				}
				if(node3 !=null && node3.getNodeValue().equalsIgnoreCase("input") ) ////if javascript operation perform and getting javascript input output variable
				{
						attribute1 = node1.getNodeValue();
						attribute2 = node2.getNodeValue();
						attribute3 = node3.getNodeValue();
						
				
				}else if (node3 !=null && node3.getNodeValue().equalsIgnoreCase("output"))
				{
			

				attribute1 = node1.getNodeValue();
				attribute2 = node2.getNodeValue();
				attribute3 = node3.getNodeValue();
				
				}else
				{
					attribute1 = node1.getNodeValue();
					attribute2 = node2.getNodeValue();
						
				}
				
				logger.debug("[" + varMap.get("callUUID")
						+ "] PARAM 1: Node Name is Found :" + attribute1);
				logger.debug("[" + varMap.get("callUUID")
						+ "] PARAM 2: Node Value is Found : " + attribute2);

				if (attribute1.equals("prompt")) {
					logger.debug("[" + varMap.get("callUUID")
							+ "] Prompt found  itemId [" + itemId + "]");
					attribute2 = attribute2.replace("$", "");
					attribute2 = attribute2.replaceAll("lang",
							varMap.get("lang"));
					if (attribute2.equalsIgnoreCase("FilePath")) {
						attribute2 = varMap.get("FilePath");
					} else if (attribute2.equalsIgnoreCase("recordFile")) {
						attribute2 = varMap.get("recordFile");
					} else {
						logger.debug("Language map : " + langMap.get("1"));
						attribute2 = langMap.get("1") + attribute2;
					}
					logger.debug("[" + varMap.get("callUUID")
							+ "] Modified Prompt Path " + attribute2);
					promptData.add(attribute2);

				} else if (attribute1.equals("parameter")) {
					logger.debug("[" + varMap.get("callUUID")
							+ "]parameter attribute found  itemId " + itemId);
					logger.debug("[" + varMap.get("callUUID") + "]ATTRIBUTE: "
							+ attribute1 + "value " + attribute2);
					paramData.add(attribute2.replaceAll("[$]", ""));

				} else if (attribute1.equals("set")) {
					logger.debug("[" + varMap.get("callUUID")
							+ "]set attribute found itemId " + itemId);
					logger.debug("[" + varMap.get("callUUID") + "]ATTRIBUTE: "
							+ attribute1 + "value " + attribute2);
					setData.add(attribute2.replaceAll("[$]", ""));

				}else if(attribute1.equals("text"))
				{
					logger.debug("[" + varMap.get("callUUID")
							+ "]set attribute found itemId " + itemId);
					logger.debug("[" + varMap.get("callUUID") + "]ATTRIBUTE: "
							+ attribute1 + "value " + attribute2);
					textData.add(attribute2);
					
	
				}
				else if(node3!=null && attribute3.equalsIgnoreCase("input"))
				{
					logger.debug("[" + varMap.get("callUUID")+ "] input variable parse " + itemId);
					inputDataBean = new InputDataBean();
					inputDataBean.setName(attribute1);
					inputDataBean.setData(attribute2);
					inputDataBean.setType(attribute3);
					inputData.add(inputDataBean);
					logger.debug("[" + varMap.get("callUUID")
							+ "] input variable parse " +inputDataBean.getName());
					
					
				}
				else if(node3!=null && attribute3.equalsIgnoreCase("output"))
				{
					logger.debug("[" + varMap.get("callUUID")
							+ "] output variable parse " + itemId);
					outputDataBean = new OutputDataBean();
					outputDataBean.setName(attribute1);
					outputDataBean.setData(attribute2);
					outputDataBean.setType(attribute3);
					outputData.add(outputDataBean);
				}
				else
				{
					logger.debug("[" + varMap.get("callUUID") + "]ATTRIBUTE: "
							+ attribute1 + "itemId " + itemId);
					paramMap.put(attribute1, attribute2);
					paramMap.put(attribute1.replaceAll("[$]", ""),
							attribute2.replaceAll("[$]", ""));// name data
					if (node3 != null && node4 != null) {
						
					
						
						if (attribute3.contains("Select")) // if select query
															// perform than this
															// this code will
															// execute
						{
							dbSBean = new DbSelectBean();
							logger.info("[" + varMap.get("callUUID")
									+ "]ATTRIBUTE: " + attribute3 + "itemId "
									+ itemId);
							int index = attribute3.indexOf("_");

							attribute3 = attribute3.substring(index + 1,
									attribute3.length());
							logger.info("[" + varMap.get("callUUID")
									+ "]ATTRIBUTE: " + attribute3 + "[" + index
									+ "]itemId " + itemId);
							dbSBean.setName(attribute1);
							dbSBean.setData(attribute2);
							dbSBean.setType(attribute3);
							logger.info("[" + varMap.get("callUUID")
									+ "]ATTRIBUTE: " + dbSBean.getType() + "["
									+ index + "]itemId " + itemId);
							dbSBean.setSelectIndex(attribute4);
							dbSData.add(dbSBean);
						} else // if update ,delete,insert query perform than
								// this code will execute
						{
							dbBean = new DbParamBean();
							
							dbBean.setName(attribute1);
							dbBean.setData(attribute2);
							dbBean.setType(attribute3);
							dbBean.setParamIndex(attribute4);
							dbData.add(dbBean);
						}

					}
				}

			}
			if (promptData.size() > 0) {
				paramMap.put("prompt", promptData);
			}
			if (paramData.size() > 0) {
				paramMap.put("parameter", paramData);
			}
			if (setData.size() > 0) {
				paramMap.put("set", setData);
			}
			if (dbData.size() > 0) {
				paramMap.put("dbdata", dbData);
			}
			if (dbSData.size() > 0) {
				paramMap.put("dbsdata", dbSData);
			}
			if(textData.size()>0)
			{
			    paramMap.put("textData", textData);
			}
			if(inputData.size()>0)
			{
				
				paramMap.put("inputData", inputData);
			}
			if(outputData.size()>0)
			{
				paramMap.put("outputData", outputData);
			}
			logger.debug("[" + varMap.get("callUUID") + "] GetParamMap is ["
					+ paramMap + "]");
			return paramMap;
		} catch (XPathExpressionException ex) {
			logger.fatal(
					"["
							+ varMap.get("callUUID")
							+ "] Error in XPath Parsing of getActionDetail() VoiceXmlReader ",
					ex);
			return null;

		} finally {
			mainNode = null;
			nnMap = null;
			node1 = null;
			node2 = null;
			expr = null;
			promptData = null;
			inputData = null;
			outputData = null;
			paramData = null;
			setData = null;
			dbData = null;
			textData = null;
			attribute1 = null;
			attribute2 = null;
			attribute3 = null;
			attribute4 = null;
			result = null;
			ndList = null;
			logger.debug("[" + varMap.get("callUUID")
					+ "] # End of getParamMap() of VoiceXmlReader");
		}

	}//getParamMap method End here

	/**
	 * This method contains info regarding link of a item Id
	 * 
	 * @param itemId
	 *            item id whose link to be find
	 * @param varMap
	 *            map conatins xml parameter info
	 * @return map with link informations
	 */
	//getNextActionLink method Start here
	HashMap<String, String> getNextActionLink(String itemId,
			HashMap<String, String> varMap) {
		logger.debug("[" + varMap.get("callUUID")
				+ "] # Inside getNextActionLink() of VoiceXmlReader itemId ["
				+ itemId + "]");
		HashMap<String, String> nextElementMap = new HashMap<String, String>();
		Node mainNode = null;
		NamedNodeMap nnMap = null;
		Node node1 = null;
		Node node2 = null;
		XPathExpression expr = null;
		Object result = null;
		NodeList ndList = null;
		String var = "";
		String val = "";

		String nextItemId = null;
		byte actionSequence = -1;
		Scanner scan = null;
		Pattern pattern = null;
		boolean match = false;
		String reserveId = null;
		String reserveVariable = null;

		try {
			expr = xpath.compile("/menus/item[@id='" + itemId + "']/links/link");
			
			synchronized (this) 
			{
				result = expr.evaluate(this.doc, XPathConstants.NODESET);	
			}
			
			ndList = (NodeList) result;
			logger.info("[" + varMap.get("callUUID") + "] digits: ["
					+ varMap.get("digits") + "] Last Executed Item ID: ["
					+ itemId + "]  Total Link Found: [" + ndList.getLength()
					+ "]");
			for (int i = 0; i < ndList.getLength(); i++) {
				nnMap = ndList.item(i).getAttributes();
				var = nnMap.getNamedItem("variable").getNodeValue();
				val = nnMap.getNamedItem("value").getNodeValue();
				var = var.replaceAll("[$]", "");
				reserveVariable = var;
				logger.debug("[" + varMap.get("callUUID") + "] variable =["
						+ var + "] and value =[" + val + "]  varmap contain value is ["+varMap.get(var)+"]");
				if (var != "" && varMap.containsKey(var)
						&& varMap.get(var).equals(val)) {
					nextItemId = nnMap.getNamedItem("id").getNodeValue();
					logger.debug("[" + varMap.get("callUUID")
							+ "]  new Item id [" + nextItemId + "]");
					actionSequence = 0;
					break;
				} else if (val.equals("") || val.equals("none")) {
					nextItemId = nnMap.getNamedItem("id").getNodeValue();
					logger.debug("[" + varMap.get("callUUID")
							+ "]  new Item id [" + nextItemId + "]");
					actionSequence = 0;
					break;
				}

				else if (var != "" && val.startsWith("regex:")) {
					String valreg = val.substring(val.indexOf(":")+1,
							val.length());
					logger.info("[" + varMap.get("callUUID")
							+ "] regular expression: " + valreg);

					pattern = Pattern.compile(valreg);
					if (valreg.contains("-")) {
						reserveId = nnMap.getNamedItem("id").getNodeValue();
						logger.info("[" + varMap.get("callUUID")
								+ "] reserve Id is [" + reserveId + "]");
					}
					if (var != null && var != ""
							&& pattern.matcher(varMap.get(var)).matches()) {

						logger.info("[" + varMap.get("callUUID")
								+ "] ### OK ### INPUT STATUS: "
								+ pattern.matcher(varMap.get(var)).matches());
						match = pattern.matcher(varMap.get(var)).matches();

					} else {

						logger.info("[" + varMap.get("callUUID")
								+ "] ### FAILED ### INPUT STATUS: "
								+ pattern.matcher(varMap.get(var)).matches());
						match = pattern.matcher(varMap.get(var)).matches();

					}

					if (match) {
						nextItemId = nnMap.getNamedItem("id").getNodeValue();
						actionSequence = 0;
						break;
					}
				}
			}
			logger.debug("[" + varMap.get("callUUID") + "] next id ["
					+ nextItemId + "] action sequence [" + actionSequence
					+ "] ");
			if (nextItemId != null && actionSequence != -1) {
				logger.debug("["
						+ varMap.get("callUUID")
						+ "] # in getNextActionLink() info placed in Map is item id["
						+ nextItemId + "] actionSequence is [" + actionSequence
						+ "]");
				nextElementMap.put("itemId", nextItemId);
				nextElementMap.put("actionSequence",
						new Byte(actionSequence).toString());
			} else {
				logger.warn("[" + varMap.get("callUUID") + "] NO LINK MATCH");
				if (reserveVariable.equals("digits")) {
					if (varMap.get("digits").length() > 1
							&& varMap.get("digits") != "-1") {
						logger.info("["
								+ varMap.get("callUUID")
								+ "] Match not found but input is greater then 1 digit so resreve Id is set ["
								+ reserveId + "]");
						nextElementMap.put("itemId", reserveId);
						actionSequence = 0;
						nextElementMap.put("actionSequence", new Byte(
								actionSequence).toString());
					}
				} else {
					logger.info("[" + varMap.get("callUUID")
							+ "] No data match is found");
					nextElementMap = null;
				}
			}

		} catch (XPathExpressionException ex) {
			logger.fatal("[" + varMap.get("callUUID")
					+ "] #Error in XpathExpression inside getNextActionLink()");
		} finally {
			mainNode = null;
			nnMap = null;
			node1 = null;
			node2 = null;
			expr = null;
			result = null;
			ndList = null;
			var = null;
			val = null;
			nextItemId = null;
			scan = null;
			pattern = null;

		}
		logger.info("["
				+ varMap.get("callUUID")
				+ "] # End of getNextActionLink() of VoiceXmlReader nextActionLinkMap is ["
				+ nextElementMap + "]");
		return nextElementMap;
	}//getNextActionLink method End here

}
