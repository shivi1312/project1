package com.telemune.ivr.util;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;
import org.plivo.bridge.exception.PlivoClientException;
import org.plivo.bridge.to.callback.AnsweredCallback;
import org.plivo.bridge.to.command.ApplicationResponse;
import org.plivo.bridge.to.command.GetDigitsWithoutHangup;
import org.plivo.bridge.to.command.Hangedup;
import org.plivo.bridge.to.command.Hangup;
import org.plivo.bridge.to.command.Play;
import org.plivo.bridge.to.command.PreAnswer;
import org.plivo.bridge.to.command.Record;
import org.plivo.bridge.to.command.Redirect;
import org.plivo.bridge.to.command.Speak;
import org.plivo.bridge.utils.PlivoUtils;
import org.testng.Assert;

/**
 * This class is used to interaction with plivo
 * 
 * @author jeevan
 */
public class PlivoXmlGenerator {

	String ip = null;
	String port = null;
	Logger logger = Logger.getLogger(PlivoXmlGenerator.class);

	PlivoXmlGenerator(String ip, String port) {
		this.ip = ip;
		this.port = port;
	}

	ArrayList<String> attributeList = new ArrayList<String>();

	/**
	 * This method is used to send the request to freeswitch to perform the
	 * action
	 * 
	 * @param request
	 *            HttpRequest Object
	 * @param response
	 *            HttpResponse Object
	 * @param actionMap
	 *            Map contains the info regarding which action is to be
	 *            requested to freeswitch
	 * @param paramMap
	 *            map contains the parameters to be passed
	 * @param varMap
	 *            map contains the info regarding xml data
	 * @param langMap
	 *            map contains the language info and path
	 * @param separator
	 *            used to separate the prompt file
	 */
	// domMyAction method Start here
	void doMyAction(HttpServletRequest request, HttpServletResponse response,
			HashMap<String, String> actionMap,
			HashMap<String, Object> paramMap, HashMap<String, String> varMap,
			HashMap<String, String> langMap, String separator)
			throws PlivoClientException, SQLException {
		logger.info("[" + varMap.get("callUUID")
				+ "]   Got Request in PlivoXmlGenerator ["
				+ actionMap.get("action") + "] url path ["+request.getContextPath().replace("/", "")+"]");
		AnsweredCallback callback = AnsweredCallback.create(PlivoTestUtils
				.mapToSingleValue(request.getParameterMap())); // request.getParameterMap()
																// send all
																// parameters of
																// request like
																// From,To,direction
																// etc
		// PlivoTestUtils.get("Alkesh");
		logger.debug("[" + varMap.get("callUUID") + "]  ==callback== "
				+ callback);

		Assert.assertNotNull(callback);
		Assert.assertNotNull(callback.getCallUUID());
		ApplicationResponse ar = new ApplicationResponse();
		// play Action Start here
		if (actionMap.get("action").equals("play")
				|| actionMap.get("action").equals("playandcontinue")) {
			logger.debug("[" + varMap.get("callUUID")
					+ "] # Play Request Comes ####");
			attributeList = (ArrayList) paramMap.get("prompt");
			String url = "";
			for (Iterator<String> iterator = attributeList.iterator(); iterator
					.hasNext();) {

				url += iterator.next();
				if (url.startsWith("$")) {
					url = url.replaceAll("$", "");
					if (varMap.containsKey(url)) {
						url = varMap.get(url);
					}
				}
				if (iterator.hasNext()) {
					url += separator; // "!";
				}
			}
			url = url.replaceAll(",", separator);
			logger.info("[" + varMap.get("callUUID") + "]  Prompt: " + url);
			Play play = new Play();
			play.setUrl(url);

			Redirect redirect = new Redirect();
			redirect.setUrl("http://" + this.ip.trim() + ":" + this.port.trim()
					+ "/"+request.getContextPath().replace("/", "")+"/plivoservlet");


			if (varMap.containsKey("preAnswer")
					&& varMap.get("preAnswer").equalsIgnoreCase("true")) {
				logger.info("preanser play file [" + varMap.get("preAnswer")
						+ "]");

				PreAnswer answer = new PreAnswer();
				answer.setPlay(play);
				answer.setRedirect(redirect);
				ar.setPreAnswer(answer);
			} else {
				ar.setPlay(play);
				ar.setRedirect(redirect);
			}

			logger.debug("[" + varMap.get("callUUID")
					+ "] # Play Request Ends ####");
			// ar.setRedirect(redirect);
			// //////////////////////////////////////////

		}// play Action End here

		// speak Action Start here
		else if (actionMap.get("action").equals("speak")) {

			logger.debug("[" + varMap.get("callUUID")
					+ "] # Speak  Request Comes ####");
			String userFeed = (String) varMap.get("userfeed");
			if (userFeed.equalsIgnoreCase("none")
					|| userFeed.equalsIgnoreCase("")) {
				userFeed = (String) paramMap.get("text");
			}

			logger.debug("[" + varMap.get("callUUID") + "]  userFeed  is : "
					+ userFeed);
			Speak speak = new Speak();
			speak.setText(userFeed);
			speak.setEngine("unimrcp");
			speak.setVoice("Sangeeta");

			Redirect redirect = new Redirect();
			redirect.setUrl("http://" + this.ip.trim() + ":" + this.port
					+ "/"+request.getContextPath().replace("/", "")+"/plivoservlet");
			ar.setSpeak(speak);
			ar.setRedirect(redirect);

			logger.info("[" + varMap.get("callUUID")
					+ "] # Speak Request ends ####");

		} // speak Action End here

		// record Action Start here
		else if (actionMap.get("action").equals("record")) {
			logger.debug("[" + varMap.get("callUUID")
					+ "] # Record Request Comes ####");
			Record record = new Record();
			if (varMap.containsKey("recordTimeout")
					&& varMap.containsKey("recordLength")) {
					record.setTimeout(Integer.parseInt(varMap.get("recordTimeout")
						.toString()));
				record.setMaxLength(Integer.parseInt(varMap.get("recordLength")
						.toString()));
				
				//record.setPlayBeep(false);
				
				
				logger.info("[" + varMap.get("callUUID")
						+ "]  set dyanamic recordTimeout ["
						+ varMap.get("recordTimeout") + "]  recordLength ["
						+ varMap.get("recordLength") + "]   ");

			} else {
				record.setTimeout(Integer.parseInt(paramMap.get("timeout")
						.toString()));
				record.setMaxLength(Integer.parseInt(paramMap.get("length")
						.toString()));
				
				logger.info("[" + varMap.get("callUUID")
						+ "]  set dyanamic recordTimeout ["
						+ paramMap.get("timeout") + "]  recordLength ["
						+ paramMap.get("length") + "]   ");

			}
			record.setFinishOnKey((String) paramMap.get("term_key"));

			record.setFileFormat("wav");
			record.setAction("http://" + this.ip.trim() + ":" + this.port
					+ "/"+request.getContextPath().replace("/", "")+"/plivoservlet");

			java.util.Date today = new java.util.Date();
			java.sql.Timestamp ts1 = new java.sql.Timestamp(today.getTime());
			long tsTime1 = ts1.getTime();

			if (varMap.containsKey("recordFilePath")
					&& varMap.containsKey("recordFileName")) {
				record.setFilePath(varMap.get("recordFilePath"));
				record.setFileName(varMap.get("recordFileName"));
				logger.info("[" + varMap.get("callUUID") + "] record file ["
						+ record.getFilePath() + "/" + record.getFileName()
						+ "." + record.getFileFormat() + "] is going to record");
			} else {
				record.setFilePath(langMap.get("1") + "/record/");
				record.setFileName(varMap.get("appName") + "_"
						+ varMap.get("callingNum") + "_" + tsTime1);
				logger.info("[" + varMap.get("callUUID") + "] record file ["
						+ record.getFilePath() + "/" + record.getFileName()
						+ "." + record.getFileFormat() + "] is going to record");
			}
			ar.setRecord(record);

			varMap.put("recordStartTime", Long.toString(tsTime1));

			logger.debug("[" + varMap.get("callUUID")
					+ "] # Record Request ends callDuration of record is ["
					+ varMap.get("recordingDuration") + "] ####");

		}// record Action End here

		// playandgetdig Action Start here
		else if (actionMap.get("action").equals("playandgetdig")) {
			logger.debug("[" + varMap.get("callUUID")
					+ "] # PlayAndgetDig Request Comes ####");
			attributeList = (ArrayList) paramMap.get("prompt");

			GetDigitsWithoutHangup getdigits = new GetDigitsWithoutHangup();
			Play play = new Play();
			String url = "";
			for (Iterator<String> iterator = attributeList.iterator(); iterator
					.hasNext();) {
				url += iterator.next().replaceAll(",", separator);
				if (iterator.hasNext()) {
					url += separator; // "!";
				}
			}
			logger.info("[" + varMap.get("callUUID") + "]  Prompt: " + url);
			play.setUrl(url);
			getdigits.setPlay(play);
			getdigits.setAction("http://" + this.ip.trim() + ":" + this.port
					+ "/"+request.getContextPath().replace("/", "")+"/plivoservlet");
			getdigits.setMethod("POST");
			logger.debug("[" + varMap.get("callUUID") + "]  timeout: ["
					+ paramMap.get("timeout") + "] terminator: ["
					+ paramMap.get("term_key") + "] length: ["
					+ paramMap.get("length") + "] playbeep: ["
					+ paramMap.get("playbeep") + "] retries: ["
					+ paramMap.get("retries") + "]");
			getdigits.setTimeout(Integer.parseInt(paramMap.get("timeout")
					.toString()));

			getdigits.setFinishOnKey((String) paramMap.get("term_key"));

			getdigits.setNumDigits(Integer.parseInt(paramMap.get("length")
					.toString()));
			// getdigits.setWait(wait);

			if ((Integer.parseInt(paramMap.get("retries").toString())) > 0) {
				getdigits.setRetries(Integer.parseInt(paramMap.get("retries")
						.toString()));// main line hai telecel k case m active

			} else {
				getdigits.setRetries(Integer.parseInt(varMap.get(
						"maxRetryCount").toString()));
			}
			if ((Integer.parseInt(paramMap.get("playbeep").toString())) == 0) {
				getdigits.setPlayBeep(false);

			} else {

				getdigits.setPlayBeep(true);

			}
			getdigits.setValidDigits((String) paramMap.get("validDigits"));

			String invalidPrompt = (String) paramMap.get("invalidDigitSound");
			if (invalidPrompt.equalsIgnoreCase("beep")
					|| invalidPrompt.equalsIgnoreCase("")) {
				String invalidDigitSound = varMap.get("invalidDigitsSound")
						.toString();
				invalidDigitSound = invalidDigitSound.replaceAll("[$]", "");
				logger.debug("[" + varMap.get("callUUID")
						+ "] invalidDigitsSound " + invalidDigitSound);
				invalidDigitSound = invalidDigitSound.replaceAll("lang",
						varMap.get("lang"));
				getdigits.setInvalidDigitsSound(invalidDigitSound);
			} else {
				invalidPrompt = invalidPrompt.replaceAll("[$]", "");
				logger.info("[" + varMap.get("callUUID")
						+ "] invalidPromptSound " + invalidPrompt);
				invalidPrompt = invalidPrompt.replaceAll("lang",
						varMap.get("lang"));
				getdigits.setInvalidDigitsSound(invalidPrompt);
			}

		
			if (varMap.containsKey("preAnswer")
					&& varMap.get("preAnswer").equalsIgnoreCase("true")) {
				logger.info("preanswer play file [" + varMap.get("preAnswer")
						+ "]");
				logger.debug("preanser play file working");
				PreAnswer answer = new PreAnswer();

				answer.setGetDigitsWithoutHangup(getdigits);

				ar.setPreAnswer(answer);

			} else {
				ar.setGetDigitsWithoutHangup(getdigits);
			}

			logger.info("[" + varMap.get("callUUID")
					+ "] # PlayAndGetDig Request ends ####");

		} // playandgetdig Action End here

		// hangup Action Start here
		else if (actionMap.get("action").equals("hangup")) {
			logger.debug("[" + varMap.get("callUUID")
					+ "] # Hangup Request Comes ####");
			Hangup h = new Hangup();
			h.setReason("NORMAL_CLEARING");
			ar.setHangup(h);

			logger.info("[" + varMap.get("callUUID")
					+ "] # Hangup Request ends ####");

		}// hangup Action End here

		// hangedup Action Start here
		else if (actionMap.get("action").equals("hangedup")) {
			logger.debug("[" + varMap.get("callUUID")
					+ "] # Hangedup Request Comes ####");
			Hangedup h = new Hangedup();
			h.setReason("NORMAL_CLEARING");
			ar.setHangedup(h);

			logger.info("[" + varMap.get("callUUID")
					+ "] # Hangedup Request ends ####");

		}// hangedup Action End here

		// transferCall Action Start here
		else if (actionMap.get("action").equals("transferCall")) {
			logger.info("[" + varMap.get("callUUID")
					+ "] # Request Comes for transfer call ####");

			Redirect redirect = new Redirect();
			redirect.setUrl("http://" + this.ip.trim() + ":" + this.port
					+ "/"+request.getContextPath().replace("/", "")+"/plivoservlet?From="
					+ varMap.get("callingNum") + "&To="
					+ varMap.get("calledNum") + "&CallUUID="
					+ varMap.get("callUUID")
					+ "&Direction=inbound&newShortCode="
					+ paramMap.get("number").toString());

			ar.setRedirect(redirect);

		}// transferCall Action End here

		else {
			logger.warn("["
					+ varMap.get("callUUID")
					+ "] Action Generator is Called but No Action Met Condition ");
		}
		try {
			PlivoUtils.JAXBContext.createContext().createMarshaller()
					.marshal(ar, response.getWriter());

		} catch (JAXBException e) {

			logger.fatal("[" + varMap.get("callUUID") + "]  JAXBException ", e);

		} catch (Exception e) {

			logger.fatal("[" + varMap.get("callUUID") + "]  Exception ", e);

		}

	}// domMyAction method End here

}