package com.telemune.ivr.servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ReloadXml extends HttpServlet {

  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
int count;

  public void init(ServletConfig config) throws ServletException {
    super.init(config);
    String initial = config.getInitParameter("initial");
    try {
      count = Integer.parseInt(initial);
    }
    catch (NumberFormatException e) {
      count = 0;
    }
  }

  public void doGet(HttpServletRequest req, HttpServletResponse res) 
                           throws ServletException, IOException {
	PlivoControlServlet controlServlet = new PlivoControlServlet();
	
	//controlServlet.loadProperties();
	controlServlet.init();
	  
	  
    res.setContentType("text/plain");
    PrintWriter out = res.getWriter();
  
    out.println("Since loading (and with a possible initialization");
    out.println("parameter are reloaded successfully");
    
  }
}