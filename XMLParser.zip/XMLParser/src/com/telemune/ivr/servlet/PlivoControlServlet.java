package com.telemune.ivr.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.client.HttpClient;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.plivo.bridge.client.PlivoClient;
import org.plivo.bridge.feature.call.CallFeature;
import org.plivo.bridge.to.response.RecordStartResponse;

import FileBaseLogging.FileLogWriter;

import com.telemune.ivr.bean.DbPool;
import com.telemune.ivr.bean.RequestBean;
import com.telemune.ivr.db.DbConnection;
import com.telemune.ivr.util.PlivoXmlGenerator;
import com.telemune.ivr.util.RequestProcess;
import com.telemune.ivr.util.ServiceInfo;
import com.telemune.ivr.util.VoiceXmlReader;

public class PlivoControlServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This (Servlet) class is used to track the state of a particular Call
	 * 
	 * @author jeevan
	 */

	Logger logger = Logger.getLogger(PlivoControlServlet.class);

	Properties props = null;
	public static String ip = null; //
	public static String port = null;
	String separator = null;
	public static String dbDriver = null; // mysql driver
	public static String dbUrl = null; // mysql url
	public static String dbUser = null; // mysql username
	public static String dbPass = null; // mysql passord
	String fWriteEnable = null; // 1 Enable 0 disable Writing digits pressed by
								// user in file
	String fWritePath = null; // Path on which file is written
	String fWriteInterval = null;
	String fWriteName = null; // Name of the file
	String fArcName = null;
	String soTimeout = null; // socket timeout in apache connection pooling
	String conTimeout = null; // connection timeout in apache connection pooling
	String conManTimeout = null; // connection manager timeout in apache
									// connection pooling
	String generalIp = null; // hit ip
	String generalPort = null;// hit port
	String callRecordFac = null;
	String callRecordFilePath = null; // filepath for save recording
	String recordingId = null; // record call enable for 1 or 0 for disable
	public static String authId = null;
	public static String authToken = null;
	public static String plivoUrl = null;
	String plivoVersion = null;
	String javasrcipt = null; // javascript 1 for Enable 0 for disable
	ServiceInfo sinfo = null;
	public static String db_type = null; // used to convert date into desired
											// format based on db_type ( Because different
											// databases have different format)
	// RequestProcess rProcess=null;

	public static String gateway = null;
	public static String extra_dial_String = null;
	FileLogWriter flw = null;
	PlivoXmlGenerator pxGenerator = null;
	public static int cacheExpireTime = 0;
	private String reloadXml;

	boolean loadingStatus = false; // variable for the status of loading xmls if
									// all xmls loaded then it becomes true.

	// init method Start here
	public void init() {
		configureSystem();
	}// init method End here

	private void configureSystem() {
		loadProperties();
		sinfo = null;
		sinfo = new ServiceInfo();
		// rProcess = new RequestProcess();

		pxGenerator = sinfo.loadXmlData(dbDriver, dbUrl, dbUser, dbPass, ip,
				port);
		if (javasrcipt.equalsIgnoreCase("1")) {
			logger.info("javascript enable");
			ServiceInfo.loadJavaScriptText();
			// sinfo.loadJavaScriptText();
			logger.debug("javascript is" + sinfo.jsTextMap);
		}
		logger.debug("PlivoXMl Object is [" + pxGenerator + "]");

		if (fWriteEnable.equals("1")) { // File Writing is enable
			flw = new FileLogWriter();
			logger.info("### File Log Writer is Now : " + flw);
			flw.setNewFileInterval(Integer.parseInt(fWriteInterval));
			flw.setFilename(fWriteName);
			flw.setFilePath(fWritePath);
			flw.setArchiveFilePath(fWritePath);
			flw.setArchiveFilename(fArcName);
			flw.initialize();
		} else {
			logger.debug("# File Writing is disable ###" + port);
		}
		loadingStatus = true;
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		if (loadingStatus) {
			processRequest(request, response);
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		if (loadingStatus) {
			processRequest(request, response);
		}
	}

	// processRequest method Start here
	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		reloadXml = request.getParameter("CallStatus");
		// logger.info("reloadXml is" + reloadXml);

		if (reloadXml != null && reloadXml.equals("yes")
				&& request.getParameter("reloadId") == null) {
			if (request.getParameter("reloadReason") != null
					&& request.getParameter("reloadReason").equals("Critical")) {

				logger.debug("## Now going to reload XML Forcely");

				sinfo.oldBeanMap.clear(); // Clearing oldBeanMap completely in
											// critical case.

				Iterator<Entry<String, VoiceXmlReader>> itr = sinfo.voiceReaderMap
						.entrySet().iterator();

				while (itr.hasNext()) {
					Entry<String, VoiceXmlReader> entry = (Map.Entry<String, VoiceXmlReader>) itr
							.next();
					String app_Id = (String) entry.getKey();
					VoiceXmlReader vxReader = (VoiceXmlReader) entry.getValue();

					sinfo.oldBeanMap.put(app_Id, vxReader, cacheExpireTime,
							TimeUnit.MINUTES);

					logger.info(" OldBeanMap set for serv_id ["
							+ app_Id
							+ "] Expire Time ["
							+ TimeUnit.MILLISECONDS.toMinutes(sinfo.oldBeanMap
									.getExpiration(app_Id)) + "]");

				}
				configureSystem();
				out.write("XML Reloaded Forcely.");
				logger.info("##  XML reloaded Forcely.");
				reloadXml = null;
			} else {

				if (sinfo.oldBeanMap.size() != 0) {
					logger.info("XML can not be reloaded at this time..!!!");
					out.write("");
					out.write("XML can not be reloaded at this time...!!!");
					// out.write("Please try after "+TimeUnit.MILLISECONDS.toMinutes(sinfo.oldBeanMap.getExpectedExpiration(app_Id))+" Minutes and "+
					// TimeUnit.MILLISECONDS.toSeconds(sinfo.oldBeanMap.getExpectedExpiration(app_Id))+" Seconds");

				} else {
					logger.info("## Now going to reload XML ");

					Iterator<Entry<String, VoiceXmlReader>> itr = sinfo.voiceReaderMap
							.entrySet().iterator();

					while (itr.hasNext()) {
						Entry<String, VoiceXmlReader> entry = (Map.Entry<String, VoiceXmlReader>) itr
								.next();
						String app_Id = (String) entry.getKey();
						VoiceXmlReader vxReader = (VoiceXmlReader) entry
								.getValue();

						sinfo.oldBeanMap.put(app_Id, vxReader, cacheExpireTime,
								TimeUnit.MINUTES);

						logger.info(" OldBeanMap set for serv_id ["
								+ app_Id
								+ "] Expire Time ["
								+ TimeUnit.MILLISECONDS
										.toMinutes(sinfo.oldBeanMap
												.getExpiration(app_Id)) + "]");

					}
					configureSystem();
					out.write("XML Reloaded Successfully");
					reloadXml = null;
				}
			}
		} else if (reloadXml != null && reloadXml.equals("yes")
				&& request.getParameter("reloadId") != null) {
			// logger.info("Reloading XML..!!!!!! ");
			if (request.getParameter("reloadReason") != null
					&& request.getParameter("reloadReason").equals("Critical")) {
				String serv_Id = request.getParameter("reloadId");

				logger.info("Going to reload App_Id [" + serv_Id + "] forcely");

				sinfo.oldBeanMap.remove(serv_Id); // Remove Serv_id from
													// oldbeamMap in critical
													// case

				VoiceXmlReader vxR = null;
				sinfo.oldBeanMap.put(serv_Id,
						sinfo.voiceReaderMap.get(serv_Id), cacheExpireTime,
						TimeUnit.MINUTES);

				logger.info("oldBeanMap set for serv_id ["
						+ serv_Id
						+ "] Expire Time ["
						+ TimeUnit.MILLISECONDS.toMinutes(sinfo.oldBeanMap
								.getExpiration(serv_Id)) + "]");
				Connection con = null;
				try {
					con = DbConnection.getConnection();
					vxR = new VoiceXmlReader(serv_Id, con);
					if (vxR.parsingSuccess) {
						sinfo.voiceReaderMap.put(serv_Id, vxR);

						logger.info("AppId [" + serv_Id
								+ "] is Forcely reloaded ");
						out.write("AppId [" + serv_Id + "] is Forcely reloaded");
					} else {
						logger.info("AppId ["
								+ serv_Id
								+ "] not exists in db or error in parsing in xml");
						out.write("AppId ["
								+ serv_Id
								+ "] not exists in db or error in parsing in xml");
					}
				} catch (Exception e) {
					logger.error("Exception in connection" + e);
				} finally {
					try {
						if (con != null)
							con.close();
					} catch (Exception e) {
						logger.error("Exception in closing connection" + e);
					}
				}
			} else {

				String serv_Id = request.getParameter("reloadId");
				// logger.info("Going to reload ["+serv_Id+"]");

				VoiceXmlReader vxR = null;
				if (sinfo.oldBeanMap.containsKey(serv_Id)) {
					logger.info("XMl can not be reloaded at this time for Serv_Id ["
							+ serv_Id + "]");
					out.write("");
					out.write("XML can not be reloaded at this time...!!!   ");
					out.write("Please try after "
							+ TimeUnit.MILLISECONDS.toMinutes(sinfo.oldBeanMap
									.getExpectedExpiration(serv_Id))
							+ " Minutes and "
							+ TimeUnit.MILLISECONDS.toSeconds(sinfo.oldBeanMap
									.getExpectedExpiration(serv_Id))
							+ " Seconds");

				} else {
					if (sinfo.voiceReaderMap.get(serv_Id) != null) {
						sinfo.oldBeanMap.put(serv_Id,
								sinfo.voiceReaderMap.get(serv_Id),
								cacheExpireTime, TimeUnit.MINUTES);
						logger.info("oldBeanMap set for serv_id ["
								+ serv_Id
								+ "] Expire Time ["
								+ TimeUnit.MILLISECONDS
										.toMinutes(sinfo.oldBeanMap
												.getExpiration(serv_Id)) + "] ");

					}

					Connection con = null;
					try {
						con = DbConnection.getConnection();

						vxR = new VoiceXmlReader(serv_Id, con);
						if (vxR.parsingSuccess) {

							sinfo.voiceReaderMap.put(serv_Id, vxR);

							logger.info("AppId [" + serv_Id
									+ "] is reloaded successfuly");
							out.write("AppId [" + serv_Id
									+ "] is reloaded successfuly");
						} else {
							logger.info("AppId ["
									+ serv_Id
									+ "] not exists in db or error in parsing in xml");
							out.write("AppId ["
									+ serv_Id
									+ "] not exists in db or error in parsing in xml");
						}
					} catch (Exception e) {
						logger.error("Exception in connection" + e);
					} finally {
						try {
							if (con != null)
								con.close();
						} catch (Exception e) {
							logger.error("Exception in closing connection" + e);
						}
					}
				}
			}
		} else {
			try {
				RequestProcess rProcess = null;
				DbPool dbPool = null;
				String callUUID = null;
				String gc_cicId = null;
				String direction = null;
				String calledNum = null;
				String callingNum = null;
				String callStatus = null;
				String itemId = null;
				String forwardedFrom = null;
				String forwardedReason = null;
				String appName = null;
				byte actionSequence = 0;
				String campaign_Id = null;
				String other = null;

				StringBuffer callDigInfo = null;
				HashMap<String, String> varMap = null;
				HashMap<String, String> dbVarMap = null;
				HashMap<String, String> langMap = null;
				HashMap<String, String> actionMap = null;
				HashMap<String, DbPool> conPoolMap = null;
				HttpClient httpClient = null;
				String appId = null;
				String dialHangupCause = null;
				String serverId = null;
				VoiceXmlReader vxReader = null;
				if (fWriteEnable.equals("1")) { // Object generates if file
												// writing
												// is Enable
					callDigInfo = new StringBuffer();
				}

				logger.info("[" + request.getParameter("CallUUID")
						+ "] request body: "
						+ request.getRequestURL().toString() + " queryString[ "
						+ request.getQueryString() + "]");
				logger.info("\n\n\nCallUUID ["
						+ request.getParameter("CallUUID") + "] callStatus ["
						+ request.getParameter("CallStatus")
						+ "]  callingNumber [" + request.getParameter("From")
						+ "]  To [" + request.getParameter("To")
						+ "] Digits Received ["
						+ request.getParameter("Digits") + "] callDirection ["
						+ request.getParameter("Direction")
						+ "] hangup cause ["
						+ request.getParameter("HangupCause") + "] ringTime ["
						+ request.getParameter("ringTime") + "] gc_ccid ["
						+ request.getParameter("gc_cicId") + "] campaignId["
						+ request.getParameter("campId") + "] ");

				if (request.getParameter("DialHangupCause") != null)
					dialHangupCause = request.getParameter("DialHangupCause");

				if (request.getParameter("To") != null
						&& request.getParameter("From") != null
						&& request.getParameter("CallStatus") != null) {

					// serverId getting from request param for identify the
					// server

					if (request.getParameter("serverId") != null
							|| request.getParameter("serverId") != "") {

						serverId = request.getParameter("serverId");
						logger.info("Server id found in request param serverId  ["
								+ serverId + "]");

					} else {
						logger.info("Server id not contain in request param");
					}

					if (request.getParameter("CallUUID") == null
							|| request.getParameter("CallUUID") == "") {
						// In telecel most of times callUUID not comes so Call
						// proceed on the basis ofcallingNumber

						callUUID = request.getParameter("To").trim();
					} else {
						callUUID = request.getParameter("CallUUID").trim();
					}
					if (request.getParameter("gc_cicId") != null) {
						// This parameter comes in outbound call through which
						// cic
						// id call comes at some sites it mix up with direction
						// so
						// there is a separation

						gc_cicId = request.getParameter("gc_cicId").replaceAll(
								"[?]", "");
						logger.debug("[" + callUUID + " ] # gc_cicId ["
								+ gc_cicId + "]");
						if (request.getParameter("gc_cicId").indexOf(
								"Direction=") != -1) {
							String[] gcid_token = gc_cicId.split("Direction=");
							gc_cicId = gcid_token[0];
							direction = gcid_token[1];
						} else {
							direction = request.getParameter("Direction");
						}
					} else {

						direction = request.getParameter("Direction");

					}
					if (direction.equalsIgnoreCase("outbound")) { // Now here we
																	// are
																	// changing
																	// calledNum
																	// and
																	// callingNum
																	// as in
																	// outbound
																	// case it
																	// reverse

						// calledNum = request.getParameter("From");

						calledNum = request.getParameter("From");
						callingNum = request.getParameter("To");

						if (request.getParameter("campId") != null)
							campaign_Id = request.getParameter("campId");

						if (request.getParameter("other") != null)
							other = request.getParameter("other");

						if (request.getParameter("appName") != null)
							appName = request.getParameter("appName");

						if (request.getParameter("appId") != null)
							appId = request.getParameter("appId");

						if (calledNum.indexOf(";") != -1) {
							logger.info("To contain extra param ["
									+ request.getParameter("From") + "]");
							calledNum = request.getParameter("From").substring(
									0,
									request.getParameter("From").indexOf(";"));
						} else if (calledNum.indexOf("@") != -1) {
							calledNum = request.getParameter("From").substring(
									0, calledNum.indexOf("@"));
							logger.info("To contain extra param ["
									+ request.getParameter("From")
									+ "] and now callingNum [" + callingNum
									+ "]");
						} else {
							calledNum = request.getParameter("From");
						}

						if (callingNum.indexOf(";") != -1) {
							logger.info("To contain extra param ["
									+ request.getParameter("To") + "]");
							callingNum = request.getParameter("To").substring(
									0, request.getParameter("To").indexOf(";"));

						} else if (callingNum.indexOf("@") != -1) {
							callingNum = request.getParameter("To").substring(
									0, callingNum.indexOf("@"));
							logger.info("To contain extra param ["
									+ request.getParameter("To")
									+ "] and now callingNum [" + callingNum
									+ "]");
						} else {
							callingNum = request.getParameter("To");
						}
					} else {
						calledNum = request.getParameter("To");
						callingNum = request.getParameter("From");

						if (request.getParameter("ForwardedFrom") != null) {
							forwardedFrom = request
									.getParameter("ForwardedFrom");
							forwardedReason = request
									.getParameter("ForwardedReason");
						}

						if (calledNum.indexOf(";") != -1) {
							logger.info("To contain extra param ["
									+ request.getParameter("To") + "]");
							calledNum = request.getParameter("To").substring(0,
									request.getParameter("To").indexOf(";"));
						} else if (calledNum.indexOf("@") != -1) {
							calledNum = request.getParameter("To").substring(0,
									calledNum.indexOf("@"));
							logger.info("To contain extra param ["
									+ request.getParameter("To")
									+ "] and now calledNum [" + calledNum + "]");
						} else {
							calledNum = request.getParameter("To");
						}

						if (callingNum.indexOf(";") != -1) {
							logger.info("To contain extra param ["
									+ request.getParameter("From") + "]");
							callingNum = request.getParameter("From")
									.substring(
											0,
											request.getParameter("From")
													.indexOf(";"));
						} else if (callingNum.indexOf("@") != -1) {
							logger.info("To contain extra param ["
									+ request.getParameter("From") + "]");
							callingNum = request.getParameter("From")
									.substring(0, callingNum.indexOf("@"));
							logger.info("To contain extra param ["
									+ request.getParameter("From")
									+ "]  and now callingNum [" + callingNum
									+ "] ");
						} else {
							callingNum = request.getParameter("From");
						}
					}

					if (request.getParameter("newShortCode") != null) {
						logger.info("[" + callUUID + "] CalledNum is different");
						// String[] callShort = calledNum.split("?");
						calledNum = request.getParameter("newShortCode");
						logger.info("[" + callUUID + "] New Called Num is [ "
								+ calledNum + "]");
					}
					if (callingNum.indexOf("-g") != -1) { // At Some sites
															// callingNum comes
															// with
															// -g attached
						int index_len = callingNum.indexOf("-g");
						callingNum = callingNum.substring(0, index_len);

					}
					callStatus = request.getParameter("CallStatus");
					if (callStatus.equalsIgnoreCase("completed")) { // If call
																	// Status is
																	// complete
																	// then item
																	// id
																	// #hangup
																	// is set

						actionSequence = 0;
						itemId = "#hangup";

						logger.info("[" + callUUID
								+ "] Call Status Complete Item ID set is ["
								+ itemId);
					} else if (callStatus.equalsIgnoreCase("ringing")) {
						itemId = "#start";
						actionSequence = 0;
					}
					logger.info("[" + callUUID + "] Total call in XMLparser  ["
							+ sinfo.beanMap.size() + "]");
					if (sinfo.beanMap.containsKey(callUUID) == false) { // call
																		// Comes
																		// first
																		// time

						if (direction.equalsIgnoreCase("outbound")) {

							if (!callStatus.equals("completed")) {
								itemId = "#start";
							}
						}

						String servId = null;
						if (appId != null) // appId used when outbound call
											// generated
						{
							servId = appId;
							logger.info("in case outbound call Active the appId is ["
									+ servId + "]");

						} else {
							servId = sinfo
									.getAppIdForCall(calledNum, direction);
							logger.debug("[" + callUUID
									+ "] App Id for this call is [" + servId
									+ "]");
						}

						if (servId != null) {
							vxReader = sinfo.voiceReaderMap.get(servId); // XMl
																			// data
																			// retrive
																			// from
																			// map
																			// voiceReaderMap
																			// according
																			// to
																			// servId
							logger.debug("[" + callUUID
									+ "] vxReader for this call is ["
									+ vxReader + "]");
							if (vxReader != null) {
								varMap = LoadParameter(callUUID, servId,
										varMap, vxReader);
								dbVarMap = LoadDbParameter(callUUID, servId,
										dbVarMap, vxReader);

								conPoolMap = LoadConPoolParameter(callUUID,
										servId, dbVarMap, conPoolMap, dbPool);

								httpClient = getHttpClientObject(callUUID,
										servId, httpClient, varMap);
								langMap = LoadLangParameter(callUUID, servId,
										langMap, vxReader);
								String ringTime = getTime(callUUID);
								varMap.put("callUUID", callUUID);
								varMap.put("callingNum", callingNum);
								varMap.put("calledNum", calledNum);
								varMap.put("ringTime", ringTime);

								if (forwardedFrom != null
										&& forwardedReason != null) {
									varMap.put("forwardedFrom", forwardedFrom);
									varMap.put("forwardedReason",
											forwardedReason);
								}
								if (serverId != null) {
									varMap.put("serverId", serverId);
								}

								if (direction.equalsIgnoreCase("outbound")
										&& other != null) {
									varMap.put("other", other);

								}

								if (direction.equalsIgnoreCase("outbound")
										&& campaign_Id != null) {
									varMap.put("campId", campaign_Id);

								} else if (direction
										.equalsIgnoreCase("outbound")
										&& appName != null) {
									varMap.put("appName", appName);
								}
								if (gc_cicId != null) {
									varMap.put("gc_cicId", gc_cicId);
								}
								if (request.getParameter("gc_songId") != null) {
									logger.info("[" + callUUID
											+ "] # SongId is ["
											+ request.getParameter("gc_songId")
											+ "]");
									varMap.put("gc_songId",
											request.getParameter("gc_songId"));
								}
								if (fWriteEnable.equals("1")) { // File Writing
																// Enable case
									callDigInfo.append(callingNum);
									callDigInfo.append(",");
									callDigInfo.append(callUUID);
									callDigInfo.append(",");
									callDigInfo.append(ringTime);
									varMap.put("callDigInfo",
											callDigInfo.toString());
								}
								if (callStatus.equals("completed")
										|| direction
												.equalsIgnoreCase("inbound")
										|| direction
												.equalsIgnoreCase("outbound")) {
									String callTime = getTime(callUUID);
									varMap.put("callTime", callTime);
									if (request.getParameter("HangupCause") != null) {
										varMap.put("hangupCause", request
												.getParameter("HangupCause"));
										String callDuration = getCallDuration(
												varMap.get("ringTime"),
												varMap.get("callTime"));
										varMap.put("callDuration", callDuration);
										logger.info("total call duration is ["
												+ callDuration + "]");
									}
									if (callRecordFac.equals("1")
											&& !callStatus.equals("completed")) { // this
																					// will
																					// record
																					// the
																					// whole
																					// voice
																					// of
																					// IVR
																					// call
										recordIvrCall(callUUID, servId, varMap);
									}
									if (callStatus.equals("completed")
											&& fWriteEnable.equals("1")) {
										logger.info("Now Writing in Call Log File ");
										flw.writeLog(callDigInfo + "");
										logger.info("CallDetails[" + callingNum
												+ "]" + callDigInfo);
									}

								}
								RequestBean reqbean = new RequestBean();
								if (request.getParameter("Digits") != null
										&& request.getParameter("Digits") != "") {
									varMap.put("digits",
											request.getParameter("Digits"));
									if (fWriteEnable.equals("1")) {
										callDigInfo.append(",");
										callDigInfo.append(request
												.getParameter("Digits"));

										reqbean.getVarMap().put("callDigInfo",
												callDigInfo + "");
									}

								} else {
									varMap.put("digits", "-1");
								}
								if (request.getParameter("recordFile") != null) {
									varMap.put("recordFile",
											request.getParameter("recordFile"));
									// logger.info("call record duration is ["+request.getParameter("RecordingDuration")+"]");
								}
								if (request.getParameter("RecordingDuration") != null) {

									varMap.put("recordingDuration", request
											.getParameter("RecordingDuration"));
									logger.info("call record duration is ["
											+ varMap.get("recordingDuration")
											+ "]");
								}

								logger.info("[" + callUUID
										+ "] Base Filepath of Prompts is ["
										+ langMap.get("1") + "]");
								reqbean.setLangMap(langMap);
								reqbean.setCallUUID(callUUID);
								reqbean.setCalledNum(calledNum);
								reqbean.setCallingNum(callingNum);
								reqbean.setCallStatus(callStatus);
								reqbean.setItemId(itemId);
								reqbean.setActionMap(actionMap);
								reqbean.setVarMap(varMap);
								reqbean.setDbVarMap(dbVarMap);
								reqbean.setConPoolMap(conPoolMap);
								reqbean.setActionSequence(actionSequence);
								reqbean.setCallDigInfo(callDigInfo);
								reqbean.setCallSequence("1");
								reqbean.setServiceId(servId);
								reqbean.setChangeShortcode(new Byte("0"));
								if (direction.equalsIgnoreCase("outbound")
										&& callStatus
												.equalsIgnoreCase("ringing")) {
									logger.info("["
											+ callUUID
											+ "] only loading the xml not initiating the process");
								} else {
									logger.info("["
											+ callUUID
											+ "] The IVR call Action is now perform item id ["
											+ itemId + "]");
									rProcess = new RequestProcess();
									rProcess.doActionEvent(request, response,
											callUUID, itemId, actionSequence,
											reqbean, vxReader, httpClient,
											this.pxGenerator, separator);
								}
								logger.debug("[" + callUUID + "] "
										+ "putting Request bean in Map ");
								if (!callStatus.equalsIgnoreCase("completed")) {
									logger.info("### ["
											+ callUUID
											+ "]CAll STATUS First time is Not Completed . ###");
									// sinfo.beanMap.put(callUUID.trim(),
									// reqbean);
									sinfo.beanMap.put(callUUID.trim(), reqbean,
											cacheExpireTime, TimeUnit.MINUTES);
									rProcess = null;
								} else {
									logger.info("["
											+ callUUID
											+ "] #User Not Respond to call or User unavailable ###");
									rProcess = null;
								}

							} else {
								logger.info("["
										+ callUUID
										+ "] # Xml Not loaded for this Call or Invalid Shortcode Call or ShortCode is InActive check DB of AppId ["
										+ servId + "] Shortcode [" + calledNum
										+ "]");

								callUUID = null;
								callDigInfo = null;
								callStatus = null;
								gc_cicId = null;
								direction = null;
								calledNum = null;
								callingNum = null;
								itemId = null;
								varMap = null;
								langMap = null;
								actionMap = null;
								httpClient = null;
								dbVarMap = null;
								conPoolMap = null;

							}
						} else {

							logger.info("[" + callUUID
									+ "] #  AppId Not Found [" + servId
									+ "] Shortcode [" + calledNum + "]");
							callUUID = null;
							callDigInfo = null;
							callStatus = null;
							gc_cicId = null;
							direction = null;
							calledNum = null;
							callingNum = null;
							itemId = null;
							varMap = null;
							langMap = null;
							actionMap = null;
							httpClient = null;
							dbVarMap = null;
							conPoolMap = null;
						}

					} else { // call continues beanmap contains callUUID
						if (callStatus.equalsIgnoreCase("ringing")
								&& direction.equalsIgnoreCase("outbound")) {
							logger.info("["
									+ callUUID
									+ "] #In Bean CallUUID exists but CALL STATUS comes RINGING So this Call is ignored");
						} else {
							RequestBean reqbean = (RequestBean) sinfo.beanMap
									.remove(callUUID);
							logger.info("[" + callUUID
									+ "] size of gloabal bean after remove ["
									+ sinfo.beanMap.size() + "]");

							// ///////////////////////////
							// ////ReturnToShortcode///////
							// /////////////////////////
							if (reqbean.getVarMap().containsKey(
									"returnToShortcode")
									&& reqbean.getVarMap()
											.get("returnToShortcode")
											.equals("-1")) {
								goToMainIvr(callUUID, calledNum, direction,
										reqbean, httpClient, callingNum,
										vxReader);
								reqbean.setItemId("#start");
								logger.info("["
										+ callUUID
										+ "] Item id after reset to main ivr is ["
										+ reqbean.getItemId() + "]");

							}
							if (reqbean.getChangeShortcode() == 0) {
								if (reqbean.getCalledNum().equals(calledNum)) {
									vxReader = sinfo.voiceReaderMap.get(reqbean
											.getServiceId());
								} else {
									logger.info("["
											+ callUUID
											+ "] Shortcode is different New Shortcode is ["
											+ calledNum + "]");
									vxReader = switchToNewShortcode(callUUID,
											calledNum, direction, httpClient,
											callingNum, vxReader, reqbean);
								}
							} else {
								vxReader = sinfo.voiceReaderMap.get(reqbean
										.getServiceId());
							}
							logger.debug("[" + callUUID
									+ "] VxReader in main [" + vxReader + "]");
							if (vxReader != null) {
								if (reqbean.getCallSequence().equals("1")
										&& direction
												.equalsIgnoreCase("outbound")
										&& callStatus
												.equalsIgnoreCase("in-progress")
										&& callRecordFac.equals("1")) {
									recordIvrCall(callUUID,
											reqbean.getServiceId(),
											reqbean.getVarMap());
									reqbean.setCallSequence("2");
								}
								if (callStatus.equalsIgnoreCase("completed")) {
									reqbean.setLinkMap(null);
									actionSequence = 0;
									reqbean.setActionSequence(actionSequence);
									reqbean.setItemId(itemId);

									if (request.getParameter("HangupCause") != null) {
										reqbean.getVarMap()
												.put("hangupCause",
														request.getParameter("HangupCause"));

										if (request.getParameter("campId") != null
												&& direction
														.equalsIgnoreCase("outbound")) {
											reqbean.getVarMap()
													.put("campId",
															request.getParameter("campId"));

										}
										if (request.getParameter("other") != null
												&& direction
														.equalsIgnoreCase("outbound")) {
											reqbean.getVarMap()
													.put("other",
															request.getParameter("other"));

										}

										String ringTime = reqbean.getVarMap()
												.get("ringTime");
										String callTime = getTime(callUUID);
										String callDuration = getCallDuration(
												ringTime, callTime);
										reqbean.getVarMap().put("callDuration",
												callDuration);
									}
									if (fWriteEnable.equals("1")) {
										flw.writeLog(reqbean.getCallDigInfo()
												.toString());
									}
								} else {
									itemId = reqbean.getItemId();
									actionSequence = reqbean
											.getActionSequence();
								}
								if (reqbean.getVarMap().containsKey(
										"recordStartTime")) {

									java.util.Date today = new java.util.Date();
									java.sql.Timestamp ts1 = new java.sql.Timestamp(
											today.getTime());
									long curTime = ts1.getTime();
									long recordStartTime = Long
											.parseLong(reqbean.getVarMap()
													.remove("recordStartTime"));
									long recordDuration = curTime
											- recordStartTime;
									reqbean.getVarMap().put("recordTime",
											Long.toString(recordDuration));

								}
								callDigInfo = reqbean.getCallDigInfo();
								if (dialHangupCause != null) {
									if (dialHangupCause
											.equalsIgnoreCase("failure"))
										reqbean.getVarMap().put(
												"dialHangupCause", "0");
									else if (dialHangupCause
											.equalsIgnoreCase("success"))
										reqbean.getVarMap().put(
												"dialHangupCause", "1");
								}
								if (request.getParameter("Digits") != null
										&& request.getParameter("Digits") != "") {
									reqbean.getVarMap().put("digits",
											request.getParameter("Digits"));
									if (fWriteEnable.equals("1")) {
										callDigInfo.append(",");
										callDigInfo.append(request
												.getParameter("Digits"));
										logger.debug("### CallDigInfo is : "
												+ callDigInfo);
										reqbean.getVarMap().put("callDigInfo",
												callDigInfo + "");
									}

								} else {
									reqbean.getVarMap().put("digits", "-1");
								}
								if (request.getParameter("RecordFile") != null) {
									reqbean.getVarMap().put("recordFile",
											request.getParameter("RecordFile"));
								}
								if (request.getParameter("RecordingDuration") != null) {
									reqbean.getVarMap()
											.put("recordingDuration",
													request.getParameter("RecordingDuration"));

								}
								if (!reqbean.getVarMap()
										.containsKey("ringTime")) {
									String ringTime = getTime(callUUID);
									reqbean.getVarMap().put("ringTime",
											ringTime);
								}
								if (!reqbean.getVarMap()
										.containsKey("callTime")) {
									String callTime = getTime(callUUID);
									reqbean.getVarMap().put("callTime",
											callTime);
								}
								httpClient = getHttpClientObject(callUUID,
										reqbean.getServiceId(), httpClient,
										reqbean.getVarMap());
								reqbean.setCallStatus(callStatus);
								rProcess = new RequestProcess();
								rProcess.doActionEvent(request, response,
										callUUID, itemId, actionSequence,
										reqbean, vxReader, httpClient,
										this.pxGenerator, separator);

								if (!reqbean.getCallStatus().equalsIgnoreCase(
										"completed")) {

									sinfo.beanMap.put(callUUID.trim(), reqbean,
											cacheExpireTime, TimeUnit.MINUTES);
									logger.info("["
											+ callUUID
											+ "] Data put in Map After perfoming Action");
									rProcess = null;

								} else {
									if (sinfo.beanMap.containsKey(callUUID)) {
										logger.info("["
												+ callUUID
												+ "] #Now removing Bean Info ####");
										sinfo.beanMap.remove(callUUID);
										logger.info("### [" + callUUID + "] "
												+ "Now Info is removed ");
									}
									rProcess = null;
									reqbean = null;
									logger.info("["
											+ callUUID
											+ "] "
											+ "HANGUP DETECTED REMOVING SESSION INFO ["
											+ callUUID + "]");
									callUUID = null;
									callDigInfo = null;
									callStatus = null;
									gc_cicId = null;
									direction = null;
									calledNum = null;
									callingNum = null;
									itemId = null;
									varMap = null;
									langMap = null;
									actionMap = null;
									httpClient = null;
									dbVarMap = null;
									conPoolMap = null;
									logger.debug("#### Sucessfully Call Ends ####");
								}

							} else {
								logger.info("["
										+ callUUID
										+ "] No Shortcode found for  this call ");
								reqbean = null;

								callUUID = null;
								callDigInfo = null;
								callStatus = null;
								gc_cicId = null;
								direction = null;
								calledNum = null;
								callingNum = null;
								itemId = null;
								varMap = null;
								langMap = null;
								actionMap = null;
								httpClient = null;
								dbVarMap = null;
								conPoolMap = null;

							}

						}
					}

				} else {
					logger.info("# Some mandatory parameters are missing . To ["
							+ request.getParameter("To")
							+ "] From ["
							+ request.getParameter("From")
							+ "] CallStatus ["
							+ request.getParameter("CallStatus") + "]");
				}
			} catch (Exception ee) {
				logger.fatal("Exception in PlivoServlet ", ee);
			} finally {

				out.close();
			}
		}
	}// processRequest method End here

	// LoadConPoolParameter method Start here
	private HashMap<String, DbPool> LoadConPoolParameter(String callUUID,
			String servId, HashMap<String, String> dbVarMap,
			HashMap<String, DbPool> conPoolMap, DbPool dbPool) {
		logger.debug("[" + callUUID + "] serv_id [" + servId
				+ "]inside the LoadConPoolParameter and Size of dbvarMap ["
				+ dbVarMap.size() + "]");
		String str = null;
		String username, password, ip, port, databasename, databaseType;
		conPoolMap = new HashMap<String, DbPool>();
		if (dbVarMap != null) {
			Iterator iterator = dbVarMap.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<String, String> mapEntry = (Map.Entry<String, String>) iterator
						.next();
				// System.out.println("The key is: " + mapEntry.getKey() +
				// ",value is :" + mapEntry.getValue());

				char copytstr[] = mapEntry.getValue().toCharArray();
				str = mapEntry.getValue();
				int lengthOfstr = copytstr.length;

				int index[] = new int[5];
				int count = 0;
				for (int i = 0; i < lengthOfstr; i++) {
					if (copytstr[i] == ',') {
						index[count] = i;
						count++;
					}
				}

				username = str.substring(0, index[0]);
				password = str.substring(index[0] + 1, index[1]);
				ip = str.substring(index[1] + 1, index[2]);
				port = str.substring(index[2] + 1, index[3]);
				databasename = str.substring(index[3] + 1, index[4]);
				databaseType = str.substring(index[4] + 1, lengthOfstr);

				username = username.substring(username.indexOf(':') + 1,
						username.length());
				password = password.substring(password.indexOf(':') + 1,
						password.length());
				ip = ip.substring(ip.indexOf(':') + 1, ip.length());
				databasename = databasename.substring(
						databasename.indexOf(':') + 1, databasename.length());
				port = port.substring(port.indexOf(':') + 1, port.length());
				databaseType = databaseType.substring(
						databaseType.indexOf(':') + 1, databaseType.length());

				dbPool = new DbPool();
				dbPool.setUsername(username);
				dbPool.setPassword(password);
				dbPool.setIp(ip);
				dbPool.setPort(port);
				dbPool.setDatabaseType(databaseType);
				dbPool.setDatabasename(databasename);
				logger.info("dbPool" + dbPool.getDatabasename());

				conPoolMap.put(dbPool.getDatabasename(), dbPool);
			}
		} else {
			logger.error("[" + callUUID + "] serv_id [" + servId
					+ "] dbVarMap found Null! ");
		}

		logger.debug("[" + callUUID
				+ "] End of LoadConPoolParameter and conPoolMap size is ["
				+ conPoolMap.size() + "]");
		return conPoolMap;
	}

	// LoadConPoolParameter method End here

	// getHttpClientObject method Start here
	private HttpClient getHttpClientObject(String callUUID, String servId,
			HttpClient httpClient, HashMap<String, String> varMap) {
		logger.debug("[" + callUUID
				+ "] #Inside getHttpClientObject() of appId [" + servId + "]");
		try {
			if (!sinfo.httpReaderMap.containsKey(servId)) {
				sinfo.createHttpClient(callUUID, servId, varMap, generalIp,
						generalPort, soTimeout, conTimeout, conManTimeout);
			}

			httpClient = sinfo.httpReaderMap.get(servId);
			logger.debug("[" + callUUID + "] # HttpClient for appId [" + servId
					+ "] is [" + httpClient
					+ "] Size of Map in getHttpClient is ["
					+ sinfo.httpReaderMap.size() + "]");
		} catch (Exception ex) {
			logger.fatal(
					"[" + callUUID + "] # Error in getHttpClientObject() ", ex);
		}
		logger.debug("[" + callUUID
				+ "] getHttpClientObject() ends here httpCLient is ["
				+ httpClient + "]");

		return httpClient;
	}// getHttpClientObject method End here

	// goToMainIvr method Start here
	private void goToMainIvr(String callUUID, String calledNum,
			String direction, RequestBean reqbean, HttpClient httpClient,
			String callingNum, VoiceXmlReader vxReader) {
		logger.info("[" + callUUID + "] Inside goToMainIvr() CalledNum ["
				+ calledNum + "] Dirction [" + direction + "]");
		String defaultId = sinfo.getDefaultShortCodeId(callUUID, calledNum,
				direction);
		String ringingTime = null;
		String callingTime = null;
		DbPool dbPool = null;
		HashMap<String, String> varMap = null;
		HashMap<String, String> langMap = null;
		HashMap<String, String> actionMap = null;
		HashMap<String, String> dbVarMap = null;
		HashMap<String, DbPool> conPoolMap = null;
		if (reqbean.getVarMap().containsKey("ringTime")) {
			ringingTime = reqbean.getVarMap().get("ringTime");
			logger.debug("[" + callUUID
					+ "] #Ringing Time is Exchanging time [" + ringingTime
					+ "]####");

		}
		if (reqbean.getVarMap().containsKey("callTime")) {
			callingTime = reqbean.getVarMap().get("callTime");
			logger.debug("[" + callUUID
					+ "] #Calling Time at Exchanging time [" + callingTime
					+ "]####");

		}

		reqbean.clearMap();

		reqbean.setServiceId(defaultId);
		varMap = reqbean.getVarMap();
		langMap = reqbean.getLangMap();
		logger.info("[" + callUUID + "] #LOADING PARAMETERS For ID ["
				+ defaultId + "] #####");
		vxReader = sinfo.voiceReaderMap.get(defaultId);
		varMap = LoadParameter(callUUID, defaultId, varMap, vxReader);
		dbVarMap = LoadDbParameter(callUUID, defaultId, dbVarMap, vxReader);
		conPoolMap = LoadConPoolParameter(callUUID, defaultId, dbVarMap,
				conPoolMap, dbPool);
		varMap.put("callUUID", callUUID);
		varMap.put("callingNum", callingNum);
		varMap.put("calledNum", calledNum);
		if (ringingTime != null || ringingTime != "") {
			varMap.put("ringTime", ringingTime);
			logger.debug("[" + callUUID + "] #RINGING TIME IS PUT ["
					+ ringingTime + "]");

		}
		if (callingTime != null || callingTime != "") {
			varMap.put("callTime", callingTime);
			logger.debug("[" + callUUID + "] #CALLING TIME IS PUT ["
					+ callingTime + "]");
		}

		if (vxReader != null) {
			langMap = LoadParameter(callUUID, defaultId, langMap, vxReader);
			reqbean.setVarMap(varMap);
			reqbean.setDbVarMap(dbVarMap);
			reqbean.setLangMap(langMap);
			reqbean.setLinkMap(null);
			reqbean.setConPoolMap(conPoolMap);
		} else {
			logger.info("[" + callUUID
					+ "] No Default Shortcode is Active for returnToShortcode ");
		}

	}// goToMainIvr method End here

	// LoadParameter method Start here
	private HashMap<String, String> LoadParameter(String callUUID,
			String servId, HashMap<String, String> varMap,
			VoiceXmlReader vxReader) {
		logger.debug("[" + callUUID + "] #Inside LoadParameter of AppId ["
				+ servId + "]");
		try {
			// variable are store in map
			varMap = vxReader.getXmlLangOrVarData(callUUID,
					vxReader.varXmlQuery, vxReader.varAttrib,
					vxReader.varAttribVal);
		} catch (Exception ex) {
			logger.fatal("[" + callUUID
					+ "] #Error in loading Parameter of AppId [" + servId
					+ "] with error ", ex);
		}
		return varMap;
	}// LoadParameter method End here

	// LoadDbParameter method Start here
	private HashMap<String, String> LoadDbParameter(String callUUID,
			String servId, HashMap<String, String> dbVarMap,
			VoiceXmlReader vxReader) {
		logger.debug("[" + callUUID + "] #Inside LoadDbParameter of AppId ["
				+ servId + "]");
		try {
			// variable are store in map
			dbVarMap = vxReader.getXmlLangOrVarData(callUUID,
					vxReader.dbVarXmlQuery, vxReader.varAttrib,
					vxReader.varAttribVal);
		} catch (Exception ex) {
			logger.fatal("[" + callUUID
					+ "] #Error in loading Parameter of AppId [" + servId
					+ "] with error ", ex);
		}
		return dbVarMap;
	}// LoadDbParameter method End here

	// recordIvrCall method Start here
	private void recordIvrCall(String callUUID, String servId,
			HashMap<String, String> varMap) {

		logger.info("[" + callUUID + "] #Inside recordIvrCall() of AppId ["
				+ servId + "]");
		try {
			boolean cCheck = false;
			logger.info("[" + callUUID + "] # Inside call Recording function ");
			String[] recordId = null;
			if (recordingId != null || recordingId != "") {
				if (recordingId.contains(",")) {
					recordId = recordingId.split(",");
					for (int i = 0; i < recordId.length; i++) {
						if (recordId[i].equals(servId)) {
							cCheck = true;
							logger.debug("### Cretaria Matched For Call Record ###");
							break;
						}
					}
				} else {
					if (recordingId.equals(servId)) {
						cCheck = true;
						logger.debug("### Cretaria Matched For Call Record ###");
					}
				}
			}
			if (callRecordFac.equalsIgnoreCase("1") && cCheck) {
				logger.debug("[" + callUUID
						+ "] #Call Record Feature Start ### ");

				logger.info("Version [" + plivoVersion + "] AccountId ["
						+ authId + "] Token [" + authToken + "] Plivo Url ["
						+ plivoUrl + "] call Record Path ["
						+ callRecordFilePath + "]");
				PlivoClient newCall = new PlivoClient(plivoVersion, authId,
						authToken, plivoUrl, true);

				CallFeature call = newCall.call();

				Map<String, String> callParams = new HashMap<String, String>();
				callParams.put("CallUUID", callUUID);
				callParams.put("FileFormat", "wav");
				callParams.put("FilePath", callRecordFilePath);
				java.util.Date today = new java.util.Date();
				java.sql.Timestamp ts1 = new java.sql.Timestamp(today.getTime());
				long tsTime1 = ts1.getTime();
				callParams.put("FileName",
						varMap.get("appName") + "_" + varMap.get("callingNum")
								+ "_" + tsTime1);
				RecordStartResponse callResponse = call.recordStart(callParams);
				logger.debug("Call Record with File Name ["
						+ varMap.get("appName") + "_"
						+ varMap.get("callingNum") + "_" + tsTime1);
				logger.debug("[" + callUUID + "] #Call Start Recording ###"
						+ callResponse);

			}
		} catch (Exception ex) {
			logger.fatal("[" + callUUID + "] # Error in recordIvrCall() ", ex);
		}

	}// recordIvrCall method End here

	// loadProperties method Start here
	public void loadProperties() {
		props = new Properties();
		String propPath = System.getenv("PROPERTY_FILE_PATH");
		String logPath = System.getenv("LOG_FILE_PATH");
		FileInputStream fin = null;
		PropertyConfigurator.configure(logPath + File.separatorChar
				+ "Log4j_XMLIVRParser.properties");
		// PropertyConfigurator.configure("/home/pankajmishra/development/server/tomcat/apache-tomcat-7.0.30/bin/Log4j_XMLIVRParser.properties");
		try {
			fin = new FileInputStream(propPath + File.separatorChar
					+ "XMLIVR_Parser.properties");
			// fin= new
			// FileInputStream("/home/pankajmishra/development/server/tomcat/apache-tomcat-7.0.30/bin/XMLIVR_Parser.properties");
			try {
				logger.debug("# Inside Loading Properties File");
				props.load(fin);
				ip = props.getProperty("IP").trim();
				port = props.getProperty("PORT").trim();
				generalIp = props.getProperty("GENERAL_IP").trim();
				generalPort = props.getProperty("GENERAL_PORT").trim();
				separator = props.getProperty("SEPARATOR").trim();
				dbDriver = props.getProperty("DB_DRIVER").trim();
				dbUrl = props.getProperty("DB_URL").trim();
				dbUser = props.getProperty("DB_USERNAME").trim();
				dbPass = props.getProperty("DB_PASSWORD").trim();
				fWriteEnable = props.getProperty("FWRITE_ENABLE").trim();
				fWritePath = props.getProperty("FWRITE_PATH").trim();
				fWriteInterval = props.getProperty("FWRITE_INTERVAL").trim();
				fWriteName = props.getProperty("FWRITE_NAME").trim();
				fArcName = props.getProperty("FARC_NAME").trim();
				soTimeout = props.getProperty("SOCKET_TIMEOUT").trim();
				conTimeout = props.getProperty("CONNECTION_TIMEOUT").trim();
				conManTimeout = props.getProperty("CON_MAN_TIMEOUT").trim();

				callRecordFac = props.getProperty("CALL_RECORDING").trim();
				callRecordFilePath = props.getProperty("CALL_RECORD_PATH")
						.trim();
				recordingId = props.getProperty("RECORD_APP_ID").trim();

				authId = props.getProperty("AUTH_ID").trim();
				authToken = props.getProperty("AUTH_TOKEN").trim();
				plivoUrl = props.getProperty("PLIVO_URL").trim();
				plivoVersion = props.getProperty("PLIVO_VERSION").trim();
				javasrcipt = props.getProperty("JAVASCRIPT").trim();
				cacheExpireTime = Integer.parseInt(props.getProperty(
						"CACHE_EXPIRE_TIME").trim());
				db_type = props.getProperty("DB_TYPE").trim();
				gateway = props.getProperty("GATEWAY").trim();
				extra_dial_String = props.getProperty("EXTRA_DIAL_STRING")
						.trim();

				fin.close();
				logger.info("# IP is [" + ip + "] Port is [" + port
						+ "] Separator [" + separator + "] FileWriteEnable ["
						+ fWriteEnable + "] conTimeout [" + conTimeout + "]");
			} catch (IOException ex) {
				logger.fatal("# Unable to load the file ", ex);
			}
		} catch (FileNotFoundException ex) {
			logger.fatal("# Exception due to file not found ", ex);
		} finally {

			props = null;
		}
		logger.debug("# Loading properties file end here");

	}// loadProperties method End here

	// getTime method Start here
	public String getTime(String callUUID) {
		logger.debug("[" + callUUID + "] #Inside getTime() ");
		String timeInfo = "";

		SimpleDateFormat sdf = null;
		if (db_type != null) {
			if (db_type.equalsIgnoreCase("mysql")) {
				sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			} else if (db_type.equalsIgnoreCase("oracle")) {
				sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			} else {
				sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			}
		} else {
			sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		}
		// sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		timeInfo = sdf.format(new java.util.Date());
		return timeInfo;
	}// getTime method End here

	public String getCallDuration(String ringTime, String callTime) {
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		Date d1 = null;
		Date d2 = null;
		long diffSeconds = 0;
		try {
			d1 = format.parse(ringTime);
			d2 = format.parse(callTime);

			// in milliseconds
			long diff = d2.getTime() - d1.getTime();

			diffSeconds = diff / 1000 % 60;
			System.out.print(diffSeconds + " seconds.");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return String.valueOf(diffSeconds);
	}

	// switchToNewShortcode method Start here
	public VoiceXmlReader switchToNewShortcode(String callUUID,
			String calledNum, String direction, HttpClient httpClient,
			String callingNum, VoiceXmlReader vxReader, RequestBean reqbean) {
		logger.info("[" + callUUID
				+ "] Request comes to switchToNewShortcode [" + calledNum + "]");
		String servId = sinfo.getAppIdForCall(calledNum, direction);
		// String
		// defaultId=sinfo.getDefaultShortCodeId(callUUID,calledNum,direction);
		String ringingTime = null;
		String callingTime = null;
		DbPool dbPool = null;
		HashMap<String, String> varMap = null;
		HashMap<String, String> dbVarMap = null;// change by jeevan
												// for add dppool
												// valiable as
												// global
		HashMap<String, String> langMap = null;
		HashMap<String, DbPool> conPoolMap = null;
		// ConcurrentHashMap<String, String> actionMap = null;
		if (reqbean.getVarMap().containsKey("ringTime")) {
			ringingTime = reqbean.getVarMap().get("ringTime");
			logger.debug("[" + callUUID
					+ "] #Ringing Time is Exchanging time  [" + ringingTime
					+ "]####");

		}
		if (reqbean.getVarMap().containsKey("callTime")) {
			callingTime = reqbean.getVarMap().get("callTime");
			logger.debug("[" + callUUID
					+ "] #Calling Time at Exchanging time [" + callingTime
					+ "]####");

		}

		reqbean.clearMap();
		reqbean.setServiceId(servId);
		reqbean.setChangeShortcode(new Byte("1"));
		reqbean.setItemId("#start");

		varMap = reqbean.getVarMap();
		langMap = reqbean.getLangMap();
		logger.info("[" + callUUID + "] #LOADING PARAMETERS For ID [" + servId
				+ "] #####");
		// vxReader = sinfo.voiceReaderMap.get(servId);
		vxReader = sinfo.voiceReaderMap.get(servId);
		dbVarMap = LoadDbParameter(callUUID, servId, dbVarMap, vxReader);// change
																			// by
																			// jeevan
																			// for
																			// add
																			// dppool
																			// valiable
																			// as
																			// global
		varMap = LoadParameter(callUUID, servId, varMap, vxReader);
		conPoolMap = LoadConPoolParameter(callUUID, servId, dbVarMap,
				conPoolMap, dbPool);

		varMap.put("callUUID", callUUID);
		varMap.put("callingNum", callingNum);
		varMap.put("calledNum", calledNum);
		if (ringingTime != null || ringingTime != "") {
			varMap.put("ringTime", ringingTime);
			logger.debug("[" + callUUID + "] #RINGING TIME IS PUT ["
					+ ringingTime + "]");

		}
		if (callingTime != null || callingTime != "") {
			varMap.put("callTime", callingTime);
			logger.debug("[" + callUUID + "] #CALLING TIME IS PUT ["
					+ callingTime + "]");
		}

		if (vxReader != null) {

			langMap = LoadLangParameter(callUUID, servId, langMap, vxReader);
			reqbean.setVarMap(varMap);
			reqbean.setLangMap(langMap);
			reqbean.setLinkMap(null);
			reqbean.setDbVarMap(dbVarMap);
			reqbean.setConPoolMap(conPoolMap);
			;
		} else {
			logger.info("[" + callUUID
					+ "] No New Shortcode is Active for returnToShortcode ");
		}
		return vxReader;
	}// switchToNewShortcode method End here

	/**
	 * 
	 * @param callUUID
	 *            unique id of call
	 * @param servId
	 *            application id
	 * @param langMap
	 *            map contains the language info
	 * @param vxReader
	 *            VoiceXmlReader object
	 * @return map contains the lang info and path
	 */
	// LoadLangParameter method Start here
	public HashMap<String, String> LoadLangParameter(String callUUID,
			String servId, HashMap<String, String> langMap,
			VoiceXmlReader vxReader) {
		logger.debug("[" + callUUID + "] #Inside LoadLangParameter of AppId ["
				+ servId + "] ");
		try {
			langMap = vxReader.getXmlLangOrVarData(callUUID,
					vxReader.langXmlQuery, vxReader.langAttrib,
					vxReader.langAttribVal);
		} catch (Exception ex) {
			logger.fatal("[" + callUUID
					+ "] #Error in loadingLang Parameter of AppId [" + servId
					+ "] with error ", ex);
		}
		return langMap;
	}// LoadLangParameter method End here
}
