package com.telemune.ivr.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;
import org.plivo.bridge.to.command.ApplicationResponse;
import org.plivo.bridge.to.command.Dial;
import org.plivo.bridge.to.command.Number;
import org.plivo.bridge.utils.PlivoUtils;

public class DialXmlServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Logger logger = Logger.getLogger(DialXmlServlet.class);

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {

		processRequest(req, res);

	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {

		processRequest(req, res);

	}

	private void processRequest(HttpServletRequest req, HttpServletResponse res) {
		ApplicationResponse ar = new ApplicationResponse();
		logger.info("Dial call request forwardingTo ["
				+ req.getParameter("forwardingTo") + "] alegid ["
				+ req.getParameter("alegid") + "]----------------------->");
		String extra_dial_string = PlivoControlServlet.extra_dial_String;
		String forwardingTo = req.getParameter("forwardingTo");
		String callUUId = req.getParameter("alegid");
		String sip_ip = req.getParameter("sip_ip");
		String sip_port = req.getParameter("sip_port");
		String gateway = PlivoControlServlet.gateway;
		forwardingTo = forwardingTo + "@" + sip_ip + ":" + sip_port;

		Dial dial = new Dial();
		dial.setTimeLimit(1200);
		Number number = new Number();
		number.setGateways(gateway);
		number.setExtraDialString(extra_dial_string);
		number.setGatewayCodecs("'PCMA,PCMU,G722'");
		number.setGatewayTimeouts("20,20");
		number.setNumber(forwardingTo);
		number.setGatewayRetries("1,1");
		dial.setNumber(number);
		dial.setAction("http://" + PlivoControlServlet.ip.trim() + ":"
				+ PlivoControlServlet.port + "/"
				+ req.getContextPath().replace("/", "") + "/plivoservlet");
		dial.setMethod("POST");
		ar.setDial(dial);
		try {
			PlivoUtils.JAXBContext.createContext().createMarshaller()
					.marshal(ar, res.getWriter());

		} catch (JAXBException e) {

			logger.fatal(" JAXBException ", e);

		} catch (Exception e) {
			logger.fatal("  Exception ", e);
		}

	}
}