package com.telemune.pojo;

import java.util.HashMap;

public class ActivationRequest {
	private String imsi="";
	private String taskName;
	private String msisdn;
	private HashMap<String, String> inputParams;
	
	public String getImsi() {
		return imsi;
	}
	public void setImsi(String imsi) {
		this.imsi = imsi;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public HashMap<String, String> getInputParams() {
		return inputParams;
	}
	public void setInputParams(HashMap<String, String> inputParams) {
		this.inputParams = inputParams;
	}
	@Override
	public String toString() {
		return "ActivationRequest [imsi=" + imsi + ", taskName=" + taskName + ", msisdn=" + msisdn + ", inputParams="
				+ inputParams + "]";
	}
	
	
	
}
