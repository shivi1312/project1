package com.telemune.pojo;

public class DeActivationRequest {
	private String imsi="";
	private String taskName;
	private String msisdn;
	public String getImsi() {
		return imsi;
	}
	public void setImsi(String imsi) {
		this.imsi = imsi;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	@Override
	public String toString() {
		return "DeActivationRequest [imsi=" + imsi + ", taskName=" + taskName + ", msisdn=" + msisdn + "]";
	}
	
}
