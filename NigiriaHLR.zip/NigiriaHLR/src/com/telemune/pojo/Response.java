package com.telemune.pojo;

import java.util.LinkedHashMap;

public class Response {
	private String st;
	private String msgid;
	private String msg;
	private String devErrorMessage;
	private String timestamp;
	private String validationError;
	private LinkedHashMap<String, String> data;
	
	public String getSt() {
		return st;
	}
	public void setSt(String st) {
		this.st = st;
	}
	public String getMsgid() {
		return msgid;
	}
	public void setMsgid(String msgid) {
		this.msgid = msgid;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getDevErrorMessage() {
		return devErrorMessage;
	}
	public void setDevErrorMessage(String devErrorMessage) {
		this.devErrorMessage = devErrorMessage;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getValidationError() {
		return validationError;
	}
	public void setValidationError(String validationError) {
		this.validationError = validationError;
	}
	public LinkedHashMap<String, String> getData() {
		return data;
	}
	public void setData(LinkedHashMap<String, String> data) {
		this.data = data;
	}
	@Override
	public String toString() {
		return "Response [st=" + st + ", msgid=" + msgid + ", msg=" + msg + ", devErrorMessage=" + devErrorMessage
				+ ", timestamp=" + timestamp + ", validationError=" + validationError + ", data=" + data + "]";
	}
	
	
}
