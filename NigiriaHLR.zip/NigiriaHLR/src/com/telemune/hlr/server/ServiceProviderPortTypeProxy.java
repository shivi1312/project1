package com.telemune.hlr.server;

public class ServiceProviderPortTypeProxy implements com.telemune.hlr.server.ServiceProviderPortType {
  private String _endpoint = null;
  private com.telemune.hlr.server.ServiceProviderPortType serviceProviderPortType = null;
  
  public ServiceProviderPortTypeProxy() {
    _initServiceProviderPortTypeProxy();
  }
  
  public ServiceProviderPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initServiceProviderPortTypeProxy();
  }
  
  private void _initServiceProviderPortTypeProxy() {
    try {
      serviceProviderPortType = (new com.telemune.hlr.server.ServiceProviderLocator()).getServiceProviderHttpSoap11Endpoint();
      if (serviceProviderPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)serviceProviderPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)serviceProviderPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (serviceProviderPortType != null)
      ((javax.xml.rpc.Stub)serviceProviderPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.telemune.hlr.server.ServiceProviderPortType getServiceProviderPortType() {
    if (serviceProviderPortType == null)
      _initServiceProviderPortTypeProxy();
    return serviceProviderPortType;
  }
  
  public int getSubType(int msisdn) throws java.rmi.RemoteException{
    if (serviceProviderPortType == null)
      _initServiceProviderPortTypeProxy();
    return serviceProviderPortType.getSubType(msisdn);
  }
  
  public int downFlag(int msisdn) throws java.rmi.RemoteException{
    if (serviceProviderPortType == null)
      _initServiceProviderPortTypeProxy();
    return serviceProviderPortType.downFlag(msisdn);
  }
  
  public int upFlag(int msisdn) throws java.rmi.RemoteException{
    if (serviceProviderPortType == null)
      _initServiceProviderPortTypeProxy();
    return serviceProviderPortType.upFlag(msisdn);
  }
  
  
}