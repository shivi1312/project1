package com.telemune.hlr.backend;
import java.util.HashMap;
import java.util.Scanner;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.pojo.ActivationRequest;
import com.telemune.pojo.DeActivationRequest;
import com.telemune.pojo.Response;

public class SendToHLR {

	final static Logger logger = Logger.getLogger("SendToHLR");
	private String url;
	private int timeout=10;
	
	public SendToHLR() {
		try
    	{
    		this.timeout=Config.connectionTimeOut;
    	}
    	catch(Exception exp)
    	{
    		exp.printStackTrace();
    	}
	}

	public String getSubType(DataObject dataObject, String url) 
	{
		String subType = "NA";
		int result = -1;
		try
		{
			result=1; // We are considering all msisdn as Prepaid at this site
			logger.info("msisdn["+dataObject.getMsisdn()+"] We are considering all msisdn as Prepaid at this site... subType is["+subType+"]");
			if(result == 1){ subType="P";
			dataObject.setIsPrePaidId("Y");
			dataObject.setResponse("0");
			}
			else { subType="O";
			dataObject.setIsPrePaidId("N");
			dataObject.setResponse("0");
			}
			System.out.println("msisdn["+dataObject.getMsisdn()+"] subType is["+subType+"]");
			return subType;
		
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		return subType;
	}
	
	public String upFlag(DataObject dataObject, String url)
	{
		String upFlag = "NA";
		this.url=url;
		String response = "-1";
		Gson gson = null;
		int responseCFB = -1;
		int responseCFNRC = -1;
		int responseCFNRY = -1;
		String msisdn = dataObject.getMsisdn().substring(3);
		try {
			gson=new Gson();
			    if (Config.VCC_CFB_ENABLE==1) {
//				int cfbResult=-1;
				ActivationRequest activationRequest = new ActivationRequest();
				activationRequest.setTaskName("CFB_ACTIVATE");
				activationRequest.setMsisdn(msisdn);
		        HashMap<String, String> inputParams = new HashMap<>();
		        inputParams.put("FTN", Config.FTN_NUMBER); 
		        activationRequest.setInputParams(inputParams);
		        String requestdata = gson.toJson(activationRequest);
		        logger.info("##>>msisdn["+dataObject.getMsisdn()+"] CFB_ACTIVATE Request Data["+requestdata.toString()+"]");
		        responseCFB=sendPost(requestdata,"Activation",dataObject);
			}
			if (Config.VCC_CFNRC_ENABLE==1) {
//				int cfnrcResult=-1;
				ActivationRequest activationRequest = new ActivationRequest();
				activationRequest.setTaskName("CFNRC_ACTIVATE");
				activationRequest.setMsisdn(msisdn);
		        HashMap<String, String> inputParams = new HashMap<>();
		        inputParams.put("FTN", Config.FTN_NUMBER); 
		        activationRequest.setInputParams(inputParams);
		        String requestdata = gson.toJson(activationRequest);
		        logger.info("##>>msisdn["+dataObject.getMsisdn()+"] CFNRC_ACTIVATE Request Data["+requestdata.toString()+"]");
		        responseCFNRC=sendPost(requestdata,"Activation",dataObject);
			}
			if (Config.VCC_CFNRY_ENABLE==1) {
//				int cfnryResult=-1;
				ActivationRequest activationRequest = new ActivationRequest();
				activationRequest.setTaskName("CFNRY_ACTIVATE");
				activationRequest.setMsisdn(msisdn);
		        HashMap<String, String> inputParams = new HashMap<>();
		        inputParams.put("FTN", Config.FTN_NUMBER); 
		        activationRequest.setInputParams(inputParams);
		        String requestdata = gson.toJson(activationRequest);
		        logger.info("##>>msisdn["+dataObject.getMsisdn()+"] CFNRY_ACTIVATE Request Data["+requestdata.toString()+"]");
		        responseCFNRY=sendPost(requestdata,"Activation",dataObject);
			}
			
			logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] "
					+ "VCC_CFB_ENABLE["+Config.VCC_CFB_ENABLE+"] Flag Up responseCFB["+responseCFB+"] "
					+ "VCC_CFNRC_ENABLE["+Config.VCC_CFNRC_ENABLE+"] Flag Up responseCFNRC["+responseCFNRC+"] "
					+ "VCC_CFNRY_ENABLE["+Config.VCC_CFNRY_ENABLE+"] Flag Up responseCFNRY["+responseCFNRY+"]");
			
			if (Config.VCC_CFB_ENABLE!=1) {
				responseCFB = 1;
			}
			if (Config.VCC_CFNRC_ENABLE!=1) {
				responseCFNRC = 1;
			}
			if (Config.VCC_CFNRY_ENABLE!=1) {
				responseCFNRY = 1;
			}
			
			if (responseCFNRY==1 && responseCFB==1 && responseCFNRC==1) {
				response = "0";
			}
			
			if(response.equalsIgnoreCase("0")){ upFlag="UP";
			dataObject.setResponse("0");
			}
			else { upFlag="NOT UP"; 
			dataObject.setResponse("-1");
			
			}
    		logger.info("msisdn["+dataObject.getMsisdn()+"] UpFlag status is ["+upFlag+"]");
			System.out.println("msisdn["+dataObject.getMsisdn()+"] UpFlag status is ["+upFlag+"]");
			return upFlag;
			
		} catch (Exception exp) {
			logger.error(">>>msisdn:["+dataObject.getMsisdn()+"] Exception in upFlag method... ",exp);
			System.err.println(">>>msisdn:["+dataObject.getMsisdn()+"] Exception in upFlag method... "+exp);
		    exp.printStackTrace();
		}
		return upFlag;
	}
	
	public String downFlag(DataObject dataObject, String url)
	{
		String downFlag = "NA";
		this.url=url;
		String response = "-1";
		Gson gson = null;
		int responseCFB = -1;
		int responseCFNRC = -1;
		int responseCFNRY = -1;
		String msisdn = dataObject.getMsisdn().substring(3);
		try {
			gson=new Gson();
			if (Config.VCC_CFB_ENABLE==1) {
//				int cfbResult=-1;
				DeActivationRequest deactivateRequest = new DeActivationRequest();
				deactivateRequest.setTaskName("CFB_DE_ACTIVATE");
				deactivateRequest.setMsisdn(msisdn);
		        String requestdata = gson.toJson(deactivateRequest);
		        logger.info("##>>msisdn["+dataObject.getMsisdn()+"] CFB_DE_ACTIVATE Request Data["+requestdata.toString()+"]");
		        responseCFB=sendPost(requestdata,"De-Activation",dataObject);
			}
			if (Config.VCC_CFNRC_ENABLE==1) {
//				int cfnrcResult=-1;
				DeActivationRequest deactivateRequest = new DeActivationRequest();
				deactivateRequest.setTaskName("CFNRC_DE_ACTIVATE");
				deactivateRequest.setMsisdn(msisdn);
		        String requestdata = gson.toJson(deactivateRequest);
		        logger.info("##>>msisdn["+dataObject.getMsisdn()+"] CFNRC_DE_ACTIVATE Request Data["+requestdata.toString()+"]");
		        responseCFNRC=sendPost(requestdata,"De-Activation",dataObject);
			}
			if (Config.VCC_CFNRY_ENABLE==1) {
//				int cfnryResult=-1;
				DeActivationRequest deactivateRequest = new DeActivationRequest();
				deactivateRequest.setTaskName("CFNRY_DE_ACTIVATE");
				deactivateRequest.setMsisdn(msisdn);
		        String requestdata = gson.toJson(deactivateRequest);
		        logger.info("##>>msisdn["+dataObject.getMsisdn()+"] CFNRY_DE_ACTIVATE Request Data["+requestdata.toString()+"]");
		        responseCFNRY=sendPost(requestdata,"De-Activation",dataObject);
			}
			
			logger.info("\n\n msisdn["+dataObject.getMsisdn()+"] "
					+ "VCC_CFB_ENABLE["+Config.VCC_CFB_ENABLE+"] Flag Down responseCFB["+responseCFB+"] "
					+ "VCC_CFNRC_ENABLE["+Config.VCC_CFNRC_ENABLE+"] Flag Down responseCFNRC["+responseCFNRC+"] "
					+ "VCC_CFNRY_ENABLE["+Config.VCC_CFNRY_ENABLE+"] Flag Down responseCFNRY["+responseCFNRY+"]");
			
			if (Config.VCC_CFB_ENABLE!=1) {
				responseCFB = 1;
			}
			if (Config.VCC_CFNRC_ENABLE!=1) {
				responseCFNRC = 1;
			}
			if (Config.VCC_CFNRY_ENABLE!=1) {
				responseCFNRY = 1;
			}
			
			if (responseCFNRY==1 && responseCFB==1 && responseCFNRC==1) {
				response = "0";
			}
			
			if(response.equalsIgnoreCase("0")){ downFlag="DOWN";
			dataObject.setResponse("0");
			}
			else { downFlag="NOT DOWN";
			dataObject.setResponse("-1");
			}
    		logger.info("msisdn["+dataObject.getMsisdn()+"] downFlag status is ["+downFlag+"]");
			System.out.println("msisdn["+dataObject.getMsisdn()+"] downFlag status is ["+downFlag+"]");
			return downFlag;
		} catch (Exception exp) {
			logger.error(">>>msisdn:["+dataObject.getMsisdn()+"] Exception in downFlag method... ",exp);
			System.err.println(">>>msisdn:["+dataObject.getMsisdn()+"] Exception in downFlag method... "+exp);
		    exp.printStackTrace();
		}
		return downFlag;
	}
	
	private int sendPost(String jsonRequest, String req, DataObject dataObject) {
//    	StringBuffer responseXml = null;
		CloseableHttpClient client = null;
		CloseableHttpResponse response = null;
		HttpPost post = null;
		HttpParams httpParams = null;
		Response jsonResponse;
		Gson gson;
		String taskName;
		String status;
		String statusCode;
		String statusDesc;
		int result=-1;
		try {
			gson=new Gson();
//			client = HttpClients.createDefault();
			client = HttpClientBuilder.create().disableContentCompression().build();
			
//			RequestConfig config = RequestConfig.custom().setLocalAddress(InetAddress.getLocalHost()).build();
//			client =  HttpClientBuilder.create().setDefaultRequestConfig(config).build();
			
			httpParams = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParams, this.timeout * 1000);
			HttpConnectionParams.setSoTimeout(httpParams, this.timeout * 1000);
			
			post = new HttpPost(this.url);
			
			post.setParams(httpParams);
//			responseXml = new StringBuffer();
			
			post.addHeader("Content-Type", "application/json");
			post.addHeader("X-Api-Client", "G8HMqxq7d6");
			post.addHeader("Accept", "*/*");
//			post.addHeader("Accept-Encoding", "identity");
//			post.addHeader("Accept", "text/xml");
//			post.addHeader("Except", "100-continue");
//			post.addHeader("IP", InetAddress.getLocalHost().toString());
			
			StringEntity entity = new StringEntity(jsonRequest);
			post.setEntity(entity);
			
			System.out.println("\n>>>msisdn[" + dataObject.getMsisdn() + "]  Sending 'POST' " + req + " request to URL :[" + this.url + "]\n");
			logger.info("\n>>>msisdn[" + dataObject.getMsisdn() + "]  Sending 'POST' " + req + " request to URL :[" + this.url + "]\n");
			
			response = client.execute(post);
			logger.debug(">>>msisdn[" + dataObject.getMsisdn() + "] response:["+response+"] response params:["+response.getParams()+"]");
			int returnCode = response.getStatusLine().getStatusCode();
			String jsonResult = EntityUtils.toString(response.getEntity());
			logger.debug(">>>msisdn[" + dataObject.getMsisdn() + "] jsonResult:["+jsonResult+"]");
			System.out.println(">>>msisdn[" + dataObject.getMsisdn() + "] " + req + " post hit returnCode:[" + returnCode + "]");
			logger.info(">>>msisdn[" + dataObject.getMsisdn() + "] " + req + " post hit returnCode:[" + returnCode + "]");
			
			if (returnCode == HttpStatus.SC_NOT_IMPLEMENTED) {
				logger.info(">>>msisdn[" + dataObject.getMsisdn() + "] The Post post is not implemented by this URI");
				System.err.println(">>>msisdn[" + dataObject.getMsisdn() + "] The Post post is not implemented by this URI");
				logger.info(">>>msisdn[" + dataObject.getMsisdn() + "] Post hit result["+jsonResult+"]");
		        System.err.println(">>>msisdn[" + dataObject.getMsisdn() + "] Post hit result["+jsonResult+"]");
			} else {
				jsonResponse = gson.fromJson(jsonResult, Response.class);
				logger.info(">>>msisdn[" + dataObject.getMsisdn() + "] Response from 'POST' "+ req + " "+jsonResponse.toString());
				taskName=jsonResponse.getData().get("taskName");
				status=jsonResponse.getData().get("status");
				statusCode=jsonResponse.getData().get("statusCode");
				statusDesc=jsonResponse.getData().get("statusDesc");
				if ((statusCode.equalsIgnoreCase("0") || statusCode.equalsIgnoreCase("3006")) && (statusDesc.contains("Operation is successful") || statusDesc.contains("already exist") || statusDesc.contains("Already existed"))) {
					result=1; // success case
					logger.info("\n###>>> msisdn:["+dataObject.getMsisdn()+"] "+req+" Response: taskName ["+taskName+"]"
							+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] "+req+" Response: status ["+status+"]"
							+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] "+req+" Response: statusCode ["+statusCode+"]"
							+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] "+req+" Response: statusDesc ["+statusDesc+"]");
				} else {
					result=-1; // fail case
					logger.info("\n###>>> msisdn:["+dataObject.getMsisdn()+"] "+req+" Response: taskName ["+taskName+"]"
							+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] "+req+" Response: status ["+status+"]"
							+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] "+req+" Response: statusCode ["+statusCode+"]"
							+ "\n###>>> msisdn:["+dataObject.getMsisdn()+"] "+req+" Response: statusDesc ["+statusDesc+"]");
				}
//				responseXml.append(result);
			}
			
		} catch (Exception e) {
			logger.error(">>>msisdn["+dataObject.getMsisdn()+"] Exception in sendPost method at " + req + " request... ",e);
		    System.err.println(">>>msisdn["+dataObject.getMsisdn()+"] Exception in sendPost method at " + req + " request... "+e);
		    e.printStackTrace();
		} finally {
			if (post != null) {
		         try {
		           post.releaseConnection();
		           post = null;
		         } catch (Exception e2) {
		           e2.printStackTrace();
		         }
		       }
		 
		       httpParams = null;
		 
		       if (client != null) {
		         try {
		           client.close();
		           client = null;
		         } catch (Exception e3) {
		           e3.printStackTrace();
		         }
		       }
		 
		       if (response != null) {
		         try {
		           response.close();
		           response = null;
		         } catch (Exception e4) {
		           e4.printStackTrace();
		         }
		       }
		}
		return result;
    }
	
	/*public String hlrFlagActivity(String msisdn, int reqtype, String hlrUrl, int conTimeout) 
	{
		logger.debug("##>>msisdn["+msisdn+"] Url fetched from HLRInterface ["+hlrUrl+"] conTimeout["+conTimeout+"]");
		hlrUrl = hlrUrl + "?MDN=" + msisdn + "&CRBT=";
		int responseCode = 404;
		String response = "";
		URL url = null;
		try {

			if (reqtype == 3) {
				hlrUrl = hlrUrl + "1";
				logger.info("##>>msisdn["+msisdn+"] HLR Up request url [" + hlrUrl + "]");
			}
			else if (reqtype == 4) {
				hlrUrl = hlrUrl + "0";
				logger.info("##>>msisdn["+msisdn+"] HLR Down request url [" + hlrUrl + "]");
			}
			
			if (Config.TESTING != 1) {
				url = new URL(hlrUrl);
			} else {
				logger.warn("\n\n\t\tTESTING is enable\n\n");
				url = new URL("https://www.google.co.in");
			}
			
			logger.info("\n\n\t\tGoing to hit url [" + url + "]\n");
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			logger.debug("##>>msisdn["+msisdn+"] Connection [" + con + "]");
			con.setRequestMethod("GET");
 
			try {
				
				con.setConnectTimeout(conTimeout*1000); // set timeout to properties
				responseCode = con.getResponseCode();
				logger.info("##>>msisdn["+msisdn+"] In hlrFlagDown.....received responseCode is ["+ responseCode + "]");
			} catch (Exception iae) {
				logger.info("##>>msisdn["+msisdn+"] Illegal Argument Exception \n", iae);
				iae.printStackTrace();
			}

			if (responseCode == 200) 
			{
				response = "0";
				if (reqtype == 3) {
					logger.info("##>>msisdn["+msisdn+"] HLR Up request processed Successfully!!! responseCode ["
							+ responseCode + "] response [" + response + "]");
				}
				if (reqtype == 4) {
					logger.info("##>>msisdn["+msisdn+"] HLR Down request processed Successfully!!! responseCode ["
							+ responseCode + "] response [" + response + "]");
				}
			}
			else 
			{
				response = "-1";
				if (reqtype == 3) {
					logger.info("##>>msisdn["+msisdn+"] There is some problem in processing HLR Up request!!! responseCode ["
							+ responseCode + "] response [" + response + "]");
				}
				if (reqtype == 4) {
					logger.info("##>>msisdn["+msisdn+"] There is some problem in processing HLR Down request!!! responseCode ["
							+ responseCode + "] response [" + response + "]");
				}
			}

		} catch (Exception ekseption) {
			response = "-1";
			logger.error("\n\n\t\tProblem in hlrFlagActivity() method \n", ekseption);
			ekseption.printStackTrace();
		}
		return response;
	}// added by yash on 21.11.2016
*/
	public static void main(String arg[])
    {
		SendToHLR sendToHlr = new SendToHLR();
		int reqType=3;
		String msisdn="99999999";
		String url = "http://IP:Port/ps/v1/rest/data/cmd";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter url : ");
		url=sc.next();
		System.out.println("Enter reqtype [3(flagUp) or 4(flagDown)] : ");
		reqType=sc.nextInt();
		System.out.println("Enter msisdn : ");
		msisdn=sc.next();
		sendToHlr.url=url;
		Config.VCC_CFB_ENABLE=1;
		Config.VCC_CFNRC_ENABLE=1;
		Config.VCC_CFNRY_ENABLE=1;
    	DataObject dataObject = new DataObject();
    	dataObject.setMsisdn(msisdn);
    	dataObject.setReqType(reqType);
    	sendToHlr.upFlag(dataObject,url);
    	System.out.println("respose["+dataObject.getResponse()+"]");
    }
}
