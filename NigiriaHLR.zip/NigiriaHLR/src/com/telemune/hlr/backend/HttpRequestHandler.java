package com.telemune.hlr.backend;

import org.apache.log4j.Logger;


public class HttpRequestHandler implements HlrInterface{
	final static Logger logger = Logger.getLogger(HttpRequestHandler.class);
	SendToHLR sendToHLR = null;		
	static int counter = 0;
	public long objectNo ;
	public String hlrUrl;
	
	public HttpRequestHandler(long i,String hlrUrl) {
		logger.info("Inside HttpRequestHandler Object no "+i+" created for hlrUrl["+hlrUrl+"]");
		sendToHLR =  new SendToHLR();
		this.objectNo = i;
		this.hlrUrl = hlrUrl;
	}
	
	public int doProcessing(DataObject dataObject) {
		try
		{
		logger.info("##>inside doProcessing in HttpRequestHandler request is ["+dataObject+"]");	
		if (Config.TESTING==1) {
			logger.info("\n\n\t\t**************Testing is Enabled***************\n\n");
			if ("SuccessTesting".equalsIgnoreCase(Config.TESTING_STRING)) {
				logger.info("Yes, TESTING_STRING contains the required String... TESTING_STRING ["+Config.TESTING_STRING+"]");
				if (dataObject.getReqType()==6) {
					dataObject.setIsPrePaidId("Y"); // In testing all msisdn is considered as Prepaid
					dataObject.setResponse("0");	
					logger.info(">>>>>"+dataObject.getMsisdn()+" is PrePaid");
					logger.debug("\n\tIn testing all msisdn considered as Prepaid");
				}
				else if (dataObject.getReqType()==3) {
					dataObject.setIsPrePaidId("Y"); // In testing all msisdn is considered as Prepaid
					dataObject.setResponse("0");
					logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Up Success");
				}
				else if (dataObject.getReqType()==4) {
					dataObject.setIsPrePaidId("Y"); // In testing all msisdn is considered as Prepaid
					dataObject.setResponse("0");
					logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Down Success");
				}
			} else {
				logger.info("No, TESTING_STRING doesn't contain the required String... TESTING_STRING ["+Config.TESTING_STRING+"]");
				if (dataObject.getReqType()==6) {
					dataObject.setResponse("-1");	
					logger.info(">>>>>"+dataObject.getMsisdn()+" subType NOT FOUND");
				}
				else if (dataObject.getReqType()==3) {
					dataObject.setResponse("-1");
					logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Up FAILURE");
				}
				else if (dataObject.getReqType()==4) {
					dataObject.setResponse("-1");
					logger.info(">>>>>"+dataObject.getMsisdn()+" Flag Down FAILURE");
				}
			}
		}else {
			if(dataObject.getReqType() == 6)
			{
				sendToHLR.getSubType(dataObject, hlrUrl);
			}
			else if(dataObject.getReqType() == 3)
			{
				sendToHLR.upFlag(dataObject, hlrUrl);
			}
			else if(dataObject.getReqType() == 4)
			{
				sendToHLR.downFlag(dataObject, hlrUrl);
			}
			logger.info("##>inside doProcessing in HttpRequestHandler Response is ["+dataObject+"]");	
			return 1;
		}

		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		return -1;
	}
	
	/*public int doProcessing(DataObject dataObject) {
		
		String response = "";
		SendToHLR sendToHLR =  new SendToHLR();
		int sendNext = -1;
		try 
		{
			logger.info("\n\n\tdata fetched to process with HLR is: \n"+dataObject+"\n\n for objectNO["+objectNo+"]");
			if(Config.TESTING != 1)
			{
			response = sendToHLR.hlrFlagActivity(dataObject.getMsisdn(), dataObject.getReqType(), hlrUrl, Config.connectionTimeOut);
			}
			dataObject.setReqId(1);
			dataObject.setMsrn("NULL");
			dataObject.setMscNo("NULL");
			dataObject.setImsi("NULL");
			dataObject.setScfAddr("NULL");
			dataObject.setServiceKey(0);
			dataObject.setIsPrePaidId("N");
			dataObject.setIsRoaming("N");
			dataObject.setResponse(response);
			dataObject.setBusyNo("NULL");
			dataObject.setNoReachNo("NULL");
			dataObject.setNoReply("NULL");
			dataObject.setIsCFU("N");
			dataObject.setCFU("NULL");
			dataObject.setSendNextHlr(sendNext);
			logger.info("\n After processing request Data is: ["+dataObject+"]\n\n for object no["+objectNo+"]");
			return 1;
		} 
		catch(NullPointerException nullexp)
		{
			logger.fatal("Problem in HttpRequestHandler",nullexp);
			nullexp.printStackTrace();
			return -1;
		}
		catch (Exception e) {
			logger.fatal("Problem in HttpRequestHandler",e);
			e.printStackTrace();
			return -1;
		}
		
	}*/
	public boolean keepAlive() {
		return false;  //not used for Http
	}
	public boolean isConnected() {
		return false; //not used for Http
	}



	public long getObjectNo() {
		// TODO Auto-generated method stub
		return objectNo;
	}

}
