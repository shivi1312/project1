package com.telemune.hlr.backend;

import java.util.ArrayList;

public class Config {

	static String TelnetRequestForCS;
	static String TelnetRequestForUF;
	static String TelnetRequestForDF;
	static String LOGIN_VALIDATOR;
	static String PASSWORDFRMT;
	static String LOGINFRMT;
	/*
	 * static String TELNET_CONFIGUREDIP; static int PORT; static String REMOTEUSER;
	 * static String REMOTEPASSWD;
	 */
	static String REMOTETERMINATOR;
	static String LOGINCMD;
	static String CONNECTION_CHECKING_CMD;
	public static int TESTING = 0;
	public static int connectionTimeOut = 1;
	public static ArrayList<String> prePaid_tplId = new ArrayList<String>();
	public static ArrayList<String> postPaid_tplId = new ArrayList<String>();
	public static String FTN_NUMBER = "NA";
	// addition by Avishkar on 3-09-2020 start
	public static String TESTING_STRING = "";
	public static int VCC_CFNRY_ENABLE = -1;
	public static int VCC_CFB_ENABLE = -1;
	public static int VCC_CFNRC_ENABLE = -1;
	static String TelentRequestFor_CFNRY_UF;
	static String TelentRequestFor_CFNRY_DF;
	static String TelentRequestFor_CFB_UF;
	static String TelentRequestFor_CFB_DF;
	static String TelentRequestFor_CFNRC_UF;
	static String TelentRequestFor_CFNRC_DF;
	public static int prepaidCheck = -1;
	public static int chk_imsi_start_bit = 1;
	public static int chk_imsi_no_of_bits = 2;
	public static ArrayList<String> prepostranges = new ArrayList<String>();
	// addition by Avishkar on 3-09-2020 ends
	
	// added by Avishkar 22-01-2021 start
	/**
	 * Below username and password is added for Soap and http hlr type
	 */
	public static String USERNAME;
	public static String PASSWORD;
	// SERIAL is used to identify current service request, Must be a unique number. Built with country identifier and service
	public static String SERIAL_FORMAT="UG-SC_-VCC-";
	public static String HLR_SOAP_URL;
	// added by Avishkar 22-01-2021 end
}
