package com.vcc.persistent.client.codec;

import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;

import org.apache.log4j.Logger;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.AttributeKey;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolEncoder;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;

public class TeleRequestEncoder implements ProtocolEncoder {
	@SuppressWarnings("unused")
	private final static Logger logger = Logger
			.getLogger(TeleRequestEncoder.class);
	private final AttributeKey ENCODER = new AttributeKey(getClass(), "encoder");
	private Charset charset;

	public TeleRequestEncoder(Charset charset){
		this.charset = charset;
	}
	
	public void encode(IoSession session, Object message,
			ProtocolEncoderOutput out) throws Exception {
		CharsetEncoder encoder = (CharsetEncoder) session.getAttribute(ENCODER);
		if (encoder == null) {
			encoder = charset.newEncoder();
            session.setAttribute(ENCODER, encoder);
		}
		TeleRequest request = (TeleRequest) message;
		IoBuffer buffer = IoBuffer.allocate(8 + request.getRequest().length())
				.setAutoExpand(true);
		buffer.putInt(4 + request.getRequest().length());
		buffer.putInt(request.getCorrelationId());
		buffer.putString(request.getRequest(), encoder);
		buffer.flip();
		out.write(buffer);
	}

	public void dispose(IoSession session) throws Exception {
		// nothing to dispose
	}

}
