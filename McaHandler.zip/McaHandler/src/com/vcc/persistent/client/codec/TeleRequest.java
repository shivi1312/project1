package com.vcc.persistent.client.codec;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class TeleRequest {
	public static AtomicInteger messageIdSeq = new AtomicInteger();
	private int correlationId;
	private String request;
	private String response;
	private String modeType = "async";

	private final BlockingQueue<String> availableResponse = new ArrayBlockingQueue<String>(
			1);
	public TeleRequest(String request){
		this.request = request;
		this.correlationId = messageIdSeq.incrementAndGet();
	}

	public TeleRequest() {
		this.correlationId = messageIdSeq.incrementAndGet();
	}

	public String getResponse() {
		return this.response;
	}

	public String getRequest() {
		return this.request;
	}

	public int getCorrelationId() {
		return correlationId;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getModeType() {
		return modeType;
	}

	public void setModeType(String modeType) {
		this.modeType = modeType;
	}

	public void setCorrelationId(int correlationId) {
		this.correlationId = correlationId;
	}

	public void responseReceived(String response) {
		this.response = response;
		availableResponse.offer(response);
	}

	public String waitResponse(long timeout, TimeUnit unit)
			throws InterruptedException {
		return availableResponse.poll(timeout, unit);
	}

	@Override
	public String toString() {
		return "-->" + correlationId + "-" + request + "-" + response;
	}
}
