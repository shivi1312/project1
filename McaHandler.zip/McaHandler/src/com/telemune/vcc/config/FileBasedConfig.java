package com.telemune.vcc.config;

import org.apache.log4j.Logger;
import FileBaseLogging.FileLogWriter;

public class FileBasedConfig {
	
	final static Logger logger = Logger.getLogger(FileBasedConfig.class);
	/*public static FileLogWriter responseFlWriter= new FileLogWriter();*/
	public static FileLogWriter dropReqFlWriter= new FileLogWriter();
	private FileBasedConfig(){
		
	}
	static{
		try{
			/*responseFlWriter.setNewFileInterval(AppConfig.config.getInt("REQ_LOG_FILE_INTERVAL"));
			responseFlWriter.setFilename(AppConfig.config.getString("Response_LOG_FILENAME"));
			responseFlWriter.setFilePath(AppConfig.config.getString("REQ_LOG_FILEPATH"));
			responseFlWriter.initialize();*/
			
			dropReqFlWriter.setNewFileInterval(AppConfig.config.getInt("DROPREQ_LOG_FILE_INTERVAL"));
			dropReqFlWriter.setFilename(AppConfig.config.getString("DROPREQ_LOG_FILENAME"));
			dropReqFlWriter.setFilePath(AppConfig.config.getString("DROPREQ_LOG_FILEPATH"));
			dropReqFlWriter.initialize();
		}
		catch(Exception ex)
		{
			logger.error("Exception in configure of FileBasedLog "+ex.getMessage());
		}
	}

}
