package com.telemune.vcc.config;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class AppConfigParamRowMapper implements RowMapper<AppConfigParam> {
	public AppConfigParam mapRow(ResultSet rs, int rownumber)
			throws SQLException {
		AppConfigParam param = new AppConfigParam();
		param.setParamName(rs.getString("PARAM_NAME"));
		param.setParamValue(rs.getString("PARAM_VALUE"));
		return param;
	}
}