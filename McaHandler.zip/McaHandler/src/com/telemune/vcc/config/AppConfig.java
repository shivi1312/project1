package com.telemune.vcc.config;

import java.io.File;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.configuration.CombinedConfiguration;
import org.apache.commons.configuration.DefaultConfigurationBuilder;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.telemune.vcc.util.AppContext;

public class AppConfig {

	public static CombinedConfiguration config;
	static Logger logger = Logger.getLogger(AppConfig.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");


	private AppConfig() {

	}

	static {
		try {
			DefaultConfigurationBuilder builder = new DefaultConfigurationBuilder();
			builder.setFile(new File("properties/config.xml"));
			config = builder.getConfiguration(true);
			readDatabaseConfig(); // uncommented by Avishkar on 18/8/2020
		} catch (NullPointerException npe) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-MCA-")
							+ "90003] [Null Pointer Exception in reading config File] Error[ "
							+ npe.getMessage() + "]");
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-MCA-")
					+ "00001] [Exception in reading config File] Error[ "
					+ e.getMessage() + "]");
			e.printStackTrace();
		}
	}

	public static void readDatabaseConfig() {
		try {
			DataSource dataSource = (DataSource) AppContext.context
					.getBean("dataSource");
			String query = "SELECT * FROM APP_CONFIG_PARAMS";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			List<AppConfigParam> list = jdbcTemplate.query(query,
					new AppConfigParamRowMapper());

			for (AppConfigParam param : list)
				config.setProperty(param.getParamName(), param.getParamValue());
		} catch (Exception e) {
			errorLogger.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-MCA-")
					+ "00014] [Exception in reading App_Config_Params Table] Error[ "
					+ e.getMessage() + "]");
			e.printStackTrace();
		}
	}
}
