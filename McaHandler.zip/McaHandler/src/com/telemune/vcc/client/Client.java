package com.telemune.vcc.client;

public interface Client {
	public void connect() throws Exception;
	public void write(String value);
	public void close();
	public void closeSession();
}
