package com.telemune.vcc.client;

import java.net.InetSocketAddress;
import java.nio.charset.Charset;

import org.apache.log4j.Logger;
import org.apache.mina.core.RuntimeIoException;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
import org.apache.mina.filter.logging.LoggingFilter;
import org.apache.mina.transport.socket.nio.NioSocketConnector;

public class TcpClient implements Client {
	private final static Logger logger = Logger.getLogger(TcpClient.class);
	private NioSocketConnector connector = null;
	private TcpConfig tcpConfig = null;
	private IoSession session = null;
	
	public TcpClient() {

	}

	public TcpClient(TcpConfig tcpConfig) {
		this.tcpConfig = tcpConfig;
	}

	@Override
	public void connect() throws Exception {
		this.setConfiguration();
		logger.info("Host: " + this.tcpConfig.getHost() + " and port: " + this.tcpConfig.getPort());
		try {
			ConnectFuture future = connector.connect(new InetSocketAddress(
					this.tcpConfig.getHost(), this.tcpConfig.getPort()));
			future.awaitUninterruptibly();
			this.session = future.getSession();
		} catch (RuntimeIoException e) {
			logger.error(e.getMessage());
			logger.info("Server could not connect going to sleep: "
					+ this.tcpConfig.getRetrySleepTime());
			Thread.sleep(this.tcpConfig.getRetrySleepTime());
		}

		if (!this.connector.isActive()) {
			logger.info("Host: " + this.tcpConfig.getHost() + " and port: " + this.tcpConfig.getPort()
					+ " could not connect");
			this.connector.dispose();
		}
	}

	private void setConfiguration() {
		connector = new NioSocketConnector();
		logger.info("Connect timeout: " + this.tcpConfig.getConnectTimeout() + " codec: "
				+ this.tcpConfig.getCodec());
		connector.setConnectTimeoutMillis(this.tcpConfig.getConnectTimeout());
		connector.getFilterChain().addLast(
				"codec",
				new ProtocolCodecFilter(new TextLineCodecFactory(Charset
						.forName(this.tcpConfig.getCodec()))));
		connector.getFilterChain().addLast("logger", new LoggingFilter());
		connector.setHandler(new TcpClientHandler());
	}

	private synchronized void reconnect(String value) throws Exception {
		if(this.session == null || !this.session.isActive())
			this.connect();
		if (this.session != null && this.session.isActive()) {
			this.session.write(value);
		} else {
			return;
		}
	}

	@Override
	public void write(String value) {
		if (this.session != null && this.session.isActive()) {
			this.session.write(value);
		} else {
			try {
				if (this.session != null) {
					this.session.getCloseFuture().awaitUninterruptibly();
				}
				this.reconnect(value);
			} catch (Exception e) {
				logger.info("Excepton while reconnect: " + e.getMessage());
			}
		}
	}
	@Override
	public void close(){
		this.connector.dispose();
	}
	@Override
	public void closeSession(){
		if(this.session != null)
			this.session.closeOnFlush();
	}
}
