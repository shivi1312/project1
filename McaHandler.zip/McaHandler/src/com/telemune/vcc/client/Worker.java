package com.telemune.vcc.client;

public class Worker implements Runnable{
	private Client client = null;
	private String msg = null;
	public Worker(Client client, String msg){
		this.client = client;
		this.msg = msg;
	}
	@Override
	public void run(){
		try{
			client.write(msg);
		}catch(Exception e){
			System.out.println("Error: "+e.getMessage());
		}
	}
}
