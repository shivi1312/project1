package com.telemune.vcc.model;

import java.util.concurrent.ArrayBlockingQueue;

import com.telemune.vcc.config.AppConfig;


public class Global {
	
	public static ArrayBlockingQueue<RequestObject> requestQueue= new ArrayBlockingQueue<RequestObject>(AppConfig.config.getInt("QUEUE_SIZE"));
	
	public static int number_of_connection=-1;
}
