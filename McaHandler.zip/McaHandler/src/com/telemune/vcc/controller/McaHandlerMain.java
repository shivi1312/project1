package com.telemune.vcc.controller;

import java.net.Socket;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.missedcallalertsnotifycallerservice.www.ConnectionManager;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.model.Global;
import com.telemune.vcc.server.TcpServer;
import com.telemune.vcc.util_reqhandler.RejectedTaskHandler;
import com.telemune.vcc.util_reqhandler.SMSCHandler;
import com.telemune.vcc.util_reqhandler.SMSCRespSender;
import com.telemune.vcc.util_reqhandler.ThreadPoolExtrSeviceHandler;

public class McaHandlerMain {
	static final Logger logger = Logger.getLogger(McaHandlerMain.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");


	private static Thread thServcHandle;
	static Socket socket[] = new Socket[2];
	private static Thread thsmscHandle;
	private static Thread thsmscResp;

	public static void main(String[] args) {
		try {
			/*PropertyConfigurator.configure("properties/mcahandler_log.properties");*/
			PropertyConfigurator.configureAndWatch(
					"properties/mcahandler_log.properties", Long
							.parseLong(AppConfig.config.getString(
									"LOGGER_FILE_REFRESH_INTERVAL", "1000")));
			
			if (args[0].equalsIgnoreCase("-v")) { 
				
				
				String VERSION = "R3.0.1.1";
				System.out.println(
						"\n******************************************************************************************");
				System.out.println("\n              MCA Handler  Version [  " + VERSION + "  ]");
				System.out.println(
						"\n				Copyright @2004-2015Telemune Software Solutions Private Limited. All rights reserved");
				System.out.println("\n				Name of the Licensee : Telemune");
				System.out.println("\n				Licence ID: 08981Telemune98Client00909");
				System.out.println(
						"\n******************************************************************************************");
				System.out.println("\n");
				System.exit(1);
			}
		} catch (ArrayIndexOutOfBoundsException e) {
		}
		try {
			String VERSION = "R3.0.0.2";
			logger.info("******************************************************************************************");
			logger.info("   MCA Handler  [  " + VERSION + "  ] ");
			logger.info("	Copyright @2004-2015Telemune Software Solutions Private Limited. All rights reserved");
			logger.info("	Name of the Licensee : Telemune");
			logger.info("   Licence ID: 08981Telemune98Client00909");
			logger.info("******************************************************************************************");

			// int serverPort = AppConfig.config.getInt("PORT");
			logger.info("Server port is" + AppConfig.config.getInt("PORT"));
			// ServerReqAcceptor serverAccptr = new
			// ServerReqAcceptor(serverPort);
			// thAcceptor = new Thread(serverAccptr);
			// thAcceptor.start();

			new TcpServer("127.0.0.1", AppConfig.config.getInt("PORT")).start();

			int corePoolSize = AppConfig.config.getInt("CORE_POOL_SIZE");
			int maxPoolSize = AppConfig.config.getInt("MAX_POOL_SIZE");
			long aliveTime = AppConfig.config.getLong("ALIVE_TIME");
			int blockingQueueSize = AppConfig.config.getInt("BLOCKING_QUEUE_SIZE");
			logger.info("core pool size: " + corePoolSize + " max pool size: " + maxPoolSize + " alive time: "
					+ aliveTime + " blockingQueueSize: " + blockingQueueSize);
			
			//ThreadPoolExecutor thrdExecute = (ThreadPoolExecutor) Executors.newFixedThreadPool(maxPoolSize);
			
			ThreadPoolExecutor thrdExecute = new ThreadPoolExecutor(
					corePoolSize, maxPoolSize, aliveTime, TimeUnit.SECONDS,
					new ArrayBlockingQueue<Runnable>(blockingQueueSize),
					new RejectedTaskHandler());
			
			ThreadPoolExtrSeviceHandler serviceHandle = new ThreadPoolExtrSeviceHandler(thrdExecute);
			thServcHandle = new Thread(serviceHandle);
			thServcHandle.start();

			if(AppConfig.config.getInt("Config_Context_Flag_Enable",0)==1)
			{
				ConnectionManager.startMonitoring();
			}
			SMSCHandler smscHandler = null;
			SMSCRespSender smscRespSender = null;
			// int number_of_connection=-1;
			// boolean smsc_connected[]=null;
			if (Integer.parseInt(AppConfig.config.getString("SMSCENABLE", "0")) == 1) {

				logger.info("SMSC is enbale");
				Global.number_of_connection = Integer.parseInt(AppConfig.config.getString("NO_OF_SMSC_MT", "1"));

				for (int i = 0; i < Global.number_of_connection; i++) {
					try {
						logger.info("Socket ip [" + AppConfig.config.getString("mt.smsc.ip" + i, "10.168.3.63")
								+ "] port is [" + AppConfig.config.getInt("mt.smsc.port" + i));
						socket[i] = new Socket(AppConfig.config.getString("mt.smsc.ip" + i, "10.168.3.69"),
								Integer.parseInt(AppConfig.config.getString("mt.smsc.port" + i, "8080")));
						smscHandler = new SMSCHandler("threadCheckRequest" + socket[i].toString(), socket[i]);
						thsmscHandle = new Thread(smscHandler);
						thsmscHandle.start();

						smscRespSender = new SMSCRespSender(socket[i]);
						thsmscResp = new Thread(smscRespSender);
						thsmscResp.start();

					} catch (Exception e) {
						errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString("errorcode_pattern",
										"VCC-MCA-")
								+ "00012] [Exception while connecting to SMSC] Error[ "
								+ e.getMessage() + "]");
						//logger.error("Exception inside connect with socket" + e.getMessage());
						e.printStackTrace();

					}
				}

			}

			//while (true) {
				//logger.info("inside.....loop");
				try {
					if (Integer.parseInt(AppConfig.config.getString("SMSCENABLE", "0")) == 1) {
						for (int i = 0; i < Global.number_of_connection; i++) {

							while (!socket[i].isConnected() || socket[i].isInputShutdown()
									|| socket[i].isOutputShutdown() || !socket[i].isBound() || socket[i].isClosed()) {
								try {
									// logger.info("socket ip is"+i);
									socket[i] = new Socket(AppConfig.config.getString("mt.smsc.ip" + i, "10.168.3.69"),
											Integer.parseInt(AppConfig.config.getString("mt.smsc.port" + i, "8080")));
									logger.info("Socket connection is" + socket[i].toString());
								} catch (Exception ee) {
									errorLogger
									.error("ErrorCode ["
											+ AppConfig.config.getString("errorcode_pattern",
													"VCC-MCA-")
											+ "00010] [Exception while reconnecting to SMSC] Error[ "
											+ ee.getMessage() + "]");
									//logger.error("got SOCKET exception in thread  Process1" + ee.toString());
									// thrd.sleep(1000);

								}
							}
							try {
								if (!thsmscHandle.isAlive()) {
									smscHandler = new SMSCHandler("threadCheckRequest" + socket[i].toString(),
											socket[i]);
									thsmscHandle = new Thread(smscHandler);
									thsmscHandle.start();

								}
							} catch (Exception e) {
								errorLogger
								.error("ErrorCode ["
										+ AppConfig.config.getString("errorcode_pattern",
												"VCC-MCA-")
										+ "00011] [Exception while restarting SMSC handler thread] Error[ "
										+ e.getMessage() + "]");
								e.printStackTrace();
								logger.error("exception in smsc connection thread: " + e);
								//System.exit(1);
							}

							try {
								if (!thsmscResp.isAlive()) {

									smscRespSender = new SMSCRespSender(socket[i]);
									thsmscResp = new Thread(smscRespSender);
									thsmscResp.start();
								}
							} catch (Exception e) {
								errorLogger
								.error("ErrorCode ["
										+ AppConfig.config.getString("errorcode_pattern",
												"VCC-MCA-")
										+ "00013] [Exception while restarting SMSC ResponseSender Thread] Error[ "
										+ e.getMessage() + "]");
								e.printStackTrace();
								logger.error("exception in send message to smsc connection thread: " + e);
								//System.exit(1);
							}

						}

					}
				} catch (Exception ee) {
					logger.error("got SOCKET exception in thread  Process1" + ee.toString());
					ee.printStackTrace();
					// thsmscResp.sleep(10);
					// thsmscHandle.sleep(10);
					System.exit(1);
				}

				/*
				 * try { if (!thsmscResp.isAlive()) { smscRespSender=new
				 * SMSCRespSender(socket); thsmscResp = new
				 * Thread(smscRespSender); thsmscResp.start(); } } catch
				 * (Exception e) { e.printStackTrace(); logger.error(
				 * "exception in send message to smsc connection thread: " + e);
				 * System.exit(1); }
				 */

				/*
				 * try { if (!thsmscHandle.isAlive()) { smscHandler=new
				 * SMSCHandler("threadCheckRequest"+socket.toString(),socket);
				 * thsmscHandle = new Thread(smscHandler); thsmscHandle.start();
				 * } } catch (Exception e) { e.printStackTrace(); logger.error(
				 * "exception in smsc connection thread: " + e); System.exit(1);
				 * }
				 */

				try {
					if (!thServcHandle.isAlive()) {
						serviceHandle = new ThreadPoolExtrSeviceHandler(thrdExecute);
						thServcHandle = new Thread(serviceHandle);
						thServcHandle.start();
					}
				} catch (Exception e) {
					errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-MCA-")
							+ "00003] [Exception in request service handler Thread] Error[ "
							+ e.getMessage() + "]");
					e.printStackTrace();
					logger.error("exception in req service handler thread: " + e);
					System.exit(1);
				}
			//}

		} catch (Exception e) {
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-MCA-")
					+ "00004] [Exception While starting McaHandler] Error[ "
					+ e.getMessage() + "]");
			e.printStackTrace();
			e.printStackTrace();
		}
	}
}
