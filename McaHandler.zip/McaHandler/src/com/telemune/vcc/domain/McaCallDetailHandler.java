package com.telemune.vcc.domain;

import java.sql.ResultSet;
import java.sql.SQLException;



import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;


import com.telemune.vcc.model.RequestObject;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.model.*;
import com.telemune.vcc.util.AppContext;

public class McaCallDetailHandler {
	
	final static Logger logger = Logger.getLogger(McaCallDetailHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	private DataSource dataSource;
	RequestObject dataObject = null;

	public McaCallDetailHandler() {
		
		}
	public McaCallDetailHandler(RequestObject dataObject)
	{
		this.dataSource = (DataSource) AppContext.context.getBean("dataSource");
	this.dataObject=dataObject;	
	}

	public McaCallDetailModel getMcaDetail()
	{
		try
		{
			McaCallDetailModel mcaCallDetailModel=null;
		logger.info("origination number=[" + dataObject.getaParty()
		+ "]  destination number is [" + dataObject.getbParty() + "]");
	
//			String query = "SELECT ORIGINATION_NUMBER,ROWID FROM MCA_CALL_DETAIL where DESTINATION_NUMBER=?";
			String query = "SELECT ORIGINATION_NUMBER FROM MCA_CALL_DETAIL where DESTINATION_NUMBER=?"; // modified by Avishkar on 17/8/2020
			logger.debug(String.format("[%s] before query [%s]",
					dataObject.getbParty(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			mcaCallDetailModel =  jdbcTemplate.query(
					query,
					new Object[] { dataObject.getbParty()},new ResultSetExtractor<McaCallDetailModel>() {
						@Override
						public McaCallDetailModel extractData(
								ResultSet rs) throws SQLException,
								DataAccessException {
							if (rs.next()) {
								McaCallDetailModel mcaCalldetail=new McaCallDetailModel();
								mcaCalldetail.setOriginationNumber(rs.getString("ORIGINATION_NUMBER"));
//								mcaCalldetail.setRowId(rs.getString("ROWID")); // commented by Avishkar on 17/8/2020
								return mcaCalldetail;
							}
							return null;
						}
					});
					
				
			logger.debug(String.format("[%s] after query [%s]",
					dataObject.getbParty(), query));
			
			return mcaCallDetailModel;
		} catch (Exception e) {
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString(
							"errorcode_pattern", "VCC-MCA-")
					+ "00019] [Exception while getting data from MCA_CALL_DETAIL table] AParty["
					+ dataObject.getaParty() + "] BParty["
					+ dataObject.getbParty() + "] Error[ "
					+ e.getMessage() + "]");
			/*logger.error(String.format(
					"msisdn [%s]  exception: [%s]",
					dataObject.getbParty(), e));*/
			return null;
		}
	}
	
	public int updateMcaCallDetail(McaCallDetailModel mcaCallDetail) {
		try {
			int result=0;
			String query="";
			int serviceType=1;
		// modification start by Avishkar on 17/8/2020	
			/*if(dataObject.getServiceType().equalsIgnoreCase("0010"))
			{
				serviceType=1;
			}
			else
				if(dataObject.getServiceType().equalsIgnoreCase("0100"))
				{
					
					serviceType=2;
				}*/
			
			if(dataObject.getServiceType().equalsIgnoreCase("0001"))
			{
				serviceType=1;
			}
			else if (dataObject.getServiceType().equalsIgnoreCase("0010")) 
			{
				serviceType=2;
			}
			else			
				if(dataObject.getServiceType().equalsIgnoreCase("0100"))
				{
					
					serviceType=4;
				}
		// modification end by Avishkar on 17/8/2020	
			
			if(mcaCallDetail!=null)
			{
				try
				{	
					if(AppConfig.config.getInt("DB_CON_PARAM",0)==0)
						{
//					query="UPDATE MCA_CALL_DETAIL set CALL_COUNTER=CALL_COUNTER+1,CALL_TIME=to_date(?,'DD-MM-YYYY HH24:MI:SS'), SERVICE_TYPE=? WHERE ROWID=?";
					query="UPDATE MCA_CALL_DETAIL set CALL_COUNTER=CALL_COUNTER+1,CALL_TIME=to_date(?,'DD-MM-YYYY HH24:MI:SS'), SERVICE_TYPE=? WHERE ORIGINATION_NUMBER=? AND DESTINATION_NUMBER=?"; // modified by Avishkar on 17/8/2020
						}
					else if(AppConfig.config.getInt("DB_CON_PARAM",0)==1)
					{
//						query="UPDATE MCA_CALL_DETAIL set CALL_COUNTER=CALL_COUNTER+1,CALL_TIME=date_format(?,'%d-%m-%Y %h:%i:%s'), SERVICE_TYPE=? WHERE ROWID=?";
						query="UPDATE MCA_CALL_DETAIL set CALL_COUNTER=CALL_COUNTER+1,CALL_TIME=date_format(?,'%Y-%m-%d %h:%i:%s'), SERVICE_TYPE=? WHERE ORIGINATION_NUMBER=? AND DESTINATION_NUMBER=?"; // modified by Avishkar on 17/8/2020
					}
					
					logger.info(String.format(
						"Origination number [%s] destination number [%s] service type [%s] before query [%s]",dataObject.getaParty(),dataObject.getbParty(),dataObject.getServiceType(),
						query));
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			// modification start by Avishkar on 17/8/2020
				 /*result = jdbcTemplate.update(
						query,
						new Object[] {dataObject.getCallTime(),serviceType,mcaCallDetail.getRowId()});*/
				 result = jdbcTemplate.update(
							query,
							new Object[] {dataObject.getCallTime(),serviceType,dataObject.getaParty(),dataObject.getbParty()});
			// modification end by Avishkar on 17/8/2020
				logger.debug(String.format(
						"Origination number [%s] destination number [%s] service type [%s] after query [%s]",
						dataObject.getaParty(),dataObject.getbParty(),serviceType, query));
				return result;
				}
				catch(Exception e)
				{
					errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString(
									"errorcode_pattern", "VCC-MCA-")
							+ "00020] [Exception while updating data in MCA_CALL_DETAIL table] AParty["
							+ dataObject.getaParty() + "] BParty["
							+ dataObject.getbParty() + "] Error[ "
							+ e.getMessage() + "]");
					
					/*logger.error("Exception inside update mca_call_detail table"+e.getMessage());*/
					e.printStackTrace();
					return 0;
				}
			}
			else
			{
				try
				{
					if(Integer.parseInt(AppConfig.config.getString("DB_CON_PARAM","0"))==0)
					{
						 query = "INSERT INTO MCA_CALL_DETAIL (ORIGINATION_NUMBER,DESTINATION_NUMBER,CALL_COUNTER,CALL_TIME,REQ_ID,SERVICE_TYPE,LANGUAGE_ID) VALUES(?,?,?,to_date(?,'DD-MM-YYYY HH24:MI:SS'),mca_reqid_seq.nextval,?,?)";
				
					}
					else if(Integer.parseInt(AppConfig.config.getString("DB_CON_PARAM","1"))==1)
					{
//						 query = "INSERT INTO MCA_CALL_DETAIL (ORIGINATION_NUMBER,DESTINATION_NUMBER,CALL_COUNTER,CALL_TIME,SERVICE_TYPE,LANGUAGE_ID) VALUES(?,?,?,?,date_format(?,'%d-%m-%Y %h:%i:%s'),?,?)";
						 query = "INSERT INTO MCA_CALL_DETAIL (ORIGINATION_NUMBER,DESTINATION_NUMBER,CALL_COUNTER,CALL_TIME,SERVICE_TYPE,LANGUAGE_ID) VALUES(?,?,?,date_format(?,'%Y-%m-%d %h:%i:%s'),?,?)"; // modified by Avishkar on 17/8/2020
 
					}
					logger.info(String.format(
						"Origination number [%s] destination number [%s] service type [%s] calltime [%s] before query [%s]",
						dataObject.getaParty(),dataObject.getbParty(),serviceType,dataObject.getCallTime(), query));
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				result = jdbcTemplate.update(query, new Object[] {dataObject.getaParty(),dataObject.getbParty()
						,1,dataObject.getCallTime(),serviceType,dataObject.getLang() });
				logger.debug(String.format(
						"origination number [%s] destination number [%s] service type [%s] after query [%s]",
						dataObject.getaParty(),dataObject.getbParty(),serviceType, query));
				return result;
				}
				catch(Exception e)
				{
					errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString(
									"errorcode_pattern", "VCC-MCA-")
							+ "00021] [Exception while inserting data in MCA_CALL_DETAIL table] AParty["
							+ dataObject.getaParty() + "] BParty["
							+ dataObject.getbParty() + "] Error[ "
							+ e.getMessage() + "]");
					
/*					logger.error("Exception inside insert into mca_call_detail table"+e.getMessage());
*/					e.printStackTrace();
					return 0;
				}
				}
				
			} 
			catch (org.springframework.dao.DuplicateKeyException dup) {
			return 0;
		} catch (Exception e) {
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString(
							"errorcode_pattern", "VCC-MCA-")
					+ "00022] [Exception while saving User data] AParty["
					+ dataObject.getaParty() + "] BParty["
					+ dataObject.getbParty() + "] Error[ "
					+ e.getMessage() + "]");
			logger.info(String.format(
					"[%s] [%s] [%s] Exception: while save user data [%s]",
					dataObject.getaParty(),dataObject.getbParty(),dataObject.getServiceType(),
				 e));
			return 0;
		}
	}
	
	
	
	public int insertIntoGmat()
	{
		String query="";
		int result=-1;
		String GMAT_MSG_TABLE_NAME=AppConfig.config.getString("GMAT_MSG_TABLE_NAME"); // added by Avishkar on 17/8/2020
		String senderId=""; // added by Avishkar on 18/8/2020
		try
		{
		// addition start by Avishkar on 18/8/2020
	        int mcacallPartyEnable = Integer.parseInt(AppConfig.config.getString("MCA_SMS_SENDER_CPN"));
	        if (mcacallPartyEnable==0) {
				senderId = AppConfig.config.getString("MCA_SMS_NUMBER");
			}else {
				senderId = dataObject.getaParty();
			}
		// addition end by Avishkar on 18/8/2020
			
			if(Integer.parseInt(AppConfig.config.getString("DB_CON_PARAM","0"))==0)
			{
//				query = "INSERT INTO GMAT_MESSAGE_STORE_2 (REQUEST_ID, RESPONSE_ID,ORIGINATING_NUMBER, DESTINATION_NUMBER,MESSAGE_TEXT, SUBMIT_TIME, STATUS,DELIVERY_RECEIPT,PROTOCOL_IDENTIFIER) VALUES(GMAT_RESPONSE_ID_SEQ.NEXTVAL, 0,?,?,'Test Message',sysdate,'R',1,64)";
				query = "INSERT INTO "+GMAT_MSG_TABLE_NAME+" (REQUEST_ID, RESPONSE_ID,ORIGINATING_NUMBER, DESTINATION_NUMBER,MESSAGE_TEXT, SUBMIT_TIME, STATUS,STATUS_REPORT,PROTOCOL_IDENTIFIER) VALUES(GMAT_RESPONSE_ID_SEQ.NEXTVAL, 0,?,?,'Test Message',sysdate,'R',1,64)"; // modified by Avishkar on 17/8/2020
			}
			else if(Integer.parseInt(AppConfig.config.getString("DB_CON_PARAM","1"))==1)
			{
//				query = "INSERT INTO GMAT_MESSAGE_STORE_2 (RESPONSE_ID,ORIGINATING_NUMBER, DESTINATION_NUMBER,MESSAGE_TEXT, SUBMIT_TIME, STATUS,DELIVERY_RECEIPT,PROTOCOL_IDENTIFIER) VALUES(0,?,?,'Test Message',now(),'R',1,64)";
				query = "INSERT INTO "+GMAT_MSG_TABLE_NAME+" (RESPONSE_ID,ORIGINATING_NUMBER, DESTINATION_NUMBER,MESSAGE_TEXT, SUBMIT_TIME, STATUS,STATUS_REPORT,PROTOCOL_IDENTIFIER) VALUES(0,?,?,'Test Message',now(),'R',1,64)"; // modified by Avishkar on 17/8/2020

			}
			logger.info(String.format(
					"Origination number [%s] destination number [%s] before query [%s]",
					dataObject.getaParty(),dataObject.getbParty(), query));
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
//			result = jdbcTemplate.update(query, new Object[] {dataObject.getaParty(),dataObject.getbParty()}); // commented by Avishkar on 18/8/2020
			result = jdbcTemplate.update(query, new Object[] {senderId,dataObject.getbParty()}); // modified by Avishkar on 18/8/2020
			logger.debug(String.format(
					"origination number [%s] destination number [%s] after query [%s]",
					dataObject.getaParty(),dataObject.getbParty(), query));
			return result;
		}
		catch(Exception e)
		{
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString(
							"errorcode_pattern", "VCC-MCA-")
					+ "00018] [Exception while Inserting into GMAT_MESSAGE_STORE table] AParty["
					+ dataObject.getaParty() + "] BParty["
					+ dataObject.getbParty() + "] Error[ "
					+ e.getMessage() + "]");
			/*logger.error("Exception inside insert into gmat-Message_store table"+e.getMessage());*/
			e.printStackTrace();
			return 0;
		}
		
	}

	
}
