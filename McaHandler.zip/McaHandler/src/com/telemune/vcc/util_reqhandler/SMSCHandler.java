package com.telemune.vcc.util_reqhandler;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

import org.apache.log4j.Logger;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.model.Global;

public class SMSCHandler implements Runnable {

	static Logger logger = Logger.getLogger(SMSCHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");

	int handleId;
	String name;
	Socket socket_me;
	Thread thrd;
	DataInputStream reader = null;

	public SMSCHandler(String name, Socket socket) {
		thrd = new Thread(this, name);
		this.name = name;
		this.socket_me = socket;
	}

	public void setHandleId(int handleId) {
		this.handleId = handleId;
	}

	public void run() {
		getfromclient(name, socket_me);
	}

	public void stop() {

	}

	public void getfromclient(String name, Socket socket_me) {
		/*
		 * for(int i=0;i<Global.number_of_connection;i++) {
		 */
		try {

			reader = new DataInputStream(socket_me.getInputStream());
		} catch(IOException e){
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString("errorcode_pattern",
							"VCC-MCA-")
					+ "90002] [IOException in getting Input Stream] Error[ "
					+ e.getMessage() + "]");
		}catch (Exception E1) {			
			E1.printStackTrace();
		}
		logger.info("\nPreparing to recv  data thread# " + name);
		try {
			while (true) {

				if (socket_me.isClosed()) {
					logger.debug("Socket closed");
					thrd.stop();

					return;
				} else {
					ByteArrayInputStream inbuf = null;

					byte dataBuf1[] = new byte[4];
					int dataLen = 0;
					try {

						logger.debug("reading Info ......starts.");
						if (reader.read(dataBuf1, 0, 4) == -1) {
							logger.warn("reader.read == -1 ...");
							try {
								socket_me.close();

								logger.warn("Destroy");
								logger.warn("socket closed");
								thrd.stop();
								return;
							} catch (Exception e) {
								e.printStackTrace();
							}

						}
						logger.debug("reading Info ......end.");
						int test = 0;
						dataLen = dataLen | (dataBuf1[0] << 24);
						dataLen = dataLen | (dataBuf1[1] << 16);
						dataLen = dataLen | (dataBuf1[2] << 8);
						test = (0x000000ff & dataBuf1[3]);
						dataLen = dataLen | test;
						logger.info("reading Info ......data len.." + dataLen);
					} catch (Exception e) {
						errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString("errorcode_pattern",
										"VCC-MCA-")
								+ "00017] [Exception in reading request Data] Error[ "
								+ e.getMessage() + "]");
						e.printStackTrace();
						try {
							thrd.sleep(1);
							socket_me.close();

						} catch (Exception eee) {
							logger.fatal("Sleep Exception in main");
						}
					}
					if (dataLen == 0) {
						try {
							logger.info("Sleeping.....n");
							continue;// thrd.sleep(10);
						} catch (Exception eee) {
							logger.info("Sleep Exception in main");
						}
					}
					logger.info("recieved tcp_req size=" + dataLen);

				}

			}
		}

		catch (Exception e) {
			System.out.println("got exception ......" + e.toString());
			e.printStackTrace();

		}
	}

	// }

}
