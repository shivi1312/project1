package com.telemune.vcc.util_reqhandler;

import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import com.telemune.vcc.config.AppConfig;

public class RejectedTaskHandler implements RejectedExecutionHandler{
	
	private final Logger logger=Logger.getLogger(RejectedTaskHandler.class);
	private final Logger errorLogger=Logger.getLogger("errorLogger");
	@Override
	public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
		
		 logger.warn("TASK IS REJECTED BECOZ ,MAX THREAD IS OPEN  and WORKING QUEUE IS ALREDY FULL ," +
		 		" SO WAIT FOR 1 SECOND  and AGAIN TRY TO EXECUTE : (To avoid this problem increase  Working queue size)"+ Thread.currentThread().getName());
	       try {
	           Thread.sleep(AppConfig.config.getInt("REJECTION_SLEEP_TIME",1000));
	       } catch (InterruptedException e) {
	           e.printStackTrace();
	       }
	       logger.debug("Lets Try another time : "+Thread.currentThread().getName());
	          try{
	              executor.execute(r);
	          }
	          catch(RejectedExecutionException re){
	          errorLogger.error("Problem In  Submitting task because Its too late processing, Please check your Processing time of Server(Good Option) or increase thread pool queue size(Bad Option) ",re);
	          }
	}

}
