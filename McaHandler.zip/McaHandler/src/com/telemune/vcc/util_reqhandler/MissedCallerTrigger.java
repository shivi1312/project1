package com.telemune.vcc.util_reqhandler;

import java.math.BigInteger;
import java.util.Date;

import org.apache.log4j.Logger;

import FileBaseLogging.FileLogWriter;

import com.google.gson.Gson;
import com.missedcallalertsnotifycallerservice.www.MCANotifyCallerServiceStub;
import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.model.RequestObject;

public class MissedCallerTrigger implements Runnable {

	final static Logger logger = Logger.getLogger(MissedCallerTrigger.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	final static Logger urlErrorLogger = Logger.getLogger("urlErrorLogger");
	final static FileLogWriter fileWriter = new FileLogWriter();
	RequestObject dataObject = null;
	int urlTry = 0;
	private Gson gson = new Gson();

	public MissedCallerTrigger(RequestObject dataObject) {
		this.dataObject = dataObject;
	}

	@Override
	public void run() {
		String response = null;
		String url = null;
		if (AppConfig.config.getInt("mca_notification_enable", 1) == 1) {

			url = this.getNotifyUrl();
			response = this.sendMcaTrigger(url);
			logger.info("aprty [" + this.dataObject.getaParty() + "] bParty ["
					+ this.dataObject.getbParty() + "]   serviceType ["
					+ this.dataObject.getServiceType() + "] reasoncode ["
					+ this.dataObject.getReasonCode() + "] ");
			logger.info("[" + this.dataObject.getaParty()
					+ "] call trigger to [" + this.dataObject.getaParty()
					+ "] response is [" + response + "]");
		} else {
			logger.info("aprty [" + this.dataObject.getaParty() + "] bParty ["
					+ this.dataObject.getbParty() + "]   serviceType ["
					+ this.dataObject.getServiceType() + "] reasoncode ["
					+ this.dataObject.getReasonCode()
					+ "] mca notification enable status ["
					+ AppConfig.config.getInt("mca_notification_enable", 1)
					+ "]");

		}

	}

	// private String sendMcaTrigger() {
	private String sendMcaTrigger(String url) {

		String response = null;
		Byte nai = 4;
		Byte npi = 1;
		String reasonCode = "6";
		String serviceType = "1";
		String serviceKey = "0";
		this.urlTry++;
		// logger.info("Inside send mca Trigger === Hitting url["+url+"] ==== urlTry ["+urlTry+"]");
		if (this.dataObject.getReasonCode().equalsIgnoreCase("user-busy")) {
			reasonCode = AppConfig.config.getString("reason.code.busy", "1");
		} else if (this.dataObject.getReasonCode()
				.equalsIgnoreCase("no-answer")) {
			reasonCode = AppConfig.config
					.getString("reason.code.noanswer", "2");
		} else if (this.dataObject.getReasonCode().equalsIgnoreCase(
				"unconditional")) {
			reasonCode = AppConfig.config.getString("reason.code.un", "4");
		} else if (this.dataObject.getReasonCode().equalsIgnoreCase(
				"unavailable")) {
			reasonCode = AppConfig.config.getString("reason.code.sw", "6");
		} else if (this.dataObject.getReasonCode().equalsIgnoreCase("unknown")) {
			reasonCode = AppConfig.config.getString("reason.code.sw", "6");
		} else {
			reasonCode = AppConfig.config.getString("reason.code.un", "4");
		}

		serviceType = this.dataObject.getType();
		serviceKey = AppConfig.config.getString("service.key", "1");
		MCANotifyCallerServiceStub stub = null;
		try {

			stub = new MCANotifyCallerServiceStub(url);
			MCANotifyCallerServiceStub.CallTriggerRequest callTriggerRequest = new MCANotifyCallerServiceStub.CallTriggerRequest();
			logger.info("aParty[" + this.dataObject.getaParty() + "] bParty["
					+ this.dataObject.getbParty()
					+ "] Mobileum url for call triggr:[" + url + "]");

			MCANotifyCallerServiceStub.ISDNAddress aPartyISDNAddressBean = new MCANotifyCallerServiceStub.ISDNAddress();
			aPartyISDNAddressBean.setDigits(this.dataObject.getaParty());
			aPartyISDNAddressBean.setNAI(aPartyISDNAddressBean.getNAI());
			aPartyISDNAddressBean.setNPI(aPartyISDNAddressBean.getNPI());

			MCANotifyCallerServiceStub.ISDNAddress bPartyISDNAddressBean = new MCANotifyCallerServiceStub.ISDNAddress();
			bPartyISDNAddressBean.setDigits(this.dataObject.getbParty());
			bPartyISDNAddressBean.setNAI(bPartyISDNAddressBean.getNAI());
			bPartyISDNAddressBean.setNPI(bPartyISDNAddressBean.getNPI());

			MCANotifyCallerServiceStub.ISDNAddress ocnISDNAddressBean = new MCANotifyCallerServiceStub.ISDNAddress();
			ocnISDNAddressBean.setDigits(this.dataObject.getbParty());
			ocnISDNAddressBean.setNAI(ocnISDNAddressBean.getNAI());
			ocnISDNAddressBean.setNPI(ocnISDNAddressBean.getNPI());

			MCANotifyCallerServiceStub.ISDNAddress rdnISDNAddressBean = new MCANotifyCallerServiceStub.ISDNAddress();
			rdnISDNAddressBean.setDigits(this.dataObject.getbParty());
			rdnISDNAddressBean.setNAI(rdnISDNAddressBean.getNAI());
			rdnISDNAddressBean.setNPI(rdnISDNAddressBean.getNPI());

			callTriggerRequest.setAParty(aPartyISDNAddressBean);
			callTriggerRequest.setBParty(bPartyISDNAddressBean);
			callTriggerRequest.setOCN(ocnISDNAddressBean);
			callTriggerRequest.setRDN(rdnISDNAddressBean);

			java.math.BigInteger localReasonCode = org.apache.axis2.databinding.utils.ConverterUtil
					.convertToInteger(reasonCode);

			if (serviceType.equals("1"))
				callTriggerRequest
						.setServiceType(MCANotifyCallerServiceStub.ServiceType_type1.value1);
			else
				callTriggerRequest
						.setServiceType(MCANotifyCallerServiceStub.ServiceType_type1.value2);

			// reason code set

			this.dataObject.setReasonCode(reasonCode);
			this.dataObject.setServiceType(serviceType);
			this.dataObject.setServiceKey(serviceKey);

			callTriggerRequest.setServiceKey(new BigInteger(this.dataObject
					.getServiceKey()));
			callTriggerRequest.setReasonCode(localReasonCode);

			Date sendTime = new Date();
			try {
				logger.info("Call trigger request send and param are ["
						+ gson.toJson(callTriggerRequest) + "] sending Time["
						+ sendTime + "]");

				MCANotifyCallerServiceStub.CallTriggerResponse callTriggerResponseBean = stub
						.callTrigger(callTriggerRequest);

				response = callTriggerResponseBean.getResponseMessage();
				Date rcvTime = new Date();
				logger.info("Response: ["
						+ gson.toJson(callTriggerResponseBean) + "] A-Party ["
						+ this.dataObject.getaParty() + "] B-Party ["
						+ this.dataObject.getbParty() + "] Time difference["
						+ (rcvTime.getTime() - sendTime.getTime()) + "]");

			} catch (Exception e) {

				if (AppConfig.config.getInt("notify_multiple_url_enable", 0) == 1) {
					if (this.urlTry <= 1) {
						if (e.getCause() instanceof java.net.ConnectException
								|| e.getCause() instanceof java.net.SocketTimeoutException
								|| e.getCause() instanceof org.apache.commons.httpclient.ConnectTimeoutException
								|| e.getCause() instanceof org.apache.axis2.AxisFault) {
							if (url.equals(AppConfig.config
									.getString("notify_alert_url_even",
											"https://10.183.126.130:8445/mca_service/services/NotifyCallerPort"))) {
								logger.error("[Exception while sending call trigger request to Mobileum] bParty["
										+ dataObject.getbParty()
										+ "] Attempt["
										+ urlTry
										+ "]. Now going to hit url["
										+ AppConfig.config
												.getString(
														"notify_alert_url_even_alternate",
														"https://10.183.126.132:8445/mca_service/services/NotifyCallerPort")
										+ "] Error[" + e.getMessage() + "]");
								sendMcaTrigger(AppConfig.config
										.getString("notify_alert_url_even_alternate",
												"https://10.183.126.132:8445/mca_service/services/NotifyCallerPort"));
							} else {
								logger.error("[Exception while sending call trigger request to Mobileum] bParty["
										+ dataObject.getbParty()
										+ "] Attempt["
										+ urlTry
										+ "]. Now going to hit url["
										+ AppConfig.config
												.getString(
														"notify_alert_url_odd_alternate",
														"https://10.183.126.133:8445/mca_service/services/NotifyCallerPort")
										+ "] Error[" + e.getMessage() + "]");
								sendMcaTrigger(AppConfig.config
										.getString("notify_alert_url_odd_alternate",
												"https://10.183.126.133:8445/mca_service/services/NotifyCallerPort"));
							}
						} else {
							errorLogger
									.error("[Exception while sending request to Mobileum.[ "
											+ this.dataObject.toString()
											+ " ] Error["
											+ e.getMessage()
											+ "]");
						}
					} else {
						urlErrorLogger
								.error("[Exception occured.All Attempts Failed to call Mobileum.]"
										+ this.dataObject.toString()
										+ " url["
										+ url
										+ "] Error["
										+ e.getMessage()
										+ "]");
					}
				} else {
					Date rcvTime = new Date();
					urlErrorLogger
							.error("[Exception while sending call trigger request to Mobileum] "
									+ this.dataObject.toString()
									+ " Url["
									+ url
									+ "] Time difference ["
									+ (rcvTime.getTime() - sendTime.getTime())
									+ "] Error[" + e.getMessage() + "]");
				}
			}

		} catch (Exception e) {
			errorLogger
					.error("ErrorCode ["
							+ AppConfig.config.getString("errorcode_pattern",
									"VCC-MCA-")
							+ "00005] [Exception while sending call trigger request to Mobileum] AParty["
							+ this.dataObject.getaParty() + "] BParty["
							+ this.dataObject.getbParty() + "] Error[ "
							+ e.getMessage() + "]");
		} finally {
		}
		return response;

	}

	public String getNotifyUrl() {
		String url = "";
		if (AppConfig.config.getInt("notify_multiple_url_enable", 0) == 1) {
			if (Integer.parseInt(dataObject.getbParty().substring(
					dataObject.getbParty().length() - 1)) % 2 == 0) {
				url = AppConfig.config
						.getString("notify_alert_url_even",
								"https://10.183.126.130:8445/mca_service/services/NotifyCallerPort");
				logger.info("Returning even url[" + url + "] aParty["
						+ this.dataObject.getaParty() + "] bParty["
						+ this.dataObject.getbParty() + "]");
			} else {

				url = AppConfig.config
						.getString("notify_alert_url_odd",
								"https://10.183.126.131:8445/mca_service/services/NotifyCallerPort");
				logger.info("Returning odd url [" + url + "] aParty["
						+ this.dataObject.getaParty() + "] bParty["
						+ this.dataObject.getbParty() + "]");
			}
		} else {
			url = AppConfig.config
					.getString("notify_alert_url",
							"https://10.183.126.130:8445/mca_service/services/NotifyCallerPort");
			logger.info("Returning default url [" + url + "] aParty["
					+ this.dataObject.getaParty() + "] bParty["
					+ this.dataObject.getbParty() + "]");
		}
		return url;
	}
}
