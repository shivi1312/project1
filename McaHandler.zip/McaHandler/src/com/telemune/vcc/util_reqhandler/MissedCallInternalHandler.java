package com.telemune.vcc.util_reqhandler;


import java.util.concurrent.ArrayBlockingQueue;

import org.apache.log4j.Logger;

import com.telemune.vcc.config.AppConfig;
import com.telemune.vcc.domain.McaCallDetailHandler;

import com.telemune.vcc.model.McaCallDetailModel;
import com.telemune.vcc.model.RequestObject;

public class MissedCallInternalHandler  implements Runnable {
	final static Logger logger = Logger.getLogger(MissedCallInternalHandler.class);
	final static Logger errorLogger = Logger.getLogger("errorLogger");
	McaCallDetailModel mcaCallModel=null;
	
	public McaCallDetailHandler mcaCallDetail=null;
	RequestObject dataObject = null;
	public static ArrayBlockingQueue<MessageParam> SMSCQueuePool =new ArrayBlockingQueue<MessageParam>(100000);
	public SMSCHandler smscHandler=null;
	MessageParam msgParam=null;
	
	public MissedCallInternalHandler(RequestObject dataObject) {
		this.dataObject = dataObject;
	}
	
	@Override
	public void run() {
		int result=-1;
		boolean send_mca_alert=true;
		boolean save_mca_call=true;
		boolean send_alert=true;
		
		

		if(!dataObject.getReasonCode().equalsIgnoreCase("") && Integer.parseInt(AppConfig.config.getString("MCA_ACTIVATED"))==1)
		{
			if(dataObject.getReasonCode().equalsIgnoreCase("user-busy") && Integer.parseInt(AppConfig.config.getString("USER_BUSY_ACTIVATED"))==0)
				send_mca_alert=false;
			else if(dataObject.getReasonCode().equalsIgnoreCase("no-answer") && Integer.parseInt(AppConfig.config.getString("NOREPLY_ACTIVATED"))==0)
				send_mca_alert=false;
			if(send_mca_alert)
			{
				if(save_mca_call)
				{
					if(Integer.parseInt(AppConfig.config.getString("SMSCENABLE","0"))==1)
					{
						logger.info("calling processMcaHit() for Origination number ["+dataObject.getaParty()+"]");
						result=this.processMcaHit();
						if(result==1)
						{
							send_alert=true;
						}
						else
						{
							send_alert=false;
						}
						logger.info("Getting result ["+result+"] from processMcaHit() when SMSC is enable for Origination number ["+dataObject.getaParty()+"]");
						
					}
					else
					{
						send_alert=false;
						result=this.processMcaHit();
						logger.info("Inside condition when smsc is not enable for msisdn ["+dataObject.getaParty()+"] and get status from processMcaHit() ["+result+"]");
					}
				
			}
				if(send_alert && Integer.parseInt(AppConfig.config.getString("MCA_SEND_ALERTS","0"))==1)
				{
					try
					{
					logger.info("Size of message queue is"+SMSCQueuePool.size());
					msgParam=new MessageParam();
					msgParam.setReq_type(RequestTag.ALERT_SC);
					msgParam.setMsisdn(dataObject.getbParty());
					SMSCQueuePool.put(msgParam);
					}
					catch(Exception e)
					{
						errorLogger
						.error("ErrorCode ["
								+ AppConfig.config.getString(
										"errorcode_pattern", "VCC-MCA-")
								+ "00015] [Exception while inserting alert into Queue] AParty["
								+ this.dataObject.getaParty() + "] BParty["
								+ this.dataObject.getbParty() + "] Error[ "
								+ e.getMessage() + "]");
						logger.error("Exception inside inserting alert into queue"+e.getMessage());
						e.printStackTrace();
					}
				}
				if(Integer.parseInt(AppConfig.config.getString("SMSCENABLE","0"))!=1 && result==1)
					{
						mcaCallDetail=new McaCallDetailHandler(dataObject);
						int status=mcaCallDetail.insertIntoGmat();
						if(status>0)
						{
							logger.info("Message inserted succesfully into gmat_message_store");
						}
					}
				}
			else
			{
				logger.info("Deactivated service call UserBusyActivated and no reply activated");
			}
			
			
		}
		else
		{
			logger.info("call is not forwarding");
		}
	
	}
	
	
	private int processMcaHit()
	{
		
		int result=0;
		int status=-1;
		
		mcaCallModel=new McaCallDetailModel();
		mcaCallDetail=new McaCallDetailHandler(dataObject);
		try
		{
			mcaCallModel=mcaCallDetail.getMcaDetail();
			
			
			if(mcaCallModel!=null)
			{
				logger.info("Inside condition when data exist into data base for ["+dataObject.getaParty()+"]");
				if(dataObject.getaParty().equalsIgnoreCase(mcaCallModel.getOriginationNumber()))
				{
					logger.info("Origination number ["+dataObject.getaParty()+"] already exist into mca_call_detail");
					result=mcaCallDetail.updateMcaCallDetail(mcaCallModel);
					status=0;
				}
				else
				{
					logger.info("Origination number ["+dataObject.getaParty()+"] not found into mca_call_detail table");
					result=mcaCallDetail.updateMcaCallDetail(mcaCallModel);
					status=1;
				}
			}
			else
			{
				logger.info("Origination number ["+dataObject.getaParty()+"] not found into mca_call_detail table");
				result=mcaCallDetail.updateMcaCallDetail(mcaCallModel);
				status=1;
			}
				if(result>0)
				{
					logger.info("Record update successfully into mca_call_detail table for origination numer ["+dataObject.getaParty()+"] and destination number ["+dataObject.getbParty()+"]");
				
				}
					else
					{
					logger.info("There is any error in update record into mca_call_detail table");
					status=-1;
					}
			}
			
		catch(Exception e)
		{
			errorLogger
			.error("ErrorCode ["
					+ AppConfig.config.getString(
							"errorcode_pattern", "VCC-MCA-")
					+ "00016] [Exception while processing MCA Hit] AParty["
					+ this.dataObject.getaParty() + "] BParty["
					+ this.dataObject.getbParty() + "] Error[ "
					+ e.getMessage() + "]");
			logger.error("Exception inside processMcaHit()"+e.getMessage());
			e.printStackTrace();
			status=-1;
		}
		return status;
	}

}
