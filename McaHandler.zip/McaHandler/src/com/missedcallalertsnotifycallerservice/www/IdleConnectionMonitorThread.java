package com.missedcallalertsnotifycallerservice.www;

import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.log4j.Logger;

import com.telemune.vcc.config.AppConfig;

public class IdleConnectionMonitorThread extends Thread {
	private static Logger logger = Logger
			.getLogger(IdleConnectionMonitorThread.class);
	private final MultiThreadedHttpConnectionManager connMgr;

	public IdleConnectionMonitorThread(
			MultiThreadedHttpConnectionManager connMgr) {
		super();
		this.connMgr = connMgr;
	}

	@Override
	public void run() {
		logger.info("Idle Monitor Thread Started. Conn_Max_Idle_Time["
				+ AppConfig.config.getInt("Connection_Max_Idle_Time", 120000)
				+ "]");
		while (true) {
			if (connMgr != null) {
				logger.info("Executing closeIdleConnection Method to get rid of the connections residing in CLOSE_WAIT phase...");
				connMgr.closeIdleConnections(AppConfig.config.getInt(
						"Connection_Max_Idle_Time", 10));
				try {
					//logger.info("Idle Monitor Thread going to sleep...");
					Thread.sleep(AppConfig.config.getInt(
							"Idle_Monitor_Thread_Sleep_Time", 120000));
				} catch (InterruptedException e) {
					logger.error("Idle Monitoring Thread Interrupted : "
							+ e.getMessage());
				}
			}
		}
	}
}
