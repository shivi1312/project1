package com.missedcallalertsnotifycallerservice.www;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.HttpClient;
import org.apache.axis2.Constants;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.axis2.context.*;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.axis2.AxisFault;
import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;

import com.telemune.vcc.config.AppConfig;
public class ConnectionManager{

    
     static ConnectionManager conManager = new ConnectionManager();	
     static ConfigurationContext defaultConfigurationContext ;	
     private ConnectionManager(){}	
     public static ConnectionManager  getInstance(){
		if(conManager ==null){
		 conManager = new ConnectionManager();
		}
		return conManager; 
	} 	

	 static MultiThreadedHttpConnectionManager defaultHttpConnectionManager;
    static {
    	defaultHttpConnectionManager = createConnectionManager();
	}	

    public static MultiThreadedHttpConnectionManager createConnectionManager() {
        MultiThreadedHttpConnectionManager mgr = new MultiThreadedHttpConnectionManager();
        //mgr.closeIdleConnections(0);//For currently it should be uncomment before use
        HttpConnectionManagerParams params = mgr.getParams();
        if (params == null) {
        params = new HttpConnectionManagerParams();
        mgr.setParams(params);
        }
        //params.setMaxTotalConnections(400);
        params.setMaxTotalConnections(AppConfig.config.getInt("MAX_TOTAL_CONN",400));
        //params.setDefaultMaxConnectionsPerHost(350);
        params.setDefaultMaxConnectionsPerHost(AppConfig.config.getInt("DEFAULT_MAX_CONN_PER_HOST",350));
	
        //params.setSoTimeout(5000);
        params.setSoTimeout(AppConfig.config.getInt("READ_TIME_OUT",5000));
        //params.setParameter("http.connection-manager.timeout",10); //connection time out from pool while getting
        params.setParameter("http.connection-manager.timeout",AppConfig.config.getInt("CONN_MANAGER_TIMEOUT",10)); //connection time out from pool while getting
        return mgr;
        }

   public static HttpClient createHttpClient(MultiThreadedHttpConnectionManager connectionManager, int soTimeoutMillies) {
        HttpClient result = new HttpClient(connectionManager);
        HttpClientParams params = result.getParams();
        if (params == null) {
        params = new HttpClientParams();
        result.setParams(params);
        }
        //params.setSoTimeout(soTimeoutMillies);
        //params.setParameter("http.tcp.nodelay", true); //added 5-11-2017
        params.setParameter("http.method.retry-handler", new DefaultHttpMethodRetryHandler(0, false)); //added 5-11-2017
        //params.setParameter("http.socket.timeout",10000);
        //params.setParameter("http.connection.timeout",5000);
        params.setParameter("http.connection.timeout",AppConfig.config.getInt("CONN_TIME_OUT",5000));
	
        return result;
       }

    public static synchronized ConfigurationContext getDefaultConfigurationContext() throws AxisFault {
        if (defaultConfigurationContext == null) {
        defaultConfigurationContext = ConfigurationContextFactory.createConfigurationContextFromFileSystem(null, null);
        defaultConfigurationContext.setProperty(HTTPConstants.REUSE_HTTP_CLIENT, Constants.VALUE_TRUE);
        HttpClient httpClient = createHttpClient(defaultHttpConnectionManager, 5000);
        defaultConfigurationContext.setProperty(HTTPConstants.CACHED_HTTP_CLIENT, httpClient);
        //System.out.println("ConfigurationContext created Successfully inside ConnectionManager");
         //defaultConfigurationContext.setProperty(HTTPConstants.AUTO_RELEASE_CONNECTION, true);
        }

        return defaultConfigurationContext;
      }
    
    public static void startMonitoring() {
		try {
			/*
			 * idle connections is a dedicated monitor thread used to evict
			 * connections that are considered expired due to a long period of
			 * inactivity. The monitor thread can periodically call
			 * ClientConnectionManager#closeExpiredConnections() method to close
			 * all expired connections and evict closed connections from the
			 * pool. It can also optionally call
			 * ClientConnectionManager#closeIdleConnections() method to close
			 * all connections that have been idle over a given period of time 
			 */
			IdleConnectionMonitorThread staleMonitor = new IdleConnectionMonitorThread(
					defaultHttpConnectionManager);
			staleMonitor.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
