package com.telemune.retrieverapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetrieverApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetrieverApiApplication.class, args);
	}

}
