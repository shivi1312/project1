package com.telemune.retrieverapi.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.telemune.retrieverapi.Entity.GmatMsg_0;

    @Repository
	public interface GmatRepository_0 extends JpaRepository<GmatMsg_0, Integer>{
    	
        List<GmatMsg_0> findAll();

    	
    	
    	

	}


