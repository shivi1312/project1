package com.telemune.retrieverapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.retrieverapi.Entity.GmatMsg_0;
import com.telemune.retrieverapi.repository.GmatRepository_0;

@RestController
public class FetchController {
	
	@Autowired
	GmatRepository_0 repo;
	
	@GetMapping("/company")
    public List<GmatMsg_0> getAllNotes()
    {
        return repo.findAll();
    }

}
