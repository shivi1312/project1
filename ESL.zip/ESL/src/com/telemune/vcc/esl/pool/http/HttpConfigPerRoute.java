package com.telemune.vcc.esl.pool.http;

@SuppressWarnings("serial")
public class HttpConfigPerRoute implements java.io.Serializable {
	

	private String host;
	private int maxPerRoute;
	private int port;

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public int getMaxPerRoute() {
		return maxPerRoute;
	}

	public void setMaxPerRoute(int maxPerRoute) {
		this.maxPerRoute = maxPerRoute;
	}

	@Override
	public String toString() {
		return "HttpConfigPerRoute [host=" + host + ", maxPerRoute=" + maxPerRoute + ", port=" + port + "]";
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	
}
