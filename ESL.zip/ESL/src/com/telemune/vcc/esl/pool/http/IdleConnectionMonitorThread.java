package com.telemune.vcc.esl.pool.http;

import java.util.concurrent.TimeUnit;

import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telemune.vcc.esl.common.AppConfig;

public class IdleConnectionMonitorThread extends Thread {
	private static Logger logger = LoggerFactory.getLogger(IdleConnectionMonitorThread.class);
	private final HttpClientConnectionManager connMgr;
	//private volatile boolean shutdown;

	public IdleConnectionMonitorThread(
			PoolingHttpClientConnectionManager connMgr) {
		super();
		this.connMgr = connMgr;
		logger.info("Conn max ideal timeout ["+AppConfig.config.getInt("hosts.max-ideal-time",
		30)+"] Idle Monitor Thread Waiting Time ["+AppConfig.config.getInt("hosts.idle-monitor-thread-sleep-time",60000)+"]");		
	}

	@Override
	public void run() {
		/*
		 * Commented on 12th Jan 2018 By Richard
		 * try {
			while (!shutdown) {
				synchronized (this) {
					wait(AppConfig.config.getInt("hosts.wait-timeout",1000));
					connMgr.closeExpiredConnections();
					connMgr.closeIdleConnections(AppConfig.
					config.getInt("hosts.max-ideal-time",10), TimeUnit.MILLISECONDS);
				}
			}
		} catch (InterruptedException ex) {
			shutdown();
		}*/
		while(true)
		{
			if (connMgr != null) {
				logger.info("Executing closeIdleConnection method...");
				connMgr.closeExpiredConnections();
				connMgr.closeIdleConnections(AppConfig.
						config.getInt("hosts.max-ideal-time",10), TimeUnit.MILLISECONDS);
				try {
					//logger.info("Idle Monitor Thread going to sleep...");
					Thread.sleep(AppConfig.config.getInt(
							"hosts.idle-monitor-thread-sleep-time",60000));
				} catch (InterruptedException e) {
					logger.error("Idle Monitoring Thread Interrupted : "
							+ e.getMessage());
				}
			}
		}
	}

	/*public void shutdown() {
		shutdown = true;
		synchronized (this) {
			notifyAll();
		}
	}*/
}
