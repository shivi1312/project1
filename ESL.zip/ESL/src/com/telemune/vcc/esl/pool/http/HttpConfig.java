package com.telemune.vcc.esl.pool.http;

//import java.util.ArrayList;
//import java.util.List;

//import org.apache.commons.configuration.HierarchicalConfiguration;
import org.apache.log4j.Logger;

import com.telemune.vcc.esl.common.AppConfig;

@SuppressWarnings("serial")
public class HttpConfig implements java.io.Serializable {
	final static Logger logger = Logger.getLogger(HttpConfig.class);
	private int maxTotal;
	private int defaultMaxPerRoute;
	//List<HttpConfigPerRoute> list = new ArrayList<HttpConfigPerRoute>();

	public HttpConfig() {
		this.setMaxTotal();
		this.setDefaultMaxPerRoute();
		//this.setList(); ---Commented on 12th Jan 2018 By Richard
	}

	public int getMaxTotal() {
		return maxTotal;
	}

	private void setMaxTotal() {
		this.maxTotal = AppConfig.config.getInt("hosts.max-total", 150);
	}

	public int getDefaultMaxPerRoute() {
		return defaultMaxPerRoute;
	}

	private void setDefaultMaxPerRoute() {
		this.defaultMaxPerRoute = AppConfig.config.getInt(
				"hosts.default-max-per-route", 150);
	}

	/* Commented on 12th Jan 2018 By Richard
	 * public List<HttpConfigPerRoute> getList() {
		return list;
	}

	private void setList() {
		try {
			List<HierarchicalConfiguration> fields = AppConfig.config.configurationsAt("hosts.host");
			for (HierarchicalConfiguration sub : fields) {
				HttpConfigPerRoute route = new HttpConfigPerRoute();
				route.setHost(sub.getString("name", ""));
				route.setPort(sub.getInt("port", 8080));
				route.setMaxPerRoute(sub.getInt("max-conn", 600));
				logger.info(route.toString());
				this.list.add(route);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception while set per route configuration: " + e.getMessage());
		}
	}

	public void setMaxTotal(int maxTotal) {
		this.maxTotal = maxTotal;
	}

	public void setDefaultMaxPerRoute(int defaultMaxPerRoute) {
		this.defaultMaxPerRoute = defaultMaxPerRoute;
	}
*/
}
