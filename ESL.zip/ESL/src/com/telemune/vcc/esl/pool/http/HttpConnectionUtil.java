package com.telemune.vcc.esl.pool.http;

//import java.util.List;
//import java.util.concurrent.TimeUnit;

//import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
//import org.apache.http.config.SocketConfig;
//import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telemune.vcc.esl.common.AppConfig;

public class HttpConnectionUtil {
	private static Logger logger = LoggerFactory.getLogger(HttpConnectionUtil.class);
	private static PoolingHttpClientConnectionManager connManager = null;
	private RequestConfig config = null;
	private static HttpConnectionUtil datasource;
	private static CloseableHttpClient client;
	private HttpConfig httpConfig = new HttpConfig();
	/*
	 * Connection Timeout : How long to wait for a connection to be established
	 * with the remote server before throwing a timeout exception
	 */
	/*
	 Socket Timeout :
	 How long to wait for the server to respond to various calls before
	 throwing a timeout exception
	 */
	/*
	  Connection Request Timeout : 
	  How long to wait when trying to checkout a connection from the connection
	  pool before throwing an exception (the connection pool won't return
	  immediately if, for example, all the connections are checked out). 
	 */

	public static HttpConnectionUtil getInstance() {
		if (datasource == null) { 
			datasource = new HttpConnectionUtil();
		}
		return datasource;
	}

	/*public CloseableHttpClient getHttpConnection() {
		return HttpClients.custom().setConnectionManager(connManager).setDefaultRequestConfig(config).build();
	}*/
	
	public CloseableHttpClient getHttpConnection() {
		logger.info("Returning CloseableHttpClient object....");
		return client;
	}
	private HttpConnectionUtil() {
		
		config = RequestConfig.custom().setConnectTimeout(AppConfig.config.getInt("connect-timeout", 3000))
				.setConnectionRequestTimeout(AppConfig.config.getInt("connect-request-timeout", 3000))
				.setSocketTimeout(AppConfig.config.getInt("socket-timeout", 3000)).build();
		
		connManager = new PoolingHttpClientConnectionManager();
		/*
		 The maximum number of connections allowed across all routes.
		 */
		connManager.setMaxTotal(httpConfig.getMaxTotal());
		/*
		 * The maximum number of connections allowed for a route that has not
		 * been specified otherwise by a call to setMaxPerRoute. Use
		 * setMaxPerRoute when you know the route ahead of time and
		 * setDefaultMaxPerRoute when you do not.
		 */
		connManager.setDefaultMaxPerRoute(httpConfig.getDefaultMaxPerRoute());
		//connManager.closeIdleConnections(10, TimeUnit.MILLISECONDS);
		startMonitoring();
		//this.doRouteConfiguration();
		client=HttpClients.custom().setConnectionManager(connManager).setDefaultRequestConfig(config).build();
		
	}

	/*Commented on 12th Jan 2018 By Richard
	 * 
	 * private void doRouteConfiguration() {
		try {
			List<HttpConfigPerRoute> list = httpConfig.getList();
			if (list != null && list.size() > 0) {
				for (HttpConfigPerRoute sub : list) {
					HttpRoute route = new HttpRoute(new HttpHost(sub.getHost(),sub.getPort()));
					connManager.setMaxPerRoute(route, sub.getMaxPerRoute());
					//connManager.setMaxPerRoute(route, sub.getMaxPerRoute());
					//connManager.setDefaultMaxPerRoute(500);
					
					 * If you want to set configuration per host in a connection
					 * manager but it will be overridden by RequestConfig
					 * configuration because it is configured per request 
					 
					
					 * connManager.setSocketConfig( route.getTargetHost(),
					 * SocketConfig.custom()
					 * .setSoTimeout(sub.getSoTimeout()).build());
					 
					
					//logger.info(""+connManager.getMaxPerRoute(route));
					//logger.info(""+connManager.getSocketConfig(route.getTargetHost()));
				}
				
			}
		} catch (Exception e) {
			logger.error("Exception while set per route configuration: "
					+ e.getMessage());
		}
	}
*/
	private static void startMonitoring() {
		try {
			/*
			 * idle connections is a dedicated monitor thread used to evict
			 * connections that are considered expired due to a long period of
			 * inactivity. The monitor thread can periodically call
			 * ClientConnectionManager#closeExpiredConnections() method to close
			 * all expired connections and evict closed connections from the
			 * pool. It can also optionally call
			 * ClientConnectionManager#closeIdleConnections() method to close
			 * all connections that have been idle over a given period of time 
			 */
			IdleConnectionMonitorThread staleMonitor = new IdleConnectionMonitorThread(
					connManager);
			staleMonitor.start();
			//staleMonitor.join(1000); ----Commented on 12th Jan 2018 By Richard
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
