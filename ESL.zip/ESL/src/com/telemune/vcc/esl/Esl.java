package com.telemune.vcc.esl;

@SuppressWarnings("serial")
public class Esl implements java.io.Serializable {
	private String callUuid;
	private String callDirection;
	private String recordFileName;
	private String bParty;
	private String aParty;
	private String hangupCause;
	private String eventName;
	private String lang = "1";
	private String ringTime;
	private String recordTempPath;
	private String answeredTime;
	private String answered = "0";
	private String teleivo;
	private String serviceType;
	private String silence;
	private String serverId;
	private String hangupTime;
	private String isVoiceMailDeleted = "0";
	private String isMailBoxFull ="0";
	private String subType = "N";
	private String isCallAllowed = "0";
	private String isSuccess = "0";
	private String isNotifyMeWithMCM = "0";
	private String isUserIsOptedOut = "0";
	private String ratePlan;
	private String recordTimeout;
	private String recordLength;
	private String reason;

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getRecordTimeout() {
		return recordTimeout;
	}

	public void setRecordTimeout(String recordTimeout) {
		this.recordTimeout = recordTimeout;
	}

	public String getRecordLength() {
		return recordLength;
	}

	public void setRecordLength(String recordTimeout) {
		this.recordLength = recordTimeout;
	}

	public String getRatePlan() {
		return ratePlan;
	}

	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}

	public String getIsNotifyMeWithMCM() {
		return isNotifyMeWithMCM;
	}

	public void setIsNotifyMeWithMCM(String isNotifyMeWithMCM) {
		this.isNotifyMeWithMCM = isNotifyMeWithMCM;
	}

	public String getIsUserIsOptedOut() {
		return isUserIsOptedOut;
	}

	public void setIsUserIsOptedOut(String isUserIsOptedOut) {
		this.isUserIsOptedOut = isUserIsOptedOut;
	}

	public String getIsCallAllowed() {
		return isCallAllowed;
	}

	public void setIsCallAllowed(String isCallAllowed) {
		this.isCallAllowed = isCallAllowed;
	}

	public String getIsSuccess() {
		return isSuccess;
	}

	public void setIsSuccess(String isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getHangupTime() {
		return hangupTime;
	}

	public void setHangupTime(String hangupTime) {
		this.hangupTime = hangupTime;
	}

	public String getServerId() {
		return serverId;
	}

	public void setServerId(String serverId) {
		this.serverId = serverId;
	}

	public String getSilence() {
		return silence;
	}

	public void setSilence(String silence) {
		this.silence = silence;
	}

	public String getAnsweredTime() {
		return answeredTime;
	}

	public void setAnsweredTime(String answeredTime) {
		this.answeredTime = answeredTime;
	}

	public String getAnswered() {
		return answered;
	}

	public void setAnswered(String answered) {
		this.answered = answered;
	}

	public String getTeleivo() {
		return teleivo;
	}

	public void setTeleivo(String teleivo) {
		this.teleivo = teleivo;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getRecordTempPath() {
		return recordTempPath;
	}

	public void setRecordTempPath(String recordTempPath) {
		this.recordTempPath = recordTempPath;
	}

	public String getCallUuid() {
		return callUuid;
	}

	public void setCallUuid(String callUuid) {
		this.callUuid = callUuid;
	}

	public String getCallDirection() {
		return callDirection;
	}

	public void setCallDirection(String callDirection) {
		this.callDirection = callDirection;
	}

	public String getRecordFileName() {
		return recordFileName;
	}

	public void setRecordFileName(String recordFileName) {
		this.recordFileName = recordFileName;
	}

	public String getbParty() {
		return bParty;
	}

	public void setbParty(String bParty) {
		this.bParty = bParty;
	}

	public String getaParty() {
		return aParty;
	}

	public void setaParty(String aParty) {
		this.aParty = aParty;
	}

	public String getHangupCause() {
		return hangupCause;
	}

	public void setHangupCause(String hangupCause) {
		this.hangupCause = hangupCause;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public String getRingTime() {
		return ringTime;
	}

	public void setRingTime(String ringTime) {
		this.ringTime = ringTime;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getIsVoiceMailDeleted() {
		return isVoiceMailDeleted;
	}

	public void setIsVoiceMailDeleted(String isVoiceMailDeleted) {
		this.isVoiceMailDeleted = isVoiceMailDeleted;
	}

	public String getIsMailBoxFull() {
		return isMailBoxFull;
	}

	public void setIsMailBoxFull(String isMailBoxFull) {
		this.isMailBoxFull = isMailBoxFull;
	}

}
