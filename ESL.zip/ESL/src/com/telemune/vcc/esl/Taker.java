package com.telemune.vcc.esl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telemune.vcc.esl.common.AppConfig;

public class Taker implements Runnable {
        private static Logger logger = LoggerFactory.getLogger(Taker.class);

        public Taker() {

        }

        @Override
        public void run() {
                while (true) {
			Esl esl = null;
			try {
				
				logger.info("Fsd inbound getting data from queue: "+VccData.eslReqQue.size());
				esl = VccData.eslReqQue.take();
				VccData.executor.submit(new Worker(esl));
			
		}catch(Exception e){
			logger.error("Fsw inbound error while getting data from queue: "+e.getMessage());			
		}
                }
        }

}
