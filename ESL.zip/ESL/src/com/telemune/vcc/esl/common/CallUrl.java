package com.telemune.vcc.esl.common;

import java.util.Date;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telemune.vcc.esl.pool.http.HttpConnectionUtil;

public class CallUrl {
	final static Logger logger = LoggerFactory.getLogger(CallUrl.class);
	
	public String call(URIBuilder builder) {
		
		CloseableHttpClient client = null;
		CloseableHttpResponse response =null;
		String result = "";
		try {
			client = HttpConnectionUtil.getInstance().getHttpConnection();
			logger.info("Fsw inbound url call: ["+builder.build() + "] Client[ "+client.toString()+ "]");
			HttpGet get = new HttpGet(builder.build());
			Date sendTime=new Date();
			response = client.execute(get);	
			result = EntityUtils.toString(response.getEntity());
			
			/* Ensures that the entity content is fully consumed and the content
			 stream, if exists, is closed. The process is done, quietly ,
			 without throwing any IOException.
			 */
			EntityUtils.consumeQuietly(response.getEntity());
			Date recvTime=new Date();
			
			Long timeDiff=recvTime.getTime()-sendTime.getTime();
			logger.info("Result[ " + result + " ] Time Diff["+timeDiff+" milliseconds]");
		} catch (Exception e) {
			try
			{
				logger.error("[Exception inside CallUrl] ["+builder.build()+"] Error[" +e.getMessage()+"]");
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}
		finally
		{
			if(response!=null)
			{
				try
				{
					response.close();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		}
		return result;
	}
}
