package com.telemune.vcc.esl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telemune.vcc.esl.common.AppConfig;

public class VmTaker implements Runnable {
        private static Logger logger = LoggerFactory.getLogger(VmTaker.class);

        public VmTaker() {

        }

        @Override
        public void run() {
                while (true) {
			VmData vmData = null;
			try {
				
				logger.info("Fsw inbound getting data from queue for profile.check: "+VccData.eslVmReqQue.size());
				vmData = VccData.eslVmReqQue.take();
				VccData.vmExecutor.submit(new VmHandler(vmData.getCtx(),vmData.getEvent()));
				
		}catch(Exception e){
			logger.error("Fsw inbound error while getting data from queue for profile.check: "+e.getMessage());			
		}
                }
        }

}
