package com.telemune.vcc.esl;

import java.net.InetSocketAddress;

import org.freeswitch.esl.client.inbound.Client;
import org.freeswitch.esl.client.internal.Context;
import org.freeswitch.esl.client.internal.IModEslApi;
import org.freeswitch.esl.client.transport.message.EslMessage;
import org.freeswitch.esl.client.outbound.IClientHandler;
import org.freeswitch.esl.client.outbound.IClientHandlerFactory;
import org.freeswitch.esl.client.outbound.SocketClient;
import org.freeswitch.esl.client.transport.event.EslEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telemune.vcc.esl.common.AppConfig;

public class EslConnector implements Connector {
	private static Logger logger = LoggerFactory.getLogger(EslConnector.class);
	static Client inboundClient = new Client();
	private static SocketClient outboundServer;
	private String ip;
	private int port;
	private String password;
	private int timeout;	

	public EslConnector() {
		this.ip = AppConfig.config.getString("fsw.inbound.ip","127.0.0.1");
		this.port = AppConfig.config.getInt("fws.inbound.port",8021);
		this.password = AppConfig.config.getString("fws.inbound.passowrd","ClueCon");
		this.timeout = AppConfig.config.getInt("fsw.inbound.timeout",10);
		logger.info("Freeswitch inbound ip ["+this.ip+"] port ["+this.port+"] "
				+ "passowrd ["+this.password+"] timeout ["+this.timeout+"]");
	}

	public void connect() {
		try {
			if(inboundClient == null)
				inboundClient = new Client();
			inboundClient.connect(new InetSocketAddress(this.ip, this.port),this.password, this.timeout);
			inboundClient.setEventSubscriptions(IModEslApi.EventFormat.PLAIN, 
					AppConfig.config.getString("fsw.inbound.allow.event","CHANNEL_HANGUP"));
			inboundClient.addEventListener(new EslListener());
			if (!this.isActive()){
				logger.warn("Fsw inbound connection is not created !..");
				inboundClient = null;
			} else {	
				logger.info("Fsw inbound connection is created successfully !..");
			}	
		} catch(Exception e){
			logger.error("Fsw inbound connection error: "+e.getMessage());
			e.printStackTrace();
		}	
	}

	public static EslMessage sendSyncApiCommand( String command, String arg, Context ctx, EslEvent event ){
		try {
			return inboundClient.sendApiCommand("uuid_setvar_multi", event.getEventHeaders().
			get("Unique-ID")+" msisdnFilePath=/home/vccuser/voice/recordings/VCCRECORD/2/VNRC_RECORD_AFTER_BEEP.wav");
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	public boolean isActive() {
		return inboundClient.canSend();
	}

	public void close() {
		inboundClient.close();
	}

}
