package com.telemune.vcc.esl;

import org.freeswitch.esl.client.inbound.IEslEventListener;
import org.freeswitch.esl.client.internal.Context;
import org.freeswitch.esl.client.transport.event.EslEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.telemune.vcc.esl.common.AppConfig;
import com.telemune.vcc.esl.util.TSSJavaUtil;

public class EslListener implements IEslEventListener {
	private static Logger logger = LoggerFactory.getLogger(EslListener.class);
	private Gson gson = new Gson();

	@Override
	public void onEslEvent(Context ctx, EslEvent event) {
		if(Main.lCheck.isRun){
			Esl esl = new Esl();
			logger.debug(gson.toJson(event));

			if (event.getEventHeaders().get("televio_app") != null
					&& event.getEventHeaders().get("televio_app").equals("1")
					&& !event.getEventHeaders().get("Event-Name").equals("custom")) {
								
				logger.info("calling [" + TSSJavaUtil.getaParty(event.getEventHeaders().get("Caller-Caller-ID-Number"))
						+ "] called [" + TSSJavaUtil.getbPartyNumber(event) + "] event ["
						+ event.getEventHeaders().get("Event-Name") + "]");
				
				esl.setCallUuid(event.getEventHeaders().get("Unique-ID"));
				esl.setCallDirection(event.getEventHeaders().get("Call-Direction"));
				esl.setHangupCause(event.getEventHeaders().get("Hangup-Cause"));
				esl.setEventName(event.getEventHeaders().get("Event-Name"));
				esl.setaParty(TSSJavaUtil.getaParty(event.getEventHeaders().get("Caller-Caller-ID-Number")));
				esl.setbParty(TSSJavaUtil.getbPartyNumber(event));
				esl.setRecordFileName(event.getEventHeaders().get("variable_record_filename"));
				// esl.setRingTime(event.getEventHeaders().get("vcc_ring_time"));
				esl.setRingTime(TSSJavaUtil.getFormattedTime(event.getEventHeaders().get("Caller-Profile-Created-Time")));
				esl.setRecordTempPath(event.getEventHeaders().get("variable_call_screen_filename"));
				if (event.getEventHeaders().get("variable_recordLength") != null)
					esl.setRecordLength(event.getEventHeaders().get("variable_recordLength"));
				if (event.getEventHeaders().get("variable_isNotifyMeWithMCM") != null)
					esl.setIsNotifyMeWithMCM(event.getEventHeaders().get("variable_isNotifyMeWithMCM"));
				if (event.getEventHeaders().get("variable_subType") != null)
					esl.setSubType(event.getEventHeaders().get("variable_subType"));
				if (event.getEventHeaders().get("variable_isCallAllowed") != null)
					esl.setIsCallAllowed(event.getEventHeaders().get("variable_isCallAllowed"));
				if (event.getEventHeaders().get("variable_isSuccess") != null)
					esl.setIsSuccess(event.getEventHeaders().get("variable_isSuccess"));
				esl.setRecordFileName(event.getEventHeaders().get("variable_recordFileName"));
				esl.setIsUserIsOptedOut(event.getEventHeaders().get("variable_isUserIsOptedOut"));
				esl.setRatePlan(event.getEventHeaders().get("variable_ratePlan"));
				esl.setLang(event.getEventHeaders().get("variable_lang"));
				if (event.getEventHeaders().get("vcc_answered_time") != null)
					esl.setAnsweredTime(event.getEventHeaders().get("vcc_answered_time"));
				else
					esl.setAnsweredTime(TSSJavaUtil.getCurrentTime());
				esl.setAnswered(event.getEventHeaders().get("vcc_answered"));
				esl.setTeleivo(event.getEventHeaders().get("televio_app"));
				
				//esl.setServiceType(event.getEventHeaders().get("service_type"));
				if (event.getEventHeaders().get("service_type") != null)
                    esl.setServiceType(event.getEventHeaders().get("service_type"));
				else
					esl.setServiceType(event.getEventHeaders().get("variable_service_type"));
				
				logger.info("["+event.getEventHeaders().get("Unique-ID")+"] calling [" + TSSJavaUtil.getaParty(event.getEventHeaders().get("Caller-Caller-ID-Number"))+"] called [" + TSSJavaUtil.getbPartyNumber(event) + "] IVR_REASON : "+event.getEventHeaders().get("variable_ivrReason"));
				if(event.getEventHeaders().get("variable_ivrReason")==null || event.getEventHeaders().get("variable_ivrReason").equalsIgnoreCase("NA"))
				{
					esl.setReason(TSSJavaUtil.getReason(event));
				}
				else
				{
					esl.setReason(event.getEventHeaders().get("variable_ivrReason"));
				}
				esl.setIsVoiceMailDeleted(event.getEventHeaders().get("variable_isVoiceMailDeleted"));
				esl.setIsMailBoxFull(event.getEventHeaders().get("variable_isMailBoxFull"));
				if (Boolean.parseBoolean(event.getEventHeaders().get("variable_silence_hits_exhausted")))
					esl.setSilence("1");
				else
					esl.setSilence("0");
				TSSJavaUtil.getServerId(esl);
				// esl.setHangupTime(this.getCurrentTime());
				esl.setHangupTime(TSSJavaUtil.getFormattedTime(event.getEventHeaders().get("Event-Date-Timestamp")));
				if(esl.getbParty()==null || esl.getaParty()==null || (esl.getReason().equalsIgnoreCase("unconditional") && AppConfig.config.getInt("discard_unconditional_call",1) == 1))
				{
					try {
						String command = "uuid_kill";
						logger.error("Call Discarded. Received Reason[Unconditional] calling [" + event.getEventHeaders().get("Caller-Caller-ID-Number") + "] ["
								+ TSSJavaUtil.getbPartyNumber(event) + "] uuid: " + event.getEventHeaders().get("Unique-ID"));
						String args = TSSJavaUtil.getUniqueId(ctx, event);
						logger.info("@@@@ command: " + command + " args: " + args);
						ctx.sendApiCommand(command, args);
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					logger.info(gson.toJson(esl));
					this.process(esl);
				}
			} else if (event.getEventHeaders().get("Event-Name").equals("custom")
					&& event.getEventHeaders().get("condition").equals("profile_check")) {
				
				logger.info("calling [" + event.getEventHeaders().get("Caller-Caller-ID-Number") + "] called ["
						+ TSSJavaUtil.getbPartyNumber(event) + "] event [" + event.getEventHeaders().get("Event-Name") + "]");
				// new VmHandler().processVoiceMail(ctx, event);
				this.processVoiceMail(ctx, event);
			}
		}else{
			logger.debug(gson.toJson(event));
			if (event.getEventHeaders().get("televio_app") != null
					&& event.getEventHeaders().get("televio_app").equals("1")
					&& !event.getEventHeaders().get("Event-Name").equals("custom")) {
				/*logger.info("############...System running properly...Hangup Request N/W Check.############## "
						+ "AParty["+event.getEventHeaders().get("Caller-Caller-ID-Number")+"] "
								+ "BParty["+TSSJavaUtil.getbPartyNumber(event)+"] UUID ["+event.getEventHeaders().get("Unique-ID")+"]");*/
				
			} else if (event.getEventHeaders().get("Event-Name").equals("custom")
					&& event.getEventHeaders().get("condition").equals("profile_check")) {
				/*logger.info("############...System running properly...INVITE Request N/W Check.############## "
						+ "AParty["+event.getEventHeaders().get("Caller-Caller-ID-Number")+"] "
								+ "BParty["+TSSJavaUtil.getbPartyNumber(event)+"] UUID ["+event.getEventHeaders().get("Unique-ID")+"]");*/
				try {
					String command = "uuid_kill";
					logger.error("calling [" + event.getEventHeaders().get("Caller-Caller-ID-Number") + "] ["
							+ TSSJavaUtil.getbPartyNumber(event) + "] uuid: " + event.getEventHeaders().get("Unique-ID"));
					String args = TSSJavaUtil.getUniqueId(ctx, event);
					logger.info("@@@@ command: " + command + " args: " + args);
					ctx.sendApiCommand(command, args);
				} catch (Exception e) {
					e.printStackTrace();
				}		
			}			
		}
	}

	public void processVoiceMail(Context ctx, EslEvent event) {
		try {
			VmData vmData = new VmData();
			vmData.setCtx(ctx);
			vmData.setEvent(event);
			VccData.eslVmReqQue.put(vmData);
		} catch (Exception e) {
			logger.error("Exception while putting data in req queue for voice mail profile check: " + e.getMessage());
		}

	}
	
	public void process(Esl esl) {
		try {
			VccData.eslReqQue.put(esl);
		} catch (Exception e) {
			logger.error("Fsd inbound error put data in queue: " + e.getMessage());
		}
	}
}
