package com.telemune.vcc.esl;

//import org.freeswitch.esl.client.inbound.IEslEventListener;
import org.freeswitch.esl.client.internal.Context;
import org.freeswitch.esl.client.transport.event.EslEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;

import com.telemune.vcc.esl.pool.http.HttpConnectionUtil;
*/
import com.telemune.vcc.esl.common.AppConfig;

import com.telemune.vcc.esl.common.CallUrl;
import com.telemune.vcc.esl.sipParser.SipUri;
import com.telemune.vcc.esl.util.TSSJavaUtil;

import org.apache.http.client.utils.URIBuilder;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;

import com.google.gson.Gson;
import org.json.XML;
import org.json.JSONObject;
import org.json.JSONArray;
import org.apache.commons.lang.builder.ToStringBuilder;

public class VmHandler implements Runnable {
	private static Logger logger = LoggerFactory.getLogger(VmHandler.class);
	private Gson gson = new Gson();

	private Context ctx = null;
	private EslEvent event = null;

	public VmHandler(Context ctx, EslEvent event) {
		this.ctx = ctx;
		this.event = event;
	}

	@Override
	public void run() {
		logger.info("Process voice mail profile.check request: " + event.getEventHeaders().get("Unique-ID"));
		this.processVoiceMail(ctx, event);
	}

	public void processVoiceMail(Context ctx, EslEvent event) {
		try {
			String reason=TSSJavaUtil.getReason(event);
			if(TSSJavaUtil.getbPartyNumber(event)==null || (reason.equalsIgnoreCase("unconditional") && AppConfig.config.getInt("discard_unconditional_call",1) == 1))
			{
				try {
					String command = "uuid_kill";
					logger.error("Call Discarded. Received Reason["+reason+"] calling [" + event.getEventHeaders().get("Caller-Caller-ID-Number") + "] ["
							+ TSSJavaUtil.getbPartyNumber(event) + "] uuid: " + event.getEventHeaders().get("Unique-ID"));
					String args = TSSJavaUtil.getUniqueId(ctx, event);
					logger.info("@@@@ command: " + command + " args: " + args);
					ctx.sendApiCommand(command, args);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				JSONObject jsonObject = XML.toJSONObject(new CallUrl().call(this.checkProfile(ctx, event)));
				//logger.info(jsonObject.toString());
				Map<String, String> map = this.getVariables(ctx, event, jsonObject);
				map.put("ivrReason",reason);
				// logger.info(gson.toJson(map));
				event.getEventHeaders().put("msisdnFilePath", map.get("msisdnFilePath"));
				this.sendApiCommand(ctx, event, map);
				map.clear();
				map = null;
			}
			
		} catch (Exception e) {
			logger.error("calling [" + event.getEventHeaders().get("Caller-Caller-ID-Number") + "] ["
					+ TSSJavaUtil.getbPartyNumber(event) + "] error when call url: " + e.getMessage());
		}
	}

	public void sendApiCommand(Context ctx, EslEvent event, Map<String, String> map) {
		try {
			logger.info("serviceType ["+map.get("serviceType")+"]");
			if(map.get("serviceType") != null && (map.get("serviceType").equals("0001") || map.get("serviceType").equals("1"))) { //added by kuldeep on 18 Aug 2020
				String command = "uuid_setvar_multi";
				String args = this.generateArgs(ctx, event, map) + ";service_type=0001";
				logger.info("command: " + command + " args: " + args);
				ctx.sendApiCommand(command, args);
				
				String reason=AppConfig.config.getString("sip_rel_map." + TSSJavaUtil.getReason(event),"SUBSCRIBER_ABSENT");
				command = "uuid_kill";
				//args = this.generateArgs(ctx, event, map); comment by kuldeep 11-Nov-2020
				args = TSSJavaUtil.getUniqueId(ctx, event) +" "+ reason;
				logger.info("@@@@ command: " + command + " args: " + args);
				ctx.sendApiCommand(command, args);
			} else {
				String command = "uuid_setvar_multi";
				String args = this.generateArgs(ctx, event, map)  + ";service_type=0010";
				logger.info("command: " + command + " args: " + args);
				ctx.sendApiCommand(command, args);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
//	public void sendApiCommand(Context ctx, EslEvent event, Map<String, String> map) {
//        try {
//                logger.info("serviceType ["+map.get("serviceType")+"]");
//                {
//                        String command = "uuid_setvar_multi";
//                        String args = this.generateArgs(ctx, event, map);
//                        logger.info("command: " + command + " args: " + args);
//                        ctx.sendApiCommand(command, args);
//                }
//
//
//                if(map.get("serviceType") != null && (map.get("serviceType").equals("0001") || map.get("serviceType").equals("1"))) {
//                        String args = event.getEventHeaders().get("Unique-ID")+" serviceType=0001" ;
//                        String command = "uuid_setvar";
//                        ctx.sendApiCommand(command, args);
//
//                        args = event.getEventHeaders().get("Unique-ID");
//                        command = "uuid_kill";
//                        ctx.sendApiCommand(command, args);
//                }
//        } catch (Exception e) {
//                e.printStackTrace();
//        }
//}

	public String generateArgs(Context ctx, EslEvent event, Map<String, String> map) {
		String args = "";
		try {
			if (map.get("greetPath") != null && !map.get("greetPath").equalsIgnoreCase("")) {
				args = event.getEventHeaders().get("Unique-ID") + " msisdnFilePath=" + map.get("msisdnFilePath")
						+ ";isIntNo=" + map.get("isIntNo") + ";isNotifyMeWithMCM=" + map.get("isNotifyMeWithMCM")
						+ ";subType=" + map.get("subType") + ";isCallAllowed=" + map.get("isCallAllowed")
						+ ";isSuccess=" + map.get("isSuccess") + ";isVoiceMailDeleted=" + map.get("isVoiceMailDeleted")
						+ ";recordFileName=" + map.get("recordFileName") + ";invalidDigitsSound="
						+ map.get("invalidDigitsSound") + ";isUserIsOptedOut=" + map.get("isUserIsOptedOut")
						+ ";recordTimeout=" + map.get("recordTimeout") + ";recordLength=" + map.get("recordLength")
						+ ";greetPath=" + map.get("greetPath") + ";isMailBoxFull=" + map.get("isMailBoxFull")
						+ ";ratePlan=" + map.get("ratePlan")+";ivrReason=" + map.get("ivrReason")+";lang=" + map.get("lang")
						+";sessionGreetPath=" + map.get("greetPath"); //sessionGreetPath added by kuldeep 29-sep-2020
			} else {
				String sessionGreetPath = AppConfig.config.getString("DEFAULT_GREETING_PATH","")+","+map.get("msisdnFilePath");
				args = event.getEventHeaders().get("Unique-ID") + " msisdnFilePath=" + map.get("msisdnFilePath")
						+ ";isIntNo=" + map.get("isIntNo") + ";isNotifyMeWithMCM=" + map.get("isNotifyMeWithMCM")
						+ ";subType=" + map.get("subType") + ";isCallAllowed=" + map.get("isCallAllowed")
						+ ";isSuccess=" + map.get("isSuccess") + ";isVoiceMailDeleted=" + map.get("isVoiceMailDeleted")
						+ ";recordFileName=" + map.get("recordFileName") + ";invalidDigitsSound="
						+ map.get("invalidDigitsSound") + ";isUserIsOptedOut=" + map.get("isUserIsOptedOut")+";lang=" + map.get("lang")
						+ ";recordTimeout=" + map.get("recordTimeout") + ";recordLength=" + map.get("recordLength")
						+ ";isMailBoxFull=" + map.get("isMailBoxFull") + ";ratePlan=" + map.get("ratePlan")+";ivrReason=" + map.get("ivrReason")
						+";sessionGreetPath=" + sessionGreetPath; //sessionGreetPath added by kuldeep 29-sep-2020
			}
		} catch (Exception e) {
			logger.error("calling [" + event.getEventHeaders().get("Caller-Caller-ID-Number") + "] ["
					+ TSSJavaUtil.getbPartyNumber(event) + "] error when generate args: " + e.getMessage());
			e.printStackTrace();
		}
		return args;
	}

	public Map<String, String> getVariables(Context ctx, EslEvent event, JSONObject jsonObject) {
		Map<String, String> map = new HashMap<String, String>();
		try {
			JSONArray jsonArr = jsonObject.getJSONObject("response").getJSONArray("var");
			for (int i = 0; i < jsonArr.length(); i++) {
				String key = jsonArr.getJSONObject(i).getString("name");
				String value = jsonArr.getJSONObject(i).get("value").toString();
				logger.debug(key+" ["+value+"]");
				map.put(key, value);
			}
			//logger.info("Inside ge variables : "+gson.toJson(map));
		} catch (Exception e) {
			logger.info("Exception occurred while getting variables map from response xml. Error["+e+"]");
			e.printStackTrace();
		}
		return map;
	}

	public URIBuilder checkProfile(Context ctx, EslEvent event) {
		URIBuilder builder = null;
		try {
			builder = new URIBuilder(AppConfig.config.getString("api.vm.profile.check"))
					.addParameter("callingNum", TSSJavaUtil.getaParty(event.getEventHeaders().get("Caller-Caller-ID-Number")))
					.addParameter("calledNum", TSSJavaUtil.getbPartyNumber(event)).addParameter("releaseCode", "unavailable")
					.addParameter("serviceType", "0010");
		} catch (Exception e) {
			logger.error("calling [" + event.getEventHeaders().get("Caller-Caller-ID-Number") + "] ["
					+ TSSJavaUtil.getbPartyNumber(event) + "] error when making url: " + e.getMessage());
		}
		return builder;
	}
}
