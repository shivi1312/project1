package com.telemune.vcc.esl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telemune.vcc.esl.common.AppConfig;
import com.telemune.vcc.esl.common.CallUrl;

import org.apache.http.client.utils.URIBuilder;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.time.DateUtils;

public class Worker implements Runnable {
	private static Logger logger = LoggerFactory.getLogger(Worker.class);
	private Esl esl = null;

	public Worker(Esl esl) {
		this.esl = esl;
	}

	@Override
	public void run() {
		logger.info("Process request: "+esl.getCallUuid());
		new CallUrl().call(this.makeUrl());
	}
	public URIBuilder makeUrl(){
		URIBuilder builder = null;
		String reasonCode = "cancel";
		String answered = "";
		try {
			if(this.esl.getAnswered() != null && this.esl.getAnswered().equals("1")){
                                reasonCode = "hangupWithSave";
                                answered = this.esl.getAnswered();
                        } else {
                                answered = "0";
                        }
			if(this.esl.getaParty()!= null && this.esl.getaParty().startsWith("+"))
				this.esl.setaParty(this.esl.getaParty().substring(1,this.esl.getaParty().length()));
			if(this.esl.getbParty()!= null && this.esl.getbParty().startsWith("+"))
                                this.esl.setbParty(this.esl.getbParty().substring(1,this.esl.getbParty().length()));
			builder = new URIBuilder(AppConfig.config.getString("api.url"))
			.addParameter("callingNum", this.esl.getaParty())
			.addParameter("calledNum", this.esl.getbParty())
			.addParameter("lang", this.esl.getLang())
			.addParameter("recordFile", "NA")
			.addParameter("serviceType", this.esl.getServiceType())
			.addParameter("ratePlan", this.esl.getRatePlan())
			.addParameter("recordingDuration", this.getRecordDuration(
                                this.esl.getAnsweredTime(),this.esl.getHangupTime(),this.esl.getRecordLength()))
			.addParameter("isVoiceMailDeleted", this.esl.getIsVoiceMailDeleted())
			.addParameter("reasonCode", reasonCode)
			.addParameter("hangupCause", this.esl.getHangupCause())
			.addParameter("recordFileName", this.esl.getRecordFileName())
			.addParameter("recordTempPath", this.esl.getRecordTempPath())
			.addParameter("subType", this.esl.getSubType())
			.addParameter("isCallAllowed", this.esl.getIsCallAllowed())
			.addParameter("releaseCode", this.esl.getReason())
			.addParameter("isMailBoxFull", this.esl.getIsMailBoxFull())
			//.addParameter("callTime", this.esl.getAnsweredTime())
			.addParameter("callTime", this.esl.getRingTime())
			.addParameter("answerd", answered)
			.addParameter("callDuration", this.getDuration(this.esl.getRingTime(),
                                this.esl.getHangupTime()))
			.addParameter("circuitId", "0")
			.addParameter("serverId", this.esl.getServerId())
			.addParameter("ringTime", this.esl.getRingTime())
			.addParameter("callUUID", this.esl.getCallUuid())
			.addParameter("isNotifyMeWithMCM", this.esl.getIsNotifyMeWithMCM())
			.addParameter("isUserIsOptedOut", this.esl.getIsUserIsOptedOut())
			.addParameter("isSilentDetect", this.esl.getSilence())
			.addParameter("isSuccess", this.esl.getIsSuccess())
			.addParameter("notificationSend", "true");
		}catch(Exception e){
			e.printStackTrace();
		}
		return builder;
	}
	public String getDuration(String start, String end){
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date d1 = null;
                Date d2 = null;
                long diffSeconds = 0;
                try {
                        logger.info("["+this.esl.getaParty()+"] ["+this.esl.getbParty()+"] start time: "+start+" end time: "+end);
                        d1 = format.parse(start);
                        d2 = format.parse(end);
                        diffSeconds = (d2.getTime() - d1.getTime()) / DateUtils.MILLIS_PER_SECOND;
                        logger.debug("call duration: "+diffSeconds);
                }catch(Exception e){
                        e.printStackTrace();
                }
                return String.valueOf(diffSeconds);
        }
	
	public String getRecordDuration(String start, String end, String maxLength){
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date d1 = null;
        Date d2 = null;
        long diffSeconds = 0;
        String recDuration = "";
        try {
                logger.info("["+this.esl.getaParty()+"] ["+this.esl.getbParty()+"] start time: "+start+" end time: "+end+" Max Length ["+maxLength+"]");
                d1 = format.parse(start);
                d2 = format.parse(end);
                diffSeconds = (d2.getTime() - d1.getTime()) / DateUtils.MILLIS_PER_SECOND;
                logger.debug("call duration: "+diffSeconds);
                if(diffSeconds>Integer.parseInt(maxLength)){
                	recDuration = maxLength;
                }else if(diffSeconds<0)	
                {
                	recDuration="0";
                }
                else
                {
                	recDuration = String.valueOf(diffSeconds);
                }
                
        }catch(Exception e){
                e.printStackTrace();
        }
        return recDuration;
}
	

}

