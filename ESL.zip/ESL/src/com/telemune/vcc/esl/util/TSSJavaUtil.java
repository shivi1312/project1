package com.telemune.vcc.esl.util;

import java.net.InetAddress;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.freeswitch.esl.client.internal.Context;
import org.freeswitch.esl.client.transport.event.EslEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telemune.vcc.esl.Esl;
import com.telemune.vcc.esl.common.AppConfig;
import com.telemune.vcc.esl.sipParser.SipUri;
import com.telemune.vcc.esl.sipParser.Uri;

public class TSSJavaUtil {

	private static Logger logger = LoggerFactory.getLogger(TSSJavaUtil.class);
	
	public static String getReason(EslEvent event) {
		String reason = "unavailable";
		String temp = "";
		String[] arr = null;

		try {
			if (event.getEventHeaders().get("variable_sip_h_Diversion-1") != null) {
				temp = URLDecoder.decode(event.getEventHeaders().get("variable_sip_h_Diversion-1"), "UTF-8");
				temp = temp.substring(temp.indexOf(";") + 1, temp.length());
				arr = temp.split(";");
				for (String val : arr) {
					if (val.indexOf("reason") != -1) {
						reason = val.substring(val.indexOf("=") + 1, val.length());
						break;
					}
				}
			} 
			else if(event.getEventHeaders().get("variable_sip_history_info")!=null)
			{
				String sipString=event.getEventHeaders().get("variable_sip_history_info");
				String[] sipArray=sipString.split(",");
				String sip=null;
				for(int i=sipArray.length-1;i>=0;i--)
				{
					try
					{
						sip=Uri.decode(sipArray[i]);
					}
					catch(Exception ex)
					{
						logger.error("Exception occurred while decoding sip string. Error["+ex+"]");
						sip=sipArray[i];
					}
					if(sip.contains("cause="))
					{
						temp = sip.substring(sip.indexOf("cause") + 6, sip.length());
						if (temp.indexOf(";") != -1)
							temp = temp.substring(0, temp.indexOf(";"));
						if (temp.indexOf("?") != -1)
							temp = temp.substring(0, temp.indexOf("?"));
						if (temp.indexOf(">") != -1)
							temp = temp.substring(0, temp.indexOf(">"));
						reason = AppConfig.config.getString("cause_code." + temp,
								AppConfig.config.getString("default_reason", "unavailable"));
						break;
					}
				}
			}
			else if (event.getEventHeaders().get("variable_sip_req_params")!=null && event.getEventHeaders().get("variable_sip_req_params").contains("cause") ){
					temp = URLDecoder.decode(event.getEventHeaders().get("variable_sip_req_params"), "UTF-8");
					if(temp.contains(";")){
						arr = temp.split(";");
						for (String val : arr) {
							if (val.indexOf("cause") != -1) {
								reason = AppConfig.config.getString("cause_code."+val.substring(val.indexOf("=") + 1, val.length()));
								break;
							}
						}
					}else{
						reason = AppConfig.config.getString("cause_code."+temp.substring(temp.indexOf("=") + 1, temp.length()));
					}
			}
			else{
				reason=AppConfig.config.getString("default_reason", "unavailable");
			}
			logger.info("calling [" + event.getEventHeaders().get("Caller-Caller-ID-Number") + "] called ["
					+ getbPartyNumber(event) + "] event [" + event.getEventHeaders().get("Event-Name")
					+ "] reason [" + reason + "]");
		} catch (Exception e) {
			logger.error("calling [" + event.getEventHeaders().get("Caller-Caller-ID-Number") + "] called ["
					+ getbPartyNumber(event) + "] event [" + event.getEventHeaders().get("Event-Name")
					+ "] Error while getting reason: " + e.getMessage());
			reason = "unavailable";
		}
		return reason;
	}
	
	
	/*
	 * Changes done by Richard Bux on 13th November 2018 
	 * to handle sip_history_info parameter accurately 
	 * and other parameters more efficiently.
	 */
	public static String getbPartyNumber(EslEvent event) {
		String sipString = "";
		String bPartyNo = "";
		try {
			if (event.getEventHeaders().get("variable_sip_h_Diversion-1") != null) {
				sipString = event.getEventHeaders().get("variable_sip_h_Diversion-1");
				logger.debug("Diversion parameter >> " +sipString);
			}else if(event.getEventHeaders().get("variable_sip_history_info") != null){
				sipString = event.getEventHeaders().get("variable_sip_history_info");
				String[] sipArray=sipString.split(",");
				if(sipArray.length>2)
					sipString=sipArray[sipArray.length-2];
				logger.debug("History_Info parameter >> " +sipString);
			}else{
				sipString = event.getEventHeaders().get("variable_sip_to_user");
				logger.debug("sip_to_user parameter >> "+sipString);
			}
			
			SipUri.ParsedSipContactInfos parsedSipContactInfos = SipUri.parseSipContact(sipString);
			bPartyNo = SipUri.getPhoneNumber(parsedSipContactInfos);
			
			if (bPartyNo == null) {
				if (sipString.contains("@"))
					bPartyNo = sipString.substring(sipString.indexOf(":") + 1, sipString.indexOf("@"));
				if (bPartyNo.contains("phone-context"))
					bPartyNo = bPartyNo.substring(0, bPartyNo.indexOf(";"));
			}

			if (bPartyNo.startsWith("+"))
				bPartyNo = bPartyNo.substring(1, bPartyNo.length());
			if (bPartyNo.startsWith("00"))
				bPartyNo = bPartyNo.substring(2, bPartyNo.length());
			
			logger.debug("Fsw inbound barty:[ " + bPartyNo+" ]");
		} catch (Exception e) {
			logger.error("Fsw inbound error while getting bparty: " + e.getMessage());
		}
		return bPartyNo;
	}
	
	public static String getaParty(String aParty) {
		try
		{
			if (aParty.startsWith("+"))
				aParty = aParty.substring(1, aParty.length());
		}
		catch(Exception e)
		{
			logger.error("Exception occurred while getting aparty number. Error["+e+"]");
		}
		return aParty;
	}
	
	public static void getServerId(Esl esl) {
		try {
			esl.setServerId(AppConfig.config.getString(InetAddress.getLocalHost().getHostName(), "1"));
		} catch (Exception e) {
			esl.setServerId("N");
		}
	}

	public static String getCurrentTime() {
		String currentTime = "";
		try {
			currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
		} catch (Exception e) {

		}
		return currentTime;
	}

	public static String getFormattedTime(String date) {

		String formattedDate = "";
		try {
			String newDate = date.substring(0, date.length() - 6);
			long epoch = Long.parseLong(newDate);
			Date unformattedDate = new Date(epoch * 1000);
			formattedDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(unformattedDate);
			// logger.info("Time : " + formattedDate);
		} catch (Exception e) {
			logger.error("Exception while getting time from epoc Time " + e.getMessage());
		}
		return formattedDate;
	}
	
	public static String getUniqueId(Context ctx, EslEvent event) {
		String args = "";
		args = event.getEventHeaders().get("Unique-ID");
		return args;
	}
	
	
}
