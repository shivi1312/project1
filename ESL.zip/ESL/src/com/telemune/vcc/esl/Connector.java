package com.telemune.vcc.esl;

public interface Connector {
	
}
