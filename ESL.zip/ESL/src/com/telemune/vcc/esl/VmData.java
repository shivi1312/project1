package com.telemune.vcc.esl;
import org.freeswitch.esl.client.transport.event.EslEvent;
import org.freeswitch.esl.client.internal.Context;

@SuppressWarnings("serial")
public class VmData implements java.io.Serializable {
        private Context ctx;
        private EslEvent event;
	public Context getCtx(){
                return ctx;
        }
        public void setCtx(Context ctx){
                this.ctx=ctx;
        }
        public EslEvent getEvent(){
                return event;
        }
        public void setEvent(EslEvent event){
                this.event = event;
        }
	
}
