package com.telemune.vcc.esl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telemune.vcc.esl.common.AppConfig;

public class EslWorker implements Runnable {
	private static Logger logger = LoggerFactory.getLogger(EslWorker.class);
	private EslConnector eslConnector;

	public EslWorker(EslConnector eslConnector) {
		this.eslConnector = eslConnector;
	}

	@Override
	public void run() {
		while (true) {
			try {
				if (!eslConnector.isActive()){
					logger.info("Fsw inbound connection is not created yet");
					eslConnector.inboundClient = null;
					eslConnector.connect();
				} else {
					logger.debug("Fsw inbound connection is already created");
				}
				Thread.sleep(AppConfig.config.getInt("fsw.inbound.retry",2000));
			} catch (Exception e) {
				try{
					Thread.sleep(AppConfig.config.getInt("fsw.inbound.retry",2000));
				}catch(Exception ee){}
				logger.error("Fsw inbound connection error: "+e.getMessage());
			}
		}
	}

}

