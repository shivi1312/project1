package com.telemune.vcc.esl;

import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.telemune.vcc.esl.common.AppConfig;

import LCheck.LCheck;

@SuppressWarnings("unused")
public class Main {
	private static Logger logger = LoggerFactory.getLogger(Main.class);
	public static LCheck lCheck = null;
	public static void main(String[] args) {
		
		
		String SITE="Airtel";
		String VERSION="3.0.1.4";
		try{
			if(args[0].equalsIgnoreCase("-v"))
			{
				System.out.println("\n******************************************************************************************");
				System.out.println("\n                               Site "+SITE);
				System.out.println("\n                               Version "+VERSION);
				System.out.println("\n******************************************************************************************");
				System.out.println("\n");
				System.exit(1);
			}
		}
		catch(Exception Arrayoutex)
		{
			
		}
		/*PropertyConfigurator.configure("properties/log4j.properties");*/
		
		PropertyConfigurator.configureAndWatch(
				"properties/log4j.properties", Long
						.parseLong(AppConfig.config.getString(
								"LOGGER_FILE_REFRESH_INTERVAL", "1000")));
		
		EslConnector eslConnector = new EslConnector();
		logger.info("Fsw inbound connection going to create !");
		new Thread(new EslWorker(eslConnector)).start();
		new Thread(new Taker()).start();
		new Thread(new VmTaker()).start();
		lCheck = new LCheck();
		new Thread(lCheck).start();
	}
}
