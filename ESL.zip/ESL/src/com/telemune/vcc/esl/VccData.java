package com.telemune.vcc.esl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import com.telemune.vcc.esl.common.AppConfig;

public class VccData {
        private static Logger logger = LoggerFactory.getLogger(VccData.class);
	public static final ArrayBlockingQueue<Esl> eslReqQue = new ArrayBlockingQueue<Esl>(
	AppConfig.config.getInt("QUEUE_SIZE",200000));

	public static final ArrayBlockingQueue<VmData> eslVmReqQue = new ArrayBlockingQueue<VmData>(
        AppConfig.config.getInt("VM_QUEUE_SIZE",200000));

	public final static ThreadGroup threadGroup = new ThreadGroup("worker");
	public static int busyCount = 0;
	public static ExecutorService executor = Executors.newFixedThreadPool(
			AppConfig.config.getInt("fsw.worker",20),new ThreadFactory(){
		public Thread newThread(Runnable r) {
			return new Thread(threadGroup, r);
		}
	});
	
	public final static ThreadGroup vmThreadGroup = new ThreadGroup("VmHandler");
	public static ExecutorService vmExecutor = Executors.newFixedThreadPool(
                        AppConfig.config.getInt("fsw.vm.worker",20),new ThreadFactory(){
                public Thread newThread(Runnable r) {
                        return new Thread(vmThreadGroup, r);
                }
        });

	public static String product_module = AppConfig.config.getString("fsw.product.module","VCC_ESL");
	public boolean worker = true;
}
