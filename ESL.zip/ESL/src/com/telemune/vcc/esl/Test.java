package com.telemune.vcc.esl;

import java.net.InetSocketAddress;

import org.freeswitch.esl.client.inbound.Client;
import org.freeswitch.esl.client.inbound.IEslEventListener;
import org.freeswitch.esl.client.internal.Context;
import org.freeswitch.esl.client.internal.IModEslApi;
import org.freeswitch.esl.client.transport.event.EslEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Throwables;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.lang.time.DateUtils;

@SuppressWarnings("unused")
public class Test {
	private static Logger logger = LoggerFactory.getLogger(Main.class);

	public static void main(String[] args) throws Exception{
		String start = "2016-11-11 12:46:35";
		String end = "2016-11-11 12:47:35";
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date d1 = null;
                Date d2 = null;
		d1 = format.parse(start);
              	d2 = format.parse(end);
		System.out.println(("time: "+(d2.getTime() - d1.getTime()) / DateUtils.MILLIS_PER_SECOND));

		System.out.println();
		getDuration("2016-11-11 12:46:35","2016-11-11 12:47:35");	
	}
	public static String getDuration(String start, String end){
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date d1 = null;
                Date d2 = null;
                long diffSeconds = 0;
                try {
                        d1 = format.parse(start);
                        d2 = format.parse(end);
			diffSeconds = (d2.getTime() - d1.getTime()) / DateUtils.MILLIS_PER_SECOND;
                        System.out.println("call duration: "+diffSeconds);
                }catch(Exception e){
                        e.printStackTrace();
                }
                return String.valueOf(diffSeconds);
        }
}
	
