package org.freeswitch.esl.client.outbound;

public interface IClientHandlerFactory {
	IClientHandler createClientHandler();
}
