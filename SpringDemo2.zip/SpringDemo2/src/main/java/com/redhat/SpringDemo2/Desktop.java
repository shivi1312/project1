package com.redhat.SpringDemo2;

public class Desktop implements Computer {
	public void compile()
	{
		System.out.println("Desktop with compiler!!!");
	}
}
