package com.redhat.SpringDemo2;

import org.springframework.stereotype.Component;

@Component
public class Student {
	
	private int age;
	private String name;
	private Computer com;
	private Laptop laptop;
	private Desktop desktop;
	
	  public Student() 
	  {
		  System.out.println("Student constuctor!!!"); 
	  }
	  
	  
	 
		/*
		 * public Student(int age,String name) { this.name=name; this.age = age; }
		 */



public void code()
 {
	 System.out.println("lets code!!!!!");
	 com.compile();
 }

 
 
public String getName() {
	return name;
}



public void setName(String name) {
	this.name = name;
}



public Desktop getDesktop() {
	return desktop;
}

public void setDesktop(Desktop desktop) {
	this.desktop = desktop;
}

public Laptop getLaptop() {
	return laptop;
}

public void setLaptop(Laptop laptop) {
	this.laptop = laptop;
}

public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}

public Computer getCom() {
	return com;
}

public void setCom(Computer com) {
	this.com = com;
}


 
 
}
