package com.redhat.SpringDemo2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App 
{
    public static void main( String[] args )
    {
    	//BeanFactory factory=new XmlBeanFactory(new FileSystemResource("spring.xml"));
    	ApplicationContext factory = new ClassPathXmlApplicationContext("Spring.xml"); // to use this we have to place Spring.xml file at class path.
    	//ApplicationContext will simply create a spring container for you. All the objects and all the processing you do in java happens in JVM. so,
    	// In JVM we having a special container which we'll call as spring container which will have spring bean.
    	// Bean -> Any class which has certain variables and every variable has some getters and setters is normally referred as bean.
    	// Spring container starts it will check spring.xml file and create the objects of all the Singleton beans mention there.
    	Student st1=(Student)factory.getBean("st",Student.class);
    	// getBean method ask to spring container give me the object of that bean whose id is 'st'.
    	st1.code();
    	st1.setAge(10);
    	Student st2=(Student)factory.getBean("st",Student.class);
    	// both sop get same result if the bean scope is singleton and if bean scope is prototype then result will not same.
    	System.out.println("age="+st2.getAge()+"   "+st2);
    	System.out.println("age="+st1.getAge()+"   "+st1);
    	
    	// ** In case of singleton bean spring container will automatically provide bean object whether we ask for it or not.
    	// ** In case of prototype bean spring container will provide bean object only when we ask for it.
    	// ** When spring container will create/start it will only create Singleton bean objects. Other beans objects will be created when we ask for them.
    }
}
