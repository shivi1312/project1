package com.redhat.SpringDemo2;

public class Laptop implements Computer {
	public void compile()
	{
		System.out.println("Laptop with compiler!!!");
	}
}
