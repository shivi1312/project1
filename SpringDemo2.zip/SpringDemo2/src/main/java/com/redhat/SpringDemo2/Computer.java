package com.redhat.SpringDemo2;

public interface Computer {
	void compile();
}
