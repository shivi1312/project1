package com.telemune.smscapi.serviceImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.telemune.smscapi.config.GlobalParams;
import com.telemune.smscapi.model.GmatMsg;
import com.telemune.smscapi.model.SmsgBean;
import com.telemune.smscapi.repository.GmatRepository;
import com.telemune.smscapi.service.SmsgService;


@Service
public class SmscServiceImpl implements  SmsgService  {
	@Autowired
    GmatRepository gmatRepository;
	
	@Autowired(required = true)
	private GlobalParams globalParams;

	private static final Logger logger = LogManager.getLogger(SmscServiceImpl.class);
	public void sendSMS(SmsgBean smsgBean) {
		
	
		try {
         //   makeCallLogs(smsgBean);
			GmatMsg msg = new GmatMsg();
			msg.setOrigin(smsgBean.getOrigination());
			msg.setDestination(smsgBean.getDestination());
			msg.setMessage(smsgBean.getMessage());
			msg.setSubmitTime("");
		
			gmatRepository.save(msg);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public synchronized void makeCallLogs(SmsgBean smsgbean) {
		try {
			globalParams.getFileLogWriter().writeLog(smsgbean.toString());
			logger.info("Details inserted into File"+ smsgbean.toString());
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}
	
	
		}

   

	


