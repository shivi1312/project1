package com.telemune.smscapi.model;

public class ResponseBean {

	String responseCode;
	String responseMsg;
	
	
	
	public ResponseBean(String responseCode, String responseMsg) {
		
		this.responseCode = responseCode;
		this.responseMsg = responseMsg;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMsg() {
		return responseMsg;
	}
	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}
	@Override
	public String toString() {
		return "ResponseBean [responseCode=" + responseCode + ", responseMsg=" + responseMsg + "]";
	}
	
	
}
