package com.telemune.smscapi.model;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.annotations.DynamicInsert;

@Entity
@DynamicInsert
@Table(name = "gmat_message_store")
public class GmatMsg {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "REQUEST_ID")
	private Integer requestId;

	public GmatMsg() {
        super();
    }

	@NotBlank
	@Size(max = 15)
	@Column(name = "ORIGINATING_NUMBER")
	private String origin;

	@NotBlank
	@Size(max = 15)
	@Column(name = "DESTINATION_NUMBER")
	private String destination;


	@Size(max = 400)
	@Column(name = "MESSAGE_TEXT")
	private String message;


	@Size(max = 120)
	@Column(name = "MESSAGE_TYPE")
	private String msgType;

	@Size(max = 40)
	@Column(name = "SUBMIT_TIME")
	private String submitTime;

	
	
	public Integer getRequestId() {
		return requestId;
	}


	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}


	public String getOrigin() {
		return origin;
	}


	public void setOrigin(String origin) {
		this.origin = origin;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	

	public String getMsgType() {
		return msgType;
	}


	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}


	public String getSubmitTime() {
		
		
		return submitTime;
	}


	public void setSubmitTime(String submitTime) {
		String pattern = "yyyy-MM-dd HH:mm:ss";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		submitTime= simpleDateFormat.format(new Date());
		this.submitTime = submitTime;
	}


	@Override
	public String toString() {
		return "GmatMsg [requestId=" + requestId + ", origin=" + origin + ", destination=" + destination + ", message="
				+ message + ", msgType=" + msgType + "]";
	}



	
	



	
	
	
}





