package com.telemune.smscapi.dao;

import com.telemune.smscapi.config.GlobalParams;
import com.telemune.smscapi.model.SmsgBean;
import com.telemune.smscapi.serviceImpl.SmscServiceImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class GmatMessageStoreImpl {
	private final JdbcTemplate jdbcTemplate;
	private static final Logger logger = LogManager.getLogger(GmatMessageStoreImpl.class);
	@Autowired(required = true)
	private GlobalParams globalParams;

	@Autowired
	public GmatMessageStoreImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int addGmatMessageStore(SmsgBean smsgBean) {
		try {
			String origination = smsgBean.getOrigination();

			String destination = smsgBean.getDestination();
			String message = smsgBean.getMessage();
			if (origination != null && destination != null) {
				// char[] chars=origination.toCharArray();
				if (origination.matches("[A-Za-z0-9]+")) {
					if (destination.matches("[0-9]+")) {
						if (message.length() <= 380) {

							makeCallLogs(smsgBean);
							int lastchar = smsgBean.getDestination().length();
							String sql = "INSERT into unip.gmat_message_store_"
									+ smsgBean.getDestination().substring(lastchar - 1, lastchar)
									+ "(DESTINATION_NUMBER,ORIGINATING_NUMBER,MESSAGE_TEXT,submit_time) VALUES (?,?,?,now())";

							return jdbcTemplate.update(sql, smsgBean.getDestination(), smsgBean.getOrigination(),
									smsgBean.getMessage());
						} else {
							logger.info("Message length invalid");
						}

					} else {
						logger.info("destination number is invalid");
					}

				} else {
					logger.info("origination invalid!");
				}

			}

			else {

				logger.info("origination or destination is null");
			}

		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public synchronized void makeCallLogs(SmsgBean smsgbean) {
		try {
			globalParams.getFileLogWriter().writeLog(smsgbean.toString());
			logger.info("Details inserted into File" + smsgbean.toString());
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

//	public void validate(SmsgBean smsgbean) {
//	    String origination = (smsgbean.getOrigination());
//	    
//	    String destination =(smsgbean.getDestination());
//	   if(origination != null && destination != null) {
//		  // char[] chars=origination.toCharArray();
//		if(origination.matches("[A-Za-z0-9]+"))
//		{
//		if(destination.matches("[0-9]"))
//			addGmatMessageStore(smsgbean);
//		}
//	   }

}
