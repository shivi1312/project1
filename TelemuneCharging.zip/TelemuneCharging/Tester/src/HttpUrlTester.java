package com.telemune.crbt.charging.tester;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.Date.*;

public class HttpUrlTester{
		
//	String url = "http://192.168.102.242:22022/openapi/v1/for_crbt";
	private String url;// = "http://10.168.3.61:18080/HttpUrlDemo/HttpTesterResponse";
	private String requestBody; // = "13,332211,,,609020204388755,24000295,,20170801123209,1,,,,,,,01,00,,,,,,,,,,,,,,,,,,,,,\n";
	//"13,<rec_number>,,,<imsi>,<msisdn>,,<yyyymmddhh24miss>,<duration>,,,,,,,01,00,,,,,,,,,,,,,,,,,,,,,<msc_number>\n"
	Scanner sc = new Scanner(System.in);

	private	String recNumber,imsi,msisdn,duration,reqType,mscNumber,date;

	public static void main(String[] args){
		try{
			System.out.println("\nTesting - Send Http POST request");
			HttpUrlTester http = new HttpUrlTester();
			System.out.println("Enter the url you want to hit :");
			http.url = http.sc.nextLine();
			http.acceptDetails();
			http.sendPost();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public void sendPost(){	
		try{	
			URL u = new URL(url);
			HttpURLConnection con = (HttpURLConnection)u.openConnection();
			requestBody = "13,"+recNumber+",,,"+imsi+","+msisdn+",,"+date+","+duration+",,,,,,,"+reqType+",00,,,,,,,,,,,,,,,,,,,,,"+mscNumber+"\n";
			int reqLength = requestBody.length();
//			System.out.println(length);
//			String reqLength = length.toString();
	
			//add request header
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type","text/cdr");
			con.setRequestProperty("Content-Length", ""+reqLength);
			
			con.setDoOutput(true);
			OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream());
			writer.write(requestBody);
			writer.flush();
			writer.close();

			int responseCode = con.getResponseCode();
			System.out.println("\nSending POST request to URL : "+ url);
			System.out.println("Response Code : "+responseCode);
			
			if(responseCode == 200){
				getResultFromInputStream(con.getInputStream());
			}
			else{
				System.out.println("error : "+responseCode);
			}
		}
		catch(Exception ex){
			ex.printStackTrace();
		}	
	}
	
	private void getResultFromInputStream(InputStream inputStream){
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			String inputLine;
			StringBuffer response = new StringBuffer();
			
			while((inputLine= reader.readLine())!=null){
				response.append(inputLine);
			}
			reader.close();
		
			//print result
			System.out.println(response.toString());			
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}

	private void acceptDetails(){
		
		try{
		//Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter rec_number or press enter for skip :"); // optional
		recNumber = sc.nextLine();
		System.out.println("Enter imsi number or press enter for skip :");
		imsi = sc.nextLine();
		System.out.println("Enter msisdn :");
		msisdn = sc.nextLine();
		System.out.println("Enter duration - quantity of charging events or press enter for skip (by defualt - 1) ");
		duration = sc.nextLine();
		System.out.println("Enter request type :");
		System.out.println(" 01 - for subscription request");
		System.out.println(" 02 - for tone request");
		reqType = sc.nextLine();
		System.out.println("Enter msc_number or press enter for skip :"); // optional
		mscNumber = sc.nextLine();
		
		if("".equals(duration)){
			duration = "1";
		} 

		if("".equals(msisdn)){
			System.out.println("msisdn cannot be blank or null");
			acceptDetails();
		}
		if("".equals(reqType)){
			System.out.println("request type cannot be blank or null");
			acceptDetails();
		}

		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddkmmss");//yyyymmddhh24miss
		Date dt = new Date();
		date = dateFormat.format(dt);
		//System.out.println(date);
		}
		catch(Exception ex){
			ex.printStackTrace();
			acceptDetails();
		}

	}
}
