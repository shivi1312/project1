package com.telemune.crbt.charging.tester;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import commonutil.TLVAppInterface;


public class ContinuousTLVHitsTester {

	TLVAppInterface send_request = null;
	DataOutputStream stream_send_data;
	ByteArrayOutputStream send_buf = null;
	String chargingIP=null;
    int chargingPort=-1;
    public int timeout=15; // here multiply with 1000 not required bcz TLV jar done it internally
    public static int REQTYPE_TAG = 12;
	public static int MSISDN_TAG = 1;
	public static int SUB_TYPE = 8;
	public static int RBTCODE_TAG = 4;
	public static int FMSISDN_TAG = 5;
	public static int INTERFACE_TAG = 6;
	public static int RESPONSE_TAG = 7;
	public static int AMOUNT_TAG = 11;
	public static int ACTION_TAG = 2;
	public static int TARIFFID_TAG = 3;
	public static int PACKID_TAG = 14;
	
	public ContinuousTLVHitsTester() {
		
		if( send_request == null )
		{
        	send_request = new TLVAppInterface();
		}
	}
	
	public static void main(String[] args) {
		System.out.println("\n\n\t\t\t\t\t================================== TESTER ==================================");
		try {
			ContinuousTLVHitsTester tlvTester = new ContinuousTLVHitsTester();
			tlvTester.sendAndReceive();
		} catch (Exception e) {
			System.out.println("Exception in main method : "+e);
			e.printStackTrace();
		}
		
	}
	
	public void sendAndReceive() {
		int send_requestLen = 0;
		int tempResult=-1;
		try {
			send_request.setServerIP("10.168.3.61");
			send_request.setServerPort(10101);
			send_request.setSocketTimeOut(timeout); // here multiply with 1000 not required bcz TLV jar done it internally
			
			for (int i = 0; i < 100; i++) {
				System.out.println("\n\n\t\t\t\t\t================================== Request Start ==================================");
				//send_request.setData(Global.REQID_TAG, data_object.getO_reqid());// added by Avishkar on 11.01.2019
				send_request.setData(MSISDN_TAG,"18768111301");
				send_request.setData(TARIFFID_TAG,3); // here we are sending chgCode directly instead of tarridId
				send_request.setData(ACTION_TAG,1);
				send_request.setData(SUB_TYPE,"P");
				send_request.setData(INTERFACE_TAG,"T");
				send_request.setData(FMSISDN_TAG, "1212121212");
				send_request.setData(RBTCODE_TAG,"25720");
				send_request.setData(REQTYPE_TAG,1);
				send_request.setData(PACKID_TAG, -1);
				//send_request.setData(Global.REDIRECT_TAG, "Redirect");
				send_request.setData(AMOUNT_TAG, 35);
				System.out.println("......Request parameters are set...... ");
				send_buf = new ByteArrayOutputStream();
				send_request.encode(send_buf);
				System.out.println("writing Info buf size="+send_requestLen);
				send_requestLen = send_buf.size();
				System.out.println("______Going To Send Charging Request_______");
				send_request.send();
				send_request.receive();
				tempResult = Integer.parseInt(send_request.getData(RESPONSE_TAG));
				System.out.println("______Response from Charging : Result["+tempResult+"] ________");
				System.out.println("\n\n\t\t\t\t\t================================== Request Complete ==================================");
			}
			
			
		} catch (Exception e) {
			System.out.println("Exception occurred in sendAndReceive method : "+e);
			e.printStackTrace();
			// TODO: handle exception
		}
		
	}
}
