package com.telemune.crbt.charging.tester;
import java.util.LinkedHashMap;
import java.io.InputStreamReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.net.Socket;
import commonutil.TLVAppInterface;
import java.util.*;
import java.text.*;
public class LoadTest
{
	static  Socket sock = null;
	static DataInputStream reader = null;
	static  DataOutputStream dataOutputStream = null;
	public static int REQTYPE_TAG = 12;
	public static int MSISDN_TAG = 1;
	public static int SUB_TYPE = 8;
	public static int RBTCODE_TAG = 4;
	public static int FMSISDN_TAG = 5;
	public static int INTERFACE_TAG = 6;
	public static int RESPONSE_TAG = 7;
	public static int AMOUNT_TAG = 11;
	public static int ACTION_TAG = 2;
	public static int TARIFFID_TAG = 3;
	public static int PACKID_TAG = 14;
	//public static int REFERENCE_TAG = 9;
	public static LinkedHashMap<String,String> lhm = new LinkedHashMap<String,String>();
	static String path = System.getProperty("user.dir");


	public static void main(String arg[])
	{

                InputStreamReader r = new InputStreamReader(System.in);
                BufferedReader br = new BufferedReader(r);
                String input = null;


		String requestType 	= "1";
		String subType 		= "P";
		String tariff 		= "8:30;129:24";
		String msisdn 		= "8130428822";
		String action 		= "1";
		String fmsisdn 		= "91991919191";
		String pack 		= "1";
		String rbtcode 		= "32244";
		String interFace 	= "T";
		String IP 		= "10.168.3.75";
		int PORT 		= 9990;

		System.out.println("IP:["+IP+"] PORT:["+PORT+"] requestType:["+requestType+"] msisdn:["+msisdn+"] subType:["+subType+"] rbtcode:["+rbtcode+"] fmsisdn:["+fmsisdn+"] interFace:["+interFace+"] action:["+action+"] tariff:["+tariff+"] pack:["+pack+"]");
		System.out.println("");

                
		int cnt = Integer.parseInt(arg[0]);
		for( int i=1; i<=cnt; i++)
		{
			send(IP,PORT,requestType,msisdn,subType,rbtcode,fmsisdn,interFace,action,tariff,pack);
			receive();
			if( sock != null )
                        {
                                try
                                {
                                }
                                catch(Exception e)
                                {
                                        System.out.println("Exception while closing socket !!");
                                }
                        }

			try
			{
				Thread.sleep(2);
			}
			catch(Exception e){e.printStackTrace();}
		}
	}

	public static void send( String IP, int PORT,String requestType, String msisdn, String subType, String rbtcode, String fmsisdn, String interFace, String action, String tariff, String pack)
	{
//		System.out.println("IP:["+IP+"] PORT:["+PORT+"] requestType:["+requestType+"] msisdn:["+msisdn+"] subType:["+subType+"] rbtcode:["+rbtcode+"] fmsisdn:["+fmsisdn+"] interFace:["+interFace+"] action:["+action+"] tariff:["+tariff+"] pack:["+pack+"]");
		try
		{
			sock = new Socket(IP,PORT);

			TLVAppInterface send_request = new TLVAppInterface();
			ByteArrayOutputStream send_buf = new ByteArrayOutputStream();

			send_request.setData(REQTYPE_TAG,requestType); // Check Bal and Deduct
			send_request.setData(MSISDN_TAG,msisdn);
			send_request.setData(SUB_TYPE,subType);


			send_request.setData(RBTCODE_TAG,rbtcode);
			send_request.setData(FMSISDN_TAG,fmsisdn);
			send_request.setData(INTERFACE_TAG,interFace);

			send_request.setData(ACTION_TAG,action);
			send_request.setData(TARIFFID_TAG,tariff);
			send_request.setData(PACKID_TAG,pack);

			send_request.encode(send_buf);
			//System.out.println("Socket:["+sock.toString()+"]");

			int send_requestLen = send_buf.size();
			if (sock.isClosed())
			{
				System.out.println("Socket is closed !!");
			}

			dataOutputStream = new DataOutputStream(sock.getOutputStream());
			byte[] len=new byte[4];
			len[3]=(byte)(send_requestLen );
			len[2]=(byte)((send_requestLen >> 8) );
			len[1]=(byte)((send_requestLen >> 16));
			len[0]=(byte)((send_requestLen >> 24));
			dataOutputStream.write(len,0, 4);
			System.out.println("Data sent to IP:["+IP+"] PORT:["+PORT+"]");
			dataOutputStream.write(send_buf.toByteArray(), 0, send_buf.toByteArray().length);
			System.out.println("");

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Exception while sending :["+e.getMessage()+"]");
		}

	}

	//public static void receive( Date date, SimpleDateFormat dateFormat)
	public static void receive( )
	{
		try
		{
			reader = new DataInputStream(sock.getInputStream());
			TLVAppInterface tcp_req = new TLVAppInterface();
			if (sock.isClosed())
			{
				System.out.println("Socket closed");
				return;
			}
			ByteArrayInputStream inbuf = null;
			byte dataBuf1[] = new byte[4];
			int dataLen = 0;
			try
			{
				if( reader.read(dataBuf1,0,4) == -1 )
				{
					System.out.println("reading reachd to end");
					try
					{
						sock.close();
						System.out.println("Destroy");
						System.out.println("socket closed");
						return;
					}
					catch(Exception e)
					{
						System.out.println(e);
					}

				}

				int test=0;
				dataLen = dataLen | (dataBuf1[0] << 24);
				dataLen = dataLen  | (dataBuf1[1] << 16);
				dataLen = dataLen | (dataBuf1[2] << 8);
				test=(0x000000ff & dataBuf1[3]);
				dataLen = dataLen | test;
			}
			catch (Exception e)
			{
				System.out.println("Getting exception in reading...."+e.toString());
			}
			byte dataBuf[] = new byte[dataLen];

			reader.read(dataBuf, 0, dataLen);

			inbuf = new ByteArrayInputStream(dataBuf);

			tcp_req.decode(inbuf,dataLen);

			Date date = new Date();
	                SimpleDateFormat dateFormat = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
			
			String currDate = dateFormat.format(date);		
			//System.out.println("Today's date is: "+currDate);

			System.out.println("\n "+currDate+" REQUEST_TYPE:["+tcp_req.getData(REQTYPE_TAG)+"] MSISDN:["+tcp_req.getData(MSISDN_TAG)+"] SUB_TYPE:["+tcp_req.getData(SUB_TYPE)+"] RBT_CODE:["+tcp_req.getData(RBTCODE_TAG)+"] FMSISDN:["+tcp_req.getData(FMSISDN_TAG)+"] INTERFACE_TAG:["+tcp_req.getData(INTERFACE_TAG)+"] RESPONSE_TAG:["+tcp_req.getData(RESPONSE_TAG)+"] AMOUNT_TAG:["+tcp_req.getData(AMOUNT_TAG)+"] ACTION_TAG:["+tcp_req.getData(ACTION_TAG)+"] TARIFFID_TAG:["+tcp_req.getData(TARIFFID_TAG)+"] PACKID_TAG:["+tcp_req.getData(PACKID_TAG)+"]");

			//System.out.println("REQUEST_TYPE:["+tcp_req.getData(REQTYPE_TAG)+"] MSISDN:["+tcp_req.getData(MSISDN_TAG)+"] SUB_TYPE:["+tcp_req.getData(SUB_TYPE)+"] RBT_CODE:["+tcp_req.getData(RBTCODE_TAG)+"] FMSISDN:["+tcp_req.getData(FMSISDN_TAG)+"] INTERFACE_TAG:["+tcp_req.getData(INTERFACE_TAG)+"] RESPONSE_TAG:["+tcp_req.getData(RESPONSE_TAG)+"] AMOUNT_TAG:["+tcp_req.getData(AMOUNT_TAG)+"] ACTION_TAG:["+tcp_req.getData(ACTION_TAG)+"] TARIFFID_TAG:["+tcp_req.getData(TARIFFID_TAG)+"] PACKID_TAG:["+tcp_req.getData(PACKID_TAG)+"]............................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................");

		}
		catch(Exception e)
		{
			System.out.println("Exception while receiving :["+e.getMessage()+"]");
		}
	}
}
