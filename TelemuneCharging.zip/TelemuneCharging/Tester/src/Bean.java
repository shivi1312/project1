package com.telemune.crbt.charging.tester;

import java.io.Serializable;
 
public class Bean implements Serializable
{
	String requestType = null;
	String subType = null ;
	String tariff =  null;
	String msisdn =  null;
	String action =  null;
	String fmsisdn =  null;
	String pack =  null;
	String rbtcode =  null;
	String interFace =  null;
	String IP = null;
	int PORT = 0;
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getTariff() {
		return tariff;
	}
	public void setTariff(String tariff) {
		this.tariff = tariff;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getFmsisdn() {
		return fmsisdn;
	}
	public void setFmsisdn(String fmsisdn) {
		this.fmsisdn = fmsisdn;
	}
	public String getPack() {
		return pack;
	}
	public void setPack(String pack) {
		this.pack = pack;
	}
	public String getRbtcode() {
		return rbtcode;
	}
	public void setRbtcode(String rbtcode) {
		this.rbtcode = rbtcode;
	}
	public String getInterFace() {
		return interFace;
	}
	public void setInterFace(String interFace) {
		this.interFace = interFace;
	}
	public String getIP() {
		return IP;
	}
	public void setIP(String iP) {
		IP = iP;
	}
	public int getPORT() {
		return PORT;
	}
	public void setPORT(int pORT) {
		PORT = pORT;
	}

	@Override
	public String toString() {
		return "myclass [requestType=" + requestType + ", subType=" + subType
				+ ", tariff=" + tariff + ", msisdn=" + msisdn + ", action="
				+ action + ", fmsisdn=" + fmsisdn + ", pack=" + pack
				+ ", rbtcode=" + rbtcode + ", interFace=" + interFace + ", IP="
				+ IP + ", PORT=" + PORT + "]";
	}
}

