#!/bin/bash
echo ""  
DATE_TIME=`date +'%d-%m-%Y %H:%M:%S:%3N'`
echo "STARTED.......... DATE_TIME :["$DATE_TIME"]"

PID=""
PID=`ps -eaf |grep -w ChargingServer/MainClient |grep commonUtilTest.jar | awk {'print $2'}`

if [ "$PID" != "" ]; then
 echo "Charging is running with PID["$PID"]";
else
	echo "going to start"
	cd ../
	java -cp ./lib/*:./axis2-1.6.3/lib/*:./commonUtilTest.jar:.: chargingserver/MainClient  1>OUT 2>OUT &
	cd -
fi

SUB_SOURCE_TYPE=`grep "SUB_SOURCE_TYPE" ../properties/chargingserver.properties`
echo "Value of SUB_SOURCE_TYPE in properties :["$SUB_SOURCE_TYPE"]"

if [ "$SUB_SOURCE_TYPE" != 2 ]; then
	echo "going to kill and setting SUB_SOURCE_TYPE=2 in properties file "
	PID=`ps -eaf |grep -w ChargingServer/MainClient |grep commonUtilTest.jar | awk {'print $2'}`
	kill -9 $PID
	PID=""
	PID=`ps -eaf |grep -w ChargingServer/MainClient |grep commonUtilTest.jar | awk {'print $2'}`
	if [ "$PID" == "" ]; then
		 echo "Charging stoped";
	fi
	sed -i 's/'"$SUB_SOURCE_TYPE"'/SUB_SOURCE_TYPE=2/g' ../properties/chargingserver.properties
	echo "SUB_SOURCE_TYPE changed"

	cd ../
	java -cp ./lib/*:./axis2-1.6.3/lib/*:./commonUtilTest.jar:.: chargingserver/MainClient  1>OUT 2>OUT &
	cd -
	echo "restarted"
	PID=""
	PID=`ps -eaf |grep -w ChargingServer/MainClient |grep commonUtilTest.jar | awk {'print $2'}`
	
	if [ "$PID" != "" ]; then
		 echo "Charging started with PID["$PID"]";
	fi
	cd Tester
	java -cp lib/commonUtilTest.jar:.: com.telemune.crbt.charging.tester.TLVTester
	
fi

