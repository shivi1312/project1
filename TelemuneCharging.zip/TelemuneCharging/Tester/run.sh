#!/bin/bash
clear
echo ""  
DATE_TIME=`date +'%d-%m-%Y %H:%M:%S:%3N'`
echo "STARTED.......... DATE_TIME :["$DATE_TIME"]"
echo "========================================================== TEST CASES ============================================================"
echo "1. Checking SubType where RequestType=1 and SUB_SOURCE_TYPE=1"


read -p "Enter TestCase Srno : " input
#echo "Input ["$input"]"


case "$input" in

1)  echo "Running Testing Case 1"
	./casese/case_1.sh
    ;;
2)  echo "Testing Case 2"
	./casese/case_2.sh
    ;;
3)  echo  "Testing Case 3"
    ;;
*) echo "Invalid Input"
   ;;
esac


