package chargingserver;
public class LowBalanceException extends Exception
{
	public LowBalanceException()
	{
		super("Low Balance");
	}
	public LowBalanceException(String reason)
	{
		 super(reason);
	}
	public LowBalanceException(Exception exp)
	{
		 super(exp.getMessage());
	}

	@Override
	public String toString() 
	{
        	return super.toString();
    	}
}


