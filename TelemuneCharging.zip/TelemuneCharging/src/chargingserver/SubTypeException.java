package chargingserver;
public class SubTypeException extends Exception
{
	public SubTypeException()
	{
		super("Low Balance");
	}
	public SubTypeException(String reason)
	{
		 super(reason);
	}
	public SubTypeException(Exception exp)
	{
		 super(exp.getMessage());
	}

	@Override
	public String toString() 
	{
        	return super.toString();
    	}
}


