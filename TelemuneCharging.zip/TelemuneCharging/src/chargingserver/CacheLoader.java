package chargingserver;

import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;

import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;


public class CacheLoader implements Runnable
{
	static final Logger logger = Logger.getLogger("ChargingCache");

	int sleeptime = 30;

	public CacheLoader(int s1)
	{
		sleeptime = s1;
	}

	public void run()
	{
		Global.postpaidcheck = 0;

		while(true)
		{
			try
			{
				getCpIdRbtCode();
				getPrepadiCharges();
				getPostpaidCharges();
				getPrepaidProductCodes();//Added by Avishkar on 1.11.2018
				getPostpaidProductCodes();//Added by Avishkar 1.11.2018
				getPostpaidCheck();
				getCOS();
				
				try
				{
					Global.cacheThreadAlive=false;
					Thread.sleep(sleeptime*1000);
					Global.cacheThreadAlive=true;
				}
				catch(InterruptedException e)
				{
					logger.fatal("sleep exception "+e.toString());
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();

			}
		}  
	}

	private void getCpIdRbtCode()
	{
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		try
		{
			con = Global.conPool.getConnection();

			stmt = con.createStatement();
			String query = DBQuery.fetchCpIdRbtCode; //"select RBT_CODE,CONTENT_PROVIDER_CODE from crbt_rbt"; // Modified by Avishkar on 25.03.2019
			logger.info("query ::["+query+"]");

			rs = stmt.executeQuery(query);

			Hashtable<Integer, Integer>  cpIdRbtCode = new Hashtable<Integer, Integer>();
			while(rs.next())
			{
				logger.debug(" RBT_CODE ==="+rs.getInt(1)+"    CONTENT_PROVIDER_CODE ==="+rs.getInt(2));
				try
				{
					cpIdRbtCode.put(rs.getInt(1),rs.getInt(2));
				}catch(Exception see)
				{
					logger.error("Can't insert into HashTable",see);
				}
			}
			Global.cpCodeRbtCode = cpIdRbtCode; 
		}
		catch(Exception sqlE)
		{
			logger.error("Error in SQL:::"+sqlE);
		}
		finally
		{
			if( rs!= null) { try{	rs.close(); }catch(Exception e) {} }
			if( stmt!= null) { try{	stmt.close(); }catch(Exception e) {} }
			if( con!= null) { try{	con.close(); }catch(Exception e) {} }
			rs = null; stmt= null; con= null;
		}
	}


	private void getPrepadiCharges()
	{
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		try
		{
			con = Global.conPool.getConnection();
			stmt = con.createStatement();

			String query = DBQuery.fetchPrepaidCharges; //"select CHARGING_CODE,AMOUNT_PRE from CRBT_CHARGING_CODE"; // Modified by Avishkar on 25.03.2019
			logger.info("query ::["+query+"]");
			rs = stmt.executeQuery(query);

			//charges_prepaid.clear();
			Hashtable charges_prepaid  = new Hashtable();
	
			while(rs.next())
			{
				logger.info("Prepaid Code==="+rs.getInt(1)+"    Amount==="+rs.getDouble(2));
				try
				{	
					charges_prepaid.put(Integer.toString(rs.getInt(1)),rs.getDouble(2));
					logger.debug("inserted in hastable");
				}catch(Exception see)
				{
					logger.error("Can't insert into HashTable"+see.toString());
				}
			}
			Global.charges_prepaid = charges_prepaid;
		}
		catch(Exception sqlE)
		{
			logger.error("Error in SQL:::"+sqlE);
		}
		finally
		{
			if( rs!= null) { try{	rs.close(); }catch(Exception e) {} }
			if( stmt!= null) { try{	stmt.close(); }catch(Exception e) {} }
			if( con!= null) { try{	con.close(); }catch(Exception e) {} }
			rs = null; stmt= null; con= null;
		}
	}

	private void getPostpaidCharges()
	{
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		try
		{
			con = Global.conPool.getConnection();
			stmt = con.createStatement();

			String query = DBQuery.fetchPostpaidCharges; //"select CHARGING_CODE,AMOUNT_POST from CRBT_CHARGING_CODE"; // Modified by Avishkar on 25.03.2019
			logger.info("query ::["+query+"]");
			rs=stmt.executeQuery(query);

			//charges_postpaid.clear();
			Hashtable charges_postpaid = new Hashtable();

			while(rs.next())
			{
				logger.info("Postpaid Code =="+rs.getInt(1)+"      Amount==="+rs.getDouble(2));
				try
				{	
					charges_postpaid.put(Integer.toString(rs.getInt(1)),rs.getDouble(2));
					logger.debug("inserted in hastable");
				}catch(Exception see)
				{
					logger.error("Can't insert into HashTable"+see.toString());
				}
			}
			Global.charges_postpaid = charges_postpaid;

		}
		catch(Exception sqlE)
		{
			logger.error("Error in SQL:::"+sqlE);
		}
		finally
		{
			if( rs!= null) { try{	rs.close(); }catch(Exception e) {} }
			if( stmt!= null) { try{	stmt.close(); }catch(Exception e) {} }
			if( con!= null) { try{	con.close(); }catch(Exception e) {} }
			rs = null; stmt= null; con= null;
		}
	}
	
	/** @author avishkar on 1.11.2018
	 *  this method is used to get prepaidProductCodes against Charging_Code
	 *  specifically only for netOneSdp Charging
	 */
	private void getPrepaidProductCodes()
	{
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		try
		{
			con = Global.conPool.getConnection();
			stmt = con.createStatement();

			String query = DBQuery.fetchPrepaidProductCodes; //"select CHARGING_CODE,TARIFF_PRE from CRBT_CHARGING_CODE"; // Modified by Avishkar on 25.03.2019
			logger.info("query ::["+query+"]");
			rs=stmt.executeQuery(query);

			//charges_postpaid.clear();
			Hashtable product_code = new Hashtable(); 

			while(rs.next())
			{
				logger.info("[Prepaid]      Charging_Code =="+rs.getInt(1)+"      Tariff_Pre (Product_Code) =="+rs.getString(2));
				try
				{	
					product_code.put(Integer.toString(rs.getInt(1)),rs.getString(2));
					logger.debug("inserted in hastable");
				}catch(Exception see)
				{
					logger.error("Can't insert into HashTable"+see.toString());
				}
			}
			Global.product_Code_prepaid = product_code;

		}
		catch(Exception sqlE)
		{
			logger.error("Error in SQL:::"+sqlE);
		}
		finally
		{
			if( rs!= null) { try{	rs.close(); }catch(Exception e) {} }
			if( stmt!= null) { try{	stmt.close(); }catch(Exception e) {} }
			if( con!= null) { try{	con.close(); }catch(Exception e) {} }
			rs = null; stmt= null; con= null;
		}
	}

	/** @author avishkar on 1.11.2018
	 *  this method is used to get postpaidProductCodes against Charging_Code
	 *  specifically only for netOneSdp Charging
	 */
	private void getPostpaidProductCodes()
	{
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		try
		{
			con = Global.conPool.getConnection();
			stmt = con.createStatement();

			String query = DBQuery.fetchPostpaidProductCodes; //"select CHARGING_CODE,TARIFF_POST from CRBT_CHARGING_CODE"; // Modified by Avishkar on 25.03.2019
			logger.info("query ::["+query+"]");
			rs=stmt.executeQuery(query);

			//charges_postpaid.clear();
			Hashtable product_code = new Hashtable(); 

			while(rs.next())
			{
				logger.info("[Postpaid]      Charging_Code =="+rs.getInt(1)+"      Tariff_Post (Product_Code) =="+rs.getString(2));
				try
				{	
					product_code.put(Integer.toString(rs.getInt(1)),rs.getString(2));
					logger.debug("inserted in hastable");
				}catch(Exception see)
				{
					logger.error("Can't insert into HashTable"+see.toString());
				}
			}
			Global.product_Code_postpaid = product_code;

		}
		catch(Exception sqlE)
		{
			logger.error("Error in SQL:::"+sqlE);
		}
		finally
		{
			if( rs!= null) { try{	rs.close(); }catch(Exception e) {} }
			if( stmt!= null) { try{	stmt.close(); }catch(Exception e) {} }
			if( con!= null) { try{	con.close(); }catch(Exception e) {} }
			rs = null; stmt= null; con= null;
		}
	}

	private void getPostpaidCheck()
	{
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		try
		{
			con = Global.conPool.getConnection();
			stmt = con.createStatement();

			String query = DBQuery.fetchPostpaidCheck; //"select param_tag,param_value from crbt_app_config_params where param_tag in ('POSTPAID_CHARGING_ENABLE','DEFAULT_RATE_PLAN')"; // Modified by Avishkar on 25.03.2019
			logger.info(query);
			rs = stmt.executeQuery(query);
			while (rs.next())
			{
				if((rs.getString("PARAM_TAG")).equals("POSTPAID_CHARGING_ENABLE"))
					Global.postpaidcheck = Integer.parseInt(rs.getString("PARAM_VALUE"));
				if((rs.getString("PARAM_TAG")).equals("DEFAULT_RATE_PLAN"))
					Global._DEFAULT_RATE_PLAN = Integer.parseInt(rs.getString("PARAM_VALUE"));
			}
		}
		catch(Exception sqlE)
		{
			logger.error("Error in SQL:::"+sqlE);
		}
		finally
		{
			if( rs!= null) { try{	rs.close(); }catch(Exception e) {} }
			if( stmt!= null) { try{	stmt.close(); }catch(Exception e) {} }
			if( con!= null) { try{	con.close(); }catch(Exception e) {} }
			rs = null; stmt= null; con= null;
		}
	}

	private void getCOS()
	{
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		try
		{
			con = Global.conPool.getConnection();
			stmt = con.createStatement();

			String query = DBQuery.fetchCOS; //"select COS_NAME,IS_CORE,IS_ADVANCE from CHG_COS_MASTER where is_enable=1"; // Modified by Avishkar on 25.03.2019
			logger.info(query);
			rs = stmt.executeQuery(query);

			Set core_COS_SET = new HashSet();
			Set advance_COS_SET = new HashSet();

			while (rs.next())
			{
				if(rs.getInt("IS_CORE")==1)
				{
					core_COS_SET.add(rs.getString("COS_NAME"));
				}
				else if(rs.getInt("IS_ADVANCE")==1)
				{
					advance_COS_SET.add(rs.getString("COS_NAME"));
				}
				else
				{
					logger.warn(rs.getString("COS_NAME")+" COS is nither in core nor in advance");
				}
			}
			Global.core_COS_SET = core_COS_SET;
			Global.advance_COS_SET = advance_COS_SET;
		}
		catch(Exception sqlE)
		{
			logger.error("Error in SQL:::"+sqlE);
		}
		finally
		{
			if( rs!= null) { try{	rs.close(); }catch(Exception e) {} }
			if( stmt!= null) { try{	stmt.close(); }catch(Exception e) {} }
			if( con!= null) { try{	con.close(); }catch(Exception e) {} }
			rs = null; stmt= null; con= null;
		}
	}
}
