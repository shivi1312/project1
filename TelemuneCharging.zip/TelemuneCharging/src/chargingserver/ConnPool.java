package chargingserver;

import FileBaseLogging.*;
import java.io.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import org.apache.log4j.*;
import com.mchange.v2.c3p0.ComboPooledDataSource;

public class ConnPool
{
	private ComboPooledDataSource cpds = null;//new ComboPooledDataSource();

	String driver;
	String url;
	String username;
	String passwd;

	int minpoolsize;
	int maxpoolsize;
	int Accomodation;

	public ConnPool(String driver,String url,String username,String passwd,int minpoolsize,int maxpoolsize,int Accomodation)
	{
		this.driver = driver;
		this.url = url;
		this.username = username;
		this.passwd = passwd;
		this.minpoolsize = minpoolsize;
		this.maxpoolsize = maxpoolsize;
		this.Accomodation = Accomodation;
	}

	public void MakePool()
	{
		try 
		{
			cpds = new ComboPooledDataSource();
			cpds.setDriverClass(driver);
			cpds.setJdbcUrl(url);
			cpds.setUser(username);
			cpds.setPassword(passwd);
			cpds.setMaxPoolSize(maxpoolsize);
			cpds.setMinPoolSize(minpoolsize);
			cpds.setAcquireIncrement(Accomodation);
			cpds.setMaxStatementsPerConnection(25);
		} 
		catch (Exception ex) 
		{
			//handle exception...not important.....
		}

	}

	public synchronized Connection getConnection()
	{
		Connection con = null;
		try
                {
			con = cpds.getConnection();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}
}
