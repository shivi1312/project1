package chargingserver;

import java.util.Properties;
import java.util.StringTokenizer;

import FileBaseLogging.FileLogWriter;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;



/**
 * This file is intened to do initialization process,It reads parameters from properties file and initializes the variables.
 * It flashes exception in case of missing parameter or bad defined parameter in properties file.
 * Based on priority value it shuts down further processing, just after occurance of above exception. 1 is for exit.
 */


public class Util
{
	Properties chrPro = null;
	static Logger logger=Logger.getLogger("Util");
	Util(){}

	Util(Properties chrPro)
	{
		this.chrPro = chrPro;
	}

	/** This method reads parameter from properties file and populate Global variables. */
	public void readGlobalParam()
	{
		String prepaidseq = "";
		String postpaidseq = "";
		String hybridseq = "";

		for(int z=0;z<5;z++)
		{
			Global.prepaidac[z] = -1;
			Global.postpaidac[z] = -1;
			Global.hybridac[z] = -1;
		}
		Global.gateway_request_timeout = readInt("GATEWAY_REQUEST_TIMEOUT",0); /** 1 for exit */
		Global.gateway_link1 = readStr("CHRIP_1",1);
		Global.gateway_link2 = readStr("CHRIP_2",0);
		Global.gateway_port2 = readInt("CHRPORT_2", 0); // Added by Avishkar on 30.11.2018
		Global.gateway_link3 = readStr("CHRIP_3", 0); // Added by Avishkar on 30.11.2018
		Global.gateway_link4 = readStr("CHRIP_4", 0); // Added by Avishkar on 07.06.2020
		Global.username = readStr("CHR_USERNAME",1);
		Global.password = readStr("CHR_PASSWORD",1);

		Global.MSISDN_MIN_LENGTH = readInt("MSISDN_MIN_LENGTH",1);
		Global.MSISDN_MAX_LENGTH = readInt("MSISDN_MAX_LENGTH",0);

		Global.BALANCE_FILE_WRITER = readInt("BALANCE_FILE_WRITER",1);
		Global.CDR_FILE_WRITER = readInt("CDR_FILE_WRITER",1);
		Global.PER_REQ_FILE_WRITER = readInt("PER_REQ_FILE_WRITER",1);
		Global.RESPONSE_FILE_WRITER = readInt("RESPONSE_FILE_WRITER",1); // Added by Avishkar on 26.09.2018
		Global.DELIVERY_URL = readStr("DELIVERY_URL", 1); // Added by Avishkar on 01.10.2018
		Global.IS_SECOND_CHARGING_ENABLE = readInt("IS_SECOND_CHARGING_ENABLE", 1); // Added by Avishkar on 29.11.2018

		Global.DEFAULT_CURRENCY = readStr("DEFAULT_CURRENCY",1);
		
		//addition start by Avishkar on 25.10.2018
			Global.TAX_ENABLE = readInt("TAX_ENABLE", 0);
			Global.g_TaxAmount = readInt("TAX_AMOUNT", 0);
			Global.g_divident = readInt("TAX_DIVIDENT", 0);
			Global.FIXED_AMOUNT_ENABLE = readInt("FIXED_AMOUNT_ENABLE", 0);
			Global.ORIGIN_HOST = readStr("ORIGIN_HOST", 1);
			Global.ORIGIN_REALM = readStr("ORIGIN_REALM", 1);
			Global.HOST_PORT = readInt("HOST_PORT", 1);
			Global.DEST_HOST = readStr("DEST_HOST", 1);
			Global.DEST_REALM = readStr("DEST_REALM", 1);
			Global.DEST_PORT = readInt("DEST_PORT", 1);
			Global.VENDOR_ID = readInt("VENDOR_ID", 1);
			Global.CHECK_BAL_URL = readStr("CHECK_BAL_URL", 1);
			Global.MODULE = readStr("MODULE", 1);
			Global.HOST = readStr("HOST", 1);
			Global.COUNTRY_CODE_ENABLE = readInt("COUNTRY_CODE_ENABLE", 0);
			Global.CURRENCY_CODE = readInt("CURRENCY_CODE", 0);
			Global.REFUND_REQUEST_ENABLE = readInt("REFUND_REQUEST_ENABLE", 0);
			Global.TESTCASE_DEBIT_SUCCESS = readInt("TESTCASE_DEBIT_SUCCESS", 0);
			Global.DIAMETER_ENABLE = readInt("DIAMETER_ENABLE", 1);
		//addition ends by Avishkar on 25.10.2018

		//addition start by Avishkar on 11.12.2018
			Global.TESTCASE_CHKBAL_SUCCESS = readInt("TESTCASE_CHKBAL_SUCCESS", 0);
			Global.FALLBACK_AFTER_DEBIT_FAIL_ENABLE = readInt("FALLBACK_AFTER_DEBIT_FAIL_ENABLE", 1);
		//addition ends by Avishkar on 11.12.2018
			Global.inter_charging_interaction_timeout =  readInt("INTER_CHARGING_INTERACTION_TIMEOUT",0); // Added by Avishkar for timeout between one charging to another within our system on 28.01.2019
			
		//Global.HTTP_URL_FOR_CHARGING = readStr("HTTP_URL_FOR_CHARGING", 1); // modify by Avishkar
		Global.DURATION = readStr("DURATION", 1);			    // modify by Avishkar
		
		// modify by Avishkar on 4.Dec.2017
		Global.TOKEN_MINUTE_DIFF = readInt("TOKEN_MINUTE_DIFF", 1);
		Global.FIND_SUB_ID_URL = readStr("FIND_SUB_ID_URL", 1);
		Global.CHK_POSSIBILITY_URL_1 = readStr("CHK_POSSIBILITY_URL_1", 1);
		Global.CHK_POSSIBILITY_URL_2 = readStr("CHK_POSSIBILITY_URL_2", 1);
		Global.DEBIT_FOR_SUBSCRIPTION_URL = readStr("DEBIT_FOR_SUBSCRIPTION_URL", 1);
		Global.DEBIT_FOR_RBT_URL = readStr("DEBIT_FOR_RBT_URL", 1);
		Global.SERVICE_ID = readStr("SERVICE_ID", 1);
		Global.MSRN_PROV_FETCH_HOST = readStr("MSRN_PROV_FETCH_HOST", 1);
		Global.MSRN_PROV_FETCH_PORT = readShort("MSRN_PROV_FETCH_PORT", 1);
		Global.AUTHTOKEN_URL = readStr("AUTHTOKEN_URL", 1);
		Global.DEACT_ENABLE = readInt("DEACT_ENABLE", 1);
		
		Global.DB_TYPE = readStr("DB_TYPE", 1); // Added by Avishkar on 25.03.2019
		
		//addition start by Avishkar on 07.06.2020
			Global.LOGIN_URL = readStr("LOGIN_URL", 0);
			Global.APISTR = readStr("APISTR", 0);
			Global.REALM = readStr("REALM", 0);
			Global.REALM_FOR_SUBID = readStr("REALM_FOR_SUBID", 0);
			Global.USERID_NAME = readStr("USERID_NAME", 0);
			Global.IS_LOGIN_ENABLE = readInt("IS_LOGIN_ENABLE", 1);
			Global.CDR_ID_REQUIRED_IN_CHG_REQ = readInt("CDR_ID_REQUIRED_IN_CHG_REQ", 1);
			Global.NRC_TERM_ID_PREPAID_SUBSCRIPTION = readInt("NRC_TERM_ID_PREPAID_SUBSCRIPTION", 0);
			Global.NRC_TERM_ID_POSTPAID_SUBSCRIPTION = readInt("NRC_TERM_ID_POSTPAID_SUBSCRIPTION", 0);
			Global.NRC_TERM_ID_PREPAID_RBT_PURCHASE = readInt("NRC_TERM_ID_PREPAID_RBT_PURCHASE", 0);
			Global.NRC_TERM_ID_POSTPAID_RBT_PURCHASE = readInt("NRC_TERM_ID_POSTPAID_RBT_PURCHASE", 0);
			Global.NRC_TERM_ID_PREPAID_GIFT_RBT = readInt("NRC_TERM_ID_PREPAID_GIFT_RBT", 0);
			Global.NRC_TERM_ID_POSTPAID_GIFT_RBT = readInt("NRC_TERM_ID_POSTPAID_GIFT_RBT", 0);
			Global.NRC_TERM_ID_PREPAID_RBT_RENEW = readInt("NRC_TERM_ID_PREPAID_RBT_RENEW", 0);
			Global.NRC_TERM_ID_POSTPAID_RBT_RENEW = readInt("NRC_TERM_ID_POSTPAID_RBT_RENEW", 0);
			Global.NRC_TERM_ID_PREPAID_RECORDING_RBT = readInt("NRC_TERM_ID_PREPAID_RECORDING_RBT", 0);
			Global.NRC_TERM_ID_POSTPAID_RECORDING_RBT = readInt("NRC_TERM_ID_POSTPAID_RECORDING_RBT", 0);
		//addition ends by Avishkar on 07.06.2020
			
		// addition start by Avishkar on 22-02-2022
			Global.opCode=Integer.parseInt(chrPro.getProperty("OPCODE"));
			Global.USSD_PORT=Integer.parseInt(chrPro.getProperty("USSD_PORT"));
			Global.USSD_HOST=chrPro.getProperty("USSD_HOST");
			Global.Check_balCommand=chrPro.getProperty("USSD_CHECKBAL");
			Global.deduct_balCommand=chrPro.getProperty("USSD_CHECHDEDUCT");
			Global.DLG_START=Integer.parseInt(chrPro.getProperty("DIALOG_START"));
			Global.DLG_STOP=Integer.parseInt(chrPro.getProperty("DIALOG_STOP"));
			Global.TOTAL_REQ_COUNT=Integer.parseInt(chrPro.getProperty("TOTAL_REQ_COUNT"));
		// addition ends by Avishkar on 22-02-2022
		
		SimpleDateFormat sdfd = new SimpleDateFormat("dd-MM-yyy HH:mm:ss");
        	Date startDate;
		try {
			startDate = sdfd.parse(sdfd.format(Calendar.getInstance().getTime()).toString());
			Global.startDate = startDate;
			logger.info("StartDate at Util :["+Global.startDate+"]"); // added by Avishkar on 14.06.2020
		} catch (ParseException e) {
			e.printStackTrace();
		}
		///End modify by Avishkar

		Global.CP_ID = readStr("CP_ID", 1); //added by Avishkar on 1.11.2018 only for NetOneSdp
		
		int totalCountry = 0;
                totalCountry = readInt("TOTAL_COUNTRY",0);
		String countryCode =  null;
                Global.country_code.put("TOTAL_COUNTRY",totalCountry+"");
		for(int i=1; i<=totalCountry;i++)
		{
			try
			{

			countryCode = readStr("COUNTRY_CODE_"+i,0);
            Global.country_code.put("COUNTRY_CODE_"+i,countryCode);
			Global.country_code.put("COUNTRY_CURRENCY_"+countryCode,readStr("COUNTRY_CURRENCY_"+i,0));
            Global.country_code.put("MSISDN_LENGTH_"+countryCode,readStr("MSISDN_LENGTH_"+i,0));
                  if (i<3) { // this if condition is added by Avishkar on 14.09.2019
					
                      	Global.country_code.put("SUB_DTTYPE_"+countryCode,readStr("SUB_DTTYPE_"+i,0));
						Global.country_code.put("MONTH_DTTYPE_"+countryCode,readStr("MONTH_DTTYPE_"+i,0));
						Global.country_code.put("PROMO_DTTYPE_"+countryCode,readStr("PROMO_DTTYPE_"+i,0));
						Global.country_code.put("GIFT_DTTYPE_"+countryCode,readStr("GIFT_DTTYPE_"+i,0));
						Global.country_code.put("RBT_DTTYPE_"+countryCode,readStr("RBT_DTTYPE_"+i,0));
						Global.country_code.put("DAILY_DTTYPE_"+countryCode,readStr("DAILY_DTTYPE_"+i,0));
						Global.country_code.put("PACK_DTTYPE_"+countryCode,readStr("PACK_DTTYPE_"+i,0));
                  }
			}
                        catch(Exception exp)
			{
			 exp.printStackTrace();
			}
		}

		for(String key:Global.country_code.keySet())
		{
			//System.out.println("Key :["+key+"] value :["+Global.country_code.get(key)+"]");
			logger.info("Key :["+key+"] value :["+Global.country_code.get(key)+"]");

		}


		Global.SUB_SOURCE_TYPE = readInt("SUB_SOURCE_TYPE",0);
		Global.SUB_TYPE_TABLE = readStr("SUB_TYPE_TABLE",1);
		Global.TESTCASE = readInt("TESTCASE",0);
		System.out.println("Global.TESTCASE :::::::::::::::::::::::"+Global.TESTCASE);
		Global.TESTBALANCE = readInt("TESTBALANCE",0);
		Global.MSRN_FETCH_HOST = readStr("MSRN_FETCH_HOST",1);
		Global.MSRN_FETCH_PORT  = readShort("MSRN_FETCH_PORT",1);

		Global.BALANCE_FILE_WRITER = readInt("BALANCE_FILE_WRITER",0);
		Global.FIXED_AMOUNT = readDouble("FIXED_AMOUNT",0);
		Global.g_REQUEST_TO_CHECK_BALANCE = readInt("REQUEST_TO_CHECK_BALANCE",0);
		Global.g_REQUEST_TO_CREDIT_BALANCE = readInt("REQUEST_TO_CREDIT_BALANCE",0);
		Global.g_REQUEST_TO_DEBIT_BALANCE = readInt("REQUEST_TO_DEBIT_BALANCE",0);     
		Global.g_REQUEST_TO_DEBIT_BALANCE = readInt("REQUEST_TO_DEBIT_BALANCE",0);     
		Global.THREAD_MONITOR_DELAY = readInt("THREAD_MONITOR_DELAY",1);
		Global.SEND_ZERO_AMOUNT_CHARGING = readBoolean("SEND_ZERO_AMOUNT_CHARGING",1);


                
		 Global.DA_ID = readInt("DA_ID",1);

			

		/*prepaidseq = readStr("PREACCSEQ",0);
		int cnt=0;
		StringTokenizer acc_req = new StringTokenizer(prepaidseq, ";");
		while(acc_req.hasMoreTokens())
		{
			Global.prepaidac[cnt] = Integer.parseInt(acc_req.nextToken());
			cnt++;
		}

		postpaidseq = readStr("POSTACCSEQ",0);
		cnt=0;
		StringTokenizer acc_req1 = new StringTokenizer(postpaidseq,";");
		while(acc_req1.hasMoreTokens())
		{
			Global.postpaidac[cnt]=Integer.parseInt(acc_req1.nextToken());
			cnt++;
		}*/

		hybridseq = readStr("HYBRIDACCSEQ",0);
		int cnt=0;
		StringTokenizer acc_req2 = new StringTokenizer(hybridseq, ";");
		while(acc_req2.hasMoreTokens())
		{
			Global.hybridac[cnt]=Integer.parseInt(acc_req2.nextToken());
			cnt++;
		} //Not using inside charging current code //


	//	Global.flwBalaceWriter = initializeLogWriter("BALANCE_CHARGING_ARCHIVE_FILE_INTERVAL","BALANCE_CHARGING_LOG_FILE_NAME","BALANCE_CHARGING_LOG_FILE_PATH","BALANCE_CHARGING_ARCHIVE_FILE_PATH","BALANCE_CHARGING_ARCHIVE_FILE_NAME",".txt");

	}

	public int readInt(String param, int doExit)
	{
		int retVal = 0;
		String str = chrPro.getProperty(param);
		if( str == null || str.equalsIgnoreCase("null") || str.length() == 0)
		{
			//System.out.println("ReadException!!! parameter [ " +param+ " ]  priority [" +doExit+ "] is Missing or Not defined properly in properties file.");
			logger.info("ReadException!!! parameter [ " +param+ " ]  priority [" +doExit+ "] is Missing or Not defined properly in properties file.");
			if( doExit == 1 ){
				System.exit(0);
			}
		}
		else
		{
			try
			{
				retVal = Integer.parseInt(str.trim());
				//System.out.println("Reading [ " +param+ " ] [OK] ]");
				logger.info("Reading [ " +param+ " ] [OK] ]");
			}
			catch(NumberFormatException nfe)
			{
				//System.out.println("ReadException!!! parameter [ " +param+ " ]  priority [" +doExit+ "] is Not Defined property in properties. Please define it as integer. eg.: ABC=123");
				logger.info("ReadException!!! parameter [ " +param+ " ]  priority [" +doExit+ "] is Not Defined properly properties file. Please define it as integer. eg.: ABC=123");
				if( doExit == 1 ){
					System.exit(0);
				}
			}
		}
		return retVal;
	}


	public short readShort(String param,int doExit)
	{
		short retVal = 0;

		String str = chrPro.getProperty(param);
		if( str == null || str.equalsIgnoreCase("null") || str.length() == 0)
		{
			//System.out.println("ReadException!!! parameter [ " +param+ " ]  priority [" +doExit+ "] is Missing or Not defined properly in properties file.");
			logger.info("ReadException!!! parameter [ " +param+ " ]  priority [" +doExit+ "] is Missing or Not defined properly in properties file.");
			if( doExit == 1){
				System.exit(0);
			}
		}
		else
		{
			try
			{
				retVal = Short.parseShort(str.trim());
				//System.out.println("Reading [ " +param+ " ] [OK] ]");
				logger.info("Reading [ " +param+ " ] [OK] ]");
			}
			catch(NumberFormatException nfe)
			{
				//System.out.println("ReadException!!! parameter [ " +param+ " ]  priority [" +doExit+ "] is Not Defined property in properties. Please define it as integer. eg.: ABC=123");
				logger.info("ReadException!!! parameter [ " +param+ " ]  priority [" +doExit+ "] is Not Defined properly properties file. Please define it as integer. eg.: ABC=123");				
				if( doExit == 1 ){
					System.exit(0);
				}
			}
		}
		return retVal;
	}

	public double readDouble(String param, int doExit)
	{
		double retVal = 0;
		String str = chrPro.getProperty(param);
		if( str == null || str.equalsIgnoreCase("null") || str.length() == 0)
		{
			//System.out.println("ReadException!!! parameter [ " +param+ " ]  priority [" +doExit+ "] is Missing or Not defined properly in properties file.");
			logger.info("ReadException!!! parameter [ " +param+ " ]   priority [" +doExit+ "] is Missing or Not defined properly in properties file.");
			System.exit(0);
		}
		else
		{
			try
			{
				retVal = Double.parseDouble(str.trim());
				//System.out.println("Reading [ " +param+ " ] [OK] ]");
				logger.info("Reading [ " +param+ " ] [OK] ]");
			}
			catch(NumberFormatException nfe)
			{
				//System.out.println("ReadException!!! parameter [ " +param+ " ]  priority [" +doExit+ "] is Not Defined property in properties. Please define it as integer. eg.: ABC=123");
				logger.info("ReadException!!! parameter [ " +param+ " ]   priority [" +doExit+ "] is Not Defined properly properties file. Please define it as integer. eg.: ABC=123");
				if( doExit == 1 ){
					System.exit(0);
				}
			}
		}
		return retVal;
	}

	public String readStr(String param, int doExit)
	{
		String str = null;
		try
		{
			//System.out.println(">>> "+param+" ::: "+doExit);
			str = chrPro.getProperty(param);
			if( str == null || str.equalsIgnoreCase("null") || str.length() == 0)
			{
				//System.out.println("ReadException!!! parameter [ " +param+ " ] is Missing or Not defined properly in properties file.");
				logger.info("ReadException!!! parameter [ " +param+ " ] priority [" +doExit+ "] is Missing or Not defined properly in properties file.");
				if( doExit == 1 ){
					System.exit(0);
				}
			}
			else
			{
				str = str.trim();
				//System.out.println("Reading [ " +param+ " ] value:["+str+"] [OK] ]");
				logger.info("Reading [ " +param+ " ] value:["+str+"] [OK] ]");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//System.out.println("Exception in reading parameter [ " +param+ " ]  priority [" +doExit+ "] in properties file.");
			logger.info("Exception in reading parameter [ " +param+ " ]   priority [" +doExit+ "] in properties file.");
		}
		return str;
	}

        public boolean readBoolean(String param, int doExit)
        {
                boolean retVal = false;
                String str = null;
                try
                {
                        str = chrPro.getProperty(param);
                        if( str == null || str.equalsIgnoreCase("null") || str.length() == 0)
                        {
                                //System.out.println("ReadException!!! parameter [ " +param+ " ] is Missing or Not defined properly in properties file.");
                                logger.info("ReadException!!! parameter [ " +param+ " ] priority [" +doExit+ "] is Missing or Not defined properly in properties file.");
                                if( doExit == 1 ){
                                        System.exit(0);
                                }
                        }
                        else
                        {
                                str = str.trim();
                                //System.out.println("Reading [ " +param+ " ] value:["+str+"] [OK] ]");
                                logger.info("Reading [ " +param+ " ] value:["+str+"] [OK] ]");
                                if( str.equalsIgnoreCase("true"))
                                {
                                        retVal = true;
                                }

                        }
                }
                catch(Exception e)
                {
                        e.printStackTrace();
                        //System.out.println("Exception in reading parameter [ " +param+ " ]  priority [" +doExit+ "] in properties file.");
                        logger.info("Exception in reading parameter [ " +param+ " ]   priority [" +doExit+ "] in properties file.");
                }
                return retVal;
        }


	public FileLogWriter initializeLogWriter(String interval,String fname, String fpath, String fpath_arch, String fname_arch, String fextension)
	{
		int file_interval = 1;
                file_interval = readInt(interval,0);
		String filename = readStr(fname,1);
		String filepath = readStr(fpath,1);
		String filepath_arch = readStr(fpath_arch,1);
		String filename_arch = readStr(fname_arch,1);

		FileLogWriter flw = null;
		try
		{
			flw = new FileLogWriter();
			flw.setNewFileInterval(file_interval);
			flw.setFilename(filename);
			flw.setFilePath(filepath);
			flw.setArchiveFilePath(filepath_arch);
			flw.setArchiveFilename(filename_arch);
			flw.setArchiveFileExtension(fextension);
			flw.initialize();
		}
		catch(Exception e)
		{	
			e.printStackTrace();
		}
		return flw;
	}
}
