package chargingserver;

import org.apache.log4j.Logger;
import org.apache.axis.AxisFault;
import java.rmi.RemoteException;
import java.sql.*;

import javax.xml.crypto.Data;


public class SendToGateway 
{
	private Logger logger=Logger.getLogger("SendToGateway");
	static int count = 0;
	int result = -1;
	boolean core_advance_flag=false;
	//WSClient _WSE=null;

//	SoapRequest soapRequest = null;

	public SendToGateway() {}

	int getAvp(int countryCode,int action)
	{
		logger.debug("countryCode:["+countryCode+"] action:["+action+"]");
		int avp = -1;
		String key = null;
		try
		{
			if(action == 1 )
			{
				key = "SUB_DTTYPE_"+countryCode;
			}
			else if(action == 2)
			{
				key = "DAILY_DTTYPE_"+countryCode;
			}
			else if(action == 3)
			{
				key = "RBT_DTTYPE_"+countryCode;
			}
			else if(action == 4)
			{
				key = "GIFT_DTTYPE_"+countryCode;
			}
			else if(action == 12)
			{
				key = "PACK_DTTYPE_"+countryCode;
			}
			logger.debug("key to find avp code :["+key+"]");
			avp = Integer.parseInt((String)Global.country_code.get(key));
			logger.debug("key :["+key+"] avp code :["+avp+"]");
		}
		catch(Exception e)
		{
			logger.debug("Exception in fetching avp type from HashMap.");
			e.printStackTrace();
		}
		return avp;

	}

	private String getCurrencyType(String msisdn )
	{
		String currencyType = null;
		String countryCode =  null;

		for(String k:Global.country_code.keySet())
		{
			logger.debug("Key :["+k+"] value:["+Global.country_code.get(k)+"]");
		}
		try
		{
			if( msisdn.length() == Global.MSISDN_MIN_LENGTH || msisdn.length() == Global.MSISDN_MAX_LENGTH )
			{
				if(msisdn.length() == Global.MSISDN_MAX_LENGTH )
				{
					countryCode = msisdn.substring(0,3);
					currencyType = (String) Global.country_code.get("COUNTRY_CURRENCY_"+countryCode);
					logger.debug("countryCode :["+countryCode+"] currencyType:["+currencyType+"]");
				}
			}
		}
		catch(Exception e)
		{
			logger.debug("Exception in gettting currency");
			currencyType = null;
		}
		return currencyType;
	}

	private boolean validMSISDN(  Data_Object data_object )
	{
		data_object.o_currency = Global.DEFAULT_CURRENCY;
		boolean flag = false;
		String msisdn = data_object.o_msisdn;

		String countryCode =  null;
		int  msisdnLength =  0;
		String currency =  null;

		int totalCountry = Integer.parseInt(Global.country_code.get("TOTAL_COUNTRY"));
		//logger.debug("totalCountry ::["+totalCountry+"]");
		if(totalCountry>0)
		{
			for(int i=1; i <= totalCountry; i++)
			{
				countryCode = Global.country_code.get("COUNTRY_CODE_"+i);
				//logger.debug("countryCode :["+countryCode+"]");
				msisdnLength = Integer.parseInt( Global.country_code.get("MSISDN_LENGTH_"+countryCode));
				//logger.debug("msisdnLength :["+msisdnLength+"]");
				currency = Global.country_code.get("COUNTRY_CURRENCY_"+countryCode);
				logger.debug("##>msisdn["+msisdn+"] country_code["+countryCode+"] msisdnLength["+msisdnLength+"] currency["+currency+"]");
				if( msisdn.startsWith(countryCode) && msisdn.length() == msisdnLength)
				{
					data_object.o_currency = currency;
					flag = true;
					break;
				}
			}
		}
		else
		{
			if( msisdn.length() == Global.MSISDN_MIN_LENGTH || msisdn.length() == Global.MSISDN_MAX_LENGTH)
			{
				flag = true;
			} 
		}
		logger.debug("#>>msisdn["+msisdn+"] currency["+data_object.o_currency+"]"); 
		return flag;
	}

	/** This method returs 1 on success and -1 on failuer. */
	public int checkBalance( Data_Object data_object ) throws Exception,AxisFault 
	{ 
		data_object.balance = 0;
		result 		= -1;

		if(Global.TESTCASE != 1)
		{
			try
			{
				//logger.debug("Going to validate msisdn.................");
				if(!validMSISDN(data_object))
				{
				  logger.warn("msisdn:[" +data_object.o_msisdn+ "]  Invalid MSISDN");
				  return -1;
				}

			/*	String currencyType = getCurrencyType(data_object.o_msisdn);
				if(currencyType == null )
				{
					logger.error("Invalid Currency !!");
					return -1;
				}*/ //Not required for telecell

				logger.debug("msisdn:[" +data_object.o_msisdn+ "] data_object.o_accountType: ["+data_object.o_accountType+"]");

				/** o_accountType=1 indicates prepaid and o_accountType=2 indicates postpaid */
				if( data_object.o_accountType == 1 )
				{ // for prepaid only 
					logger.debug(">>>msisdn["+data_object.o_msisdn+"] going to hit the gateway for checkBalance");
					
				//Modification start by Avishkar on 14.09.2018	
					
					data_object.balance = data_object.thirdPartyRequest.checkBalance(data_object); // modified by Avishkar on 18.10.2018
					//data_object.balance = data_object.postCharging.checkBalance(data_object); 
					result = ( data_object.balance >= 0 ) ? 1 : -1;
					logger.debug("##>>msisdn["+data_object.o_msisdn+"] Balance:[" +data_object.balance+ "]");
					
				//Modification end by Avishkar on 14.09.2018
					
					
				}

			}
			catch( Exception ex )
			{
				logger.error(" ##>>msisdn:[" +data_object.o_msisdn+ "]Exception inside checkBalance "+((AxisFault)ex).getFaultString());
				ex.printStackTrace();
			}       
		}
		else
		{
			logger.debug("INSIDE ELSE####### TESTING MODE IS ON. ie; TESTCASE=1 in property file.");

			//modification start by Avishkar on 11.12.2018
			if (Global.TESTCASE_CHKBAL_SUCCESS==1) {
				data_object.balance = Global.TESTBALANCE;
				result = 1;
			}
			else {
				result = -1;
			}
			//modification ends by Avishkar on 11.12.2018
		} 

		logger.debug("##>>msisdn:[" +data_object.o_msisdn+ "]Inside checkBalance method ends here... Balance is ["+data_object.balance+"]");
		return result;
	}





	/** 
	 * This method is used to find subscriber type it returns integer where 0 for Prepaid , 1 for Postpaid and -1 for no response , 2 for Dual, 3 for Hybrid.
	 */
	//public int hlrRequest( Data_Object data_object) throws Exception
	public int findSubType( Data_Object data_object) throws Exception
	{

		String vlr = "";
		String scfAddress = "";
		String busyNumber = "";
		String noReplyNumber = "";
		String unreachableNumber = "";
		StringBuffer msrnBuf = new StringBuffer();
		StringBuffer imsiBuf = new StringBuffer();
		StringBuffer cfuActiveStr = new StringBuffer();

		Boolean isRoaming = true;
		Boolean isPrepaid = true;
		Boolean cfuActive = true;

		int msrnError = 0;
		int serviceKey = 0;
		//int sourceType = -1;

		String subType = ""; 
		result = -1;

		if(Global.TESTCASE !=1 ) 
		{
			try
			{
				///sourceType = Global.SUB_SOURCE_TYPE;
				if( Global.SUB_SOURCE_TYPE == 1 )
				{
					logger.info("msisdn:[" +data_object.o_msisdn+ "] Global.SUB_SOURCE_TYPE=1, so going to find subType from HLR.");
					/** to find simType form HLR */

					result = new FetchMsrn().fetchmsrn(6,data_object.o_msisdn,msrnBuf, vlr, imsiBuf, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber,unreachableNumber, cfuActive, cfuActiveStr);
					logger.info("After FetchMsrn result :[" +result+ "]");

					if( result == 1) // Treat postpaid as prepaid
					{
						result = 0; /** prepaid */
					}
					else if( result == 2 || result == 3 ) // Treat Dual and hybrid as postpaid
					{
						logger.info("msisdn:["+data_object.o_msisdn+"] value of [result = "+result+" ] converted to [result =1] ie, treating dual/hyprid as POSTPAID");
						result = 1; /** postpaid */
					}
					else
					{
						logger.info("Subtype not found. Rresponse from fechMsrn is["+result+"]");
						result = -1;
					}
				}
				else if( Global.SUB_SOURCE_TYPE == 2 )
				{
//					logger.info("msisdn:[" +data_object.o_msisdn+ "] Global.SUB_SOURCE_TYPE=2, so going to find subType from charing gateway which is not applicable for this site");
					
					// addition start by Aviskhar on 24.05.2020
						logger.info("msisdn:[" +data_object.o_msisdn+ "] Global.SUB_SOURCE_TYPE=2, so going to find subType from charing gateway.");
						result = data_object.thirdPartyRequest.checkAndFindSubType(data_object);
						logger.info("msisdn:[" +data_object.o_msisdn+ "] After charing gateway SubType Found :[" +result+ "]");
						   
						if( result == 1)
						{
							result = 0; //treated as prepaid
						    data_object.o_subtype = "P";
						}
						else if(result == 2)
						{
							result = 1 ; //tread as postpaid  
							data_object.o_subtype = "O";
						}
						else
						{
							result = -3; //no data found
						}
					// addition end by Avishkar on 24.05.2020
					
					/*
					   logger.info("msisdn:[" +data_object.o_msisdn+ "] Global.SUB_SOURCE_TYPE=2, so going to find subType from charing gateway.");
					   result = data_object.soapRequest.checkSubType(data_object.o_msisdn);
					   logger.info("msisdn:[" +data_object.o_msisdn+ "] After charing gateway SubType Found :[" +result+ "]");
					   if( result == 3)
					   {
					   result = 1; //treated as postpaid
					   logger.info("msisdn:[" +data_object.o_msisdn+ "]## {result = 3} converted in {result = 1} to treat as POSTPAID now result:[" +result+ "]");
					   }*/
						
					//   result = -1; // commented by Avishkar on 24.05.2020
				}
				else if( Global.SUB_SOURCE_TYPE == 3 )
				{
					logger.info("msisdn:[" +data_object.o_msisdn+ "] Global.SUB_SOURCE_TYPE=3, so we consider msisdn as Prepaid.");
					/**  Consider All Msisdn As prepaid */
					result=0; //p  

				}
				else if( Global.SUB_SOURCE_TYPE == 4 )
				{
					logger.info("msisdn:[" +data_object.o_msisdn+ "] Global.SUB_SOURCE_TYPE=4, so we consider msisdn as Postpaid.");
					/** Consider All misisdn As Postpaid */
					result=1; //O 
				}
				else if( Global.SUB_SOURCE_TYPE == 5 )
				{
					logger.info("msisdn:[" +data_object.o_msisdn+ "] Global.SUB_SOURCE_TYPE=5, so going to find subType from DB.");

					/** Get Subtype (simpType) From Data Base */
					String query = DBQuery.fetchSubTypeFromDb.replace("${Global.SUB_TYPE_TABLE}", Global.SUB_TYPE_TABLE); //"select SUB_TYPE from " +Global.SUB_TYPE_TABLE+ " where MSISDN = ?"; // Modified by Avishkar on 16.04.2019
					String query_print = query.replaceFirst("\\?","'"+data_object.o_msisdn+"'");

					PreparedStatement pstmt = null;
					Connection con = null; 
					ResultSet rs = null; 
					try
					{
						con = Global.conPool.getConnection();
						logger.debug("Query :["+query_print+"]");
						pstmt = con.prepareStatement(query);
						pstmt.setString(1,data_object.o_msisdn);
						rs = pstmt.executeQuery();

						if( rs.next() )
						{
							subType = rs.getString("SUB_TYPE");
						}

						if( subType.equalsIgnoreCase("P") )
						{
							result = 0;
						}
						else if(subType.equalsIgnoreCase("O") )
						{
							result = 1;
						}
						else
						{
							result = -1;
						}

					}
					catch(Exception e)
					{
						logger.debug("Exception Cought :: "+e.getMessage());
					}
					finally
					{
						if( rs != null ) { try{ rs.close(); }catch(Exception e){} }	
						if( pstmt != null ) { try{ pstmt.close(); }catch(Exception e){} }	
						if( con != null ) { try{ con.close(); }catch(Exception e){} }	
						result = 0; //p			
					}
				}     

			}
			catch(Exception ex)
			{
				if(ex instanceof AxisFault)
				{

					logger.error(" ##>>msisdn["+data_object.o_msisdn+"]Exception inside findSubType "+((AxisFault)ex).getFaultString());
					logger.error("##>>msisdn["+data_object.o_msisdn+"] Exception occured while relogin inside findSubType method");
					result=-1;
					ex.printStackTrace();
				}
			}   
		}
		else
		{
			logger.debug("INSIDE ELSE####### TESTING MODE ON !!! TESTCASE is 1");
			result = 0; //Postpaid 
		}          
		return result;
	}


	public  int debitBalance(Data_Object data_object,double amount) throws Exception // method structure modified by Avishkar amount int to double on 03.09.2019
	{
		int result = -1;
		data_object.o_camount = amount;
		data_object.o_desc = "RBT";
		logger.debug("##>>msisdn["+data_object.o_msisdn+"] Inside debitBalance method start here............");

		if( Global.TESTCASE != 1 )
		{
			try
			{
				if(!validMSISDN(data_object))
				  {
					logger.info("GETING NEGATIVE RESPONSE");
				  	return  -1;
				  }
			/*	String currencyType = getCurrencyType(data_object.o_msisdn);
				if(currencyType == null )
				{
					logger.error("Invalid Currency !!");
					return -1;
				}
				int countryCode = Integer.parseInt(data_object.o_msisdn.substring(0,3));
				int avp = getAvp(countryCode,data_object.o_action);
				if(avp == -1)
				{
					logger.error("Invalid AVP code");
					return -1;
				}*/
				
				//Modification start by Avishkar on 17.09.2018
				
				result = data_object.thirdPartyRequest.deductBlnce(data_object); // modified by Avishkar on 18.10.2018
				//result = data_object.postCharging.deductBlnce(data_object);
				
				//Modification end by Avishkar on 17.09.2018
			}
			catch(Exception ex)
			{
				logger.error(" ##>>msisdn["+data_object.o_msisdn+"]Exception inside debitBalance "+((AxisFault)ex).getFaultString());
				ex.printStackTrace();

			}
		}
		else
		{
			//modification start by Avishkar on 23.10.2018
				if (Global.TESTCASE_DEBIT_SUCCESS==1) {
					result=1;
				}
				else {
					result = 124;
				}
			//modification ends by Avishkar on 23.10.2018
			
		}
		if(result==0)
		{
			logger.debug("##>>msisdn["+data_object.o_msisdn+"] Response from Request for debit balance["+result+"]"); // modified by Avishkar on 22.10.2018
			result=1;
		}  	

		logger.debug("##>>msisdn["+data_object.o_msisdn+"] Inside debitBalance method ends here............");		
		return result;
 	}

		
	public int getReserveStatus( Data_Object data_object ) throws Exception,AxisFault
    {
		result          = -1;

	if(Global.TESTCASE != 1) 
    {
        try
        {
            if(!validMSISDN(data_object))
            {
              logger.warn("msisdn:[" +data_object.o_msisdn+ "]  Invalid MSISDN");
              return -1;
            }

    /*      String currencyType = getCurrencyType(data_object.o_msisdn);
            if(currencyType == null )
            {
                    logger.error("Invalid Currency !!");
                    return -1;
            }*/ //Not required for telecell

            logger.debug("msisdn:[" +data_object.o_msisdn+ "] data_object.o_accountType: ["+data_object.o_accountType+"]");

            /** o_accountType=1 indicates prepaid and o_accountType=2 indicates postpaid */
            if( data_object.o_accountType == 1 )
            { // for prepaid only 
                    logger.debug("msisdn["+data_object.o_msisdn+"] going to hit the gateway for getReserveStatus");
                    result = data_object.thirdPartyRequest.GetReserveStatus(data_object); // Modified by Avishkar on 18.10.2018
                    //result = data_object.postCharging.GetReserveStatus(data_object); // Commented by Avishkar on 28.09.2018
                    logger.debug("##>>msisdn["+data_object.o_msisdn+"] GetReserveStatus [" +result+ "]");
            }

        }
        catch( Exception ex )
        {
            logger.error(" ##>>msisdn:[" +data_object.o_msisdn+ "]Exception inside getReserveStatus  "+((AxisFault)ex).getFaultString());
            ex.printStackTrace();
        }
    }
	 else
            {
                    logger.debug("INSIDE ELSE####### TESTING MODE IS ON. ie; TESTCASE=1 in property file.");
                    data_object.balance = -1.1f;
                    result = -1;
            }

            logger.debug("##>>msisdn:[" +data_object.o_msisdn+ "]Inside getReserveStatus method ends here... reservestatus is ["+result+"]");
            return result;
    }
	
	public int setProvisioning( Data_Object data_object, String serviceType) throws Exception
	{
	
		String vlr = "";
		String scfAddress = "";
		String busyNumber = "";
		String noReplyNumber = "";
		String unreachableNumber = "";
		String msisdn=null;
		StringBuffer msrnBuf = new StringBuffer();
		StringBuffer imsiBuf = new StringBuffer();
		StringBuffer cfuActiveStr = new StringBuffer();

		Boolean isRoaming = true;
		Boolean isPrepaid = true;
		Boolean cfuActive = true;

		int msrnError = 0;
		int serviceKey = 0;
		//int sourceType = -1;
		int service=0;

		//String subType = ""; 
		int result = -1;

		if(Global.TESTCASE !=1 ) 
		{
			try
			{
					msisdn = data_object.o_msisdn.substring(3);
					service = Integer.parseInt(serviceType);
					logger.info("msisdn:[" +data_object.o_msisdn+ "] Global.SUB_SOURCE_TYPE=1, so going to find subType from HLR.");
					/** to find simType form HLR */

					result = new FetchMsrn().fetchmsrn(service,msisdn,msrnBuf, vlr, imsiBuf, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber,unreachableNumber, cfuActive, cfuActiveStr,"Prov");
					logger.info("After Provisioning FetchMsrn result :[" +result+ "]");

					if( result >= 1) // Treat postpaid as prepaid
					{
						result = 1; //success
					}
					else if ( result == -3) {
						logger.info("Request under process");
						result = -1; // under process also fail case
					}
					else
					{
						logger.info("Provisioning not found. Rresponse from fechMsrn is["+result+"]");
						result = -1;//fail
					}
			}
			catch(Exception ex)
			{
				if(ex instanceof AxisFault)
				{

					logger.error("##>>msisdn["+data_object.o_msisdn+"] Exception occured while relogin inside setProvisioning method");
					result=-1;
					ex.printStackTrace();
				}
			}   
		}
		else
		{
			logger.debug("INSIDE ELSE####### TESTING MODE ON !!! TESTCASE is 1");
			result = -1; 
		}          
		return result;
	}

	/**
	 * @author avishkar
	 * This method is added to get to know extra charges chargeable by client
	 * @param camount
	 * @param msisdn
	 * @return
	 * @throws Exception
	 */
	public double getOtherCharges(Data_Object data_object,double camount) throws Exception
	{
		logger.debug("##>>msisdn["+data_object.o_msisdn+"] Inside otherCharges method start here............");
		double otherChgs = 0;
		try {
			otherChgs = data_object.thirdPartyRequest.getOtherCharges(camount, data_object.o_msisdn);
		} catch (Exception ex) {
			logger.error(" ##>>msisdn["+data_object.o_msisdn+"] Exception inside otherCharges : ",ex);
			System.out.println(" ##>>msisdn["+data_object.o_msisdn+"] Exception inside otherCharges : "+ex);
			ex.printStackTrace();
		}
		
		return otherChgs;
	}
	
	/**
	 * @author avishkar
	 * This method is used to credit the amount or refund
	 * @param data_object
	 * @param amount
	 * @return
	 * @throws Exception
	 */
	public  int refundBalance(Data_Object data_object,double amount) throws Exception // method structure modified by Avishkar amount int to double on 03.09.2019
	{
		int result=-1;
		data_object.o_camount = amount;
		logger.debug("##>>msisdn["+data_object.o_msisdn+"] Inside refundBalance method start here............");

		if( Global.TESTCASE != 1 )
		{
			try
			{
				if(!validMSISDN(data_object))
				  {
					logger.info("GETING NEGATIVE RESPONSE");
				  	return  -1;
				  }
				result = data_object.thirdPartyRequest.refundBlnce(data_object);
			}
			catch(Exception ex)
			{
				logger.error(" ##>>msisdn["+data_object.o_msisdn+"]Exception inside refundBalance ",ex);
				System.out.println(" ##>>msisdn["+data_object.o_msisdn+"]Exception inside refundBalance "+ex);
				ex.printStackTrace();

			}
		}
		else
		{
			result = 124;
		}
		if(result==0)
		{
			logger.info("Response from refundRequest for credit balance["+result+"]");
			result=1;
		}  	

		logger.debug("Inside refundBalance method ends here............");		
		
		return result;
	}
	
	public boolean loginUser(Data_Object data_object, String username, String password) {
		logger.debug("##>> Inside loginUser method start here............");
		boolean flag = false;
		try {
			flag = data_object.thirdPartyRequest.userLogin(username, password);
		} catch (Exception e) {
			logger.error(" ##>> Exception inside loginUser : ",e);
			System.out.println(" ##>> Exception inside loginUser : "+e);
			e.printStackTrace();
		}
		return flag;
	}
	
	public boolean logoutUser(Data_Object data_object) {
		logger.debug("##>> Inside logoutUser method start here............");
		boolean flag = false;
		try {
			flag = data_object.thirdPartyRequest.userLogout();
		} catch (Exception e) {
			logger.error(" ##>> Exception inside logoutUser : ",e);
			System.out.println(" ##>> Exception inside logoutUser : "+e);
			e.printStackTrace();
		}
		return flag;
	}
}
