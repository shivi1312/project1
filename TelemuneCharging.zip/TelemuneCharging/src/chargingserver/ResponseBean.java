package chargingserver;

import java.util.List;

public class ResponseBean {

	List<SearchResults> searchResults;
	ListInfo listInfo;
	AdvancedStatus advancedStatus;
	
	static class ListInfo{
		String limit,offSet,count;
	}
	
	static class SearchResults{
		String subscriberId;	
	}
	
	static class AdvancedStatus{
		String advancedServiceStatusId;
		String name;
	}
}
