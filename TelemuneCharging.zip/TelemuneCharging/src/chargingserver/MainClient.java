package chargingserver;

import FileBaseLogging.FileLogWriter;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.telemune.client.DiameterRequest;

import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;

import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.StringTokenizer;

public class MainClient
{
	static Logger logger = Logger.getLogger("MainClient");

	static Thread responseSenderThread;
	static Thread cacheLoaderThread;
	static Thread serverAcceptorThread;

	static FileLogWriter flw_perRequest = null;
	static FileLogWriter flw_balancewriter = null;
	static FileLogWriter flw_CdrsWriter = null;
	//static FileLogWriter flw_ResponseWriter = null; // Added by Avishkar on 26.09.2018

	
	public static void main(String[] args) 
	{
		final String VERSION = "R1_2_4_0";
		final String APPLICATION = "Telemune Charging System"; // modified by Avishkar on 10.01.2020
		try
		{
			PropertyConfigurator.configure("properties/charging_log.properties");
			if(args[0].equalsIgnoreCase("-v"))
			{

				System.out.println("\n******************************************************************************************");
				System.out.println("\n                               Application "+APPLICATION); // modified by Avishkar on 10.01.2020
				System.out.println("\n                               Version "+VERSION);
				System.out.println("\n******************************************************************************************");
				System.out.println("\n");
				System.exit(1);
			}
		}
		catch(Exception Arrayoutex)
		{
			//System.out.println("Starts...."+Arrayoutex.toString());
		}

		try
		{
			logger.info("\n******************************************************************************************");
			logger.info("\n                               Application "+APPLICATION); // modified by Avishkar on 10.01.2020
			logger.info("\n                               Version "+VERSION);
			logger.info("\n******************************************************************************************");
			logger.info("\n");


			int port  = 2100; 
			int numofcon = 10; 
			int accomodation = 5; 
			int minnumofcon = 5; 
			int numofcontentthreads = 10; 

			int cacheLoadTimeInterval = 3600; 

			String dbuser = "NA";
			String dbpass = "NA";
			String dburl  = "NA";
			String driver = "NA";

			String hybridseq="";
			Properties chrPro = new Properties();

			try
			{
				FileInputStream fins=new FileInputStream("properties/chargingserver.properties");
				chrPro.load(fins);
				fins.close();
				fins = null;
			}
			catch(IOException ioe)
			{
				ioe.printStackTrace();
				System.out.println("Properties File Missing :: "+ioe.getMessage());
				System.exit(1);
			}

			Util util = new Util(chrPro);
			chrPro = null;
			
			// Modification start by Avishkar on 29.11.2018
			logger.info("Loading Configuration for the Application");

			port   = util.readInt("LOCAL_PORT",1); /** 1 for exit if something wrong with parameter */
			numofcontentthreads = util.readInt("NUM_OF_CONTENT_THREADS",0);
			logger.info("Intializing Global Parameters");
			util.readGlobalParam();
			logger.info("Constructing DB queries"); // Added by Avishkar on 26.03.2019
			DBQuery.constructQuery(Global.DB_TYPE); // Added by Avishkar on 26.03.2019
			
			if (Global.IS_SECOND_CHARGING_ENABLE==1) { /* here it means we will load cache and db configurations only when
											charging is acting as a first charging and we are allowed to send hit to second charging.
									If charging is acting as a second charging then we will not load cache and db related configuration.
									Second charging is only used to send direct hit to the third party gateway.
													*/
				logger.info("Database Connectivity");
				dbuser = util.readStr("DBUSER",1);
				dbpass = util.readStr("DBPASSWORD",1);
				dburl  = util.readStr("DBURL",1);
				driver = util.readStr("DRIVER",1);

				hybridseq = util.readStr("PREACCSEQ",1);
				int cnt=0;
				StringTokenizer acc_req2 = new StringTokenizer(hybridseq, ";");
				while(acc_req2.hasMoreTokens())
				{
					Global.hybridac[cnt]=Integer.parseInt(acc_req2.nextToken());
					cnt++;
				}

				numofcon = util.readInt("NUM_OF_CONNECTION",0);
				minnumofcon = util.readInt("MIN_NUM_OF_CONNECTION",0);
				accomodation = util.readInt("DB_ACCOMODATION",0);
				
				cacheLoadTimeInterval = util.readInt("RELOAD_TIME",0);
				
				logger.info("Intializing Loggers");

				/** ParameterList : fileInterval,filename,filepath,archive_filepath,archive_filename,archive_file_extension*/
				if( Global.PER_REQ_FILE_WRITER == 1)
				{
					flw_perRequest = util.initializeLogWriter("PER_REQ_ARCHIVE_FILE_INTERVAL","PER_REQ_LOG_FILE_NAME","PER_REQ_LOG_FILE_PATH","PER_REQ_ARCHIVE_FILE_PATH","PER_REQ_ARCHIVE_FILE_NAME","");
				}
				if( Global.BALANCE_FILE_WRITER == 1)
				{
					flw_balancewriter = util.initializeLogWriter("BALANCE_CHARGING_ARCHIVE_FILE_INTERVAL","BALANCE_CHARGING_LOG_FILE_NAME","BALANCE_CHARGING_LOG_FILE_PATH","BALANCE_CHARGING_ARCHIVE_FILE_PATH","BALANCE_CHARGING_ARCHIVE_FILE_NAME","");
				}

				if( Global.CDR_FILE_WRITER == 1 )
				{
					flw_CdrsWriter= util.initializeLogWriter("CDRS_ARCHIVE_FILE_INTERVAL","CDRS_LOG_FILE_NAME","CDRS_LOG_FILE_PATH","CDRS_ARCHIVE_FILE_PATH","CDRS_ARCHIVE_FILE_NAME","");
				}
				
				
				logger.info("Intializing Database...");
				Global.conPool = new ConnPool(driver,dburl,dbuser,dbpass,minnumofcon,numofcon,accomodation);
				Global.conPool.MakePool();


				logger.info("Starting Cache Loader ...");
				cacheLoaderThread = new Thread( new CacheLoader(cacheLoadTimeInterval) );
				cacheLoaderThread.start();
			}
			// Modification ends by Avishkar on 29.11.2018
			
			// Modification start by Avishkar on 26.09.2018
			if( Global.RESPONSE_FILE_WRITER == 1 )
			{
				Global.flw_ResponseWriter= util.initializeLogWriter("RESPONSE_ARCHIVE_FILE_INTERVAL","RESPONSE_LOG_FILE_NAME","RESPONSE_LOG_FILE_PATH","RESPONSE_LOG_ARCHIVE_FILE_PATH","RESPONSE_LOG_ARCHIVE_FILE_NAME","");
			}
			// Modification end by Avishkar on 26.09.2018
			
			//logger.debug("loggin to gateway...............");
			//Global.sendtogateway = new SendToGateway();
			
			if (Global.DIAMETER_ENABLE==1) { // Added by Avishkar on 23.09.2019
				Global.diameterRequest = new DiameterRequest();
			}

			Global.numofcontentthreads = numofcontentthreads;
			ThreadPoolExecutor contentexecutorPool = new ThreadPoolExecutor(1, numofcontentthreads, 10, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(10));
//			contentexecutorPool.execute(new ChargingServer(flw_perRequest,flw_balancewriter,flw_CdrsWriter));
			RequestExecutor reqExector=new RequestExecutor(flw_perRequest,flw_balancewriter,flw_CdrsWriter,contentexecutorPool);
			Thread reqExectorThread=new Thread(reqExector);
			reqExectorThread.start();

			ThreadMonitor thMonitor = new ThreadMonitor(contentexecutorPool,Global.THREAD_MONITOR_DELAY,flw_perRequest,flw_balancewriter,flw_CdrsWriter);
			Thread monitorThread = new Thread(thMonitor);
			monitorThread.start(); 

			responseSenderThread = new Thread( new ResponseSender("threadCheckResponses") );
			responseSenderThread.start();

			logger.info("Intializing Acceptor Thread...");
			try
			{
				serverAcceptorThread = new Thread( new ServerAcceptor(port) );
				serverAcceptorThread.start();
			}
			catch(Exception ee)
			{
				logger.fatal("got SOCKET exception in thread" +ee.toString());
				System.out.println("got SOCKET exception in thread" +ee.toString());
				System.exit(1);
			}

			while(true)
			{
				try
				{
					if(!serverAcceptorThread.isAlive())
					{
						logger.info("serverAcceptorThread has been stoped , so restarting");
						serverAcceptorThread = new Thread( new ServerAcceptor(port) );
						serverAcceptorThread.start();
					}

					if(!responseSenderThread.isAlive())
					{
						logger.info("Response Sender Thread  has been stoped , so restarting");

						responseSenderThread = new Thread( new ResponseSender("threadCheckResponses") );
						responseSenderThread.start();
					}
					
					if (cacheLoaderThread!=null) {
						if(!cacheLoaderThread.isAlive() && Global.IS_SECOND_CHARGING_ENABLE==1) // Modified by Avishkar on 29.11.2018
						{
							logger.info("cacheLoaderThread has been stoped , so restarting");
							cacheLoaderThread = new Thread( new CacheLoader(cacheLoadTimeInterval) );
							cacheLoaderThread.start();
						}
					}
						
					if(!reqExectorThread.isAlive())
					{
						logger.info("reqExectorThread thread has been stoped, Needs to check application");
						reqExectorThread = new Thread(new RequestExecutor(flw_perRequest,flw_balancewriter,flw_CdrsWriter,contentexecutorPool));
						reqExectorThread.start();
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
					System.out.println("got exception in  thread" +e);
					System.exit(1);
				}

				try
				{
					Thread.sleep(30*60*1000);
					logger.info("All Threads Running Successfully...");
				}
				catch(Exception eee)
				{
					logger.fatal("Sleep Exception in main");
					System.out.println("Sleep Exception in main");
				}	
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}
