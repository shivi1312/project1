package chargingserver;

import FileBaseLogging.*;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.*;
import java.net.*;
import java.util.*;
import java.text.DecimalFormat;


public class RequestTypeOne extends CommonAbstract
{
	private static Logger logger = Logger.getLogger("RequestTypeOne");

	FileLogWriter flw_balancewriter = null;
	FileLogWriter flw_CdrsWriter = null;

	int[] hybridac = new int[5];
	int i=-1;	


	boolean prepaid = false;
	boolean postpaid_normal = false;
	boolean dual_hybrid = false;

	int prepaid_status 	= -1;
	int chg_code 		= -1;

	int status 		= -1;	
	int resultFromCommon 	= -1;
	int doCharging 		= -1;
	int result 		= -1;
	int resp_data 		= -1; 

	Double camount = new Double(0.0);
	DecimalFormat df = null;

	String accountId 	= "-1";
	String reason 		= "NA";
	int subtype_found       = -1;

	private RequestTypeOne(){}

	public RequestTypeOne(FileLogWriter flw_balancewriter,FileLogWriter flw_cdrswriter) 
	{
		this.flw_balancewriter = flw_balancewriter;
		this.flw_CdrsWriter = flw_cdrswriter;
		df = new DecimalFormat("#.######");
	}

	/**
	 * This method finds SubscriberType either form HLR or DB , condition depends on value of action.
	 * Also responsible for checking balance , balance is checked as per the instruction given by configuration value g_REQUEST_TO_CHECK_BALANCE.
	 * Checking Balance is done for prepaid only. It does not check the balance for postpaid subscriber.
	 * For prepaid subscriber balance is deducted only when the configruation value of REQUEST_TO_DEBIT_BALANCE is 1.
	 * For postpaid subscriber balance is deducted only when the value of postpaidcheck is 1 as well as REQUEST_TO_DEBIT_BALANCE must also be 1.
	 * The value of postpaidcheck is reset by CacheLoader which is defined in DB.
	 * */

	//public int requestTypeOne(Data_Object data_object)throws LowBalanceException,UndefindCOSException,SocketTimeoutException,ConnectException,Exception
	public int requestTypeOne(Data_Object data_object)throws UndefindCOSException,SocketTimeoutException,ConnectException,Exception
	{

		int amount 		= -1;	
		int chgDays  		= -1;
		int da_id 		= -1; /** Dedicated Account Id */
		int service_class 	= -1;
		boolean chkBalanceResult = false; // added by Avishkar on 26.12.2018
		String chgCode 		= "";
		String productCode = ""; // added by Avishkar on 1.11.2018
		//req_typeone 		= new RequestTypeOne();

		int rbt 		= Integer.parseInt(data_object.o_rbtcode);
		reason 			= data_object.o_action+""; 
		
		// modification start by Avishkar on 16.10.2018
		double otherCharges=0.0f;
		int cpCode = -1;
		if( rbt > 0 )
		{
			cpCode = getCpCode(rbt);
			data_object.o_cpCode = cpCode;
		}
		//modification end by Avishkar on 16.10.2018

		ArrayList<ChargingCodeAmount> chargingCodeDays = new ArrayList<ChargingCodeAmount>();
		resultFromCommon = getChargingCodeDays(chargingCodeDays,data_object.o_tariffid);

		logger.debug("msisdn:["+data_object.o_msisdn+"] chargingCodeDays size is["+chargingCodeDays.size()+"] resultFromCommon ["+resultFromCommon+"]");
		doCharging = ( resultFromCommon == 1 )? 1 : -1;

		if( doCharging == 1 )
		{
			int  _actDesc = -1;
			if( data_object.o_subtype.equalsIgnoreCase("P") )
			{
				logger.info("MSISDN:["+data_object.o_msisdn+"] is PREPAID");
				prepaid = true;
				postpaid_normal = false;
				prepaid_status = 0;
				service_class = 1;
			}
			else if( data_object.o_subtype.equalsIgnoreCase("O") )
			{
				logger.info("MSISDN:["+data_object.o_msisdn+"] is POSTPAID");
				prepaid = false;
				postpaid_normal = true;
				prepaid_status = 1;
				service_class = 2;
			}
			else
			{
				if(data_object.o_action == 1)
				{
					/** Finding SubType, it depends on the value of SUB_SOURCE_TYPE (defined in properties file.)
						1-from HLR,  2-from Gateway, 3-Prepaid, 4-Postpaid, 5-from DB */
					prepaid_status = data_object.sendToGateway.findSubType( data_object );
					logger.debug("msisdn:["+data_object.o_msisdn+"] After requeting HLR prepaidStatus:[" +prepaid_status+ "]");
				}
				else
				{
					logger.debug("msisdn:["+data_object.o_msisdn+"] request to local DB for checking subType.");
					boolean doHlrRequest = false;
					String l_subType = "N";

					try
					{
						//l_subType = req_typeone.checkForSubType(data_object.o_msisdn);
						l_subType = checkForSubType(data_object.o_msisdn);
						if(!(StringUtils.isBlank(l_subType)))
						{
							if(l_subType.equalsIgnoreCase("P"))
								prepaid_status = 0;
							else if(l_subType.equalsIgnoreCase("O"))
								prepaid_status = 1;
							else
								doHlrRequest = true;
						}
						else
						{
							doHlrRequest = true;
						} 
					}
					catch(Exception exp)
					{
						doHlrRequest = true;
						logger.error("###>>msisdn:["+data_object.o_msisdn+"]  exception in checking subType from db."+exp);
					}

					if(doHlrRequest)
					{
						logger.debug("msisdn:["+data_object.o_msisdn+"] subType not found in DB, going to find by another way that depends on the value of SUB_SOURCE_TYPE.");
						prepaid_status = data_object.sendToGateway.findSubType( data_object );
						logger.debug("msisdn:["+data_object.o_msisdn+"] After finding subType  prepaidStatus:[" +prepaid_status+ "]");
					}
				}
			}

			// Below method is used to find the minimum balance between prepaid and postpaid chargin amount which is predefined in database.
			/*
			   String chgAmount = "";
			   for(int tariffCount=0; tariffCount<chargingCodeDays.size(); tariffCount++)
			   {
			   chgDays = -1;
			   chgCode = "";
			   chgDays = chargingCodeDays.get(tariffCount).getChargingDays();
			   chgCode = chargingCodeDays.get(tariffCount).getChargingCode()+"";
			   if(prepaid_status == 0) // If it is prepaid 
			   {
			   chgAmount = String.valueOf(Global.charges_prepaid.get(chgCode.trim()));
			   }
			   else if(prepaid_status == 1) // If it is postpaid 
			   {
			   chgAmount = String.valueOf(Global.charges_postpaid.get(chgCode.trim()));

			   }	
			   else if(prepaid_status ==2 || prepaid_status ==3) // Either it is Dual or Hybrid 
			   {
			   chgAmount = String.valueOf(Global.charges_postpaid.get(chgCode.trim())); //for dual/hybrid where to get camount
			   }
			   else
			   {
			   logger.info("msisdn["+msisdn+"] subtype["+prepaid_status+"] is Invalid.");	
			   break; // If subtype not defined 
			   }			
			   logger.info("msisdn["+msisdn+"] chgCode :[" +chgCode+ "] chgAmount:[" +chgAmount+ "]");
			   if( chgAmount != null )
			   {
			   Global.chargescodes_amount.put(chgCode,Double.parseDouble(chgAmount.trim()));
			   }
			   }*/

			/** If it is prepaid. or postpaid or hybrid or dual or hybrid */
			if( prepaid_status == 0 || prepaid_status == 1 || prepaid_status == 2 || prepaid_status == 3)
			{
				//data_object.o_minimum_amount = Collections.min(Global.chargescodes_amount.values());
				//logger.info("msisdn[" +msisdn+ "] minimum amount  acoording to incoming trarrigId's is[" +data_object.o_minimum_amount+ "]");

				if( Global.g_REQUEST_TO_CHECK_BALANCE != 1 ) /** If it is NOT allowd in configuration file to check Balance. */
				{
					logger.debug("Sending request to check balance not enable so will not go for checkingBalance and considering data_object.balance = 0.0");
					data_object.balance = 0.0f;
				}
				else
				{
					/** If it is postpaid or dual or hybrid */
					if( prepaid_status == 1 || prepaid_status ==2 || prepaid_status == 3)
					{
						logger.info("msisdn:["+data_object.o_msisdn+"] prepaid_status :[" +prepaid_status+ "] WE are not Going to checkBalance.");
						data_object.o_accountType = 2;
						data_object.o_dedAccId = Global.DA_ID;
					}
					else
					{
						/** For prepaid olny.  */
						data_object.o_accountType = 1;

						/** Going to check balance , result = 1 means success */
						logger.debug("msisdn:["+data_object.o_msisdn+"] Going to checkBalance.");
						int results = data_object.sendToGateway.checkBalance(data_object);
						if( results == 1 )
						{
							chkBalanceResult = true; // added by Avishkar on 26.12.2018
							logger.info("msisdn:["+data_object.o_msisdn+"] OK, after checkBalance balance:[" +data_object.balance+ "]");
						}
						else
						{
							chkBalanceResult = false; // added by Avishkar on 26.12.2018
							logger.info("msisdn:["+data_object.o_msisdn+"] NOT OK After checkbalance result:["+results+"]");
						}
					}

					if( Global.BALANCE_FILE_WRITER == 1 ) /** If it is configured to write balance in file.  */
					{
						/**  writing in logs/BalanceWrite/BalanceWrite */
						synchronized(flw_balancewriter) 
						{
							//flw_balancewriter.writeLog(data_object.o_msisdn+","+data_object.balance+","+data_object.advancebalance); // commented by Avishkar on 18.10.2018
							flw_balancewriter.writeLog(">>>msisdn :["+data_object.o_msisdn+"] MainBalance:[" +data_object.balance+ "] OtherBalance:[" +data_object.advancebalance+ "] Total Balance:["+data_object.balance+data_object.advancebalance+"]"); // Added by Avishkar on 18.10.2018
						}
					}
				}

				if( prepaid_status == 0 ) /** If it is prepaid. */
				{
					data_object.o_subtype = "P"; // Added by Avishkar on 01.10.2018
					prepaid = true;
					postpaid_normal = false;
					dual_hybrid =false;
					service_class = 1;
				}
				else if( prepaid_status == 1 ) /** If it is Postpaid. */
				{
					data_object.o_subtype = "O"; // Added by Avishkar on 01.10.2018
					prepaid = false;
					postpaid_normal = true;
					dual_hybrid = false;
					service_class = 2;
				}
				else if( prepaid_status == 2 || prepaid_status ==3 ) /** IF it is Dual or hybrid. */
				{
					prepaid = false;
					postpaid_normal = false;
					dual_hybrid = true;
					service_class = 2; //service_class 2 for both hybrid or dual.
				}
				else 
				{	/** Defult Asumption */
					prepaid = false;
					postpaid_normal = false;
					dual_hybrid = false;
				}  

				result = -2;
				/////////////////////////////////////////////////////////////////////
				for(int tariffCount=0; tariffCount<chargingCodeDays.size(); tariffCount++)
				{
					//chgDays = -1;
					//chgCode = "";
					chgDays = chargingCodeDays.get(tariffCount).getChargingDays();
					chgCode = chargingCodeDays.get(tariffCount).getChargingCode()+"";
					logger.debug("chgDays :["+chgDays+"] chgCode:["+chgCode+"]");

					_actDesc = data_object.o_action;
					if(data_object.o_action == 5 || data_object.o_action==6 || data_object.o_action ==7 ) 
					{
						_actDesc = data_object.o_action=2;
					}
				
					while(Global.cacheThreadAlive)
					{
						try
						{
							logger.debug("waiting ...............for chache free.........");
							Thread.sleep(1);
						}catch(Exception e){e.printStackTrace();}
					}


					data_object.o_days = chgDays;
					data_object.o_chgcode = Integer.parseInt(chgCode);


					if(prepaid) {	
						camount = (Double)Global.charges_prepaid.get(chgCode.trim());
						productCode = Global.product_Code_prepaid.get(chgCode.trim()); //Added by Avishkar on 1.11.2018 (Exclusively for NetOneSdp)
					}
					else if(postpaid_normal) {
						camount = (Double)Global.charges_postpaid.get(chgCode.trim());
						productCode = Global.product_Code_postpaid.get(chgCode.trim()); //Added by Avishkar on 1.11.2018 (Exclusively for NetOneSdp)
					}
					else if(dual_hybrid) {
						camount = (Double) Global.charges_postpaid.get(chgCode.trim());  //from postpaid hastable to get camount for hybrid /dual
						productCode = Global.product_Code_postpaid.get(chgCode.trim()); //Added by Avishkar on 1.11.2018 (Exclusively for NetOneSdp)
					}

					chg_code = Integer.parseInt(chgCode);	
					logger.debug("msisdn:[" +data_object.o_msisdn+ "] Charging Code:["+chgCode+"] Charging Days:["+chgDays+"] FIXED_AMOUNT["+Global.FIXED_AMOUNT+"] Charging amount:["+camount+"] Balance:["+data_object.balance+"]");

					if(camount != null)
					{

						da_id = 0; /** Dedicated Account ID */	

						/** IF the value of postpaidcheck is 1 then postpaid will also be charged , postpaidcheck is reset by CacheLoader using DB*/
						if((dual_hybrid) || ( (prepaid)|| ((postpaid_normal)&&(Global.postpaidcheck == 1)) ))
						{
							/** service_class = 1 for prepaid and service_class = 2 for postpaid 
							accountType == 1 represents prepaid */
							if(Global.g_REQUEST_TO_CHECK_BALANCE == 1 && data_object.o_accountType == 1) 
							{	
								/** Checking Balance For Prepaid only */
								//double sum = camount + Global.FIXED_AMOUNT; // commented by Avishkar on 18.10.2018
								otherCharges = data_object.sendToGateway.getOtherCharges(data_object,camount); // added by Avishkar on 22.10.2018
								double sum = camount + otherCharges; // added by Avishkar on 22.10.2018
								if( data_object.balance >= ( sum ) )
								{//
									//Double d = camount + Global.FIXED_AMOUNT; // commented by Avishkar on 18.10.2018
									Double d = camount + otherCharges; // added by Avishkar on 22.10.2018
									logger.info("msisdn:["+data_object.o_msisdn+"] ChargingAmount+FIXED_AMOUNT:["+d+"] Balance in userAccount:["+data_object.balance+"], Suitable Balance Found! No need to go for further fallback iteration.");
								//	logger.debug("msisdn:["+data_object.o_msisdn+"] Fixed_amount ["+Global.FIXED_AMOUNT+"] Charging Amount["+camount+"] balance["+data_object.balance+"]");
								}
								else if(camount==0 && !Global.SEND_ZERO_AMOUNT_CHARGING)
								{//
									/** Don't do debit for zero amount because SEND_ZERO_AMOUNT_CHARGING is false in config */
									logger.info("msisdn :["+data_object.o_msisdn+"] SEND_ZERO_AMOUNT_CHARGING is false in config,so we don't go for debit");
									/** In case of SEND_ZERO_AMOUNT_CHARGING=false in config , don't go for debit*/
									result = 1;
									data_object.o_serviceclass = service_class;
									break;
								}
								else if( camount==0  && Global.SEND_ZERO_AMOUNT_CHARGING)
                                {//
                                        logger.info("msisdn :[" +data_object.o_msisdn+ "] As SEND_ZERO_AMOUNT_CHARGING=true in config, doing debit for charging amount=0");
                                }
								else
								{
									if(chgDays==1)
									{
										if(data_object.balance>camount)
										{//
											logger.info("msisdn:["+data_object.o_msisdn+"] For 1 day, we need not to keep FIXED_AMOUT["+Global.FIXED_AMOUNT+"] left in user account.\n"+  //modified by Avishkar on 4.1.2019
											"msisdn:["+data_object.o_msisdn+"] ChargingAmount:["+camount+"] Balance in userAccount:["+data_object.balance+"], Suitable Balance Found! No need to go for further fallback iteration.");
										}
										// addition start by Avishkar on 26.12.2018
										else if (chkBalanceResult && data_object.balance<camount) {
											logger.info("###>>   Charging request for msisdn ==== ["+data_object.o_msisdn+"]   is not sent due to insufficent[ TotalBalance = ["+data_object.balance+"], chargable amount ["+camount+"]");
											result = -2; /** denotes LowBalance */
											break;
										}
										// addition end by Avishkar on 26.12.2018
										else
										{//
											//logger.info("###>>   Charging request for msisdn ==== ["+data_object.o_msisdn+"]   is not sent due to insufficent[ TotalBalance = ["+data_object.balance+"], chargable amount ["+camount+"]"); // commented by Avishkar on 12.12.2018
											logger.info("###>>   Charging request for 1 day for msisdn ==== ["+data_object.o_msisdn+"] TotalBalance = ["+data_object.balance+"], chargable amount ["+camount+"]"); // modified by Avishkar on 12.12.2018
										}
									}
									else
									{ //
										double d = camount + Global.FIXED_AMOUNT;
										logger.debug("msisdn:["+data_object.o_msisdn+"] ChargingAmount+FIXED_AMOUNT:["+d+"] Balance in userAccount:["+data_object.balance+"], Continue.... to next fallback.");
										result = -2; /** denotes LowBalance */
										continue;
									}


								}
							}
							else
							{
								logger.debug("REQUEST_TO_CHECK_BALANCE for fall back is disabled so fall back skipped.");	
							}

							if(camount > 0 || (camount == 0 && Global.SEND_ZERO_AMOUNT_CHARGING) )
							{
								/*if( checkInCoreAdvance(data_object.o_msisdn,camount,data_object))
								{*/ //not required for this charging

									logger.debug("msisdn :[" +data_object.o_msisdn+ "]## going to deduct Amt:["+camount+"] where existing  Balance (Core/Main) ["+data_object.balance+"] OterhBal:[" +data_object.advancebalance+ "] ");

									result = -2;
									i = 0;
									data_object.camount = camount;
									data_object.o_days = chgDays;
									data_object.o_chgcode = Integer.parseInt(chgCode);
									data_object.o_serviceclass = service_class;
									data_object.productCode = productCode; //Added by Avishkar on 1.11.2018 (Exclusively for NetOneSdp)

									this.hybridac=Global.hybridac;
									while (hybridac[i]!=-1)
									{
										logger.debug("Getting Hybrid is: "+hybridac[i]);
										da_id=hybridac[i];
										accountId=hybridac[i]+"";
										logger.info("###>>    "+data_object.o_msisdn+" Try Charge from DA="+da_id);
										//if(da_id==0)
									//	{
									//	}
									//      else
										if( da_id != 0 )
										{
											if(Global.g_REQUEST_TO_DEBIT_BALANCE !=1 )
											{
												logger.debug("##>>msisdn:["+data_object.o_msisdn+"]Not enable to send request to debit balance");
											}	
											else
											{
												amount = Integer.valueOf(camount.intValue());
												
											// addition start by Avishkar on 24.05.2020
												if (Global.CDR_ID_REQUIRED_IN_CHG_REQ==1) { // this condition is used when cdr_id is required to send in debit request
													if ("oracle".equalsIgnoreCase(Global.DB_TYPE)) {
														data_object.o_cdrId = getCdrId();
													} else if ("mysql".equalsIgnoreCase(Global.DB_TYPE)) {
														data_object.o_cdrId = getLastInsertedId(); // to generate cdrId in case of mySql
													}
												}
											// addition end by Avishkar on 24.05.2020
												
												/** Deducting Balance where result = 1 for success */
												//result = data_object.sendToGateway.debitBalance(data_object,amount); // commented by Avishkar on 03.09.2019
												result = data_object.sendToGateway.debitBalance(data_object,camount); // modified by Avishkar on 03.09.2019
												logger.info("msisdn:["+data_object.o_msisdn+"] After deducting balance result:::["+result+"]");
											}
										}
										i++;
										logger.debug("###>>    "+data_object.o_msisdn+" result= "+ result);
									}// while
									if(result==1)
									{
										break;
									}
								// modification start by Avishkar on 11.12.2018
									if (Global.FALLBACK_AFTER_DEBIT_FAIL_ENABLE!=1 && result!=1) {
										logger.info("msisdn:["+data_object.o_msisdn+"] Fallback Disable after Debit Fail Response");
										break;
									}	
								//modification end by Avishkar on 11.12.2018
									
								/*}*///close	

								/*else
								{
									logger.debug("###>>    "+data_object.o_msisdn+"  Insufficient balance..");
									if(Global.g_REQUEST_TO_CHECK_BALANCE == 1 && data_object.o_accountType == 1)
									{
										result = -2;
										continue;
									}
								}*/ //not request for this charging
							}
							else if( camount == 0 )
							{
								logger.debug("msisdn:["+data_object.o_msisdn+ "] Amount::["+ camount+ "]");
								result = 1;	
								data_object.o_serviceclass = service_class;
							}
							else if( camount < 0 )
							{
								//modification start by Avishkar on 22.10.2018
									if (Global.REFUND_REQUEST_ENABLE==1) {
										logger.info("###>> msisdn["+data_object.o_msisdn+"] Credit Balance Amount Less then 0."+camount);
										camount=camount*-1;
										//amount = Integer.valueOf(camount.intValue()); // commented by Avishkar on 03.09.2019
										data_object.sendToGateway.refundBalance(data_object, camount); // modified by Avishkar on 03.09.2019
									}
								//modification end by Avishkar on 22.10.2018
								result = -4;
							}

						}//prepaid ends
						else
						{
							logger.info("msisdn :["+data_object.o_msisdn+"] Case Of Postpaid!! postpaidcheck not enable");
							result = 1;	
							service_class = 2;
							data_object.o_serviceclass = service_class;
						}
					}//camount != null -Ends
					else
					{
						result=0;
					}
					if(result==1) // block added by Avishkar on 14.08.2019
					{
						break;
					}

				}//loop end here
			}
			else
			{
				logger.info("msisdn[" +data_object.o_msisdn+ "] subtype not found , making result = -3");
				result = -3;
			}		
			switch( result )
			{
				case Global.SUCCESS_CODE :
				{
					reason = "Success";
					result = 1;
					break;
				}
				case Global.LOW_BALANCE_CODE :
				{
					reason = "Insufficient Balance";
					result = -2;
					break;
				}
				case Global.LOW_BALANCE_CODE_PRE :
				{
					reason = "Insufficient Balance";
					result = -2;
					break;
				}
				default :
				{
					reason = "Charging Failure";
					break;
				}
			}

			//this.chg_reqId = data_object.o_reqid;
			logger.debug("###>> msisdn:["+data_object.o_msisdn+"] chg_code:[" +chg_code+ "] reson:[" +reason+ "] result:[" +result+"] accountId:["+data_object.o_dedAccId+ "]");
			if(result != -2 && result != -3)
			{	
				//insertLog(data_object.o_msisdn, chg_code,reason,result,2, data_object.o_dedAccId+"");
				insertLog(data_object.o_msisdn, chg_code,reason,result,2, data_object.o_dedAccId+"" ,data_object.o_interface+","+data_object.o_action+","+data_object.o_rbtcode);
			}

			if( result == 1 )
			{
				resp_data = 1;
				_actDesc = data_object.o_action;
				//long cdrId = req_typeone.getCdrId();
				
				//modification start by Avishkar on 24.05.2020
				long cdrId=-1;
				if (Global.CDR_ID_REQUIRED_IN_CHG_REQ!=1) { // this condition is used when cdr_id is not required to send in debit request, so generating later.
					if ("oracle".equalsIgnoreCase(Global.DB_TYPE)) {
						cdrId = getCdrId();
					} else if ("mysql".equalsIgnoreCase(Global.DB_TYPE)) {
						cdrId = getLastInsertedId(); // to generate cdrId in case of mySql
					}
				} else { // already generated above before sending debit hit
					cdrId = data_object.o_cdrId;
				}
				//modification end by Avishkar on 24.05.2020
				
				//comments start by Avishkar on 16.10.2018 // this logic has been shifted above in same class
				/*int cpCode = -1;
				if( rbt > 0 )
				{
					//cpCode = req_typeone.getCpCode(rbt);
					cpCode = getCpCode(rbt);
				}*/
				//comments end by Avishkar on 16.10.2018

				logger.debug("##>>msisdn:["+data_object.o_msisdn+"] cdrsId:["+cdrId+"] cpCode:["+cpCode+"] service_class:["+service_class+"]");
				insertfullLog(cdrId, cpCode, data_object.o_msisdn, chg_code, _actDesc, data_object.o_interface, service_class,data_object.o_dedAccId, data_object.f_msisdn, rbt, camount, data_object.o_packId, chgDays, data_object.transId, data_object.o_corpId); // modified by Avishkar on 10.01.2020
				if( Global.CDR_FILE_WRITER == 1)
				{
					synchronized( flw_CdrsWriter )
					{
						flw_CdrsWriter.writeLog(cdrId+","+cpCode+","+data_object.o_msisdn+","+chg_code+","+_actDesc+","+data_object.o_interface+","+service_class+","+data_object.o_dedAccId+","+data_object.f_msisdn+","+rbt+","+camount+","+data_object.o_packId+","+chgDays);
					}
				}
				//insertfullLog(cdrId, cpCode, data_object.o_msisdn, chg_code, _actDesc, data_object.o_interface, service_class,data_object.o_dedAccId, data_object.f_msisdn, rbt, camount, data_object.o_packId, chgDays);
				status=1;
			}
			else if( result == -2 )
			{
				resp_data = -2;
				logger.info("###>> Charging for msisdn ==== "+data_object.o_msisdn+"   is UNSUCCESSFUL for amount of  ======   "+camount+" Due To Low Balance");
				throw new LowBalanceException("Low Balance::"+df.format(data_object.balance)); //Not Throwing Low Balance Exception just print // uncommented by Avishkar on 25.10.2018
			}
			else if( result == -3)
			{
				resp_data = -1;
				status = -1;
				throw new SubTypeException("SubTypeNotFound::"+result);
			}
			else if( result == -4 )
			{
				logger.info("###>>   msisdn ==== "+data_object.o_msisdn+"   camount["+camount+"] less than Zero..");
				resp_data = -1;
				status = -1;
			}
			else
			{
				resp_data = -1;
				logger.info("###>>   Charging for msisdn ==== "+data_object.o_msisdn+"   is UNSUCCESSFUL for amount of  ======   "+camount+" result:["+result+"]");
				status = -1;
			}

		}	
		else
		{
			resp_data = -1;
			logger.warn("msisdn:[" +data_object.o_msisdn+ "] tariff is null or blank so it will not continue for charing.");
		}	
		chargingCodeDays = null; //going to free ArrayList ref
		//logger.debug("...........RequestTypeOne end here  resp_data["+resp_data+"].......................");  
		return resp_data;
	}


/*	private boolean checkInCoreAdvance(String msisdn,double chargeAmt, Data_Object data_object)
	{
		boolean deductFromCore=false;
		boolean deductFromAdvance=false;
		try{
			logger.debug(" MSISDN ["+msisdn+"] chargeAmt ["+chargeAmt+"] Core ["+data_object.balance+"] Advance ["+data_object.advancebalance+"]");
			if(chargeAmt<data_object.balance)  //Core_advance[0] corosponds to core balance
			{
				deductFromCore=true;
				deductFromAdvance=false;
			}
			if(deductFromCore||deductFromAdvance)
				return true;
			else return false;
		}
		catch(Exception exp)
		{
			logger.error("exception in checkInCoreAdvance",exp);
			return false;
		}
	}//checkInCoreAdvance  */ //not required for this charing
}
