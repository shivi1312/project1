package chargingserver;

import java.util.concurrent.ThreadPoolExecutor;

import FileBaseLogging.*;
import java.io.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import org.apache.log4j.*;


public class ThreadMonitor implements Runnable
{
	static final Logger logger=Logger.getLogger(ThreadMonitor.class);
	private ThreadPoolExecutor contentexecutorPool;
	private int seconds;

	private boolean run=true;

	FileLogWriter flw = null;
	FileLogWriter flw_balancededuct = null;
	FileLogWriter flwCdrsWrite = null;

	public ThreadMonitor(ThreadPoolExecutor executor, int delay,FileLogWriter flw,FileLogWriter flw_balancededuct,FileLogWriter flw_cdrswrite)
	{
		this.contentexecutorPool = executor;

		this.flw_balancededuct=flw_balancededuct;
		this.flw=flw;
		this.flwCdrsWrite = flw_cdrswrite;

		this.seconds=delay;
	}

	public void shutdown(){
		this.run=false;
	}

	@Override
		public void run()
		{
			int activeCount  = 0;
			while( run )
			{
				try
				{
					/*
					if(logger.isEnabledFor(Level.DEBUG))
					  {
					  logger.debug("[monitor] size is ["+this.contentexecutorPool.getPoolSize()+"]");
					  logger.debug("[monitor] core pool size ["+this.contentexecutorPool.getCorePoolSize()+"]");
					  logger.debug("[monitor] active count ["+this.contentexecutorPool.getActiveCount()+"]");
					  logger.debug("[monitor] complete task count ["+this.contentexecutorPool.getCompletedTaskCount()+"]");
					  logger.debug("[monitor] task count ["+this.contentexecutorPool.getTaskCount()+"]");
					  logger.debug("[monitor] is shutdow ["+this.contentexecutorPool.isShutdown()+"]");
					  logger.debug("[monitor] is terminated ["+this.contentexecutorPool.isTerminated()+"]");
					  }*/
					
					   logger.debug(
					   String.format("[monitor] [%d/%d] Active: %d, Completed: %d, Task: %d, isShutdown: %s, isTerminated: %s",
					   this.contentexecutorPool.getPoolSize(),
					   this.contentexecutorPool.getCorePoolSize(),
					   this.contentexecutorPool.getActiveCount(),
					   this.contentexecutorPool.getCompletedTaskCount(),
					   this.contentexecutorPool.getTaskCount(),
					   this.contentexecutorPool.isShutdown(),
					   this.contentexecutorPool.isTerminated()));
					activeCount = this.contentexecutorPool.getActiveCount();
					logger.info("Size of the Que :["+Global.que.size()+"] Count of ActiveThread:["+activeCount+"]");
				//	if((Global.que.size()>3 && activeCount <Global.numofcontentthreads) || activeCount == 0 )
				//	{
				//		contentexecutorPool.execute(new ChargingServer(flw,flw_balancededuct,flwCdrsWrite));
				//	}


				}
				catch(Exception es)
				{
					es.printStackTrace();
				}


				try 
				{
					Thread.sleep(seconds*1000);
				}catch (InterruptedException e) { e.printStackTrace(); }
			}
		}
}
