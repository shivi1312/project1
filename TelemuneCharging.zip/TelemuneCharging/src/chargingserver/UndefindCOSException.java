package chargingserver;

public class UndefindCOSException extends Exception
{
public UndefindCOSException()
        {
        super("Undefind COS Found");
        }
public UndefindCOSException(String reason)
        {
         super(reason);
        }
public UndefindCOSException(Exception exp)
    {
        super(exp.getMessage());
        //System.out.println("exception converted");
        
    }

 @Override
    public String toString() {
        return super.toString();
    }

}
