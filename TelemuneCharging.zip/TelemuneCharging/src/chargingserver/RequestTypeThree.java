package chargingserver;

import FileBaseLogging.*;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.*;
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.security.MessageDigest;
import java.text.DecimalFormat;


/**
 * This class is defined to check Balance only.
 * */
public class RequestTypeThree extends CommonAbstract
{
	private static Logger logger = Logger.getLogger("RequestTypeThree");

	public  RequestTypeThree(){}

	public int requestTypeThree(Data_Object data_object)throws UndefindCOSException,SocketTimeoutException,ConnectException,Exception
	{
		int  prepaid_status = -1;
		int resp_data = -1;

		data_object.o_minimum_amount = 0;

		if( data_object.o_subtype.equalsIgnoreCase("O") )
		{
			logger.debug("msisdn :[" +data_object.o_msisdn+"] It is Postpaid, setting prepaid_status:[1]");
			resp_data = 1;	
			prepaid_status = 1;
		}
		else if( data_object.o_subtype.equalsIgnoreCase("P") )
		{
			logger.debug("msisdn :[" +data_object.o_msisdn+"] It is Prepaid, setting prepaid_status:[0]");
			prepaid_status = 0;
			resp_data = 1;
		}
		else if( data_object.o_subtype.equalsIgnoreCase("N") )
		{
			/**  find status for subscriber type */
			prepaid_status = -1;
			logger.debug("msisdn:[" +data_object.o_msisdn+ "] for subType N , we checking subType");
			prepaid_status = data_object.sendToGateway.findSubType( data_object );
			logger.debug("msisdn:[" +data_object.o_msisdn+ "] After finding subType ret_val of prepaidStatus: "+prepaid_status);
		}

		if( prepaid_status == 0 ) /** if it is prepaid  */
		{
			data_object.o_accountType = 1;
			logger.debug("Going to check balance from gateway....");
			int results = data_object.sendToGateway.checkBalance(data_object);
			if( results >= 1 )
			{
				resp_data = 1;
			}
			else
			{
				resp_data = -1;
			}
		}
		/*else if(prepaid_status == 2 || prepaid_status == 3) 
		{
			data_object.o_accountType = 2;
			int results = data_object.sendToGateway.checkBalance(data_object);
			if( results == 1 )
			{
				resp_data =1;
			}
			else
			{
				resp_data = -1;
			}
		}*/
		else
		{
			resp_data = -1; 
		} 
		return resp_data;
	}		
}
