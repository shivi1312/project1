package chargingserver;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.log4j.*;

public abstract class  CommonAbstract
{
	private static Logger logger=Logger.getLogger("CommonAbstract");

	//private String query_req="insert into crbt_chg_request(req_date,req_id,msisdn,charging_code,description, account_type) values(sysdate,CRBT_CHG_REQID.nextval,?,?,?,?)"; // Commented by Avishkar on 25.03.2019
	private String query_req=DBQuery.saveChgRequest; // Modified by Avishkar on 25.03.2019
	//private String query_res="insert into crbt_chg_response(req_date,req_id,msisdn,charging_code,description,account_type,resp_code) values(sysdate,CRBT_CHG_REQID.nextval,?,?,?,?,?)";
	//private String query_res="insert into crbt_chg_response(req_date,req_id,msisdn,charging_code,description,account_type,resp_code,other) values(sysdate,CRBT_CHG_REQID.nextval,?,?,?,?,?,?)"; // Commented by Avishkar on 25.03.2019
	private String query_res=DBQuery.saveChgResponse; // Modified by Avishkar on 25.03.2019

	int result = -1;
	String vlr = "", scfAddress = "", busyNumber = "", noReplyNumber = "", unreachableNumber = "";
	StringBuffer msrnBuf ;
	StringBuffer imsiBuf ;
	StringBuffer cfuActiveStr;

	int serviceKey=0;
	Boolean isRoaming = true;
	Boolean isPrepaid = true;
	Boolean cfuActive = true;
	int msrnError =0;

	public CommonAbstract(){}

	protected int getChargingCodeDays(ArrayList<ChargingCodeAmount> chargingCodeDays,String tarrifId)
	{
		result = -1;
		try
		{
			int i=-1;	
			int j=-1;
			int[] chgCodeDays=new int[2];
			String[] s1=new String[20];
			StringTokenizer s = new StringTokenizer(tarrifId ,";");
			while (s.hasMoreTokens())
			{
				i++;
				s1[i]=s.nextToken();
			}

			for(int cntr=0;cntr<19;cntr++)
			{
				if(s1[cntr]!=null)
				{
					ChargingCodeAmount chargingCodeAmount=null;
					StringTokenizer stParam=new StringTokenizer(s1[cntr],":");
					j=-1;
					while(stParam.hasMoreTokens())
					{
						j++;
						chgCodeDays[j]=Integer.parseInt(stParam.nextToken());  
					}
					chargingCodeAmount=new ChargingCodeAmount();
					chargingCodeAmount.setChargingCode(chgCodeDays[0]);
					chargingCodeAmount.setChargingDays(chgCodeDays[1]);
					chargingCodeDays.add(chargingCodeAmount);
					//logger.info("ChargingCode:["+chgCodeDays[0]+"] ChargingDays:["+chgCodeDays[1]+"]");
				}
			}

			if(chargingCodeDays.size() > 0)
			{
				result =1; 
			}
		}
		catch(Exception exp)	
		{
			logger.error("Err inside getChargingCodeDays method");
			exp.printStackTrace();
			result = -1;	
		} 
		return result;
	}


	protected void insertLog(String msisdn,int chg_code,String desc,int resp_code, int req_for, String acId,String other_data)
	{
		String query_log="";
		Connection con = null;
		PreparedStatement pstmt=null; 

		logger.debug("..............................msisdn["+msisdn+"] insertLog start here................................");

		try
		{
			if(req_for==1)
				query_log=query_req;
			else
				query_log=query_res;
			String print_log = query_log.replaceFirst( "\\?", msisdn ).replaceFirst( "\\?", chg_code+"" ).replaceFirst( "\\?", "'"+desc+"'" ).replaceFirst( "\\?", acId+"" ).replaceFirst( "\\?", resp_code+"" ).replaceFirst("\\?",other_data+"" );

			logger.debug("QUERY :: "+print_log); // modified by Avishkar on 04.1.2019

			con = Global.conPool.getConnection();

			pstmt=con.prepareStatement(query_log);
			pstmt.setString(1,msisdn);
			pstmt.setInt(2,chg_code);
			pstmt.setString(3,desc);
			pstmt.setInt(4,Integer.parseInt(acId));
			if(query_log.equalsIgnoreCase(query_res))
				{
				pstmt.setInt(5,resp_code);
				pstmt.setString(6,other_data); // other_data include :- interface,action,rbtcode
				}

			pstmt.executeUpdate();
			logger.debug("..............................msisdn["+msisdn+"] insertLog end here................................");

		}
		catch(SQLException sqlex)
		{
			logger.error("Problem while excuting query::",sqlex);
		}
		finally
		{
			if(pstmt != null) { try { pstmt.close(); } catch(Exception e){}	}
			if(con != null) { try { con.close(); } catch(Exception e){}	}
			pstmt = null; con = null;
		}
	}

	protected long getCdrId()
	{
		long l_result =-1;
		String l_query ="";
		Connection con =null; 
		Statement stmt =null; 
		ResultSet rs = null;

		try
		{
			con=Global.conPool.getConnection();
			l_query= DBQuery.fetchCdrId; //"Select crbt_cdr_id.nextval from dual"; // Modified by Avishkar on 25.03.2019
			stmt=con.createStatement();	
			rs=stmt.executeQuery(l_query);
			if(rs.next())
			{
				l_result=rs.getLong(1);
			}
		}
		catch(SQLException sqlex)
		{
			logger.error("Problem in excuting query::",sqlex);
		}
		finally
		{
			if(rs != null) { try { rs.close(); } catch(Exception e){}	}
			if(stmt != null) { try { stmt.close(); } catch(Exception e){}	}
			if(con != null) { try { con.close(); } catch(Exception e){}	}
			rs = null; stmt = null; con = null;
		}
		return l_result;
	}

	protected synchronized int getCpCode(int rbtCode)
	{
		int cpId=0;
		String query = "";
		Connection con = null;
		//Statement stmt = null; //commented by Avishkar on 16.04.2019
		ResultSet rs = null;
		PreparedStatement pstmt=null; // added by Avishkar on 16.04.2019

		try
		{
			if(Global.cpCodeRbtCode.containsKey(rbtCode))
			{
				cpId=Global.cpCodeRbtCode.get(rbtCode);
				return cpId;
			}

			con=Global.conPool.getConnection();
			// Modification start by Avishkar on 16.04.2019
			//stmt=con.createStatement();
			query=DBQuery.fetchCpCode; //"select RBT_CODE,CONTENT_PROVIDER_CODE from crbt_rbt where RBT_CODE='"+rbtCode+"'"; // Modified by Avishkar on 25.03.2019
			String print_log = query.replaceFirst( "\\?", rbtCode+"");
			logger.info("query==="+print_log+" and RBT_CODE ["+rbtCode+"]");
			pstmt=con.prepareStatement(query);
			pstmt.setInt(1, rbtCode);
			//rs=stmt.executeQuery(query);
			rs=pstmt.executeQuery();
			// Modification ends by Avishkar on 16.04.2019
			if(rs.next())
			{
				logger.info(" RBT_CODE ==="+rs.getInt(1)+"    CONTENT_PROVIDER_CODE ==="+rs.getInt(2));
				try
				{
					cpId=rs.getInt(2);
					Global.cpCodeRbtCode.put(rbtCode,cpId);
				}catch(Exception see)
				{
					logger.error("Can't insert into HashTable",see);
				}
			}
			else
			{
				logger.warn(" No Conetent Provider Id found in crbt_rbt for RBT_CODE ["+rbtCode+"]");
				cpId=0;
			}
		}
		catch(Exception exp)
		{
			logger.error("Exception while getting CPCode "+exp);
		}
		finally
		{
			if(rs != null) { try { rs.close(); } catch(Exception e){}	}
			//if(stmt != null) { try { stmt.close(); } catch(Exception e){}	}
			if( pstmt != null ) { try { pstmt.close(); }catch(Exception e){} } // modified by Avishkar on 16.04.2019
			if(con != null) { try { con.close(); } catch(Exception e){}	}
			//rs = null; stmt = null; con = null;
			rs = null; pstmt = null; con = null; // modified by Avishkar on 16.04.2019
		}
		return cpId;
	}


	protected void insertfullLog(long cdrId,int cpCode,String msisdn,int tariffid,int action,String interfaceUsed,int service_class,int da_id,String fmsisdn,int rbtcode,double amount,int packId,int chgDays,String transId,int corpId) // modified by Avishkar on 10.01.2020
	{

		Connection con = null;
		PreparedStatement pstmt=null; 

		logger.debug("##>>msisdn["+msisdn+"] Inside insertFullLog method start here cdrsId["+cdrId+"]");

		//String query_log=//"insert into CRBT_CDRS(cdr_id,msisdn,tariffid,action,interface,service_class,da_id,create_date,fmsisdn,rbt_code,amount,pack_id,DAYS,CP_CODE) values(?,?,?,?,?,?,?,sysdate,?,?,?,?,?,?)"; // Commented by Avishkar on 23.03.2019
		String query_log=DBQuery.saveCdrsRecord; // Modified by Avishkar on 23.03.2019
		String query_log_1=query_log.replaceFirst("\\?",cdrId+"").replaceFirst("\\?","'"+msisdn+"'").replaceFirst("\\?",tariffid+"").replaceFirst("\\?",action+"").replaceFirst("\\?","'"+interfaceUsed+"'").replaceFirst("\\?",service_class+"").replaceFirst("\\?",da_id+"").replaceFirst("\\?","'"+fmsisdn+"'").replaceFirst("\\?",rbtcode+"").replaceFirst("\\?",amount+"").replaceFirst("\\?",packId+"").replaceFirst("\\?",chgDays+"").replaceFirst("\\?",cpCode+"").replaceFirst("\\?",transId+"").replaceFirst("\\?",corpId+""); // modified by Avishkar on 10.01.2020
		logger.debug("Query :["+query_log_1+"]"); // modified by Avishkar on 04.1.2019

		try
		{
			con = Global.conPool.getConnection();
			pstmt=con.prepareStatement(query_log);
			pstmt.setLong(1,cdrId);
			pstmt.setString(2,msisdn);
			pstmt.setInt(3,tariffid);
			pstmt.setInt(4,action);
			pstmt.setString(5,interfaceUsed);
			pstmt.setInt(6,service_class);
			pstmt.setInt(7,da_id);
			pstmt.setString(8,fmsisdn);
			pstmt.setInt(9,rbtcode);
			pstmt.setDouble(10,amount);
			pstmt.setInt(11,packId);
			pstmt.setInt(12,chgDays);
			pstmt.setInt(13,cpCode);
			pstmt.setString(14,transId); // added by Avishkar on 10.01.2020
			pstmt.setInt(15,corpId); // added by Avishkar on 10.01.2020

			pstmt.executeUpdate();
			logger.debug("##>>msisdn ["+msisdn+"] insertFullLog method ends here.....................");

		}
		catch(SQLException sqlex)
		{
			logger.error("Problem in excute query::",sqlex);
		}
		finally
		{
			if(pstmt != null) { try { pstmt.close(); } catch(Exception e){}	}
			if(con != null) { try { con.close(); } catch(Exception e){}	}
			pstmt = null; con = null;
		}
	}


	/*
	 * this function check for subscriber type from crbt_subscriber_master 
	 * using msisdn of user and retuen sub type
	 */

	protected String checkForSubType(String msisdn)
	{
		String subType="N";
		Connection con = null;
		PreparedStatement pstmt=null; 
		ResultSet rs = null;

		try
		{
			con = Global.conPool.getConnection();
			String query = DBQuery.fetchSubType; //"select SUB_TYPE from crbt_subscriber_master where MSISDN=?"; // Modified by Avishkar on 25.03.2019
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			rs = pstmt.executeQuery();

			if(rs.next())
			{
				subType = rs.getString("SUB_TYPE");
				logger.debug("###>> query:"+query+"    "+msisdn+"  ret_val DB SUBTYPE:"+subType);
			}
		}
		catch(Exception e)
		{
			logger.error("Problem in excuting query :: "+e.getMessage()+"]");
		}
		finally
		{
			if( rs!= null ) { try {	rs.close(); }catch(Exception e){} }
			if( pstmt != null ) { try { pstmt.close(); }catch(Exception e){} }
			if( con != null ) { try { con.close(); }catch(Exception e){} }
			rs = null; pstmt = null; con = null;
		}
		return subType;
	}



	/*
	 * this Function process pending request if balance in reserver status
	 * using msisdn and return 1 for success and -1 for unsuccess
	 */
	/*	public int insertPendingReq(String msisdn)
		{
		int res=-1;
		PreparedStatement pstmt=null;
		try{
		this.con=Global.conPool.getConnection();
		String query="update crbt_pending_request set SUB_TYPE='P' where MSISDN=?";
		pstmt=con.prepareStatement(query);
		pstmt.setString(1,msisdn);
		pstmt.executeUpdate();
		pstmt.close();
		logger.debug("###>>   updated subtype in db for :"+msisdn);
		res=1;
		}
		catch(Exception e)
		{
		logger.info("###>> "+msisdn+"  updated subtype in db");
		if(pstmt!=null)
		try {
		pstmt.close();
		} catch (SQLException e1) {
		logger.error("##>>msisdn["+msisdn+"] Err inside insertPendingReq");
		e1.printStackTrace();
		}

		}
		return res;
		}*/
	
	/**@author avishkar
	 * this method is to generate cdrId through sequence in case of mysql DB. 
	 */
	public int getLastInsertedId() {
        int numero;
        int insertedId=-1;
        Connection connection=null;
        Statement statement=null;
        ResultSet rs = null;
        try {
        	connection=Global.conPool.getConnection();
            //connection=MySQLConnection.getInstance().getConnection();
            String sql="insert into cdr_seq_id values (null)";
            statement=connection.createStatement();
            //Statement stmt = prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            numero = statement.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);

            rs = statement.getGeneratedKeys();
            if (rs.next()){
                insertedId=rs.getInt(1);
            }
            
            rs.close();
            statement.close();
            connection.close();
            
            return insertedId;
            
            
        }catch(SQLException exception){
            try {
                if(rs!=null) rs.close();
                if(statement!=null)statement.close();
                if(connection!=null) connection.close();
            } catch (SQLException e) {
            	logger.error("Exception in closing resources inside getLastInsertedId method: ",e);
                e.printStackTrace();
            }
            logger.error("Exception in generating cdrId inside getLastInsertedId method: ",exception);
        } catch (Exception e) {
            try {
                if(rs!=null) rs.close();
                if(statement!=null)statement.close();
                if(connection!=null) connection.close();
            } catch (SQLException ex) {
            	logger.error("Exception in generating cdrId inside getLastInsertedId method: ",e);
                ex.printStackTrace();
            }
            logger.error("Exception in generating cdrId inside getLastInsertedId method: ",e);
            e.printStackTrace();
        }finally {
            try {
                if(rs!=null) rs.close();
                if(statement!=null)statement.close();
                if(connection!=null) connection.close();
            }catch(SQLException exception) {
            	logger.error("Exception in generating cdrId inside getLastInsertedId method: ",exception);
                exception.printStackTrace();
            }
            
        }
        return insertedId;
        
    }

}
