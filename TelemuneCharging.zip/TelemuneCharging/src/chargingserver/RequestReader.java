package chargingserver;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.net.Socket;
import org.apache.log4j.Logger;
import commonutil.*;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

public class RequestReader implements Runnable // modified by by ashu 01-07-2019
{

	static final Logger logger = Logger.getLogger(RequestReader.class);

	Connection con = null;
	ResultSet rs = null;
	Statement stmt = null;
	String query = DBQuery.fetchRequestId; //"select crbt_chg_reqid.nextVal as reqid  from dual"; // Modified by Avishkar on 25.03.2019

	// addition start by ashu 01-07-2019  
	Socket socket=null;
	TLVAppInterface tcp_req = null;

	RequestReader(String  sockString,Socket sock) 	
	{
		socket=sock;
		tcp_req = new TLVAppInterface();

	}
	
	public void run()
	{

		readPacket();
	}
	//addition ends by ashu 01-07-2019
	
	public void readPacket() // modified by ashu 01-07-2019
	{
		try
		{
		//	logger.debug("#############>>>>>>>>>>>>>>>>>>>> inside run of RequestReader");

			String l_msisdn = "";
			int l_reqtype = 0;
			int dataLen = 0;
			byte dataBuf[] = null;
			int test = 0;
			Data_Object data_object = null;
			DataInputStream reader = null;

			if (socket.isClosed())
			{
				return;
			}


//			logger.debug("reading Info ........");

			try
			{
				reader = new DataInputStream(socket.getInputStream());
				dataBuf = new byte[4];

				// reading first 4 bytes if it is -1 then close the socket and return
				if(reader.read(dataBuf,0,4)==-1)
				{
					//logger.debug("reader.read == -1 ...");
					try
					{
						socket.close();
						return;
					}
					catch(Exception e) {e.printStackTrace(); }
				}
				/*for(int j=0;j<dataBuf.length;j++)
				  {
				  System.out.println("readerr   ["+j+"] ::: "+dataBuf[j]);
				  }*/

				dataLen = dataLen | (dataBuf[0] << 24);
				dataLen = dataLen  | (dataBuf[1] << 16);
				dataLen = dataLen | (dataBuf[2] << 8);
				test=(0x000000ff & dataBuf[3]);
				dataLen = dataLen | test;
				//System.out.println("reading Info ......data len.."+dataLen);
			}
			catch (Exception e)
			{
				e.printStackTrace();
				logger.error("Exception while reading first 4 bytes on socket ::["+e.getMessage()+"]");
				try
				{
					Thread.sleep(1);
					socket.close();
				}
				catch(Exception ex) {	ex.printStackTrace();	}	
			}

			//logger.debug("recieved tcp_req size["+dataLen+"]");
			if (dataLen == 0)
			{	
				logger.warn("Length of first 4 bytes is ["+dataLen+"] so sleeping 10 millis and return");
				try
				{
					Thread.sleep(10);
				}
				catch(Exception eee){eee.printStackTrace();}
				return;
			}

			dataBuf = new byte[dataLen];
			reader.read( dataBuf, 0, dataLen);
			//logger.info("just priting readed"+dataBuf);
			tcp_req.decode( new ByteArrayInputStream( dataBuf) ,dataLen );

			l_msisdn = tcp_req.getData (Global.MSISDN_TAG).trim();
			l_reqtype = Integer.parseInt(tcp_req.getData (Global.REQTYPE_TAG));

			if(l_msisdn.equalsIgnoreCase("") || l_msisdn== null || l_msisdn=="" || l_msisdn.length() < Global.MSISDN_MIN_LENGTH )
			{
				try
				{
					socket.close();
					logger.error("stream closed because l_msisdn:["+l_msisdn+"]");
				}
				catch(Exception e)
				{
					logger.error(e);
				}
				return;
			}

			data_object = new Data_Object();
			
			//data_object.o_reqid = getRequestId(); //commented by Avishkar on 11.01.2019
			//logger.debug("Query:["+query+"] data_object.o_reqid  :["+data_object.o_reqid+"]"); //commented by Avishkar on 11.01.2019
			data_object.redirectTagValue = tcp_req.getData(Global.REDIRECT_TAG); // added by Avishkar on 26.11.2018
			
			//modified by Avishkar on 11.01.2019 starts
			if (data_object.redirectTagValue==null && Global.IS_SECOND_CHARGING_ENABLE==1) {
				//data_object.o_reqid = getRequestId(); //Commented by Avishkar on 16.04.2019
				data_object.o_reqid = Global.getChgReqId(); // modified by Avishkar on 16.04.2019
				logger.debug("Query:["+query+"] data_object.o_reqid  :["+data_object.o_reqid+"]");
			}
			else {
				data_object.o_reqid = Integer.parseInt(tcp_req.getData(Global.REQID_TAG));
			}
			//modified by Avishkar on 11.01.2019 ends
			
			if( l_reqtype == 1 ) // to checkBalance and deductBalace
			{
				//data_object.o_reqid = Global.getChgReqId();
				data_object.o_msisdn = l_msisdn;
				data_object.o_tariffid = (tcp_req.getData(Global.TARIFFID_TAG));
				data_object.o_action = Integer.parseInt(tcp_req.getData(Global.ACTION_TAG));
				data_object.o_subtype = tcp_req.getData(Global.SUB_TYPE);
				data_object.o_interface = tcp_req.getData(Global.INTERFACE_TAG);
				data_object.f_msisdn = tcp_req.getData(Global.FMSISDN_TAG);
				data_object.o_rbtcode = tcp_req.getData(Global.RBTCODE_TAG);
				// addition start by Avishkar on 28.11.2018
				if (tcp_req.getData(Global.AMOUNT_TAG)!=null) {
					//data_object.o_camount = Integer.parseInt(tcp_req.getData(Global.AMOUNT_TAG));
					data_object.o_camount = Double.parseDouble(tcp_req.getData(Global.AMOUNT_TAG)); // modified by Avishkar on 03.09.2019
				}
				// addition ends by Avishkar on 28.11.2018
				data_object.o_reqtype = l_reqtype;
				if(tcp_req.getData(Global.PACKID_TAG)!= null) 
					data_object.o_packId = Integer.parseInt(tcp_req.getData(Global.PACKID_TAG));
				else
					data_object.o_packId = -1;
				
				// addition start by Avishkar on 10.01.2020
				if(tcp_req.getData(Global.CORPID_TAG)!=null){
					data_object.o_corpId = Integer.parseInt(tcp_req.getData(Global.CORPID_TAG));
				}
				//addition ends by Avishkar on 10.01.2020
				
				data_object.sock = socket;
			}
			else if( l_reqtype == 2 ) // to check reserveStatus only
                        {
                                data_object.o_msisdn = l_msisdn;
                                data_object.o_reqtype = l_reqtype;
                                data_object.sock = socket;
                                data_object.o_subtype = tcp_req.getData(Global.SUB_TYPE);
                        }
			else if( l_reqtype == 3 ) // to checkBalance only
			{
				data_object.o_msisdn = l_msisdn;
				data_object.o_reqtype = l_reqtype;
				data_object.sock = socket;
				data_object.o_subtype = tcp_req.getData(Global.SUB_TYPE);
			}
			else if( l_reqtype == 6 ) //to checkSubType
			{
				data_object.o_msisdn = l_msisdn;
				data_object.o_reqtype = l_reqtype;
				data_object.sock = socket;
				//  data_object.o_subtype =  tcp_req.getData(Global.SUB_TYPE);
			}
			else
			{
				logger.error("Undefined RequestType l_reqtype:["+l_reqtype+"]");
				try
				{
					socket.close();
					return;
				}
				catch(Exception e) {e.printStackTrace(); }
			}
			//logger.info("Received Data :["+data_object+"]");
			Global.que.put(data_object);
			logger.info("Received Request :["+data_object+"] is INSERTED in Queue.");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error("Exception :: ["+e.getMessage()+"]");
		}
	/*	finally
		{
			if( socket != null )
			{
				try
				{
					socket.close();
				}catch(Exception e){e.printStackTrace();}
				socket = null;
			}

		}*/

	}
	private int getRequestId()
	{
		int reqId = -1;
		con = Global.conPool.getConnection();
		if( con != null )
		{
			try
			{
				//logger.info("query :["+query+"]");
				stmt = con.createStatement();
				rs = stmt.executeQuery(query);
				if( rs.next())
				{
					reqId = rs.getInt("reqid");
				}

			}
			catch(Exception sqle)
			{
				logger.info("Excute Update"+ sqle.toString());
			}
			finally
			{
				if( stmt != null )
				{
					try
					{
						stmt.close();
					}catch(Exception e){e.printStackTrace();}
					stmt = null;
				}
				if( con != null )
				{
					try
					{
						con.close();
					}catch(Exception e){e.printStackTrace();}
					con = null;
				}
			}
		}
		return reqId;
	}
}
