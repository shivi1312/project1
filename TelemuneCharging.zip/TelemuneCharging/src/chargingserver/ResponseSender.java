package chargingserver;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.apache.log4j.Logger;
import commonutil.*; 

public class ResponseSender implements Runnable {

	static final Logger logger = Logger.getLogger(ResponseSender.class);

	Connection con = null;
	ResultSet rs = null;
	PreparedStatement stmt = null;
	//String query = "insert into CRBT_CHARGING_LOG (REQ_ID,MSISDN,CHARGING_CODE,RESPONSE,RESPONSE_TIME) values(?,?,?,?,sysdate)"; // Commented by Avishkar on 25.03.2019
	String query = DBQuery.saveChgLog; // Added by Avishkar on 25.03.2019
	String name;
	Data_Object data_element = null;
	DataOutputStream stream_send_data;
	TLVAppInterface send_request = null;
	ByteArrayOutputStream send_buf = null;
	ResponseSender(String name)
	{
		logger.info("========sending data thread==========");
		this.name = name;
		logger.info("started thread to send data: # " + name );
	}

	public void run()
	{
		sendtoclient(name);
	}

	public void sendtoclient(String name)
	{
		logger.info("preparing data from queue to send ......");
		try
		{
			//int ls_reqdata = -1;
			int send_requestLen = 0;

			while(true)
			{

				if (Global.que_send.isEmpty())
				{
					try
					{
						Thread.sleep(1);
					}
					catch(InterruptedException E)
					{
					}
				}
				else
				{
					data_element = Global.que_send.poll();

					//ls_reqdata = -1;

					send_request = new TLVAppInterface();

					send_request.setData(Global.REQID_TAG,data_element.o_reqid);
					send_request.setData(Global.MSISDN_TAG,data_element.o_msisdn);
					send_request.setData(Global.ACTION_TAG,data_element.o_action);
					send_request.setData(Global.INTERFACE_TAG,data_element.o_interface);
					send_request.setData(Global.TARIFFID_TAG,data_element.o_tariffid);
					send_request.setData(Global.SUB_TYPE,data_element.o_subtype);
					send_request.setData(Global.RBTCODE_TAG,data_element.o_rbtcode);
					send_request.setData(Global.RESPONSE_TAG,data_element.res_data);
					send_request.setData(Global.REQTYPE_TAG,data_element.o_reqtype);
					send_request.setData(Global.AMOUNT_TAG,data_element.o_amount);

					send_buf = new ByteArrayOutputStream();

					send_request.encode(send_buf);
					send_requestLen = send_buf.size();

					String print_log = query.replaceFirst( "\\?", data_element.o_reqid+"" ).replaceFirst( "\\?", data_element.o_msisdn).replaceFirst( "\\?", data_element.o_chgcode+"").replaceFirst( "\\?", data_element.res_data );
					try{
						logger.debug("is_socketClosed ::["+data_element.sock.isClosed()+"]");
						// Modification start by Avishkar on 29.11.2018
						if (Global.IS_SECOND_CHARGING_ENABLE==1) { // here it means Charging is acting as Fisrt Charging & db configuration has been done and we can perform db operations
							if ( data_element.sock.isClosed())
							{
								con = Global.conPool.getConnection();
								if(con!=null)
								{
									try
									{
										stmt = con.prepareStatement(query);
										stmt.setInt(1,data_element.o_reqid);
										stmt.setString(2,data_element.o_msisdn);
										//stmt.setInt(3,ls_reqdata);
										stmt.setInt(3,data_element.o_chgcode);
										stmt.setString(4,data_element.res_data);
										logger.info(print_log);
										stmt.executeUpdate();
										stmt.close();
										con.close();
									}
									catch(Exception sqle)
									{
										logger.info("Excute Update"+ sqle.toString());
									}
								}
								continue;
							}
						}
						// Modification ends by Avishkar on 29.11.2018
						stream_send_data = new DataOutputStream( data_element.sock.getOutputStream());
						logger.debug("writing Info buf size="+send_requestLen);
						byte[] len=new byte[4];
						len[3] = (byte)(send_requestLen );
						len[2] = (byte)((send_requestLen >> 8) );
						len[1] = (byte)((send_requestLen >> 16));
						len[0] = (byte)((send_requestLen >> 24));
						stream_send_data.write(len,0, 4);

						logger.info("msisdn:["+data_element.o_msisdn+"] XXXXXXXXXXXXXXXXXXXXXXX Data length sent of  buf size="+send_requestLen);
						stream_send_data.write(send_buf.toByteArray(), 0, send_buf.toByteArray().length);
					}
					catch(Exception eee)
					{
						try
						{
							logger.info("Exception Sending Data:: "+eee.toString());
						}
						catch(Exception e)
						{
							logger.info(e);
						}
					}
					finally
					{
						if( data_element.sock != null )
						{
							try
							{
								data_element.sock.close();
							}catch(Exception e){e.printStackTrace();}
							data_element.sock = null;
						}
						if( con != null )
						{
							try
							{
								con.close();	
							}
							catch(Exception econ1){}  
							con = null;
						}
					}
					data_element = null;	
				}
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error(e);
			logger.error(" send to client stopped success ");
			System.exit(1);
		}
	}
}
