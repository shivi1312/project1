package chargingserver;

public class ChargingCodeAmount 
{
	private  int chargingCode=-1;
	private  float chargingAmount=0f;
	private int chargingDays=-1;

	public int getChargingCode() 
	{
		return chargingCode;
	}

	public void setChargingCode(int chargingCode) {
		this.chargingCode = chargingCode;
	}
	public float getChargingAmount() 
	{
		return chargingAmount;
	}

	public void setChargingAmount(float chargingAmount)
	{ 
		this.chargingAmount = chargingAmount;
	}

	public int getChargingDays() 
	{
		return chargingDays;
	}

	public void setChargingDays(int chargingDays) 
	{
		this.chargingDays = chargingDays;
	}
}
