package chargingserver;

import org.apache.log4j.Logger;

import com.telemune.client.ThirdPartyRequest;

import java.text.DecimalFormat;
import FileBaseLogging.FileLogWriter;

/**

 * @author Athar Karim
 *This class implements runnable interface which check for user status and try to deduct and check balance
 */

public class ChargingServer extends CommonAbstract implements Runnable 
{
	static final Logger logger = Logger.getLogger("ChargingServer");

	Data_Object data_object = null;

	FileLogWriter flw_perRequest = null;
	FileLogWriter flw_balancewriter = null;
	FileLogWriter flw_CdrsWriter = null;

	DecimalFormat df = null;


	public ChargingServer(FileLogWriter flw_perRequest,FileLogWriter flw_balancewriter,FileLogWriter flw_cdrswriter,Data_Object data_object)
	{
		this.flw_perRequest = flw_perRequest;
		this.flw_balancewriter = flw_balancewriter;
		this.flw_CdrsWriter = flw_cdrswriter; 
		this.data_object=data_object;
	}
	
	public ChargingServer(){}
	
	public void run()
	{
		df = new DecimalFormat("#.######");
		int temp_cntr = 0;
		//while(true)
		{
			try
			{
				if (data_object.redirectTagValue==null && Global.IS_SECOND_CHARGING_ENABLE==1) { // this if-else block is added by Avishkar on 26.11.2018
																								// it means Charging itself is acting as First Charging, so it may redirect hit to other charging, if applicable.
					/*		if (Global.que.isEmpty())
					{
					try
					{		
					Thread.sleep(2);				
			//Global.rst(true);
			if(temp_cntr==3000)
			break;
			else
			temp_cntr++;
			}
			catch(Exception e)
			{
			logger.error("exception in charging server");

			}
			}
			else
			 */
			{

				//temp_cntr = 0;
				/*data_object = new Data_Object();
				data_object = (Data_Object) Global.que.poll();
				if( data_object == null ) 
				{
					logger.info (" # Request data is null");
					continue;
				}
*/
				String accountId = "0"; // 0 - main account : 8-DA8 account

				int result 	= -1;
				int req_type 	= -1;
				int status 	= 0;
				double  totalBalance	= 0.0;
				String resdata		= "";

				try
				{
					try
					{
						req_type = data_object.o_reqtype;
						if(req_type == 1) /** req_type 1 intended to Check Balance and Deduct Balance */
						{
							/** 
							  We need object of SoapRequest on per hit, It is mandatory when a request do login at gateway and after login do some operation and finally logged out.
							  In such a situation another request must not work on old object and hence new object is required per request.
							 */
//							data_object.soapRequest = new SoapRequest();
//							data_object.postCharging = new PostCharging();
//							data_object._WSE = new WSClient(Global.gateway_request_timeout); // Modified by Avishkar on 17.09.2018
							data_object.thirdPartyRequest = new ThirdPartyRequest(); // Modified by Avishkar on 18.10.2018
							data_object.sendToGateway = new SendToGateway();
							
						// addition start by Avishkar on 23.05.2020
							if (Global.IS_LOGIN_ENABLE==1) { // this login request is used to get security token
								//Boolean loginflag = data_object.soapRequest.loginUser(Global.username,Global.password);
								Boolean loginflag = data_object.sendToGateway.loginUser(data_object, Global.username,Global.password);
							}
						// addition end by Avishkar on 23.05.2020

							RequestTypeOne one = new RequestTypeOne(this.flw_balancewriter,this.flw_CdrsWriter);

							/** Check and Deduct Balance, result greater than 0 means success*/
							result = one.requestTypeOne(data_object);	
							logger.debug("msisdn:[" +data_object.o_msisdn+ "] After check subtype and deduct balance result:[" +result+ "]");

							if( result > 0 )
							{
								logger.info("##>>msisdn["+data_object.o_msisdn+"] Charging successfull");
								resdata = data_object.o_days +"";
								totalBalance = data_object.camount;
								status = 1; 
							}
							else
							{
								logger.info("##>>msisdn["+data_object.o_msisdn+"] Charging Not successfull result["+result+"]");
								resdata = result+"";
								totalBalance = data_object.camount;
								status = -1;
							}


							/** Going to free the object - one */
							one = null;
						
						// addition start by Avishkar on 23.05.2020
							if (Global.IS_LOGIN_ENABLE==1) {
								//Boolean logoutflag = data_object.soapRequest.logoutUser();
								Boolean logoutflag = data_object.sendToGateway.logoutUser(data_object);
							}
						// addition end by Avishkar on 23.05.2020
							
						}
						else if(req_type == 2) /** req_type 22 intended to Check Reserve Status only */
						{

							//data_object.soapRequest = new SoapRequest();
							//data_object.postCharging = new PostCharging();
							//data_object._WSE = new WSClient(Global.gateway_request_timeout); // Modified by Avishkar on 17.09.2018
							data_object.thirdPartyRequest = new ThirdPartyRequest(); // Modified by Avishkar on 18.10.2018
							data_object.sendToGateway = new SendToGateway();
							
						// addition start by Avishkar on 23.05.2020
							if (Global.IS_LOGIN_ENABLE==1) { // this login request is used to get security token
								//Boolean loginflag = data_object.soapRequest.loginUser(Global.username,Global.password);
								Boolean loginflag = data_object.sendToGateway.loginUser(data_object, Global.username,Global.password);
							}
						// addition end by Avishkar on 23.05.2020

							RequestTypeTwo two = new RequestTypeTwo();

							logger.debug("msisdn:[" +data_object.o_msisdn+ "] Going to check resveve status only. In case subType=N then it will find resveve status");
							/** Only Check balance , resut greater than 0 means success. */
							result = two.requestTypeTwo(data_object);
							logger.info("msisdn:[" +data_object.o_msisdn+ "] After checking Reserve status result:[" +result+ "]");

							if( result > 0 )
							{
								logger.info("msisdn["+data_object.o_msisdn+"] getReserveStatus successfull");
								resdata = result +"";
							}	
							else
							{
								logger.info("##>>msisdn["+data_object.o_msisdn+"] getReserveStatus Not successfull");
								resdata = result+"";
							}

							/** Going to free the object - three */	
							two = null; 
							
						// addition start by Avishkar on 23.05.2020
							if (Global.IS_LOGIN_ENABLE==1) {
								//Boolean logoutflag = data_object.soapRequest.logoutUser();
								Boolean logoutflag = data_object.sendToGateway.logoutUser(data_object);
							}
						// addition end by Avishkar on 23.05.2020
						}
						else if(req_type == 3) /** req_type 3 intended to Check Balance only */
						{

						//	data_object.soapRequest = new SoapRequest();
						//	data_object.postCharging = new PostCharging();
						//	data_object._WSE = new WSClient(Global.gateway_request_timeout); // Modified by Avishkar on 17.09.2018
							data_object.thirdPartyRequest = new ThirdPartyRequest(); // Modified by Avishkar on 18.10.2018
							data_object.sendToGateway = new SendToGateway();
							
						// addition start by Avishkar on 23.05.2020
							if (Global.IS_LOGIN_ENABLE==1) { // this login request is used to get security token
								//Boolean loginflag = data_object.soapRequest.loginUser(Global.username,Global.password);
								Boolean loginflag = data_object.sendToGateway.loginUser(data_object, Global.username,Global.password);
							}
						// addition end by Avishkar on 23.05.2020

							RequestTypeThree three = new RequestTypeThree();

							logger.debug("msisdn:[" +data_object.o_msisdn+ "] Going to check balance only. In case subType=N then it will find subType first");
							/** Only Check balance , resut greater than 0 means success. */
							result = three.requestTypeThree(data_object);
							logger.info("msisdn:[" +data_object.o_msisdn+ "] After checking balance result:[" +result+ "]");

							if( result > 0 )
							{
								logger.info("msisdn["+data_object.o_msisdn+"] getBalance successfull");
								resdata = result +"";
								totalBalance = data_object.balance+data_object.advancebalance;
							}
							else
							{
								logger.info("##>>msisdn["+data_object.o_msisdn+"] getBalance Not successfull");
								resdata = result+"";
								totalBalance = data_object.balance;
							}

							/** Going to free the object - three */
							three = null;
							
						// addition start by Avishkar on 23.05.2020
							if (Global.IS_LOGIN_ENABLE==1) {
								//Boolean logoutflag = data_object.soapRequest.logoutUser();
								Boolean logoutflag = data_object.sendToGateway.logoutUser(data_object);
							}
						// addition end by Avishkar on 23.05.2020
						}
						else if( req_type == 6 ) /** req_type 6 intended to check subType */
						{

							//data_object.soapRequest = new SoapRequest();
							//data_object.postCharging = new PostCharging();
							//data_object._WSE = new WSClient(Global.gateway_request_timeout); // Modified by Avishkar on 17.09.2018
							data_object.thirdPartyRequest = new ThirdPartyRequest(); // Modified by Avishkar on 18.10.2018
							data_object.sendToGateway = new SendToGateway();
							
						// addition start by Avishkar on 23.05.2020
							if (Global.IS_LOGIN_ENABLE==1) { // this login request is used to get security token
								//Boolean loginflag = data_object.soapRequest.loginUser(Global.username,Global.password);
								Boolean loginflag = data_object.sendToGateway.loginUser(data_object, Global.username,Global.password);
							}
						// addition end by Avishkar on 23.05.2020

							RequestTypeSix six = new RequestTypeSix();
							logger.info("msisdn:[" +data_object.o_msisdn+ "] As [requestType = 6] going to find subType only");
							/** check subType only*/
							result = six.requestTypeSix(data_object);
							logger.info("msisdn:[" +data_object.o_msisdn+ "] After checking subtype result:[" +result+ "]");

							resdata = result+"";

							/** Going to free the object - six */
							six = null; 
							
						// addition start by Avishkar on 23.05.2020
							if (Global.IS_LOGIN_ENABLE==1) {
								//Boolean logoutflag = data_object.soapRequest.logoutUser();
								Boolean logoutflag = data_object.sendToGateway.logoutUser(data_object);
							}
						// addition end by Avishkar on 23.05.2020
						}
						else
						{
							resdata = -1+"";
							return;
						}
					}
					catch(LowBalanceException lowbal)
					{
						resdata = "-1";
						status = -1;
						//Global.rst(true);
						logger.error("Exception::::::::LowBalanceException : "+lowbal.getMessage());
						lowbal.printStackTrace();
						insertLog(data_object.o_msisdn, -1, lowbal.getMessage(), -2, 2, accountId,data_object.o_interface+","+data_object.o_action+","+data_object.o_rbtcode);

					}
					catch(SubTypeException subexp)
					{
						resdata = "-1";
						status = -1;
						//Global.rst(true);
						logger.error("###>>   "+data_object.o_msisdn+" Exception::::::::SubTypeException:",subexp);
						logger.error("Error in  SubType exception is: : "+subexp.getMessage());
						subexp.printStackTrace();
						insertLog(data_object.o_msisdn, -1, subexp.getMessage(), -2, 2, accountId,"NA");

					}
					catch(UndefindCOSException undefcos)
					{
						resdata = "-1";
						status = -1;

						//Global.rst(true);
						logger.error("###>>    "+data_object.o_msisdn+" Exception::::::::UndefindCOSException:",undefcos);
						undefcos.printStackTrace();
						insertLog(data_object.o_msisdn, -1, undefcos.getMessage(), -2, 2, accountId,"NA");
					}
					catch(java.net.SocketTimeoutException sockexp)
					{
						resdata = "-1";
						status = -1;
						//Global.rst(true);
						logger.error("###>>   "+data_object.o_msisdn+" Exception::::::::SocketTimeoutException:",sockexp);
						sockexp.printStackTrace();
						String errorDesc=((sockexp.getMessage().length()>90)?sockexp.getMessage().substring(0,89):sockexp.getMessage());
						insertLog(data_object.o_msisdn, -1, errorDesc, -3, 2, accountId,"NA");
					}
					catch(java.net.ConnectException conref)
					{
						resdata = "-1";
						status = -1;

						//Global.rst(true);
						logger.error("###>>   "+data_object.o_msisdn+" Exception::::::::ConnectException:",conref);
						conref.printStackTrace();
						String errorDesc=((conref.getMessage().length()>90)?conref.getMessage().substring(0,89):conref.getMessage());
						insertLog(data_object.o_msisdn, -1, errorDesc, -5, 2, accountId,"NA");

					}
					catch(org.apache.axis.AxisFault conref)
					{
						resdata = "-1";
						status = -1;
						//Global.rst(true);
						logger.error( "###>>   "+data_object.o_msisdn+" Exception::::::::AxisFault",conref);
						String errorDesc=((conref.getMessage().length()>90)?conref.getMessage().substring(0,89):conref.getMessage());
						insertLog(data_object.o_msisdn, -1, errorDesc, -6, 2, accountId,"NA");
					}
					catch(Exception conref)
					{
						resdata = "-1";
						status = -1;
						//Global.rst(true);
						logger.error( "###>>   "+data_object.o_msisdn+" Exception::::::::Exception:",conref);
						conref.printStackTrace();
						java.lang.Throwable throwable = conref.getCause();
						String errorDesc = ((conref.getMessage().length()>90)?conref.getMessage().substring(0,89):conref.getMessage());
						if(throwable!=null)
						{
							logger.error("###>>   "+data_object.o_msisdn+" Exception::::::::Nested Exception is:",throwable);
							if(throwable instanceof java.net.SocketTimeoutException)
							{
								insertLog(data_object.o_msisdn, -1, errorDesc, -3, 2, accountId,"NA");
							}
							else if(throwable instanceof java.net.ConnectException)
							{
								insertLog(data_object.o_msisdn, -1, errorDesc, -5, 2, accountId,"NA");
							}
							else 
							{
								insertLog(data_object.o_msisdn, -1, errorDesc, -1, 2, accountId,"NA");
							}
						}
						else
						{
							insertLog(data_object.o_msisdn, -1, errorDesc, -8, 2, accountId,"NA"); 
						}
					}

					if( Global.PER_REQ_FILE_WRITER == 1)
					{
						synchronized(flw_perRequest)
						{
							logger.debug("Going to write in log file. per_request logging.");
							flw_perRequest.writeLog(data_object.o_msisdn+","+data_object.o_action+","+data_object.o_rbtcode+","+data_object.o_interface+","+data_object.balance+","+data_object.camount+","+status+","+req_type);
						}      
					}

					data_object.o_amount = df.format(totalBalance);
					data_object.o_tariffid = data_object.o_chgcode + "";
					data_object.res_data = resdata;
					//Global.rst(true);
					Global.que_send.put (data_object); 
					logger.info("msisdn:[" +data_object.o_msisdn+ "] INSERTED in ResponseQueue  data_object:["+data_object+"]");

				}
				catch(Exception ee)
				{
					//Global.rst(true);
					logger.error("###>>"+data_object.o_msisdn+"  Exception",ee);
					insertLog(data_object.o_msisdn, -1, ee.getMessage().substring(0,24), -8,2, accountId,"NA");
				}
			}
			
			//modify by Avishkar for HttpUrlTester
			/*HttpUrlTester httpUrl = new HttpUrlTester();
			String reqType = null;
			if (data_object.o_action==1||data_object.o_action==2) { //1 for Subscribe OR 2 for Subscription Renewal
				reqType="01"; // Subscription request
			}
			else if (data_object.o_action==3||data_object.o_action==4||data_object.o_action==8) { // 3 for rbt purchase/renew OR 4 for rbt gift OR 8 for recorded rbt/recorded rbt renew
				reqType="02"; // Tone request
			}
			httpUrl.sendPost(data_object.o_msisdn, reqType);*/
				
			// addition start by Avishkar on 26.11.2018
				} else if (data_object.redirectTagValue.equalsIgnoreCase("Redirect") && Global.IS_SECOND_CHARGING_ENABLE!=1) { // it means Charging itself is acting as Second Charging, so it will not redirect hit to any other charging.
					int result 	= -1;
					int req_type 	= -1;
					//int status 	= 0;
					double  totalBalance	= 0.0;
					String resdata		= "";
					
					req_type = data_object.o_reqtype;
					if(req_type == 1) /** req_type 1 intended to Deduct Balance in case of Redirect */
					{
						data_object.thirdPartyRequest = new ThirdPartyRequest(); // Modified by Avishkar on 18.10.2018
						data_object.sendToGateway = new SendToGateway();
						data_object.o_chgcode = Integer.parseInt(data_object.o_tariffid);
						
						logger.info("msisdn:["+data_object.o_msisdn+"] Going to deductBalance. chgCode:["+data_object.o_chgcode+"] chgAmount:["+data_object.o_camount+"]");
						result = data_object.sendToGateway.debitBalance(data_object, data_object.o_camount);
						logger.debug("msisdn:[" +data_object.o_msisdn+ "] After deduct balance result:[" +result+ "]");

						if( result == 1 )
						{
							logger.info("##>>msisdn["+data_object.o_msisdn+"] Charging successfull");
							resdata = result +""; //data_object.o_days +"";
							//totalBalance = data_object.o_camount; //data_object.camount;
							//status = 1; 
						}
						else
						{
							logger.info("##>>msisdn["+data_object.o_msisdn+"] Charging Not successfull result["+result+"]");
							resdata = result+"";
							//totalBalance = data_object.o_camount; //data_object.camount;
							//status = -1;
						}
					}
					else if(req_type == 3) /** req_type 3 intended to Check Balance only */
					{

						data_object.thirdPartyRequest = new ThirdPartyRequest(); // Modified by Avishkar on 18.10.2018
						data_object.sendToGateway = new SendToGateway();
						// addition start by Avishkar on 05.03.2019
						if (data_object.o_subtype.equalsIgnoreCase("P")) {
							/** For prepaid only.  */
							data_object.o_accountType = 1;
						}
						// addition end by Avishkar on 05.03.2019
						logger.info("msisdn:["+data_object.o_msisdn+"] Going to checkBalance... data_object.o_accountType: ["+data_object.o_accountType+"]");
						result = data_object.sendToGateway.checkBalance(data_object);
						if( result == 1 )
						{
							logger.info("msisdn:["+data_object.o_msisdn+"] OK, after checkBalance balance:[" +data_object.balance+ "] getBalance successfull");
							resdata = result +"";
							totalBalance = data_object.balance+data_object.advancebalance;
						}
						else
						{
							logger.info("msisdn:["+data_object.o_msisdn+"] NOT OK After checkbalance result:["+result+"] getBalance Not successfull");
							resdata = result+"";
							totalBalance = data_object.balance;
						}
					}
					else
					{
						logger.info("msisdn:["+data_object.o_msisdn+"] Wrong reqType send to Second Charging, reqType :["+req_type+"]");
						resdata = -1+"";
						//return;
					}
					
					data_object.o_amount = df.format(totalBalance);
					//data_object.o_tariffid = data_object.o_chgcode + "";
					logger.info("msisdn:["+data_object.o_msisdn+"] res_data:["+resdata+"]");
					data_object.res_data = resdata;
					//Global.rst(true);
					Global.que_send.put (data_object); 
					logger.info("msisdn:[" +data_object.o_msisdn+ "] INSERTED in ResponseQueue  data_object:["+data_object+"]");
					
				} else {
					logger.info("msisdn:[" +data_object.o_msisdn+ "] Request send to Wrong Charging. This Charging accept request only from Other Charging.");
					return;
				}
			// modification ends by Avishkar on 26.11.2018


			}
			catch(Exception ee)
			{
				logger.fatal("Exception::::::::"+ee.toString());
				ee.printStackTrace();
				//System.exit(1);
			}
		}
	}//end of run
}
