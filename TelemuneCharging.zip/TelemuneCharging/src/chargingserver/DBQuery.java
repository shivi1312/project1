package chargingserver;

import org.apache.log4j.Logger;

/**
 * 
 * @author avishkar
 * this class is added by Avishkar in reference to the Dual DB support of Charging Module.
 */
public class DBQuery {

	private static Logger logger = Logger.getLogger("DBQuery");
	
	public static String fetchCpIdRbtCode="select RBT_CODE,CONTENT_PROVIDER_CODE from crbt_rbt";
	public static String fetchPrepaidCharges="select CHARGING_CODE,AMOUNT_PRE from CRBT_CHARGING_CODE";
	public static String fetchPostpaidCharges="select CHARGING_CODE,AMOUNT_POST from CRBT_CHARGING_CODE";
	public static String fetchPrepaidProductCodes="select CHARGING_CODE,TARIFF_PRE from CRBT_CHARGING_CODE";
	public static String fetchPostpaidProductCodes="select CHARGING_CODE,TARIFF_POST from CRBT_CHARGING_CODE";
	public static String fetchPostpaidCheck="select param_tag,param_value from crbt_app_config_params where param_tag in ('POSTPAID_CHARGING_ENABLE','DEFAULT_RATE_PLAN')";
	public static String fetchCOS="select COS_NAME,IS_CORE,IS_ADVANCE from CHG_COS_MASTER where is_enable=1";
	public static String fetchCdrId="Select crbt_cdr_id.nextval from dual";
	//public static String fetchCpCode="select RBT_CODE,CONTENT_PROVIDER_CODE from crbt_rbt where RBT_CODE="+"rbtCode+";
	public static String fetchCpCode="select RBT_CODE,CONTENT_PROVIDER_CODE from crbt_rbt where RBT_CODE=?";
	public static String fetchSubType="select SUB_TYPE from crbt_subscriber_master where MSISDN=?";
	public static String fetchRequestId="select crbt_chg_reqid.nextVal as reqid  from dual";
	//public static String fetchSubTypeFromDb="select SUB_TYPE from " +Global.SUB_TYPE_TABLE+ " where MSISDN = ?";
	public static String fetchSubTypeFromDb="select SUB_TYPE from ${Global.SUB_TYPE_TABLE} where MSISDN = ?";
	public static String saveChgRequest="insert into crbt_chg_request(req_date,req_id,msisdn,charging_code,description, account_type) values(sysdate,CRBT_CHG_REQID.nextval,?,?,?,?)";
	public static String saveChgResponse="insert into crbt_chg_response(req_date,req_id,msisdn,charging_code,description,account_type,resp_code,other) values(sysdate,CRBT_CHG_REQID.nextval,?,?,?,?,?,?)";
	//public static String saveCdrsRecord="insert into CRBT_CDRS(cdr_id,msisdn,tariffid,action,interface,service_class,da_id,create_date,fmsisdn,rbt_code,amount,pack_id,DAYS,CP_CODE) values(?,?,?,?,?,?,?,sysdate,?,?,?,?,?,?)";
	public static String saveCdrsRecord="insert into CRBT_CDRS(cdr_id,msisdn,tariffid,action,interface,service_class,da_id,create_date,fmsisdn,rbt_code,amount,pack_id,DAYS,CP_CODE,TRANS_ID,CORP_ID) values(?,?,?,?,?,?,?,sysdate,?,?,?,?,?,?,?,?)"; // modified by Avishkar on 10.01.2020
	public static String saveChgLog="insert into CRBT_CHARGING_LOG (REQ_ID,MSISDN,CHARGING_CODE,RESPONSE,RESPONSE_TIME) values(?,?,?,?,sysdate)";
	
	public static void constructQuery(String dbType) {
		try {
			switch (dbType.toLowerCase()) {
			case "oracle":
				fetchCpIdRbtCode="select RBT_CODE,CONTENT_PROVIDER_CODE from crbt_rbt";
				fetchPrepaidCharges="select CHARGING_CODE,AMOUNT_PRE from CRBT_CHARGING_CODE";
				fetchPostpaidCharges="select CHARGING_CODE,AMOUNT_POST from CRBT_CHARGING_CODE";
				fetchPrepaidProductCodes="select CHARGING_CODE,TARIFF_PRE from CRBT_CHARGING_CODE";
				fetchPostpaidProductCodes="select CHARGING_CODE,TARIFF_POST from CRBT_CHARGING_CODE";
				fetchPostpaidCheck="select param_tag,param_value from crbt_app_config_params where param_tag in ('POSTPAID_CHARGING_ENABLE','DEFAULT_RATE_PLAN')";
				fetchCOS="select COS_NAME,IS_CORE,IS_ADVANCE from CHG_COS_MASTER where is_enable=1";
				fetchCdrId="Select crbt_cdr_id.nextval from dual";
				//fetchCpCode="select RBT_CODE,CONTENT_PROVIDER_CODE from crbt_rbt where RBT_CODE="+"rbtCode+";
				fetchCpCode="select RBT_CODE,CONTENT_PROVIDER_CODE from crbt_rbt where RBT_CODE=?";
				fetchSubType="select SUB_TYPE from crbt_subscriber_master where MSISDN=?";
				fetchRequestId="select crbt_chg_reqid.nextVal as reqid  from dual";
				//fetchSubTypeFromDb="select SUB_TYPE from " +Global.SUB_TYPE_TABLE+ " where MSISDN = ?";
				fetchSubTypeFromDb="select SUB_TYPE from ${Global.SUB_TYPE_TABLE} where MSISDN = ?";
				saveChgRequest="insert into crbt_chg_request(req_date,req_id,msisdn,charging_code,description, account_type) values(sysdate,CRBT_CHG_REQID.nextval,?,?,?,?)";
				saveChgResponse="insert into crbt_chg_response(req_date,req_id,msisdn,charging_code,description,account_type,resp_code,other) values(sysdate,CRBT_CHG_REQID.nextval,?,?,?,?,?,?)";
				//saveCdrsRecord="insert into CRBT_CDRS(cdr_id,msisdn,tariffid,action,interface,service_class,da_id,create_date,fmsisdn,rbt_code,amount,pack_id,DAYS,CP_CODE) values(?,?,?,?,?,?,?,sysdate,?,?,?,?,?,?)";
				saveCdrsRecord="insert into CRBT_CDRS(cdr_id,msisdn,tariffid,action,interface,service_class,da_id,create_date,fmsisdn,rbt_code,amount,pack_id,DAYS,CP_CODE,TRANS_ID,CORP_ID) values(?,?,?,?,?,?,?,sysdate,?,?,?,?,?,?,?,?)"; // modified by Avishkar on 10.01.2020
				saveChgLog="insert into CRBT_CHARGING_LOG (REQ_ID,MSISDN,CHARGING_CODE,RESPONSE,RESPONSE_TIME) values(?,?,?,?,sysdate)";
				logger.info("Oracle queries loaded successfully");
				break;

			case "mysql":
				fetchCpIdRbtCode="select RBT_CODE,CONTENT_PROVIDER_CODE from crbt_rbt";
				fetchPrepaidCharges="select CHARGING_CODE,AMOUNT_PRE from CRBT_CHARGING_CODE";
				fetchPostpaidCharges="select CHARGING_CODE,AMOUNT_POST from CRBT_CHARGING_CODE";
				fetchPrepaidProductCodes="select CHARGING_CODE,TARIFF_PRE from CRBT_CHARGING_CODE";
				fetchPostpaidProductCodes="select CHARGING_CODE,TARIFF_POST from CRBT_CHARGING_CODE";
				fetchPostpaidCheck="select param_tag,param_value from crbt_app_config_params where param_tag in ('POSTPAID_CHARGING_ENABLE','DEFAULT_RATE_PLAN')";
				fetchCOS="select COS_NAME,IS_CORE,IS_ADVANCE from CHG_COS_MASTER where is_enable=1";
				fetchCdrId="";//not required
				fetchCpCode="select RBT_CODE,CONTENT_PROVIDER_CODE from crbt_rbt where RBT_CODE=?";
				fetchSubType="select SUB_TYPE from crbt_subscriber_master where MSISDN=?";
				fetchRequestId="";//not required
				fetchSubTypeFromDb="select SUB_TYPE from ${Global.SUB_TYPE_TABLE} where MSISDN = ?";
				saveChgRequest="insert into crbt_chg_request(req_date,msisdn,charging_code,description, account_type) values(now(),?,?,?,?)"; // this table is not in use currently
				saveChgResponse="insert into crbt_chg_response(req_date,msisdn,charging_code,description,account_type,resp_code,other) values(now(),?,?,?,?,?,?)"; // reqId is autoincremented
				//saveCdrsRecord="insert into CRBT_CDRS(cdr_id,msisdn,tariffid,action,interface,service_class,da_id,create_date,fmsisdn,rbt_code,amount,pack_id,DAYS,CP_CODE) values(?,?,?,?,?,?,?,now(),?,?,?,?,?,?)";
				saveCdrsRecord="insert into CRBT_CDRS(cdr_id,msisdn,tariffid,action,interface,service_class,da_id,create_date,fmsisdn,rbt_code,amount,pack_id,DAYS,CP_CODE,TRANS_ID,CORP_ID) values(?,?,?,?,?,?,?,now(),?,?,?,?,?,?,?,?)"; // modified by Avishkar on 10.01.2020
				saveChgLog="insert into CRBT_CHARGING_LOG (REQ_ID,MSISDN,CHARGING_CODE,RESPONSE,RESPONSE_TIME) values(?,?,?,?,now())";
				logger.info("mysql queries loaded successfully");
				break;
				
			default:
				break;
			}
		} catch (Exception e) {
			logger.error("Exception in constructQuery method for dbType:["+dbType+"], ",e);
			e.printStackTrace();
		}
	}
	
}
