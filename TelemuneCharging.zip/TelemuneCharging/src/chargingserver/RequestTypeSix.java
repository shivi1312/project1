package chargingserver;

import FileBaseLogging.*;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.*;
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.security.MessageDigest;
import java.text.DecimalFormat;

public class RequestTypeSix
{
	private static Logger logger = Logger.getLogger("RequestTypeSix");

	/** This medhod find subType from hlr , on success it returs 1 on fail it returns -1 */
	public int requestTypeSix(Data_Object data_object)throws UndefindCOSException,SocketTimeoutException,ConnectException,Exception
	{
		int  prepaid_status = -1;
		int resp_data = -1;

		logger.debug("msisdn:[" +data_object.o_msisdn+ "] requestTypeSix START here..............");
		prepaid_status = -1;

		/**  method hlrRequest returns  eihter 0 for Prepaid or 1 for Postpaid or -1 for no response or 2 for Dual or 3 for Hybrid. */
		prepaid_status = data_object.sendToGateway.findSubType( data_object );
		logger.info("msisdn:[" +data_object.o_msisdn+ "] status received after finding subType   status:[" +prepaid_status+ "]");

		if(prepaid_status == 0)
		{
			data_object.o_subtype = "P";       
			resp_data =1;     
		}
		else if(prepaid_status == 1)
		{
			data_object.o_subtype = "O";    
			resp_data =1;
		}
		else if( prepaid_status == 2 || prepaid_status == 3)
		{
			// treating as preopaid incase of dual and hybrid
			//data_object.o_subtype = "N";
			data_object.o_subtype = "N";
			resp_data =1;
		}
		logger.info("msisdn:[" +data_object.o_msisdn+ "] decided subType::["+data_object.o_subtype+"]");
		return resp_data;
	}		
}
