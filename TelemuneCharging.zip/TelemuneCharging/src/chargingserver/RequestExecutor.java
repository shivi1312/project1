package chargingserver;

import java.util.concurrent.ThreadPoolExecutor;

import FileBaseLogging.*;
import java.io.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import org.apache.log4j.*;


public class RequestExecutor implements Runnable
{
	static final Logger logger=Logger.getLogger(RequestExecutor.class);
	private ThreadPoolExecutor contentexecutorPool;
	private int seconds;

	private boolean run=true;


	FileLogWriter flw_perRequest = null;
	FileLogWriter flw_balancewriter = null;
	FileLogWriter flw_CdrsWriter = null;



	public RequestExecutor(FileLogWriter flw_perRequest,FileLogWriter flw_balancewriter,FileLogWriter flw_cdrswriter,ThreadPoolExecutor executor)
	{
		this.contentexecutorPool = executor;
		this.flw_balancewriter = flw_balancewriter;
		this.flw_CdrsWriter = flw_cdrswriter; 
		this.flw_perRequest=flw_perRequest;

	}

	public void shutdown(){
		this.run=false;
	}

	@Override
		public void run()
		{
			//int activeCount  = 0;
			//int temp_cntr = 0;
			while( run )
			{
				try
				{
					if (Global.que.isEmpty())
					{
						try
						{		
							Thread.sleep(2);				
							/*
							if(temp_cntr==3000)
							{
								break;
							}
							else
								temp_cntr++;
							*/
						}
						catch(Exception e)
						{
							logger.error("exception in charging server");

						}
					}
					else
					{
						//temp_cntr=0;
						Data_Object data_object = null;//new Data_Object();
						data_object = (Data_Object) Global.que.poll();
						logger.info(">>>>>>>>>>>>>>>> Polling request for process execution : "+data_object);
						if( data_object == null ) 
						{
							logger.info (" # Request data is null");
							continue;
						}
						else
						{
							contentexecutorPool.execute(new ChargingServer(flw_perRequest,flw_balancewriter,flw_CdrsWriter,data_object));
						}
					}
				}
				catch(Exception es)
				{
					es.printStackTrace();
				}


				try 
				{
					Thread.sleep(seconds*1000);
				}catch (InterruptedException e) { e.printStackTrace(); }
			}
		}
}
