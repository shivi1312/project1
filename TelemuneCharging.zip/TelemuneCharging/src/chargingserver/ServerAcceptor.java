package chargingserver;

import java.io.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import org.apache.log4j.*;
import commonutil.*;

public class ServerAcceptor implements Runnable 
{
	ServerSocket serverSocket = null;
	Logger logger = Logger.getLogger("ServerAcceptor");
	int port = -1;
//	TLVAppInterface tcp_req = null; // commented by ashu 01-07-2019 	
//	RequestReader requestReader = new RequestReader(); // commented by ashu 01-07-2019 	
	Socket socket = null; // ashu 01-07-2019 	
	ServerAcceptor(int port)
	{
		this.port=port;
	}
	public void run()
	{
		try 
		{
			try
			{
                                if( serverSocket == null )
                                {
                                        serverSocket = new ServerSocket(port);
                                }
                                else if ( serverSocket.isClosed() )
                                {
                                        serverSocket = new ServerSocket(port);
                                }
			}
			catch(Exception e)
			{
				logger.fatal("Exception while createing SOCKET" +e.toString());
				return;
			}
	
			while(true)
			{
			// commented by ashu 01-07-2019 
			/*	if( tcp_req == null )
				{
					tcp_req = new TLVAppInterface();
				}

				Socket socket = null;
			*/
			// ashu 01-07-2019 	
				try
				{
					socket = serverSocket.accept(); //Listens for a connection to be made to this socket and accepts it.
					logger.debug("########################Connection accepted response at " + socket.getInetAddress() + ":" + socket.getPort());
					//requestReader.readPacket(socket, tcp_req ); // commented by ashu 01-07-2019
				 	new Thread (new RequestReader("threadCheckRequest"+socket.toString(),socket)).start();  // modified by ashu 01-07-2019
				}
				catch(Exception e)
				{
					logger.fatal("got exception in  thread" +e.getMessage());
					if( socket != null )
					{
						try
						{
							socket.close();
						}
						catch(Exception es){ es.printStackTrace();}
					}
				}
				try
				{
					Thread.sleep(1);
				}
				catch(Exception eee){}
			}

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				serverSocket.close();
				logger.debug("All Threads  stoped: ");
				System.exit(1);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Threads cannot stoped: "+ e.toString());
			}
		}
	}
}
